<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-10-11 17:25:04 --> Config Class Initialized
INFO - 2016-10-11 17:25:04 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:25:04 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:25:04 --> Utf8 Class Initialized
INFO - 2016-10-11 17:25:04 --> URI Class Initialized
DEBUG - 2016-10-11 17:25:04 --> No URI present. Default controller set.
INFO - 2016-10-11 17:25:04 --> Router Class Initialized
INFO - 2016-10-11 17:25:04 --> Output Class Initialized
INFO - 2016-10-11 17:25:05 --> Security Class Initialized
DEBUG - 2016-10-11 17:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:25:05 --> Input Class Initialized
INFO - 2016-10-11 17:25:05 --> Language Class Initialized
INFO - 2016-10-11 17:25:05 --> Language Class Initialized
INFO - 2016-10-11 17:25:05 --> Config Class Initialized
INFO - 2016-10-11 17:25:05 --> Loader Class Initialized
INFO - 2016-10-11 17:25:05 --> Helper loaded: url_helper
INFO - 2016-10-11 17:25:06 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:25:06 --> Controller Class Initialized
DEBUG - 2016-10-11 17:25:06 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:25:06 --> Model Class Initialized
INFO - 2016-10-11 17:25:06 --> Model Class Initialized
ERROR - 2016-10-11 17:25:06 --> Unable to delete cache file for 
DEBUG - 2016-10-11 17:25:06 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-11 17:25:06 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-11 17:25:06 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-11 17:25:06 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/dashboard.php
DEBUG - 2016-10-11 17:25:06 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-11 17:25:06 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-11 17:25:06 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:07 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:07 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:07 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:07 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:07 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:07 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:07 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:07 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:07 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:07 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:07 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:07 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:07 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:07 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:07 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:07 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:07 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:07 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:07 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:07 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:07 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:07 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:07 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:07 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:07 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:07 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:07 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:07 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:07 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:07 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:07 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:07 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:07 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:07 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:07 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:07 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:07 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:07 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:07 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:07 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:07 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:08 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:08 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:08 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:08 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:08 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:08 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:08 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:08 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:08 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:08 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:08 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:08 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:08 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:08 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:08 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:08 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:08 --> Database Driver Class Initialized
DEBUG - 2016-10-11 17:25:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-11 17:25:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-11 17:25:08 --> Final output sent to browser
INFO - 2016-10-11 17:25:08 --> Config Class Initialized
DEBUG - 2016-10-11 17:25:08 --> Total execution time: 4.3991
INFO - 2016-10-11 17:25:08 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:25:08 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:25:08 --> Utf8 Class Initialized
INFO - 2016-10-11 17:25:08 --> URI Class Initialized
INFO - 2016-10-11 17:25:08 --> Router Class Initialized
INFO - 2016-10-11 17:25:08 --> Output Class Initialized
INFO - 2016-10-11 17:25:08 --> Security Class Initialized
DEBUG - 2016-10-11 17:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:25:08 --> Input Class Initialized
INFO - 2016-10-11 17:25:08 --> Language Class Initialized
INFO - 2016-10-11 17:25:08 --> Language Class Initialized
INFO - 2016-10-11 17:25:08 --> Config Class Initialized
INFO - 2016-10-11 17:25:08 --> Loader Class Initialized
INFO - 2016-10-11 17:25:08 --> Helper loaded: url_helper
INFO - 2016-10-11 17:25:09 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:25:09 --> Controller Class Initialized
DEBUG - 2016-10-11 17:25:09 --> login MX_Controller Initialized
INFO - 2016-10-11 17:25:09 --> Model Class Initialized
INFO - 2016-10-11 17:25:09 --> Model Class Initialized
DEBUG - 2016-10-11 17:25:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/login.php
INFO - 2016-10-11 17:25:09 --> Final output sent to browser
DEBUG - 2016-10-11 17:25:09 --> Total execution time: 0.6456
INFO - 2016-10-11 17:25:14 --> Config Class Initialized
INFO - 2016-10-11 17:25:14 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:25:14 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:25:14 --> Utf8 Class Initialized
INFO - 2016-10-11 17:25:14 --> URI Class Initialized
INFO - 2016-10-11 17:25:14 --> Router Class Initialized
INFO - 2016-10-11 17:25:14 --> Output Class Initialized
INFO - 2016-10-11 17:25:14 --> Security Class Initialized
DEBUG - 2016-10-11 17:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:25:14 --> Input Class Initialized
INFO - 2016-10-11 17:25:14 --> Language Class Initialized
INFO - 2016-10-11 17:25:14 --> Language Class Initialized
INFO - 2016-10-11 17:25:14 --> Config Class Initialized
INFO - 2016-10-11 17:25:14 --> Loader Class Initialized
INFO - 2016-10-11 17:25:14 --> Helper loaded: url_helper
INFO - 2016-10-11 17:25:14 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:25:14 --> Controller Class Initialized
DEBUG - 2016-10-11 17:25:14 --> login MX_Controller Initialized
INFO - 2016-10-11 17:25:14 --> Model Class Initialized
INFO - 2016-10-11 17:25:14 --> Model Class Initialized
INFO - 2016-10-11 17:25:14 --> Final output sent to browser
DEBUG - 2016-10-11 17:25:14 --> Total execution time: 0.4479
INFO - 2016-10-11 17:25:15 --> Config Class Initialized
INFO - 2016-10-11 17:25:15 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:25:15 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:25:15 --> Utf8 Class Initialized
INFO - 2016-10-11 17:25:15 --> URI Class Initialized
INFO - 2016-10-11 17:25:15 --> Router Class Initialized
INFO - 2016-10-11 17:25:15 --> Output Class Initialized
INFO - 2016-10-11 17:25:15 --> Security Class Initialized
DEBUG - 2016-10-11 17:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:25:15 --> Input Class Initialized
INFO - 2016-10-11 17:25:15 --> Language Class Initialized
INFO - 2016-10-11 17:25:15 --> Language Class Initialized
INFO - 2016-10-11 17:25:15 --> Config Class Initialized
INFO - 2016-10-11 17:25:15 --> Loader Class Initialized
INFO - 2016-10-11 17:25:15 --> Helper loaded: url_helper
INFO - 2016-10-11 17:25:15 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:25:15 --> Controller Class Initialized
DEBUG - 2016-10-11 17:25:15 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:25:15 --> Model Class Initialized
INFO - 2016-10-11 17:25:15 --> Model Class Initialized
ERROR - 2016-10-11 17:25:15 --> Unable to delete cache file for admin/index
DEBUG - 2016-10-11 17:25:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-11 17:25:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-11 17:25:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-11 17:25:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/dashboard.php
DEBUG - 2016-10-11 17:25:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-11 17:25:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-11 17:25:15 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:15 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:15 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:15 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:15 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:15 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:15 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:17 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:17 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:17 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:17 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:17 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:17 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:17 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:17 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:17 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:17 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:17 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:17 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:17 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:17 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:17 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:17 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:17 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:17 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:17 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:17 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:17 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:17 --> Database Driver Class Initialized
DEBUG - 2016-10-11 17:25:17 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-11 17:25:17 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-11 17:25:17 --> Final output sent to browser
DEBUG - 2016-10-11 17:25:17 --> Total execution time: 2.7983
INFO - 2016-10-11 17:25:26 --> Config Class Initialized
INFO - 2016-10-11 17:25:26 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:25:26 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:25:26 --> Utf8 Class Initialized
INFO - 2016-10-11 17:25:26 --> URI Class Initialized
INFO - 2016-10-11 17:25:26 --> Router Class Initialized
INFO - 2016-10-11 17:25:26 --> Output Class Initialized
INFO - 2016-10-11 17:25:26 --> Security Class Initialized
DEBUG - 2016-10-11 17:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:25:26 --> Input Class Initialized
INFO - 2016-10-11 17:25:26 --> Language Class Initialized
INFO - 2016-10-11 17:25:26 --> Language Class Initialized
INFO - 2016-10-11 17:25:26 --> Config Class Initialized
INFO - 2016-10-11 17:25:26 --> Loader Class Initialized
INFO - 2016-10-11 17:25:26 --> Helper loaded: url_helper
INFO - 2016-10-11 17:25:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:25:26 --> Controller Class Initialized
DEBUG - 2016-10-11 17:25:26 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:25:26 --> Model Class Initialized
INFO - 2016-10-11 17:25:26 --> Model Class Initialized
ERROR - 2016-10-11 17:25:26 --> Unable to delete cache file for admin/index/data/anggota
DEBUG - 2016-10-11 17:25:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-11 17:25:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-11 17:25:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-11 17:25:26 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-11 17:25:26 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-11 17:25:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-11 17:25:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-11 17:25:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-11 17:25:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:28 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:28 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:28 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:28 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:28 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:28 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:28 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:28 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:28 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:28 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:28 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:28 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:28 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:28 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:28 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:28 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:28 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:28 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:28 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:28 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:28 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:28 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:28 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:28 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:28 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:28 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:28 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:28 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:28 --> Database Driver Class Initialized
DEBUG - 2016-10-11 17:25:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-11 17:25:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-11 17:25:29 --> Final output sent to browser
DEBUG - 2016-10-11 17:25:29 --> Total execution time: 2.7621
INFO - 2016-10-11 17:25:33 --> Config Class Initialized
INFO - 2016-10-11 17:25:33 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:25:33 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:25:33 --> Utf8 Class Initialized
INFO - 2016-10-11 17:25:33 --> URI Class Initialized
INFO - 2016-10-11 17:25:33 --> Router Class Initialized
INFO - 2016-10-11 17:25:34 --> Output Class Initialized
INFO - 2016-10-11 17:25:34 --> Security Class Initialized
DEBUG - 2016-10-11 17:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:25:34 --> Input Class Initialized
INFO - 2016-10-11 17:25:34 --> Language Class Initialized
INFO - 2016-10-11 17:25:34 --> Language Class Initialized
INFO - 2016-10-11 17:25:34 --> Config Class Initialized
INFO - 2016-10-11 17:25:34 --> Loader Class Initialized
INFO - 2016-10-11 17:25:34 --> Helper loaded: url_helper
INFO - 2016-10-11 17:25:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:25:34 --> Controller Class Initialized
DEBUG - 2016-10-11 17:25:34 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:25:34 --> Model Class Initialized
INFO - 2016-10-11 17:25:34 --> Model Class Initialized
ERROR - 2016-10-11 17:25:34 --> Unable to delete cache file for admin/index/detail_anggota/356a192b7913b04c54574d18c28d46e6395428ab
DEBUG - 2016-10-11 17:25:34 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-11 17:25:34 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-11 17:25:34 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
INFO - 2016-10-11 17:25:34 --> Database Driver Class Initialized
DEBUG - 2016-10-11 17:25:34 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_pinjaman.php
INFO - 2016-10-11 17:25:34 --> Database Driver Class Initialized
DEBUG - 2016-10-11 17:25:34 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_tabungan.php
DEBUG - 2016-10-11 17:25:34 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/profile_anggota.php
DEBUG - 2016-10-11 17:25:34 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-11 17:25:34 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-11 17:25:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:36 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:36 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:36 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:36 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:36 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:36 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:36 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:36 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:36 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:36 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:36 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:36 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:36 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:36 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:36 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:36 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:36 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:36 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:36 --> Database Driver Class Initialized
DEBUG - 2016-10-11 17:25:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-11 17:25:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-11 17:25:36 --> Final output sent to browser
DEBUG - 2016-10-11 17:25:36 --> Total execution time: 2.7719
INFO - 2016-10-11 17:25:36 --> Config Class Initialized
INFO - 2016-10-11 17:25:36 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:25:36 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:25:36 --> Utf8 Class Initialized
INFO - 2016-10-11 17:25:36 --> URI Class Initialized
INFO - 2016-10-11 17:25:36 --> Router Class Initialized
INFO - 2016-10-11 17:25:36 --> Output Class Initialized
INFO - 2016-10-11 17:25:37 --> Security Class Initialized
DEBUG - 2016-10-11 17:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:25:37 --> Input Class Initialized
INFO - 2016-10-11 17:25:37 --> Language Class Initialized
INFO - 2016-10-11 17:25:37 --> Language Class Initialized
INFO - 2016-10-11 17:25:37 --> Config Class Initialized
INFO - 2016-10-11 17:25:37 --> Loader Class Initialized
INFO - 2016-10-11 17:25:37 --> Helper loaded: url_helper
INFO - 2016-10-11 17:25:37 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:25:37 --> Controller Class Initialized
DEBUG - 2016-10-11 17:25:37 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:25:37 --> Model Class Initialized
INFO - 2016-10-11 17:25:37 --> Model Class Initialized
ERROR - 2016-10-11 17:25:37 --> Unable to delete cache file for admin/index/detail_anggota/images/picture.jpg
DEBUG - 2016-10-11 17:25:37 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-11 17:25:37 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-11 17:25:37 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
ERROR - 2016-10-11 17:25:37 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 16
ERROR - 2016-10-11 17:25:37 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 19
ERROR - 2016-10-11 17:25:37 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 22
ERROR - 2016-10-11 17:25:38 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 38
INFO - 2016-10-11 17:25:38 --> Database Driver Class Initialized
DEBUG - 2016-10-11 17:25:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_pinjaman.php
ERROR - 2016-10-11 17:25:38 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 41
INFO - 2016-10-11 17:25:38 --> Database Driver Class Initialized
DEBUG - 2016-10-11 17:25:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_tabungan.php
DEBUG - 2016-10-11 17:25:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/profile_anggota.php
DEBUG - 2016-10-11 17:25:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-11 17:25:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-11 17:25:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:40 --> Database Driver Class Initialized
DEBUG - 2016-10-11 17:25:40 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-11 17:25:40 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-11 17:25:40 --> Final output sent to browser
DEBUG - 2016-10-11 17:25:40 --> Total execution time: 4.1022
INFO - 2016-10-11 17:25:45 --> Config Class Initialized
INFO - 2016-10-11 17:25:45 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:25:45 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:25:45 --> Utf8 Class Initialized
INFO - 2016-10-11 17:25:45 --> URI Class Initialized
INFO - 2016-10-11 17:25:45 --> Router Class Initialized
INFO - 2016-10-11 17:25:45 --> Output Class Initialized
INFO - 2016-10-11 17:25:45 --> Security Class Initialized
DEBUG - 2016-10-11 17:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:25:45 --> Input Class Initialized
INFO - 2016-10-11 17:25:45 --> Language Class Initialized
INFO - 2016-10-11 17:25:45 --> Language Class Initialized
INFO - 2016-10-11 17:25:46 --> Config Class Initialized
INFO - 2016-10-11 17:25:46 --> Loader Class Initialized
INFO - 2016-10-11 17:25:46 --> Helper loaded: url_helper
INFO - 2016-10-11 17:25:46 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:25:46 --> Controller Class Initialized
DEBUG - 2016-10-11 17:25:46 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:25:46 --> Model Class Initialized
INFO - 2016-10-11 17:25:46 --> Model Class Initialized
ERROR - 2016-10-11 17:25:46 --> Unable to delete cache file for admin/index/getRaportAngsuran/356a192b7913b04c54574d18c28d46e6395428ab
DEBUG - 2016-10-11 17:25:46 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/raport_angsuran.php
INFO - 2016-10-11 17:25:46 --> Final output sent to browser
DEBUG - 2016-10-11 17:25:46 --> Total execution time: 0.8852
INFO - 2016-10-11 17:25:52 --> Config Class Initialized
INFO - 2016-10-11 17:25:52 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:25:52 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:25:52 --> Utf8 Class Initialized
INFO - 2016-10-11 17:25:52 --> URI Class Initialized
INFO - 2016-10-11 17:25:52 --> Router Class Initialized
INFO - 2016-10-11 17:25:52 --> Output Class Initialized
INFO - 2016-10-11 17:25:52 --> Security Class Initialized
DEBUG - 2016-10-11 17:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:25:53 --> Input Class Initialized
INFO - 2016-10-11 17:25:53 --> Language Class Initialized
INFO - 2016-10-11 17:25:53 --> Language Class Initialized
INFO - 2016-10-11 17:25:53 --> Config Class Initialized
INFO - 2016-10-11 17:25:53 --> Loader Class Initialized
INFO - 2016-10-11 17:25:53 --> Helper loaded: url_helper
INFO - 2016-10-11 17:25:53 --> Database Driver Class Initialized
INFO - 2016-10-11 17:25:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:25:53 --> Controller Class Initialized
DEBUG - 2016-10-11 17:25:53 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:25:53 --> Model Class Initialized
INFO - 2016-10-11 17:25:53 --> Model Class Initialized
ERROR - 2016-10-11 17:25:53 --> Unable to delete cache file for admin/index/getRaportAngsuran/356a192b7913b04c54574d18c28d46e6395428ab
DEBUG - 2016-10-11 17:25:53 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/raport_angsuran.php
INFO - 2016-10-11 17:25:53 --> Final output sent to browser
DEBUG - 2016-10-11 17:25:53 --> Total execution time: 0.6887
INFO - 2016-10-11 17:26:06 --> Config Class Initialized
INFO - 2016-10-11 17:26:06 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:26:06 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:26:06 --> Utf8 Class Initialized
INFO - 2016-10-11 17:26:06 --> URI Class Initialized
INFO - 2016-10-11 17:26:06 --> Router Class Initialized
INFO - 2016-10-11 17:26:06 --> Output Class Initialized
INFO - 2016-10-11 17:26:06 --> Security Class Initialized
DEBUG - 2016-10-11 17:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:26:06 --> Input Class Initialized
INFO - 2016-10-11 17:26:06 --> Language Class Initialized
INFO - 2016-10-11 17:26:06 --> Language Class Initialized
INFO - 2016-10-11 17:26:06 --> Config Class Initialized
INFO - 2016-10-11 17:26:06 --> Loader Class Initialized
INFO - 2016-10-11 17:26:06 --> Helper loaded: url_helper
INFO - 2016-10-11 17:26:06 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:26:06 --> Controller Class Initialized
DEBUG - 2016-10-11 17:26:06 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:26:06 --> Model Class Initialized
INFO - 2016-10-11 17:26:06 --> Model Class Initialized
ERROR - 2016-10-11 17:26:06 --> Unable to delete cache file for admin/index/getRaportAngsuran/91032ad7bbcb6cf72875e8e8207dcfba80173f7c
DEBUG - 2016-10-11 17:26:06 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/raport_angsuran.php
INFO - 2016-10-11 17:26:06 --> Final output sent to browser
DEBUG - 2016-10-11 17:26:06 --> Total execution time: 0.7002
INFO - 2016-10-11 17:26:24 --> Config Class Initialized
INFO - 2016-10-11 17:26:24 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:26:24 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:26:24 --> Utf8 Class Initialized
INFO - 2016-10-11 17:26:24 --> URI Class Initialized
INFO - 2016-10-11 17:26:24 --> Router Class Initialized
INFO - 2016-10-11 17:26:24 --> Output Class Initialized
INFO - 2016-10-11 17:26:24 --> Security Class Initialized
DEBUG - 2016-10-11 17:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:26:24 --> Input Class Initialized
INFO - 2016-10-11 17:26:24 --> Language Class Initialized
INFO - 2016-10-11 17:26:24 --> Language Class Initialized
INFO - 2016-10-11 17:26:24 --> Config Class Initialized
INFO - 2016-10-11 17:26:24 --> Loader Class Initialized
INFO - 2016-10-11 17:26:24 --> Helper loaded: url_helper
INFO - 2016-10-11 17:26:24 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:26:24 --> Controller Class Initialized
DEBUG - 2016-10-11 17:26:24 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:26:24 --> Model Class Initialized
INFO - 2016-10-11 17:26:24 --> Model Class Initialized
ERROR - 2016-10-11 17:26:24 --> Unable to delete cache file for admin/index/getRaportAngsuran/f1f836cb4ea6efb2a0b1b99f41ad8b103eff4b59
DEBUG - 2016-10-11 17:26:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/raport_angsuran.php
INFO - 2016-10-11 17:26:24 --> Final output sent to browser
DEBUG - 2016-10-11 17:26:24 --> Total execution time: 0.7514
INFO - 2016-10-11 17:26:43 --> Config Class Initialized
INFO - 2016-10-11 17:26:43 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:26:43 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:26:43 --> Utf8 Class Initialized
INFO - 2016-10-11 17:26:43 --> URI Class Initialized
INFO - 2016-10-11 17:26:43 --> Router Class Initialized
INFO - 2016-10-11 17:26:43 --> Output Class Initialized
INFO - 2016-10-11 17:26:43 --> Security Class Initialized
DEBUG - 2016-10-11 17:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:26:43 --> Input Class Initialized
INFO - 2016-10-11 17:26:43 --> Language Class Initialized
INFO - 2016-10-11 17:26:43 --> Language Class Initialized
INFO - 2016-10-11 17:26:43 --> Config Class Initialized
INFO - 2016-10-11 17:26:43 --> Loader Class Initialized
INFO - 2016-10-11 17:26:43 --> Helper loaded: url_helper
INFO - 2016-10-11 17:26:43 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:26:43 --> Controller Class Initialized
DEBUG - 2016-10-11 17:26:43 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:26:43 --> Model Class Initialized
INFO - 2016-10-11 17:26:43 --> Model Class Initialized
ERROR - 2016-10-11 17:26:43 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-10-11 17:26:43 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-11 17:26:43 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-11 17:26:43 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-11 17:26:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-10-11 17:26:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-11 17:26:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-11 17:26:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:45 --> Database Driver Class Initialized
DEBUG - 2016-10-11 17:26:46 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-11 17:26:46 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-11 17:26:46 --> Final output sent to browser
DEBUG - 2016-10-11 17:26:46 --> Total execution time: 2.6250
INFO - 2016-10-11 17:26:52 --> Config Class Initialized
INFO - 2016-10-11 17:26:52 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:26:52 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:26:52 --> Utf8 Class Initialized
INFO - 2016-10-11 17:26:52 --> URI Class Initialized
INFO - 2016-10-11 17:26:52 --> Router Class Initialized
INFO - 2016-10-11 17:26:52 --> Output Class Initialized
INFO - 2016-10-11 17:26:52 --> Security Class Initialized
DEBUG - 2016-10-11 17:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:26:52 --> Input Class Initialized
INFO - 2016-10-11 17:26:52 --> Language Class Initialized
INFO - 2016-10-11 17:26:52 --> Language Class Initialized
INFO - 2016-10-11 17:26:52 --> Config Class Initialized
INFO - 2016-10-11 17:26:52 --> Loader Class Initialized
INFO - 2016-10-11 17:26:52 --> Helper loaded: url_helper
INFO - 2016-10-11 17:26:52 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:26:52 --> Controller Class Initialized
DEBUG - 2016-10-11 17:26:52 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:26:52 --> Model Class Initialized
INFO - 2016-10-11 17:26:52 --> Model Class Initialized
ERROR - 2016-10-11 17:26:52 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-11 17:26:52 --> Anggota MX_Controller Initialized
INFO - 2016-10-11 17:26:52 --> Database Driver Class Initialized
INFO - 2016-10-11 17:26:52 --> Final output sent to browser
DEBUG - 2016-10-11 17:26:52 --> Total execution time: 0.7236
INFO - 2016-10-11 17:27:14 --> Config Class Initialized
INFO - 2016-10-11 17:27:14 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:27:14 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:27:14 --> Utf8 Class Initialized
INFO - 2016-10-11 17:27:14 --> URI Class Initialized
INFO - 2016-10-11 17:27:14 --> Router Class Initialized
INFO - 2016-10-11 17:27:14 --> Output Class Initialized
INFO - 2016-10-11 17:27:14 --> Security Class Initialized
DEBUG - 2016-10-11 17:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:27:14 --> Input Class Initialized
INFO - 2016-10-11 17:27:14 --> Language Class Initialized
INFO - 2016-10-11 17:27:14 --> Language Class Initialized
INFO - 2016-10-11 17:27:14 --> Config Class Initialized
INFO - 2016-10-11 17:27:14 --> Loader Class Initialized
INFO - 2016-10-11 17:27:14 --> Helper loaded: url_helper
INFO - 2016-10-11 17:27:14 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:27:14 --> Controller Class Initialized
DEBUG - 2016-10-11 17:27:14 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:27:14 --> Model Class Initialized
INFO - 2016-10-11 17:27:14 --> Model Class Initialized
ERROR - 2016-10-11 17:27:14 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-10-11 17:27:14 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-11 17:27:14 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-11 17:27:14 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-11 17:27:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_umum.php
DEBUG - 2016-10-11 17:27:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-11 17:27:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-11 17:27:15 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:15 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:15 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:15 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:15 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:15 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:15 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:15 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:15 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:15 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:15 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:15 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:15 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:15 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:15 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:15 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:15 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:15 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:15 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:15 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:15 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:15 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:15 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:15 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:15 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:15 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:15 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:15 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:15 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:15 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:16 --> Database Driver Class Initialized
DEBUG - 2016-10-11 17:27:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-11 17:27:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-11 17:27:16 --> Final output sent to browser
DEBUG - 2016-10-11 17:27:16 --> Total execution time: 2.6977
INFO - 2016-10-11 17:27:36 --> Config Class Initialized
INFO - 2016-10-11 17:27:36 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:27:36 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:27:36 --> Utf8 Class Initialized
INFO - 2016-10-11 17:27:36 --> URI Class Initialized
INFO - 2016-10-11 17:27:36 --> Router Class Initialized
INFO - 2016-10-11 17:27:36 --> Output Class Initialized
INFO - 2016-10-11 17:27:36 --> Security Class Initialized
DEBUG - 2016-10-11 17:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:27:36 --> Input Class Initialized
INFO - 2016-10-11 17:27:36 --> Language Class Initialized
INFO - 2016-10-11 17:27:36 --> Language Class Initialized
INFO - 2016-10-11 17:27:36 --> Config Class Initialized
INFO - 2016-10-11 17:27:36 --> Loader Class Initialized
INFO - 2016-10-11 17:27:36 --> Helper loaded: url_helper
INFO - 2016-10-11 17:27:36 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:27:36 --> Controller Class Initialized
DEBUG - 2016-10-11 17:27:36 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:27:36 --> Model Class Initialized
INFO - 2016-10-11 17:27:36 --> Model Class Initialized
ERROR - 2016-10-11 17:27:36 --> Unable to delete cache file for admin/index/do_ajukan_pinjaman
INFO - 2016-10-11 17:27:36 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:36 --> Database Driver Class Initialized
INFO - 2016-10-11 17:27:37 --> Final output sent to browser
DEBUG - 2016-10-11 17:27:37 --> Total execution time: 0.7885
INFO - 2016-10-11 17:28:05 --> Config Class Initialized
INFO - 2016-10-11 17:28:05 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:28:05 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:28:05 --> Utf8 Class Initialized
INFO - 2016-10-11 17:28:05 --> URI Class Initialized
INFO - 2016-10-11 17:28:05 --> Router Class Initialized
INFO - 2016-10-11 17:28:05 --> Output Class Initialized
INFO - 2016-10-11 17:28:05 --> Security Class Initialized
DEBUG - 2016-10-11 17:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:28:05 --> Input Class Initialized
INFO - 2016-10-11 17:28:05 --> Language Class Initialized
INFO - 2016-10-11 17:28:05 --> Language Class Initialized
INFO - 2016-10-11 17:28:05 --> Config Class Initialized
INFO - 2016-10-11 17:28:05 --> Loader Class Initialized
INFO - 2016-10-11 17:28:05 --> Helper loaded: url_helper
INFO - 2016-10-11 17:28:06 --> Database Driver Class Initialized
INFO - 2016-10-11 17:28:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:28:06 --> Controller Class Initialized
DEBUG - 2016-10-11 17:28:06 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:28:06 --> Model Class Initialized
INFO - 2016-10-11 17:28:06 --> Model Class Initialized
ERROR - 2016-10-11 17:28:06 --> Unable to delete cache file for admin/index/do_save_jaminan/sertifikat
INFO - 2016-10-11 17:28:06 --> Database Driver Class Initialized
INFO - 2016-10-11 17:28:06 --> Final output sent to browser
DEBUG - 2016-10-11 17:28:06 --> Total execution time: 0.6096
INFO - 2016-10-11 17:30:12 --> Config Class Initialized
INFO - 2016-10-11 17:30:12 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:30:12 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:30:12 --> Utf8 Class Initialized
INFO - 2016-10-11 17:30:12 --> URI Class Initialized
INFO - 2016-10-11 17:30:12 --> Router Class Initialized
INFO - 2016-10-11 17:30:12 --> Output Class Initialized
INFO - 2016-10-11 17:30:12 --> Security Class Initialized
DEBUG - 2016-10-11 17:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:30:12 --> Input Class Initialized
INFO - 2016-10-11 17:30:12 --> Language Class Initialized
INFO - 2016-10-11 17:30:12 --> Language Class Initialized
INFO - 2016-10-11 17:30:12 --> Config Class Initialized
INFO - 2016-10-11 17:30:12 --> Loader Class Initialized
INFO - 2016-10-11 17:30:12 --> Helper loaded: url_helper
INFO - 2016-10-11 17:30:12 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:30:12 --> Controller Class Initialized
DEBUG - 2016-10-11 17:30:12 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:30:12 --> Model Class Initialized
INFO - 2016-10-11 17:30:12 --> Model Class Initialized
ERROR - 2016-10-11 17:30:12 --> Unable to delete cache file for admin/index/data/anggota
DEBUG - 2016-10-11 17:30:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-11 17:30:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-11 17:30:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-11 17:30:12 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-11 17:30:12 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-11 17:30:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-11 17:30:13 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-11 17:30:13 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-11 17:30:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:14 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:14 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:14 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:14 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:14 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:14 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:14 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:14 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:14 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:14 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:14 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:14 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:14 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:14 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:14 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:14 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:14 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:14 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:14 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:14 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:14 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:14 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:14 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:14 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:14 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:14 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:14 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:14 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:14 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:14 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:14 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:14 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:14 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:14 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:15 --> Database Driver Class Initialized
DEBUG - 2016-10-11 17:30:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-11 17:30:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-11 17:30:15 --> Final output sent to browser
DEBUG - 2016-10-11 17:30:15 --> Total execution time: 2.9427
INFO - 2016-10-11 17:30:19 --> Config Class Initialized
INFO - 2016-10-11 17:30:19 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:30:19 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:30:19 --> Utf8 Class Initialized
INFO - 2016-10-11 17:30:19 --> URI Class Initialized
INFO - 2016-10-11 17:30:19 --> Router Class Initialized
INFO - 2016-10-11 17:30:19 --> Output Class Initialized
INFO - 2016-10-11 17:30:19 --> Security Class Initialized
DEBUG - 2016-10-11 17:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:30:19 --> Input Class Initialized
INFO - 2016-10-11 17:30:19 --> Language Class Initialized
INFO - 2016-10-11 17:30:20 --> Language Class Initialized
INFO - 2016-10-11 17:30:20 --> Config Class Initialized
INFO - 2016-10-11 17:30:20 --> Loader Class Initialized
INFO - 2016-10-11 17:30:20 --> Helper loaded: url_helper
INFO - 2016-10-11 17:30:20 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:30:20 --> Controller Class Initialized
DEBUG - 2016-10-11 17:30:20 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:30:20 --> Model Class Initialized
INFO - 2016-10-11 17:30:20 --> Model Class Initialized
ERROR - 2016-10-11 17:30:20 --> Unable to delete cache file for admin/index/detail_anggota/356a192b7913b04c54574d18c28d46e6395428ab
DEBUG - 2016-10-11 17:30:20 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-11 17:30:20 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-11 17:30:20 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
INFO - 2016-10-11 17:30:20 --> Database Driver Class Initialized
DEBUG - 2016-10-11 17:30:20 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_pinjaman.php
INFO - 2016-10-11 17:30:20 --> Database Driver Class Initialized
DEBUG - 2016-10-11 17:30:20 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_tabungan.php
DEBUG - 2016-10-11 17:30:20 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/profile_anggota.php
DEBUG - 2016-10-11 17:30:20 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-11 17:30:20 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-11 17:30:20 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:20 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:20 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:20 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:20 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:20 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:20 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:20 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:20 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:20 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:20 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:20 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:20 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:20 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:20 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:20 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:20 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:20 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:21 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:21 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:21 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:21 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:21 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:21 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:21 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:21 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:21 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:21 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:21 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:21 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:21 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:21 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:21 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:21 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:21 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:21 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:21 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:21 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:21 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:21 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:21 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:21 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:21 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:21 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:21 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:21 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:21 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:21 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:21 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:21 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:21 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:21 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:22 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:22 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:22 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:22 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:22 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:22 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:22 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:22 --> Database Driver Class Initialized
DEBUG - 2016-10-11 17:30:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-11 17:30:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-11 17:30:22 --> Final output sent to browser
DEBUG - 2016-10-11 17:30:22 --> Total execution time: 2.5642
INFO - 2016-10-11 17:30:22 --> Config Class Initialized
INFO - 2016-10-11 17:30:22 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:30:22 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:30:22 --> Utf8 Class Initialized
INFO - 2016-10-11 17:30:22 --> URI Class Initialized
INFO - 2016-10-11 17:30:22 --> Router Class Initialized
INFO - 2016-10-11 17:30:22 --> Output Class Initialized
INFO - 2016-10-11 17:30:22 --> Security Class Initialized
DEBUG - 2016-10-11 17:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:30:22 --> Input Class Initialized
INFO - 2016-10-11 17:30:22 --> Language Class Initialized
INFO - 2016-10-11 17:30:22 --> Language Class Initialized
INFO - 2016-10-11 17:30:22 --> Config Class Initialized
INFO - 2016-10-11 17:30:22 --> Loader Class Initialized
INFO - 2016-10-11 17:30:22 --> Helper loaded: url_helper
INFO - 2016-10-11 17:30:22 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:30:23 --> Controller Class Initialized
DEBUG - 2016-10-11 17:30:23 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:30:23 --> Model Class Initialized
INFO - 2016-10-11 17:30:23 --> Model Class Initialized
ERROR - 2016-10-11 17:30:23 --> Unable to delete cache file for admin/index/detail_anggota/images/picture.jpg
DEBUG - 2016-10-11 17:30:23 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-11 17:30:23 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-11 17:30:23 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
ERROR - 2016-10-11 17:30:23 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 16
ERROR - 2016-10-11 17:30:23 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 19
ERROR - 2016-10-11 17:30:23 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 22
ERROR - 2016-10-11 17:30:23 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 38
INFO - 2016-10-11 17:30:23 --> Database Driver Class Initialized
DEBUG - 2016-10-11 17:30:23 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_pinjaman.php
ERROR - 2016-10-11 17:30:23 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 41
INFO - 2016-10-11 17:30:24 --> Database Driver Class Initialized
DEBUG - 2016-10-11 17:30:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_tabungan.php
DEBUG - 2016-10-11 17:30:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/profile_anggota.php
DEBUG - 2016-10-11 17:30:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-11 17:30:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-11 17:30:24 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:24 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:24 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:24 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:24 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:25 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:25 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:25 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:25 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:25 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:25 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:25 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:25 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:25 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:25 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:25 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:25 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:25 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:25 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:25 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:25 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:25 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:27 --> Database Driver Class Initialized
DEBUG - 2016-10-11 17:30:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-11 17:30:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-11 17:30:27 --> Final output sent to browser
DEBUG - 2016-10-11 17:30:27 --> Total execution time: 5.2828
INFO - 2016-10-11 17:30:36 --> Config Class Initialized
INFO - 2016-10-11 17:30:37 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:30:37 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:30:37 --> Utf8 Class Initialized
INFO - 2016-10-11 17:30:37 --> URI Class Initialized
INFO - 2016-10-11 17:30:37 --> Router Class Initialized
INFO - 2016-10-11 17:30:37 --> Output Class Initialized
INFO - 2016-10-11 17:30:37 --> Security Class Initialized
DEBUG - 2016-10-11 17:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:30:37 --> Input Class Initialized
INFO - 2016-10-11 17:30:37 --> Language Class Initialized
INFO - 2016-10-11 17:30:37 --> Language Class Initialized
INFO - 2016-10-11 17:30:37 --> Config Class Initialized
INFO - 2016-10-11 17:30:37 --> Loader Class Initialized
INFO - 2016-10-11 17:30:37 --> Helper loaded: url_helper
INFO - 2016-10-11 17:30:37 --> Database Driver Class Initialized
INFO - 2016-10-11 17:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:30:37 --> Controller Class Initialized
DEBUG - 2016-10-11 17:30:37 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:30:37 --> Model Class Initialized
INFO - 2016-10-11 17:30:37 --> Model Class Initialized
ERROR - 2016-10-11 17:30:37 --> Unable to delete cache file for admin/index/getRaportAngsuran/356a192b7913b04c54574d18c28d46e6395428ab
DEBUG - 2016-10-11 17:30:37 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/raport_angsuran.php
INFO - 2016-10-11 17:30:37 --> Final output sent to browser
DEBUG - 2016-10-11 17:30:37 --> Total execution time: 0.9013
INFO - 2016-10-11 17:31:30 --> Config Class Initialized
INFO - 2016-10-11 17:31:30 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:31:30 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:31:30 --> Utf8 Class Initialized
INFO - 2016-10-11 17:31:30 --> URI Class Initialized
INFO - 2016-10-11 17:31:30 --> Router Class Initialized
INFO - 2016-10-11 17:31:30 --> Output Class Initialized
INFO - 2016-10-11 17:31:30 --> Security Class Initialized
DEBUG - 2016-10-11 17:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:31:30 --> Input Class Initialized
INFO - 2016-10-11 17:31:31 --> Language Class Initialized
INFO - 2016-10-11 17:31:31 --> Language Class Initialized
INFO - 2016-10-11 17:31:31 --> Config Class Initialized
INFO - 2016-10-11 17:31:31 --> Loader Class Initialized
INFO - 2016-10-11 17:31:31 --> Helper loaded: url_helper
INFO - 2016-10-11 17:31:31 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:31:31 --> Controller Class Initialized
DEBUG - 2016-10-11 17:31:31 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:31:31 --> Model Class Initialized
INFO - 2016-10-11 17:31:31 --> Model Class Initialized
ERROR - 2016-10-11 17:31:31 --> Unable to delete cache file for admin/index/finish_pinjaman/ca3512f4dfa95a03169c5a670a4c91a19b3077b4
INFO - 2016-10-11 17:31:31 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:31 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:31 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:31 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:31 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:31 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:31 --> Final output sent to browser
DEBUG - 2016-10-11 17:31:31 --> Total execution time: 0.9852
INFO - 2016-10-11 17:31:31 --> Config Class Initialized
INFO - 2016-10-11 17:31:31 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:31:31 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:31:32 --> Utf8 Class Initialized
INFO - 2016-10-11 17:31:32 --> URI Class Initialized
INFO - 2016-10-11 17:31:32 --> Router Class Initialized
INFO - 2016-10-11 17:31:32 --> Output Class Initialized
INFO - 2016-10-11 17:31:32 --> Security Class Initialized
DEBUG - 2016-10-11 17:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:31:32 --> Input Class Initialized
INFO - 2016-10-11 17:31:32 --> Language Class Initialized
INFO - 2016-10-11 17:31:32 --> Language Class Initialized
INFO - 2016-10-11 17:31:32 --> Config Class Initialized
INFO - 2016-10-11 17:31:32 --> Loader Class Initialized
INFO - 2016-10-11 17:31:32 --> Helper loaded: url_helper
INFO - 2016-10-11 17:31:32 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:31:32 --> Controller Class Initialized
DEBUG - 2016-10-11 17:31:32 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:31:32 --> Model Class Initialized
INFO - 2016-10-11 17:31:32 --> Model Class Initialized
ERROR - 2016-10-11 17:31:32 --> Unable to delete cache file for admin/index/data_peminjam
DEBUG - 2016-10-11 17:31:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-11 17:31:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-11 17:31:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-11 17:31:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_peminjam.php
DEBUG - 2016-10-11 17:31:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-11 17:31:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-11 17:31:32 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:32 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:32 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:32 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:32 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:33 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:33 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:33 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:33 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:33 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:33 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:33 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:33 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:33 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:33 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:33 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:33 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:33 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:33 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:33 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:33 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:33 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:33 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:33 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:33 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:33 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:33 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:33 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:33 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:33 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:33 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:33 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:33 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:33 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:33 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:34 --> Database Driver Class Initialized
DEBUG - 2016-10-11 17:31:34 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-11 17:31:34 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-11 17:31:34 --> Final output sent to browser
DEBUG - 2016-10-11 17:31:34 --> Total execution time: 3.0314
INFO - 2016-10-11 17:31:41 --> Config Class Initialized
INFO - 2016-10-11 17:31:41 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:31:41 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:31:41 --> Utf8 Class Initialized
INFO - 2016-10-11 17:31:41 --> URI Class Initialized
INFO - 2016-10-11 17:31:41 --> Router Class Initialized
INFO - 2016-10-11 17:31:41 --> Output Class Initialized
INFO - 2016-10-11 17:31:41 --> Security Class Initialized
DEBUG - 2016-10-11 17:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:31:41 --> Input Class Initialized
INFO - 2016-10-11 17:31:41 --> Language Class Initialized
INFO - 2016-10-11 17:31:41 --> Language Class Initialized
INFO - 2016-10-11 17:31:41 --> Config Class Initialized
INFO - 2016-10-11 17:31:41 --> Loader Class Initialized
INFO - 2016-10-11 17:31:41 --> Helper loaded: url_helper
INFO - 2016-10-11 17:31:41 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:31:41 --> Controller Class Initialized
DEBUG - 2016-10-11 17:31:41 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:31:41 --> Model Class Initialized
INFO - 2016-10-11 17:31:41 --> Model Class Initialized
ERROR - 2016-10-11 17:31:41 --> Unable to delete cache file for admin/index/bayar_angsuran
DEBUG - 2016-10-11 17:31:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-11 17:31:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-11 17:31:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-11 17:31:42 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_bayar_angsuran.php
DEBUG - 2016-10-11 17:31:42 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-11 17:31:42 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-11 17:31:42 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:42 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:42 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:42 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:42 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:42 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:42 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:42 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:42 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:42 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:42 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:42 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:42 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:42 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:42 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:42 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:42 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:42 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:42 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:42 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:43 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:43 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:43 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:43 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:43 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:43 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:43 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:43 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:43 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:43 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:43 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:43 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:43 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:43 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:43 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:43 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:43 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:43 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:43 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:43 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:43 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:43 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:43 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:44 --> Database Driver Class Initialized
DEBUG - 2016-10-11 17:31:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-11 17:31:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-11 17:31:44 --> Final output sent to browser
DEBUG - 2016-10-11 17:31:44 --> Total execution time: 3.6679
INFO - 2016-10-11 17:31:52 --> Config Class Initialized
INFO - 2016-10-11 17:31:52 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:31:52 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:31:52 --> Utf8 Class Initialized
INFO - 2016-10-11 17:31:52 --> URI Class Initialized
INFO - 2016-10-11 17:31:52 --> Router Class Initialized
INFO - 2016-10-11 17:31:52 --> Output Class Initialized
INFO - 2016-10-11 17:31:52 --> Security Class Initialized
DEBUG - 2016-10-11 17:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:31:52 --> Input Class Initialized
INFO - 2016-10-11 17:31:52 --> Language Class Initialized
INFO - 2016-10-11 17:31:52 --> Language Class Initialized
INFO - 2016-10-11 17:31:52 --> Config Class Initialized
INFO - 2016-10-11 17:31:52 --> Loader Class Initialized
INFO - 2016-10-11 17:31:52 --> Helper loaded: url_helper
INFO - 2016-10-11 17:31:52 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:31:52 --> Controller Class Initialized
DEBUG - 2016-10-11 17:31:52 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:31:53 --> Model Class Initialized
INFO - 2016-10-11 17:31:53 --> Model Class Initialized
ERROR - 2016-10-11 17:31:53 --> Unable to delete cache file for admin/index/getDetailAngsuran
INFO - 2016-10-11 17:31:53 --> Database Driver Class Initialized
INFO - 2016-10-11 17:31:53 --> Final output sent to browser
DEBUG - 2016-10-11 17:31:53 --> Total execution time: 0.7140
INFO - 2016-10-11 17:32:03 --> Config Class Initialized
INFO - 2016-10-11 17:32:03 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:32:03 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:32:03 --> Utf8 Class Initialized
INFO - 2016-10-11 17:32:03 --> URI Class Initialized
INFO - 2016-10-11 17:32:03 --> Router Class Initialized
INFO - 2016-10-11 17:32:03 --> Output Class Initialized
INFO - 2016-10-11 17:32:03 --> Security Class Initialized
DEBUG - 2016-10-11 17:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:32:03 --> Input Class Initialized
INFO - 2016-10-11 17:32:03 --> Language Class Initialized
INFO - 2016-10-11 17:32:03 --> Language Class Initialized
INFO - 2016-10-11 17:32:03 --> Config Class Initialized
INFO - 2016-10-11 17:32:03 --> Loader Class Initialized
INFO - 2016-10-11 17:32:03 --> Helper loaded: url_helper
INFO - 2016-10-11 17:32:03 --> Database Driver Class Initialized
INFO - 2016-10-11 17:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:32:03 --> Controller Class Initialized
DEBUG - 2016-10-11 17:32:03 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:32:03 --> Model Class Initialized
INFO - 2016-10-11 17:32:03 --> Model Class Initialized
ERROR - 2016-10-11 17:32:03 --> Unable to delete cache file for admin/index/do_bayar
INFO - 2016-10-11 17:32:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:32:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:32:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:32:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:32:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:32:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:32:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:32:04 --> Final output sent to browser
DEBUG - 2016-10-11 17:32:04 --> Total execution time: 1.1047
INFO - 2016-10-11 17:32:07 --> Config Class Initialized
INFO - 2016-10-11 17:32:07 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:32:07 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:32:07 --> Utf8 Class Initialized
INFO - 2016-10-11 17:32:07 --> URI Class Initialized
INFO - 2016-10-11 17:32:07 --> Router Class Initialized
INFO - 2016-10-11 17:32:07 --> Output Class Initialized
INFO - 2016-10-11 17:32:07 --> Security Class Initialized
DEBUG - 2016-10-11 17:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:32:07 --> Input Class Initialized
INFO - 2016-10-11 17:32:07 --> Language Class Initialized
INFO - 2016-10-11 17:32:07 --> Language Class Initialized
INFO - 2016-10-11 17:32:07 --> Config Class Initialized
INFO - 2016-10-11 17:32:07 --> Loader Class Initialized
INFO - 2016-10-11 17:32:07 --> Helper loaded: url_helper
INFO - 2016-10-11 17:32:07 --> Database Driver Class Initialized
INFO - 2016-10-11 17:32:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:32:07 --> Controller Class Initialized
DEBUG - 2016-10-11 17:32:07 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:32:07 --> Model Class Initialized
INFO - 2016-10-11 17:32:07 --> Model Class Initialized
ERROR - 2016-10-11 17:32:07 --> Unable to delete cache file for admin/index/getDetailAngsuran
INFO - 2016-10-11 17:32:07 --> Database Driver Class Initialized
INFO - 2016-10-11 17:32:07 --> Final output sent to browser
DEBUG - 2016-10-11 17:32:07 --> Total execution time: 0.6545
INFO - 2016-10-11 17:32:08 --> Config Class Initialized
INFO - 2016-10-11 17:32:08 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:32:08 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:32:08 --> Utf8 Class Initialized
INFO - 2016-10-11 17:32:08 --> URI Class Initialized
INFO - 2016-10-11 17:32:08 --> Router Class Initialized
INFO - 2016-10-11 17:32:08 --> Output Class Initialized
INFO - 2016-10-11 17:32:09 --> Security Class Initialized
DEBUG - 2016-10-11 17:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:32:09 --> Input Class Initialized
INFO - 2016-10-11 17:32:09 --> Language Class Initialized
INFO - 2016-10-11 17:32:09 --> Language Class Initialized
INFO - 2016-10-11 17:32:09 --> Config Class Initialized
INFO - 2016-10-11 17:32:09 --> Loader Class Initialized
INFO - 2016-10-11 17:32:09 --> Helper loaded: url_helper
INFO - 2016-10-11 17:32:09 --> Database Driver Class Initialized
INFO - 2016-10-11 17:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:32:09 --> Controller Class Initialized
DEBUG - 2016-10-11 17:32:09 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:32:09 --> Model Class Initialized
INFO - 2016-10-11 17:32:09 --> Model Class Initialized
ERROR - 2016-10-11 17:32:09 --> Unable to delete cache file for admin/index/do_bayar
INFO - 2016-10-11 17:32:09 --> Database Driver Class Initialized
INFO - 2016-10-11 17:32:09 --> Database Driver Class Initialized
INFO - 2016-10-11 17:32:09 --> Database Driver Class Initialized
INFO - 2016-10-11 17:32:09 --> Database Driver Class Initialized
INFO - 2016-10-11 17:32:09 --> Database Driver Class Initialized
INFO - 2016-10-11 17:32:09 --> Database Driver Class Initialized
INFO - 2016-10-11 17:32:09 --> Database Driver Class Initialized
INFO - 2016-10-11 17:32:09 --> Final output sent to browser
DEBUG - 2016-10-11 17:32:09 --> Total execution time: 1.2031
INFO - 2016-10-11 17:32:11 --> Config Class Initialized
INFO - 2016-10-11 17:32:11 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:32:11 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:32:11 --> Utf8 Class Initialized
INFO - 2016-10-11 17:32:11 --> URI Class Initialized
INFO - 2016-10-11 17:32:11 --> Router Class Initialized
INFO - 2016-10-11 17:32:11 --> Output Class Initialized
INFO - 2016-10-11 17:32:11 --> Security Class Initialized
DEBUG - 2016-10-11 17:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:32:11 --> Input Class Initialized
INFO - 2016-10-11 17:32:11 --> Language Class Initialized
INFO - 2016-10-11 17:32:11 --> Language Class Initialized
INFO - 2016-10-11 17:32:11 --> Config Class Initialized
INFO - 2016-10-11 17:32:11 --> Loader Class Initialized
INFO - 2016-10-11 17:32:11 --> Helper loaded: url_helper
INFO - 2016-10-11 17:32:11 --> Database Driver Class Initialized
INFO - 2016-10-11 17:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:32:11 --> Controller Class Initialized
DEBUG - 2016-10-11 17:32:11 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:32:11 --> Model Class Initialized
INFO - 2016-10-11 17:32:11 --> Model Class Initialized
ERROR - 2016-10-11 17:32:11 --> Unable to delete cache file for admin/index/getDetailAngsuran
INFO - 2016-10-11 17:32:11 --> Database Driver Class Initialized
INFO - 2016-10-11 17:32:11 --> Final output sent to browser
DEBUG - 2016-10-11 17:32:11 --> Total execution time: 0.6384
INFO - 2016-10-11 17:32:12 --> Config Class Initialized
INFO - 2016-10-11 17:32:12 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:32:12 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:32:12 --> Utf8 Class Initialized
INFO - 2016-10-11 17:32:12 --> URI Class Initialized
INFO - 2016-10-11 17:32:12 --> Router Class Initialized
INFO - 2016-10-11 17:32:12 --> Output Class Initialized
INFO - 2016-10-11 17:32:12 --> Security Class Initialized
DEBUG - 2016-10-11 17:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:32:12 --> Input Class Initialized
INFO - 2016-10-11 17:32:12 --> Language Class Initialized
INFO - 2016-10-11 17:32:12 --> Language Class Initialized
INFO - 2016-10-11 17:32:12 --> Config Class Initialized
INFO - 2016-10-11 17:32:12 --> Loader Class Initialized
INFO - 2016-10-11 17:32:12 --> Helper loaded: url_helper
INFO - 2016-10-11 17:32:12 --> Database Driver Class Initialized
INFO - 2016-10-11 17:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:32:12 --> Controller Class Initialized
DEBUG - 2016-10-11 17:32:12 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:32:12 --> Model Class Initialized
INFO - 2016-10-11 17:32:12 --> Model Class Initialized
ERROR - 2016-10-11 17:32:13 --> Unable to delete cache file for admin/index/do_bayar
INFO - 2016-10-11 17:32:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:32:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:32:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:32:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:32:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:32:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:32:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:32:13 --> Final output sent to browser
DEBUG - 2016-10-11 17:32:13 --> Total execution time: 1.2332
INFO - 2016-10-11 17:32:14 --> Config Class Initialized
INFO - 2016-10-11 17:32:14 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:32:14 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:32:14 --> Utf8 Class Initialized
INFO - 2016-10-11 17:32:14 --> URI Class Initialized
INFO - 2016-10-11 17:32:15 --> Router Class Initialized
INFO - 2016-10-11 17:32:15 --> Output Class Initialized
INFO - 2016-10-11 17:32:15 --> Security Class Initialized
DEBUG - 2016-10-11 17:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:32:15 --> Input Class Initialized
INFO - 2016-10-11 17:32:15 --> Language Class Initialized
INFO - 2016-10-11 17:32:15 --> Language Class Initialized
INFO - 2016-10-11 17:32:15 --> Config Class Initialized
INFO - 2016-10-11 17:32:15 --> Loader Class Initialized
INFO - 2016-10-11 17:32:15 --> Helper loaded: url_helper
INFO - 2016-10-11 17:32:15 --> Database Driver Class Initialized
INFO - 2016-10-11 17:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:32:15 --> Controller Class Initialized
DEBUG - 2016-10-11 17:32:15 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:32:15 --> Model Class Initialized
INFO - 2016-10-11 17:32:15 --> Model Class Initialized
ERROR - 2016-10-11 17:32:15 --> Unable to delete cache file for admin/index/getDetailAngsuran
INFO - 2016-10-11 17:32:15 --> Database Driver Class Initialized
INFO - 2016-10-11 17:32:15 --> Final output sent to browser
DEBUG - 2016-10-11 17:32:15 --> Total execution time: 0.6839
INFO - 2016-10-11 17:32:31 --> Config Class Initialized
INFO - 2016-10-11 17:32:31 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:32:31 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:32:31 --> Utf8 Class Initialized
INFO - 2016-10-11 17:32:31 --> URI Class Initialized
INFO - 2016-10-11 17:32:31 --> Router Class Initialized
INFO - 2016-10-11 17:32:31 --> Output Class Initialized
INFO - 2016-10-11 17:32:31 --> Security Class Initialized
DEBUG - 2016-10-11 17:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:32:31 --> Input Class Initialized
INFO - 2016-10-11 17:32:31 --> Language Class Initialized
INFO - 2016-10-11 17:32:31 --> Language Class Initialized
INFO - 2016-10-11 17:32:31 --> Config Class Initialized
INFO - 2016-10-11 17:32:31 --> Loader Class Initialized
INFO - 2016-10-11 17:32:31 --> Helper loaded: url_helper
INFO - 2016-10-11 17:32:31 --> Database Driver Class Initialized
INFO - 2016-10-11 17:32:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:32:31 --> Controller Class Initialized
DEBUG - 2016-10-11 17:32:31 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:32:31 --> Model Class Initialized
INFO - 2016-10-11 17:32:31 --> Model Class Initialized
ERROR - 2016-10-11 17:32:31 --> Unable to delete cache file for admin/index/do_bayar
INFO - 2016-10-11 17:32:31 --> Database Driver Class Initialized
INFO - 2016-10-11 17:32:31 --> Database Driver Class Initialized
INFO - 2016-10-11 17:32:31 --> Database Driver Class Initialized
INFO - 2016-10-11 17:32:31 --> Database Driver Class Initialized
INFO - 2016-10-11 17:32:31 --> Database Driver Class Initialized
INFO - 2016-10-11 17:32:32 --> Database Driver Class Initialized
INFO - 2016-10-11 17:32:32 --> Database Driver Class Initialized
INFO - 2016-10-11 17:32:32 --> Final output sent to browser
DEBUG - 2016-10-11 17:32:32 --> Total execution time: 0.9937
INFO - 2016-10-11 17:32:35 --> Config Class Initialized
INFO - 2016-10-11 17:32:35 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:32:35 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:32:35 --> Utf8 Class Initialized
INFO - 2016-10-11 17:32:35 --> URI Class Initialized
INFO - 2016-10-11 17:32:35 --> Router Class Initialized
INFO - 2016-10-11 17:32:35 --> Output Class Initialized
INFO - 2016-10-11 17:32:35 --> Security Class Initialized
DEBUG - 2016-10-11 17:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:32:35 --> Input Class Initialized
INFO - 2016-10-11 17:32:35 --> Language Class Initialized
INFO - 2016-10-11 17:32:35 --> Language Class Initialized
INFO - 2016-10-11 17:32:35 --> Config Class Initialized
INFO - 2016-10-11 17:32:35 --> Loader Class Initialized
INFO - 2016-10-11 17:32:35 --> Helper loaded: url_helper
INFO - 2016-10-11 17:32:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:32:35 --> Controller Class Initialized
DEBUG - 2016-10-11 17:32:35 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:32:35 --> Model Class Initialized
INFO - 2016-10-11 17:32:35 --> Model Class Initialized
ERROR - 2016-10-11 17:32:35 --> Unable to delete cache file for admin/index/getDetailAngsuran
INFO - 2016-10-11 17:32:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:32:35 --> Final output sent to browser
DEBUG - 2016-10-11 17:32:35 --> Total execution time: 0.5809
INFO - 2016-10-11 17:32:54 --> Config Class Initialized
INFO - 2016-10-11 17:32:54 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:32:54 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:32:54 --> Utf8 Class Initialized
INFO - 2016-10-11 17:32:54 --> URI Class Initialized
INFO - 2016-10-11 17:32:54 --> Router Class Initialized
INFO - 2016-10-11 17:32:54 --> Output Class Initialized
INFO - 2016-10-11 17:32:54 --> Security Class Initialized
DEBUG - 2016-10-11 17:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:32:54 --> Input Class Initialized
INFO - 2016-10-11 17:32:54 --> Language Class Initialized
INFO - 2016-10-11 17:32:54 --> Language Class Initialized
INFO - 2016-10-11 17:32:54 --> Config Class Initialized
INFO - 2016-10-11 17:32:54 --> Loader Class Initialized
INFO - 2016-10-11 17:32:54 --> Helper loaded: url_helper
INFO - 2016-10-11 17:32:54 --> Database Driver Class Initialized
INFO - 2016-10-11 17:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:32:54 --> Controller Class Initialized
DEBUG - 2016-10-11 17:32:54 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:32:54 --> Model Class Initialized
INFO - 2016-10-11 17:32:54 --> Model Class Initialized
ERROR - 2016-10-11 17:32:54 --> Unable to delete cache file for admin/index/do_bayar
INFO - 2016-10-11 17:32:54 --> Database Driver Class Initialized
INFO - 2016-10-11 17:32:54 --> Database Driver Class Initialized
INFO - 2016-10-11 17:32:54 --> Database Driver Class Initialized
INFO - 2016-10-11 17:32:54 --> Database Driver Class Initialized
INFO - 2016-10-11 17:32:54 --> Database Driver Class Initialized
INFO - 2016-10-11 17:32:55 --> Database Driver Class Initialized
INFO - 2016-10-11 17:32:55 --> Database Driver Class Initialized
INFO - 2016-10-11 17:32:55 --> Final output sent to browser
DEBUG - 2016-10-11 17:32:55 --> Total execution time: 1.0560
INFO - 2016-10-11 17:32:58 --> Config Class Initialized
INFO - 2016-10-11 17:32:58 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:32:58 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:32:58 --> Utf8 Class Initialized
INFO - 2016-10-11 17:32:58 --> URI Class Initialized
INFO - 2016-10-11 17:32:58 --> Router Class Initialized
INFO - 2016-10-11 17:32:58 --> Output Class Initialized
INFO - 2016-10-11 17:32:58 --> Security Class Initialized
DEBUG - 2016-10-11 17:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:32:58 --> Input Class Initialized
INFO - 2016-10-11 17:32:58 --> Language Class Initialized
INFO - 2016-10-11 17:32:58 --> Language Class Initialized
INFO - 2016-10-11 17:32:58 --> Config Class Initialized
INFO - 2016-10-11 17:32:58 --> Loader Class Initialized
INFO - 2016-10-11 17:32:58 --> Helper loaded: url_helper
INFO - 2016-10-11 17:32:58 --> Database Driver Class Initialized
INFO - 2016-10-11 17:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:32:58 --> Controller Class Initialized
DEBUG - 2016-10-11 17:32:58 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:32:58 --> Model Class Initialized
INFO - 2016-10-11 17:32:58 --> Model Class Initialized
ERROR - 2016-10-11 17:32:58 --> Unable to delete cache file for admin/index/getDetailAngsuran
INFO - 2016-10-11 17:32:58 --> Database Driver Class Initialized
INFO - 2016-10-11 17:32:58 --> Final output sent to browser
DEBUG - 2016-10-11 17:32:58 --> Total execution time: 0.6196
INFO - 2016-10-11 17:33:02 --> Config Class Initialized
INFO - 2016-10-11 17:33:02 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:33:02 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:33:02 --> Utf8 Class Initialized
INFO - 2016-10-11 17:33:02 --> URI Class Initialized
INFO - 2016-10-11 17:33:02 --> Router Class Initialized
INFO - 2016-10-11 17:33:02 --> Output Class Initialized
INFO - 2016-10-11 17:33:02 --> Security Class Initialized
DEBUG - 2016-10-11 17:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:33:02 --> Input Class Initialized
INFO - 2016-10-11 17:33:02 --> Language Class Initialized
INFO - 2016-10-11 17:33:02 --> Language Class Initialized
INFO - 2016-10-11 17:33:02 --> Config Class Initialized
INFO - 2016-10-11 17:33:02 --> Loader Class Initialized
INFO - 2016-10-11 17:33:02 --> Helper loaded: url_helper
INFO - 2016-10-11 17:33:02 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:33:02 --> Controller Class Initialized
DEBUG - 2016-10-11 17:33:02 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:33:02 --> Model Class Initialized
INFO - 2016-10-11 17:33:02 --> Model Class Initialized
ERROR - 2016-10-11 17:33:02 --> Unable to delete cache file for admin/index/do_bayar
INFO - 2016-10-11 17:33:02 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:02 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:03 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:03 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:03 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:03 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:03 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:03 --> Final output sent to browser
DEBUG - 2016-10-11 17:33:03 --> Total execution time: 0.9998
INFO - 2016-10-11 17:33:05 --> Config Class Initialized
INFO - 2016-10-11 17:33:05 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:33:05 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:33:05 --> Utf8 Class Initialized
INFO - 2016-10-11 17:33:05 --> URI Class Initialized
INFO - 2016-10-11 17:33:05 --> Router Class Initialized
INFO - 2016-10-11 17:33:05 --> Output Class Initialized
INFO - 2016-10-11 17:33:05 --> Security Class Initialized
DEBUG - 2016-10-11 17:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:33:05 --> Input Class Initialized
INFO - 2016-10-11 17:33:05 --> Language Class Initialized
INFO - 2016-10-11 17:33:05 --> Language Class Initialized
INFO - 2016-10-11 17:33:05 --> Config Class Initialized
INFO - 2016-10-11 17:33:05 --> Loader Class Initialized
INFO - 2016-10-11 17:33:06 --> Helper loaded: url_helper
INFO - 2016-10-11 17:33:06 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:33:06 --> Controller Class Initialized
DEBUG - 2016-10-11 17:33:06 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:33:06 --> Model Class Initialized
INFO - 2016-10-11 17:33:06 --> Model Class Initialized
ERROR - 2016-10-11 17:33:06 --> Unable to delete cache file for admin/index/getDetailAngsuran
INFO - 2016-10-11 17:33:06 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:06 --> Final output sent to browser
DEBUG - 2016-10-11 17:33:06 --> Total execution time: 0.6859
INFO - 2016-10-11 17:33:07 --> Config Class Initialized
INFO - 2016-10-11 17:33:07 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:33:08 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:33:08 --> Utf8 Class Initialized
INFO - 2016-10-11 17:33:08 --> URI Class Initialized
INFO - 2016-10-11 17:33:08 --> Router Class Initialized
INFO - 2016-10-11 17:33:08 --> Output Class Initialized
INFO - 2016-10-11 17:33:08 --> Security Class Initialized
DEBUG - 2016-10-11 17:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:33:08 --> Input Class Initialized
INFO - 2016-10-11 17:33:08 --> Language Class Initialized
INFO - 2016-10-11 17:33:08 --> Language Class Initialized
INFO - 2016-10-11 17:33:08 --> Config Class Initialized
INFO - 2016-10-11 17:33:08 --> Loader Class Initialized
INFO - 2016-10-11 17:33:08 --> Helper loaded: url_helper
INFO - 2016-10-11 17:33:08 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:33:08 --> Controller Class Initialized
DEBUG - 2016-10-11 17:33:08 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:33:08 --> Model Class Initialized
INFO - 2016-10-11 17:33:08 --> Model Class Initialized
ERROR - 2016-10-11 17:33:08 --> Unable to delete cache file for admin/index/do_bayar
INFO - 2016-10-11 17:33:08 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:08 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:08 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:09 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:09 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:09 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:09 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:09 --> Final output sent to browser
DEBUG - 2016-10-11 17:33:09 --> Total execution time: 1.5151
INFO - 2016-10-11 17:33:10 --> Config Class Initialized
INFO - 2016-10-11 17:33:10 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:33:10 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:33:10 --> Utf8 Class Initialized
INFO - 2016-10-11 17:33:10 --> URI Class Initialized
INFO - 2016-10-11 17:33:10 --> Router Class Initialized
INFO - 2016-10-11 17:33:10 --> Output Class Initialized
INFO - 2016-10-11 17:33:10 --> Security Class Initialized
DEBUG - 2016-10-11 17:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:33:10 --> Input Class Initialized
INFO - 2016-10-11 17:33:10 --> Language Class Initialized
INFO - 2016-10-11 17:33:10 --> Language Class Initialized
INFO - 2016-10-11 17:33:10 --> Config Class Initialized
INFO - 2016-10-11 17:33:10 --> Loader Class Initialized
INFO - 2016-10-11 17:33:10 --> Helper loaded: url_helper
INFO - 2016-10-11 17:33:10 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:33:10 --> Controller Class Initialized
DEBUG - 2016-10-11 17:33:11 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:33:11 --> Model Class Initialized
INFO - 2016-10-11 17:33:11 --> Model Class Initialized
ERROR - 2016-10-11 17:33:11 --> Unable to delete cache file for admin/index/getDetailAngsuran
INFO - 2016-10-11 17:33:11 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:11 --> Final output sent to browser
DEBUG - 2016-10-11 17:33:11 --> Total execution time: 0.7440
INFO - 2016-10-11 17:33:12 --> Config Class Initialized
INFO - 2016-10-11 17:33:12 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:33:12 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:33:12 --> Utf8 Class Initialized
INFO - 2016-10-11 17:33:12 --> URI Class Initialized
INFO - 2016-10-11 17:33:12 --> Router Class Initialized
INFO - 2016-10-11 17:33:12 --> Output Class Initialized
INFO - 2016-10-11 17:33:12 --> Security Class Initialized
DEBUG - 2016-10-11 17:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:33:12 --> Input Class Initialized
INFO - 2016-10-11 17:33:12 --> Language Class Initialized
INFO - 2016-10-11 17:33:12 --> Language Class Initialized
INFO - 2016-10-11 17:33:12 --> Config Class Initialized
INFO - 2016-10-11 17:33:12 --> Loader Class Initialized
INFO - 2016-10-11 17:33:12 --> Helper loaded: url_helper
INFO - 2016-10-11 17:33:12 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:33:12 --> Controller Class Initialized
DEBUG - 2016-10-11 17:33:12 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:33:12 --> Model Class Initialized
INFO - 2016-10-11 17:33:12 --> Model Class Initialized
ERROR - 2016-10-11 17:33:13 --> Unable to delete cache file for admin/index/do_bayar
INFO - 2016-10-11 17:33:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:13 --> Final output sent to browser
DEBUG - 2016-10-11 17:33:13 --> Total execution time: 1.3605
INFO - 2016-10-11 17:33:15 --> Config Class Initialized
INFO - 2016-10-11 17:33:15 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:33:15 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:33:15 --> Utf8 Class Initialized
INFO - 2016-10-11 17:33:15 --> URI Class Initialized
INFO - 2016-10-11 17:33:15 --> Router Class Initialized
INFO - 2016-10-11 17:33:15 --> Output Class Initialized
INFO - 2016-10-11 17:33:15 --> Security Class Initialized
DEBUG - 2016-10-11 17:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:33:15 --> Input Class Initialized
INFO - 2016-10-11 17:33:15 --> Language Class Initialized
INFO - 2016-10-11 17:33:15 --> Language Class Initialized
INFO - 2016-10-11 17:33:15 --> Config Class Initialized
INFO - 2016-10-11 17:33:15 --> Loader Class Initialized
INFO - 2016-10-11 17:33:15 --> Helper loaded: url_helper
INFO - 2016-10-11 17:33:15 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:33:16 --> Controller Class Initialized
DEBUG - 2016-10-11 17:33:16 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:33:16 --> Model Class Initialized
INFO - 2016-10-11 17:33:16 --> Model Class Initialized
ERROR - 2016-10-11 17:33:16 --> Unable to delete cache file for admin/index/getDetailAngsuran
INFO - 2016-10-11 17:33:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:16 --> Final output sent to browser
DEBUG - 2016-10-11 17:33:16 --> Total execution time: 0.7699
INFO - 2016-10-11 17:33:17 --> Config Class Initialized
INFO - 2016-10-11 17:33:17 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:33:17 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:33:17 --> Utf8 Class Initialized
INFO - 2016-10-11 17:33:17 --> URI Class Initialized
INFO - 2016-10-11 17:33:17 --> Router Class Initialized
INFO - 2016-10-11 17:33:17 --> Output Class Initialized
INFO - 2016-10-11 17:33:17 --> Security Class Initialized
DEBUG - 2016-10-11 17:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:33:17 --> Input Class Initialized
INFO - 2016-10-11 17:33:17 --> Language Class Initialized
INFO - 2016-10-11 17:33:17 --> Language Class Initialized
INFO - 2016-10-11 17:33:17 --> Config Class Initialized
INFO - 2016-10-11 17:33:17 --> Loader Class Initialized
INFO - 2016-10-11 17:33:17 --> Helper loaded: url_helper
INFO - 2016-10-11 17:33:17 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:33:17 --> Controller Class Initialized
DEBUG - 2016-10-11 17:33:17 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:33:17 --> Model Class Initialized
INFO - 2016-10-11 17:33:17 --> Model Class Initialized
ERROR - 2016-10-11 17:33:17 --> Unable to delete cache file for admin/index/do_bayar
INFO - 2016-10-11 17:33:17 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:17 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:18 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:18 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:18 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:18 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:18 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:18 --> Final output sent to browser
DEBUG - 2016-10-11 17:33:18 --> Total execution time: 1.3460
INFO - 2016-10-11 17:33:19 --> Config Class Initialized
INFO - 2016-10-11 17:33:19 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:33:19 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:33:19 --> Utf8 Class Initialized
INFO - 2016-10-11 17:33:19 --> URI Class Initialized
INFO - 2016-10-11 17:33:19 --> Router Class Initialized
INFO - 2016-10-11 17:33:20 --> Output Class Initialized
INFO - 2016-10-11 17:33:20 --> Security Class Initialized
DEBUG - 2016-10-11 17:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:33:20 --> Input Class Initialized
INFO - 2016-10-11 17:33:20 --> Language Class Initialized
INFO - 2016-10-11 17:33:20 --> Language Class Initialized
INFO - 2016-10-11 17:33:20 --> Config Class Initialized
INFO - 2016-10-11 17:33:20 --> Loader Class Initialized
INFO - 2016-10-11 17:33:20 --> Helper loaded: url_helper
INFO - 2016-10-11 17:33:20 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:33:20 --> Controller Class Initialized
DEBUG - 2016-10-11 17:33:20 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:33:20 --> Model Class Initialized
INFO - 2016-10-11 17:33:20 --> Model Class Initialized
ERROR - 2016-10-11 17:33:20 --> Unable to delete cache file for admin/index/getDetailAngsuran
INFO - 2016-10-11 17:33:20 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:20 --> Final output sent to browser
DEBUG - 2016-10-11 17:33:20 --> Total execution time: 0.7422
INFO - 2016-10-11 17:33:21 --> Config Class Initialized
INFO - 2016-10-11 17:33:21 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:33:21 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:33:21 --> Utf8 Class Initialized
INFO - 2016-10-11 17:33:21 --> URI Class Initialized
INFO - 2016-10-11 17:33:21 --> Router Class Initialized
INFO - 2016-10-11 17:33:21 --> Output Class Initialized
INFO - 2016-10-11 17:33:21 --> Security Class Initialized
DEBUG - 2016-10-11 17:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:33:21 --> Input Class Initialized
INFO - 2016-10-11 17:33:21 --> Language Class Initialized
INFO - 2016-10-11 17:33:21 --> Language Class Initialized
INFO - 2016-10-11 17:33:21 --> Config Class Initialized
INFO - 2016-10-11 17:33:21 --> Loader Class Initialized
INFO - 2016-10-11 17:33:21 --> Helper loaded: url_helper
INFO - 2016-10-11 17:33:21 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:33:21 --> Controller Class Initialized
DEBUG - 2016-10-11 17:33:21 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:33:22 --> Model Class Initialized
INFO - 2016-10-11 17:33:22 --> Model Class Initialized
ERROR - 2016-10-11 17:33:22 --> Unable to delete cache file for admin/index/do_bayar
INFO - 2016-10-11 17:33:22 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:22 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:22 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:22 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:22 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:22 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:22 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:22 --> Final output sent to browser
DEBUG - 2016-10-11 17:33:22 --> Total execution time: 1.0800
INFO - 2016-10-11 17:33:25 --> Config Class Initialized
INFO - 2016-10-11 17:33:25 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:33:25 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:33:25 --> Utf8 Class Initialized
INFO - 2016-10-11 17:33:25 --> URI Class Initialized
INFO - 2016-10-11 17:33:25 --> Router Class Initialized
INFO - 2016-10-11 17:33:25 --> Output Class Initialized
INFO - 2016-10-11 17:33:25 --> Security Class Initialized
DEBUG - 2016-10-11 17:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:33:25 --> Input Class Initialized
INFO - 2016-10-11 17:33:25 --> Language Class Initialized
INFO - 2016-10-11 17:33:25 --> Language Class Initialized
INFO - 2016-10-11 17:33:25 --> Config Class Initialized
INFO - 2016-10-11 17:33:25 --> Loader Class Initialized
INFO - 2016-10-11 17:33:25 --> Helper loaded: url_helper
INFO - 2016-10-11 17:33:25 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:33:25 --> Controller Class Initialized
DEBUG - 2016-10-11 17:33:25 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:33:25 --> Model Class Initialized
INFO - 2016-10-11 17:33:26 --> Model Class Initialized
ERROR - 2016-10-11 17:33:26 --> Unable to delete cache file for admin/index/getDetailAngsuran
INFO - 2016-10-11 17:33:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:26 --> Final output sent to browser
DEBUG - 2016-10-11 17:33:26 --> Total execution time: 0.6978
INFO - 2016-10-11 17:33:32 --> Config Class Initialized
INFO - 2016-10-11 17:33:32 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:33:32 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:33:32 --> Utf8 Class Initialized
INFO - 2016-10-11 17:33:32 --> URI Class Initialized
INFO - 2016-10-11 17:33:32 --> Router Class Initialized
INFO - 2016-10-11 17:33:32 --> Output Class Initialized
INFO - 2016-10-11 17:33:32 --> Security Class Initialized
DEBUG - 2016-10-11 17:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:33:33 --> Input Class Initialized
INFO - 2016-10-11 17:33:33 --> Language Class Initialized
INFO - 2016-10-11 17:33:33 --> Language Class Initialized
INFO - 2016-10-11 17:33:33 --> Config Class Initialized
INFO - 2016-10-11 17:33:33 --> Loader Class Initialized
INFO - 2016-10-11 17:33:33 --> Helper loaded: url_helper
INFO - 2016-10-11 17:33:33 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:33:33 --> Controller Class Initialized
DEBUG - 2016-10-11 17:33:33 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:33:33 --> Model Class Initialized
INFO - 2016-10-11 17:33:33 --> Model Class Initialized
ERROR - 2016-10-11 17:33:33 --> Unable to delete cache file for admin/index/detail_anggota/356a192b7913b04c54574d18c28d46e6395428ab
DEBUG - 2016-10-11 17:33:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-11 17:33:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-11 17:33:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
INFO - 2016-10-11 17:33:33 --> Database Driver Class Initialized
DEBUG - 2016-10-11 17:33:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_pinjaman.php
INFO - 2016-10-11 17:33:33 --> Database Driver Class Initialized
DEBUG - 2016-10-11 17:33:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_tabungan.php
DEBUG - 2016-10-11 17:33:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/profile_anggota.php
DEBUG - 2016-10-11 17:33:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-11 17:33:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-11 17:33:33 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:33 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:33 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:33 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:33 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:33 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:33 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:33 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:33 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:33 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:35 --> Database Driver Class Initialized
DEBUG - 2016-10-11 17:33:35 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-11 17:33:35 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-11 17:33:35 --> Final output sent to browser
DEBUG - 2016-10-11 17:33:35 --> Total execution time: 2.8868
INFO - 2016-10-11 17:33:35 --> Config Class Initialized
INFO - 2016-10-11 17:33:35 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:33:35 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:33:35 --> Utf8 Class Initialized
INFO - 2016-10-11 17:33:36 --> URI Class Initialized
INFO - 2016-10-11 17:33:36 --> Router Class Initialized
INFO - 2016-10-11 17:33:36 --> Output Class Initialized
INFO - 2016-10-11 17:33:36 --> Security Class Initialized
DEBUG - 2016-10-11 17:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:33:36 --> Input Class Initialized
INFO - 2016-10-11 17:33:36 --> Language Class Initialized
INFO - 2016-10-11 17:33:36 --> Language Class Initialized
INFO - 2016-10-11 17:33:36 --> Config Class Initialized
INFO - 2016-10-11 17:33:36 --> Loader Class Initialized
INFO - 2016-10-11 17:33:36 --> Helper loaded: url_helper
INFO - 2016-10-11 17:33:36 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:33:36 --> Controller Class Initialized
DEBUG - 2016-10-11 17:33:36 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:33:36 --> Model Class Initialized
INFO - 2016-10-11 17:33:36 --> Model Class Initialized
ERROR - 2016-10-11 17:33:37 --> Unable to delete cache file for admin/index/detail_anggota/images/picture.jpg
DEBUG - 2016-10-11 17:33:37 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-11 17:33:37 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-11 17:33:37 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
ERROR - 2016-10-11 17:33:37 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 16
ERROR - 2016-10-11 17:33:37 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 19
ERROR - 2016-10-11 17:33:37 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 22
ERROR - 2016-10-11 17:33:37 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 38
INFO - 2016-10-11 17:33:37 --> Database Driver Class Initialized
DEBUG - 2016-10-11 17:33:37 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_pinjaman.php
ERROR - 2016-10-11 17:33:37 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 41
INFO - 2016-10-11 17:33:37 --> Database Driver Class Initialized
DEBUG - 2016-10-11 17:33:37 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_tabungan.php
DEBUG - 2016-10-11 17:33:37 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/profile_anggota.php
DEBUG - 2016-10-11 17:33:37 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-11 17:33:37 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-11 17:33:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:41 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:41 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:41 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:41 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:41 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:41 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:41 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:41 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:41 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:41 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:41 --> Database Driver Class Initialized
DEBUG - 2016-10-11 17:33:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-11 17:33:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-11 17:33:41 --> Final output sent to browser
DEBUG - 2016-10-11 17:33:41 --> Total execution time: 5.6349
INFO - 2016-10-11 17:33:43 --> Config Class Initialized
INFO - 2016-10-11 17:33:43 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:33:43 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:33:43 --> Utf8 Class Initialized
INFO - 2016-10-11 17:33:43 --> URI Class Initialized
INFO - 2016-10-11 17:33:43 --> Router Class Initialized
INFO - 2016-10-11 17:33:43 --> Output Class Initialized
INFO - 2016-10-11 17:33:43 --> Security Class Initialized
DEBUG - 2016-10-11 17:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:33:44 --> Input Class Initialized
INFO - 2016-10-11 17:33:44 --> Language Class Initialized
INFO - 2016-10-11 17:33:44 --> Language Class Initialized
INFO - 2016-10-11 17:33:44 --> Config Class Initialized
INFO - 2016-10-11 17:33:44 --> Loader Class Initialized
INFO - 2016-10-11 17:33:44 --> Helper loaded: url_helper
INFO - 2016-10-11 17:33:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:33:44 --> Controller Class Initialized
DEBUG - 2016-10-11 17:33:44 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:33:44 --> Model Class Initialized
INFO - 2016-10-11 17:33:44 --> Model Class Initialized
ERROR - 2016-10-11 17:33:44 --> Unable to delete cache file for admin/index/getRaportAngsuran/ca3512f4dfa95a03169c5a670a4c91a19b3077b4
DEBUG - 2016-10-11 17:33:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/raport_angsuran.php
INFO - 2016-10-11 17:33:44 --> Final output sent to browser
DEBUG - 2016-10-11 17:33:44 --> Total execution time: 0.9566
INFO - 2016-10-11 17:35:28 --> Config Class Initialized
INFO - 2016-10-11 17:35:28 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:35:28 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:35:28 --> Utf8 Class Initialized
INFO - 2016-10-11 17:35:28 --> URI Class Initialized
INFO - 2016-10-11 17:35:28 --> Router Class Initialized
INFO - 2016-10-11 17:35:28 --> Output Class Initialized
INFO - 2016-10-11 17:35:29 --> Security Class Initialized
DEBUG - 2016-10-11 17:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:35:29 --> Input Class Initialized
INFO - 2016-10-11 17:35:29 --> Language Class Initialized
INFO - 2016-10-11 17:35:29 --> Language Class Initialized
INFO - 2016-10-11 17:35:29 --> Config Class Initialized
INFO - 2016-10-11 17:35:29 --> Loader Class Initialized
INFO - 2016-10-11 17:35:29 --> Helper loaded: url_helper
INFO - 2016-10-11 17:35:29 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:35:29 --> Controller Class Initialized
DEBUG - 2016-10-11 17:35:29 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:35:29 --> Model Class Initialized
INFO - 2016-10-11 17:35:29 --> Model Class Initialized
ERROR - 2016-10-11 17:35:29 --> Unable to delete cache file for admin/index/buku_besar
DEBUG - 2016-10-11 17:35:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-11 17:35:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-11 17:35:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-11 17:35:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/buku_besar.php
DEBUG - 2016-10-11 17:35:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-11 17:35:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-11 17:35:29 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:29 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:29 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:29 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:29 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:29 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:29 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:29 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:29 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:29 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:29 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:29 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:29 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:30 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:30 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:30 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:30 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:30 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:30 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:30 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:30 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:30 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:30 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:30 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:30 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:30 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:30 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:30 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:30 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:30 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:30 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:30 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:30 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:30 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:30 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:30 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:30 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:30 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:30 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:30 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:30 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:30 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:30 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:30 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:30 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:31 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:31 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:31 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:31 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:31 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:31 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:31 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:31 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:31 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:31 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:31 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:31 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:31 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:31 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:31 --> Database Driver Class Initialized
DEBUG - 2016-10-11 17:35:31 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-11 17:35:31 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-11 17:35:31 --> Final output sent to browser
DEBUG - 2016-10-11 17:35:31 --> Total execution time: 2.7999
INFO - 2016-10-11 17:35:47 --> Config Class Initialized
INFO - 2016-10-11 17:35:47 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:35:47 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:35:47 --> Utf8 Class Initialized
INFO - 2016-10-11 17:35:47 --> URI Class Initialized
INFO - 2016-10-11 17:35:47 --> Router Class Initialized
INFO - 2016-10-11 17:35:47 --> Output Class Initialized
INFO - 2016-10-11 17:35:47 --> Security Class Initialized
DEBUG - 2016-10-11 17:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:35:47 --> Input Class Initialized
INFO - 2016-10-11 17:35:47 --> Language Class Initialized
INFO - 2016-10-11 17:35:47 --> Language Class Initialized
INFO - 2016-10-11 17:35:47 --> Config Class Initialized
INFO - 2016-10-11 17:35:47 --> Loader Class Initialized
INFO - 2016-10-11 17:35:47 --> Helper loaded: url_helper
INFO - 2016-10-11 17:35:47 --> Database Driver Class Initialized
INFO - 2016-10-11 17:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:35:47 --> Controller Class Initialized
DEBUG - 2016-10-11 17:35:47 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:35:47 --> Model Class Initialized
INFO - 2016-10-11 17:35:47 --> Model Class Initialized
ERROR - 2016-10-11 17:35:47 --> Unable to delete cache file for admin/index/do_laporan_buku_besar
DEBUG - 2016-10-11 17:35:48 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_buku_besar.php
INFO - 2016-10-11 17:35:48 --> Final output sent to browser
DEBUG - 2016-10-11 17:35:48 --> Total execution time: 0.8099
INFO - 2016-10-11 17:36:07 --> Config Class Initialized
INFO - 2016-10-11 17:36:07 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:36:07 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:36:07 --> Utf8 Class Initialized
INFO - 2016-10-11 17:36:07 --> URI Class Initialized
INFO - 2016-10-11 17:36:07 --> Router Class Initialized
INFO - 2016-10-11 17:36:07 --> Output Class Initialized
INFO - 2016-10-11 17:36:07 --> Security Class Initialized
DEBUG - 2016-10-11 17:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:36:07 --> Input Class Initialized
INFO - 2016-10-11 17:36:07 --> Language Class Initialized
INFO - 2016-10-11 17:36:07 --> Language Class Initialized
INFO - 2016-10-11 17:36:07 --> Config Class Initialized
INFO - 2016-10-11 17:36:07 --> Loader Class Initialized
INFO - 2016-10-11 17:36:07 --> Helper loaded: url_helper
INFO - 2016-10-11 17:36:08 --> Database Driver Class Initialized
INFO - 2016-10-11 17:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:36:08 --> Controller Class Initialized
DEBUG - 2016-10-11 17:36:08 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:36:08 --> Model Class Initialized
INFO - 2016-10-11 17:36:08 --> Model Class Initialized
ERROR - 2016-10-11 17:36:08 --> Unable to delete cache file for admin/index/do_laporan_buku_besar
DEBUG - 2016-10-11 17:36:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_buku_besar.php
INFO - 2016-10-11 17:36:08 --> Final output sent to browser
DEBUG - 2016-10-11 17:36:08 --> Total execution time: 0.6452
INFO - 2016-10-11 17:36:17 --> Config Class Initialized
INFO - 2016-10-11 17:36:17 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:36:17 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:36:17 --> Utf8 Class Initialized
INFO - 2016-10-11 17:36:17 --> URI Class Initialized
INFO - 2016-10-11 17:36:17 --> Router Class Initialized
INFO - 2016-10-11 17:36:17 --> Output Class Initialized
INFO - 2016-10-11 17:36:17 --> Security Class Initialized
DEBUG - 2016-10-11 17:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:36:17 --> Input Class Initialized
INFO - 2016-10-11 17:36:17 --> Language Class Initialized
INFO - 2016-10-11 17:36:17 --> Language Class Initialized
INFO - 2016-10-11 17:36:17 --> Config Class Initialized
INFO - 2016-10-11 17:36:17 --> Loader Class Initialized
INFO - 2016-10-11 17:36:17 --> Helper loaded: url_helper
INFO - 2016-10-11 17:36:17 --> Database Driver Class Initialized
INFO - 2016-10-11 17:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:36:17 --> Controller Class Initialized
DEBUG - 2016-10-11 17:36:17 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:36:17 --> Model Class Initialized
INFO - 2016-10-11 17:36:17 --> Model Class Initialized
ERROR - 2016-10-11 17:36:17 --> Unable to delete cache file for admin/index/do_laporan_buku_besar
DEBUG - 2016-10-11 17:36:17 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_buku_besar.php
INFO - 2016-10-11 17:36:17 --> Final output sent to browser
DEBUG - 2016-10-11 17:36:17 --> Total execution time: 0.6368
INFO - 2016-10-11 17:36:28 --> Config Class Initialized
INFO - 2016-10-11 17:36:29 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:36:29 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:36:29 --> Utf8 Class Initialized
INFO - 2016-10-11 17:36:29 --> URI Class Initialized
INFO - 2016-10-11 17:36:29 --> Router Class Initialized
INFO - 2016-10-11 17:36:29 --> Output Class Initialized
INFO - 2016-10-11 17:36:29 --> Security Class Initialized
DEBUG - 2016-10-11 17:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:36:29 --> Input Class Initialized
INFO - 2016-10-11 17:36:29 --> Language Class Initialized
INFO - 2016-10-11 17:36:29 --> Language Class Initialized
INFO - 2016-10-11 17:36:29 --> Config Class Initialized
INFO - 2016-10-11 17:36:29 --> Loader Class Initialized
INFO - 2016-10-11 17:36:29 --> Helper loaded: url_helper
INFO - 2016-10-11 17:36:29 --> Database Driver Class Initialized
INFO - 2016-10-11 17:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:36:29 --> Controller Class Initialized
DEBUG - 2016-10-11 17:36:29 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:36:29 --> Model Class Initialized
INFO - 2016-10-11 17:36:29 --> Model Class Initialized
ERROR - 2016-10-11 17:36:29 --> Unable to delete cache file for admin/index/do_laporan_buku_besar
DEBUG - 2016-10-11 17:36:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_buku_besar.php
INFO - 2016-10-11 17:36:29 --> Final output sent to browser
DEBUG - 2016-10-11 17:36:29 --> Total execution time: 0.6575
INFO - 2016-10-11 17:36:39 --> Config Class Initialized
INFO - 2016-10-11 17:36:39 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:36:39 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:36:39 --> Utf8 Class Initialized
INFO - 2016-10-11 17:36:39 --> URI Class Initialized
INFO - 2016-10-11 17:36:39 --> Router Class Initialized
INFO - 2016-10-11 17:36:39 --> Output Class Initialized
INFO - 2016-10-11 17:36:39 --> Security Class Initialized
DEBUG - 2016-10-11 17:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:36:39 --> Input Class Initialized
INFO - 2016-10-11 17:36:39 --> Language Class Initialized
INFO - 2016-10-11 17:36:40 --> Language Class Initialized
INFO - 2016-10-11 17:36:40 --> Config Class Initialized
INFO - 2016-10-11 17:36:40 --> Loader Class Initialized
INFO - 2016-10-11 17:36:40 --> Helper loaded: url_helper
INFO - 2016-10-11 17:36:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:36:40 --> Controller Class Initialized
DEBUG - 2016-10-11 17:36:40 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:36:40 --> Model Class Initialized
INFO - 2016-10-11 17:36:40 --> Model Class Initialized
ERROR - 2016-10-11 17:36:40 --> Unable to delete cache file for admin/index/do_laporan_buku_besar
DEBUG - 2016-10-11 17:36:40 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_buku_besar.php
INFO - 2016-10-11 17:36:40 --> Final output sent to browser
DEBUG - 2016-10-11 17:36:40 --> Total execution time: 0.6123
INFO - 2016-10-11 17:42:02 --> Config Class Initialized
INFO - 2016-10-11 17:42:02 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:42:02 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:42:02 --> Utf8 Class Initialized
INFO - 2016-10-11 17:42:02 --> URI Class Initialized
INFO - 2016-10-11 17:42:02 --> Router Class Initialized
INFO - 2016-10-11 17:42:02 --> Output Class Initialized
INFO - 2016-10-11 17:42:02 --> Security Class Initialized
DEBUG - 2016-10-11 17:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:42:02 --> Input Class Initialized
INFO - 2016-10-11 17:42:02 --> Language Class Initialized
INFO - 2016-10-11 17:42:02 --> Language Class Initialized
INFO - 2016-10-11 17:42:02 --> Config Class Initialized
INFO - 2016-10-11 17:42:02 --> Loader Class Initialized
INFO - 2016-10-11 17:42:02 --> Helper loaded: url_helper
INFO - 2016-10-11 17:42:02 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:42:02 --> Controller Class Initialized
DEBUG - 2016-10-11 17:42:02 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:42:02 --> Model Class Initialized
INFO - 2016-10-11 17:42:02 --> Model Class Initialized
ERROR - 2016-10-11 17:42:02 --> Unable to delete cache file for admin/index/tabungan
DEBUG - 2016-10-11 17:42:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-11 17:42:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-11 17:42:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-11 17:42:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_nasabah_tabungan.php
DEBUG - 2016-10-11 17:42:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_tabungan.php
DEBUG - 2016-10-11 17:42:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-11 17:42:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-11 17:42:03 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:03 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:03 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:03 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:03 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:03 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:03 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:03 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:03 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:03 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:03 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:03 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:03 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:03 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:03 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:03 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:03 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:03 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:03 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:03 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:03 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:03 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:03 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:03 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:03 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:03 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:03 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:03 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:03 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:05 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:05 --> Database Driver Class Initialized
DEBUG - 2016-10-11 17:42:05 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-11 17:42:05 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-11 17:42:05 --> Final output sent to browser
DEBUG - 2016-10-11 17:42:05 --> Total execution time: 3.1111
INFO - 2016-10-11 17:42:15 --> Config Class Initialized
INFO - 2016-10-11 17:42:15 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:42:15 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:42:15 --> Utf8 Class Initialized
INFO - 2016-10-11 17:42:15 --> URI Class Initialized
INFO - 2016-10-11 17:42:16 --> Router Class Initialized
INFO - 2016-10-11 17:42:16 --> Output Class Initialized
INFO - 2016-10-11 17:42:16 --> Security Class Initialized
DEBUG - 2016-10-11 17:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:42:16 --> Input Class Initialized
INFO - 2016-10-11 17:42:16 --> Language Class Initialized
INFO - 2016-10-11 17:42:16 --> Language Class Initialized
INFO - 2016-10-11 17:42:16 --> Config Class Initialized
INFO - 2016-10-11 17:42:16 --> Loader Class Initialized
INFO - 2016-10-11 17:42:16 --> Helper loaded: url_helper
INFO - 2016-10-11 17:42:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:42:16 --> Controller Class Initialized
DEBUG - 2016-10-11 17:42:16 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:42:16 --> Model Class Initialized
INFO - 2016-10-11 17:42:16 --> Model Class Initialized
ERROR - 2016-10-11 17:42:16 --> Unable to delete cache file for admin/index/getDetailNasabah
INFO - 2016-10-11 17:42:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:16 --> Final output sent to browser
DEBUG - 2016-10-11 17:42:16 --> Total execution time: 0.7095
INFO - 2016-10-11 17:42:22 --> Config Class Initialized
INFO - 2016-10-11 17:42:22 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:42:22 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:42:22 --> Utf8 Class Initialized
INFO - 2016-10-11 17:42:22 --> URI Class Initialized
INFO - 2016-10-11 17:42:22 --> Router Class Initialized
INFO - 2016-10-11 17:42:22 --> Output Class Initialized
INFO - 2016-10-11 17:42:22 --> Security Class Initialized
DEBUG - 2016-10-11 17:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:42:23 --> Input Class Initialized
INFO - 2016-10-11 17:42:23 --> Language Class Initialized
INFO - 2016-10-11 17:42:23 --> Language Class Initialized
INFO - 2016-10-11 17:42:23 --> Config Class Initialized
INFO - 2016-10-11 17:42:23 --> Loader Class Initialized
INFO - 2016-10-11 17:42:23 --> Helper loaded: url_helper
INFO - 2016-10-11 17:42:23 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:42:23 --> Controller Class Initialized
DEBUG - 2016-10-11 17:42:23 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:42:23 --> Model Class Initialized
INFO - 2016-10-11 17:42:23 --> Model Class Initialized
ERROR - 2016-10-11 17:42:23 --> Unable to delete cache file for admin/index/form_simpan_tabungan/356a192b7913b04c54574d18c28d46e6395428ab
INFO - 2016-10-11 17:42:23 --> Database Driver Class Initialized
DEBUG - 2016-10-11 17:42:23 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-11 17:42:23 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-11 17:42:23 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-11 17:42:23 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_simpan_tabungan.php
DEBUG - 2016-10-11 17:42:23 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-11 17:42:23 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-11 17:42:23 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:23 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:23 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:23 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:23 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:23 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:23 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:23 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:23 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:23 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:23 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:23 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:23 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:24 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:24 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:24 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:24 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:24 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:24 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:24 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:24 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:24 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:24 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:24 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:24 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:24 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:24 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:24 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:24 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:24 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:24 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:24 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:24 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:24 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:24 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:24 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:24 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:24 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:24 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:24 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:24 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:24 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:24 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:24 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:25 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:25 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:25 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:25 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:25 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:25 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:25 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:25 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:25 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:25 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:25 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:25 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:25 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:25 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:25 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:25 --> Database Driver Class Initialized
DEBUG - 2016-10-11 17:42:25 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-11 17:42:25 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-11 17:42:25 --> Final output sent to browser
DEBUG - 2016-10-11 17:42:25 --> Total execution time: 2.8511
INFO - 2016-10-11 17:42:34 --> Config Class Initialized
INFO - 2016-10-11 17:42:34 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:42:34 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:42:34 --> Utf8 Class Initialized
INFO - 2016-10-11 17:42:34 --> URI Class Initialized
INFO - 2016-10-11 17:42:34 --> Router Class Initialized
INFO - 2016-10-11 17:42:34 --> Output Class Initialized
INFO - 2016-10-11 17:42:34 --> Security Class Initialized
DEBUG - 2016-10-11 17:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:42:34 --> Input Class Initialized
INFO - 2016-10-11 17:42:34 --> Language Class Initialized
INFO - 2016-10-11 17:42:34 --> Language Class Initialized
INFO - 2016-10-11 17:42:34 --> Config Class Initialized
INFO - 2016-10-11 17:42:34 --> Loader Class Initialized
INFO - 2016-10-11 17:42:34 --> Helper loaded: url_helper
INFO - 2016-10-11 17:42:34 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:42:34 --> Controller Class Initialized
DEBUG - 2016-10-11 17:42:34 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:42:35 --> Model Class Initialized
INFO - 2016-10-11 17:42:35 --> Model Class Initialized
ERROR - 2016-10-11 17:42:35 --> Unable to delete cache file for admin/index/simpan_tabungan
INFO - 2016-10-11 17:42:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:35 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:35 --> Final output sent to browser
DEBUG - 2016-10-11 17:42:35 --> Total execution time: 1.0188
INFO - 2016-10-11 17:42:43 --> Config Class Initialized
INFO - 2016-10-11 17:42:43 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:42:43 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:42:43 --> Utf8 Class Initialized
INFO - 2016-10-11 17:42:43 --> URI Class Initialized
INFO - 2016-10-11 17:42:43 --> Router Class Initialized
INFO - 2016-10-11 17:42:43 --> Output Class Initialized
INFO - 2016-10-11 17:42:43 --> Security Class Initialized
DEBUG - 2016-10-11 17:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:42:43 --> Input Class Initialized
INFO - 2016-10-11 17:42:43 --> Language Class Initialized
INFO - 2016-10-11 17:42:43 --> Language Class Initialized
INFO - 2016-10-11 17:42:43 --> Config Class Initialized
INFO - 2016-10-11 17:42:43 --> Loader Class Initialized
INFO - 2016-10-11 17:42:43 --> Helper loaded: url_helper
INFO - 2016-10-11 17:42:43 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:42:43 --> Controller Class Initialized
DEBUG - 2016-10-11 17:42:43 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:42:43 --> Model Class Initialized
INFO - 2016-10-11 17:42:44 --> Model Class Initialized
ERROR - 2016-10-11 17:42:44 --> Unable to delete cache file for admin/index/tabungan
DEBUG - 2016-10-11 17:42:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-11 17:42:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-11 17:42:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
INFO - 2016-10-11 17:42:44 --> Database Driver Class Initialized
DEBUG - 2016-10-11 17:42:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_nasabah_tabungan.php
DEBUG - 2016-10-11 17:42:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_tabungan.php
DEBUG - 2016-10-11 17:42:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-11 17:42:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-11 17:42:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:46 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:46 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:46 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:46 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:46 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:46 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:46 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:46 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:46 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:46 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:46 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:46 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:46 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:46 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:46 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:46 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:46 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:46 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:46 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:46 --> Database Driver Class Initialized
INFO - 2016-10-11 17:42:46 --> Database Driver Class Initialized
DEBUG - 2016-10-11 17:42:46 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-11 17:42:46 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-11 17:42:46 --> Final output sent to browser
DEBUG - 2016-10-11 17:42:46 --> Total execution time: 3.5351
INFO - 2016-10-11 17:43:25 --> Config Class Initialized
INFO - 2016-10-11 17:43:25 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:43:25 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:43:25 --> Utf8 Class Initialized
INFO - 2016-10-11 17:43:25 --> URI Class Initialized
INFO - 2016-10-11 17:43:25 --> Router Class Initialized
INFO - 2016-10-11 17:43:25 --> Output Class Initialized
INFO - 2016-10-11 17:43:25 --> Security Class Initialized
DEBUG - 2016-10-11 17:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:43:25 --> Input Class Initialized
INFO - 2016-10-11 17:43:26 --> Language Class Initialized
INFO - 2016-10-11 17:43:26 --> Language Class Initialized
INFO - 2016-10-11 17:43:26 --> Config Class Initialized
INFO - 2016-10-11 17:43:26 --> Loader Class Initialized
INFO - 2016-10-11 17:43:26 --> Helper loaded: url_helper
INFO - 2016-10-11 17:43:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:43:26 --> Controller Class Initialized
DEBUG - 2016-10-11 17:43:26 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:43:26 --> Model Class Initialized
INFO - 2016-10-11 17:43:26 --> Model Class Initialized
ERROR - 2016-10-11 17:43:26 --> Unable to delete cache file for admin/index/buku_besar
DEBUG - 2016-10-11 17:43:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-11 17:43:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-11 17:43:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-11 17:43:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/buku_besar.php
DEBUG - 2016-10-11 17:43:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-11 17:43:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-11 17:43:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:28 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:28 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:28 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:28 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:28 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:28 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:28 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:28 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:28 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:28 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:28 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:28 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:28 --> Database Driver Class Initialized
DEBUG - 2016-10-11 17:43:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-11 17:43:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-11 17:43:28 --> Final output sent to browser
DEBUG - 2016-10-11 17:43:28 --> Total execution time: 2.8240
INFO - 2016-10-11 17:43:44 --> Config Class Initialized
INFO - 2016-10-11 17:43:44 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:43:44 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:43:44 --> Utf8 Class Initialized
INFO - 2016-10-11 17:43:44 --> URI Class Initialized
INFO - 2016-10-11 17:43:44 --> Router Class Initialized
INFO - 2016-10-11 17:43:44 --> Output Class Initialized
INFO - 2016-10-11 17:43:44 --> Security Class Initialized
DEBUG - 2016-10-11 17:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:43:44 --> Input Class Initialized
INFO - 2016-10-11 17:43:44 --> Language Class Initialized
INFO - 2016-10-11 17:43:44 --> Language Class Initialized
INFO - 2016-10-11 17:43:44 --> Config Class Initialized
INFO - 2016-10-11 17:43:44 --> Loader Class Initialized
INFO - 2016-10-11 17:43:44 --> Helper loaded: url_helper
INFO - 2016-10-11 17:43:44 --> Database Driver Class Initialized
INFO - 2016-10-11 17:43:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:43:44 --> Controller Class Initialized
DEBUG - 2016-10-11 17:43:44 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:43:44 --> Model Class Initialized
INFO - 2016-10-11 17:43:44 --> Model Class Initialized
ERROR - 2016-10-11 17:43:44 --> Unable to delete cache file for admin/index/do_laporan_buku_besar
DEBUG - 2016-10-11 17:43:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_buku_besar.php
INFO - 2016-10-11 17:43:45 --> Final output sent to browser
DEBUG - 2016-10-11 17:43:45 --> Total execution time: 0.6364
INFO - 2016-10-11 17:44:37 --> Config Class Initialized
INFO - 2016-10-11 17:44:37 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:44:37 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:44:37 --> Utf8 Class Initialized
INFO - 2016-10-11 17:44:37 --> URI Class Initialized
INFO - 2016-10-11 17:44:37 --> Router Class Initialized
INFO - 2016-10-11 17:44:37 --> Output Class Initialized
INFO - 2016-10-11 17:44:37 --> Security Class Initialized
DEBUG - 2016-10-11 17:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:44:37 --> Input Class Initialized
INFO - 2016-10-11 17:44:37 --> Language Class Initialized
INFO - 2016-10-11 17:44:37 --> Language Class Initialized
INFO - 2016-10-11 17:44:37 --> Config Class Initialized
INFO - 2016-10-11 17:44:37 --> Loader Class Initialized
INFO - 2016-10-11 17:44:37 --> Helper loaded: url_helper
INFO - 2016-10-11 17:44:37 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:44:38 --> Controller Class Initialized
DEBUG - 2016-10-11 17:44:38 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:44:38 --> Model Class Initialized
INFO - 2016-10-11 17:44:38 --> Model Class Initialized
ERROR - 2016-10-11 17:44:38 --> Unable to delete cache file for admin/index/tabungan
DEBUG - 2016-10-11 17:44:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-11 17:44:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-11 17:44:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
INFO - 2016-10-11 17:44:38 --> Database Driver Class Initialized
DEBUG - 2016-10-11 17:44:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_nasabah_tabungan.php
DEBUG - 2016-10-11 17:44:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_tabungan.php
DEBUG - 2016-10-11 17:44:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-11 17:44:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-11 17:44:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:44:40 --> Database Driver Class Initialized
DEBUG - 2016-10-11 17:44:40 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-11 17:44:40 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-11 17:44:40 --> Final output sent to browser
DEBUG - 2016-10-11 17:44:40 --> Total execution time: 3.5179
INFO - 2016-10-11 17:45:36 --> Config Class Initialized
INFO - 2016-10-11 17:45:36 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:45:36 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:45:36 --> Utf8 Class Initialized
INFO - 2016-10-11 17:45:36 --> URI Class Initialized
INFO - 2016-10-11 17:45:36 --> Router Class Initialized
INFO - 2016-10-11 17:45:36 --> Output Class Initialized
INFO - 2016-10-11 17:45:36 --> Security Class Initialized
DEBUG - 2016-10-11 17:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:45:37 --> Input Class Initialized
INFO - 2016-10-11 17:45:37 --> Language Class Initialized
INFO - 2016-10-11 17:45:37 --> Language Class Initialized
INFO - 2016-10-11 17:45:37 --> Config Class Initialized
INFO - 2016-10-11 17:45:37 --> Loader Class Initialized
INFO - 2016-10-11 17:45:37 --> Helper loaded: url_helper
INFO - 2016-10-11 17:45:37 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:45:37 --> Controller Class Initialized
DEBUG - 2016-10-11 17:45:37 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:45:37 --> Model Class Initialized
INFO - 2016-10-11 17:45:37 --> Model Class Initialized
ERROR - 2016-10-11 17:45:37 --> Unable to delete cache file for admin/index/data/anggota
DEBUG - 2016-10-11 17:45:37 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-11 17:45:37 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-11 17:45:37 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-11 17:45:37 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-11 17:45:37 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-11 17:45:37 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-11 17:45:37 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-11 17:45:37 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-11 17:45:37 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:37 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:37 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:37 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:39 --> Database Driver Class Initialized
DEBUG - 2016-10-11 17:45:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-11 17:45:40 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-11 17:45:40 --> Final output sent to browser
DEBUG - 2016-10-11 17:45:40 --> Total execution time: 3.3419
INFO - 2016-10-11 17:45:44 --> Config Class Initialized
INFO - 2016-10-11 17:45:44 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:45:44 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:45:44 --> Utf8 Class Initialized
INFO - 2016-10-11 17:45:44 --> URI Class Initialized
INFO - 2016-10-11 17:45:44 --> Router Class Initialized
INFO - 2016-10-11 17:45:44 --> Output Class Initialized
INFO - 2016-10-11 17:45:44 --> Security Class Initialized
DEBUG - 2016-10-11 17:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:45:44 --> Input Class Initialized
INFO - 2016-10-11 17:45:44 --> Language Class Initialized
INFO - 2016-10-11 17:45:45 --> Language Class Initialized
INFO - 2016-10-11 17:45:45 --> Config Class Initialized
INFO - 2016-10-11 17:45:45 --> Loader Class Initialized
INFO - 2016-10-11 17:45:45 --> Helper loaded: url_helper
INFO - 2016-10-11 17:45:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:45:45 --> Controller Class Initialized
DEBUG - 2016-10-11 17:45:45 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:45:45 --> Model Class Initialized
INFO - 2016-10-11 17:45:45 --> Model Class Initialized
ERROR - 2016-10-11 17:45:45 --> Unable to delete cache file for admin/index/detail_anggota/356a192b7913b04c54574d18c28d46e6395428ab
DEBUG - 2016-10-11 17:45:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-11 17:45:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-11 17:45:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
INFO - 2016-10-11 17:45:45 --> Database Driver Class Initialized
DEBUG - 2016-10-11 17:45:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_pinjaman.php
INFO - 2016-10-11 17:45:45 --> Database Driver Class Initialized
DEBUG - 2016-10-11 17:45:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_tabungan.php
DEBUG - 2016-10-11 17:45:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/profile_anggota.php
DEBUG - 2016-10-11 17:45:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-11 17:45:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-11 17:45:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:45 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:46 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:46 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:46 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:46 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:46 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:46 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:46 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:46 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:46 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:46 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:46 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:46 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:46 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:46 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:46 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:46 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:46 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:46 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:46 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:46 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:46 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:46 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:46 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:46 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:46 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:47 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:47 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:47 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:47 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:47 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:47 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:47 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:47 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:47 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:47 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:47 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:47 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:47 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:47 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:47 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:47 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:47 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:47 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:47 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:47 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:47 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:47 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:47 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:47 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:47 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:48 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:48 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:48 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:48 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:48 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:48 --> Database Driver Class Initialized
DEBUG - 2016-10-11 17:45:48 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-11 17:45:48 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-11 17:45:48 --> Final output sent to browser
DEBUG - 2016-10-11 17:45:48 --> Total execution time: 3.7552
INFO - 2016-10-11 17:45:48 --> Config Class Initialized
INFO - 2016-10-11 17:45:48 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:45:48 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:45:48 --> Utf8 Class Initialized
INFO - 2016-10-11 17:45:48 --> URI Class Initialized
INFO - 2016-10-11 17:45:48 --> Router Class Initialized
INFO - 2016-10-11 17:45:48 --> Output Class Initialized
INFO - 2016-10-11 17:45:48 --> Security Class Initialized
DEBUG - 2016-10-11 17:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:45:48 --> Input Class Initialized
INFO - 2016-10-11 17:45:49 --> Language Class Initialized
INFO - 2016-10-11 17:45:49 --> Language Class Initialized
INFO - 2016-10-11 17:45:49 --> Config Class Initialized
INFO - 2016-10-11 17:45:49 --> Loader Class Initialized
INFO - 2016-10-11 17:45:49 --> Helper loaded: url_helper
INFO - 2016-10-11 17:45:49 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:45:49 --> Controller Class Initialized
DEBUG - 2016-10-11 17:45:49 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:45:49 --> Model Class Initialized
INFO - 2016-10-11 17:45:49 --> Model Class Initialized
ERROR - 2016-10-11 17:45:49 --> Unable to delete cache file for admin/index/detail_anggota/images/picture.jpg
DEBUG - 2016-10-11 17:45:50 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-11 17:45:50 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-11 17:45:50 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
ERROR - 2016-10-11 17:45:50 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 16
ERROR - 2016-10-11 17:45:50 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 19
ERROR - 2016-10-11 17:45:50 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 22
ERROR - 2016-10-11 17:45:50 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 38
INFO - 2016-10-11 17:45:50 --> Database Driver Class Initialized
DEBUG - 2016-10-11 17:45:50 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_pinjaman.php
ERROR - 2016-10-11 17:45:50 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 41
INFO - 2016-10-11 17:45:50 --> Database Driver Class Initialized
DEBUG - 2016-10-11 17:45:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_tabungan.php
DEBUG - 2016-10-11 17:45:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/profile_anggota.php
DEBUG - 2016-10-11 17:45:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-11 17:45:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-11 17:45:51 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:51 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:51 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:51 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:51 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:51 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:51 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:52 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:52 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:52 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:52 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:52 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:52 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:52 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:52 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:52 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:52 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:52 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:52 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:52 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:52 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:53 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:53 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:53 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:53 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:53 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:53 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:53 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:53 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:53 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:53 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:53 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:53 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:53 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:53 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:53 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:53 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:53 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:53 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:53 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:53 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:53 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:53 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:53 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:54 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:54 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:54 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:54 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:54 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:54 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:54 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:54 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:54 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:54 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:54 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:54 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:54 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:54 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:54 --> Database Driver Class Initialized
INFO - 2016-10-11 17:45:54 --> Database Driver Class Initialized
DEBUG - 2016-10-11 17:45:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-11 17:45:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-11 17:45:55 --> Final output sent to browser
DEBUG - 2016-10-11 17:45:55 --> Total execution time: 6.6542
INFO - 2016-10-11 17:47:03 --> Config Class Initialized
INFO - 2016-10-11 17:47:03 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:47:03 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:47:03 --> Utf8 Class Initialized
INFO - 2016-10-11 17:47:03 --> URI Class Initialized
INFO - 2016-10-11 17:47:03 --> Router Class Initialized
INFO - 2016-10-11 17:47:03 --> Output Class Initialized
INFO - 2016-10-11 17:47:03 --> Security Class Initialized
DEBUG - 2016-10-11 17:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:47:03 --> Input Class Initialized
INFO - 2016-10-11 17:47:03 --> Language Class Initialized
INFO - 2016-10-11 17:47:03 --> Language Class Initialized
INFO - 2016-10-11 17:47:03 --> Config Class Initialized
INFO - 2016-10-11 17:47:03 --> Loader Class Initialized
INFO - 2016-10-11 17:47:03 --> Helper loaded: url_helper
INFO - 2016-10-11 17:47:03 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:47:03 --> Controller Class Initialized
DEBUG - 2016-10-11 17:47:03 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:47:03 --> Model Class Initialized
INFO - 2016-10-11 17:47:03 --> Model Class Initialized
ERROR - 2016-10-11 17:47:03 --> Unable to delete cache file for admin/index/data/anggota
DEBUG - 2016-10-11 17:47:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-11 17:47:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-11 17:47:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-11 17:47:03 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-11 17:47:03 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-11 17:47:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-11 17:47:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-11 17:47:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-11 17:47:03 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:04 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:05 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:05 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:05 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:05 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:05 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:05 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:05 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:05 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:05 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:05 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:05 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:05 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:05 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:05 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:05 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:05 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:05 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:05 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:05 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:05 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:05 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:05 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:05 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:05 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:05 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:05 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:05 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:05 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:06 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:06 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:06 --> Database Driver Class Initialized
DEBUG - 2016-10-11 17:47:06 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-11 17:47:06 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-11 17:47:06 --> Final output sent to browser
DEBUG - 2016-10-11 17:47:06 --> Total execution time: 3.2025
INFO - 2016-10-11 17:47:15 --> Config Class Initialized
INFO - 2016-10-11 17:47:15 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:47:15 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:47:15 --> Utf8 Class Initialized
INFO - 2016-10-11 17:47:15 --> URI Class Initialized
INFO - 2016-10-11 17:47:15 --> Router Class Initialized
INFO - 2016-10-11 17:47:15 --> Output Class Initialized
INFO - 2016-10-11 17:47:15 --> Security Class Initialized
DEBUG - 2016-10-11 17:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:47:15 --> Input Class Initialized
INFO - 2016-10-11 17:47:15 --> Language Class Initialized
INFO - 2016-10-11 17:47:15 --> Language Class Initialized
INFO - 2016-10-11 17:47:15 --> Config Class Initialized
INFO - 2016-10-11 17:47:16 --> Loader Class Initialized
INFO - 2016-10-11 17:47:16 --> Helper loaded: url_helper
INFO - 2016-10-11 17:47:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:47:16 --> Controller Class Initialized
DEBUG - 2016-10-11 17:47:16 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:47:16 --> Model Class Initialized
INFO - 2016-10-11 17:47:16 --> Model Class Initialized
ERROR - 2016-10-11 17:47:16 --> Unable to delete cache file for admin/index/data/anggota/karyawan
DEBUG - 2016-10-11 17:47:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-11 17:47:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-11 17:47:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-11 17:47:16 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-11 17:47:16 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-11 17:47:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-11 17:47:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-11 17:47:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-11 17:47:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:16 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:17 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:17 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:17 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:17 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:17 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:17 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:17 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:17 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:17 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:17 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:17 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:17 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:17 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:17 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:17 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:17 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:17 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:17 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:17 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:17 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:17 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:17 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:17 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:17 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:18 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:18 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:18 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:18 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:18 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:18 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:18 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:18 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:18 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:18 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:18 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:18 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:18 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:18 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:18 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:18 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:18 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:18 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:19 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:19 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:19 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:19 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:19 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:19 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:19 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:19 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:19 --> Database Driver Class Initialized
DEBUG - 2016-10-11 17:47:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-11 17:47:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-11 17:47:19 --> Final output sent to browser
DEBUG - 2016-10-11 17:47:19 --> Total execution time: 3.9906
INFO - 2016-10-11 17:47:22 --> Config Class Initialized
INFO - 2016-10-11 17:47:22 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:47:23 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:47:23 --> Utf8 Class Initialized
INFO - 2016-10-11 17:47:23 --> URI Class Initialized
INFO - 2016-10-11 17:47:23 --> Router Class Initialized
INFO - 2016-10-11 17:47:23 --> Output Class Initialized
INFO - 2016-10-11 17:47:23 --> Security Class Initialized
DEBUG - 2016-10-11 17:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:47:23 --> Input Class Initialized
INFO - 2016-10-11 17:47:23 --> Language Class Initialized
INFO - 2016-10-11 17:47:23 --> Language Class Initialized
INFO - 2016-10-11 17:47:23 --> Config Class Initialized
INFO - 2016-10-11 17:47:23 --> Loader Class Initialized
INFO - 2016-10-11 17:47:23 --> Helper loaded: url_helper
INFO - 2016-10-11 17:47:23 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:47:23 --> Controller Class Initialized
DEBUG - 2016-10-11 17:47:23 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:47:24 --> Model Class Initialized
INFO - 2016-10-11 17:47:24 --> Model Class Initialized
ERROR - 2016-10-11 17:47:24 --> Unable to delete cache file for admin/index/data/anggota/umum
DEBUG - 2016-10-11 17:47:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-11 17:47:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-11 17:47:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-11 17:47:24 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-11 17:47:24 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-11 17:47:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-11 17:47:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-11 17:47:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-11 17:47:24 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:24 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:24 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:24 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:24 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:24 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:24 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:24 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:24 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:25 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:25 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:25 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:25 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:25 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:25 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:25 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:25 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:25 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:25 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:25 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:25 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:25 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:25 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:25 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:25 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:25 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:25 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:26 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:27 --> Database Driver Class Initialized
INFO - 2016-10-11 17:47:27 --> Database Driver Class Initialized
DEBUG - 2016-10-11 17:47:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-11 17:47:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-11 17:47:27 --> Final output sent to browser
DEBUG - 2016-10-11 17:47:28 --> Total execution time: 5.0114
INFO - 2016-10-11 17:48:06 --> Config Class Initialized
INFO - 2016-10-11 17:48:06 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:48:06 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:48:06 --> Utf8 Class Initialized
INFO - 2016-10-11 17:48:06 --> URI Class Initialized
INFO - 2016-10-11 17:48:07 --> Router Class Initialized
INFO - 2016-10-11 17:48:07 --> Output Class Initialized
INFO - 2016-10-11 17:48:07 --> Security Class Initialized
DEBUG - 2016-10-11 17:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:48:07 --> Input Class Initialized
INFO - 2016-10-11 17:48:07 --> Language Class Initialized
INFO - 2016-10-11 17:48:07 --> Language Class Initialized
INFO - 2016-10-11 17:48:07 --> Config Class Initialized
INFO - 2016-10-11 17:48:07 --> Loader Class Initialized
INFO - 2016-10-11 17:48:07 --> Helper loaded: url_helper
INFO - 2016-10-11 17:48:07 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:48:07 --> Controller Class Initialized
DEBUG - 2016-10-11 17:48:07 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:48:07 --> Model Class Initialized
INFO - 2016-10-11 17:48:07 --> Model Class Initialized
ERROR - 2016-10-11 17:48:07 --> Unable to delete cache file for admin/index/getDetailNasabah
INFO - 2016-10-11 17:48:07 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:07 --> Final output sent to browser
DEBUG - 2016-10-11 17:48:07 --> Total execution time: 0.7159
INFO - 2016-10-11 17:48:10 --> Config Class Initialized
INFO - 2016-10-11 17:48:10 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:48:10 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:48:10 --> Utf8 Class Initialized
INFO - 2016-10-11 17:48:10 --> URI Class Initialized
INFO - 2016-10-11 17:48:10 --> Router Class Initialized
INFO - 2016-10-11 17:48:10 --> Output Class Initialized
INFO - 2016-10-11 17:48:10 --> Security Class Initialized
DEBUG - 2016-10-11 17:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:48:10 --> Input Class Initialized
INFO - 2016-10-11 17:48:11 --> Language Class Initialized
INFO - 2016-10-11 17:48:11 --> Language Class Initialized
INFO - 2016-10-11 17:48:11 --> Config Class Initialized
INFO - 2016-10-11 17:48:11 --> Loader Class Initialized
INFO - 2016-10-11 17:48:11 --> Helper loaded: url_helper
INFO - 2016-10-11 17:48:11 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:48:11 --> Controller Class Initialized
DEBUG - 2016-10-11 17:48:11 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:48:11 --> Model Class Initialized
INFO - 2016-10-11 17:48:11 --> Model Class Initialized
ERROR - 2016-10-11 17:48:11 --> Unable to delete cache file for admin/index/form_simpan_tabungan/902ba3cda1883801594b6e1b452790cc53948fda
INFO - 2016-10-11 17:48:11 --> Database Driver Class Initialized
DEBUG - 2016-10-11 17:48:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-11 17:48:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-11 17:48:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-11 17:48:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_simpan_tabungan.php
DEBUG - 2016-10-11 17:48:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-11 17:48:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-11 17:48:11 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:11 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:11 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:11 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:11 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:11 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:11 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:11 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:11 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:11 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:11 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:12 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:12 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:12 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:12 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:12 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:12 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:12 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:12 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:12 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:12 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:12 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:12 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:12 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:12 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:12 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:12 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:12 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:12 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:12 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:12 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:12 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:12 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:12 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:12 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:12 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:12 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:12 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:13 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:13 --> Database Driver Class Initialized
DEBUG - 2016-10-11 17:48:13 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-11 17:48:13 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-11 17:48:13 --> Final output sent to browser
DEBUG - 2016-10-11 17:48:13 --> Total execution time: 3.1401
INFO - 2016-10-11 17:48:23 --> Config Class Initialized
INFO - 2016-10-11 17:48:23 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:48:23 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:48:24 --> Utf8 Class Initialized
INFO - 2016-10-11 17:48:24 --> URI Class Initialized
INFO - 2016-10-11 17:48:24 --> Router Class Initialized
INFO - 2016-10-11 17:48:24 --> Output Class Initialized
INFO - 2016-10-11 17:48:24 --> Security Class Initialized
DEBUG - 2016-10-11 17:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:48:24 --> Input Class Initialized
INFO - 2016-10-11 17:48:24 --> Language Class Initialized
INFO - 2016-10-11 17:48:24 --> Language Class Initialized
INFO - 2016-10-11 17:48:24 --> Config Class Initialized
INFO - 2016-10-11 17:48:24 --> Loader Class Initialized
INFO - 2016-10-11 17:48:24 --> Helper loaded: url_helper
INFO - 2016-10-11 17:48:24 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:48:24 --> Controller Class Initialized
DEBUG - 2016-10-11 17:48:24 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:48:24 --> Model Class Initialized
INFO - 2016-10-11 17:48:24 --> Model Class Initialized
ERROR - 2016-10-11 17:48:24 --> Unable to delete cache file for admin/index/simpan_tabungan
INFO - 2016-10-11 17:48:24 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:24 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:24 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:24 --> Final output sent to browser
DEBUG - 2016-10-11 17:48:24 --> Total execution time: 1.0349
INFO - 2016-10-11 17:48:37 --> Config Class Initialized
INFO - 2016-10-11 17:48:37 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:48:37 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:48:37 --> Utf8 Class Initialized
INFO - 2016-10-11 17:48:37 --> URI Class Initialized
INFO - 2016-10-11 17:48:37 --> Router Class Initialized
INFO - 2016-10-11 17:48:38 --> Output Class Initialized
INFO - 2016-10-11 17:48:38 --> Security Class Initialized
DEBUG - 2016-10-11 17:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:48:38 --> Input Class Initialized
INFO - 2016-10-11 17:48:38 --> Language Class Initialized
INFO - 2016-10-11 17:48:38 --> Language Class Initialized
INFO - 2016-10-11 17:48:38 --> Config Class Initialized
INFO - 2016-10-11 17:48:38 --> Loader Class Initialized
INFO - 2016-10-11 17:48:38 --> Helper loaded: url_helper
INFO - 2016-10-11 17:48:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:48:38 --> Controller Class Initialized
DEBUG - 2016-10-11 17:48:38 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:48:38 --> Model Class Initialized
INFO - 2016-10-11 17:48:38 --> Model Class Initialized
ERROR - 2016-10-11 17:48:38 --> Unable to delete cache file for admin/index/tabungan
DEBUG - 2016-10-11 17:48:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-11 17:48:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-11 17:48:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
INFO - 2016-10-11 17:48:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:38 --> Database Driver Class Initialized
DEBUG - 2016-10-11 17:48:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_nasabah_tabungan.php
DEBUG - 2016-10-11 17:48:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_tabungan.php
DEBUG - 2016-10-11 17:48:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-11 17:48:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-11 17:48:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:38 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:39 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:40 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:41 --> Database Driver Class Initialized
DEBUG - 2016-10-11 17:48:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-11 17:48:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-11 17:48:41 --> Final output sent to browser
DEBUG - 2016-10-11 17:48:41 --> Total execution time: 3.2824
INFO - 2016-10-11 17:48:46 --> Config Class Initialized
INFO - 2016-10-11 17:48:46 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:48:46 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:48:46 --> Utf8 Class Initialized
INFO - 2016-10-11 17:48:46 --> URI Class Initialized
INFO - 2016-10-11 17:48:46 --> Router Class Initialized
INFO - 2016-10-11 17:48:46 --> Output Class Initialized
INFO - 2016-10-11 17:48:46 --> Security Class Initialized
DEBUG - 2016-10-11 17:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:48:46 --> Input Class Initialized
INFO - 2016-10-11 17:48:46 --> Language Class Initialized
INFO - 2016-10-11 17:48:46 --> Language Class Initialized
INFO - 2016-10-11 17:48:46 --> Config Class Initialized
INFO - 2016-10-11 17:48:46 --> Loader Class Initialized
INFO - 2016-10-11 17:48:46 --> Helper loaded: url_helper
INFO - 2016-10-11 17:48:46 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:48:47 --> Controller Class Initialized
DEBUG - 2016-10-11 17:48:47 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:48:47 --> Model Class Initialized
INFO - 2016-10-11 17:48:47 --> Model Class Initialized
ERROR - 2016-10-11 17:48:47 --> Unable to delete cache file for admin/index/do_bunga_tabungan
INFO - 2016-10-11 17:48:47 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:47 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:47 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:47 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:47 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:47 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:47 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:47 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:47 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:47 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:48 --> Final output sent to browser
DEBUG - 2016-10-11 17:48:48 --> Total execution time: 1.7083
INFO - 2016-10-11 17:48:53 --> Config Class Initialized
INFO - 2016-10-11 17:48:53 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:48:53 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:48:53 --> Utf8 Class Initialized
INFO - 2016-10-11 17:48:53 --> URI Class Initialized
INFO - 2016-10-11 17:48:53 --> Router Class Initialized
INFO - 2016-10-11 17:48:53 --> Output Class Initialized
INFO - 2016-10-11 17:48:53 --> Security Class Initialized
DEBUG - 2016-10-11 17:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:48:53 --> Input Class Initialized
INFO - 2016-10-11 17:48:53 --> Language Class Initialized
INFO - 2016-10-11 17:48:53 --> Language Class Initialized
INFO - 2016-10-11 17:48:53 --> Config Class Initialized
INFO - 2016-10-11 17:48:53 --> Loader Class Initialized
INFO - 2016-10-11 17:48:53 --> Helper loaded: url_helper
INFO - 2016-10-11 17:48:53 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:48:53 --> Controller Class Initialized
DEBUG - 2016-10-11 17:48:53 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:48:54 --> Model Class Initialized
INFO - 2016-10-11 17:48:54 --> Model Class Initialized
ERROR - 2016-10-11 17:48:54 --> Unable to delete cache file for admin/index/tabungan
DEBUG - 2016-10-11 17:48:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-11 17:48:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-11 17:48:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
INFO - 2016-10-11 17:48:54 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:54 --> Database Driver Class Initialized
DEBUG - 2016-10-11 17:48:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_nasabah_tabungan.php
DEBUG - 2016-10-11 17:48:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_tabungan.php
DEBUG - 2016-10-11 17:48:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-11 17:48:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-11 17:48:54 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:54 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:54 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:54 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:54 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:54 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:54 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:54 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:54 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:54 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:54 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:54 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:54 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:55 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:55 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:55 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:55 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:55 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:55 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:55 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:55 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:55 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:55 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:55 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:55 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:55 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:55 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:55 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:55 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:55 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:55 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:55 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:55 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:56 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:56 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:56 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:56 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:56 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:56 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:56 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:56 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:56 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:56 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:56 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:56 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:56 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:56 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:56 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:56 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:56 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:56 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:56 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:56 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:56 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:56 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:56 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:56 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:56 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:56 --> Database Driver Class Initialized
INFO - 2016-10-11 17:48:57 --> Database Driver Class Initialized
DEBUG - 2016-10-11 17:48:57 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-11 17:48:57 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-11 17:48:57 --> Final output sent to browser
DEBUG - 2016-10-11 17:48:57 --> Total execution time: 3.7445
INFO - 2016-10-11 17:49:31 --> Config Class Initialized
INFO - 2016-10-11 17:49:31 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:49:31 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:49:31 --> Utf8 Class Initialized
INFO - 2016-10-11 17:49:31 --> URI Class Initialized
INFO - 2016-10-11 17:49:31 --> Router Class Initialized
INFO - 2016-10-11 17:49:31 --> Output Class Initialized
INFO - 2016-10-11 17:49:31 --> Security Class Initialized
DEBUG - 2016-10-11 17:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:49:31 --> Input Class Initialized
INFO - 2016-10-11 17:49:31 --> Language Class Initialized
INFO - 2016-10-11 17:49:31 --> Language Class Initialized
INFO - 2016-10-11 17:49:31 --> Config Class Initialized
INFO - 2016-10-11 17:49:31 --> Loader Class Initialized
INFO - 2016-10-11 17:49:31 --> Helper loaded: url_helper
INFO - 2016-10-11 17:49:31 --> Database Driver Class Initialized
INFO - 2016-10-11 17:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:49:31 --> Controller Class Initialized
DEBUG - 2016-10-11 17:49:31 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:49:31 --> Model Class Initialized
INFO - 2016-10-11 17:49:31 --> Model Class Initialized
ERROR - 2016-10-11 17:49:31 --> Unable to delete cache file for admin/index/do_laporan_buku_besar
DEBUG - 2016-10-11 17:49:31 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_buku_besar.php
INFO - 2016-10-11 17:49:31 --> Final output sent to browser
DEBUG - 2016-10-11 17:49:31 --> Total execution time: 0.7194
INFO - 2016-10-11 17:50:08 --> Config Class Initialized
INFO - 2016-10-11 17:50:08 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:50:08 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:50:08 --> Utf8 Class Initialized
INFO - 2016-10-11 17:50:08 --> URI Class Initialized
INFO - 2016-10-11 17:50:08 --> Router Class Initialized
INFO - 2016-10-11 17:50:08 --> Output Class Initialized
INFO - 2016-10-11 17:50:08 --> Security Class Initialized
DEBUG - 2016-10-11 17:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:50:08 --> Input Class Initialized
INFO - 2016-10-11 17:50:08 --> Language Class Initialized
INFO - 2016-10-11 17:50:08 --> Language Class Initialized
INFO - 2016-10-11 17:50:08 --> Config Class Initialized
INFO - 2016-10-11 17:50:08 --> Loader Class Initialized
INFO - 2016-10-11 17:50:08 --> Helper loaded: url_helper
INFO - 2016-10-11 17:50:08 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:50:08 --> Controller Class Initialized
DEBUG - 2016-10-11 17:50:08 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:50:08 --> Model Class Initialized
INFO - 2016-10-11 17:50:08 --> Model Class Initialized
ERROR - 2016-10-11 17:50:08 --> Unable to delete cache file for admin/index/laporan_jurnal
DEBUG - 2016-10-11 17:50:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-11 17:50:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-11 17:50:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-11 17:50:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/jurnal_umum.php
DEBUG - 2016-10-11 17:50:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-11 17:50:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-11 17:50:08 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:09 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:09 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:09 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:09 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:09 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:09 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:09 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:09 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:09 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:09 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:09 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:09 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:09 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:09 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:09 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:09 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:09 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:09 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:09 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:09 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:09 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:09 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:09 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:09 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:09 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:09 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:09 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:10 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:10 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:10 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:10 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:10 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:10 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:10 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:10 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:10 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:10 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:10 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:10 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:10 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:10 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:10 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:10 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:10 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:10 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:10 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:10 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:10 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:10 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:10 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:10 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:10 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:10 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:10 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:10 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:11 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:11 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:11 --> Database Driver Class Initialized
DEBUG - 2016-10-11 17:50:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-11 17:50:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-11 17:50:11 --> Final output sent to browser
DEBUG - 2016-10-11 17:50:11 --> Total execution time: 3.2071
INFO - 2016-10-11 17:50:20 --> Config Class Initialized
INFO - 2016-10-11 17:50:20 --> Hooks Class Initialized
DEBUG - 2016-10-11 17:50:20 --> UTF-8 Support Enabled
INFO - 2016-10-11 17:50:20 --> Utf8 Class Initialized
INFO - 2016-10-11 17:50:20 --> URI Class Initialized
INFO - 2016-10-11 17:50:20 --> Router Class Initialized
INFO - 2016-10-11 17:50:20 --> Output Class Initialized
INFO - 2016-10-11 17:50:20 --> Security Class Initialized
DEBUG - 2016-10-11 17:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 17:50:20 --> Input Class Initialized
INFO - 2016-10-11 17:50:20 --> Language Class Initialized
INFO - 2016-10-11 17:50:20 --> Language Class Initialized
INFO - 2016-10-11 17:50:20 --> Config Class Initialized
INFO - 2016-10-11 17:50:21 --> Loader Class Initialized
INFO - 2016-10-11 17:50:21 --> Helper loaded: url_helper
INFO - 2016-10-11 17:50:21 --> Database Driver Class Initialized
INFO - 2016-10-11 17:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 17:50:21 --> Controller Class Initialized
DEBUG - 2016-10-11 17:50:21 --> Index MX_Controller Initialized
INFO - 2016-10-11 17:50:21 --> Model Class Initialized
INFO - 2016-10-11 17:50:21 --> Model Class Initialized
ERROR - 2016-10-11 17:50:21 --> Unable to delete cache file for admin/index/do_laporan_jurnal
DEBUG - 2016-10-11 17:50:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_jurnal_umum.php
INFO - 2016-10-11 17:50:21 --> Final output sent to browser
DEBUG - 2016-10-11 17:50:21 --> Total execution time: 0.9572
INFO - 2016-10-11 18:09:16 --> Config Class Initialized
INFO - 2016-10-11 18:09:16 --> Hooks Class Initialized
DEBUG - 2016-10-11 18:09:16 --> UTF-8 Support Enabled
INFO - 2016-10-11 18:09:16 --> Utf8 Class Initialized
INFO - 2016-10-11 18:09:16 --> URI Class Initialized
INFO - 2016-10-11 18:09:16 --> Router Class Initialized
INFO - 2016-10-11 18:09:16 --> Output Class Initialized
INFO - 2016-10-11 18:09:16 --> Security Class Initialized
DEBUG - 2016-10-11 18:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 18:09:16 --> Input Class Initialized
INFO - 2016-10-11 18:09:16 --> Language Class Initialized
INFO - 2016-10-11 18:09:16 --> Language Class Initialized
INFO - 2016-10-11 18:09:16 --> Config Class Initialized
INFO - 2016-10-11 18:09:16 --> Loader Class Initialized
INFO - 2016-10-11 18:09:16 --> Helper loaded: url_helper
INFO - 2016-10-11 18:09:16 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 18:09:16 --> Controller Class Initialized
DEBUG - 2016-10-11 18:09:16 --> Index MX_Controller Initialized
INFO - 2016-10-11 18:09:16 --> Model Class Initialized
INFO - 2016-10-11 18:09:16 --> Model Class Initialized
ERROR - 2016-10-11 18:09:16 --> Unable to delete cache file for admin/index/data/anggota/karyawan
DEBUG - 2016-10-11 18:09:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-11 18:09:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-11 18:09:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-11 18:09:17 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-11 18:09:17 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-11 18:09:17 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-11 18:09:17 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-11 18:09:17 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-11 18:09:17 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:17 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:17 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:17 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:17 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:17 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:17 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:17 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:17 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:17 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:17 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:17 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:17 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:17 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:17 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:17 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:17 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:17 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:17 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:17 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:17 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:17 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:17 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:18 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:18 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:18 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:18 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:18 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:18 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:18 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:18 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:18 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:18 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:18 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:18 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:18 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:18 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:18 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:18 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:18 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:18 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:18 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:18 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:18 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:18 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:18 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:18 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:18 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:18 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:19 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:19 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:19 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:19 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:19 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:19 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:19 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:19 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:19 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:19 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:19 --> Database Driver Class Initialized
DEBUG - 2016-10-11 18:09:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-11 18:09:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-11 18:09:19 --> Final output sent to browser
DEBUG - 2016-10-11 18:09:19 --> Total execution time: 3.2801
INFO - 2016-10-11 18:09:25 --> Config Class Initialized
INFO - 2016-10-11 18:09:25 --> Hooks Class Initialized
DEBUG - 2016-10-11 18:09:25 --> UTF-8 Support Enabled
INFO - 2016-10-11 18:09:25 --> Utf8 Class Initialized
INFO - 2016-10-11 18:09:25 --> URI Class Initialized
INFO - 2016-10-11 18:09:25 --> Router Class Initialized
INFO - 2016-10-11 18:09:25 --> Output Class Initialized
INFO - 2016-10-11 18:09:25 --> Security Class Initialized
DEBUG - 2016-10-11 18:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 18:09:25 --> Input Class Initialized
INFO - 2016-10-11 18:09:25 --> Language Class Initialized
INFO - 2016-10-11 18:09:25 --> Language Class Initialized
INFO - 2016-10-11 18:09:25 --> Config Class Initialized
INFO - 2016-10-11 18:09:26 --> Loader Class Initialized
INFO - 2016-10-11 18:09:26 --> Helper loaded: url_helper
INFO - 2016-10-11 18:09:26 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 18:09:26 --> Controller Class Initialized
DEBUG - 2016-10-11 18:09:26 --> Index MX_Controller Initialized
INFO - 2016-10-11 18:09:26 --> Model Class Initialized
INFO - 2016-10-11 18:09:26 --> Model Class Initialized
ERROR - 2016-10-11 18:09:26 --> Unable to delete cache file for admin/index/detail_anggota/356a192b7913b04c54574d18c28d46e6395428ab
DEBUG - 2016-10-11 18:09:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-11 18:09:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-11 18:09:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
INFO - 2016-10-11 18:09:26 --> Database Driver Class Initialized
DEBUG - 2016-10-11 18:09:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_pinjaman.php
INFO - 2016-10-11 18:09:26 --> Database Driver Class Initialized
DEBUG - 2016-10-11 18:09:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_tabungan.php
DEBUG - 2016-10-11 18:09:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/profile_anggota.php
DEBUG - 2016-10-11 18:09:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-11 18:09:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-11 18:09:26 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:26 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:26 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:26 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:26 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:26 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:26 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:26 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:26 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:27 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:27 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:27 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:27 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:27 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:27 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:27 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:27 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:27 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:27 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:27 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:27 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:27 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:27 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:27 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:27 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:27 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:27 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:27 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:27 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:27 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:27 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:27 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:27 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:27 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:27 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:28 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:28 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:28 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:28 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:28 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:28 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:28 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:28 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:28 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:28 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:28 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:28 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:28 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:28 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:28 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:28 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:28 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:28 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:28 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:28 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:28 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:28 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:28 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:28 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:28 --> Database Driver Class Initialized
DEBUG - 2016-10-11 18:09:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-11 18:09:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-11 18:09:29 --> Final output sent to browser
DEBUG - 2016-10-11 18:09:29 --> Total execution time: 3.4979
INFO - 2016-10-11 18:09:29 --> Config Class Initialized
INFO - 2016-10-11 18:09:29 --> Hooks Class Initialized
DEBUG - 2016-10-11 18:09:29 --> UTF-8 Support Enabled
INFO - 2016-10-11 18:09:29 --> Utf8 Class Initialized
INFO - 2016-10-11 18:09:29 --> URI Class Initialized
INFO - 2016-10-11 18:09:29 --> Router Class Initialized
INFO - 2016-10-11 18:09:29 --> Output Class Initialized
INFO - 2016-10-11 18:09:29 --> Security Class Initialized
DEBUG - 2016-10-11 18:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 18:09:29 --> Input Class Initialized
INFO - 2016-10-11 18:09:29 --> Language Class Initialized
INFO - 2016-10-11 18:09:29 --> Language Class Initialized
INFO - 2016-10-11 18:09:29 --> Config Class Initialized
INFO - 2016-10-11 18:09:29 --> Loader Class Initialized
INFO - 2016-10-11 18:09:29 --> Helper loaded: url_helper
INFO - 2016-10-11 18:09:29 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 18:09:30 --> Controller Class Initialized
DEBUG - 2016-10-11 18:09:30 --> Index MX_Controller Initialized
INFO - 2016-10-11 18:09:30 --> Model Class Initialized
INFO - 2016-10-11 18:09:30 --> Model Class Initialized
ERROR - 2016-10-11 18:09:30 --> Unable to delete cache file for admin/index/detail_anggota/images/picture.jpg
DEBUG - 2016-10-11 18:09:30 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-11 18:09:30 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-11 18:09:30 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
ERROR - 2016-10-11 18:09:30 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 16
ERROR - 2016-10-11 18:09:30 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 19
ERROR - 2016-10-11 18:09:30 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 22
ERROR - 2016-10-11 18:09:30 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 38
INFO - 2016-10-11 18:09:30 --> Database Driver Class Initialized
DEBUG - 2016-10-11 18:09:31 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_pinjaman.php
ERROR - 2016-10-11 18:09:31 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 41
INFO - 2016-10-11 18:09:31 --> Database Driver Class Initialized
DEBUG - 2016-10-11 18:09:31 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_tabungan.php
DEBUG - 2016-10-11 18:09:31 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/profile_anggota.php
DEBUG - 2016-10-11 18:09:31 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-11 18:09:31 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-11 18:09:31 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:32 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:32 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:32 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:32 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:32 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:32 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:32 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:32 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:33 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:33 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:33 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:33 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:33 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:33 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:33 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:33 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:33 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:33 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:33 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:33 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:33 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:33 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:33 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:33 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:34 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:34 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:34 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:34 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:34 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:34 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:34 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:34 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:34 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:34 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:34 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:34 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:34 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:35 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:35 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:35 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:35 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:35 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:35 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:35 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:35 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:35 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:35 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:35 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:35 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:35 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:35 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:35 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:36 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:36 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:36 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:36 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:36 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:36 --> Database Driver Class Initialized
INFO - 2016-10-11 18:09:36 --> Database Driver Class Initialized
DEBUG - 2016-10-11 18:09:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-11 18:09:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-11 18:09:36 --> Final output sent to browser
DEBUG - 2016-10-11 18:09:36 --> Total execution time: 7.4016
INFO - 2016-10-11 18:10:11 --> Config Class Initialized
INFO - 2016-10-11 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-10-11 18:10:11 --> UTF-8 Support Enabled
INFO - 2016-10-11 18:10:11 --> Utf8 Class Initialized
INFO - 2016-10-11 18:10:11 --> URI Class Initialized
INFO - 2016-10-11 18:10:11 --> Router Class Initialized
INFO - 2016-10-11 18:10:11 --> Output Class Initialized
INFO - 2016-10-11 18:10:11 --> Security Class Initialized
DEBUG - 2016-10-11 18:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 18:10:11 --> Input Class Initialized
INFO - 2016-10-11 18:10:11 --> Language Class Initialized
INFO - 2016-10-11 18:10:12 --> Language Class Initialized
INFO - 2016-10-11 18:10:12 --> Config Class Initialized
INFO - 2016-10-11 18:10:12 --> Loader Class Initialized
INFO - 2016-10-11 18:10:12 --> Helper loaded: url_helper
INFO - 2016-10-11 18:10:12 --> Database Driver Class Initialized
INFO - 2016-10-11 18:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 18:10:12 --> Controller Class Initialized
DEBUG - 2016-10-11 18:10:12 --> Index MX_Controller Initialized
INFO - 2016-10-11 18:10:12 --> Model Class Initialized
INFO - 2016-10-11 18:10:12 --> Model Class Initialized
ERROR - 2016-10-11 18:10:12 --> Unable to delete cache file for admin/index/getRaportAngsuran/ca3512f4dfa95a03169c5a670a4c91a19b3077b4
DEBUG - 2016-10-11 18:10:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/raport_angsuran.php
INFO - 2016-10-11 18:10:12 --> Final output sent to browser
DEBUG - 2016-10-11 18:10:12 --> Total execution time: 1.0316
INFO - 2016-10-11 18:10:25 --> Config Class Initialized
INFO - 2016-10-11 18:10:25 --> Hooks Class Initialized
DEBUG - 2016-10-11 18:10:25 --> UTF-8 Support Enabled
INFO - 2016-10-11 18:10:25 --> Utf8 Class Initialized
INFO - 2016-10-11 18:10:25 --> URI Class Initialized
INFO - 2016-10-11 18:10:25 --> Router Class Initialized
INFO - 2016-10-11 18:10:25 --> Output Class Initialized
INFO - 2016-10-11 18:10:25 --> Security Class Initialized
DEBUG - 2016-10-11 18:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 18:10:25 --> Input Class Initialized
INFO - 2016-10-11 18:10:25 --> Language Class Initialized
INFO - 2016-10-11 18:10:26 --> Language Class Initialized
INFO - 2016-10-11 18:10:26 --> Config Class Initialized
INFO - 2016-10-11 18:10:26 --> Loader Class Initialized
INFO - 2016-10-11 18:10:26 --> Helper loaded: url_helper
INFO - 2016-10-11 18:10:26 --> Database Driver Class Initialized
INFO - 2016-10-11 18:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 18:10:26 --> Controller Class Initialized
DEBUG - 2016-10-11 18:10:26 --> Index MX_Controller Initialized
INFO - 2016-10-11 18:10:26 --> Model Class Initialized
INFO - 2016-10-11 18:10:26 --> Model Class Initialized
ERROR - 2016-10-11 18:10:26 --> Unable to delete cache file for admin/index/getRaportAngsuran/ca3512f4dfa95a03169c5a670a4c91a19b3077b4
DEBUG - 2016-10-11 18:10:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/raport_angsuran.php
INFO - 2016-10-11 18:10:26 --> Final output sent to browser
DEBUG - 2016-10-11 18:10:26 --> Total execution time: 1.0434
INFO - 2016-10-11 18:11:06 --> Config Class Initialized
INFO - 2016-10-11 18:11:06 --> Hooks Class Initialized
DEBUG - 2016-10-11 18:11:06 --> UTF-8 Support Enabled
INFO - 2016-10-11 18:11:06 --> Utf8 Class Initialized
INFO - 2016-10-11 18:11:06 --> URI Class Initialized
INFO - 2016-10-11 18:11:06 --> Router Class Initialized
INFO - 2016-10-11 18:11:06 --> Output Class Initialized
INFO - 2016-10-11 18:11:06 --> Security Class Initialized
DEBUG - 2016-10-11 18:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 18:11:06 --> Input Class Initialized
INFO - 2016-10-11 18:11:06 --> Language Class Initialized
INFO - 2016-10-11 18:11:06 --> Language Class Initialized
INFO - 2016-10-11 18:11:06 --> Config Class Initialized
INFO - 2016-10-11 18:11:07 --> Loader Class Initialized
INFO - 2016-10-11 18:11:07 --> Helper loaded: url_helper
INFO - 2016-10-11 18:11:07 --> Database Driver Class Initialized
INFO - 2016-10-11 18:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 18:11:07 --> Controller Class Initialized
DEBUG - 2016-10-11 18:11:07 --> Index MX_Controller Initialized
INFO - 2016-10-11 18:11:07 --> Model Class Initialized
INFO - 2016-10-11 18:11:07 --> Model Class Initialized
ERROR - 2016-10-11 18:11:07 --> Unable to delete cache file for admin/index/getRaportAngsuran/ca3512f4dfa95a03169c5a670a4c91a19b3077b4
DEBUG - 2016-10-11 18:11:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/raport_angsuran.php
INFO - 2016-10-11 18:11:07 --> Final output sent to browser
DEBUG - 2016-10-11 18:11:07 --> Total execution time: 1.0612
INFO - 2016-10-11 18:15:16 --> Config Class Initialized
INFO - 2016-10-11 18:15:16 --> Hooks Class Initialized
DEBUG - 2016-10-11 18:15:16 --> UTF-8 Support Enabled
INFO - 2016-10-11 18:15:16 --> Utf8 Class Initialized
INFO - 2016-10-11 18:15:16 --> URI Class Initialized
INFO - 2016-10-11 18:15:16 --> Router Class Initialized
INFO - 2016-10-11 18:15:16 --> Output Class Initialized
INFO - 2016-10-11 18:15:16 --> Security Class Initialized
DEBUG - 2016-10-11 18:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 18:15:16 --> Input Class Initialized
INFO - 2016-10-11 18:15:16 --> Language Class Initialized
INFO - 2016-10-11 18:15:16 --> Language Class Initialized
INFO - 2016-10-11 18:15:16 --> Config Class Initialized
INFO - 2016-10-11 18:15:16 --> Loader Class Initialized
INFO - 2016-10-11 18:15:16 --> Helper loaded: url_helper
INFO - 2016-10-11 18:15:16 --> Database Driver Class Initialized
INFO - 2016-10-11 18:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 18:15:17 --> Controller Class Initialized
DEBUG - 2016-10-11 18:15:17 --> Index MX_Controller Initialized
INFO - 2016-10-11 18:15:17 --> Model Class Initialized
INFO - 2016-10-11 18:15:17 --> Model Class Initialized
ERROR - 2016-10-11 18:15:17 --> Unable to delete cache file for admin/index/getRaportAngsuran/ca3512f4dfa95a03169c5a670a4c91a19b3077b4
DEBUG - 2016-10-11 18:15:17 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/raport_angsuran.php
INFO - 2016-10-11 18:15:17 --> Final output sent to browser
DEBUG - 2016-10-11 18:15:17 --> Total execution time: 1.1890
INFO - 2016-10-11 18:16:41 --> Config Class Initialized
INFO - 2016-10-11 18:16:41 --> Hooks Class Initialized
DEBUG - 2016-10-11 18:16:41 --> UTF-8 Support Enabled
INFO - 2016-10-11 18:16:41 --> Utf8 Class Initialized
INFO - 2016-10-11 18:16:41 --> URI Class Initialized
INFO - 2016-10-11 18:16:41 --> Router Class Initialized
INFO - 2016-10-11 18:16:41 --> Output Class Initialized
INFO - 2016-10-11 18:16:41 --> Security Class Initialized
DEBUG - 2016-10-11 18:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 18:16:41 --> Input Class Initialized
INFO - 2016-10-11 18:16:41 --> Language Class Initialized
INFO - 2016-10-11 18:16:41 --> Language Class Initialized
INFO - 2016-10-11 18:16:41 --> Config Class Initialized
INFO - 2016-10-11 18:16:41 --> Loader Class Initialized
INFO - 2016-10-11 18:16:41 --> Helper loaded: url_helper
INFO - 2016-10-11 18:16:42 --> Database Driver Class Initialized
INFO - 2016-10-11 18:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 18:16:42 --> Controller Class Initialized
DEBUG - 2016-10-11 18:16:42 --> Index MX_Controller Initialized
INFO - 2016-10-11 18:16:42 --> Model Class Initialized
INFO - 2016-10-11 18:16:42 --> Model Class Initialized
ERROR - 2016-10-11 18:16:42 --> Unable to delete cache file for admin/index/getRaportAngsuran/ca3512f4dfa95a03169c5a670a4c91a19b3077b4
DEBUG - 2016-10-11 18:16:42 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/raport_angsuran.php
INFO - 2016-10-11 18:16:42 --> Final output sent to browser
DEBUG - 2016-10-11 18:16:42 --> Total execution time: 1.0143
INFO - 2016-10-11 18:17:45 --> Config Class Initialized
INFO - 2016-10-11 18:17:45 --> Hooks Class Initialized
DEBUG - 2016-10-11 18:17:45 --> UTF-8 Support Enabled
INFO - 2016-10-11 18:17:45 --> Utf8 Class Initialized
INFO - 2016-10-11 18:17:45 --> URI Class Initialized
INFO - 2016-10-11 18:17:45 --> Router Class Initialized
INFO - 2016-10-11 18:17:45 --> Output Class Initialized
INFO - 2016-10-11 18:17:45 --> Security Class Initialized
DEBUG - 2016-10-11 18:17:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 18:17:46 --> Input Class Initialized
INFO - 2016-10-11 18:17:46 --> Language Class Initialized
INFO - 2016-10-11 18:17:46 --> Language Class Initialized
INFO - 2016-10-11 18:17:46 --> Config Class Initialized
INFO - 2016-10-11 18:17:46 --> Loader Class Initialized
INFO - 2016-10-11 18:17:46 --> Helper loaded: url_helper
INFO - 2016-10-11 18:17:46 --> Database Driver Class Initialized
INFO - 2016-10-11 18:17:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 18:17:46 --> Controller Class Initialized
DEBUG - 2016-10-11 18:17:46 --> Index MX_Controller Initialized
INFO - 2016-10-11 18:17:46 --> Model Class Initialized
INFO - 2016-10-11 18:17:46 --> Model Class Initialized
ERROR - 2016-10-11 18:17:46 --> Unable to delete cache file for admin/index/getRaportAngsuran/ca3512f4dfa95a03169c5a670a4c91a19b3077b4
DEBUG - 2016-10-11 18:17:46 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/raport_angsuran.php
INFO - 2016-10-11 18:17:46 --> Final output sent to browser
DEBUG - 2016-10-11 18:17:46 --> Total execution time: 1.1009
INFO - 2016-10-11 18:29:07 --> Config Class Initialized
INFO - 2016-10-11 18:29:07 --> Hooks Class Initialized
DEBUG - 2016-10-11 18:29:07 --> UTF-8 Support Enabled
INFO - 2016-10-11 18:29:07 --> Utf8 Class Initialized
INFO - 2016-10-11 18:29:07 --> URI Class Initialized
INFO - 2016-10-11 18:29:07 --> Router Class Initialized
INFO - 2016-10-11 18:29:07 --> Output Class Initialized
INFO - 2016-10-11 18:29:07 --> Security Class Initialized
DEBUG - 2016-10-11 18:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 18:29:07 --> Input Class Initialized
INFO - 2016-10-11 18:29:07 --> Language Class Initialized
INFO - 2016-10-11 18:29:07 --> Language Class Initialized
INFO - 2016-10-11 18:29:07 --> Config Class Initialized
INFO - 2016-10-11 18:29:07 --> Loader Class Initialized
INFO - 2016-10-11 18:29:07 --> Helper loaded: url_helper
INFO - 2016-10-11 18:29:07 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 18:29:07 --> Controller Class Initialized
DEBUG - 2016-10-11 18:29:07 --> Index MX_Controller Initialized
INFO - 2016-10-11 18:29:08 --> Model Class Initialized
INFO - 2016-10-11 18:29:08 --> Model Class Initialized
ERROR - 2016-10-11 18:29:08 --> Unable to delete cache file for admin/index/data_biaya
DEBUG - 2016-10-11 18:29:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-11 18:29:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-11 18:29:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-11 18:29:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_biaya.php
DEBUG - 2016-10-11 18:29:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-11 18:29:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-11 18:29:08 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:08 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:08 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:08 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:08 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:08 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:08 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:08 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:08 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:08 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:08 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:08 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:08 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:09 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:09 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:09 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:09 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:09 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:09 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:09 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:09 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:09 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:09 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:09 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:09 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:09 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:09 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:09 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:09 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:09 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:09 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:09 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:09 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:09 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:09 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:09 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:09 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:09 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:09 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:10 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:10 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:10 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:10 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:10 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:10 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:10 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:10 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:10 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:10 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:10 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:10 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:10 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:10 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:10 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:10 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:10 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:10 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:10 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:10 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:10 --> Database Driver Class Initialized
DEBUG - 2016-10-11 18:29:10 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-11 18:29:10 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-11 18:29:10 --> Final output sent to browser
DEBUG - 2016-10-11 18:29:11 --> Total execution time: 3.6252
INFO - 2016-10-11 18:29:20 --> Config Class Initialized
INFO - 2016-10-11 18:29:20 --> Hooks Class Initialized
DEBUG - 2016-10-11 18:29:21 --> UTF-8 Support Enabled
INFO - 2016-10-11 18:29:21 --> Utf8 Class Initialized
INFO - 2016-10-11 18:29:21 --> URI Class Initialized
INFO - 2016-10-11 18:29:21 --> Router Class Initialized
INFO - 2016-10-11 18:29:21 --> Output Class Initialized
INFO - 2016-10-11 18:29:21 --> Security Class Initialized
DEBUG - 2016-10-11 18:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 18:29:21 --> Input Class Initialized
INFO - 2016-10-11 18:29:21 --> Language Class Initialized
INFO - 2016-10-11 18:29:21 --> Language Class Initialized
INFO - 2016-10-11 18:29:21 --> Config Class Initialized
INFO - 2016-10-11 18:29:21 --> Loader Class Initialized
INFO - 2016-10-11 18:29:21 --> Helper loaded: url_helper
INFO - 2016-10-11 18:29:21 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 18:29:21 --> Controller Class Initialized
DEBUG - 2016-10-11 18:29:21 --> Index MX_Controller Initialized
INFO - 2016-10-11 18:29:21 --> Model Class Initialized
INFO - 2016-10-11 18:29:21 --> Model Class Initialized
ERROR - 2016-10-11 18:29:21 --> Unable to delete cache file for admin/index
DEBUG - 2016-10-11 18:29:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-11 18:29:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-11 18:29:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-11 18:29:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/dashboard.php
DEBUG - 2016-10-11 18:29:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-11 18:29:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-11 18:29:21 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:21 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:22 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:22 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:22 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:22 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:22 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:22 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:22 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:22 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:22 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:22 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:22 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:22 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:22 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:22 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:22 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:22 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:22 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:22 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:22 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:22 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:22 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:22 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:22 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:23 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:23 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:23 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:23 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:23 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:23 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:23 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:23 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:23 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:23 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:23 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:23 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:23 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:23 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:23 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:23 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:23 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:23 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:23 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:23 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:23 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:24 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:24 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:24 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:24 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:24 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:24 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:24 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:24 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:24 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:24 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:24 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:24 --> Database Driver Class Initialized
INFO - 2016-10-11 18:29:24 --> Database Driver Class Initialized
DEBUG - 2016-10-11 18:29:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-11 18:29:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-11 18:29:24 --> Final output sent to browser
DEBUG - 2016-10-11 18:29:24 --> Total execution time: 3.7347
INFO - 2016-10-11 18:37:27 --> Config Class Initialized
INFO - 2016-10-11 18:37:27 --> Hooks Class Initialized
DEBUG - 2016-10-11 18:37:27 --> UTF-8 Support Enabled
INFO - 2016-10-11 18:37:27 --> Utf8 Class Initialized
INFO - 2016-10-11 18:37:27 --> URI Class Initialized
INFO - 2016-10-11 18:37:27 --> Router Class Initialized
INFO - 2016-10-11 18:37:27 --> Output Class Initialized
INFO - 2016-10-11 18:37:27 --> Security Class Initialized
DEBUG - 2016-10-11 18:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 18:37:27 --> Input Class Initialized
INFO - 2016-10-11 18:37:27 --> Language Class Initialized
INFO - 2016-10-11 18:37:27 --> Language Class Initialized
INFO - 2016-10-11 18:37:27 --> Config Class Initialized
INFO - 2016-10-11 18:37:27 --> Loader Class Initialized
INFO - 2016-10-11 18:37:27 --> Helper loaded: url_helper
INFO - 2016-10-11 18:37:27 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 18:37:27 --> Controller Class Initialized
DEBUG - 2016-10-11 18:37:27 --> Index MX_Controller Initialized
INFO - 2016-10-11 18:37:27 --> Model Class Initialized
INFO - 2016-10-11 18:37:27 --> Model Class Initialized
ERROR - 2016-10-11 18:37:27 --> Unable to delete cache file for admin/index/bayar_angsuran
DEBUG - 2016-10-11 18:37:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-11 18:37:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-11 18:37:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-11 18:37:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_bayar_angsuran.php
DEBUG - 2016-10-11 18:37:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-11 18:37:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-11 18:37:28 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:28 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:28 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:28 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:28 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:28 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:28 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:28 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:28 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:28 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:28 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:28 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:28 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:28 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:28 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:28 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:28 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:28 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:28 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:28 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:28 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:29 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:29 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:29 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:29 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:29 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:29 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:29 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:29 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:29 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:29 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:29 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:29 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:29 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:29 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:29 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:29 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:29 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:29 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:29 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:29 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:29 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:29 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:29 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:29 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:29 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:29 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:30 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:30 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:30 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:30 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:30 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:30 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:30 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:30 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:30 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:30 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:30 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:30 --> Database Driver Class Initialized
DEBUG - 2016-10-11 18:37:30 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-11 18:37:30 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-11 18:37:30 --> Final output sent to browser
DEBUG - 2016-10-11 18:37:30 --> Total execution time: 3.3423
INFO - 2016-10-11 18:37:38 --> Config Class Initialized
INFO - 2016-10-11 18:37:38 --> Hooks Class Initialized
DEBUG - 2016-10-11 18:37:38 --> UTF-8 Support Enabled
INFO - 2016-10-11 18:37:38 --> Utf8 Class Initialized
INFO - 2016-10-11 18:37:38 --> URI Class Initialized
INFO - 2016-10-11 18:37:38 --> Router Class Initialized
INFO - 2016-10-11 18:37:38 --> Output Class Initialized
INFO - 2016-10-11 18:37:38 --> Security Class Initialized
DEBUG - 2016-10-11 18:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 18:37:39 --> Input Class Initialized
INFO - 2016-10-11 18:37:39 --> Language Class Initialized
INFO - 2016-10-11 18:37:39 --> Language Class Initialized
INFO - 2016-10-11 18:37:39 --> Config Class Initialized
INFO - 2016-10-11 18:37:39 --> Loader Class Initialized
INFO - 2016-10-11 18:37:39 --> Helper loaded: url_helper
INFO - 2016-10-11 18:37:39 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 18:37:39 --> Controller Class Initialized
DEBUG - 2016-10-11 18:37:39 --> Index MX_Controller Initialized
INFO - 2016-10-11 18:37:39 --> Model Class Initialized
INFO - 2016-10-11 18:37:39 --> Model Class Initialized
ERROR - 2016-10-11 18:37:39 --> Unable to delete cache file for admin/index/getDetailAngsuran
INFO - 2016-10-11 18:37:39 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:39 --> Final output sent to browser
DEBUG - 2016-10-11 18:37:39 --> Total execution time: 0.7880
INFO - 2016-10-11 18:37:53 --> Config Class Initialized
INFO - 2016-10-11 18:37:53 --> Hooks Class Initialized
DEBUG - 2016-10-11 18:37:53 --> UTF-8 Support Enabled
INFO - 2016-10-11 18:37:53 --> Utf8 Class Initialized
INFO - 2016-10-11 18:37:53 --> URI Class Initialized
INFO - 2016-10-11 18:37:54 --> Router Class Initialized
INFO - 2016-10-11 18:37:54 --> Output Class Initialized
INFO - 2016-10-11 18:37:54 --> Security Class Initialized
DEBUG - 2016-10-11 18:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 18:37:54 --> Input Class Initialized
INFO - 2016-10-11 18:37:54 --> Language Class Initialized
INFO - 2016-10-11 18:37:54 --> Language Class Initialized
INFO - 2016-10-11 18:37:54 --> Config Class Initialized
INFO - 2016-10-11 18:37:54 --> Loader Class Initialized
INFO - 2016-10-11 18:37:54 --> Helper loaded: url_helper
INFO - 2016-10-11 18:37:54 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 18:37:54 --> Controller Class Initialized
DEBUG - 2016-10-11 18:37:54 --> Index MX_Controller Initialized
INFO - 2016-10-11 18:37:54 --> Model Class Initialized
INFO - 2016-10-11 18:37:54 --> Model Class Initialized
ERROR - 2016-10-11 18:37:54 --> Unable to delete cache file for admin/index/getDetailAngsuran
INFO - 2016-10-11 18:37:54 --> Database Driver Class Initialized
INFO - 2016-10-11 18:37:54 --> Final output sent to browser
DEBUG - 2016-10-11 18:37:54 --> Total execution time: 0.8011
INFO - 2016-10-11 18:38:00 --> Config Class Initialized
INFO - 2016-10-11 18:38:00 --> Hooks Class Initialized
DEBUG - 2016-10-11 18:38:00 --> UTF-8 Support Enabled
INFO - 2016-10-11 18:38:00 --> Utf8 Class Initialized
INFO - 2016-10-11 18:38:00 --> URI Class Initialized
INFO - 2016-10-11 18:38:01 --> Router Class Initialized
INFO - 2016-10-11 18:38:01 --> Output Class Initialized
INFO - 2016-10-11 18:38:01 --> Security Class Initialized
DEBUG - 2016-10-11 18:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 18:38:01 --> Input Class Initialized
INFO - 2016-10-11 18:38:01 --> Language Class Initialized
INFO - 2016-10-11 18:38:01 --> Language Class Initialized
INFO - 2016-10-11 18:38:01 --> Config Class Initialized
INFO - 2016-10-11 18:38:01 --> Loader Class Initialized
INFO - 2016-10-11 18:38:01 --> Helper loaded: url_helper
INFO - 2016-10-11 18:38:01 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 18:38:01 --> Controller Class Initialized
DEBUG - 2016-10-11 18:38:01 --> Index MX_Controller Initialized
INFO - 2016-10-11 18:38:01 --> Model Class Initialized
INFO - 2016-10-11 18:38:01 --> Model Class Initialized
ERROR - 2016-10-11 18:38:01 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-10-11 18:38:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-11 18:38:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-11 18:38:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-11 18:38:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-10-11 18:38:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-11 18:38:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-11 18:38:01 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:02 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:02 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:02 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:02 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:02 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:02 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:02 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:02 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:02 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:02 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:02 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:02 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:02 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:02 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:02 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:02 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:02 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:02 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:02 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:02 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:02 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:02 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:02 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:02 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:02 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:03 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:03 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:03 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:03 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:03 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:03 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:03 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:03 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:03 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:03 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:03 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:03 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:03 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:03 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:03 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:03 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:03 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:03 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:03 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:03 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:03 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:03 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:03 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:03 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:04 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:04 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:04 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:04 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:04 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:04 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:04 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:04 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:04 --> Database Driver Class Initialized
DEBUG - 2016-10-11 18:38:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-11 18:38:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-11 18:38:04 --> Final output sent to browser
DEBUG - 2016-10-11 18:38:04 --> Total execution time: 3.5944
INFO - 2016-10-11 18:38:14 --> Config Class Initialized
INFO - 2016-10-11 18:38:14 --> Hooks Class Initialized
DEBUG - 2016-10-11 18:38:14 --> UTF-8 Support Enabled
INFO - 2016-10-11 18:38:14 --> Utf8 Class Initialized
INFO - 2016-10-11 18:38:14 --> URI Class Initialized
INFO - 2016-10-11 18:38:14 --> Router Class Initialized
INFO - 2016-10-11 18:38:14 --> Output Class Initialized
INFO - 2016-10-11 18:38:14 --> Security Class Initialized
DEBUG - 2016-10-11 18:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 18:38:14 --> Input Class Initialized
INFO - 2016-10-11 18:38:14 --> Language Class Initialized
INFO - 2016-10-11 18:38:14 --> Language Class Initialized
INFO - 2016-10-11 18:38:14 --> Config Class Initialized
INFO - 2016-10-11 18:38:14 --> Loader Class Initialized
INFO - 2016-10-11 18:38:14 --> Helper loaded: url_helper
INFO - 2016-10-11 18:38:14 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 18:38:14 --> Controller Class Initialized
DEBUG - 2016-10-11 18:38:14 --> Index MX_Controller Initialized
INFO - 2016-10-11 18:38:14 --> Model Class Initialized
INFO - 2016-10-11 18:38:14 --> Model Class Initialized
ERROR - 2016-10-11 18:38:15 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-11 18:38:15 --> Anggota MX_Controller Initialized
INFO - 2016-10-11 18:38:15 --> Database Driver Class Initialized
INFO - 2016-10-11 18:38:15 --> Final output sent to browser
DEBUG - 2016-10-11 18:38:15 --> Total execution time: 0.9476
