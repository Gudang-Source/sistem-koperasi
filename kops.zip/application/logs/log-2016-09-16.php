<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-09-16 09:16:28 --> Config Class Initialized
INFO - 2016-09-16 09:16:28 --> Hooks Class Initialized
DEBUG - 2016-09-16 09:16:28 --> UTF-8 Support Enabled
INFO - 2016-09-16 09:16:28 --> Utf8 Class Initialized
INFO - 2016-09-16 09:16:28 --> URI Class Initialized
INFO - 2016-09-16 09:16:28 --> Router Class Initialized
INFO - 2016-09-16 09:16:28 --> Output Class Initialized
INFO - 2016-09-16 09:16:28 --> Security Class Initialized
DEBUG - 2016-09-16 09:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 09:16:28 --> Input Class Initialized
INFO - 2016-09-16 09:16:28 --> Language Class Initialized
INFO - 2016-09-16 09:16:28 --> Language Class Initialized
INFO - 2016-09-16 09:16:28 --> Config Class Initialized
INFO - 2016-09-16 09:16:28 --> Loader Class Initialized
INFO - 2016-09-16 09:16:29 --> Helper loaded: url_helper
INFO - 2016-09-16 09:16:29 --> Database Driver Class Initialized
INFO - 2016-09-16 09:16:29 --> Controller Class Initialized
DEBUG - 2016-09-16 09:16:29 --> Index MX_Controller Initialized
INFO - 2016-09-16 09:16:29 --> Model Class Initialized
INFO - 2016-09-16 09:16:29 --> Model Class Initialized
DEBUG - 2016-09-16 09:16:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-16 09:16:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-16 09:16:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-16 09:16:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/pinjaman.php
DEBUG - 2016-09-16 09:16:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-16 09:16:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-16 09:16:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-16 09:16:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-16 09:16:29 --> Final output sent to browser
DEBUG - 2016-09-16 09:16:29 --> Total execution time: 0.4674
INFO - 2016-09-16 09:16:37 --> Config Class Initialized
INFO - 2016-09-16 09:16:37 --> Hooks Class Initialized
DEBUG - 2016-09-16 09:16:37 --> UTF-8 Support Enabled
INFO - 2016-09-16 09:16:37 --> Utf8 Class Initialized
INFO - 2016-09-16 09:16:37 --> URI Class Initialized
INFO - 2016-09-16 09:16:37 --> Router Class Initialized
INFO - 2016-09-16 09:16:37 --> Output Class Initialized
INFO - 2016-09-16 09:16:37 --> Security Class Initialized
DEBUG - 2016-09-16 09:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 09:16:37 --> Input Class Initialized
INFO - 2016-09-16 09:16:37 --> Language Class Initialized
INFO - 2016-09-16 09:16:37 --> Language Class Initialized
INFO - 2016-09-16 09:16:37 --> Config Class Initialized
INFO - 2016-09-16 09:16:37 --> Loader Class Initialized
INFO - 2016-09-16 09:16:37 --> Helper loaded: url_helper
INFO - 2016-09-16 09:16:37 --> Database Driver Class Initialized
INFO - 2016-09-16 09:16:37 --> Controller Class Initialized
DEBUG - 2016-09-16 09:16:37 --> Index MX_Controller Initialized
INFO - 2016-09-16 09:16:37 --> Model Class Initialized
INFO - 2016-09-16 09:16:37 --> Model Class Initialized
DEBUG - 2016-09-16 09:16:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_pinjaman.php
INFO - 2016-09-16 09:16:38 --> Final output sent to browser
DEBUG - 2016-09-16 09:16:38 --> Total execution time: 0.3957
INFO - 2016-09-16 09:17:49 --> Config Class Initialized
INFO - 2016-09-16 09:17:49 --> Hooks Class Initialized
DEBUG - 2016-09-16 09:17:49 --> UTF-8 Support Enabled
INFO - 2016-09-16 09:17:49 --> Utf8 Class Initialized
INFO - 2016-09-16 09:17:49 --> URI Class Initialized
INFO - 2016-09-16 09:17:49 --> Router Class Initialized
INFO - 2016-09-16 09:17:49 --> Output Class Initialized
INFO - 2016-09-16 09:17:49 --> Security Class Initialized
DEBUG - 2016-09-16 09:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 09:17:49 --> Input Class Initialized
INFO - 2016-09-16 09:17:49 --> Language Class Initialized
INFO - 2016-09-16 09:17:49 --> Language Class Initialized
INFO - 2016-09-16 09:17:49 --> Config Class Initialized
INFO - 2016-09-16 09:17:49 --> Loader Class Initialized
INFO - 2016-09-16 09:17:49 --> Helper loaded: url_helper
INFO - 2016-09-16 09:17:49 --> Database Driver Class Initialized
INFO - 2016-09-16 09:17:49 --> Controller Class Initialized
DEBUG - 2016-09-16 09:17:49 --> Index MX_Controller Initialized
INFO - 2016-09-16 09:17:49 --> Model Class Initialized
INFO - 2016-09-16 09:17:50 --> Model Class Initialized
DEBUG - 2016-09-16 09:17:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_pinjaman.php
INFO - 2016-09-16 09:17:50 --> Final output sent to browser
DEBUG - 2016-09-16 09:17:50 --> Total execution time: 0.5070
INFO - 2016-09-16 09:18:00 --> Config Class Initialized
INFO - 2016-09-16 09:18:00 --> Hooks Class Initialized
DEBUG - 2016-09-16 09:18:00 --> UTF-8 Support Enabled
INFO - 2016-09-16 09:18:00 --> Utf8 Class Initialized
INFO - 2016-09-16 09:18:00 --> URI Class Initialized
INFO - 2016-09-16 09:18:00 --> Router Class Initialized
INFO - 2016-09-16 09:18:00 --> Output Class Initialized
INFO - 2016-09-16 09:18:00 --> Security Class Initialized
DEBUG - 2016-09-16 09:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 09:18:00 --> Input Class Initialized
INFO - 2016-09-16 09:18:00 --> Language Class Initialized
INFO - 2016-09-16 09:18:00 --> Language Class Initialized
INFO - 2016-09-16 09:18:00 --> Config Class Initialized
INFO - 2016-09-16 09:18:00 --> Loader Class Initialized
INFO - 2016-09-16 09:18:00 --> Helper loaded: url_helper
INFO - 2016-09-16 09:18:00 --> Database Driver Class Initialized
INFO - 2016-09-16 09:18:00 --> Controller Class Initialized
DEBUG - 2016-09-16 09:18:00 --> Index MX_Controller Initialized
INFO - 2016-09-16 09:18:00 --> Model Class Initialized
INFO - 2016-09-16 09:18:00 --> Model Class Initialized
DEBUG - 2016-09-16 09:18:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_pinjaman.php
INFO - 2016-09-16 09:18:01 --> Final output sent to browser
DEBUG - 2016-09-16 09:18:01 --> Total execution time: 0.4162
INFO - 2016-09-16 10:17:37 --> Config Class Initialized
INFO - 2016-09-16 10:17:37 --> Hooks Class Initialized
DEBUG - 2016-09-16 10:17:37 --> UTF-8 Support Enabled
INFO - 2016-09-16 10:17:37 --> Utf8 Class Initialized
INFO - 2016-09-16 10:17:37 --> URI Class Initialized
INFO - 2016-09-16 10:17:37 --> Router Class Initialized
INFO - 2016-09-16 10:17:37 --> Output Class Initialized
INFO - 2016-09-16 10:17:37 --> Security Class Initialized
DEBUG - 2016-09-16 10:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 10:17:37 --> Input Class Initialized
INFO - 2016-09-16 10:17:37 --> Language Class Initialized
INFO - 2016-09-16 10:17:37 --> Language Class Initialized
INFO - 2016-09-16 10:17:37 --> Config Class Initialized
INFO - 2016-09-16 10:17:37 --> Loader Class Initialized
INFO - 2016-09-16 10:17:37 --> Helper loaded: url_helper
INFO - 2016-09-16 10:17:37 --> Database Driver Class Initialized
INFO - 2016-09-16 10:17:37 --> Controller Class Initialized
DEBUG - 2016-09-16 10:17:37 --> Index MX_Controller Initialized
INFO - 2016-09-16 10:17:37 --> Model Class Initialized
INFO - 2016-09-16 10:17:37 --> Model Class Initialized
DEBUG - 2016-09-16 10:17:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-16 10:17:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-16 10:17:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-16 10:17:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/angsuran.php
DEBUG - 2016-09-16 10:17:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-16 10:17:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-16 10:17:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-16 10:17:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-16 10:17:37 --> Final output sent to browser
DEBUG - 2016-09-16 10:17:38 --> Total execution time: 0.4944
INFO - 2016-09-16 10:17:44 --> Config Class Initialized
INFO - 2016-09-16 10:17:44 --> Hooks Class Initialized
DEBUG - 2016-09-16 10:17:44 --> UTF-8 Support Enabled
INFO - 2016-09-16 10:17:44 --> Utf8 Class Initialized
INFO - 2016-09-16 10:17:44 --> URI Class Initialized
INFO - 2016-09-16 10:17:44 --> Router Class Initialized
INFO - 2016-09-16 10:17:44 --> Output Class Initialized
INFO - 2016-09-16 10:17:44 --> Security Class Initialized
DEBUG - 2016-09-16 10:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 10:17:44 --> Input Class Initialized
INFO - 2016-09-16 10:17:44 --> Language Class Initialized
INFO - 2016-09-16 10:17:45 --> Language Class Initialized
INFO - 2016-09-16 10:17:45 --> Config Class Initialized
INFO - 2016-09-16 10:17:45 --> Loader Class Initialized
INFO - 2016-09-16 10:17:45 --> Helper loaded: url_helper
INFO - 2016-09-16 10:17:45 --> Database Driver Class Initialized
INFO - 2016-09-16 10:17:45 --> Controller Class Initialized
DEBUG - 2016-09-16 10:17:45 --> Index MX_Controller Initialized
INFO - 2016-09-16 10:17:45 --> Model Class Initialized
INFO - 2016-09-16 10:17:45 --> Model Class Initialized
INFO - 2016-09-16 10:17:45 --> Database Driver Class Initialized
INFO - 2016-09-16 10:17:45 --> Database Driver Class Initialized
INFO - 2016-09-16 10:17:45 --> Database Driver Class Initialized
INFO - 2016-09-16 10:17:45 --> Database Driver Class Initialized
INFO - 2016-09-16 10:17:45 --> Database Driver Class Initialized
INFO - 2016-09-16 10:17:45 --> Database Driver Class Initialized
INFO - 2016-09-16 10:17:45 --> Database Driver Class Initialized
INFO - 2016-09-16 10:17:45 --> Database Driver Class Initialized
INFO - 2016-09-16 10:17:45 --> Database Driver Class Initialized
DEBUG - 2016-09-16 10:17:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_angsuran.php
INFO - 2016-09-16 10:17:45 --> Final output sent to browser
DEBUG - 2016-09-16 10:17:45 --> Total execution time: 0.6568
INFO - 2016-09-16 10:19:32 --> Config Class Initialized
INFO - 2016-09-16 10:19:32 --> Hooks Class Initialized
DEBUG - 2016-09-16 10:19:32 --> UTF-8 Support Enabled
INFO - 2016-09-16 10:19:32 --> Utf8 Class Initialized
INFO - 2016-09-16 10:19:32 --> URI Class Initialized
INFO - 2016-09-16 10:19:32 --> Router Class Initialized
INFO - 2016-09-16 10:19:32 --> Output Class Initialized
INFO - 2016-09-16 10:19:32 --> Security Class Initialized
DEBUG - 2016-09-16 10:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 10:19:33 --> Input Class Initialized
INFO - 2016-09-16 10:19:33 --> Language Class Initialized
INFO - 2016-09-16 10:19:33 --> Language Class Initialized
INFO - 2016-09-16 10:19:33 --> Config Class Initialized
INFO - 2016-09-16 10:19:33 --> Loader Class Initialized
INFO - 2016-09-16 10:19:33 --> Helper loaded: url_helper
INFO - 2016-09-16 10:19:33 --> Database Driver Class Initialized
INFO - 2016-09-16 10:19:33 --> Controller Class Initialized
DEBUG - 2016-09-16 10:19:33 --> Index MX_Controller Initialized
INFO - 2016-09-16 10:19:33 --> Model Class Initialized
INFO - 2016-09-16 10:19:33 --> Model Class Initialized
DEBUG - 2016-09-16 10:19:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-16 10:19:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-16 10:19:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-16 10:19:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_peminjam.php
DEBUG - 2016-09-16 10:19:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-16 10:19:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-16 10:19:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-16 10:19:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-16 10:19:33 --> Final output sent to browser
DEBUG - 2016-09-16 10:19:33 --> Total execution time: 0.4999
INFO - 2016-09-16 10:19:35 --> Config Class Initialized
INFO - 2016-09-16 10:19:35 --> Hooks Class Initialized
DEBUG - 2016-09-16 10:19:35 --> UTF-8 Support Enabled
INFO - 2016-09-16 10:19:35 --> Utf8 Class Initialized
INFO - 2016-09-16 10:19:35 --> URI Class Initialized
INFO - 2016-09-16 10:19:35 --> Router Class Initialized
INFO - 2016-09-16 10:19:35 --> Output Class Initialized
INFO - 2016-09-16 10:19:35 --> Security Class Initialized
DEBUG - 2016-09-16 10:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 10:19:35 --> Input Class Initialized
INFO - 2016-09-16 10:19:35 --> Language Class Initialized
INFO - 2016-09-16 10:19:35 --> Language Class Initialized
INFO - 2016-09-16 10:19:35 --> Config Class Initialized
INFO - 2016-09-16 10:19:35 --> Loader Class Initialized
INFO - 2016-09-16 10:19:36 --> Helper loaded: url_helper
INFO - 2016-09-16 10:19:36 --> Database Driver Class Initialized
INFO - 2016-09-16 10:19:36 --> Controller Class Initialized
DEBUG - 2016-09-16 10:19:36 --> Index MX_Controller Initialized
INFO - 2016-09-16 10:19:36 --> Model Class Initialized
INFO - 2016-09-16 10:19:36 --> Model Class Initialized
DEBUG - 2016-09-16 10:19:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-16 10:19:36 --> Final output sent to browser
DEBUG - 2016-09-16 10:19:36 --> Total execution time: 0.4574
INFO - 2016-09-16 10:19:36 --> Config Class Initialized
INFO - 2016-09-16 10:19:36 --> Hooks Class Initialized
DEBUG - 2016-09-16 10:19:36 --> UTF-8 Support Enabled
INFO - 2016-09-16 10:19:36 --> Utf8 Class Initialized
INFO - 2016-09-16 10:19:36 --> URI Class Initialized
INFO - 2016-09-16 10:19:36 --> Router Class Initialized
INFO - 2016-09-16 10:19:36 --> Output Class Initialized
INFO - 2016-09-16 10:19:36 --> Security Class Initialized
DEBUG - 2016-09-16 10:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 10:19:36 --> Input Class Initialized
INFO - 2016-09-16 10:19:36 --> Language Class Initialized
INFO - 2016-09-16 10:19:36 --> Language Class Initialized
INFO - 2016-09-16 10:19:36 --> Config Class Initialized
INFO - 2016-09-16 10:19:37 --> Loader Class Initialized
INFO - 2016-09-16 10:19:37 --> Helper loaded: url_helper
INFO - 2016-09-16 10:19:37 --> Database Driver Class Initialized
INFO - 2016-09-16 10:19:37 --> Controller Class Initialized
DEBUG - 2016-09-16 10:19:37 --> Index MX_Controller Initialized
INFO - 2016-09-16 10:19:37 --> Model Class Initialized
INFO - 2016-09-16 10:19:37 --> Model Class Initialized
DEBUG - 2016-09-16 10:19:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-16 10:19:37 --> Final output sent to browser
DEBUG - 2016-09-16 10:19:37 --> Total execution time: 0.3712
INFO - 2016-09-16 10:19:38 --> Config Class Initialized
INFO - 2016-09-16 10:19:38 --> Hooks Class Initialized
DEBUG - 2016-09-16 10:19:38 --> UTF-8 Support Enabled
INFO - 2016-09-16 10:19:38 --> Utf8 Class Initialized
INFO - 2016-09-16 10:19:38 --> URI Class Initialized
INFO - 2016-09-16 10:19:38 --> Router Class Initialized
INFO - 2016-09-16 10:19:38 --> Output Class Initialized
INFO - 2016-09-16 10:19:38 --> Security Class Initialized
DEBUG - 2016-09-16 10:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 10:19:38 --> Input Class Initialized
INFO - 2016-09-16 10:19:38 --> Language Class Initialized
INFO - 2016-09-16 10:19:38 --> Language Class Initialized
INFO - 2016-09-16 10:19:38 --> Config Class Initialized
INFO - 2016-09-16 10:19:38 --> Loader Class Initialized
INFO - 2016-09-16 10:19:38 --> Helper loaded: url_helper
INFO - 2016-09-16 10:19:38 --> Database Driver Class Initialized
INFO - 2016-09-16 10:19:38 --> Controller Class Initialized
DEBUG - 2016-09-16 10:19:38 --> Index MX_Controller Initialized
INFO - 2016-09-16 10:19:38 --> Model Class Initialized
INFO - 2016-09-16 10:19:38 --> Model Class Initialized
DEBUG - 2016-09-16 10:19:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-16 10:19:38 --> Final output sent to browser
DEBUG - 2016-09-16 10:19:38 --> Total execution time: 0.4164
INFO - 2016-09-16 10:19:40 --> Config Class Initialized
INFO - 2016-09-16 10:19:40 --> Hooks Class Initialized
DEBUG - 2016-09-16 10:19:40 --> UTF-8 Support Enabled
INFO - 2016-09-16 10:19:40 --> Utf8 Class Initialized
INFO - 2016-09-16 10:19:40 --> URI Class Initialized
INFO - 2016-09-16 10:19:40 --> Router Class Initialized
INFO - 2016-09-16 10:19:40 --> Output Class Initialized
INFO - 2016-09-16 10:19:40 --> Security Class Initialized
DEBUG - 2016-09-16 10:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 10:19:40 --> Input Class Initialized
INFO - 2016-09-16 10:19:40 --> Language Class Initialized
INFO - 2016-09-16 10:19:40 --> Language Class Initialized
INFO - 2016-09-16 10:19:40 --> Config Class Initialized
INFO - 2016-09-16 10:19:40 --> Loader Class Initialized
INFO - 2016-09-16 10:19:40 --> Helper loaded: url_helper
INFO - 2016-09-16 10:19:40 --> Database Driver Class Initialized
INFO - 2016-09-16 10:19:40 --> Controller Class Initialized
DEBUG - 2016-09-16 10:19:40 --> Index MX_Controller Initialized
INFO - 2016-09-16 10:19:40 --> Model Class Initialized
INFO - 2016-09-16 10:19:40 --> Model Class Initialized
DEBUG - 2016-09-16 10:19:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_transaksi.php
INFO - 2016-09-16 10:19:40 --> Final output sent to browser
DEBUG - 2016-09-16 10:19:40 --> Total execution time: 0.5356
INFO - 2016-09-16 10:19:44 --> Config Class Initialized
INFO - 2016-09-16 10:19:44 --> Hooks Class Initialized
DEBUG - 2016-09-16 10:19:44 --> UTF-8 Support Enabled
INFO - 2016-09-16 10:19:44 --> Utf8 Class Initialized
INFO - 2016-09-16 10:19:44 --> URI Class Initialized
INFO - 2016-09-16 10:19:44 --> Router Class Initialized
INFO - 2016-09-16 10:19:44 --> Output Class Initialized
INFO - 2016-09-16 10:19:44 --> Security Class Initialized
DEBUG - 2016-09-16 10:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 10:19:44 --> Input Class Initialized
INFO - 2016-09-16 10:19:44 --> Language Class Initialized
INFO - 2016-09-16 10:19:44 --> Language Class Initialized
INFO - 2016-09-16 10:19:44 --> Config Class Initialized
INFO - 2016-09-16 10:19:45 --> Loader Class Initialized
INFO - 2016-09-16 10:19:45 --> Helper loaded: url_helper
INFO - 2016-09-16 10:19:45 --> Database Driver Class Initialized
INFO - 2016-09-16 10:19:45 --> Controller Class Initialized
DEBUG - 2016-09-16 10:19:45 --> Index MX_Controller Initialized
INFO - 2016-09-16 10:19:45 --> Model Class Initialized
INFO - 2016-09-16 10:19:45 --> Model Class Initialized
DEBUG - 2016-09-16 10:19:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-16 10:19:45 --> Final output sent to browser
DEBUG - 2016-09-16 10:19:45 --> Total execution time: 0.4928
INFO - 2016-09-16 10:19:47 --> Config Class Initialized
INFO - 2016-09-16 10:19:47 --> Hooks Class Initialized
DEBUG - 2016-09-16 10:19:47 --> UTF-8 Support Enabled
INFO - 2016-09-16 10:19:47 --> Utf8 Class Initialized
INFO - 2016-09-16 10:19:47 --> URI Class Initialized
INFO - 2016-09-16 10:19:47 --> Router Class Initialized
INFO - 2016-09-16 10:19:47 --> Output Class Initialized
INFO - 2016-09-16 10:19:47 --> Security Class Initialized
DEBUG - 2016-09-16 10:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 10:19:47 --> Input Class Initialized
INFO - 2016-09-16 10:19:47 --> Language Class Initialized
INFO - 2016-09-16 10:19:47 --> Language Class Initialized
INFO - 2016-09-16 10:19:47 --> Config Class Initialized
INFO - 2016-09-16 10:19:47 --> Loader Class Initialized
INFO - 2016-09-16 10:19:47 --> Helper loaded: url_helper
INFO - 2016-09-16 10:19:47 --> Database Driver Class Initialized
INFO - 2016-09-16 10:19:47 --> Controller Class Initialized
DEBUG - 2016-09-16 10:19:47 --> Index MX_Controller Initialized
INFO - 2016-09-16 10:19:47 --> Model Class Initialized
INFO - 2016-09-16 10:19:47 --> Model Class Initialized
DEBUG - 2016-09-16 10:19:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-16 10:19:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-16 10:19:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-16 10:19:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-16 10:19:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-16 10:19:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-16 10:19:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-16 10:19:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-16 10:19:48 --> Final output sent to browser
DEBUG - 2016-09-16 10:19:48 --> Total execution time: 0.5197
INFO - 2016-09-16 10:20:02 --> Config Class Initialized
INFO - 2016-09-16 10:20:02 --> Hooks Class Initialized
DEBUG - 2016-09-16 10:20:02 --> UTF-8 Support Enabled
INFO - 2016-09-16 10:20:02 --> Utf8 Class Initialized
INFO - 2016-09-16 10:20:03 --> URI Class Initialized
INFO - 2016-09-16 10:20:03 --> Router Class Initialized
INFO - 2016-09-16 10:20:03 --> Output Class Initialized
INFO - 2016-09-16 10:20:03 --> Security Class Initialized
DEBUG - 2016-09-16 10:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 10:20:03 --> Input Class Initialized
INFO - 2016-09-16 10:20:03 --> Language Class Initialized
INFO - 2016-09-16 10:20:03 --> Language Class Initialized
INFO - 2016-09-16 10:20:03 --> Config Class Initialized
INFO - 2016-09-16 10:20:03 --> Loader Class Initialized
INFO - 2016-09-16 10:20:03 --> Helper loaded: url_helper
INFO - 2016-09-16 10:20:03 --> Database Driver Class Initialized
INFO - 2016-09-16 10:20:03 --> Controller Class Initialized
DEBUG - 2016-09-16 10:20:03 --> Index MX_Controller Initialized
INFO - 2016-09-16 10:20:03 --> Model Class Initialized
INFO - 2016-09-16 10:20:03 --> Model Class Initialized
DEBUG - 2016-09-16 10:20:03 --> Anggota MX_Controller Initialized
INFO - 2016-09-16 10:20:03 --> Database Driver Class Initialized
INFO - 2016-09-16 10:20:03 --> Final output sent to browser
DEBUG - 2016-09-16 10:20:03 --> Total execution time: 0.4758
INFO - 2016-09-16 10:20:04 --> Config Class Initialized
INFO - 2016-09-16 10:20:04 --> Hooks Class Initialized
DEBUG - 2016-09-16 10:20:04 --> UTF-8 Support Enabled
INFO - 2016-09-16 10:20:04 --> Utf8 Class Initialized
INFO - 2016-09-16 10:20:04 --> URI Class Initialized
INFO - 2016-09-16 10:20:04 --> Router Class Initialized
INFO - 2016-09-16 10:20:04 --> Output Class Initialized
INFO - 2016-09-16 10:20:04 --> Security Class Initialized
DEBUG - 2016-09-16 10:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 10:20:04 --> Input Class Initialized
INFO - 2016-09-16 10:20:04 --> Language Class Initialized
INFO - 2016-09-16 10:20:04 --> Language Class Initialized
INFO - 2016-09-16 10:20:04 --> Config Class Initialized
INFO - 2016-09-16 10:20:04 --> Loader Class Initialized
INFO - 2016-09-16 10:20:04 --> Helper loaded: url_helper
INFO - 2016-09-16 10:20:04 --> Database Driver Class Initialized
INFO - 2016-09-16 10:20:04 --> Controller Class Initialized
DEBUG - 2016-09-16 10:20:04 --> Index MX_Controller Initialized
INFO - 2016-09-16 10:20:04 --> Model Class Initialized
INFO - 2016-09-16 10:20:04 --> Model Class Initialized
DEBUG - 2016-09-16 10:20:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-16 10:20:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-16 10:20:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-16 10:20:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_umum.php
DEBUG - 2016-09-16 10:20:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-16 10:20:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-16 10:20:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-16 10:20:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-16 10:20:05 --> Final output sent to browser
DEBUG - 2016-09-16 10:20:05 --> Total execution time: 0.5614
INFO - 2016-09-16 10:23:24 --> Config Class Initialized
INFO - 2016-09-16 10:23:24 --> Hooks Class Initialized
DEBUG - 2016-09-16 10:23:24 --> UTF-8 Support Enabled
INFO - 2016-09-16 10:23:24 --> Utf8 Class Initialized
INFO - 2016-09-16 10:23:24 --> URI Class Initialized
INFO - 2016-09-16 10:23:24 --> Router Class Initialized
INFO - 2016-09-16 10:23:24 --> Output Class Initialized
INFO - 2016-09-16 10:23:24 --> Security Class Initialized
DEBUG - 2016-09-16 10:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 10:23:24 --> Input Class Initialized
INFO - 2016-09-16 10:23:24 --> Language Class Initialized
INFO - 2016-09-16 10:23:24 --> Language Class Initialized
INFO - 2016-09-16 10:23:24 --> Config Class Initialized
INFO - 2016-09-16 10:23:24 --> Loader Class Initialized
INFO - 2016-09-16 10:23:25 --> Helper loaded: url_helper
INFO - 2016-09-16 10:23:25 --> Database Driver Class Initialized
INFO - 2016-09-16 10:23:25 --> Controller Class Initialized
DEBUG - 2016-09-16 10:23:25 --> Index MX_Controller Initialized
INFO - 2016-09-16 10:23:25 --> Model Class Initialized
INFO - 2016-09-16 10:23:25 --> Model Class Initialized
DEBUG - 2016-09-16 10:23:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-16 10:23:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-16 10:23:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-16 10:23:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_umum.php
DEBUG - 2016-09-16 10:23:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-16 10:23:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-16 10:23:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-16 10:23:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-16 10:23:25 --> Final output sent to browser
DEBUG - 2016-09-16 10:23:25 --> Total execution time: 0.5437
INFO - 2016-09-16 10:24:13 --> Config Class Initialized
INFO - 2016-09-16 10:24:13 --> Hooks Class Initialized
DEBUG - 2016-09-16 10:24:13 --> UTF-8 Support Enabled
INFO - 2016-09-16 10:24:13 --> Utf8 Class Initialized
INFO - 2016-09-16 10:24:13 --> URI Class Initialized
INFO - 2016-09-16 10:24:13 --> Router Class Initialized
INFO - 2016-09-16 10:24:13 --> Output Class Initialized
INFO - 2016-09-16 10:24:13 --> Security Class Initialized
DEBUG - 2016-09-16 10:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 10:24:13 --> Input Class Initialized
INFO - 2016-09-16 10:24:13 --> Language Class Initialized
INFO - 2016-09-16 10:24:13 --> Language Class Initialized
INFO - 2016-09-16 10:24:13 --> Config Class Initialized
INFO - 2016-09-16 10:24:13 --> Loader Class Initialized
INFO - 2016-09-16 10:24:13 --> Helper loaded: url_helper
INFO - 2016-09-16 10:24:13 --> Database Driver Class Initialized
INFO - 2016-09-16 10:24:13 --> Controller Class Initialized
DEBUG - 2016-09-16 10:24:13 --> Index MX_Controller Initialized
INFO - 2016-09-16 10:24:13 --> Model Class Initialized
INFO - 2016-09-16 10:24:13 --> Model Class Initialized
INFO - 2016-09-16 10:24:13 --> Database Driver Class Initialized
INFO - 2016-09-16 10:24:14 --> Final output sent to browser
DEBUG - 2016-09-16 10:24:14 --> Total execution time: 0.4908
INFO - 2016-09-16 10:26:08 --> Config Class Initialized
INFO - 2016-09-16 10:26:08 --> Hooks Class Initialized
DEBUG - 2016-09-16 10:26:08 --> UTF-8 Support Enabled
INFO - 2016-09-16 10:26:08 --> Utf8 Class Initialized
INFO - 2016-09-16 10:26:08 --> URI Class Initialized
INFO - 2016-09-16 10:26:08 --> Router Class Initialized
INFO - 2016-09-16 10:26:08 --> Output Class Initialized
INFO - 2016-09-16 10:26:08 --> Security Class Initialized
DEBUG - 2016-09-16 10:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 10:26:08 --> Input Class Initialized
INFO - 2016-09-16 10:26:08 --> Language Class Initialized
INFO - 2016-09-16 10:26:08 --> Language Class Initialized
INFO - 2016-09-16 10:26:08 --> Config Class Initialized
INFO - 2016-09-16 10:26:08 --> Loader Class Initialized
INFO - 2016-09-16 10:26:08 --> Helper loaded: url_helper
INFO - 2016-09-16 10:26:08 --> Database Driver Class Initialized
INFO - 2016-09-16 10:26:08 --> Controller Class Initialized
DEBUG - 2016-09-16 10:26:08 --> Index MX_Controller Initialized
INFO - 2016-09-16 10:26:08 --> Model Class Initialized
INFO - 2016-09-16 10:26:08 --> Model Class Initialized
DEBUG - 2016-09-16 10:26:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-16 10:26:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-16 10:26:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-16 10:26:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_umum.php
DEBUG - 2016-09-16 10:26:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-16 10:26:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-16 10:26:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-16 10:26:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-16 10:26:08 --> Final output sent to browser
DEBUG - 2016-09-16 10:26:08 --> Total execution time: 0.6401
INFO - 2016-09-16 10:26:43 --> Config Class Initialized
INFO - 2016-09-16 10:26:43 --> Hooks Class Initialized
DEBUG - 2016-09-16 10:26:43 --> UTF-8 Support Enabled
INFO - 2016-09-16 10:26:43 --> Utf8 Class Initialized
INFO - 2016-09-16 10:26:43 --> URI Class Initialized
INFO - 2016-09-16 10:26:43 --> Router Class Initialized
INFO - 2016-09-16 10:26:43 --> Output Class Initialized
INFO - 2016-09-16 10:26:43 --> Security Class Initialized
DEBUG - 2016-09-16 10:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 10:26:43 --> Input Class Initialized
INFO - 2016-09-16 10:26:43 --> Language Class Initialized
INFO - 2016-09-16 10:26:43 --> Language Class Initialized
INFO - 2016-09-16 10:26:44 --> Config Class Initialized
INFO - 2016-09-16 10:26:44 --> Loader Class Initialized
INFO - 2016-09-16 10:26:44 --> Helper loaded: url_helper
INFO - 2016-09-16 10:26:44 --> Database Driver Class Initialized
INFO - 2016-09-16 10:26:44 --> Controller Class Initialized
DEBUG - 2016-09-16 10:26:44 --> Index MX_Controller Initialized
INFO - 2016-09-16 10:26:44 --> Model Class Initialized
INFO - 2016-09-16 10:26:44 --> Model Class Initialized
INFO - 2016-09-16 10:26:44 --> Final output sent to browser
DEBUG - 2016-09-16 10:26:44 --> Total execution time: 0.4466
INFO - 2016-09-16 10:26:44 --> Config Class Initialized
INFO - 2016-09-16 10:26:44 --> Hooks Class Initialized
DEBUG - 2016-09-16 10:26:44 --> UTF-8 Support Enabled
INFO - 2016-09-16 10:26:44 --> Utf8 Class Initialized
INFO - 2016-09-16 10:26:44 --> URI Class Initialized
INFO - 2016-09-16 10:26:44 --> Router Class Initialized
INFO - 2016-09-16 10:26:44 --> Output Class Initialized
INFO - 2016-09-16 10:26:44 --> Security Class Initialized
DEBUG - 2016-09-16 10:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 10:26:44 --> Input Class Initialized
INFO - 2016-09-16 10:26:44 --> Language Class Initialized
INFO - 2016-09-16 10:26:44 --> Language Class Initialized
INFO - 2016-09-16 10:26:44 --> Config Class Initialized
INFO - 2016-09-16 10:26:44 --> Loader Class Initialized
INFO - 2016-09-16 10:26:44 --> Helper loaded: url_helper
INFO - 2016-09-16 10:26:44 --> Database Driver Class Initialized
INFO - 2016-09-16 10:26:44 --> Controller Class Initialized
DEBUG - 2016-09-16 10:26:44 --> Index MX_Controller Initialized
INFO - 2016-09-16 10:26:44 --> Model Class Initialized
INFO - 2016-09-16 10:26:45 --> Model Class Initialized
DEBUG - 2016-09-16 10:26:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-16 10:26:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-16 10:26:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-16 10:26:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-16 10:26:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-16 10:26:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-16 10:26:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-16 10:26:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-16 10:26:45 --> Final output sent to browser
DEBUG - 2016-09-16 10:26:45 --> Total execution time: 0.5466
INFO - 2016-09-16 10:27:02 --> Config Class Initialized
INFO - 2016-09-16 10:27:02 --> Hooks Class Initialized
DEBUG - 2016-09-16 10:27:02 --> UTF-8 Support Enabled
INFO - 2016-09-16 10:27:02 --> Utf8 Class Initialized
INFO - 2016-09-16 10:27:02 --> URI Class Initialized
INFO - 2016-09-16 10:27:02 --> Router Class Initialized
INFO - 2016-09-16 10:27:02 --> Output Class Initialized
INFO - 2016-09-16 10:27:02 --> Security Class Initialized
DEBUG - 2016-09-16 10:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 10:27:02 --> Input Class Initialized
INFO - 2016-09-16 10:27:02 --> Language Class Initialized
INFO - 2016-09-16 10:27:02 --> Language Class Initialized
INFO - 2016-09-16 10:27:02 --> Config Class Initialized
INFO - 2016-09-16 10:27:02 --> Loader Class Initialized
INFO - 2016-09-16 10:27:02 --> Helper loaded: url_helper
INFO - 2016-09-16 10:27:02 --> Database Driver Class Initialized
INFO - 2016-09-16 10:27:02 --> Controller Class Initialized
DEBUG - 2016-09-16 10:27:02 --> Index MX_Controller Initialized
INFO - 2016-09-16 10:27:02 --> Model Class Initialized
INFO - 2016-09-16 10:27:02 --> Model Class Initialized
DEBUG - 2016-09-16 10:27:03 --> Anggota MX_Controller Initialized
INFO - 2016-09-16 10:27:03 --> Database Driver Class Initialized
INFO - 2016-09-16 10:27:03 --> Final output sent to browser
DEBUG - 2016-09-16 10:27:03 --> Total execution time: 0.5999
INFO - 2016-09-16 10:27:04 --> Config Class Initialized
INFO - 2016-09-16 10:27:04 --> Hooks Class Initialized
DEBUG - 2016-09-16 10:27:04 --> UTF-8 Support Enabled
INFO - 2016-09-16 10:27:04 --> Utf8 Class Initialized
INFO - 2016-09-16 10:27:04 --> URI Class Initialized
INFO - 2016-09-16 10:27:04 --> Router Class Initialized
INFO - 2016-09-16 10:27:04 --> Output Class Initialized
INFO - 2016-09-16 10:27:04 --> Security Class Initialized
DEBUG - 2016-09-16 10:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 10:27:04 --> Input Class Initialized
INFO - 2016-09-16 10:27:04 --> Language Class Initialized
INFO - 2016-09-16 10:27:04 --> Language Class Initialized
INFO - 2016-09-16 10:27:04 --> Config Class Initialized
INFO - 2016-09-16 10:27:04 --> Loader Class Initialized
INFO - 2016-09-16 10:27:04 --> Helper loaded: url_helper
INFO - 2016-09-16 10:27:04 --> Database Driver Class Initialized
INFO - 2016-09-16 10:27:04 --> Controller Class Initialized
DEBUG - 2016-09-16 10:27:04 --> Index MX_Controller Initialized
INFO - 2016-09-16 10:27:04 --> Model Class Initialized
INFO - 2016-09-16 10:27:04 --> Model Class Initialized
DEBUG - 2016-09-16 10:27:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-16 10:27:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-16 10:27:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-16 10:27:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_umum.php
DEBUG - 2016-09-16 10:27:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-16 10:27:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-16 10:27:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-16 10:27:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-16 10:27:04 --> Final output sent to browser
DEBUG - 2016-09-16 10:27:05 --> Total execution time: 0.6698
INFO - 2016-09-16 10:27:38 --> Config Class Initialized
INFO - 2016-09-16 10:27:38 --> Hooks Class Initialized
DEBUG - 2016-09-16 10:27:38 --> UTF-8 Support Enabled
INFO - 2016-09-16 10:27:38 --> Utf8 Class Initialized
INFO - 2016-09-16 10:27:38 --> URI Class Initialized
INFO - 2016-09-16 10:27:38 --> Router Class Initialized
INFO - 2016-09-16 10:27:38 --> Output Class Initialized
INFO - 2016-09-16 10:27:38 --> Security Class Initialized
DEBUG - 2016-09-16 10:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 10:27:38 --> Input Class Initialized
INFO - 2016-09-16 10:27:38 --> Language Class Initialized
INFO - 2016-09-16 10:27:38 --> Language Class Initialized
INFO - 2016-09-16 10:27:38 --> Config Class Initialized
INFO - 2016-09-16 10:27:38 --> Loader Class Initialized
INFO - 2016-09-16 10:27:38 --> Helper loaded: url_helper
INFO - 2016-09-16 10:27:38 --> Database Driver Class Initialized
INFO - 2016-09-16 10:27:38 --> Controller Class Initialized
DEBUG - 2016-09-16 10:27:38 --> Index MX_Controller Initialized
INFO - 2016-09-16 10:27:38 --> Model Class Initialized
INFO - 2016-09-16 10:27:38 --> Model Class Initialized
INFO - 2016-09-16 10:27:39 --> Database Driver Class Initialized
INFO - 2016-09-16 10:27:39 --> Final output sent to browser
DEBUG - 2016-09-16 10:27:39 --> Total execution time: 0.6099
INFO - 2016-09-16 10:28:27 --> Config Class Initialized
INFO - 2016-09-16 10:28:27 --> Hooks Class Initialized
DEBUG - 2016-09-16 10:28:27 --> UTF-8 Support Enabled
INFO - 2016-09-16 10:28:27 --> Utf8 Class Initialized
INFO - 2016-09-16 10:28:27 --> URI Class Initialized
INFO - 2016-09-16 10:28:27 --> Router Class Initialized
INFO - 2016-09-16 10:28:27 --> Output Class Initialized
INFO - 2016-09-16 10:28:27 --> Security Class Initialized
DEBUG - 2016-09-16 10:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 10:28:27 --> Input Class Initialized
INFO - 2016-09-16 10:28:27 --> Language Class Initialized
INFO - 2016-09-16 10:28:27 --> Language Class Initialized
INFO - 2016-09-16 10:28:27 --> Config Class Initialized
INFO - 2016-09-16 10:28:27 --> Loader Class Initialized
INFO - 2016-09-16 10:28:27 --> Helper loaded: url_helper
INFO - 2016-09-16 10:28:27 --> Database Driver Class Initialized
INFO - 2016-09-16 10:28:27 --> Controller Class Initialized
DEBUG - 2016-09-16 10:28:27 --> Index MX_Controller Initialized
INFO - 2016-09-16 10:28:27 --> Model Class Initialized
INFO - 2016-09-16 10:28:27 --> Model Class Initialized
INFO - 2016-09-16 10:28:27 --> Final output sent to browser
DEBUG - 2016-09-16 10:28:27 --> Total execution time: 0.4579
INFO - 2016-09-16 10:28:27 --> Config Class Initialized
INFO - 2016-09-16 10:28:27 --> Hooks Class Initialized
DEBUG - 2016-09-16 10:28:27 --> UTF-8 Support Enabled
INFO - 2016-09-16 10:28:27 --> Utf8 Class Initialized
INFO - 2016-09-16 10:28:27 --> URI Class Initialized
INFO - 2016-09-16 10:28:28 --> Router Class Initialized
INFO - 2016-09-16 10:28:28 --> Output Class Initialized
INFO - 2016-09-16 10:28:28 --> Security Class Initialized
DEBUG - 2016-09-16 10:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 10:28:28 --> Input Class Initialized
INFO - 2016-09-16 10:28:28 --> Language Class Initialized
INFO - 2016-09-16 10:28:28 --> Language Class Initialized
INFO - 2016-09-16 10:28:28 --> Config Class Initialized
INFO - 2016-09-16 10:28:28 --> Loader Class Initialized
INFO - 2016-09-16 10:28:28 --> Helper loaded: url_helper
INFO - 2016-09-16 10:28:28 --> Database Driver Class Initialized
INFO - 2016-09-16 10:28:28 --> Controller Class Initialized
DEBUG - 2016-09-16 10:28:28 --> Index MX_Controller Initialized
INFO - 2016-09-16 10:28:28 --> Model Class Initialized
INFO - 2016-09-16 10:28:28 --> Model Class Initialized
DEBUG - 2016-09-16 10:28:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-16 10:28:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-16 10:28:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-16 10:28:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-16 10:28:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-16 10:28:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-16 10:28:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-16 10:28:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-16 10:28:28 --> Final output sent to browser
DEBUG - 2016-09-16 10:28:28 --> Total execution time: 0.7005
INFO - 2016-09-16 10:28:41 --> Config Class Initialized
INFO - 2016-09-16 10:28:41 --> Hooks Class Initialized
DEBUG - 2016-09-16 10:28:41 --> UTF-8 Support Enabled
INFO - 2016-09-16 10:28:41 --> Utf8 Class Initialized
INFO - 2016-09-16 10:28:41 --> URI Class Initialized
INFO - 2016-09-16 10:28:41 --> Router Class Initialized
INFO - 2016-09-16 10:28:41 --> Output Class Initialized
INFO - 2016-09-16 10:28:41 --> Security Class Initialized
DEBUG - 2016-09-16 10:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 10:28:41 --> Input Class Initialized
INFO - 2016-09-16 10:28:41 --> Language Class Initialized
INFO - 2016-09-16 10:28:41 --> Language Class Initialized
INFO - 2016-09-16 10:28:41 --> Config Class Initialized
INFO - 2016-09-16 10:28:41 --> Loader Class Initialized
INFO - 2016-09-16 10:28:41 --> Helper loaded: url_helper
INFO - 2016-09-16 10:28:41 --> Database Driver Class Initialized
INFO - 2016-09-16 10:28:41 --> Controller Class Initialized
DEBUG - 2016-09-16 10:28:41 --> Index MX_Controller Initialized
INFO - 2016-09-16 10:28:41 --> Model Class Initialized
INFO - 2016-09-16 10:28:41 --> Model Class Initialized
DEBUG - 2016-09-16 10:28:41 --> Anggota MX_Controller Initialized
INFO - 2016-09-16 10:28:41 --> Database Driver Class Initialized
INFO - 2016-09-16 10:28:41 --> Final output sent to browser
DEBUG - 2016-09-16 10:28:41 --> Total execution time: 0.5933
INFO - 2016-09-16 10:28:42 --> Config Class Initialized
INFO - 2016-09-16 10:28:42 --> Hooks Class Initialized
DEBUG - 2016-09-16 10:28:42 --> UTF-8 Support Enabled
INFO - 2016-09-16 10:28:42 --> Utf8 Class Initialized
INFO - 2016-09-16 10:28:42 --> URI Class Initialized
INFO - 2016-09-16 10:28:42 --> Router Class Initialized
INFO - 2016-09-16 10:28:42 --> Output Class Initialized
INFO - 2016-09-16 10:28:42 --> Security Class Initialized
DEBUG - 2016-09-16 10:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 10:28:42 --> Input Class Initialized
INFO - 2016-09-16 10:28:42 --> Language Class Initialized
INFO - 2016-09-16 10:28:42 --> Language Class Initialized
INFO - 2016-09-16 10:28:42 --> Config Class Initialized
INFO - 2016-09-16 10:28:42 --> Loader Class Initialized
INFO - 2016-09-16 10:28:42 --> Helper loaded: url_helper
INFO - 2016-09-16 10:28:42 --> Database Driver Class Initialized
INFO - 2016-09-16 10:28:42 --> Controller Class Initialized
DEBUG - 2016-09-16 10:28:42 --> Index MX_Controller Initialized
INFO - 2016-09-16 10:28:42 --> Model Class Initialized
INFO - 2016-09-16 10:28:42 --> Model Class Initialized
DEBUG - 2016-09-16 10:28:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-16 10:28:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-16 10:28:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-16 10:28:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_umum.php
DEBUG - 2016-09-16 10:28:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-16 10:28:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-16 10:28:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-16 10:28:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-16 10:28:43 --> Final output sent to browser
DEBUG - 2016-09-16 10:28:43 --> Total execution time: 0.6592
INFO - 2016-09-16 10:28:55 --> Config Class Initialized
INFO - 2016-09-16 10:28:55 --> Hooks Class Initialized
DEBUG - 2016-09-16 10:28:56 --> UTF-8 Support Enabled
INFO - 2016-09-16 10:28:56 --> Utf8 Class Initialized
INFO - 2016-09-16 10:28:56 --> URI Class Initialized
INFO - 2016-09-16 10:28:56 --> Router Class Initialized
INFO - 2016-09-16 10:28:56 --> Output Class Initialized
INFO - 2016-09-16 10:28:56 --> Security Class Initialized
DEBUG - 2016-09-16 10:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 10:28:56 --> Input Class Initialized
INFO - 2016-09-16 10:28:56 --> Language Class Initialized
INFO - 2016-09-16 10:28:56 --> Language Class Initialized
INFO - 2016-09-16 10:28:56 --> Config Class Initialized
INFO - 2016-09-16 10:28:56 --> Loader Class Initialized
INFO - 2016-09-16 10:28:56 --> Helper loaded: url_helper
INFO - 2016-09-16 10:28:56 --> Database Driver Class Initialized
INFO - 2016-09-16 10:28:56 --> Controller Class Initialized
DEBUG - 2016-09-16 10:28:56 --> Index MX_Controller Initialized
INFO - 2016-09-16 10:28:56 --> Model Class Initialized
INFO - 2016-09-16 10:28:56 --> Model Class Initialized
INFO - 2016-09-16 10:28:56 --> Database Driver Class Initialized
INFO - 2016-09-16 10:28:56 --> Final output sent to browser
DEBUG - 2016-09-16 10:28:56 --> Total execution time: 0.6971
INFO - 2016-09-16 10:43:47 --> Config Class Initialized
INFO - 2016-09-16 10:43:47 --> Hooks Class Initialized
DEBUG - 2016-09-16 10:43:48 --> UTF-8 Support Enabled
INFO - 2016-09-16 10:43:48 --> Utf8 Class Initialized
INFO - 2016-09-16 10:43:48 --> URI Class Initialized
INFO - 2016-09-16 10:43:48 --> Router Class Initialized
INFO - 2016-09-16 10:43:48 --> Output Class Initialized
INFO - 2016-09-16 10:43:48 --> Security Class Initialized
DEBUG - 2016-09-16 10:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 10:43:48 --> Input Class Initialized
INFO - 2016-09-16 10:43:48 --> Language Class Initialized
INFO - 2016-09-16 10:43:48 --> Language Class Initialized
INFO - 2016-09-16 10:43:48 --> Config Class Initialized
INFO - 2016-09-16 10:43:48 --> Loader Class Initialized
INFO - 2016-09-16 10:43:48 --> Helper loaded: url_helper
INFO - 2016-09-16 10:43:48 --> Database Driver Class Initialized
INFO - 2016-09-16 10:43:48 --> Controller Class Initialized
DEBUG - 2016-09-16 10:43:48 --> Index MX_Controller Initialized
INFO - 2016-09-16 10:43:48 --> Model Class Initialized
INFO - 2016-09-16 10:43:48 --> Model Class Initialized
INFO - 2016-09-16 10:43:48 --> Final output sent to browser
DEBUG - 2016-09-16 10:43:48 --> Total execution time: 0.5613
INFO - 2016-09-16 10:43:48 --> Config Class Initialized
INFO - 2016-09-16 10:43:48 --> Hooks Class Initialized
DEBUG - 2016-09-16 10:43:48 --> UTF-8 Support Enabled
INFO - 2016-09-16 10:43:48 --> Utf8 Class Initialized
INFO - 2016-09-16 10:43:48 --> URI Class Initialized
INFO - 2016-09-16 10:43:48 --> Router Class Initialized
INFO - 2016-09-16 10:43:48 --> Output Class Initialized
INFO - 2016-09-16 10:43:48 --> Security Class Initialized
DEBUG - 2016-09-16 10:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 10:43:48 --> Input Class Initialized
INFO - 2016-09-16 10:43:48 --> Language Class Initialized
INFO - 2016-09-16 10:43:48 --> Language Class Initialized
INFO - 2016-09-16 10:43:48 --> Config Class Initialized
INFO - 2016-09-16 10:43:48 --> Loader Class Initialized
INFO - 2016-09-16 10:43:48 --> Helper loaded: url_helper
INFO - 2016-09-16 10:43:48 --> Database Driver Class Initialized
INFO - 2016-09-16 10:43:49 --> Controller Class Initialized
DEBUG - 2016-09-16 10:43:49 --> Index MX_Controller Initialized
INFO - 2016-09-16 10:43:49 --> Model Class Initialized
INFO - 2016-09-16 10:43:49 --> Model Class Initialized
DEBUG - 2016-09-16 10:43:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-16 10:43:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-16 10:43:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-16 10:43:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-16 10:43:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-16 10:43:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-16 10:43:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-16 10:43:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-16 10:43:49 --> Final output sent to browser
DEBUG - 2016-09-16 10:43:49 --> Total execution time: 0.7205
INFO - 2016-09-16 10:43:53 --> Config Class Initialized
INFO - 2016-09-16 10:43:53 --> Hooks Class Initialized
DEBUG - 2016-09-16 10:43:53 --> UTF-8 Support Enabled
INFO - 2016-09-16 10:43:53 --> Utf8 Class Initialized
INFO - 2016-09-16 10:43:53 --> URI Class Initialized
INFO - 2016-09-16 10:43:53 --> Router Class Initialized
INFO - 2016-09-16 10:43:53 --> Output Class Initialized
INFO - 2016-09-16 10:43:53 --> Security Class Initialized
DEBUG - 2016-09-16 10:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 10:43:53 --> Input Class Initialized
INFO - 2016-09-16 10:43:53 --> Language Class Initialized
INFO - 2016-09-16 10:43:53 --> Language Class Initialized
INFO - 2016-09-16 10:43:53 --> Config Class Initialized
INFO - 2016-09-16 10:43:53 --> Loader Class Initialized
INFO - 2016-09-16 10:43:53 --> Helper loaded: url_helper
INFO - 2016-09-16 10:43:53 --> Database Driver Class Initialized
INFO - 2016-09-16 10:43:53 --> Controller Class Initialized
DEBUG - 2016-09-16 10:43:53 --> Index MX_Controller Initialized
INFO - 2016-09-16 10:43:53 --> Model Class Initialized
INFO - 2016-09-16 10:43:53 --> Model Class Initialized
DEBUG - 2016-09-16 10:43:53 --> Anggota MX_Controller Initialized
INFO - 2016-09-16 10:43:53 --> Database Driver Class Initialized
INFO - 2016-09-16 10:43:53 --> Final output sent to browser
DEBUG - 2016-09-16 10:43:53 --> Total execution time: 0.5846
INFO - 2016-09-16 10:43:55 --> Config Class Initialized
INFO - 2016-09-16 10:43:55 --> Hooks Class Initialized
DEBUG - 2016-09-16 10:43:55 --> UTF-8 Support Enabled
INFO - 2016-09-16 10:43:55 --> Utf8 Class Initialized
INFO - 2016-09-16 10:43:55 --> URI Class Initialized
INFO - 2016-09-16 10:43:55 --> Router Class Initialized
INFO - 2016-09-16 10:43:55 --> Output Class Initialized
INFO - 2016-09-16 10:43:55 --> Security Class Initialized
DEBUG - 2016-09-16 10:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 10:43:55 --> Input Class Initialized
INFO - 2016-09-16 10:43:55 --> Language Class Initialized
INFO - 2016-09-16 10:43:55 --> Language Class Initialized
INFO - 2016-09-16 10:43:55 --> Config Class Initialized
INFO - 2016-09-16 10:43:55 --> Loader Class Initialized
INFO - 2016-09-16 10:43:55 --> Helper loaded: url_helper
INFO - 2016-09-16 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-16 10:43:55 --> Controller Class Initialized
DEBUG - 2016-09-16 10:43:55 --> Index MX_Controller Initialized
INFO - 2016-09-16 10:43:55 --> Model Class Initialized
INFO - 2016-09-16 10:43:55 --> Model Class Initialized
DEBUG - 2016-09-16 10:43:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-16 10:43:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-16 10:43:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-16 10:43:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_umum.php
DEBUG - 2016-09-16 10:43:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-16 10:43:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-16 10:43:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-16 10:43:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-16 10:43:55 --> Final output sent to browser
DEBUG - 2016-09-16 10:43:55 --> Total execution time: 0.6516
INFO - 2016-09-16 10:44:36 --> Config Class Initialized
INFO - 2016-09-16 10:44:36 --> Hooks Class Initialized
DEBUG - 2016-09-16 10:44:36 --> UTF-8 Support Enabled
INFO - 2016-09-16 10:44:36 --> Utf8 Class Initialized
INFO - 2016-09-16 10:44:36 --> URI Class Initialized
INFO - 2016-09-16 10:44:36 --> Router Class Initialized
INFO - 2016-09-16 10:44:36 --> Output Class Initialized
INFO - 2016-09-16 10:44:36 --> Security Class Initialized
DEBUG - 2016-09-16 10:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 10:44:36 --> Input Class Initialized
INFO - 2016-09-16 10:44:36 --> Language Class Initialized
INFO - 2016-09-16 10:44:36 --> Language Class Initialized
INFO - 2016-09-16 10:44:36 --> Config Class Initialized
INFO - 2016-09-16 10:44:36 --> Loader Class Initialized
INFO - 2016-09-16 10:44:36 --> Helper loaded: url_helper
INFO - 2016-09-16 10:44:37 --> Database Driver Class Initialized
INFO - 2016-09-16 10:44:37 --> Controller Class Initialized
DEBUG - 2016-09-16 10:44:37 --> Index MX_Controller Initialized
INFO - 2016-09-16 10:44:37 --> Model Class Initialized
INFO - 2016-09-16 10:44:37 --> Model Class Initialized
INFO - 2016-09-16 10:44:37 --> Database Driver Class Initialized
INFO - 2016-09-16 10:44:37 --> Final output sent to browser
DEBUG - 2016-09-16 10:44:37 --> Total execution time: 0.6239
INFO - 2016-09-16 10:44:45 --> Config Class Initialized
INFO - 2016-09-16 10:44:45 --> Hooks Class Initialized
DEBUG - 2016-09-16 10:44:46 --> UTF-8 Support Enabled
INFO - 2016-09-16 10:44:46 --> Utf8 Class Initialized
INFO - 2016-09-16 10:44:46 --> URI Class Initialized
INFO - 2016-09-16 10:44:46 --> Router Class Initialized
INFO - 2016-09-16 10:44:46 --> Output Class Initialized
INFO - 2016-09-16 10:44:46 --> Security Class Initialized
DEBUG - 2016-09-16 10:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 10:44:46 --> Input Class Initialized
INFO - 2016-09-16 10:44:46 --> Language Class Initialized
INFO - 2016-09-16 10:44:46 --> Language Class Initialized
INFO - 2016-09-16 10:44:46 --> Config Class Initialized
INFO - 2016-09-16 10:44:46 --> Loader Class Initialized
INFO - 2016-09-16 10:44:46 --> Helper loaded: url_helper
INFO - 2016-09-16 10:44:46 --> Database Driver Class Initialized
INFO - 2016-09-16 10:44:46 --> Controller Class Initialized
DEBUG - 2016-09-16 10:44:46 --> Index MX_Controller Initialized
INFO - 2016-09-16 10:44:46 --> Model Class Initialized
INFO - 2016-09-16 10:44:46 --> Model Class Initialized
INFO - 2016-09-16 10:44:46 --> Database Driver Class Initialized
INFO - 2016-09-16 10:44:46 --> Final output sent to browser
DEBUG - 2016-09-16 10:44:46 --> Total execution time: 0.4790
INFO - 2016-09-16 10:44:51 --> Config Class Initialized
INFO - 2016-09-16 10:44:51 --> Hooks Class Initialized
DEBUG - 2016-09-16 10:44:51 --> UTF-8 Support Enabled
INFO - 2016-09-16 10:44:51 --> Utf8 Class Initialized
INFO - 2016-09-16 10:44:51 --> URI Class Initialized
INFO - 2016-09-16 10:44:51 --> Router Class Initialized
INFO - 2016-09-16 10:44:51 --> Output Class Initialized
INFO - 2016-09-16 10:44:51 --> Security Class Initialized
DEBUG - 2016-09-16 10:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 10:44:52 --> Input Class Initialized
INFO - 2016-09-16 10:44:52 --> Language Class Initialized
INFO - 2016-09-16 10:44:52 --> Language Class Initialized
INFO - 2016-09-16 10:44:52 --> Config Class Initialized
INFO - 2016-09-16 10:44:52 --> Loader Class Initialized
INFO - 2016-09-16 10:44:52 --> Helper loaded: url_helper
INFO - 2016-09-16 10:44:52 --> Database Driver Class Initialized
INFO - 2016-09-16 10:44:52 --> Controller Class Initialized
DEBUG - 2016-09-16 10:44:52 --> Index MX_Controller Initialized
INFO - 2016-09-16 10:44:52 --> Model Class Initialized
INFO - 2016-09-16 10:44:52 --> Model Class Initialized
INFO - 2016-09-16 10:44:52 --> Database Driver Class Initialized
INFO - 2016-09-16 10:44:52 --> Database Driver Class Initialized
ERROR - 2016-09-16 10:44:52 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`koperasi`.`tt_jurnal_umum`, CONSTRAINT `FK__tm_akun` FOREIGN KEY (`kd_akun`) REFERENCES `tm_akun` (`kode_akun`)) - Invalid query: INSERT INTO `tt_jurnal_umum` (`kd_akun`, `kd_transaksi`, `kd_angsuran`, `keterangan`, `debet`, `kredit`) VALUES ('10.0.1', '33', 0, 'Pinjaman VIvi Atika Unnisyah', '20000000', 0)
INFO - 2016-09-16 10:44:52 --> Language file loaded: language/english/db_lang.php
INFO - 2016-09-16 10:45:06 --> Config Class Initialized
INFO - 2016-09-16 10:45:06 --> Hooks Class Initialized
DEBUG - 2016-09-16 10:45:06 --> UTF-8 Support Enabled
INFO - 2016-09-16 10:45:06 --> Utf8 Class Initialized
INFO - 2016-09-16 10:45:06 --> URI Class Initialized
INFO - 2016-09-16 10:45:06 --> Router Class Initialized
INFO - 2016-09-16 10:45:06 --> Output Class Initialized
INFO - 2016-09-16 10:45:06 --> Security Class Initialized
DEBUG - 2016-09-16 10:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 10:45:06 --> Input Class Initialized
INFO - 2016-09-16 10:45:06 --> Language Class Initialized
INFO - 2016-09-16 10:45:06 --> Language Class Initialized
INFO - 2016-09-16 10:45:06 --> Config Class Initialized
INFO - 2016-09-16 10:45:06 --> Loader Class Initialized
INFO - 2016-09-16 10:45:06 --> Helper loaded: url_helper
INFO - 2016-09-16 10:45:06 --> Database Driver Class Initialized
INFO - 2016-09-16 10:45:06 --> Controller Class Initialized
DEBUG - 2016-09-16 10:45:06 --> Index MX_Controller Initialized
INFO - 2016-09-16 10:45:06 --> Model Class Initialized
INFO - 2016-09-16 10:45:06 --> Model Class Initialized
INFO - 2016-09-16 10:45:06 --> Database Driver Class Initialized
INFO - 2016-09-16 10:45:06 --> Database Driver Class Initialized
ERROR - 2016-09-16 10:45:07 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`koperasi`.`tt_jurnal_umum`, CONSTRAINT `FK__tm_akun` FOREIGN KEY (`kd_akun`) REFERENCES `tm_akun` (`kode_akun`)) - Invalid query: INSERT INTO `tt_jurnal_umum` (`kd_akun`, `kd_transaksi`, `kd_angsuran`, `keterangan`, `debet`, `kredit`) VALUES ('10.0.1', '33', 0, 'Pinjaman VIvi Atika Unnisyah', '20000000', 0)
INFO - 2016-09-16 10:45:07 --> Language file loaded: language/english/db_lang.php
INFO - 2016-09-16 10:46:26 --> Config Class Initialized
INFO - 2016-09-16 10:46:26 --> Hooks Class Initialized
DEBUG - 2016-09-16 10:46:26 --> UTF-8 Support Enabled
INFO - 2016-09-16 10:46:27 --> Utf8 Class Initialized
INFO - 2016-09-16 10:46:27 --> URI Class Initialized
INFO - 2016-09-16 10:46:27 --> Router Class Initialized
INFO - 2016-09-16 10:46:27 --> Output Class Initialized
INFO - 2016-09-16 10:46:27 --> Security Class Initialized
DEBUG - 2016-09-16 10:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 10:46:27 --> Input Class Initialized
INFO - 2016-09-16 10:46:27 --> Language Class Initialized
INFO - 2016-09-16 10:46:27 --> Language Class Initialized
INFO - 2016-09-16 10:46:27 --> Config Class Initialized
INFO - 2016-09-16 10:46:27 --> Loader Class Initialized
INFO - 2016-09-16 10:46:27 --> Helper loaded: url_helper
INFO - 2016-09-16 10:46:27 --> Database Driver Class Initialized
INFO - 2016-09-16 10:46:27 --> Controller Class Initialized
DEBUG - 2016-09-16 10:46:27 --> Index MX_Controller Initialized
INFO - 2016-09-16 10:46:27 --> Model Class Initialized
INFO - 2016-09-16 10:46:27 --> Model Class Initialized
INFO - 2016-09-16 10:46:27 --> Database Driver Class Initialized
INFO - 2016-09-16 10:46:27 --> Database Driver Class Initialized
INFO - 2016-09-16 10:46:27 --> Final output sent to browser
DEBUG - 2016-09-16 10:46:27 --> Total execution time: 0.6460
INFO - 2016-09-16 10:54:54 --> Config Class Initialized
INFO - 2016-09-16 10:54:54 --> Hooks Class Initialized
DEBUG - 2016-09-16 10:54:54 --> UTF-8 Support Enabled
INFO - 2016-09-16 10:54:54 --> Utf8 Class Initialized
INFO - 2016-09-16 10:54:54 --> URI Class Initialized
INFO - 2016-09-16 10:54:54 --> Router Class Initialized
INFO - 2016-09-16 10:54:54 --> Output Class Initialized
INFO - 2016-09-16 10:54:54 --> Security Class Initialized
DEBUG - 2016-09-16 10:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 10:54:55 --> Input Class Initialized
INFO - 2016-09-16 10:54:55 --> Language Class Initialized
INFO - 2016-09-16 10:54:55 --> Language Class Initialized
INFO - 2016-09-16 10:54:55 --> Config Class Initialized
INFO - 2016-09-16 10:54:55 --> Loader Class Initialized
INFO - 2016-09-16 10:54:55 --> Helper loaded: url_helper
INFO - 2016-09-16 10:54:55 --> Database Driver Class Initialized
INFO - 2016-09-16 10:54:55 --> Controller Class Initialized
DEBUG - 2016-09-16 10:54:55 --> Index MX_Controller Initialized
INFO - 2016-09-16 10:54:55 --> Model Class Initialized
INFO - 2016-09-16 10:54:55 --> Model Class Initialized
DEBUG - 2016-09-16 10:54:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-16 10:54:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-16 10:54:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-16 10:54:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_bayar_angsuran.php
DEBUG - 2016-09-16 10:54:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-16 10:54:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-16 10:54:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-16 10:54:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-16 10:54:55 --> Final output sent to browser
DEBUG - 2016-09-16 10:54:55 --> Total execution time: 0.6329
INFO - 2016-09-16 10:54:58 --> Config Class Initialized
INFO - 2016-09-16 10:54:58 --> Hooks Class Initialized
DEBUG - 2016-09-16 10:54:58 --> UTF-8 Support Enabled
INFO - 2016-09-16 10:54:58 --> Utf8 Class Initialized
INFO - 2016-09-16 10:54:58 --> URI Class Initialized
INFO - 2016-09-16 10:54:59 --> Router Class Initialized
INFO - 2016-09-16 10:54:59 --> Output Class Initialized
INFO - 2016-09-16 10:54:59 --> Security Class Initialized
DEBUG - 2016-09-16 10:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 10:54:59 --> Input Class Initialized
INFO - 2016-09-16 10:54:59 --> Language Class Initialized
INFO - 2016-09-16 10:54:59 --> Language Class Initialized
INFO - 2016-09-16 10:54:59 --> Config Class Initialized
INFO - 2016-09-16 10:54:59 --> Loader Class Initialized
INFO - 2016-09-16 10:54:59 --> Helper loaded: url_helper
INFO - 2016-09-16 10:54:59 --> Database Driver Class Initialized
INFO - 2016-09-16 10:54:59 --> Controller Class Initialized
DEBUG - 2016-09-16 10:54:59 --> Index MX_Controller Initialized
INFO - 2016-09-16 10:54:59 --> Model Class Initialized
INFO - 2016-09-16 10:54:59 --> Model Class Initialized
INFO - 2016-09-16 10:54:59 --> Database Driver Class Initialized
INFO - 2016-09-16 10:54:59 --> Final output sent to browser
DEBUG - 2016-09-16 10:54:59 --> Total execution time: 0.5448
INFO - 2016-09-16 10:55:07 --> Config Class Initialized
INFO - 2016-09-16 10:55:07 --> Hooks Class Initialized
DEBUG - 2016-09-16 10:55:07 --> UTF-8 Support Enabled
INFO - 2016-09-16 10:55:07 --> Utf8 Class Initialized
INFO - 2016-09-16 10:55:07 --> URI Class Initialized
INFO - 2016-09-16 10:55:07 --> Router Class Initialized
INFO - 2016-09-16 10:55:07 --> Output Class Initialized
INFO - 2016-09-16 10:55:07 --> Security Class Initialized
DEBUG - 2016-09-16 10:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 10:55:08 --> Input Class Initialized
INFO - 2016-09-16 10:55:08 --> Language Class Initialized
INFO - 2016-09-16 10:55:08 --> Language Class Initialized
INFO - 2016-09-16 10:55:08 --> Config Class Initialized
INFO - 2016-09-16 10:55:08 --> Loader Class Initialized
INFO - 2016-09-16 10:55:08 --> Helper loaded: url_helper
INFO - 2016-09-16 10:55:08 --> Database Driver Class Initialized
INFO - 2016-09-16 10:55:08 --> Controller Class Initialized
DEBUG - 2016-09-16 10:55:08 --> Index MX_Controller Initialized
INFO - 2016-09-16 10:55:08 --> Model Class Initialized
INFO - 2016-09-16 10:55:08 --> Model Class Initialized
INFO - 2016-09-16 10:55:08 --> Database Driver Class Initialized
INFO - 2016-09-16 10:55:08 --> Database Driver Class Initialized
ERROR - 2016-09-16 10:55:08 --> Severity: Notice --> Undefined index: ke E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 339
INFO - 2016-09-16 10:55:08 --> Database Driver Class Initialized
ERROR - 2016-09-16 10:55:08 --> Severity: Notice --> Undefined index: ke E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 349
INFO - 2016-09-16 10:55:08 --> Database Driver Class Initialized
INFO - 2016-09-16 10:55:08 --> Final output sent to browser
DEBUG - 2016-09-16 10:55:08 --> Total execution time: 0.7906
INFO - 2016-09-16 10:55:19 --> Config Class Initialized
INFO - 2016-09-16 10:55:19 --> Hooks Class Initialized
DEBUG - 2016-09-16 10:55:19 --> UTF-8 Support Enabled
INFO - 2016-09-16 10:55:19 --> Utf8 Class Initialized
INFO - 2016-09-16 10:55:19 --> URI Class Initialized
INFO - 2016-09-16 10:55:19 --> Router Class Initialized
INFO - 2016-09-16 10:55:19 --> Output Class Initialized
INFO - 2016-09-16 10:55:19 --> Security Class Initialized
DEBUG - 2016-09-16 10:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 10:55:19 --> Input Class Initialized
INFO - 2016-09-16 10:55:19 --> Language Class Initialized
INFO - 2016-09-16 10:55:19 --> Language Class Initialized
INFO - 2016-09-16 10:55:19 --> Config Class Initialized
INFO - 2016-09-16 10:55:19 --> Loader Class Initialized
INFO - 2016-09-16 10:55:19 --> Helper loaded: url_helper
INFO - 2016-09-16 10:55:19 --> Database Driver Class Initialized
INFO - 2016-09-16 10:55:19 --> Controller Class Initialized
DEBUG - 2016-09-16 10:55:19 --> Index MX_Controller Initialized
INFO - 2016-09-16 10:55:19 --> Model Class Initialized
INFO - 2016-09-16 10:55:19 --> Model Class Initialized
INFO - 2016-09-16 10:55:19 --> Database Driver Class Initialized
INFO - 2016-09-16 10:55:19 --> Database Driver Class Initialized
ERROR - 2016-09-16 10:55:19 --> Severity: Notice --> Undefined index: ke E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 339
INFO - 2016-09-16 10:55:19 --> Database Driver Class Initialized
ERROR - 2016-09-16 10:55:19 --> Severity: Notice --> Undefined index: ke E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 349
INFO - 2016-09-16 10:55:20 --> Database Driver Class Initialized
INFO - 2016-09-16 10:55:20 --> Final output sent to browser
DEBUG - 2016-09-16 10:55:20 --> Total execution time: 0.9298
INFO - 2016-09-16 10:55:53 --> Config Class Initialized
INFO - 2016-09-16 10:55:53 --> Hooks Class Initialized
DEBUG - 2016-09-16 10:55:53 --> UTF-8 Support Enabled
INFO - 2016-09-16 10:55:53 --> Utf8 Class Initialized
INFO - 2016-09-16 10:55:53 --> URI Class Initialized
INFO - 2016-09-16 10:55:53 --> Router Class Initialized
INFO - 2016-09-16 10:55:53 --> Output Class Initialized
INFO - 2016-09-16 10:55:53 --> Security Class Initialized
DEBUG - 2016-09-16 10:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 10:55:53 --> Input Class Initialized
INFO - 2016-09-16 10:55:53 --> Language Class Initialized
INFO - 2016-09-16 10:55:53 --> Language Class Initialized
INFO - 2016-09-16 10:55:53 --> Config Class Initialized
INFO - 2016-09-16 10:55:53 --> Loader Class Initialized
INFO - 2016-09-16 10:55:53 --> Helper loaded: url_helper
INFO - 2016-09-16 10:55:53 --> Database Driver Class Initialized
INFO - 2016-09-16 10:55:53 --> Controller Class Initialized
DEBUG - 2016-09-16 10:55:53 --> Index MX_Controller Initialized
INFO - 2016-09-16 10:55:53 --> Model Class Initialized
INFO - 2016-09-16 10:55:53 --> Model Class Initialized
INFO - 2016-09-16 10:55:53 --> Database Driver Class Initialized
INFO - 2016-09-16 10:55:53 --> Database Driver Class Initialized
INFO - 2016-09-16 10:55:53 --> Database Driver Class Initialized
INFO - 2016-09-16 10:55:54 --> Database Driver Class Initialized
INFO - 2016-09-16 10:55:54 --> Final output sent to browser
DEBUG - 2016-09-16 10:55:54 --> Total execution time: 0.7626
INFO - 2016-09-16 10:56:20 --> Config Class Initialized
INFO - 2016-09-16 10:56:20 --> Hooks Class Initialized
DEBUG - 2016-09-16 10:56:20 --> UTF-8 Support Enabled
INFO - 2016-09-16 10:56:20 --> Utf8 Class Initialized
INFO - 2016-09-16 10:56:20 --> URI Class Initialized
INFO - 2016-09-16 10:56:21 --> Router Class Initialized
INFO - 2016-09-16 10:56:21 --> Output Class Initialized
INFO - 2016-09-16 10:56:21 --> Security Class Initialized
DEBUG - 2016-09-16 10:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 10:56:21 --> Input Class Initialized
INFO - 2016-09-16 10:56:21 --> Language Class Initialized
INFO - 2016-09-16 10:56:21 --> Language Class Initialized
INFO - 2016-09-16 10:56:21 --> Config Class Initialized
INFO - 2016-09-16 10:56:21 --> Loader Class Initialized
INFO - 2016-09-16 10:56:21 --> Helper loaded: url_helper
INFO - 2016-09-16 10:56:21 --> Database Driver Class Initialized
INFO - 2016-09-16 10:56:21 --> Controller Class Initialized
DEBUG - 2016-09-16 10:56:21 --> Index MX_Controller Initialized
INFO - 2016-09-16 10:56:21 --> Model Class Initialized
INFO - 2016-09-16 10:56:21 --> Model Class Initialized
INFO - 2016-09-16 10:56:21 --> Database Driver Class Initialized
INFO - 2016-09-16 10:56:21 --> Final output sent to browser
DEBUG - 2016-09-16 10:56:21 --> Total execution time: 0.5188
INFO - 2016-09-16 10:56:45 --> Config Class Initialized
INFO - 2016-09-16 10:56:45 --> Hooks Class Initialized
DEBUG - 2016-09-16 10:56:45 --> UTF-8 Support Enabled
INFO - 2016-09-16 10:56:45 --> Utf8 Class Initialized
INFO - 2016-09-16 10:56:45 --> URI Class Initialized
INFO - 2016-09-16 10:56:45 --> Router Class Initialized
INFO - 2016-09-16 10:56:45 --> Output Class Initialized
INFO - 2016-09-16 10:56:45 --> Security Class Initialized
DEBUG - 2016-09-16 10:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 10:56:45 --> Input Class Initialized
INFO - 2016-09-16 10:56:45 --> Language Class Initialized
INFO - 2016-09-16 10:56:45 --> Language Class Initialized
INFO - 2016-09-16 10:56:45 --> Config Class Initialized
INFO - 2016-09-16 10:56:45 --> Loader Class Initialized
INFO - 2016-09-16 10:56:45 --> Helper loaded: url_helper
INFO - 2016-09-16 10:56:45 --> Database Driver Class Initialized
INFO - 2016-09-16 10:56:45 --> Controller Class Initialized
DEBUG - 2016-09-16 10:56:45 --> Index MX_Controller Initialized
INFO - 2016-09-16 10:56:45 --> Model Class Initialized
INFO - 2016-09-16 10:56:45 --> Model Class Initialized
INFO - 2016-09-16 10:56:45 --> Database Driver Class Initialized
INFO - 2016-09-16 10:56:45 --> Final output sent to browser
DEBUG - 2016-09-16 10:56:45 --> Total execution time: 0.5545
INFO - 2016-09-16 10:57:03 --> Config Class Initialized
INFO - 2016-09-16 10:57:03 --> Hooks Class Initialized
DEBUG - 2016-09-16 10:57:03 --> UTF-8 Support Enabled
INFO - 2016-09-16 10:57:03 --> Utf8 Class Initialized
INFO - 2016-09-16 10:57:03 --> URI Class Initialized
INFO - 2016-09-16 10:57:03 --> Router Class Initialized
INFO - 2016-09-16 10:57:03 --> Output Class Initialized
INFO - 2016-09-16 10:57:03 --> Security Class Initialized
DEBUG - 2016-09-16 10:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 10:57:03 --> Input Class Initialized
INFO - 2016-09-16 10:57:03 --> Language Class Initialized
INFO - 2016-09-16 10:57:03 --> Language Class Initialized
INFO - 2016-09-16 10:57:03 --> Config Class Initialized
INFO - 2016-09-16 10:57:03 --> Loader Class Initialized
INFO - 2016-09-16 10:57:03 --> Helper loaded: url_helper
INFO - 2016-09-16 10:57:03 --> Database Driver Class Initialized
INFO - 2016-09-16 10:57:03 --> Controller Class Initialized
DEBUG - 2016-09-16 10:57:03 --> Index MX_Controller Initialized
INFO - 2016-09-16 10:57:03 --> Model Class Initialized
INFO - 2016-09-16 10:57:03 --> Model Class Initialized
INFO - 2016-09-16 10:57:03 --> Database Driver Class Initialized
INFO - 2016-09-16 10:57:03 --> Database Driver Class Initialized
INFO - 2016-09-16 10:57:03 --> Database Driver Class Initialized
INFO - 2016-09-16 10:57:03 --> Database Driver Class Initialized
INFO - 2016-09-16 10:57:03 --> Final output sent to browser
DEBUG - 2016-09-16 10:57:03 --> Total execution time: 0.7176
INFO - 2016-09-16 10:57:25 --> Config Class Initialized
INFO - 2016-09-16 10:57:25 --> Hooks Class Initialized
DEBUG - 2016-09-16 10:57:25 --> UTF-8 Support Enabled
INFO - 2016-09-16 10:57:25 --> Utf8 Class Initialized
INFO - 2016-09-16 10:57:25 --> URI Class Initialized
INFO - 2016-09-16 10:57:25 --> Router Class Initialized
INFO - 2016-09-16 10:57:25 --> Output Class Initialized
INFO - 2016-09-16 10:57:25 --> Security Class Initialized
DEBUG - 2016-09-16 10:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 10:57:25 --> Input Class Initialized
INFO - 2016-09-16 10:57:25 --> Language Class Initialized
INFO - 2016-09-16 10:57:25 --> Language Class Initialized
INFO - 2016-09-16 10:57:25 --> Config Class Initialized
INFO - 2016-09-16 10:57:25 --> Loader Class Initialized
INFO - 2016-09-16 10:57:25 --> Helper loaded: url_helper
INFO - 2016-09-16 10:57:25 --> Database Driver Class Initialized
INFO - 2016-09-16 10:57:25 --> Controller Class Initialized
DEBUG - 2016-09-16 10:57:25 --> Index MX_Controller Initialized
INFO - 2016-09-16 10:57:25 --> Model Class Initialized
INFO - 2016-09-16 10:57:25 --> Model Class Initialized
INFO - 2016-09-16 10:57:25 --> Database Driver Class Initialized
INFO - 2016-09-16 10:57:25 --> Final output sent to browser
DEBUG - 2016-09-16 10:57:25 --> Total execution time: 0.5194
INFO - 2016-09-16 10:58:09 --> Config Class Initialized
INFO - 2016-09-16 10:58:09 --> Hooks Class Initialized
DEBUG - 2016-09-16 10:58:09 --> UTF-8 Support Enabled
INFO - 2016-09-16 10:58:09 --> Utf8 Class Initialized
INFO - 2016-09-16 10:58:09 --> URI Class Initialized
INFO - 2016-09-16 10:58:09 --> Router Class Initialized
INFO - 2016-09-16 10:58:09 --> Output Class Initialized
INFO - 2016-09-16 10:58:09 --> Security Class Initialized
DEBUG - 2016-09-16 10:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 10:58:09 --> Input Class Initialized
INFO - 2016-09-16 10:58:09 --> Language Class Initialized
INFO - 2016-09-16 10:58:09 --> Language Class Initialized
INFO - 2016-09-16 10:58:09 --> Config Class Initialized
INFO - 2016-09-16 10:58:09 --> Loader Class Initialized
INFO - 2016-09-16 10:58:09 --> Helper loaded: url_helper
INFO - 2016-09-16 10:58:09 --> Database Driver Class Initialized
INFO - 2016-09-16 10:58:09 --> Controller Class Initialized
DEBUG - 2016-09-16 10:58:09 --> Index MX_Controller Initialized
INFO - 2016-09-16 10:58:09 --> Model Class Initialized
INFO - 2016-09-16 10:58:09 --> Model Class Initialized
INFO - 2016-09-16 10:58:09 --> Database Driver Class Initialized
INFO - 2016-09-16 10:58:10 --> Database Driver Class Initialized
INFO - 2016-09-16 10:58:10 --> Database Driver Class Initialized
INFO - 2016-09-16 10:58:10 --> Database Driver Class Initialized
INFO - 2016-09-16 10:58:10 --> Final output sent to browser
DEBUG - 2016-09-16 10:58:10 --> Total execution time: 0.8048
INFO - 2016-09-16 11:04:30 --> Config Class Initialized
INFO - 2016-09-16 11:04:30 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:04:30 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:04:30 --> Utf8 Class Initialized
INFO - 2016-09-16 11:04:30 --> URI Class Initialized
INFO - 2016-09-16 11:04:30 --> Router Class Initialized
INFO - 2016-09-16 11:04:30 --> Output Class Initialized
INFO - 2016-09-16 11:04:30 --> Security Class Initialized
DEBUG - 2016-09-16 11:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:04:30 --> Input Class Initialized
INFO - 2016-09-16 11:04:30 --> Language Class Initialized
INFO - 2016-09-16 11:04:30 --> Language Class Initialized
INFO - 2016-09-16 11:04:30 --> Config Class Initialized
INFO - 2016-09-16 11:04:30 --> Loader Class Initialized
INFO - 2016-09-16 11:04:30 --> Helper loaded: url_helper
INFO - 2016-09-16 11:04:30 --> Database Driver Class Initialized
INFO - 2016-09-16 11:04:30 --> Controller Class Initialized
DEBUG - 2016-09-16 11:04:30 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:04:30 --> Model Class Initialized
INFO - 2016-09-16 11:04:30 --> Model Class Initialized
INFO - 2016-09-16 11:04:30 --> Database Driver Class Initialized
INFO - 2016-09-16 11:04:30 --> Final output sent to browser
DEBUG - 2016-09-16 11:04:30 --> Total execution time: 0.6739
INFO - 2016-09-16 11:04:37 --> Config Class Initialized
INFO - 2016-09-16 11:04:37 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:04:37 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:04:37 --> Utf8 Class Initialized
INFO - 2016-09-16 11:04:37 --> URI Class Initialized
INFO - 2016-09-16 11:04:37 --> Router Class Initialized
INFO - 2016-09-16 11:04:37 --> Output Class Initialized
INFO - 2016-09-16 11:04:37 --> Security Class Initialized
DEBUG - 2016-09-16 11:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:04:37 --> Input Class Initialized
INFO - 2016-09-16 11:04:37 --> Language Class Initialized
INFO - 2016-09-16 11:04:37 --> Language Class Initialized
INFO - 2016-09-16 11:04:37 --> Config Class Initialized
INFO - 2016-09-16 11:04:37 --> Loader Class Initialized
INFO - 2016-09-16 11:04:37 --> Helper loaded: url_helper
INFO - 2016-09-16 11:04:37 --> Database Driver Class Initialized
INFO - 2016-09-16 11:04:37 --> Controller Class Initialized
DEBUG - 2016-09-16 11:04:37 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:04:37 --> Model Class Initialized
INFO - 2016-09-16 11:04:37 --> Model Class Initialized
DEBUG - 2016-09-16 11:04:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-16 11:04:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-16 11:04:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-16 11:04:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-16 11:04:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-16 11:04:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-16 11:04:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-16 11:04:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-16 11:04:38 --> Final output sent to browser
DEBUG - 2016-09-16 11:04:38 --> Total execution time: 0.6062
INFO - 2016-09-16 11:04:42 --> Config Class Initialized
INFO - 2016-09-16 11:04:42 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:04:42 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:04:42 --> Utf8 Class Initialized
INFO - 2016-09-16 11:04:42 --> URI Class Initialized
INFO - 2016-09-16 11:04:42 --> Router Class Initialized
INFO - 2016-09-16 11:04:42 --> Output Class Initialized
INFO - 2016-09-16 11:04:42 --> Security Class Initialized
DEBUG - 2016-09-16 11:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:04:42 --> Input Class Initialized
INFO - 2016-09-16 11:04:42 --> Language Class Initialized
INFO - 2016-09-16 11:04:42 --> Language Class Initialized
INFO - 2016-09-16 11:04:42 --> Config Class Initialized
INFO - 2016-09-16 11:04:42 --> Loader Class Initialized
INFO - 2016-09-16 11:04:42 --> Helper loaded: url_helper
INFO - 2016-09-16 11:04:42 --> Database Driver Class Initialized
INFO - 2016-09-16 11:04:42 --> Controller Class Initialized
DEBUG - 2016-09-16 11:04:42 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:04:42 --> Model Class Initialized
INFO - 2016-09-16 11:04:42 --> Model Class Initialized
DEBUG - 2016-09-16 11:04:42 --> Anggota MX_Controller Initialized
INFO - 2016-09-16 11:04:43 --> Database Driver Class Initialized
INFO - 2016-09-16 11:04:43 --> Final output sent to browser
DEBUG - 2016-09-16 11:04:43 --> Total execution time: 0.6706
INFO - 2016-09-16 11:04:57 --> Config Class Initialized
INFO - 2016-09-16 11:04:57 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:04:57 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:04:57 --> Utf8 Class Initialized
INFO - 2016-09-16 11:04:57 --> URI Class Initialized
INFO - 2016-09-16 11:04:58 --> Router Class Initialized
INFO - 2016-09-16 11:04:58 --> Output Class Initialized
INFO - 2016-09-16 11:04:58 --> Security Class Initialized
DEBUG - 2016-09-16 11:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:04:58 --> Input Class Initialized
INFO - 2016-09-16 11:04:58 --> Language Class Initialized
INFO - 2016-09-16 11:04:58 --> Language Class Initialized
INFO - 2016-09-16 11:04:58 --> Config Class Initialized
INFO - 2016-09-16 11:04:58 --> Loader Class Initialized
INFO - 2016-09-16 11:04:58 --> Helper loaded: url_helper
INFO - 2016-09-16 11:04:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:04:58 --> Controller Class Initialized
DEBUG - 2016-09-16 11:04:58 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:04:58 --> Model Class Initialized
INFO - 2016-09-16 11:04:58 --> Model Class Initialized
DEBUG - 2016-09-16 11:04:58 --> Anggota MX_Controller Initialized
INFO - 2016-09-16 11:04:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:04:58 --> Final output sent to browser
DEBUG - 2016-09-16 11:04:58 --> Total execution time: 0.5686
INFO - 2016-09-16 11:04:59 --> Config Class Initialized
INFO - 2016-09-16 11:04:59 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:04:59 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:04:59 --> Utf8 Class Initialized
INFO - 2016-09-16 11:04:59 --> URI Class Initialized
INFO - 2016-09-16 11:04:59 --> Router Class Initialized
INFO - 2016-09-16 11:04:59 --> Output Class Initialized
INFO - 2016-09-16 11:04:59 --> Security Class Initialized
DEBUG - 2016-09-16 11:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:04:59 --> Input Class Initialized
INFO - 2016-09-16 11:04:59 --> Language Class Initialized
INFO - 2016-09-16 11:04:59 --> Language Class Initialized
INFO - 2016-09-16 11:04:59 --> Config Class Initialized
INFO - 2016-09-16 11:04:59 --> Loader Class Initialized
INFO - 2016-09-16 11:04:59 --> Helper loaded: url_helper
INFO - 2016-09-16 11:04:59 --> Database Driver Class Initialized
INFO - 2016-09-16 11:04:59 --> Controller Class Initialized
DEBUG - 2016-09-16 11:04:59 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:04:59 --> Model Class Initialized
INFO - 2016-09-16 11:04:59 --> Model Class Initialized
DEBUG - 2016-09-16 11:04:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-16 11:04:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-16 11:04:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-16 11:04:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_umum.php
DEBUG - 2016-09-16 11:04:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-16 11:04:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-16 11:04:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-16 11:04:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-16 11:04:59 --> Final output sent to browser
DEBUG - 2016-09-16 11:05:00 --> Total execution time: 0.6344
INFO - 2016-09-16 11:05:22 --> Config Class Initialized
INFO - 2016-09-16 11:05:22 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:05:22 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:05:22 --> Utf8 Class Initialized
INFO - 2016-09-16 11:05:22 --> URI Class Initialized
INFO - 2016-09-16 11:05:22 --> Router Class Initialized
INFO - 2016-09-16 11:05:22 --> Output Class Initialized
INFO - 2016-09-16 11:05:22 --> Security Class Initialized
DEBUG - 2016-09-16 11:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:05:22 --> Input Class Initialized
INFO - 2016-09-16 11:05:22 --> Language Class Initialized
INFO - 2016-09-16 11:05:22 --> Language Class Initialized
INFO - 2016-09-16 11:05:22 --> Config Class Initialized
INFO - 2016-09-16 11:05:22 --> Loader Class Initialized
INFO - 2016-09-16 11:05:22 --> Helper loaded: url_helper
INFO - 2016-09-16 11:05:22 --> Database Driver Class Initialized
INFO - 2016-09-16 11:05:22 --> Controller Class Initialized
DEBUG - 2016-09-16 11:05:22 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:05:22 --> Model Class Initialized
INFO - 2016-09-16 11:05:22 --> Model Class Initialized
INFO - 2016-09-16 11:05:23 --> Database Driver Class Initialized
INFO - 2016-09-16 11:05:23 --> Final output sent to browser
DEBUG - 2016-09-16 11:05:23 --> Total execution time: 0.5801
INFO - 2016-09-16 11:05:30 --> Config Class Initialized
INFO - 2016-09-16 11:05:30 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:05:30 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:05:30 --> Utf8 Class Initialized
INFO - 2016-09-16 11:05:30 --> URI Class Initialized
INFO - 2016-09-16 11:05:30 --> Router Class Initialized
INFO - 2016-09-16 11:05:30 --> Output Class Initialized
INFO - 2016-09-16 11:05:30 --> Security Class Initialized
DEBUG - 2016-09-16 11:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:05:30 --> Input Class Initialized
INFO - 2016-09-16 11:05:30 --> Language Class Initialized
INFO - 2016-09-16 11:05:30 --> Language Class Initialized
INFO - 2016-09-16 11:05:30 --> Config Class Initialized
INFO - 2016-09-16 11:05:30 --> Loader Class Initialized
INFO - 2016-09-16 11:05:30 --> Helper loaded: url_helper
INFO - 2016-09-16 11:05:30 --> Database Driver Class Initialized
INFO - 2016-09-16 11:05:30 --> Controller Class Initialized
DEBUG - 2016-09-16 11:05:30 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:05:30 --> Model Class Initialized
INFO - 2016-09-16 11:05:30 --> Model Class Initialized
INFO - 2016-09-16 11:05:30 --> Database Driver Class Initialized
INFO - 2016-09-16 11:05:30 --> Final output sent to browser
DEBUG - 2016-09-16 11:05:30 --> Total execution time: 0.6119
INFO - 2016-09-16 11:05:53 --> Config Class Initialized
INFO - 2016-09-16 11:05:53 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:05:53 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:05:53 --> Utf8 Class Initialized
INFO - 2016-09-16 11:05:53 --> URI Class Initialized
INFO - 2016-09-16 11:05:53 --> Router Class Initialized
INFO - 2016-09-16 11:05:53 --> Output Class Initialized
INFO - 2016-09-16 11:05:53 --> Security Class Initialized
DEBUG - 2016-09-16 11:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:05:53 --> Input Class Initialized
INFO - 2016-09-16 11:05:53 --> Language Class Initialized
INFO - 2016-09-16 11:05:53 --> Language Class Initialized
INFO - 2016-09-16 11:05:53 --> Config Class Initialized
INFO - 2016-09-16 11:05:53 --> Loader Class Initialized
INFO - 2016-09-16 11:05:53 --> Helper loaded: url_helper
INFO - 2016-09-16 11:05:53 --> Database Driver Class Initialized
INFO - 2016-09-16 11:05:53 --> Controller Class Initialized
DEBUG - 2016-09-16 11:05:53 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:05:53 --> Model Class Initialized
INFO - 2016-09-16 11:05:53 --> Model Class Initialized
INFO - 2016-09-16 11:05:53 --> Database Driver Class Initialized
INFO - 2016-09-16 11:05:53 --> Database Driver Class Initialized
INFO - 2016-09-16 11:05:54 --> Final output sent to browser
DEBUG - 2016-09-16 11:05:54 --> Total execution time: 0.6714
INFO - 2016-09-16 11:06:05 --> Config Class Initialized
INFO - 2016-09-16 11:06:05 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:06:05 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:06:05 --> Utf8 Class Initialized
INFO - 2016-09-16 11:06:05 --> URI Class Initialized
INFO - 2016-09-16 11:06:05 --> Router Class Initialized
INFO - 2016-09-16 11:06:05 --> Output Class Initialized
INFO - 2016-09-16 11:06:05 --> Security Class Initialized
DEBUG - 2016-09-16 11:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:06:05 --> Input Class Initialized
INFO - 2016-09-16 11:06:05 --> Language Class Initialized
INFO - 2016-09-16 11:06:05 --> Language Class Initialized
INFO - 2016-09-16 11:06:05 --> Config Class Initialized
INFO - 2016-09-16 11:06:05 --> Loader Class Initialized
INFO - 2016-09-16 11:06:05 --> Helper loaded: url_helper
INFO - 2016-09-16 11:06:05 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:05 --> Controller Class Initialized
DEBUG - 2016-09-16 11:06:05 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:06:05 --> Model Class Initialized
INFO - 2016-09-16 11:06:06 --> Model Class Initialized
DEBUG - 2016-09-16 11:06:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-16 11:06:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-16 11:06:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-16 11:06:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_bayar_angsuran.php
DEBUG - 2016-09-16 11:06:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-16 11:06:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-16 11:06:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-16 11:06:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-16 11:06:06 --> Final output sent to browser
DEBUG - 2016-09-16 11:06:06 --> Total execution time: 0.6044
INFO - 2016-09-16 11:06:09 --> Config Class Initialized
INFO - 2016-09-16 11:06:09 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:06:09 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:06:09 --> Utf8 Class Initialized
INFO - 2016-09-16 11:06:09 --> URI Class Initialized
INFO - 2016-09-16 11:06:09 --> Router Class Initialized
INFO - 2016-09-16 11:06:09 --> Output Class Initialized
INFO - 2016-09-16 11:06:09 --> Security Class Initialized
DEBUG - 2016-09-16 11:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:06:09 --> Input Class Initialized
INFO - 2016-09-16 11:06:09 --> Language Class Initialized
INFO - 2016-09-16 11:06:09 --> Language Class Initialized
INFO - 2016-09-16 11:06:09 --> Config Class Initialized
INFO - 2016-09-16 11:06:09 --> Loader Class Initialized
INFO - 2016-09-16 11:06:09 --> Helper loaded: url_helper
INFO - 2016-09-16 11:06:09 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:09 --> Controller Class Initialized
DEBUG - 2016-09-16 11:06:09 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:06:09 --> Model Class Initialized
INFO - 2016-09-16 11:06:09 --> Model Class Initialized
INFO - 2016-09-16 11:06:10 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:10 --> Final output sent to browser
DEBUG - 2016-09-16 11:06:10 --> Total execution time: 0.5685
INFO - 2016-09-16 11:06:17 --> Config Class Initialized
INFO - 2016-09-16 11:06:17 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:06:17 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:06:17 --> Utf8 Class Initialized
INFO - 2016-09-16 11:06:17 --> URI Class Initialized
INFO - 2016-09-16 11:06:17 --> Router Class Initialized
INFO - 2016-09-16 11:06:17 --> Output Class Initialized
INFO - 2016-09-16 11:06:17 --> Security Class Initialized
DEBUG - 2016-09-16 11:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:06:17 --> Input Class Initialized
INFO - 2016-09-16 11:06:17 --> Language Class Initialized
INFO - 2016-09-16 11:06:17 --> Language Class Initialized
INFO - 2016-09-16 11:06:17 --> Config Class Initialized
INFO - 2016-09-16 11:06:17 --> Loader Class Initialized
INFO - 2016-09-16 11:06:17 --> Helper loaded: url_helper
INFO - 2016-09-16 11:06:17 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:17 --> Controller Class Initialized
DEBUG - 2016-09-16 11:06:17 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:06:17 --> Model Class Initialized
INFO - 2016-09-16 11:06:17 --> Model Class Initialized
INFO - 2016-09-16 11:06:17 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:17 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:17 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:17 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:17 --> Final output sent to browser
DEBUG - 2016-09-16 11:06:17 --> Total execution time: 0.8065
INFO - 2016-09-16 11:06:20 --> Config Class Initialized
INFO - 2016-09-16 11:06:20 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:06:20 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:06:20 --> Utf8 Class Initialized
INFO - 2016-09-16 11:06:20 --> URI Class Initialized
INFO - 2016-09-16 11:06:20 --> Router Class Initialized
INFO - 2016-09-16 11:06:20 --> Output Class Initialized
INFO - 2016-09-16 11:06:20 --> Security Class Initialized
DEBUG - 2016-09-16 11:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:06:20 --> Input Class Initialized
INFO - 2016-09-16 11:06:20 --> Language Class Initialized
INFO - 2016-09-16 11:06:20 --> Language Class Initialized
INFO - 2016-09-16 11:06:20 --> Config Class Initialized
INFO - 2016-09-16 11:06:20 --> Loader Class Initialized
INFO - 2016-09-16 11:06:20 --> Helper loaded: url_helper
INFO - 2016-09-16 11:06:20 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:20 --> Controller Class Initialized
DEBUG - 2016-09-16 11:06:20 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:06:20 --> Model Class Initialized
INFO - 2016-09-16 11:06:20 --> Model Class Initialized
INFO - 2016-09-16 11:06:20 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:20 --> Final output sent to browser
DEBUG - 2016-09-16 11:06:20 --> Total execution time: 0.5321
INFO - 2016-09-16 11:06:22 --> Config Class Initialized
INFO - 2016-09-16 11:06:22 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:06:22 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:06:22 --> Utf8 Class Initialized
INFO - 2016-09-16 11:06:22 --> URI Class Initialized
INFO - 2016-09-16 11:06:22 --> Router Class Initialized
INFO - 2016-09-16 11:06:22 --> Output Class Initialized
INFO - 2016-09-16 11:06:22 --> Security Class Initialized
DEBUG - 2016-09-16 11:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:06:22 --> Input Class Initialized
INFO - 2016-09-16 11:06:22 --> Language Class Initialized
INFO - 2016-09-16 11:06:22 --> Language Class Initialized
INFO - 2016-09-16 11:06:22 --> Config Class Initialized
INFO - 2016-09-16 11:06:22 --> Loader Class Initialized
INFO - 2016-09-16 11:06:22 --> Helper loaded: url_helper
INFO - 2016-09-16 11:06:22 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:22 --> Controller Class Initialized
DEBUG - 2016-09-16 11:06:22 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:06:22 --> Model Class Initialized
INFO - 2016-09-16 11:06:22 --> Model Class Initialized
INFO - 2016-09-16 11:06:22 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:22 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:22 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:23 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:23 --> Final output sent to browser
DEBUG - 2016-09-16 11:06:23 --> Total execution time: 0.8494
INFO - 2016-09-16 11:06:24 --> Config Class Initialized
INFO - 2016-09-16 11:06:24 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:06:24 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:06:24 --> Utf8 Class Initialized
INFO - 2016-09-16 11:06:24 --> URI Class Initialized
INFO - 2016-09-16 11:06:24 --> Router Class Initialized
INFO - 2016-09-16 11:06:24 --> Output Class Initialized
INFO - 2016-09-16 11:06:24 --> Security Class Initialized
DEBUG - 2016-09-16 11:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:06:24 --> Input Class Initialized
INFO - 2016-09-16 11:06:24 --> Language Class Initialized
INFO - 2016-09-16 11:06:24 --> Language Class Initialized
INFO - 2016-09-16 11:06:24 --> Config Class Initialized
INFO - 2016-09-16 11:06:24 --> Loader Class Initialized
INFO - 2016-09-16 11:06:24 --> Helper loaded: url_helper
INFO - 2016-09-16 11:06:24 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:24 --> Controller Class Initialized
DEBUG - 2016-09-16 11:06:24 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:06:25 --> Model Class Initialized
INFO - 2016-09-16 11:06:25 --> Model Class Initialized
INFO - 2016-09-16 11:06:25 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:25 --> Final output sent to browser
DEBUG - 2016-09-16 11:06:25 --> Total execution time: 0.5355
INFO - 2016-09-16 11:06:26 --> Config Class Initialized
INFO - 2016-09-16 11:06:26 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:06:26 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:06:26 --> Utf8 Class Initialized
INFO - 2016-09-16 11:06:26 --> URI Class Initialized
INFO - 2016-09-16 11:06:26 --> Router Class Initialized
INFO - 2016-09-16 11:06:26 --> Output Class Initialized
INFO - 2016-09-16 11:06:26 --> Security Class Initialized
DEBUG - 2016-09-16 11:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:06:26 --> Input Class Initialized
INFO - 2016-09-16 11:06:26 --> Language Class Initialized
INFO - 2016-09-16 11:06:26 --> Language Class Initialized
INFO - 2016-09-16 11:06:26 --> Config Class Initialized
INFO - 2016-09-16 11:06:26 --> Loader Class Initialized
INFO - 2016-09-16 11:06:26 --> Helper loaded: url_helper
INFO - 2016-09-16 11:06:26 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:26 --> Controller Class Initialized
DEBUG - 2016-09-16 11:06:26 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:06:26 --> Model Class Initialized
INFO - 2016-09-16 11:06:26 --> Model Class Initialized
INFO - 2016-09-16 11:06:26 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:27 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:27 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:27 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:27 --> Final output sent to browser
DEBUG - 2016-09-16 11:06:27 --> Total execution time: 0.9777
INFO - 2016-09-16 11:06:29 --> Config Class Initialized
INFO - 2016-09-16 11:06:29 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:06:29 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:06:29 --> Utf8 Class Initialized
INFO - 2016-09-16 11:06:29 --> URI Class Initialized
INFO - 2016-09-16 11:06:29 --> Router Class Initialized
INFO - 2016-09-16 11:06:29 --> Output Class Initialized
INFO - 2016-09-16 11:06:29 --> Security Class Initialized
DEBUG - 2016-09-16 11:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:06:29 --> Input Class Initialized
INFO - 2016-09-16 11:06:29 --> Language Class Initialized
INFO - 2016-09-16 11:06:29 --> Language Class Initialized
INFO - 2016-09-16 11:06:29 --> Config Class Initialized
INFO - 2016-09-16 11:06:29 --> Loader Class Initialized
INFO - 2016-09-16 11:06:29 --> Helper loaded: url_helper
INFO - 2016-09-16 11:06:29 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:29 --> Controller Class Initialized
DEBUG - 2016-09-16 11:06:29 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:06:29 --> Model Class Initialized
INFO - 2016-09-16 11:06:29 --> Model Class Initialized
DEBUG - 2016-09-16 11:06:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-16 11:06:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-16 11:06:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-16 11:06:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tutup_angsuran.php
DEBUG - 2016-09-16 11:06:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-16 11:06:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-16 11:06:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-16 11:06:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-16 11:06:29 --> Final output sent to browser
DEBUG - 2016-09-16 11:06:29 --> Total execution time: 0.6759
INFO - 2016-09-16 11:06:33 --> Config Class Initialized
INFO - 2016-09-16 11:06:33 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:06:33 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:06:33 --> Utf8 Class Initialized
INFO - 2016-09-16 11:06:33 --> URI Class Initialized
INFO - 2016-09-16 11:06:33 --> Router Class Initialized
INFO - 2016-09-16 11:06:33 --> Output Class Initialized
INFO - 2016-09-16 11:06:33 --> Security Class Initialized
DEBUG - 2016-09-16 11:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:06:33 --> Input Class Initialized
INFO - 2016-09-16 11:06:33 --> Language Class Initialized
INFO - 2016-09-16 11:06:33 --> Language Class Initialized
INFO - 2016-09-16 11:06:33 --> Config Class Initialized
INFO - 2016-09-16 11:06:33 --> Loader Class Initialized
INFO - 2016-09-16 11:06:33 --> Helper loaded: url_helper
INFO - 2016-09-16 11:06:33 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:33 --> Controller Class Initialized
DEBUG - 2016-09-16 11:06:33 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:06:33 --> Model Class Initialized
INFO - 2016-09-16 11:06:33 --> Model Class Initialized
INFO - 2016-09-16 11:06:33 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:33 --> Final output sent to browser
DEBUG - 2016-09-16 11:06:33 --> Total execution time: 0.5299
INFO - 2016-09-16 11:06:40 --> Config Class Initialized
INFO - 2016-09-16 11:06:40 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:06:40 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:06:40 --> Utf8 Class Initialized
INFO - 2016-09-16 11:06:40 --> URI Class Initialized
INFO - 2016-09-16 11:06:40 --> Router Class Initialized
INFO - 2016-09-16 11:06:40 --> Output Class Initialized
INFO - 2016-09-16 11:06:40 --> Security Class Initialized
DEBUG - 2016-09-16 11:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:06:40 --> Input Class Initialized
INFO - 2016-09-16 11:06:40 --> Language Class Initialized
INFO - 2016-09-16 11:06:40 --> Language Class Initialized
INFO - 2016-09-16 11:06:40 --> Config Class Initialized
INFO - 2016-09-16 11:06:40 --> Loader Class Initialized
INFO - 2016-09-16 11:06:40 --> Helper loaded: url_helper
INFO - 2016-09-16 11:06:40 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:40 --> Controller Class Initialized
DEBUG - 2016-09-16 11:06:40 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:06:40 --> Model Class Initialized
INFO - 2016-09-16 11:06:40 --> Model Class Initialized
INFO - 2016-09-16 11:06:40 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:40 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:40 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:41 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:41 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:41 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:41 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:41 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:41 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:41 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:41 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:41 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:41 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:41 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:41 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:41 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:41 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:41 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:41 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:42 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:42 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:42 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:42 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:42 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:42 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:42 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:42 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:42 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:42 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:42 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:42 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:42 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:42 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:42 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:42 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:43 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:43 --> Database Driver Class Initialized
INFO - 2016-09-16 11:06:43 --> Final output sent to browser
DEBUG - 2016-09-16 11:06:43 --> Total execution time: 2.8339
INFO - 2016-09-16 11:26:18 --> Config Class Initialized
INFO - 2016-09-16 11:26:18 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:26:18 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:26:18 --> Utf8 Class Initialized
INFO - 2016-09-16 11:26:18 --> URI Class Initialized
INFO - 2016-09-16 11:26:18 --> Router Class Initialized
INFO - 2016-09-16 11:26:18 --> Output Class Initialized
INFO - 2016-09-16 11:26:18 --> Security Class Initialized
DEBUG - 2016-09-16 11:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:26:18 --> Input Class Initialized
INFO - 2016-09-16 11:26:18 --> Language Class Initialized
ERROR - 2016-09-16 11:26:19 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting ',' or ';' E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 577
INFO - 2016-09-16 11:26:27 --> Config Class Initialized
INFO - 2016-09-16 11:26:27 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:26:27 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:26:27 --> Utf8 Class Initialized
INFO - 2016-09-16 11:26:27 --> URI Class Initialized
INFO - 2016-09-16 11:26:27 --> Router Class Initialized
INFO - 2016-09-16 11:26:27 --> Output Class Initialized
INFO - 2016-09-16 11:26:27 --> Security Class Initialized
DEBUG - 2016-09-16 11:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:26:28 --> Input Class Initialized
INFO - 2016-09-16 11:26:28 --> Language Class Initialized
INFO - 2016-09-16 11:26:28 --> Language Class Initialized
INFO - 2016-09-16 11:26:28 --> Config Class Initialized
INFO - 2016-09-16 11:26:28 --> Loader Class Initialized
INFO - 2016-09-16 11:26:28 --> Helper loaded: url_helper
INFO - 2016-09-16 11:26:28 --> Database Driver Class Initialized
INFO - 2016-09-16 11:26:28 --> Controller Class Initialized
DEBUG - 2016-09-16 11:26:28 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:26:28 --> Model Class Initialized
INFO - 2016-09-16 11:26:28 --> Model Class Initialized
DEBUG - 2016-09-16 11:26:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-16 11:26:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-16 11:26:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-16 11:26:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/jurnal_umum.php
DEBUG - 2016-09-16 11:26:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-16 11:26:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-16 11:26:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-16 11:26:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-16 11:26:28 --> Final output sent to browser
DEBUG - 2016-09-16 11:26:28 --> Total execution time: 0.6892
INFO - 2016-09-16 11:26:35 --> Config Class Initialized
INFO - 2016-09-16 11:26:35 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:26:35 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:26:35 --> Utf8 Class Initialized
INFO - 2016-09-16 11:26:35 --> URI Class Initialized
INFO - 2016-09-16 11:26:35 --> Router Class Initialized
INFO - 2016-09-16 11:26:35 --> Output Class Initialized
INFO - 2016-09-16 11:26:35 --> Security Class Initialized
DEBUG - 2016-09-16 11:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:26:35 --> Input Class Initialized
INFO - 2016-09-16 11:26:35 --> Language Class Initialized
INFO - 2016-09-16 11:26:35 --> Language Class Initialized
INFO - 2016-09-16 11:26:35 --> Config Class Initialized
INFO - 2016-09-16 11:26:35 --> Loader Class Initialized
INFO - 2016-09-16 11:26:35 --> Helper loaded: url_helper
INFO - 2016-09-16 11:26:35 --> Database Driver Class Initialized
INFO - 2016-09-16 11:26:35 --> Controller Class Initialized
DEBUG - 2016-09-16 11:26:35 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:26:35 --> Model Class Initialized
INFO - 2016-09-16 11:26:35 --> Model Class Initialized
DEBUG - 2016-09-16 11:26:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_jurnal_umum.php
INFO - 2016-09-16 11:26:35 --> Final output sent to browser
DEBUG - 2016-09-16 11:26:36 --> Total execution time: 0.5115
INFO - 2016-09-16 11:27:04 --> Config Class Initialized
INFO - 2016-09-16 11:27:04 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:27:04 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:27:04 --> Utf8 Class Initialized
INFO - 2016-09-16 11:27:04 --> URI Class Initialized
INFO - 2016-09-16 11:27:04 --> Router Class Initialized
INFO - 2016-09-16 11:27:04 --> Output Class Initialized
INFO - 2016-09-16 11:27:04 --> Security Class Initialized
DEBUG - 2016-09-16 11:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:27:04 --> Input Class Initialized
INFO - 2016-09-16 11:27:04 --> Language Class Initialized
INFO - 2016-09-16 11:27:04 --> Language Class Initialized
INFO - 2016-09-16 11:27:04 --> Config Class Initialized
INFO - 2016-09-16 11:27:04 --> Loader Class Initialized
INFO - 2016-09-16 11:27:04 --> Helper loaded: url_helper
INFO - 2016-09-16 11:27:04 --> Database Driver Class Initialized
INFO - 2016-09-16 11:27:05 --> Controller Class Initialized
DEBUG - 2016-09-16 11:27:05 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:27:05 --> Model Class Initialized
INFO - 2016-09-16 11:27:05 --> Model Class Initialized
DEBUG - 2016-09-16 11:27:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_jurnal_umum.php
INFO - 2016-09-16 11:27:05 --> Final output sent to browser
DEBUG - 2016-09-16 11:27:05 --> Total execution time: 0.5470
INFO - 2016-09-16 11:27:47 --> Config Class Initialized
INFO - 2016-09-16 11:27:47 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:27:47 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:27:47 --> Utf8 Class Initialized
INFO - 2016-09-16 11:27:47 --> URI Class Initialized
INFO - 2016-09-16 11:27:47 --> Router Class Initialized
INFO - 2016-09-16 11:27:47 --> Output Class Initialized
INFO - 2016-09-16 11:27:47 --> Security Class Initialized
DEBUG - 2016-09-16 11:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:27:47 --> Input Class Initialized
INFO - 2016-09-16 11:27:47 --> Language Class Initialized
INFO - 2016-09-16 11:27:47 --> Language Class Initialized
INFO - 2016-09-16 11:27:47 --> Config Class Initialized
INFO - 2016-09-16 11:27:48 --> Loader Class Initialized
INFO - 2016-09-16 11:27:48 --> Helper loaded: url_helper
INFO - 2016-09-16 11:27:48 --> Database Driver Class Initialized
INFO - 2016-09-16 11:27:48 --> Controller Class Initialized
DEBUG - 2016-09-16 11:27:48 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:27:48 --> Model Class Initialized
INFO - 2016-09-16 11:27:48 --> Model Class Initialized
DEBUG - 2016-09-16 11:27:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_jurnal_umum.php
INFO - 2016-09-16 11:27:48 --> Final output sent to browser
DEBUG - 2016-09-16 11:27:48 --> Total execution time: 0.5031
INFO - 2016-09-16 11:29:35 --> Config Class Initialized
INFO - 2016-09-16 11:29:35 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:29:35 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:29:35 --> Utf8 Class Initialized
INFO - 2016-09-16 11:29:35 --> URI Class Initialized
INFO - 2016-09-16 11:29:35 --> Router Class Initialized
INFO - 2016-09-16 11:29:35 --> Output Class Initialized
INFO - 2016-09-16 11:29:35 --> Security Class Initialized
DEBUG - 2016-09-16 11:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:29:35 --> Input Class Initialized
INFO - 2016-09-16 11:29:35 --> Language Class Initialized
INFO - 2016-09-16 11:29:35 --> Language Class Initialized
INFO - 2016-09-16 11:29:35 --> Config Class Initialized
INFO - 2016-09-16 11:29:35 --> Loader Class Initialized
INFO - 2016-09-16 11:29:35 --> Helper loaded: url_helper
INFO - 2016-09-16 11:29:35 --> Database Driver Class Initialized
INFO - 2016-09-16 11:29:35 --> Controller Class Initialized
DEBUG - 2016-09-16 11:29:35 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:29:35 --> Model Class Initialized
INFO - 2016-09-16 11:29:35 --> Model Class Initialized
DEBUG - 2016-09-16 11:29:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_jurnal_umum.php
INFO - 2016-09-16 11:29:35 --> Final output sent to browser
DEBUG - 2016-09-16 11:29:35 --> Total execution time: 0.5402
INFO - 2016-09-16 11:31:47 --> Config Class Initialized
INFO - 2016-09-16 11:31:47 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:31:47 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:31:47 --> Utf8 Class Initialized
INFO - 2016-09-16 11:31:47 --> URI Class Initialized
INFO - 2016-09-16 11:31:47 --> Router Class Initialized
INFO - 2016-09-16 11:31:47 --> Output Class Initialized
INFO - 2016-09-16 11:31:47 --> Security Class Initialized
DEBUG - 2016-09-16 11:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:31:47 --> Input Class Initialized
INFO - 2016-09-16 11:31:47 --> Language Class Initialized
INFO - 2016-09-16 11:31:47 --> Language Class Initialized
INFO - 2016-09-16 11:31:47 --> Config Class Initialized
INFO - 2016-09-16 11:31:47 --> Loader Class Initialized
INFO - 2016-09-16 11:31:47 --> Helper loaded: url_helper
INFO - 2016-09-16 11:31:47 --> Database Driver Class Initialized
INFO - 2016-09-16 11:31:48 --> Controller Class Initialized
DEBUG - 2016-09-16 11:31:48 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:31:48 --> Model Class Initialized
INFO - 2016-09-16 11:31:48 --> Model Class Initialized
DEBUG - 2016-09-16 11:31:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_jurnal_umum.php
INFO - 2016-09-16 11:31:48 --> Final output sent to browser
DEBUG - 2016-09-16 11:31:48 --> Total execution time: 0.4752
INFO - 2016-09-16 11:37:03 --> Config Class Initialized
INFO - 2016-09-16 11:37:03 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:37:03 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:37:04 --> Utf8 Class Initialized
INFO - 2016-09-16 11:37:04 --> URI Class Initialized
INFO - 2016-09-16 11:37:04 --> Router Class Initialized
INFO - 2016-09-16 11:37:04 --> Output Class Initialized
INFO - 2016-09-16 11:37:04 --> Security Class Initialized
DEBUG - 2016-09-16 11:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:37:04 --> Input Class Initialized
INFO - 2016-09-16 11:37:04 --> Language Class Initialized
INFO - 2016-09-16 11:37:04 --> Language Class Initialized
INFO - 2016-09-16 11:37:04 --> Config Class Initialized
INFO - 2016-09-16 11:37:04 --> Loader Class Initialized
INFO - 2016-09-16 11:37:04 --> Helper loaded: url_helper
INFO - 2016-09-16 11:37:04 --> Database Driver Class Initialized
INFO - 2016-09-16 11:37:04 --> Controller Class Initialized
DEBUG - 2016-09-16 11:37:04 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:37:04 --> Model Class Initialized
INFO - 2016-09-16 11:37:04 --> Model Class Initialized
DEBUG - 2016-09-16 11:37:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-16 11:37:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-16 11:37:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-16 11:37:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/angsuran.php
DEBUG - 2016-09-16 11:37:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-16 11:37:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-16 11:37:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-16 11:37:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-16 11:37:04 --> Final output sent to browser
DEBUG - 2016-09-16 11:37:04 --> Total execution time: 0.6516
INFO - 2016-09-16 11:37:13 --> Config Class Initialized
INFO - 2016-09-16 11:37:13 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:37:13 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:37:13 --> Utf8 Class Initialized
INFO - 2016-09-16 11:37:13 --> URI Class Initialized
INFO - 2016-09-16 11:37:13 --> Router Class Initialized
INFO - 2016-09-16 11:37:13 --> Output Class Initialized
INFO - 2016-09-16 11:37:13 --> Security Class Initialized
DEBUG - 2016-09-16 11:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:37:13 --> Input Class Initialized
INFO - 2016-09-16 11:37:13 --> Language Class Initialized
INFO - 2016-09-16 11:37:13 --> Language Class Initialized
INFO - 2016-09-16 11:37:13 --> Config Class Initialized
INFO - 2016-09-16 11:37:13 --> Loader Class Initialized
INFO - 2016-09-16 11:37:13 --> Helper loaded: url_helper
INFO - 2016-09-16 11:37:13 --> Database Driver Class Initialized
INFO - 2016-09-16 11:37:13 --> Controller Class Initialized
DEBUG - 2016-09-16 11:37:13 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:37:13 --> Model Class Initialized
INFO - 2016-09-16 11:37:13 --> Model Class Initialized
INFO - 2016-09-16 11:37:13 --> Database Driver Class Initialized
INFO - 2016-09-16 11:37:13 --> Database Driver Class Initialized
INFO - 2016-09-16 11:37:13 --> Database Driver Class Initialized
INFO - 2016-09-16 11:37:14 --> Database Driver Class Initialized
INFO - 2016-09-16 11:37:14 --> Database Driver Class Initialized
INFO - 2016-09-16 11:37:14 --> Database Driver Class Initialized
INFO - 2016-09-16 11:37:14 --> Database Driver Class Initialized
INFO - 2016-09-16 11:37:14 --> Database Driver Class Initialized
INFO - 2016-09-16 11:37:14 --> Database Driver Class Initialized
INFO - 2016-09-16 11:37:14 --> Database Driver Class Initialized
INFO - 2016-09-16 11:37:14 --> Database Driver Class Initialized
INFO - 2016-09-16 11:37:14 --> Database Driver Class Initialized
INFO - 2016-09-16 11:37:14 --> Database Driver Class Initialized
INFO - 2016-09-16 11:37:14 --> Database Driver Class Initialized
INFO - 2016-09-16 11:37:14 --> Database Driver Class Initialized
INFO - 2016-09-16 11:37:14 --> Database Driver Class Initialized
INFO - 2016-09-16 11:37:14 --> Database Driver Class Initialized
INFO - 2016-09-16 11:37:14 --> Database Driver Class Initialized
INFO - 2016-09-16 11:37:14 --> Database Driver Class Initialized
INFO - 2016-09-16 11:37:14 --> Database Driver Class Initialized
INFO - 2016-09-16 11:37:14 --> Database Driver Class Initialized
INFO - 2016-09-16 11:37:14 --> Database Driver Class Initialized
INFO - 2016-09-16 11:37:14 --> Database Driver Class Initialized
INFO - 2016-09-16 11:37:14 --> Database Driver Class Initialized
INFO - 2016-09-16 11:37:14 --> Database Driver Class Initialized
INFO - 2016-09-16 11:37:14 --> Database Driver Class Initialized
INFO - 2016-09-16 11:37:14 --> Database Driver Class Initialized
DEBUG - 2016-09-16 11:37:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_angsuran.php
INFO - 2016-09-16 11:37:14 --> Final output sent to browser
DEBUG - 2016-09-16 11:37:14 --> Total execution time: 1.3178
INFO - 2016-09-16 11:38:12 --> Config Class Initialized
INFO - 2016-09-16 11:38:12 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:38:12 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:38:12 --> Utf8 Class Initialized
INFO - 2016-09-16 11:38:12 --> URI Class Initialized
INFO - 2016-09-16 11:38:12 --> Router Class Initialized
INFO - 2016-09-16 11:38:12 --> Output Class Initialized
INFO - 2016-09-16 11:38:12 --> Security Class Initialized
DEBUG - 2016-09-16 11:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:38:12 --> Input Class Initialized
INFO - 2016-09-16 11:38:12 --> Language Class Initialized
INFO - 2016-09-16 11:38:12 --> Language Class Initialized
INFO - 2016-09-16 11:38:12 --> Config Class Initialized
INFO - 2016-09-16 11:38:12 --> Loader Class Initialized
INFO - 2016-09-16 11:38:12 --> Helper loaded: url_helper
INFO - 2016-09-16 11:38:12 --> Database Driver Class Initialized
INFO - 2016-09-16 11:38:12 --> Controller Class Initialized
DEBUG - 2016-09-16 11:38:12 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:38:12 --> Model Class Initialized
INFO - 2016-09-16 11:38:12 --> Model Class Initialized
DEBUG - 2016-09-16 11:38:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-16 11:38:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-16 11:38:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-16 11:38:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-16 11:38:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-16 11:38:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-16 11:38:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-16 11:38:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-16 11:38:12 --> Final output sent to browser
DEBUG - 2016-09-16 11:38:12 --> Total execution time: 0.6595
INFO - 2016-09-16 11:38:17 --> Config Class Initialized
INFO - 2016-09-16 11:38:17 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:38:17 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:38:17 --> Utf8 Class Initialized
INFO - 2016-09-16 11:38:17 --> URI Class Initialized
INFO - 2016-09-16 11:38:17 --> Router Class Initialized
INFO - 2016-09-16 11:38:17 --> Output Class Initialized
INFO - 2016-09-16 11:38:17 --> Security Class Initialized
DEBUG - 2016-09-16 11:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:38:17 --> Input Class Initialized
INFO - 2016-09-16 11:38:17 --> Language Class Initialized
INFO - 2016-09-16 11:38:17 --> Language Class Initialized
INFO - 2016-09-16 11:38:17 --> Config Class Initialized
INFO - 2016-09-16 11:38:17 --> Loader Class Initialized
INFO - 2016-09-16 11:38:17 --> Helper loaded: url_helper
INFO - 2016-09-16 11:38:18 --> Database Driver Class Initialized
INFO - 2016-09-16 11:38:18 --> Controller Class Initialized
DEBUG - 2016-09-16 11:38:18 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:38:18 --> Model Class Initialized
INFO - 2016-09-16 11:38:18 --> Model Class Initialized
DEBUG - 2016-09-16 11:38:18 --> Anggota MX_Controller Initialized
INFO - 2016-09-16 11:38:18 --> Database Driver Class Initialized
INFO - 2016-09-16 11:38:18 --> Final output sent to browser
DEBUG - 2016-09-16 11:38:18 --> Total execution time: 0.5523
INFO - 2016-09-16 11:38:19 --> Config Class Initialized
INFO - 2016-09-16 11:38:19 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:38:19 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:38:19 --> Utf8 Class Initialized
INFO - 2016-09-16 11:38:19 --> URI Class Initialized
INFO - 2016-09-16 11:38:19 --> Router Class Initialized
INFO - 2016-09-16 11:38:19 --> Output Class Initialized
INFO - 2016-09-16 11:38:19 --> Security Class Initialized
DEBUG - 2016-09-16 11:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:38:19 --> Input Class Initialized
INFO - 2016-09-16 11:38:19 --> Language Class Initialized
INFO - 2016-09-16 11:38:19 --> Language Class Initialized
INFO - 2016-09-16 11:38:19 --> Config Class Initialized
INFO - 2016-09-16 11:38:20 --> Loader Class Initialized
INFO - 2016-09-16 11:38:20 --> Helper loaded: url_helper
INFO - 2016-09-16 11:38:20 --> Database Driver Class Initialized
INFO - 2016-09-16 11:38:20 --> Controller Class Initialized
DEBUG - 2016-09-16 11:38:20 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:38:20 --> Model Class Initialized
INFO - 2016-09-16 11:38:20 --> Model Class Initialized
DEBUG - 2016-09-16 11:38:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-16 11:38:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-16 11:38:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-16 11:38:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_umum.php
DEBUG - 2016-09-16 11:38:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-16 11:38:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-16 11:38:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-16 11:38:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-16 11:38:20 --> Final output sent to browser
DEBUG - 2016-09-16 11:38:20 --> Total execution time: 0.7185
INFO - 2016-09-16 11:39:17 --> Config Class Initialized
INFO - 2016-09-16 11:39:17 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:39:17 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:39:17 --> Utf8 Class Initialized
INFO - 2016-09-16 11:39:17 --> URI Class Initialized
INFO - 2016-09-16 11:39:17 --> Router Class Initialized
INFO - 2016-09-16 11:39:17 --> Output Class Initialized
INFO - 2016-09-16 11:39:17 --> Security Class Initialized
DEBUG - 2016-09-16 11:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:39:17 --> Input Class Initialized
INFO - 2016-09-16 11:39:17 --> Language Class Initialized
INFO - 2016-09-16 11:39:17 --> Language Class Initialized
INFO - 2016-09-16 11:39:17 --> Config Class Initialized
INFO - 2016-09-16 11:39:17 --> Loader Class Initialized
INFO - 2016-09-16 11:39:17 --> Helper loaded: url_helper
INFO - 2016-09-16 11:39:17 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:17 --> Controller Class Initialized
DEBUG - 2016-09-16 11:39:17 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:39:17 --> Model Class Initialized
INFO - 2016-09-16 11:39:17 --> Model Class Initialized
INFO - 2016-09-16 11:39:18 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:18 --> Final output sent to browser
DEBUG - 2016-09-16 11:39:18 --> Total execution time: 0.6222
INFO - 2016-09-16 11:39:23 --> Config Class Initialized
INFO - 2016-09-16 11:39:23 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:39:23 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:39:23 --> Utf8 Class Initialized
INFO - 2016-09-16 11:39:23 --> URI Class Initialized
INFO - 2016-09-16 11:39:23 --> Router Class Initialized
INFO - 2016-09-16 11:39:23 --> Output Class Initialized
INFO - 2016-09-16 11:39:23 --> Security Class Initialized
DEBUG - 2016-09-16 11:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:39:23 --> Input Class Initialized
INFO - 2016-09-16 11:39:23 --> Language Class Initialized
INFO - 2016-09-16 11:39:23 --> Language Class Initialized
INFO - 2016-09-16 11:39:23 --> Config Class Initialized
INFO - 2016-09-16 11:39:23 --> Loader Class Initialized
INFO - 2016-09-16 11:39:23 --> Helper loaded: url_helper
INFO - 2016-09-16 11:39:23 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:23 --> Controller Class Initialized
DEBUG - 2016-09-16 11:39:23 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:39:23 --> Model Class Initialized
INFO - 2016-09-16 11:39:23 --> Model Class Initialized
INFO - 2016-09-16 11:39:23 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:23 --> Final output sent to browser
DEBUG - 2016-09-16 11:39:23 --> Total execution time: 0.6795
INFO - 2016-09-16 11:39:29 --> Config Class Initialized
INFO - 2016-09-16 11:39:29 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:39:29 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:39:29 --> Utf8 Class Initialized
INFO - 2016-09-16 11:39:29 --> URI Class Initialized
INFO - 2016-09-16 11:39:29 --> Router Class Initialized
INFO - 2016-09-16 11:39:29 --> Output Class Initialized
INFO - 2016-09-16 11:39:29 --> Security Class Initialized
DEBUG - 2016-09-16 11:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:39:29 --> Input Class Initialized
INFO - 2016-09-16 11:39:29 --> Language Class Initialized
INFO - 2016-09-16 11:39:29 --> Language Class Initialized
INFO - 2016-09-16 11:39:29 --> Config Class Initialized
INFO - 2016-09-16 11:39:29 --> Loader Class Initialized
INFO - 2016-09-16 11:39:29 --> Helper loaded: url_helper
INFO - 2016-09-16 11:39:29 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:29 --> Controller Class Initialized
DEBUG - 2016-09-16 11:39:29 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:39:29 --> Model Class Initialized
INFO - 2016-09-16 11:39:29 --> Model Class Initialized
INFO - 2016-09-16 11:39:29 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:29 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:29 --> Final output sent to browser
DEBUG - 2016-09-16 11:39:29 --> Total execution time: 0.6844
INFO - 2016-09-16 11:39:34 --> Config Class Initialized
INFO - 2016-09-16 11:39:34 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:39:34 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:39:34 --> Utf8 Class Initialized
INFO - 2016-09-16 11:39:34 --> URI Class Initialized
INFO - 2016-09-16 11:39:34 --> Router Class Initialized
INFO - 2016-09-16 11:39:34 --> Output Class Initialized
INFO - 2016-09-16 11:39:35 --> Security Class Initialized
DEBUG - 2016-09-16 11:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:39:35 --> Input Class Initialized
INFO - 2016-09-16 11:39:35 --> Language Class Initialized
INFO - 2016-09-16 11:39:35 --> Language Class Initialized
INFO - 2016-09-16 11:39:35 --> Config Class Initialized
INFO - 2016-09-16 11:39:35 --> Loader Class Initialized
INFO - 2016-09-16 11:39:35 --> Helper loaded: url_helper
INFO - 2016-09-16 11:39:35 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:35 --> Controller Class Initialized
DEBUG - 2016-09-16 11:39:35 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:39:35 --> Model Class Initialized
INFO - 2016-09-16 11:39:35 --> Model Class Initialized
DEBUG - 2016-09-16 11:39:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-16 11:39:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-16 11:39:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-16 11:39:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-16 11:39:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-16 11:39:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-16 11:39:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-16 11:39:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-16 11:39:35 --> Final output sent to browser
DEBUG - 2016-09-16 11:39:35 --> Total execution time: 0.7319
INFO - 2016-09-16 11:39:40 --> Config Class Initialized
INFO - 2016-09-16 11:39:40 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:39:40 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:39:40 --> Utf8 Class Initialized
INFO - 2016-09-16 11:39:40 --> URI Class Initialized
INFO - 2016-09-16 11:39:40 --> Router Class Initialized
INFO - 2016-09-16 11:39:40 --> Output Class Initialized
INFO - 2016-09-16 11:39:40 --> Security Class Initialized
DEBUG - 2016-09-16 11:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:39:40 --> Input Class Initialized
INFO - 2016-09-16 11:39:40 --> Language Class Initialized
INFO - 2016-09-16 11:39:40 --> Language Class Initialized
INFO - 2016-09-16 11:39:40 --> Config Class Initialized
INFO - 2016-09-16 11:39:40 --> Loader Class Initialized
INFO - 2016-09-16 11:39:40 --> Helper loaded: url_helper
INFO - 2016-09-16 11:39:40 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:40 --> Controller Class Initialized
DEBUG - 2016-09-16 11:39:40 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:39:40 --> Model Class Initialized
INFO - 2016-09-16 11:39:40 --> Model Class Initialized
DEBUG - 2016-09-16 11:39:40 --> Anggota MX_Controller Initialized
INFO - 2016-09-16 11:39:40 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:40 --> Final output sent to browser
DEBUG - 2016-09-16 11:39:40 --> Total execution time: 0.5364
INFO - 2016-09-16 11:39:43 --> Config Class Initialized
INFO - 2016-09-16 11:39:43 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:39:43 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:39:43 --> Utf8 Class Initialized
INFO - 2016-09-16 11:39:43 --> URI Class Initialized
INFO - 2016-09-16 11:39:43 --> Router Class Initialized
INFO - 2016-09-16 11:39:43 --> Output Class Initialized
INFO - 2016-09-16 11:39:43 --> Security Class Initialized
DEBUG - 2016-09-16 11:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:39:43 --> Input Class Initialized
INFO - 2016-09-16 11:39:43 --> Language Class Initialized
INFO - 2016-09-16 11:39:43 --> Language Class Initialized
INFO - 2016-09-16 11:39:43 --> Config Class Initialized
INFO - 2016-09-16 11:39:43 --> Loader Class Initialized
INFO - 2016-09-16 11:39:43 --> Helper loaded: url_helper
INFO - 2016-09-16 11:39:43 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:43 --> Controller Class Initialized
DEBUG - 2016-09-16 11:39:44 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:39:44 --> Model Class Initialized
INFO - 2016-09-16 11:39:44 --> Model Class Initialized
DEBUG - 2016-09-16 11:39:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-16 11:39:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-16 11:39:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-16 11:39:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tutup_angsuran.php
DEBUG - 2016-09-16 11:39:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-16 11:39:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-16 11:39:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-16 11:39:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-16 11:39:44 --> Final output sent to browser
DEBUG - 2016-09-16 11:39:44 --> Total execution time: 0.7733
INFO - 2016-09-16 11:39:48 --> Config Class Initialized
INFO - 2016-09-16 11:39:48 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:39:48 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:39:49 --> Utf8 Class Initialized
INFO - 2016-09-16 11:39:49 --> URI Class Initialized
INFO - 2016-09-16 11:39:49 --> Router Class Initialized
INFO - 2016-09-16 11:39:49 --> Output Class Initialized
INFO - 2016-09-16 11:39:49 --> Security Class Initialized
DEBUG - 2016-09-16 11:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:39:49 --> Input Class Initialized
INFO - 2016-09-16 11:39:49 --> Language Class Initialized
INFO - 2016-09-16 11:39:49 --> Language Class Initialized
INFO - 2016-09-16 11:39:49 --> Config Class Initialized
INFO - 2016-09-16 11:39:49 --> Loader Class Initialized
INFO - 2016-09-16 11:39:49 --> Helper loaded: url_helper
INFO - 2016-09-16 11:39:49 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:49 --> Controller Class Initialized
DEBUG - 2016-09-16 11:39:49 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:39:49 --> Model Class Initialized
INFO - 2016-09-16 11:39:49 --> Model Class Initialized
INFO - 2016-09-16 11:39:49 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:49 --> Final output sent to browser
DEBUG - 2016-09-16 11:39:49 --> Total execution time: 0.5256
INFO - 2016-09-16 11:39:54 --> Config Class Initialized
INFO - 2016-09-16 11:39:54 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:39:54 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:39:54 --> Utf8 Class Initialized
INFO - 2016-09-16 11:39:54 --> URI Class Initialized
INFO - 2016-09-16 11:39:54 --> Router Class Initialized
INFO - 2016-09-16 11:39:54 --> Output Class Initialized
INFO - 2016-09-16 11:39:54 --> Security Class Initialized
DEBUG - 2016-09-16 11:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:39:54 --> Input Class Initialized
INFO - 2016-09-16 11:39:54 --> Language Class Initialized
INFO - 2016-09-16 11:39:54 --> Language Class Initialized
INFO - 2016-09-16 11:39:54 --> Config Class Initialized
INFO - 2016-09-16 11:39:54 --> Loader Class Initialized
INFO - 2016-09-16 11:39:54 --> Helper loaded: url_helper
INFO - 2016-09-16 11:39:54 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:54 --> Controller Class Initialized
DEBUG - 2016-09-16 11:39:54 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:39:54 --> Model Class Initialized
INFO - 2016-09-16 11:39:54 --> Model Class Initialized
INFO - 2016-09-16 11:39:54 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:54 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:54 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:55 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:55 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:55 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:55 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:55 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:55 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:55 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:55 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:55 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:55 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:55 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:55 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:56 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:56 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:56 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:56 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:56 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:56 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:56 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:56 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:56 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:56 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:56 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:56 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:56 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:56 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:56 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:56 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:57 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:57 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:57 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:57 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:57 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:57 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:57 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:57 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:57 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:57 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:57 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:57 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:57 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:57 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:39:58 --> Final output sent to browser
DEBUG - 2016-09-16 11:39:58 --> Total execution time: 4.1068
INFO - 2016-09-16 11:40:03 --> Config Class Initialized
INFO - 2016-09-16 11:40:03 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:40:03 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:40:03 --> Utf8 Class Initialized
INFO - 2016-09-16 11:40:03 --> URI Class Initialized
INFO - 2016-09-16 11:40:03 --> Router Class Initialized
INFO - 2016-09-16 11:40:03 --> Output Class Initialized
INFO - 2016-09-16 11:40:03 --> Security Class Initialized
DEBUG - 2016-09-16 11:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:40:03 --> Input Class Initialized
INFO - 2016-09-16 11:40:03 --> Language Class Initialized
INFO - 2016-09-16 11:40:03 --> Language Class Initialized
INFO - 2016-09-16 11:40:03 --> Config Class Initialized
INFO - 2016-09-16 11:40:03 --> Loader Class Initialized
INFO - 2016-09-16 11:40:03 --> Helper loaded: url_helper
INFO - 2016-09-16 11:40:03 --> Database Driver Class Initialized
INFO - 2016-09-16 11:40:03 --> Controller Class Initialized
DEBUG - 2016-09-16 11:40:03 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:40:03 --> Model Class Initialized
INFO - 2016-09-16 11:40:03 --> Model Class Initialized
DEBUG - 2016-09-16 11:40:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-16 11:40:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-16 11:40:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-16 11:40:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-16 11:40:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-16 11:40:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-16 11:40:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-16 11:40:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-16 11:40:03 --> Final output sent to browser
DEBUG - 2016-09-16 11:40:03 --> Total execution time: 0.6715
INFO - 2016-09-16 11:40:09 --> Config Class Initialized
INFO - 2016-09-16 11:40:09 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:40:09 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:40:09 --> Utf8 Class Initialized
INFO - 2016-09-16 11:40:09 --> URI Class Initialized
INFO - 2016-09-16 11:40:09 --> Router Class Initialized
INFO - 2016-09-16 11:40:09 --> Output Class Initialized
INFO - 2016-09-16 11:40:09 --> Security Class Initialized
DEBUG - 2016-09-16 11:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:40:09 --> Input Class Initialized
INFO - 2016-09-16 11:40:09 --> Language Class Initialized
INFO - 2016-09-16 11:40:09 --> Language Class Initialized
INFO - 2016-09-16 11:40:09 --> Config Class Initialized
INFO - 2016-09-16 11:40:09 --> Loader Class Initialized
INFO - 2016-09-16 11:40:09 --> Helper loaded: url_helper
INFO - 2016-09-16 11:40:09 --> Database Driver Class Initialized
INFO - 2016-09-16 11:40:09 --> Controller Class Initialized
DEBUG - 2016-09-16 11:40:09 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:40:09 --> Model Class Initialized
INFO - 2016-09-16 11:40:09 --> Model Class Initialized
DEBUG - 2016-09-16 11:40:09 --> Anggota MX_Controller Initialized
INFO - 2016-09-16 11:40:09 --> Database Driver Class Initialized
INFO - 2016-09-16 11:40:09 --> Final output sent to browser
DEBUG - 2016-09-16 11:40:09 --> Total execution time: 0.5894
INFO - 2016-09-16 11:40:10 --> Config Class Initialized
INFO - 2016-09-16 11:40:10 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:40:10 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:40:10 --> Utf8 Class Initialized
INFO - 2016-09-16 11:40:10 --> URI Class Initialized
INFO - 2016-09-16 11:40:10 --> Router Class Initialized
INFO - 2016-09-16 11:40:10 --> Output Class Initialized
INFO - 2016-09-16 11:40:10 --> Security Class Initialized
DEBUG - 2016-09-16 11:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:40:10 --> Input Class Initialized
INFO - 2016-09-16 11:40:10 --> Language Class Initialized
INFO - 2016-09-16 11:40:10 --> Language Class Initialized
INFO - 2016-09-16 11:40:10 --> Config Class Initialized
INFO - 2016-09-16 11:40:10 --> Loader Class Initialized
INFO - 2016-09-16 11:40:10 --> Helper loaded: url_helper
INFO - 2016-09-16 11:40:10 --> Database Driver Class Initialized
INFO - 2016-09-16 11:40:10 --> Controller Class Initialized
DEBUG - 2016-09-16 11:40:11 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:40:11 --> Model Class Initialized
INFO - 2016-09-16 11:40:11 --> Model Class Initialized
DEBUG - 2016-09-16 11:40:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-16 11:40:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-16 11:40:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-16 11:40:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_umum.php
DEBUG - 2016-09-16 11:40:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-16 11:40:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-16 11:40:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-16 11:40:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-16 11:40:11 --> Final output sent to browser
DEBUG - 2016-09-16 11:40:11 --> Total execution time: 0.7093
INFO - 2016-09-16 11:40:20 --> Config Class Initialized
INFO - 2016-09-16 11:40:20 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:40:20 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:40:20 --> Utf8 Class Initialized
INFO - 2016-09-16 11:40:20 --> URI Class Initialized
INFO - 2016-09-16 11:40:20 --> Router Class Initialized
INFO - 2016-09-16 11:40:20 --> Output Class Initialized
INFO - 2016-09-16 11:40:20 --> Security Class Initialized
DEBUG - 2016-09-16 11:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:40:20 --> Input Class Initialized
INFO - 2016-09-16 11:40:20 --> Language Class Initialized
INFO - 2016-09-16 11:40:20 --> Language Class Initialized
INFO - 2016-09-16 11:40:20 --> Config Class Initialized
INFO - 2016-09-16 11:40:20 --> Loader Class Initialized
INFO - 2016-09-16 11:40:20 --> Helper loaded: url_helper
INFO - 2016-09-16 11:40:20 --> Database Driver Class Initialized
INFO - 2016-09-16 11:40:20 --> Controller Class Initialized
DEBUG - 2016-09-16 11:40:20 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:40:20 --> Model Class Initialized
INFO - 2016-09-16 11:40:20 --> Model Class Initialized
INFO - 2016-09-16 11:40:21 --> Database Driver Class Initialized
INFO - 2016-09-16 11:40:21 --> Final output sent to browser
DEBUG - 2016-09-16 11:40:21 --> Total execution time: 0.6802
INFO - 2016-09-16 11:40:25 --> Config Class Initialized
INFO - 2016-09-16 11:40:25 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:40:25 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:40:25 --> Utf8 Class Initialized
INFO - 2016-09-16 11:40:25 --> URI Class Initialized
INFO - 2016-09-16 11:40:25 --> Router Class Initialized
INFO - 2016-09-16 11:40:25 --> Output Class Initialized
INFO - 2016-09-16 11:40:25 --> Security Class Initialized
DEBUG - 2016-09-16 11:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:40:26 --> Input Class Initialized
INFO - 2016-09-16 11:40:26 --> Language Class Initialized
INFO - 2016-09-16 11:40:26 --> Language Class Initialized
INFO - 2016-09-16 11:40:26 --> Config Class Initialized
INFO - 2016-09-16 11:40:26 --> Loader Class Initialized
INFO - 2016-09-16 11:40:26 --> Helper loaded: url_helper
INFO - 2016-09-16 11:40:26 --> Database Driver Class Initialized
INFO - 2016-09-16 11:40:26 --> Controller Class Initialized
DEBUG - 2016-09-16 11:40:26 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:40:26 --> Model Class Initialized
INFO - 2016-09-16 11:40:26 --> Model Class Initialized
INFO - 2016-09-16 11:40:26 --> Database Driver Class Initialized
INFO - 2016-09-16 11:40:26 --> Final output sent to browser
DEBUG - 2016-09-16 11:40:26 --> Total execution time: 0.7256
INFO - 2016-09-16 11:40:32 --> Config Class Initialized
INFO - 2016-09-16 11:40:32 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:40:32 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:40:32 --> Utf8 Class Initialized
INFO - 2016-09-16 11:40:32 --> URI Class Initialized
INFO - 2016-09-16 11:40:32 --> Router Class Initialized
INFO - 2016-09-16 11:40:32 --> Output Class Initialized
INFO - 2016-09-16 11:40:32 --> Security Class Initialized
DEBUG - 2016-09-16 11:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:40:32 --> Input Class Initialized
INFO - 2016-09-16 11:40:32 --> Language Class Initialized
INFO - 2016-09-16 11:40:32 --> Language Class Initialized
INFO - 2016-09-16 11:40:32 --> Config Class Initialized
INFO - 2016-09-16 11:40:32 --> Loader Class Initialized
INFO - 2016-09-16 11:40:32 --> Helper loaded: url_helper
INFO - 2016-09-16 11:40:32 --> Database Driver Class Initialized
INFO - 2016-09-16 11:40:32 --> Controller Class Initialized
DEBUG - 2016-09-16 11:40:32 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:40:32 --> Model Class Initialized
INFO - 2016-09-16 11:40:32 --> Model Class Initialized
INFO - 2016-09-16 11:40:32 --> Database Driver Class Initialized
INFO - 2016-09-16 11:40:32 --> Database Driver Class Initialized
INFO - 2016-09-16 11:40:33 --> Final output sent to browser
DEBUG - 2016-09-16 11:40:33 --> Total execution time: 0.7356
INFO - 2016-09-16 11:40:50 --> Config Class Initialized
INFO - 2016-09-16 11:40:50 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:40:50 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:40:50 --> Utf8 Class Initialized
INFO - 2016-09-16 11:40:50 --> URI Class Initialized
INFO - 2016-09-16 11:40:50 --> Router Class Initialized
INFO - 2016-09-16 11:40:50 --> Output Class Initialized
INFO - 2016-09-16 11:40:50 --> Security Class Initialized
DEBUG - 2016-09-16 11:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:40:50 --> Input Class Initialized
INFO - 2016-09-16 11:40:51 --> Language Class Initialized
INFO - 2016-09-16 11:40:51 --> Language Class Initialized
INFO - 2016-09-16 11:40:51 --> Config Class Initialized
INFO - 2016-09-16 11:40:51 --> Loader Class Initialized
INFO - 2016-09-16 11:40:51 --> Helper loaded: url_helper
INFO - 2016-09-16 11:40:51 --> Database Driver Class Initialized
INFO - 2016-09-16 11:40:51 --> Controller Class Initialized
DEBUG - 2016-09-16 11:40:51 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:40:51 --> Model Class Initialized
INFO - 2016-09-16 11:40:51 --> Model Class Initialized
DEBUG - 2016-09-16 11:40:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-16 11:40:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-16 11:40:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-16 11:40:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/jurnal_umum.php
DEBUG - 2016-09-16 11:40:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-16 11:40:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-16 11:40:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-16 11:40:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-16 11:40:51 --> Final output sent to browser
DEBUG - 2016-09-16 11:40:51 --> Total execution time: 0.9674
INFO - 2016-09-16 11:41:21 --> Config Class Initialized
INFO - 2016-09-16 11:41:21 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:41:21 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:41:21 --> Utf8 Class Initialized
INFO - 2016-09-16 11:41:21 --> URI Class Initialized
INFO - 2016-09-16 11:41:21 --> Router Class Initialized
INFO - 2016-09-16 11:41:21 --> Output Class Initialized
INFO - 2016-09-16 11:41:21 --> Security Class Initialized
DEBUG - 2016-09-16 11:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:41:21 --> Input Class Initialized
INFO - 2016-09-16 11:41:21 --> Language Class Initialized
INFO - 2016-09-16 11:41:21 --> Language Class Initialized
INFO - 2016-09-16 11:41:21 --> Config Class Initialized
INFO - 2016-09-16 11:41:21 --> Loader Class Initialized
INFO - 2016-09-16 11:41:21 --> Helper loaded: url_helper
INFO - 2016-09-16 11:41:21 --> Database Driver Class Initialized
INFO - 2016-09-16 11:41:21 --> Controller Class Initialized
DEBUG - 2016-09-16 11:41:21 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:41:21 --> Model Class Initialized
INFO - 2016-09-16 11:41:21 --> Model Class Initialized
DEBUG - 2016-09-16 11:41:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-16 11:41:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-16 11:41:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-16 11:41:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/jurnal_umum.php
DEBUG - 2016-09-16 11:41:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-16 11:41:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-16 11:41:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-16 11:41:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-16 11:41:21 --> Final output sent to browser
DEBUG - 2016-09-16 11:41:21 --> Total execution time: 0.8294
INFO - 2016-09-16 11:41:32 --> Config Class Initialized
INFO - 2016-09-16 11:41:32 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:41:32 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:41:32 --> Utf8 Class Initialized
INFO - 2016-09-16 11:41:32 --> URI Class Initialized
INFO - 2016-09-16 11:41:32 --> Router Class Initialized
INFO - 2016-09-16 11:41:32 --> Output Class Initialized
INFO - 2016-09-16 11:41:32 --> Security Class Initialized
DEBUG - 2016-09-16 11:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:41:33 --> Input Class Initialized
INFO - 2016-09-16 11:41:33 --> Language Class Initialized
INFO - 2016-09-16 11:41:33 --> Language Class Initialized
INFO - 2016-09-16 11:41:33 --> Config Class Initialized
INFO - 2016-09-16 11:41:33 --> Loader Class Initialized
INFO - 2016-09-16 11:41:33 --> Helper loaded: url_helper
INFO - 2016-09-16 11:41:33 --> Database Driver Class Initialized
INFO - 2016-09-16 11:41:33 --> Controller Class Initialized
DEBUG - 2016-09-16 11:41:33 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:41:33 --> Model Class Initialized
INFO - 2016-09-16 11:41:33 --> Model Class Initialized
DEBUG - 2016-09-16 11:41:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_jurnal_umum.php
INFO - 2016-09-16 11:41:33 --> Final output sent to browser
DEBUG - 2016-09-16 11:41:33 --> Total execution time: 0.5866
INFO - 2016-09-16 11:41:54 --> Config Class Initialized
INFO - 2016-09-16 11:41:54 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:41:54 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:41:54 --> Utf8 Class Initialized
INFO - 2016-09-16 11:41:54 --> URI Class Initialized
INFO - 2016-09-16 11:41:54 --> Router Class Initialized
INFO - 2016-09-16 11:41:54 --> Output Class Initialized
INFO - 2016-09-16 11:41:54 --> Security Class Initialized
DEBUG - 2016-09-16 11:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:41:54 --> Input Class Initialized
INFO - 2016-09-16 11:41:54 --> Language Class Initialized
INFO - 2016-09-16 11:41:54 --> Language Class Initialized
INFO - 2016-09-16 11:41:54 --> Config Class Initialized
INFO - 2016-09-16 11:41:54 --> Loader Class Initialized
INFO - 2016-09-16 11:41:54 --> Helper loaded: url_helper
INFO - 2016-09-16 11:41:54 --> Database Driver Class Initialized
INFO - 2016-09-16 11:41:54 --> Controller Class Initialized
DEBUG - 2016-09-16 11:41:54 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:41:54 --> Model Class Initialized
INFO - 2016-09-16 11:41:54 --> Model Class Initialized
DEBUG - 2016-09-16 11:41:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-16 11:41:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-16 11:41:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-16 11:41:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/angsuran.php
DEBUG - 2016-09-16 11:41:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-16 11:41:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-16 11:41:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-16 11:41:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-16 11:41:54 --> Final output sent to browser
DEBUG - 2016-09-16 11:41:54 --> Total execution time: 0.7065
INFO - 2016-09-16 11:41:58 --> Config Class Initialized
INFO - 2016-09-16 11:41:58 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:41:58 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:41:58 --> Utf8 Class Initialized
INFO - 2016-09-16 11:41:58 --> URI Class Initialized
INFO - 2016-09-16 11:41:58 --> Router Class Initialized
INFO - 2016-09-16 11:41:58 --> Output Class Initialized
INFO - 2016-09-16 11:41:58 --> Security Class Initialized
DEBUG - 2016-09-16 11:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:41:58 --> Input Class Initialized
INFO - 2016-09-16 11:41:58 --> Language Class Initialized
INFO - 2016-09-16 11:41:59 --> Language Class Initialized
INFO - 2016-09-16 11:41:59 --> Config Class Initialized
INFO - 2016-09-16 11:41:59 --> Loader Class Initialized
INFO - 2016-09-16 11:41:59 --> Helper loaded: url_helper
INFO - 2016-09-16 11:41:59 --> Database Driver Class Initialized
INFO - 2016-09-16 11:41:59 --> Controller Class Initialized
DEBUG - 2016-09-16 11:41:59 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:41:59 --> Model Class Initialized
INFO - 2016-09-16 11:41:59 --> Model Class Initialized
DEBUG - 2016-09-16 11:41:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-16 11:41:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-16 11:41:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-16 11:41:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_bayar_angsuran.php
DEBUG - 2016-09-16 11:41:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-16 11:41:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-16 11:41:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-16 11:41:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-16 11:41:59 --> Final output sent to browser
DEBUG - 2016-09-16 11:41:59 --> Total execution time: 0.8136
INFO - 2016-09-16 11:42:04 --> Config Class Initialized
INFO - 2016-09-16 11:42:04 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:42:04 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:42:04 --> Utf8 Class Initialized
INFO - 2016-09-16 11:42:04 --> URI Class Initialized
INFO - 2016-09-16 11:42:04 --> Router Class Initialized
INFO - 2016-09-16 11:42:04 --> Output Class Initialized
INFO - 2016-09-16 11:42:04 --> Security Class Initialized
DEBUG - 2016-09-16 11:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:42:04 --> Input Class Initialized
INFO - 2016-09-16 11:42:04 --> Language Class Initialized
INFO - 2016-09-16 11:42:04 --> Language Class Initialized
INFO - 2016-09-16 11:42:04 --> Config Class Initialized
INFO - 2016-09-16 11:42:04 --> Loader Class Initialized
INFO - 2016-09-16 11:42:04 --> Helper loaded: url_helper
INFO - 2016-09-16 11:42:04 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:04 --> Controller Class Initialized
DEBUG - 2016-09-16 11:42:04 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:42:04 --> Model Class Initialized
INFO - 2016-09-16 11:42:04 --> Model Class Initialized
INFO - 2016-09-16 11:42:05 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:05 --> Final output sent to browser
DEBUG - 2016-09-16 11:42:05 --> Total execution time: 0.5561
INFO - 2016-09-16 11:42:09 --> Config Class Initialized
INFO - 2016-09-16 11:42:09 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:42:09 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:42:09 --> Utf8 Class Initialized
INFO - 2016-09-16 11:42:10 --> URI Class Initialized
INFO - 2016-09-16 11:42:10 --> Router Class Initialized
INFO - 2016-09-16 11:42:10 --> Output Class Initialized
INFO - 2016-09-16 11:42:10 --> Security Class Initialized
DEBUG - 2016-09-16 11:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:42:10 --> Input Class Initialized
INFO - 2016-09-16 11:42:10 --> Language Class Initialized
INFO - 2016-09-16 11:42:10 --> Language Class Initialized
INFO - 2016-09-16 11:42:10 --> Config Class Initialized
INFO - 2016-09-16 11:42:10 --> Loader Class Initialized
INFO - 2016-09-16 11:42:10 --> Helper loaded: url_helper
INFO - 2016-09-16 11:42:10 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:10 --> Controller Class Initialized
DEBUG - 2016-09-16 11:42:10 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:42:10 --> Model Class Initialized
INFO - 2016-09-16 11:42:10 --> Model Class Initialized
INFO - 2016-09-16 11:42:10 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:10 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:10 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:10 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:10 --> Final output sent to browser
DEBUG - 2016-09-16 11:42:10 --> Total execution time: 0.9488
INFO - 2016-09-16 11:42:12 --> Config Class Initialized
INFO - 2016-09-16 11:42:12 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:42:12 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:42:12 --> Utf8 Class Initialized
INFO - 2016-09-16 11:42:12 --> URI Class Initialized
INFO - 2016-09-16 11:42:12 --> Router Class Initialized
INFO - 2016-09-16 11:42:12 --> Output Class Initialized
INFO - 2016-09-16 11:42:12 --> Security Class Initialized
DEBUG - 2016-09-16 11:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:42:12 --> Input Class Initialized
INFO - 2016-09-16 11:42:12 --> Language Class Initialized
INFO - 2016-09-16 11:42:12 --> Language Class Initialized
INFO - 2016-09-16 11:42:12 --> Config Class Initialized
INFO - 2016-09-16 11:42:12 --> Loader Class Initialized
INFO - 2016-09-16 11:42:13 --> Helper loaded: url_helper
INFO - 2016-09-16 11:42:13 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:13 --> Controller Class Initialized
DEBUG - 2016-09-16 11:42:13 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:42:13 --> Model Class Initialized
INFO - 2016-09-16 11:42:13 --> Model Class Initialized
INFO - 2016-09-16 11:42:13 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:13 --> Final output sent to browser
DEBUG - 2016-09-16 11:42:13 --> Total execution time: 0.5533
INFO - 2016-09-16 11:42:14 --> Config Class Initialized
INFO - 2016-09-16 11:42:14 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:42:14 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:42:14 --> Utf8 Class Initialized
INFO - 2016-09-16 11:42:14 --> URI Class Initialized
INFO - 2016-09-16 11:42:14 --> Router Class Initialized
INFO - 2016-09-16 11:42:14 --> Output Class Initialized
INFO - 2016-09-16 11:42:14 --> Security Class Initialized
DEBUG - 2016-09-16 11:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:42:14 --> Input Class Initialized
INFO - 2016-09-16 11:42:14 --> Language Class Initialized
INFO - 2016-09-16 11:42:14 --> Language Class Initialized
INFO - 2016-09-16 11:42:14 --> Config Class Initialized
INFO - 2016-09-16 11:42:14 --> Loader Class Initialized
INFO - 2016-09-16 11:42:14 --> Helper loaded: url_helper
INFO - 2016-09-16 11:42:14 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:14 --> Controller Class Initialized
DEBUG - 2016-09-16 11:42:14 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:42:14 --> Model Class Initialized
INFO - 2016-09-16 11:42:14 --> Model Class Initialized
INFO - 2016-09-16 11:42:14 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:15 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:15 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:15 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:15 --> Final output sent to browser
DEBUG - 2016-09-16 11:42:15 --> Total execution time: 0.8832
INFO - 2016-09-16 11:42:16 --> Config Class Initialized
INFO - 2016-09-16 11:42:16 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:42:16 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:42:16 --> Utf8 Class Initialized
INFO - 2016-09-16 11:42:16 --> URI Class Initialized
INFO - 2016-09-16 11:42:16 --> Router Class Initialized
INFO - 2016-09-16 11:42:16 --> Output Class Initialized
INFO - 2016-09-16 11:42:16 --> Security Class Initialized
DEBUG - 2016-09-16 11:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:42:16 --> Input Class Initialized
INFO - 2016-09-16 11:42:16 --> Language Class Initialized
INFO - 2016-09-16 11:42:16 --> Language Class Initialized
INFO - 2016-09-16 11:42:16 --> Config Class Initialized
INFO - 2016-09-16 11:42:16 --> Loader Class Initialized
INFO - 2016-09-16 11:42:16 --> Helper loaded: url_helper
INFO - 2016-09-16 11:42:16 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:16 --> Controller Class Initialized
DEBUG - 2016-09-16 11:42:16 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:42:16 --> Model Class Initialized
INFO - 2016-09-16 11:42:16 --> Model Class Initialized
INFO - 2016-09-16 11:42:16 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:16 --> Final output sent to browser
DEBUG - 2016-09-16 11:42:16 --> Total execution time: 0.5633
INFO - 2016-09-16 11:42:17 --> Config Class Initialized
INFO - 2016-09-16 11:42:17 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:42:17 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:42:17 --> Utf8 Class Initialized
INFO - 2016-09-16 11:42:17 --> URI Class Initialized
INFO - 2016-09-16 11:42:17 --> Router Class Initialized
INFO - 2016-09-16 11:42:17 --> Output Class Initialized
INFO - 2016-09-16 11:42:17 --> Security Class Initialized
DEBUG - 2016-09-16 11:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:42:17 --> Input Class Initialized
INFO - 2016-09-16 11:42:17 --> Language Class Initialized
INFO - 2016-09-16 11:42:17 --> Language Class Initialized
INFO - 2016-09-16 11:42:17 --> Config Class Initialized
INFO - 2016-09-16 11:42:17 --> Loader Class Initialized
INFO - 2016-09-16 11:42:17 --> Helper loaded: url_helper
INFO - 2016-09-16 11:42:17 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:17 --> Controller Class Initialized
DEBUG - 2016-09-16 11:42:17 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:42:17 --> Model Class Initialized
INFO - 2016-09-16 11:42:17 --> Model Class Initialized
INFO - 2016-09-16 11:42:17 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:18 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:18 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:18 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:18 --> Final output sent to browser
DEBUG - 2016-09-16 11:42:18 --> Total execution time: 0.8844
INFO - 2016-09-16 11:42:19 --> Config Class Initialized
INFO - 2016-09-16 11:42:19 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:42:19 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:42:19 --> Utf8 Class Initialized
INFO - 2016-09-16 11:42:19 --> URI Class Initialized
INFO - 2016-09-16 11:42:19 --> Router Class Initialized
INFO - 2016-09-16 11:42:19 --> Output Class Initialized
INFO - 2016-09-16 11:42:19 --> Security Class Initialized
DEBUG - 2016-09-16 11:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:42:19 --> Input Class Initialized
INFO - 2016-09-16 11:42:19 --> Language Class Initialized
INFO - 2016-09-16 11:42:19 --> Language Class Initialized
INFO - 2016-09-16 11:42:19 --> Config Class Initialized
INFO - 2016-09-16 11:42:19 --> Loader Class Initialized
INFO - 2016-09-16 11:42:19 --> Helper loaded: url_helper
INFO - 2016-09-16 11:42:19 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:19 --> Controller Class Initialized
DEBUG - 2016-09-16 11:42:19 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:42:19 --> Model Class Initialized
INFO - 2016-09-16 11:42:19 --> Model Class Initialized
INFO - 2016-09-16 11:42:19 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:19 --> Final output sent to browser
DEBUG - 2016-09-16 11:42:19 --> Total execution time: 0.6888
INFO - 2016-09-16 11:42:20 --> Config Class Initialized
INFO - 2016-09-16 11:42:20 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:42:20 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:42:20 --> Utf8 Class Initialized
INFO - 2016-09-16 11:42:20 --> URI Class Initialized
INFO - 2016-09-16 11:42:20 --> Router Class Initialized
INFO - 2016-09-16 11:42:20 --> Output Class Initialized
INFO - 2016-09-16 11:42:20 --> Security Class Initialized
DEBUG - 2016-09-16 11:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:42:21 --> Input Class Initialized
INFO - 2016-09-16 11:42:21 --> Language Class Initialized
INFO - 2016-09-16 11:42:21 --> Language Class Initialized
INFO - 2016-09-16 11:42:21 --> Config Class Initialized
INFO - 2016-09-16 11:42:21 --> Loader Class Initialized
INFO - 2016-09-16 11:42:21 --> Helper loaded: url_helper
INFO - 2016-09-16 11:42:21 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:21 --> Controller Class Initialized
DEBUG - 2016-09-16 11:42:21 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:42:21 --> Model Class Initialized
INFO - 2016-09-16 11:42:21 --> Model Class Initialized
INFO - 2016-09-16 11:42:21 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:21 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:21 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:21 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:21 --> Final output sent to browser
DEBUG - 2016-09-16 11:42:21 --> Total execution time: 1.1778
INFO - 2016-09-16 11:42:23 --> Config Class Initialized
INFO - 2016-09-16 11:42:23 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:42:23 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:42:23 --> Utf8 Class Initialized
INFO - 2016-09-16 11:42:23 --> URI Class Initialized
INFO - 2016-09-16 11:42:23 --> Router Class Initialized
INFO - 2016-09-16 11:42:23 --> Output Class Initialized
INFO - 2016-09-16 11:42:23 --> Security Class Initialized
DEBUG - 2016-09-16 11:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:42:23 --> Input Class Initialized
INFO - 2016-09-16 11:42:23 --> Language Class Initialized
INFO - 2016-09-16 11:42:23 --> Language Class Initialized
INFO - 2016-09-16 11:42:23 --> Config Class Initialized
INFO - 2016-09-16 11:42:23 --> Loader Class Initialized
INFO - 2016-09-16 11:42:23 --> Helper loaded: url_helper
INFO - 2016-09-16 11:42:23 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:23 --> Controller Class Initialized
DEBUG - 2016-09-16 11:42:23 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:42:23 --> Model Class Initialized
INFO - 2016-09-16 11:42:23 --> Model Class Initialized
INFO - 2016-09-16 11:42:23 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:23 --> Final output sent to browser
DEBUG - 2016-09-16 11:42:23 --> Total execution time: 0.5801
INFO - 2016-09-16 11:42:24 --> Config Class Initialized
INFO - 2016-09-16 11:42:24 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:42:24 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:42:24 --> Utf8 Class Initialized
INFO - 2016-09-16 11:42:24 --> URI Class Initialized
INFO - 2016-09-16 11:42:24 --> Router Class Initialized
INFO - 2016-09-16 11:42:24 --> Output Class Initialized
INFO - 2016-09-16 11:42:24 --> Security Class Initialized
DEBUG - 2016-09-16 11:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:42:24 --> Input Class Initialized
INFO - 2016-09-16 11:42:24 --> Language Class Initialized
INFO - 2016-09-16 11:42:24 --> Language Class Initialized
INFO - 2016-09-16 11:42:24 --> Config Class Initialized
INFO - 2016-09-16 11:42:24 --> Loader Class Initialized
INFO - 2016-09-16 11:42:24 --> Helper loaded: url_helper
INFO - 2016-09-16 11:42:24 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:24 --> Controller Class Initialized
DEBUG - 2016-09-16 11:42:24 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:42:24 --> Model Class Initialized
INFO - 2016-09-16 11:42:24 --> Model Class Initialized
INFO - 2016-09-16 11:42:25 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:25 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:25 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:25 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:25 --> Final output sent to browser
DEBUG - 2016-09-16 11:42:25 --> Total execution time: 1.0893
INFO - 2016-09-16 11:42:26 --> Config Class Initialized
INFO - 2016-09-16 11:42:26 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:42:26 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:42:26 --> Utf8 Class Initialized
INFO - 2016-09-16 11:42:26 --> URI Class Initialized
INFO - 2016-09-16 11:42:26 --> Router Class Initialized
INFO - 2016-09-16 11:42:26 --> Output Class Initialized
INFO - 2016-09-16 11:42:26 --> Security Class Initialized
DEBUG - 2016-09-16 11:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:42:26 --> Input Class Initialized
INFO - 2016-09-16 11:42:26 --> Language Class Initialized
INFO - 2016-09-16 11:42:26 --> Language Class Initialized
INFO - 2016-09-16 11:42:26 --> Config Class Initialized
INFO - 2016-09-16 11:42:26 --> Loader Class Initialized
INFO - 2016-09-16 11:42:27 --> Helper loaded: url_helper
INFO - 2016-09-16 11:42:27 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:27 --> Controller Class Initialized
DEBUG - 2016-09-16 11:42:27 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:42:27 --> Model Class Initialized
INFO - 2016-09-16 11:42:27 --> Model Class Initialized
INFO - 2016-09-16 11:42:27 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:27 --> Final output sent to browser
DEBUG - 2016-09-16 11:42:27 --> Total execution time: 0.6713
INFO - 2016-09-16 11:42:28 --> Config Class Initialized
INFO - 2016-09-16 11:42:28 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:42:28 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:42:28 --> Utf8 Class Initialized
INFO - 2016-09-16 11:42:28 --> URI Class Initialized
INFO - 2016-09-16 11:42:28 --> Router Class Initialized
INFO - 2016-09-16 11:42:28 --> Output Class Initialized
INFO - 2016-09-16 11:42:28 --> Security Class Initialized
DEBUG - 2016-09-16 11:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:42:28 --> Input Class Initialized
INFO - 2016-09-16 11:42:28 --> Language Class Initialized
INFO - 2016-09-16 11:42:28 --> Language Class Initialized
INFO - 2016-09-16 11:42:28 --> Config Class Initialized
INFO - 2016-09-16 11:42:28 --> Loader Class Initialized
INFO - 2016-09-16 11:42:28 --> Helper loaded: url_helper
INFO - 2016-09-16 11:42:28 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:28 --> Controller Class Initialized
DEBUG - 2016-09-16 11:42:28 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:42:28 --> Model Class Initialized
INFO - 2016-09-16 11:42:28 --> Model Class Initialized
INFO - 2016-09-16 11:42:28 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:28 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:29 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:29 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:29 --> Final output sent to browser
DEBUG - 2016-09-16 11:42:29 --> Total execution time: 0.9374
INFO - 2016-09-16 11:42:31 --> Config Class Initialized
INFO - 2016-09-16 11:42:31 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:42:31 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:42:31 --> Utf8 Class Initialized
INFO - 2016-09-16 11:42:31 --> URI Class Initialized
INFO - 2016-09-16 11:42:31 --> Router Class Initialized
INFO - 2016-09-16 11:42:31 --> Output Class Initialized
INFO - 2016-09-16 11:42:31 --> Security Class Initialized
DEBUG - 2016-09-16 11:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:42:32 --> Input Class Initialized
INFO - 2016-09-16 11:42:32 --> Language Class Initialized
INFO - 2016-09-16 11:42:32 --> Language Class Initialized
INFO - 2016-09-16 11:42:32 --> Config Class Initialized
INFO - 2016-09-16 11:42:32 --> Loader Class Initialized
INFO - 2016-09-16 11:42:32 --> Helper loaded: url_helper
INFO - 2016-09-16 11:42:32 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:32 --> Controller Class Initialized
DEBUG - 2016-09-16 11:42:32 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:42:32 --> Model Class Initialized
INFO - 2016-09-16 11:42:32 --> Model Class Initialized
INFO - 2016-09-16 11:42:32 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:32 --> Final output sent to browser
DEBUG - 2016-09-16 11:42:32 --> Total execution time: 0.5365
INFO - 2016-09-16 11:42:34 --> Config Class Initialized
INFO - 2016-09-16 11:42:34 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:42:34 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:42:34 --> Utf8 Class Initialized
INFO - 2016-09-16 11:42:34 --> URI Class Initialized
INFO - 2016-09-16 11:42:34 --> Router Class Initialized
INFO - 2016-09-16 11:42:34 --> Output Class Initialized
INFO - 2016-09-16 11:42:34 --> Security Class Initialized
DEBUG - 2016-09-16 11:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:42:34 --> Input Class Initialized
INFO - 2016-09-16 11:42:34 --> Language Class Initialized
INFO - 2016-09-16 11:42:34 --> Language Class Initialized
INFO - 2016-09-16 11:42:34 --> Config Class Initialized
INFO - 2016-09-16 11:42:34 --> Loader Class Initialized
INFO - 2016-09-16 11:42:35 --> Helper loaded: url_helper
INFO - 2016-09-16 11:42:35 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:35 --> Controller Class Initialized
DEBUG - 2016-09-16 11:42:35 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:42:35 --> Model Class Initialized
INFO - 2016-09-16 11:42:35 --> Model Class Initialized
DEBUG - 2016-09-16 11:42:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-16 11:42:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-16 11:42:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-16 11:42:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tutup_angsuran.php
DEBUG - 2016-09-16 11:42:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-16 11:42:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-16 11:42:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-16 11:42:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-16 11:42:35 --> Final output sent to browser
DEBUG - 2016-09-16 11:42:35 --> Total execution time: 0.9037
INFO - 2016-09-16 11:42:39 --> Config Class Initialized
INFO - 2016-09-16 11:42:39 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:42:39 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:42:39 --> Utf8 Class Initialized
INFO - 2016-09-16 11:42:39 --> URI Class Initialized
INFO - 2016-09-16 11:42:39 --> Router Class Initialized
INFO - 2016-09-16 11:42:39 --> Output Class Initialized
INFO - 2016-09-16 11:42:39 --> Security Class Initialized
DEBUG - 2016-09-16 11:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:42:39 --> Input Class Initialized
INFO - 2016-09-16 11:42:39 --> Language Class Initialized
INFO - 2016-09-16 11:42:39 --> Language Class Initialized
INFO - 2016-09-16 11:42:39 --> Config Class Initialized
INFO - 2016-09-16 11:42:39 --> Loader Class Initialized
INFO - 2016-09-16 11:42:39 --> Helper loaded: url_helper
INFO - 2016-09-16 11:42:39 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:39 --> Controller Class Initialized
DEBUG - 2016-09-16 11:42:39 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:42:39 --> Model Class Initialized
INFO - 2016-09-16 11:42:39 --> Model Class Initialized
INFO - 2016-09-16 11:42:39 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:39 --> Final output sent to browser
DEBUG - 2016-09-16 11:42:39 --> Total execution time: 0.6629
INFO - 2016-09-16 11:42:45 --> Config Class Initialized
INFO - 2016-09-16 11:42:45 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:42:45 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:42:45 --> Utf8 Class Initialized
INFO - 2016-09-16 11:42:45 --> URI Class Initialized
INFO - 2016-09-16 11:42:45 --> Router Class Initialized
INFO - 2016-09-16 11:42:45 --> Output Class Initialized
INFO - 2016-09-16 11:42:45 --> Security Class Initialized
DEBUG - 2016-09-16 11:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:42:45 --> Input Class Initialized
INFO - 2016-09-16 11:42:45 --> Language Class Initialized
INFO - 2016-09-16 11:42:45 --> Language Class Initialized
INFO - 2016-09-16 11:42:45 --> Config Class Initialized
INFO - 2016-09-16 11:42:45 --> Loader Class Initialized
INFO - 2016-09-16 11:42:45 --> Helper loaded: url_helper
INFO - 2016-09-16 11:42:45 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:45 --> Controller Class Initialized
DEBUG - 2016-09-16 11:42:45 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:42:45 --> Model Class Initialized
INFO - 2016-09-16 11:42:45 --> Model Class Initialized
INFO - 2016-09-16 11:42:45 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:45 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:46 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:46 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:46 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:46 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:46 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:46 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:46 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:46 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:46 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:46 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:47 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:47 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:47 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:47 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:47 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:47 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:47 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:47 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:47 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:47 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:47 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:47 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:47 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:47 --> Final output sent to browser
DEBUG - 2016-09-16 11:42:47 --> Total execution time: 2.6189
INFO - 2016-09-16 11:42:53 --> Config Class Initialized
INFO - 2016-09-16 11:42:53 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:42:53 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:42:53 --> Utf8 Class Initialized
INFO - 2016-09-16 11:42:53 --> URI Class Initialized
INFO - 2016-09-16 11:42:53 --> Router Class Initialized
INFO - 2016-09-16 11:42:53 --> Output Class Initialized
INFO - 2016-09-16 11:42:53 --> Security Class Initialized
DEBUG - 2016-09-16 11:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:42:53 --> Input Class Initialized
INFO - 2016-09-16 11:42:53 --> Language Class Initialized
INFO - 2016-09-16 11:42:53 --> Language Class Initialized
INFO - 2016-09-16 11:42:53 --> Config Class Initialized
INFO - 2016-09-16 11:42:53 --> Loader Class Initialized
INFO - 2016-09-16 11:42:53 --> Helper loaded: url_helper
INFO - 2016-09-16 11:42:53 --> Database Driver Class Initialized
INFO - 2016-09-16 11:42:53 --> Controller Class Initialized
DEBUG - 2016-09-16 11:42:53 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:42:53 --> Model Class Initialized
INFO - 2016-09-16 11:42:53 --> Model Class Initialized
DEBUG - 2016-09-16 11:42:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-16 11:42:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-16 11:42:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-16 11:42:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/angsuran.php
DEBUG - 2016-09-16 11:42:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-16 11:42:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-16 11:42:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-16 11:42:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-16 11:42:53 --> Final output sent to browser
DEBUG - 2016-09-16 11:42:53 --> Total execution time: 0.7351
INFO - 2016-09-16 11:43:00 --> Config Class Initialized
INFO - 2016-09-16 11:43:00 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:43:00 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:43:00 --> Utf8 Class Initialized
INFO - 2016-09-16 11:43:00 --> URI Class Initialized
INFO - 2016-09-16 11:43:00 --> Router Class Initialized
INFO - 2016-09-16 11:43:00 --> Output Class Initialized
INFO - 2016-09-16 11:43:00 --> Security Class Initialized
DEBUG - 2016-09-16 11:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:43:00 --> Input Class Initialized
INFO - 2016-09-16 11:43:00 --> Language Class Initialized
INFO - 2016-09-16 11:43:00 --> Language Class Initialized
INFO - 2016-09-16 11:43:00 --> Config Class Initialized
INFO - 2016-09-16 11:43:00 --> Loader Class Initialized
INFO - 2016-09-16 11:43:00 --> Helper loaded: url_helper
INFO - 2016-09-16 11:43:00 --> Database Driver Class Initialized
INFO - 2016-09-16 11:43:00 --> Controller Class Initialized
DEBUG - 2016-09-16 11:43:00 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:43:00 --> Model Class Initialized
INFO - 2016-09-16 11:43:00 --> Model Class Initialized
INFO - 2016-09-16 11:43:00 --> Database Driver Class Initialized
INFO - 2016-09-16 11:43:00 --> Database Driver Class Initialized
INFO - 2016-09-16 11:43:01 --> Database Driver Class Initialized
INFO - 2016-09-16 11:43:01 --> Database Driver Class Initialized
INFO - 2016-09-16 11:43:01 --> Database Driver Class Initialized
INFO - 2016-09-16 11:43:01 --> Database Driver Class Initialized
INFO - 2016-09-16 11:43:01 --> Database Driver Class Initialized
INFO - 2016-09-16 11:43:01 --> Database Driver Class Initialized
INFO - 2016-09-16 11:43:01 --> Database Driver Class Initialized
INFO - 2016-09-16 11:43:01 --> Database Driver Class Initialized
INFO - 2016-09-16 11:43:01 --> Database Driver Class Initialized
INFO - 2016-09-16 11:43:01 --> Database Driver Class Initialized
INFO - 2016-09-16 11:43:01 --> Database Driver Class Initialized
INFO - 2016-09-16 11:43:01 --> Database Driver Class Initialized
INFO - 2016-09-16 11:43:01 --> Database Driver Class Initialized
INFO - 2016-09-16 11:43:01 --> Database Driver Class Initialized
INFO - 2016-09-16 11:43:01 --> Database Driver Class Initialized
INFO - 2016-09-16 11:43:01 --> Database Driver Class Initialized
INFO - 2016-09-16 11:43:01 --> Database Driver Class Initialized
INFO - 2016-09-16 11:43:01 --> Database Driver Class Initialized
INFO - 2016-09-16 11:43:01 --> Database Driver Class Initialized
INFO - 2016-09-16 11:43:01 --> Database Driver Class Initialized
INFO - 2016-09-16 11:43:01 --> Database Driver Class Initialized
INFO - 2016-09-16 11:43:01 --> Database Driver Class Initialized
INFO - 2016-09-16 11:43:01 --> Database Driver Class Initialized
INFO - 2016-09-16 11:43:01 --> Database Driver Class Initialized
INFO - 2016-09-16 11:43:01 --> Database Driver Class Initialized
INFO - 2016-09-16 11:43:01 --> Database Driver Class Initialized
INFO - 2016-09-16 11:43:01 --> Database Driver Class Initialized
INFO - 2016-09-16 11:43:01 --> Database Driver Class Initialized
INFO - 2016-09-16 11:43:02 --> Database Driver Class Initialized
INFO - 2016-09-16 11:43:02 --> Database Driver Class Initialized
INFO - 2016-09-16 11:43:02 --> Database Driver Class Initialized
DEBUG - 2016-09-16 11:43:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_angsuran.php
INFO - 2016-09-16 11:43:02 --> Final output sent to browser
DEBUG - 2016-09-16 11:43:02 --> Total execution time: 1.8354
INFO - 2016-09-16 11:43:32 --> Config Class Initialized
INFO - 2016-09-16 11:43:32 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:43:32 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:43:32 --> Utf8 Class Initialized
INFO - 2016-09-16 11:43:32 --> URI Class Initialized
INFO - 2016-09-16 11:43:32 --> Router Class Initialized
INFO - 2016-09-16 11:43:32 --> Output Class Initialized
INFO - 2016-09-16 11:43:32 --> Security Class Initialized
DEBUG - 2016-09-16 11:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:43:32 --> Input Class Initialized
INFO - 2016-09-16 11:43:32 --> Language Class Initialized
INFO - 2016-09-16 11:43:32 --> Language Class Initialized
INFO - 2016-09-16 11:43:32 --> Config Class Initialized
INFO - 2016-09-16 11:43:32 --> Loader Class Initialized
INFO - 2016-09-16 11:43:32 --> Helper loaded: url_helper
INFO - 2016-09-16 11:43:32 --> Database Driver Class Initialized
INFO - 2016-09-16 11:43:32 --> Controller Class Initialized
DEBUG - 2016-09-16 11:43:32 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:43:32 --> Model Class Initialized
INFO - 2016-09-16 11:43:32 --> Model Class Initialized
DEBUG - 2016-09-16 11:43:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-16 11:43:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-16 11:43:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-16 11:43:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/jurnal_umum.php
DEBUG - 2016-09-16 11:43:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-16 11:43:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-16 11:43:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-16 11:43:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-16 11:43:33 --> Final output sent to browser
DEBUG - 2016-09-16 11:43:33 --> Total execution time: 0.7384
INFO - 2016-09-16 11:43:39 --> Config Class Initialized
INFO - 2016-09-16 11:43:39 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:43:39 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:43:39 --> Utf8 Class Initialized
INFO - 2016-09-16 11:43:39 --> URI Class Initialized
INFO - 2016-09-16 11:43:39 --> Router Class Initialized
INFO - 2016-09-16 11:43:39 --> Output Class Initialized
INFO - 2016-09-16 11:43:39 --> Security Class Initialized
DEBUG - 2016-09-16 11:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:43:39 --> Input Class Initialized
INFO - 2016-09-16 11:43:39 --> Language Class Initialized
INFO - 2016-09-16 11:43:39 --> Language Class Initialized
INFO - 2016-09-16 11:43:39 --> Config Class Initialized
INFO - 2016-09-16 11:43:39 --> Loader Class Initialized
INFO - 2016-09-16 11:43:39 --> Helper loaded: url_helper
INFO - 2016-09-16 11:43:39 --> Database Driver Class Initialized
INFO - 2016-09-16 11:43:39 --> Controller Class Initialized
DEBUG - 2016-09-16 11:43:39 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:43:39 --> Model Class Initialized
INFO - 2016-09-16 11:43:39 --> Model Class Initialized
DEBUG - 2016-09-16 11:43:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_jurnal_umum.php
INFO - 2016-09-16 11:43:39 --> Final output sent to browser
DEBUG - 2016-09-16 11:43:39 --> Total execution time: 0.5480
INFO - 2016-09-16 11:44:30 --> Config Class Initialized
INFO - 2016-09-16 11:44:30 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:44:30 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:44:30 --> Utf8 Class Initialized
INFO - 2016-09-16 11:44:30 --> URI Class Initialized
INFO - 2016-09-16 11:44:30 --> Router Class Initialized
INFO - 2016-09-16 11:44:30 --> Output Class Initialized
INFO - 2016-09-16 11:44:30 --> Security Class Initialized
DEBUG - 2016-09-16 11:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:44:30 --> Input Class Initialized
INFO - 2016-09-16 11:44:30 --> Language Class Initialized
INFO - 2016-09-16 11:44:30 --> Language Class Initialized
INFO - 2016-09-16 11:44:30 --> Config Class Initialized
INFO - 2016-09-16 11:44:30 --> Loader Class Initialized
INFO - 2016-09-16 11:44:31 --> Helper loaded: url_helper
INFO - 2016-09-16 11:44:31 --> Database Driver Class Initialized
INFO - 2016-09-16 11:44:31 --> Controller Class Initialized
DEBUG - 2016-09-16 11:44:31 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:44:31 --> Model Class Initialized
INFO - 2016-09-16 11:44:31 --> Model Class Initialized
DEBUG - 2016-09-16 11:44:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-16 11:44:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-16 11:44:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-16 11:44:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/angsuran.php
DEBUG - 2016-09-16 11:44:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-16 11:44:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-16 11:44:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-16 11:44:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-16 11:44:31 --> Final output sent to browser
DEBUG - 2016-09-16 11:44:31 --> Total execution time: 0.8453
INFO - 2016-09-16 11:45:57 --> Config Class Initialized
INFO - 2016-09-16 11:45:57 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:45:57 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:45:57 --> Utf8 Class Initialized
INFO - 2016-09-16 11:45:57 --> URI Class Initialized
INFO - 2016-09-16 11:45:57 --> Router Class Initialized
INFO - 2016-09-16 11:45:57 --> Output Class Initialized
INFO - 2016-09-16 11:45:57 --> Security Class Initialized
DEBUG - 2016-09-16 11:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:45:57 --> Input Class Initialized
INFO - 2016-09-16 11:45:57 --> Language Class Initialized
INFO - 2016-09-16 11:45:57 --> Language Class Initialized
INFO - 2016-09-16 11:45:57 --> Config Class Initialized
INFO - 2016-09-16 11:45:58 --> Loader Class Initialized
INFO - 2016-09-16 11:45:58 --> Helper loaded: url_helper
INFO - 2016-09-16 11:45:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:45:58 --> Controller Class Initialized
DEBUG - 2016-09-16 11:45:58 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:45:58 --> Model Class Initialized
INFO - 2016-09-16 11:45:58 --> Model Class Initialized
INFO - 2016-09-16 11:45:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:45:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:45:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:45:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:45:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:45:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:45:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:45:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:45:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:45:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:45:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:45:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:45:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:45:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:45:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:45:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:45:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:45:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:45:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:45:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:45:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:45:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:45:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:45:59 --> Database Driver Class Initialized
INFO - 2016-09-16 11:45:59 --> Database Driver Class Initialized
INFO - 2016-09-16 11:45:59 --> Database Driver Class Initialized
INFO - 2016-09-16 11:45:59 --> Database Driver Class Initialized
INFO - 2016-09-16 11:45:59 --> Database Driver Class Initialized
INFO - 2016-09-16 11:45:59 --> Database Driver Class Initialized
INFO - 2016-09-16 11:45:59 --> Database Driver Class Initialized
INFO - 2016-09-16 11:45:59 --> Database Driver Class Initialized
INFO - 2016-09-16 11:45:59 --> Database Driver Class Initialized
INFO - 2016-09-16 11:45:59 --> Database Driver Class Initialized
INFO - 2016-09-16 11:45:59 --> Database Driver Class Initialized
INFO - 2016-09-16 11:45:59 --> Database Driver Class Initialized
INFO - 2016-09-16 11:45:59 --> Database Driver Class Initialized
INFO - 2016-09-16 11:45:59 --> Database Driver Class Initialized
INFO - 2016-09-16 11:45:59 --> Database Driver Class Initialized
INFO - 2016-09-16 11:45:59 --> Database Driver Class Initialized
INFO - 2016-09-16 11:45:59 --> Database Driver Class Initialized
INFO - 2016-09-16 11:45:59 --> Database Driver Class Initialized
INFO - 2016-09-16 11:45:59 --> Database Driver Class Initialized
INFO - 2016-09-16 11:45:59 --> Database Driver Class Initialized
INFO - 2016-09-16 11:45:59 --> Database Driver Class Initialized
DEBUG - 2016-09-16 11:45:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_angsuran.php
INFO - 2016-09-16 11:45:59 --> Final output sent to browser
DEBUG - 2016-09-16 11:45:59 --> Total execution time: 2.0072
INFO - 2016-09-16 11:47:19 --> Config Class Initialized
INFO - 2016-09-16 11:47:19 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:47:19 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:47:19 --> Utf8 Class Initialized
INFO - 2016-09-16 11:47:19 --> URI Class Initialized
INFO - 2016-09-16 11:47:19 --> Router Class Initialized
INFO - 2016-09-16 11:47:19 --> Output Class Initialized
INFO - 2016-09-16 11:47:19 --> Security Class Initialized
DEBUG - 2016-09-16 11:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:47:19 --> Input Class Initialized
INFO - 2016-09-16 11:47:19 --> Language Class Initialized
INFO - 2016-09-16 11:47:19 --> Language Class Initialized
INFO - 2016-09-16 11:47:19 --> Config Class Initialized
INFO - 2016-09-16 11:47:19 --> Loader Class Initialized
INFO - 2016-09-16 11:47:19 --> Helper loaded: url_helper
INFO - 2016-09-16 11:47:19 --> Database Driver Class Initialized
INFO - 2016-09-16 11:47:19 --> Controller Class Initialized
DEBUG - 2016-09-16 11:47:19 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:47:19 --> Model Class Initialized
INFO - 2016-09-16 11:47:19 --> Model Class Initialized
INFO - 2016-09-16 11:47:19 --> Database Driver Class Initialized
INFO - 2016-09-16 11:47:19 --> Database Driver Class Initialized
INFO - 2016-09-16 11:47:19 --> Database Driver Class Initialized
INFO - 2016-09-16 11:47:19 --> Database Driver Class Initialized
INFO - 2016-09-16 11:47:19 --> Database Driver Class Initialized
INFO - 2016-09-16 11:47:20 --> Database Driver Class Initialized
INFO - 2016-09-16 11:47:20 --> Database Driver Class Initialized
INFO - 2016-09-16 11:47:20 --> Database Driver Class Initialized
INFO - 2016-09-16 11:47:20 --> Database Driver Class Initialized
INFO - 2016-09-16 11:47:20 --> Database Driver Class Initialized
INFO - 2016-09-16 11:47:20 --> Database Driver Class Initialized
INFO - 2016-09-16 11:47:20 --> Database Driver Class Initialized
INFO - 2016-09-16 11:47:20 --> Database Driver Class Initialized
INFO - 2016-09-16 11:47:20 --> Database Driver Class Initialized
INFO - 2016-09-16 11:47:20 --> Database Driver Class Initialized
INFO - 2016-09-16 11:47:20 --> Database Driver Class Initialized
INFO - 2016-09-16 11:47:20 --> Database Driver Class Initialized
INFO - 2016-09-16 11:47:20 --> Database Driver Class Initialized
INFO - 2016-09-16 11:47:20 --> Database Driver Class Initialized
INFO - 2016-09-16 11:47:20 --> Database Driver Class Initialized
INFO - 2016-09-16 11:47:20 --> Database Driver Class Initialized
INFO - 2016-09-16 11:47:20 --> Database Driver Class Initialized
INFO - 2016-09-16 11:47:20 --> Database Driver Class Initialized
INFO - 2016-09-16 11:47:20 --> Database Driver Class Initialized
INFO - 2016-09-16 11:47:20 --> Database Driver Class Initialized
INFO - 2016-09-16 11:47:20 --> Database Driver Class Initialized
INFO - 2016-09-16 11:47:20 --> Database Driver Class Initialized
INFO - 2016-09-16 11:47:20 --> Database Driver Class Initialized
INFO - 2016-09-16 11:47:20 --> Database Driver Class Initialized
INFO - 2016-09-16 11:47:20 --> Database Driver Class Initialized
INFO - 2016-09-16 11:47:20 --> Database Driver Class Initialized
INFO - 2016-09-16 11:47:20 --> Database Driver Class Initialized
INFO - 2016-09-16 11:47:20 --> Database Driver Class Initialized
INFO - 2016-09-16 11:47:20 --> Database Driver Class Initialized
INFO - 2016-09-16 11:47:20 --> Database Driver Class Initialized
INFO - 2016-09-16 11:47:20 --> Database Driver Class Initialized
INFO - 2016-09-16 11:47:20 --> Database Driver Class Initialized
INFO - 2016-09-16 11:47:20 --> Database Driver Class Initialized
INFO - 2016-09-16 11:47:21 --> Database Driver Class Initialized
INFO - 2016-09-16 11:47:21 --> Database Driver Class Initialized
INFO - 2016-09-16 11:47:21 --> Database Driver Class Initialized
INFO - 2016-09-16 11:47:21 --> Database Driver Class Initialized
INFO - 2016-09-16 11:47:21 --> Database Driver Class Initialized
INFO - 2016-09-16 11:47:21 --> Database Driver Class Initialized
DEBUG - 2016-09-16 11:47:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_angsuran.php
INFO - 2016-09-16 11:47:21 --> Final output sent to browser
DEBUG - 2016-09-16 11:47:21 --> Total execution time: 1.9559
INFO - 2016-09-16 11:48:26 --> Config Class Initialized
INFO - 2016-09-16 11:48:26 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:48:27 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:48:27 --> Utf8 Class Initialized
INFO - 2016-09-16 11:48:27 --> URI Class Initialized
INFO - 2016-09-16 11:48:27 --> Router Class Initialized
INFO - 2016-09-16 11:48:27 --> Output Class Initialized
INFO - 2016-09-16 11:48:27 --> Security Class Initialized
DEBUG - 2016-09-16 11:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:48:27 --> Input Class Initialized
INFO - 2016-09-16 11:48:27 --> Language Class Initialized
INFO - 2016-09-16 11:48:27 --> Language Class Initialized
INFO - 2016-09-16 11:48:27 --> Config Class Initialized
INFO - 2016-09-16 11:48:27 --> Loader Class Initialized
INFO - 2016-09-16 11:48:27 --> Helper loaded: url_helper
INFO - 2016-09-16 11:48:27 --> Database Driver Class Initialized
INFO - 2016-09-16 11:48:27 --> Controller Class Initialized
DEBUG - 2016-09-16 11:48:27 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:48:27 --> Model Class Initialized
INFO - 2016-09-16 11:48:27 --> Model Class Initialized
DEBUG - 2016-09-16 11:48:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-16 11:48:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-16 11:48:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-16 11:48:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/pinjaman.php
DEBUG - 2016-09-16 11:48:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-16 11:48:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-16 11:48:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-16 11:48:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-16 11:48:27 --> Final output sent to browser
DEBUG - 2016-09-16 11:48:27 --> Total execution time: 0.7354
INFO - 2016-09-16 11:48:32 --> Config Class Initialized
INFO - 2016-09-16 11:48:32 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:48:32 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:48:32 --> Utf8 Class Initialized
INFO - 2016-09-16 11:48:32 --> URI Class Initialized
INFO - 2016-09-16 11:48:32 --> Router Class Initialized
INFO - 2016-09-16 11:48:32 --> Output Class Initialized
INFO - 2016-09-16 11:48:32 --> Security Class Initialized
DEBUG - 2016-09-16 11:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:48:32 --> Input Class Initialized
INFO - 2016-09-16 11:48:32 --> Language Class Initialized
INFO - 2016-09-16 11:48:32 --> Language Class Initialized
INFO - 2016-09-16 11:48:32 --> Config Class Initialized
INFO - 2016-09-16 11:48:33 --> Loader Class Initialized
INFO - 2016-09-16 11:48:33 --> Helper loaded: url_helper
INFO - 2016-09-16 11:48:33 --> Database Driver Class Initialized
INFO - 2016-09-16 11:48:33 --> Controller Class Initialized
DEBUG - 2016-09-16 11:48:33 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:48:33 --> Model Class Initialized
INFO - 2016-09-16 11:48:33 --> Model Class Initialized
DEBUG - 2016-09-16 11:48:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_pinjaman.php
INFO - 2016-09-16 11:48:33 --> Final output sent to browser
DEBUG - 2016-09-16 11:48:33 --> Total execution time: 0.5772
INFO - 2016-09-16 11:48:48 --> Config Class Initialized
INFO - 2016-09-16 11:48:48 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:48:48 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:48:49 --> Utf8 Class Initialized
INFO - 2016-09-16 11:48:49 --> URI Class Initialized
INFO - 2016-09-16 11:48:49 --> Router Class Initialized
INFO - 2016-09-16 11:48:49 --> Output Class Initialized
INFO - 2016-09-16 11:48:49 --> Security Class Initialized
DEBUG - 2016-09-16 11:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:48:49 --> Input Class Initialized
INFO - 2016-09-16 11:48:49 --> Language Class Initialized
INFO - 2016-09-16 11:48:49 --> Language Class Initialized
INFO - 2016-09-16 11:48:49 --> Config Class Initialized
INFO - 2016-09-16 11:48:49 --> Loader Class Initialized
INFO - 2016-09-16 11:48:49 --> Helper loaded: url_helper
INFO - 2016-09-16 11:48:49 --> Database Driver Class Initialized
INFO - 2016-09-16 11:48:49 --> Controller Class Initialized
DEBUG - 2016-09-16 11:48:49 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:48:49 --> Model Class Initialized
INFO - 2016-09-16 11:48:49 --> Model Class Initialized
DEBUG - 2016-09-16 11:48:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-16 11:48:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-16 11:48:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-16 11:48:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/angsuran.php
DEBUG - 2016-09-16 11:48:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-16 11:48:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-16 11:48:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-16 11:48:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-16 11:48:49 --> Final output sent to browser
DEBUG - 2016-09-16 11:48:49 --> Total execution time: 0.7626
INFO - 2016-09-16 11:48:57 --> Config Class Initialized
INFO - 2016-09-16 11:48:57 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:48:57 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:48:57 --> Utf8 Class Initialized
INFO - 2016-09-16 11:48:57 --> URI Class Initialized
INFO - 2016-09-16 11:48:57 --> Router Class Initialized
INFO - 2016-09-16 11:48:57 --> Output Class Initialized
INFO - 2016-09-16 11:48:57 --> Security Class Initialized
DEBUG - 2016-09-16 11:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:48:57 --> Input Class Initialized
INFO - 2016-09-16 11:48:57 --> Language Class Initialized
INFO - 2016-09-16 11:48:57 --> Language Class Initialized
INFO - 2016-09-16 11:48:57 --> Config Class Initialized
INFO - 2016-09-16 11:48:57 --> Loader Class Initialized
INFO - 2016-09-16 11:48:57 --> Helper loaded: url_helper
INFO - 2016-09-16 11:48:57 --> Database Driver Class Initialized
INFO - 2016-09-16 11:48:57 --> Controller Class Initialized
DEBUG - 2016-09-16 11:48:57 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:48:57 --> Model Class Initialized
INFO - 2016-09-16 11:48:57 --> Model Class Initialized
INFO - 2016-09-16 11:48:57 --> Database Driver Class Initialized
INFO - 2016-09-16 11:48:57 --> Database Driver Class Initialized
INFO - 2016-09-16 11:48:57 --> Database Driver Class Initialized
INFO - 2016-09-16 11:48:57 --> Database Driver Class Initialized
INFO - 2016-09-16 11:48:57 --> Database Driver Class Initialized
INFO - 2016-09-16 11:48:57 --> Database Driver Class Initialized
INFO - 2016-09-16 11:48:57 --> Database Driver Class Initialized
INFO - 2016-09-16 11:48:57 --> Database Driver Class Initialized
INFO - 2016-09-16 11:48:57 --> Database Driver Class Initialized
INFO - 2016-09-16 11:48:57 --> Database Driver Class Initialized
INFO - 2016-09-16 11:48:57 --> Database Driver Class Initialized
INFO - 2016-09-16 11:48:57 --> Database Driver Class Initialized
INFO - 2016-09-16 11:48:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:48:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:48:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:48:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:48:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:48:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:48:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:48:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:48:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:48:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:48:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:48:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:48:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:48:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:48:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:48:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:48:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:48:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:48:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:48:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:48:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:48:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:48:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:48:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:48:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:48:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:48:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:48:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:48:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:48:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:48:58 --> Database Driver Class Initialized
INFO - 2016-09-16 11:48:58 --> Database Driver Class Initialized
DEBUG - 2016-09-16 11:48:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_angsuran.php
INFO - 2016-09-16 11:48:59 --> Final output sent to browser
DEBUG - 2016-09-16 11:48:59 --> Total execution time: 1.8575
INFO - 2016-09-16 11:49:39 --> Config Class Initialized
INFO - 2016-09-16 11:49:39 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:49:39 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:49:39 --> Utf8 Class Initialized
INFO - 2016-09-16 11:49:39 --> URI Class Initialized
INFO - 2016-09-16 11:49:39 --> Router Class Initialized
INFO - 2016-09-16 11:49:39 --> Output Class Initialized
INFO - 2016-09-16 11:49:39 --> Security Class Initialized
DEBUG - 2016-09-16 11:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:49:39 --> Input Class Initialized
INFO - 2016-09-16 11:49:39 --> Language Class Initialized
INFO - 2016-09-16 11:49:39 --> Language Class Initialized
INFO - 2016-09-16 11:49:39 --> Config Class Initialized
INFO - 2016-09-16 11:49:39 --> Loader Class Initialized
INFO - 2016-09-16 11:49:39 --> Helper loaded: url_helper
INFO - 2016-09-16 11:49:39 --> Database Driver Class Initialized
INFO - 2016-09-16 11:49:39 --> Controller Class Initialized
DEBUG - 2016-09-16 11:49:39 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:49:39 --> Model Class Initialized
INFO - 2016-09-16 11:49:39 --> Model Class Initialized
DEBUG - 2016-09-16 11:49:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-16 11:49:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-16 11:49:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-16 11:49:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/jurnal_umum.php
DEBUG - 2016-09-16 11:49:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-16 11:49:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-16 11:49:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-16 11:49:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-16 11:49:40 --> Final output sent to browser
DEBUG - 2016-09-16 11:49:40 --> Total execution time: 0.7285
INFO - 2016-09-16 11:49:44 --> Config Class Initialized
INFO - 2016-09-16 11:49:44 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:49:44 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:49:44 --> Utf8 Class Initialized
INFO - 2016-09-16 11:49:44 --> URI Class Initialized
INFO - 2016-09-16 11:49:44 --> Router Class Initialized
INFO - 2016-09-16 11:49:44 --> Output Class Initialized
INFO - 2016-09-16 11:49:44 --> Security Class Initialized
DEBUG - 2016-09-16 11:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:49:44 --> Input Class Initialized
INFO - 2016-09-16 11:49:44 --> Language Class Initialized
INFO - 2016-09-16 11:49:45 --> Language Class Initialized
INFO - 2016-09-16 11:49:45 --> Config Class Initialized
INFO - 2016-09-16 11:49:45 --> Loader Class Initialized
INFO - 2016-09-16 11:49:45 --> Helper loaded: url_helper
INFO - 2016-09-16 11:49:45 --> Database Driver Class Initialized
INFO - 2016-09-16 11:49:45 --> Controller Class Initialized
DEBUG - 2016-09-16 11:49:45 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:49:45 --> Model Class Initialized
INFO - 2016-09-16 11:49:45 --> Model Class Initialized
DEBUG - 2016-09-16 11:49:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_jurnal_umum.php
INFO - 2016-09-16 11:49:45 --> Final output sent to browser
DEBUG - 2016-09-16 11:49:45 --> Total execution time: 0.6160
INFO - 2016-09-16 11:50:21 --> Config Class Initialized
INFO - 2016-09-16 11:50:21 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:50:21 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:50:21 --> Utf8 Class Initialized
INFO - 2016-09-16 11:50:21 --> URI Class Initialized
INFO - 2016-09-16 11:50:21 --> Router Class Initialized
INFO - 2016-09-16 11:50:21 --> Output Class Initialized
INFO - 2016-09-16 11:50:21 --> Security Class Initialized
DEBUG - 2016-09-16 11:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:50:21 --> Input Class Initialized
INFO - 2016-09-16 11:50:21 --> Language Class Initialized
INFO - 2016-09-16 11:50:21 --> Language Class Initialized
INFO - 2016-09-16 11:50:21 --> Config Class Initialized
INFO - 2016-09-16 11:50:22 --> Loader Class Initialized
INFO - 2016-09-16 11:50:22 --> Helper loaded: url_helper
INFO - 2016-09-16 11:50:22 --> Database Driver Class Initialized
INFO - 2016-09-16 11:50:22 --> Controller Class Initialized
DEBUG - 2016-09-16 11:50:22 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:50:22 --> Model Class Initialized
INFO - 2016-09-16 11:50:22 --> Model Class Initialized
DEBUG - 2016-09-16 11:50:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-16 11:50:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-16 11:50:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-16 11:50:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/angsuran.php
DEBUG - 2016-09-16 11:50:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-16 11:50:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-16 11:50:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-16 11:50:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-16 11:50:22 --> Final output sent to browser
DEBUG - 2016-09-16 11:50:22 --> Total execution time: 0.7341
INFO - 2016-09-16 11:50:27 --> Config Class Initialized
INFO - 2016-09-16 11:50:27 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:50:27 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:50:27 --> Utf8 Class Initialized
INFO - 2016-09-16 11:50:27 --> URI Class Initialized
INFO - 2016-09-16 11:50:27 --> Router Class Initialized
INFO - 2016-09-16 11:50:27 --> Output Class Initialized
INFO - 2016-09-16 11:50:27 --> Security Class Initialized
DEBUG - 2016-09-16 11:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:50:27 --> Input Class Initialized
INFO - 2016-09-16 11:50:27 --> Language Class Initialized
INFO - 2016-09-16 11:50:27 --> Language Class Initialized
INFO - 2016-09-16 11:50:27 --> Config Class Initialized
INFO - 2016-09-16 11:50:27 --> Loader Class Initialized
INFO - 2016-09-16 11:50:27 --> Helper loaded: url_helper
INFO - 2016-09-16 11:50:27 --> Database Driver Class Initialized
INFO - 2016-09-16 11:50:27 --> Controller Class Initialized
DEBUG - 2016-09-16 11:50:27 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:50:27 --> Model Class Initialized
INFO - 2016-09-16 11:50:27 --> Model Class Initialized
INFO - 2016-09-16 11:50:27 --> Database Driver Class Initialized
INFO - 2016-09-16 11:50:27 --> Database Driver Class Initialized
INFO - 2016-09-16 11:50:27 --> Database Driver Class Initialized
INFO - 2016-09-16 11:50:27 --> Database Driver Class Initialized
INFO - 2016-09-16 11:50:27 --> Database Driver Class Initialized
INFO - 2016-09-16 11:50:27 --> Database Driver Class Initialized
INFO - 2016-09-16 11:50:27 --> Database Driver Class Initialized
INFO - 2016-09-16 11:50:27 --> Database Driver Class Initialized
INFO - 2016-09-16 11:50:27 --> Database Driver Class Initialized
INFO - 2016-09-16 11:50:28 --> Database Driver Class Initialized
INFO - 2016-09-16 11:50:28 --> Database Driver Class Initialized
INFO - 2016-09-16 11:50:28 --> Database Driver Class Initialized
INFO - 2016-09-16 11:50:28 --> Database Driver Class Initialized
INFO - 2016-09-16 11:50:28 --> Database Driver Class Initialized
INFO - 2016-09-16 11:50:28 --> Database Driver Class Initialized
INFO - 2016-09-16 11:50:28 --> Database Driver Class Initialized
INFO - 2016-09-16 11:50:28 --> Database Driver Class Initialized
INFO - 2016-09-16 11:50:28 --> Database Driver Class Initialized
INFO - 2016-09-16 11:50:28 --> Database Driver Class Initialized
INFO - 2016-09-16 11:50:28 --> Database Driver Class Initialized
INFO - 2016-09-16 11:50:28 --> Database Driver Class Initialized
INFO - 2016-09-16 11:50:28 --> Database Driver Class Initialized
INFO - 2016-09-16 11:50:28 --> Database Driver Class Initialized
INFO - 2016-09-16 11:50:28 --> Database Driver Class Initialized
INFO - 2016-09-16 11:50:28 --> Database Driver Class Initialized
INFO - 2016-09-16 11:50:28 --> Database Driver Class Initialized
INFO - 2016-09-16 11:50:28 --> Database Driver Class Initialized
INFO - 2016-09-16 11:50:28 --> Database Driver Class Initialized
INFO - 2016-09-16 11:50:28 --> Database Driver Class Initialized
INFO - 2016-09-16 11:50:28 --> Database Driver Class Initialized
INFO - 2016-09-16 11:50:28 --> Database Driver Class Initialized
INFO - 2016-09-16 11:50:28 --> Database Driver Class Initialized
INFO - 2016-09-16 11:50:28 --> Database Driver Class Initialized
INFO - 2016-09-16 11:50:28 --> Database Driver Class Initialized
INFO - 2016-09-16 11:50:28 --> Database Driver Class Initialized
INFO - 2016-09-16 11:50:28 --> Database Driver Class Initialized
INFO - 2016-09-16 11:50:28 --> Database Driver Class Initialized
INFO - 2016-09-16 11:50:28 --> Database Driver Class Initialized
INFO - 2016-09-16 11:50:29 --> Database Driver Class Initialized
INFO - 2016-09-16 11:50:29 --> Database Driver Class Initialized
INFO - 2016-09-16 11:50:29 --> Database Driver Class Initialized
INFO - 2016-09-16 11:50:29 --> Database Driver Class Initialized
INFO - 2016-09-16 11:50:29 --> Database Driver Class Initialized
INFO - 2016-09-16 11:50:29 --> Database Driver Class Initialized
DEBUG - 2016-09-16 11:50:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_angsuran.php
INFO - 2016-09-16 11:50:29 --> Final output sent to browser
DEBUG - 2016-09-16 11:50:29 --> Total execution time: 1.9974
INFO - 2016-09-16 11:50:33 --> Config Class Initialized
INFO - 2016-09-16 11:50:33 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:50:33 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:50:33 --> Utf8 Class Initialized
INFO - 2016-09-16 11:50:33 --> URI Class Initialized
INFO - 2016-09-16 11:50:33 --> Router Class Initialized
INFO - 2016-09-16 11:50:33 --> Output Class Initialized
INFO - 2016-09-16 11:50:33 --> Security Class Initialized
DEBUG - 2016-09-16 11:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:50:33 --> Input Class Initialized
INFO - 2016-09-16 11:50:33 --> Language Class Initialized
INFO - 2016-09-16 11:50:34 --> Language Class Initialized
INFO - 2016-09-16 11:50:34 --> Config Class Initialized
INFO - 2016-09-16 11:50:34 --> Loader Class Initialized
INFO - 2016-09-16 11:50:34 --> Helper loaded: url_helper
INFO - 2016-09-16 11:50:34 --> Database Driver Class Initialized
INFO - 2016-09-16 11:50:34 --> Controller Class Initialized
DEBUG - 2016-09-16 11:50:34 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:50:34 --> Model Class Initialized
INFO - 2016-09-16 11:50:34 --> Model Class Initialized
DEBUG - 2016-09-16 11:50:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-16 11:50:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-16 11:50:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-16 11:50:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/pinjaman.php
DEBUG - 2016-09-16 11:50:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-16 11:50:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-16 11:50:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-16 11:50:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-16 11:50:34 --> Final output sent to browser
DEBUG - 2016-09-16 11:50:34 --> Total execution time: 0.8400
INFO - 2016-09-16 11:50:45 --> Config Class Initialized
INFO - 2016-09-16 11:50:45 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:50:45 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:50:45 --> Utf8 Class Initialized
INFO - 2016-09-16 11:50:45 --> URI Class Initialized
INFO - 2016-09-16 11:50:45 --> Router Class Initialized
INFO - 2016-09-16 11:50:45 --> Output Class Initialized
INFO - 2016-09-16 11:50:45 --> Security Class Initialized
DEBUG - 2016-09-16 11:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:50:45 --> Input Class Initialized
INFO - 2016-09-16 11:50:45 --> Language Class Initialized
INFO - 2016-09-16 11:50:45 --> Language Class Initialized
INFO - 2016-09-16 11:50:45 --> Config Class Initialized
INFO - 2016-09-16 11:50:45 --> Loader Class Initialized
INFO - 2016-09-16 11:50:45 --> Helper loaded: url_helper
INFO - 2016-09-16 11:50:45 --> Database Driver Class Initialized
INFO - 2016-09-16 11:50:45 --> Controller Class Initialized
DEBUG - 2016-09-16 11:50:45 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:50:45 --> Model Class Initialized
INFO - 2016-09-16 11:50:45 --> Model Class Initialized
DEBUG - 2016-09-16 11:50:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_pinjaman.php
INFO - 2016-09-16 11:50:45 --> Final output sent to browser
DEBUG - 2016-09-16 11:50:45 --> Total execution time: 0.5680
INFO - 2016-09-16 11:51:29 --> Config Class Initialized
INFO - 2016-09-16 11:51:29 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:51:29 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:51:29 --> Utf8 Class Initialized
INFO - 2016-09-16 11:51:29 --> URI Class Initialized
INFO - 2016-09-16 11:51:29 --> Router Class Initialized
INFO - 2016-09-16 11:51:29 --> Output Class Initialized
INFO - 2016-09-16 11:51:29 --> Security Class Initialized
DEBUG - 2016-09-16 11:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:51:29 --> Input Class Initialized
INFO - 2016-09-16 11:51:29 --> Language Class Initialized
INFO - 2016-09-16 11:51:29 --> Language Class Initialized
INFO - 2016-09-16 11:51:29 --> Config Class Initialized
INFO - 2016-09-16 11:51:29 --> Loader Class Initialized
INFO - 2016-09-16 11:51:29 --> Helper loaded: url_helper
INFO - 2016-09-16 11:51:29 --> Database Driver Class Initialized
INFO - 2016-09-16 11:51:29 --> Controller Class Initialized
DEBUG - 2016-09-16 11:51:29 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:51:29 --> Model Class Initialized
INFO - 2016-09-16 11:51:29 --> Model Class Initialized
DEBUG - 2016-09-16 11:51:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-16 11:51:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-16 11:51:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-16 11:51:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/jurnal_umum.php
DEBUG - 2016-09-16 11:51:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-16 11:51:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-16 11:51:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-16 11:51:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-16 11:51:30 --> Final output sent to browser
DEBUG - 2016-09-16 11:51:30 --> Total execution time: 0.8738
INFO - 2016-09-16 11:51:37 --> Config Class Initialized
INFO - 2016-09-16 11:51:37 --> Hooks Class Initialized
DEBUG - 2016-09-16 11:51:37 --> UTF-8 Support Enabled
INFO - 2016-09-16 11:51:37 --> Utf8 Class Initialized
INFO - 2016-09-16 11:51:37 --> URI Class Initialized
INFO - 2016-09-16 11:51:37 --> Router Class Initialized
INFO - 2016-09-16 11:51:38 --> Output Class Initialized
INFO - 2016-09-16 11:51:38 --> Security Class Initialized
DEBUG - 2016-09-16 11:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-16 11:51:38 --> Input Class Initialized
INFO - 2016-09-16 11:51:38 --> Language Class Initialized
INFO - 2016-09-16 11:51:38 --> Language Class Initialized
INFO - 2016-09-16 11:51:38 --> Config Class Initialized
INFO - 2016-09-16 11:51:38 --> Loader Class Initialized
INFO - 2016-09-16 11:51:38 --> Helper loaded: url_helper
INFO - 2016-09-16 11:51:38 --> Database Driver Class Initialized
INFO - 2016-09-16 11:51:38 --> Controller Class Initialized
DEBUG - 2016-09-16 11:51:38 --> Index MX_Controller Initialized
INFO - 2016-09-16 11:51:38 --> Model Class Initialized
INFO - 2016-09-16 11:51:38 --> Model Class Initialized
DEBUG - 2016-09-16 11:51:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_jurnal_umum.php
INFO - 2016-09-16 11:51:38 --> Final output sent to browser
DEBUG - 2016-09-16 11:51:38 --> Total execution time: 0.6261
