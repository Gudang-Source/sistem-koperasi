<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-09-08 06:01:51 --> Config Class Initialized
INFO - 2016-09-08 06:01:51 --> Hooks Class Initialized
DEBUG - 2016-09-08 06:01:51 --> UTF-8 Support Enabled
INFO - 2016-09-08 06:01:51 --> Utf8 Class Initialized
INFO - 2016-09-08 06:01:51 --> URI Class Initialized
INFO - 2016-09-08 06:01:51 --> Router Class Initialized
INFO - 2016-09-08 06:01:51 --> Output Class Initialized
INFO - 2016-09-08 06:01:51 --> Security Class Initialized
DEBUG - 2016-09-08 06:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 06:01:51 --> Input Class Initialized
INFO - 2016-09-08 06:01:51 --> Language Class Initialized
INFO - 2016-09-08 06:01:51 --> Language Class Initialized
INFO - 2016-09-08 06:01:51 --> Config Class Initialized
INFO - 2016-09-08 06:01:51 --> Loader Class Initialized
INFO - 2016-09-08 06:01:51 --> Helper loaded: url_helper
INFO - 2016-09-08 06:01:51 --> Database Driver Class Initialized
INFO - 2016-09-08 06:01:51 --> Controller Class Initialized
DEBUG - 2016-09-08 06:01:51 --> Index MX_Controller Initialized
INFO - 2016-09-08 06:01:51 --> Model Class Initialized
INFO - 2016-09-08 06:01:51 --> Model Class Initialized
DEBUG - 2016-09-08 06:01:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 06:01:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 06:01:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 06:01:52 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 06:01:52 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 06:01:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 06:01:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 06:01:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 06:01:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 06:01:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 06:01:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 06:01:52 --> Final output sent to browser
DEBUG - 2016-09-08 06:01:52 --> Total execution time: 0.6049
INFO - 2016-09-08 06:02:48 --> Config Class Initialized
INFO - 2016-09-08 06:02:48 --> Hooks Class Initialized
DEBUG - 2016-09-08 06:02:48 --> UTF-8 Support Enabled
INFO - 2016-09-08 06:02:48 --> Utf8 Class Initialized
INFO - 2016-09-08 06:02:48 --> URI Class Initialized
INFO - 2016-09-08 06:02:48 --> Router Class Initialized
INFO - 2016-09-08 06:02:48 --> Output Class Initialized
INFO - 2016-09-08 06:02:48 --> Security Class Initialized
DEBUG - 2016-09-08 06:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 06:02:48 --> Input Class Initialized
INFO - 2016-09-08 06:02:48 --> Language Class Initialized
INFO - 2016-09-08 06:02:48 --> Language Class Initialized
INFO - 2016-09-08 06:02:48 --> Config Class Initialized
INFO - 2016-09-08 06:02:48 --> Loader Class Initialized
INFO - 2016-09-08 06:02:49 --> Helper loaded: url_helper
INFO - 2016-09-08 06:02:49 --> Database Driver Class Initialized
INFO - 2016-09-08 06:02:49 --> Controller Class Initialized
DEBUG - 2016-09-08 06:02:49 --> Index MX_Controller Initialized
INFO - 2016-09-08 06:02:49 --> Model Class Initialized
INFO - 2016-09-08 06:02:49 --> Model Class Initialized
DEBUG - 2016-09-08 06:02:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 06:02:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 06:02:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 06:02:49 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 06:02:49 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 06:02:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 06:02:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 06:02:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 06:02:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 06:02:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 06:02:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 06:02:49 --> Final output sent to browser
DEBUG - 2016-09-08 06:02:49 --> Total execution time: 0.6375
INFO - 2016-09-08 06:03:42 --> Config Class Initialized
INFO - 2016-09-08 06:03:42 --> Hooks Class Initialized
DEBUG - 2016-09-08 06:03:42 --> UTF-8 Support Enabled
INFO - 2016-09-08 06:03:42 --> Utf8 Class Initialized
INFO - 2016-09-08 06:03:42 --> URI Class Initialized
INFO - 2016-09-08 06:03:42 --> Router Class Initialized
INFO - 2016-09-08 06:03:42 --> Output Class Initialized
INFO - 2016-09-08 06:03:42 --> Security Class Initialized
DEBUG - 2016-09-08 06:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 06:03:42 --> Input Class Initialized
INFO - 2016-09-08 06:03:42 --> Language Class Initialized
INFO - 2016-09-08 06:03:42 --> Language Class Initialized
INFO - 2016-09-08 06:03:42 --> Config Class Initialized
INFO - 2016-09-08 06:03:42 --> Loader Class Initialized
INFO - 2016-09-08 06:03:42 --> Helper loaded: url_helper
INFO - 2016-09-08 06:03:42 --> Database Driver Class Initialized
INFO - 2016-09-08 06:03:42 --> Controller Class Initialized
DEBUG - 2016-09-08 06:03:42 --> Index MX_Controller Initialized
INFO - 2016-09-08 06:03:42 --> Model Class Initialized
INFO - 2016-09-08 06:03:42 --> Model Class Initialized
DEBUG - 2016-09-08 06:03:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 06:03:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 06:03:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 06:03:42 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 06:03:42 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 06:03:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 06:03:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 06:03:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 06:03:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 06:03:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 06:03:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 06:03:43 --> Final output sent to browser
DEBUG - 2016-09-08 06:03:43 --> Total execution time: 0.5786
INFO - 2016-09-08 06:07:00 --> Config Class Initialized
INFO - 2016-09-08 06:07:00 --> Hooks Class Initialized
DEBUG - 2016-09-08 06:07:00 --> UTF-8 Support Enabled
INFO - 2016-09-08 06:07:01 --> Utf8 Class Initialized
INFO - 2016-09-08 06:07:01 --> URI Class Initialized
INFO - 2016-09-08 06:07:01 --> Router Class Initialized
INFO - 2016-09-08 06:07:01 --> Output Class Initialized
INFO - 2016-09-08 06:07:01 --> Security Class Initialized
DEBUG - 2016-09-08 06:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 06:07:01 --> Input Class Initialized
INFO - 2016-09-08 06:07:01 --> Language Class Initialized
INFO - 2016-09-08 06:07:01 --> Language Class Initialized
INFO - 2016-09-08 06:07:01 --> Config Class Initialized
INFO - 2016-09-08 06:07:01 --> Loader Class Initialized
INFO - 2016-09-08 06:07:02 --> Helper loaded: url_helper
INFO - 2016-09-08 06:07:02 --> Database Driver Class Initialized
INFO - 2016-09-08 06:07:02 --> Controller Class Initialized
DEBUG - 2016-09-08 06:07:02 --> Index MX_Controller Initialized
INFO - 2016-09-08 06:07:02 --> Model Class Initialized
INFO - 2016-09-08 06:07:02 --> Model Class Initialized
DEBUG - 2016-09-08 06:07:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 06:07:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 06:07:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 06:07:02 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 06:07:02 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 06:07:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 06:07:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 06:07:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 06:07:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 06:07:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 06:07:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 06:07:03 --> Final output sent to browser
DEBUG - 2016-09-08 06:07:03 --> Total execution time: 2.4037
INFO - 2016-09-08 06:09:08 --> Config Class Initialized
INFO - 2016-09-08 06:09:08 --> Hooks Class Initialized
DEBUG - 2016-09-08 06:09:08 --> UTF-8 Support Enabled
INFO - 2016-09-08 06:09:08 --> Utf8 Class Initialized
INFO - 2016-09-08 06:09:08 --> URI Class Initialized
INFO - 2016-09-08 06:09:08 --> Router Class Initialized
INFO - 2016-09-08 06:09:08 --> Output Class Initialized
INFO - 2016-09-08 06:09:08 --> Security Class Initialized
DEBUG - 2016-09-08 06:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 06:09:08 --> Input Class Initialized
INFO - 2016-09-08 06:09:08 --> Language Class Initialized
INFO - 2016-09-08 06:09:08 --> Language Class Initialized
INFO - 2016-09-08 06:09:08 --> Config Class Initialized
INFO - 2016-09-08 06:09:08 --> Loader Class Initialized
INFO - 2016-09-08 06:09:08 --> Helper loaded: url_helper
INFO - 2016-09-08 06:09:08 --> Database Driver Class Initialized
INFO - 2016-09-08 06:09:09 --> Controller Class Initialized
DEBUG - 2016-09-08 06:09:09 --> Index MX_Controller Initialized
INFO - 2016-09-08 06:09:09 --> Model Class Initialized
INFO - 2016-09-08 06:09:09 --> Model Class Initialized
DEBUG - 2016-09-08 06:09:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 06:09:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 06:09:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 06:09:09 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 06:09:09 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 06:09:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 06:09:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 06:09:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 06:09:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 06:09:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 06:09:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 06:09:09 --> Final output sent to browser
DEBUG - 2016-09-08 06:09:09 --> Total execution time: 0.6110
INFO - 2016-09-08 06:09:41 --> Config Class Initialized
INFO - 2016-09-08 06:09:41 --> Hooks Class Initialized
DEBUG - 2016-09-08 06:09:41 --> UTF-8 Support Enabled
INFO - 2016-09-08 06:09:41 --> Utf8 Class Initialized
INFO - 2016-09-08 06:09:41 --> URI Class Initialized
INFO - 2016-09-08 06:09:41 --> Router Class Initialized
INFO - 2016-09-08 06:09:41 --> Output Class Initialized
INFO - 2016-09-08 06:09:41 --> Security Class Initialized
DEBUG - 2016-09-08 06:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 06:09:41 --> Input Class Initialized
INFO - 2016-09-08 06:09:41 --> Language Class Initialized
INFO - 2016-09-08 06:09:41 --> Language Class Initialized
INFO - 2016-09-08 06:09:41 --> Config Class Initialized
INFO - 2016-09-08 06:09:41 --> Loader Class Initialized
INFO - 2016-09-08 06:09:41 --> Helper loaded: url_helper
INFO - 2016-09-08 06:09:41 --> Database Driver Class Initialized
INFO - 2016-09-08 06:09:41 --> Controller Class Initialized
DEBUG - 2016-09-08 06:09:41 --> Index MX_Controller Initialized
INFO - 2016-09-08 06:09:41 --> Model Class Initialized
INFO - 2016-09-08 06:09:41 --> Model Class Initialized
DEBUG - 2016-09-08 06:09:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 06:09:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 06:09:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 06:09:41 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 06:09:42 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 06:09:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 06:09:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 06:09:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 06:09:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 06:09:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 06:09:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 06:09:42 --> Final output sent to browser
DEBUG - 2016-09-08 06:09:42 --> Total execution time: 0.6348
INFO - 2016-09-08 06:10:25 --> Config Class Initialized
INFO - 2016-09-08 06:10:25 --> Hooks Class Initialized
DEBUG - 2016-09-08 06:10:25 --> UTF-8 Support Enabled
INFO - 2016-09-08 06:10:25 --> Utf8 Class Initialized
INFO - 2016-09-08 06:10:25 --> URI Class Initialized
INFO - 2016-09-08 06:10:25 --> Router Class Initialized
INFO - 2016-09-08 06:10:25 --> Output Class Initialized
INFO - 2016-09-08 06:10:25 --> Security Class Initialized
DEBUG - 2016-09-08 06:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 06:10:25 --> Input Class Initialized
INFO - 2016-09-08 06:10:25 --> Language Class Initialized
INFO - 2016-09-08 06:10:25 --> Language Class Initialized
INFO - 2016-09-08 06:10:25 --> Config Class Initialized
INFO - 2016-09-08 06:10:25 --> Loader Class Initialized
INFO - 2016-09-08 06:10:26 --> Helper loaded: url_helper
INFO - 2016-09-08 06:10:26 --> Database Driver Class Initialized
INFO - 2016-09-08 06:10:26 --> Controller Class Initialized
DEBUG - 2016-09-08 06:10:26 --> Index MX_Controller Initialized
INFO - 2016-09-08 06:10:26 --> Model Class Initialized
INFO - 2016-09-08 06:10:26 --> Model Class Initialized
DEBUG - 2016-09-08 06:10:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 06:10:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 06:10:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 06:10:26 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 06:10:26 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 06:10:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 06:10:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 06:10:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 06:10:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 06:10:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 06:10:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 06:10:26 --> Final output sent to browser
DEBUG - 2016-09-08 06:10:26 --> Total execution time: 0.6165
INFO - 2016-09-08 06:12:12 --> Config Class Initialized
INFO - 2016-09-08 06:12:12 --> Hooks Class Initialized
DEBUG - 2016-09-08 06:12:13 --> UTF-8 Support Enabled
INFO - 2016-09-08 06:12:13 --> Utf8 Class Initialized
INFO - 2016-09-08 06:12:13 --> URI Class Initialized
INFO - 2016-09-08 06:12:13 --> Router Class Initialized
INFO - 2016-09-08 06:12:13 --> Output Class Initialized
INFO - 2016-09-08 06:12:13 --> Security Class Initialized
DEBUG - 2016-09-08 06:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 06:12:13 --> Input Class Initialized
INFO - 2016-09-08 06:12:13 --> Language Class Initialized
INFO - 2016-09-08 06:12:13 --> Language Class Initialized
INFO - 2016-09-08 06:12:13 --> Config Class Initialized
INFO - 2016-09-08 06:12:13 --> Loader Class Initialized
INFO - 2016-09-08 06:12:13 --> Helper loaded: url_helper
INFO - 2016-09-08 06:12:13 --> Database Driver Class Initialized
INFO - 2016-09-08 06:12:13 --> Controller Class Initialized
DEBUG - 2016-09-08 06:12:13 --> Index MX_Controller Initialized
INFO - 2016-09-08 06:12:13 --> Model Class Initialized
INFO - 2016-09-08 06:12:13 --> Model Class Initialized
DEBUG - 2016-09-08 06:12:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 06:12:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 06:12:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 06:12:13 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 06:12:13 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 06:12:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 06:12:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 06:12:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 06:12:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 06:12:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 06:12:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 06:12:13 --> Final output sent to browser
DEBUG - 2016-09-08 06:12:13 --> Total execution time: 0.6641
INFO - 2016-09-08 06:13:08 --> Config Class Initialized
INFO - 2016-09-08 06:13:08 --> Hooks Class Initialized
DEBUG - 2016-09-08 06:13:08 --> UTF-8 Support Enabled
INFO - 2016-09-08 06:13:08 --> Utf8 Class Initialized
INFO - 2016-09-08 06:13:08 --> URI Class Initialized
INFO - 2016-09-08 06:13:08 --> Router Class Initialized
INFO - 2016-09-08 06:13:08 --> Output Class Initialized
INFO - 2016-09-08 06:13:08 --> Security Class Initialized
DEBUG - 2016-09-08 06:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 06:13:08 --> Input Class Initialized
INFO - 2016-09-08 06:13:08 --> Language Class Initialized
INFO - 2016-09-08 06:13:08 --> Language Class Initialized
INFO - 2016-09-08 06:13:08 --> Config Class Initialized
INFO - 2016-09-08 06:13:08 --> Loader Class Initialized
INFO - 2016-09-08 06:13:08 --> Helper loaded: url_helper
INFO - 2016-09-08 06:13:08 --> Database Driver Class Initialized
INFO - 2016-09-08 06:13:08 --> Controller Class Initialized
DEBUG - 2016-09-08 06:13:08 --> Index MX_Controller Initialized
INFO - 2016-09-08 06:13:08 --> Model Class Initialized
INFO - 2016-09-08 06:13:08 --> Model Class Initialized
DEBUG - 2016-09-08 06:13:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 06:13:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 06:13:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 06:13:08 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 06:13:08 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 06:13:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 06:13:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 06:13:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 06:13:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 06:13:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 06:13:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 06:13:08 --> Final output sent to browser
DEBUG - 2016-09-08 06:13:08 --> Total execution time: 0.6512
INFO - 2016-09-08 06:13:44 --> Config Class Initialized
INFO - 2016-09-08 06:13:44 --> Hooks Class Initialized
DEBUG - 2016-09-08 06:13:44 --> UTF-8 Support Enabled
INFO - 2016-09-08 06:13:44 --> Utf8 Class Initialized
INFO - 2016-09-08 06:13:44 --> URI Class Initialized
INFO - 2016-09-08 06:13:44 --> Router Class Initialized
INFO - 2016-09-08 06:13:44 --> Output Class Initialized
INFO - 2016-09-08 06:13:44 --> Security Class Initialized
DEBUG - 2016-09-08 06:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 06:13:45 --> Input Class Initialized
INFO - 2016-09-08 06:13:45 --> Language Class Initialized
INFO - 2016-09-08 06:13:45 --> Language Class Initialized
INFO - 2016-09-08 06:13:45 --> Config Class Initialized
INFO - 2016-09-08 06:13:45 --> Loader Class Initialized
INFO - 2016-09-08 06:13:45 --> Helper loaded: url_helper
INFO - 2016-09-08 06:13:45 --> Database Driver Class Initialized
INFO - 2016-09-08 06:13:45 --> Controller Class Initialized
DEBUG - 2016-09-08 06:13:45 --> Index MX_Controller Initialized
INFO - 2016-09-08 06:13:45 --> Model Class Initialized
INFO - 2016-09-08 06:13:45 --> Model Class Initialized
DEBUG - 2016-09-08 06:13:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 06:13:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 06:13:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 06:13:45 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 06:13:45 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 06:13:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 06:13:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 06:13:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 06:13:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 06:13:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 06:13:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 06:13:45 --> Final output sent to browser
DEBUG - 2016-09-08 06:13:45 --> Total execution time: 0.5660
INFO - 2016-09-08 06:15:18 --> Config Class Initialized
INFO - 2016-09-08 06:15:18 --> Hooks Class Initialized
DEBUG - 2016-09-08 06:15:18 --> UTF-8 Support Enabled
INFO - 2016-09-08 06:15:18 --> Utf8 Class Initialized
INFO - 2016-09-08 06:15:18 --> URI Class Initialized
INFO - 2016-09-08 06:15:18 --> Router Class Initialized
INFO - 2016-09-08 06:15:18 --> Output Class Initialized
INFO - 2016-09-08 06:15:18 --> Security Class Initialized
DEBUG - 2016-09-08 06:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 06:15:18 --> Input Class Initialized
INFO - 2016-09-08 06:15:18 --> Language Class Initialized
INFO - 2016-09-08 06:15:18 --> Language Class Initialized
INFO - 2016-09-08 06:15:18 --> Config Class Initialized
INFO - 2016-09-08 06:15:19 --> Loader Class Initialized
INFO - 2016-09-08 06:15:19 --> Helper loaded: url_helper
INFO - 2016-09-08 06:15:19 --> Database Driver Class Initialized
INFO - 2016-09-08 06:15:19 --> Controller Class Initialized
DEBUG - 2016-09-08 06:15:19 --> Index MX_Controller Initialized
INFO - 2016-09-08 06:15:19 --> Model Class Initialized
INFO - 2016-09-08 06:15:19 --> Model Class Initialized
DEBUG - 2016-09-08 06:15:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 06:15:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 06:15:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 06:15:19 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 06:15:19 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 06:15:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 06:15:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 06:15:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 06:15:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 06:15:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 06:15:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 06:15:19 --> Final output sent to browser
DEBUG - 2016-09-08 06:15:19 --> Total execution time: 0.6552
INFO - 2016-09-08 06:16:30 --> Config Class Initialized
INFO - 2016-09-08 06:16:30 --> Hooks Class Initialized
DEBUG - 2016-09-08 06:16:30 --> UTF-8 Support Enabled
INFO - 2016-09-08 06:16:30 --> Utf8 Class Initialized
INFO - 2016-09-08 06:16:30 --> URI Class Initialized
INFO - 2016-09-08 06:16:30 --> Router Class Initialized
INFO - 2016-09-08 06:16:30 --> Output Class Initialized
INFO - 2016-09-08 06:16:30 --> Security Class Initialized
DEBUG - 2016-09-08 06:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 06:16:30 --> Input Class Initialized
INFO - 2016-09-08 06:16:30 --> Language Class Initialized
INFO - 2016-09-08 06:16:30 --> Language Class Initialized
INFO - 2016-09-08 06:16:30 --> Config Class Initialized
INFO - 2016-09-08 06:16:30 --> Loader Class Initialized
INFO - 2016-09-08 06:16:30 --> Helper loaded: url_helper
INFO - 2016-09-08 06:16:30 --> Database Driver Class Initialized
INFO - 2016-09-08 06:16:30 --> Controller Class Initialized
DEBUG - 2016-09-08 06:16:30 --> Index MX_Controller Initialized
INFO - 2016-09-08 06:16:30 --> Model Class Initialized
INFO - 2016-09-08 06:16:31 --> Model Class Initialized
DEBUG - 2016-09-08 06:16:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 06:16:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 06:16:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 06:16:31 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 06:16:31 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 06:16:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 06:16:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 06:16:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 06:16:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 06:16:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 06:16:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 06:16:31 --> Final output sent to browser
DEBUG - 2016-09-08 06:16:31 --> Total execution time: 0.6563
INFO - 2016-09-08 06:22:40 --> Config Class Initialized
INFO - 2016-09-08 06:22:40 --> Hooks Class Initialized
DEBUG - 2016-09-08 06:22:40 --> UTF-8 Support Enabled
INFO - 2016-09-08 06:22:40 --> Utf8 Class Initialized
INFO - 2016-09-08 06:22:40 --> URI Class Initialized
INFO - 2016-09-08 06:22:40 --> Router Class Initialized
INFO - 2016-09-08 06:22:40 --> Output Class Initialized
INFO - 2016-09-08 06:22:40 --> Security Class Initialized
DEBUG - 2016-09-08 06:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 06:22:40 --> Input Class Initialized
INFO - 2016-09-08 06:22:40 --> Language Class Initialized
INFO - 2016-09-08 06:22:40 --> Language Class Initialized
INFO - 2016-09-08 06:22:40 --> Config Class Initialized
INFO - 2016-09-08 06:22:40 --> Loader Class Initialized
INFO - 2016-09-08 06:22:40 --> Helper loaded: url_helper
INFO - 2016-09-08 06:22:40 --> Database Driver Class Initialized
INFO - 2016-09-08 06:22:40 --> Controller Class Initialized
DEBUG - 2016-09-08 06:22:40 --> Index MX_Controller Initialized
INFO - 2016-09-08 06:22:40 --> Model Class Initialized
INFO - 2016-09-08 06:22:40 --> Model Class Initialized
DEBUG - 2016-09-08 06:22:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 06:22:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 06:22:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 06:22:40 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 06:22:40 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 06:22:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 06:22:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 06:22:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 06:22:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 06:22:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 06:22:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 06:22:40 --> Final output sent to browser
DEBUG - 2016-09-08 06:22:40 --> Total execution time: 0.7201
INFO - 2016-09-08 06:29:31 --> Config Class Initialized
INFO - 2016-09-08 06:29:31 --> Hooks Class Initialized
DEBUG - 2016-09-08 06:29:31 --> UTF-8 Support Enabled
INFO - 2016-09-08 06:29:31 --> Utf8 Class Initialized
INFO - 2016-09-08 06:29:31 --> URI Class Initialized
INFO - 2016-09-08 06:29:31 --> Router Class Initialized
INFO - 2016-09-08 06:29:31 --> Output Class Initialized
INFO - 2016-09-08 06:29:31 --> Security Class Initialized
DEBUG - 2016-09-08 06:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 06:29:31 --> Input Class Initialized
INFO - 2016-09-08 06:29:31 --> Language Class Initialized
INFO - 2016-09-08 06:29:31 --> Language Class Initialized
INFO - 2016-09-08 06:29:31 --> Config Class Initialized
INFO - 2016-09-08 06:29:31 --> Loader Class Initialized
INFO - 2016-09-08 06:29:31 --> Helper loaded: url_helper
INFO - 2016-09-08 06:29:31 --> Database Driver Class Initialized
INFO - 2016-09-08 06:29:31 --> Controller Class Initialized
DEBUG - 2016-09-08 06:29:31 --> Index MX_Controller Initialized
INFO - 2016-09-08 06:29:31 --> Model Class Initialized
INFO - 2016-09-08 06:29:31 --> Model Class Initialized
DEBUG - 2016-09-08 06:29:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 06:29:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 06:29:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 06:29:31 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 06:29:31 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 06:29:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 06:29:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 06:29:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 06:29:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 06:29:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 06:29:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 06:29:31 --> Final output sent to browser
DEBUG - 2016-09-08 06:29:32 --> Total execution time: 0.6973
INFO - 2016-09-08 06:29:58 --> Config Class Initialized
INFO - 2016-09-08 06:29:58 --> Hooks Class Initialized
DEBUG - 2016-09-08 06:29:58 --> UTF-8 Support Enabled
INFO - 2016-09-08 06:29:58 --> Utf8 Class Initialized
INFO - 2016-09-08 06:29:58 --> URI Class Initialized
INFO - 2016-09-08 06:29:58 --> Router Class Initialized
INFO - 2016-09-08 06:29:58 --> Output Class Initialized
INFO - 2016-09-08 06:29:58 --> Security Class Initialized
DEBUG - 2016-09-08 06:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 06:29:59 --> Input Class Initialized
INFO - 2016-09-08 06:29:59 --> Language Class Initialized
INFO - 2016-09-08 06:29:59 --> Language Class Initialized
INFO - 2016-09-08 06:29:59 --> Config Class Initialized
INFO - 2016-09-08 06:29:59 --> Loader Class Initialized
INFO - 2016-09-08 06:29:59 --> Helper loaded: url_helper
INFO - 2016-09-08 06:29:59 --> Database Driver Class Initialized
INFO - 2016-09-08 06:29:59 --> Controller Class Initialized
DEBUG - 2016-09-08 06:29:59 --> Index MX_Controller Initialized
INFO - 2016-09-08 06:29:59 --> Model Class Initialized
INFO - 2016-09-08 06:29:59 --> Model Class Initialized
DEBUG - 2016-09-08 06:29:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 06:29:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 06:29:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 06:29:59 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 06:29:59 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 06:29:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 06:29:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 06:29:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 06:29:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 06:29:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 06:29:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 06:29:59 --> Final output sent to browser
DEBUG - 2016-09-08 06:29:59 --> Total execution time: 0.6227
INFO - 2016-09-08 06:30:37 --> Config Class Initialized
INFO - 2016-09-08 06:30:37 --> Hooks Class Initialized
DEBUG - 2016-09-08 06:30:37 --> UTF-8 Support Enabled
INFO - 2016-09-08 06:30:37 --> Utf8 Class Initialized
INFO - 2016-09-08 06:30:37 --> URI Class Initialized
INFO - 2016-09-08 06:30:37 --> Router Class Initialized
INFO - 2016-09-08 06:30:37 --> Output Class Initialized
INFO - 2016-09-08 06:30:37 --> Security Class Initialized
DEBUG - 2016-09-08 06:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 06:30:37 --> Input Class Initialized
INFO - 2016-09-08 06:30:37 --> Language Class Initialized
INFO - 2016-09-08 06:30:37 --> Language Class Initialized
INFO - 2016-09-08 06:30:37 --> Config Class Initialized
INFO - 2016-09-08 06:30:37 --> Loader Class Initialized
INFO - 2016-09-08 06:30:37 --> Helper loaded: url_helper
INFO - 2016-09-08 06:30:37 --> Database Driver Class Initialized
INFO - 2016-09-08 06:30:37 --> Controller Class Initialized
DEBUG - 2016-09-08 06:30:37 --> Index MX_Controller Initialized
INFO - 2016-09-08 06:30:37 --> Model Class Initialized
INFO - 2016-09-08 06:30:37 --> Model Class Initialized
DEBUG - 2016-09-08 06:30:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 06:30:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 06:30:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 06:30:37 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 06:30:37 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 06:30:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 06:30:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 06:30:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 06:30:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 06:30:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 06:30:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 06:30:38 --> Final output sent to browser
DEBUG - 2016-09-08 06:30:38 --> Total execution time: 0.9259
INFO - 2016-09-08 06:33:04 --> Config Class Initialized
INFO - 2016-09-08 06:33:04 --> Hooks Class Initialized
DEBUG - 2016-09-08 06:33:04 --> UTF-8 Support Enabled
INFO - 2016-09-08 06:33:04 --> Utf8 Class Initialized
INFO - 2016-09-08 06:33:04 --> URI Class Initialized
INFO - 2016-09-08 06:33:04 --> Router Class Initialized
INFO - 2016-09-08 06:33:04 --> Output Class Initialized
INFO - 2016-09-08 06:33:04 --> Security Class Initialized
DEBUG - 2016-09-08 06:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 06:33:04 --> Input Class Initialized
INFO - 2016-09-08 06:33:04 --> Language Class Initialized
INFO - 2016-09-08 06:33:04 --> Language Class Initialized
INFO - 2016-09-08 06:33:04 --> Config Class Initialized
INFO - 2016-09-08 06:33:04 --> Loader Class Initialized
INFO - 2016-09-08 06:33:04 --> Helper loaded: url_helper
INFO - 2016-09-08 06:33:04 --> Database Driver Class Initialized
INFO - 2016-09-08 06:33:04 --> Controller Class Initialized
DEBUG - 2016-09-08 06:33:04 --> Index MX_Controller Initialized
INFO - 2016-09-08 06:33:04 --> Model Class Initialized
INFO - 2016-09-08 06:33:05 --> Model Class Initialized
DEBUG - 2016-09-08 06:33:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 06:33:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 06:33:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 06:33:05 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 06:33:05 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 06:33:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 06:33:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 06:33:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 06:33:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 06:33:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 06:33:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 06:33:05 --> Final output sent to browser
DEBUG - 2016-09-08 06:33:05 --> Total execution time: 0.6385
INFO - 2016-09-08 06:34:13 --> Config Class Initialized
INFO - 2016-09-08 06:34:13 --> Hooks Class Initialized
DEBUG - 2016-09-08 06:34:13 --> UTF-8 Support Enabled
INFO - 2016-09-08 06:34:13 --> Utf8 Class Initialized
INFO - 2016-09-08 06:34:13 --> URI Class Initialized
INFO - 2016-09-08 06:34:13 --> Router Class Initialized
INFO - 2016-09-08 06:34:13 --> Output Class Initialized
INFO - 2016-09-08 06:34:13 --> Security Class Initialized
DEBUG - 2016-09-08 06:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 06:34:13 --> Input Class Initialized
INFO - 2016-09-08 06:34:13 --> Language Class Initialized
INFO - 2016-09-08 06:34:13 --> Language Class Initialized
INFO - 2016-09-08 06:34:13 --> Config Class Initialized
INFO - 2016-09-08 06:34:13 --> Loader Class Initialized
INFO - 2016-09-08 06:34:13 --> Helper loaded: url_helper
INFO - 2016-09-08 06:34:14 --> Database Driver Class Initialized
INFO - 2016-09-08 06:34:14 --> Controller Class Initialized
DEBUG - 2016-09-08 06:34:14 --> Index MX_Controller Initialized
INFO - 2016-09-08 06:34:14 --> Model Class Initialized
INFO - 2016-09-08 06:34:14 --> Model Class Initialized
DEBUG - 2016-09-08 06:34:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 06:34:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 06:34:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 06:34:14 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 06:34:14 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 06:34:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 06:34:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 06:34:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 06:34:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 06:34:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 06:34:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 06:34:14 --> Final output sent to browser
DEBUG - 2016-09-08 06:34:14 --> Total execution time: 0.6143
INFO - 2016-09-08 06:35:58 --> Config Class Initialized
INFO - 2016-09-08 06:35:58 --> Hooks Class Initialized
DEBUG - 2016-09-08 06:35:58 --> UTF-8 Support Enabled
INFO - 2016-09-08 06:35:58 --> Utf8 Class Initialized
INFO - 2016-09-08 06:35:58 --> URI Class Initialized
INFO - 2016-09-08 06:35:58 --> Router Class Initialized
INFO - 2016-09-08 06:35:58 --> Output Class Initialized
INFO - 2016-09-08 06:35:58 --> Security Class Initialized
DEBUG - 2016-09-08 06:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 06:35:58 --> Input Class Initialized
INFO - 2016-09-08 06:35:58 --> Language Class Initialized
INFO - 2016-09-08 06:35:58 --> Language Class Initialized
INFO - 2016-09-08 06:35:58 --> Config Class Initialized
INFO - 2016-09-08 06:35:58 --> Loader Class Initialized
INFO - 2016-09-08 06:35:58 --> Helper loaded: url_helper
INFO - 2016-09-08 06:35:58 --> Database Driver Class Initialized
INFO - 2016-09-08 06:35:58 --> Controller Class Initialized
DEBUG - 2016-09-08 06:35:59 --> Index MX_Controller Initialized
INFO - 2016-09-08 06:35:59 --> Model Class Initialized
INFO - 2016-09-08 06:35:59 --> Model Class Initialized
DEBUG - 2016-09-08 06:35:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 06:35:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 06:35:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 06:35:59 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 06:35:59 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 06:35:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 06:35:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 06:35:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 06:35:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 06:35:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 06:35:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 06:35:59 --> Final output sent to browser
DEBUG - 2016-09-08 06:35:59 --> Total execution time: 0.7303
INFO - 2016-09-08 06:37:04 --> Config Class Initialized
INFO - 2016-09-08 06:37:04 --> Hooks Class Initialized
DEBUG - 2016-09-08 06:37:04 --> UTF-8 Support Enabled
INFO - 2016-09-08 06:37:04 --> Utf8 Class Initialized
INFO - 2016-09-08 06:37:04 --> URI Class Initialized
INFO - 2016-09-08 06:37:04 --> Router Class Initialized
INFO - 2016-09-08 06:37:04 --> Output Class Initialized
INFO - 2016-09-08 06:37:04 --> Security Class Initialized
DEBUG - 2016-09-08 06:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 06:37:04 --> Input Class Initialized
INFO - 2016-09-08 06:37:04 --> Language Class Initialized
INFO - 2016-09-08 06:37:04 --> Language Class Initialized
INFO - 2016-09-08 06:37:04 --> Config Class Initialized
INFO - 2016-09-08 06:37:04 --> Loader Class Initialized
INFO - 2016-09-08 06:37:04 --> Helper loaded: url_helper
INFO - 2016-09-08 06:37:04 --> Database Driver Class Initialized
INFO - 2016-09-08 06:37:04 --> Controller Class Initialized
DEBUG - 2016-09-08 06:37:04 --> Index MX_Controller Initialized
INFO - 2016-09-08 06:37:04 --> Model Class Initialized
INFO - 2016-09-08 06:37:04 --> Model Class Initialized
DEBUG - 2016-09-08 06:37:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 06:37:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 06:37:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 06:37:04 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 06:37:04 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 06:37:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 06:37:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 06:37:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 06:37:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 06:37:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 06:37:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 06:37:05 --> Final output sent to browser
DEBUG - 2016-09-08 06:37:05 --> Total execution time: 0.5961
INFO - 2016-09-08 06:37:24 --> Config Class Initialized
INFO - 2016-09-08 06:37:24 --> Hooks Class Initialized
DEBUG - 2016-09-08 06:37:24 --> UTF-8 Support Enabled
INFO - 2016-09-08 06:37:24 --> Utf8 Class Initialized
INFO - 2016-09-08 06:37:24 --> URI Class Initialized
INFO - 2016-09-08 06:37:24 --> Router Class Initialized
INFO - 2016-09-08 06:37:24 --> Output Class Initialized
INFO - 2016-09-08 06:37:24 --> Security Class Initialized
DEBUG - 2016-09-08 06:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 06:37:24 --> Input Class Initialized
INFO - 2016-09-08 06:37:24 --> Language Class Initialized
INFO - 2016-09-08 06:37:24 --> Language Class Initialized
INFO - 2016-09-08 06:37:24 --> Config Class Initialized
INFO - 2016-09-08 06:37:24 --> Loader Class Initialized
INFO - 2016-09-08 06:37:24 --> Helper loaded: url_helper
INFO - 2016-09-08 06:37:24 --> Database Driver Class Initialized
INFO - 2016-09-08 06:37:24 --> Controller Class Initialized
ERROR - 2016-09-08 06:37:24 --> 404 Page Not Found: ../modules/admin/controllers/Index/post_del
INFO - 2016-09-08 06:37:25 --> Config Class Initialized
INFO - 2016-09-08 06:37:25 --> Hooks Class Initialized
DEBUG - 2016-09-08 06:37:25 --> UTF-8 Support Enabled
INFO - 2016-09-08 06:37:25 --> Utf8 Class Initialized
INFO - 2016-09-08 06:37:25 --> URI Class Initialized
INFO - 2016-09-08 06:37:26 --> Router Class Initialized
INFO - 2016-09-08 06:37:26 --> Output Class Initialized
INFO - 2016-09-08 06:37:26 --> Security Class Initialized
DEBUG - 2016-09-08 06:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 06:37:26 --> Input Class Initialized
INFO - 2016-09-08 06:37:26 --> Language Class Initialized
INFO - 2016-09-08 06:37:26 --> Language Class Initialized
INFO - 2016-09-08 06:37:26 --> Config Class Initialized
INFO - 2016-09-08 06:37:26 --> Loader Class Initialized
INFO - 2016-09-08 06:37:26 --> Helper loaded: url_helper
INFO - 2016-09-08 06:37:26 --> Database Driver Class Initialized
INFO - 2016-09-08 06:37:26 --> Controller Class Initialized
ERROR - 2016-09-08 06:37:26 --> 404 Page Not Found: ../modules/admin/controllers/Index/post_del
INFO - 2016-09-08 06:39:27 --> Config Class Initialized
INFO - 2016-09-08 06:39:27 --> Hooks Class Initialized
DEBUG - 2016-09-08 06:39:27 --> UTF-8 Support Enabled
INFO - 2016-09-08 06:39:27 --> Utf8 Class Initialized
INFO - 2016-09-08 06:39:27 --> URI Class Initialized
INFO - 2016-09-08 06:39:27 --> Router Class Initialized
INFO - 2016-09-08 06:39:27 --> Output Class Initialized
INFO - 2016-09-08 06:39:27 --> Security Class Initialized
DEBUG - 2016-09-08 06:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 06:39:27 --> Input Class Initialized
INFO - 2016-09-08 06:39:27 --> Language Class Initialized
INFO - 2016-09-08 06:39:27 --> Language Class Initialized
INFO - 2016-09-08 06:39:27 --> Config Class Initialized
INFO - 2016-09-08 06:39:27 --> Loader Class Initialized
INFO - 2016-09-08 06:39:27 --> Helper loaded: url_helper
INFO - 2016-09-08 06:39:27 --> Database Driver Class Initialized
INFO - 2016-09-08 06:39:27 --> Controller Class Initialized
DEBUG - 2016-09-08 06:39:27 --> Index MX_Controller Initialized
INFO - 2016-09-08 06:39:27 --> Model Class Initialized
INFO - 2016-09-08 06:39:27 --> Model Class Initialized
DEBUG - 2016-09-08 06:39:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 06:39:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 06:39:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 06:39:27 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 06:39:27 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 06:39:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 06:39:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 06:39:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 06:39:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 06:39:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 06:39:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 06:39:27 --> Final output sent to browser
DEBUG - 2016-09-08 06:39:27 --> Total execution time: 0.6253
INFO - 2016-09-08 06:40:58 --> Config Class Initialized
INFO - 2016-09-08 06:40:58 --> Hooks Class Initialized
DEBUG - 2016-09-08 06:40:58 --> UTF-8 Support Enabled
INFO - 2016-09-08 06:40:58 --> Utf8 Class Initialized
INFO - 2016-09-08 06:40:58 --> URI Class Initialized
INFO - 2016-09-08 06:40:58 --> Router Class Initialized
INFO - 2016-09-08 06:40:58 --> Output Class Initialized
INFO - 2016-09-08 06:40:58 --> Security Class Initialized
DEBUG - 2016-09-08 06:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 06:40:58 --> Input Class Initialized
INFO - 2016-09-08 06:40:58 --> Language Class Initialized
INFO - 2016-09-08 06:40:58 --> Language Class Initialized
INFO - 2016-09-08 06:40:58 --> Config Class Initialized
INFO - 2016-09-08 06:40:58 --> Loader Class Initialized
INFO - 2016-09-08 06:40:58 --> Helper loaded: url_helper
INFO - 2016-09-08 06:40:58 --> Database Driver Class Initialized
INFO - 2016-09-08 06:40:58 --> Controller Class Initialized
DEBUG - 2016-09-08 06:40:58 --> Index MX_Controller Initialized
INFO - 2016-09-08 06:40:58 --> Model Class Initialized
INFO - 2016-09-08 06:40:58 --> Model Class Initialized
DEBUG - 2016-09-08 06:40:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 06:40:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 06:40:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 06:40:58 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 06:40:58 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 06:40:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 06:40:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 06:40:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 06:40:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 06:40:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 06:40:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 06:40:59 --> Final output sent to browser
DEBUG - 2016-09-08 06:40:59 --> Total execution time: 0.6169
INFO - 2016-09-08 06:41:13 --> Config Class Initialized
INFO - 2016-09-08 06:41:13 --> Hooks Class Initialized
DEBUG - 2016-09-08 06:41:13 --> UTF-8 Support Enabled
INFO - 2016-09-08 06:41:13 --> Utf8 Class Initialized
INFO - 2016-09-08 06:41:13 --> URI Class Initialized
INFO - 2016-09-08 06:41:13 --> Router Class Initialized
INFO - 2016-09-08 06:41:13 --> Output Class Initialized
INFO - 2016-09-08 06:41:13 --> Security Class Initialized
DEBUG - 2016-09-08 06:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 06:41:13 --> Input Class Initialized
INFO - 2016-09-08 06:41:13 --> Language Class Initialized
INFO - 2016-09-08 06:41:13 --> Language Class Initialized
INFO - 2016-09-08 06:41:13 --> Config Class Initialized
INFO - 2016-09-08 06:41:13 --> Loader Class Initialized
INFO - 2016-09-08 06:41:13 --> Helper loaded: url_helper
INFO - 2016-09-08 06:41:13 --> Database Driver Class Initialized
INFO - 2016-09-08 06:41:13 --> Controller Class Initialized
ERROR - 2016-09-08 06:41:13 --> 404 Page Not Found: ../modules/admin/controllers/Index/post_del
INFO - 2016-09-08 06:58:40 --> Config Class Initialized
INFO - 2016-09-08 06:58:40 --> Hooks Class Initialized
DEBUG - 2016-09-08 06:58:40 --> UTF-8 Support Enabled
INFO - 2016-09-08 06:58:40 --> Utf8 Class Initialized
INFO - 2016-09-08 06:58:40 --> URI Class Initialized
INFO - 2016-09-08 06:58:40 --> Router Class Initialized
INFO - 2016-09-08 06:58:40 --> Output Class Initialized
INFO - 2016-09-08 06:58:40 --> Security Class Initialized
DEBUG - 2016-09-08 06:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 06:58:40 --> Input Class Initialized
INFO - 2016-09-08 06:58:40 --> Language Class Initialized
INFO - 2016-09-08 06:58:40 --> Language Class Initialized
INFO - 2016-09-08 06:58:40 --> Config Class Initialized
INFO - 2016-09-08 06:58:40 --> Loader Class Initialized
INFO - 2016-09-08 06:58:40 --> Helper loaded: url_helper
INFO - 2016-09-08 06:58:40 --> Database Driver Class Initialized
INFO - 2016-09-08 06:58:40 --> Controller Class Initialized
DEBUG - 2016-09-08 06:58:40 --> Index MX_Controller Initialized
INFO - 2016-09-08 06:58:40 --> Model Class Initialized
INFO - 2016-09-08 06:58:40 --> Model Class Initialized
DEBUG - 2016-09-08 06:58:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 06:58:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 06:58:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 06:58:40 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 06:58:40 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 06:58:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 06:58:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 06:58:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 06:58:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 06:58:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 06:58:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 06:58:40 --> Final output sent to browser
DEBUG - 2016-09-08 06:58:41 --> Total execution time: 0.7365
INFO - 2016-09-08 06:59:48 --> Config Class Initialized
INFO - 2016-09-08 06:59:48 --> Hooks Class Initialized
DEBUG - 2016-09-08 06:59:48 --> UTF-8 Support Enabled
INFO - 2016-09-08 06:59:48 --> Utf8 Class Initialized
INFO - 2016-09-08 06:59:48 --> URI Class Initialized
INFO - 2016-09-08 06:59:48 --> Router Class Initialized
INFO - 2016-09-08 06:59:48 --> Output Class Initialized
INFO - 2016-09-08 06:59:48 --> Security Class Initialized
DEBUG - 2016-09-08 06:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 06:59:48 --> Input Class Initialized
INFO - 2016-09-08 06:59:48 --> Language Class Initialized
INFO - 2016-09-08 06:59:48 --> Language Class Initialized
INFO - 2016-09-08 06:59:48 --> Config Class Initialized
INFO - 2016-09-08 06:59:48 --> Loader Class Initialized
INFO - 2016-09-08 06:59:48 --> Helper loaded: url_helper
INFO - 2016-09-08 06:59:48 --> Database Driver Class Initialized
INFO - 2016-09-08 06:59:48 --> Controller Class Initialized
DEBUG - 2016-09-08 06:59:48 --> Index MX_Controller Initialized
INFO - 2016-09-08 06:59:48 --> Model Class Initialized
INFO - 2016-09-08 06:59:48 --> Model Class Initialized
DEBUG - 2016-09-08 06:59:48 --> Anggota MX_Controller Initialized
ERROR - 2016-09-08 06:59:48 --> Severity: Notice --> Undefined variable: delete E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 50
INFO - 2016-09-08 06:59:49 --> Final output sent to browser
DEBUG - 2016-09-08 06:59:49 --> Total execution time: 0.8511
INFO - 2016-09-08 07:03:20 --> Config Class Initialized
INFO - 2016-09-08 07:03:20 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:03:20 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:03:20 --> Utf8 Class Initialized
INFO - 2016-09-08 07:03:20 --> URI Class Initialized
INFO - 2016-09-08 07:03:20 --> Router Class Initialized
INFO - 2016-09-08 07:03:20 --> Output Class Initialized
INFO - 2016-09-08 07:03:20 --> Security Class Initialized
DEBUG - 2016-09-08 07:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:03:20 --> Input Class Initialized
INFO - 2016-09-08 07:03:20 --> Language Class Initialized
INFO - 2016-09-08 07:03:20 --> Language Class Initialized
INFO - 2016-09-08 07:03:20 --> Config Class Initialized
INFO - 2016-09-08 07:03:20 --> Loader Class Initialized
INFO - 2016-09-08 07:03:20 --> Helper loaded: url_helper
INFO - 2016-09-08 07:03:20 --> Database Driver Class Initialized
INFO - 2016-09-08 07:03:20 --> Controller Class Initialized
DEBUG - 2016-09-08 07:03:20 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:03:20 --> Model Class Initialized
INFO - 2016-09-08 07:03:20 --> Model Class Initialized
DEBUG - 2016-09-08 07:03:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 07:03:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 07:03:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 07:03:21 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 07:03:21 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 07:03:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 07:03:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 07:03:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 07:03:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 07:03:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 07:03:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 07:03:21 --> Final output sent to browser
DEBUG - 2016-09-08 07:03:21 --> Total execution time: 0.6351
INFO - 2016-09-08 07:03:29 --> Config Class Initialized
INFO - 2016-09-08 07:03:29 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:03:29 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:03:29 --> Utf8 Class Initialized
INFO - 2016-09-08 07:03:29 --> URI Class Initialized
INFO - 2016-09-08 07:03:29 --> Router Class Initialized
INFO - 2016-09-08 07:03:29 --> Output Class Initialized
INFO - 2016-09-08 07:03:29 --> Security Class Initialized
DEBUG - 2016-09-08 07:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:03:29 --> Input Class Initialized
INFO - 2016-09-08 07:03:29 --> Language Class Initialized
INFO - 2016-09-08 07:03:29 --> Language Class Initialized
INFO - 2016-09-08 07:03:29 --> Config Class Initialized
INFO - 2016-09-08 07:03:29 --> Loader Class Initialized
INFO - 2016-09-08 07:03:29 --> Helper loaded: url_helper
INFO - 2016-09-08 07:03:29 --> Database Driver Class Initialized
INFO - 2016-09-08 07:03:29 --> Controller Class Initialized
DEBUG - 2016-09-08 07:03:29 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:03:29 --> Model Class Initialized
INFO - 2016-09-08 07:03:29 --> Model Class Initialized
DEBUG - 2016-09-08 07:03:29 --> Anggota MX_Controller Initialized
ERROR - 2016-09-08 07:03:29 --> Severity: Notice --> Undefined variable: delete E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 50
INFO - 2016-09-08 07:03:29 --> Final output sent to browser
DEBUG - 2016-09-08 07:03:29 --> Total execution time: 0.4850
INFO - 2016-09-08 07:05:53 --> Config Class Initialized
INFO - 2016-09-08 07:05:53 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:05:53 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:05:53 --> Utf8 Class Initialized
INFO - 2016-09-08 07:05:53 --> URI Class Initialized
INFO - 2016-09-08 07:05:53 --> Router Class Initialized
INFO - 2016-09-08 07:05:53 --> Output Class Initialized
INFO - 2016-09-08 07:05:53 --> Security Class Initialized
DEBUG - 2016-09-08 07:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:05:53 --> Input Class Initialized
INFO - 2016-09-08 07:05:53 --> Language Class Initialized
INFO - 2016-09-08 07:05:53 --> Language Class Initialized
INFO - 2016-09-08 07:05:53 --> Config Class Initialized
INFO - 2016-09-08 07:05:53 --> Loader Class Initialized
INFO - 2016-09-08 07:05:53 --> Helper loaded: url_helper
INFO - 2016-09-08 07:05:53 --> Database Driver Class Initialized
INFO - 2016-09-08 07:05:53 --> Controller Class Initialized
DEBUG - 2016-09-08 07:05:53 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:05:53 --> Model Class Initialized
INFO - 2016-09-08 07:05:53 --> Model Class Initialized
DEBUG - 2016-09-08 07:05:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 07:05:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 07:05:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 07:05:53 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 07:05:53 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 07:05:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 07:05:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 07:05:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 07:05:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 07:05:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 07:05:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 07:05:54 --> Final output sent to browser
DEBUG - 2016-09-08 07:05:54 --> Total execution time: 0.6966
INFO - 2016-09-08 07:05:59 --> Config Class Initialized
INFO - 2016-09-08 07:05:59 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:05:59 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:05:59 --> Utf8 Class Initialized
INFO - 2016-09-08 07:05:59 --> URI Class Initialized
INFO - 2016-09-08 07:05:59 --> Router Class Initialized
INFO - 2016-09-08 07:05:59 --> Output Class Initialized
INFO - 2016-09-08 07:05:59 --> Security Class Initialized
DEBUG - 2016-09-08 07:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:05:59 --> Input Class Initialized
INFO - 2016-09-08 07:06:00 --> Language Class Initialized
INFO - 2016-09-08 07:06:00 --> Language Class Initialized
INFO - 2016-09-08 07:06:00 --> Config Class Initialized
INFO - 2016-09-08 07:06:00 --> Loader Class Initialized
INFO - 2016-09-08 07:06:00 --> Helper loaded: url_helper
INFO - 2016-09-08 07:06:00 --> Database Driver Class Initialized
INFO - 2016-09-08 07:06:00 --> Controller Class Initialized
DEBUG - 2016-09-08 07:06:00 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:06:00 --> Model Class Initialized
INFO - 2016-09-08 07:06:00 --> Model Class Initialized
DEBUG - 2016-09-08 07:06:00 --> Anggota MX_Controller Initialized
ERROR - 2016-09-08 07:06:00 --> Severity: Notice --> Undefined variable: delete E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 50
INFO - 2016-09-08 07:06:00 --> Final output sent to browser
DEBUG - 2016-09-08 07:06:00 --> Total execution time: 0.4784
INFO - 2016-09-08 07:06:11 --> Config Class Initialized
INFO - 2016-09-08 07:06:11 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:06:11 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:06:11 --> Utf8 Class Initialized
INFO - 2016-09-08 07:06:11 --> URI Class Initialized
INFO - 2016-09-08 07:06:11 --> Router Class Initialized
INFO - 2016-09-08 07:06:11 --> Output Class Initialized
INFO - 2016-09-08 07:06:11 --> Security Class Initialized
DEBUG - 2016-09-08 07:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:06:11 --> Input Class Initialized
INFO - 2016-09-08 07:06:11 --> Language Class Initialized
INFO - 2016-09-08 07:06:11 --> Language Class Initialized
INFO - 2016-09-08 07:06:11 --> Config Class Initialized
INFO - 2016-09-08 07:06:11 --> Loader Class Initialized
INFO - 2016-09-08 07:06:11 --> Helper loaded: url_helper
INFO - 2016-09-08 07:06:11 --> Database Driver Class Initialized
INFO - 2016-09-08 07:06:11 --> Controller Class Initialized
DEBUG - 2016-09-08 07:06:11 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:06:11 --> Model Class Initialized
INFO - 2016-09-08 07:06:12 --> Model Class Initialized
DEBUG - 2016-09-08 07:06:12 --> Anggota MX_Controller Initialized
ERROR - 2016-09-08 07:06:12 --> Severity: Notice --> Undefined variable: delete E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 50
INFO - 2016-09-08 07:06:12 --> Final output sent to browser
DEBUG - 2016-09-08 07:06:12 --> Total execution time: 0.4557
INFO - 2016-09-08 07:06:15 --> Config Class Initialized
INFO - 2016-09-08 07:06:15 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:06:15 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:06:15 --> Utf8 Class Initialized
INFO - 2016-09-08 07:06:15 --> URI Class Initialized
INFO - 2016-09-08 07:06:15 --> Router Class Initialized
INFO - 2016-09-08 07:06:15 --> Output Class Initialized
INFO - 2016-09-08 07:06:15 --> Security Class Initialized
DEBUG - 2016-09-08 07:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:06:15 --> Input Class Initialized
INFO - 2016-09-08 07:06:15 --> Language Class Initialized
INFO - 2016-09-08 07:06:15 --> Language Class Initialized
INFO - 2016-09-08 07:06:15 --> Config Class Initialized
INFO - 2016-09-08 07:06:15 --> Loader Class Initialized
INFO - 2016-09-08 07:06:15 --> Helper loaded: url_helper
INFO - 2016-09-08 07:06:15 --> Database Driver Class Initialized
INFO - 2016-09-08 07:06:15 --> Controller Class Initialized
DEBUG - 2016-09-08 07:06:15 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:06:15 --> Model Class Initialized
INFO - 2016-09-08 07:06:15 --> Model Class Initialized
DEBUG - 2016-09-08 07:06:15 --> Anggota MX_Controller Initialized
ERROR - 2016-09-08 07:06:15 --> Severity: Notice --> Undefined variable: delete E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 50
INFO - 2016-09-08 07:06:15 --> Final output sent to browser
DEBUG - 2016-09-08 07:06:15 --> Total execution time: 0.4703
INFO - 2016-09-08 07:06:18 --> Config Class Initialized
INFO - 2016-09-08 07:06:18 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:06:18 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:06:19 --> Utf8 Class Initialized
INFO - 2016-09-08 07:06:19 --> URI Class Initialized
INFO - 2016-09-08 07:06:19 --> Router Class Initialized
INFO - 2016-09-08 07:06:19 --> Output Class Initialized
INFO - 2016-09-08 07:06:19 --> Security Class Initialized
DEBUG - 2016-09-08 07:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:06:19 --> Input Class Initialized
INFO - 2016-09-08 07:06:19 --> Language Class Initialized
INFO - 2016-09-08 07:06:19 --> Language Class Initialized
INFO - 2016-09-08 07:06:19 --> Config Class Initialized
INFO - 2016-09-08 07:06:19 --> Loader Class Initialized
INFO - 2016-09-08 07:06:19 --> Helper loaded: url_helper
INFO - 2016-09-08 07:06:19 --> Database Driver Class Initialized
INFO - 2016-09-08 07:06:19 --> Controller Class Initialized
DEBUG - 2016-09-08 07:06:19 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:06:19 --> Model Class Initialized
INFO - 2016-09-08 07:06:19 --> Model Class Initialized
DEBUG - 2016-09-08 07:06:19 --> Anggota MX_Controller Initialized
ERROR - 2016-09-08 07:06:19 --> Severity: Notice --> Undefined variable: delete E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 50
INFO - 2016-09-08 07:06:19 --> Final output sent to browser
DEBUG - 2016-09-08 07:06:19 --> Total execution time: 0.4942
INFO - 2016-09-08 07:06:21 --> Config Class Initialized
INFO - 2016-09-08 07:06:21 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:06:21 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:06:21 --> Utf8 Class Initialized
INFO - 2016-09-08 07:06:21 --> URI Class Initialized
INFO - 2016-09-08 07:06:21 --> Router Class Initialized
INFO - 2016-09-08 07:06:22 --> Output Class Initialized
INFO - 2016-09-08 07:06:22 --> Security Class Initialized
DEBUG - 2016-09-08 07:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:06:22 --> Input Class Initialized
INFO - 2016-09-08 07:06:22 --> Language Class Initialized
INFO - 2016-09-08 07:06:22 --> Language Class Initialized
INFO - 2016-09-08 07:06:22 --> Config Class Initialized
INFO - 2016-09-08 07:06:22 --> Loader Class Initialized
INFO - 2016-09-08 07:06:22 --> Helper loaded: url_helper
INFO - 2016-09-08 07:06:22 --> Database Driver Class Initialized
INFO - 2016-09-08 07:06:22 --> Controller Class Initialized
DEBUG - 2016-09-08 07:06:22 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:06:22 --> Model Class Initialized
INFO - 2016-09-08 07:06:22 --> Model Class Initialized
DEBUG - 2016-09-08 07:06:22 --> Anggota MX_Controller Initialized
ERROR - 2016-09-08 07:06:22 --> Severity: Notice --> Undefined variable: delete E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 50
INFO - 2016-09-08 07:06:22 --> Final output sent to browser
DEBUG - 2016-09-08 07:06:22 --> Total execution time: 0.5237
INFO - 2016-09-08 07:06:24 --> Config Class Initialized
INFO - 2016-09-08 07:06:24 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:06:24 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:06:24 --> Utf8 Class Initialized
INFO - 2016-09-08 07:06:24 --> URI Class Initialized
INFO - 2016-09-08 07:06:24 --> Router Class Initialized
INFO - 2016-09-08 07:06:24 --> Output Class Initialized
INFO - 2016-09-08 07:06:24 --> Security Class Initialized
DEBUG - 2016-09-08 07:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:06:24 --> Input Class Initialized
INFO - 2016-09-08 07:06:24 --> Language Class Initialized
INFO - 2016-09-08 07:06:24 --> Language Class Initialized
INFO - 2016-09-08 07:06:24 --> Config Class Initialized
INFO - 2016-09-08 07:06:24 --> Loader Class Initialized
INFO - 2016-09-08 07:06:24 --> Helper loaded: url_helper
INFO - 2016-09-08 07:06:24 --> Database Driver Class Initialized
INFO - 2016-09-08 07:06:24 --> Controller Class Initialized
DEBUG - 2016-09-08 07:06:24 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:06:25 --> Model Class Initialized
INFO - 2016-09-08 07:06:25 --> Model Class Initialized
DEBUG - 2016-09-08 07:06:25 --> Anggota MX_Controller Initialized
ERROR - 2016-09-08 07:06:25 --> Severity: Notice --> Undefined variable: delete E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 50
INFO - 2016-09-08 07:06:25 --> Final output sent to browser
DEBUG - 2016-09-08 07:06:25 --> Total execution time: 0.5589
INFO - 2016-09-08 07:06:27 --> Config Class Initialized
INFO - 2016-09-08 07:06:27 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:06:27 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:06:28 --> Utf8 Class Initialized
INFO - 2016-09-08 07:06:28 --> URI Class Initialized
INFO - 2016-09-08 07:06:28 --> Router Class Initialized
INFO - 2016-09-08 07:06:28 --> Output Class Initialized
INFO - 2016-09-08 07:06:28 --> Security Class Initialized
DEBUG - 2016-09-08 07:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:06:28 --> Input Class Initialized
INFO - 2016-09-08 07:06:28 --> Language Class Initialized
INFO - 2016-09-08 07:06:28 --> Language Class Initialized
INFO - 2016-09-08 07:06:28 --> Config Class Initialized
INFO - 2016-09-08 07:06:28 --> Loader Class Initialized
INFO - 2016-09-08 07:06:28 --> Helper loaded: url_helper
INFO - 2016-09-08 07:06:28 --> Database Driver Class Initialized
INFO - 2016-09-08 07:06:28 --> Controller Class Initialized
DEBUG - 2016-09-08 07:06:28 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:06:28 --> Model Class Initialized
INFO - 2016-09-08 07:06:28 --> Model Class Initialized
DEBUG - 2016-09-08 07:06:28 --> Anggota MX_Controller Initialized
ERROR - 2016-09-08 07:06:28 --> Severity: Notice --> Undefined variable: delete E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 50
INFO - 2016-09-08 07:06:28 --> Final output sent to browser
DEBUG - 2016-09-08 07:06:28 --> Total execution time: 0.4963
INFO - 2016-09-08 07:06:45 --> Config Class Initialized
INFO - 2016-09-08 07:06:45 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:06:45 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:06:45 --> Utf8 Class Initialized
INFO - 2016-09-08 07:06:45 --> URI Class Initialized
INFO - 2016-09-08 07:06:45 --> Router Class Initialized
INFO - 2016-09-08 07:06:45 --> Output Class Initialized
INFO - 2016-09-08 07:06:45 --> Security Class Initialized
DEBUG - 2016-09-08 07:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:06:45 --> Input Class Initialized
INFO - 2016-09-08 07:06:45 --> Language Class Initialized
INFO - 2016-09-08 07:06:45 --> Language Class Initialized
INFO - 2016-09-08 07:06:45 --> Config Class Initialized
INFO - 2016-09-08 07:06:45 --> Loader Class Initialized
INFO - 2016-09-08 07:06:45 --> Helper loaded: url_helper
INFO - 2016-09-08 07:06:45 --> Database Driver Class Initialized
INFO - 2016-09-08 07:06:45 --> Controller Class Initialized
DEBUG - 2016-09-08 07:06:45 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:06:45 --> Model Class Initialized
INFO - 2016-09-08 07:06:45 --> Model Class Initialized
DEBUG - 2016-09-08 07:06:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 07:06:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 07:06:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 07:06:45 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 07:06:45 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 07:06:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 07:06:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 07:06:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 07:06:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 07:06:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 07:06:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 07:06:45 --> Final output sent to browser
DEBUG - 2016-09-08 07:06:45 --> Total execution time: 0.7248
INFO - 2016-09-08 07:06:58 --> Config Class Initialized
INFO - 2016-09-08 07:06:58 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:06:58 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:06:58 --> Utf8 Class Initialized
INFO - 2016-09-08 07:06:58 --> URI Class Initialized
INFO - 2016-09-08 07:06:58 --> Router Class Initialized
INFO - 2016-09-08 07:06:58 --> Output Class Initialized
INFO - 2016-09-08 07:06:58 --> Security Class Initialized
DEBUG - 2016-09-08 07:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:06:58 --> Input Class Initialized
INFO - 2016-09-08 07:06:58 --> Language Class Initialized
INFO - 2016-09-08 07:06:58 --> Language Class Initialized
INFO - 2016-09-08 07:06:58 --> Config Class Initialized
INFO - 2016-09-08 07:06:58 --> Loader Class Initialized
INFO - 2016-09-08 07:06:58 --> Helper loaded: url_helper
INFO - 2016-09-08 07:06:58 --> Database Driver Class Initialized
INFO - 2016-09-08 07:06:58 --> Controller Class Initialized
DEBUG - 2016-09-08 07:06:58 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:06:58 --> Model Class Initialized
INFO - 2016-09-08 07:06:58 --> Model Class Initialized
DEBUG - 2016-09-08 07:06:59 --> Anggota MX_Controller Initialized
ERROR - 2016-09-08 07:06:59 --> Severity: Notice --> Undefined variable: delete E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 50
INFO - 2016-09-08 07:06:59 --> Final output sent to browser
DEBUG - 2016-09-08 07:06:59 --> Total execution time: 0.4671
INFO - 2016-09-08 07:07:03 --> Config Class Initialized
INFO - 2016-09-08 07:07:03 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:07:03 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:07:03 --> Utf8 Class Initialized
INFO - 2016-09-08 07:07:03 --> URI Class Initialized
INFO - 2016-09-08 07:07:03 --> Router Class Initialized
INFO - 2016-09-08 07:07:03 --> Output Class Initialized
INFO - 2016-09-08 07:07:03 --> Security Class Initialized
DEBUG - 2016-09-08 07:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:07:03 --> Input Class Initialized
INFO - 2016-09-08 07:07:03 --> Language Class Initialized
INFO - 2016-09-08 07:07:03 --> Language Class Initialized
INFO - 2016-09-08 07:07:03 --> Config Class Initialized
INFO - 2016-09-08 07:07:03 --> Loader Class Initialized
INFO - 2016-09-08 07:07:03 --> Helper loaded: url_helper
INFO - 2016-09-08 07:07:03 --> Database Driver Class Initialized
INFO - 2016-09-08 07:07:03 --> Controller Class Initialized
DEBUG - 2016-09-08 07:07:03 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:07:03 --> Model Class Initialized
INFO - 2016-09-08 07:07:03 --> Model Class Initialized
DEBUG - 2016-09-08 07:07:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 07:07:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 07:07:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 07:07:03 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 07:07:03 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 07:07:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 07:07:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 07:07:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 07:07:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 07:07:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 07:07:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 07:07:04 --> Final output sent to browser
DEBUG - 2016-09-08 07:07:04 --> Total execution time: 0.7477
INFO - 2016-09-08 07:07:42 --> Config Class Initialized
INFO - 2016-09-08 07:07:42 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:07:42 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:07:42 --> Utf8 Class Initialized
INFO - 2016-09-08 07:07:42 --> URI Class Initialized
INFO - 2016-09-08 07:07:42 --> Router Class Initialized
INFO - 2016-09-08 07:07:42 --> Output Class Initialized
INFO - 2016-09-08 07:07:42 --> Security Class Initialized
DEBUG - 2016-09-08 07:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:07:42 --> Input Class Initialized
INFO - 2016-09-08 07:07:42 --> Language Class Initialized
INFO - 2016-09-08 07:07:42 --> Language Class Initialized
INFO - 2016-09-08 07:07:42 --> Config Class Initialized
INFO - 2016-09-08 07:07:42 --> Loader Class Initialized
INFO - 2016-09-08 07:07:42 --> Helper loaded: url_helper
INFO - 2016-09-08 07:07:42 --> Database Driver Class Initialized
INFO - 2016-09-08 07:07:42 --> Controller Class Initialized
DEBUG - 2016-09-08 07:07:42 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:07:42 --> Model Class Initialized
INFO - 2016-09-08 07:07:42 --> Model Class Initialized
DEBUG - 2016-09-08 07:07:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 07:07:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 07:07:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 07:07:42 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 07:07:42 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 07:07:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 07:07:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 07:07:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 07:07:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 07:07:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 07:07:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 07:07:42 --> Final output sent to browser
DEBUG - 2016-09-08 07:07:42 --> Total execution time: 0.7165
INFO - 2016-09-08 07:07:48 --> Config Class Initialized
INFO - 2016-09-08 07:07:48 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:07:48 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:07:48 --> Utf8 Class Initialized
INFO - 2016-09-08 07:07:48 --> URI Class Initialized
INFO - 2016-09-08 07:07:48 --> Router Class Initialized
INFO - 2016-09-08 07:07:48 --> Output Class Initialized
INFO - 2016-09-08 07:07:48 --> Security Class Initialized
DEBUG - 2016-09-08 07:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:07:48 --> Input Class Initialized
INFO - 2016-09-08 07:07:48 --> Language Class Initialized
INFO - 2016-09-08 07:07:48 --> Language Class Initialized
INFO - 2016-09-08 07:07:48 --> Config Class Initialized
INFO - 2016-09-08 07:07:48 --> Loader Class Initialized
INFO - 2016-09-08 07:07:48 --> Helper loaded: url_helper
INFO - 2016-09-08 07:07:48 --> Database Driver Class Initialized
INFO - 2016-09-08 07:07:48 --> Controller Class Initialized
DEBUG - 2016-09-08 07:07:48 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:07:48 --> Model Class Initialized
INFO - 2016-09-08 07:07:48 --> Model Class Initialized
DEBUG - 2016-09-08 07:07:48 --> Anggota MX_Controller Initialized
ERROR - 2016-09-08 07:07:48 --> Severity: Notice --> Undefined variable: delete E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 50
INFO - 2016-09-08 07:07:48 --> Final output sent to browser
DEBUG - 2016-09-08 07:07:48 --> Total execution time: 0.4761
INFO - 2016-09-08 07:08:34 --> Config Class Initialized
INFO - 2016-09-08 07:08:34 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:08:34 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:08:34 --> Utf8 Class Initialized
INFO - 2016-09-08 07:08:34 --> URI Class Initialized
INFO - 2016-09-08 07:08:34 --> Router Class Initialized
INFO - 2016-09-08 07:08:34 --> Output Class Initialized
INFO - 2016-09-08 07:08:34 --> Security Class Initialized
DEBUG - 2016-09-08 07:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:08:34 --> Input Class Initialized
INFO - 2016-09-08 07:08:34 --> Language Class Initialized
INFO - 2016-09-08 07:08:34 --> Language Class Initialized
INFO - 2016-09-08 07:08:34 --> Config Class Initialized
INFO - 2016-09-08 07:08:34 --> Loader Class Initialized
INFO - 2016-09-08 07:08:34 --> Helper loaded: url_helper
INFO - 2016-09-08 07:08:34 --> Database Driver Class Initialized
INFO - 2016-09-08 07:08:34 --> Controller Class Initialized
DEBUG - 2016-09-08 07:08:35 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:08:35 --> Model Class Initialized
INFO - 2016-09-08 07:08:35 --> Model Class Initialized
DEBUG - 2016-09-08 07:08:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 07:08:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 07:08:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 07:08:35 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 07:08:35 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 07:08:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 07:08:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 07:08:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 07:08:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 07:08:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 07:08:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 07:08:35 --> Final output sent to browser
DEBUG - 2016-09-08 07:08:35 --> Total execution time: 0.7271
INFO - 2016-09-08 07:08:40 --> Config Class Initialized
INFO - 2016-09-08 07:08:40 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:08:40 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:08:40 --> Utf8 Class Initialized
INFO - 2016-09-08 07:08:40 --> URI Class Initialized
INFO - 2016-09-08 07:08:40 --> Router Class Initialized
INFO - 2016-09-08 07:08:40 --> Output Class Initialized
INFO - 2016-09-08 07:08:40 --> Security Class Initialized
DEBUG - 2016-09-08 07:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:08:40 --> Input Class Initialized
INFO - 2016-09-08 07:08:40 --> Language Class Initialized
INFO - 2016-09-08 07:08:40 --> Language Class Initialized
INFO - 2016-09-08 07:08:40 --> Config Class Initialized
INFO - 2016-09-08 07:08:40 --> Loader Class Initialized
INFO - 2016-09-08 07:08:40 --> Helper loaded: url_helper
INFO - 2016-09-08 07:08:40 --> Database Driver Class Initialized
INFO - 2016-09-08 07:08:40 --> Controller Class Initialized
DEBUG - 2016-09-08 07:08:40 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:08:40 --> Model Class Initialized
INFO - 2016-09-08 07:08:40 --> Model Class Initialized
DEBUG - 2016-09-08 07:08:40 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:08:40 --> Final output sent to browser
DEBUG - 2016-09-08 07:08:40 --> Total execution time: 0.4682
INFO - 2016-09-08 07:08:56 --> Config Class Initialized
INFO - 2016-09-08 07:08:56 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:08:56 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:08:56 --> Utf8 Class Initialized
INFO - 2016-09-08 07:08:56 --> URI Class Initialized
INFO - 2016-09-08 07:08:56 --> Router Class Initialized
INFO - 2016-09-08 07:08:56 --> Output Class Initialized
INFO - 2016-09-08 07:08:56 --> Security Class Initialized
DEBUG - 2016-09-08 07:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:08:56 --> Input Class Initialized
INFO - 2016-09-08 07:08:56 --> Language Class Initialized
INFO - 2016-09-08 07:08:56 --> Language Class Initialized
INFO - 2016-09-08 07:08:56 --> Config Class Initialized
INFO - 2016-09-08 07:08:56 --> Loader Class Initialized
INFO - 2016-09-08 07:08:56 --> Helper loaded: url_helper
INFO - 2016-09-08 07:08:56 --> Database Driver Class Initialized
INFO - 2016-09-08 07:08:56 --> Controller Class Initialized
DEBUG - 2016-09-08 07:08:56 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:08:56 --> Model Class Initialized
INFO - 2016-09-08 07:08:56 --> Model Class Initialized
DEBUG - 2016-09-08 07:08:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 07:08:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 07:08:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 07:08:56 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 07:08:56 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 07:08:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 07:08:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 07:08:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 07:08:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 07:08:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 07:08:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 07:08:56 --> Final output sent to browser
DEBUG - 2016-09-08 07:08:56 --> Total execution time: 0.7375
INFO - 2016-09-08 07:09:01 --> Config Class Initialized
INFO - 2016-09-08 07:09:01 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:09:01 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:09:01 --> Utf8 Class Initialized
INFO - 2016-09-08 07:09:01 --> URI Class Initialized
INFO - 2016-09-08 07:09:01 --> Router Class Initialized
INFO - 2016-09-08 07:09:01 --> Output Class Initialized
INFO - 2016-09-08 07:09:01 --> Security Class Initialized
DEBUG - 2016-09-08 07:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:09:01 --> Input Class Initialized
INFO - 2016-09-08 07:09:01 --> Language Class Initialized
INFO - 2016-09-08 07:09:01 --> Language Class Initialized
INFO - 2016-09-08 07:09:01 --> Config Class Initialized
INFO - 2016-09-08 07:09:01 --> Loader Class Initialized
INFO - 2016-09-08 07:09:01 --> Helper loaded: url_helper
INFO - 2016-09-08 07:09:01 --> Database Driver Class Initialized
INFO - 2016-09-08 07:09:02 --> Controller Class Initialized
DEBUG - 2016-09-08 07:09:02 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:09:02 --> Model Class Initialized
INFO - 2016-09-08 07:09:02 --> Model Class Initialized
DEBUG - 2016-09-08 07:09:02 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:09:02 --> Final output sent to browser
DEBUG - 2016-09-08 07:09:02 --> Total execution time: 0.4585
INFO - 2016-09-08 07:09:07 --> Config Class Initialized
INFO - 2016-09-08 07:09:07 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:09:07 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:09:07 --> Utf8 Class Initialized
INFO - 2016-09-08 07:09:07 --> URI Class Initialized
INFO - 2016-09-08 07:09:07 --> Router Class Initialized
INFO - 2016-09-08 07:09:07 --> Output Class Initialized
INFO - 2016-09-08 07:09:07 --> Security Class Initialized
DEBUG - 2016-09-08 07:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:09:07 --> Input Class Initialized
INFO - 2016-09-08 07:09:07 --> Language Class Initialized
INFO - 2016-09-08 07:09:07 --> Language Class Initialized
INFO - 2016-09-08 07:09:07 --> Config Class Initialized
INFO - 2016-09-08 07:09:07 --> Loader Class Initialized
INFO - 2016-09-08 07:09:07 --> Helper loaded: url_helper
INFO - 2016-09-08 07:09:07 --> Database Driver Class Initialized
INFO - 2016-09-08 07:09:07 --> Controller Class Initialized
DEBUG - 2016-09-08 07:09:07 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:09:07 --> Model Class Initialized
INFO - 2016-09-08 07:09:07 --> Model Class Initialized
DEBUG - 2016-09-08 07:09:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 07:09:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 07:09:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 07:09:07 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 07:09:07 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 07:09:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 07:09:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 07:09:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 07:09:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 07:09:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 07:09:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 07:09:07 --> Final output sent to browser
DEBUG - 2016-09-08 07:09:08 --> Total execution time: 0.7125
INFO - 2016-09-08 07:09:28 --> Config Class Initialized
INFO - 2016-09-08 07:09:28 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:09:28 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:09:28 --> Utf8 Class Initialized
INFO - 2016-09-08 07:09:28 --> URI Class Initialized
INFO - 2016-09-08 07:09:28 --> Router Class Initialized
INFO - 2016-09-08 07:09:28 --> Output Class Initialized
INFO - 2016-09-08 07:09:28 --> Security Class Initialized
DEBUG - 2016-09-08 07:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:09:28 --> Input Class Initialized
INFO - 2016-09-08 07:09:28 --> Language Class Initialized
INFO - 2016-09-08 07:09:28 --> Language Class Initialized
INFO - 2016-09-08 07:09:28 --> Config Class Initialized
INFO - 2016-09-08 07:09:28 --> Loader Class Initialized
INFO - 2016-09-08 07:09:28 --> Helper loaded: url_helper
INFO - 2016-09-08 07:09:29 --> Database Driver Class Initialized
INFO - 2016-09-08 07:09:29 --> Controller Class Initialized
DEBUG - 2016-09-08 07:09:29 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:09:29 --> Model Class Initialized
INFO - 2016-09-08 07:09:29 --> Model Class Initialized
DEBUG - 2016-09-08 07:09:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 07:09:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 07:09:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 07:09:29 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 07:09:29 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 07:09:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 07:09:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 07:09:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 07:09:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 07:09:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 07:09:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 07:09:29 --> Final output sent to browser
DEBUG - 2016-09-08 07:09:29 --> Total execution time: 0.7635
INFO - 2016-09-08 07:09:36 --> Config Class Initialized
INFO - 2016-09-08 07:09:36 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:09:36 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:09:36 --> Utf8 Class Initialized
INFO - 2016-09-08 07:09:36 --> URI Class Initialized
INFO - 2016-09-08 07:09:36 --> Router Class Initialized
INFO - 2016-09-08 07:09:36 --> Output Class Initialized
INFO - 2016-09-08 07:09:36 --> Security Class Initialized
DEBUG - 2016-09-08 07:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:09:36 --> Input Class Initialized
INFO - 2016-09-08 07:09:36 --> Language Class Initialized
INFO - 2016-09-08 07:09:36 --> Language Class Initialized
INFO - 2016-09-08 07:09:36 --> Config Class Initialized
INFO - 2016-09-08 07:09:36 --> Loader Class Initialized
INFO - 2016-09-08 07:09:36 --> Helper loaded: url_helper
INFO - 2016-09-08 07:09:36 --> Database Driver Class Initialized
INFO - 2016-09-08 07:09:36 --> Controller Class Initialized
DEBUG - 2016-09-08 07:09:36 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:09:36 --> Model Class Initialized
INFO - 2016-09-08 07:09:36 --> Model Class Initialized
DEBUG - 2016-09-08 07:09:36 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:09:36 --> Final output sent to browser
DEBUG - 2016-09-08 07:09:36 --> Total execution time: 0.4651
INFO - 2016-09-08 07:10:06 --> Config Class Initialized
INFO - 2016-09-08 07:10:06 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:10:06 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:10:06 --> Utf8 Class Initialized
INFO - 2016-09-08 07:10:06 --> URI Class Initialized
INFO - 2016-09-08 07:10:06 --> Router Class Initialized
INFO - 2016-09-08 07:10:06 --> Output Class Initialized
INFO - 2016-09-08 07:10:06 --> Security Class Initialized
DEBUG - 2016-09-08 07:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:10:06 --> Input Class Initialized
INFO - 2016-09-08 07:10:06 --> Language Class Initialized
INFO - 2016-09-08 07:10:06 --> Language Class Initialized
INFO - 2016-09-08 07:10:06 --> Config Class Initialized
INFO - 2016-09-08 07:10:06 --> Loader Class Initialized
INFO - 2016-09-08 07:10:06 --> Helper loaded: url_helper
INFO - 2016-09-08 07:10:06 --> Database Driver Class Initialized
INFO - 2016-09-08 07:10:06 --> Controller Class Initialized
DEBUG - 2016-09-08 07:10:06 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:10:06 --> Model Class Initialized
INFO - 2016-09-08 07:10:06 --> Model Class Initialized
DEBUG - 2016-09-08 07:10:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 07:10:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 07:10:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 07:10:06 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 07:10:06 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 07:10:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 07:10:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 07:10:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 07:10:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 07:10:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 07:10:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 07:10:07 --> Final output sent to browser
DEBUG - 2016-09-08 07:10:07 --> Total execution time: 0.7267
INFO - 2016-09-08 07:10:12 --> Config Class Initialized
INFO - 2016-09-08 07:10:12 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:10:12 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:10:12 --> Utf8 Class Initialized
INFO - 2016-09-08 07:10:12 --> URI Class Initialized
INFO - 2016-09-08 07:10:12 --> Router Class Initialized
INFO - 2016-09-08 07:10:12 --> Output Class Initialized
INFO - 2016-09-08 07:10:12 --> Security Class Initialized
DEBUG - 2016-09-08 07:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:10:12 --> Input Class Initialized
INFO - 2016-09-08 07:10:12 --> Language Class Initialized
INFO - 2016-09-08 07:10:12 --> Language Class Initialized
INFO - 2016-09-08 07:10:12 --> Config Class Initialized
INFO - 2016-09-08 07:10:12 --> Loader Class Initialized
INFO - 2016-09-08 07:10:12 --> Helper loaded: url_helper
INFO - 2016-09-08 07:10:12 --> Database Driver Class Initialized
INFO - 2016-09-08 07:10:12 --> Controller Class Initialized
DEBUG - 2016-09-08 07:10:12 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:10:12 --> Model Class Initialized
INFO - 2016-09-08 07:10:12 --> Model Class Initialized
DEBUG - 2016-09-08 07:10:12 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:10:13 --> Final output sent to browser
DEBUG - 2016-09-08 07:10:13 --> Total execution time: 0.4648
INFO - 2016-09-08 07:10:22 --> Config Class Initialized
INFO - 2016-09-08 07:10:22 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:10:22 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:10:22 --> Utf8 Class Initialized
INFO - 2016-09-08 07:10:22 --> URI Class Initialized
INFO - 2016-09-08 07:10:22 --> Router Class Initialized
INFO - 2016-09-08 07:10:22 --> Output Class Initialized
INFO - 2016-09-08 07:10:22 --> Security Class Initialized
DEBUG - 2016-09-08 07:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:10:22 --> Input Class Initialized
INFO - 2016-09-08 07:10:22 --> Language Class Initialized
INFO - 2016-09-08 07:10:22 --> Language Class Initialized
INFO - 2016-09-08 07:10:22 --> Config Class Initialized
INFO - 2016-09-08 07:10:22 --> Loader Class Initialized
INFO - 2016-09-08 07:10:22 --> Helper loaded: url_helper
INFO - 2016-09-08 07:10:22 --> Database Driver Class Initialized
INFO - 2016-09-08 07:10:22 --> Controller Class Initialized
DEBUG - 2016-09-08 07:10:23 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:10:23 --> Model Class Initialized
INFO - 2016-09-08 07:10:23 --> Model Class Initialized
DEBUG - 2016-09-08 07:10:23 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:10:23 --> Final output sent to browser
DEBUG - 2016-09-08 07:10:23 --> Total execution time: 0.4798
INFO - 2016-09-08 07:11:42 --> Config Class Initialized
INFO - 2016-09-08 07:11:42 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:11:42 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:11:42 --> Utf8 Class Initialized
INFO - 2016-09-08 07:11:42 --> URI Class Initialized
INFO - 2016-09-08 07:11:42 --> Router Class Initialized
INFO - 2016-09-08 07:11:42 --> Output Class Initialized
INFO - 2016-09-08 07:11:42 --> Security Class Initialized
DEBUG - 2016-09-08 07:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:11:43 --> Input Class Initialized
INFO - 2016-09-08 07:11:43 --> Language Class Initialized
INFO - 2016-09-08 07:11:43 --> Language Class Initialized
INFO - 2016-09-08 07:11:43 --> Config Class Initialized
INFO - 2016-09-08 07:11:43 --> Loader Class Initialized
INFO - 2016-09-08 07:11:43 --> Helper loaded: url_helper
INFO - 2016-09-08 07:11:43 --> Database Driver Class Initialized
INFO - 2016-09-08 07:11:43 --> Controller Class Initialized
DEBUG - 2016-09-08 07:11:43 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:11:43 --> Model Class Initialized
INFO - 2016-09-08 07:11:43 --> Model Class Initialized
DEBUG - 2016-09-08 07:11:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 07:11:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 07:11:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 07:11:43 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 07:11:43 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 07:11:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 07:11:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 07:11:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 07:11:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 07:11:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 07:11:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 07:11:43 --> Final output sent to browser
DEBUG - 2016-09-08 07:11:43 --> Total execution time: 0.7227
INFO - 2016-09-08 07:13:06 --> Config Class Initialized
INFO - 2016-09-08 07:13:06 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:13:06 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:13:06 --> Utf8 Class Initialized
INFO - 2016-09-08 07:13:06 --> URI Class Initialized
INFO - 2016-09-08 07:13:06 --> Router Class Initialized
INFO - 2016-09-08 07:13:06 --> Output Class Initialized
INFO - 2016-09-08 07:13:06 --> Security Class Initialized
DEBUG - 2016-09-08 07:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:13:06 --> Input Class Initialized
INFO - 2016-09-08 07:13:06 --> Language Class Initialized
INFO - 2016-09-08 07:13:06 --> Language Class Initialized
INFO - 2016-09-08 07:13:06 --> Config Class Initialized
INFO - 2016-09-08 07:13:06 --> Loader Class Initialized
INFO - 2016-09-08 07:13:06 --> Helper loaded: url_helper
INFO - 2016-09-08 07:13:06 --> Database Driver Class Initialized
INFO - 2016-09-08 07:13:06 --> Controller Class Initialized
DEBUG - 2016-09-08 07:13:06 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:13:06 --> Model Class Initialized
INFO - 2016-09-08 07:13:06 --> Model Class Initialized
INFO - 2016-09-08 07:13:06 --> Final output sent to browser
DEBUG - 2016-09-08 07:13:06 --> Total execution time: 0.4763
INFO - 2016-09-08 07:13:37 --> Config Class Initialized
INFO - 2016-09-08 07:13:37 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:13:37 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:13:37 --> Utf8 Class Initialized
INFO - 2016-09-08 07:13:37 --> URI Class Initialized
INFO - 2016-09-08 07:13:37 --> Router Class Initialized
INFO - 2016-09-08 07:13:37 --> Output Class Initialized
INFO - 2016-09-08 07:13:37 --> Security Class Initialized
DEBUG - 2016-09-08 07:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:13:37 --> Input Class Initialized
INFO - 2016-09-08 07:13:37 --> Language Class Initialized
INFO - 2016-09-08 07:13:37 --> Language Class Initialized
INFO - 2016-09-08 07:13:37 --> Config Class Initialized
INFO - 2016-09-08 07:13:37 --> Loader Class Initialized
INFO - 2016-09-08 07:13:37 --> Helper loaded: url_helper
INFO - 2016-09-08 07:13:37 --> Database Driver Class Initialized
INFO - 2016-09-08 07:13:37 --> Controller Class Initialized
DEBUG - 2016-09-08 07:13:37 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:13:37 --> Model Class Initialized
INFO - 2016-09-08 07:13:37 --> Model Class Initialized
DEBUG - 2016-09-08 07:13:37 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:13:37 --> Final output sent to browser
DEBUG - 2016-09-08 07:13:37 --> Total execution time: 0.5204
INFO - 2016-09-08 07:14:10 --> Config Class Initialized
INFO - 2016-09-08 07:14:10 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:14:10 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:14:10 --> Utf8 Class Initialized
INFO - 2016-09-08 07:14:10 --> URI Class Initialized
INFO - 2016-09-08 07:14:10 --> Router Class Initialized
INFO - 2016-09-08 07:14:10 --> Output Class Initialized
INFO - 2016-09-08 07:14:10 --> Security Class Initialized
DEBUG - 2016-09-08 07:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:14:10 --> Input Class Initialized
INFO - 2016-09-08 07:14:10 --> Language Class Initialized
INFO - 2016-09-08 07:14:10 --> Language Class Initialized
INFO - 2016-09-08 07:14:10 --> Config Class Initialized
INFO - 2016-09-08 07:14:10 --> Loader Class Initialized
INFO - 2016-09-08 07:14:10 --> Helper loaded: url_helper
INFO - 2016-09-08 07:14:10 --> Database Driver Class Initialized
INFO - 2016-09-08 07:14:10 --> Controller Class Initialized
DEBUG - 2016-09-08 07:14:10 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:14:10 --> Model Class Initialized
INFO - 2016-09-08 07:14:10 --> Model Class Initialized
DEBUG - 2016-09-08 07:14:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 07:14:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 07:14:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 07:14:10 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 07:14:10 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 07:14:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 07:14:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 07:14:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 07:14:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 07:14:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 07:14:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 07:14:10 --> Final output sent to browser
DEBUG - 2016-09-08 07:14:10 --> Total execution time: 0.7439
INFO - 2016-09-08 07:14:18 --> Config Class Initialized
INFO - 2016-09-08 07:14:18 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:14:18 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:14:18 --> Utf8 Class Initialized
INFO - 2016-09-08 07:14:18 --> URI Class Initialized
INFO - 2016-09-08 07:14:18 --> Router Class Initialized
INFO - 2016-09-08 07:14:19 --> Output Class Initialized
INFO - 2016-09-08 07:14:19 --> Security Class Initialized
DEBUG - 2016-09-08 07:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:14:19 --> Input Class Initialized
INFO - 2016-09-08 07:14:19 --> Language Class Initialized
INFO - 2016-09-08 07:14:19 --> Language Class Initialized
INFO - 2016-09-08 07:14:19 --> Config Class Initialized
INFO - 2016-09-08 07:14:19 --> Loader Class Initialized
INFO - 2016-09-08 07:14:19 --> Helper loaded: url_helper
INFO - 2016-09-08 07:14:19 --> Database Driver Class Initialized
INFO - 2016-09-08 07:14:19 --> Controller Class Initialized
DEBUG - 2016-09-08 07:14:19 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:14:19 --> Model Class Initialized
INFO - 2016-09-08 07:14:19 --> Model Class Initialized
DEBUG - 2016-09-08 07:14:19 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:14:19 --> Final output sent to browser
DEBUG - 2016-09-08 07:14:19 --> Total execution time: 0.4680
INFO - 2016-09-08 07:15:04 --> Config Class Initialized
INFO - 2016-09-08 07:15:04 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:15:04 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:15:04 --> Utf8 Class Initialized
INFO - 2016-09-08 07:15:04 --> URI Class Initialized
INFO - 2016-09-08 07:15:04 --> Router Class Initialized
INFO - 2016-09-08 07:15:04 --> Output Class Initialized
INFO - 2016-09-08 07:15:04 --> Security Class Initialized
DEBUG - 2016-09-08 07:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:15:04 --> Input Class Initialized
INFO - 2016-09-08 07:15:04 --> Language Class Initialized
INFO - 2016-09-08 07:15:04 --> Language Class Initialized
INFO - 2016-09-08 07:15:05 --> Config Class Initialized
INFO - 2016-09-08 07:15:05 --> Loader Class Initialized
INFO - 2016-09-08 07:15:05 --> Helper loaded: url_helper
INFO - 2016-09-08 07:15:05 --> Database Driver Class Initialized
INFO - 2016-09-08 07:15:05 --> Controller Class Initialized
DEBUG - 2016-09-08 07:15:05 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:15:05 --> Model Class Initialized
INFO - 2016-09-08 07:15:05 --> Model Class Initialized
DEBUG - 2016-09-08 07:15:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 07:15:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 07:15:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 07:15:05 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 07:15:05 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 07:15:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 07:15:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 07:15:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 07:15:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 07:15:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 07:15:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 07:15:05 --> Final output sent to browser
DEBUG - 2016-09-08 07:15:05 --> Total execution time: 0.7889
INFO - 2016-09-08 07:15:12 --> Config Class Initialized
INFO - 2016-09-08 07:15:12 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:15:12 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:15:12 --> Utf8 Class Initialized
INFO - 2016-09-08 07:15:12 --> URI Class Initialized
INFO - 2016-09-08 07:15:12 --> Router Class Initialized
INFO - 2016-09-08 07:15:12 --> Output Class Initialized
INFO - 2016-09-08 07:15:12 --> Security Class Initialized
DEBUG - 2016-09-08 07:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:15:12 --> Input Class Initialized
INFO - 2016-09-08 07:15:12 --> Language Class Initialized
INFO - 2016-09-08 07:15:12 --> Language Class Initialized
INFO - 2016-09-08 07:15:12 --> Config Class Initialized
INFO - 2016-09-08 07:15:12 --> Loader Class Initialized
INFO - 2016-09-08 07:15:12 --> Helper loaded: url_helper
INFO - 2016-09-08 07:15:12 --> Database Driver Class Initialized
INFO - 2016-09-08 07:15:12 --> Controller Class Initialized
DEBUG - 2016-09-08 07:15:12 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:15:12 --> Model Class Initialized
INFO - 2016-09-08 07:15:12 --> Model Class Initialized
DEBUG - 2016-09-08 07:15:12 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:15:12 --> Final output sent to browser
DEBUG - 2016-09-08 07:15:12 --> Total execution time: 0.5188
INFO - 2016-09-08 07:18:31 --> Config Class Initialized
INFO - 2016-09-08 07:18:31 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:18:31 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:18:31 --> Utf8 Class Initialized
INFO - 2016-09-08 07:18:31 --> URI Class Initialized
INFO - 2016-09-08 07:18:31 --> Router Class Initialized
INFO - 2016-09-08 07:18:31 --> Output Class Initialized
INFO - 2016-09-08 07:18:31 --> Security Class Initialized
DEBUG - 2016-09-08 07:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:18:31 --> Input Class Initialized
INFO - 2016-09-08 07:18:31 --> Language Class Initialized
INFO - 2016-09-08 07:18:31 --> Language Class Initialized
INFO - 2016-09-08 07:18:31 --> Config Class Initialized
INFO - 2016-09-08 07:18:31 --> Loader Class Initialized
INFO - 2016-09-08 07:18:31 --> Helper loaded: url_helper
INFO - 2016-09-08 07:18:31 --> Database Driver Class Initialized
INFO - 2016-09-08 07:18:31 --> Controller Class Initialized
DEBUG - 2016-09-08 07:18:31 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:18:31 --> Model Class Initialized
INFO - 2016-09-08 07:18:31 --> Model Class Initialized
DEBUG - 2016-09-08 07:18:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 07:18:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 07:18:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 07:18:31 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 07:18:31 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 07:18:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 07:18:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 07:18:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 07:18:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 07:18:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 07:18:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 07:18:31 --> Final output sent to browser
DEBUG - 2016-09-08 07:18:31 --> Total execution time: 0.7966
INFO - 2016-09-08 07:18:53 --> Config Class Initialized
INFO - 2016-09-08 07:18:53 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:18:53 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:18:53 --> Utf8 Class Initialized
INFO - 2016-09-08 07:18:53 --> URI Class Initialized
INFO - 2016-09-08 07:18:53 --> Router Class Initialized
INFO - 2016-09-08 07:18:53 --> Output Class Initialized
INFO - 2016-09-08 07:18:53 --> Security Class Initialized
DEBUG - 2016-09-08 07:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:18:53 --> Input Class Initialized
INFO - 2016-09-08 07:18:53 --> Language Class Initialized
INFO - 2016-09-08 07:18:53 --> Language Class Initialized
INFO - 2016-09-08 07:18:53 --> Config Class Initialized
INFO - 2016-09-08 07:18:53 --> Loader Class Initialized
INFO - 2016-09-08 07:18:53 --> Helper loaded: url_helper
INFO - 2016-09-08 07:18:53 --> Database Driver Class Initialized
INFO - 2016-09-08 07:18:53 --> Controller Class Initialized
DEBUG - 2016-09-08 07:18:53 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:18:53 --> Model Class Initialized
INFO - 2016-09-08 07:18:53 --> Model Class Initialized
DEBUG - 2016-09-08 07:18:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 07:18:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 07:18:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 07:18:53 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 07:18:53 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 07:18:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 07:18:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 07:18:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 07:18:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 07:18:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 07:18:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 07:18:54 --> Final output sent to browser
DEBUG - 2016-09-08 07:18:54 --> Total execution time: 0.7692
INFO - 2016-09-08 07:19:16 --> Config Class Initialized
INFO - 2016-09-08 07:19:16 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:19:16 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:19:16 --> Utf8 Class Initialized
INFO - 2016-09-08 07:19:16 --> URI Class Initialized
INFO - 2016-09-08 07:19:16 --> Router Class Initialized
INFO - 2016-09-08 07:19:16 --> Output Class Initialized
INFO - 2016-09-08 07:19:16 --> Security Class Initialized
DEBUG - 2016-09-08 07:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:19:16 --> Input Class Initialized
INFO - 2016-09-08 07:19:16 --> Language Class Initialized
INFO - 2016-09-08 07:19:16 --> Language Class Initialized
INFO - 2016-09-08 07:19:16 --> Config Class Initialized
INFO - 2016-09-08 07:19:16 --> Loader Class Initialized
INFO - 2016-09-08 07:19:16 --> Helper loaded: url_helper
INFO - 2016-09-08 07:19:16 --> Database Driver Class Initialized
INFO - 2016-09-08 07:19:16 --> Controller Class Initialized
DEBUG - 2016-09-08 07:19:16 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:19:16 --> Model Class Initialized
INFO - 2016-09-08 07:19:16 --> Model Class Initialized
DEBUG - 2016-09-08 07:19:16 --> Anggota MX_Controller Initialized
ERROR - 2016-09-08 07:19:16 --> Severity: Notice --> Undefined variable: delete E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 51
INFO - 2016-09-08 07:19:16 --> Final output sent to browser
DEBUG - 2016-09-08 07:19:16 --> Total execution time: 0.4963
INFO - 2016-09-08 07:19:34 --> Config Class Initialized
INFO - 2016-09-08 07:19:34 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:19:34 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:19:34 --> Utf8 Class Initialized
INFO - 2016-09-08 07:19:34 --> URI Class Initialized
INFO - 2016-09-08 07:19:34 --> Router Class Initialized
INFO - 2016-09-08 07:19:34 --> Output Class Initialized
INFO - 2016-09-08 07:19:34 --> Security Class Initialized
DEBUG - 2016-09-08 07:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:19:34 --> Input Class Initialized
INFO - 2016-09-08 07:19:34 --> Language Class Initialized
INFO - 2016-09-08 07:19:34 --> Language Class Initialized
INFO - 2016-09-08 07:19:34 --> Config Class Initialized
INFO - 2016-09-08 07:19:34 --> Loader Class Initialized
INFO - 2016-09-08 07:19:34 --> Helper loaded: url_helper
INFO - 2016-09-08 07:19:34 --> Database Driver Class Initialized
INFO - 2016-09-08 07:19:34 --> Controller Class Initialized
DEBUG - 2016-09-08 07:19:35 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:19:35 --> Model Class Initialized
INFO - 2016-09-08 07:19:35 --> Model Class Initialized
DEBUG - 2016-09-08 07:19:35 --> Anggota MX_Controller Initialized
ERROR - 2016-09-08 07:19:35 --> Severity: Notice --> Undefined variable: delete E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 51
INFO - 2016-09-08 07:19:35 --> Final output sent to browser
DEBUG - 2016-09-08 07:19:35 --> Total execution time: 0.5206
INFO - 2016-09-08 07:19:39 --> Config Class Initialized
INFO - 2016-09-08 07:19:39 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:19:39 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:19:39 --> Utf8 Class Initialized
INFO - 2016-09-08 07:19:39 --> URI Class Initialized
INFO - 2016-09-08 07:19:39 --> Router Class Initialized
INFO - 2016-09-08 07:19:39 --> Output Class Initialized
INFO - 2016-09-08 07:19:39 --> Security Class Initialized
DEBUG - 2016-09-08 07:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:19:39 --> Input Class Initialized
INFO - 2016-09-08 07:19:39 --> Language Class Initialized
INFO - 2016-09-08 07:19:40 --> Language Class Initialized
INFO - 2016-09-08 07:19:40 --> Config Class Initialized
INFO - 2016-09-08 07:19:40 --> Loader Class Initialized
INFO - 2016-09-08 07:19:40 --> Helper loaded: url_helper
INFO - 2016-09-08 07:19:40 --> Database Driver Class Initialized
INFO - 2016-09-08 07:19:40 --> Controller Class Initialized
DEBUG - 2016-09-08 07:19:40 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:19:40 --> Model Class Initialized
INFO - 2016-09-08 07:19:40 --> Model Class Initialized
DEBUG - 2016-09-08 07:19:40 --> Anggota MX_Controller Initialized
ERROR - 2016-09-08 07:19:40 --> Severity: Notice --> Undefined variable: delete E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 51
INFO - 2016-09-08 07:19:40 --> Final output sent to browser
DEBUG - 2016-09-08 07:19:40 --> Total execution time: 0.5020
INFO - 2016-09-08 07:19:41 --> Config Class Initialized
INFO - 2016-09-08 07:19:41 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:19:41 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:19:41 --> Utf8 Class Initialized
INFO - 2016-09-08 07:19:41 --> URI Class Initialized
INFO - 2016-09-08 07:19:41 --> Router Class Initialized
INFO - 2016-09-08 07:19:41 --> Output Class Initialized
INFO - 2016-09-08 07:19:41 --> Security Class Initialized
DEBUG - 2016-09-08 07:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:19:41 --> Input Class Initialized
INFO - 2016-09-08 07:19:41 --> Language Class Initialized
INFO - 2016-09-08 07:19:41 --> Language Class Initialized
INFO - 2016-09-08 07:19:41 --> Config Class Initialized
INFO - 2016-09-08 07:19:41 --> Loader Class Initialized
INFO - 2016-09-08 07:19:41 --> Helper loaded: url_helper
INFO - 2016-09-08 07:19:41 --> Database Driver Class Initialized
INFO - 2016-09-08 07:19:41 --> Controller Class Initialized
DEBUG - 2016-09-08 07:19:41 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:19:41 --> Model Class Initialized
INFO - 2016-09-08 07:19:41 --> Model Class Initialized
DEBUG - 2016-09-08 07:19:41 --> Anggota MX_Controller Initialized
ERROR - 2016-09-08 07:19:41 --> Severity: Notice --> Undefined variable: delete E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 51
INFO - 2016-09-08 07:19:41 --> Final output sent to browser
DEBUG - 2016-09-08 07:19:41 --> Total execution time: 0.5195
INFO - 2016-09-08 07:20:01 --> Config Class Initialized
INFO - 2016-09-08 07:20:01 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:20:01 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:20:01 --> Utf8 Class Initialized
INFO - 2016-09-08 07:20:01 --> URI Class Initialized
INFO - 2016-09-08 07:20:01 --> Router Class Initialized
INFO - 2016-09-08 07:20:01 --> Output Class Initialized
INFO - 2016-09-08 07:20:01 --> Security Class Initialized
DEBUG - 2016-09-08 07:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:20:01 --> Input Class Initialized
INFO - 2016-09-08 07:20:01 --> Language Class Initialized
INFO - 2016-09-08 07:20:01 --> Language Class Initialized
INFO - 2016-09-08 07:20:01 --> Config Class Initialized
INFO - 2016-09-08 07:20:01 --> Loader Class Initialized
INFO - 2016-09-08 07:20:01 --> Helper loaded: url_helper
INFO - 2016-09-08 07:20:01 --> Database Driver Class Initialized
INFO - 2016-09-08 07:20:01 --> Controller Class Initialized
DEBUG - 2016-09-08 07:20:01 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:20:01 --> Model Class Initialized
INFO - 2016-09-08 07:20:01 --> Model Class Initialized
DEBUG - 2016-09-08 07:20:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 07:20:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 07:20:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 07:20:02 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 07:20:02 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 07:20:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 07:20:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 07:20:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 07:20:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 07:20:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 07:20:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 07:20:02 --> Final output sent to browser
DEBUG - 2016-09-08 07:20:02 --> Total execution time: 0.7773
INFO - 2016-09-08 07:20:17 --> Config Class Initialized
INFO - 2016-09-08 07:20:17 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:20:17 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:20:17 --> Utf8 Class Initialized
INFO - 2016-09-08 07:20:17 --> URI Class Initialized
INFO - 2016-09-08 07:20:17 --> Router Class Initialized
INFO - 2016-09-08 07:20:17 --> Output Class Initialized
INFO - 2016-09-08 07:20:17 --> Security Class Initialized
DEBUG - 2016-09-08 07:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:20:17 --> Input Class Initialized
INFO - 2016-09-08 07:20:17 --> Language Class Initialized
INFO - 2016-09-08 07:20:17 --> Language Class Initialized
INFO - 2016-09-08 07:20:17 --> Config Class Initialized
INFO - 2016-09-08 07:20:17 --> Loader Class Initialized
INFO - 2016-09-08 07:20:17 --> Helper loaded: url_helper
INFO - 2016-09-08 07:20:17 --> Database Driver Class Initialized
INFO - 2016-09-08 07:20:17 --> Controller Class Initialized
DEBUG - 2016-09-08 07:20:17 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:20:17 --> Model Class Initialized
INFO - 2016-09-08 07:20:17 --> Model Class Initialized
DEBUG - 2016-09-08 07:20:17 --> Anggota MX_Controller Initialized
ERROR - 2016-09-08 07:20:17 --> Severity: Notice --> Undefined variable: delete E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 51
INFO - 2016-09-08 07:20:17 --> Final output sent to browser
DEBUG - 2016-09-08 07:20:17 --> Total execution time: 0.5177
INFO - 2016-09-08 07:20:59 --> Config Class Initialized
INFO - 2016-09-08 07:20:59 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:20:59 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:20:59 --> Utf8 Class Initialized
INFO - 2016-09-08 07:20:59 --> URI Class Initialized
INFO - 2016-09-08 07:20:59 --> Router Class Initialized
INFO - 2016-09-08 07:20:59 --> Output Class Initialized
INFO - 2016-09-08 07:20:59 --> Security Class Initialized
DEBUG - 2016-09-08 07:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:20:59 --> Input Class Initialized
INFO - 2016-09-08 07:20:59 --> Language Class Initialized
INFO - 2016-09-08 07:20:59 --> Language Class Initialized
INFO - 2016-09-08 07:20:59 --> Config Class Initialized
INFO - 2016-09-08 07:20:59 --> Loader Class Initialized
INFO - 2016-09-08 07:20:59 --> Helper loaded: url_helper
INFO - 2016-09-08 07:20:59 --> Database Driver Class Initialized
INFO - 2016-09-08 07:20:59 --> Controller Class Initialized
DEBUG - 2016-09-08 07:20:59 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:20:59 --> Model Class Initialized
INFO - 2016-09-08 07:20:59 --> Model Class Initialized
DEBUG - 2016-09-08 07:20:59 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:20:59 --> Final output sent to browser
DEBUG - 2016-09-08 07:20:59 --> Total execution time: 0.5166
INFO - 2016-09-08 07:21:55 --> Config Class Initialized
INFO - 2016-09-08 07:21:55 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:21:55 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:21:55 --> Utf8 Class Initialized
INFO - 2016-09-08 07:21:55 --> URI Class Initialized
INFO - 2016-09-08 07:21:55 --> Router Class Initialized
INFO - 2016-09-08 07:21:55 --> Output Class Initialized
INFO - 2016-09-08 07:21:55 --> Security Class Initialized
DEBUG - 2016-09-08 07:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:21:55 --> Input Class Initialized
INFO - 2016-09-08 07:21:55 --> Language Class Initialized
INFO - 2016-09-08 07:21:55 --> Language Class Initialized
INFO - 2016-09-08 07:21:55 --> Config Class Initialized
INFO - 2016-09-08 07:21:55 --> Loader Class Initialized
INFO - 2016-09-08 07:21:56 --> Helper loaded: url_helper
INFO - 2016-09-08 07:21:56 --> Database Driver Class Initialized
INFO - 2016-09-08 07:21:56 --> Controller Class Initialized
DEBUG - 2016-09-08 07:21:56 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:21:56 --> Model Class Initialized
INFO - 2016-09-08 07:21:56 --> Model Class Initialized
DEBUG - 2016-09-08 07:21:56 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:21:56 --> Final output sent to browser
DEBUG - 2016-09-08 07:21:56 --> Total execution time: 0.4969
INFO - 2016-09-08 07:21:57 --> Config Class Initialized
INFO - 2016-09-08 07:21:57 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:21:57 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:21:57 --> Utf8 Class Initialized
INFO - 2016-09-08 07:21:57 --> URI Class Initialized
INFO - 2016-09-08 07:21:57 --> Router Class Initialized
INFO - 2016-09-08 07:21:57 --> Output Class Initialized
INFO - 2016-09-08 07:21:57 --> Security Class Initialized
DEBUG - 2016-09-08 07:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:21:57 --> Input Class Initialized
INFO - 2016-09-08 07:21:57 --> Language Class Initialized
INFO - 2016-09-08 07:21:57 --> Language Class Initialized
INFO - 2016-09-08 07:21:57 --> Config Class Initialized
INFO - 2016-09-08 07:21:57 --> Loader Class Initialized
INFO - 2016-09-08 07:21:57 --> Helper loaded: url_helper
INFO - 2016-09-08 07:21:57 --> Database Driver Class Initialized
INFO - 2016-09-08 07:21:57 --> Controller Class Initialized
DEBUG - 2016-09-08 07:21:57 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:21:57 --> Model Class Initialized
INFO - 2016-09-08 07:21:57 --> Model Class Initialized
DEBUG - 2016-09-08 07:21:57 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:21:57 --> Final output sent to browser
DEBUG - 2016-09-08 07:21:57 --> Total execution time: 0.5049
INFO - 2016-09-08 07:23:42 --> Config Class Initialized
INFO - 2016-09-08 07:23:42 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:23:42 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:23:42 --> Utf8 Class Initialized
INFO - 2016-09-08 07:23:42 --> URI Class Initialized
INFO - 2016-09-08 07:23:42 --> Router Class Initialized
INFO - 2016-09-08 07:23:42 --> Output Class Initialized
INFO - 2016-09-08 07:23:42 --> Security Class Initialized
DEBUG - 2016-09-08 07:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:23:42 --> Input Class Initialized
INFO - 2016-09-08 07:23:42 --> Language Class Initialized
INFO - 2016-09-08 07:23:42 --> Language Class Initialized
INFO - 2016-09-08 07:23:42 --> Config Class Initialized
INFO - 2016-09-08 07:23:42 --> Loader Class Initialized
INFO - 2016-09-08 07:23:42 --> Helper loaded: url_helper
INFO - 2016-09-08 07:23:42 --> Database Driver Class Initialized
INFO - 2016-09-08 07:23:42 --> Controller Class Initialized
DEBUG - 2016-09-08 07:23:42 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:23:42 --> Model Class Initialized
INFO - 2016-09-08 07:23:42 --> Model Class Initialized
DEBUG - 2016-09-08 07:23:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 07:23:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 07:23:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 07:23:42 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 07:23:42 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 07:23:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 07:23:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 07:23:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 07:23:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 07:23:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 07:23:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 07:23:42 --> Final output sent to browser
DEBUG - 2016-09-08 07:23:43 --> Total execution time: 0.8080
INFO - 2016-09-08 07:23:48 --> Config Class Initialized
INFO - 2016-09-08 07:23:48 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:23:48 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:23:48 --> Utf8 Class Initialized
INFO - 2016-09-08 07:23:48 --> URI Class Initialized
INFO - 2016-09-08 07:23:48 --> Router Class Initialized
INFO - 2016-09-08 07:23:48 --> Output Class Initialized
INFO - 2016-09-08 07:23:48 --> Security Class Initialized
DEBUG - 2016-09-08 07:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:23:48 --> Input Class Initialized
INFO - 2016-09-08 07:23:48 --> Language Class Initialized
INFO - 2016-09-08 07:23:48 --> Language Class Initialized
INFO - 2016-09-08 07:23:48 --> Config Class Initialized
INFO - 2016-09-08 07:23:48 --> Loader Class Initialized
INFO - 2016-09-08 07:23:48 --> Helper loaded: url_helper
INFO - 2016-09-08 07:23:48 --> Database Driver Class Initialized
INFO - 2016-09-08 07:23:48 --> Controller Class Initialized
DEBUG - 2016-09-08 07:23:48 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:23:48 --> Model Class Initialized
INFO - 2016-09-08 07:23:48 --> Model Class Initialized
DEBUG - 2016-09-08 07:23:48 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:23:48 --> Final output sent to browser
DEBUG - 2016-09-08 07:23:48 --> Total execution time: 0.4947
INFO - 2016-09-08 07:24:25 --> Config Class Initialized
INFO - 2016-09-08 07:24:25 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:24:25 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:24:25 --> Utf8 Class Initialized
INFO - 2016-09-08 07:24:25 --> URI Class Initialized
INFO - 2016-09-08 07:24:25 --> Router Class Initialized
INFO - 2016-09-08 07:24:25 --> Output Class Initialized
INFO - 2016-09-08 07:24:25 --> Security Class Initialized
DEBUG - 2016-09-08 07:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:24:25 --> Input Class Initialized
INFO - 2016-09-08 07:24:25 --> Language Class Initialized
INFO - 2016-09-08 07:24:25 --> Language Class Initialized
INFO - 2016-09-08 07:24:25 --> Config Class Initialized
INFO - 2016-09-08 07:24:25 --> Loader Class Initialized
INFO - 2016-09-08 07:24:25 --> Helper loaded: url_helper
INFO - 2016-09-08 07:24:26 --> Database Driver Class Initialized
INFO - 2016-09-08 07:24:26 --> Controller Class Initialized
DEBUG - 2016-09-08 07:24:26 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:24:26 --> Model Class Initialized
INFO - 2016-09-08 07:24:26 --> Model Class Initialized
DEBUG - 2016-09-08 07:24:26 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:24:26 --> Final output sent to browser
DEBUG - 2016-09-08 07:24:26 --> Total execution time: 0.4909
INFO - 2016-09-08 07:24:28 --> Config Class Initialized
INFO - 2016-09-08 07:24:28 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:24:28 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:24:28 --> Utf8 Class Initialized
INFO - 2016-09-08 07:24:28 --> URI Class Initialized
INFO - 2016-09-08 07:24:28 --> Router Class Initialized
INFO - 2016-09-08 07:24:28 --> Output Class Initialized
INFO - 2016-09-08 07:24:28 --> Security Class Initialized
DEBUG - 2016-09-08 07:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:24:29 --> Input Class Initialized
INFO - 2016-09-08 07:24:29 --> Language Class Initialized
INFO - 2016-09-08 07:24:29 --> Language Class Initialized
INFO - 2016-09-08 07:24:29 --> Config Class Initialized
INFO - 2016-09-08 07:24:29 --> Loader Class Initialized
INFO - 2016-09-08 07:24:29 --> Helper loaded: url_helper
INFO - 2016-09-08 07:24:29 --> Database Driver Class Initialized
INFO - 2016-09-08 07:24:29 --> Controller Class Initialized
DEBUG - 2016-09-08 07:24:29 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:24:29 --> Model Class Initialized
INFO - 2016-09-08 07:24:29 --> Model Class Initialized
DEBUG - 2016-09-08 07:24:29 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:24:29 --> Final output sent to browser
DEBUG - 2016-09-08 07:24:29 --> Total execution time: 0.4927
INFO - 2016-09-08 07:24:34 --> Config Class Initialized
INFO - 2016-09-08 07:24:34 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:24:34 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:24:34 --> Utf8 Class Initialized
INFO - 2016-09-08 07:24:34 --> URI Class Initialized
INFO - 2016-09-08 07:24:34 --> Router Class Initialized
INFO - 2016-09-08 07:24:34 --> Output Class Initialized
INFO - 2016-09-08 07:24:34 --> Security Class Initialized
DEBUG - 2016-09-08 07:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:24:34 --> Input Class Initialized
INFO - 2016-09-08 07:24:34 --> Language Class Initialized
INFO - 2016-09-08 07:24:34 --> Language Class Initialized
INFO - 2016-09-08 07:24:34 --> Config Class Initialized
INFO - 2016-09-08 07:24:34 --> Loader Class Initialized
INFO - 2016-09-08 07:24:34 --> Helper loaded: url_helper
INFO - 2016-09-08 07:24:34 --> Database Driver Class Initialized
INFO - 2016-09-08 07:24:34 --> Controller Class Initialized
DEBUG - 2016-09-08 07:24:34 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:24:34 --> Model Class Initialized
INFO - 2016-09-08 07:24:34 --> Model Class Initialized
DEBUG - 2016-09-08 07:24:34 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:24:34 --> Final output sent to browser
DEBUG - 2016-09-08 07:24:34 --> Total execution time: 0.5077
INFO - 2016-09-08 07:25:40 --> Config Class Initialized
INFO - 2016-09-08 07:25:40 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:25:40 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:25:40 --> Utf8 Class Initialized
INFO - 2016-09-08 07:25:40 --> URI Class Initialized
INFO - 2016-09-08 07:25:40 --> Router Class Initialized
INFO - 2016-09-08 07:25:40 --> Output Class Initialized
INFO - 2016-09-08 07:25:40 --> Security Class Initialized
DEBUG - 2016-09-08 07:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:25:40 --> Input Class Initialized
INFO - 2016-09-08 07:25:40 --> Language Class Initialized
INFO - 2016-09-08 07:25:40 --> Language Class Initialized
INFO - 2016-09-08 07:25:40 --> Config Class Initialized
INFO - 2016-09-08 07:25:40 --> Loader Class Initialized
INFO - 2016-09-08 07:25:40 --> Helper loaded: url_helper
INFO - 2016-09-08 07:25:40 --> Database Driver Class Initialized
INFO - 2016-09-08 07:25:40 --> Controller Class Initialized
DEBUG - 2016-09-08 07:25:40 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:25:40 --> Model Class Initialized
INFO - 2016-09-08 07:25:40 --> Model Class Initialized
DEBUG - 2016-09-08 07:25:41 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:25:41 --> Final output sent to browser
DEBUG - 2016-09-08 07:25:41 --> Total execution time: 0.5132
INFO - 2016-09-08 07:29:22 --> Config Class Initialized
INFO - 2016-09-08 07:29:22 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:29:22 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:29:22 --> Utf8 Class Initialized
INFO - 2016-09-08 07:29:22 --> URI Class Initialized
INFO - 2016-09-08 07:29:22 --> Router Class Initialized
INFO - 2016-09-08 07:29:22 --> Output Class Initialized
INFO - 2016-09-08 07:29:22 --> Security Class Initialized
DEBUG - 2016-09-08 07:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:29:22 --> Input Class Initialized
INFO - 2016-09-08 07:29:22 --> Language Class Initialized
INFO - 2016-09-08 07:29:22 --> Language Class Initialized
INFO - 2016-09-08 07:29:22 --> Config Class Initialized
INFO - 2016-09-08 07:29:22 --> Loader Class Initialized
INFO - 2016-09-08 07:29:22 --> Helper loaded: url_helper
INFO - 2016-09-08 07:29:22 --> Database Driver Class Initialized
INFO - 2016-09-08 07:29:22 --> Controller Class Initialized
DEBUG - 2016-09-08 07:29:22 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:29:22 --> Model Class Initialized
INFO - 2016-09-08 07:29:22 --> Model Class Initialized
DEBUG - 2016-09-08 07:29:22 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:29:22 --> Final output sent to browser
DEBUG - 2016-09-08 07:29:22 --> Total execution time: 0.5114
INFO - 2016-09-08 07:29:54 --> Config Class Initialized
INFO - 2016-09-08 07:29:54 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:29:54 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:29:54 --> Utf8 Class Initialized
INFO - 2016-09-08 07:29:54 --> URI Class Initialized
INFO - 2016-09-08 07:29:54 --> Router Class Initialized
INFO - 2016-09-08 07:29:54 --> Output Class Initialized
INFO - 2016-09-08 07:29:54 --> Security Class Initialized
DEBUG - 2016-09-08 07:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:29:54 --> Input Class Initialized
INFO - 2016-09-08 07:29:54 --> Language Class Initialized
INFO - 2016-09-08 07:29:54 --> Language Class Initialized
INFO - 2016-09-08 07:29:54 --> Config Class Initialized
INFO - 2016-09-08 07:29:54 --> Loader Class Initialized
INFO - 2016-09-08 07:29:54 --> Helper loaded: url_helper
INFO - 2016-09-08 07:29:54 --> Database Driver Class Initialized
INFO - 2016-09-08 07:29:54 --> Controller Class Initialized
DEBUG - 2016-09-08 07:29:54 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:29:54 --> Model Class Initialized
INFO - 2016-09-08 07:29:54 --> Model Class Initialized
DEBUG - 2016-09-08 07:29:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 07:29:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 07:29:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 07:29:54 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 07:29:54 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 07:29:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 07:29:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 07:29:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 07:29:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 07:29:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 07:29:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 07:29:54 --> Final output sent to browser
DEBUG - 2016-09-08 07:29:55 --> Total execution time: 0.7952
INFO - 2016-09-08 07:30:11 --> Config Class Initialized
INFO - 2016-09-08 07:30:11 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:30:11 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:30:11 --> Utf8 Class Initialized
INFO - 2016-09-08 07:30:11 --> URI Class Initialized
INFO - 2016-09-08 07:30:11 --> Router Class Initialized
INFO - 2016-09-08 07:30:11 --> Output Class Initialized
INFO - 2016-09-08 07:30:11 --> Security Class Initialized
DEBUG - 2016-09-08 07:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:30:11 --> Input Class Initialized
INFO - 2016-09-08 07:30:11 --> Language Class Initialized
INFO - 2016-09-08 07:30:11 --> Language Class Initialized
INFO - 2016-09-08 07:30:11 --> Config Class Initialized
INFO - 2016-09-08 07:30:11 --> Loader Class Initialized
INFO - 2016-09-08 07:30:11 --> Helper loaded: url_helper
INFO - 2016-09-08 07:30:11 --> Database Driver Class Initialized
INFO - 2016-09-08 07:30:11 --> Controller Class Initialized
DEBUG - 2016-09-08 07:30:12 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:30:12 --> Model Class Initialized
INFO - 2016-09-08 07:30:12 --> Model Class Initialized
DEBUG - 2016-09-08 07:30:12 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:30:12 --> Final output sent to browser
DEBUG - 2016-09-08 07:30:12 --> Total execution time: 0.4976
INFO - 2016-09-08 07:30:19 --> Config Class Initialized
INFO - 2016-09-08 07:30:19 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:30:19 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:30:19 --> Utf8 Class Initialized
INFO - 2016-09-08 07:30:19 --> URI Class Initialized
INFO - 2016-09-08 07:30:19 --> Router Class Initialized
INFO - 2016-09-08 07:30:19 --> Output Class Initialized
INFO - 2016-09-08 07:30:19 --> Security Class Initialized
DEBUG - 2016-09-08 07:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:30:19 --> Input Class Initialized
INFO - 2016-09-08 07:30:19 --> Language Class Initialized
INFO - 2016-09-08 07:30:19 --> Language Class Initialized
INFO - 2016-09-08 07:30:19 --> Config Class Initialized
INFO - 2016-09-08 07:30:19 --> Loader Class Initialized
INFO - 2016-09-08 07:30:19 --> Helper loaded: url_helper
INFO - 2016-09-08 07:30:19 --> Database Driver Class Initialized
INFO - 2016-09-08 07:30:20 --> Controller Class Initialized
DEBUG - 2016-09-08 07:30:20 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:30:20 --> Model Class Initialized
INFO - 2016-09-08 07:30:20 --> Model Class Initialized
DEBUG - 2016-09-08 07:30:20 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:30:20 --> Final output sent to browser
DEBUG - 2016-09-08 07:30:20 --> Total execution time: 0.5224
INFO - 2016-09-08 07:30:47 --> Config Class Initialized
INFO - 2016-09-08 07:30:47 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:30:47 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:30:47 --> Utf8 Class Initialized
INFO - 2016-09-08 07:30:47 --> URI Class Initialized
INFO - 2016-09-08 07:30:47 --> Router Class Initialized
INFO - 2016-09-08 07:30:47 --> Output Class Initialized
INFO - 2016-09-08 07:30:47 --> Security Class Initialized
DEBUG - 2016-09-08 07:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:30:48 --> Input Class Initialized
INFO - 2016-09-08 07:30:48 --> Language Class Initialized
INFO - 2016-09-08 07:30:48 --> Language Class Initialized
INFO - 2016-09-08 07:30:48 --> Config Class Initialized
INFO - 2016-09-08 07:30:48 --> Loader Class Initialized
INFO - 2016-09-08 07:30:48 --> Helper loaded: url_helper
INFO - 2016-09-08 07:30:48 --> Database Driver Class Initialized
INFO - 2016-09-08 07:30:48 --> Controller Class Initialized
DEBUG - 2016-09-08 07:30:48 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:30:48 --> Model Class Initialized
INFO - 2016-09-08 07:30:48 --> Model Class Initialized
DEBUG - 2016-09-08 07:30:48 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:30:48 --> Final output sent to browser
DEBUG - 2016-09-08 07:30:48 --> Total execution time: 0.4943
INFO - 2016-09-08 07:30:50 --> Config Class Initialized
INFO - 2016-09-08 07:30:50 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:30:50 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:30:50 --> Utf8 Class Initialized
INFO - 2016-09-08 07:30:50 --> URI Class Initialized
INFO - 2016-09-08 07:30:50 --> Router Class Initialized
INFO - 2016-09-08 07:30:51 --> Output Class Initialized
INFO - 2016-09-08 07:30:51 --> Security Class Initialized
DEBUG - 2016-09-08 07:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:30:51 --> Input Class Initialized
INFO - 2016-09-08 07:30:51 --> Language Class Initialized
INFO - 2016-09-08 07:30:51 --> Language Class Initialized
INFO - 2016-09-08 07:30:51 --> Config Class Initialized
INFO - 2016-09-08 07:30:51 --> Loader Class Initialized
INFO - 2016-09-08 07:30:51 --> Helper loaded: url_helper
INFO - 2016-09-08 07:30:51 --> Database Driver Class Initialized
INFO - 2016-09-08 07:30:51 --> Controller Class Initialized
DEBUG - 2016-09-08 07:30:51 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:30:51 --> Model Class Initialized
INFO - 2016-09-08 07:30:51 --> Model Class Initialized
DEBUG - 2016-09-08 07:30:51 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:30:51 --> Final output sent to browser
DEBUG - 2016-09-08 07:30:51 --> Total execution time: 0.5805
INFO - 2016-09-08 07:30:53 --> Config Class Initialized
INFO - 2016-09-08 07:30:53 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:30:53 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:30:53 --> Utf8 Class Initialized
INFO - 2016-09-08 07:30:53 --> URI Class Initialized
INFO - 2016-09-08 07:30:53 --> Router Class Initialized
INFO - 2016-09-08 07:30:53 --> Output Class Initialized
INFO - 2016-09-08 07:30:53 --> Security Class Initialized
DEBUG - 2016-09-08 07:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:30:53 --> Input Class Initialized
INFO - 2016-09-08 07:30:53 --> Language Class Initialized
INFO - 2016-09-08 07:30:53 --> Language Class Initialized
INFO - 2016-09-08 07:30:53 --> Config Class Initialized
INFO - 2016-09-08 07:30:53 --> Loader Class Initialized
INFO - 2016-09-08 07:30:53 --> Helper loaded: url_helper
INFO - 2016-09-08 07:30:53 --> Database Driver Class Initialized
INFO - 2016-09-08 07:30:54 --> Controller Class Initialized
DEBUG - 2016-09-08 07:30:54 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:30:54 --> Model Class Initialized
INFO - 2016-09-08 07:30:54 --> Model Class Initialized
DEBUG - 2016-09-08 07:30:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 07:30:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 07:30:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 07:30:54 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 07:30:54 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 07:30:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 07:30:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 07:30:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 07:30:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 07:30:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 07:30:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 07:30:54 --> Final output sent to browser
DEBUG - 2016-09-08 07:30:54 --> Total execution time: 0.8062
INFO - 2016-09-08 07:31:00 --> Config Class Initialized
INFO - 2016-09-08 07:31:00 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:31:00 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:31:00 --> Utf8 Class Initialized
INFO - 2016-09-08 07:31:00 --> URI Class Initialized
INFO - 2016-09-08 07:31:00 --> Router Class Initialized
INFO - 2016-09-08 07:31:00 --> Output Class Initialized
INFO - 2016-09-08 07:31:00 --> Security Class Initialized
DEBUG - 2016-09-08 07:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:31:00 --> Input Class Initialized
INFO - 2016-09-08 07:31:00 --> Language Class Initialized
INFO - 2016-09-08 07:31:00 --> Language Class Initialized
INFO - 2016-09-08 07:31:00 --> Config Class Initialized
INFO - 2016-09-08 07:31:00 --> Loader Class Initialized
INFO - 2016-09-08 07:31:00 --> Helper loaded: url_helper
INFO - 2016-09-08 07:31:00 --> Database Driver Class Initialized
INFO - 2016-09-08 07:31:00 --> Controller Class Initialized
DEBUG - 2016-09-08 07:31:00 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:31:00 --> Model Class Initialized
INFO - 2016-09-08 07:31:00 --> Model Class Initialized
DEBUG - 2016-09-08 07:31:00 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:31:01 --> Final output sent to browser
DEBUG - 2016-09-08 07:31:01 --> Total execution time: 0.6891
INFO - 2016-09-08 07:32:07 --> Config Class Initialized
INFO - 2016-09-08 07:32:07 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:32:07 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:32:07 --> Utf8 Class Initialized
INFO - 2016-09-08 07:32:07 --> URI Class Initialized
INFO - 2016-09-08 07:32:07 --> Router Class Initialized
INFO - 2016-09-08 07:32:07 --> Output Class Initialized
INFO - 2016-09-08 07:32:07 --> Security Class Initialized
DEBUG - 2016-09-08 07:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:32:07 --> Input Class Initialized
INFO - 2016-09-08 07:32:07 --> Language Class Initialized
INFO - 2016-09-08 07:32:07 --> Language Class Initialized
INFO - 2016-09-08 07:32:07 --> Config Class Initialized
INFO - 2016-09-08 07:32:08 --> Loader Class Initialized
INFO - 2016-09-08 07:32:08 --> Helper loaded: url_helper
INFO - 2016-09-08 07:32:08 --> Database Driver Class Initialized
INFO - 2016-09-08 07:32:08 --> Controller Class Initialized
DEBUG - 2016-09-08 07:32:08 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:32:08 --> Model Class Initialized
INFO - 2016-09-08 07:32:08 --> Model Class Initialized
DEBUG - 2016-09-08 07:32:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 07:32:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 07:32:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 07:32:08 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 07:32:08 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 07:32:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 07:32:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 07:32:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 07:32:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 07:32:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 07:32:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 07:32:08 --> Final output sent to browser
DEBUG - 2016-09-08 07:32:08 --> Total execution time: 0.8006
INFO - 2016-09-08 07:32:15 --> Config Class Initialized
INFO - 2016-09-08 07:32:15 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:32:15 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:32:15 --> Utf8 Class Initialized
INFO - 2016-09-08 07:32:15 --> URI Class Initialized
INFO - 2016-09-08 07:32:15 --> Router Class Initialized
INFO - 2016-09-08 07:32:15 --> Output Class Initialized
INFO - 2016-09-08 07:32:15 --> Security Class Initialized
DEBUG - 2016-09-08 07:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:32:15 --> Input Class Initialized
INFO - 2016-09-08 07:32:15 --> Language Class Initialized
INFO - 2016-09-08 07:32:15 --> Language Class Initialized
INFO - 2016-09-08 07:32:15 --> Config Class Initialized
INFO - 2016-09-08 07:32:15 --> Loader Class Initialized
INFO - 2016-09-08 07:32:15 --> Helper loaded: url_helper
INFO - 2016-09-08 07:32:15 --> Database Driver Class Initialized
INFO - 2016-09-08 07:32:15 --> Controller Class Initialized
DEBUG - 2016-09-08 07:32:15 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:32:15 --> Model Class Initialized
INFO - 2016-09-08 07:32:15 --> Model Class Initialized
DEBUG - 2016-09-08 07:32:15 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:32:15 --> Final output sent to browser
DEBUG - 2016-09-08 07:32:15 --> Total execution time: 0.6418
INFO - 2016-09-08 07:32:20 --> Config Class Initialized
INFO - 2016-09-08 07:32:20 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:32:20 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:32:20 --> Utf8 Class Initialized
INFO - 2016-09-08 07:32:20 --> URI Class Initialized
INFO - 2016-09-08 07:32:20 --> Router Class Initialized
INFO - 2016-09-08 07:32:20 --> Output Class Initialized
INFO - 2016-09-08 07:32:20 --> Security Class Initialized
DEBUG - 2016-09-08 07:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:32:20 --> Input Class Initialized
INFO - 2016-09-08 07:32:21 --> Language Class Initialized
INFO - 2016-09-08 07:32:21 --> Language Class Initialized
INFO - 2016-09-08 07:32:21 --> Config Class Initialized
INFO - 2016-09-08 07:32:21 --> Loader Class Initialized
INFO - 2016-09-08 07:32:21 --> Helper loaded: url_helper
INFO - 2016-09-08 07:32:21 --> Database Driver Class Initialized
INFO - 2016-09-08 07:32:21 --> Controller Class Initialized
DEBUG - 2016-09-08 07:32:21 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:32:21 --> Model Class Initialized
INFO - 2016-09-08 07:32:21 --> Model Class Initialized
DEBUG - 2016-09-08 07:32:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 07:32:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 07:32:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 07:32:21 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 07:32:21 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 07:32:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 07:32:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 07:32:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 07:32:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 07:32:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 07:32:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 07:32:21 --> Final output sent to browser
DEBUG - 2016-09-08 07:32:21 --> Total execution time: 0.8328
INFO - 2016-09-08 07:32:30 --> Config Class Initialized
INFO - 2016-09-08 07:32:30 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:32:30 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:32:30 --> Utf8 Class Initialized
INFO - 2016-09-08 07:32:30 --> URI Class Initialized
INFO - 2016-09-08 07:32:30 --> Router Class Initialized
INFO - 2016-09-08 07:32:30 --> Output Class Initialized
INFO - 2016-09-08 07:32:30 --> Security Class Initialized
DEBUG - 2016-09-08 07:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:32:30 --> Input Class Initialized
INFO - 2016-09-08 07:32:30 --> Language Class Initialized
INFO - 2016-09-08 07:32:30 --> Language Class Initialized
INFO - 2016-09-08 07:32:30 --> Config Class Initialized
INFO - 2016-09-08 07:32:30 --> Loader Class Initialized
INFO - 2016-09-08 07:32:30 --> Helper loaded: url_helper
INFO - 2016-09-08 07:32:30 --> Database Driver Class Initialized
INFO - 2016-09-08 07:32:30 --> Controller Class Initialized
DEBUG - 2016-09-08 07:32:30 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:32:30 --> Model Class Initialized
INFO - 2016-09-08 07:32:30 --> Model Class Initialized
DEBUG - 2016-09-08 07:32:31 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:32:31 --> Final output sent to browser
DEBUG - 2016-09-08 07:32:31 --> Total execution time: 0.6509
INFO - 2016-09-08 07:32:34 --> Config Class Initialized
INFO - 2016-09-08 07:32:34 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:32:34 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:32:34 --> Utf8 Class Initialized
INFO - 2016-09-08 07:32:34 --> URI Class Initialized
INFO - 2016-09-08 07:32:34 --> Router Class Initialized
INFO - 2016-09-08 07:32:34 --> Output Class Initialized
INFO - 2016-09-08 07:32:34 --> Security Class Initialized
DEBUG - 2016-09-08 07:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:32:34 --> Input Class Initialized
INFO - 2016-09-08 07:32:34 --> Language Class Initialized
INFO - 2016-09-08 07:32:34 --> Language Class Initialized
INFO - 2016-09-08 07:32:34 --> Config Class Initialized
INFO - 2016-09-08 07:32:34 --> Loader Class Initialized
INFO - 2016-09-08 07:32:34 --> Helper loaded: url_helper
INFO - 2016-09-08 07:32:34 --> Database Driver Class Initialized
INFO - 2016-09-08 07:32:34 --> Controller Class Initialized
DEBUG - 2016-09-08 07:32:34 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:32:34 --> Model Class Initialized
INFO - 2016-09-08 07:32:34 --> Model Class Initialized
DEBUG - 2016-09-08 07:32:34 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:32:34 --> Final output sent to browser
DEBUG - 2016-09-08 07:32:34 --> Total execution time: 0.5469
INFO - 2016-09-08 07:32:37 --> Config Class Initialized
INFO - 2016-09-08 07:32:37 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:32:37 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:32:37 --> Utf8 Class Initialized
INFO - 2016-09-08 07:32:37 --> URI Class Initialized
INFO - 2016-09-08 07:32:37 --> Router Class Initialized
INFO - 2016-09-08 07:32:37 --> Output Class Initialized
INFO - 2016-09-08 07:32:37 --> Security Class Initialized
DEBUG - 2016-09-08 07:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:32:37 --> Input Class Initialized
INFO - 2016-09-08 07:32:37 --> Language Class Initialized
INFO - 2016-09-08 07:32:37 --> Language Class Initialized
INFO - 2016-09-08 07:32:37 --> Config Class Initialized
INFO - 2016-09-08 07:32:37 --> Loader Class Initialized
INFO - 2016-09-08 07:32:37 --> Helper loaded: url_helper
INFO - 2016-09-08 07:32:37 --> Database Driver Class Initialized
INFO - 2016-09-08 07:32:37 --> Controller Class Initialized
DEBUG - 2016-09-08 07:32:37 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:32:37 --> Model Class Initialized
INFO - 2016-09-08 07:32:37 --> Model Class Initialized
DEBUG - 2016-09-08 07:32:37 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:32:37 --> Final output sent to browser
DEBUG - 2016-09-08 07:32:37 --> Total execution time: 0.5473
INFO - 2016-09-08 07:32:40 --> Config Class Initialized
INFO - 2016-09-08 07:32:40 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:32:40 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:32:40 --> Utf8 Class Initialized
INFO - 2016-09-08 07:32:41 --> URI Class Initialized
INFO - 2016-09-08 07:32:41 --> Router Class Initialized
INFO - 2016-09-08 07:32:41 --> Output Class Initialized
INFO - 2016-09-08 07:32:41 --> Security Class Initialized
DEBUG - 2016-09-08 07:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:32:41 --> Input Class Initialized
INFO - 2016-09-08 07:32:41 --> Language Class Initialized
INFO - 2016-09-08 07:32:41 --> Language Class Initialized
INFO - 2016-09-08 07:32:41 --> Config Class Initialized
INFO - 2016-09-08 07:32:41 --> Loader Class Initialized
INFO - 2016-09-08 07:32:41 --> Helper loaded: url_helper
INFO - 2016-09-08 07:32:41 --> Database Driver Class Initialized
INFO - 2016-09-08 07:32:41 --> Controller Class Initialized
DEBUG - 2016-09-08 07:32:41 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:32:41 --> Model Class Initialized
INFO - 2016-09-08 07:32:41 --> Model Class Initialized
DEBUG - 2016-09-08 07:32:41 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:32:41 --> Final output sent to browser
DEBUG - 2016-09-08 07:32:41 --> Total execution time: 0.5502
INFO - 2016-09-08 07:32:43 --> Config Class Initialized
INFO - 2016-09-08 07:32:43 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:32:43 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:32:43 --> Utf8 Class Initialized
INFO - 2016-09-08 07:32:43 --> URI Class Initialized
INFO - 2016-09-08 07:32:43 --> Router Class Initialized
INFO - 2016-09-08 07:32:43 --> Output Class Initialized
INFO - 2016-09-08 07:32:43 --> Security Class Initialized
DEBUG - 2016-09-08 07:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:32:44 --> Input Class Initialized
INFO - 2016-09-08 07:32:44 --> Language Class Initialized
INFO - 2016-09-08 07:32:44 --> Language Class Initialized
INFO - 2016-09-08 07:32:44 --> Config Class Initialized
INFO - 2016-09-08 07:32:44 --> Loader Class Initialized
INFO - 2016-09-08 07:32:44 --> Helper loaded: url_helper
INFO - 2016-09-08 07:32:44 --> Database Driver Class Initialized
INFO - 2016-09-08 07:32:44 --> Controller Class Initialized
DEBUG - 2016-09-08 07:32:44 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:32:44 --> Model Class Initialized
INFO - 2016-09-08 07:32:44 --> Model Class Initialized
DEBUG - 2016-09-08 07:32:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 07:32:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 07:32:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 07:32:44 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 07:32:44 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 07:32:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 07:32:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 07:32:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 07:32:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 07:32:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 07:32:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 07:32:44 --> Final output sent to browser
DEBUG - 2016-09-08 07:32:44 --> Total execution time: 0.8107
INFO - 2016-09-08 07:32:49 --> Config Class Initialized
INFO - 2016-09-08 07:32:49 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:32:49 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:32:49 --> Utf8 Class Initialized
INFO - 2016-09-08 07:32:49 --> URI Class Initialized
INFO - 2016-09-08 07:32:49 --> Router Class Initialized
INFO - 2016-09-08 07:32:49 --> Output Class Initialized
INFO - 2016-09-08 07:32:49 --> Security Class Initialized
DEBUG - 2016-09-08 07:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:32:50 --> Input Class Initialized
INFO - 2016-09-08 07:32:50 --> Language Class Initialized
INFO - 2016-09-08 07:32:50 --> Language Class Initialized
INFO - 2016-09-08 07:32:50 --> Config Class Initialized
INFO - 2016-09-08 07:32:50 --> Loader Class Initialized
INFO - 2016-09-08 07:32:50 --> Helper loaded: url_helper
INFO - 2016-09-08 07:32:50 --> Database Driver Class Initialized
INFO - 2016-09-08 07:32:50 --> Controller Class Initialized
DEBUG - 2016-09-08 07:32:50 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:32:50 --> Model Class Initialized
INFO - 2016-09-08 07:32:50 --> Model Class Initialized
DEBUG - 2016-09-08 07:32:50 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:32:50 --> Final output sent to browser
DEBUG - 2016-09-08 07:32:50 --> Total execution time: 0.6273
INFO - 2016-09-08 07:32:52 --> Config Class Initialized
INFO - 2016-09-08 07:32:52 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:32:52 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:32:52 --> Utf8 Class Initialized
INFO - 2016-09-08 07:32:52 --> URI Class Initialized
INFO - 2016-09-08 07:32:53 --> Router Class Initialized
INFO - 2016-09-08 07:32:53 --> Output Class Initialized
INFO - 2016-09-08 07:32:53 --> Security Class Initialized
DEBUG - 2016-09-08 07:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:32:53 --> Input Class Initialized
INFO - 2016-09-08 07:32:53 --> Language Class Initialized
INFO - 2016-09-08 07:32:53 --> Language Class Initialized
INFO - 2016-09-08 07:32:53 --> Config Class Initialized
INFO - 2016-09-08 07:32:53 --> Loader Class Initialized
INFO - 2016-09-08 07:32:53 --> Helper loaded: url_helper
INFO - 2016-09-08 07:32:53 --> Database Driver Class Initialized
INFO - 2016-09-08 07:32:53 --> Controller Class Initialized
DEBUG - 2016-09-08 07:32:53 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:32:53 --> Model Class Initialized
INFO - 2016-09-08 07:32:53 --> Model Class Initialized
DEBUG - 2016-09-08 07:32:53 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:32:53 --> Final output sent to browser
DEBUG - 2016-09-08 07:32:53 --> Total execution time: 0.5095
INFO - 2016-09-08 07:32:56 --> Config Class Initialized
INFO - 2016-09-08 07:32:56 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:32:56 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:32:56 --> Utf8 Class Initialized
INFO - 2016-09-08 07:32:56 --> URI Class Initialized
INFO - 2016-09-08 07:32:56 --> Router Class Initialized
INFO - 2016-09-08 07:32:56 --> Output Class Initialized
INFO - 2016-09-08 07:32:56 --> Security Class Initialized
DEBUG - 2016-09-08 07:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:32:56 --> Input Class Initialized
INFO - 2016-09-08 07:32:56 --> Language Class Initialized
INFO - 2016-09-08 07:32:56 --> Language Class Initialized
INFO - 2016-09-08 07:32:56 --> Config Class Initialized
INFO - 2016-09-08 07:32:56 --> Loader Class Initialized
INFO - 2016-09-08 07:32:56 --> Helper loaded: url_helper
INFO - 2016-09-08 07:32:56 --> Database Driver Class Initialized
INFO - 2016-09-08 07:32:56 --> Controller Class Initialized
DEBUG - 2016-09-08 07:32:57 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:32:57 --> Model Class Initialized
INFO - 2016-09-08 07:32:57 --> Model Class Initialized
DEBUG - 2016-09-08 07:32:57 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:32:57 --> Final output sent to browser
DEBUG - 2016-09-08 07:32:57 --> Total execution time: 0.5350
INFO - 2016-09-08 07:32:59 --> Config Class Initialized
INFO - 2016-09-08 07:32:59 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:32:59 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:32:59 --> Utf8 Class Initialized
INFO - 2016-09-08 07:32:59 --> URI Class Initialized
INFO - 2016-09-08 07:32:59 --> Router Class Initialized
INFO - 2016-09-08 07:32:59 --> Output Class Initialized
INFO - 2016-09-08 07:32:59 --> Security Class Initialized
DEBUG - 2016-09-08 07:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:32:59 --> Input Class Initialized
INFO - 2016-09-08 07:32:59 --> Language Class Initialized
INFO - 2016-09-08 07:32:59 --> Language Class Initialized
INFO - 2016-09-08 07:32:59 --> Config Class Initialized
INFO - 2016-09-08 07:32:59 --> Loader Class Initialized
INFO - 2016-09-08 07:32:59 --> Helper loaded: url_helper
INFO - 2016-09-08 07:32:59 --> Database Driver Class Initialized
INFO - 2016-09-08 07:32:59 --> Controller Class Initialized
DEBUG - 2016-09-08 07:32:59 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:32:59 --> Model Class Initialized
INFO - 2016-09-08 07:33:00 --> Model Class Initialized
DEBUG - 2016-09-08 07:33:00 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:33:00 --> Final output sent to browser
DEBUG - 2016-09-08 07:33:00 --> Total execution time: 0.5455
INFO - 2016-09-08 07:33:06 --> Config Class Initialized
INFO - 2016-09-08 07:33:06 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:33:06 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:33:06 --> Utf8 Class Initialized
INFO - 2016-09-08 07:33:06 --> URI Class Initialized
INFO - 2016-09-08 07:33:06 --> Router Class Initialized
INFO - 2016-09-08 07:33:06 --> Output Class Initialized
INFO - 2016-09-08 07:33:06 --> Security Class Initialized
DEBUG - 2016-09-08 07:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:33:06 --> Input Class Initialized
INFO - 2016-09-08 07:33:06 --> Language Class Initialized
INFO - 2016-09-08 07:33:06 --> Language Class Initialized
INFO - 2016-09-08 07:33:06 --> Config Class Initialized
INFO - 2016-09-08 07:33:06 --> Loader Class Initialized
INFO - 2016-09-08 07:33:06 --> Helper loaded: url_helper
INFO - 2016-09-08 07:33:06 --> Database Driver Class Initialized
INFO - 2016-09-08 07:33:06 --> Controller Class Initialized
DEBUG - 2016-09-08 07:33:07 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:33:07 --> Model Class Initialized
INFO - 2016-09-08 07:33:07 --> Model Class Initialized
DEBUG - 2016-09-08 07:33:07 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:33:07 --> Final output sent to browser
DEBUG - 2016-09-08 07:33:07 --> Total execution time: 0.5307
INFO - 2016-09-08 07:33:21 --> Config Class Initialized
INFO - 2016-09-08 07:33:21 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:33:21 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:33:21 --> Utf8 Class Initialized
INFO - 2016-09-08 07:33:21 --> URI Class Initialized
INFO - 2016-09-08 07:33:21 --> Router Class Initialized
INFO - 2016-09-08 07:33:21 --> Output Class Initialized
INFO - 2016-09-08 07:33:21 --> Security Class Initialized
DEBUG - 2016-09-08 07:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:33:21 --> Input Class Initialized
INFO - 2016-09-08 07:33:21 --> Language Class Initialized
INFO - 2016-09-08 07:33:21 --> Language Class Initialized
INFO - 2016-09-08 07:33:21 --> Config Class Initialized
INFO - 2016-09-08 07:33:21 --> Loader Class Initialized
INFO - 2016-09-08 07:33:21 --> Helper loaded: url_helper
INFO - 2016-09-08 07:33:21 --> Database Driver Class Initialized
INFO - 2016-09-08 07:33:21 --> Controller Class Initialized
DEBUG - 2016-09-08 07:33:21 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:33:21 --> Model Class Initialized
INFO - 2016-09-08 07:33:21 --> Model Class Initialized
DEBUG - 2016-09-08 07:33:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 07:33:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 07:33:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 07:33:22 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 07:33:22 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 07:33:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 07:33:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 07:33:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 07:33:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 07:33:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 07:33:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 07:33:22 --> Final output sent to browser
DEBUG - 2016-09-08 07:33:22 --> Total execution time: 0.8375
INFO - 2016-09-08 07:35:18 --> Config Class Initialized
INFO - 2016-09-08 07:35:18 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:35:18 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:35:18 --> Utf8 Class Initialized
INFO - 2016-09-08 07:35:18 --> URI Class Initialized
INFO - 2016-09-08 07:35:18 --> Router Class Initialized
INFO - 2016-09-08 07:35:18 --> Output Class Initialized
INFO - 2016-09-08 07:35:19 --> Security Class Initialized
DEBUG - 2016-09-08 07:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:35:19 --> Input Class Initialized
INFO - 2016-09-08 07:35:19 --> Language Class Initialized
INFO - 2016-09-08 07:35:19 --> Language Class Initialized
INFO - 2016-09-08 07:35:19 --> Config Class Initialized
INFO - 2016-09-08 07:35:19 --> Loader Class Initialized
INFO - 2016-09-08 07:35:19 --> Helper loaded: url_helper
INFO - 2016-09-08 07:35:19 --> Database Driver Class Initialized
INFO - 2016-09-08 07:35:19 --> Controller Class Initialized
DEBUG - 2016-09-08 07:35:19 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:35:19 --> Model Class Initialized
INFO - 2016-09-08 07:35:19 --> Model Class Initialized
DEBUG - 2016-09-08 07:35:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 07:35:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 07:35:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 07:35:19 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 07:35:19 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 07:35:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 07:35:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 07:35:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 07:35:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 07:35:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 07:35:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 07:35:19 --> Final output sent to browser
DEBUG - 2016-09-08 07:35:19 --> Total execution time: 0.8170
INFO - 2016-09-08 07:35:29 --> Config Class Initialized
INFO - 2016-09-08 07:35:29 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:35:29 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:35:29 --> Utf8 Class Initialized
INFO - 2016-09-08 07:35:29 --> URI Class Initialized
INFO - 2016-09-08 07:35:29 --> Router Class Initialized
INFO - 2016-09-08 07:35:29 --> Output Class Initialized
INFO - 2016-09-08 07:35:29 --> Security Class Initialized
DEBUG - 2016-09-08 07:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:35:29 --> Input Class Initialized
INFO - 2016-09-08 07:35:29 --> Language Class Initialized
INFO - 2016-09-08 07:35:29 --> Language Class Initialized
INFO - 2016-09-08 07:35:29 --> Config Class Initialized
INFO - 2016-09-08 07:35:29 --> Loader Class Initialized
INFO - 2016-09-08 07:35:29 --> Helper loaded: url_helper
INFO - 2016-09-08 07:35:29 --> Database Driver Class Initialized
INFO - 2016-09-08 07:35:29 --> Controller Class Initialized
DEBUG - 2016-09-08 07:35:29 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:35:29 --> Model Class Initialized
INFO - 2016-09-08 07:35:29 --> Model Class Initialized
DEBUG - 2016-09-08 07:35:29 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:35:29 --> Final output sent to browser
DEBUG - 2016-09-08 07:35:29 --> Total execution time: 0.6520
INFO - 2016-09-08 07:35:34 --> Config Class Initialized
INFO - 2016-09-08 07:35:34 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:35:34 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:35:34 --> Utf8 Class Initialized
INFO - 2016-09-08 07:35:34 --> URI Class Initialized
INFO - 2016-09-08 07:35:34 --> Router Class Initialized
INFO - 2016-09-08 07:35:34 --> Output Class Initialized
INFO - 2016-09-08 07:35:34 --> Security Class Initialized
DEBUG - 2016-09-08 07:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:35:34 --> Input Class Initialized
INFO - 2016-09-08 07:35:34 --> Language Class Initialized
INFO - 2016-09-08 07:35:34 --> Language Class Initialized
INFO - 2016-09-08 07:35:34 --> Config Class Initialized
INFO - 2016-09-08 07:35:34 --> Loader Class Initialized
INFO - 2016-09-08 07:35:34 --> Helper loaded: url_helper
INFO - 2016-09-08 07:35:34 --> Database Driver Class Initialized
INFO - 2016-09-08 07:35:34 --> Controller Class Initialized
DEBUG - 2016-09-08 07:35:34 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:35:34 --> Model Class Initialized
INFO - 2016-09-08 07:35:34 --> Model Class Initialized
DEBUG - 2016-09-08 07:35:34 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:35:34 --> Final output sent to browser
DEBUG - 2016-09-08 07:35:34 --> Total execution time: 0.5432
INFO - 2016-09-08 07:35:40 --> Config Class Initialized
INFO - 2016-09-08 07:35:40 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:35:40 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:35:40 --> Utf8 Class Initialized
INFO - 2016-09-08 07:35:40 --> URI Class Initialized
INFO - 2016-09-08 07:35:40 --> Router Class Initialized
INFO - 2016-09-08 07:35:40 --> Output Class Initialized
INFO - 2016-09-08 07:35:40 --> Security Class Initialized
DEBUG - 2016-09-08 07:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:35:40 --> Input Class Initialized
INFO - 2016-09-08 07:35:40 --> Language Class Initialized
INFO - 2016-09-08 07:35:40 --> Language Class Initialized
INFO - 2016-09-08 07:35:40 --> Config Class Initialized
INFO - 2016-09-08 07:35:40 --> Loader Class Initialized
INFO - 2016-09-08 07:35:40 --> Helper loaded: url_helper
INFO - 2016-09-08 07:35:40 --> Database Driver Class Initialized
INFO - 2016-09-08 07:35:40 --> Controller Class Initialized
DEBUG - 2016-09-08 07:35:40 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:35:40 --> Model Class Initialized
INFO - 2016-09-08 07:35:40 --> Model Class Initialized
DEBUG - 2016-09-08 07:35:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 07:35:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 07:35:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 07:35:40 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 07:35:40 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 07:35:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 07:35:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 07:35:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 07:35:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 07:35:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 07:35:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 07:35:40 --> Final output sent to browser
DEBUG - 2016-09-08 07:35:41 --> Total execution time: 0.8383
INFO - 2016-09-08 07:36:06 --> Config Class Initialized
INFO - 2016-09-08 07:36:06 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:36:06 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:36:06 --> Utf8 Class Initialized
INFO - 2016-09-08 07:36:06 --> URI Class Initialized
INFO - 2016-09-08 07:36:06 --> Router Class Initialized
INFO - 2016-09-08 07:36:06 --> Output Class Initialized
INFO - 2016-09-08 07:36:06 --> Security Class Initialized
DEBUG - 2016-09-08 07:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:36:06 --> Input Class Initialized
INFO - 2016-09-08 07:36:06 --> Language Class Initialized
INFO - 2016-09-08 07:36:06 --> Language Class Initialized
INFO - 2016-09-08 07:36:06 --> Config Class Initialized
INFO - 2016-09-08 07:36:06 --> Loader Class Initialized
INFO - 2016-09-08 07:36:06 --> Helper loaded: url_helper
INFO - 2016-09-08 07:36:06 --> Database Driver Class Initialized
INFO - 2016-09-08 07:36:06 --> Controller Class Initialized
DEBUG - 2016-09-08 07:36:06 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:36:06 --> Model Class Initialized
INFO - 2016-09-08 07:36:06 --> Model Class Initialized
DEBUG - 2016-09-08 07:36:06 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:36:06 --> Final output sent to browser
DEBUG - 2016-09-08 07:36:06 --> Total execution time: 0.6251
INFO - 2016-09-08 07:47:57 --> Config Class Initialized
INFO - 2016-09-08 07:47:57 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:47:57 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:47:57 --> Utf8 Class Initialized
INFO - 2016-09-08 07:47:57 --> URI Class Initialized
INFO - 2016-09-08 07:47:57 --> Router Class Initialized
INFO - 2016-09-08 07:47:57 --> Output Class Initialized
INFO - 2016-09-08 07:47:57 --> Security Class Initialized
DEBUG - 2016-09-08 07:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:47:57 --> Input Class Initialized
INFO - 2016-09-08 07:47:57 --> Language Class Initialized
INFO - 2016-09-08 07:47:57 --> Language Class Initialized
INFO - 2016-09-08 07:47:57 --> Config Class Initialized
INFO - 2016-09-08 07:47:57 --> Loader Class Initialized
INFO - 2016-09-08 07:47:57 --> Helper loaded: url_helper
INFO - 2016-09-08 07:47:57 --> Database Driver Class Initialized
INFO - 2016-09-08 07:47:57 --> Controller Class Initialized
DEBUG - 2016-09-08 07:47:57 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:47:57 --> Model Class Initialized
INFO - 2016-09-08 07:47:57 --> Model Class Initialized
DEBUG - 2016-09-08 07:47:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 07:47:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 07:47:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 07:47:57 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 07:47:57 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 07:47:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 07:47:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 07:47:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 07:47:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 07:47:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 07:47:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 07:47:58 --> Final output sent to browser
DEBUG - 2016-09-08 07:47:58 --> Total execution time: 0.9629
INFO - 2016-09-08 07:48:31 --> Config Class Initialized
INFO - 2016-09-08 07:48:31 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:48:31 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:48:31 --> Utf8 Class Initialized
INFO - 2016-09-08 07:48:31 --> URI Class Initialized
INFO - 2016-09-08 07:48:31 --> Router Class Initialized
INFO - 2016-09-08 07:48:31 --> Output Class Initialized
INFO - 2016-09-08 07:48:31 --> Security Class Initialized
DEBUG - 2016-09-08 07:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:48:31 --> Input Class Initialized
INFO - 2016-09-08 07:48:31 --> Language Class Initialized
INFO - 2016-09-08 07:48:31 --> Language Class Initialized
INFO - 2016-09-08 07:48:31 --> Config Class Initialized
INFO - 2016-09-08 07:48:31 --> Loader Class Initialized
INFO - 2016-09-08 07:48:31 --> Helper loaded: url_helper
INFO - 2016-09-08 07:48:31 --> Database Driver Class Initialized
INFO - 2016-09-08 07:48:31 --> Controller Class Initialized
DEBUG - 2016-09-08 07:48:31 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:48:31 --> Model Class Initialized
INFO - 2016-09-08 07:48:31 --> Model Class Initialized
DEBUG - 2016-09-08 07:48:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 07:48:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 07:48:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 07:48:31 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 07:48:31 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 07:48:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 07:48:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 07:48:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 07:48:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 07:48:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 07:48:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 07:48:32 --> Final output sent to browser
DEBUG - 2016-09-08 07:48:32 --> Total execution time: 0.8806
INFO - 2016-09-08 07:49:34 --> Config Class Initialized
INFO - 2016-09-08 07:49:34 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:49:34 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:49:34 --> Utf8 Class Initialized
INFO - 2016-09-08 07:49:34 --> URI Class Initialized
INFO - 2016-09-08 07:49:34 --> Router Class Initialized
INFO - 2016-09-08 07:49:34 --> Output Class Initialized
INFO - 2016-09-08 07:49:34 --> Security Class Initialized
DEBUG - 2016-09-08 07:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:49:34 --> Input Class Initialized
INFO - 2016-09-08 07:49:34 --> Language Class Initialized
INFO - 2016-09-08 07:49:34 --> Language Class Initialized
INFO - 2016-09-08 07:49:34 --> Config Class Initialized
INFO - 2016-09-08 07:49:34 --> Loader Class Initialized
INFO - 2016-09-08 07:49:34 --> Helper loaded: url_helper
INFO - 2016-09-08 07:49:34 --> Database Driver Class Initialized
INFO - 2016-09-08 07:49:34 --> Controller Class Initialized
DEBUG - 2016-09-08 07:49:34 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:49:34 --> Model Class Initialized
INFO - 2016-09-08 07:49:34 --> Model Class Initialized
DEBUG - 2016-09-08 07:49:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 07:49:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 07:49:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 07:49:34 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 07:49:34 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 07:49:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 07:49:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 07:49:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 07:49:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 07:49:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 07:49:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 07:49:34 --> Final output sent to browser
DEBUG - 2016-09-08 07:49:34 --> Total execution time: 0.8368
INFO - 2016-09-08 07:52:39 --> Config Class Initialized
INFO - 2016-09-08 07:52:39 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:52:39 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:52:39 --> Utf8 Class Initialized
INFO - 2016-09-08 07:52:39 --> URI Class Initialized
INFO - 2016-09-08 07:52:39 --> Router Class Initialized
INFO - 2016-09-08 07:52:39 --> Output Class Initialized
INFO - 2016-09-08 07:52:39 --> Security Class Initialized
DEBUG - 2016-09-08 07:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:52:39 --> Input Class Initialized
INFO - 2016-09-08 07:52:39 --> Language Class Initialized
INFO - 2016-09-08 07:52:39 --> Language Class Initialized
INFO - 2016-09-08 07:52:39 --> Config Class Initialized
INFO - 2016-09-08 07:52:39 --> Loader Class Initialized
INFO - 2016-09-08 07:52:39 --> Helper loaded: url_helper
INFO - 2016-09-08 07:52:39 --> Database Driver Class Initialized
INFO - 2016-09-08 07:52:39 --> Controller Class Initialized
DEBUG - 2016-09-08 07:52:39 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:52:39 --> Model Class Initialized
INFO - 2016-09-08 07:52:39 --> Model Class Initialized
DEBUG - 2016-09-08 07:52:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 07:52:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 07:52:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 07:52:39 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 07:52:39 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 07:52:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 07:52:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 07:52:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 07:52:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 07:52:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 07:52:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 07:52:39 --> Final output sent to browser
DEBUG - 2016-09-08 07:52:40 --> Total execution time: 0.8713
INFO - 2016-09-08 07:53:37 --> Config Class Initialized
INFO - 2016-09-08 07:53:37 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:53:37 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:53:38 --> Utf8 Class Initialized
INFO - 2016-09-08 07:53:38 --> URI Class Initialized
INFO - 2016-09-08 07:53:38 --> Router Class Initialized
INFO - 2016-09-08 07:53:38 --> Output Class Initialized
INFO - 2016-09-08 07:53:38 --> Security Class Initialized
DEBUG - 2016-09-08 07:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:53:38 --> Input Class Initialized
INFO - 2016-09-08 07:53:38 --> Language Class Initialized
INFO - 2016-09-08 07:53:38 --> Language Class Initialized
INFO - 2016-09-08 07:53:38 --> Config Class Initialized
INFO - 2016-09-08 07:53:38 --> Loader Class Initialized
INFO - 2016-09-08 07:53:38 --> Helper loaded: url_helper
INFO - 2016-09-08 07:53:38 --> Database Driver Class Initialized
INFO - 2016-09-08 07:53:38 --> Controller Class Initialized
DEBUG - 2016-09-08 07:53:38 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:53:38 --> Model Class Initialized
INFO - 2016-09-08 07:53:38 --> Model Class Initialized
DEBUG - 2016-09-08 07:53:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 07:53:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 07:53:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 07:53:38 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 07:53:38 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 07:53:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 07:53:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 07:53:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 07:53:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 07:53:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 07:53:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 07:53:38 --> Final output sent to browser
DEBUG - 2016-09-08 07:53:39 --> Total execution time: 0.8552
INFO - 2016-09-08 07:53:48 --> Config Class Initialized
INFO - 2016-09-08 07:53:48 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:53:48 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:53:48 --> Utf8 Class Initialized
INFO - 2016-09-08 07:53:48 --> URI Class Initialized
INFO - 2016-09-08 07:53:48 --> Router Class Initialized
INFO - 2016-09-08 07:53:48 --> Output Class Initialized
INFO - 2016-09-08 07:53:48 --> Security Class Initialized
DEBUG - 2016-09-08 07:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:53:48 --> Input Class Initialized
INFO - 2016-09-08 07:53:48 --> Language Class Initialized
INFO - 2016-09-08 07:53:48 --> Language Class Initialized
INFO - 2016-09-08 07:53:48 --> Config Class Initialized
INFO - 2016-09-08 07:53:48 --> Loader Class Initialized
INFO - 2016-09-08 07:53:48 --> Helper loaded: url_helper
INFO - 2016-09-08 07:53:48 --> Database Driver Class Initialized
INFO - 2016-09-08 07:53:48 --> Controller Class Initialized
DEBUG - 2016-09-08 07:53:48 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:53:48 --> Model Class Initialized
INFO - 2016-09-08 07:53:48 --> Model Class Initialized
DEBUG - 2016-09-08 07:53:48 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:53:48 --> Final output sent to browser
DEBUG - 2016-09-08 07:53:48 --> Total execution time: 0.6674
INFO - 2016-09-08 07:53:54 --> Config Class Initialized
INFO - 2016-09-08 07:53:54 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:53:54 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:53:54 --> Utf8 Class Initialized
INFO - 2016-09-08 07:53:55 --> URI Class Initialized
INFO - 2016-09-08 07:53:55 --> Router Class Initialized
INFO - 2016-09-08 07:53:55 --> Output Class Initialized
INFO - 2016-09-08 07:53:55 --> Security Class Initialized
DEBUG - 2016-09-08 07:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:53:55 --> Input Class Initialized
INFO - 2016-09-08 07:53:55 --> Language Class Initialized
INFO - 2016-09-08 07:53:55 --> Language Class Initialized
INFO - 2016-09-08 07:53:55 --> Config Class Initialized
INFO - 2016-09-08 07:53:55 --> Loader Class Initialized
INFO - 2016-09-08 07:53:55 --> Helper loaded: url_helper
INFO - 2016-09-08 07:53:55 --> Database Driver Class Initialized
INFO - 2016-09-08 07:53:55 --> Controller Class Initialized
DEBUG - 2016-09-08 07:53:55 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:53:55 --> Model Class Initialized
INFO - 2016-09-08 07:53:55 --> Model Class Initialized
DEBUG - 2016-09-08 07:53:55 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:53:55 --> Final output sent to browser
DEBUG - 2016-09-08 07:53:55 --> Total execution time: 0.5378
INFO - 2016-09-08 07:54:00 --> Config Class Initialized
INFO - 2016-09-08 07:54:00 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:54:00 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:54:00 --> Utf8 Class Initialized
INFO - 2016-09-08 07:54:00 --> URI Class Initialized
INFO - 2016-09-08 07:54:00 --> Router Class Initialized
INFO - 2016-09-08 07:54:00 --> Output Class Initialized
INFO - 2016-09-08 07:54:00 --> Security Class Initialized
DEBUG - 2016-09-08 07:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:54:01 --> Input Class Initialized
INFO - 2016-09-08 07:54:01 --> Language Class Initialized
INFO - 2016-09-08 07:54:01 --> Language Class Initialized
INFO - 2016-09-08 07:54:01 --> Config Class Initialized
INFO - 2016-09-08 07:54:01 --> Loader Class Initialized
INFO - 2016-09-08 07:54:01 --> Helper loaded: url_helper
INFO - 2016-09-08 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-08 07:54:01 --> Controller Class Initialized
DEBUG - 2016-09-08 07:54:01 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:54:01 --> Model Class Initialized
INFO - 2016-09-08 07:54:01 --> Model Class Initialized
DEBUG - 2016-09-08 07:54:01 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:54:01 --> Final output sent to browser
DEBUG - 2016-09-08 07:54:01 --> Total execution time: 0.5422
INFO - 2016-09-08 07:54:04 --> Config Class Initialized
INFO - 2016-09-08 07:54:04 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:54:04 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:54:04 --> Utf8 Class Initialized
INFO - 2016-09-08 07:54:04 --> URI Class Initialized
INFO - 2016-09-08 07:54:04 --> Router Class Initialized
INFO - 2016-09-08 07:54:04 --> Output Class Initialized
INFO - 2016-09-08 07:54:04 --> Security Class Initialized
DEBUG - 2016-09-08 07:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:54:04 --> Input Class Initialized
INFO - 2016-09-08 07:54:04 --> Language Class Initialized
INFO - 2016-09-08 07:54:04 --> Language Class Initialized
INFO - 2016-09-08 07:54:04 --> Config Class Initialized
INFO - 2016-09-08 07:54:04 --> Loader Class Initialized
INFO - 2016-09-08 07:54:04 --> Helper loaded: url_helper
INFO - 2016-09-08 07:54:04 --> Database Driver Class Initialized
INFO - 2016-09-08 07:54:04 --> Controller Class Initialized
DEBUG - 2016-09-08 07:54:04 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:54:04 --> Model Class Initialized
INFO - 2016-09-08 07:54:04 --> Model Class Initialized
DEBUG - 2016-09-08 07:54:04 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:54:04 --> Final output sent to browser
DEBUG - 2016-09-08 07:54:04 --> Total execution time: 0.5313
INFO - 2016-09-08 07:54:07 --> Config Class Initialized
INFO - 2016-09-08 07:54:07 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:54:07 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:54:07 --> Utf8 Class Initialized
INFO - 2016-09-08 07:54:07 --> URI Class Initialized
INFO - 2016-09-08 07:54:07 --> Router Class Initialized
INFO - 2016-09-08 07:54:07 --> Output Class Initialized
INFO - 2016-09-08 07:54:07 --> Security Class Initialized
DEBUG - 2016-09-08 07:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:54:07 --> Input Class Initialized
INFO - 2016-09-08 07:54:07 --> Language Class Initialized
INFO - 2016-09-08 07:54:07 --> Language Class Initialized
INFO - 2016-09-08 07:54:07 --> Config Class Initialized
INFO - 2016-09-08 07:54:07 --> Loader Class Initialized
INFO - 2016-09-08 07:54:07 --> Helper loaded: url_helper
INFO - 2016-09-08 07:54:07 --> Database Driver Class Initialized
INFO - 2016-09-08 07:54:07 --> Controller Class Initialized
DEBUG - 2016-09-08 07:54:07 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:54:07 --> Model Class Initialized
INFO - 2016-09-08 07:54:07 --> Model Class Initialized
DEBUG - 2016-09-08 07:54:07 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:54:07 --> Final output sent to browser
DEBUG - 2016-09-08 07:54:07 --> Total execution time: 0.6588
INFO - 2016-09-08 07:54:12 --> Config Class Initialized
INFO - 2016-09-08 07:54:12 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:54:12 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:54:12 --> Utf8 Class Initialized
INFO - 2016-09-08 07:54:12 --> URI Class Initialized
INFO - 2016-09-08 07:54:12 --> Router Class Initialized
INFO - 2016-09-08 07:54:12 --> Output Class Initialized
INFO - 2016-09-08 07:54:12 --> Security Class Initialized
DEBUG - 2016-09-08 07:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:54:12 --> Input Class Initialized
INFO - 2016-09-08 07:54:12 --> Language Class Initialized
INFO - 2016-09-08 07:54:12 --> Language Class Initialized
INFO - 2016-09-08 07:54:12 --> Config Class Initialized
INFO - 2016-09-08 07:54:12 --> Loader Class Initialized
INFO - 2016-09-08 07:54:12 --> Helper loaded: url_helper
INFO - 2016-09-08 07:54:12 --> Database Driver Class Initialized
INFO - 2016-09-08 07:54:12 --> Controller Class Initialized
DEBUG - 2016-09-08 07:54:12 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:54:12 --> Model Class Initialized
INFO - 2016-09-08 07:54:12 --> Model Class Initialized
DEBUG - 2016-09-08 07:54:12 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:54:12 --> Final output sent to browser
DEBUG - 2016-09-08 07:54:12 --> Total execution time: 0.5290
INFO - 2016-09-08 07:54:29 --> Config Class Initialized
INFO - 2016-09-08 07:54:29 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:54:29 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:54:29 --> Utf8 Class Initialized
INFO - 2016-09-08 07:54:29 --> URI Class Initialized
INFO - 2016-09-08 07:54:29 --> Router Class Initialized
INFO - 2016-09-08 07:54:29 --> Output Class Initialized
INFO - 2016-09-08 07:54:29 --> Security Class Initialized
DEBUG - 2016-09-08 07:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:54:29 --> Input Class Initialized
INFO - 2016-09-08 07:54:29 --> Language Class Initialized
INFO - 2016-09-08 07:54:29 --> Language Class Initialized
INFO - 2016-09-08 07:54:29 --> Config Class Initialized
INFO - 2016-09-08 07:54:29 --> Loader Class Initialized
INFO - 2016-09-08 07:54:29 --> Helper loaded: url_helper
INFO - 2016-09-08 07:54:29 --> Database Driver Class Initialized
INFO - 2016-09-08 07:54:29 --> Controller Class Initialized
DEBUG - 2016-09-08 07:54:29 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:54:29 --> Model Class Initialized
INFO - 2016-09-08 07:54:29 --> Model Class Initialized
DEBUG - 2016-09-08 07:54:29 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:54:29 --> Final output sent to browser
DEBUG - 2016-09-08 07:54:29 --> Total execution time: 0.5374
INFO - 2016-09-08 07:54:32 --> Config Class Initialized
INFO - 2016-09-08 07:54:32 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:54:32 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:54:32 --> Utf8 Class Initialized
INFO - 2016-09-08 07:54:32 --> URI Class Initialized
INFO - 2016-09-08 07:54:32 --> Router Class Initialized
INFO - 2016-09-08 07:54:32 --> Output Class Initialized
INFO - 2016-09-08 07:54:32 --> Security Class Initialized
DEBUG - 2016-09-08 07:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:54:32 --> Input Class Initialized
INFO - 2016-09-08 07:54:32 --> Language Class Initialized
INFO - 2016-09-08 07:54:32 --> Language Class Initialized
INFO - 2016-09-08 07:54:32 --> Config Class Initialized
INFO - 2016-09-08 07:54:32 --> Loader Class Initialized
INFO - 2016-09-08 07:54:32 --> Helper loaded: url_helper
INFO - 2016-09-08 07:54:32 --> Database Driver Class Initialized
INFO - 2016-09-08 07:54:32 --> Controller Class Initialized
DEBUG - 2016-09-08 07:54:32 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:54:32 --> Model Class Initialized
INFO - 2016-09-08 07:54:32 --> Model Class Initialized
DEBUG - 2016-09-08 07:54:32 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:54:32 --> Final output sent to browser
DEBUG - 2016-09-08 07:54:32 --> Total execution time: 0.5915
INFO - 2016-09-08 07:54:35 --> Config Class Initialized
INFO - 2016-09-08 07:54:35 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:54:35 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:54:35 --> Utf8 Class Initialized
INFO - 2016-09-08 07:54:35 --> URI Class Initialized
INFO - 2016-09-08 07:54:35 --> Router Class Initialized
INFO - 2016-09-08 07:54:35 --> Output Class Initialized
INFO - 2016-09-08 07:54:35 --> Security Class Initialized
DEBUG - 2016-09-08 07:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:54:35 --> Input Class Initialized
INFO - 2016-09-08 07:54:35 --> Language Class Initialized
INFO - 2016-09-08 07:54:35 --> Language Class Initialized
INFO - 2016-09-08 07:54:35 --> Config Class Initialized
INFO - 2016-09-08 07:54:35 --> Loader Class Initialized
INFO - 2016-09-08 07:54:35 --> Helper loaded: url_helper
INFO - 2016-09-08 07:54:36 --> Database Driver Class Initialized
INFO - 2016-09-08 07:54:36 --> Controller Class Initialized
DEBUG - 2016-09-08 07:54:36 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:54:36 --> Model Class Initialized
INFO - 2016-09-08 07:54:36 --> Model Class Initialized
DEBUG - 2016-09-08 07:54:36 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:54:36 --> Final output sent to browser
DEBUG - 2016-09-08 07:54:36 --> Total execution time: 0.5933
INFO - 2016-09-08 07:54:42 --> Config Class Initialized
INFO - 2016-09-08 07:54:42 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:54:42 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:54:42 --> Utf8 Class Initialized
INFO - 2016-09-08 07:54:42 --> URI Class Initialized
INFO - 2016-09-08 07:54:42 --> Router Class Initialized
INFO - 2016-09-08 07:54:42 --> Output Class Initialized
INFO - 2016-09-08 07:54:42 --> Security Class Initialized
DEBUG - 2016-09-08 07:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:54:42 --> Input Class Initialized
INFO - 2016-09-08 07:54:42 --> Language Class Initialized
INFO - 2016-09-08 07:54:42 --> Language Class Initialized
INFO - 2016-09-08 07:54:42 --> Config Class Initialized
INFO - 2016-09-08 07:54:42 --> Loader Class Initialized
INFO - 2016-09-08 07:54:42 --> Helper loaded: url_helper
INFO - 2016-09-08 07:54:42 --> Database Driver Class Initialized
INFO - 2016-09-08 07:54:42 --> Controller Class Initialized
DEBUG - 2016-09-08 07:54:42 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:54:42 --> Model Class Initialized
INFO - 2016-09-08 07:54:42 --> Model Class Initialized
DEBUG - 2016-09-08 07:54:42 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:54:42 --> Final output sent to browser
DEBUG - 2016-09-08 07:54:42 --> Total execution time: 0.5371
INFO - 2016-09-08 07:54:46 --> Config Class Initialized
INFO - 2016-09-08 07:54:46 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:54:46 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:54:46 --> Utf8 Class Initialized
INFO - 2016-09-08 07:54:46 --> URI Class Initialized
INFO - 2016-09-08 07:54:46 --> Router Class Initialized
INFO - 2016-09-08 07:54:46 --> Output Class Initialized
INFO - 2016-09-08 07:54:47 --> Security Class Initialized
DEBUG - 2016-09-08 07:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:54:47 --> Input Class Initialized
INFO - 2016-09-08 07:54:47 --> Language Class Initialized
INFO - 2016-09-08 07:54:47 --> Language Class Initialized
INFO - 2016-09-08 07:54:47 --> Config Class Initialized
INFO - 2016-09-08 07:54:47 --> Loader Class Initialized
INFO - 2016-09-08 07:54:47 --> Helper loaded: url_helper
INFO - 2016-09-08 07:54:47 --> Database Driver Class Initialized
INFO - 2016-09-08 07:54:47 --> Controller Class Initialized
DEBUG - 2016-09-08 07:54:47 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:54:47 --> Model Class Initialized
INFO - 2016-09-08 07:54:47 --> Model Class Initialized
DEBUG - 2016-09-08 07:54:47 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:54:47 --> Final output sent to browser
DEBUG - 2016-09-08 07:54:47 --> Total execution time: 0.5681
INFO - 2016-09-08 07:54:52 --> Config Class Initialized
INFO - 2016-09-08 07:54:52 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:54:52 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:54:53 --> Utf8 Class Initialized
INFO - 2016-09-08 07:54:53 --> URI Class Initialized
INFO - 2016-09-08 07:54:53 --> Router Class Initialized
INFO - 2016-09-08 07:54:53 --> Output Class Initialized
INFO - 2016-09-08 07:54:53 --> Security Class Initialized
DEBUG - 2016-09-08 07:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:54:53 --> Input Class Initialized
INFO - 2016-09-08 07:54:53 --> Language Class Initialized
INFO - 2016-09-08 07:54:53 --> Language Class Initialized
INFO - 2016-09-08 07:54:53 --> Config Class Initialized
INFO - 2016-09-08 07:54:53 --> Loader Class Initialized
INFO - 2016-09-08 07:54:53 --> Helper loaded: url_helper
INFO - 2016-09-08 07:54:53 --> Database Driver Class Initialized
INFO - 2016-09-08 07:54:53 --> Controller Class Initialized
DEBUG - 2016-09-08 07:54:53 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:54:53 --> Model Class Initialized
INFO - 2016-09-08 07:54:53 --> Model Class Initialized
DEBUG - 2016-09-08 07:54:53 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:54:53 --> Final output sent to browser
DEBUG - 2016-09-08 07:54:53 --> Total execution time: 0.5480
INFO - 2016-09-08 07:54:58 --> Config Class Initialized
INFO - 2016-09-08 07:54:58 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:54:58 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:54:58 --> Utf8 Class Initialized
INFO - 2016-09-08 07:54:58 --> URI Class Initialized
INFO - 2016-09-08 07:54:58 --> Router Class Initialized
INFO - 2016-09-08 07:54:58 --> Output Class Initialized
INFO - 2016-09-08 07:54:58 --> Security Class Initialized
DEBUG - 2016-09-08 07:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:54:58 --> Input Class Initialized
INFO - 2016-09-08 07:54:59 --> Language Class Initialized
INFO - 2016-09-08 07:54:59 --> Language Class Initialized
INFO - 2016-09-08 07:54:59 --> Config Class Initialized
INFO - 2016-09-08 07:54:59 --> Loader Class Initialized
INFO - 2016-09-08 07:54:59 --> Helper loaded: url_helper
INFO - 2016-09-08 07:54:59 --> Database Driver Class Initialized
INFO - 2016-09-08 07:54:59 --> Controller Class Initialized
DEBUG - 2016-09-08 07:54:59 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:54:59 --> Model Class Initialized
INFO - 2016-09-08 07:54:59 --> Model Class Initialized
DEBUG - 2016-09-08 07:54:59 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:54:59 --> Final output sent to browser
DEBUG - 2016-09-08 07:54:59 --> Total execution time: 0.6137
INFO - 2016-09-08 07:55:01 --> Config Class Initialized
INFO - 2016-09-08 07:55:01 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:55:01 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:55:01 --> Utf8 Class Initialized
INFO - 2016-09-08 07:55:01 --> URI Class Initialized
INFO - 2016-09-08 07:55:01 --> Router Class Initialized
INFO - 2016-09-08 07:55:01 --> Output Class Initialized
INFO - 2016-09-08 07:55:01 --> Security Class Initialized
DEBUG - 2016-09-08 07:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:55:01 --> Input Class Initialized
INFO - 2016-09-08 07:55:01 --> Language Class Initialized
INFO - 2016-09-08 07:55:01 --> Language Class Initialized
INFO - 2016-09-08 07:55:01 --> Config Class Initialized
INFO - 2016-09-08 07:55:01 --> Loader Class Initialized
INFO - 2016-09-08 07:55:01 --> Helper loaded: url_helper
INFO - 2016-09-08 07:55:01 --> Database Driver Class Initialized
INFO - 2016-09-08 07:55:01 --> Controller Class Initialized
DEBUG - 2016-09-08 07:55:01 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:55:01 --> Model Class Initialized
INFO - 2016-09-08 07:55:01 --> Model Class Initialized
DEBUG - 2016-09-08 07:55:01 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:55:01 --> Final output sent to browser
DEBUG - 2016-09-08 07:55:01 --> Total execution time: 0.5964
INFO - 2016-09-08 07:55:04 --> Config Class Initialized
INFO - 2016-09-08 07:55:04 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:55:04 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:55:04 --> Utf8 Class Initialized
INFO - 2016-09-08 07:55:04 --> URI Class Initialized
INFO - 2016-09-08 07:55:04 --> Router Class Initialized
INFO - 2016-09-08 07:55:04 --> Output Class Initialized
INFO - 2016-09-08 07:55:04 --> Security Class Initialized
DEBUG - 2016-09-08 07:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:55:04 --> Input Class Initialized
INFO - 2016-09-08 07:55:04 --> Language Class Initialized
INFO - 2016-09-08 07:55:04 --> Language Class Initialized
INFO - 2016-09-08 07:55:04 --> Config Class Initialized
INFO - 2016-09-08 07:55:04 --> Loader Class Initialized
INFO - 2016-09-08 07:55:04 --> Helper loaded: url_helper
INFO - 2016-09-08 07:55:04 --> Database Driver Class Initialized
INFO - 2016-09-08 07:55:04 --> Controller Class Initialized
DEBUG - 2016-09-08 07:55:04 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:55:04 --> Model Class Initialized
INFO - 2016-09-08 07:55:04 --> Model Class Initialized
DEBUG - 2016-09-08 07:55:04 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:55:04 --> Final output sent to browser
DEBUG - 2016-09-08 07:55:04 --> Total execution time: 0.6310
INFO - 2016-09-08 07:55:07 --> Config Class Initialized
INFO - 2016-09-08 07:55:07 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:55:07 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:55:07 --> Utf8 Class Initialized
INFO - 2016-09-08 07:55:07 --> URI Class Initialized
INFO - 2016-09-08 07:55:07 --> Router Class Initialized
INFO - 2016-09-08 07:55:07 --> Output Class Initialized
INFO - 2016-09-08 07:55:07 --> Security Class Initialized
DEBUG - 2016-09-08 07:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:55:07 --> Input Class Initialized
INFO - 2016-09-08 07:55:07 --> Language Class Initialized
INFO - 2016-09-08 07:55:07 --> Language Class Initialized
INFO - 2016-09-08 07:55:07 --> Config Class Initialized
INFO - 2016-09-08 07:55:07 --> Loader Class Initialized
INFO - 2016-09-08 07:55:07 --> Helper loaded: url_helper
INFO - 2016-09-08 07:55:07 --> Database Driver Class Initialized
INFO - 2016-09-08 07:55:07 --> Controller Class Initialized
DEBUG - 2016-09-08 07:55:07 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:55:07 --> Model Class Initialized
INFO - 2016-09-08 07:55:07 --> Model Class Initialized
DEBUG - 2016-09-08 07:55:07 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:55:07 --> Final output sent to browser
DEBUG - 2016-09-08 07:55:07 --> Total execution time: 0.6154
INFO - 2016-09-08 07:55:14 --> Config Class Initialized
INFO - 2016-09-08 07:55:14 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:55:14 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:55:14 --> Utf8 Class Initialized
INFO - 2016-09-08 07:55:14 --> URI Class Initialized
INFO - 2016-09-08 07:55:14 --> Router Class Initialized
INFO - 2016-09-08 07:55:14 --> Output Class Initialized
INFO - 2016-09-08 07:55:14 --> Security Class Initialized
DEBUG - 2016-09-08 07:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:55:14 --> Input Class Initialized
INFO - 2016-09-08 07:55:14 --> Language Class Initialized
INFO - 2016-09-08 07:55:14 --> Language Class Initialized
INFO - 2016-09-08 07:55:14 --> Config Class Initialized
INFO - 2016-09-08 07:55:14 --> Loader Class Initialized
INFO - 2016-09-08 07:55:14 --> Helper loaded: url_helper
INFO - 2016-09-08 07:55:14 --> Database Driver Class Initialized
INFO - 2016-09-08 07:55:14 --> Controller Class Initialized
DEBUG - 2016-09-08 07:55:14 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:55:14 --> Model Class Initialized
INFO - 2016-09-08 07:55:14 --> Model Class Initialized
DEBUG - 2016-09-08 07:55:14 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:55:14 --> Final output sent to browser
DEBUG - 2016-09-08 07:55:14 --> Total execution time: 0.6051
INFO - 2016-09-08 07:55:17 --> Config Class Initialized
INFO - 2016-09-08 07:55:17 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:55:17 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:55:17 --> Utf8 Class Initialized
INFO - 2016-09-08 07:55:17 --> URI Class Initialized
INFO - 2016-09-08 07:55:17 --> Router Class Initialized
INFO - 2016-09-08 07:55:17 --> Output Class Initialized
INFO - 2016-09-08 07:55:17 --> Security Class Initialized
DEBUG - 2016-09-08 07:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:55:17 --> Input Class Initialized
INFO - 2016-09-08 07:55:17 --> Language Class Initialized
INFO - 2016-09-08 07:55:17 --> Language Class Initialized
INFO - 2016-09-08 07:55:17 --> Config Class Initialized
INFO - 2016-09-08 07:55:17 --> Loader Class Initialized
INFO - 2016-09-08 07:55:17 --> Helper loaded: url_helper
INFO - 2016-09-08 07:55:17 --> Database Driver Class Initialized
INFO - 2016-09-08 07:55:17 --> Controller Class Initialized
DEBUG - 2016-09-08 07:55:17 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:55:17 --> Model Class Initialized
INFO - 2016-09-08 07:55:17 --> Model Class Initialized
DEBUG - 2016-09-08 07:55:17 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:55:17 --> Final output sent to browser
DEBUG - 2016-09-08 07:55:17 --> Total execution time: 0.5458
INFO - 2016-09-08 07:55:20 --> Config Class Initialized
INFO - 2016-09-08 07:55:20 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:55:20 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:55:20 --> Utf8 Class Initialized
INFO - 2016-09-08 07:55:20 --> URI Class Initialized
INFO - 2016-09-08 07:55:20 --> Router Class Initialized
INFO - 2016-09-08 07:55:20 --> Output Class Initialized
INFO - 2016-09-08 07:55:20 --> Security Class Initialized
DEBUG - 2016-09-08 07:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:55:20 --> Input Class Initialized
INFO - 2016-09-08 07:55:20 --> Language Class Initialized
INFO - 2016-09-08 07:55:20 --> Language Class Initialized
INFO - 2016-09-08 07:55:20 --> Config Class Initialized
INFO - 2016-09-08 07:55:20 --> Loader Class Initialized
INFO - 2016-09-08 07:55:21 --> Helper loaded: url_helper
INFO - 2016-09-08 07:55:21 --> Database Driver Class Initialized
INFO - 2016-09-08 07:55:21 --> Controller Class Initialized
DEBUG - 2016-09-08 07:55:21 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:55:21 --> Model Class Initialized
INFO - 2016-09-08 07:55:21 --> Model Class Initialized
DEBUG - 2016-09-08 07:55:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 07:55:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 07:55:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 07:55:21 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 07:55:21 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 07:55:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 07:55:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 07:55:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 07:55:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 07:55:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 07:55:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 07:55:21 --> Final output sent to browser
DEBUG - 2016-09-08 07:55:21 --> Total execution time: 0.9495
INFO - 2016-09-08 07:55:28 --> Config Class Initialized
INFO - 2016-09-08 07:55:28 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:55:28 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:55:29 --> Utf8 Class Initialized
INFO - 2016-09-08 07:55:29 --> URI Class Initialized
INFO - 2016-09-08 07:55:29 --> Router Class Initialized
INFO - 2016-09-08 07:55:29 --> Output Class Initialized
INFO - 2016-09-08 07:55:29 --> Security Class Initialized
DEBUG - 2016-09-08 07:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:55:29 --> Input Class Initialized
INFO - 2016-09-08 07:55:29 --> Language Class Initialized
INFO - 2016-09-08 07:55:29 --> Language Class Initialized
INFO - 2016-09-08 07:55:29 --> Config Class Initialized
INFO - 2016-09-08 07:55:29 --> Loader Class Initialized
INFO - 2016-09-08 07:55:29 --> Helper loaded: url_helper
INFO - 2016-09-08 07:55:29 --> Database Driver Class Initialized
INFO - 2016-09-08 07:55:29 --> Controller Class Initialized
DEBUG - 2016-09-08 07:55:29 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:55:29 --> Model Class Initialized
INFO - 2016-09-08 07:55:29 --> Model Class Initialized
DEBUG - 2016-09-08 07:55:29 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:55:29 --> Final output sent to browser
DEBUG - 2016-09-08 07:55:29 --> Total execution time: 0.6036
INFO - 2016-09-08 07:55:32 --> Config Class Initialized
INFO - 2016-09-08 07:55:32 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:55:32 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:55:32 --> Utf8 Class Initialized
INFO - 2016-09-08 07:55:32 --> URI Class Initialized
INFO - 2016-09-08 07:55:32 --> Router Class Initialized
INFO - 2016-09-08 07:55:32 --> Output Class Initialized
INFO - 2016-09-08 07:55:32 --> Security Class Initialized
DEBUG - 2016-09-08 07:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:55:32 --> Input Class Initialized
INFO - 2016-09-08 07:55:32 --> Language Class Initialized
INFO - 2016-09-08 07:55:32 --> Language Class Initialized
INFO - 2016-09-08 07:55:32 --> Config Class Initialized
INFO - 2016-09-08 07:55:32 --> Loader Class Initialized
INFO - 2016-09-08 07:55:32 --> Helper loaded: url_helper
INFO - 2016-09-08 07:55:32 --> Database Driver Class Initialized
INFO - 2016-09-08 07:55:32 --> Controller Class Initialized
DEBUG - 2016-09-08 07:55:32 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:55:32 --> Model Class Initialized
INFO - 2016-09-08 07:55:32 --> Model Class Initialized
DEBUG - 2016-09-08 07:55:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 07:55:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 07:55:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 07:55:32 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 07:55:32 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 07:55:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 07:55:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 07:55:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 07:55:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 07:55:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 07:55:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 07:55:33 --> Final output sent to browser
DEBUG - 2016-09-08 07:55:33 --> Total execution time: 0.9750
INFO - 2016-09-08 07:55:37 --> Config Class Initialized
INFO - 2016-09-08 07:55:37 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:55:37 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:55:38 --> Utf8 Class Initialized
INFO - 2016-09-08 07:55:38 --> URI Class Initialized
INFO - 2016-09-08 07:55:38 --> Router Class Initialized
INFO - 2016-09-08 07:55:38 --> Output Class Initialized
INFO - 2016-09-08 07:55:38 --> Security Class Initialized
DEBUG - 2016-09-08 07:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:55:38 --> Input Class Initialized
INFO - 2016-09-08 07:55:38 --> Language Class Initialized
INFO - 2016-09-08 07:55:38 --> Language Class Initialized
INFO - 2016-09-08 07:55:38 --> Config Class Initialized
INFO - 2016-09-08 07:55:38 --> Loader Class Initialized
INFO - 2016-09-08 07:55:38 --> Helper loaded: url_helper
INFO - 2016-09-08 07:55:38 --> Database Driver Class Initialized
INFO - 2016-09-08 07:55:38 --> Controller Class Initialized
DEBUG - 2016-09-08 07:55:38 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:55:38 --> Model Class Initialized
INFO - 2016-09-08 07:55:38 --> Model Class Initialized
DEBUG - 2016-09-08 07:55:38 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:55:38 --> Final output sent to browser
DEBUG - 2016-09-08 07:55:38 --> Total execution time: 0.6293
INFO - 2016-09-08 07:55:45 --> Config Class Initialized
INFO - 2016-09-08 07:55:45 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:55:45 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:55:45 --> Utf8 Class Initialized
INFO - 2016-09-08 07:55:45 --> URI Class Initialized
INFO - 2016-09-08 07:55:46 --> Router Class Initialized
INFO - 2016-09-08 07:55:46 --> Output Class Initialized
INFO - 2016-09-08 07:55:46 --> Security Class Initialized
DEBUG - 2016-09-08 07:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:55:46 --> Input Class Initialized
INFO - 2016-09-08 07:55:46 --> Language Class Initialized
INFO - 2016-09-08 07:55:46 --> Language Class Initialized
INFO - 2016-09-08 07:55:46 --> Config Class Initialized
INFO - 2016-09-08 07:55:46 --> Loader Class Initialized
INFO - 2016-09-08 07:55:46 --> Helper loaded: url_helper
INFO - 2016-09-08 07:55:46 --> Database Driver Class Initialized
INFO - 2016-09-08 07:55:46 --> Controller Class Initialized
DEBUG - 2016-09-08 07:55:46 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:55:46 --> Model Class Initialized
INFO - 2016-09-08 07:55:46 --> Model Class Initialized
DEBUG - 2016-09-08 07:55:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 07:55:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 07:55:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 07:55:46 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 07:55:46 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 07:55:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 07:55:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 07:55:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 07:55:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 07:55:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 07:55:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 07:55:46 --> Final output sent to browser
DEBUG - 2016-09-08 07:55:46 --> Total execution time: 0.9462
INFO - 2016-09-08 07:55:53 --> Config Class Initialized
INFO - 2016-09-08 07:55:54 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:55:54 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:55:54 --> Utf8 Class Initialized
INFO - 2016-09-08 07:55:54 --> URI Class Initialized
INFO - 2016-09-08 07:55:54 --> Router Class Initialized
INFO - 2016-09-08 07:55:54 --> Output Class Initialized
INFO - 2016-09-08 07:55:54 --> Security Class Initialized
DEBUG - 2016-09-08 07:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:55:54 --> Input Class Initialized
INFO - 2016-09-08 07:55:54 --> Language Class Initialized
INFO - 2016-09-08 07:55:54 --> Language Class Initialized
INFO - 2016-09-08 07:55:54 --> Config Class Initialized
INFO - 2016-09-08 07:55:54 --> Loader Class Initialized
INFO - 2016-09-08 07:55:54 --> Helper loaded: url_helper
INFO - 2016-09-08 07:55:54 --> Database Driver Class Initialized
INFO - 2016-09-08 07:55:54 --> Controller Class Initialized
DEBUG - 2016-09-08 07:55:54 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:55:54 --> Model Class Initialized
INFO - 2016-09-08 07:55:54 --> Model Class Initialized
DEBUG - 2016-09-08 07:55:54 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:55:54 --> Final output sent to browser
DEBUG - 2016-09-08 07:55:54 --> Total execution time: 0.6383
INFO - 2016-09-08 07:56:01 --> Config Class Initialized
INFO - 2016-09-08 07:56:01 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:56:01 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:56:01 --> Utf8 Class Initialized
INFO - 2016-09-08 07:56:01 --> URI Class Initialized
INFO - 2016-09-08 07:56:01 --> Router Class Initialized
INFO - 2016-09-08 07:56:01 --> Output Class Initialized
INFO - 2016-09-08 07:56:01 --> Security Class Initialized
DEBUG - 2016-09-08 07:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:56:01 --> Input Class Initialized
INFO - 2016-09-08 07:56:01 --> Language Class Initialized
INFO - 2016-09-08 07:56:01 --> Language Class Initialized
INFO - 2016-09-08 07:56:01 --> Config Class Initialized
INFO - 2016-09-08 07:56:01 --> Loader Class Initialized
INFO - 2016-09-08 07:56:01 --> Helper loaded: url_helper
INFO - 2016-09-08 07:56:02 --> Database Driver Class Initialized
INFO - 2016-09-08 07:56:02 --> Controller Class Initialized
DEBUG - 2016-09-08 07:56:02 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:56:02 --> Model Class Initialized
INFO - 2016-09-08 07:56:02 --> Model Class Initialized
DEBUG - 2016-09-08 07:56:02 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:56:02 --> Final output sent to browser
DEBUG - 2016-09-08 07:56:02 --> Total execution time: 0.5631
INFO - 2016-09-08 07:56:04 --> Config Class Initialized
INFO - 2016-09-08 07:56:04 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:56:04 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:56:04 --> Utf8 Class Initialized
INFO - 2016-09-08 07:56:04 --> URI Class Initialized
INFO - 2016-09-08 07:56:04 --> Router Class Initialized
INFO - 2016-09-08 07:56:04 --> Output Class Initialized
INFO - 2016-09-08 07:56:04 --> Security Class Initialized
DEBUG - 2016-09-08 07:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:56:04 --> Input Class Initialized
INFO - 2016-09-08 07:56:04 --> Language Class Initialized
INFO - 2016-09-08 07:56:04 --> Language Class Initialized
INFO - 2016-09-08 07:56:04 --> Config Class Initialized
INFO - 2016-09-08 07:56:04 --> Loader Class Initialized
INFO - 2016-09-08 07:56:04 --> Helper loaded: url_helper
INFO - 2016-09-08 07:56:04 --> Database Driver Class Initialized
INFO - 2016-09-08 07:56:04 --> Controller Class Initialized
DEBUG - 2016-09-08 07:56:04 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:56:04 --> Model Class Initialized
INFO - 2016-09-08 07:56:04 --> Model Class Initialized
DEBUG - 2016-09-08 07:56:05 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:56:05 --> Final output sent to browser
DEBUG - 2016-09-08 07:56:05 --> Total execution time: 0.6277
INFO - 2016-09-08 07:56:08 --> Config Class Initialized
INFO - 2016-09-08 07:56:08 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:56:08 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:56:08 --> Utf8 Class Initialized
INFO - 2016-09-08 07:56:08 --> URI Class Initialized
INFO - 2016-09-08 07:56:08 --> Router Class Initialized
INFO - 2016-09-08 07:56:08 --> Output Class Initialized
INFO - 2016-09-08 07:56:08 --> Security Class Initialized
DEBUG - 2016-09-08 07:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:56:08 --> Input Class Initialized
INFO - 2016-09-08 07:56:08 --> Language Class Initialized
INFO - 2016-09-08 07:56:08 --> Language Class Initialized
INFO - 2016-09-08 07:56:08 --> Config Class Initialized
INFO - 2016-09-08 07:56:08 --> Loader Class Initialized
INFO - 2016-09-08 07:56:08 --> Helper loaded: url_helper
INFO - 2016-09-08 07:56:08 --> Database Driver Class Initialized
INFO - 2016-09-08 07:56:08 --> Controller Class Initialized
DEBUG - 2016-09-08 07:56:08 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:56:09 --> Model Class Initialized
INFO - 2016-09-08 07:56:09 --> Model Class Initialized
DEBUG - 2016-09-08 07:56:09 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:56:09 --> Final output sent to browser
DEBUG - 2016-09-08 07:56:09 --> Total execution time: 0.5673
INFO - 2016-09-08 07:56:12 --> Config Class Initialized
INFO - 2016-09-08 07:56:12 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:56:12 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:56:12 --> Utf8 Class Initialized
INFO - 2016-09-08 07:56:12 --> URI Class Initialized
INFO - 2016-09-08 07:56:12 --> Router Class Initialized
INFO - 2016-09-08 07:56:12 --> Output Class Initialized
INFO - 2016-09-08 07:56:12 --> Security Class Initialized
DEBUG - 2016-09-08 07:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:56:12 --> Input Class Initialized
INFO - 2016-09-08 07:56:12 --> Language Class Initialized
INFO - 2016-09-08 07:56:12 --> Language Class Initialized
INFO - 2016-09-08 07:56:12 --> Config Class Initialized
INFO - 2016-09-08 07:56:12 --> Loader Class Initialized
INFO - 2016-09-08 07:56:12 --> Helper loaded: url_helper
INFO - 2016-09-08 07:56:12 --> Database Driver Class Initialized
INFO - 2016-09-08 07:56:12 --> Controller Class Initialized
DEBUG - 2016-09-08 07:56:12 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:56:12 --> Model Class Initialized
INFO - 2016-09-08 07:56:12 --> Model Class Initialized
DEBUG - 2016-09-08 07:56:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 07:56:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 07:56:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 07:56:12 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 07:56:12 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 07:56:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 07:56:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 07:56:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 07:56:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 07:56:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 07:56:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 07:56:13 --> Final output sent to browser
DEBUG - 2016-09-08 07:56:13 --> Total execution time: 0.9731
INFO - 2016-09-08 07:56:22 --> Config Class Initialized
INFO - 2016-09-08 07:56:22 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:56:22 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:56:22 --> Utf8 Class Initialized
INFO - 2016-09-08 07:56:22 --> URI Class Initialized
INFO - 2016-09-08 07:56:22 --> Router Class Initialized
INFO - 2016-09-08 07:56:22 --> Output Class Initialized
INFO - 2016-09-08 07:56:22 --> Security Class Initialized
DEBUG - 2016-09-08 07:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:56:22 --> Input Class Initialized
INFO - 2016-09-08 07:56:22 --> Language Class Initialized
INFO - 2016-09-08 07:56:22 --> Language Class Initialized
INFO - 2016-09-08 07:56:22 --> Config Class Initialized
INFO - 2016-09-08 07:56:22 --> Loader Class Initialized
INFO - 2016-09-08 07:56:22 --> Helper loaded: url_helper
INFO - 2016-09-08 07:56:22 --> Database Driver Class Initialized
INFO - 2016-09-08 07:56:22 --> Controller Class Initialized
DEBUG - 2016-09-08 07:56:22 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:56:23 --> Model Class Initialized
INFO - 2016-09-08 07:56:23 --> Model Class Initialized
DEBUG - 2016-09-08 07:56:23 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:56:23 --> Final output sent to browser
DEBUG - 2016-09-08 07:56:23 --> Total execution time: 0.8056
INFO - 2016-09-08 07:56:25 --> Config Class Initialized
INFO - 2016-09-08 07:56:25 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:56:25 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:56:25 --> Utf8 Class Initialized
INFO - 2016-09-08 07:56:25 --> URI Class Initialized
INFO - 2016-09-08 07:56:25 --> Router Class Initialized
INFO - 2016-09-08 07:56:25 --> Output Class Initialized
INFO - 2016-09-08 07:56:25 --> Security Class Initialized
DEBUG - 2016-09-08 07:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:56:25 --> Input Class Initialized
INFO - 2016-09-08 07:56:25 --> Language Class Initialized
INFO - 2016-09-08 07:56:25 --> Language Class Initialized
INFO - 2016-09-08 07:56:25 --> Config Class Initialized
INFO - 2016-09-08 07:56:25 --> Loader Class Initialized
INFO - 2016-09-08 07:56:25 --> Helper loaded: url_helper
INFO - 2016-09-08 07:56:25 --> Database Driver Class Initialized
INFO - 2016-09-08 07:56:25 --> Controller Class Initialized
DEBUG - 2016-09-08 07:56:25 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:56:25 --> Model Class Initialized
INFO - 2016-09-08 07:56:25 --> Model Class Initialized
DEBUG - 2016-09-08 07:56:25 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:56:26 --> Final output sent to browser
DEBUG - 2016-09-08 07:56:26 --> Total execution time: 0.6473
INFO - 2016-09-08 07:56:28 --> Config Class Initialized
INFO - 2016-09-08 07:56:28 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:56:28 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:56:28 --> Utf8 Class Initialized
INFO - 2016-09-08 07:56:28 --> URI Class Initialized
INFO - 2016-09-08 07:56:28 --> Router Class Initialized
INFO - 2016-09-08 07:56:28 --> Output Class Initialized
INFO - 2016-09-08 07:56:28 --> Security Class Initialized
DEBUG - 2016-09-08 07:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:56:28 --> Input Class Initialized
INFO - 2016-09-08 07:56:28 --> Language Class Initialized
INFO - 2016-09-08 07:56:28 --> Language Class Initialized
INFO - 2016-09-08 07:56:28 --> Config Class Initialized
INFO - 2016-09-08 07:56:28 --> Loader Class Initialized
INFO - 2016-09-08 07:56:28 --> Helper loaded: url_helper
INFO - 2016-09-08 07:56:28 --> Database Driver Class Initialized
INFO - 2016-09-08 07:56:28 --> Controller Class Initialized
DEBUG - 2016-09-08 07:56:28 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:56:28 --> Model Class Initialized
INFO - 2016-09-08 07:56:28 --> Model Class Initialized
DEBUG - 2016-09-08 07:56:28 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 07:56:28 --> Final output sent to browser
DEBUG - 2016-09-08 07:56:28 --> Total execution time: 0.5740
INFO - 2016-09-08 07:56:32 --> Config Class Initialized
INFO - 2016-09-08 07:56:32 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:56:32 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:56:32 --> Utf8 Class Initialized
INFO - 2016-09-08 07:56:32 --> URI Class Initialized
INFO - 2016-09-08 07:56:32 --> Router Class Initialized
INFO - 2016-09-08 07:56:32 --> Output Class Initialized
INFO - 2016-09-08 07:56:32 --> Security Class Initialized
DEBUG - 2016-09-08 07:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:56:32 --> Input Class Initialized
INFO - 2016-09-08 07:56:32 --> Language Class Initialized
INFO - 2016-09-08 07:56:32 --> Language Class Initialized
INFO - 2016-09-08 07:56:32 --> Config Class Initialized
INFO - 2016-09-08 07:56:32 --> Loader Class Initialized
INFO - 2016-09-08 07:56:32 --> Helper loaded: url_helper
INFO - 2016-09-08 07:56:32 --> Database Driver Class Initialized
INFO - 2016-09-08 07:56:32 --> Controller Class Initialized
DEBUG - 2016-09-08 07:56:32 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:56:32 --> Model Class Initialized
INFO - 2016-09-08 07:56:32 --> Model Class Initialized
DEBUG - 2016-09-08 07:56:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 07:56:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 07:56:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 07:56:32 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 07:56:32 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 07:56:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 07:56:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 07:56:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 07:56:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 07:56:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 07:56:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 07:56:33 --> Final output sent to browser
DEBUG - 2016-09-08 07:56:33 --> Total execution time: 1.0182
INFO - 2016-09-08 07:57:41 --> Config Class Initialized
INFO - 2016-09-08 07:57:41 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:57:41 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:57:41 --> Utf8 Class Initialized
INFO - 2016-09-08 07:57:41 --> URI Class Initialized
INFO - 2016-09-08 07:57:41 --> Router Class Initialized
INFO - 2016-09-08 07:57:41 --> Output Class Initialized
INFO - 2016-09-08 07:57:41 --> Security Class Initialized
DEBUG - 2016-09-08 07:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:57:41 --> Input Class Initialized
INFO - 2016-09-08 07:57:41 --> Language Class Initialized
INFO - 2016-09-08 07:57:41 --> Language Class Initialized
INFO - 2016-09-08 07:57:41 --> Config Class Initialized
INFO - 2016-09-08 07:57:41 --> Loader Class Initialized
INFO - 2016-09-08 07:57:41 --> Helper loaded: url_helper
INFO - 2016-09-08 07:57:41 --> Database Driver Class Initialized
INFO - 2016-09-08 07:57:41 --> Controller Class Initialized
DEBUG - 2016-09-08 07:57:41 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:57:41 --> Model Class Initialized
INFO - 2016-09-08 07:57:41 --> Model Class Initialized
DEBUG - 2016-09-08 07:57:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 07:57:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 07:57:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 07:57:41 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 07:57:41 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 07:57:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 07:57:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 07:57:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 07:57:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 07:57:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 07:57:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 07:57:41 --> Final output sent to browser
DEBUG - 2016-09-08 07:57:42 --> Total execution time: 0.9175
INFO - 2016-09-08 07:58:14 --> Config Class Initialized
INFO - 2016-09-08 07:58:14 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:58:14 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:58:14 --> Utf8 Class Initialized
INFO - 2016-09-08 07:58:14 --> URI Class Initialized
INFO - 2016-09-08 07:58:14 --> Router Class Initialized
INFO - 2016-09-08 07:58:14 --> Output Class Initialized
INFO - 2016-09-08 07:58:14 --> Security Class Initialized
DEBUG - 2016-09-08 07:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:58:14 --> Input Class Initialized
INFO - 2016-09-08 07:58:14 --> Language Class Initialized
INFO - 2016-09-08 07:58:14 --> Language Class Initialized
INFO - 2016-09-08 07:58:14 --> Config Class Initialized
INFO - 2016-09-08 07:58:14 --> Loader Class Initialized
INFO - 2016-09-08 07:58:14 --> Helper loaded: url_helper
INFO - 2016-09-08 07:58:14 --> Database Driver Class Initialized
INFO - 2016-09-08 07:58:14 --> Controller Class Initialized
DEBUG - 2016-09-08 07:58:14 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:58:14 --> Model Class Initialized
INFO - 2016-09-08 07:58:14 --> Model Class Initialized
DEBUG - 2016-09-08 07:58:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 07:58:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 07:58:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 07:58:14 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 07:58:14 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 07:58:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 07:58:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 07:58:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 07:58:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 07:58:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 07:58:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 07:58:15 --> Final output sent to browser
DEBUG - 2016-09-08 07:58:15 --> Total execution time: 0.9292
INFO - 2016-09-08 07:58:39 --> Config Class Initialized
INFO - 2016-09-08 07:58:39 --> Hooks Class Initialized
DEBUG - 2016-09-08 07:58:39 --> UTF-8 Support Enabled
INFO - 2016-09-08 07:58:39 --> Utf8 Class Initialized
INFO - 2016-09-08 07:58:39 --> URI Class Initialized
INFO - 2016-09-08 07:58:39 --> Router Class Initialized
INFO - 2016-09-08 07:58:39 --> Output Class Initialized
INFO - 2016-09-08 07:58:39 --> Security Class Initialized
DEBUG - 2016-09-08 07:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 07:58:39 --> Input Class Initialized
INFO - 2016-09-08 07:58:39 --> Language Class Initialized
INFO - 2016-09-08 07:58:39 --> Language Class Initialized
INFO - 2016-09-08 07:58:39 --> Config Class Initialized
INFO - 2016-09-08 07:58:39 --> Loader Class Initialized
INFO - 2016-09-08 07:58:39 --> Helper loaded: url_helper
INFO - 2016-09-08 07:58:39 --> Database Driver Class Initialized
INFO - 2016-09-08 07:58:39 --> Controller Class Initialized
DEBUG - 2016-09-08 07:58:39 --> Index MX_Controller Initialized
INFO - 2016-09-08 07:58:39 --> Model Class Initialized
INFO - 2016-09-08 07:58:39 --> Model Class Initialized
DEBUG - 2016-09-08 07:58:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 07:58:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 07:58:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 07:58:39 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 07:58:39 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 07:58:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 07:58:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 07:58:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 07:58:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 07:58:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 07:58:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 07:58:40 --> Final output sent to browser
DEBUG - 2016-09-08 07:58:40 --> Total execution time: 0.9558
INFO - 2016-09-08 08:02:36 --> Config Class Initialized
INFO - 2016-09-08 08:02:36 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:02:36 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:02:36 --> Utf8 Class Initialized
INFO - 2016-09-08 08:02:36 --> URI Class Initialized
INFO - 2016-09-08 08:02:36 --> Router Class Initialized
INFO - 2016-09-08 08:02:36 --> Output Class Initialized
INFO - 2016-09-08 08:02:36 --> Security Class Initialized
DEBUG - 2016-09-08 08:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:02:36 --> Input Class Initialized
INFO - 2016-09-08 08:02:36 --> Language Class Initialized
INFO - 2016-09-08 08:02:36 --> Language Class Initialized
INFO - 2016-09-08 08:02:36 --> Config Class Initialized
INFO - 2016-09-08 08:02:36 --> Loader Class Initialized
INFO - 2016-09-08 08:02:36 --> Helper loaded: url_helper
INFO - 2016-09-08 08:02:37 --> Database Driver Class Initialized
INFO - 2016-09-08 08:02:37 --> Controller Class Initialized
DEBUG - 2016-09-08 08:02:37 --> Index MX_Controller Initialized
INFO - 2016-09-08 08:02:37 --> Model Class Initialized
INFO - 2016-09-08 08:02:37 --> Model Class Initialized
DEBUG - 2016-09-08 08:02:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 08:02:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 08:02:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 08:02:37 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 08:02:37 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 08:02:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 08:02:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 08:02:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 08:02:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 08:02:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 08:02:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 08:02:37 --> Final output sent to browser
DEBUG - 2016-09-08 08:02:37 --> Total execution time: 0.9238
INFO - 2016-09-08 08:03:39 --> Config Class Initialized
INFO - 2016-09-08 08:03:39 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:03:39 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:03:40 --> Utf8 Class Initialized
INFO - 2016-09-08 08:03:40 --> URI Class Initialized
INFO - 2016-09-08 08:03:40 --> Router Class Initialized
INFO - 2016-09-08 08:03:40 --> Output Class Initialized
INFO - 2016-09-08 08:03:40 --> Security Class Initialized
DEBUG - 2016-09-08 08:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:03:40 --> Input Class Initialized
INFO - 2016-09-08 08:03:40 --> Language Class Initialized
INFO - 2016-09-08 08:03:40 --> Language Class Initialized
INFO - 2016-09-08 08:03:40 --> Config Class Initialized
INFO - 2016-09-08 08:03:40 --> Loader Class Initialized
INFO - 2016-09-08 08:03:40 --> Helper loaded: url_helper
INFO - 2016-09-08 08:03:40 --> Database Driver Class Initialized
INFO - 2016-09-08 08:03:40 --> Controller Class Initialized
DEBUG - 2016-09-08 08:03:40 --> Index MX_Controller Initialized
INFO - 2016-09-08 08:03:40 --> Model Class Initialized
INFO - 2016-09-08 08:03:40 --> Model Class Initialized
DEBUG - 2016-09-08 08:03:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 08:03:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 08:03:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 08:03:40 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 08:03:40 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 08:03:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 08:03:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 08:03:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 08:03:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 08:03:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 08:03:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 08:03:40 --> Final output sent to browser
DEBUG - 2016-09-08 08:03:41 --> Total execution time: 0.9152
INFO - 2016-09-08 08:04:11 --> Config Class Initialized
INFO - 2016-09-08 08:04:11 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:04:11 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:04:11 --> Utf8 Class Initialized
INFO - 2016-09-08 08:04:11 --> URI Class Initialized
INFO - 2016-09-08 08:04:11 --> Router Class Initialized
INFO - 2016-09-08 08:04:11 --> Output Class Initialized
INFO - 2016-09-08 08:04:11 --> Security Class Initialized
DEBUG - 2016-09-08 08:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:04:11 --> Input Class Initialized
INFO - 2016-09-08 08:04:11 --> Language Class Initialized
INFO - 2016-09-08 08:04:11 --> Language Class Initialized
INFO - 2016-09-08 08:04:11 --> Config Class Initialized
INFO - 2016-09-08 08:04:11 --> Loader Class Initialized
INFO - 2016-09-08 08:04:11 --> Helper loaded: url_helper
INFO - 2016-09-08 08:04:11 --> Database Driver Class Initialized
INFO - 2016-09-08 08:04:11 --> Controller Class Initialized
DEBUG - 2016-09-08 08:04:11 --> Index MX_Controller Initialized
INFO - 2016-09-08 08:04:11 --> Model Class Initialized
INFO - 2016-09-08 08:04:11 --> Model Class Initialized
DEBUG - 2016-09-08 08:04:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 08:04:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 08:04:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 08:04:12 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 08:04:12 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 08:04:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 08:04:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 08:04:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 08:04:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 08:04:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 08:04:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 08:04:12 --> Final output sent to browser
DEBUG - 2016-09-08 08:04:12 --> Total execution time: 0.9232
INFO - 2016-09-08 08:05:22 --> Config Class Initialized
INFO - 2016-09-08 08:05:22 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:05:22 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:05:22 --> Utf8 Class Initialized
INFO - 2016-09-08 08:05:22 --> URI Class Initialized
INFO - 2016-09-08 08:05:22 --> Router Class Initialized
INFO - 2016-09-08 08:05:22 --> Output Class Initialized
INFO - 2016-09-08 08:05:22 --> Security Class Initialized
DEBUG - 2016-09-08 08:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:05:22 --> Input Class Initialized
INFO - 2016-09-08 08:05:22 --> Language Class Initialized
INFO - 2016-09-08 08:05:22 --> Language Class Initialized
INFO - 2016-09-08 08:05:22 --> Config Class Initialized
INFO - 2016-09-08 08:05:22 --> Loader Class Initialized
INFO - 2016-09-08 08:05:22 --> Helper loaded: url_helper
INFO - 2016-09-08 08:05:22 --> Database Driver Class Initialized
INFO - 2016-09-08 08:05:22 --> Controller Class Initialized
DEBUG - 2016-09-08 08:05:22 --> Index MX_Controller Initialized
INFO - 2016-09-08 08:05:22 --> Model Class Initialized
INFO - 2016-09-08 08:05:22 --> Model Class Initialized
DEBUG - 2016-09-08 08:05:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 08:05:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 08:05:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 08:05:22 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 08:05:22 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 08:05:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 08:05:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 08:05:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 08:05:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 08:05:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 08:05:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 08:05:23 --> Final output sent to browser
DEBUG - 2016-09-08 08:05:23 --> Total execution time: 1.0205
INFO - 2016-09-08 08:06:35 --> Config Class Initialized
INFO - 2016-09-08 08:06:35 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:06:35 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:06:35 --> Utf8 Class Initialized
INFO - 2016-09-08 08:06:35 --> URI Class Initialized
INFO - 2016-09-08 08:06:35 --> Router Class Initialized
INFO - 2016-09-08 08:06:35 --> Output Class Initialized
INFO - 2016-09-08 08:06:35 --> Security Class Initialized
DEBUG - 2016-09-08 08:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:06:35 --> Input Class Initialized
INFO - 2016-09-08 08:06:35 --> Language Class Initialized
INFO - 2016-09-08 08:06:35 --> Language Class Initialized
INFO - 2016-09-08 08:06:36 --> Config Class Initialized
INFO - 2016-09-08 08:06:36 --> Loader Class Initialized
INFO - 2016-09-08 08:06:36 --> Helper loaded: url_helper
INFO - 2016-09-08 08:06:36 --> Database Driver Class Initialized
INFO - 2016-09-08 08:06:36 --> Controller Class Initialized
DEBUG - 2016-09-08 08:06:36 --> Index MX_Controller Initialized
INFO - 2016-09-08 08:06:36 --> Model Class Initialized
INFO - 2016-09-08 08:06:36 --> Model Class Initialized
DEBUG - 2016-09-08 08:06:36 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 08:06:36 --> Final output sent to browser
DEBUG - 2016-09-08 08:06:36 --> Total execution time: 0.7313
INFO - 2016-09-08 08:06:41 --> Config Class Initialized
INFO - 2016-09-08 08:06:41 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:06:41 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:06:41 --> Utf8 Class Initialized
INFO - 2016-09-08 08:06:41 --> URI Class Initialized
INFO - 2016-09-08 08:06:41 --> Router Class Initialized
INFO - 2016-09-08 08:06:41 --> Output Class Initialized
INFO - 2016-09-08 08:06:41 --> Security Class Initialized
DEBUG - 2016-09-08 08:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:06:41 --> Input Class Initialized
INFO - 2016-09-08 08:06:41 --> Language Class Initialized
INFO - 2016-09-08 08:06:41 --> Language Class Initialized
INFO - 2016-09-08 08:06:41 --> Config Class Initialized
INFO - 2016-09-08 08:06:41 --> Loader Class Initialized
INFO - 2016-09-08 08:06:41 --> Helper loaded: url_helper
INFO - 2016-09-08 08:06:41 --> Database Driver Class Initialized
INFO - 2016-09-08 08:06:41 --> Controller Class Initialized
DEBUG - 2016-09-08 08:06:41 --> Index MX_Controller Initialized
INFO - 2016-09-08 08:06:41 --> Model Class Initialized
INFO - 2016-09-08 08:06:41 --> Model Class Initialized
DEBUG - 2016-09-08 08:06:41 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 08:06:41 --> Final output sent to browser
DEBUG - 2016-09-08 08:06:41 --> Total execution time: 0.7792
INFO - 2016-09-08 08:06:44 --> Config Class Initialized
INFO - 2016-09-08 08:06:44 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:06:44 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:06:44 --> Utf8 Class Initialized
INFO - 2016-09-08 08:06:44 --> URI Class Initialized
INFO - 2016-09-08 08:06:44 --> Router Class Initialized
INFO - 2016-09-08 08:06:44 --> Output Class Initialized
INFO - 2016-09-08 08:06:44 --> Security Class Initialized
DEBUG - 2016-09-08 08:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:06:44 --> Input Class Initialized
INFO - 2016-09-08 08:06:44 --> Language Class Initialized
INFO - 2016-09-08 08:06:44 --> Language Class Initialized
INFO - 2016-09-08 08:06:44 --> Config Class Initialized
INFO - 2016-09-08 08:06:44 --> Loader Class Initialized
INFO - 2016-09-08 08:06:44 --> Helper loaded: url_helper
INFO - 2016-09-08 08:06:44 --> Database Driver Class Initialized
INFO - 2016-09-08 08:06:44 --> Controller Class Initialized
DEBUG - 2016-09-08 08:06:44 --> Index MX_Controller Initialized
INFO - 2016-09-08 08:06:44 --> Model Class Initialized
INFO - 2016-09-08 08:06:44 --> Model Class Initialized
DEBUG - 2016-09-08 08:06:44 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 08:06:45 --> Final output sent to browser
DEBUG - 2016-09-08 08:06:45 --> Total execution time: 0.7303
INFO - 2016-09-08 08:06:47 --> Config Class Initialized
INFO - 2016-09-08 08:06:47 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:06:47 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:06:47 --> Utf8 Class Initialized
INFO - 2016-09-08 08:06:47 --> URI Class Initialized
INFO - 2016-09-08 08:06:47 --> Router Class Initialized
INFO - 2016-09-08 08:06:47 --> Output Class Initialized
INFO - 2016-09-08 08:06:47 --> Security Class Initialized
DEBUG - 2016-09-08 08:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:06:47 --> Input Class Initialized
INFO - 2016-09-08 08:06:47 --> Language Class Initialized
INFO - 2016-09-08 08:06:47 --> Language Class Initialized
INFO - 2016-09-08 08:06:47 --> Config Class Initialized
INFO - 2016-09-08 08:06:47 --> Loader Class Initialized
INFO - 2016-09-08 08:06:47 --> Helper loaded: url_helper
INFO - 2016-09-08 08:06:48 --> Database Driver Class Initialized
INFO - 2016-09-08 08:06:48 --> Controller Class Initialized
DEBUG - 2016-09-08 08:06:48 --> Index MX_Controller Initialized
INFO - 2016-09-08 08:06:48 --> Model Class Initialized
INFO - 2016-09-08 08:06:48 --> Model Class Initialized
DEBUG - 2016-09-08 08:06:48 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 08:06:48 --> Final output sent to browser
DEBUG - 2016-09-08 08:06:48 --> Total execution time: 0.6327
INFO - 2016-09-08 08:06:50 --> Config Class Initialized
INFO - 2016-09-08 08:06:50 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:06:50 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:06:50 --> Utf8 Class Initialized
INFO - 2016-09-08 08:06:50 --> URI Class Initialized
INFO - 2016-09-08 08:06:50 --> Router Class Initialized
INFO - 2016-09-08 08:06:50 --> Output Class Initialized
INFO - 2016-09-08 08:06:50 --> Security Class Initialized
DEBUG - 2016-09-08 08:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:06:50 --> Input Class Initialized
INFO - 2016-09-08 08:06:50 --> Language Class Initialized
INFO - 2016-09-08 08:06:50 --> Language Class Initialized
INFO - 2016-09-08 08:06:50 --> Config Class Initialized
INFO - 2016-09-08 08:06:50 --> Loader Class Initialized
INFO - 2016-09-08 08:06:51 --> Helper loaded: url_helper
INFO - 2016-09-08 08:06:51 --> Database Driver Class Initialized
INFO - 2016-09-08 08:06:51 --> Controller Class Initialized
DEBUG - 2016-09-08 08:06:51 --> Index MX_Controller Initialized
INFO - 2016-09-08 08:06:51 --> Model Class Initialized
INFO - 2016-09-08 08:06:51 --> Model Class Initialized
DEBUG - 2016-09-08 08:06:51 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 08:06:51 --> Final output sent to browser
DEBUG - 2016-09-08 08:06:51 --> Total execution time: 0.7309
INFO - 2016-09-08 08:06:55 --> Config Class Initialized
INFO - 2016-09-08 08:06:55 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:06:55 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:06:55 --> Utf8 Class Initialized
INFO - 2016-09-08 08:06:55 --> URI Class Initialized
INFO - 2016-09-08 08:06:55 --> Router Class Initialized
INFO - 2016-09-08 08:06:55 --> Output Class Initialized
INFO - 2016-09-08 08:06:55 --> Security Class Initialized
DEBUG - 2016-09-08 08:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:06:55 --> Input Class Initialized
INFO - 2016-09-08 08:06:55 --> Language Class Initialized
INFO - 2016-09-08 08:06:55 --> Language Class Initialized
INFO - 2016-09-08 08:06:56 --> Config Class Initialized
INFO - 2016-09-08 08:06:56 --> Loader Class Initialized
INFO - 2016-09-08 08:06:56 --> Helper loaded: url_helper
INFO - 2016-09-08 08:06:56 --> Database Driver Class Initialized
INFO - 2016-09-08 08:06:56 --> Controller Class Initialized
DEBUG - 2016-09-08 08:06:56 --> Index MX_Controller Initialized
INFO - 2016-09-08 08:06:56 --> Model Class Initialized
INFO - 2016-09-08 08:06:56 --> Model Class Initialized
DEBUG - 2016-09-08 08:06:56 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 08:06:56 --> Final output sent to browser
DEBUG - 2016-09-08 08:06:56 --> Total execution time: 0.7354
INFO - 2016-09-08 08:07:00 --> Config Class Initialized
INFO - 2016-09-08 08:07:00 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:07:00 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:07:00 --> Utf8 Class Initialized
INFO - 2016-09-08 08:07:00 --> URI Class Initialized
INFO - 2016-09-08 08:07:00 --> Router Class Initialized
INFO - 2016-09-08 08:07:00 --> Output Class Initialized
INFO - 2016-09-08 08:07:00 --> Security Class Initialized
DEBUG - 2016-09-08 08:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:07:00 --> Input Class Initialized
INFO - 2016-09-08 08:07:00 --> Language Class Initialized
INFO - 2016-09-08 08:07:00 --> Language Class Initialized
INFO - 2016-09-08 08:07:00 --> Config Class Initialized
INFO - 2016-09-08 08:07:00 --> Loader Class Initialized
INFO - 2016-09-08 08:07:00 --> Helper loaded: url_helper
INFO - 2016-09-08 08:07:00 --> Database Driver Class Initialized
INFO - 2016-09-08 08:07:00 --> Controller Class Initialized
DEBUG - 2016-09-08 08:07:00 --> Index MX_Controller Initialized
INFO - 2016-09-08 08:07:00 --> Model Class Initialized
INFO - 2016-09-08 08:07:00 --> Model Class Initialized
DEBUG - 2016-09-08 08:07:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 08:07:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 08:07:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 08:07:00 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 08:07:00 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 08:07:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 08:07:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 08:07:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 08:07:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 08:07:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 08:07:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 08:07:01 --> Final output sent to browser
DEBUG - 2016-09-08 08:07:01 --> Total execution time: 0.9323
INFO - 2016-09-08 08:07:28 --> Config Class Initialized
INFO - 2016-09-08 08:07:29 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:07:29 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:07:29 --> Utf8 Class Initialized
INFO - 2016-09-08 08:07:29 --> URI Class Initialized
INFO - 2016-09-08 08:07:29 --> Router Class Initialized
INFO - 2016-09-08 08:07:29 --> Output Class Initialized
INFO - 2016-09-08 08:07:29 --> Security Class Initialized
DEBUG - 2016-09-08 08:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:07:29 --> Input Class Initialized
INFO - 2016-09-08 08:07:29 --> Language Class Initialized
INFO - 2016-09-08 08:07:29 --> Language Class Initialized
INFO - 2016-09-08 08:07:29 --> Config Class Initialized
INFO - 2016-09-08 08:07:29 --> Loader Class Initialized
INFO - 2016-09-08 08:07:29 --> Helper loaded: url_helper
INFO - 2016-09-08 08:07:29 --> Database Driver Class Initialized
INFO - 2016-09-08 08:07:29 --> Controller Class Initialized
DEBUG - 2016-09-08 08:07:29 --> Index MX_Controller Initialized
INFO - 2016-09-08 08:07:29 --> Model Class Initialized
INFO - 2016-09-08 08:07:29 --> Model Class Initialized
DEBUG - 2016-09-08 08:07:29 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 08:07:29 --> Final output sent to browser
DEBUG - 2016-09-08 08:07:29 --> Total execution time: 0.7022
INFO - 2016-09-08 08:07:31 --> Config Class Initialized
INFO - 2016-09-08 08:07:31 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:07:31 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:07:31 --> Utf8 Class Initialized
INFO - 2016-09-08 08:07:31 --> URI Class Initialized
INFO - 2016-09-08 08:07:31 --> Router Class Initialized
INFO - 2016-09-08 08:07:31 --> Output Class Initialized
INFO - 2016-09-08 08:07:32 --> Security Class Initialized
DEBUG - 2016-09-08 08:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:07:32 --> Input Class Initialized
INFO - 2016-09-08 08:07:32 --> Language Class Initialized
INFO - 2016-09-08 08:07:32 --> Language Class Initialized
INFO - 2016-09-08 08:07:32 --> Config Class Initialized
INFO - 2016-09-08 08:07:32 --> Loader Class Initialized
INFO - 2016-09-08 08:07:32 --> Helper loaded: url_helper
INFO - 2016-09-08 08:07:32 --> Database Driver Class Initialized
INFO - 2016-09-08 08:07:32 --> Controller Class Initialized
DEBUG - 2016-09-08 08:07:32 --> Index MX_Controller Initialized
INFO - 2016-09-08 08:07:32 --> Model Class Initialized
INFO - 2016-09-08 08:07:32 --> Model Class Initialized
DEBUG - 2016-09-08 08:07:32 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 08:07:32 --> Final output sent to browser
DEBUG - 2016-09-08 08:07:32 --> Total execution time: 0.8706
INFO - 2016-09-08 08:07:34 --> Config Class Initialized
INFO - 2016-09-08 08:07:34 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:07:34 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:07:34 --> Utf8 Class Initialized
INFO - 2016-09-08 08:07:34 --> URI Class Initialized
INFO - 2016-09-08 08:07:34 --> Router Class Initialized
INFO - 2016-09-08 08:07:34 --> Output Class Initialized
INFO - 2016-09-08 08:07:34 --> Security Class Initialized
DEBUG - 2016-09-08 08:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:07:34 --> Input Class Initialized
INFO - 2016-09-08 08:07:34 --> Language Class Initialized
INFO - 2016-09-08 08:07:34 --> Language Class Initialized
INFO - 2016-09-08 08:07:34 --> Config Class Initialized
INFO - 2016-09-08 08:07:34 --> Loader Class Initialized
INFO - 2016-09-08 08:07:34 --> Helper loaded: url_helper
INFO - 2016-09-08 08:07:34 --> Database Driver Class Initialized
INFO - 2016-09-08 08:07:34 --> Controller Class Initialized
DEBUG - 2016-09-08 08:07:34 --> Index MX_Controller Initialized
INFO - 2016-09-08 08:07:35 --> Model Class Initialized
INFO - 2016-09-08 08:07:35 --> Model Class Initialized
DEBUG - 2016-09-08 08:07:35 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 08:07:35 --> Final output sent to browser
DEBUG - 2016-09-08 08:07:35 --> Total execution time: 0.7147
INFO - 2016-09-08 08:07:37 --> Config Class Initialized
INFO - 2016-09-08 08:07:37 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:07:37 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:07:37 --> Utf8 Class Initialized
INFO - 2016-09-08 08:07:37 --> URI Class Initialized
INFO - 2016-09-08 08:07:37 --> Router Class Initialized
INFO - 2016-09-08 08:07:37 --> Output Class Initialized
INFO - 2016-09-08 08:07:37 --> Security Class Initialized
DEBUG - 2016-09-08 08:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:07:37 --> Input Class Initialized
INFO - 2016-09-08 08:07:37 --> Language Class Initialized
INFO - 2016-09-08 08:07:37 --> Language Class Initialized
INFO - 2016-09-08 08:07:37 --> Config Class Initialized
INFO - 2016-09-08 08:07:37 --> Loader Class Initialized
INFO - 2016-09-08 08:07:38 --> Helper loaded: url_helper
INFO - 2016-09-08 08:07:38 --> Database Driver Class Initialized
INFO - 2016-09-08 08:07:38 --> Controller Class Initialized
DEBUG - 2016-09-08 08:07:38 --> Index MX_Controller Initialized
INFO - 2016-09-08 08:07:38 --> Model Class Initialized
INFO - 2016-09-08 08:07:38 --> Model Class Initialized
DEBUG - 2016-09-08 08:07:38 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 08:07:38 --> Final output sent to browser
DEBUG - 2016-09-08 08:07:38 --> Total execution time: 0.7936
INFO - 2016-09-08 08:07:40 --> Config Class Initialized
INFO - 2016-09-08 08:07:40 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:07:40 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:07:40 --> Utf8 Class Initialized
INFO - 2016-09-08 08:07:40 --> URI Class Initialized
INFO - 2016-09-08 08:07:40 --> Router Class Initialized
INFO - 2016-09-08 08:07:40 --> Output Class Initialized
INFO - 2016-09-08 08:07:40 --> Security Class Initialized
DEBUG - 2016-09-08 08:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:07:40 --> Input Class Initialized
INFO - 2016-09-08 08:07:40 --> Language Class Initialized
INFO - 2016-09-08 08:07:40 --> Language Class Initialized
INFO - 2016-09-08 08:07:40 --> Config Class Initialized
INFO - 2016-09-08 08:07:40 --> Loader Class Initialized
INFO - 2016-09-08 08:07:41 --> Helper loaded: url_helper
INFO - 2016-09-08 08:07:41 --> Database Driver Class Initialized
INFO - 2016-09-08 08:07:41 --> Controller Class Initialized
DEBUG - 2016-09-08 08:07:41 --> Index MX_Controller Initialized
INFO - 2016-09-08 08:07:41 --> Model Class Initialized
INFO - 2016-09-08 08:07:41 --> Model Class Initialized
DEBUG - 2016-09-08 08:07:41 --> Anggota MX_Controller Initialized
INFO - 2016-09-08 08:07:41 --> Final output sent to browser
DEBUG - 2016-09-08 08:07:41 --> Total execution time: 0.6570
INFO - 2016-09-08 08:07:49 --> Config Class Initialized
INFO - 2016-09-08 08:07:49 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:07:49 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:07:49 --> Utf8 Class Initialized
INFO - 2016-09-08 08:07:49 --> URI Class Initialized
INFO - 2016-09-08 08:07:49 --> Router Class Initialized
INFO - 2016-09-08 08:07:49 --> Output Class Initialized
INFO - 2016-09-08 08:07:49 --> Security Class Initialized
DEBUG - 2016-09-08 08:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:07:49 --> Input Class Initialized
INFO - 2016-09-08 08:07:49 --> Language Class Initialized
INFO - 2016-09-08 08:07:49 --> Language Class Initialized
INFO - 2016-09-08 08:07:49 --> Config Class Initialized
INFO - 2016-09-08 08:07:49 --> Loader Class Initialized
INFO - 2016-09-08 08:07:49 --> Helper loaded: url_helper
INFO - 2016-09-08 08:07:49 --> Database Driver Class Initialized
INFO - 2016-09-08 08:07:49 --> Controller Class Initialized
DEBUG - 2016-09-08 08:07:49 --> Index MX_Controller Initialized
INFO - 2016-09-08 08:07:49 --> Model Class Initialized
INFO - 2016-09-08 08:07:49 --> Model Class Initialized
DEBUG - 2016-09-08 08:07:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 08:07:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 08:07:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 08:07:49 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 08:07:49 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 08:07:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 08:07:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 08:07:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 08:07:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 08:07:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 08:07:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 08:07:50 --> Final output sent to browser
DEBUG - 2016-09-08 08:07:50 --> Total execution time: 0.9234
INFO - 2016-09-08 08:19:41 --> Config Class Initialized
INFO - 2016-09-08 08:19:41 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:19:42 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:19:42 --> Utf8 Class Initialized
INFO - 2016-09-08 08:19:42 --> URI Class Initialized
INFO - 2016-09-08 08:19:42 --> Router Class Initialized
INFO - 2016-09-08 08:19:42 --> Output Class Initialized
INFO - 2016-09-08 08:19:42 --> Security Class Initialized
DEBUG - 2016-09-08 08:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:19:42 --> Input Class Initialized
INFO - 2016-09-08 08:19:42 --> Language Class Initialized
ERROR - 2016-09-08 08:19:42 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:19:57 --> Config Class Initialized
INFO - 2016-09-08 08:19:57 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:19:57 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:19:57 --> Utf8 Class Initialized
INFO - 2016-09-08 08:19:57 --> URI Class Initialized
INFO - 2016-09-08 08:19:57 --> Router Class Initialized
INFO - 2016-09-08 08:19:57 --> Output Class Initialized
INFO - 2016-09-08 08:19:58 --> Security Class Initialized
DEBUG - 2016-09-08 08:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:19:58 --> Input Class Initialized
INFO - 2016-09-08 08:19:58 --> Language Class Initialized
ERROR - 2016-09-08 08:19:58 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:20:04 --> Config Class Initialized
INFO - 2016-09-08 08:20:04 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:20:04 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:20:04 --> Utf8 Class Initialized
INFO - 2016-09-08 08:20:04 --> URI Class Initialized
INFO - 2016-09-08 08:20:04 --> Router Class Initialized
INFO - 2016-09-08 08:20:04 --> Output Class Initialized
INFO - 2016-09-08 08:20:04 --> Security Class Initialized
DEBUG - 2016-09-08 08:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:20:04 --> Input Class Initialized
INFO - 2016-09-08 08:20:04 --> Language Class Initialized
ERROR - 2016-09-08 08:20:04 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:20:12 --> Config Class Initialized
INFO - 2016-09-08 08:20:12 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:20:12 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:20:12 --> Utf8 Class Initialized
INFO - 2016-09-08 08:20:12 --> URI Class Initialized
INFO - 2016-09-08 08:20:12 --> Router Class Initialized
INFO - 2016-09-08 08:20:12 --> Output Class Initialized
INFO - 2016-09-08 08:20:12 --> Security Class Initialized
DEBUG - 2016-09-08 08:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:20:12 --> Input Class Initialized
INFO - 2016-09-08 08:20:12 --> Language Class Initialized
ERROR - 2016-09-08 08:20:12 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:20:22 --> Config Class Initialized
INFO - 2016-09-08 08:20:22 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:20:22 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:20:22 --> Utf8 Class Initialized
INFO - 2016-09-08 08:20:22 --> URI Class Initialized
INFO - 2016-09-08 08:20:22 --> Router Class Initialized
INFO - 2016-09-08 08:20:22 --> Output Class Initialized
INFO - 2016-09-08 08:20:22 --> Security Class Initialized
DEBUG - 2016-09-08 08:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:20:22 --> Input Class Initialized
INFO - 2016-09-08 08:20:22 --> Language Class Initialized
ERROR - 2016-09-08 08:20:22 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:20:28 --> Config Class Initialized
INFO - 2016-09-08 08:20:28 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:20:28 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:20:28 --> Utf8 Class Initialized
INFO - 2016-09-08 08:20:28 --> URI Class Initialized
INFO - 2016-09-08 08:20:28 --> Router Class Initialized
INFO - 2016-09-08 08:20:28 --> Output Class Initialized
INFO - 2016-09-08 08:20:28 --> Security Class Initialized
DEBUG - 2016-09-08 08:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:20:28 --> Input Class Initialized
INFO - 2016-09-08 08:20:28 --> Language Class Initialized
ERROR - 2016-09-08 08:20:28 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:20:53 --> Config Class Initialized
INFO - 2016-09-08 08:20:53 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:20:53 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:20:53 --> Utf8 Class Initialized
INFO - 2016-09-08 08:20:53 --> URI Class Initialized
INFO - 2016-09-08 08:20:53 --> Router Class Initialized
INFO - 2016-09-08 08:20:53 --> Output Class Initialized
INFO - 2016-09-08 08:20:53 --> Security Class Initialized
DEBUG - 2016-09-08 08:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:20:53 --> Input Class Initialized
INFO - 2016-09-08 08:20:53 --> Language Class Initialized
ERROR - 2016-09-08 08:20:53 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:21:00 --> Config Class Initialized
INFO - 2016-09-08 08:21:00 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:21:00 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:21:00 --> Utf8 Class Initialized
INFO - 2016-09-08 08:21:00 --> URI Class Initialized
INFO - 2016-09-08 08:21:00 --> Router Class Initialized
INFO - 2016-09-08 08:21:00 --> Output Class Initialized
INFO - 2016-09-08 08:21:00 --> Security Class Initialized
DEBUG - 2016-09-08 08:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:21:00 --> Input Class Initialized
INFO - 2016-09-08 08:21:00 --> Language Class Initialized
ERROR - 2016-09-08 08:21:00 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:21:14 --> Config Class Initialized
INFO - 2016-09-08 08:21:14 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:21:14 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:21:15 --> Utf8 Class Initialized
INFO - 2016-09-08 08:21:15 --> URI Class Initialized
INFO - 2016-09-08 08:21:15 --> Router Class Initialized
INFO - 2016-09-08 08:21:15 --> Output Class Initialized
INFO - 2016-09-08 08:21:15 --> Security Class Initialized
DEBUG - 2016-09-08 08:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:21:15 --> Input Class Initialized
INFO - 2016-09-08 08:21:15 --> Language Class Initialized
ERROR - 2016-09-08 08:21:15 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:21:22 --> Config Class Initialized
INFO - 2016-09-08 08:21:22 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:21:22 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:21:22 --> Utf8 Class Initialized
INFO - 2016-09-08 08:21:22 --> URI Class Initialized
INFO - 2016-09-08 08:21:22 --> Router Class Initialized
INFO - 2016-09-08 08:21:22 --> Output Class Initialized
INFO - 2016-09-08 08:21:22 --> Security Class Initialized
DEBUG - 2016-09-08 08:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:21:22 --> Input Class Initialized
INFO - 2016-09-08 08:21:22 --> Language Class Initialized
ERROR - 2016-09-08 08:21:22 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:21:30 --> Config Class Initialized
INFO - 2016-09-08 08:21:30 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:21:30 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:21:30 --> Utf8 Class Initialized
INFO - 2016-09-08 08:21:30 --> URI Class Initialized
INFO - 2016-09-08 08:21:30 --> Router Class Initialized
INFO - 2016-09-08 08:21:30 --> Output Class Initialized
INFO - 2016-09-08 08:21:30 --> Security Class Initialized
DEBUG - 2016-09-08 08:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:21:30 --> Input Class Initialized
INFO - 2016-09-08 08:21:30 --> Language Class Initialized
ERROR - 2016-09-08 08:21:30 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:21:36 --> Config Class Initialized
INFO - 2016-09-08 08:21:36 --> Config Class Initialized
INFO - 2016-09-08 08:21:36 --> Config Class Initialized
INFO - 2016-09-08 08:21:36 --> Hooks Class Initialized
INFO - 2016-09-08 08:21:36 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:21:36 --> UTF-8 Support Enabled
DEBUG - 2016-09-08 08:21:36 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:21:36 --> Utf8 Class Initialized
INFO - 2016-09-08 08:21:36 --> Utf8 Class Initialized
INFO - 2016-09-08 08:21:36 --> Hooks Class Initialized
INFO - 2016-09-08 08:21:36 --> URI Class Initialized
INFO - 2016-09-08 08:21:36 --> URI Class Initialized
DEBUG - 2016-09-08 08:21:36 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:21:36 --> Router Class Initialized
INFO - 2016-09-08 08:21:36 --> Utf8 Class Initialized
INFO - 2016-09-08 08:21:36 --> Output Class Initialized
INFO - 2016-09-08 08:21:36 --> Router Class Initialized
INFO - 2016-09-08 08:21:36 --> URI Class Initialized
INFO - 2016-09-08 08:21:36 --> Security Class Initialized
DEBUG - 2016-09-08 08:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:21:36 --> Router Class Initialized
INFO - 2016-09-08 08:21:37 --> Input Class Initialized
INFO - 2016-09-08 08:21:37 --> Output Class Initialized
INFO - 2016-09-08 08:21:37 --> Language Class Initialized
INFO - 2016-09-08 08:21:37 --> Output Class Initialized
INFO - 2016-09-08 08:21:37 --> Security Class Initialized
DEBUG - 2016-09-08 08:21:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-09-08 08:21:37 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:21:37 --> Input Class Initialized
INFO - 2016-09-08 08:21:37 --> Language Class Initialized
INFO - 2016-09-08 08:21:37 --> Security Class Initialized
DEBUG - 2016-09-08 08:21:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-09-08 08:21:37 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:21:37 --> Input Class Initialized
INFO - 2016-09-08 08:21:37 --> Language Class Initialized
ERROR - 2016-09-08 08:21:39 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:21:43 --> Config Class Initialized
INFO - 2016-09-08 08:21:43 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:21:43 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:21:43 --> Utf8 Class Initialized
INFO - 2016-09-08 08:21:43 --> URI Class Initialized
INFO - 2016-09-08 08:21:43 --> Router Class Initialized
INFO - 2016-09-08 08:21:43 --> Output Class Initialized
INFO - 2016-09-08 08:21:43 --> Security Class Initialized
DEBUG - 2016-09-08 08:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:21:43 --> Input Class Initialized
INFO - 2016-09-08 08:21:43 --> Language Class Initialized
ERROR - 2016-09-08 08:21:43 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:21:49 --> Config Class Initialized
INFO - 2016-09-08 08:21:49 --> Config Class Initialized
INFO - 2016-09-08 08:21:49 --> Hooks Class Initialized
INFO - 2016-09-08 08:21:49 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:21:49 --> UTF-8 Support Enabled
DEBUG - 2016-09-08 08:21:49 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:21:49 --> Utf8 Class Initialized
INFO - 2016-09-08 08:21:49 --> Utf8 Class Initialized
INFO - 2016-09-08 08:21:49 --> URI Class Initialized
INFO - 2016-09-08 08:21:49 --> URI Class Initialized
INFO - 2016-09-08 08:21:49 --> Router Class Initialized
INFO - 2016-09-08 08:21:49 --> Output Class Initialized
INFO - 2016-09-08 08:21:49 --> Router Class Initialized
INFO - 2016-09-08 08:21:49 --> Security Class Initialized
INFO - 2016-09-08 08:21:49 --> Output Class Initialized
INFO - 2016-09-08 08:21:49 --> Security Class Initialized
DEBUG - 2016-09-08 08:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:21:49 --> Input Class Initialized
DEBUG - 2016-09-08 08:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:21:49 --> Input Class Initialized
INFO - 2016-09-08 08:21:49 --> Language Class Initialized
INFO - 2016-09-08 08:21:49 --> Language Class Initialized
ERROR - 2016-09-08 08:21:49 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
ERROR - 2016-09-08 08:21:49 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:21:55 --> Config Class Initialized
INFO - 2016-09-08 08:21:55 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:21:55 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:21:55 --> Utf8 Class Initialized
INFO - 2016-09-08 08:21:55 --> URI Class Initialized
INFO - 2016-09-08 08:21:55 --> Router Class Initialized
INFO - 2016-09-08 08:21:55 --> Output Class Initialized
INFO - 2016-09-08 08:21:55 --> Security Class Initialized
DEBUG - 2016-09-08 08:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:21:55 --> Input Class Initialized
INFO - 2016-09-08 08:21:55 --> Language Class Initialized
ERROR - 2016-09-08 08:21:55 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:22:37 --> Config Class Initialized
INFO - 2016-09-08 08:22:37 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:22:37 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:22:37 --> Utf8 Class Initialized
INFO - 2016-09-08 08:22:37 --> URI Class Initialized
INFO - 2016-09-08 08:22:37 --> Router Class Initialized
INFO - 2016-09-08 08:22:37 --> Output Class Initialized
INFO - 2016-09-08 08:22:37 --> Security Class Initialized
DEBUG - 2016-09-08 08:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:22:37 --> Input Class Initialized
INFO - 2016-09-08 08:22:37 --> Language Class Initialized
ERROR - 2016-09-08 08:22:37 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:22:43 --> Config Class Initialized
INFO - 2016-09-08 08:22:43 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:22:43 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:22:43 --> Utf8 Class Initialized
INFO - 2016-09-08 08:22:43 --> URI Class Initialized
INFO - 2016-09-08 08:22:43 --> Router Class Initialized
INFO - 2016-09-08 08:22:43 --> Output Class Initialized
INFO - 2016-09-08 08:22:43 --> Security Class Initialized
DEBUG - 2016-09-08 08:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:22:43 --> Input Class Initialized
INFO - 2016-09-08 08:22:43 --> Language Class Initialized
ERROR - 2016-09-08 08:22:43 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:22:51 --> Config Class Initialized
INFO - 2016-09-08 08:22:51 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:22:51 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:22:51 --> Utf8 Class Initialized
INFO - 2016-09-08 08:22:51 --> URI Class Initialized
INFO - 2016-09-08 08:22:51 --> Router Class Initialized
INFO - 2016-09-08 08:22:51 --> Output Class Initialized
INFO - 2016-09-08 08:22:51 --> Security Class Initialized
DEBUG - 2016-09-08 08:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:22:51 --> Input Class Initialized
INFO - 2016-09-08 08:22:51 --> Language Class Initialized
ERROR - 2016-09-08 08:22:51 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:22:57 --> Config Class Initialized
INFO - 2016-09-08 08:22:57 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:22:57 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:22:57 --> Utf8 Class Initialized
INFO - 2016-09-08 08:22:57 --> URI Class Initialized
INFO - 2016-09-08 08:22:57 --> Router Class Initialized
INFO - 2016-09-08 08:22:57 --> Output Class Initialized
INFO - 2016-09-08 08:22:57 --> Security Class Initialized
DEBUG - 2016-09-08 08:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:22:57 --> Input Class Initialized
INFO - 2016-09-08 08:22:57 --> Language Class Initialized
ERROR - 2016-09-08 08:22:57 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:40:02 --> Config Class Initialized
INFO - 2016-09-08 08:40:03 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:40:03 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:40:03 --> Utf8 Class Initialized
INFO - 2016-09-08 08:40:03 --> URI Class Initialized
INFO - 2016-09-08 08:40:03 --> Router Class Initialized
INFO - 2016-09-08 08:40:03 --> Output Class Initialized
INFO - 2016-09-08 08:40:03 --> Security Class Initialized
DEBUG - 2016-09-08 08:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:40:03 --> Input Class Initialized
INFO - 2016-09-08 08:40:03 --> Language Class Initialized
ERROR - 2016-09-08 08:40:04 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:40:10 --> Config Class Initialized
INFO - 2016-09-08 08:40:10 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:40:10 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:40:10 --> Utf8 Class Initialized
INFO - 2016-09-08 08:40:10 --> URI Class Initialized
INFO - 2016-09-08 08:40:10 --> Router Class Initialized
INFO - 2016-09-08 08:40:10 --> Output Class Initialized
INFO - 2016-09-08 08:40:10 --> Security Class Initialized
DEBUG - 2016-09-08 08:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:40:10 --> Input Class Initialized
INFO - 2016-09-08 08:40:10 --> Language Class Initialized
ERROR - 2016-09-08 08:40:10 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:40:16 --> Config Class Initialized
INFO - 2016-09-08 08:40:16 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:40:16 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:40:16 --> Utf8 Class Initialized
INFO - 2016-09-08 08:40:16 --> URI Class Initialized
INFO - 2016-09-08 08:40:16 --> Router Class Initialized
INFO - 2016-09-08 08:40:16 --> Output Class Initialized
INFO - 2016-09-08 08:40:16 --> Security Class Initialized
DEBUG - 2016-09-08 08:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:40:16 --> Input Class Initialized
INFO - 2016-09-08 08:40:16 --> Language Class Initialized
ERROR - 2016-09-08 08:40:16 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:40:22 --> Config Class Initialized
INFO - 2016-09-08 08:40:22 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:40:22 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:40:22 --> Utf8 Class Initialized
INFO - 2016-09-08 08:40:22 --> URI Class Initialized
INFO - 2016-09-08 08:40:22 --> Router Class Initialized
INFO - 2016-09-08 08:40:22 --> Output Class Initialized
INFO - 2016-09-08 08:40:22 --> Security Class Initialized
DEBUG - 2016-09-08 08:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:40:22 --> Input Class Initialized
INFO - 2016-09-08 08:40:22 --> Language Class Initialized
ERROR - 2016-09-08 08:40:22 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:40:27 --> Config Class Initialized
INFO - 2016-09-08 08:40:27 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:40:27 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:40:27 --> Utf8 Class Initialized
INFO - 2016-09-08 08:40:27 --> URI Class Initialized
INFO - 2016-09-08 08:40:27 --> Router Class Initialized
INFO - 2016-09-08 08:40:27 --> Output Class Initialized
INFO - 2016-09-08 08:40:27 --> Security Class Initialized
DEBUG - 2016-09-08 08:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:40:27 --> Input Class Initialized
INFO - 2016-09-08 08:40:27 --> Language Class Initialized
ERROR - 2016-09-08 08:40:28 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:40:33 --> Config Class Initialized
INFO - 2016-09-08 08:40:33 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:40:33 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:40:33 --> Utf8 Class Initialized
INFO - 2016-09-08 08:40:33 --> URI Class Initialized
INFO - 2016-09-08 08:40:33 --> Router Class Initialized
INFO - 2016-09-08 08:40:33 --> Output Class Initialized
INFO - 2016-09-08 08:40:33 --> Security Class Initialized
DEBUG - 2016-09-08 08:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:40:33 --> Input Class Initialized
INFO - 2016-09-08 08:40:33 --> Language Class Initialized
ERROR - 2016-09-08 08:40:33 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:40:38 --> Config Class Initialized
INFO - 2016-09-08 08:40:38 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:40:38 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:40:38 --> Utf8 Class Initialized
INFO - 2016-09-08 08:40:38 --> URI Class Initialized
INFO - 2016-09-08 08:40:38 --> Router Class Initialized
INFO - 2016-09-08 08:40:38 --> Output Class Initialized
INFO - 2016-09-08 08:40:38 --> Security Class Initialized
DEBUG - 2016-09-08 08:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:40:38 --> Input Class Initialized
INFO - 2016-09-08 08:40:38 --> Language Class Initialized
ERROR - 2016-09-08 08:40:39 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:40:44 --> Config Class Initialized
INFO - 2016-09-08 08:40:44 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:40:44 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:40:44 --> Utf8 Class Initialized
INFO - 2016-09-08 08:40:44 --> URI Class Initialized
INFO - 2016-09-08 08:40:44 --> Router Class Initialized
INFO - 2016-09-08 08:40:44 --> Output Class Initialized
INFO - 2016-09-08 08:40:44 --> Security Class Initialized
DEBUG - 2016-09-08 08:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:40:44 --> Input Class Initialized
INFO - 2016-09-08 08:40:44 --> Language Class Initialized
ERROR - 2016-09-08 08:40:44 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:40:49 --> Config Class Initialized
INFO - 2016-09-08 08:40:49 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:40:49 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:40:49 --> Utf8 Class Initialized
INFO - 2016-09-08 08:40:49 --> URI Class Initialized
INFO - 2016-09-08 08:40:49 --> Router Class Initialized
INFO - 2016-09-08 08:40:49 --> Output Class Initialized
INFO - 2016-09-08 08:40:49 --> Security Class Initialized
DEBUG - 2016-09-08 08:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:40:49 --> Input Class Initialized
INFO - 2016-09-08 08:40:49 --> Language Class Initialized
ERROR - 2016-09-08 08:40:49 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:40:55 --> Config Class Initialized
INFO - 2016-09-08 08:40:55 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:40:55 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:40:55 --> Utf8 Class Initialized
INFO - 2016-09-08 08:40:55 --> URI Class Initialized
INFO - 2016-09-08 08:40:55 --> Router Class Initialized
INFO - 2016-09-08 08:40:55 --> Output Class Initialized
INFO - 2016-09-08 08:40:55 --> Security Class Initialized
DEBUG - 2016-09-08 08:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:40:55 --> Input Class Initialized
INFO - 2016-09-08 08:40:55 --> Language Class Initialized
ERROR - 2016-09-08 08:40:55 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:42:38 --> Config Class Initialized
INFO - 2016-09-08 08:42:38 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:42:38 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:42:38 --> Utf8 Class Initialized
INFO - 2016-09-08 08:42:38 --> URI Class Initialized
INFO - 2016-09-08 08:42:38 --> Router Class Initialized
INFO - 2016-09-08 08:42:38 --> Output Class Initialized
INFO - 2016-09-08 08:42:38 --> Security Class Initialized
DEBUG - 2016-09-08 08:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:42:38 --> Input Class Initialized
INFO - 2016-09-08 08:42:38 --> Language Class Initialized
ERROR - 2016-09-08 08:42:38 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:42:44 --> Config Class Initialized
INFO - 2016-09-08 08:42:44 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:42:44 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:42:44 --> Utf8 Class Initialized
INFO - 2016-09-08 08:42:44 --> URI Class Initialized
INFO - 2016-09-08 08:42:44 --> Router Class Initialized
INFO - 2016-09-08 08:42:44 --> Output Class Initialized
INFO - 2016-09-08 08:42:44 --> Security Class Initialized
DEBUG - 2016-09-08 08:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:42:44 --> Input Class Initialized
INFO - 2016-09-08 08:42:44 --> Language Class Initialized
ERROR - 2016-09-08 08:42:44 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:42:50 --> Config Class Initialized
INFO - 2016-09-08 08:42:50 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:42:50 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:42:50 --> Utf8 Class Initialized
INFO - 2016-09-08 08:42:50 --> URI Class Initialized
INFO - 2016-09-08 08:42:50 --> Router Class Initialized
INFO - 2016-09-08 08:42:50 --> Output Class Initialized
INFO - 2016-09-08 08:42:50 --> Security Class Initialized
DEBUG - 2016-09-08 08:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:42:50 --> Input Class Initialized
INFO - 2016-09-08 08:42:50 --> Language Class Initialized
ERROR - 2016-09-08 08:42:50 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:42:57 --> Config Class Initialized
INFO - 2016-09-08 08:42:57 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:42:57 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:42:57 --> Utf8 Class Initialized
INFO - 2016-09-08 08:42:57 --> URI Class Initialized
INFO - 2016-09-08 08:42:57 --> Router Class Initialized
INFO - 2016-09-08 08:42:58 --> Output Class Initialized
INFO - 2016-09-08 08:42:58 --> Security Class Initialized
DEBUG - 2016-09-08 08:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:42:58 --> Input Class Initialized
INFO - 2016-09-08 08:42:58 --> Language Class Initialized
ERROR - 2016-09-08 08:42:58 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:43:03 --> Config Class Initialized
INFO - 2016-09-08 08:43:03 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:43:03 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:43:03 --> Utf8 Class Initialized
INFO - 2016-09-08 08:43:03 --> URI Class Initialized
INFO - 2016-09-08 08:43:04 --> Router Class Initialized
INFO - 2016-09-08 08:43:04 --> Output Class Initialized
INFO - 2016-09-08 08:43:04 --> Security Class Initialized
DEBUG - 2016-09-08 08:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:43:04 --> Input Class Initialized
INFO - 2016-09-08 08:43:04 --> Language Class Initialized
ERROR - 2016-09-08 08:43:04 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:43:10 --> Config Class Initialized
INFO - 2016-09-08 08:43:10 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:43:10 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:43:10 --> Utf8 Class Initialized
INFO - 2016-09-08 08:43:10 --> URI Class Initialized
INFO - 2016-09-08 08:43:10 --> Router Class Initialized
INFO - 2016-09-08 08:43:10 --> Output Class Initialized
INFO - 2016-09-08 08:43:10 --> Security Class Initialized
DEBUG - 2016-09-08 08:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:43:10 --> Input Class Initialized
INFO - 2016-09-08 08:43:10 --> Language Class Initialized
ERROR - 2016-09-08 08:43:10 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:43:16 --> Config Class Initialized
INFO - 2016-09-08 08:43:16 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:43:16 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:43:16 --> Utf8 Class Initialized
INFO - 2016-09-08 08:43:16 --> URI Class Initialized
INFO - 2016-09-08 08:43:16 --> Router Class Initialized
INFO - 2016-09-08 08:43:16 --> Output Class Initialized
INFO - 2016-09-08 08:43:16 --> Security Class Initialized
DEBUG - 2016-09-08 08:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:43:16 --> Input Class Initialized
INFO - 2016-09-08 08:43:16 --> Language Class Initialized
ERROR - 2016-09-08 08:43:16 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:43:22 --> Config Class Initialized
INFO - 2016-09-08 08:43:22 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:43:22 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:43:22 --> Utf8 Class Initialized
INFO - 2016-09-08 08:43:22 --> URI Class Initialized
INFO - 2016-09-08 08:43:23 --> Router Class Initialized
INFO - 2016-09-08 08:43:23 --> Output Class Initialized
INFO - 2016-09-08 08:43:23 --> Security Class Initialized
DEBUG - 2016-09-08 08:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:43:23 --> Input Class Initialized
INFO - 2016-09-08 08:43:23 --> Language Class Initialized
ERROR - 2016-09-08 08:43:23 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:43:29 --> Config Class Initialized
INFO - 2016-09-08 08:43:29 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:43:29 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:43:29 --> Utf8 Class Initialized
INFO - 2016-09-08 08:43:29 --> URI Class Initialized
INFO - 2016-09-08 08:43:29 --> Router Class Initialized
INFO - 2016-09-08 08:43:29 --> Output Class Initialized
INFO - 2016-09-08 08:43:29 --> Security Class Initialized
DEBUG - 2016-09-08 08:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:43:29 --> Input Class Initialized
INFO - 2016-09-08 08:43:29 --> Language Class Initialized
ERROR - 2016-09-08 08:43:29 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:43:35 --> Config Class Initialized
INFO - 2016-09-08 08:43:35 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:43:35 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:43:35 --> Utf8 Class Initialized
INFO - 2016-09-08 08:43:36 --> URI Class Initialized
INFO - 2016-09-08 08:43:36 --> Router Class Initialized
INFO - 2016-09-08 08:43:36 --> Output Class Initialized
INFO - 2016-09-08 08:43:36 --> Security Class Initialized
DEBUG - 2016-09-08 08:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:43:36 --> Input Class Initialized
INFO - 2016-09-08 08:43:36 --> Language Class Initialized
ERROR - 2016-09-08 08:43:36 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:49:01 --> Config Class Initialized
INFO - 2016-09-08 08:49:01 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:49:01 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:49:01 --> Utf8 Class Initialized
INFO - 2016-09-08 08:49:01 --> URI Class Initialized
INFO - 2016-09-08 08:49:01 --> Router Class Initialized
INFO - 2016-09-08 08:49:01 --> Output Class Initialized
INFO - 2016-09-08 08:49:01 --> Security Class Initialized
DEBUG - 2016-09-08 08:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:49:01 --> Input Class Initialized
INFO - 2016-09-08 08:49:01 --> Language Class Initialized
ERROR - 2016-09-08 08:49:02 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:49:08 --> Config Class Initialized
INFO - 2016-09-08 08:49:08 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:49:08 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:49:08 --> Utf8 Class Initialized
INFO - 2016-09-08 08:49:08 --> URI Class Initialized
INFO - 2016-09-08 08:49:08 --> Router Class Initialized
INFO - 2016-09-08 08:49:08 --> Output Class Initialized
INFO - 2016-09-08 08:49:08 --> Security Class Initialized
DEBUG - 2016-09-08 08:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:49:08 --> Input Class Initialized
INFO - 2016-09-08 08:49:08 --> Language Class Initialized
ERROR - 2016-09-08 08:49:08 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:49:13 --> Config Class Initialized
INFO - 2016-09-08 08:49:13 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:49:13 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:49:13 --> Utf8 Class Initialized
INFO - 2016-09-08 08:49:13 --> URI Class Initialized
INFO - 2016-09-08 08:49:13 --> Router Class Initialized
INFO - 2016-09-08 08:49:13 --> Output Class Initialized
INFO - 2016-09-08 08:49:13 --> Security Class Initialized
DEBUG - 2016-09-08 08:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:49:14 --> Input Class Initialized
INFO - 2016-09-08 08:49:14 --> Language Class Initialized
ERROR - 2016-09-08 08:49:14 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:49:19 --> Config Class Initialized
INFO - 2016-09-08 08:49:19 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:49:19 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:49:19 --> Utf8 Class Initialized
INFO - 2016-09-08 08:49:19 --> URI Class Initialized
INFO - 2016-09-08 08:49:19 --> Router Class Initialized
INFO - 2016-09-08 08:49:19 --> Output Class Initialized
INFO - 2016-09-08 08:49:19 --> Security Class Initialized
DEBUG - 2016-09-08 08:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:49:20 --> Input Class Initialized
INFO - 2016-09-08 08:49:20 --> Language Class Initialized
ERROR - 2016-09-08 08:49:20 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:49:25 --> Config Class Initialized
INFO - 2016-09-08 08:49:25 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:49:25 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:49:25 --> Utf8 Class Initialized
INFO - 2016-09-08 08:49:25 --> URI Class Initialized
INFO - 2016-09-08 08:49:25 --> Router Class Initialized
INFO - 2016-09-08 08:49:25 --> Output Class Initialized
INFO - 2016-09-08 08:49:25 --> Security Class Initialized
DEBUG - 2016-09-08 08:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:49:25 --> Input Class Initialized
INFO - 2016-09-08 08:49:25 --> Language Class Initialized
ERROR - 2016-09-08 08:49:25 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:49:30 --> Config Class Initialized
INFO - 2016-09-08 08:49:30 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:49:30 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:49:30 --> Utf8 Class Initialized
INFO - 2016-09-08 08:49:30 --> URI Class Initialized
INFO - 2016-09-08 08:49:30 --> Router Class Initialized
INFO - 2016-09-08 08:49:30 --> Output Class Initialized
INFO - 2016-09-08 08:49:30 --> Security Class Initialized
DEBUG - 2016-09-08 08:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:49:30 --> Input Class Initialized
INFO - 2016-09-08 08:49:31 --> Language Class Initialized
ERROR - 2016-09-08 08:49:31 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:49:36 --> Config Class Initialized
INFO - 2016-09-08 08:49:36 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:49:36 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:49:36 --> Utf8 Class Initialized
INFO - 2016-09-08 08:49:36 --> URI Class Initialized
INFO - 2016-09-08 08:49:36 --> Router Class Initialized
INFO - 2016-09-08 08:49:36 --> Output Class Initialized
INFO - 2016-09-08 08:49:36 --> Security Class Initialized
DEBUG - 2016-09-08 08:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:49:36 --> Input Class Initialized
INFO - 2016-09-08 08:49:36 --> Language Class Initialized
ERROR - 2016-09-08 08:49:36 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:49:42 --> Config Class Initialized
INFO - 2016-09-08 08:49:42 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:49:42 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:49:42 --> Utf8 Class Initialized
INFO - 2016-09-08 08:49:42 --> URI Class Initialized
INFO - 2016-09-08 08:49:42 --> Router Class Initialized
INFO - 2016-09-08 08:49:42 --> Output Class Initialized
INFO - 2016-09-08 08:49:42 --> Security Class Initialized
DEBUG - 2016-09-08 08:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:49:42 --> Input Class Initialized
INFO - 2016-09-08 08:49:42 --> Language Class Initialized
ERROR - 2016-09-08 08:49:42 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:49:47 --> Config Class Initialized
INFO - 2016-09-08 08:49:47 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:49:47 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:49:47 --> Utf8 Class Initialized
INFO - 2016-09-08 08:49:47 --> URI Class Initialized
INFO - 2016-09-08 08:49:47 --> Router Class Initialized
INFO - 2016-09-08 08:49:47 --> Output Class Initialized
INFO - 2016-09-08 08:49:47 --> Security Class Initialized
DEBUG - 2016-09-08 08:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:49:47 --> Input Class Initialized
INFO - 2016-09-08 08:49:47 --> Language Class Initialized
ERROR - 2016-09-08 08:49:48 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:49:53 --> Config Class Initialized
INFO - 2016-09-08 08:49:53 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:49:53 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:49:53 --> Utf8 Class Initialized
INFO - 2016-09-08 08:49:53 --> URI Class Initialized
INFO - 2016-09-08 08:49:53 --> Router Class Initialized
INFO - 2016-09-08 08:49:53 --> Output Class Initialized
INFO - 2016-09-08 08:49:53 --> Security Class Initialized
DEBUG - 2016-09-08 08:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:49:53 --> Input Class Initialized
INFO - 2016-09-08 08:49:53 --> Language Class Initialized
ERROR - 2016-09-08 08:49:53 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:54:53 --> Config Class Initialized
INFO - 2016-09-08 08:54:53 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:54:53 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:54:53 --> Utf8 Class Initialized
INFO - 2016-09-08 08:54:53 --> URI Class Initialized
INFO - 2016-09-08 08:54:53 --> Router Class Initialized
INFO - 2016-09-08 08:54:53 --> Output Class Initialized
INFO - 2016-09-08 08:54:53 --> Security Class Initialized
DEBUG - 2016-09-08 08:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:54:53 --> Input Class Initialized
INFO - 2016-09-08 08:54:53 --> Language Class Initialized
ERROR - 2016-09-08 08:54:53 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:54:58 --> Config Class Initialized
INFO - 2016-09-08 08:54:58 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:54:58 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:54:59 --> Utf8 Class Initialized
INFO - 2016-09-08 08:54:59 --> URI Class Initialized
INFO - 2016-09-08 08:54:59 --> Router Class Initialized
INFO - 2016-09-08 08:54:59 --> Output Class Initialized
INFO - 2016-09-08 08:54:59 --> Security Class Initialized
DEBUG - 2016-09-08 08:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:54:59 --> Input Class Initialized
INFO - 2016-09-08 08:54:59 --> Language Class Initialized
ERROR - 2016-09-08 08:54:59 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:55:04 --> Config Class Initialized
INFO - 2016-09-08 08:55:04 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:55:04 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:55:04 --> Utf8 Class Initialized
INFO - 2016-09-08 08:55:04 --> URI Class Initialized
INFO - 2016-09-08 08:55:04 --> Router Class Initialized
INFO - 2016-09-08 08:55:04 --> Output Class Initialized
INFO - 2016-09-08 08:55:04 --> Security Class Initialized
DEBUG - 2016-09-08 08:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:55:04 --> Input Class Initialized
INFO - 2016-09-08 08:55:04 --> Language Class Initialized
ERROR - 2016-09-08 08:55:04 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:55:10 --> Config Class Initialized
INFO - 2016-09-08 08:55:10 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:55:10 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:55:10 --> Utf8 Class Initialized
INFO - 2016-09-08 08:55:10 --> URI Class Initialized
INFO - 2016-09-08 08:55:10 --> Router Class Initialized
INFO - 2016-09-08 08:55:10 --> Output Class Initialized
INFO - 2016-09-08 08:55:10 --> Security Class Initialized
DEBUG - 2016-09-08 08:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:55:10 --> Input Class Initialized
INFO - 2016-09-08 08:55:10 --> Language Class Initialized
ERROR - 2016-09-08 08:55:10 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:55:15 --> Config Class Initialized
INFO - 2016-09-08 08:55:15 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:55:15 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:55:15 --> Utf8 Class Initialized
INFO - 2016-09-08 08:55:15 --> URI Class Initialized
INFO - 2016-09-08 08:55:15 --> Router Class Initialized
INFO - 2016-09-08 08:55:15 --> Output Class Initialized
INFO - 2016-09-08 08:55:15 --> Security Class Initialized
DEBUG - 2016-09-08 08:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:55:16 --> Input Class Initialized
INFO - 2016-09-08 08:55:16 --> Language Class Initialized
ERROR - 2016-09-08 08:55:16 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:55:21 --> Config Class Initialized
INFO - 2016-09-08 08:55:21 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:55:21 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:55:21 --> Utf8 Class Initialized
INFO - 2016-09-08 08:55:21 --> URI Class Initialized
INFO - 2016-09-08 08:55:21 --> Router Class Initialized
INFO - 2016-09-08 08:55:21 --> Output Class Initialized
INFO - 2016-09-08 08:55:21 --> Security Class Initialized
DEBUG - 2016-09-08 08:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:55:21 --> Input Class Initialized
INFO - 2016-09-08 08:55:21 --> Language Class Initialized
ERROR - 2016-09-08 08:55:21 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:55:39 --> Config Class Initialized
INFO - 2016-09-08 08:55:39 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:55:39 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:55:39 --> Utf8 Class Initialized
INFO - 2016-09-08 08:55:39 --> URI Class Initialized
INFO - 2016-09-08 08:55:39 --> Router Class Initialized
INFO - 2016-09-08 08:55:39 --> Output Class Initialized
INFO - 2016-09-08 08:55:39 --> Security Class Initialized
DEBUG - 2016-09-08 08:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:55:39 --> Input Class Initialized
INFO - 2016-09-08 08:55:39 --> Language Class Initialized
ERROR - 2016-09-08 08:55:39 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:55:45 --> Config Class Initialized
INFO - 2016-09-08 08:55:45 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:55:45 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:55:45 --> Utf8 Class Initialized
INFO - 2016-09-08 08:55:45 --> URI Class Initialized
INFO - 2016-09-08 08:55:45 --> Router Class Initialized
INFO - 2016-09-08 08:55:45 --> Output Class Initialized
INFO - 2016-09-08 08:55:45 --> Security Class Initialized
DEBUG - 2016-09-08 08:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:55:45 --> Input Class Initialized
INFO - 2016-09-08 08:55:45 --> Language Class Initialized
ERROR - 2016-09-08 08:55:46 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:55:51 --> Config Class Initialized
INFO - 2016-09-08 08:55:51 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:55:51 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:55:51 --> Utf8 Class Initialized
INFO - 2016-09-08 08:55:51 --> URI Class Initialized
INFO - 2016-09-08 08:55:52 --> Router Class Initialized
INFO - 2016-09-08 08:55:52 --> Output Class Initialized
INFO - 2016-09-08 08:55:52 --> Security Class Initialized
DEBUG - 2016-09-08 08:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:55:52 --> Input Class Initialized
INFO - 2016-09-08 08:55:52 --> Language Class Initialized
ERROR - 2016-09-08 08:55:52 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:55:58 --> Config Class Initialized
INFO - 2016-09-08 08:55:58 --> Config Class Initialized
INFO - 2016-09-08 08:55:58 --> Hooks Class Initialized
INFO - 2016-09-08 08:55:58 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:55:58 --> UTF-8 Support Enabled
DEBUG - 2016-09-08 08:55:58 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:55:58 --> Utf8 Class Initialized
INFO - 2016-09-08 08:55:58 --> URI Class Initialized
INFO - 2016-09-08 08:55:58 --> Router Class Initialized
INFO - 2016-09-08 08:55:58 --> Output Class Initialized
INFO - 2016-09-08 08:55:58 --> Security Class Initialized
DEBUG - 2016-09-08 08:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:55:58 --> Input Class Initialized
INFO - 2016-09-08 08:55:58 --> Language Class Initialized
ERROR - 2016-09-08 08:55:59 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:55:59 --> Utf8 Class Initialized
INFO - 2016-09-08 08:55:59 --> URI Class Initialized
INFO - 2016-09-08 08:55:59 --> Router Class Initialized
INFO - 2016-09-08 08:55:59 --> Output Class Initialized
INFO - 2016-09-08 08:56:01 --> Security Class Initialized
DEBUG - 2016-09-08 08:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:56:01 --> Input Class Initialized
INFO - 2016-09-08 08:56:01 --> Language Class Initialized
INFO - 2016-09-08 08:56:05 --> Config Class Initialized
INFO - 2016-09-08 08:56:05 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:56:05 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:56:05 --> Utf8 Class Initialized
INFO - 2016-09-08 08:56:05 --> URI Class Initialized
INFO - 2016-09-08 08:56:05 --> Router Class Initialized
INFO - 2016-09-08 08:56:05 --> Output Class Initialized
INFO - 2016-09-08 08:56:05 --> Security Class Initialized
DEBUG - 2016-09-08 08:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:56:05 --> Input Class Initialized
INFO - 2016-09-08 08:56:05 --> Language Class Initialized
ERROR - 2016-09-08 08:56:05 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:56:10 --> Config Class Initialized
INFO - 2016-09-08 08:56:10 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:56:10 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:56:10 --> Utf8 Class Initialized
INFO - 2016-09-08 08:56:10 --> URI Class Initialized
INFO - 2016-09-08 08:56:10 --> Router Class Initialized
INFO - 2016-09-08 08:56:10 --> Output Class Initialized
INFO - 2016-09-08 08:56:10 --> Security Class Initialized
DEBUG - 2016-09-08 08:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:56:11 --> Input Class Initialized
INFO - 2016-09-08 08:56:11 --> Language Class Initialized
ERROR - 2016-09-08 08:56:11 --> Severity: Compile Error --> Cannot use [] for reading E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 62
INFO - 2016-09-08 08:56:16 --> Config Class Initialized
INFO - 2016-09-08 08:56:16 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:56:16 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:56:16 --> Utf8 Class Initialized
INFO - 2016-09-08 08:56:16 --> URI Class Initialized
INFO - 2016-09-08 08:56:16 --> Router Class Initialized
INFO - 2016-09-08 08:56:16 --> Output Class Initialized
INFO - 2016-09-08 08:56:16 --> Security Class Initialized
DEBUG - 2016-09-08 08:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:56:16 --> Input Class Initialized
INFO - 2016-09-08 08:56:16 --> Language Class Initialized
INFO - 2016-09-08 08:56:16 --> Language Class Initialized
INFO - 2016-09-08 08:56:16 --> Config Class Initialized
INFO - 2016-09-08 08:56:17 --> Loader Class Initialized
INFO - 2016-09-08 08:56:17 --> Helper loaded: url_helper
INFO - 2016-09-08 08:56:17 --> Database Driver Class Initialized
INFO - 2016-09-08 08:56:17 --> Controller Class Initialized
DEBUG - 2016-09-08 08:56:17 --> Index MX_Controller Initialized
INFO - 2016-09-08 08:56:18 --> Model Class Initialized
INFO - 2016-09-08 08:56:18 --> Model Class Initialized
DEBUG - 2016-09-08 08:56:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 08:56:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 08:56:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 08:56:18 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 08:56:18 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 08:56:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 08:56:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 08:56:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 08:56:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 08:56:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 08:56:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 08:56:18 --> Final output sent to browser
DEBUG - 2016-09-08 08:56:18 --> Total execution time: 2.4407
INFO - 2016-09-08 08:56:18 --> Config Class Initialized
INFO - 2016-09-08 08:56:18 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:56:19 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:56:19 --> Utf8 Class Initialized
INFO - 2016-09-08 08:56:19 --> URI Class Initialized
INFO - 2016-09-08 08:56:19 --> Router Class Initialized
INFO - 2016-09-08 08:56:19 --> Output Class Initialized
INFO - 2016-09-08 08:56:19 --> Security Class Initialized
DEBUG - 2016-09-08 08:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:56:19 --> Input Class Initialized
INFO - 2016-09-08 08:56:19 --> Language Class Initialized
INFO - 2016-09-08 08:56:19 --> Language Class Initialized
INFO - 2016-09-08 08:56:19 --> Config Class Initialized
INFO - 2016-09-08 08:56:19 --> Loader Class Initialized
INFO - 2016-09-08 08:56:19 --> Helper loaded: url_helper
INFO - 2016-09-08 08:56:19 --> Database Driver Class Initialized
INFO - 2016-09-08 08:56:19 --> Controller Class Initialized
DEBUG - 2016-09-08 08:56:19 --> Index MX_Controller Initialized
INFO - 2016-09-08 08:56:19 --> Model Class Initialized
INFO - 2016-09-08 08:56:19 --> Model Class Initialized
DEBUG - 2016-09-08 08:56:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 08:56:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 08:56:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 08:56:19 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 08:56:20 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 08:56:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 08:56:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 08:56:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 08:56:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 08:56:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 08:56:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 08:56:20 --> Final output sent to browser
DEBUG - 2016-09-08 08:56:20 --> Total execution time: 1.2975
INFO - 2016-09-08 08:56:33 --> Config Class Initialized
INFO - 2016-09-08 08:56:33 --> Hooks Class Initialized
DEBUG - 2016-09-08 08:56:33 --> UTF-8 Support Enabled
INFO - 2016-09-08 08:56:33 --> Utf8 Class Initialized
INFO - 2016-09-08 08:56:33 --> URI Class Initialized
INFO - 2016-09-08 08:56:33 --> Router Class Initialized
INFO - 2016-09-08 08:56:33 --> Output Class Initialized
INFO - 2016-09-08 08:56:33 --> Security Class Initialized
DEBUG - 2016-09-08 08:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 08:56:33 --> Input Class Initialized
INFO - 2016-09-08 08:56:33 --> Language Class Initialized
INFO - 2016-09-08 08:56:33 --> Language Class Initialized
INFO - 2016-09-08 08:56:33 --> Config Class Initialized
INFO - 2016-09-08 08:56:33 --> Loader Class Initialized
INFO - 2016-09-08 08:56:33 --> Helper loaded: url_helper
INFO - 2016-09-08 08:56:33 --> Database Driver Class Initialized
INFO - 2016-09-08 08:56:33 --> Controller Class Initialized
DEBUG - 2016-09-08 08:56:33 --> Index MX_Controller Initialized
INFO - 2016-09-08 08:56:33 --> Model Class Initialized
INFO - 2016-09-08 08:56:33 --> Model Class Initialized
DEBUG - 2016-09-08 08:56:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-08 08:56:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-08 08:56:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-08 08:56:34 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-08 08:56:34 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-08 08:56:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-08 08:56:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-08 08:56:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-08 08:56:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-08 08:56:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-08 08:56:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-08 08:56:34 --> Final output sent to browser
DEBUG - 2016-09-08 08:56:34 --> Total execution time: 0.9500
