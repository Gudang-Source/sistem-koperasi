<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-10-26 03:32:40 --> Config Class Initialized
INFO - 2016-10-26 03:32:40 --> Hooks Class Initialized
DEBUG - 2016-10-26 03:32:40 --> UTF-8 Support Enabled
INFO - 2016-10-26 03:32:40 --> Utf8 Class Initialized
INFO - 2016-10-26 03:32:40 --> URI Class Initialized
INFO - 2016-10-26 03:32:40 --> Router Class Initialized
INFO - 2016-10-26 03:32:40 --> Output Class Initialized
INFO - 2016-10-26 03:32:40 --> Security Class Initialized
DEBUG - 2016-10-26 03:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 03:32:40 --> Input Class Initialized
INFO - 2016-10-26 03:32:41 --> Language Class Initialized
INFO - 2016-10-26 03:32:41 --> Language Class Initialized
INFO - 2016-10-26 03:32:41 --> Config Class Initialized
INFO - 2016-10-26 03:32:41 --> Loader Class Initialized
INFO - 2016-10-26 03:32:41 --> Helper loaded: url_helper
INFO - 2016-10-26 03:32:41 --> Database Driver Class Initialized
INFO - 2016-10-26 03:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 03:32:41 --> Controller Class Initialized
DEBUG - 2016-10-26 03:32:41 --> Index MX_Controller Initialized
INFO - 2016-10-26 03:32:41 --> Model Class Initialized
INFO - 2016-10-26 03:32:41 --> Model Class Initialized
ERROR - 2016-10-26 03:32:41 --> Unable to delete cache file for admin/index/toPdf
ERROR - 2016-10-26 03:32:41 --> Severity: Notice --> Undefined variable: type E:\SERVER\htdocs\kops\application\views\main_html\content\list_anggota.php 15
ERROR - 2016-10-26 03:32:41 --> Severity: Notice --> Undefined variable: type E:\SERVER\htdocs\kops\application\views\main_html\content\list_anggota.php 36
DEBUG - 2016-10-26 03:32:41 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-26 03:32:41 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-26 03:32:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
ERROR - 2016-10-26 03:32:42 --> Severity: Error --> Call to undefined method DOMText::getAttribute() E:\SERVER\htdocs\kops\application\third_party\dompdf\include\cellmap.cls.php 407
INFO - 2016-10-26 05:10:55 --> Config Class Initialized
INFO - 2016-10-26 05:10:56 --> Hooks Class Initialized
DEBUG - 2016-10-26 05:10:56 --> UTF-8 Support Enabled
INFO - 2016-10-26 05:10:56 --> Utf8 Class Initialized
INFO - 2016-10-26 05:10:56 --> URI Class Initialized
INFO - 2016-10-26 05:10:56 --> Router Class Initialized
INFO - 2016-10-26 05:10:56 --> Output Class Initialized
INFO - 2016-10-26 05:10:56 --> Security Class Initialized
DEBUG - 2016-10-26 05:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 05:10:56 --> Input Class Initialized
INFO - 2016-10-26 05:10:56 --> Language Class Initialized
INFO - 2016-10-26 05:10:56 --> Language Class Initialized
INFO - 2016-10-26 05:10:56 --> Config Class Initialized
INFO - 2016-10-26 05:10:56 --> Loader Class Initialized
INFO - 2016-10-26 05:10:56 --> Helper loaded: url_helper
INFO - 2016-10-26 05:10:56 --> Database Driver Class Initialized
INFO - 2016-10-26 05:10:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 05:10:56 --> Controller Class Initialized
DEBUG - 2016-10-26 05:10:56 --> Index MX_Controller Initialized
INFO - 2016-10-26 05:10:56 --> Model Class Initialized
INFO - 2016-10-26 05:10:56 --> Model Class Initialized
ERROR - 2016-10-26 05:10:56 --> Unable to delete cache file for admin/index/toPdf
ERROR - 2016-10-26 05:10:56 --> Severity: Notice --> Undefined variable: type E:\SERVER\htdocs\kops\application\views\main_html\content\list_anggota.php 15
ERROR - 2016-10-26 05:10:56 --> Severity: Notice --> Undefined variable: type E:\SERVER\htdocs\kops\application\views\main_html\content\list_anggota.php 36
DEBUG - 2016-10-26 05:10:56 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-26 05:10:56 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-26 05:10:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
ERROR - 2016-10-26 05:10:57 --> Severity: Error --> Call to undefined method DOMText::getAttribute() E:\SERVER\htdocs\kops\application\third_party\dompdf\include\cellmap.cls.php 407
INFO - 2016-10-26 07:10:56 --> Config Class Initialized
INFO - 2016-10-26 07:10:56 --> Hooks Class Initialized
DEBUG - 2016-10-26 07:10:56 --> UTF-8 Support Enabled
INFO - 2016-10-26 07:10:56 --> Utf8 Class Initialized
INFO - 2016-10-26 07:10:56 --> URI Class Initialized
INFO - 2016-10-26 07:10:56 --> Router Class Initialized
INFO - 2016-10-26 07:10:56 --> Output Class Initialized
INFO - 2016-10-26 07:10:56 --> Security Class Initialized
DEBUG - 2016-10-26 07:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 07:10:56 --> Input Class Initialized
INFO - 2016-10-26 07:10:56 --> Language Class Initialized
INFO - 2016-10-26 07:10:56 --> Language Class Initialized
INFO - 2016-10-26 07:10:56 --> Config Class Initialized
INFO - 2016-10-26 07:10:56 --> Loader Class Initialized
INFO - 2016-10-26 07:10:56 --> Helper loaded: url_helper
INFO - 2016-10-26 07:10:56 --> Database Driver Class Initialized
INFO - 2016-10-26 07:10:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 07:10:56 --> Controller Class Initialized
DEBUG - 2016-10-26 07:10:56 --> Index MX_Controller Initialized
INFO - 2016-10-26 07:10:56 --> Model Class Initialized
INFO - 2016-10-26 07:10:56 --> Model Class Initialized
ERROR - 2016-10-26 07:10:56 --> Unable to delete cache file for admin/index/toPdf
ERROR - 2016-10-26 07:10:56 --> Severity: Notice --> Undefined variable: type E:\SERVER\htdocs\kops\application\views\main_html\content\list_anggota.php 15
ERROR - 2016-10-26 07:10:56 --> Severity: Notice --> Undefined variable: type E:\SERVER\htdocs\kops\application\views\main_html\content\list_anggota.php 36
DEBUG - 2016-10-26 07:10:56 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-26 07:10:57 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-26 07:10:57 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
ERROR - 2016-10-26 07:10:57 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5132
ERROR - 2016-10-26 07:10:57 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5140
ERROR - 2016-10-26 07:10:57 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5140
ERROR - 2016-10-26 07:10:57 --> Severity: Notice --> Undefined index: td_x E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:10:57 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5450
INFO - 2016-10-26 07:10:57 --> Config Class Initialized
INFO - 2016-10-26 07:10:57 --> Hooks Class Initialized
ERROR - 2016-10-26 07:10:57 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5487
ERROR - 2016-10-26 07:10:57 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5450
DEBUG - 2016-10-26 07:10:57 --> UTF-8 Support Enabled
INFO - 2016-10-26 07:10:57 --> Utf8 Class Initialized
ERROR - 2016-10-26 07:10:57 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5487
INFO - 2016-10-26 07:10:57 --> URI Class Initialized
ERROR - 2016-10-26 07:10:57 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5450
ERROR - 2016-10-26 07:10:58 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5487
INFO - 2016-10-26 07:10:58 --> Router Class Initialized
INFO - 2016-10-26 07:10:58 --> Output Class Initialized
ERROR - 2016-10-26 07:10:58 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5450
ERROR - 2016-10-26 07:10:58 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5487
INFO - 2016-10-26 07:10:58 --> Security Class Initialized
DEBUG - 2016-10-26 07:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 07:10:58 --> Input Class Initialized
INFO - 2016-10-26 07:10:58 --> Language Class Initialized
INFO - 2016-10-26 07:10:58 --> Language Class Initialized
INFO - 2016-10-26 07:10:58 --> Config Class Initialized
INFO - 2016-10-26 07:10:58 --> Loader Class Initialized
INFO - 2016-10-26 07:10:58 --> Helper loaded: url_helper
INFO - 2016-10-26 07:10:58 --> Database Driver Class Initialized
INFO - 2016-10-26 07:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 07:10:58 --> Controller Class Initialized
DEBUG - 2016-10-26 07:10:58 --> login MX_Controller Initialized
INFO - 2016-10-26 07:10:58 --> Model Class Initialized
INFO - 2016-10-26 07:10:58 --> Model Class Initialized
DEBUG - 2016-10-26 07:10:58 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/login.php
INFO - 2016-10-26 07:10:58 --> Final output sent to browser
DEBUG - 2016-10-26 07:10:58 --> Total execution time: 0.5133
INFO - 2016-10-26 07:11:03 --> Config Class Initialized
INFO - 2016-10-26 07:11:03 --> Hooks Class Initialized
DEBUG - 2016-10-26 07:11:03 --> UTF-8 Support Enabled
INFO - 2016-10-26 07:11:03 --> Utf8 Class Initialized
INFO - 2016-10-26 07:11:03 --> URI Class Initialized
INFO - 2016-10-26 07:11:03 --> Router Class Initialized
INFO - 2016-10-26 07:11:03 --> Output Class Initialized
INFO - 2016-10-26 07:11:03 --> Security Class Initialized
DEBUG - 2016-10-26 07:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 07:11:03 --> Input Class Initialized
INFO - 2016-10-26 07:11:03 --> Language Class Initialized
INFO - 2016-10-26 07:11:04 --> Language Class Initialized
INFO - 2016-10-26 07:11:04 --> Config Class Initialized
INFO - 2016-10-26 07:11:04 --> Loader Class Initialized
INFO - 2016-10-26 07:11:04 --> Helper loaded: url_helper
INFO - 2016-10-26 07:11:04 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 07:11:04 --> Controller Class Initialized
DEBUG - 2016-10-26 07:11:04 --> login MX_Controller Initialized
INFO - 2016-10-26 07:11:04 --> Model Class Initialized
INFO - 2016-10-26 07:11:04 --> Model Class Initialized
INFO - 2016-10-26 07:11:04 --> Final output sent to browser
DEBUG - 2016-10-26 07:11:04 --> Total execution time: 0.4311
INFO - 2016-10-26 07:11:04 --> Config Class Initialized
INFO - 2016-10-26 07:11:04 --> Hooks Class Initialized
DEBUG - 2016-10-26 07:11:04 --> UTF-8 Support Enabled
INFO - 2016-10-26 07:11:04 --> Utf8 Class Initialized
INFO - 2016-10-26 07:11:04 --> URI Class Initialized
INFO - 2016-10-26 07:11:04 --> Router Class Initialized
INFO - 2016-10-26 07:11:04 --> Output Class Initialized
INFO - 2016-10-26 07:11:04 --> Security Class Initialized
DEBUG - 2016-10-26 07:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 07:11:04 --> Input Class Initialized
INFO - 2016-10-26 07:11:04 --> Language Class Initialized
INFO - 2016-10-26 07:11:04 --> Language Class Initialized
INFO - 2016-10-26 07:11:04 --> Config Class Initialized
INFO - 2016-10-26 07:11:04 --> Loader Class Initialized
INFO - 2016-10-26 07:11:04 --> Helper loaded: url_helper
INFO - 2016-10-26 07:11:04 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 07:11:04 --> Controller Class Initialized
DEBUG - 2016-10-26 07:11:04 --> Index MX_Controller Initialized
INFO - 2016-10-26 07:11:04 --> Model Class Initialized
INFO - 2016-10-26 07:11:04 --> Model Class Initialized
ERROR - 2016-10-26 07:11:04 --> Unable to delete cache file for admin/index
DEBUG - 2016-10-26 07:11:05 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 07:11:05 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 07:11:05 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-26 07:11:05 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/dashboard.php
DEBUG - 2016-10-26 07:11:05 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 07:11:05 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 07:11:05 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:05 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:05 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:05 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:05 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:05 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:05 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:05 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:05 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:05 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:05 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:05 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:05 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:05 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:05 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:05 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:05 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:05 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:05 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:05 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:06 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:06 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:06 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:06 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:06 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:06 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:06 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:06 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:06 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:06 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:06 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:06 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:06 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:06 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:06 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:06 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:06 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:06 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:06 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:06 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:06 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:06 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:06 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:06 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:06 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:06 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:06 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:06 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:06 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:06 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:07 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:07 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:07 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:07 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:07 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:07 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:07 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:07 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:07 --> Database Driver Class Initialized
DEBUG - 2016-10-26 07:11:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 07:11:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 07:11:07 --> Final output sent to browser
DEBUG - 2016-10-26 07:11:07 --> Total execution time: 3.3324
INFO - 2016-10-26 07:11:14 --> Config Class Initialized
INFO - 2016-10-26 07:11:14 --> Hooks Class Initialized
DEBUG - 2016-10-26 07:11:14 --> UTF-8 Support Enabled
INFO - 2016-10-26 07:11:14 --> Utf8 Class Initialized
INFO - 2016-10-26 07:11:14 --> URI Class Initialized
INFO - 2016-10-26 07:11:14 --> Router Class Initialized
INFO - 2016-10-26 07:11:14 --> Output Class Initialized
INFO - 2016-10-26 07:11:14 --> Security Class Initialized
DEBUG - 2016-10-26 07:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 07:11:14 --> Input Class Initialized
INFO - 2016-10-26 07:11:14 --> Language Class Initialized
INFO - 2016-10-26 07:11:14 --> Language Class Initialized
INFO - 2016-10-26 07:11:14 --> Config Class Initialized
INFO - 2016-10-26 07:11:14 --> Loader Class Initialized
INFO - 2016-10-26 07:11:15 --> Helper loaded: url_helper
INFO - 2016-10-26 07:11:15 --> Database Driver Class Initialized
INFO - 2016-10-26 07:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 07:11:15 --> Controller Class Initialized
DEBUG - 2016-10-26 07:11:15 --> Index MX_Controller Initialized
INFO - 2016-10-26 07:11:15 --> Model Class Initialized
INFO - 2016-10-26 07:11:15 --> Model Class Initialized
ERROR - 2016-10-26 07:11:15 --> Unable to delete cache file for admin/index/toPdf
ERROR - 2016-10-26 07:11:15 --> Severity: Notice --> Undefined variable: type E:\SERVER\htdocs\kops\application\views\main_html\content\list_anggota.php 15
ERROR - 2016-10-26 07:11:15 --> Severity: Notice --> Undefined variable: type E:\SERVER\htdocs\kops\application\views\main_html\content\list_anggota.php 36
DEBUG - 2016-10-26 07:11:15 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-26 07:11:15 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-26 07:11:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
ERROR - 2016-10-26 07:11:15 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5132
ERROR - 2016-10-26 07:11:15 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5140
ERROR - 2016-10-26 07:11:15 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5140
ERROR - 2016-10-26 07:11:15 --> Severity: Notice --> Undefined index: td_x E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:15 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5450
ERROR - 2016-10-26 07:11:16 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5487
ERROR - 2016-10-26 07:11:16 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5450
ERROR - 2016-10-26 07:11:16 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5487
ERROR - 2016-10-26 07:11:16 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5450
ERROR - 2016-10-26 07:11:16 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5487
ERROR - 2016-10-26 07:11:16 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5450
ERROR - 2016-10-26 07:11:16 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5487
ERROR - 2016-10-26 07:11:16 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5450
ERROR - 2016-10-26 07:11:16 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5487
ERROR - 2016-10-26 07:11:16 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5450
ERROR - 2016-10-26 07:11:16 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5487
ERROR - 2016-10-26 07:11:16 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5450
ERROR - 2016-10-26 07:11:16 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5487
ERROR - 2016-10-26 07:11:16 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5450
ERROR - 2016-10-26 07:11:16 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5487
ERROR - 2016-10-26 07:11:16 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5450
ERROR - 2016-10-26 07:11:16 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5487
ERROR - 2016-10-26 07:11:16 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5258
ERROR - 2016-10-26 07:11:16 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:16 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:16 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:16 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:16 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:16 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:16 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:16 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:16 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:16 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:17 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:17 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:17 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:17 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:17 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:17 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:17 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:17 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:17 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:17 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:17 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:17 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:17 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:17 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:17 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:17 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:17 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:17 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:17 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:17 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:17 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:17 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:17 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:17 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:17 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:17 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:17 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:17 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:17 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:17 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:17 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:17 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:17 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:17 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:17 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:17 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:17 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:18 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:18 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:18 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:18 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:18 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:18 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:18 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:18 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:18 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:18 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:18 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:18 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:18 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:18 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:18 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:18 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:18 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5250
ERROR - 2016-10-26 07:11:18 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5132
ERROR - 2016-10-26 07:11:18 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:18 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:18 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:18 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:18 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:18 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:18 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:18 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:18 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:18 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:18 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:18 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:18 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:18 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:18 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:18 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:18 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:18 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:18 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:18 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:18 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:18 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:19 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:19 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:19 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:19 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:19 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:19 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:19 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:19 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:19 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:19 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:19 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:19 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:19 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:19 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:19 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:19 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:19 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:19 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:19 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:19 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:19 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:19 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:19 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:19 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:19 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:19 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:19 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:19 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:19 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:19 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:19 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:19 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:19 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:19 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:19 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:20 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:20 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:20 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:20 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:20 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:20 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:20 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5250
ERROR - 2016-10-26 07:11:20 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5010
ERROR - 2016-10-26 07:11:20 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5010
ERROR - 2016-10-26 07:11:20 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5132
ERROR - 2016-10-26 07:11:20 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:20 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:20 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:20 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:20 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:20 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:20 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:20 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:20 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:20 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:20 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:20 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:20 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:20 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:20 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:21 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:21 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:21 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:21 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:21 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:21 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:21 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:21 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:21 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:21 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:21 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:21 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:21 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:21 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:21 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:21 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:21 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:21 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:21 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:21 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:21 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:21 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:21 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:21 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:21 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:21 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:21 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:22 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:22 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:22 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:22 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:22 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:22 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:22 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:22 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:22 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:22 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:22 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:22 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:22 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:22 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:22 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:22 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:22 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:22 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:22 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:22 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:22 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:22 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5250
ERROR - 2016-10-26 07:11:22 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5132
ERROR - 2016-10-26 07:11:22 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:22 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:22 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:22 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:22 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:23 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:23 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:23 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:23 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:23 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:23 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:23 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:23 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:23 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:23 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:23 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:23 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:23 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:23 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:23 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:23 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:23 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:23 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:23 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:23 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:23 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:23 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:23 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:23 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:23 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:23 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:23 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:23 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:23 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:23 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:23 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:24 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:24 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:24 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:24 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:24 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:24 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:24 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:24 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:24 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:24 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:24 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:24 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:24 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:24 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:24 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:24 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:24 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:24 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:24 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:24 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:24 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:24 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:24 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:24 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:24 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:24 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:24 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:24 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5250
ERROR - 2016-10-26 07:11:25 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5132
ERROR - 2016-10-26 07:11:25 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5140
ERROR - 2016-10-26 07:11:25 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5140
ERROR - 2016-10-26 07:11:25 --> Severity: Notice --> Undefined index: td_x E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:25 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5450
ERROR - 2016-10-26 07:11:25 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5487
ERROR - 2016-10-26 07:11:25 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5450
ERROR - 2016-10-26 07:11:25 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5487
ERROR - 2016-10-26 07:11:25 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5450
ERROR - 2016-10-26 07:11:25 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5487
ERROR - 2016-10-26 07:11:25 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5450
ERROR - 2016-10-26 07:11:25 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5487
ERROR - 2016-10-26 07:11:25 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5450
ERROR - 2016-10-26 07:11:25 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5487
ERROR - 2016-10-26 07:11:25 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5450
ERROR - 2016-10-26 07:11:25 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5487
ERROR - 2016-10-26 07:11:25 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5450
ERROR - 2016-10-26 07:11:25 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5487
ERROR - 2016-10-26 07:11:25 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5450
ERROR - 2016-10-26 07:11:25 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5487
ERROR - 2016-10-26 07:11:25 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5450
ERROR - 2016-10-26 07:11:25 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5487
ERROR - 2016-10-26 07:11:25 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5258
ERROR - 2016-10-26 07:11:25 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:25 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:25 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:25 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:25 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:25 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:25 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:25 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:26 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:26 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:26 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:26 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:26 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:26 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:26 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:26 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:26 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:26 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:26 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:26 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:26 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:26 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:26 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:26 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:26 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:26 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:26 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:26 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:26 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:26 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:26 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:26 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:26 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:26 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:26 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:26 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:26 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:26 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:26 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:26 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:27 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:27 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:27 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:27 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:27 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:27 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:27 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:27 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:27 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:27 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:27 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:27 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:27 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:27 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:27 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:27 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:27 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:27 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:27 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:27 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:27 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:27 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:27 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:27 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5250
ERROR - 2016-10-26 07:11:27 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5132
ERROR - 2016-10-26 07:11:27 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:27 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:27 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:28 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:28 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:28 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:28 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:28 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:28 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:28 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:28 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:28 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:28 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:28 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:28 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:28 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:28 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:28 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:28 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:28 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:28 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:28 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:28 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:28 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:28 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:28 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:28 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:28 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:28 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:28 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:29 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:29 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:29 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:29 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:29 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:29 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:29 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:29 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:29 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:29 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:29 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:29 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:29 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:29 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:29 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:29 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:29 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:29 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:29 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:29 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:29 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:29 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:29 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:29 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:29 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:29 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:29 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:30 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:30 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:30 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:30 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:30 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:30 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:30 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5250
ERROR - 2016-10-26 07:11:30 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5010
ERROR - 2016-10-26 07:11:30 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5010
ERROR - 2016-10-26 07:11:30 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5132
ERROR - 2016-10-26 07:11:30 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:30 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:30 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:30 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:30 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:30 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:30 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:30 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:30 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:30 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:30 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:30 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:31 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:31 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:31 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:31 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:31 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:31 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:31 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:31 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:31 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:31 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:31 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:31 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:31 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:31 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:31 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:31 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:31 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:31 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:31 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:31 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:31 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:31 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:31 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:31 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:31 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:31 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:32 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:32 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:32 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:32 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:32 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:32 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:32 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:32 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:32 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:32 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:32 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:32 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:32 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:32 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:32 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:32 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:32 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:32 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:32 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:32 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:32 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:32 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:32 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:32 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:32 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:32 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5250
ERROR - 2016-10-26 07:11:32 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5132
ERROR - 2016-10-26 07:11:32 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:32 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:33 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:33 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:33 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:33 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:33 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:33 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:33 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:33 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:33 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:33 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:33 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:33 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:33 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:33 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:33 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:33 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:33 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:33 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:33 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:33 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:33 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:33 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:33 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:33 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:33 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:33 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:33 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:33 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:33 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:33 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:33 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:34 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:34 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:34 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:34 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:34 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:34 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:34 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:34 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:34 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:34 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:34 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:34 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:34 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:34 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:34 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:34 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:34 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:34 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:34 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:34 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:34 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:34 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:34 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:34 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:34 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:34 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:34 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:35 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:35 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:35 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:35 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5250
ERROR - 2016-10-26 07:11:35 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5132
ERROR - 2016-10-26 07:11:35 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5140
ERROR - 2016-10-26 07:11:35 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5140
ERROR - 2016-10-26 07:11:35 --> Severity: Notice --> Undefined index: td_x E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:35 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5450
ERROR - 2016-10-26 07:11:35 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5487
ERROR - 2016-10-26 07:11:35 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5450
ERROR - 2016-10-26 07:11:35 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5487
ERROR - 2016-10-26 07:11:35 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5450
ERROR - 2016-10-26 07:11:35 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5487
ERROR - 2016-10-26 07:11:35 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5450
ERROR - 2016-10-26 07:11:35 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5487
ERROR - 2016-10-26 07:11:35 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5450
ERROR - 2016-10-26 07:11:35 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5487
ERROR - 2016-10-26 07:11:35 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5450
ERROR - 2016-10-26 07:11:36 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5487
ERROR - 2016-10-26 07:11:36 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5450
ERROR - 2016-10-26 07:11:36 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5487
ERROR - 2016-10-26 07:11:36 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5450
ERROR - 2016-10-26 07:11:36 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5487
ERROR - 2016-10-26 07:11:36 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5450
ERROR - 2016-10-26 07:11:36 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5487
ERROR - 2016-10-26 07:11:36 --> Severity: Notice --> Undefined index: td_y E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5258
ERROR - 2016-10-26 07:11:36 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:36 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:36 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:36 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:36 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:36 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:36 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:36 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:36 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:36 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:36 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:36 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:36 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:36 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:36 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:36 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:36 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:36 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:36 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:36 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:36 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:36 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:36 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:37 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:37 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:37 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:37 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:37 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:37 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:37 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:37 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:37 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:37 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:37 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:37 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:37 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:37 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:37 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:37 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:37 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:37 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:37 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:37 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:37 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:37 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:37 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:37 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:37 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:37 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:37 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:37 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:37 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:37 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:37 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:38 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:38 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:38 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:38 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:38 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:38 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:38 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:38 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:38 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:38 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5250
ERROR - 2016-10-26 07:11:38 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5132
ERROR - 2016-10-26 07:11:38 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:38 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:38 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:38 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:38 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:38 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:38 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:38 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:38 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:38 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:38 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:38 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:38 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:38 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:38 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:38 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:38 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:38 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:38 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:38 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:39 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:39 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:39 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:39 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:39 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:39 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:39 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:39 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:39 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:39 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:39 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:39 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:39 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:39 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:39 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:39 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:39 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:39 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:39 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:39 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:39 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:39 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:39 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:39 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:39 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:39 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:39 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:39 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:39 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:39 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:39 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:39 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:40 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:40 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:40 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:40 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:40 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:40 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:40 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:40 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:40 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:40 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:40 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:40 --> Severity: Notice --> Undefined offset: 3 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5250
ERROR - 2016-10-26 07:11:40 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5010
ERROR - 2016-10-26 07:11:40 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5010
ERROR - 2016-10-26 07:11:40 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5132
ERROR - 2016-10-26 07:11:40 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:40 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:40 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:40 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:40 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:40 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:40 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:40 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:40 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:40 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:40 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:41 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:41 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:41 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:41 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:41 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:41 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:41 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:41 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:41 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:41 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:41 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:41 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:41 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:41 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:41 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:41 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:41 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:41 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:41 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:41 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:41 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:41 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:41 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:41 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:41 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:41 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:41 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:41 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:41 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:41 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:41 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:41 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:42 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:42 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:42 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:42 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:42 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:42 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:42 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:42 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:42 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:42 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:42 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:42 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:42 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:42 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:42 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:42 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:42 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:42 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:42 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:42 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:42 --> Severity: Notice --> Undefined offset: 1 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5250
ERROR - 2016-10-26 07:11:42 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5132
ERROR - 2016-10-26 07:11:42 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:42 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:42 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:42 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:42 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:42 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:42 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:42 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:42 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:43 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:43 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:43 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:43 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:43 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:43 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:43 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:43 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:43 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:43 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:43 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:43 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:43 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:43 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:43 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:43 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:43 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:43 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:43 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:43 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:43 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:43 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:43 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:43 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:43 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:43 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:43 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:43 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:43 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:44 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:44 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:44 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:44 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:44 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:44 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:44 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:44 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:44 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5467
ERROR - 2016-10-26 07:11:44 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5468
ERROR - 2016-10-26 07:11:44 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5548
ERROR - 2016-10-26 07:11:44 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5445
ERROR - 2016-10-26 07:11:44 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5451
ERROR - 2016-10-26 07:11:44 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5452
ERROR - 2016-10-26 07:11:44 --> Severity: Notice --> Undefined offset: 2 E:\SERVER\htdocs\kops\assets\html2pdf\html2pdf.class.php 5459
ERROR - 2016-10-26 07:11:44 --> Severity: Error --> Maximum execution time of 30 seconds exceeded E:\SERVER\htdocs\kops\system\core\Log.php 222
INFO - 2016-10-26 07:12:37 --> Config Class Initialized
INFO - 2016-10-26 07:12:37 --> Hooks Class Initialized
DEBUG - 2016-10-26 07:12:37 --> UTF-8 Support Enabled
INFO - 2016-10-26 07:12:37 --> Utf8 Class Initialized
INFO - 2016-10-26 07:12:37 --> URI Class Initialized
INFO - 2016-10-26 07:12:37 --> Router Class Initialized
INFO - 2016-10-26 07:12:37 --> Output Class Initialized
INFO - 2016-10-26 07:12:37 --> Security Class Initialized
DEBUG - 2016-10-26 07:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 07:12:37 --> Input Class Initialized
INFO - 2016-10-26 07:12:37 --> Language Class Initialized
INFO - 2016-10-26 07:12:37 --> Language Class Initialized
INFO - 2016-10-26 07:12:37 --> Config Class Initialized
INFO - 2016-10-26 07:12:37 --> Loader Class Initialized
INFO - 2016-10-26 07:12:37 --> Helper loaded: url_helper
INFO - 2016-10-26 07:12:37 --> Database Driver Class Initialized
INFO - 2016-10-26 07:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 07:12:37 --> Controller Class Initialized
DEBUG - 2016-10-26 07:12:37 --> Index MX_Controller Initialized
INFO - 2016-10-26 07:12:37 --> Model Class Initialized
INFO - 2016-10-26 07:12:38 --> Model Class Initialized
ERROR - 2016-10-26 07:12:38 --> Unable to delete cache file for admin/index/toPdf
INFO - 2016-10-26 07:13:47 --> Config Class Initialized
INFO - 2016-10-26 07:13:47 --> Hooks Class Initialized
DEBUG - 2016-10-26 07:13:47 --> UTF-8 Support Enabled
INFO - 2016-10-26 07:13:47 --> Utf8 Class Initialized
INFO - 2016-10-26 07:13:47 --> URI Class Initialized
INFO - 2016-10-26 07:13:47 --> Router Class Initialized
INFO - 2016-10-26 07:13:47 --> Output Class Initialized
INFO - 2016-10-26 07:13:47 --> Security Class Initialized
DEBUG - 2016-10-26 07:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 07:13:48 --> Input Class Initialized
INFO - 2016-10-26 07:13:48 --> Language Class Initialized
INFO - 2016-10-26 07:13:48 --> Language Class Initialized
INFO - 2016-10-26 07:13:48 --> Config Class Initialized
INFO - 2016-10-26 07:13:48 --> Loader Class Initialized
INFO - 2016-10-26 07:13:48 --> Helper loaded: url_helper
INFO - 2016-10-26 07:13:48 --> Database Driver Class Initialized
INFO - 2016-10-26 07:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 07:13:48 --> Controller Class Initialized
DEBUG - 2016-10-26 07:13:48 --> Index MX_Controller Initialized
INFO - 2016-10-26 07:13:48 --> Model Class Initialized
INFO - 2016-10-26 07:13:48 --> Model Class Initialized
ERROR - 2016-10-26 07:13:48 --> Unable to delete cache file for admin/index/toPdf
INFO - 2016-10-26 07:14:11 --> Config Class Initialized
INFO - 2016-10-26 07:14:11 --> Hooks Class Initialized
DEBUG - 2016-10-26 07:14:11 --> UTF-8 Support Enabled
INFO - 2016-10-26 07:14:11 --> Utf8 Class Initialized
INFO - 2016-10-26 07:14:11 --> URI Class Initialized
INFO - 2016-10-26 07:14:11 --> Router Class Initialized
INFO - 2016-10-26 07:14:11 --> Output Class Initialized
INFO - 2016-10-26 07:14:11 --> Security Class Initialized
DEBUG - 2016-10-26 07:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 07:14:11 --> Input Class Initialized
INFO - 2016-10-26 07:14:11 --> Language Class Initialized
INFO - 2016-10-26 07:14:11 --> Language Class Initialized
INFO - 2016-10-26 07:14:11 --> Config Class Initialized
INFO - 2016-10-26 07:14:11 --> Loader Class Initialized
INFO - 2016-10-26 07:14:11 --> Helper loaded: url_helper
INFO - 2016-10-26 07:14:11 --> Database Driver Class Initialized
INFO - 2016-10-26 07:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 07:14:11 --> Controller Class Initialized
DEBUG - 2016-10-26 07:14:11 --> Index MX_Controller Initialized
INFO - 2016-10-26 07:14:11 --> Model Class Initialized
INFO - 2016-10-26 07:14:12 --> Model Class Initialized
ERROR - 2016-10-26 07:14:12 --> Unable to delete cache file for admin/index/toPdf
DEBUG - 2016-10-26 07:14:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/perjanijan.php
INFO - 2016-10-26 07:14:32 --> Final output sent to browser
DEBUG - 2016-10-26 07:14:33 --> Total execution time: 21.6386
INFO - 2016-10-26 07:16:41 --> Config Class Initialized
INFO - 2016-10-26 07:16:41 --> Hooks Class Initialized
DEBUG - 2016-10-26 07:16:41 --> UTF-8 Support Enabled
INFO - 2016-10-26 07:16:41 --> Utf8 Class Initialized
INFO - 2016-10-26 07:16:41 --> URI Class Initialized
INFO - 2016-10-26 07:16:41 --> Router Class Initialized
INFO - 2016-10-26 07:16:41 --> Output Class Initialized
INFO - 2016-10-26 07:16:41 --> Security Class Initialized
DEBUG - 2016-10-26 07:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 07:16:41 --> Input Class Initialized
INFO - 2016-10-26 07:16:41 --> Language Class Initialized
INFO - 2016-10-26 07:16:41 --> Language Class Initialized
INFO - 2016-10-26 07:16:41 --> Config Class Initialized
INFO - 2016-10-26 07:16:41 --> Loader Class Initialized
INFO - 2016-10-26 07:16:41 --> Helper loaded: url_helper
INFO - 2016-10-26 07:16:41 --> Database Driver Class Initialized
INFO - 2016-10-26 07:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 07:16:42 --> Controller Class Initialized
DEBUG - 2016-10-26 07:16:42 --> Index MX_Controller Initialized
INFO - 2016-10-26 07:16:42 --> Model Class Initialized
INFO - 2016-10-26 07:16:42 --> Model Class Initialized
ERROR - 2016-10-26 07:16:42 --> Unable to delete cache file for admin/index/toPdf
DEBUG - 2016-10-26 07:16:42 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/perjanijan.php
INFO - 2016-10-26 07:16:56 --> Final output sent to browser
DEBUG - 2016-10-26 07:16:56 --> Total execution time: 14.9086
INFO - 2016-10-26 07:16:56 --> Config Class Initialized
INFO - 2016-10-26 07:16:56 --> Hooks Class Initialized
DEBUG - 2016-10-26 07:16:56 --> UTF-8 Support Enabled
INFO - 2016-10-26 07:16:56 --> Utf8 Class Initialized
INFO - 2016-10-26 07:16:56 --> URI Class Initialized
INFO - 2016-10-26 07:16:56 --> Router Class Initialized
INFO - 2016-10-26 07:16:56 --> Output Class Initialized
INFO - 2016-10-26 07:16:56 --> Security Class Initialized
DEBUG - 2016-10-26 07:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 07:16:56 --> Input Class Initialized
INFO - 2016-10-26 07:16:56 --> Language Class Initialized
INFO - 2016-10-26 07:16:56 --> Language Class Initialized
INFO - 2016-10-26 07:16:56 --> Config Class Initialized
INFO - 2016-10-26 07:16:56 --> Loader Class Initialized
INFO - 2016-10-26 07:16:56 --> Helper loaded: url_helper
INFO - 2016-10-26 07:16:57 --> Database Driver Class Initialized
INFO - 2016-10-26 07:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 07:16:57 --> Controller Class Initialized
DEBUG - 2016-10-26 07:16:57 --> Index MX_Controller Initialized
INFO - 2016-10-26 07:16:57 --> Model Class Initialized
INFO - 2016-10-26 07:16:57 --> Model Class Initialized
ERROR - 2016-10-26 07:16:57 --> Unable to delete cache file for admin/index/toPdf
DEBUG - 2016-10-26 07:16:57 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/perjanijan.php
INFO - 2016-10-26 07:17:16 --> Final output sent to browser
DEBUG - 2016-10-26 07:17:16 --> Total execution time: 19.8857
INFO - 2016-10-26 13:22:54 --> Config Class Initialized
INFO - 2016-10-26 13:22:54 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:22:54 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:22:54 --> Utf8 Class Initialized
INFO - 2016-10-26 13:22:54 --> URI Class Initialized
DEBUG - 2016-10-26 13:22:54 --> No URI present. Default controller set.
INFO - 2016-10-26 13:22:54 --> Router Class Initialized
INFO - 2016-10-26 13:22:54 --> Output Class Initialized
INFO - 2016-10-26 13:22:54 --> Security Class Initialized
DEBUG - 2016-10-26 13:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:22:54 --> Input Class Initialized
INFO - 2016-10-26 13:22:54 --> Language Class Initialized
INFO - 2016-10-26 13:22:54 --> Language Class Initialized
INFO - 2016-10-26 13:22:55 --> Config Class Initialized
INFO - 2016-10-26 13:22:55 --> Loader Class Initialized
INFO - 2016-10-26 13:22:55 --> Helper loaded: url_helper
INFO - 2016-10-26 13:22:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:22:55 --> Controller Class Initialized
DEBUG - 2016-10-26 13:22:55 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:22:55 --> Model Class Initialized
INFO - 2016-10-26 13:22:55 --> Model Class Initialized
ERROR - 2016-10-26 13:22:55 --> Unable to delete cache file for 
DEBUG - 2016-10-26 13:22:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 13:22:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 13:22:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-26 13:22:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/dashboard.php
DEBUG - 2016-10-26 13:22:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 13:22:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 13:22:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:57 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:57 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:57 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:57 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:57 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:57 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:57 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:57 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:57 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:57 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:22:57 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 13:22:57 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 13:22:57 --> Final output sent to browser
INFO - 2016-10-26 13:22:57 --> Config Class Initialized
INFO - 2016-10-26 13:22:57 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:22:57 --> Total execution time: 2.8305
DEBUG - 2016-10-26 13:22:57 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:22:57 --> Utf8 Class Initialized
INFO - 2016-10-26 13:22:57 --> URI Class Initialized
INFO - 2016-10-26 13:22:57 --> Router Class Initialized
INFO - 2016-10-26 13:22:57 --> Output Class Initialized
INFO - 2016-10-26 13:22:57 --> Security Class Initialized
DEBUG - 2016-10-26 13:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:22:57 --> Input Class Initialized
INFO - 2016-10-26 13:22:57 --> Language Class Initialized
INFO - 2016-10-26 13:22:57 --> Language Class Initialized
INFO - 2016-10-26 13:22:57 --> Config Class Initialized
INFO - 2016-10-26 13:22:57 --> Loader Class Initialized
INFO - 2016-10-26 13:22:57 --> Helper loaded: url_helper
INFO - 2016-10-26 13:22:57 --> Database Driver Class Initialized
INFO - 2016-10-26 13:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:22:58 --> Controller Class Initialized
DEBUG - 2016-10-26 13:22:58 --> login MX_Controller Initialized
INFO - 2016-10-26 13:22:58 --> Model Class Initialized
INFO - 2016-10-26 13:22:58 --> Model Class Initialized
DEBUG - 2016-10-26 13:22:58 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/login.php
INFO - 2016-10-26 13:22:58 --> Final output sent to browser
DEBUG - 2016-10-26 13:22:58 --> Total execution time: 0.7264
INFO - 2016-10-26 13:23:15 --> Config Class Initialized
INFO - 2016-10-26 13:23:15 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:23:15 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:23:15 --> Utf8 Class Initialized
INFO - 2016-10-26 13:23:15 --> URI Class Initialized
INFO - 2016-10-26 13:23:15 --> Router Class Initialized
INFO - 2016-10-26 13:23:15 --> Output Class Initialized
INFO - 2016-10-26 13:23:15 --> Security Class Initialized
DEBUG - 2016-10-26 13:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:23:15 --> Input Class Initialized
INFO - 2016-10-26 13:23:15 --> Language Class Initialized
INFO - 2016-10-26 13:23:15 --> Language Class Initialized
INFO - 2016-10-26 13:23:15 --> Config Class Initialized
INFO - 2016-10-26 13:23:15 --> Loader Class Initialized
INFO - 2016-10-26 13:23:15 --> Helper loaded: url_helper
INFO - 2016-10-26 13:23:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:23:15 --> Controller Class Initialized
DEBUG - 2016-10-26 13:23:15 --> login MX_Controller Initialized
INFO - 2016-10-26 13:23:15 --> Model Class Initialized
INFO - 2016-10-26 13:23:15 --> Model Class Initialized
INFO - 2016-10-26 13:23:15 --> Final output sent to browser
DEBUG - 2016-10-26 13:23:15 --> Total execution time: 0.5442
INFO - 2016-10-26 13:23:16 --> Config Class Initialized
INFO - 2016-10-26 13:23:16 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:23:16 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:23:16 --> Utf8 Class Initialized
INFO - 2016-10-26 13:23:16 --> URI Class Initialized
INFO - 2016-10-26 13:23:16 --> Router Class Initialized
INFO - 2016-10-26 13:23:16 --> Output Class Initialized
INFO - 2016-10-26 13:23:16 --> Security Class Initialized
DEBUG - 2016-10-26 13:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:23:16 --> Input Class Initialized
INFO - 2016-10-26 13:23:16 --> Language Class Initialized
INFO - 2016-10-26 13:23:16 --> Language Class Initialized
INFO - 2016-10-26 13:23:16 --> Config Class Initialized
INFO - 2016-10-26 13:23:16 --> Loader Class Initialized
INFO - 2016-10-26 13:23:16 --> Helper loaded: url_helper
INFO - 2016-10-26 13:23:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:23:16 --> Controller Class Initialized
DEBUG - 2016-10-26 13:23:16 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:23:16 --> Model Class Initialized
INFO - 2016-10-26 13:23:16 --> Model Class Initialized
ERROR - 2016-10-26 13:23:16 --> Unable to delete cache file for admin/index
DEBUG - 2016-10-26 13:23:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 13:23:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 13:23:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-26 13:23:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/dashboard.php
DEBUG - 2016-10-26 13:23:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 13:23:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 13:23:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:19 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:19 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:19 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:19 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:23:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 13:23:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 13:23:19 --> Final output sent to browser
DEBUG - 2016-10-26 13:23:19 --> Total execution time: 3.1469
INFO - 2016-10-26 13:23:34 --> Config Class Initialized
INFO - 2016-10-26 13:23:34 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:23:34 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:23:34 --> Utf8 Class Initialized
INFO - 2016-10-26 13:23:34 --> URI Class Initialized
INFO - 2016-10-26 13:23:34 --> Router Class Initialized
INFO - 2016-10-26 13:23:34 --> Output Class Initialized
INFO - 2016-10-26 13:23:34 --> Security Class Initialized
DEBUG - 2016-10-26 13:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:23:34 --> Input Class Initialized
INFO - 2016-10-26 13:23:34 --> Language Class Initialized
INFO - 2016-10-26 13:23:34 --> Language Class Initialized
INFO - 2016-10-26 13:23:34 --> Config Class Initialized
INFO - 2016-10-26 13:23:34 --> Loader Class Initialized
INFO - 2016-10-26 13:23:34 --> Helper loaded: url_helper
INFO - 2016-10-26 13:23:34 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:23:34 --> Controller Class Initialized
DEBUG - 2016-10-26 13:23:34 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:23:34 --> Model Class Initialized
INFO - 2016-10-26 13:23:34 --> Model Class Initialized
ERROR - 2016-10-26 13:23:34 --> Unable to delete cache file for admin/index/data_peminjam
DEBUG - 2016-10-26 13:23:34 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 13:23:34 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 13:23:34 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-26 13:23:34 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_peminjam.php
DEBUG - 2016-10-26 13:23:34 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 13:23:34 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 13:23:34 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:35 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:35 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:35 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:35 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:35 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:35 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:35 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:35 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:35 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:35 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:35 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:35 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:35 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:35 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:35 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:35 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:35 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:35 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:35 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:35 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:35 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:35 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:35 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:35 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:35 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:35 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:35 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:36 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:36 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:36 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:36 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:36 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:36 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:36 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:36 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:36 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:36 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:36 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:36 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:36 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:36 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:36 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:36 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:36 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:36 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:36 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:36 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:36 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:36 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:36 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:36 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:36 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:36 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:37 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:37 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:37 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:37 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:37 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:23:37 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 13:23:37 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 13:23:37 --> Final output sent to browser
DEBUG - 2016-10-26 13:23:37 --> Total execution time: 3.1846
INFO - 2016-10-26 13:23:41 --> Config Class Initialized
INFO - 2016-10-26 13:23:41 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:23:41 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:23:41 --> Utf8 Class Initialized
INFO - 2016-10-26 13:23:41 --> URI Class Initialized
INFO - 2016-10-26 13:23:41 --> Router Class Initialized
INFO - 2016-10-26 13:23:41 --> Output Class Initialized
INFO - 2016-10-26 13:23:41 --> Security Class Initialized
DEBUG - 2016-10-26 13:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:23:41 --> Input Class Initialized
INFO - 2016-10-26 13:23:41 --> Language Class Initialized
INFO - 2016-10-26 13:23:41 --> Language Class Initialized
INFO - 2016-10-26 13:23:41 --> Config Class Initialized
INFO - 2016-10-26 13:23:41 --> Loader Class Initialized
INFO - 2016-10-26 13:23:42 --> Helper loaded: url_helper
INFO - 2016-10-26 13:23:42 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:23:42 --> Controller Class Initialized
DEBUG - 2016-10-26 13:23:42 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:23:42 --> Model Class Initialized
INFO - 2016-10-26 13:23:42 --> Model Class Initialized
ERROR - 2016-10-26 13:23:42 --> Unable to delete cache file for admin/index/getDataPeminjam
DEBUG - 2016-10-26 13:23:42 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-10-26 13:23:42 --> Final output sent to browser
DEBUG - 2016-10-26 13:23:42 --> Total execution time: 0.7159
INFO - 2016-10-26 13:23:42 --> Config Class Initialized
INFO - 2016-10-26 13:23:42 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:23:42 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:23:42 --> Utf8 Class Initialized
INFO - 2016-10-26 13:23:42 --> URI Class Initialized
INFO - 2016-10-26 13:23:42 --> Router Class Initialized
INFO - 2016-10-26 13:23:42 --> Output Class Initialized
INFO - 2016-10-26 13:23:42 --> Security Class Initialized
DEBUG - 2016-10-26 13:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:23:42 --> Input Class Initialized
INFO - 2016-10-26 13:23:42 --> Language Class Initialized
INFO - 2016-10-26 13:23:42 --> Language Class Initialized
INFO - 2016-10-26 13:23:42 --> Config Class Initialized
INFO - 2016-10-26 13:23:42 --> Loader Class Initialized
INFO - 2016-10-26 13:23:42 --> Helper loaded: url_helper
INFO - 2016-10-26 13:23:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:23:43 --> Controller Class Initialized
DEBUG - 2016-10-26 13:23:43 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:23:43 --> Model Class Initialized
INFO - 2016-10-26 13:23:43 --> Model Class Initialized
ERROR - 2016-10-26 13:23:43 --> Unable to delete cache file for admin/index/getDataPeminjam/umum
DEBUG - 2016-10-26 13:23:43 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-10-26 13:23:43 --> Final output sent to browser
DEBUG - 2016-10-26 13:23:43 --> Total execution time: 0.6450
INFO - 2016-10-26 13:23:46 --> Config Class Initialized
INFO - 2016-10-26 13:23:46 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:23:46 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:23:46 --> Utf8 Class Initialized
INFO - 2016-10-26 13:23:46 --> URI Class Initialized
INFO - 2016-10-26 13:23:46 --> Router Class Initialized
INFO - 2016-10-26 13:23:46 --> Output Class Initialized
INFO - 2016-10-26 13:23:46 --> Security Class Initialized
DEBUG - 2016-10-26 13:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:23:46 --> Input Class Initialized
INFO - 2016-10-26 13:23:46 --> Language Class Initialized
INFO - 2016-10-26 13:23:46 --> Language Class Initialized
INFO - 2016-10-26 13:23:47 --> Config Class Initialized
INFO - 2016-10-26 13:23:47 --> Loader Class Initialized
INFO - 2016-10-26 13:23:47 --> Helper loaded: url_helper
INFO - 2016-10-26 13:23:47 --> Database Driver Class Initialized
INFO - 2016-10-26 13:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:23:47 --> Controller Class Initialized
DEBUG - 2016-10-26 13:23:47 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:23:47 --> Model Class Initialized
INFO - 2016-10-26 13:23:47 --> Model Class Initialized
ERROR - 2016-10-26 13:23:47 --> Unable to delete cache file for admin/index/detail_pinjaman/5b384ce32d8cdef02bc3a139d4cac0a22bb029e8
DEBUG - 2016-10-26 13:23:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/subcontent/data_transaksi.php
INFO - 2016-10-26 13:23:47 --> Final output sent to browser
DEBUG - 2016-10-26 13:23:47 --> Total execution time: 1.0688
INFO - 2016-10-26 13:24:01 --> Config Class Initialized
INFO - 2016-10-26 13:24:01 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:24:01 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:24:01 --> Utf8 Class Initialized
INFO - 2016-10-26 13:24:01 --> URI Class Initialized
INFO - 2016-10-26 13:24:01 --> Router Class Initialized
INFO - 2016-10-26 13:24:01 --> Output Class Initialized
INFO - 2016-10-26 13:24:01 --> Security Class Initialized
DEBUG - 2016-10-26 13:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:24:01 --> Input Class Initialized
INFO - 2016-10-26 13:24:01 --> Language Class Initialized
INFO - 2016-10-26 13:24:01 --> Language Class Initialized
INFO - 2016-10-26 13:24:01 --> Config Class Initialized
INFO - 2016-10-26 13:24:01 --> Loader Class Initialized
INFO - 2016-10-26 13:24:01 --> Helper loaded: url_helper
INFO - 2016-10-26 13:24:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:24:01 --> Controller Class Initialized
DEBUG - 2016-10-26 13:24:02 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:24:02 --> Model Class Initialized
INFO - 2016-10-26 13:24:02 --> Model Class Initialized
ERROR - 2016-10-26 13:24:02 --> Unable to delete cache file for admin/index/bayar_angsuran
DEBUG - 2016-10-26 13:24:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 13:24:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 13:24:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-26 13:24:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_bayar_angsuran.php
DEBUG - 2016-10-26 13:24:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 13:24:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 13:24:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:04 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:24:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 13:24:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 13:24:04 --> Final output sent to browser
DEBUG - 2016-10-26 13:24:04 --> Total execution time: 3.2331
INFO - 2016-10-26 13:24:11 --> Config Class Initialized
INFO - 2016-10-26 13:24:12 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:24:12 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:24:12 --> Utf8 Class Initialized
INFO - 2016-10-26 13:24:12 --> URI Class Initialized
INFO - 2016-10-26 13:24:12 --> Router Class Initialized
INFO - 2016-10-26 13:24:12 --> Output Class Initialized
INFO - 2016-10-26 13:24:12 --> Security Class Initialized
DEBUG - 2016-10-26 13:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:24:12 --> Input Class Initialized
INFO - 2016-10-26 13:24:12 --> Language Class Initialized
INFO - 2016-10-26 13:24:12 --> Language Class Initialized
INFO - 2016-10-26 13:24:12 --> Config Class Initialized
INFO - 2016-10-26 13:24:12 --> Loader Class Initialized
INFO - 2016-10-26 13:24:12 --> Helper loaded: url_helper
INFO - 2016-10-26 13:24:12 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:24:12 --> Controller Class Initialized
DEBUG - 2016-10-26 13:24:12 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:24:12 --> Model Class Initialized
INFO - 2016-10-26 13:24:12 --> Model Class Initialized
ERROR - 2016-10-26 13:24:12 --> Unable to delete cache file for admin/index/getDetailAngsuran
INFO - 2016-10-26 13:24:12 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:12 --> Final output sent to browser
DEBUG - 2016-10-26 13:24:12 --> Total execution time: 0.7308
INFO - 2016-10-26 13:24:22 --> Config Class Initialized
INFO - 2016-10-26 13:24:22 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:24:22 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:24:22 --> Utf8 Class Initialized
INFO - 2016-10-26 13:24:22 --> URI Class Initialized
INFO - 2016-10-26 13:24:22 --> Router Class Initialized
INFO - 2016-10-26 13:24:22 --> Output Class Initialized
INFO - 2016-10-26 13:24:22 --> Security Class Initialized
DEBUG - 2016-10-26 13:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:24:22 --> Input Class Initialized
INFO - 2016-10-26 13:24:22 --> Language Class Initialized
INFO - 2016-10-26 13:24:22 --> Language Class Initialized
INFO - 2016-10-26 13:24:22 --> Config Class Initialized
INFO - 2016-10-26 13:24:22 --> Loader Class Initialized
INFO - 2016-10-26 13:24:22 --> Helper loaded: url_helper
INFO - 2016-10-26 13:24:22 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:24:22 --> Controller Class Initialized
DEBUG - 2016-10-26 13:24:22 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:24:22 --> Model Class Initialized
INFO - 2016-10-26 13:24:22 --> Model Class Initialized
ERROR - 2016-10-26 13:24:23 --> Unable to delete cache file for admin/index/do_bayar
INFO - 2016-10-26 13:24:23 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:23 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:23 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:23 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:23 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:23 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:23 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:23 --> Final output sent to browser
DEBUG - 2016-10-26 13:24:23 --> Total execution time: 1.1357
INFO - 2016-10-26 13:24:27 --> Config Class Initialized
INFO - 2016-10-26 13:24:27 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:24:27 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:24:27 --> Utf8 Class Initialized
INFO - 2016-10-26 13:24:27 --> URI Class Initialized
INFO - 2016-10-26 13:24:27 --> Router Class Initialized
INFO - 2016-10-26 13:24:27 --> Output Class Initialized
INFO - 2016-10-26 13:24:27 --> Security Class Initialized
DEBUG - 2016-10-26 13:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:24:27 --> Input Class Initialized
INFO - 2016-10-26 13:24:27 --> Language Class Initialized
INFO - 2016-10-26 13:24:27 --> Language Class Initialized
INFO - 2016-10-26 13:24:27 --> Config Class Initialized
INFO - 2016-10-26 13:24:27 --> Loader Class Initialized
INFO - 2016-10-26 13:24:27 --> Helper loaded: url_helper
INFO - 2016-10-26 13:24:28 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:24:28 --> Controller Class Initialized
DEBUG - 2016-10-26 13:24:28 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:24:28 --> Model Class Initialized
INFO - 2016-10-26 13:24:28 --> Model Class Initialized
ERROR - 2016-10-26 13:24:28 --> Unable to delete cache file for admin/index/data_peminjam
DEBUG - 2016-10-26 13:24:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 13:24:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 13:24:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-26 13:24:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_peminjam.php
DEBUG - 2016-10-26 13:24:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 13:24:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 13:24:28 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:28 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:28 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:28 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:28 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:28 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:28 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:28 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:28 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:28 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:28 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:28 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:28 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:28 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:28 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:28 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:28 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:30 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:30 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:30 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:30 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:30 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:30 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:30 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:30 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:30 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:30 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:24:30 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 13:24:30 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 13:24:30 --> Final output sent to browser
DEBUG - 2016-10-26 13:24:30 --> Total execution time: 3.3280
INFO - 2016-10-26 13:24:33 --> Config Class Initialized
INFO - 2016-10-26 13:24:33 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:24:33 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:24:33 --> Utf8 Class Initialized
INFO - 2016-10-26 13:24:33 --> URI Class Initialized
INFO - 2016-10-26 13:24:33 --> Router Class Initialized
INFO - 2016-10-26 13:24:33 --> Output Class Initialized
INFO - 2016-10-26 13:24:33 --> Security Class Initialized
DEBUG - 2016-10-26 13:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:24:33 --> Input Class Initialized
INFO - 2016-10-26 13:24:34 --> Language Class Initialized
INFO - 2016-10-26 13:24:34 --> Language Class Initialized
INFO - 2016-10-26 13:24:34 --> Config Class Initialized
INFO - 2016-10-26 13:24:34 --> Loader Class Initialized
INFO - 2016-10-26 13:24:34 --> Helper loaded: url_helper
INFO - 2016-10-26 13:24:34 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:24:34 --> Controller Class Initialized
DEBUG - 2016-10-26 13:24:34 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:24:34 --> Model Class Initialized
INFO - 2016-10-26 13:24:34 --> Model Class Initialized
ERROR - 2016-10-26 13:24:34 --> Unable to delete cache file for admin/index/getDataPeminjam/umum
DEBUG - 2016-10-26 13:24:34 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-10-26 13:24:34 --> Final output sent to browser
DEBUG - 2016-10-26 13:24:34 --> Total execution time: 0.7908
INFO - 2016-10-26 13:24:37 --> Config Class Initialized
INFO - 2016-10-26 13:24:37 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:24:37 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:24:37 --> Utf8 Class Initialized
INFO - 2016-10-26 13:24:37 --> URI Class Initialized
INFO - 2016-10-26 13:24:37 --> Router Class Initialized
INFO - 2016-10-26 13:24:37 --> Output Class Initialized
INFO - 2016-10-26 13:24:37 --> Security Class Initialized
DEBUG - 2016-10-26 13:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:24:37 --> Input Class Initialized
INFO - 2016-10-26 13:24:37 --> Language Class Initialized
INFO - 2016-10-26 13:24:37 --> Language Class Initialized
INFO - 2016-10-26 13:24:38 --> Config Class Initialized
INFO - 2016-10-26 13:24:38 --> Loader Class Initialized
INFO - 2016-10-26 13:24:38 --> Helper loaded: url_helper
INFO - 2016-10-26 13:24:38 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:24:38 --> Controller Class Initialized
DEBUG - 2016-10-26 13:24:38 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:24:38 --> Model Class Initialized
INFO - 2016-10-26 13:24:38 --> Model Class Initialized
ERROR - 2016-10-26 13:24:38 --> Unable to delete cache file for admin/index/detail_pinjaman/5b384ce32d8cdef02bc3a139d4cac0a22bb029e8
DEBUG - 2016-10-26 13:24:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/subcontent/data_transaksi.php
INFO - 2016-10-26 13:24:38 --> Final output sent to browser
DEBUG - 2016-10-26 13:24:38 --> Total execution time: 1.0051
INFO - 2016-10-26 13:24:51 --> Config Class Initialized
INFO - 2016-10-26 13:24:51 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:24:51 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:24:51 --> Utf8 Class Initialized
INFO - 2016-10-26 13:24:52 --> URI Class Initialized
INFO - 2016-10-26 13:24:52 --> Router Class Initialized
INFO - 2016-10-26 13:24:52 --> Output Class Initialized
INFO - 2016-10-26 13:24:52 --> Security Class Initialized
DEBUG - 2016-10-26 13:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:24:52 --> Input Class Initialized
INFO - 2016-10-26 13:24:52 --> Language Class Initialized
INFO - 2016-10-26 13:24:52 --> Language Class Initialized
INFO - 2016-10-26 13:24:52 --> Config Class Initialized
INFO - 2016-10-26 13:24:52 --> Loader Class Initialized
INFO - 2016-10-26 13:24:52 --> Helper loaded: url_helper
INFO - 2016-10-26 13:24:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:24:52 --> Controller Class Initialized
DEBUG - 2016-10-26 13:24:52 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:24:52 --> Model Class Initialized
INFO - 2016-10-26 13:24:52 --> Model Class Initialized
ERROR - 2016-10-26 13:24:52 --> Unable to delete cache file for admin/index/data/anggota
DEBUG - 2016-10-26 13:24:52 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 13:24:52 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 13:24:52 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-26 13:24:52 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-26 13:24:52 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-26 13:24:52 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-26 13:24:52 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 13:24:52 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 13:24:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:24:54 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:24:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 13:24:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 13:24:54 --> Final output sent to browser
DEBUG - 2016-10-26 13:24:54 --> Total execution time: 2.9042
INFO - 2016-10-26 13:25:00 --> Config Class Initialized
INFO - 2016-10-26 13:25:00 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:25:00 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:25:00 --> Utf8 Class Initialized
INFO - 2016-10-26 13:25:00 --> URI Class Initialized
INFO - 2016-10-26 13:25:00 --> Router Class Initialized
INFO - 2016-10-26 13:25:00 --> Output Class Initialized
INFO - 2016-10-26 13:25:00 --> Security Class Initialized
DEBUG - 2016-10-26 13:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:25:00 --> Input Class Initialized
INFO - 2016-10-26 13:25:00 --> Language Class Initialized
INFO - 2016-10-26 13:25:01 --> Language Class Initialized
INFO - 2016-10-26 13:25:01 --> Config Class Initialized
INFO - 2016-10-26 13:25:01 --> Loader Class Initialized
INFO - 2016-10-26 13:25:01 --> Helper loaded: url_helper
INFO - 2016-10-26 13:25:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:25:01 --> Controller Class Initialized
DEBUG - 2016-10-26 13:25:01 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:25:01 --> Model Class Initialized
INFO - 2016-10-26 13:25:01 --> Model Class Initialized
ERROR - 2016-10-26 13:25:01 --> Unable to delete cache file for admin/index/data/anggota/umum
DEBUG - 2016-10-26 13:25:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 13:25:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 13:25:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-26 13:25:01 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-26 13:25:01 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-26 13:25:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-26 13:25:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 13:25:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 13:25:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:03 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:25:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 13:25:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 13:25:03 --> Final output sent to browser
DEBUG - 2016-10-26 13:25:03 --> Total execution time: 2.9852
INFO - 2016-10-26 13:25:08 --> Config Class Initialized
INFO - 2016-10-26 13:25:08 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:25:08 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:25:08 --> Utf8 Class Initialized
INFO - 2016-10-26 13:25:08 --> URI Class Initialized
INFO - 2016-10-26 13:25:08 --> Router Class Initialized
INFO - 2016-10-26 13:25:08 --> Output Class Initialized
INFO - 2016-10-26 13:25:08 --> Security Class Initialized
DEBUG - 2016-10-26 13:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:25:08 --> Input Class Initialized
INFO - 2016-10-26 13:25:08 --> Language Class Initialized
INFO - 2016-10-26 13:25:09 --> Language Class Initialized
INFO - 2016-10-26 13:25:09 --> Config Class Initialized
INFO - 2016-10-26 13:25:09 --> Loader Class Initialized
INFO - 2016-10-26 13:25:09 --> Helper loaded: url_helper
INFO - 2016-10-26 13:25:09 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:25:09 --> Controller Class Initialized
DEBUG - 2016-10-26 13:25:09 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:25:09 --> Model Class Initialized
INFO - 2016-10-26 13:25:09 --> Model Class Initialized
ERROR - 2016-10-26 13:25:09 --> Unable to delete cache file for admin/index/detail_anggota/902ba3cda1883801594b6e1b452790cc53948fda
DEBUG - 2016-10-26 13:25:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 13:25:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 13:25:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
INFO - 2016-10-26 13:25:09 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:25:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_pinjaman.php
INFO - 2016-10-26 13:25:09 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:25:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_tabungan.php
DEBUG - 2016-10-26 13:25:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/profile_anggota.php
DEBUG - 2016-10-26 13:25:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 13:25:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 13:25:09 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:09 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:09 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:09 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:10 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:10 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:10 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:10 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:10 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:10 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:10 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:10 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:10 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:10 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:10 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:10 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:10 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:10 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:10 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:10 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:10 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:10 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:10 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:10 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:10 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:10 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:10 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:10 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:10 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:10 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:10 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:10 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:10 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:11 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:11 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:11 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:11 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:11 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:11 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:11 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:11 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:11 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:11 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:11 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:11 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:11 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:11 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:11 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:11 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:11 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:11 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:11 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:11 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:11 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:11 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:11 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:11 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:11 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:11 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:11 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:25:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 13:25:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 13:25:12 --> Final output sent to browser
DEBUG - 2016-10-26 13:25:12 --> Total execution time: 3.5327
INFO - 2016-10-26 13:25:12 --> Config Class Initialized
INFO - 2016-10-26 13:25:12 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:25:12 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:25:12 --> Utf8 Class Initialized
INFO - 2016-10-26 13:25:12 --> URI Class Initialized
INFO - 2016-10-26 13:25:12 --> Router Class Initialized
INFO - 2016-10-26 13:25:12 --> Output Class Initialized
INFO - 2016-10-26 13:25:12 --> Security Class Initialized
DEBUG - 2016-10-26 13:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:25:12 --> Input Class Initialized
INFO - 2016-10-26 13:25:12 --> Language Class Initialized
INFO - 2016-10-26 13:25:12 --> Language Class Initialized
INFO - 2016-10-26 13:25:12 --> Config Class Initialized
INFO - 2016-10-26 13:25:12 --> Loader Class Initialized
INFO - 2016-10-26 13:25:12 --> Helper loaded: url_helper
INFO - 2016-10-26 13:25:12 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:25:13 --> Controller Class Initialized
DEBUG - 2016-10-26 13:25:13 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:25:13 --> Model Class Initialized
INFO - 2016-10-26 13:25:13 --> Model Class Initialized
ERROR - 2016-10-26 13:25:13 --> Unable to delete cache file for admin/index/detail_anggota/images/picture.jpg
DEBUG - 2016-10-26 13:25:13 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 13:25:13 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 13:25:13 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
ERROR - 2016-10-26 13:25:13 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 16
ERROR - 2016-10-26 13:25:13 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 19
ERROR - 2016-10-26 13:25:13 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 22
ERROR - 2016-10-26 13:25:13 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 38
INFO - 2016-10-26 13:25:13 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:25:14 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_pinjaman.php
ERROR - 2016-10-26 13:25:14 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 41
INFO - 2016-10-26 13:25:14 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:25:14 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_tabungan.php
DEBUG - 2016-10-26 13:25:14 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/profile_anggota.php
DEBUG - 2016-10-26 13:25:14 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 13:25:14 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 13:25:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:18 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:25:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 13:25:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 13:25:19 --> Final output sent to browser
DEBUG - 2016-10-26 13:25:19 --> Total execution time: 6.8521
INFO - 2016-10-26 13:25:31 --> Config Class Initialized
INFO - 2016-10-26 13:25:31 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:25:31 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:25:31 --> Utf8 Class Initialized
INFO - 2016-10-26 13:25:31 --> URI Class Initialized
INFO - 2016-10-26 13:25:31 --> Router Class Initialized
INFO - 2016-10-26 13:25:31 --> Output Class Initialized
INFO - 2016-10-26 13:25:31 --> Security Class Initialized
DEBUG - 2016-10-26 13:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:25:31 --> Input Class Initialized
INFO - 2016-10-26 13:25:31 --> Language Class Initialized
INFO - 2016-10-26 13:25:31 --> Language Class Initialized
INFO - 2016-10-26 13:25:32 --> Config Class Initialized
INFO - 2016-10-26 13:25:32 --> Loader Class Initialized
INFO - 2016-10-26 13:25:32 --> Helper loaded: url_helper
INFO - 2016-10-26 13:25:32 --> Database Driver Class Initialized
INFO - 2016-10-26 13:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:25:32 --> Controller Class Initialized
DEBUG - 2016-10-26 13:25:32 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:25:32 --> Model Class Initialized
INFO - 2016-10-26 13:25:32 --> Model Class Initialized
ERROR - 2016-10-26 13:25:32 --> Unable to delete cache file for admin/index/getRaportAngsuran/5b384ce32d8cdef02bc3a139d4cac0a22bb029e8
DEBUG - 2016-10-26 13:25:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/raport_angsuran.php
INFO - 2016-10-26 13:25:32 --> Final output sent to browser
DEBUG - 2016-10-26 13:25:32 --> Total execution time: 1.2216
INFO - 2016-10-26 13:26:22 --> Config Class Initialized
INFO - 2016-10-26 13:26:22 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:26:22 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:26:22 --> Utf8 Class Initialized
INFO - 2016-10-26 13:26:22 --> URI Class Initialized
INFO - 2016-10-26 13:26:22 --> Router Class Initialized
INFO - 2016-10-26 13:26:22 --> Output Class Initialized
INFO - 2016-10-26 13:26:22 --> Security Class Initialized
DEBUG - 2016-10-26 13:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:26:23 --> Input Class Initialized
INFO - 2016-10-26 13:26:23 --> Language Class Initialized
INFO - 2016-10-26 13:26:23 --> Language Class Initialized
INFO - 2016-10-26 13:26:23 --> Config Class Initialized
INFO - 2016-10-26 13:26:23 --> Loader Class Initialized
INFO - 2016-10-26 13:26:23 --> Helper loaded: url_helper
INFO - 2016-10-26 13:26:23 --> Database Driver Class Initialized
INFO - 2016-10-26 13:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:26:23 --> Controller Class Initialized
DEBUG - 2016-10-26 13:26:23 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:26:23 --> Model Class Initialized
INFO - 2016-10-26 13:26:23 --> Model Class Initialized
ERROR - 2016-10-26 13:26:23 --> Unable to delete cache file for admin/index/getDetailAngsuran
INFO - 2016-10-26 13:26:23 --> Database Driver Class Initialized
INFO - 2016-10-26 13:26:23 --> Final output sent to browser
DEBUG - 2016-10-26 13:26:23 --> Total execution time: 0.6464
INFO - 2016-10-26 13:26:25 --> Config Class Initialized
INFO - 2016-10-26 13:26:25 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:26:25 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:26:25 --> Utf8 Class Initialized
INFO - 2016-10-26 13:26:25 --> URI Class Initialized
INFO - 2016-10-26 13:26:25 --> Router Class Initialized
INFO - 2016-10-26 13:26:25 --> Output Class Initialized
INFO - 2016-10-26 13:26:25 --> Security Class Initialized
DEBUG - 2016-10-26 13:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:26:25 --> Input Class Initialized
INFO - 2016-10-26 13:26:25 --> Language Class Initialized
INFO - 2016-10-26 13:26:25 --> Language Class Initialized
INFO - 2016-10-26 13:26:25 --> Config Class Initialized
INFO - 2016-10-26 13:26:25 --> Loader Class Initialized
INFO - 2016-10-26 13:26:25 --> Helper loaded: url_helper
INFO - 2016-10-26 13:26:25 --> Database Driver Class Initialized
INFO - 2016-10-26 13:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:26:25 --> Controller Class Initialized
DEBUG - 2016-10-26 13:26:25 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:26:25 --> Model Class Initialized
INFO - 2016-10-26 13:26:25 --> Model Class Initialized
ERROR - 2016-10-26 13:26:25 --> Unable to delete cache file for admin/index/do_bayar
INFO - 2016-10-26 13:26:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:26:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:26:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:26:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:26:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:26:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:26:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:26:26 --> Final output sent to browser
DEBUG - 2016-10-26 13:26:26 --> Total execution time: 1.2811
INFO - 2016-10-26 13:26:27 --> Config Class Initialized
INFO - 2016-10-26 13:26:27 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:26:27 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:26:27 --> Utf8 Class Initialized
INFO - 2016-10-26 13:26:27 --> URI Class Initialized
INFO - 2016-10-26 13:26:27 --> Router Class Initialized
INFO - 2016-10-26 13:26:27 --> Output Class Initialized
INFO - 2016-10-26 13:26:27 --> Security Class Initialized
DEBUG - 2016-10-26 13:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:26:27 --> Input Class Initialized
INFO - 2016-10-26 13:26:27 --> Language Class Initialized
INFO - 2016-10-26 13:26:27 --> Language Class Initialized
INFO - 2016-10-26 13:26:27 --> Config Class Initialized
INFO - 2016-10-26 13:26:27 --> Loader Class Initialized
INFO - 2016-10-26 13:26:27 --> Helper loaded: url_helper
INFO - 2016-10-26 13:26:27 --> Database Driver Class Initialized
INFO - 2016-10-26 13:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:26:27 --> Controller Class Initialized
DEBUG - 2016-10-26 13:26:27 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:26:27 --> Model Class Initialized
INFO - 2016-10-26 13:26:27 --> Model Class Initialized
ERROR - 2016-10-26 13:26:27 --> Unable to delete cache file for admin/index/getDetailAngsuran
INFO - 2016-10-26 13:26:27 --> Database Driver Class Initialized
INFO - 2016-10-26 13:26:27 --> Final output sent to browser
DEBUG - 2016-10-26 13:26:28 --> Total execution time: 0.7045
INFO - 2016-10-26 13:26:29 --> Config Class Initialized
INFO - 2016-10-26 13:26:29 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:26:29 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:26:29 --> Utf8 Class Initialized
INFO - 2016-10-26 13:26:29 --> URI Class Initialized
INFO - 2016-10-26 13:26:29 --> Router Class Initialized
INFO - 2016-10-26 13:26:29 --> Output Class Initialized
INFO - 2016-10-26 13:26:29 --> Security Class Initialized
DEBUG - 2016-10-26 13:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:26:29 --> Input Class Initialized
INFO - 2016-10-26 13:26:29 --> Language Class Initialized
INFO - 2016-10-26 13:26:29 --> Language Class Initialized
INFO - 2016-10-26 13:26:29 --> Config Class Initialized
INFO - 2016-10-26 13:26:29 --> Loader Class Initialized
INFO - 2016-10-26 13:26:29 --> Helper loaded: url_helper
INFO - 2016-10-26 13:26:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:26:29 --> Controller Class Initialized
DEBUG - 2016-10-26 13:26:29 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:26:29 --> Model Class Initialized
INFO - 2016-10-26 13:26:29 --> Model Class Initialized
ERROR - 2016-10-26 13:26:29 --> Unable to delete cache file for admin/index/do_bayar
INFO - 2016-10-26 13:26:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:26:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:26:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:26:30 --> Database Driver Class Initialized
INFO - 2016-10-26 13:26:30 --> Database Driver Class Initialized
INFO - 2016-10-26 13:26:30 --> Database Driver Class Initialized
INFO - 2016-10-26 13:26:30 --> Database Driver Class Initialized
INFO - 2016-10-26 13:26:30 --> Final output sent to browser
DEBUG - 2016-10-26 13:26:30 --> Total execution time: 1.1038
INFO - 2016-10-26 13:26:33 --> Config Class Initialized
INFO - 2016-10-26 13:26:33 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:26:33 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:26:33 --> Utf8 Class Initialized
INFO - 2016-10-26 13:26:33 --> URI Class Initialized
INFO - 2016-10-26 13:26:33 --> Router Class Initialized
INFO - 2016-10-26 13:26:33 --> Output Class Initialized
INFO - 2016-10-26 13:26:33 --> Security Class Initialized
DEBUG - 2016-10-26 13:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:26:34 --> Input Class Initialized
INFO - 2016-10-26 13:26:34 --> Language Class Initialized
INFO - 2016-10-26 13:26:34 --> Language Class Initialized
INFO - 2016-10-26 13:26:34 --> Config Class Initialized
INFO - 2016-10-26 13:26:34 --> Loader Class Initialized
INFO - 2016-10-26 13:26:34 --> Helper loaded: url_helper
INFO - 2016-10-26 13:26:34 --> Database Driver Class Initialized
INFO - 2016-10-26 13:26:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:26:34 --> Controller Class Initialized
DEBUG - 2016-10-26 13:26:34 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:26:34 --> Model Class Initialized
INFO - 2016-10-26 13:26:34 --> Model Class Initialized
ERROR - 2016-10-26 13:26:34 --> Unable to delete cache file for admin/index/getRaportAngsuran/5b384ce32d8cdef02bc3a139d4cac0a22bb029e8
DEBUG - 2016-10-26 13:26:34 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/raport_angsuran.php
INFO - 2016-10-26 13:26:34 --> Final output sent to browser
DEBUG - 2016-10-26 13:26:34 --> Total execution time: 0.9791
INFO - 2016-10-26 13:27:11 --> Config Class Initialized
INFO - 2016-10-26 13:27:11 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:27:11 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:27:11 --> Utf8 Class Initialized
INFO - 2016-10-26 13:27:11 --> URI Class Initialized
INFO - 2016-10-26 13:27:11 --> Router Class Initialized
INFO - 2016-10-26 13:27:11 --> Output Class Initialized
INFO - 2016-10-26 13:27:11 --> Security Class Initialized
DEBUG - 2016-10-26 13:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:27:11 --> Input Class Initialized
INFO - 2016-10-26 13:27:11 --> Language Class Initialized
INFO - 2016-10-26 13:27:11 --> Language Class Initialized
INFO - 2016-10-26 13:27:11 --> Config Class Initialized
INFO - 2016-10-26 13:27:11 --> Loader Class Initialized
INFO - 2016-10-26 13:27:12 --> Helper loaded: url_helper
INFO - 2016-10-26 13:27:12 --> Database Driver Class Initialized
INFO - 2016-10-26 13:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:27:12 --> Controller Class Initialized
DEBUG - 2016-10-26 13:27:12 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:27:12 --> Model Class Initialized
INFO - 2016-10-26 13:27:12 --> Model Class Initialized
ERROR - 2016-10-26 13:27:12 --> Unable to delete cache file for admin/index/getDetailAngsuran
INFO - 2016-10-26 13:27:12 --> Database Driver Class Initialized
INFO - 2016-10-26 13:27:12 --> Final output sent to browser
DEBUG - 2016-10-26 13:27:12 --> Total execution time: 0.6777
INFO - 2016-10-26 13:31:14 --> Config Class Initialized
INFO - 2016-10-26 13:31:14 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:31:14 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:31:14 --> Utf8 Class Initialized
INFO - 2016-10-26 13:31:14 --> URI Class Initialized
INFO - 2016-10-26 13:31:14 --> Router Class Initialized
INFO - 2016-10-26 13:31:15 --> Output Class Initialized
INFO - 2016-10-26 13:31:15 --> Security Class Initialized
DEBUG - 2016-10-26 13:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:31:15 --> Input Class Initialized
INFO - 2016-10-26 13:31:15 --> Language Class Initialized
INFO - 2016-10-26 13:31:15 --> Language Class Initialized
INFO - 2016-10-26 13:31:15 --> Config Class Initialized
INFO - 2016-10-26 13:31:15 --> Loader Class Initialized
INFO - 2016-10-26 13:31:15 --> Helper loaded: url_helper
INFO - 2016-10-26 13:31:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:31:15 --> Controller Class Initialized
DEBUG - 2016-10-26 13:31:15 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:31:15 --> Model Class Initialized
INFO - 2016-10-26 13:31:15 --> Model Class Initialized
ERROR - 2016-10-26 13:31:15 --> Unable to delete cache file for admin/index/getRaportAngsuran/5b384ce32d8cdef02bc3a139d4cac0a22bb029e8
DEBUG - 2016-10-26 13:31:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/raport_angsuran.php
INFO - 2016-10-26 13:31:15 --> Final output sent to browser
DEBUG - 2016-10-26 13:31:15 --> Total execution time: 1.0336
INFO - 2016-10-26 13:31:29 --> Config Class Initialized
INFO - 2016-10-26 13:31:29 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:31:29 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:31:29 --> Utf8 Class Initialized
INFO - 2016-10-26 13:31:29 --> URI Class Initialized
INFO - 2016-10-26 13:31:29 --> Router Class Initialized
INFO - 2016-10-26 13:31:29 --> Output Class Initialized
INFO - 2016-10-26 13:31:29 --> Security Class Initialized
DEBUG - 2016-10-26 13:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:31:29 --> Input Class Initialized
INFO - 2016-10-26 13:31:29 --> Language Class Initialized
INFO - 2016-10-26 13:31:29 --> Language Class Initialized
INFO - 2016-10-26 13:31:29 --> Config Class Initialized
INFO - 2016-10-26 13:31:29 --> Loader Class Initialized
INFO - 2016-10-26 13:31:29 --> Helper loaded: url_helper
INFO - 2016-10-26 13:31:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:31:29 --> Controller Class Initialized
DEBUG - 2016-10-26 13:31:29 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:31:29 --> Model Class Initialized
INFO - 2016-10-26 13:31:29 --> Model Class Initialized
ERROR - 2016-10-26 13:31:29 --> Unable to delete cache file for admin/index/list_jaminan
DEBUG - 2016-10-26 13:31:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 13:31:30 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 13:31:30 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-26 13:31:30 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/jaminan.php
DEBUG - 2016-10-26 13:31:30 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 13:31:30 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 13:31:30 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:30 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:30 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:30 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:30 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:30 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:30 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:30 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:30 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:30 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:30 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:30 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:30 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:30 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:30 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:30 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:31 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:31 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:31 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:31 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:31 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:31 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:31 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:31 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:31 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:31 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:31 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:31 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:31 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:31 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:31 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:31 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:31 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:31 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:31 --> Config Class Initialized
INFO - 2016-10-26 13:31:31 --> Hooks Class Initialized
INFO - 2016-10-26 13:31:31 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:31:31 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:31:31 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:31 --> Utf8 Class Initialized
INFO - 2016-10-26 13:31:31 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:31 --> URI Class Initialized
INFO - 2016-10-26 13:31:31 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:31 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:31 --> Router Class Initialized
INFO - 2016-10-26 13:31:31 --> Output Class Initialized
INFO - 2016-10-26 13:31:31 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:32 --> Security Class Initialized
DEBUG - 2016-10-26 13:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:31:32 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:32 --> Input Class Initialized
INFO - 2016-10-26 13:31:32 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:32 --> Language Class Initialized
INFO - 2016-10-26 13:31:32 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:32 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:32 --> Language Class Initialized
INFO - 2016-10-26 13:31:32 --> Config Class Initialized
INFO - 2016-10-26 13:31:32 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:32 --> Loader Class Initialized
INFO - 2016-10-26 13:31:32 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:32 --> Helper loaded: url_helper
INFO - 2016-10-26 13:31:32 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:32 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:32 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:32 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:32 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:32 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:32 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:32 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:32 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:32 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:32 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:32 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:32 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:32 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:32 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:31:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 13:31:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 13:31:32 --> Final output sent to browser
DEBUG - 2016-10-26 13:31:32 --> Total execution time: 3.5856
INFO - 2016-10-26 13:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:31:32 --> Controller Class Initialized
DEBUG - 2016-10-26 13:31:33 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:31:33 --> Model Class Initialized
INFO - 2016-10-26 13:31:33 --> Model Class Initialized
ERROR - 2016-10-26 13:31:33 --> Unable to delete cache file for admin/index/data_peminjam
DEBUG - 2016-10-26 13:31:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 13:31:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 13:31:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-26 13:31:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_peminjam.php
DEBUG - 2016-10-26 13:31:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 13:31:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 13:31:33 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:33 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:33 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:33 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:33 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:33 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:33 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:33 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:33 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:33 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:33 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:33 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:33 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:33 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:33 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:33 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:33 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:33 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:33 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:33 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:33 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:33 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:34 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:34 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:34 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:34 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:34 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:34 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:34 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:34 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:34 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:34 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:34 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:34 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:34 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:34 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:34 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:34 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:34 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:34 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:34 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:34 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:34 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:34 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:34 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:34 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:34 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:34 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:34 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:35 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:35 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:35 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:35 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:35 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:35 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:35 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:35 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:35 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:35 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:31:35 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 13:31:35 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 13:31:35 --> Final output sent to browser
DEBUG - 2016-10-26 13:31:35 --> Total execution time: 3.6450
INFO - 2016-10-26 13:31:38 --> Config Class Initialized
INFO - 2016-10-26 13:31:38 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:31:38 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:31:38 --> Utf8 Class Initialized
INFO - 2016-10-26 13:31:38 --> URI Class Initialized
INFO - 2016-10-26 13:31:38 --> Router Class Initialized
INFO - 2016-10-26 13:31:39 --> Output Class Initialized
INFO - 2016-10-26 13:31:39 --> Security Class Initialized
DEBUG - 2016-10-26 13:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:31:39 --> Input Class Initialized
INFO - 2016-10-26 13:31:39 --> Language Class Initialized
INFO - 2016-10-26 13:31:39 --> Language Class Initialized
INFO - 2016-10-26 13:31:39 --> Config Class Initialized
INFO - 2016-10-26 13:31:39 --> Loader Class Initialized
INFO - 2016-10-26 13:31:39 --> Helper loaded: url_helper
INFO - 2016-10-26 13:31:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:31:39 --> Controller Class Initialized
DEBUG - 2016-10-26 13:31:39 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:31:39 --> Model Class Initialized
INFO - 2016-10-26 13:31:39 --> Model Class Initialized
ERROR - 2016-10-26 13:31:39 --> Unable to delete cache file for admin/index/getDataPeminjam/umum
DEBUG - 2016-10-26 13:31:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-10-26 13:31:39 --> Final output sent to browser
DEBUG - 2016-10-26 13:31:39 --> Total execution time: 0.7467
INFO - 2016-10-26 13:31:43 --> Config Class Initialized
INFO - 2016-10-26 13:31:43 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:31:43 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:31:43 --> Utf8 Class Initialized
INFO - 2016-10-26 13:31:43 --> URI Class Initialized
INFO - 2016-10-26 13:31:44 --> Router Class Initialized
INFO - 2016-10-26 13:31:44 --> Output Class Initialized
INFO - 2016-10-26 13:31:44 --> Security Class Initialized
DEBUG - 2016-10-26 13:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:31:44 --> Input Class Initialized
INFO - 2016-10-26 13:31:44 --> Language Class Initialized
INFO - 2016-10-26 13:31:44 --> Language Class Initialized
INFO - 2016-10-26 13:31:44 --> Config Class Initialized
INFO - 2016-10-26 13:31:44 --> Loader Class Initialized
INFO - 2016-10-26 13:31:44 --> Helper loaded: url_helper
INFO - 2016-10-26 13:31:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:31:44 --> Controller Class Initialized
DEBUG - 2016-10-26 13:31:44 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:31:44 --> Model Class Initialized
INFO - 2016-10-26 13:31:44 --> Model Class Initialized
ERROR - 2016-10-26 13:31:44 --> Unable to delete cache file for admin/index/detail_pinjaman/5b384ce32d8cdef02bc3a139d4cac0a22bb029e8
DEBUG - 2016-10-26 13:31:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/subcontent/data_transaksi.php
INFO - 2016-10-26 13:31:44 --> Final output sent to browser
DEBUG - 2016-10-26 13:31:44 --> Total execution time: 1.0366
INFO - 2016-10-26 13:36:38 --> Config Class Initialized
INFO - 2016-10-26 13:36:38 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:36:38 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:36:38 --> Utf8 Class Initialized
INFO - 2016-10-26 13:36:38 --> URI Class Initialized
INFO - 2016-10-26 13:36:38 --> Router Class Initialized
INFO - 2016-10-26 13:36:39 --> Output Class Initialized
INFO - 2016-10-26 13:36:39 --> Security Class Initialized
DEBUG - 2016-10-26 13:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:36:39 --> Input Class Initialized
INFO - 2016-10-26 13:36:39 --> Language Class Initialized
INFO - 2016-10-26 13:36:39 --> Language Class Initialized
INFO - 2016-10-26 13:36:39 --> Config Class Initialized
INFO - 2016-10-26 13:36:39 --> Loader Class Initialized
INFO - 2016-10-26 13:36:39 --> Helper loaded: url_helper
INFO - 2016-10-26 13:36:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:36:39 --> Controller Class Initialized
DEBUG - 2016-10-26 13:36:39 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:36:39 --> Model Class Initialized
INFO - 2016-10-26 13:36:39 --> Model Class Initialized
ERROR - 2016-10-26 13:36:39 --> Unable to delete cache file for admin/index/detail_pinjaman/5b384ce32d8cdef02bc3a139d4cac0a22bb029e8
ERROR - 2016-10-26 13:36:39 --> Severity: Notice --> Undefined variable: row E:\SERVER\htdocs\kops\application\views\main_html\content\subcontent\data_transaksi.php 51
DEBUG - 2016-10-26 13:36:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/subcontent/data_transaksi.php
INFO - 2016-10-26 13:36:39 --> Final output sent to browser
DEBUG - 2016-10-26 13:36:39 --> Total execution time: 1.2856
INFO - 2016-10-26 13:36:57 --> Config Class Initialized
INFO - 2016-10-26 13:36:57 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:36:57 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:36:57 --> Utf8 Class Initialized
INFO - 2016-10-26 13:36:57 --> URI Class Initialized
INFO - 2016-10-26 13:36:57 --> Router Class Initialized
INFO - 2016-10-26 13:36:57 --> Output Class Initialized
INFO - 2016-10-26 13:36:57 --> Security Class Initialized
DEBUG - 2016-10-26 13:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:36:57 --> Input Class Initialized
INFO - 2016-10-26 13:36:57 --> Language Class Initialized
INFO - 2016-10-26 13:36:57 --> Language Class Initialized
INFO - 2016-10-26 13:36:57 --> Config Class Initialized
INFO - 2016-10-26 13:36:58 --> Loader Class Initialized
INFO - 2016-10-26 13:36:58 --> Helper loaded: url_helper
INFO - 2016-10-26 13:36:58 --> Database Driver Class Initialized
INFO - 2016-10-26 13:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:36:58 --> Controller Class Initialized
DEBUG - 2016-10-26 13:36:58 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:36:58 --> Model Class Initialized
INFO - 2016-10-26 13:36:58 --> Model Class Initialized
ERROR - 2016-10-26 13:36:58 --> Unable to delete cache file for admin/index/detail_pinjaman/5b384ce32d8cdef02bc3a139d4cac0a22bb029e8
DEBUG - 2016-10-26 13:36:58 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/subcontent/data_transaksi.php
INFO - 2016-10-26 13:36:58 --> Final output sent to browser
DEBUG - 2016-10-26 13:36:58 --> Total execution time: 1.2713
INFO - 2016-10-26 13:38:30 --> Config Class Initialized
INFO - 2016-10-26 13:38:30 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:38:31 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:38:31 --> Utf8 Class Initialized
INFO - 2016-10-26 13:38:31 --> URI Class Initialized
INFO - 2016-10-26 13:38:31 --> Router Class Initialized
INFO - 2016-10-26 13:38:31 --> Output Class Initialized
INFO - 2016-10-26 13:38:31 --> Security Class Initialized
DEBUG - 2016-10-26 13:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:38:31 --> Input Class Initialized
INFO - 2016-10-26 13:38:31 --> Language Class Initialized
INFO - 2016-10-26 13:38:31 --> Language Class Initialized
INFO - 2016-10-26 13:38:31 --> Config Class Initialized
INFO - 2016-10-26 13:38:31 --> Loader Class Initialized
INFO - 2016-10-26 13:38:31 --> Helper loaded: url_helper
INFO - 2016-10-26 13:38:31 --> Database Driver Class Initialized
INFO - 2016-10-26 13:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:38:31 --> Controller Class Initialized
DEBUG - 2016-10-26 13:38:31 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:38:31 --> Model Class Initialized
INFO - 2016-10-26 13:38:31 --> Model Class Initialized
ERROR - 2016-10-26 13:38:32 --> Unable to delete cache file for admin/index/detail_pinjaman/5b384ce32d8cdef02bc3a139d4cac0a22bb029e8
DEBUG - 2016-10-26 13:38:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/subcontent/data_transaksi.php
INFO - 2016-10-26 13:38:32 --> Final output sent to browser
DEBUG - 2016-10-26 13:38:32 --> Total execution time: 1.2546
INFO - 2016-10-26 13:40:07 --> Config Class Initialized
INFO - 2016-10-26 13:40:07 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:40:08 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:40:08 --> Utf8 Class Initialized
INFO - 2016-10-26 13:40:08 --> URI Class Initialized
INFO - 2016-10-26 13:40:08 --> Router Class Initialized
INFO - 2016-10-26 13:40:08 --> Output Class Initialized
INFO - 2016-10-26 13:40:08 --> Security Class Initialized
DEBUG - 2016-10-26 13:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:40:08 --> Input Class Initialized
INFO - 2016-10-26 13:40:08 --> Language Class Initialized
INFO - 2016-10-26 13:40:08 --> Language Class Initialized
INFO - 2016-10-26 13:40:08 --> Config Class Initialized
INFO - 2016-10-26 13:40:08 --> Loader Class Initialized
INFO - 2016-10-26 13:40:08 --> Helper loaded: url_helper
INFO - 2016-10-26 13:40:08 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:40:09 --> Controller Class Initialized
DEBUG - 2016-10-26 13:40:09 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:40:09 --> Model Class Initialized
INFO - 2016-10-26 13:40:09 --> Model Class Initialized
ERROR - 2016-10-26 13:40:09 --> Unable to delete cache file for admin/index/detail_pinjaman/5b384ce32d8cdef02bc3a139d4cac0a22bb029e8
DEBUG - 2016-10-26 13:40:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/subcontent/data_transaksi.php
INFO - 2016-10-26 13:40:09 --> Final output sent to browser
DEBUG - 2016-10-26 13:40:09 --> Total execution time: 1.3271
INFO - 2016-10-26 13:40:49 --> Config Class Initialized
INFO - 2016-10-26 13:40:49 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:40:49 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:40:49 --> Utf8 Class Initialized
INFO - 2016-10-26 13:40:49 --> URI Class Initialized
INFO - 2016-10-26 13:40:49 --> Router Class Initialized
INFO - 2016-10-26 13:40:49 --> Output Class Initialized
INFO - 2016-10-26 13:40:49 --> Security Class Initialized
DEBUG - 2016-10-26 13:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:40:49 --> Input Class Initialized
INFO - 2016-10-26 13:40:49 --> Language Class Initialized
INFO - 2016-10-26 13:40:49 --> Language Class Initialized
INFO - 2016-10-26 13:40:49 --> Config Class Initialized
INFO - 2016-10-26 13:40:49 --> Loader Class Initialized
INFO - 2016-10-26 13:40:49 --> Helper loaded: url_helper
INFO - 2016-10-26 13:40:50 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:40:50 --> Controller Class Initialized
DEBUG - 2016-10-26 13:40:50 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:40:50 --> Model Class Initialized
INFO - 2016-10-26 13:40:50 --> Model Class Initialized
ERROR - 2016-10-26 13:40:50 --> Unable to delete cache file for admin/index/tutup_angsuran
DEBUG - 2016-10-26 13:40:50 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 13:40:50 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 13:40:50 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-26 13:40:50 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_tutup_angsuran.php
DEBUG - 2016-10-26 13:40:50 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 13:40:50 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 13:40:50 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:50 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:50 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:50 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:50 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:50 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:50 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:50 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:50 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:53 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:40:53 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 13:40:53 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 13:40:53 --> Final output sent to browser
DEBUG - 2016-10-26 13:40:53 --> Total execution time: 3.9607
INFO - 2016-10-26 13:40:58 --> Config Class Initialized
INFO - 2016-10-26 13:40:58 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:40:58 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:40:58 --> Utf8 Class Initialized
INFO - 2016-10-26 13:40:58 --> URI Class Initialized
INFO - 2016-10-26 13:40:58 --> Router Class Initialized
INFO - 2016-10-26 13:40:58 --> Output Class Initialized
INFO - 2016-10-26 13:40:58 --> Security Class Initialized
DEBUG - 2016-10-26 13:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:40:58 --> Input Class Initialized
INFO - 2016-10-26 13:40:58 --> Language Class Initialized
INFO - 2016-10-26 13:40:58 --> Language Class Initialized
INFO - 2016-10-26 13:40:58 --> Config Class Initialized
INFO - 2016-10-26 13:40:58 --> Loader Class Initialized
INFO - 2016-10-26 13:40:58 --> Helper loaded: url_helper
INFO - 2016-10-26 13:40:58 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:40:59 --> Controller Class Initialized
DEBUG - 2016-10-26 13:40:59 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:40:59 --> Model Class Initialized
INFO - 2016-10-26 13:40:59 --> Model Class Initialized
ERROR - 2016-10-26 13:40:59 --> Unable to delete cache file for admin/index/getDetailLunas
INFO - 2016-10-26 13:40:59 --> Database Driver Class Initialized
INFO - 2016-10-26 13:40:59 --> Final output sent to browser
DEBUG - 2016-10-26 13:40:59 --> Total execution time: 1.3434
INFO - 2016-10-26 13:41:14 --> Config Class Initialized
INFO - 2016-10-26 13:41:14 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:41:14 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:41:14 --> Utf8 Class Initialized
INFO - 2016-10-26 13:41:14 --> URI Class Initialized
INFO - 2016-10-26 13:41:15 --> Router Class Initialized
INFO - 2016-10-26 13:41:15 --> Output Class Initialized
INFO - 2016-10-26 13:41:15 --> Security Class Initialized
DEBUG - 2016-10-26 13:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:41:15 --> Input Class Initialized
INFO - 2016-10-26 13:41:15 --> Language Class Initialized
INFO - 2016-10-26 13:41:15 --> Language Class Initialized
INFO - 2016-10-26 13:41:15 --> Config Class Initialized
INFO - 2016-10-26 13:41:15 --> Loader Class Initialized
INFO - 2016-10-26 13:41:15 --> Helper loaded: url_helper
INFO - 2016-10-26 13:41:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:41:15 --> Controller Class Initialized
DEBUG - 2016-10-26 13:41:15 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:41:15 --> Model Class Initialized
INFO - 2016-10-26 13:41:15 --> Model Class Initialized
ERROR - 2016-10-26 13:41:15 --> Unable to delete cache file for admin/index/do_lunas
INFO - 2016-10-26 13:41:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:19 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:19 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:19 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:19 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:19 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:19 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:19 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:19 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:19 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:20 --> Final output sent to browser
DEBUG - 2016-10-26 13:41:20 --> Total execution time: 5.3904
INFO - 2016-10-26 13:41:26 --> Config Class Initialized
INFO - 2016-10-26 13:41:26 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:41:26 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:41:26 --> Utf8 Class Initialized
INFO - 2016-10-26 13:41:26 --> URI Class Initialized
INFO - 2016-10-26 13:41:26 --> Router Class Initialized
INFO - 2016-10-26 13:41:26 --> Output Class Initialized
INFO - 2016-10-26 13:41:26 --> Security Class Initialized
DEBUG - 2016-10-26 13:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:41:26 --> Input Class Initialized
INFO - 2016-10-26 13:41:26 --> Language Class Initialized
INFO - 2016-10-26 13:41:26 --> Language Class Initialized
INFO - 2016-10-26 13:41:26 --> Config Class Initialized
INFO - 2016-10-26 13:41:27 --> Loader Class Initialized
INFO - 2016-10-26 13:41:27 --> Helper loaded: url_helper
INFO - 2016-10-26 13:41:27 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:41:27 --> Controller Class Initialized
DEBUG - 2016-10-26 13:41:27 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:41:27 --> Model Class Initialized
INFO - 2016-10-26 13:41:27 --> Model Class Initialized
ERROR - 2016-10-26 13:41:27 --> Unable to delete cache file for admin/index/data_peminjam
DEBUG - 2016-10-26 13:41:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 13:41:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 13:41:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-26 13:41:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_peminjam.php
DEBUG - 2016-10-26 13:41:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 13:41:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 13:41:27 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:27 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:27 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:27 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:27 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:27 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:27 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:27 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:28 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:28 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:28 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:28 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:28 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:28 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:28 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:28 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:28 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:28 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:28 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:28 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:28 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:28 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:28 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:28 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:28 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:28 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:28 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:30 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:30 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:30 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:30 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:30 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:30 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:30 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:30 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:30 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:30 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:30 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:30 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:41:30 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 13:41:30 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 13:41:30 --> Final output sent to browser
DEBUG - 2016-10-26 13:41:30 --> Total execution time: 4.0564
INFO - 2016-10-26 13:41:33 --> Config Class Initialized
INFO - 2016-10-26 13:41:33 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:41:33 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:41:33 --> Utf8 Class Initialized
INFO - 2016-10-26 13:41:33 --> URI Class Initialized
INFO - 2016-10-26 13:41:34 --> Router Class Initialized
INFO - 2016-10-26 13:41:34 --> Output Class Initialized
INFO - 2016-10-26 13:41:34 --> Security Class Initialized
DEBUG - 2016-10-26 13:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:41:34 --> Input Class Initialized
INFO - 2016-10-26 13:41:34 --> Language Class Initialized
INFO - 2016-10-26 13:41:34 --> Language Class Initialized
INFO - 2016-10-26 13:41:34 --> Config Class Initialized
INFO - 2016-10-26 13:41:34 --> Loader Class Initialized
INFO - 2016-10-26 13:41:34 --> Helper loaded: url_helper
INFO - 2016-10-26 13:41:34 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:41:34 --> Controller Class Initialized
DEBUG - 2016-10-26 13:41:34 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:41:34 --> Model Class Initialized
INFO - 2016-10-26 13:41:34 --> Model Class Initialized
ERROR - 2016-10-26 13:41:34 --> Unable to delete cache file for admin/index/getDataPeminjam/umum
DEBUG - 2016-10-26 13:41:35 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-10-26 13:41:35 --> Final output sent to browser
DEBUG - 2016-10-26 13:41:35 --> Total execution time: 1.3968
INFO - 2016-10-26 13:41:37 --> Config Class Initialized
INFO - 2016-10-26 13:41:37 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:41:37 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:41:37 --> Utf8 Class Initialized
INFO - 2016-10-26 13:41:37 --> URI Class Initialized
INFO - 2016-10-26 13:41:37 --> Router Class Initialized
INFO - 2016-10-26 13:41:38 --> Output Class Initialized
INFO - 2016-10-26 13:41:38 --> Security Class Initialized
DEBUG - 2016-10-26 13:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:41:38 --> Input Class Initialized
INFO - 2016-10-26 13:41:38 --> Language Class Initialized
INFO - 2016-10-26 13:41:38 --> Language Class Initialized
INFO - 2016-10-26 13:41:38 --> Config Class Initialized
INFO - 2016-10-26 13:41:38 --> Loader Class Initialized
INFO - 2016-10-26 13:41:38 --> Helper loaded: url_helper
INFO - 2016-10-26 13:41:38 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:41:38 --> Controller Class Initialized
DEBUG - 2016-10-26 13:41:38 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:41:38 --> Model Class Initialized
INFO - 2016-10-26 13:41:38 --> Model Class Initialized
ERROR - 2016-10-26 13:41:38 --> Unable to delete cache file for admin/index/detail_pinjaman/5b384ce32d8cdef02bc3a139d4cac0a22bb029e8
DEBUG - 2016-10-26 13:41:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/subcontent/data_transaksi.php
INFO - 2016-10-26 13:41:38 --> Final output sent to browser
DEBUG - 2016-10-26 13:41:38 --> Total execution time: 1.2703
INFO - 2016-10-26 13:41:42 --> Config Class Initialized
INFO - 2016-10-26 13:41:42 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:41:42 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:41:42 --> Utf8 Class Initialized
INFO - 2016-10-26 13:41:42 --> URI Class Initialized
INFO - 2016-10-26 13:41:42 --> Router Class Initialized
INFO - 2016-10-26 13:41:42 --> Output Class Initialized
INFO - 2016-10-26 13:41:42 --> Security Class Initialized
DEBUG - 2016-10-26 13:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:41:43 --> Input Class Initialized
INFO - 2016-10-26 13:41:43 --> Language Class Initialized
INFO - 2016-10-26 13:41:43 --> Language Class Initialized
INFO - 2016-10-26 13:41:43 --> Config Class Initialized
INFO - 2016-10-26 13:41:43 --> Loader Class Initialized
INFO - 2016-10-26 13:41:43 --> Helper loaded: url_helper
INFO - 2016-10-26 13:41:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:41:43 --> Controller Class Initialized
DEBUG - 2016-10-26 13:41:43 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:41:43 --> Model Class Initialized
INFO - 2016-10-26 13:41:43 --> Model Class Initialized
ERROR - 2016-10-26 13:41:43 --> Unable to delete cache file for admin/index/data/anggota
DEBUG - 2016-10-26 13:41:43 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 13:41:43 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 13:41:43 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-26 13:41:43 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-26 13:41:43 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-26 13:41:43 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-26 13:41:43 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 13:41:43 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 13:41:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:46 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:46 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:46 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:46 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:46 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:46 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:46 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:46 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:46 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:46 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:46 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:46 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:46 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:46 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:46 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:46 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:46 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:46 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:41:46 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 13:41:46 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 13:41:46 --> Final output sent to browser
DEBUG - 2016-10-26 13:41:47 --> Total execution time: 4.3826
INFO - 2016-10-26 13:41:52 --> Config Class Initialized
INFO - 2016-10-26 13:41:52 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:41:52 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:41:53 --> Utf8 Class Initialized
INFO - 2016-10-26 13:41:53 --> URI Class Initialized
INFO - 2016-10-26 13:41:53 --> Router Class Initialized
INFO - 2016-10-26 13:41:53 --> Output Class Initialized
INFO - 2016-10-26 13:41:53 --> Security Class Initialized
DEBUG - 2016-10-26 13:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:41:53 --> Input Class Initialized
INFO - 2016-10-26 13:41:53 --> Language Class Initialized
INFO - 2016-10-26 13:41:53 --> Language Class Initialized
INFO - 2016-10-26 13:41:53 --> Config Class Initialized
INFO - 2016-10-26 13:41:53 --> Loader Class Initialized
INFO - 2016-10-26 13:41:53 --> Helper loaded: url_helper
INFO - 2016-10-26 13:41:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:41:53 --> Controller Class Initialized
DEBUG - 2016-10-26 13:41:53 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:41:53 --> Model Class Initialized
INFO - 2016-10-26 13:41:53 --> Model Class Initialized
ERROR - 2016-10-26 13:41:53 --> Unable to delete cache file for admin/index/data/anggota/umum
DEBUG - 2016-10-26 13:41:53 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 13:41:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 13:41:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-26 13:41:54 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-26 13:41:54 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-26 13:41:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-26 13:41:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 13:41:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 13:41:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:57 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:57 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:57 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:57 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:57 --> Database Driver Class Initialized
INFO - 2016-10-26 13:41:57 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:41:57 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 13:41:57 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 13:41:57 --> Final output sent to browser
DEBUG - 2016-10-26 13:41:57 --> Total execution time: 4.6154
INFO - 2016-10-26 13:42:03 --> Config Class Initialized
INFO - 2016-10-26 13:42:03 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:42:03 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:42:03 --> Utf8 Class Initialized
INFO - 2016-10-26 13:42:03 --> URI Class Initialized
INFO - 2016-10-26 13:42:03 --> Router Class Initialized
INFO - 2016-10-26 13:42:03 --> Output Class Initialized
INFO - 2016-10-26 13:42:03 --> Security Class Initialized
DEBUG - 2016-10-26 13:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:42:03 --> Input Class Initialized
INFO - 2016-10-26 13:42:03 --> Language Class Initialized
INFO - 2016-10-26 13:42:04 --> Language Class Initialized
INFO - 2016-10-26 13:42:04 --> Config Class Initialized
INFO - 2016-10-26 13:42:04 --> Loader Class Initialized
INFO - 2016-10-26 13:42:04 --> Helper loaded: url_helper
INFO - 2016-10-26 13:42:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:42:04 --> Controller Class Initialized
DEBUG - 2016-10-26 13:42:04 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:42:04 --> Model Class Initialized
INFO - 2016-10-26 13:42:04 --> Model Class Initialized
ERROR - 2016-10-26 13:42:04 --> Unable to delete cache file for admin/index/detail_anggota/c1dfd96eea8cc2b62785275bca38ac261256e278
DEBUG - 2016-10-26 13:42:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 13:42:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 13:42:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
INFO - 2016-10-26 13:42:04 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:42:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_pinjaman.php
INFO - 2016-10-26 13:42:04 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:42:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_tabungan.php
DEBUG - 2016-10-26 13:42:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/profile_anggota.php
DEBUG - 2016-10-26 13:42:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 13:42:05 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 13:42:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:06 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:06 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:06 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:06 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:06 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:06 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:06 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:06 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:06 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:06 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:06 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:06 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:06 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:06 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:06 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:06 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:06 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:07 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:07 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:07 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:07 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:07 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:07 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:07 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:07 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:07 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:07 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:07 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:07 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:07 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:07 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:07 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:07 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:07 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:07 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:07 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:07 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:07 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:08 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:08 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:08 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:08 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:08 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:42:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 13:42:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 13:42:08 --> Final output sent to browser
INFO - 2016-10-26 13:42:08 --> Config Class Initialized
INFO - 2016-10-26 13:42:08 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:42:08 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:42:08 --> Utf8 Class Initialized
DEBUG - 2016-10-26 13:42:08 --> Total execution time: 5.1138
INFO - 2016-10-26 13:42:08 --> URI Class Initialized
INFO - 2016-10-26 13:42:08 --> Router Class Initialized
INFO - 2016-10-26 13:42:08 --> Output Class Initialized
INFO - 2016-10-26 13:42:08 --> Security Class Initialized
DEBUG - 2016-10-26 13:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:42:08 --> Input Class Initialized
INFO - 2016-10-26 13:42:09 --> Language Class Initialized
INFO - 2016-10-26 13:42:09 --> Language Class Initialized
INFO - 2016-10-26 13:42:09 --> Config Class Initialized
INFO - 2016-10-26 13:42:09 --> Loader Class Initialized
INFO - 2016-10-26 13:42:09 --> Helper loaded: url_helper
INFO - 2016-10-26 13:42:09 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:42:09 --> Controller Class Initialized
DEBUG - 2016-10-26 13:42:09 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:42:09 --> Model Class Initialized
INFO - 2016-10-26 13:42:10 --> Model Class Initialized
ERROR - 2016-10-26 13:42:10 --> Unable to delete cache file for admin/index/detail_anggota/images/picture.jpg
DEBUG - 2016-10-26 13:42:10 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 13:42:10 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 13:42:10 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
ERROR - 2016-10-26 13:42:10 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 16
ERROR - 2016-10-26 13:42:10 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 19
ERROR - 2016-10-26 13:42:10 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 22
ERROR - 2016-10-26 13:42:10 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 38
INFO - 2016-10-26 13:42:10 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:42:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_pinjaman.php
ERROR - 2016-10-26 13:42:11 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 41
INFO - 2016-10-26 13:42:11 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:42:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_tabungan.php
DEBUG - 2016-10-26 13:42:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/profile_anggota.php
DEBUG - 2016-10-26 13:42:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 13:42:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 13:42:12 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:12 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:12 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:12 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:12 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:12 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:12 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:12 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:12 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:12 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:13 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:13 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:13 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:13 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:13 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:13 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:13 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:16 --> Config Class Initialized
INFO - 2016-10-26 13:42:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:16 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:42:17 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:42:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:17 --> Utf8 Class Initialized
INFO - 2016-10-26 13:42:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:17 --> URI Class Initialized
INFO - 2016-10-26 13:42:17 --> Router Class Initialized
INFO - 2016-10-26 13:42:17 --> Output Class Initialized
INFO - 2016-10-26 13:42:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:17 --> Security Class Initialized
INFO - 2016-10-26 13:42:17 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:42:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:18 --> Input Class Initialized
INFO - 2016-10-26 13:42:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:18 --> Language Class Initialized
INFO - 2016-10-26 13:42:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:18 --> Language Class Initialized
INFO - 2016-10-26 13:42:18 --> Config Class Initialized
INFO - 2016-10-26 13:42:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:18 --> Loader Class Initialized
INFO - 2016-10-26 13:42:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:18 --> Helper loaded: url_helper
INFO - 2016-10-26 13:42:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:19 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:19 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:19 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:19 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:19 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:19 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:19 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:19 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:19 --> Database Driver Class Initialized
INFO - 2016-10-26 13:42:20 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:42:20 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 13:42:20 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 13:42:20 --> Final output sent to browser
DEBUG - 2016-10-26 13:42:20 --> Total execution time: 11.6636
INFO - 2016-10-26 13:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:42:20 --> Controller Class Initialized
DEBUG - 2016-10-26 13:42:20 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:42:20 --> Model Class Initialized
INFO - 2016-10-26 13:42:20 --> Model Class Initialized
ERROR - 2016-10-26 13:42:20 --> Unable to delete cache file for admin/index/getRaportAngsuran/fc074d501302eb2b93e2554793fcaf50b3bf7291
DEBUG - 2016-10-26 13:42:20 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/raport_angsuran.php
INFO - 2016-10-26 13:42:20 --> Final output sent to browser
DEBUG - 2016-10-26 13:42:20 --> Total execution time: 4.2260
INFO - 2016-10-26 13:43:13 --> Config Class Initialized
INFO - 2016-10-26 13:43:13 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:43:13 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:43:13 --> Utf8 Class Initialized
INFO - 2016-10-26 13:43:13 --> URI Class Initialized
INFO - 2016-10-26 13:43:13 --> Router Class Initialized
INFO - 2016-10-26 13:43:13 --> Output Class Initialized
INFO - 2016-10-26 13:43:13 --> Security Class Initialized
DEBUG - 2016-10-26 13:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:43:13 --> Input Class Initialized
INFO - 2016-10-26 13:43:13 --> Language Class Initialized
INFO - 2016-10-26 13:43:13 --> Language Class Initialized
INFO - 2016-10-26 13:43:13 --> Config Class Initialized
INFO - 2016-10-26 13:43:13 --> Loader Class Initialized
INFO - 2016-10-26 13:43:13 --> Helper loaded: url_helper
INFO - 2016-10-26 13:43:13 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:43:14 --> Controller Class Initialized
DEBUG - 2016-10-26 13:43:14 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:43:14 --> Model Class Initialized
INFO - 2016-10-26 13:43:14 --> Model Class Initialized
ERROR - 2016-10-26 13:43:14 --> Unable to delete cache file for admin/index/data/anggota/umum
DEBUG - 2016-10-26 13:43:14 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 13:43:14 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 13:43:14 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-26 13:43:14 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-26 13:43:14 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-26 13:43:14 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-26 13:43:14 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 13:43:14 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 13:43:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:17 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:43:17 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 13:43:17 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 13:43:17 --> Final output sent to browser
DEBUG - 2016-10-26 13:43:17 --> Total execution time: 4.6168
INFO - 2016-10-26 13:43:22 --> Config Class Initialized
INFO - 2016-10-26 13:43:22 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:43:22 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:43:22 --> Utf8 Class Initialized
INFO - 2016-10-26 13:43:23 --> URI Class Initialized
INFO - 2016-10-26 13:43:23 --> Router Class Initialized
INFO - 2016-10-26 13:43:23 --> Output Class Initialized
INFO - 2016-10-26 13:43:23 --> Security Class Initialized
DEBUG - 2016-10-26 13:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:43:23 --> Input Class Initialized
INFO - 2016-10-26 13:43:23 --> Language Class Initialized
INFO - 2016-10-26 13:43:23 --> Language Class Initialized
INFO - 2016-10-26 13:43:23 --> Config Class Initialized
INFO - 2016-10-26 13:43:23 --> Loader Class Initialized
INFO - 2016-10-26 13:43:23 --> Helper loaded: url_helper
INFO - 2016-10-26 13:43:23 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:43:23 --> Controller Class Initialized
DEBUG - 2016-10-26 13:43:23 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:43:23 --> Model Class Initialized
INFO - 2016-10-26 13:43:24 --> Model Class Initialized
ERROR - 2016-10-26 13:43:24 --> Unable to delete cache file for admin/index/detail_anggota/902ba3cda1883801594b6e1b452790cc53948fda
DEBUG - 2016-10-26 13:43:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 13:43:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 13:43:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
INFO - 2016-10-26 13:43:24 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:43:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_pinjaman.php
INFO - 2016-10-26 13:43:24 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:43:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_tabungan.php
DEBUG - 2016-10-26 13:43:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/profile_anggota.php
DEBUG - 2016-10-26 13:43:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 13:43:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 13:43:24 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:24 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:25 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:25 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:25 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:25 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:25 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:25 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:25 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:25 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:25 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:25 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:25 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:25 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:25 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:25 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:25 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:25 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:25 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:27 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:27 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:27 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:27 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:27 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:27 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:27 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:27 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:27 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:27 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:27 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:27 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:27 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:27 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:27 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:27 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:27 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:28 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:28 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:28 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:28 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:28 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:28 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:43:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 13:43:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 13:43:28 --> Final output sent to browser
DEBUG - 2016-10-26 13:43:28 --> Total execution time: 5.8386
INFO - 2016-10-26 13:43:28 --> Config Class Initialized
INFO - 2016-10-26 13:43:28 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:43:28 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:43:28 --> Utf8 Class Initialized
INFO - 2016-10-26 13:43:28 --> URI Class Initialized
INFO - 2016-10-26 13:43:28 --> Router Class Initialized
INFO - 2016-10-26 13:43:29 --> Output Class Initialized
INFO - 2016-10-26 13:43:29 --> Security Class Initialized
DEBUG - 2016-10-26 13:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:43:29 --> Input Class Initialized
INFO - 2016-10-26 13:43:29 --> Language Class Initialized
INFO - 2016-10-26 13:43:29 --> Language Class Initialized
INFO - 2016-10-26 13:43:29 --> Config Class Initialized
INFO - 2016-10-26 13:43:29 --> Loader Class Initialized
INFO - 2016-10-26 13:43:29 --> Helper loaded: url_helper
INFO - 2016-10-26 13:43:29 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:43:29 --> Controller Class Initialized
DEBUG - 2016-10-26 13:43:29 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:43:30 --> Model Class Initialized
INFO - 2016-10-26 13:43:30 --> Model Class Initialized
ERROR - 2016-10-26 13:43:30 --> Unable to delete cache file for admin/index/detail_anggota/images/picture.jpg
DEBUG - 2016-10-26 13:43:30 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 13:43:30 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 13:43:30 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
ERROR - 2016-10-26 13:43:30 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 16
ERROR - 2016-10-26 13:43:30 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 19
ERROR - 2016-10-26 13:43:30 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 22
ERROR - 2016-10-26 13:43:30 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 38
INFO - 2016-10-26 13:43:31 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:43:31 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_pinjaman.php
ERROR - 2016-10-26 13:43:31 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 41
INFO - 2016-10-26 13:43:31 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:43:31 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_tabungan.php
DEBUG - 2016-10-26 13:43:31 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/profile_anggota.php
DEBUG - 2016-10-26 13:43:31 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 13:43:31 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 13:43:32 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:32 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:32 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:32 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:32 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:32 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:32 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:32 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:33 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:33 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:33 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:33 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:33 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:33 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:33 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:33 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:33 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:33 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:33 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:33 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:33 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:33 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:33 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:33 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:34 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:34 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:34 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:34 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:34 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:34 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:34 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:35 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:35 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:35 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:36 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:36 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:36 --> Config Class Initialized
INFO - 2016-10-26 13:43:36 --> Hooks Class Initialized
INFO - 2016-10-26 13:43:36 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:43:36 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:43:37 --> Utf8 Class Initialized
INFO - 2016-10-26 13:43:37 --> URI Class Initialized
INFO - 2016-10-26 13:43:37 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:37 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:37 --> Router Class Initialized
INFO - 2016-10-26 13:43:37 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:37 --> Output Class Initialized
INFO - 2016-10-26 13:43:37 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:37 --> Security Class Initialized
DEBUG - 2016-10-26 13:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:43:37 --> Input Class Initialized
INFO - 2016-10-26 13:43:37 --> Language Class Initialized
INFO - 2016-10-26 13:43:37 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:37 --> Language Class Initialized
INFO - 2016-10-26 13:43:37 --> Config Class Initialized
INFO - 2016-10-26 13:43:38 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:38 --> Loader Class Initialized
INFO - 2016-10-26 13:43:38 --> Helper loaded: url_helper
INFO - 2016-10-26 13:43:38 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:38 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:38 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:38 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:38 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:38 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:38 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:38 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:38 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:43:39 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:43:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 13:43:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 13:43:39 --> Final output sent to browser
DEBUG - 2016-10-26 13:43:39 --> Total execution time: 11.3019
INFO - 2016-10-26 13:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:43:40 --> Controller Class Initialized
DEBUG - 2016-10-26 13:43:40 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:43:40 --> Model Class Initialized
INFO - 2016-10-26 13:43:40 --> Model Class Initialized
ERROR - 2016-10-26 13:43:40 --> Unable to delete cache file for admin/index/getRaportAngsuran/5b384ce32d8cdef02bc3a139d4cac0a22bb029e8
DEBUG - 2016-10-26 13:43:40 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/raport_angsuran.php
INFO - 2016-10-26 13:43:40 --> Final output sent to browser
DEBUG - 2016-10-26 13:43:40 --> Total execution time: 3.8851
INFO - 2016-10-26 13:44:47 --> Config Class Initialized
INFO - 2016-10-26 13:44:47 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:44:47 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:44:47 --> Utf8 Class Initialized
INFO - 2016-10-26 13:44:47 --> URI Class Initialized
INFO - 2016-10-26 13:44:47 --> Router Class Initialized
INFO - 2016-10-26 13:44:47 --> Output Class Initialized
INFO - 2016-10-26 13:44:47 --> Security Class Initialized
DEBUG - 2016-10-26 13:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:44:47 --> Input Class Initialized
INFO - 2016-10-26 13:44:47 --> Language Class Initialized
INFO - 2016-10-26 13:44:47 --> Language Class Initialized
INFO - 2016-10-26 13:44:48 --> Config Class Initialized
INFO - 2016-10-26 13:44:48 --> Loader Class Initialized
INFO - 2016-10-26 13:44:48 --> Helper loaded: url_helper
INFO - 2016-10-26 13:44:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:44:48 --> Controller Class Initialized
DEBUG - 2016-10-26 13:44:48 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:44:48 --> Model Class Initialized
INFO - 2016-10-26 13:44:48 --> Model Class Initialized
ERROR - 2016-10-26 13:44:48 --> Unable to delete cache file for admin/index/getRaportAngsuran/5b384ce32d8cdef02bc3a139d4cac0a22bb029e8
DEBUG - 2016-10-26 13:44:48 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/raport_angsuran.php
INFO - 2016-10-26 13:44:48 --> Final output sent to browser
DEBUG - 2016-10-26 13:44:48 --> Total execution time: 1.2877
INFO - 2016-10-26 13:44:56 --> Config Class Initialized
INFO - 2016-10-26 13:44:56 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:44:56 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:44:56 --> Utf8 Class Initialized
INFO - 2016-10-26 13:44:56 --> URI Class Initialized
INFO - 2016-10-26 13:44:56 --> Router Class Initialized
INFO - 2016-10-26 13:44:56 --> Output Class Initialized
INFO - 2016-10-26 13:44:56 --> Security Class Initialized
DEBUG - 2016-10-26 13:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:44:56 --> Input Class Initialized
INFO - 2016-10-26 13:44:56 --> Language Class Initialized
INFO - 2016-10-26 13:44:56 --> Language Class Initialized
INFO - 2016-10-26 13:44:56 --> Config Class Initialized
INFO - 2016-10-26 13:44:57 --> Loader Class Initialized
INFO - 2016-10-26 13:44:57 --> Helper loaded: url_helper
INFO - 2016-10-26 13:44:57 --> Database Driver Class Initialized
INFO - 2016-10-26 13:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:44:57 --> Controller Class Initialized
DEBUG - 2016-10-26 13:44:57 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:44:57 --> Model Class Initialized
INFO - 2016-10-26 13:44:57 --> Model Class Initialized
ERROR - 2016-10-26 13:44:57 --> Unable to delete cache file for admin/index/getRaportAngsuran/5b384ce32d8cdef02bc3a139d4cac0a22bb029e8
DEBUG - 2016-10-26 13:44:57 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/raport_angsuran.php
INFO - 2016-10-26 13:44:57 --> Final output sent to browser
DEBUG - 2016-10-26 13:44:57 --> Total execution time: 1.0939
INFO - 2016-10-26 13:49:46 --> Config Class Initialized
INFO - 2016-10-26 13:49:46 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:49:46 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:49:46 --> Utf8 Class Initialized
INFO - 2016-10-26 13:49:46 --> URI Class Initialized
INFO - 2016-10-26 13:49:46 --> Router Class Initialized
INFO - 2016-10-26 13:49:46 --> Output Class Initialized
INFO - 2016-10-26 13:49:46 --> Security Class Initialized
DEBUG - 2016-10-26 13:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:49:46 --> Input Class Initialized
INFO - 2016-10-26 13:49:46 --> Language Class Initialized
INFO - 2016-10-26 13:49:46 --> Language Class Initialized
INFO - 2016-10-26 13:49:46 --> Config Class Initialized
INFO - 2016-10-26 13:49:46 --> Loader Class Initialized
INFO - 2016-10-26 13:49:46 --> Helper loaded: url_helper
INFO - 2016-10-26 13:49:46 --> Database Driver Class Initialized
INFO - 2016-10-26 13:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:49:46 --> Controller Class Initialized
DEBUG - 2016-10-26 13:49:47 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:49:47 --> Model Class Initialized
INFO - 2016-10-26 13:49:47 --> Model Class Initialized
ERROR - 2016-10-26 13:49:47 --> Unable to delete cache file for admin/index/getRaportAngsuran/5b384ce32d8cdef02bc3a139d4cac0a22bb029e8
DEBUG - 2016-10-26 13:49:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/raport_angsuran.php
INFO - 2016-10-26 13:49:47 --> Final output sent to browser
DEBUG - 2016-10-26 13:49:47 --> Total execution time: 1.1338
INFO - 2016-10-26 13:51:09 --> Config Class Initialized
INFO - 2016-10-26 13:51:10 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:51:10 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:51:10 --> Utf8 Class Initialized
INFO - 2016-10-26 13:51:10 --> URI Class Initialized
INFO - 2016-10-26 13:51:10 --> Router Class Initialized
INFO - 2016-10-26 13:51:10 --> Output Class Initialized
INFO - 2016-10-26 13:51:10 --> Security Class Initialized
DEBUG - 2016-10-26 13:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:51:10 --> Input Class Initialized
INFO - 2016-10-26 13:51:10 --> Language Class Initialized
INFO - 2016-10-26 13:51:10 --> Language Class Initialized
INFO - 2016-10-26 13:51:10 --> Config Class Initialized
INFO - 2016-10-26 13:51:10 --> Loader Class Initialized
INFO - 2016-10-26 13:51:10 --> Helper loaded: url_helper
INFO - 2016-10-26 13:51:10 --> Database Driver Class Initialized
INFO - 2016-10-26 13:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:51:10 --> Controller Class Initialized
DEBUG - 2016-10-26 13:51:10 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:51:10 --> Model Class Initialized
INFO - 2016-10-26 13:51:10 --> Model Class Initialized
ERROR - 2016-10-26 13:51:10 --> Unable to delete cache file for admin/index/getRaportAngsuran/5b384ce32d8cdef02bc3a139d4cac0a22bb029e8
DEBUG - 2016-10-26 13:51:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/raport_angsuran.php
INFO - 2016-10-26 13:51:11 --> Final output sent to browser
DEBUG - 2016-10-26 13:51:11 --> Total execution time: 1.0716
INFO - 2016-10-26 13:51:45 --> Config Class Initialized
INFO - 2016-10-26 13:51:45 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:51:45 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:51:45 --> Utf8 Class Initialized
INFO - 2016-10-26 13:51:45 --> URI Class Initialized
INFO - 2016-10-26 13:51:45 --> Router Class Initialized
INFO - 2016-10-26 13:51:45 --> Output Class Initialized
INFO - 2016-10-26 13:51:45 --> Security Class Initialized
DEBUG - 2016-10-26 13:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:51:45 --> Input Class Initialized
INFO - 2016-10-26 13:51:45 --> Language Class Initialized
INFO - 2016-10-26 13:51:45 --> Language Class Initialized
INFO - 2016-10-26 13:51:45 --> Config Class Initialized
INFO - 2016-10-26 13:51:45 --> Loader Class Initialized
INFO - 2016-10-26 13:51:46 --> Helper loaded: url_helper
INFO - 2016-10-26 13:51:46 --> Database Driver Class Initialized
INFO - 2016-10-26 13:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:51:46 --> Controller Class Initialized
DEBUG - 2016-10-26 13:51:46 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:51:46 --> Model Class Initialized
INFO - 2016-10-26 13:51:46 --> Model Class Initialized
ERROR - 2016-10-26 13:51:46 --> Unable to delete cache file for admin/index/getRaportAngsuran/5b384ce32d8cdef02bc3a139d4cac0a22bb029e8
DEBUG - 2016-10-26 13:51:46 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/raport_angsuran.php
INFO - 2016-10-26 13:51:46 --> Final output sent to browser
DEBUG - 2016-10-26 13:51:46 --> Total execution time: 1.0301
INFO - 2016-10-26 13:52:01 --> Config Class Initialized
INFO - 2016-10-26 13:52:01 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:52:01 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:52:01 --> Utf8 Class Initialized
INFO - 2016-10-26 13:52:01 --> URI Class Initialized
INFO - 2016-10-26 13:52:01 --> Router Class Initialized
INFO - 2016-10-26 13:52:01 --> Output Class Initialized
INFO - 2016-10-26 13:52:01 --> Security Class Initialized
DEBUG - 2016-10-26 13:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:52:01 --> Input Class Initialized
INFO - 2016-10-26 13:52:01 --> Language Class Initialized
INFO - 2016-10-26 13:52:01 --> Language Class Initialized
INFO - 2016-10-26 13:52:01 --> Config Class Initialized
INFO - 2016-10-26 13:52:02 --> Loader Class Initialized
INFO - 2016-10-26 13:52:02 --> Helper loaded: url_helper
INFO - 2016-10-26 13:52:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:52:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:52:02 --> Controller Class Initialized
DEBUG - 2016-10-26 13:52:02 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:52:02 --> Model Class Initialized
INFO - 2016-10-26 13:52:02 --> Model Class Initialized
ERROR - 2016-10-26 13:52:02 --> Unable to delete cache file for admin/index/getRaportAngsuran/5b384ce32d8cdef02bc3a139d4cac0a22bb029e8
DEBUG - 2016-10-26 13:52:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/raport_angsuran.php
INFO - 2016-10-26 13:52:02 --> Final output sent to browser
DEBUG - 2016-10-26 13:52:02 --> Total execution time: 1.0420
INFO - 2016-10-26 13:52:20 --> Config Class Initialized
INFO - 2016-10-26 13:52:20 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:52:20 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:52:20 --> Utf8 Class Initialized
INFO - 2016-10-26 13:52:20 --> URI Class Initialized
INFO - 2016-10-26 13:52:20 --> Router Class Initialized
INFO - 2016-10-26 13:52:20 --> Output Class Initialized
INFO - 2016-10-26 13:52:20 --> Security Class Initialized
DEBUG - 2016-10-26 13:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:52:20 --> Input Class Initialized
INFO - 2016-10-26 13:52:20 --> Language Class Initialized
INFO - 2016-10-26 13:52:21 --> Language Class Initialized
INFO - 2016-10-26 13:52:21 --> Config Class Initialized
INFO - 2016-10-26 13:52:21 --> Loader Class Initialized
INFO - 2016-10-26 13:52:21 --> Helper loaded: url_helper
INFO - 2016-10-26 13:52:21 --> Database Driver Class Initialized
INFO - 2016-10-26 13:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:52:21 --> Controller Class Initialized
DEBUG - 2016-10-26 13:52:21 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:52:21 --> Model Class Initialized
INFO - 2016-10-26 13:52:21 --> Model Class Initialized
ERROR - 2016-10-26 13:52:21 --> Unable to delete cache file for admin/index/getRaportAngsuran/5b384ce32d8cdef02bc3a139d4cac0a22bb029e8
DEBUG - 2016-10-26 13:52:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/raport_angsuran.php
INFO - 2016-10-26 13:52:21 --> Final output sent to browser
DEBUG - 2016-10-26 13:52:21 --> Total execution time: 1.0807
INFO - 2016-10-26 13:53:24 --> Config Class Initialized
INFO - 2016-10-26 13:53:24 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:53:24 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:53:24 --> Utf8 Class Initialized
INFO - 2016-10-26 13:53:25 --> URI Class Initialized
INFO - 2016-10-26 13:53:25 --> Router Class Initialized
INFO - 2016-10-26 13:53:25 --> Output Class Initialized
INFO - 2016-10-26 13:53:25 --> Security Class Initialized
DEBUG - 2016-10-26 13:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:53:25 --> Input Class Initialized
INFO - 2016-10-26 13:53:25 --> Language Class Initialized
INFO - 2016-10-26 13:53:25 --> Language Class Initialized
INFO - 2016-10-26 13:53:25 --> Config Class Initialized
INFO - 2016-10-26 13:53:25 --> Loader Class Initialized
INFO - 2016-10-26 13:53:25 --> Helper loaded: url_helper
INFO - 2016-10-26 13:53:25 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:53:25 --> Controller Class Initialized
DEBUG - 2016-10-26 13:53:25 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:53:25 --> Model Class Initialized
INFO - 2016-10-26 13:53:25 --> Model Class Initialized
ERROR - 2016-10-26 13:53:25 --> Unable to delete cache file for admin/index/data/anggota
DEBUG - 2016-10-26 13:53:25 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 13:53:25 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 13:53:25 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-26 13:53:25 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-26 13:53:25 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-26 13:53:25 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-26 13:53:25 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 13:53:25 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 13:53:25 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:25 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:25 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:25 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:27 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:27 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:27 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:27 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:27 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:27 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:27 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:27 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:27 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:27 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:27 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:27 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:27 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:27 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:27 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:27 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:27 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:27 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:27 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:27 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:27 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:27 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:27 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:27 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:27 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:27 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:28 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:28 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:28 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:53:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 13:53:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 13:53:28 --> Final output sent to browser
DEBUG - 2016-10-26 13:53:28 --> Total execution time: 3.3021
INFO - 2016-10-26 13:53:37 --> Config Class Initialized
INFO - 2016-10-26 13:53:37 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:53:37 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:53:37 --> Utf8 Class Initialized
INFO - 2016-10-26 13:53:38 --> URI Class Initialized
INFO - 2016-10-26 13:53:38 --> Config Class Initialized
INFO - 2016-10-26 13:53:38 --> Hooks Class Initialized
INFO - 2016-10-26 13:53:38 --> Router Class Initialized
INFO - 2016-10-26 13:53:38 --> Output Class Initialized
DEBUG - 2016-10-26 13:53:38 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:53:38 --> Utf8 Class Initialized
INFO - 2016-10-26 13:53:38 --> Security Class Initialized
DEBUG - 2016-10-26 13:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:53:38 --> URI Class Initialized
INFO - 2016-10-26 13:53:38 --> Input Class Initialized
INFO - 2016-10-26 13:53:38 --> Language Class Initialized
INFO - 2016-10-26 13:53:38 --> Router Class Initialized
INFO - 2016-10-26 13:53:38 --> Output Class Initialized
INFO - 2016-10-26 13:53:38 --> Language Class Initialized
INFO - 2016-10-26 13:53:38 --> Config Class Initialized
INFO - 2016-10-26 13:53:38 --> Security Class Initialized
DEBUG - 2016-10-26 13:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:53:38 --> Loader Class Initialized
INFO - 2016-10-26 13:53:38 --> Input Class Initialized
INFO - 2016-10-26 13:53:38 --> Helper loaded: url_helper
INFO - 2016-10-26 13:53:38 --> Language Class Initialized
INFO - 2016-10-26 13:53:38 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:38 --> Language Class Initialized
INFO - 2016-10-26 13:53:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:53:38 --> Controller Class Initialized
INFO - 2016-10-26 13:53:38 --> Config Class Initialized
DEBUG - 2016-10-26 13:53:38 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:53:38 --> Model Class Initialized
INFO - 2016-10-26 13:53:38 --> Loader Class Initialized
INFO - 2016-10-26 13:53:38 --> Model Class Initialized
INFO - 2016-10-26 13:53:38 --> Helper loaded: url_helper
ERROR - 2016-10-26 13:53:38 --> Unable to delete cache file for admin/index/data/anggota/umum
DEBUG - 2016-10-26 13:53:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
INFO - 2016-10-26 13:53:38 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:53:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 13:53:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-26 13:53:38 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-26 13:53:38 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-26 13:53:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-26 13:53:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 13:53:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 13:53:38 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:38 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:38 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:41 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:53:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 13:53:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 13:53:41 --> Final output sent to browser
DEBUG - 2016-10-26 13:53:41 --> Total execution time: 3.6395
INFO - 2016-10-26 13:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:53:41 --> Controller Class Initialized
DEBUG - 2016-10-26 13:53:41 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:53:41 --> Model Class Initialized
INFO - 2016-10-26 13:53:41 --> Model Class Initialized
ERROR - 2016-10-26 13:53:41 --> Unable to delete cache file for admin/index/data/anggota/umum
DEBUG - 2016-10-26 13:53:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 13:53:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 13:53:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-26 13:53:41 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-26 13:53:41 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-26 13:53:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-26 13:53:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 13:53:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 13:53:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:42 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:42 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:42 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:42 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:42 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:42 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:42 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:42 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:42 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:42 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:42 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:42 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:42 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:42 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:42 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:42 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:42 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:42 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:42 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:42 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:42 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:42 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:42 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:42 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:44 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:53:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 13:53:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 13:53:44 --> Final output sent to browser
DEBUG - 2016-10-26 13:53:44 --> Total execution time: 6.5971
INFO - 2016-10-26 13:53:50 --> Config Class Initialized
INFO - 2016-10-26 13:53:50 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:53:50 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:53:50 --> Utf8 Class Initialized
INFO - 2016-10-26 13:53:50 --> URI Class Initialized
INFO - 2016-10-26 13:53:50 --> Router Class Initialized
INFO - 2016-10-26 13:53:50 --> Output Class Initialized
INFO - 2016-10-26 13:53:50 --> Security Class Initialized
INFO - 2016-10-26 13:53:50 --> Config Class Initialized
INFO - 2016-10-26 13:53:50 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:53:50 --> Input Class Initialized
DEBUG - 2016-10-26 13:53:50 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:53:50 --> Utf8 Class Initialized
INFO - 2016-10-26 13:53:50 --> Language Class Initialized
INFO - 2016-10-26 13:53:50 --> URI Class Initialized
INFO - 2016-10-26 13:53:50 --> Language Class Initialized
INFO - 2016-10-26 13:53:50 --> Config Class Initialized
INFO - 2016-10-26 13:53:50 --> Router Class Initialized
INFO - 2016-10-26 13:53:50 --> Output Class Initialized
INFO - 2016-10-26 13:53:50 --> Loader Class Initialized
INFO - 2016-10-26 13:53:50 --> Helper loaded: url_helper
INFO - 2016-10-26 13:53:50 --> Security Class Initialized
DEBUG - 2016-10-26 13:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:53:50 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:50 --> Input Class Initialized
INFO - 2016-10-26 13:53:50 --> Language Class Initialized
INFO - 2016-10-26 13:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:53:50 --> Controller Class Initialized
INFO - 2016-10-26 13:53:50 --> Language Class Initialized
DEBUG - 2016-10-26 13:53:50 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:53:50 --> Config Class Initialized
INFO - 2016-10-26 13:53:50 --> Model Class Initialized
INFO - 2016-10-26 13:53:50 --> Loader Class Initialized
INFO - 2016-10-26 13:53:50 --> Model Class Initialized
ERROR - 2016-10-26 13:53:50 --> Unable to delete cache file for admin/index/detail_anggota/902ba3cda1883801594b6e1b452790cc53948fda
INFO - 2016-10-26 13:53:50 --> Helper loaded: url_helper
DEBUG - 2016-10-26 13:53:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
INFO - 2016-10-26 13:53:51 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:53:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 13:53:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
INFO - 2016-10-26 13:53:51 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:53:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_pinjaman.php
INFO - 2016-10-26 13:53:51 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:53:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_tabungan.php
DEBUG - 2016-10-26 13:53:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/profile_anggota.php
DEBUG - 2016-10-26 13:53:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 13:53:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 13:53:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:53 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:53:53 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 13:53:53 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 13:53:54 --> Final output sent to browser
DEBUG - 2016-10-26 13:53:54 --> Total execution time: 3.9461
INFO - 2016-10-26 13:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:53:54 --> Controller Class Initialized
DEBUG - 2016-10-26 13:53:54 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:53:54 --> Model Class Initialized
INFO - 2016-10-26 13:53:54 --> Model Class Initialized
ERROR - 2016-10-26 13:53:54 --> Unable to delete cache file for admin/index/detail_anggota/902ba3cda1883801594b6e1b452790cc53948fda
DEBUG - 2016-10-26 13:53:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 13:53:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 13:53:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
INFO - 2016-10-26 13:53:54 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:53:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_pinjaman.php
INFO - 2016-10-26 13:53:54 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:53:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_tabungan.php
DEBUG - 2016-10-26 13:53:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/profile_anggota.php
DEBUG - 2016-10-26 13:53:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 13:53:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 13:53:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:57 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:57 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:57 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:57 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:57 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:57 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:53:57 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 13:53:57 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 13:53:57 --> Final output sent to browser
DEBUG - 2016-10-26 13:53:57 --> Total execution time: 6.8858
INFO - 2016-10-26 13:53:57 --> Config Class Initialized
INFO - 2016-10-26 13:53:57 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:53:57 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:53:57 --> Utf8 Class Initialized
INFO - 2016-10-26 13:53:57 --> URI Class Initialized
INFO - 2016-10-26 13:53:57 --> Router Class Initialized
INFO - 2016-10-26 13:53:57 --> Output Class Initialized
INFO - 2016-10-26 13:53:57 --> Security Class Initialized
DEBUG - 2016-10-26 13:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:53:57 --> Input Class Initialized
INFO - 2016-10-26 13:53:58 --> Language Class Initialized
INFO - 2016-10-26 13:53:58 --> Language Class Initialized
INFO - 2016-10-26 13:53:58 --> Config Class Initialized
INFO - 2016-10-26 13:53:58 --> Loader Class Initialized
INFO - 2016-10-26 13:53:58 --> Helper loaded: url_helper
INFO - 2016-10-26 13:53:58 --> Database Driver Class Initialized
INFO - 2016-10-26 13:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:53:58 --> Controller Class Initialized
DEBUG - 2016-10-26 13:53:58 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:53:58 --> Model Class Initialized
INFO - 2016-10-26 13:53:58 --> Model Class Initialized
ERROR - 2016-10-26 13:53:58 --> Unable to delete cache file for admin/index/detail_anggota/images/picture.jpg
DEBUG - 2016-10-26 13:53:58 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 13:53:58 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 13:53:59 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
ERROR - 2016-10-26 13:53:59 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 16
ERROR - 2016-10-26 13:53:59 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 19
ERROR - 2016-10-26 13:53:59 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 22
ERROR - 2016-10-26 13:53:59 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 38
INFO - 2016-10-26 13:53:59 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:53:59 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_pinjaman.php
ERROR - 2016-10-26 13:53:59 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 41
INFO - 2016-10-26 13:53:59 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:53:59 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_tabungan.php
DEBUG - 2016-10-26 13:53:59 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/profile_anggota.php
DEBUG - 2016-10-26 13:53:59 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 13:54:00 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 13:54:00 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:00 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:00 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:00 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:00 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:00 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:00 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:00 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:00 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:05 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:54:05 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 13:54:05 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 13:54:05 --> Final output sent to browser
DEBUG - 2016-10-26 13:54:05 --> Total execution time: 7.8007
INFO - 2016-10-26 13:54:08 --> Config Class Initialized
INFO - 2016-10-26 13:54:08 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:54:08 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:54:08 --> Utf8 Class Initialized
INFO - 2016-10-26 13:54:08 --> URI Class Initialized
INFO - 2016-10-26 13:54:08 --> Router Class Initialized
INFO - 2016-10-26 13:54:08 --> Output Class Initialized
INFO - 2016-10-26 13:54:08 --> Security Class Initialized
DEBUG - 2016-10-26 13:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:54:09 --> Input Class Initialized
INFO - 2016-10-26 13:54:09 --> Language Class Initialized
INFO - 2016-10-26 13:54:09 --> Language Class Initialized
INFO - 2016-10-26 13:54:09 --> Config Class Initialized
INFO - 2016-10-26 13:54:09 --> Loader Class Initialized
INFO - 2016-10-26 13:54:09 --> Helper loaded: url_helper
INFO - 2016-10-26 13:54:09 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:54:09 --> Controller Class Initialized
DEBUG - 2016-10-26 13:54:09 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:54:09 --> Model Class Initialized
INFO - 2016-10-26 13:54:09 --> Model Class Initialized
ERROR - 2016-10-26 13:54:09 --> Unable to delete cache file for admin/index/getRaportAngsuran/5b384ce32d8cdef02bc3a139d4cac0a22bb029e8
DEBUG - 2016-10-26 13:54:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/raport_angsuran.php
INFO - 2016-10-26 13:54:09 --> Final output sent to browser
DEBUG - 2016-10-26 13:54:09 --> Total execution time: 1.1150
INFO - 2016-10-26 13:54:42 --> Config Class Initialized
INFO - 2016-10-26 13:54:42 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:54:42 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:54:42 --> Utf8 Class Initialized
INFO - 2016-10-26 13:54:42 --> URI Class Initialized
INFO - 2016-10-26 13:54:43 --> Router Class Initialized
INFO - 2016-10-26 13:54:43 --> Output Class Initialized
INFO - 2016-10-26 13:54:43 --> Security Class Initialized
DEBUG - 2016-10-26 13:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:54:43 --> Input Class Initialized
INFO - 2016-10-26 13:54:43 --> Language Class Initialized
INFO - 2016-10-26 13:54:43 --> Language Class Initialized
INFO - 2016-10-26 13:54:43 --> Config Class Initialized
INFO - 2016-10-26 13:54:43 --> Loader Class Initialized
INFO - 2016-10-26 13:54:43 --> Helper loaded: url_helper
INFO - 2016-10-26 13:54:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:54:43 --> Controller Class Initialized
DEBUG - 2016-10-26 13:54:43 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:54:43 --> Model Class Initialized
INFO - 2016-10-26 13:54:43 --> Model Class Initialized
ERROR - 2016-10-26 13:54:43 --> Unable to delete cache file for admin/index/tutup_angsuran
DEBUG - 2016-10-26 13:54:43 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 13:54:43 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 13:54:43 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-26 13:54:43 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_tutup_angsuran.php
DEBUG - 2016-10-26 13:54:43 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 13:54:43 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 13:54:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:44 --> Config Class Initialized
INFO - 2016-10-26 13:54:44 --> Hooks Class Initialized
INFO - 2016-10-26 13:54:44 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:54:44 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:54:44 --> Utf8 Class Initialized
INFO - 2016-10-26 13:54:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:44 --> Config Class Initialized
INFO - 2016-10-26 13:54:44 --> URI Class Initialized
INFO - 2016-10-26 13:54:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:44 --> Hooks Class Initialized
INFO - 2016-10-26 13:54:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:44 --> Router Class Initialized
DEBUG - 2016-10-26 13:54:44 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:54:44 --> Utf8 Class Initialized
INFO - 2016-10-26 13:54:44 --> Output Class Initialized
INFO - 2016-10-26 13:54:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:44 --> URI Class Initialized
INFO - 2016-10-26 13:54:44 --> Security Class Initialized
INFO - 2016-10-26 13:54:44 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:54:44 --> Router Class Initialized
INFO - 2016-10-26 13:54:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:44 --> Input Class Initialized
INFO - 2016-10-26 13:54:44 --> Output Class Initialized
INFO - 2016-10-26 13:54:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:45 --> Language Class Initialized
INFO - 2016-10-26 13:54:45 --> Security Class Initialized
INFO - 2016-10-26 13:54:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:45 --> Language Class Initialized
DEBUG - 2016-10-26 13:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:54:45 --> Config Class Initialized
INFO - 2016-10-26 13:54:45 --> Input Class Initialized
INFO - 2016-10-26 13:54:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:45 --> Loader Class Initialized
INFO - 2016-10-26 13:54:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:45 --> Helper loaded: url_helper
INFO - 2016-10-26 13:54:45 --> Language Class Initialized
INFO - 2016-10-26 13:54:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:45 --> Language Class Initialized
INFO - 2016-10-26 13:54:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:45 --> Config Class Initialized
INFO - 2016-10-26 13:54:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:45 --> Loader Class Initialized
INFO - 2016-10-26 13:54:45 --> Helper loaded: url_helper
INFO - 2016-10-26 13:54:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:46 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:46 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:46 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:46 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:46 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:46 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:46 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:46 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:54:46 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 13:54:46 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 13:54:46 --> Final output sent to browser
DEBUG - 2016-10-26 13:54:46 --> Total execution time: 3.5557
INFO - 2016-10-26 13:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:54:46 --> Controller Class Initialized
DEBUG - 2016-10-26 13:54:46 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:54:46 --> Model Class Initialized
INFO - 2016-10-26 13:54:46 --> Model Class Initialized
ERROR - 2016-10-26 13:54:46 --> Unable to delete cache file for admin/index/tutup_angsuran
DEBUG - 2016-10-26 13:54:46 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 13:54:46 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 13:54:46 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-26 13:54:46 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_tutup_angsuran.php
DEBUG - 2016-10-26 13:54:46 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 13:54:46 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 13:54:46 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:46 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:46 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:47 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:47 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:47 --> Config Class Initialized
INFO - 2016-10-26 13:54:47 --> Hooks Class Initialized
INFO - 2016-10-26 13:54:47 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:54:47 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:54:47 --> Utf8 Class Initialized
INFO - 2016-10-26 13:54:47 --> Config Class Initialized
INFO - 2016-10-26 13:54:47 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:47 --> Hooks Class Initialized
INFO - 2016-10-26 13:54:47 --> URI Class Initialized
INFO - 2016-10-26 13:54:47 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:54:47 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:54:47 --> Router Class Initialized
INFO - 2016-10-26 13:54:47 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:47 --> Utf8 Class Initialized
INFO - 2016-10-26 13:54:47 --> Output Class Initialized
INFO - 2016-10-26 13:54:47 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:47 --> URI Class Initialized
INFO - 2016-10-26 13:54:47 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:47 --> Security Class Initialized
INFO - 2016-10-26 13:54:47 --> Router Class Initialized
INFO - 2016-10-26 13:54:47 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:47 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:47 --> Output Class Initialized
DEBUG - 2016-10-26 13:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:54:47 --> Input Class Initialized
INFO - 2016-10-26 13:54:47 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:47 --> Security Class Initialized
INFO - 2016-10-26 13:54:47 --> Language Class Initialized
INFO - 2016-10-26 13:54:47 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:54:47 --> Input Class Initialized
INFO - 2016-10-26 13:54:47 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:47 --> Language Class Initialized
INFO - 2016-10-26 13:54:47 --> Language Class Initialized
INFO - 2016-10-26 13:54:47 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:47 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:47 --> Language Class Initialized
INFO - 2016-10-26 13:54:47 --> Config Class Initialized
INFO - 2016-10-26 13:54:47 --> Config Class Initialized
INFO - 2016-10-26 13:54:47 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:47 --> Loader Class Initialized
INFO - 2016-10-26 13:54:47 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:47 --> Helper loaded: url_helper
INFO - 2016-10-26 13:54:47 --> Loader Class Initialized
INFO - 2016-10-26 13:54:47 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:47 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:47 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:47 --> Helper loaded: url_helper
INFO - 2016-10-26 13:54:47 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:47 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:49 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:49 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:49 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:49 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:49 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:49 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:49 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:49 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:49 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:49 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:49 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:54:49 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 13:54:49 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 13:54:49 --> Final output sent to browser
DEBUG - 2016-10-26 13:54:49 --> Total execution time: 4.9333
INFO - 2016-10-26 13:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:54:49 --> Controller Class Initialized
DEBUG - 2016-10-26 13:54:49 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:54:49 --> Model Class Initialized
INFO - 2016-10-26 13:54:49 --> Model Class Initialized
ERROR - 2016-10-26 13:54:49 --> Unable to delete cache file for admin/index/tutup_angsuran
DEBUG - 2016-10-26 13:54:49 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 13:54:49 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 13:54:49 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-26 13:54:49 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_tutup_angsuran.php
DEBUG - 2016-10-26 13:54:49 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 13:54:49 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 13:54:49 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:50 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:50 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:50 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:50 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:50 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:50 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:50 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:50 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:50 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:50 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:50 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:50 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:50 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:50 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:50 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:50 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:50 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:50 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:50 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:50 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:50 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:50 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:50 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:50 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:50 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:52 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:54:52 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 13:54:52 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 13:54:52 --> Final output sent to browser
DEBUG - 2016-10-26 13:54:52 --> Total execution time: 7.6891
INFO - 2016-10-26 13:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:54:52 --> Controller Class Initialized
DEBUG - 2016-10-26 13:54:52 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:54:52 --> Model Class Initialized
INFO - 2016-10-26 13:54:52 --> Model Class Initialized
ERROR - 2016-10-26 13:54:52 --> Unable to delete cache file for admin/index/tutup_angsuran
DEBUG - 2016-10-26 13:54:52 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 13:54:52 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 13:54:52 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-26 13:54:52 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_tutup_angsuran.php
DEBUG - 2016-10-26 13:54:52 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 13:54:52 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 13:54:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:55 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:54:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 13:54:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 13:54:55 --> Final output sent to browser
DEBUG - 2016-10-26 13:54:55 --> Total execution time: 8.1864
INFO - 2016-10-26 13:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:54:55 --> Controller Class Initialized
DEBUG - 2016-10-26 13:54:55 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:54:55 --> Model Class Initialized
INFO - 2016-10-26 13:54:55 --> Model Class Initialized
ERROR - 2016-10-26 13:54:55 --> Unable to delete cache file for admin/index/tutup_angsuran
DEBUG - 2016-10-26 13:54:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 13:54:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 13:54:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-26 13:54:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_tutup_angsuran.php
DEBUG - 2016-10-26 13:54:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 13:54:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 13:54:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:57 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:57 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:57 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:57 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:57 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:57 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:57 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:57 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:57 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:57 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:57 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:57 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:57 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:57 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:57 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:57 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:57 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:57 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:57 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:57 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:57 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:57 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:57 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:57 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:58 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:58 --> Database Driver Class Initialized
INFO - 2016-10-26 13:54:58 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:54:58 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 13:54:58 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 13:54:58 --> Final output sent to browser
DEBUG - 2016-10-26 13:54:58 --> Total execution time: 10.9223
INFO - 2016-10-26 13:55:11 --> Config Class Initialized
INFO - 2016-10-26 13:55:11 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:55:11 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:55:11 --> Utf8 Class Initialized
INFO - 2016-10-26 13:55:11 --> URI Class Initialized
INFO - 2016-10-26 13:55:11 --> Router Class Initialized
INFO - 2016-10-26 13:55:11 --> Output Class Initialized
INFO - 2016-10-26 13:55:11 --> Security Class Initialized
DEBUG - 2016-10-26 13:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:55:11 --> Input Class Initialized
INFO - 2016-10-26 13:55:11 --> Language Class Initialized
INFO - 2016-10-26 13:55:11 --> Language Class Initialized
INFO - 2016-10-26 13:55:11 --> Config Class Initialized
INFO - 2016-10-26 13:55:11 --> Loader Class Initialized
INFO - 2016-10-26 13:55:11 --> Helper loaded: url_helper
INFO - 2016-10-26 13:55:11 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:55:11 --> Controller Class Initialized
DEBUG - 2016-10-26 13:55:11 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:55:11 --> Model Class Initialized
INFO - 2016-10-26 13:55:11 --> Model Class Initialized
ERROR - 2016-10-26 13:55:11 --> Unable to delete cache file for admin/index/getDetailLunas
INFO - 2016-10-26 13:55:12 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:12 --> Final output sent to browser
DEBUG - 2016-10-26 13:55:12 --> Total execution time: 0.8389
INFO - 2016-10-26 13:55:25 --> Config Class Initialized
INFO - 2016-10-26 13:55:25 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:55:25 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:55:25 --> Utf8 Class Initialized
INFO - 2016-10-26 13:55:25 --> Config Class Initialized
INFO - 2016-10-26 13:55:25 --> Hooks Class Initialized
INFO - 2016-10-26 13:55:25 --> URI Class Initialized
DEBUG - 2016-10-26 13:55:25 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:55:25 --> Router Class Initialized
INFO - 2016-10-26 13:55:25 --> Utf8 Class Initialized
INFO - 2016-10-26 13:55:25 --> URI Class Initialized
INFO - 2016-10-26 13:55:25 --> Output Class Initialized
INFO - 2016-10-26 13:55:25 --> Security Class Initialized
INFO - 2016-10-26 13:55:25 --> Router Class Initialized
DEBUG - 2016-10-26 13:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:55:25 --> Output Class Initialized
INFO - 2016-10-26 13:55:26 --> Input Class Initialized
INFO - 2016-10-26 13:55:26 --> Security Class Initialized
INFO - 2016-10-26 13:55:26 --> Language Class Initialized
DEBUG - 2016-10-26 13:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:55:26 --> Language Class Initialized
INFO - 2016-10-26 13:55:26 --> Config Class Initialized
INFO - 2016-10-26 13:55:26 --> Input Class Initialized
INFO - 2016-10-26 13:55:26 --> Language Class Initialized
INFO - 2016-10-26 13:55:26 --> Loader Class Initialized
INFO - 2016-10-26 13:55:26 --> Helper loaded: url_helper
INFO - 2016-10-26 13:55:26 --> Language Class Initialized
INFO - 2016-10-26 13:55:26 --> Config Class Initialized
INFO - 2016-10-26 13:55:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:26 --> Loader Class Initialized
INFO - 2016-10-26 13:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:55:26 --> Controller Class Initialized
INFO - 2016-10-26 13:55:26 --> Helper loaded: url_helper
DEBUG - 2016-10-26 13:55:26 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:55:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:26 --> Model Class Initialized
INFO - 2016-10-26 13:55:26 --> Model Class Initialized
ERROR - 2016-10-26 13:55:26 --> Unable to delete cache file for admin/index/getDetailLunas
INFO - 2016-10-26 13:55:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:26 --> Final output sent to browser
DEBUG - 2016-10-26 13:55:26 --> Total execution time: 0.9088
INFO - 2016-10-26 13:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:55:26 --> Controller Class Initialized
DEBUG - 2016-10-26 13:55:26 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:55:26 --> Model Class Initialized
INFO - 2016-10-26 13:55:26 --> Model Class Initialized
ERROR - 2016-10-26 13:55:26 --> Unable to delete cache file for admin/index/getDetailLunas
INFO - 2016-10-26 13:55:26 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:26 --> Final output sent to browser
DEBUG - 2016-10-26 13:55:26 --> Total execution time: 1.0853
INFO - 2016-10-26 13:55:34 --> Config Class Initialized
INFO - 2016-10-26 13:55:34 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:55:34 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:55:34 --> Utf8 Class Initialized
INFO - 2016-10-26 13:55:34 --> Config Class Initialized
INFO - 2016-10-26 13:55:34 --> Hooks Class Initialized
INFO - 2016-10-26 13:55:34 --> URI Class Initialized
INFO - 2016-10-26 13:55:34 --> Router Class Initialized
DEBUG - 2016-10-26 13:55:34 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:55:34 --> Utf8 Class Initialized
INFO - 2016-10-26 13:55:34 --> Output Class Initialized
INFO - 2016-10-26 13:55:34 --> Security Class Initialized
INFO - 2016-10-26 13:55:34 --> URI Class Initialized
DEBUG - 2016-10-26 13:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:55:34 --> Router Class Initialized
INFO - 2016-10-26 13:55:34 --> Input Class Initialized
INFO - 2016-10-26 13:55:34 --> Output Class Initialized
INFO - 2016-10-26 13:55:35 --> Language Class Initialized
INFO - 2016-10-26 13:55:35 --> Security Class Initialized
DEBUG - 2016-10-26 13:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:55:35 --> Language Class Initialized
INFO - 2016-10-26 13:55:35 --> Input Class Initialized
INFO - 2016-10-26 13:55:35 --> Config Class Initialized
INFO - 2016-10-26 13:55:35 --> Language Class Initialized
INFO - 2016-10-26 13:55:35 --> Loader Class Initialized
INFO - 2016-10-26 13:55:35 --> Language Class Initialized
INFO - 2016-10-26 13:55:35 --> Config Class Initialized
INFO - 2016-10-26 13:55:35 --> Helper loaded: url_helper
INFO - 2016-10-26 13:55:35 --> Loader Class Initialized
INFO - 2016-10-26 13:55:35 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:35 --> Helper loaded: url_helper
INFO - 2016-10-26 13:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:55:35 --> Controller Class Initialized
INFO - 2016-10-26 13:55:35 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:55:35 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:55:35 --> Model Class Initialized
INFO - 2016-10-26 13:55:35 --> Model Class Initialized
ERROR - 2016-10-26 13:55:35 --> Unable to delete cache file for admin/index/data/anggota
DEBUG - 2016-10-26 13:55:35 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 13:55:35 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 13:55:35 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-26 13:55:35 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-26 13:55:35 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-26 13:55:35 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-26 13:55:35 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 13:55:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 13:55:36 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:36 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:36 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:36 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:36 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:36 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:36 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:36 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:36 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:36 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:36 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:36 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:36 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:36 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:36 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:36 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:36 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:36 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:36 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:36 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:36 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:36 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:36 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:36 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:37 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:37 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:37 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:37 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:37 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:37 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:37 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:37 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:37 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:37 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:37 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:37 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:37 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:37 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:37 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:37 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:37 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:37 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:37 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:37 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:37 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:37 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:37 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:38 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:38 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:38 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:38 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:38 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:38 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:38 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:38 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:38 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:38 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:38 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:38 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:38 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:55:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 13:55:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 13:55:38 --> Final output sent to browser
DEBUG - 2016-10-26 13:55:38 --> Total execution time: 4.0343
INFO - 2016-10-26 13:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:55:38 --> Controller Class Initialized
DEBUG - 2016-10-26 13:55:38 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:55:38 --> Model Class Initialized
INFO - 2016-10-26 13:55:38 --> Model Class Initialized
ERROR - 2016-10-26 13:55:38 --> Unable to delete cache file for admin/index/data/anggota
DEBUG - 2016-10-26 13:55:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 13:55:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 13:55:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-26 13:55:39 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-26 13:55:39 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-26 13:55:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-26 13:55:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 13:55:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 13:55:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:41 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:55:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 13:55:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 13:55:41 --> Final output sent to browser
DEBUG - 2016-10-26 13:55:41 --> Total execution time: 6.9489
INFO - 2016-10-26 13:55:47 --> Config Class Initialized
INFO - 2016-10-26 13:55:47 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:55:47 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:55:47 --> Config Class Initialized
INFO - 2016-10-26 13:55:47 --> Hooks Class Initialized
INFO - 2016-10-26 13:55:47 --> Utf8 Class Initialized
INFO - 2016-10-26 13:55:47 --> URI Class Initialized
DEBUG - 2016-10-26 13:55:47 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:55:47 --> Utf8 Class Initialized
INFO - 2016-10-26 13:55:47 --> Router Class Initialized
INFO - 2016-10-26 13:55:47 --> URI Class Initialized
INFO - 2016-10-26 13:55:47 --> Output Class Initialized
INFO - 2016-10-26 13:55:47 --> Security Class Initialized
INFO - 2016-10-26 13:55:47 --> Router Class Initialized
DEBUG - 2016-10-26 13:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:55:47 --> Output Class Initialized
INFO - 2016-10-26 13:55:47 --> Input Class Initialized
INFO - 2016-10-26 13:55:47 --> Security Class Initialized
DEBUG - 2016-10-26 13:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:55:47 --> Language Class Initialized
INFO - 2016-10-26 13:55:47 --> Input Class Initialized
INFO - 2016-10-26 13:55:47 --> Language Class Initialized
INFO - 2016-10-26 13:55:47 --> Language Class Initialized
INFO - 2016-10-26 13:55:47 --> Config Class Initialized
INFO - 2016-10-26 13:55:47 --> Language Class Initialized
INFO - 2016-10-26 13:55:47 --> Config Class Initialized
INFO - 2016-10-26 13:55:47 --> Loader Class Initialized
INFO - 2016-10-26 13:55:47 --> Helper loaded: url_helper
INFO - 2016-10-26 13:55:47 --> Loader Class Initialized
INFO - 2016-10-26 13:55:47 --> Helper loaded: url_helper
INFO - 2016-10-26 13:55:47 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:55:47 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:47 --> Controller Class Initialized
DEBUG - 2016-10-26 13:55:47 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:55:47 --> Model Class Initialized
INFO - 2016-10-26 13:55:47 --> Model Class Initialized
ERROR - 2016-10-26 13:55:47 --> Unable to delete cache file for admin/index/data/anggota/umum
DEBUG - 2016-10-26 13:55:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 13:55:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 13:55:48 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-26 13:55:48 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-26 13:55:48 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-26 13:55:48 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-26 13:55:48 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 13:55:48 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 13:55:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:49 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:49 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:49 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:49 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:49 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:49 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:49 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:49 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:49 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:49 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:49 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:49 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:49 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:49 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:49 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:49 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:49 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:49 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:49 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:49 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:49 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:49 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:49 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:50 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:50 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:50 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:50 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:50 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:50 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:50 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:50 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:50 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:50 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:50 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:50 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:50 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:50 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:50 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:50 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:50 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:50 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:55:50 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 13:55:50 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 13:55:50 --> Final output sent to browser
DEBUG - 2016-10-26 13:55:50 --> Total execution time: 3.8699
INFO - 2016-10-26 13:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:55:51 --> Controller Class Initialized
DEBUG - 2016-10-26 13:55:51 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:55:51 --> Model Class Initialized
INFO - 2016-10-26 13:55:51 --> Model Class Initialized
ERROR - 2016-10-26 13:55:51 --> Unable to delete cache file for admin/index/data/anggota/umum
DEBUG - 2016-10-26 13:55:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 13:55:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 13:55:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-26 13:55:51 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-26 13:55:51 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-26 13:55:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-26 13:55:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 13:55:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 13:55:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:55:54 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:55:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 13:55:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 13:55:54 --> Final output sent to browser
DEBUG - 2016-10-26 13:55:54 --> Total execution time: 6.9298
INFO - 2016-10-26 13:55:58 --> Config Class Initialized
INFO - 2016-10-26 13:55:59 --> Hooks Class Initialized
INFO - 2016-10-26 13:55:59 --> Config Class Initialized
INFO - 2016-10-26 13:55:59 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:55:59 --> UTF-8 Support Enabled
DEBUG - 2016-10-26 13:55:59 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:55:59 --> Utf8 Class Initialized
INFO - 2016-10-26 13:55:59 --> URI Class Initialized
INFO - 2016-10-26 13:55:59 --> Router Class Initialized
INFO - 2016-10-26 13:55:59 --> Output Class Initialized
INFO - 2016-10-26 13:55:59 --> Security Class Initialized
INFO - 2016-10-26 13:55:59 --> Utf8 Class Initialized
DEBUG - 2016-10-26 13:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:55:59 --> URI Class Initialized
INFO - 2016-10-26 13:55:59 --> Router Class Initialized
INFO - 2016-10-26 13:55:59 --> Output Class Initialized
INFO - 2016-10-26 13:55:59 --> Security Class Initialized
DEBUG - 2016-10-26 13:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:55:59 --> Input Class Initialized
INFO - 2016-10-26 13:55:59 --> Language Class Initialized
INFO - 2016-10-26 13:55:59 --> Language Class Initialized
INFO - 2016-10-26 13:55:59 --> Config Class Initialized
INFO - 2016-10-26 13:56:00 --> Loader Class Initialized
INFO - 2016-10-26 13:56:00 --> Input Class Initialized
INFO - 2016-10-26 13:56:00 --> Language Class Initialized
INFO - 2016-10-26 13:56:00 --> Helper loaded: url_helper
INFO - 2016-10-26 13:56:00 --> Language Class Initialized
INFO - 2016-10-26 13:56:00 --> Config Class Initialized
INFO - 2016-10-26 13:56:00 --> Loader Class Initialized
INFO - 2016-10-26 13:56:00 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:00 --> Helper loaded: url_helper
INFO - 2016-10-26 13:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:56:00 --> Controller Class Initialized
INFO - 2016-10-26 13:56:00 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:56:00 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:56:00 --> Model Class Initialized
INFO - 2016-10-26 13:56:00 --> Model Class Initialized
ERROR - 2016-10-26 13:56:00 --> Unable to delete cache file for admin/index/detail_anggota/c1dfd96eea8cc2b62785275bca38ac261256e278
DEBUG - 2016-10-26 13:56:00 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 13:56:00 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 13:56:00 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
INFO - 2016-10-26 13:56:00 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:56:00 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_pinjaman.php
INFO - 2016-10-26 13:56:00 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:56:00 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_tabungan.php
DEBUG - 2016-10-26 13:56:00 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/profile_anggota.php
DEBUG - 2016-10-26 13:56:00 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 13:56:00 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 13:56:00 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:00 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:00 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:00 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:03 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:56:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 13:56:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 13:56:03 --> Final output sent to browser
DEBUG - 2016-10-26 13:56:03 --> Total execution time: 4.5208
INFO - 2016-10-26 13:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:56:03 --> Controller Class Initialized
DEBUG - 2016-10-26 13:56:03 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:56:03 --> Model Class Initialized
INFO - 2016-10-26 13:56:03 --> Model Class Initialized
ERROR - 2016-10-26 13:56:03 --> Unable to delete cache file for admin/index/detail_anggota/c1dfd96eea8cc2b62785275bca38ac261256e278
DEBUG - 2016-10-26 13:56:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 13:56:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 13:56:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
INFO - 2016-10-26 13:56:03 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:56:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_pinjaman.php
INFO - 2016-10-26 13:56:03 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:56:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_tabungan.php
DEBUG - 2016-10-26 13:56:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/profile_anggota.php
DEBUG - 2016-10-26 13:56:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 13:56:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 13:56:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:06 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:06 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:06 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:06 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:06 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:06 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:06 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:06 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:06 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:06 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:06 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:06 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:06 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:06 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:06 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:06 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:06 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:06 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:06 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:06 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:56:06 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 13:56:06 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 13:56:06 --> Final output sent to browser
DEBUG - 2016-10-26 13:56:06 --> Total execution time: 7.8639
INFO - 2016-10-26 13:56:07 --> Config Class Initialized
INFO - 2016-10-26 13:56:07 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:56:07 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:56:07 --> Utf8 Class Initialized
INFO - 2016-10-26 13:56:07 --> URI Class Initialized
INFO - 2016-10-26 13:56:07 --> Router Class Initialized
INFO - 2016-10-26 13:56:07 --> Output Class Initialized
INFO - 2016-10-26 13:56:07 --> Security Class Initialized
DEBUG - 2016-10-26 13:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:56:07 --> Input Class Initialized
INFO - 2016-10-26 13:56:07 --> Language Class Initialized
INFO - 2016-10-26 13:56:07 --> Language Class Initialized
INFO - 2016-10-26 13:56:07 --> Config Class Initialized
INFO - 2016-10-26 13:56:07 --> Loader Class Initialized
INFO - 2016-10-26 13:56:08 --> Helper loaded: url_helper
INFO - 2016-10-26 13:56:08 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:56:08 --> Controller Class Initialized
DEBUG - 2016-10-26 13:56:08 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:56:08 --> Model Class Initialized
INFO - 2016-10-26 13:56:08 --> Model Class Initialized
ERROR - 2016-10-26 13:56:08 --> Unable to delete cache file for admin/index/detail_anggota/images/picture.jpg
DEBUG - 2016-10-26 13:56:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 13:56:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 13:56:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
ERROR - 2016-10-26 13:56:08 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 16
ERROR - 2016-10-26 13:56:09 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 19
ERROR - 2016-10-26 13:56:09 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 22
ERROR - 2016-10-26 13:56:09 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 38
INFO - 2016-10-26 13:56:09 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:56:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_pinjaman.php
ERROR - 2016-10-26 13:56:09 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 41
INFO - 2016-10-26 13:56:09 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:56:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_tabungan.php
DEBUG - 2016-10-26 13:56:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/profile_anggota.php
DEBUG - 2016-10-26 13:56:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 13:56:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 13:56:09 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:09 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:09 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:10 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:10 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:10 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:10 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:10 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:10 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:10 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:10 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:10 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:10 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:10 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:11 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:11 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:11 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:11 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:11 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:11 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:11 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:11 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:11 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:11 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:11 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:11 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:11 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:11 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:11 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:11 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:12 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:12 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:12 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:12 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:12 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:12 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:12 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:13 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:13 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:13 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:13 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:13 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:13 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:13 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:13 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:13 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:13 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:14 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:56:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 13:56:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 13:56:15 --> Final output sent to browser
DEBUG - 2016-10-26 13:56:15 --> Total execution time: 7.9530
INFO - 2016-10-26 13:56:20 --> Config Class Initialized
INFO - 2016-10-26 13:56:20 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:56:20 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:56:20 --> Utf8 Class Initialized
INFO - 2016-10-26 13:56:21 --> URI Class Initialized
INFO - 2016-10-26 13:56:21 --> Router Class Initialized
INFO - 2016-10-26 13:56:21 --> Output Class Initialized
INFO - 2016-10-26 13:56:21 --> Security Class Initialized
DEBUG - 2016-10-26 13:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:56:21 --> Input Class Initialized
INFO - 2016-10-26 13:56:21 --> Language Class Initialized
INFO - 2016-10-26 13:56:21 --> Language Class Initialized
INFO - 2016-10-26 13:56:21 --> Config Class Initialized
INFO - 2016-10-26 13:56:21 --> Loader Class Initialized
INFO - 2016-10-26 13:56:21 --> Helper loaded: url_helper
INFO - 2016-10-26 13:56:21 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:56:21 --> Controller Class Initialized
DEBUG - 2016-10-26 13:56:21 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:56:21 --> Model Class Initialized
INFO - 2016-10-26 13:56:21 --> Model Class Initialized
ERROR - 2016-10-26 13:56:21 --> Unable to delete cache file for admin/index/getRaportAngsuran/fc074d501302eb2b93e2554793fcaf50b3bf7291
DEBUG - 2016-10-26 13:56:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/raport_angsuran.php
INFO - 2016-10-26 13:56:21 --> Final output sent to browser
DEBUG - 2016-10-26 13:56:22 --> Total execution time: 1.1843
INFO - 2016-10-26 13:56:38 --> Config Class Initialized
INFO - 2016-10-26 13:56:38 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:56:38 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:56:38 --> Utf8 Class Initialized
INFO - 2016-10-26 13:56:38 --> Config Class Initialized
INFO - 2016-10-26 13:56:38 --> Hooks Class Initialized
INFO - 2016-10-26 13:56:38 --> URI Class Initialized
DEBUG - 2016-10-26 13:56:38 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:56:38 --> Router Class Initialized
INFO - 2016-10-26 13:56:38 --> Utf8 Class Initialized
INFO - 2016-10-26 13:56:38 --> Output Class Initialized
INFO - 2016-10-26 13:56:38 --> URI Class Initialized
INFO - 2016-10-26 13:56:38 --> Security Class Initialized
INFO - 2016-10-26 13:56:38 --> Router Class Initialized
DEBUG - 2016-10-26 13:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:56:38 --> Input Class Initialized
INFO - 2016-10-26 13:56:38 --> Output Class Initialized
INFO - 2016-10-26 13:56:38 --> Language Class Initialized
INFO - 2016-10-26 13:56:38 --> Security Class Initialized
DEBUG - 2016-10-26 13:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:56:38 --> Language Class Initialized
INFO - 2016-10-26 13:56:38 --> Input Class Initialized
INFO - 2016-10-26 13:56:38 --> Config Class Initialized
INFO - 2016-10-26 13:56:38 --> Language Class Initialized
INFO - 2016-10-26 13:56:38 --> Loader Class Initialized
INFO - 2016-10-26 13:56:38 --> Language Class Initialized
INFO - 2016-10-26 13:56:38 --> Config Class Initialized
INFO - 2016-10-26 13:56:39 --> Helper loaded: url_helper
INFO - 2016-10-26 13:56:39 --> Loader Class Initialized
INFO - 2016-10-26 13:56:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:39 --> Helper loaded: url_helper
INFO - 2016-10-26 13:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:56:39 --> Controller Class Initialized
INFO - 2016-10-26 13:56:39 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:56:39 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:56:39 --> Model Class Initialized
INFO - 2016-10-26 13:56:39 --> Model Class Initialized
ERROR - 2016-10-26 13:56:39 --> Unable to delete cache file for admin/index/data/anggota
DEBUG - 2016-10-26 13:56:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 13:56:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 13:56:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-26 13:56:39 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-26 13:56:39 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-26 13:56:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-26 13:56:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 13:56:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 13:56:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:42 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:42 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:42 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:42 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:42 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:56:42 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 13:56:42 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 13:56:42 --> Final output sent to browser
DEBUG - 2016-10-26 13:56:42 --> Total execution time: 3.9570
INFO - 2016-10-26 13:56:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:56:42 --> Controller Class Initialized
DEBUG - 2016-10-26 13:56:42 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:56:42 --> Model Class Initialized
INFO - 2016-10-26 13:56:42 --> Model Class Initialized
ERROR - 2016-10-26 13:56:42 --> Unable to delete cache file for admin/index/data/anggota
DEBUG - 2016-10-26 13:56:42 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 13:56:42 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 13:56:42 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-26 13:56:42 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-26 13:56:42 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-26 13:56:42 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-26 13:56:42 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 13:56:42 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 13:56:42 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:42 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:42 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:45 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:56:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 13:56:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 13:56:45 --> Final output sent to browser
DEBUG - 2016-10-26 13:56:45 --> Total execution time: 7.3017
INFO - 2016-10-26 13:56:50 --> Config Class Initialized
INFO - 2016-10-26 13:56:50 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:56:50 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:56:50 --> Config Class Initialized
INFO - 2016-10-26 13:56:50 --> Hooks Class Initialized
INFO - 2016-10-26 13:56:50 --> Utf8 Class Initialized
INFO - 2016-10-26 13:56:50 --> URI Class Initialized
DEBUG - 2016-10-26 13:56:50 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:56:50 --> Utf8 Class Initialized
INFO - 2016-10-26 13:56:50 --> Router Class Initialized
INFO - 2016-10-26 13:56:50 --> URI Class Initialized
INFO - 2016-10-26 13:56:50 --> Output Class Initialized
INFO - 2016-10-26 13:56:50 --> Router Class Initialized
INFO - 2016-10-26 13:56:51 --> Output Class Initialized
INFO - 2016-10-26 13:56:51 --> Security Class Initialized
DEBUG - 2016-10-26 13:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:56:51 --> Input Class Initialized
INFO - 2016-10-26 13:56:51 --> Language Class Initialized
INFO - 2016-10-26 13:56:51 --> Security Class Initialized
DEBUG - 2016-10-26 13:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:56:51 --> Language Class Initialized
INFO - 2016-10-26 13:56:51 --> Config Class Initialized
INFO - 2016-10-26 13:56:51 --> Input Class Initialized
INFO - 2016-10-26 13:56:51 --> Language Class Initialized
INFO - 2016-10-26 13:56:51 --> Loader Class Initialized
INFO - 2016-10-26 13:56:51 --> Helper loaded: url_helper
INFO - 2016-10-26 13:56:51 --> Language Class Initialized
INFO - 2016-10-26 13:56:51 --> Config Class Initialized
INFO - 2016-10-26 13:56:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:51 --> Loader Class Initialized
INFO - 2016-10-26 13:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:56:51 --> Controller Class Initialized
INFO - 2016-10-26 13:56:51 --> Helper loaded: url_helper
DEBUG - 2016-10-26 13:56:51 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:56:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:51 --> Model Class Initialized
INFO - 2016-10-26 13:56:51 --> Model Class Initialized
ERROR - 2016-10-26 13:56:51 --> Unable to delete cache file for admin/index/data/anggota/umum
DEBUG - 2016-10-26 13:56:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 13:56:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 13:56:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-26 13:56:51 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-26 13:56:51 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-26 13:56:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-26 13:56:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 13:56:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 13:56:51 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:54 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:54 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:56:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 13:56:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 13:56:54 --> Final output sent to browser
DEBUG - 2016-10-26 13:56:54 --> Total execution time: 3.8194
INFO - 2016-10-26 13:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:56:54 --> Controller Class Initialized
DEBUG - 2016-10-26 13:56:54 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:56:54 --> Model Class Initialized
INFO - 2016-10-26 13:56:55 --> Model Class Initialized
ERROR - 2016-10-26 13:56:55 --> Unable to delete cache file for admin/index/data/anggota/umum
DEBUG - 2016-10-26 13:56:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 13:56:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 13:56:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-26 13:56:55 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-26 13:56:55 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-26 13:56:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-26 13:56:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 13:56:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 13:56:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:56 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:57 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:57 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:57 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:57 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:57 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:57 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:57 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:57 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:58 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:58 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:58 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:58 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:58 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:58 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:58 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:58 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:59 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:59 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:59 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:59 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:59 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:59 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:59 --> Database Driver Class Initialized
INFO - 2016-10-26 13:56:59 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:00 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:00 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:00 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:00 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:00 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:00 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:00 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:00 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:00 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:00 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:00 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:00 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:00 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:00 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:00 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:00 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:00 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:00 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:00 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:00 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:01 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:57:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 13:57:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 13:57:01 --> Final output sent to browser
DEBUG - 2016-10-26 13:57:01 --> Total execution time: 10.9335
INFO - 2016-10-26 13:57:02 --> Config Class Initialized
INFO - 2016-10-26 13:57:02 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:57:02 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:57:02 --> Utf8 Class Initialized
INFO - 2016-10-26 13:57:02 --> URI Class Initialized
INFO - 2016-10-26 13:57:02 --> Config Class Initialized
INFO - 2016-10-26 13:57:02 --> Hooks Class Initialized
INFO - 2016-10-26 13:57:02 --> Router Class Initialized
INFO - 2016-10-26 13:57:02 --> Output Class Initialized
DEBUG - 2016-10-26 13:57:02 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:57:02 --> Utf8 Class Initialized
INFO - 2016-10-26 13:57:02 --> Security Class Initialized
INFO - 2016-10-26 13:57:02 --> URI Class Initialized
DEBUG - 2016-10-26 13:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:57:02 --> Input Class Initialized
INFO - 2016-10-26 13:57:02 --> Router Class Initialized
INFO - 2016-10-26 13:57:02 --> Language Class Initialized
INFO - 2016-10-26 13:57:02 --> Output Class Initialized
INFO - 2016-10-26 13:57:02 --> Language Class Initialized
INFO - 2016-10-26 13:57:02 --> Config Class Initialized
INFO - 2016-10-26 13:57:02 --> Security Class Initialized
DEBUG - 2016-10-26 13:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:57:02 --> Loader Class Initialized
INFO - 2016-10-26 13:57:02 --> Input Class Initialized
INFO - 2016-10-26 13:57:02 --> Helper loaded: url_helper
INFO - 2016-10-26 13:57:02 --> Language Class Initialized
INFO - 2016-10-26 13:57:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:57:02 --> Language Class Initialized
INFO - 2016-10-26 13:57:02 --> Controller Class Initialized
DEBUG - 2016-10-26 13:57:03 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:57:03 --> Config Class Initialized
INFO - 2016-10-26 13:57:03 --> Model Class Initialized
INFO - 2016-10-26 13:57:03 --> Loader Class Initialized
INFO - 2016-10-26 13:57:03 --> Model Class Initialized
INFO - 2016-10-26 13:57:03 --> Helper loaded: url_helper
ERROR - 2016-10-26 13:57:03 --> Unable to delete cache file for admin/index/detail_anggota/902ba3cda1883801594b6e1b452790cc53948fda
INFO - 2016-10-26 13:57:03 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:57:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 13:57:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 13:57:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
INFO - 2016-10-26 13:57:03 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:57:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_pinjaman.php
INFO - 2016-10-26 13:57:03 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:57:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_tabungan.php
DEBUG - 2016-10-26 13:57:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/profile_anggota.php
DEBUG - 2016-10-26 13:57:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 13:57:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 13:57:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:05 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:06 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:06 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:06 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:06 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:06 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:06 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:57:06 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 13:57:06 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 13:57:06 --> Final output sent to browser
DEBUG - 2016-10-26 13:57:06 --> Total execution time: 4.1696
INFO - 2016-10-26 13:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:57:06 --> Controller Class Initialized
DEBUG - 2016-10-26 13:57:06 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:57:06 --> Model Class Initialized
INFO - 2016-10-26 13:57:06 --> Model Class Initialized
ERROR - 2016-10-26 13:57:06 --> Unable to delete cache file for admin/index/detail_anggota/902ba3cda1883801594b6e1b452790cc53948fda
DEBUG - 2016-10-26 13:57:06 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 13:57:06 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 13:57:06 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
INFO - 2016-10-26 13:57:06 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:57:06 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_pinjaman.php
INFO - 2016-10-26 13:57:06 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:57:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_tabungan.php
DEBUG - 2016-10-26 13:57:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/profile_anggota.php
DEBUG - 2016-10-26 13:57:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 13:57:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 13:57:07 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:07 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:07 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:07 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:07 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:07 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:07 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:07 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:07 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:07 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:07 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:07 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:07 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:07 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:07 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:07 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:07 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:07 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:07 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:08 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:08 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:08 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:08 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:08 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:08 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:08 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:08 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:08 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:08 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:08 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:08 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:08 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:08 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:08 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:08 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:08 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:08 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:08 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:08 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:08 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:08 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:08 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:08 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:09 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:09 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:09 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:09 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:09 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:09 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:09 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:09 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:09 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:09 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:09 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:09 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:09 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:09 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:09 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:09 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:09 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:57:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 13:57:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 13:57:09 --> Final output sent to browser
DEBUG - 2016-10-26 13:57:09 --> Total execution time: 7.4203
INFO - 2016-10-26 13:57:10 --> Config Class Initialized
INFO - 2016-10-26 13:57:10 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:57:10 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:57:10 --> Utf8 Class Initialized
INFO - 2016-10-26 13:57:10 --> URI Class Initialized
INFO - 2016-10-26 13:57:10 --> Router Class Initialized
INFO - 2016-10-26 13:57:10 --> Output Class Initialized
INFO - 2016-10-26 13:57:10 --> Security Class Initialized
DEBUG - 2016-10-26 13:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:57:10 --> Input Class Initialized
INFO - 2016-10-26 13:57:10 --> Language Class Initialized
INFO - 2016-10-26 13:57:10 --> Language Class Initialized
INFO - 2016-10-26 13:57:10 --> Config Class Initialized
INFO - 2016-10-26 13:57:10 --> Loader Class Initialized
INFO - 2016-10-26 13:57:11 --> Helper loaded: url_helper
INFO - 2016-10-26 13:57:11 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:57:11 --> Controller Class Initialized
DEBUG - 2016-10-26 13:57:11 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:57:11 --> Model Class Initialized
INFO - 2016-10-26 13:57:11 --> Model Class Initialized
ERROR - 2016-10-26 13:57:11 --> Unable to delete cache file for admin/index/detail_anggota/images/picture.jpg
DEBUG - 2016-10-26 13:57:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 13:57:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 13:57:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
ERROR - 2016-10-26 13:57:11 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 16
ERROR - 2016-10-26 13:57:12 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 19
ERROR - 2016-10-26 13:57:12 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 22
ERROR - 2016-10-26 13:57:12 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 38
INFO - 2016-10-26 13:57:12 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:57:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_pinjaman.php
ERROR - 2016-10-26 13:57:12 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 41
INFO - 2016-10-26 13:57:12 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:57:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_tabungan.php
DEBUG - 2016-10-26 13:57:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/profile_anggota.php
DEBUG - 2016-10-26 13:57:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 13:57:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 13:57:12 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:13 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:13 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:13 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:13 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:13 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:13 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:13 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:13 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:18 --> Config Class Initialized
INFO - 2016-10-26 13:57:18 --> Hooks Class Initialized
INFO - 2016-10-26 13:57:18 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:57:18 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:57:18 --> Utf8 Class Initialized
INFO - 2016-10-26 13:57:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:18 --> URI Class Initialized
INFO - 2016-10-26 13:57:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:18 --> Router Class Initialized
INFO - 2016-10-26 13:57:18 --> Output Class Initialized
INFO - 2016-10-26 13:57:18 --> Security Class Initialized
INFO - 2016-10-26 13:57:18 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:57:18 --> Input Class Initialized
INFO - 2016-10-26 13:57:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:19 --> Language Class Initialized
INFO - 2016-10-26 13:57:19 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:19 --> Language Class Initialized
INFO - 2016-10-26 13:57:19 --> Config Class Initialized
DEBUG - 2016-10-26 13:57:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 13:57:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 13:57:19 --> Loader Class Initialized
INFO - 2016-10-26 13:57:19 --> Final output sent to browser
DEBUG - 2016-10-26 13:57:19 --> Total execution time: 9.3292
INFO - 2016-10-26 13:57:19 --> Helper loaded: url_helper
INFO - 2016-10-26 13:57:19 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:57:19 --> Controller Class Initialized
DEBUG - 2016-10-26 13:57:19 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:57:19 --> Model Class Initialized
INFO - 2016-10-26 13:57:19 --> Model Class Initialized
ERROR - 2016-10-26 13:57:19 --> Unable to delete cache file for admin/index/getRaportAngsuran/5b384ce32d8cdef02bc3a139d4cac0a22bb029e8
DEBUG - 2016-10-26 13:57:20 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/raport_angsuran.php
INFO - 2016-10-26 13:57:20 --> Final output sent to browser
DEBUG - 2016-10-26 13:57:20 --> Total execution time: 1.8088
INFO - 2016-10-26 13:57:39 --> Config Class Initialized
INFO - 2016-10-26 13:57:39 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:57:39 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:57:39 --> Utf8 Class Initialized
INFO - 2016-10-26 13:57:39 --> Config Class Initialized
INFO - 2016-10-26 13:57:39 --> URI Class Initialized
INFO - 2016-10-26 13:57:39 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:57:39 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:57:39 --> Router Class Initialized
INFO - 2016-10-26 13:57:39 --> Utf8 Class Initialized
INFO - 2016-10-26 13:57:39 --> Output Class Initialized
INFO - 2016-10-26 13:57:39 --> Security Class Initialized
INFO - 2016-10-26 13:57:39 --> URI Class Initialized
DEBUG - 2016-10-26 13:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:57:40 --> Router Class Initialized
INFO - 2016-10-26 13:57:40 --> Input Class Initialized
INFO - 2016-10-26 13:57:40 --> Language Class Initialized
INFO - 2016-10-26 13:57:40 --> Output Class Initialized
INFO - 2016-10-26 13:57:40 --> Security Class Initialized
INFO - 2016-10-26 13:57:40 --> Language Class Initialized
INFO - 2016-10-26 13:57:40 --> Config Class Initialized
DEBUG - 2016-10-26 13:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:57:40 --> Input Class Initialized
INFO - 2016-10-26 13:57:40 --> Loader Class Initialized
INFO - 2016-10-26 13:57:40 --> Language Class Initialized
INFO - 2016-10-26 13:57:40 --> Helper loaded: url_helper
INFO - 2016-10-26 13:57:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:40 --> Language Class Initialized
INFO - 2016-10-26 13:57:40 --> Config Class Initialized
INFO - 2016-10-26 13:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:57:40 --> Controller Class Initialized
INFO - 2016-10-26 13:57:40 --> Loader Class Initialized
DEBUG - 2016-10-26 13:57:40 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:57:40 --> Helper loaded: url_helper
INFO - 2016-10-26 13:57:40 --> Model Class Initialized
INFO - 2016-10-26 13:57:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:40 --> Model Class Initialized
ERROR - 2016-10-26 13:57:40 --> Unable to delete cache file for admin/index/tutup_angsuran
DEBUG - 2016-10-26 13:57:40 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 13:57:40 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 13:57:40 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-26 13:57:40 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_tutup_angsuran.php
DEBUG - 2016-10-26 13:57:40 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 13:57:40 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 13:57:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:40 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:42 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:42 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:42 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:42 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:42 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:42 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:42 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:42 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:42 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:42 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:42 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:42 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:42 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:42 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:42 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:42 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:42 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:42 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:42 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:42 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:42 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:42 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:43 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:57:43 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 13:57:43 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 13:57:43 --> Final output sent to browser
DEBUG - 2016-10-26 13:57:43 --> Total execution time: 3.8183
INFO - 2016-10-26 13:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:57:43 --> Controller Class Initialized
DEBUG - 2016-10-26 13:57:43 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:57:43 --> Model Class Initialized
INFO - 2016-10-26 13:57:43 --> Model Class Initialized
ERROR - 2016-10-26 13:57:43 --> Unable to delete cache file for admin/index/tutup_angsuran
DEBUG - 2016-10-26 13:57:43 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 13:57:43 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 13:57:43 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-26 13:57:43 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_tutup_angsuran.php
DEBUG - 2016-10-26 13:57:43 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 13:57:43 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 13:57:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:43 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:44 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:46 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:46 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:46 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:46 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:46 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:46 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:46 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:46 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:46 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:46 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:46 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:46 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:57:46 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 13:57:46 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 13:57:46 --> Final output sent to browser
DEBUG - 2016-10-26 13:57:46 --> Total execution time: 6.8823
INFO - 2016-10-26 13:57:52 --> Config Class Initialized
INFO - 2016-10-26 13:57:52 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:57:52 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:57:52 --> Utf8 Class Initialized
INFO - 2016-10-26 13:57:52 --> URI Class Initialized
INFO - 2016-10-26 13:57:52 --> Router Class Initialized
INFO - 2016-10-26 13:57:52 --> Output Class Initialized
INFO - 2016-10-26 13:57:52 --> Security Class Initialized
DEBUG - 2016-10-26 13:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:57:52 --> Input Class Initialized
INFO - 2016-10-26 13:57:52 --> Language Class Initialized
INFO - 2016-10-26 13:57:52 --> Language Class Initialized
INFO - 2016-10-26 13:57:52 --> Config Class Initialized
INFO - 2016-10-26 13:57:52 --> Loader Class Initialized
INFO - 2016-10-26 13:57:52 --> Helper loaded: url_helper
INFO - 2016-10-26 13:57:52 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:57:52 --> Controller Class Initialized
DEBUG - 2016-10-26 13:57:53 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:57:53 --> Model Class Initialized
INFO - 2016-10-26 13:57:53 --> Model Class Initialized
ERROR - 2016-10-26 13:57:53 --> Unable to delete cache file for admin/index/getDetailLunas
INFO - 2016-10-26 13:57:53 --> Database Driver Class Initialized
INFO - 2016-10-26 13:57:53 --> Final output sent to browser
DEBUG - 2016-10-26 13:57:53 --> Total execution time: 0.9255
INFO - 2016-10-26 13:58:03 --> Config Class Initialized
INFO - 2016-10-26 13:58:03 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:58:03 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:58:03 --> Utf8 Class Initialized
INFO - 2016-10-26 13:58:03 --> URI Class Initialized
INFO - 2016-10-26 13:58:03 --> Router Class Initialized
INFO - 2016-10-26 13:58:03 --> Output Class Initialized
INFO - 2016-10-26 13:58:03 --> Security Class Initialized
DEBUG - 2016-10-26 13:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:58:03 --> Input Class Initialized
INFO - 2016-10-26 13:58:03 --> Language Class Initialized
INFO - 2016-10-26 13:58:03 --> Language Class Initialized
INFO - 2016-10-26 13:58:03 --> Config Class Initialized
INFO - 2016-10-26 13:58:03 --> Loader Class Initialized
INFO - 2016-10-26 13:58:03 --> Helper loaded: url_helper
INFO - 2016-10-26 13:58:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:58:03 --> Controller Class Initialized
DEBUG - 2016-10-26 13:58:03 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:58:03 --> Model Class Initialized
INFO - 2016-10-26 13:58:03 --> Model Class Initialized
ERROR - 2016-10-26 13:58:03 --> Unable to delete cache file for admin/index/getDetailLunas
INFO - 2016-10-26 13:58:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:03 --> Final output sent to browser
DEBUG - 2016-10-26 13:58:04 --> Total execution time: 0.9863
INFO - 2016-10-26 13:58:11 --> Config Class Initialized
INFO - 2016-10-26 13:58:11 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:58:11 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:58:11 --> Utf8 Class Initialized
INFO - 2016-10-26 13:58:11 --> URI Class Initialized
INFO - 2016-10-26 13:58:11 --> Config Class Initialized
INFO - 2016-10-26 13:58:11 --> Hooks Class Initialized
INFO - 2016-10-26 13:58:11 --> Router Class Initialized
INFO - 2016-10-26 13:58:11 --> Output Class Initialized
DEBUG - 2016-10-26 13:58:11 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:58:11 --> Utf8 Class Initialized
INFO - 2016-10-26 13:58:11 --> Security Class Initialized
DEBUG - 2016-10-26 13:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:58:11 --> URI Class Initialized
INFO - 2016-10-26 13:58:11 --> Input Class Initialized
INFO - 2016-10-26 13:58:11 --> Language Class Initialized
INFO - 2016-10-26 13:58:11 --> Router Class Initialized
INFO - 2016-10-26 13:58:11 --> Output Class Initialized
INFO - 2016-10-26 13:58:11 --> Language Class Initialized
INFO - 2016-10-26 13:58:11 --> Config Class Initialized
INFO - 2016-10-26 13:58:11 --> Security Class Initialized
DEBUG - 2016-10-26 13:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:58:11 --> Loader Class Initialized
INFO - 2016-10-26 13:58:11 --> Input Class Initialized
INFO - 2016-10-26 13:58:11 --> Language Class Initialized
INFO - 2016-10-26 13:58:11 --> Helper loaded: url_helper
INFO - 2016-10-26 13:58:11 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:11 --> Language Class Initialized
INFO - 2016-10-26 13:58:11 --> Config Class Initialized
INFO - 2016-10-26 13:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:58:12 --> Controller Class Initialized
INFO - 2016-10-26 13:58:12 --> Loader Class Initialized
DEBUG - 2016-10-26 13:58:12 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:58:12 --> Helper loaded: url_helper
INFO - 2016-10-26 13:58:12 --> Model Class Initialized
INFO - 2016-10-26 13:58:12 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:12 --> Model Class Initialized
ERROR - 2016-10-26 13:58:12 --> Unable to delete cache file for admin/index/add/anggota
DEBUG - 2016-10-26 13:58:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 13:58:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 13:58:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-26 13:58:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_anggota.php
DEBUG - 2016-10-26 13:58:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 13:58:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 13:58:12 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:12 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:12 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:12 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:12 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:12 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:12 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:12 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:13 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:13 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:13 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:13 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:13 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:13 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:13 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:13 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:13 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:13 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:13 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:13 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:13 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:13 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:13 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:13 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:13 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:13 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:13 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:13 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:13 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:13 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:13 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:15 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:58:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 13:58:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 13:58:15 --> Final output sent to browser
DEBUG - 2016-10-26 13:58:15 --> Total execution time: 4.1337
INFO - 2016-10-26 13:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:58:15 --> Controller Class Initialized
DEBUG - 2016-10-26 13:58:15 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:58:15 --> Model Class Initialized
INFO - 2016-10-26 13:58:15 --> Model Class Initialized
ERROR - 2016-10-26 13:58:15 --> Unable to delete cache file for admin/index/add/anggota
DEBUG - 2016-10-26 13:58:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 13:58:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 13:58:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-26 13:58:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_anggota.php
DEBUG - 2016-10-26 13:58:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 13:58:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 13:58:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:15 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:16 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:17 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:18 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:18 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:58:18 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 13:58:18 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 13:58:18 --> Final output sent to browser
DEBUG - 2016-10-26 13:58:18 --> Total execution time: 7.1563
INFO - 2016-10-26 13:58:44 --> Config Class Initialized
INFO - 2016-10-26 13:58:44 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:58:44 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:58:44 --> Utf8 Class Initialized
INFO - 2016-10-26 13:58:44 --> URI Class Initialized
INFO - 2016-10-26 13:58:44 --> Router Class Initialized
INFO - 2016-10-26 13:58:44 --> Output Class Initialized
INFO - 2016-10-26 13:58:44 --> Security Class Initialized
DEBUG - 2016-10-26 13:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:58:44 --> Input Class Initialized
INFO - 2016-10-26 13:58:44 --> Language Class Initialized
INFO - 2016-10-26 13:58:44 --> Language Class Initialized
INFO - 2016-10-26 13:58:44 --> Config Class Initialized
INFO - 2016-10-26 13:58:44 --> Loader Class Initialized
INFO - 2016-10-26 13:58:44 --> Helper loaded: url_helper
INFO - 2016-10-26 13:58:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:58:45 --> Controller Class Initialized
DEBUG - 2016-10-26 13:58:45 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:58:45 --> Model Class Initialized
INFO - 2016-10-26 13:58:45 --> Model Class Initialized
ERROR - 2016-10-26 13:58:45 --> Unable to delete cache file for admin/index/post_add
DEBUG - 2016-10-26 13:58:45 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-26 13:58:45 --> Users MX_Controller Initialized
DEBUG - 2016-10-26 13:58:45 --> Index MX_Controller Initialized
ERROR - 2016-10-26 13:58:45 --> Unable to delete cache file for admin/index/post_add
INFO - 2016-10-26 13:58:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:45 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:45 --> Final output sent to browser
DEBUG - 2016-10-26 13:58:45 --> Total execution time: 1.2224
INFO - 2016-10-26 13:58:45 --> Config Class Initialized
INFO - 2016-10-26 13:58:45 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:58:45 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:58:45 --> Utf8 Class Initialized
INFO - 2016-10-26 13:58:45 --> URI Class Initialized
INFO - 2016-10-26 13:58:46 --> Router Class Initialized
INFO - 2016-10-26 13:58:46 --> Output Class Initialized
INFO - 2016-10-26 13:58:46 --> Security Class Initialized
DEBUG - 2016-10-26 13:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:58:46 --> Input Class Initialized
INFO - 2016-10-26 13:58:46 --> Language Class Initialized
INFO - 2016-10-26 13:58:46 --> Language Class Initialized
INFO - 2016-10-26 13:58:46 --> Config Class Initialized
INFO - 2016-10-26 13:58:46 --> Loader Class Initialized
INFO - 2016-10-26 13:58:46 --> Helper loaded: url_helper
INFO - 2016-10-26 13:58:46 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:58:46 --> Controller Class Initialized
DEBUG - 2016-10-26 13:58:46 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:58:46 --> Model Class Initialized
INFO - 2016-10-26 13:58:46 --> Model Class Initialized
ERROR - 2016-10-26 13:58:46 --> Unable to delete cache file for admin/index/data/anggota
DEBUG - 2016-10-26 13:58:46 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 13:58:46 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 13:58:46 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-26 13:58:46 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-26 13:58:46 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-26 13:58:46 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-26 13:58:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 13:58:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 13:58:47 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:47 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:47 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:47 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:47 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:47 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:47 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:47 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:47 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:47 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:47 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:47 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:47 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:47 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:47 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:47 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:47 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:47 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:47 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:47 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:47 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:48 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:49 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:49 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:49 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:49 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:49 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:49 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:49 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:49 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:49 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:49 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:49 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:49 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:49 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:49 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:49 --> Database Driver Class Initialized
INFO - 2016-10-26 13:58:49 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:58:49 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 13:58:49 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 13:58:49 --> Final output sent to browser
DEBUG - 2016-10-26 13:58:49 --> Total execution time: 4.0661
INFO - 2016-10-26 13:59:00 --> Config Class Initialized
INFO - 2016-10-26 13:59:00 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:59:00 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:59:00 --> Utf8 Class Initialized
INFO - 2016-10-26 13:59:00 --> URI Class Initialized
INFO - 2016-10-26 13:59:00 --> Router Class Initialized
INFO - 2016-10-26 13:59:00 --> Output Class Initialized
INFO - 2016-10-26 13:59:00 --> Security Class Initialized
DEBUG - 2016-10-26 13:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:59:00 --> Input Class Initialized
INFO - 2016-10-26 13:59:00 --> Language Class Initialized
INFO - 2016-10-26 13:59:00 --> Language Class Initialized
INFO - 2016-10-26 13:59:00 --> Config Class Initialized
INFO - 2016-10-26 13:59:01 --> Loader Class Initialized
INFO - 2016-10-26 13:59:01 --> Helper loaded: url_helper
INFO - 2016-10-26 13:59:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:59:01 --> Controller Class Initialized
DEBUG - 2016-10-26 13:59:01 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:59:01 --> Model Class Initialized
INFO - 2016-10-26 13:59:01 --> Model Class Initialized
ERROR - 2016-10-26 13:59:01 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-10-26 13:59:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 13:59:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 13:59:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-26 13:59:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-10-26 13:59:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 13:59:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 13:59:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:01 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:02 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:03 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:04 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:04 --> Database Driver Class Initialized
DEBUG - 2016-10-26 13:59:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 13:59:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 13:59:04 --> Final output sent to browser
DEBUG - 2016-10-26 13:59:04 --> Total execution time: 4.0597
INFO - 2016-10-26 13:59:13 --> Config Class Initialized
INFO - 2016-10-26 13:59:13 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:59:13 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:59:13 --> Utf8 Class Initialized
INFO - 2016-10-26 13:59:13 --> URI Class Initialized
INFO - 2016-10-26 13:59:13 --> Router Class Initialized
INFO - 2016-10-26 13:59:13 --> Output Class Initialized
INFO - 2016-10-26 13:59:13 --> Security Class Initialized
DEBUG - 2016-10-26 13:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:59:14 --> Input Class Initialized
INFO - 2016-10-26 13:59:14 --> Language Class Initialized
INFO - 2016-10-26 13:59:14 --> Language Class Initialized
INFO - 2016-10-26 13:59:14 --> Config Class Initialized
INFO - 2016-10-26 13:59:14 --> Loader Class Initialized
INFO - 2016-10-26 13:59:14 --> Helper loaded: url_helper
INFO - 2016-10-26 13:59:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:59:14 --> Controller Class Initialized
DEBUG - 2016-10-26 13:59:14 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:59:14 --> Model Class Initialized
INFO - 2016-10-26 13:59:14 --> Model Class Initialized
ERROR - 2016-10-26 13:59:14 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-26 13:59:14 --> Anggota MX_Controller Initialized
INFO - 2016-10-26 13:59:14 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:14 --> Final output sent to browser
DEBUG - 2016-10-26 13:59:14 --> Total execution time: 1.0821
INFO - 2016-10-26 13:59:22 --> Config Class Initialized
INFO - 2016-10-26 13:59:22 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:59:22 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:59:22 --> Utf8 Class Initialized
INFO - 2016-10-26 13:59:22 --> URI Class Initialized
INFO - 2016-10-26 13:59:22 --> Router Class Initialized
INFO - 2016-10-26 13:59:22 --> Output Class Initialized
INFO - 2016-10-26 13:59:22 --> Security Class Initialized
DEBUG - 2016-10-26 13:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:59:22 --> Input Class Initialized
INFO - 2016-10-26 13:59:22 --> Language Class Initialized
INFO - 2016-10-26 13:59:22 --> Language Class Initialized
INFO - 2016-10-26 13:59:22 --> Config Class Initialized
INFO - 2016-10-26 13:59:22 --> Loader Class Initialized
INFO - 2016-10-26 13:59:22 --> Helper loaded: url_helper
INFO - 2016-10-26 13:59:22 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:59:22 --> Controller Class Initialized
DEBUG - 2016-10-26 13:59:22 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:59:22 --> Model Class Initialized
INFO - 2016-10-26 13:59:23 --> Model Class Initialized
ERROR - 2016-10-26 13:59:23 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-26 13:59:23 --> Anggota MX_Controller Initialized
INFO - 2016-10-26 13:59:23 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:23 --> Final output sent to browser
DEBUG - 2016-10-26 13:59:23 --> Total execution time: 0.9612
INFO - 2016-10-26 13:59:27 --> Config Class Initialized
INFO - 2016-10-26 13:59:27 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:59:27 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:59:27 --> Config Class Initialized
INFO - 2016-10-26 13:59:27 --> Utf8 Class Initialized
INFO - 2016-10-26 13:59:27 --> Hooks Class Initialized
INFO - 2016-10-26 13:59:27 --> URI Class Initialized
DEBUG - 2016-10-26 13:59:27 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:59:27 --> Utf8 Class Initialized
INFO - 2016-10-26 13:59:27 --> URI Class Initialized
INFO - 2016-10-26 13:59:27 --> Router Class Initialized
INFO - 2016-10-26 13:59:27 --> Output Class Initialized
INFO - 2016-10-26 13:59:27 --> Router Class Initialized
INFO - 2016-10-26 13:59:27 --> Security Class Initialized
INFO - 2016-10-26 13:59:27 --> Output Class Initialized
INFO - 2016-10-26 13:59:27 --> Security Class Initialized
DEBUG - 2016-10-26 13:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:59:27 --> Input Class Initialized
DEBUG - 2016-10-26 13:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:59:27 --> Input Class Initialized
INFO - 2016-10-26 13:59:27 --> Language Class Initialized
INFO - 2016-10-26 13:59:28 --> Language Class Initialized
INFO - 2016-10-26 13:59:28 --> Language Class Initialized
INFO - 2016-10-26 13:59:28 --> Config Class Initialized
INFO - 2016-10-26 13:59:28 --> Language Class Initialized
INFO - 2016-10-26 13:59:28 --> Config Class Initialized
INFO - 2016-10-26 13:59:28 --> Loader Class Initialized
INFO - 2016-10-26 13:59:28 --> Helper loaded: url_helper
INFO - 2016-10-26 13:59:28 --> Loader Class Initialized
INFO - 2016-10-26 13:59:28 --> Helper loaded: url_helper
INFO - 2016-10-26 13:59:28 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:59:28 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:28 --> Controller Class Initialized
DEBUG - 2016-10-26 13:59:28 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:59:28 --> Model Class Initialized
INFO - 2016-10-26 13:59:28 --> Model Class Initialized
ERROR - 2016-10-26 13:59:28 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-26 13:59:28 --> Anggota MX_Controller Initialized
INFO - 2016-10-26 13:59:28 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:28 --> Final output sent to browser
DEBUG - 2016-10-26 13:59:28 --> Total execution time: 1.1398
INFO - 2016-10-26 13:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:59:28 --> Controller Class Initialized
DEBUG - 2016-10-26 13:59:28 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:59:28 --> Model Class Initialized
INFO - 2016-10-26 13:59:28 --> Model Class Initialized
ERROR - 2016-10-26 13:59:28 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-26 13:59:28 --> Anggota MX_Controller Initialized
INFO - 2016-10-26 13:59:28 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:28 --> Final output sent to browser
DEBUG - 2016-10-26 13:59:28 --> Total execution time: 1.2608
INFO - 2016-10-26 13:59:34 --> Config Class Initialized
INFO - 2016-10-26 13:59:34 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:59:34 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:59:34 --> Utf8 Class Initialized
INFO - 2016-10-26 13:59:34 --> URI Class Initialized
INFO - 2016-10-26 13:59:34 --> Router Class Initialized
INFO - 2016-10-26 13:59:34 --> Output Class Initialized
INFO - 2016-10-26 13:59:35 --> Security Class Initialized
DEBUG - 2016-10-26 13:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:59:35 --> Input Class Initialized
INFO - 2016-10-26 13:59:35 --> Language Class Initialized
INFO - 2016-10-26 13:59:35 --> Language Class Initialized
INFO - 2016-10-26 13:59:35 --> Config Class Initialized
INFO - 2016-10-26 13:59:35 --> Loader Class Initialized
INFO - 2016-10-26 13:59:35 --> Helper loaded: url_helper
INFO - 2016-10-26 13:59:35 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:59:35 --> Controller Class Initialized
DEBUG - 2016-10-26 13:59:35 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:59:35 --> Model Class Initialized
INFO - 2016-10-26 13:59:35 --> Model Class Initialized
ERROR - 2016-10-26 13:59:35 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-26 13:59:35 --> Anggota MX_Controller Initialized
INFO - 2016-10-26 13:59:35 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:35 --> Final output sent to browser
DEBUG - 2016-10-26 13:59:35 --> Total execution time: 0.9130
INFO - 2016-10-26 13:59:35 --> Config Class Initialized
INFO - 2016-10-26 13:59:35 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:59:35 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:59:35 --> Utf8 Class Initialized
INFO - 2016-10-26 13:59:35 --> URI Class Initialized
INFO - 2016-10-26 13:59:36 --> Router Class Initialized
INFO - 2016-10-26 13:59:36 --> Output Class Initialized
INFO - 2016-10-26 13:59:36 --> Security Class Initialized
DEBUG - 2016-10-26 13:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:59:36 --> Input Class Initialized
INFO - 2016-10-26 13:59:36 --> Language Class Initialized
INFO - 2016-10-26 13:59:36 --> Language Class Initialized
INFO - 2016-10-26 13:59:36 --> Config Class Initialized
INFO - 2016-10-26 13:59:36 --> Loader Class Initialized
INFO - 2016-10-26 13:59:36 --> Helper loaded: url_helper
INFO - 2016-10-26 13:59:36 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:59:36 --> Controller Class Initialized
DEBUG - 2016-10-26 13:59:36 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:59:36 --> Model Class Initialized
INFO - 2016-10-26 13:59:36 --> Model Class Initialized
ERROR - 2016-10-26 13:59:36 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-26 13:59:36 --> Anggota MX_Controller Initialized
INFO - 2016-10-26 13:59:36 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:36 --> Final output sent to browser
DEBUG - 2016-10-26 13:59:36 --> Total execution time: 0.9269
INFO - 2016-10-26 13:59:40 --> Config Class Initialized
INFO - 2016-10-26 13:59:40 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:59:40 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:59:40 --> Utf8 Class Initialized
INFO - 2016-10-26 13:59:40 --> URI Class Initialized
INFO - 2016-10-26 13:59:40 --> Router Class Initialized
INFO - 2016-10-26 13:59:40 --> Output Class Initialized
INFO - 2016-10-26 13:59:40 --> Security Class Initialized
DEBUG - 2016-10-26 13:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:59:40 --> Input Class Initialized
INFO - 2016-10-26 13:59:40 --> Language Class Initialized
INFO - 2016-10-26 13:59:40 --> Language Class Initialized
INFO - 2016-10-26 13:59:41 --> Config Class Initialized
INFO - 2016-10-26 13:59:41 --> Loader Class Initialized
INFO - 2016-10-26 13:59:41 --> Helper loaded: url_helper
INFO - 2016-10-26 13:59:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:59:41 --> Controller Class Initialized
DEBUG - 2016-10-26 13:59:41 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:59:41 --> Model Class Initialized
INFO - 2016-10-26 13:59:41 --> Model Class Initialized
ERROR - 2016-10-26 13:59:41 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-26 13:59:41 --> Anggota MX_Controller Initialized
INFO - 2016-10-26 13:59:41 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:41 --> Final output sent to browser
DEBUG - 2016-10-26 13:59:41 --> Total execution time: 0.9593
INFO - 2016-10-26 13:59:54 --> Config Class Initialized
INFO - 2016-10-26 13:59:54 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:59:54 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:59:54 --> Utf8 Class Initialized
INFO - 2016-10-26 13:59:54 --> URI Class Initialized
INFO - 2016-10-26 13:59:54 --> Router Class Initialized
INFO - 2016-10-26 13:59:54 --> Output Class Initialized
INFO - 2016-10-26 13:59:54 --> Security Class Initialized
DEBUG - 2016-10-26 13:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:59:55 --> Input Class Initialized
INFO - 2016-10-26 13:59:55 --> Language Class Initialized
INFO - 2016-10-26 13:59:55 --> Language Class Initialized
INFO - 2016-10-26 13:59:55 --> Config Class Initialized
INFO - 2016-10-26 13:59:55 --> Loader Class Initialized
INFO - 2016-10-26 13:59:55 --> Helper loaded: url_helper
INFO - 2016-10-26 13:59:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:59:55 --> Controller Class Initialized
DEBUG - 2016-10-26 13:59:55 --> Index MX_Controller Initialized
INFO - 2016-10-26 13:59:55 --> Model Class Initialized
INFO - 2016-10-26 13:59:55 --> Model Class Initialized
ERROR - 2016-10-26 13:59:55 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-26 13:59:55 --> Anggota MX_Controller Initialized
INFO - 2016-10-26 13:59:55 --> Database Driver Class Initialized
INFO - 2016-10-26 13:59:55 --> Final output sent to browser
DEBUG - 2016-10-26 13:59:55 --> Total execution time: 0.9399
INFO - 2016-10-26 14:00:06 --> Config Class Initialized
INFO - 2016-10-26 14:00:06 --> Hooks Class Initialized
DEBUG - 2016-10-26 14:00:06 --> UTF-8 Support Enabled
INFO - 2016-10-26 14:00:06 --> Utf8 Class Initialized
INFO - 2016-10-26 14:00:06 --> URI Class Initialized
INFO - 2016-10-26 14:00:06 --> Router Class Initialized
INFO - 2016-10-26 14:00:07 --> Output Class Initialized
INFO - 2016-10-26 14:00:07 --> Security Class Initialized
DEBUG - 2016-10-26 14:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 14:00:07 --> Input Class Initialized
INFO - 2016-10-26 14:00:07 --> Language Class Initialized
INFO - 2016-10-26 14:00:07 --> Language Class Initialized
INFO - 2016-10-26 14:00:07 --> Config Class Initialized
INFO - 2016-10-26 14:00:07 --> Loader Class Initialized
INFO - 2016-10-26 14:00:07 --> Helper loaded: url_helper
INFO - 2016-10-26 14:00:07 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 14:00:07 --> Controller Class Initialized
DEBUG - 2016-10-26 14:00:07 --> Index MX_Controller Initialized
INFO - 2016-10-26 14:00:07 --> Model Class Initialized
INFO - 2016-10-26 14:00:07 --> Model Class Initialized
ERROR - 2016-10-26 14:00:07 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-10-26 14:00:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 14:00:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 14:00:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-26 14:00:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_umum.php
DEBUG - 2016-10-26 14:00:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 14:00:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 14:00:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:10 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:10 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:10 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:10 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:10 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:10 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:10 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:10 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:10 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:10 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:10 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:10 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:10 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:10 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:10 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:10 --> Database Driver Class Initialized
DEBUG - 2016-10-26 14:00:10 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 14:00:10 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 14:00:10 --> Final output sent to browser
DEBUG - 2016-10-26 14:00:10 --> Total execution time: 4.1088
INFO - 2016-10-26 14:00:45 --> Config Class Initialized
INFO - 2016-10-26 14:00:45 --> Hooks Class Initialized
DEBUG - 2016-10-26 14:00:45 --> UTF-8 Support Enabled
INFO - 2016-10-26 14:00:46 --> Utf8 Class Initialized
INFO - 2016-10-26 14:00:46 --> URI Class Initialized
INFO - 2016-10-26 14:00:46 --> Router Class Initialized
INFO - 2016-10-26 14:00:46 --> Output Class Initialized
INFO - 2016-10-26 14:00:46 --> Security Class Initialized
DEBUG - 2016-10-26 14:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 14:00:46 --> Input Class Initialized
INFO - 2016-10-26 14:00:46 --> Language Class Initialized
INFO - 2016-10-26 14:00:46 --> Language Class Initialized
INFO - 2016-10-26 14:00:46 --> Config Class Initialized
INFO - 2016-10-26 14:00:46 --> Loader Class Initialized
INFO - 2016-10-26 14:00:46 --> Helper loaded: url_helper
INFO - 2016-10-26 14:00:46 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 14:00:46 --> Controller Class Initialized
DEBUG - 2016-10-26 14:00:46 --> Index MX_Controller Initialized
INFO - 2016-10-26 14:00:46 --> Model Class Initialized
INFO - 2016-10-26 14:00:46 --> Model Class Initialized
ERROR - 2016-10-26 14:00:46 --> Unable to delete cache file for admin/index/do_ajukan_pinjaman
INFO - 2016-10-26 14:00:46 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:46 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:47 --> Final output sent to browser
DEBUG - 2016-10-26 14:00:47 --> Total execution time: 1.1752
INFO - 2016-10-26 14:00:47 --> Config Class Initialized
INFO - 2016-10-26 14:00:47 --> Hooks Class Initialized
DEBUG - 2016-10-26 14:00:47 --> UTF-8 Support Enabled
INFO - 2016-10-26 14:00:47 --> Utf8 Class Initialized
INFO - 2016-10-26 14:00:47 --> URI Class Initialized
INFO - 2016-10-26 14:00:47 --> Router Class Initialized
INFO - 2016-10-26 14:00:47 --> Output Class Initialized
INFO - 2016-10-26 14:00:47 --> Security Class Initialized
DEBUG - 2016-10-26 14:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 14:00:47 --> Input Class Initialized
INFO - 2016-10-26 14:00:47 --> Language Class Initialized
INFO - 2016-10-26 14:00:47 --> Language Class Initialized
INFO - 2016-10-26 14:00:47 --> Config Class Initialized
INFO - 2016-10-26 14:00:47 --> Loader Class Initialized
INFO - 2016-10-26 14:00:47 --> Helper loaded: url_helper
INFO - 2016-10-26 14:00:47 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 14:00:47 --> Controller Class Initialized
DEBUG - 2016-10-26 14:00:47 --> Index MX_Controller Initialized
INFO - 2016-10-26 14:00:48 --> Model Class Initialized
INFO - 2016-10-26 14:00:48 --> Model Class Initialized
ERROR - 2016-10-26 14:00:48 --> Unable to delete cache file for admin/index/do_ajukan_pinjaman
INFO - 2016-10-26 14:00:48 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:48 --> Database Driver Class Initialized
INFO - 2016-10-26 14:00:48 --> Final output sent to browser
DEBUG - 2016-10-26 14:00:48 --> Total execution time: 1.1361
INFO - 2016-10-26 14:01:16 --> Config Class Initialized
INFO - 2016-10-26 14:01:16 --> Hooks Class Initialized
DEBUG - 2016-10-26 14:01:16 --> UTF-8 Support Enabled
INFO - 2016-10-26 14:01:16 --> Utf8 Class Initialized
INFO - 2016-10-26 14:01:16 --> URI Class Initialized
INFO - 2016-10-26 14:01:16 --> Router Class Initialized
INFO - 2016-10-26 14:01:16 --> Output Class Initialized
INFO - 2016-10-26 14:01:17 --> Security Class Initialized
DEBUG - 2016-10-26 14:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 14:01:17 --> Input Class Initialized
INFO - 2016-10-26 14:01:17 --> Language Class Initialized
INFO - 2016-10-26 14:01:17 --> Language Class Initialized
INFO - 2016-10-26 14:01:17 --> Config Class Initialized
INFO - 2016-10-26 14:01:17 --> Loader Class Initialized
INFO - 2016-10-26 14:01:17 --> Helper loaded: url_helper
INFO - 2016-10-26 14:01:17 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 14:01:17 --> Controller Class Initialized
DEBUG - 2016-10-26 14:01:17 --> Index MX_Controller Initialized
INFO - 2016-10-26 14:01:17 --> Model Class Initialized
INFO - 2016-10-26 14:01:17 --> Model Class Initialized
ERROR - 2016-10-26 14:01:17 --> Unable to delete cache file for admin/index/do_save_jaminan/sertifikat
INFO - 2016-10-26 14:01:17 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:17 --> Final output sent to browser
DEBUG - 2016-10-26 14:01:17 --> Total execution time: 1.1064
INFO - 2016-10-26 14:01:38 --> Config Class Initialized
INFO - 2016-10-26 14:01:38 --> Hooks Class Initialized
DEBUG - 2016-10-26 14:01:38 --> UTF-8 Support Enabled
INFO - 2016-10-26 14:01:38 --> Utf8 Class Initialized
INFO - 2016-10-26 14:01:38 --> URI Class Initialized
INFO - 2016-10-26 14:01:38 --> Router Class Initialized
INFO - 2016-10-26 14:01:38 --> Output Class Initialized
INFO - 2016-10-26 14:01:38 --> Security Class Initialized
DEBUG - 2016-10-26 14:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 14:01:39 --> Input Class Initialized
INFO - 2016-10-26 14:01:39 --> Language Class Initialized
INFO - 2016-10-26 14:01:39 --> Language Class Initialized
INFO - 2016-10-26 14:01:39 --> Config Class Initialized
INFO - 2016-10-26 14:01:39 --> Loader Class Initialized
INFO - 2016-10-26 14:01:39 --> Helper loaded: url_helper
INFO - 2016-10-26 14:01:39 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 14:01:39 --> Controller Class Initialized
DEBUG - 2016-10-26 14:01:39 --> Index MX_Controller Initialized
INFO - 2016-10-26 14:01:39 --> Model Class Initialized
INFO - 2016-10-26 14:01:39 --> Model Class Initialized
ERROR - 2016-10-26 14:01:39 --> Unable to delete cache file for admin/index/finish_pinjaman/af3e133428b9e25c55bc59fe534248e6a0c0f17b
INFO - 2016-10-26 14:01:39 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:39 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:39 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:39 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:39 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:39 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:39 --> Final output sent to browser
DEBUG - 2016-10-26 14:01:39 --> Total execution time: 1.2257
INFO - 2016-10-26 14:01:40 --> Config Class Initialized
INFO - 2016-10-26 14:01:40 --> Hooks Class Initialized
DEBUG - 2016-10-26 14:01:40 --> UTF-8 Support Enabled
INFO - 2016-10-26 14:01:40 --> Utf8 Class Initialized
INFO - 2016-10-26 14:01:40 --> URI Class Initialized
INFO - 2016-10-26 14:01:40 --> Router Class Initialized
INFO - 2016-10-26 14:01:40 --> Output Class Initialized
INFO - 2016-10-26 14:01:40 --> Security Class Initialized
DEBUG - 2016-10-26 14:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 14:01:40 --> Input Class Initialized
INFO - 2016-10-26 14:01:40 --> Language Class Initialized
INFO - 2016-10-26 14:01:40 --> Language Class Initialized
INFO - 2016-10-26 14:01:40 --> Config Class Initialized
INFO - 2016-10-26 14:01:40 --> Loader Class Initialized
INFO - 2016-10-26 14:01:40 --> Config Class Initialized
INFO - 2016-10-26 14:01:40 --> Hooks Class Initialized
INFO - 2016-10-26 14:01:40 --> Helper loaded: url_helper
DEBUG - 2016-10-26 14:01:40 --> UTF-8 Support Enabled
INFO - 2016-10-26 14:01:40 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:40 --> Utf8 Class Initialized
INFO - 2016-10-26 14:01:40 --> URI Class Initialized
INFO - 2016-10-26 14:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 14:01:40 --> Controller Class Initialized
INFO - 2016-10-26 14:01:40 --> Router Class Initialized
DEBUG - 2016-10-26 14:01:40 --> Index MX_Controller Initialized
INFO - 2016-10-26 14:01:40 --> Output Class Initialized
INFO - 2016-10-26 14:01:41 --> Model Class Initialized
INFO - 2016-10-26 14:01:41 --> Security Class Initialized
INFO - 2016-10-26 14:01:41 --> Model Class Initialized
DEBUG - 2016-10-26 14:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 14:01:41 --> Input Class Initialized
ERROR - 2016-10-26 14:01:41 --> Unable to delete cache file for admin/index/data_peminjam
INFO - 2016-10-26 14:01:41 --> Language Class Initialized
DEBUG - 2016-10-26 14:01:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 14:01:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
INFO - 2016-10-26 14:01:41 --> Language Class Initialized
INFO - 2016-10-26 14:01:41 --> Config Class Initialized
DEBUG - 2016-10-26 14:01:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-26 14:01:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_peminjam.php
INFO - 2016-10-26 14:01:41 --> Loader Class Initialized
DEBUG - 2016-10-26 14:01:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 14:01:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 14:01:41 --> Helper loaded: url_helper
INFO - 2016-10-26 14:01:41 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:41 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:41 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:41 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:41 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:41 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:41 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:41 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:41 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:41 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:41 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:41 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:41 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:42 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:42 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:42 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:42 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:42 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:42 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:42 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:42 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:42 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:42 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:42 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:42 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:42 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:42 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:42 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:42 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:42 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:43 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:43 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:43 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:43 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:43 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:43 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:43 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:43 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:43 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:43 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:43 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:43 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:43 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:43 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:43 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:43 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:43 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:43 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:43 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:43 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:43 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:43 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:44 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:44 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:44 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:44 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:44 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:44 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:44 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:44 --> Database Driver Class Initialized
DEBUG - 2016-10-26 14:01:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 14:01:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 14:01:44 --> Final output sent to browser
DEBUG - 2016-10-26 14:01:44 --> Total execution time: 4.4341
INFO - 2016-10-26 14:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 14:01:44 --> Controller Class Initialized
DEBUG - 2016-10-26 14:01:44 --> Index MX_Controller Initialized
INFO - 2016-10-26 14:01:44 --> Model Class Initialized
INFO - 2016-10-26 14:01:44 --> Model Class Initialized
ERROR - 2016-10-26 14:01:44 --> Unable to delete cache file for admin/index/finish_pinjaman/af3e133428b9e25c55bc59fe534248e6a0c0f17b
INFO - 2016-10-26 14:01:45 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:45 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:45 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:45 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:45 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:46 --> Database Driver Class Initialized
INFO - 2016-10-26 14:01:46 --> Final output sent to browser
DEBUG - 2016-10-26 14:01:46 --> Total execution time: 5.5577
INFO - 2016-10-26 14:02:06 --> Config Class Initialized
INFO - 2016-10-26 14:02:06 --> Hooks Class Initialized
DEBUG - 2016-10-26 14:02:06 --> UTF-8 Support Enabled
INFO - 2016-10-26 14:02:06 --> Utf8 Class Initialized
INFO - 2016-10-26 14:02:06 --> Config Class Initialized
INFO - 2016-10-26 14:02:06 --> Hooks Class Initialized
INFO - 2016-10-26 14:02:06 --> URI Class Initialized
DEBUG - 2016-10-26 14:02:07 --> UTF-8 Support Enabled
INFO - 2016-10-26 14:02:07 --> Router Class Initialized
INFO - 2016-10-26 14:02:07 --> Utf8 Class Initialized
INFO - 2016-10-26 14:02:07 --> URI Class Initialized
INFO - 2016-10-26 14:02:07 --> Output Class Initialized
INFO - 2016-10-26 14:02:07 --> Security Class Initialized
INFO - 2016-10-26 14:02:07 --> Router Class Initialized
DEBUG - 2016-10-26 14:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 14:02:07 --> Output Class Initialized
INFO - 2016-10-26 14:02:07 --> Input Class Initialized
INFO - 2016-10-26 14:02:07 --> Language Class Initialized
INFO - 2016-10-26 14:02:07 --> Security Class Initialized
DEBUG - 2016-10-26 14:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 14:02:07 --> Language Class Initialized
INFO - 2016-10-26 14:02:07 --> Config Class Initialized
INFO - 2016-10-26 14:02:07 --> Input Class Initialized
INFO - 2016-10-26 14:02:07 --> Language Class Initialized
INFO - 2016-10-26 14:02:07 --> Loader Class Initialized
INFO - 2016-10-26 14:02:07 --> Helper loaded: url_helper
INFO - 2016-10-26 14:02:07 --> Language Class Initialized
INFO - 2016-10-26 14:02:07 --> Config Class Initialized
INFO - 2016-10-26 14:02:07 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:07 --> Loader Class Initialized
INFO - 2016-10-26 14:02:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 14:02:07 --> Controller Class Initialized
INFO - 2016-10-26 14:02:07 --> Helper loaded: url_helper
DEBUG - 2016-10-26 14:02:07 --> Index MX_Controller Initialized
INFO - 2016-10-26 14:02:07 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:07 --> Model Class Initialized
INFO - 2016-10-26 14:02:07 --> Model Class Initialized
ERROR - 2016-10-26 14:02:07 --> Unable to delete cache file for admin/index/bayar_angsuran
DEBUG - 2016-10-26 14:02:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 14:02:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 14:02:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-26 14:02:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_bayar_angsuran.php
DEBUG - 2016-10-26 14:02:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 14:02:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 14:02:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:10 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:10 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:10 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:10 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:10 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:10 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:10 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:10 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:10 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:10 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:10 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:10 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:10 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:10 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:10 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:10 --> Database Driver Class Initialized
DEBUG - 2016-10-26 14:02:10 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 14:02:10 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 14:02:10 --> Final output sent to browser
DEBUG - 2016-10-26 14:02:10 --> Total execution time: 4.0732
INFO - 2016-10-26 14:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 14:02:10 --> Controller Class Initialized
DEBUG - 2016-10-26 14:02:10 --> Index MX_Controller Initialized
INFO - 2016-10-26 14:02:11 --> Model Class Initialized
INFO - 2016-10-26 14:02:11 --> Model Class Initialized
ERROR - 2016-10-26 14:02:11 --> Unable to delete cache file for admin/index/bayar_angsuran
DEBUG - 2016-10-26 14:02:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 14:02:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 14:02:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-26 14:02:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_bayar_angsuran.php
DEBUG - 2016-10-26 14:02:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 14:02:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 14:02:11 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:11 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:11 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:11 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:11 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:11 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:11 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:11 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:11 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:11 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:11 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:11 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:11 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:11 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:12 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:12 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:12 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:12 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:12 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:12 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:12 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:12 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:12 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:12 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:12 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:12 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:12 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:12 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:12 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:12 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:12 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:12 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:12 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:12 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:12 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:13 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:13 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:13 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:13 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:13 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:13 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:13 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:13 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:13 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:13 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:13 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:13 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:13 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:13 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:13 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:13 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:13 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:13 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:13 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:13 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:13 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:14 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:14 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:14 --> Database Driver Class Initialized
DEBUG - 2016-10-26 14:02:14 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 14:02:14 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 14:02:14 --> Final output sent to browser
DEBUG - 2016-10-26 14:02:14 --> Total execution time: 7.2915
INFO - 2016-10-26 14:02:20 --> Config Class Initialized
INFO - 2016-10-26 14:02:20 --> Hooks Class Initialized
DEBUG - 2016-10-26 14:02:20 --> UTF-8 Support Enabled
INFO - 2016-10-26 14:02:20 --> Utf8 Class Initialized
INFO - 2016-10-26 14:02:20 --> URI Class Initialized
INFO - 2016-10-26 14:02:20 --> Router Class Initialized
INFO - 2016-10-26 14:02:20 --> Output Class Initialized
INFO - 2016-10-26 14:02:20 --> Security Class Initialized
DEBUG - 2016-10-26 14:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 14:02:20 --> Input Class Initialized
INFO - 2016-10-26 14:02:20 --> Language Class Initialized
INFO - 2016-10-26 14:02:21 --> Language Class Initialized
INFO - 2016-10-26 14:02:21 --> Config Class Initialized
INFO - 2016-10-26 14:02:21 --> Loader Class Initialized
INFO - 2016-10-26 14:02:21 --> Helper loaded: url_helper
INFO - 2016-10-26 14:02:21 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 14:02:21 --> Controller Class Initialized
DEBUG - 2016-10-26 14:02:21 --> Index MX_Controller Initialized
INFO - 2016-10-26 14:02:21 --> Model Class Initialized
INFO - 2016-10-26 14:02:21 --> Model Class Initialized
ERROR - 2016-10-26 14:02:21 --> Unable to delete cache file for admin/index/getDetailAngsuran
INFO - 2016-10-26 14:02:21 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:21 --> Final output sent to browser
DEBUG - 2016-10-26 14:02:21 --> Total execution time: 0.9220
INFO - 2016-10-26 14:02:33 --> Config Class Initialized
INFO - 2016-10-26 14:02:33 --> Hooks Class Initialized
DEBUG - 2016-10-26 14:02:33 --> UTF-8 Support Enabled
INFO - 2016-10-26 14:02:33 --> Utf8 Class Initialized
INFO - 2016-10-26 14:02:33 --> URI Class Initialized
INFO - 2016-10-26 14:02:33 --> Router Class Initialized
INFO - 2016-10-26 14:02:33 --> Output Class Initialized
INFO - 2016-10-26 14:02:33 --> Security Class Initialized
DEBUG - 2016-10-26 14:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 14:02:33 --> Input Class Initialized
INFO - 2016-10-26 14:02:33 --> Language Class Initialized
INFO - 2016-10-26 14:02:33 --> Language Class Initialized
INFO - 2016-10-26 14:02:33 --> Config Class Initialized
INFO - 2016-10-26 14:02:34 --> Loader Class Initialized
INFO - 2016-10-26 14:02:34 --> Helper loaded: url_helper
INFO - 2016-10-26 14:02:34 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 14:02:34 --> Controller Class Initialized
DEBUG - 2016-10-26 14:02:34 --> Index MX_Controller Initialized
INFO - 2016-10-26 14:02:34 --> Model Class Initialized
INFO - 2016-10-26 14:02:34 --> Model Class Initialized
ERROR - 2016-10-26 14:02:34 --> Unable to delete cache file for admin/index/do_bayar
INFO - 2016-10-26 14:02:34 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:34 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:34 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:34 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:34 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:34 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:34 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:34 --> Final output sent to browser
DEBUG - 2016-10-26 14:02:34 --> Total execution time: 1.4211
INFO - 2016-10-26 14:02:38 --> Config Class Initialized
INFO - 2016-10-26 14:02:38 --> Hooks Class Initialized
DEBUG - 2016-10-26 14:02:38 --> UTF-8 Support Enabled
INFO - 2016-10-26 14:02:38 --> Utf8 Class Initialized
INFO - 2016-10-26 14:02:38 --> URI Class Initialized
INFO - 2016-10-26 14:02:38 --> Router Class Initialized
INFO - 2016-10-26 14:02:38 --> Output Class Initialized
INFO - 2016-10-26 14:02:38 --> Security Class Initialized
DEBUG - 2016-10-26 14:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 14:02:38 --> Input Class Initialized
INFO - 2016-10-26 14:02:38 --> Language Class Initialized
INFO - 2016-10-26 14:02:38 --> Language Class Initialized
INFO - 2016-10-26 14:02:38 --> Config Class Initialized
INFO - 2016-10-26 14:02:38 --> Loader Class Initialized
INFO - 2016-10-26 14:02:38 --> Helper loaded: url_helper
INFO - 2016-10-26 14:02:39 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 14:02:39 --> Controller Class Initialized
DEBUG - 2016-10-26 14:02:39 --> Index MX_Controller Initialized
INFO - 2016-10-26 14:02:39 --> Model Class Initialized
INFO - 2016-10-26 14:02:39 --> Model Class Initialized
ERROR - 2016-10-26 14:02:39 --> Unable to delete cache file for admin/index/getDetailAngsuran
INFO - 2016-10-26 14:02:39 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:39 --> Final output sent to browser
DEBUG - 2016-10-26 14:02:39 --> Total execution time: 1.0461
INFO - 2016-10-26 14:02:47 --> Config Class Initialized
INFO - 2016-10-26 14:02:47 --> Hooks Class Initialized
DEBUG - 2016-10-26 14:02:47 --> UTF-8 Support Enabled
INFO - 2016-10-26 14:02:47 --> Utf8 Class Initialized
INFO - 2016-10-26 14:02:47 --> URI Class Initialized
INFO - 2016-10-26 14:02:47 --> Router Class Initialized
INFO - 2016-10-26 14:02:47 --> Output Class Initialized
INFO - 2016-10-26 14:02:47 --> Security Class Initialized
DEBUG - 2016-10-26 14:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 14:02:47 --> Input Class Initialized
INFO - 2016-10-26 14:02:47 --> Language Class Initialized
INFO - 2016-10-26 14:02:47 --> Language Class Initialized
INFO - 2016-10-26 14:02:48 --> Config Class Initialized
INFO - 2016-10-26 14:02:48 --> Loader Class Initialized
INFO - 2016-10-26 14:02:48 --> Helper loaded: url_helper
INFO - 2016-10-26 14:02:48 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 14:02:48 --> Controller Class Initialized
DEBUG - 2016-10-26 14:02:48 --> Index MX_Controller Initialized
INFO - 2016-10-26 14:02:48 --> Model Class Initialized
INFO - 2016-10-26 14:02:48 --> Model Class Initialized
ERROR - 2016-10-26 14:02:48 --> Unable to delete cache file for admin/index/do_bayar
INFO - 2016-10-26 14:02:48 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:48 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:48 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:48 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:48 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:48 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:48 --> Config Class Initialized
INFO - 2016-10-26 14:02:49 --> Hooks Class Initialized
INFO - 2016-10-26 14:02:49 --> Config Class Initialized
DEBUG - 2016-10-26 14:02:49 --> UTF-8 Support Enabled
INFO - 2016-10-26 14:02:49 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:49 --> Hooks Class Initialized
INFO - 2016-10-26 14:02:49 --> Utf8 Class Initialized
DEBUG - 2016-10-26 14:02:49 --> UTF-8 Support Enabled
INFO - 2016-10-26 14:02:49 --> Utf8 Class Initialized
INFO - 2016-10-26 14:02:49 --> URI Class Initialized
INFO - 2016-10-26 14:02:49 --> Final output sent to browser
DEBUG - 2016-10-26 14:02:49 --> Total execution time: 1.8538
INFO - 2016-10-26 14:02:49 --> URI Class Initialized
INFO - 2016-10-26 14:02:49 --> Router Class Initialized
INFO - 2016-10-26 14:02:49 --> Router Class Initialized
INFO - 2016-10-26 14:02:49 --> Output Class Initialized
INFO - 2016-10-26 14:02:49 --> Output Class Initialized
INFO - 2016-10-26 14:02:49 --> Security Class Initialized
INFO - 2016-10-26 14:02:49 --> Security Class Initialized
DEBUG - 2016-10-26 14:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-10-26 14:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 14:02:49 --> Input Class Initialized
INFO - 2016-10-26 14:02:49 --> Input Class Initialized
INFO - 2016-10-26 14:02:49 --> Language Class Initialized
INFO - 2016-10-26 14:02:49 --> Language Class Initialized
INFO - 2016-10-26 14:02:49 --> Language Class Initialized
INFO - 2016-10-26 14:02:49 --> Config Class Initialized
INFO - 2016-10-26 14:02:49 --> Language Class Initialized
INFO - 2016-10-26 14:02:49 --> Config Class Initialized
INFO - 2016-10-26 14:02:49 --> Loader Class Initialized
INFO - 2016-10-26 14:02:49 --> Helper loaded: url_helper
INFO - 2016-10-26 14:02:49 --> Loader Class Initialized
INFO - 2016-10-26 14:02:49 --> Helper loaded: url_helper
INFO - 2016-10-26 14:02:49 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 14:02:49 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:49 --> Controller Class Initialized
DEBUG - 2016-10-26 14:02:50 --> Index MX_Controller Initialized
INFO - 2016-10-26 14:02:50 --> Model Class Initialized
INFO - 2016-10-26 14:02:50 --> Model Class Initialized
ERROR - 2016-10-26 14:02:50 --> Unable to delete cache file for admin/index/do_bayar
INFO - 2016-10-26 14:02:50 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:50 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:50 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:50 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:50 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:50 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:50 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:50 --> Final output sent to browser
DEBUG - 2016-10-26 14:02:50 --> Total execution time: 1.6853
INFO - 2016-10-26 14:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 14:02:50 --> Controller Class Initialized
DEBUG - 2016-10-26 14:02:50 --> Index MX_Controller Initialized
INFO - 2016-10-26 14:02:50 --> Model Class Initialized
INFO - 2016-10-26 14:02:50 --> Model Class Initialized
ERROR - 2016-10-26 14:02:50 --> Unable to delete cache file for admin/index/do_bayar
INFO - 2016-10-26 14:02:51 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:51 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:51 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:51 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:51 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:51 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:51 --> Database Driver Class Initialized
INFO - 2016-10-26 14:02:51 --> Final output sent to browser
DEBUG - 2016-10-26 14:02:51 --> Total execution time: 2.6711
INFO - 2016-10-26 14:03:05 --> Config Class Initialized
INFO - 2016-10-26 14:03:05 --> Hooks Class Initialized
DEBUG - 2016-10-26 14:03:05 --> UTF-8 Support Enabled
INFO - 2016-10-26 14:03:05 --> Utf8 Class Initialized
INFO - 2016-10-26 14:03:05 --> Config Class Initialized
INFO - 2016-10-26 14:03:05 --> Hooks Class Initialized
INFO - 2016-10-26 14:03:05 --> URI Class Initialized
DEBUG - 2016-10-26 14:03:05 --> UTF-8 Support Enabled
INFO - 2016-10-26 14:03:05 --> Router Class Initialized
INFO - 2016-10-26 14:03:05 --> Utf8 Class Initialized
INFO - 2016-10-26 14:03:05 --> Output Class Initialized
INFO - 2016-10-26 14:03:05 --> Security Class Initialized
INFO - 2016-10-26 14:03:05 --> URI Class Initialized
DEBUG - 2016-10-26 14:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 14:03:05 --> Router Class Initialized
INFO - 2016-10-26 14:03:05 --> Input Class Initialized
INFO - 2016-10-26 14:03:05 --> Language Class Initialized
INFO - 2016-10-26 14:03:05 --> Output Class Initialized
INFO - 2016-10-26 14:03:05 --> Security Class Initialized
INFO - 2016-10-26 14:03:05 --> Language Class Initialized
INFO - 2016-10-26 14:03:05 --> Config Class Initialized
DEBUG - 2016-10-26 14:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 14:03:05 --> Input Class Initialized
INFO - 2016-10-26 14:03:05 --> Loader Class Initialized
INFO - 2016-10-26 14:03:05 --> Language Class Initialized
INFO - 2016-10-26 14:03:05 --> Helper loaded: url_helper
INFO - 2016-10-26 14:03:05 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:05 --> Language Class Initialized
INFO - 2016-10-26 14:03:05 --> Config Class Initialized
INFO - 2016-10-26 14:03:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 14:03:05 --> Controller Class Initialized
DEBUG - 2016-10-26 14:03:05 --> Index MX_Controller Initialized
INFO - 2016-10-26 14:03:05 --> Loader Class Initialized
INFO - 2016-10-26 14:03:05 --> Model Class Initialized
INFO - 2016-10-26 14:03:05 --> Helper loaded: url_helper
INFO - 2016-10-26 14:03:05 --> Model Class Initialized
INFO - 2016-10-26 14:03:05 --> Database Driver Class Initialized
ERROR - 2016-10-26 14:03:05 --> Unable to delete cache file for admin/index/tutup_angsuran
DEBUG - 2016-10-26 14:03:06 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 14:03:06 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 14:03:06 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-26 14:03:06 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_tutup_angsuran.php
DEBUG - 2016-10-26 14:03:06 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 14:03:06 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 14:03:06 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:06 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:06 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:06 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:06 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:06 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:06 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:06 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:06 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:06 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:06 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:06 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:06 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:06 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:06 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:06 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:06 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:07 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:07 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:07 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:07 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:07 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:07 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:07 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:07 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:07 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:07 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:07 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:07 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:07 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:07 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:07 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:07 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:07 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:07 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:07 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:07 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:07 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:08 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:08 --> Database Driver Class Initialized
DEBUG - 2016-10-26 14:03:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 14:03:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 14:03:09 --> Final output sent to browser
DEBUG - 2016-10-26 14:03:09 --> Total execution time: 4.0512
INFO - 2016-10-26 14:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 14:03:09 --> Controller Class Initialized
DEBUG - 2016-10-26 14:03:09 --> Index MX_Controller Initialized
INFO - 2016-10-26 14:03:09 --> Model Class Initialized
INFO - 2016-10-26 14:03:09 --> Model Class Initialized
ERROR - 2016-10-26 14:03:09 --> Unable to delete cache file for admin/index/tutup_angsuran
DEBUG - 2016-10-26 14:03:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 14:03:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 14:03:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-26 14:03:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_tutup_angsuran.php
DEBUG - 2016-10-26 14:03:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 14:03:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 14:03:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:10 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:10 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:10 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:10 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:10 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:10 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:10 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:10 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:10 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:10 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:10 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:10 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:10 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:10 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:10 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:10 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:10 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:10 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:10 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:10 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:10 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:10 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:11 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:11 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:11 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:11 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:11 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:11 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:11 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:11 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:11 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:11 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:11 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:11 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:11 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:11 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:11 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:11 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:11 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:11 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:11 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:11 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:11 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:12 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:12 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:12 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:12 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:12 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:12 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:12 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:12 --> Database Driver Class Initialized
DEBUG - 2016-10-26 14:03:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 14:03:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 14:03:12 --> Final output sent to browser
DEBUG - 2016-10-26 14:03:12 --> Total execution time: 7.2340
INFO - 2016-10-26 14:03:17 --> Config Class Initialized
INFO - 2016-10-26 14:03:17 --> Hooks Class Initialized
DEBUG - 2016-10-26 14:03:17 --> UTF-8 Support Enabled
INFO - 2016-10-26 14:03:17 --> Utf8 Class Initialized
INFO - 2016-10-26 14:03:17 --> URI Class Initialized
INFO - 2016-10-26 14:03:17 --> Router Class Initialized
INFO - 2016-10-26 14:03:17 --> Output Class Initialized
INFO - 2016-10-26 14:03:18 --> Security Class Initialized
DEBUG - 2016-10-26 14:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 14:03:18 --> Input Class Initialized
INFO - 2016-10-26 14:03:18 --> Language Class Initialized
INFO - 2016-10-26 14:03:18 --> Language Class Initialized
INFO - 2016-10-26 14:03:18 --> Config Class Initialized
INFO - 2016-10-26 14:03:18 --> Loader Class Initialized
INFO - 2016-10-26 14:03:18 --> Helper loaded: url_helper
INFO - 2016-10-26 14:03:18 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 14:03:18 --> Controller Class Initialized
DEBUG - 2016-10-26 14:03:18 --> Index MX_Controller Initialized
INFO - 2016-10-26 14:03:18 --> Model Class Initialized
INFO - 2016-10-26 14:03:18 --> Model Class Initialized
ERROR - 2016-10-26 14:03:18 --> Unable to delete cache file for admin/index/getDetailLunas
INFO - 2016-10-26 14:03:18 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:18 --> Final output sent to browser
DEBUG - 2016-10-26 14:03:18 --> Total execution time: 1.0424
INFO - 2016-10-26 14:03:30 --> Config Class Initialized
INFO - 2016-10-26 14:03:30 --> Hooks Class Initialized
DEBUG - 2016-10-26 14:03:30 --> UTF-8 Support Enabled
INFO - 2016-10-26 14:03:30 --> Utf8 Class Initialized
INFO - 2016-10-26 14:03:30 --> URI Class Initialized
INFO - 2016-10-26 14:03:30 --> Router Class Initialized
INFO - 2016-10-26 14:03:30 --> Output Class Initialized
INFO - 2016-10-26 14:03:30 --> Security Class Initialized
DEBUG - 2016-10-26 14:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 14:03:30 --> Input Class Initialized
INFO - 2016-10-26 14:03:31 --> Language Class Initialized
INFO - 2016-10-26 14:03:31 --> Language Class Initialized
INFO - 2016-10-26 14:03:31 --> Config Class Initialized
INFO - 2016-10-26 14:03:31 --> Loader Class Initialized
INFO - 2016-10-26 14:03:31 --> Helper loaded: url_helper
INFO - 2016-10-26 14:03:31 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 14:03:31 --> Controller Class Initialized
DEBUG - 2016-10-26 14:03:31 --> Index MX_Controller Initialized
INFO - 2016-10-26 14:03:31 --> Model Class Initialized
INFO - 2016-10-26 14:03:31 --> Model Class Initialized
ERROR - 2016-10-26 14:03:31 --> Unable to delete cache file for admin/index/do_lunas
INFO - 2016-10-26 14:03:31 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:31 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:31 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:31 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:31 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:32 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:32 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:32 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:32 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:32 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:32 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:32 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:32 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:32 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:33 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:33 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:33 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:33 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:33 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:33 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:33 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:33 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:33 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:33 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:33 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:34 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:34 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:34 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:34 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:34 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:34 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:34 --> Final output sent to browser
DEBUG - 2016-10-26 14:03:34 --> Total execution time: 4.0585
INFO - 2016-10-26 14:03:55 --> Config Class Initialized
INFO - 2016-10-26 14:03:55 --> Hooks Class Initialized
DEBUG - 2016-10-26 14:03:55 --> UTF-8 Support Enabled
INFO - 2016-10-26 14:03:55 --> Utf8 Class Initialized
INFO - 2016-10-26 14:03:55 --> Config Class Initialized
INFO - 2016-10-26 14:03:55 --> Hooks Class Initialized
INFO - 2016-10-26 14:03:55 --> URI Class Initialized
INFO - 2016-10-26 14:03:55 --> Router Class Initialized
DEBUG - 2016-10-26 14:03:55 --> UTF-8 Support Enabled
INFO - 2016-10-26 14:03:55 --> Utf8 Class Initialized
INFO - 2016-10-26 14:03:55 --> Output Class Initialized
INFO - 2016-10-26 14:03:55 --> URI Class Initialized
INFO - 2016-10-26 14:03:55 --> Security Class Initialized
DEBUG - 2016-10-26 14:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 14:03:56 --> Router Class Initialized
INFO - 2016-10-26 14:03:56 --> Input Class Initialized
INFO - 2016-10-26 14:03:56 --> Language Class Initialized
INFO - 2016-10-26 14:03:56 --> Output Class Initialized
INFO - 2016-10-26 14:03:56 --> Security Class Initialized
INFO - 2016-10-26 14:03:56 --> Language Class Initialized
INFO - 2016-10-26 14:03:56 --> Config Class Initialized
DEBUG - 2016-10-26 14:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 14:03:56 --> Input Class Initialized
INFO - 2016-10-26 14:03:56 --> Loader Class Initialized
INFO - 2016-10-26 14:03:56 --> Language Class Initialized
INFO - 2016-10-26 14:03:56 --> Helper loaded: url_helper
INFO - 2016-10-26 14:03:56 --> Language Class Initialized
INFO - 2016-10-26 14:03:56 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:56 --> Config Class Initialized
INFO - 2016-10-26 14:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 14:03:56 --> Controller Class Initialized
DEBUG - 2016-10-26 14:03:56 --> Index MX_Controller Initialized
INFO - 2016-10-26 14:03:56 --> Loader Class Initialized
INFO - 2016-10-26 14:03:56 --> Model Class Initialized
INFO - 2016-10-26 14:03:56 --> Helper loaded: url_helper
INFO - 2016-10-26 14:03:56 --> Model Class Initialized
INFO - 2016-10-26 14:03:56 --> Database Driver Class Initialized
ERROR - 2016-10-26 14:03:56 --> Unable to delete cache file for admin/index/data/anggota
DEBUG - 2016-10-26 14:03:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 14:03:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 14:03:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-26 14:03:56 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-26 14:03:56 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-26 14:03:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-26 14:03:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 14:03:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 14:03:56 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:56 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:56 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:57 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:57 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:57 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:57 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:57 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:57 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:57 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:57 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:57 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:57 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:57 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:57 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:57 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:57 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:57 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:57 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:57 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:57 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:57 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:58 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:58 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:58 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:58 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:58 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:58 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:58 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:58 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:58 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:58 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:58 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:58 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:58 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:58 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:58 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:58 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:58 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:58 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:58 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:58 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:58 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:59 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:59 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:59 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:59 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:59 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:59 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:59 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:59 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:59 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:59 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:59 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:59 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:59 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:59 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:59 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:59 --> Database Driver Class Initialized
INFO - 2016-10-26 14:03:59 --> Database Driver Class Initialized
DEBUG - 2016-10-26 14:03:59 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 14:03:59 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 14:03:59 --> Final output sent to browser
DEBUG - 2016-10-26 14:03:59 --> Total execution time: 4.3265
INFO - 2016-10-26 14:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 14:04:00 --> Controller Class Initialized
DEBUG - 2016-10-26 14:04:00 --> Index MX_Controller Initialized
INFO - 2016-10-26 14:04:00 --> Model Class Initialized
INFO - 2016-10-26 14:04:00 --> Model Class Initialized
ERROR - 2016-10-26 14:04:00 --> Unable to delete cache file for admin/index/data/anggota
DEBUG - 2016-10-26 14:04:00 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 14:04:00 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 14:04:00 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-26 14:04:00 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-26 14:04:00 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-26 14:04:00 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-26 14:04:00 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 14:04:00 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 14:04:00 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:00 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:00 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:00 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:00 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:00 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:00 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:00 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:00 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:00 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:01 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:01 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:01 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:01 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:01 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:01 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:01 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:01 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:01 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:01 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:01 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:01 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:01 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:01 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:01 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:01 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:01 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:01 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:01 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:01 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:01 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:02 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:02 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:02 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:02 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:02 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:02 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:02 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:02 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:02 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:02 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:02 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:02 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:02 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:02 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:02 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:02 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:02 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:02 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:02 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:02 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:02 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:03 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:03 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:03 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:03 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:03 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:03 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:03 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:03 --> Database Driver Class Initialized
DEBUG - 2016-10-26 14:04:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 14:04:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 14:04:03 --> Final output sent to browser
DEBUG - 2016-10-26 14:04:03 --> Total execution time: 7.6612
INFO - 2016-10-26 14:04:27 --> Config Class Initialized
INFO - 2016-10-26 14:04:27 --> Hooks Class Initialized
DEBUG - 2016-10-26 14:04:27 --> UTF-8 Support Enabled
INFO - 2016-10-26 14:04:27 --> Utf8 Class Initialized
INFO - 2016-10-26 14:04:27 --> URI Class Initialized
INFO - 2016-10-26 14:04:27 --> Router Class Initialized
INFO - 2016-10-26 14:04:27 --> Output Class Initialized
INFO - 2016-10-26 14:04:27 --> Security Class Initialized
DEBUG - 2016-10-26 14:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 14:04:27 --> Input Class Initialized
INFO - 2016-10-26 14:04:27 --> Language Class Initialized
INFO - 2016-10-26 14:04:27 --> Language Class Initialized
INFO - 2016-10-26 14:04:27 --> Config Class Initialized
INFO - 2016-10-26 14:04:27 --> Loader Class Initialized
INFO - 2016-10-26 14:04:27 --> Helper loaded: url_helper
INFO - 2016-10-26 14:04:27 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 14:04:27 --> Controller Class Initialized
DEBUG - 2016-10-26 14:04:27 --> Index MX_Controller Initialized
INFO - 2016-10-26 14:04:28 --> Model Class Initialized
INFO - 2016-10-26 14:04:28 --> Model Class Initialized
ERROR - 2016-10-26 14:04:28 --> Unable to delete cache file for admin/index/data/anggota/umum
DEBUG - 2016-10-26 14:04:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 14:04:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 14:04:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-26 14:04:28 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-26 14:04:28 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-26 14:04:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-26 14:04:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 14:04:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 14:04:28 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:28 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:28 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:28 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:28 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:28 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:28 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:28 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:28 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:28 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:28 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:28 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:28 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:29 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:29 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:29 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:29 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:29 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:29 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:29 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:29 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:29 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:29 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:29 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:29 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:29 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:29 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:29 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:29 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:29 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:29 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:29 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:29 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:29 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:30 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:30 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:30 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:30 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:30 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:30 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:30 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:30 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:30 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:30 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:30 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:30 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:30 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:30 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:30 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:30 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:30 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:30 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:30 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:30 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:30 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:31 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:31 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:31 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:31 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:31 --> Database Driver Class Initialized
DEBUG - 2016-10-26 14:04:31 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 14:04:31 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 14:04:31 --> Final output sent to browser
DEBUG - 2016-10-26 14:04:31 --> Total execution time: 4.2826
INFO - 2016-10-26 14:04:40 --> Config Class Initialized
INFO - 2016-10-26 14:04:40 --> Hooks Class Initialized
DEBUG - 2016-10-26 14:04:40 --> UTF-8 Support Enabled
INFO - 2016-10-26 14:04:40 --> Utf8 Class Initialized
INFO - 2016-10-26 14:04:40 --> Config Class Initialized
INFO - 2016-10-26 14:04:40 --> Hooks Class Initialized
INFO - 2016-10-26 14:04:40 --> URI Class Initialized
DEBUG - 2016-10-26 14:04:40 --> UTF-8 Support Enabled
INFO - 2016-10-26 14:04:40 --> Router Class Initialized
INFO - 2016-10-26 14:04:40 --> Utf8 Class Initialized
INFO - 2016-10-26 14:04:40 --> URI Class Initialized
INFO - 2016-10-26 14:04:40 --> Output Class Initialized
INFO - 2016-10-26 14:04:40 --> Security Class Initialized
INFO - 2016-10-26 14:04:40 --> Router Class Initialized
INFO - 2016-10-26 14:04:40 --> Output Class Initialized
DEBUG - 2016-10-26 14:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 14:04:40 --> Input Class Initialized
INFO - 2016-10-26 14:04:40 --> Security Class Initialized
INFO - 2016-10-26 14:04:40 --> Language Class Initialized
DEBUG - 2016-10-26 14:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 14:04:40 --> Input Class Initialized
INFO - 2016-10-26 14:04:40 --> Language Class Initialized
INFO - 2016-10-26 14:04:40 --> Config Class Initialized
INFO - 2016-10-26 14:04:40 --> Language Class Initialized
INFO - 2016-10-26 14:04:40 --> Loader Class Initialized
INFO - 2016-10-26 14:04:40 --> Language Class Initialized
INFO - 2016-10-26 14:04:40 --> Config Class Initialized
INFO - 2016-10-26 14:04:40 --> Helper loaded: url_helper
INFO - 2016-10-26 14:04:40 --> Loader Class Initialized
INFO - 2016-10-26 14:04:40 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:40 --> Helper loaded: url_helper
INFO - 2016-10-26 14:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 14:04:40 --> Controller Class Initialized
INFO - 2016-10-26 14:04:40 --> Database Driver Class Initialized
DEBUG - 2016-10-26 14:04:40 --> Index MX_Controller Initialized
INFO - 2016-10-26 14:04:40 --> Model Class Initialized
INFO - 2016-10-26 14:04:41 --> Model Class Initialized
ERROR - 2016-10-26 14:04:41 --> Unable to delete cache file for admin/index/detail_anggota/fe5dbbcea5ce7e2988b8c69bcfdfde8904aabc1f
DEBUG - 2016-10-26 14:04:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 14:04:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 14:04:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
INFO - 2016-10-26 14:04:41 --> Database Driver Class Initialized
DEBUG - 2016-10-26 14:04:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_pinjaman.php
INFO - 2016-10-26 14:04:41 --> Database Driver Class Initialized
DEBUG - 2016-10-26 14:04:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_tabungan.php
DEBUG - 2016-10-26 14:04:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/profile_anggota.php
DEBUG - 2016-10-26 14:04:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 14:04:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 14:04:41 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:41 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:41 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:41 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:41 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:41 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:41 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:41 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:42 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:42 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:42 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:42 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:42 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:42 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:42 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:42 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:42 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:42 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:42 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:42 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:42 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:42 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:42 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:42 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:42 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:42 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:42 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:42 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:42 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:43 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:43 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:43 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:43 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:43 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:43 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:43 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:43 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:43 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:43 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:43 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:43 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:43 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:43 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:43 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:43 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:43 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:43 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:43 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:43 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:43 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:44 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:44 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:44 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:44 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:44 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:44 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:44 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:44 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:44 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:44 --> Database Driver Class Initialized
DEBUG - 2016-10-26 14:04:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 14:04:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 14:04:44 --> Final output sent to browser
DEBUG - 2016-10-26 14:04:44 --> Total execution time: 4.5536
INFO - 2016-10-26 14:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 14:04:44 --> Controller Class Initialized
DEBUG - 2016-10-26 14:04:44 --> Index MX_Controller Initialized
INFO - 2016-10-26 14:04:44 --> Model Class Initialized
INFO - 2016-10-26 14:04:44 --> Model Class Initialized
ERROR - 2016-10-26 14:04:44 --> Unable to delete cache file for admin/index/detail_anggota/fe5dbbcea5ce7e2988b8c69bcfdfde8904aabc1f
DEBUG - 2016-10-26 14:04:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 14:04:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 14:04:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
INFO - 2016-10-26 14:04:45 --> Database Driver Class Initialized
DEBUG - 2016-10-26 14:04:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_pinjaman.php
INFO - 2016-10-26 14:04:45 --> Database Driver Class Initialized
DEBUG - 2016-10-26 14:04:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_tabungan.php
DEBUG - 2016-10-26 14:04:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/profile_anggota.php
DEBUG - 2016-10-26 14:04:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 14:04:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 14:04:45 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:45 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:45 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:45 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:45 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:45 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:45 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:45 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:45 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:45 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:45 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:45 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:45 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:45 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:46 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:46 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:46 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:46 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:46 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:46 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:46 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:46 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:46 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:46 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:46 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:46 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:46 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:46 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:46 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:46 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:46 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:46 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:46 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:46 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:46 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:46 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:47 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:47 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:47 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:47 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:47 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:47 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:47 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:47 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:47 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:47 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:47 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:47 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:47 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:47 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:47 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:47 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:47 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:47 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:47 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:47 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:48 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:48 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:48 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:48 --> Database Driver Class Initialized
DEBUG - 2016-10-26 14:04:48 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 14:04:48 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 14:04:48 --> Final output sent to browser
DEBUG - 2016-10-26 14:04:48 --> Total execution time: 8.0895
INFO - 2016-10-26 14:04:48 --> Config Class Initialized
INFO - 2016-10-26 14:04:48 --> Hooks Class Initialized
DEBUG - 2016-10-26 14:04:48 --> UTF-8 Support Enabled
INFO - 2016-10-26 14:04:48 --> Utf8 Class Initialized
INFO - 2016-10-26 14:04:48 --> URI Class Initialized
INFO - 2016-10-26 14:04:48 --> Router Class Initialized
INFO - 2016-10-26 14:04:49 --> Output Class Initialized
INFO - 2016-10-26 14:04:49 --> Security Class Initialized
DEBUG - 2016-10-26 14:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 14:04:49 --> Input Class Initialized
INFO - 2016-10-26 14:04:49 --> Language Class Initialized
INFO - 2016-10-26 14:04:49 --> Language Class Initialized
INFO - 2016-10-26 14:04:49 --> Config Class Initialized
INFO - 2016-10-26 14:04:49 --> Loader Class Initialized
INFO - 2016-10-26 14:04:49 --> Helper loaded: url_helper
INFO - 2016-10-26 14:04:50 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 14:04:50 --> Controller Class Initialized
DEBUG - 2016-10-26 14:04:50 --> Index MX_Controller Initialized
INFO - 2016-10-26 14:04:50 --> Model Class Initialized
INFO - 2016-10-26 14:04:50 --> Model Class Initialized
ERROR - 2016-10-26 14:04:50 --> Unable to delete cache file for admin/index/detail_anggota/images/picture.jpg
DEBUG - 2016-10-26 14:04:50 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 14:04:50 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 14:04:50 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
ERROR - 2016-10-26 14:04:50 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 16
ERROR - 2016-10-26 14:04:50 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 19
ERROR - 2016-10-26 14:04:51 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 22
ERROR - 2016-10-26 14:04:51 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 38
INFO - 2016-10-26 14:04:51 --> Database Driver Class Initialized
DEBUG - 2016-10-26 14:04:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_pinjaman.php
ERROR - 2016-10-26 14:04:51 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 41
INFO - 2016-10-26 14:04:51 --> Database Driver Class Initialized
DEBUG - 2016-10-26 14:04:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_tabungan.php
DEBUG - 2016-10-26 14:04:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/profile_anggota.php
DEBUG - 2016-10-26 14:04:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 14:04:52 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 14:04:52 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:52 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:52 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:52 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:52 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:52 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:52 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:52 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:53 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:53 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:53 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:53 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:53 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:53 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:54 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:54 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:54 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:54 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:54 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:54 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:54 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:54 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:54 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:54 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:54 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:54 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:55 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:55 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:55 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:55 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:55 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:55 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:55 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:55 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:55 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:55 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:55 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:55 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:55 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:56 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:56 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:56 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:56 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:56 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:56 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:56 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:56 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:56 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:56 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:56 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:56 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:56 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:56 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:56 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:57 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:57 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:57 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:57 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:57 --> Database Driver Class Initialized
INFO - 2016-10-26 14:04:57 --> Database Driver Class Initialized
DEBUG - 2016-10-26 14:04:57 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 14:04:57 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 14:04:57 --> Final output sent to browser
DEBUG - 2016-10-26 14:04:57 --> Total execution time: 8.9200
INFO - 2016-10-26 14:05:02 --> Config Class Initialized
INFO - 2016-10-26 14:05:02 --> Hooks Class Initialized
DEBUG - 2016-10-26 14:05:02 --> UTF-8 Support Enabled
INFO - 2016-10-26 14:05:02 --> Utf8 Class Initialized
INFO - 2016-10-26 14:05:02 --> URI Class Initialized
INFO - 2016-10-26 14:05:02 --> Router Class Initialized
INFO - 2016-10-26 14:05:02 --> Output Class Initialized
INFO - 2016-10-26 14:05:02 --> Security Class Initialized
DEBUG - 2016-10-26 14:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 14:05:02 --> Input Class Initialized
INFO - 2016-10-26 14:05:02 --> Language Class Initialized
INFO - 2016-10-26 14:05:02 --> Language Class Initialized
INFO - 2016-10-26 14:05:03 --> Config Class Initialized
INFO - 2016-10-26 14:05:03 --> Loader Class Initialized
INFO - 2016-10-26 14:05:03 --> Helper loaded: url_helper
INFO - 2016-10-26 14:05:03 --> Database Driver Class Initialized
INFO - 2016-10-26 14:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 14:05:03 --> Controller Class Initialized
DEBUG - 2016-10-26 14:05:03 --> Index MX_Controller Initialized
INFO - 2016-10-26 14:05:03 --> Model Class Initialized
INFO - 2016-10-26 14:05:03 --> Model Class Initialized
ERROR - 2016-10-26 14:05:03 --> Unable to delete cache file for admin/index/getRaportAngsuran/af3e133428b9e25c55bc59fe534248e6a0c0f17b
DEBUG - 2016-10-26 14:05:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/raport_angsuran.php
INFO - 2016-10-26 14:05:03 --> Final output sent to browser
DEBUG - 2016-10-26 14:05:03 --> Total execution time: 1.3132
INFO - 2016-10-26 14:08:28 --> Config Class Initialized
INFO - 2016-10-26 14:08:28 --> Hooks Class Initialized
DEBUG - 2016-10-26 14:08:28 --> UTF-8 Support Enabled
INFO - 2016-10-26 14:08:28 --> Utf8 Class Initialized
INFO - 2016-10-26 14:08:28 --> URI Class Initialized
INFO - 2016-10-26 14:08:28 --> Router Class Initialized
INFO - 2016-10-26 14:08:28 --> Output Class Initialized
INFO - 2016-10-26 14:08:28 --> Security Class Initialized
DEBUG - 2016-10-26 14:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 14:08:28 --> Input Class Initialized
INFO - 2016-10-26 14:08:29 --> Language Class Initialized
INFO - 2016-10-26 14:08:29 --> Language Class Initialized
INFO - 2016-10-26 14:08:29 --> Config Class Initialized
INFO - 2016-10-26 14:08:29 --> Loader Class Initialized
INFO - 2016-10-26 14:08:29 --> Helper loaded: url_helper
INFO - 2016-10-26 14:08:29 --> Database Driver Class Initialized
INFO - 2016-10-26 14:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 14:08:29 --> Controller Class Initialized
DEBUG - 2016-10-26 14:08:29 --> Index MX_Controller Initialized
INFO - 2016-10-26 14:08:29 --> Model Class Initialized
INFO - 2016-10-26 14:08:29 --> Model Class Initialized
ERROR - 2016-10-26 14:08:29 --> Unable to delete cache file for admin/index/getRaportAngsuran/761f22b2c1593d0bb87e0b606f990ba4974706de
ERROR - 2016-10-26 14:08:29 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\laporan\raport_angsuran.php 21
DEBUG - 2016-10-26 14:08:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/raport_angsuran.php
INFO - 2016-10-26 14:08:29 --> Final output sent to browser
DEBUG - 2016-10-26 14:08:29 --> Total execution time: 1.4471
INFO - 2016-10-26 14:08:39 --> Config Class Initialized
INFO - 2016-10-26 14:08:39 --> Hooks Class Initialized
DEBUG - 2016-10-26 14:08:39 --> UTF-8 Support Enabled
INFO - 2016-10-26 14:08:39 --> Utf8 Class Initialized
INFO - 2016-10-26 14:08:39 --> URI Class Initialized
INFO - 2016-10-26 14:08:39 --> Router Class Initialized
INFO - 2016-10-26 14:08:40 --> Output Class Initialized
INFO - 2016-10-26 14:08:40 --> Security Class Initialized
DEBUG - 2016-10-26 14:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 14:08:40 --> Input Class Initialized
INFO - 2016-10-26 14:08:40 --> Language Class Initialized
INFO - 2016-10-26 14:08:40 --> Language Class Initialized
INFO - 2016-10-26 14:08:40 --> Config Class Initialized
INFO - 2016-10-26 14:08:40 --> Loader Class Initialized
INFO - 2016-10-26 14:08:40 --> Helper loaded: url_helper
INFO - 2016-10-26 14:08:40 --> Database Driver Class Initialized
INFO - 2016-10-26 14:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 14:08:40 --> Controller Class Initialized
DEBUG - 2016-10-26 14:08:40 --> Index MX_Controller Initialized
INFO - 2016-10-26 14:08:40 --> Model Class Initialized
INFO - 2016-10-26 14:08:40 --> Model Class Initialized
ERROR - 2016-10-26 14:08:40 --> Unable to delete cache file for admin/index/getRaportAngsuran/761f22b2c1593d0bb87e0b606f990ba4974706de
ERROR - 2016-10-26 14:08:40 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\laporan\raport_angsuran.php 21
DEBUG - 2016-10-26 14:08:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/raport_angsuran.php
INFO - 2016-10-26 14:08:41 --> Final output sent to browser
DEBUG - 2016-10-26 14:08:41 --> Total execution time: 1.4243
INFO - 2016-10-26 14:09:34 --> Config Class Initialized
INFO - 2016-10-26 14:09:34 --> Hooks Class Initialized
DEBUG - 2016-10-26 14:09:34 --> UTF-8 Support Enabled
INFO - 2016-10-26 14:09:34 --> Utf8 Class Initialized
INFO - 2016-10-26 14:09:34 --> URI Class Initialized
INFO - 2016-10-26 14:09:34 --> Router Class Initialized
INFO - 2016-10-26 14:09:34 --> Output Class Initialized
INFO - 2016-10-26 14:09:34 --> Security Class Initialized
DEBUG - 2016-10-26 14:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 14:09:35 --> Input Class Initialized
INFO - 2016-10-26 14:09:35 --> Language Class Initialized
INFO - 2016-10-26 14:09:35 --> Language Class Initialized
INFO - 2016-10-26 14:09:35 --> Config Class Initialized
INFO - 2016-10-26 14:09:35 --> Loader Class Initialized
INFO - 2016-10-26 14:09:35 --> Helper loaded: url_helper
INFO - 2016-10-26 14:09:35 --> Database Driver Class Initialized
INFO - 2016-10-26 14:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 14:09:35 --> Controller Class Initialized
DEBUG - 2016-10-26 14:09:35 --> Index MX_Controller Initialized
INFO - 2016-10-26 14:09:35 --> Model Class Initialized
INFO - 2016-10-26 14:09:35 --> Model Class Initialized
ERROR - 2016-10-26 14:09:35 --> Unable to delete cache file for admin/index/getRaportAngsuran/761f22b2c1593d0bb87e0b606f990ba4974706de
ERROR - 2016-10-26 14:09:35 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\laporan\raport_angsuran.php 21
DEBUG - 2016-10-26 14:09:35 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/raport_angsuran.php
INFO - 2016-10-26 14:09:35 --> Final output sent to browser
DEBUG - 2016-10-26 14:09:35 --> Total execution time: 1.5367
INFO - 2016-10-26 14:10:34 --> Config Class Initialized
INFO - 2016-10-26 14:10:34 --> Hooks Class Initialized
DEBUG - 2016-10-26 14:10:34 --> UTF-8 Support Enabled
INFO - 2016-10-26 14:10:34 --> Utf8 Class Initialized
INFO - 2016-10-26 14:10:34 --> URI Class Initialized
INFO - 2016-10-26 14:10:35 --> Router Class Initialized
INFO - 2016-10-26 14:10:35 --> Output Class Initialized
INFO - 2016-10-26 14:10:35 --> Security Class Initialized
DEBUG - 2016-10-26 14:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 14:10:35 --> Input Class Initialized
INFO - 2016-10-26 14:10:35 --> Language Class Initialized
INFO - 2016-10-26 14:10:35 --> Language Class Initialized
INFO - 2016-10-26 14:10:35 --> Config Class Initialized
INFO - 2016-10-26 14:10:35 --> Loader Class Initialized
INFO - 2016-10-26 14:10:35 --> Helper loaded: url_helper
INFO - 2016-10-26 14:10:35 --> Database Driver Class Initialized
INFO - 2016-10-26 14:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 14:10:35 --> Controller Class Initialized
DEBUG - 2016-10-26 14:10:35 --> Index MX_Controller Initialized
INFO - 2016-10-26 14:10:35 --> Model Class Initialized
INFO - 2016-10-26 14:10:35 --> Model Class Initialized
ERROR - 2016-10-26 14:10:35 --> Unable to delete cache file for admin/index/getRaportAngsuran/761f22b2c1593d0bb87e0b606f990ba4974706de
DEBUG - 2016-10-26 14:10:35 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/raport_angsuran.php
INFO - 2016-10-26 14:10:35 --> Final output sent to browser
DEBUG - 2016-10-26 14:10:35 --> Total execution time: 1.6115
INFO - 2016-10-26 14:11:45 --> Config Class Initialized
INFO - 2016-10-26 14:11:45 --> Hooks Class Initialized
DEBUG - 2016-10-26 14:11:45 --> UTF-8 Support Enabled
INFO - 2016-10-26 14:11:45 --> Utf8 Class Initialized
INFO - 2016-10-26 14:11:45 --> URI Class Initialized
INFO - 2016-10-26 14:11:45 --> Router Class Initialized
INFO - 2016-10-26 14:11:46 --> Output Class Initialized
INFO - 2016-10-26 14:11:46 --> Security Class Initialized
DEBUG - 2016-10-26 14:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 14:11:46 --> Input Class Initialized
INFO - 2016-10-26 14:11:46 --> Language Class Initialized
INFO - 2016-10-26 14:11:46 --> Language Class Initialized
INFO - 2016-10-26 14:11:46 --> Config Class Initialized
INFO - 2016-10-26 14:11:46 --> Loader Class Initialized
INFO - 2016-10-26 14:11:46 --> Helper loaded: url_helper
INFO - 2016-10-26 14:11:46 --> Database Driver Class Initialized
INFO - 2016-10-26 14:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 14:11:46 --> Controller Class Initialized
DEBUG - 2016-10-26 14:11:46 --> Index MX_Controller Initialized
INFO - 2016-10-26 14:11:46 --> Model Class Initialized
INFO - 2016-10-26 14:11:46 --> Model Class Initialized
ERROR - 2016-10-26 14:11:46 --> Unable to delete cache file for admin/index/getRaportAngsuran/761f22b2c1593d0bb87e0b606f990ba4974706de
DEBUG - 2016-10-26 14:11:46 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/raport_angsuran.php
INFO - 2016-10-26 14:11:46 --> Final output sent to browser
DEBUG - 2016-10-26 14:11:47 --> Total execution time: 1.6794
INFO - 2016-10-26 14:11:50 --> Config Class Initialized
INFO - 2016-10-26 14:11:50 --> Hooks Class Initialized
DEBUG - 2016-10-26 14:11:50 --> UTF-8 Support Enabled
INFO - 2016-10-26 14:11:50 --> Utf8 Class Initialized
INFO - 2016-10-26 14:11:50 --> URI Class Initialized
INFO - 2016-10-26 14:11:50 --> Router Class Initialized
INFO - 2016-10-26 14:11:50 --> Output Class Initialized
INFO - 2016-10-26 14:11:50 --> Security Class Initialized
DEBUG - 2016-10-26 14:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 14:11:51 --> Input Class Initialized
INFO - 2016-10-26 14:11:51 --> Language Class Initialized
INFO - 2016-10-26 14:11:51 --> Language Class Initialized
INFO - 2016-10-26 14:11:51 --> Config Class Initialized
INFO - 2016-10-26 14:11:51 --> Loader Class Initialized
INFO - 2016-10-26 14:11:51 --> Helper loaded: url_helper
INFO - 2016-10-26 14:11:51 --> Database Driver Class Initialized
INFO - 2016-10-26 14:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 14:11:51 --> Controller Class Initialized
DEBUG - 2016-10-26 14:11:51 --> Index MX_Controller Initialized
INFO - 2016-10-26 14:11:51 --> Model Class Initialized
INFO - 2016-10-26 14:11:51 --> Model Class Initialized
ERROR - 2016-10-26 14:11:51 --> Unable to delete cache file for admin/index/getRaportAngsuran/af3e133428b9e25c55bc59fe534248e6a0c0f17b
DEBUG - 2016-10-26 14:11:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/raport_angsuran.php
INFO - 2016-10-26 14:11:51 --> Final output sent to browser
DEBUG - 2016-10-26 14:11:51 --> Total execution time: 1.6828
INFO - 2016-10-26 14:12:02 --> Config Class Initialized
INFO - 2016-10-26 14:12:02 --> Hooks Class Initialized
DEBUG - 2016-10-26 14:12:02 --> UTF-8 Support Enabled
INFO - 2016-10-26 14:12:02 --> Config Class Initialized
INFO - 2016-10-26 14:12:02 --> Utf8 Class Initialized
INFO - 2016-10-26 14:12:02 --> Hooks Class Initialized
INFO - 2016-10-26 14:12:02 --> URI Class Initialized
DEBUG - 2016-10-26 14:12:02 --> UTF-8 Support Enabled
INFO - 2016-10-26 14:12:02 --> Utf8 Class Initialized
INFO - 2016-10-26 14:12:02 --> URI Class Initialized
INFO - 2016-10-26 14:12:02 --> Router Class Initialized
INFO - 2016-10-26 14:12:02 --> Output Class Initialized
INFO - 2016-10-26 14:12:02 --> Security Class Initialized
INFO - 2016-10-26 14:12:02 --> Router Class Initialized
DEBUG - 2016-10-26 14:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 14:12:02 --> Input Class Initialized
INFO - 2016-10-26 14:12:02 --> Language Class Initialized
INFO - 2016-10-26 14:12:02 --> Output Class Initialized
INFO - 2016-10-26 14:12:02 --> Language Class Initialized
INFO - 2016-10-26 14:12:03 --> Security Class Initialized
INFO - 2016-10-26 14:12:03 --> Config Class Initialized
INFO - 2016-10-26 14:12:03 --> Loader Class Initialized
INFO - 2016-10-26 14:12:03 --> Helper loaded: url_helper
INFO - 2016-10-26 14:12:03 --> Database Driver Class Initialized
DEBUG - 2016-10-26 14:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 14:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 14:12:03 --> Controller Class Initialized
INFO - 2016-10-26 14:12:03 --> Input Class Initialized
DEBUG - 2016-10-26 14:12:03 --> Index MX_Controller Initialized
INFO - 2016-10-26 14:12:03 --> Model Class Initialized
INFO - 2016-10-26 14:12:03 --> Language Class Initialized
INFO - 2016-10-26 14:12:03 --> Model Class Initialized
INFO - 2016-10-26 14:12:03 --> Language Class Initialized
ERROR - 2016-10-26 14:12:03 --> Unable to delete cache file for admin/index
DEBUG - 2016-10-26 14:12:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 14:12:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 14:12:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-26 14:12:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/dashboard.php
DEBUG - 2016-10-26 14:12:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 14:12:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 14:12:04 --> Config Class Initialized
INFO - 2016-10-26 14:12:04 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:04 --> Loader Class Initialized
INFO - 2016-10-26 14:12:04 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:04 --> Helper loaded: url_helper
INFO - 2016-10-26 14:12:04 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:04 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:04 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:04 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:04 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:04 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:04 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:04 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:04 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:04 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:04 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:04 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:04 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:04 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:04 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:04 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:05 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:05 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:05 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:05 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:05 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:05 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:05 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:05 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:05 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:05 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:05 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:05 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:05 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:05 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:05 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:05 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:05 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:05 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:06 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:06 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:06 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:06 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:06 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:06 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:06 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:06 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:06 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:06 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:06 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:06 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:06 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:06 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:06 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:06 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:06 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:06 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:07 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:07 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:07 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:07 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:07 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:07 --> Database Driver Class Initialized
DEBUG - 2016-10-26 14:12:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 14:12:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 14:12:07 --> Final output sent to browser
DEBUG - 2016-10-26 14:12:07 --> Total execution time: 5.1800
INFO - 2016-10-26 14:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 14:12:07 --> Controller Class Initialized
DEBUG - 2016-10-26 14:12:07 --> Index MX_Controller Initialized
INFO - 2016-10-26 14:12:08 --> Model Class Initialized
INFO - 2016-10-26 14:12:08 --> Model Class Initialized
ERROR - 2016-10-26 14:12:08 --> Unable to delete cache file for admin/index
DEBUG - 2016-10-26 14:12:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-26 14:12:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-26 14:12:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-26 14:12:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/dashboard.php
DEBUG - 2016-10-26 14:12:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-26 14:12:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-26 14:12:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:09 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:10 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:10 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:11 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:11 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:11 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:11 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:11 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:11 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:11 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:12 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:12 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:12 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:12 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:12 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:12 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:12 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:12 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:13 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:13 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:13 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:13 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:13 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:13 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:13 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:14 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:14 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:14 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:14 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:14 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:14 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:14 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:14 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:14 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:14 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:14 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:15 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:15 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:15 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:15 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:15 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:15 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:15 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:15 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:15 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:15 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:15 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:15 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:15 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:15 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:15 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:15 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:15 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:16 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:16 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:16 --> Database Driver Class Initialized
INFO - 2016-10-26 14:12:16 --> Database Driver Class Initialized
DEBUG - 2016-10-26 14:12:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-26 14:12:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-26 14:12:16 --> Final output sent to browser
DEBUG - 2016-10-26 14:12:16 --> Total execution time: 14.2031
