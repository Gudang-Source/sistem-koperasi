<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-10-09 02:37:12 --> Config Class Initialized
INFO - 2016-10-09 02:37:12 --> Hooks Class Initialized
DEBUG - 2016-10-09 02:37:12 --> UTF-8 Support Enabled
INFO - 2016-10-09 02:37:13 --> Utf8 Class Initialized
INFO - 2016-10-09 02:37:13 --> URI Class Initialized
INFO - 2016-10-09 02:37:13 --> Router Class Initialized
INFO - 2016-10-09 02:37:13 --> Output Class Initialized
INFO - 2016-10-09 02:37:13 --> Security Class Initialized
DEBUG - 2016-10-09 02:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 02:37:13 --> Input Class Initialized
INFO - 2016-10-09 02:37:13 --> Language Class Initialized
INFO - 2016-10-09 02:37:13 --> Language Class Initialized
INFO - 2016-10-09 02:37:13 --> Config Class Initialized
INFO - 2016-10-09 02:37:13 --> Loader Class Initialized
INFO - 2016-10-09 02:37:13 --> Helper loaded: url_helper
INFO - 2016-10-09 02:37:13 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 02:37:13 --> Controller Class Initialized
DEBUG - 2016-10-09 02:37:13 --> Index MX_Controller Initialized
INFO - 2016-10-09 02:37:13 --> Model Class Initialized
INFO - 2016-10-09 02:37:13 --> Model Class Initialized
ERROR - 2016-10-09 02:37:13 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-09 02:37:13 --> Anggota MX_Controller Initialized
INFO - 2016-10-09 02:37:13 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:13 --> Final output sent to browser
DEBUG - 2016-10-09 02:37:13 --> Total execution time: 0.6094
INFO - 2016-10-09 02:37:13 --> Config Class Initialized
INFO - 2016-10-09 02:37:13 --> Hooks Class Initialized
DEBUG - 2016-10-09 02:37:13 --> UTF-8 Support Enabled
INFO - 2016-10-09 02:37:13 --> Utf8 Class Initialized
INFO - 2016-10-09 02:37:13 --> URI Class Initialized
INFO - 2016-10-09 02:37:13 --> Router Class Initialized
INFO - 2016-10-09 02:37:13 --> Output Class Initialized
INFO - 2016-10-09 02:37:13 --> Security Class Initialized
DEBUG - 2016-10-09 02:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 02:37:13 --> Input Class Initialized
INFO - 2016-10-09 02:37:13 --> Language Class Initialized
INFO - 2016-10-09 02:37:13 --> Language Class Initialized
INFO - 2016-10-09 02:37:13 --> Config Class Initialized
INFO - 2016-10-09 02:37:13 --> Loader Class Initialized
INFO - 2016-10-09 02:37:13 --> Helper loaded: url_helper
INFO - 2016-10-09 02:37:13 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 02:37:13 --> Controller Class Initialized
DEBUG - 2016-10-09 02:37:13 --> login MX_Controller Initialized
INFO - 2016-10-09 02:37:13 --> Model Class Initialized
INFO - 2016-10-09 02:37:13 --> Model Class Initialized
DEBUG - 2016-10-09 02:37:14 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/login.php
INFO - 2016-10-09 02:37:14 --> Final output sent to browser
DEBUG - 2016-10-09 02:37:14 --> Total execution time: 0.4955
INFO - 2016-10-09 02:37:18 --> Config Class Initialized
INFO - 2016-10-09 02:37:18 --> Hooks Class Initialized
DEBUG - 2016-10-09 02:37:19 --> UTF-8 Support Enabled
INFO - 2016-10-09 02:37:19 --> Utf8 Class Initialized
INFO - 2016-10-09 02:37:19 --> URI Class Initialized
INFO - 2016-10-09 02:37:19 --> Router Class Initialized
INFO - 2016-10-09 02:37:19 --> Output Class Initialized
INFO - 2016-10-09 02:37:19 --> Security Class Initialized
DEBUG - 2016-10-09 02:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 02:37:19 --> Input Class Initialized
INFO - 2016-10-09 02:37:19 --> Language Class Initialized
INFO - 2016-10-09 02:37:19 --> Language Class Initialized
INFO - 2016-10-09 02:37:19 --> Config Class Initialized
INFO - 2016-10-09 02:37:19 --> Loader Class Initialized
INFO - 2016-10-09 02:37:19 --> Helper loaded: url_helper
INFO - 2016-10-09 02:37:19 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 02:37:19 --> Controller Class Initialized
DEBUG - 2016-10-09 02:37:19 --> Index MX_Controller Initialized
INFO - 2016-10-09 02:37:19 --> Model Class Initialized
INFO - 2016-10-09 02:37:19 --> Model Class Initialized
ERROR - 2016-10-09 02:37:19 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-09 02:37:19 --> Anggota MX_Controller Initialized
INFO - 2016-10-09 02:37:19 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:19 --> Final output sent to browser
DEBUG - 2016-10-09 02:37:19 --> Total execution time: 0.5829
INFO - 2016-10-09 02:37:19 --> Config Class Initialized
INFO - 2016-10-09 02:37:19 --> Hooks Class Initialized
DEBUG - 2016-10-09 02:37:19 --> UTF-8 Support Enabled
INFO - 2016-10-09 02:37:19 --> Utf8 Class Initialized
INFO - 2016-10-09 02:37:19 --> URI Class Initialized
INFO - 2016-10-09 02:37:19 --> Router Class Initialized
INFO - 2016-10-09 02:37:19 --> Output Class Initialized
INFO - 2016-10-09 02:37:19 --> Security Class Initialized
DEBUG - 2016-10-09 02:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 02:37:19 --> Input Class Initialized
INFO - 2016-10-09 02:37:19 --> Language Class Initialized
INFO - 2016-10-09 02:37:19 --> Language Class Initialized
INFO - 2016-10-09 02:37:19 --> Config Class Initialized
INFO - 2016-10-09 02:37:19 --> Loader Class Initialized
INFO - 2016-10-09 02:37:19 --> Helper loaded: url_helper
INFO - 2016-10-09 02:37:19 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 02:37:19 --> Controller Class Initialized
DEBUG - 2016-10-09 02:37:19 --> login MX_Controller Initialized
INFO - 2016-10-09 02:37:19 --> Model Class Initialized
INFO - 2016-10-09 02:37:19 --> Model Class Initialized
DEBUG - 2016-10-09 02:37:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/login.php
INFO - 2016-10-09 02:37:19 --> Final output sent to browser
DEBUG - 2016-10-09 02:37:20 --> Total execution time: 0.4087
INFO - 2016-10-09 02:37:29 --> Config Class Initialized
INFO - 2016-10-09 02:37:29 --> Hooks Class Initialized
DEBUG - 2016-10-09 02:37:29 --> UTF-8 Support Enabled
INFO - 2016-10-09 02:37:29 --> Utf8 Class Initialized
INFO - 2016-10-09 02:37:30 --> URI Class Initialized
INFO - 2016-10-09 02:37:30 --> Router Class Initialized
INFO - 2016-10-09 02:37:30 --> Output Class Initialized
INFO - 2016-10-09 02:37:30 --> Security Class Initialized
DEBUG - 2016-10-09 02:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 02:37:30 --> Input Class Initialized
INFO - 2016-10-09 02:37:30 --> Language Class Initialized
INFO - 2016-10-09 02:37:30 --> Language Class Initialized
INFO - 2016-10-09 02:37:30 --> Config Class Initialized
INFO - 2016-10-09 02:37:30 --> Loader Class Initialized
INFO - 2016-10-09 02:37:30 --> Helper loaded: url_helper
INFO - 2016-10-09 02:37:30 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 02:37:30 --> Controller Class Initialized
DEBUG - 2016-10-09 02:37:30 --> Index MX_Controller Initialized
INFO - 2016-10-09 02:37:30 --> Model Class Initialized
INFO - 2016-10-09 02:37:30 --> Model Class Initialized
ERROR - 2016-10-09 02:37:30 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-09 02:37:30 --> Anggota MX_Controller Initialized
INFO - 2016-10-09 02:37:30 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:30 --> Final output sent to browser
DEBUG - 2016-10-09 02:37:30 --> Total execution time: 0.5601
INFO - 2016-10-09 02:37:30 --> Config Class Initialized
INFO - 2016-10-09 02:37:30 --> Hooks Class Initialized
DEBUG - 2016-10-09 02:37:30 --> UTF-8 Support Enabled
INFO - 2016-10-09 02:37:30 --> Utf8 Class Initialized
INFO - 2016-10-09 02:37:30 --> URI Class Initialized
INFO - 2016-10-09 02:37:30 --> Router Class Initialized
INFO - 2016-10-09 02:37:30 --> Output Class Initialized
INFO - 2016-10-09 02:37:30 --> Security Class Initialized
DEBUG - 2016-10-09 02:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 02:37:30 --> Input Class Initialized
INFO - 2016-10-09 02:37:30 --> Language Class Initialized
INFO - 2016-10-09 02:37:30 --> Language Class Initialized
INFO - 2016-10-09 02:37:30 --> Config Class Initialized
INFO - 2016-10-09 02:37:30 --> Loader Class Initialized
INFO - 2016-10-09 02:37:30 --> Helper loaded: url_helper
INFO - 2016-10-09 02:37:30 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 02:37:30 --> Controller Class Initialized
DEBUG - 2016-10-09 02:37:30 --> login MX_Controller Initialized
INFO - 2016-10-09 02:37:30 --> Model Class Initialized
INFO - 2016-10-09 02:37:30 --> Model Class Initialized
DEBUG - 2016-10-09 02:37:30 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/login.php
INFO - 2016-10-09 02:37:30 --> Final output sent to browser
DEBUG - 2016-10-09 02:37:30 --> Total execution time: 0.4799
INFO - 2016-10-09 02:37:32 --> Config Class Initialized
INFO - 2016-10-09 02:37:32 --> Hooks Class Initialized
DEBUG - 2016-10-09 02:37:32 --> UTF-8 Support Enabled
INFO - 2016-10-09 02:37:32 --> Utf8 Class Initialized
INFO - 2016-10-09 02:37:32 --> URI Class Initialized
INFO - 2016-10-09 02:37:32 --> Router Class Initialized
INFO - 2016-10-09 02:37:32 --> Output Class Initialized
INFO - 2016-10-09 02:37:32 --> Security Class Initialized
DEBUG - 2016-10-09 02:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 02:37:32 --> Input Class Initialized
INFO - 2016-10-09 02:37:32 --> Language Class Initialized
INFO - 2016-10-09 02:37:32 --> Language Class Initialized
INFO - 2016-10-09 02:37:32 --> Config Class Initialized
INFO - 2016-10-09 02:37:32 --> Loader Class Initialized
INFO - 2016-10-09 02:37:32 --> Helper loaded: url_helper
INFO - 2016-10-09 02:37:32 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 02:37:32 --> Controller Class Initialized
DEBUG - 2016-10-09 02:37:32 --> Index MX_Controller Initialized
INFO - 2016-10-09 02:37:32 --> Model Class Initialized
INFO - 2016-10-09 02:37:32 --> Model Class Initialized
ERROR - 2016-10-09 02:37:32 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-10-09 02:37:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 02:37:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 02:37:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 02:37:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-10-09 02:37:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 02:37:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 02:37:33 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:33 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:33 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:33 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:33 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:33 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:33 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:33 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:33 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:33 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:33 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:33 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:33 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:33 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:33 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:33 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:33 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:33 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:33 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:33 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:33 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:33 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:33 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:33 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:33 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:33 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:33 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:33 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:33 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:33 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:33 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:33 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:33 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:33 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:33 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:33 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:34 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:34 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:34 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:34 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:34 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:34 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:34 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:34 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:34 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:34 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:34 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:34 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:34 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:34 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:34 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:34 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:34 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:34 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:34 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:34 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:34 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:34 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:34 --> Database Driver Class Initialized
DEBUG - 2016-10-09 02:37:34 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 02:37:34 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 02:37:34 --> Final output sent to browser
INFO - 2016-10-09 02:37:34 --> Config Class Initialized
DEBUG - 2016-10-09 02:37:34 --> Total execution time: 2.3198
INFO - 2016-10-09 02:37:34 --> Hooks Class Initialized
DEBUG - 2016-10-09 02:37:34 --> UTF-8 Support Enabled
INFO - 2016-10-09 02:37:34 --> Utf8 Class Initialized
INFO - 2016-10-09 02:37:34 --> URI Class Initialized
INFO - 2016-10-09 02:37:34 --> Router Class Initialized
INFO - 2016-10-09 02:37:34 --> Output Class Initialized
INFO - 2016-10-09 02:37:34 --> Security Class Initialized
DEBUG - 2016-10-09 02:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 02:37:35 --> Input Class Initialized
INFO - 2016-10-09 02:37:35 --> Language Class Initialized
INFO - 2016-10-09 02:37:35 --> Language Class Initialized
INFO - 2016-10-09 02:37:35 --> Config Class Initialized
INFO - 2016-10-09 02:37:35 --> Loader Class Initialized
INFO - 2016-10-09 02:37:35 --> Helper loaded: url_helper
INFO - 2016-10-09 02:37:35 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 02:37:35 --> Controller Class Initialized
DEBUG - 2016-10-09 02:37:35 --> login MX_Controller Initialized
INFO - 2016-10-09 02:37:35 --> Model Class Initialized
INFO - 2016-10-09 02:37:35 --> Model Class Initialized
DEBUG - 2016-10-09 02:37:35 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/login.php
INFO - 2016-10-09 02:37:35 --> Final output sent to browser
DEBUG - 2016-10-09 02:37:35 --> Total execution time: 0.5840
INFO - 2016-10-09 02:37:42 --> Config Class Initialized
INFO - 2016-10-09 02:37:42 --> Hooks Class Initialized
DEBUG - 2016-10-09 02:37:42 --> UTF-8 Support Enabled
INFO - 2016-10-09 02:37:42 --> Utf8 Class Initialized
INFO - 2016-10-09 02:37:42 --> URI Class Initialized
INFO - 2016-10-09 02:37:42 --> Router Class Initialized
INFO - 2016-10-09 02:37:42 --> Output Class Initialized
INFO - 2016-10-09 02:37:42 --> Security Class Initialized
DEBUG - 2016-10-09 02:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 02:37:42 --> Input Class Initialized
INFO - 2016-10-09 02:37:42 --> Language Class Initialized
INFO - 2016-10-09 02:37:42 --> Language Class Initialized
INFO - 2016-10-09 02:37:42 --> Config Class Initialized
INFO - 2016-10-09 02:37:42 --> Loader Class Initialized
INFO - 2016-10-09 02:37:42 --> Helper loaded: url_helper
INFO - 2016-10-09 02:37:42 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 02:37:42 --> Controller Class Initialized
DEBUG - 2016-10-09 02:37:42 --> login MX_Controller Initialized
INFO - 2016-10-09 02:37:42 --> Model Class Initialized
INFO - 2016-10-09 02:37:42 --> Model Class Initialized
INFO - 2016-10-09 02:37:42 --> Final output sent to browser
DEBUG - 2016-10-09 02:37:42 --> Total execution time: 0.4835
INFO - 2016-10-09 02:37:42 --> Config Class Initialized
INFO - 2016-10-09 02:37:42 --> Hooks Class Initialized
DEBUG - 2016-10-09 02:37:42 --> UTF-8 Support Enabled
INFO - 2016-10-09 02:37:42 --> Utf8 Class Initialized
INFO - 2016-10-09 02:37:42 --> URI Class Initialized
INFO - 2016-10-09 02:37:42 --> Router Class Initialized
INFO - 2016-10-09 02:37:43 --> Output Class Initialized
INFO - 2016-10-09 02:37:43 --> Security Class Initialized
DEBUG - 2016-10-09 02:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 02:37:43 --> Input Class Initialized
INFO - 2016-10-09 02:37:43 --> Language Class Initialized
INFO - 2016-10-09 02:37:43 --> Language Class Initialized
INFO - 2016-10-09 02:37:43 --> Config Class Initialized
INFO - 2016-10-09 02:37:43 --> Loader Class Initialized
INFO - 2016-10-09 02:37:43 --> Helper loaded: url_helper
INFO - 2016-10-09 02:37:43 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 02:37:43 --> Controller Class Initialized
DEBUG - 2016-10-09 02:37:43 --> Index MX_Controller Initialized
INFO - 2016-10-09 02:37:43 --> Model Class Initialized
INFO - 2016-10-09 02:37:43 --> Model Class Initialized
ERROR - 2016-10-09 02:37:43 --> Unable to delete cache file for admin/index
DEBUG - 2016-10-09 02:37:43 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 02:37:43 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 02:37:43 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 02:37:43 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/dashboard.php
DEBUG - 2016-10-09 02:37:43 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 02:37:43 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 02:37:43 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:43 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:43 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:43 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:43 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:43 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:43 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:43 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:43 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:43 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:43 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:43 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:43 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:44 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:44 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:44 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:44 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:44 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:44 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:44 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:44 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:44 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:44 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:44 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:44 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:44 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:44 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:44 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:44 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:44 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:44 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:44 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:44 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:44 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:44 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:44 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:44 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:44 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:44 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:44 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:44 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:44 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:44 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:44 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:44 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:44 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:44 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:45 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:45 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:45 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:45 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:45 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:45 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:45 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:45 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:45 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:45 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:45 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:45 --> Database Driver Class Initialized
DEBUG - 2016-10-09 02:37:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 02:37:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 02:37:45 --> Final output sent to browser
DEBUG - 2016-10-09 02:37:45 --> Total execution time: 2.6310
INFO - 2016-10-09 02:37:55 --> Config Class Initialized
INFO - 2016-10-09 02:37:55 --> Hooks Class Initialized
DEBUG - 2016-10-09 02:37:55 --> UTF-8 Support Enabled
INFO - 2016-10-09 02:37:55 --> Utf8 Class Initialized
INFO - 2016-10-09 02:37:55 --> URI Class Initialized
INFO - 2016-10-09 02:37:55 --> Router Class Initialized
INFO - 2016-10-09 02:37:55 --> Output Class Initialized
INFO - 2016-10-09 02:37:55 --> Security Class Initialized
DEBUG - 2016-10-09 02:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 02:37:55 --> Input Class Initialized
INFO - 2016-10-09 02:37:55 --> Language Class Initialized
INFO - 2016-10-09 02:37:55 --> Language Class Initialized
INFO - 2016-10-09 02:37:55 --> Config Class Initialized
INFO - 2016-10-09 02:37:55 --> Loader Class Initialized
INFO - 2016-10-09 02:37:55 --> Helper loaded: url_helper
INFO - 2016-10-09 02:37:55 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 02:37:55 --> Controller Class Initialized
DEBUG - 2016-10-09 02:37:55 --> Index MX_Controller Initialized
INFO - 2016-10-09 02:37:55 --> Model Class Initialized
INFO - 2016-10-09 02:37:55 --> Model Class Initialized
ERROR - 2016-10-09 02:37:55 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-10-09 02:37:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 02:37:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 02:37:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 02:37:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-10-09 02:37:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 02:37:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 02:37:56 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:56 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:56 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:56 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:56 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:56 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:56 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:56 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:56 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:56 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:56 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:56 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:56 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:56 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:56 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:56 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:56 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:56 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:56 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:56 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:56 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:56 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:56 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:56 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:56 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:56 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:56 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:57 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:57 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:57 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:57 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:57 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:57 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:57 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:57 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:57 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:57 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:57 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:57 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:57 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:57 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:57 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:57 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:57 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:57 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:57 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:57 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:57 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:57 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:57 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:57 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:57 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:57 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:57 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:57 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:57 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:57 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:57 --> Database Driver Class Initialized
INFO - 2016-10-09 02:37:57 --> Database Driver Class Initialized
DEBUG - 2016-10-09 02:37:57 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 02:37:58 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 02:37:58 --> Final output sent to browser
DEBUG - 2016-10-09 02:37:58 --> Total execution time: 2.6682
INFO - 2016-10-09 02:38:06 --> Config Class Initialized
INFO - 2016-10-09 02:38:06 --> Hooks Class Initialized
DEBUG - 2016-10-09 02:38:06 --> UTF-8 Support Enabled
INFO - 2016-10-09 02:38:06 --> Utf8 Class Initialized
INFO - 2016-10-09 02:38:06 --> URI Class Initialized
INFO - 2016-10-09 02:38:06 --> Router Class Initialized
INFO - 2016-10-09 02:38:06 --> Output Class Initialized
INFO - 2016-10-09 02:38:06 --> Security Class Initialized
DEBUG - 2016-10-09 02:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 02:38:06 --> Input Class Initialized
INFO - 2016-10-09 02:38:06 --> Language Class Initialized
INFO - 2016-10-09 02:38:06 --> Language Class Initialized
INFO - 2016-10-09 02:38:06 --> Config Class Initialized
INFO - 2016-10-09 02:38:06 --> Loader Class Initialized
INFO - 2016-10-09 02:38:06 --> Helper loaded: url_helper
INFO - 2016-10-09 02:38:06 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 02:38:06 --> Controller Class Initialized
DEBUG - 2016-10-09 02:38:06 --> Index MX_Controller Initialized
INFO - 2016-10-09 02:38:06 --> Model Class Initialized
INFO - 2016-10-09 02:38:06 --> Model Class Initialized
ERROR - 2016-10-09 02:38:06 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-09 02:38:06 --> Anggota MX_Controller Initialized
INFO - 2016-10-09 02:38:06 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:06 --> Final output sent to browser
DEBUG - 2016-10-09 02:38:06 --> Total execution time: 0.6079
INFO - 2016-10-09 02:38:09 --> Config Class Initialized
INFO - 2016-10-09 02:38:09 --> Hooks Class Initialized
DEBUG - 2016-10-09 02:38:09 --> UTF-8 Support Enabled
INFO - 2016-10-09 02:38:09 --> Utf8 Class Initialized
INFO - 2016-10-09 02:38:09 --> URI Class Initialized
INFO - 2016-10-09 02:38:09 --> Router Class Initialized
INFO - 2016-10-09 02:38:09 --> Output Class Initialized
INFO - 2016-10-09 02:38:09 --> Security Class Initialized
DEBUG - 2016-10-09 02:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 02:38:09 --> Input Class Initialized
INFO - 2016-10-09 02:38:09 --> Language Class Initialized
INFO - 2016-10-09 02:38:09 --> Language Class Initialized
INFO - 2016-10-09 02:38:09 --> Config Class Initialized
INFO - 2016-10-09 02:38:09 --> Loader Class Initialized
INFO - 2016-10-09 02:38:09 --> Helper loaded: url_helper
INFO - 2016-10-09 02:38:09 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 02:38:09 --> Controller Class Initialized
DEBUG - 2016-10-09 02:38:09 --> Index MX_Controller Initialized
INFO - 2016-10-09 02:38:09 --> Model Class Initialized
INFO - 2016-10-09 02:38:09 --> Model Class Initialized
ERROR - 2016-10-09 02:38:09 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-10-09 02:38:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 02:38:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 02:38:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 02:38:10 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-10-09 02:38:10 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 02:38:10 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 02:38:10 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:10 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:10 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:10 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:10 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:10 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:10 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:10 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:10 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:10 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:10 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:10 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:10 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:10 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:10 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:10 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:10 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:10 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:10 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:10 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:10 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:10 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:10 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:10 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:10 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:11 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:11 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:11 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:11 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:11 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:11 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:11 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:11 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:11 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:11 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:11 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:11 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:11 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:11 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:11 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:11 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:11 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:11 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:11 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:11 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:11 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:11 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:11 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:11 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:11 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:11 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:12 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:12 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:12 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:12 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:12 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:12 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:12 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:12 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:12 --> Database Driver Class Initialized
DEBUG - 2016-10-09 02:38:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 02:38:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 02:38:12 --> Final output sent to browser
DEBUG - 2016-10-09 02:38:12 --> Total execution time: 3.0177
INFO - 2016-10-09 02:38:19 --> Config Class Initialized
INFO - 2016-10-09 02:38:19 --> Hooks Class Initialized
DEBUG - 2016-10-09 02:38:19 --> UTF-8 Support Enabled
INFO - 2016-10-09 02:38:19 --> Utf8 Class Initialized
INFO - 2016-10-09 02:38:19 --> URI Class Initialized
INFO - 2016-10-09 02:38:19 --> Router Class Initialized
INFO - 2016-10-09 02:38:19 --> Output Class Initialized
INFO - 2016-10-09 02:38:19 --> Security Class Initialized
DEBUG - 2016-10-09 02:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 02:38:19 --> Input Class Initialized
INFO - 2016-10-09 02:38:19 --> Language Class Initialized
INFO - 2016-10-09 02:38:19 --> Language Class Initialized
INFO - 2016-10-09 02:38:19 --> Config Class Initialized
INFO - 2016-10-09 02:38:19 --> Loader Class Initialized
INFO - 2016-10-09 02:38:19 --> Helper loaded: url_helper
INFO - 2016-10-09 02:38:20 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 02:38:20 --> Controller Class Initialized
DEBUG - 2016-10-09 02:38:20 --> Index MX_Controller Initialized
INFO - 2016-10-09 02:38:20 --> Model Class Initialized
INFO - 2016-10-09 02:38:20 --> Model Class Initialized
ERROR - 2016-10-09 02:38:20 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-10-09 02:38:20 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 02:38:20 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 02:38:20 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 02:38:20 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-10-09 02:38:20 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 02:38:20 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 02:38:20 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:20 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:20 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:20 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:20 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:20 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:20 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:20 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:20 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:20 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:20 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:20 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:20 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:20 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:20 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:20 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:20 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:20 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:21 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:21 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:21 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:21 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:21 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:21 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:21 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:21 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:21 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:21 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:21 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:21 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:21 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:21 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:21 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:21 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:21 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:21 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:21 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:21 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:21 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:21 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:21 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:21 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:21 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:21 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:22 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:22 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:22 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:22 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:22 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:22 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:22 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:22 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:22 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:22 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:22 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:22 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:22 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:22 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:22 --> Database Driver Class Initialized
DEBUG - 2016-10-09 02:38:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 02:38:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 02:38:22 --> Final output sent to browser
DEBUG - 2016-10-09 02:38:22 --> Total execution time: 2.9599
INFO - 2016-10-09 02:38:30 --> Config Class Initialized
INFO - 2016-10-09 02:38:30 --> Hooks Class Initialized
DEBUG - 2016-10-09 02:38:30 --> UTF-8 Support Enabled
INFO - 2016-10-09 02:38:30 --> Utf8 Class Initialized
INFO - 2016-10-09 02:38:30 --> URI Class Initialized
INFO - 2016-10-09 02:38:30 --> Router Class Initialized
INFO - 2016-10-09 02:38:30 --> Output Class Initialized
INFO - 2016-10-09 02:38:30 --> Security Class Initialized
DEBUG - 2016-10-09 02:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 02:38:30 --> Input Class Initialized
INFO - 2016-10-09 02:38:30 --> Language Class Initialized
INFO - 2016-10-09 02:38:30 --> Language Class Initialized
INFO - 2016-10-09 02:38:30 --> Config Class Initialized
INFO - 2016-10-09 02:38:30 --> Loader Class Initialized
INFO - 2016-10-09 02:38:30 --> Helper loaded: url_helper
INFO - 2016-10-09 02:38:30 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 02:38:30 --> Controller Class Initialized
DEBUG - 2016-10-09 02:38:30 --> Index MX_Controller Initialized
INFO - 2016-10-09 02:38:30 --> Model Class Initialized
INFO - 2016-10-09 02:38:31 --> Model Class Initialized
ERROR - 2016-10-09 02:38:31 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-09 02:38:31 --> Anggota MX_Controller Initialized
INFO - 2016-10-09 02:38:31 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:31 --> Final output sent to browser
DEBUG - 2016-10-09 02:38:31 --> Total execution time: 0.6933
INFO - 2016-10-09 02:38:33 --> Config Class Initialized
INFO - 2016-10-09 02:38:33 --> Hooks Class Initialized
DEBUG - 2016-10-09 02:38:33 --> UTF-8 Support Enabled
INFO - 2016-10-09 02:38:33 --> Utf8 Class Initialized
INFO - 2016-10-09 02:38:33 --> URI Class Initialized
INFO - 2016-10-09 02:38:33 --> Router Class Initialized
INFO - 2016-10-09 02:38:33 --> Output Class Initialized
INFO - 2016-10-09 02:38:33 --> Security Class Initialized
DEBUG - 2016-10-09 02:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 02:38:34 --> Input Class Initialized
INFO - 2016-10-09 02:38:34 --> Language Class Initialized
INFO - 2016-10-09 02:38:34 --> Language Class Initialized
INFO - 2016-10-09 02:38:34 --> Config Class Initialized
INFO - 2016-10-09 02:38:34 --> Loader Class Initialized
INFO - 2016-10-09 02:38:34 --> Helper loaded: url_helper
INFO - 2016-10-09 02:38:34 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 02:38:34 --> Controller Class Initialized
DEBUG - 2016-10-09 02:38:34 --> Index MX_Controller Initialized
INFO - 2016-10-09 02:38:34 --> Model Class Initialized
INFO - 2016-10-09 02:38:34 --> Model Class Initialized
ERROR - 2016-10-09 02:38:34 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-10-09 02:38:34 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 02:38:34 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 02:38:34 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 02:38:34 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_umum.php
DEBUG - 2016-10-09 02:38:34 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 02:38:34 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 02:38:34 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:34 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:34 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:34 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:34 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:34 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:34 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:34 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:34 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:34 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:34 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:34 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:34 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:34 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:35 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:35 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:35 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:35 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:35 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:35 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:35 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:35 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:35 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:35 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:35 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:35 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:35 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:35 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:35 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:35 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:35 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:35 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:35 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:35 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:35 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:35 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:35 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:35 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:35 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:35 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:35 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:35 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:35 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:35 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:35 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:35 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:35 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:35 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:35 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:36 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:36 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:36 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:36 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:36 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:36 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:36 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:36 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:36 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:36 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:36 --> Database Driver Class Initialized
DEBUG - 2016-10-09 02:38:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 02:38:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 02:38:36 --> Final output sent to browser
DEBUG - 2016-10-09 02:38:36 --> Total execution time: 2.5845
INFO - 2016-10-09 02:38:53 --> Config Class Initialized
INFO - 2016-10-09 02:38:53 --> Hooks Class Initialized
DEBUG - 2016-10-09 02:38:53 --> UTF-8 Support Enabled
INFO - 2016-10-09 02:38:53 --> Utf8 Class Initialized
INFO - 2016-10-09 02:38:53 --> URI Class Initialized
INFO - 2016-10-09 02:38:53 --> Router Class Initialized
INFO - 2016-10-09 02:38:53 --> Output Class Initialized
INFO - 2016-10-09 02:38:53 --> Security Class Initialized
DEBUG - 2016-10-09 02:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 02:38:53 --> Input Class Initialized
INFO - 2016-10-09 02:38:53 --> Language Class Initialized
INFO - 2016-10-09 02:38:53 --> Language Class Initialized
INFO - 2016-10-09 02:38:53 --> Config Class Initialized
INFO - 2016-10-09 02:38:53 --> Loader Class Initialized
INFO - 2016-10-09 02:38:53 --> Helper loaded: url_helper
INFO - 2016-10-09 02:38:54 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 02:38:54 --> Controller Class Initialized
DEBUG - 2016-10-09 02:38:54 --> Index MX_Controller Initialized
INFO - 2016-10-09 02:38:54 --> Model Class Initialized
INFO - 2016-10-09 02:38:54 --> Model Class Initialized
ERROR - 2016-10-09 02:38:54 --> Unable to delete cache file for admin/index/do_ajukan_pinjaman
INFO - 2016-10-09 02:38:54 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:54 --> Database Driver Class Initialized
INFO - 2016-10-09 02:38:54 --> Final output sent to browser
DEBUG - 2016-10-09 02:38:54 --> Total execution time: 0.8723
INFO - 2016-10-09 02:56:15 --> Config Class Initialized
INFO - 2016-10-09 02:56:15 --> Hooks Class Initialized
DEBUG - 2016-10-09 02:56:15 --> UTF-8 Support Enabled
INFO - 2016-10-09 02:56:15 --> Utf8 Class Initialized
INFO - 2016-10-09 02:56:15 --> URI Class Initialized
INFO - 2016-10-09 02:56:15 --> Router Class Initialized
INFO - 2016-10-09 02:56:15 --> Output Class Initialized
INFO - 2016-10-09 02:56:15 --> Security Class Initialized
DEBUG - 2016-10-09 02:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 02:56:16 --> Input Class Initialized
INFO - 2016-10-09 02:56:16 --> Language Class Initialized
INFO - 2016-10-09 02:56:16 --> Language Class Initialized
INFO - 2016-10-09 02:56:16 --> Config Class Initialized
INFO - 2016-10-09 02:56:16 --> Loader Class Initialized
INFO - 2016-10-09 02:56:16 --> Helper loaded: url_helper
INFO - 2016-10-09 02:56:16 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 02:56:16 --> Controller Class Initialized
DEBUG - 2016-10-09 02:56:16 --> Index MX_Controller Initialized
INFO - 2016-10-09 02:56:16 --> Model Class Initialized
INFO - 2016-10-09 02:56:16 --> Model Class Initialized
ERROR - 2016-10-09 02:56:16 --> Unable to delete cache file for admin/index/batal/9e6a55b6b4563e652a23be9d623ca5055c356940
INFO - 2016-10-09 02:56:16 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:16 --> Final output sent to browser
DEBUG - 2016-10-09 02:56:16 --> Total execution time: 0.6701
INFO - 2016-10-09 02:56:16 --> Config Class Initialized
INFO - 2016-10-09 02:56:16 --> Hooks Class Initialized
DEBUG - 2016-10-09 02:56:16 --> UTF-8 Support Enabled
INFO - 2016-10-09 02:56:16 --> Utf8 Class Initialized
INFO - 2016-10-09 02:56:16 --> URI Class Initialized
INFO - 2016-10-09 02:56:16 --> Router Class Initialized
INFO - 2016-10-09 02:56:16 --> Output Class Initialized
INFO - 2016-10-09 02:56:16 --> Security Class Initialized
DEBUG - 2016-10-09 02:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 02:56:16 --> Input Class Initialized
INFO - 2016-10-09 02:56:16 --> Language Class Initialized
INFO - 2016-10-09 02:56:16 --> Language Class Initialized
INFO - 2016-10-09 02:56:16 --> Config Class Initialized
INFO - 2016-10-09 02:56:16 --> Loader Class Initialized
INFO - 2016-10-09 02:56:16 --> Helper loaded: url_helper
INFO - 2016-10-09 02:56:17 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 02:56:17 --> Controller Class Initialized
DEBUG - 2016-10-09 02:56:17 --> Index MX_Controller Initialized
INFO - 2016-10-09 02:56:17 --> Model Class Initialized
INFO - 2016-10-09 02:56:17 --> Model Class Initialized
ERROR - 2016-10-09 02:56:17 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-10-09 02:56:17 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 02:56:17 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 02:56:17 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 02:56:17 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-10-09 02:56:17 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 02:56:17 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 02:56:17 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:17 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:17 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:17 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:17 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:17 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:17 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:17 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:17 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:17 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:17 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:17 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:17 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:17 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:17 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:17 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:17 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:17 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:17 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:17 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:17 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:17 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:17 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:18 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:18 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:18 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:18 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:18 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:18 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:18 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:18 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:18 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:18 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:18 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:18 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:18 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:18 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:18 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:18 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:18 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:18 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:18 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:18 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:18 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:18 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:18 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:18 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:18 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:18 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:18 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:18 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:18 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:18 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:18 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:18 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:18 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:18 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:18 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:18 --> Database Driver Class Initialized
DEBUG - 2016-10-09 02:56:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 02:56:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 02:56:19 --> Final output sent to browser
DEBUG - 2016-10-09 02:56:19 --> Total execution time: 2.4678
INFO - 2016-10-09 02:56:26 --> Config Class Initialized
INFO - 2016-10-09 02:56:26 --> Hooks Class Initialized
DEBUG - 2016-10-09 02:56:26 --> UTF-8 Support Enabled
INFO - 2016-10-09 02:56:26 --> Utf8 Class Initialized
INFO - 2016-10-09 02:56:26 --> URI Class Initialized
INFO - 2016-10-09 02:56:26 --> Router Class Initialized
INFO - 2016-10-09 02:56:26 --> Output Class Initialized
INFO - 2016-10-09 02:56:26 --> Security Class Initialized
DEBUG - 2016-10-09 02:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 02:56:26 --> Input Class Initialized
INFO - 2016-10-09 02:56:26 --> Language Class Initialized
INFO - 2016-10-09 02:56:26 --> Language Class Initialized
INFO - 2016-10-09 02:56:26 --> Config Class Initialized
INFO - 2016-10-09 02:56:26 --> Loader Class Initialized
INFO - 2016-10-09 02:56:26 --> Helper loaded: url_helper
INFO - 2016-10-09 02:56:26 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 02:56:26 --> Controller Class Initialized
DEBUG - 2016-10-09 02:56:26 --> Index MX_Controller Initialized
INFO - 2016-10-09 02:56:26 --> Model Class Initialized
INFO - 2016-10-09 02:56:26 --> Model Class Initialized
ERROR - 2016-10-09 02:56:27 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-09 02:56:27 --> Anggota MX_Controller Initialized
INFO - 2016-10-09 02:56:27 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:27 --> Final output sent to browser
DEBUG - 2016-10-09 02:56:27 --> Total execution time: 0.6501
INFO - 2016-10-09 02:56:28 --> Config Class Initialized
INFO - 2016-10-09 02:56:28 --> Hooks Class Initialized
DEBUG - 2016-10-09 02:56:28 --> UTF-8 Support Enabled
INFO - 2016-10-09 02:56:28 --> Utf8 Class Initialized
INFO - 2016-10-09 02:56:28 --> URI Class Initialized
INFO - 2016-10-09 02:56:28 --> Router Class Initialized
INFO - 2016-10-09 02:56:28 --> Output Class Initialized
INFO - 2016-10-09 02:56:28 --> Security Class Initialized
DEBUG - 2016-10-09 02:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 02:56:28 --> Input Class Initialized
INFO - 2016-10-09 02:56:28 --> Language Class Initialized
INFO - 2016-10-09 02:56:28 --> Language Class Initialized
INFO - 2016-10-09 02:56:28 --> Config Class Initialized
INFO - 2016-10-09 02:56:28 --> Loader Class Initialized
INFO - 2016-10-09 02:56:28 --> Helper loaded: url_helper
INFO - 2016-10-09 02:56:28 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 02:56:28 --> Controller Class Initialized
DEBUG - 2016-10-09 02:56:28 --> Index MX_Controller Initialized
INFO - 2016-10-09 02:56:29 --> Model Class Initialized
INFO - 2016-10-09 02:56:29 --> Model Class Initialized
ERROR - 2016-10-09 02:56:29 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-10-09 02:56:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 02:56:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 02:56:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 02:56:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_umum.php
DEBUG - 2016-10-09 02:56:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 02:56:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 02:56:29 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:29 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:29 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:29 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:29 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:29 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:29 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:29 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:29 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:29 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:29 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:29 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:29 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:29 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:29 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:29 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:29 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:29 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:29 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:29 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:29 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:29 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:29 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:29 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:29 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:29 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:30 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:30 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:30 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:30 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:30 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:30 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:30 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:30 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:30 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:30 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:30 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:30 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:30 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:30 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:30 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:30 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:30 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:30 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:30 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:30 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:30 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:30 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:30 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:30 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:30 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:30 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:30 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:30 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:30 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:30 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:30 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:30 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:30 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:31 --> Database Driver Class Initialized
DEBUG - 2016-10-09 02:56:31 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 02:56:31 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 02:56:31 --> Final output sent to browser
DEBUG - 2016-10-09 02:56:31 --> Total execution time: 2.7016
INFO - 2016-10-09 02:56:38 --> Config Class Initialized
INFO - 2016-10-09 02:56:38 --> Hooks Class Initialized
DEBUG - 2016-10-09 02:56:38 --> UTF-8 Support Enabled
INFO - 2016-10-09 02:56:38 --> Utf8 Class Initialized
INFO - 2016-10-09 02:56:38 --> URI Class Initialized
INFO - 2016-10-09 02:56:38 --> Router Class Initialized
INFO - 2016-10-09 02:56:38 --> Output Class Initialized
INFO - 2016-10-09 02:56:38 --> Security Class Initialized
DEBUG - 2016-10-09 02:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 02:56:38 --> Input Class Initialized
INFO - 2016-10-09 02:56:38 --> Language Class Initialized
INFO - 2016-10-09 02:56:38 --> Language Class Initialized
INFO - 2016-10-09 02:56:38 --> Config Class Initialized
INFO - 2016-10-09 02:56:38 --> Loader Class Initialized
INFO - 2016-10-09 02:56:38 --> Helper loaded: url_helper
INFO - 2016-10-09 02:56:38 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 02:56:38 --> Controller Class Initialized
DEBUG - 2016-10-09 02:56:38 --> Index MX_Controller Initialized
INFO - 2016-10-09 02:56:38 --> Model Class Initialized
INFO - 2016-10-09 02:56:38 --> Model Class Initialized
ERROR - 2016-10-09 02:56:38 --> Unable to delete cache file for admin/index/do_ajukan_pinjaman
INFO - 2016-10-09 02:56:38 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:38 --> Database Driver Class Initialized
INFO - 2016-10-09 02:56:38 --> Final output sent to browser
DEBUG - 2016-10-09 02:56:38 --> Total execution time: 0.7357
INFO - 2016-10-09 04:23:50 --> Config Class Initialized
INFO - 2016-10-09 04:23:51 --> Hooks Class Initialized
DEBUG - 2016-10-09 04:23:51 --> UTF-8 Support Enabled
INFO - 2016-10-09 04:23:51 --> Utf8 Class Initialized
INFO - 2016-10-09 04:23:51 --> URI Class Initialized
INFO - 2016-10-09 04:23:51 --> Router Class Initialized
INFO - 2016-10-09 04:23:51 --> Output Class Initialized
INFO - 2016-10-09 04:23:51 --> Security Class Initialized
DEBUG - 2016-10-09 04:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 04:23:51 --> Input Class Initialized
INFO - 2016-10-09 04:23:51 --> Language Class Initialized
INFO - 2016-10-09 04:23:51 --> Language Class Initialized
INFO - 2016-10-09 04:23:51 --> Config Class Initialized
INFO - 2016-10-09 04:23:51 --> Loader Class Initialized
INFO - 2016-10-09 04:23:51 --> Helper loaded: url_helper
INFO - 2016-10-09 04:23:51 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 04:23:51 --> Controller Class Initialized
DEBUG - 2016-10-09 04:23:51 --> Index MX_Controller Initialized
INFO - 2016-10-09 04:23:51 --> Model Class Initialized
INFO - 2016-10-09 04:23:51 --> Model Class Initialized
ERROR - 2016-10-09 04:23:51 --> Unable to delete cache file for admin/index/batal/b3f0c7f6bb763af1be91d9e74eabfeb199dc1f1f
INFO - 2016-10-09 04:23:51 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:51 --> Final output sent to browser
DEBUG - 2016-10-09 04:23:51 --> Total execution time: 0.8372
INFO - 2016-10-09 04:23:51 --> Config Class Initialized
INFO - 2016-10-09 04:23:51 --> Hooks Class Initialized
DEBUG - 2016-10-09 04:23:52 --> UTF-8 Support Enabled
INFO - 2016-10-09 04:23:52 --> Utf8 Class Initialized
INFO - 2016-10-09 04:23:52 --> URI Class Initialized
INFO - 2016-10-09 04:23:52 --> Router Class Initialized
INFO - 2016-10-09 04:23:52 --> Output Class Initialized
INFO - 2016-10-09 04:23:52 --> Security Class Initialized
DEBUG - 2016-10-09 04:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 04:23:52 --> Input Class Initialized
INFO - 2016-10-09 04:23:52 --> Language Class Initialized
INFO - 2016-10-09 04:23:52 --> Language Class Initialized
INFO - 2016-10-09 04:23:52 --> Config Class Initialized
INFO - 2016-10-09 04:23:52 --> Loader Class Initialized
INFO - 2016-10-09 04:23:52 --> Helper loaded: url_helper
INFO - 2016-10-09 04:23:52 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 04:23:52 --> Controller Class Initialized
DEBUG - 2016-10-09 04:23:52 --> Index MX_Controller Initialized
INFO - 2016-10-09 04:23:52 --> Model Class Initialized
INFO - 2016-10-09 04:23:52 --> Model Class Initialized
ERROR - 2016-10-09 04:23:52 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-10-09 04:23:52 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 04:23:52 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 04:23:52 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 04:23:52 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-10-09 04:23:52 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 04:23:52 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 04:23:52 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:52 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:52 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:52 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:52 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:52 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:52 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:52 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:52 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:52 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:52 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:52 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:52 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:53 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:53 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:53 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:53 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:53 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:53 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:53 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:53 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:53 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:53 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:53 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:53 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:53 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:53 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:53 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:53 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:53 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:53 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:53 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:53 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:53 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:53 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:53 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:53 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:53 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:53 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:53 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:53 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:53 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:53 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:53 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:54 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:54 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:54 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:54 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:54 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:54 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:54 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:54 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:54 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:54 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:54 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:54 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:54 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:54 --> Database Driver Class Initialized
INFO - 2016-10-09 04:23:54 --> Database Driver Class Initialized
DEBUG - 2016-10-09 04:23:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 04:23:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 04:23:54 --> Final output sent to browser
DEBUG - 2016-10-09 04:23:54 --> Total execution time: 2.5516
INFO - 2016-10-09 04:26:25 --> Config Class Initialized
INFO - 2016-10-09 04:26:25 --> Hooks Class Initialized
DEBUG - 2016-10-09 04:26:25 --> UTF-8 Support Enabled
INFO - 2016-10-09 04:26:25 --> Utf8 Class Initialized
INFO - 2016-10-09 04:26:25 --> URI Class Initialized
INFO - 2016-10-09 04:26:25 --> Router Class Initialized
INFO - 2016-10-09 04:26:25 --> Output Class Initialized
INFO - 2016-10-09 04:26:25 --> Security Class Initialized
DEBUG - 2016-10-09 04:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 04:26:25 --> Input Class Initialized
INFO - 2016-10-09 04:26:25 --> Language Class Initialized
INFO - 2016-10-09 04:26:25 --> Language Class Initialized
INFO - 2016-10-09 04:26:25 --> Config Class Initialized
INFO - 2016-10-09 04:26:25 --> Loader Class Initialized
INFO - 2016-10-09 04:26:25 --> Helper loaded: url_helper
INFO - 2016-10-09 04:26:25 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 04:26:25 --> Controller Class Initialized
DEBUG - 2016-10-09 04:26:25 --> Index MX_Controller Initialized
INFO - 2016-10-09 04:26:25 --> Model Class Initialized
INFO - 2016-10-09 04:26:25 --> Model Class Initialized
ERROR - 2016-10-09 04:26:25 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-09 04:26:25 --> Anggota MX_Controller Initialized
INFO - 2016-10-09 04:26:25 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:25 --> Final output sent to browser
DEBUG - 2016-10-09 04:26:25 --> Total execution time: 0.7242
INFO - 2016-10-09 04:26:27 --> Config Class Initialized
INFO - 2016-10-09 04:26:27 --> Hooks Class Initialized
DEBUG - 2016-10-09 04:26:27 --> UTF-8 Support Enabled
INFO - 2016-10-09 04:26:27 --> Utf8 Class Initialized
INFO - 2016-10-09 04:26:27 --> URI Class Initialized
INFO - 2016-10-09 04:26:27 --> Router Class Initialized
INFO - 2016-10-09 04:26:27 --> Output Class Initialized
INFO - 2016-10-09 04:26:27 --> Security Class Initialized
DEBUG - 2016-10-09 04:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 04:26:27 --> Input Class Initialized
INFO - 2016-10-09 04:26:27 --> Language Class Initialized
INFO - 2016-10-09 04:26:27 --> Language Class Initialized
INFO - 2016-10-09 04:26:27 --> Config Class Initialized
INFO - 2016-10-09 04:26:27 --> Loader Class Initialized
INFO - 2016-10-09 04:26:27 --> Helper loaded: url_helper
INFO - 2016-10-09 04:26:27 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 04:26:27 --> Controller Class Initialized
DEBUG - 2016-10-09 04:26:27 --> Index MX_Controller Initialized
INFO - 2016-10-09 04:26:27 --> Model Class Initialized
INFO - 2016-10-09 04:26:27 --> Model Class Initialized
ERROR - 2016-10-09 04:26:27 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-10-09 04:26:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 04:26:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 04:26:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 04:26:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-10-09 04:26:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 04:26:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 04:26:27 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:27 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:28 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:28 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:28 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:28 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:28 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:28 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:28 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:28 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:28 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:28 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:28 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:28 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:28 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:28 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:28 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:28 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:28 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:28 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:28 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:28 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:28 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:28 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:28 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:28 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:28 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:28 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:28 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:28 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:28 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:28 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:28 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:28 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:28 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:29 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:29 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:29 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:29 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:29 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:29 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:29 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:29 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:29 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:29 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:29 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:29 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:29 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:29 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:29 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:29 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:29 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:29 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:29 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:29 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:29 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:29 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:29 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:29 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:29 --> Database Driver Class Initialized
DEBUG - 2016-10-09 04:26:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 04:26:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 04:26:29 --> Final output sent to browser
DEBUG - 2016-10-09 04:26:29 --> Total execution time: 2.7690
INFO - 2016-10-09 04:26:39 --> Config Class Initialized
INFO - 2016-10-09 04:26:39 --> Hooks Class Initialized
DEBUG - 2016-10-09 04:26:39 --> UTF-8 Support Enabled
INFO - 2016-10-09 04:26:39 --> Utf8 Class Initialized
INFO - 2016-10-09 04:26:39 --> URI Class Initialized
INFO - 2016-10-09 04:26:40 --> Router Class Initialized
INFO - 2016-10-09 04:26:40 --> Output Class Initialized
INFO - 2016-10-09 04:26:40 --> Security Class Initialized
DEBUG - 2016-10-09 04:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 04:26:40 --> Input Class Initialized
INFO - 2016-10-09 04:26:40 --> Language Class Initialized
INFO - 2016-10-09 04:26:40 --> Language Class Initialized
INFO - 2016-10-09 04:26:40 --> Config Class Initialized
INFO - 2016-10-09 04:26:40 --> Loader Class Initialized
INFO - 2016-10-09 04:26:40 --> Helper loaded: url_helper
INFO - 2016-10-09 04:26:40 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 04:26:40 --> Controller Class Initialized
DEBUG - 2016-10-09 04:26:40 --> Index MX_Controller Initialized
INFO - 2016-10-09 04:26:40 --> Model Class Initialized
INFO - 2016-10-09 04:26:40 --> Model Class Initialized
ERROR - 2016-10-09 04:26:40 --> Unable to delete cache file for admin/index/do_ajukan_pinjaman
INFO - 2016-10-09 04:26:40 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:40 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:40 --> Final output sent to browser
DEBUG - 2016-10-09 04:26:40 --> Total execution time: 0.8789
INFO - 2016-10-09 04:26:55 --> Config Class Initialized
INFO - 2016-10-09 04:26:55 --> Hooks Class Initialized
DEBUG - 2016-10-09 04:26:55 --> UTF-8 Support Enabled
INFO - 2016-10-09 04:26:55 --> Utf8 Class Initialized
INFO - 2016-10-09 04:26:55 --> URI Class Initialized
INFO - 2016-10-09 04:26:55 --> Router Class Initialized
INFO - 2016-10-09 04:26:55 --> Output Class Initialized
INFO - 2016-10-09 04:26:55 --> Security Class Initialized
DEBUG - 2016-10-09 04:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 04:26:55 --> Input Class Initialized
INFO - 2016-10-09 04:26:55 --> Language Class Initialized
INFO - 2016-10-09 04:26:55 --> Language Class Initialized
INFO - 2016-10-09 04:26:55 --> Config Class Initialized
INFO - 2016-10-09 04:26:55 --> Loader Class Initialized
INFO - 2016-10-09 04:26:55 --> Helper loaded: url_helper
INFO - 2016-10-09 04:26:56 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 04:26:56 --> Controller Class Initialized
DEBUG - 2016-10-09 04:26:56 --> Index MX_Controller Initialized
INFO - 2016-10-09 04:26:56 --> Model Class Initialized
INFO - 2016-10-09 04:26:56 --> Model Class Initialized
ERROR - 2016-10-09 04:26:56 --> Unable to delete cache file for admin/index/finish_pinjaman/91032ad7bbcb6cf72875e8e8207dcfba80173f7c
INFO - 2016-10-09 04:26:56 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:56 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:56 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:56 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:56 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:56 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:56 --> Final output sent to browser
DEBUG - 2016-10-09 04:26:56 --> Total execution time: 1.2094
INFO - 2016-10-09 04:26:56 --> Config Class Initialized
INFO - 2016-10-09 04:26:56 --> Hooks Class Initialized
DEBUG - 2016-10-09 04:26:57 --> UTF-8 Support Enabled
INFO - 2016-10-09 04:26:57 --> Utf8 Class Initialized
INFO - 2016-10-09 04:26:57 --> URI Class Initialized
INFO - 2016-10-09 04:26:57 --> Router Class Initialized
INFO - 2016-10-09 04:26:57 --> Output Class Initialized
INFO - 2016-10-09 04:26:57 --> Security Class Initialized
DEBUG - 2016-10-09 04:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 04:26:57 --> Input Class Initialized
INFO - 2016-10-09 04:26:57 --> Language Class Initialized
INFO - 2016-10-09 04:26:57 --> Language Class Initialized
INFO - 2016-10-09 04:26:57 --> Config Class Initialized
INFO - 2016-10-09 04:26:57 --> Loader Class Initialized
INFO - 2016-10-09 04:26:57 --> Helper loaded: url_helper
INFO - 2016-10-09 04:26:57 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 04:26:57 --> Controller Class Initialized
DEBUG - 2016-10-09 04:26:57 --> Index MX_Controller Initialized
INFO - 2016-10-09 04:26:57 --> Model Class Initialized
INFO - 2016-10-09 04:26:57 --> Model Class Initialized
ERROR - 2016-10-09 04:26:57 --> Unable to delete cache file for admin/index/data_peminjam
DEBUG - 2016-10-09 04:26:57 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 04:26:57 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 04:26:57 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 04:26:57 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_peminjam.php
DEBUG - 2016-10-09 04:26:57 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 04:26:57 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 04:26:57 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:57 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:57 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:57 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:57 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:57 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:57 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:58 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:58 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:58 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:58 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:58 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:58 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:58 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:58 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:58 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:58 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:58 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:58 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:58 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:58 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:58 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:58 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:58 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:58 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:58 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:58 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:58 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:58 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:58 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:58 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:58 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:58 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:58 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:58 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:58 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:58 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:58 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:58 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:58 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:58 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:58 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:59 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:59 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:59 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:59 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:59 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:59 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:59 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:59 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:59 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:59 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:59 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:59 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:59 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:59 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:59 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:59 --> Database Driver Class Initialized
INFO - 2016-10-09 04:26:59 --> Database Driver Class Initialized
DEBUG - 2016-10-09 04:26:59 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 04:26:59 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 04:26:59 --> Final output sent to browser
DEBUG - 2016-10-09 04:26:59 --> Total execution time: 2.5567
INFO - 2016-10-09 04:27:03 --> Config Class Initialized
INFO - 2016-10-09 04:27:03 --> Hooks Class Initialized
DEBUG - 2016-10-09 04:27:03 --> UTF-8 Support Enabled
INFO - 2016-10-09 04:27:03 --> Utf8 Class Initialized
INFO - 2016-10-09 04:27:03 --> URI Class Initialized
INFO - 2016-10-09 04:27:03 --> Router Class Initialized
INFO - 2016-10-09 04:27:03 --> Output Class Initialized
INFO - 2016-10-09 04:27:03 --> Security Class Initialized
DEBUG - 2016-10-09 04:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 04:27:03 --> Input Class Initialized
INFO - 2016-10-09 04:27:03 --> Language Class Initialized
INFO - 2016-10-09 04:27:03 --> Language Class Initialized
INFO - 2016-10-09 04:27:03 --> Config Class Initialized
INFO - 2016-10-09 04:27:03 --> Loader Class Initialized
INFO - 2016-10-09 04:27:03 --> Helper loaded: url_helper
INFO - 2016-10-09 04:27:03 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 04:27:03 --> Controller Class Initialized
DEBUG - 2016-10-09 04:27:03 --> Index MX_Controller Initialized
INFO - 2016-10-09 04:27:04 --> Model Class Initialized
INFO - 2016-10-09 04:27:04 --> Model Class Initialized
ERROR - 2016-10-09 04:27:04 --> Unable to delete cache file for admin/index/tutup_angsuran
DEBUG - 2016-10-09 04:27:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 04:27:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 04:27:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 04:27:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_tutup_angsuran.php
DEBUG - 2016-10-09 04:27:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 04:27:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 04:27:04 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:04 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:04 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:04 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:04 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:04 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:04 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:04 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:04 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:04 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:04 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:04 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:04 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:04 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:04 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:04 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:04 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:04 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:04 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:04 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:04 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:04 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:04 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:04 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:04 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:05 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:05 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:05 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:05 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:05 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:05 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:05 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:05 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:05 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:05 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:05 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:05 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:05 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:05 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:05 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:05 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:05 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:05 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:05 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:05 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:05 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:05 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:05 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:05 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:05 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:05 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:05 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:05 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:05 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:06 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:06 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:06 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:06 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:06 --> Database Driver Class Initialized
DEBUG - 2016-10-09 04:27:06 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 04:27:06 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 04:27:06 --> Final output sent to browser
DEBUG - 2016-10-09 04:27:06 --> Total execution time: 2.8615
INFO - 2016-10-09 04:27:10 --> Config Class Initialized
INFO - 2016-10-09 04:27:10 --> Hooks Class Initialized
DEBUG - 2016-10-09 04:27:10 --> UTF-8 Support Enabled
INFO - 2016-10-09 04:27:10 --> Utf8 Class Initialized
INFO - 2016-10-09 04:27:10 --> URI Class Initialized
INFO - 2016-10-09 04:27:10 --> Router Class Initialized
INFO - 2016-10-09 04:27:10 --> Output Class Initialized
INFO - 2016-10-09 04:27:10 --> Security Class Initialized
DEBUG - 2016-10-09 04:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 04:27:10 --> Input Class Initialized
INFO - 2016-10-09 04:27:10 --> Language Class Initialized
INFO - 2016-10-09 04:27:10 --> Language Class Initialized
INFO - 2016-10-09 04:27:10 --> Config Class Initialized
INFO - 2016-10-09 04:27:10 --> Loader Class Initialized
INFO - 2016-10-09 04:27:10 --> Helper loaded: url_helper
INFO - 2016-10-09 04:27:10 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 04:27:10 --> Controller Class Initialized
DEBUG - 2016-10-09 04:27:10 --> Index MX_Controller Initialized
INFO - 2016-10-09 04:27:10 --> Model Class Initialized
INFO - 2016-10-09 04:27:10 --> Model Class Initialized
ERROR - 2016-10-09 04:27:10 --> Unable to delete cache file for admin/index/getDetailLunas
INFO - 2016-10-09 04:27:10 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:10 --> Final output sent to browser
DEBUG - 2016-10-09 04:27:10 --> Total execution time: 0.7068
INFO - 2016-10-09 04:27:19 --> Config Class Initialized
INFO - 2016-10-09 04:27:20 --> Hooks Class Initialized
DEBUG - 2016-10-09 04:27:20 --> UTF-8 Support Enabled
INFO - 2016-10-09 04:27:20 --> Utf8 Class Initialized
INFO - 2016-10-09 04:27:20 --> URI Class Initialized
INFO - 2016-10-09 04:27:20 --> Router Class Initialized
INFO - 2016-10-09 04:27:20 --> Output Class Initialized
INFO - 2016-10-09 04:27:20 --> Security Class Initialized
DEBUG - 2016-10-09 04:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 04:27:20 --> Input Class Initialized
INFO - 2016-10-09 04:27:20 --> Language Class Initialized
INFO - 2016-10-09 04:27:20 --> Language Class Initialized
INFO - 2016-10-09 04:27:20 --> Config Class Initialized
INFO - 2016-10-09 04:27:20 --> Loader Class Initialized
INFO - 2016-10-09 04:27:20 --> Helper loaded: url_helper
INFO - 2016-10-09 04:27:20 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 04:27:20 --> Controller Class Initialized
DEBUG - 2016-10-09 04:27:20 --> Index MX_Controller Initialized
INFO - 2016-10-09 04:27:20 --> Model Class Initialized
INFO - 2016-10-09 04:27:20 --> Model Class Initialized
ERROR - 2016-10-09 04:27:20 --> Unable to delete cache file for admin/index/do_lunas
INFO - 2016-10-09 04:27:20 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:20 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:20 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:20 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:20 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:21 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:21 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:21 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:21 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:21 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:21 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:21 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:21 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:21 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:21 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:21 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:21 --> Final output sent to browser
DEBUG - 2016-10-09 04:27:21 --> Total execution time: 1.8094
INFO - 2016-10-09 04:27:49 --> Config Class Initialized
INFO - 2016-10-09 04:27:49 --> Hooks Class Initialized
DEBUG - 2016-10-09 04:27:49 --> UTF-8 Support Enabled
INFO - 2016-10-09 04:27:49 --> Utf8 Class Initialized
INFO - 2016-10-09 04:27:49 --> URI Class Initialized
INFO - 2016-10-09 04:27:49 --> Router Class Initialized
INFO - 2016-10-09 04:27:49 --> Output Class Initialized
INFO - 2016-10-09 04:27:49 --> Security Class Initialized
DEBUG - 2016-10-09 04:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 04:27:49 --> Input Class Initialized
INFO - 2016-10-09 04:27:49 --> Language Class Initialized
INFO - 2016-10-09 04:27:49 --> Language Class Initialized
INFO - 2016-10-09 04:27:49 --> Config Class Initialized
INFO - 2016-10-09 04:27:49 --> Loader Class Initialized
INFO - 2016-10-09 04:27:49 --> Helper loaded: url_helper
INFO - 2016-10-09 04:27:49 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 04:27:49 --> Controller Class Initialized
DEBUG - 2016-10-09 04:27:49 --> Index MX_Controller Initialized
INFO - 2016-10-09 04:27:49 --> Model Class Initialized
INFO - 2016-10-09 04:27:49 --> Model Class Initialized
ERROR - 2016-10-09 04:27:49 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-10-09 04:27:49 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 04:27:49 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 04:27:49 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 04:27:50 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-10-09 04:27:50 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 04:27:50 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 04:27:50 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:50 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:50 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:50 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:50 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:50 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:50 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:50 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:50 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:50 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:50 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:50 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:50 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:50 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:50 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:50 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:50 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:50 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:50 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:50 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:50 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:50 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:50 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:50 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:50 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:50 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:50 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:50 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:50 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:50 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:50 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:50 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:51 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:51 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:51 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:51 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:51 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:51 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:51 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:51 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:51 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:51 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:51 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:51 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:51 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:51 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:51 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:51 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:51 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:51 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:51 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:51 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:51 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:51 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:51 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:51 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:51 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:51 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:51 --> Database Driver Class Initialized
DEBUG - 2016-10-09 04:27:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 04:27:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 04:27:51 --> Final output sent to browser
DEBUG - 2016-10-09 04:27:51 --> Total execution time: 2.5265
INFO - 2016-10-09 04:27:58 --> Config Class Initialized
INFO - 2016-10-09 04:27:58 --> Hooks Class Initialized
DEBUG - 2016-10-09 04:27:58 --> UTF-8 Support Enabled
INFO - 2016-10-09 04:27:58 --> Utf8 Class Initialized
INFO - 2016-10-09 04:27:58 --> URI Class Initialized
INFO - 2016-10-09 04:27:58 --> Router Class Initialized
INFO - 2016-10-09 04:27:58 --> Output Class Initialized
INFO - 2016-10-09 04:27:58 --> Security Class Initialized
DEBUG - 2016-10-09 04:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 04:27:58 --> Input Class Initialized
INFO - 2016-10-09 04:27:58 --> Language Class Initialized
INFO - 2016-10-09 04:27:58 --> Language Class Initialized
INFO - 2016-10-09 04:27:58 --> Config Class Initialized
INFO - 2016-10-09 04:27:58 --> Loader Class Initialized
INFO - 2016-10-09 04:27:58 --> Helper loaded: url_helper
INFO - 2016-10-09 04:27:58 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 04:27:58 --> Controller Class Initialized
DEBUG - 2016-10-09 04:27:58 --> Index MX_Controller Initialized
INFO - 2016-10-09 04:27:58 --> Model Class Initialized
INFO - 2016-10-09 04:27:58 --> Model Class Initialized
ERROR - 2016-10-09 04:27:58 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-09 04:27:58 --> Anggota MX_Controller Initialized
INFO - 2016-10-09 04:27:58 --> Database Driver Class Initialized
INFO - 2016-10-09 04:27:58 --> Final output sent to browser
DEBUG - 2016-10-09 04:27:58 --> Total execution time: 0.6540
INFO - 2016-10-09 04:27:59 --> Config Class Initialized
INFO - 2016-10-09 04:27:59 --> Hooks Class Initialized
DEBUG - 2016-10-09 04:28:00 --> UTF-8 Support Enabled
INFO - 2016-10-09 04:28:00 --> Utf8 Class Initialized
INFO - 2016-10-09 04:28:00 --> URI Class Initialized
INFO - 2016-10-09 04:28:00 --> Router Class Initialized
INFO - 2016-10-09 04:28:00 --> Output Class Initialized
INFO - 2016-10-09 04:28:00 --> Security Class Initialized
DEBUG - 2016-10-09 04:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 04:28:00 --> Input Class Initialized
INFO - 2016-10-09 04:28:00 --> Language Class Initialized
INFO - 2016-10-09 04:28:00 --> Language Class Initialized
INFO - 2016-10-09 04:28:00 --> Config Class Initialized
INFO - 2016-10-09 04:28:00 --> Loader Class Initialized
INFO - 2016-10-09 04:28:00 --> Helper loaded: url_helper
INFO - 2016-10-09 04:28:00 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 04:28:00 --> Controller Class Initialized
DEBUG - 2016-10-09 04:28:00 --> Index MX_Controller Initialized
INFO - 2016-10-09 04:28:00 --> Model Class Initialized
INFO - 2016-10-09 04:28:00 --> Model Class Initialized
ERROR - 2016-10-09 04:28:00 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-10-09 04:28:00 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 04:28:00 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 04:28:00 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 04:28:00 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-10-09 04:28:00 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 04:28:00 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 04:28:00 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:00 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:00 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:00 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:00 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:00 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:00 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:00 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:00 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:00 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:00 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:00 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:01 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:01 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:01 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:01 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:01 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:01 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:01 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:01 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:01 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:01 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:01 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:01 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:01 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:01 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:01 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:01 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:01 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:01 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:01 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:01 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:01 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:01 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:01 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:01 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:01 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:01 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:01 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:02 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:02 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:02 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:02 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:02 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:02 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:02 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:02 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:02 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:02 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:02 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:02 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:02 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:02 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:02 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:02 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:02 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:02 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:02 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:02 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:02 --> Database Driver Class Initialized
DEBUG - 2016-10-09 04:28:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 04:28:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 04:28:02 --> Final output sent to browser
DEBUG - 2016-10-09 04:28:02 --> Total execution time: 2.9303
INFO - 2016-10-09 04:28:10 --> Config Class Initialized
INFO - 2016-10-09 04:28:10 --> Hooks Class Initialized
DEBUG - 2016-10-09 04:28:10 --> UTF-8 Support Enabled
INFO - 2016-10-09 04:28:10 --> Utf8 Class Initialized
INFO - 2016-10-09 04:28:10 --> URI Class Initialized
INFO - 2016-10-09 04:28:10 --> Router Class Initialized
INFO - 2016-10-09 04:28:10 --> Output Class Initialized
INFO - 2016-10-09 04:28:10 --> Security Class Initialized
DEBUG - 2016-10-09 04:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 04:28:10 --> Input Class Initialized
INFO - 2016-10-09 04:28:10 --> Language Class Initialized
INFO - 2016-10-09 04:28:10 --> Language Class Initialized
INFO - 2016-10-09 04:28:10 --> Config Class Initialized
INFO - 2016-10-09 04:28:10 --> Loader Class Initialized
INFO - 2016-10-09 04:28:10 --> Helper loaded: url_helper
INFO - 2016-10-09 04:28:10 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 04:28:10 --> Controller Class Initialized
DEBUG - 2016-10-09 04:28:10 --> Index MX_Controller Initialized
INFO - 2016-10-09 04:28:10 --> Model Class Initialized
INFO - 2016-10-09 04:28:10 --> Model Class Initialized
ERROR - 2016-10-09 04:28:10 --> Unable to delete cache file for admin/index/do_ajukan_pinjaman
INFO - 2016-10-09 04:28:11 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:11 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:11 --> Final output sent to browser
DEBUG - 2016-10-09 04:28:11 --> Total execution time: 0.7095
INFO - 2016-10-09 04:28:23 --> Config Class Initialized
INFO - 2016-10-09 04:28:23 --> Hooks Class Initialized
DEBUG - 2016-10-09 04:28:23 --> UTF-8 Support Enabled
INFO - 2016-10-09 04:28:23 --> Utf8 Class Initialized
INFO - 2016-10-09 04:28:23 --> URI Class Initialized
INFO - 2016-10-09 04:28:23 --> Router Class Initialized
INFO - 2016-10-09 04:28:23 --> Output Class Initialized
INFO - 2016-10-09 04:28:23 --> Security Class Initialized
DEBUG - 2016-10-09 04:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 04:28:23 --> Input Class Initialized
INFO - 2016-10-09 04:28:23 --> Language Class Initialized
INFO - 2016-10-09 04:28:23 --> Language Class Initialized
INFO - 2016-10-09 04:28:23 --> Config Class Initialized
INFO - 2016-10-09 04:28:23 --> Loader Class Initialized
INFO - 2016-10-09 04:28:23 --> Helper loaded: url_helper
INFO - 2016-10-09 04:28:23 --> Database Driver Class Initialized
INFO - 2016-10-09 04:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 04:28:23 --> Controller Class Initialized
DEBUG - 2016-10-09 04:28:23 --> Index MX_Controller Initialized
INFO - 2016-10-09 04:28:23 --> Model Class Initialized
INFO - 2016-10-09 04:28:23 --> Model Class Initialized
ERROR - 2016-10-09 04:28:23 --> Unable to delete cache file for admin/index/batal/91032ad7bbcb6cf72875e8e8207dcfba80173f7c
INFO - 2016-10-09 04:28:23 --> Database Driver Class Initialized
ERROR - 2016-10-09 04:28:23 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`koperasi`.`tt_angsuran`, CONSTRAINT `FK_tt_angsuran_tm_pinjaman` FOREIGN KEY (`kd_pinjaman`) REFERENCES `tm_pinjaman` (`kd_pinjaman`)) - Invalid query: DELETE FROM `tm_pinjaman`
WHERE sha1(kd_pinjaman) = '91032ad7bbcb6cf72875e8e8207dcfba80173f7c'
INFO - 2016-10-09 04:28:23 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-09 16:46:13 --> Config Class Initialized
INFO - 2016-10-09 16:46:13 --> Hooks Class Initialized
DEBUG - 2016-10-09 16:46:13 --> UTF-8 Support Enabled
INFO - 2016-10-09 16:46:13 --> Utf8 Class Initialized
INFO - 2016-10-09 16:46:13 --> URI Class Initialized
INFO - 2016-10-09 16:46:14 --> Router Class Initialized
INFO - 2016-10-09 16:46:14 --> Output Class Initialized
INFO - 2016-10-09 16:46:14 --> Security Class Initialized
DEBUG - 2016-10-09 16:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 16:46:14 --> Input Class Initialized
INFO - 2016-10-09 16:46:14 --> Language Class Initialized
INFO - 2016-10-09 16:46:14 --> Language Class Initialized
INFO - 2016-10-09 16:46:14 --> Config Class Initialized
INFO - 2016-10-09 16:46:15 --> Loader Class Initialized
INFO - 2016-10-09 16:46:15 --> Helper loaded: url_helper
INFO - 2016-10-09 16:46:15 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 16:46:15 --> Controller Class Initialized
DEBUG - 2016-10-09 16:46:15 --> Index MX_Controller Initialized
INFO - 2016-10-09 16:46:15 --> Model Class Initialized
INFO - 2016-10-09 16:46:15 --> Model Class Initialized
ERROR - 2016-10-09 16:46:16 --> Unable to delete cache file for admin/index/proses_peminjaman
INFO - 2016-10-09 16:46:16 --> Final output sent to browser
DEBUG - 2016-10-09 16:46:16 --> Total execution time: 2.8111
INFO - 2016-10-09 16:46:16 --> Config Class Initialized
INFO - 2016-10-09 16:46:16 --> Hooks Class Initialized
DEBUG - 2016-10-09 16:46:16 --> UTF-8 Support Enabled
INFO - 2016-10-09 16:46:16 --> Utf8 Class Initialized
INFO - 2016-10-09 16:46:16 --> URI Class Initialized
INFO - 2016-10-09 16:46:16 --> Router Class Initialized
INFO - 2016-10-09 16:46:16 --> Output Class Initialized
INFO - 2016-10-09 16:46:16 --> Security Class Initialized
DEBUG - 2016-10-09 16:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 16:46:16 --> Input Class Initialized
INFO - 2016-10-09 16:46:16 --> Language Class Initialized
INFO - 2016-10-09 16:46:16 --> Language Class Initialized
INFO - 2016-10-09 16:46:16 --> Config Class Initialized
INFO - 2016-10-09 16:46:16 --> Loader Class Initialized
INFO - 2016-10-09 16:46:16 --> Helper loaded: url_helper
INFO - 2016-10-09 16:46:16 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 16:46:16 --> Controller Class Initialized
DEBUG - 2016-10-09 16:46:16 --> Index MX_Controller Initialized
INFO - 2016-10-09 16:46:16 --> Model Class Initialized
INFO - 2016-10-09 16:46:16 --> Model Class Initialized
ERROR - 2016-10-09 16:46:16 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-10-09 16:46:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 16:46:17 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 16:46:17 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 16:46:17 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-10-09 16:46:17 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 16:46:17 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 16:46:17 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:17 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:17 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:17 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:17 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:17 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:17 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:17 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:17 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:17 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:17 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:17 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:17 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:17 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:17 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:17 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:17 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:17 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:17 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:17 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:17 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:18 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:18 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:18 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:18 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:18 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:18 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:18 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:18 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:18 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:18 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:18 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:18 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:18 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:18 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:18 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:18 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:18 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:18 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:18 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:18 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:18 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:18 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:18 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:18 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:18 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:18 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:18 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:18 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:18 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:18 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:18 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:18 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:18 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:18 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:19 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:19 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:19 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:19 --> Database Driver Class Initialized
DEBUG - 2016-10-09 16:46:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 16:46:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 16:46:19 --> Final output sent to browser
DEBUG - 2016-10-09 16:46:19 --> Total execution time: 3.0195
INFO - 2016-10-09 16:46:19 --> Config Class Initialized
INFO - 2016-10-09 16:46:19 --> Hooks Class Initialized
DEBUG - 2016-10-09 16:46:19 --> UTF-8 Support Enabled
INFO - 2016-10-09 16:46:19 --> Utf8 Class Initialized
INFO - 2016-10-09 16:46:19 --> URI Class Initialized
INFO - 2016-10-09 16:46:19 --> Router Class Initialized
INFO - 2016-10-09 16:46:19 --> Output Class Initialized
INFO - 2016-10-09 16:46:19 --> Security Class Initialized
DEBUG - 2016-10-09 16:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 16:46:19 --> Input Class Initialized
INFO - 2016-10-09 16:46:19 --> Language Class Initialized
INFO - 2016-10-09 16:46:19 --> Language Class Initialized
INFO - 2016-10-09 16:46:19 --> Config Class Initialized
INFO - 2016-10-09 16:46:19 --> Loader Class Initialized
INFO - 2016-10-09 16:46:19 --> Helper loaded: url_helper
INFO - 2016-10-09 16:46:19 --> Database Driver Class Initialized
INFO - 2016-10-09 16:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 16:46:19 --> Controller Class Initialized
DEBUG - 2016-10-09 16:46:19 --> login MX_Controller Initialized
INFO - 2016-10-09 16:46:19 --> Model Class Initialized
INFO - 2016-10-09 16:46:19 --> Model Class Initialized
DEBUG - 2016-10-09 16:46:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/login.php
INFO - 2016-10-09 16:46:19 --> Final output sent to browser
DEBUG - 2016-10-09 16:46:19 --> Total execution time: 0.6261
INFO - 2016-10-09 16:48:10 --> Config Class Initialized
INFO - 2016-10-09 16:48:10 --> Hooks Class Initialized
DEBUG - 2016-10-09 16:48:10 --> UTF-8 Support Enabled
INFO - 2016-10-09 16:48:10 --> Utf8 Class Initialized
INFO - 2016-10-09 16:48:10 --> URI Class Initialized
INFO - 2016-10-09 16:48:10 --> Router Class Initialized
INFO - 2016-10-09 16:48:10 --> Output Class Initialized
INFO - 2016-10-09 16:48:10 --> Security Class Initialized
DEBUG - 2016-10-09 16:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 16:48:10 --> Input Class Initialized
INFO - 2016-10-09 16:48:10 --> Language Class Initialized
INFO - 2016-10-09 16:48:10 --> Language Class Initialized
INFO - 2016-10-09 16:48:10 --> Config Class Initialized
INFO - 2016-10-09 16:48:10 --> Loader Class Initialized
INFO - 2016-10-09 16:48:10 --> Helper loaded: url_helper
INFO - 2016-10-09 16:48:10 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 16:48:11 --> Controller Class Initialized
DEBUG - 2016-10-09 16:48:11 --> login MX_Controller Initialized
INFO - 2016-10-09 16:48:11 --> Model Class Initialized
INFO - 2016-10-09 16:48:11 --> Model Class Initialized
INFO - 2016-10-09 16:48:11 --> Final output sent to browser
DEBUG - 2016-10-09 16:48:11 --> Total execution time: 0.4904
INFO - 2016-10-09 16:48:11 --> Config Class Initialized
INFO - 2016-10-09 16:48:11 --> Hooks Class Initialized
DEBUG - 2016-10-09 16:48:11 --> UTF-8 Support Enabled
INFO - 2016-10-09 16:48:11 --> Utf8 Class Initialized
INFO - 2016-10-09 16:48:11 --> URI Class Initialized
INFO - 2016-10-09 16:48:11 --> Router Class Initialized
INFO - 2016-10-09 16:48:11 --> Output Class Initialized
INFO - 2016-10-09 16:48:11 --> Security Class Initialized
DEBUG - 2016-10-09 16:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 16:48:11 --> Input Class Initialized
INFO - 2016-10-09 16:48:11 --> Language Class Initialized
INFO - 2016-10-09 16:48:11 --> Language Class Initialized
INFO - 2016-10-09 16:48:11 --> Config Class Initialized
INFO - 2016-10-09 16:48:11 --> Loader Class Initialized
INFO - 2016-10-09 16:48:11 --> Helper loaded: url_helper
INFO - 2016-10-09 16:48:11 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 16:48:11 --> Controller Class Initialized
DEBUG - 2016-10-09 16:48:11 --> Index MX_Controller Initialized
INFO - 2016-10-09 16:48:11 --> Model Class Initialized
INFO - 2016-10-09 16:48:11 --> Model Class Initialized
ERROR - 2016-10-09 16:48:11 --> Unable to delete cache file for admin/index
DEBUG - 2016-10-09 16:48:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 16:48:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 16:48:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 16:48:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/dashboard.php
DEBUG - 2016-10-09 16:48:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 16:48:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 16:48:12 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:12 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:12 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:12 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:12 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:12 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:12 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:12 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:12 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:12 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:12 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:12 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:12 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:12 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:12 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:12 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:12 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:12 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:12 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:12 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:12 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:12 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:12 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:12 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:12 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:12 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:12 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:12 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:12 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:12 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:12 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:13 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:13 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:13 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:13 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:13 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:13 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:13 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:13 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:13 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:13 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:13 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:13 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:13 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:13 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:13 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:13 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:13 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:13 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:13 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:13 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:13 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:13 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:13 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:13 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:13 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:13 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:13 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:13 --> Database Driver Class Initialized
DEBUG - 2016-10-09 16:48:13 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 16:48:13 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 16:48:13 --> Final output sent to browser
DEBUG - 2016-10-09 16:48:13 --> Total execution time: 2.6414
INFO - 2016-10-09 16:48:21 --> Config Class Initialized
INFO - 2016-10-09 16:48:21 --> Hooks Class Initialized
DEBUG - 2016-10-09 16:48:21 --> UTF-8 Support Enabled
INFO - 2016-10-09 16:48:21 --> Utf8 Class Initialized
INFO - 2016-10-09 16:48:21 --> URI Class Initialized
INFO - 2016-10-09 16:48:21 --> Router Class Initialized
INFO - 2016-10-09 16:48:21 --> Output Class Initialized
INFO - 2016-10-09 16:48:21 --> Security Class Initialized
DEBUG - 2016-10-09 16:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 16:48:21 --> Input Class Initialized
INFO - 2016-10-09 16:48:21 --> Language Class Initialized
INFO - 2016-10-09 16:48:21 --> Language Class Initialized
INFO - 2016-10-09 16:48:21 --> Config Class Initialized
INFO - 2016-10-09 16:48:21 --> Loader Class Initialized
INFO - 2016-10-09 16:48:21 --> Helper loaded: url_helper
INFO - 2016-10-09 16:48:21 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 16:48:21 --> Controller Class Initialized
DEBUG - 2016-10-09 16:48:21 --> Index MX_Controller Initialized
INFO - 2016-10-09 16:48:21 --> Model Class Initialized
INFO - 2016-10-09 16:48:21 --> Model Class Initialized
ERROR - 2016-10-09 16:48:21 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-10-09 16:48:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 16:48:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 16:48:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 16:48:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-10-09 16:48:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 16:48:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 16:48:21 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:21 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:21 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:21 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:21 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:22 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:22 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:22 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:22 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:22 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:22 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:22 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:22 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:22 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:22 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:22 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:22 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:22 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:22 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:22 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:22 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:22 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:22 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:22 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:22 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:22 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:22 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:22 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:22 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:22 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:23 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:23 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:23 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:23 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:23 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:23 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:23 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:23 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:23 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:23 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:23 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:23 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:23 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:23 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:23 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:23 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:23 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:23 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:23 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:23 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:23 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:23 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:23 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:23 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:23 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:23 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:23 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:24 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:24 --> Database Driver Class Initialized
DEBUG - 2016-10-09 16:48:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 16:48:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 16:48:24 --> Final output sent to browser
DEBUG - 2016-10-09 16:48:24 --> Total execution time: 3.0557
INFO - 2016-10-09 16:48:28 --> Config Class Initialized
INFO - 2016-10-09 16:48:29 --> Hooks Class Initialized
DEBUG - 2016-10-09 16:48:29 --> UTF-8 Support Enabled
INFO - 2016-10-09 16:48:29 --> Utf8 Class Initialized
INFO - 2016-10-09 16:48:29 --> URI Class Initialized
INFO - 2016-10-09 16:48:29 --> Router Class Initialized
INFO - 2016-10-09 16:48:29 --> Output Class Initialized
INFO - 2016-10-09 16:48:29 --> Security Class Initialized
DEBUG - 2016-10-09 16:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 16:48:29 --> Input Class Initialized
INFO - 2016-10-09 16:48:29 --> Language Class Initialized
INFO - 2016-10-09 16:48:29 --> Language Class Initialized
INFO - 2016-10-09 16:48:29 --> Config Class Initialized
INFO - 2016-10-09 16:48:29 --> Loader Class Initialized
INFO - 2016-10-09 16:48:29 --> Helper loaded: url_helper
INFO - 2016-10-09 16:48:29 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 16:48:29 --> Controller Class Initialized
DEBUG - 2016-10-09 16:48:29 --> Index MX_Controller Initialized
INFO - 2016-10-09 16:48:29 --> Model Class Initialized
INFO - 2016-10-09 16:48:29 --> Model Class Initialized
ERROR - 2016-10-09 16:48:29 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-09 16:48:29 --> Anggota MX_Controller Initialized
INFO - 2016-10-09 16:48:29 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:29 --> Final output sent to browser
DEBUG - 2016-10-09 16:48:29 --> Total execution time: 0.8083
INFO - 2016-10-09 16:48:32 --> Config Class Initialized
INFO - 2016-10-09 16:48:32 --> Hooks Class Initialized
DEBUG - 2016-10-09 16:48:32 --> UTF-8 Support Enabled
INFO - 2016-10-09 16:48:32 --> Utf8 Class Initialized
INFO - 2016-10-09 16:48:32 --> URI Class Initialized
INFO - 2016-10-09 16:48:32 --> Router Class Initialized
INFO - 2016-10-09 16:48:32 --> Output Class Initialized
INFO - 2016-10-09 16:48:32 --> Security Class Initialized
DEBUG - 2016-10-09 16:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 16:48:32 --> Input Class Initialized
INFO - 2016-10-09 16:48:32 --> Language Class Initialized
INFO - 2016-10-09 16:48:32 --> Language Class Initialized
INFO - 2016-10-09 16:48:32 --> Config Class Initialized
INFO - 2016-10-09 16:48:32 --> Loader Class Initialized
INFO - 2016-10-09 16:48:32 --> Helper loaded: url_helper
INFO - 2016-10-09 16:48:32 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 16:48:33 --> Controller Class Initialized
DEBUG - 2016-10-09 16:48:33 --> Index MX_Controller Initialized
INFO - 2016-10-09 16:48:33 --> Model Class Initialized
INFO - 2016-10-09 16:48:33 --> Model Class Initialized
ERROR - 2016-10-09 16:48:33 --> Unable to delete cache file for admin/index/tutup_angsuran
DEBUG - 2016-10-09 16:48:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 16:48:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 16:48:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 16:48:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_tutup_angsuran.php
DEBUG - 2016-10-09 16:48:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 16:48:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 16:48:33 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:33 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:33 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:33 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:33 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:33 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:33 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:33 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:33 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:33 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:33 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:33 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:33 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:33 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:33 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:33 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:33 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:33 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:34 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:34 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:34 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:34 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:34 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:34 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:34 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:34 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:34 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:34 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:34 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:34 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:34 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:34 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:34 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:34 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:34 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:34 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:34 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:34 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:34 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:34 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:34 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:34 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:34 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:34 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:34 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:34 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:34 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:34 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:35 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:35 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:35 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:35 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:35 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:35 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:35 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:35 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:35 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:35 --> Database Driver Class Initialized
INFO - 2016-10-09 16:48:35 --> Database Driver Class Initialized
DEBUG - 2016-10-09 16:48:35 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 16:48:35 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 16:48:35 --> Final output sent to browser
DEBUG - 2016-10-09 16:48:35 --> Total execution time: 2.9421
INFO - 2016-10-09 17:46:21 --> Config Class Initialized
INFO - 2016-10-09 17:46:21 --> Hooks Class Initialized
DEBUG - 2016-10-09 17:46:21 --> UTF-8 Support Enabled
INFO - 2016-10-09 17:46:21 --> Utf8 Class Initialized
INFO - 2016-10-09 17:46:21 --> URI Class Initialized
INFO - 2016-10-09 17:46:21 --> Router Class Initialized
INFO - 2016-10-09 17:46:21 --> Output Class Initialized
INFO - 2016-10-09 17:46:21 --> Security Class Initialized
DEBUG - 2016-10-09 17:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 17:46:21 --> Input Class Initialized
INFO - 2016-10-09 17:46:21 --> Language Class Initialized
INFO - 2016-10-09 17:46:21 --> Language Class Initialized
INFO - 2016-10-09 17:46:21 --> Config Class Initialized
INFO - 2016-10-09 17:46:21 --> Loader Class Initialized
INFO - 2016-10-09 17:46:21 --> Helper loaded: url_helper
INFO - 2016-10-09 17:46:21 --> Database Driver Class Initialized
INFO - 2016-10-09 17:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 17:46:21 --> Controller Class Initialized
DEBUG - 2016-10-09 17:46:21 --> Index MX_Controller Initialized
INFO - 2016-10-09 17:46:21 --> Model Class Initialized
INFO - 2016-10-09 17:46:22 --> Model Class Initialized
ERROR - 2016-10-09 17:46:22 --> Unable to delete cache file for admin/index/getDetailLunas
INFO - 2016-10-09 17:46:22 --> Database Driver Class Initialized
INFO - 2016-10-09 17:46:22 --> Final output sent to browser
DEBUG - 2016-10-09 17:46:22 --> Total execution time: 0.6406
INFO - 2016-10-09 17:46:27 --> Config Class Initialized
INFO - 2016-10-09 17:46:27 --> Hooks Class Initialized
DEBUG - 2016-10-09 17:46:27 --> UTF-8 Support Enabled
INFO - 2016-10-09 17:46:27 --> Utf8 Class Initialized
INFO - 2016-10-09 17:46:27 --> URI Class Initialized
INFO - 2016-10-09 17:46:27 --> Router Class Initialized
INFO - 2016-10-09 17:46:27 --> Output Class Initialized
INFO - 2016-10-09 17:46:27 --> Security Class Initialized
DEBUG - 2016-10-09 17:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 17:46:27 --> Input Class Initialized
INFO - 2016-10-09 17:46:27 --> Language Class Initialized
INFO - 2016-10-09 17:46:27 --> Language Class Initialized
INFO - 2016-10-09 17:46:27 --> Config Class Initialized
INFO - 2016-10-09 17:46:27 --> Loader Class Initialized
INFO - 2016-10-09 17:46:27 --> Helper loaded: url_helper
INFO - 2016-10-09 17:46:27 --> Database Driver Class Initialized
INFO - 2016-10-09 17:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 17:46:27 --> Controller Class Initialized
DEBUG - 2016-10-09 17:46:27 --> Index MX_Controller Initialized
INFO - 2016-10-09 17:46:28 --> Model Class Initialized
INFO - 2016-10-09 17:46:28 --> Model Class Initialized
ERROR - 2016-10-09 17:46:28 --> Unable to delete cache file for admin/index/do_lunas
INFO - 2016-10-09 17:46:28 --> Database Driver Class Initialized
INFO - 2016-10-09 17:46:28 --> Database Driver Class Initialized
INFO - 2016-10-09 17:46:28 --> Database Driver Class Initialized
INFO - 2016-10-09 17:46:28 --> Database Driver Class Initialized
INFO - 2016-10-09 17:46:28 --> Database Driver Class Initialized
INFO - 2016-10-09 17:46:28 --> Database Driver Class Initialized
INFO - 2016-10-09 17:46:28 --> Database Driver Class Initialized
INFO - 2016-10-09 17:46:28 --> Database Driver Class Initialized
INFO - 2016-10-09 17:46:28 --> Database Driver Class Initialized
INFO - 2016-10-09 17:46:28 --> Database Driver Class Initialized
INFO - 2016-10-09 17:46:28 --> Database Driver Class Initialized
INFO - 2016-10-09 17:46:28 --> Database Driver Class Initialized
INFO - 2016-10-09 17:46:29 --> Database Driver Class Initialized
INFO - 2016-10-09 17:46:29 --> Database Driver Class Initialized
INFO - 2016-10-09 17:46:29 --> Database Driver Class Initialized
INFO - 2016-10-09 17:46:29 --> Database Driver Class Initialized
INFO - 2016-10-09 17:46:29 --> Final output sent to browser
DEBUG - 2016-10-09 17:46:29 --> Total execution time: 1.9031
INFO - 2016-10-09 17:46:33 --> Config Class Initialized
INFO - 2016-10-09 17:46:33 --> Hooks Class Initialized
DEBUG - 2016-10-09 17:46:33 --> UTF-8 Support Enabled
INFO - 2016-10-09 17:46:33 --> Utf8 Class Initialized
INFO - 2016-10-09 17:46:33 --> URI Class Initialized
INFO - 2016-10-09 17:46:33 --> Router Class Initialized
INFO - 2016-10-09 17:46:33 --> Output Class Initialized
INFO - 2016-10-09 17:46:33 --> Security Class Initialized
DEBUG - 2016-10-09 17:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 17:46:33 --> Input Class Initialized
INFO - 2016-10-09 17:46:33 --> Language Class Initialized
INFO - 2016-10-09 17:46:33 --> Language Class Initialized
INFO - 2016-10-09 17:46:33 --> Config Class Initialized
INFO - 2016-10-09 17:46:33 --> Loader Class Initialized
INFO - 2016-10-09 17:46:33 --> Helper loaded: url_helper
INFO - 2016-10-09 17:46:33 --> Database Driver Class Initialized
INFO - 2016-10-09 17:46:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 17:46:33 --> Controller Class Initialized
DEBUG - 2016-10-09 17:46:33 --> Index MX_Controller Initialized
INFO - 2016-10-09 17:46:33 --> Model Class Initialized
INFO - 2016-10-09 17:46:33 --> Model Class Initialized
ERROR - 2016-10-09 17:46:33 --> Unable to delete cache file for admin/index/getDetailLunas
INFO - 2016-10-09 17:46:34 --> Final output sent to browser
DEBUG - 2016-10-09 17:46:34 --> Total execution time: 0.6532
INFO - 2016-10-09 17:51:29 --> Config Class Initialized
INFO - 2016-10-09 17:51:29 --> Hooks Class Initialized
DEBUG - 2016-10-09 17:51:29 --> UTF-8 Support Enabled
INFO - 2016-10-09 17:51:29 --> Utf8 Class Initialized
INFO - 2016-10-09 17:51:29 --> URI Class Initialized
INFO - 2016-10-09 17:51:29 --> Router Class Initialized
INFO - 2016-10-09 17:51:29 --> Output Class Initialized
INFO - 2016-10-09 17:51:29 --> Security Class Initialized
DEBUG - 2016-10-09 17:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 17:51:29 --> Input Class Initialized
INFO - 2016-10-09 17:51:29 --> Language Class Initialized
INFO - 2016-10-09 17:51:29 --> Language Class Initialized
INFO - 2016-10-09 17:51:29 --> Config Class Initialized
INFO - 2016-10-09 17:51:29 --> Loader Class Initialized
INFO - 2016-10-09 17:51:29 --> Helper loaded: url_helper
INFO - 2016-10-09 17:51:29 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 17:51:29 --> Controller Class Initialized
DEBUG - 2016-10-09 17:51:29 --> Index MX_Controller Initialized
INFO - 2016-10-09 17:51:29 --> Model Class Initialized
INFO - 2016-10-09 17:51:29 --> Model Class Initialized
ERROR - 2016-10-09 17:51:29 --> Unable to delete cache file for admin/index/getDetailLunas
INFO - 2016-10-09 17:51:29 --> Final output sent to browser
DEBUG - 2016-10-09 17:51:29 --> Total execution time: 0.6539
INFO - 2016-10-09 17:51:31 --> Config Class Initialized
INFO - 2016-10-09 17:51:31 --> Hooks Class Initialized
DEBUG - 2016-10-09 17:51:31 --> UTF-8 Support Enabled
INFO - 2016-10-09 17:51:31 --> Utf8 Class Initialized
INFO - 2016-10-09 17:51:31 --> URI Class Initialized
INFO - 2016-10-09 17:51:31 --> Router Class Initialized
INFO - 2016-10-09 17:51:31 --> Output Class Initialized
INFO - 2016-10-09 17:51:31 --> Security Class Initialized
DEBUG - 2016-10-09 17:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 17:51:31 --> Input Class Initialized
INFO - 2016-10-09 17:51:31 --> Language Class Initialized
INFO - 2016-10-09 17:51:31 --> Language Class Initialized
INFO - 2016-10-09 17:51:31 --> Config Class Initialized
INFO - 2016-10-09 17:51:31 --> Loader Class Initialized
INFO - 2016-10-09 17:51:32 --> Helper loaded: url_helper
INFO - 2016-10-09 17:51:32 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 17:51:32 --> Controller Class Initialized
DEBUG - 2016-10-09 17:51:32 --> Index MX_Controller Initialized
INFO - 2016-10-09 17:51:32 --> Model Class Initialized
INFO - 2016-10-09 17:51:32 --> Model Class Initialized
ERROR - 2016-10-09 17:51:32 --> Unable to delete cache file for admin/index/data_peminjam
DEBUG - 2016-10-09 17:51:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 17:51:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 17:51:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 17:51:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_peminjam.php
DEBUG - 2016-10-09 17:51:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 17:51:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 17:51:32 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:32 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:32 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:32 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:32 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:32 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:32 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:32 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:32 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:32 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:32 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:32 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:32 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:32 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:32 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:33 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:33 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:33 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:33 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:33 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:33 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:33 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:33 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:33 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:33 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:33 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:33 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:33 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:33 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:33 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:33 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:33 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:33 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:33 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:33 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:34 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:34 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:34 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:34 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:34 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:34 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:34 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:34 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:34 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:34 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:34 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:34 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:34 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:34 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:34 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:34 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:34 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:34 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:34 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:34 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:34 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:34 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:34 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:34 --> Database Driver Class Initialized
DEBUG - 2016-10-09 17:51:34 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 17:51:34 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 17:51:34 --> Final output sent to browser
DEBUG - 2016-10-09 17:51:34 --> Total execution time: 3.3681
INFO - 2016-10-09 17:51:42 --> Config Class Initialized
INFO - 2016-10-09 17:51:42 --> Hooks Class Initialized
DEBUG - 2016-10-09 17:51:42 --> UTF-8 Support Enabled
INFO - 2016-10-09 17:51:42 --> Utf8 Class Initialized
INFO - 2016-10-09 17:51:42 --> URI Class Initialized
INFO - 2016-10-09 17:51:42 --> Router Class Initialized
INFO - 2016-10-09 17:51:42 --> Output Class Initialized
INFO - 2016-10-09 17:51:42 --> Security Class Initialized
DEBUG - 2016-10-09 17:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 17:51:42 --> Input Class Initialized
INFO - 2016-10-09 17:51:42 --> Language Class Initialized
INFO - 2016-10-09 17:51:42 --> Language Class Initialized
INFO - 2016-10-09 17:51:42 --> Config Class Initialized
INFO - 2016-10-09 17:51:42 --> Loader Class Initialized
INFO - 2016-10-09 17:51:42 --> Helper loaded: url_helper
INFO - 2016-10-09 17:51:42 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 17:51:42 --> Controller Class Initialized
DEBUG - 2016-10-09 17:51:42 --> Index MX_Controller Initialized
INFO - 2016-10-09 17:51:42 --> Model Class Initialized
INFO - 2016-10-09 17:51:42 --> Model Class Initialized
ERROR - 2016-10-09 17:51:42 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-10-09 17:51:42 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 17:51:42 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 17:51:42 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 17:51:42 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-10-09 17:51:42 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 17:51:42 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 17:51:42 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:42 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:43 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:43 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:43 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:43 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:43 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:43 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:43 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:43 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:43 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:43 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:43 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:43 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:43 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:43 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:43 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:43 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:43 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:43 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:43 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:43 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:43 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:43 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:43 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:43 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:43 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:43 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:44 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:44 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:44 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:44 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:44 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:44 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:44 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:44 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:44 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:44 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:44 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:44 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:44 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:44 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:44 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:44 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:44 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:44 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:44 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:44 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:44 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:44 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:45 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:45 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:45 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:45 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:45 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:45 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:45 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:45 --> Database Driver Class Initialized
INFO - 2016-10-09 17:51:45 --> Database Driver Class Initialized
DEBUG - 2016-10-09 17:51:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 17:51:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 17:51:45 --> Final output sent to browser
DEBUG - 2016-10-09 17:51:45 --> Total execution time: 3.3732
INFO - 2016-10-09 17:52:18 --> Config Class Initialized
INFO - 2016-10-09 17:52:18 --> Hooks Class Initialized
DEBUG - 2016-10-09 17:52:18 --> UTF-8 Support Enabled
INFO - 2016-10-09 17:52:18 --> Utf8 Class Initialized
INFO - 2016-10-09 17:52:18 --> URI Class Initialized
INFO - 2016-10-09 17:52:18 --> Router Class Initialized
INFO - 2016-10-09 17:52:18 --> Output Class Initialized
INFO - 2016-10-09 17:52:19 --> Security Class Initialized
DEBUG - 2016-10-09 17:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 17:52:19 --> Input Class Initialized
INFO - 2016-10-09 17:52:19 --> Language Class Initialized
INFO - 2016-10-09 17:52:19 --> Language Class Initialized
INFO - 2016-10-09 17:52:19 --> Config Class Initialized
INFO - 2016-10-09 17:52:19 --> Loader Class Initialized
INFO - 2016-10-09 17:52:19 --> Helper loaded: url_helper
INFO - 2016-10-09 17:52:19 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 17:52:19 --> Controller Class Initialized
DEBUG - 2016-10-09 17:52:19 --> Index MX_Controller Initialized
INFO - 2016-10-09 17:52:19 --> Model Class Initialized
INFO - 2016-10-09 17:52:19 --> Model Class Initialized
ERROR - 2016-10-09 17:52:19 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-09 17:52:19 --> Anggota MX_Controller Initialized
INFO - 2016-10-09 17:52:19 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:19 --> Final output sent to browser
DEBUG - 2016-10-09 17:52:19 --> Total execution time: 0.8313
INFO - 2016-10-09 17:52:21 --> Config Class Initialized
INFO - 2016-10-09 17:52:21 --> Hooks Class Initialized
DEBUG - 2016-10-09 17:52:21 --> UTF-8 Support Enabled
INFO - 2016-10-09 17:52:21 --> Utf8 Class Initialized
INFO - 2016-10-09 17:52:21 --> URI Class Initialized
INFO - 2016-10-09 17:52:21 --> Router Class Initialized
INFO - 2016-10-09 17:52:22 --> Output Class Initialized
INFO - 2016-10-09 17:52:22 --> Security Class Initialized
DEBUG - 2016-10-09 17:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 17:52:22 --> Input Class Initialized
INFO - 2016-10-09 17:52:22 --> Language Class Initialized
INFO - 2016-10-09 17:52:22 --> Language Class Initialized
INFO - 2016-10-09 17:52:22 --> Config Class Initialized
INFO - 2016-10-09 17:52:22 --> Loader Class Initialized
INFO - 2016-10-09 17:52:22 --> Helper loaded: url_helper
INFO - 2016-10-09 17:52:22 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 17:52:22 --> Controller Class Initialized
DEBUG - 2016-10-09 17:52:22 --> Index MX_Controller Initialized
INFO - 2016-10-09 17:52:22 --> Model Class Initialized
INFO - 2016-10-09 17:52:22 --> Model Class Initialized
ERROR - 2016-10-09 17:52:22 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-10-09 17:52:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 17:52:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 17:52:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 17:52:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-10-09 17:52:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 17:52:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 17:52:22 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:22 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:22 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:22 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:22 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:22 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:22 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:22 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:22 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:22 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:22 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:23 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:23 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:23 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:23 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:23 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:23 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:23 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:23 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:23 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:23 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:23 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:23 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:23 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:23 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:23 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:23 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:23 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:23 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:23 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:23 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:23 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:23 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:23 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:23 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:23 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:23 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:23 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:23 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:23 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:23 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:24 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:24 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:24 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:24 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:24 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:24 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:24 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:24 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:24 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:24 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:24 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:24 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:24 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:24 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:24 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:24 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:24 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:24 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:24 --> Database Driver Class Initialized
DEBUG - 2016-10-09 17:52:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 17:52:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 17:52:24 --> Final output sent to browser
DEBUG - 2016-10-09 17:52:24 --> Total execution time: 3.0081
INFO - 2016-10-09 17:52:33 --> Config Class Initialized
INFO - 2016-10-09 17:52:33 --> Hooks Class Initialized
DEBUG - 2016-10-09 17:52:33 --> UTF-8 Support Enabled
INFO - 2016-10-09 17:52:33 --> Utf8 Class Initialized
INFO - 2016-10-09 17:52:33 --> URI Class Initialized
INFO - 2016-10-09 17:52:33 --> Router Class Initialized
INFO - 2016-10-09 17:52:33 --> Output Class Initialized
INFO - 2016-10-09 17:52:33 --> Security Class Initialized
DEBUG - 2016-10-09 17:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 17:52:34 --> Input Class Initialized
INFO - 2016-10-09 17:52:34 --> Language Class Initialized
INFO - 2016-10-09 17:52:34 --> Language Class Initialized
INFO - 2016-10-09 17:52:34 --> Config Class Initialized
INFO - 2016-10-09 17:52:34 --> Loader Class Initialized
INFO - 2016-10-09 17:52:34 --> Helper loaded: url_helper
INFO - 2016-10-09 17:52:34 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 17:52:34 --> Controller Class Initialized
DEBUG - 2016-10-09 17:52:34 --> Index MX_Controller Initialized
INFO - 2016-10-09 17:52:34 --> Model Class Initialized
INFO - 2016-10-09 17:52:34 --> Model Class Initialized
ERROR - 2016-10-09 17:52:34 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-10-09 17:52:34 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 17:52:34 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 17:52:34 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 17:52:34 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-10-09 17:52:34 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 17:52:34 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 17:52:34 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:34 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:34 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:34 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:34 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:34 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:34 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:35 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:35 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:35 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:35 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:35 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:35 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:35 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:35 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:35 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:35 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:35 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:35 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:35 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:35 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:35 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:35 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:35 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:35 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:35 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:35 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:35 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:35 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:35 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:35 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:35 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:36 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:36 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:36 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:36 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:36 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:36 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:36 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:36 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:36 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:36 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:36 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:36 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:36 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:36 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:36 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:36 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:36 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:36 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:36 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:36 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:36 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:36 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:36 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:36 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:36 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:36 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:36 --> Database Driver Class Initialized
DEBUG - 2016-10-09 17:52:37 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 17:52:37 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 17:52:37 --> Final output sent to browser
DEBUG - 2016-10-09 17:52:37 --> Total execution time: 3.4284
INFO - 2016-10-09 17:52:43 --> Config Class Initialized
INFO - 2016-10-09 17:52:43 --> Hooks Class Initialized
DEBUG - 2016-10-09 17:52:43 --> UTF-8 Support Enabled
INFO - 2016-10-09 17:52:43 --> Utf8 Class Initialized
INFO - 2016-10-09 17:52:43 --> URI Class Initialized
INFO - 2016-10-09 17:52:43 --> Router Class Initialized
INFO - 2016-10-09 17:52:43 --> Output Class Initialized
INFO - 2016-10-09 17:52:43 --> Security Class Initialized
DEBUG - 2016-10-09 17:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 17:52:44 --> Input Class Initialized
INFO - 2016-10-09 17:52:44 --> Language Class Initialized
INFO - 2016-10-09 17:52:44 --> Language Class Initialized
INFO - 2016-10-09 17:52:44 --> Config Class Initialized
INFO - 2016-10-09 17:52:44 --> Loader Class Initialized
INFO - 2016-10-09 17:52:44 --> Helper loaded: url_helper
INFO - 2016-10-09 17:52:44 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 17:52:44 --> Controller Class Initialized
DEBUG - 2016-10-09 17:52:44 --> Index MX_Controller Initialized
INFO - 2016-10-09 17:52:44 --> Model Class Initialized
INFO - 2016-10-09 17:52:44 --> Model Class Initialized
ERROR - 2016-10-09 17:52:44 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-09 17:52:44 --> Anggota MX_Controller Initialized
INFO - 2016-10-09 17:52:44 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:44 --> Final output sent to browser
DEBUG - 2016-10-09 17:52:44 --> Total execution time: 0.7111
INFO - 2016-10-09 17:52:46 --> Config Class Initialized
INFO - 2016-10-09 17:52:47 --> Hooks Class Initialized
DEBUG - 2016-10-09 17:52:47 --> UTF-8 Support Enabled
INFO - 2016-10-09 17:52:47 --> Utf8 Class Initialized
INFO - 2016-10-09 17:52:47 --> URI Class Initialized
INFO - 2016-10-09 17:52:47 --> Router Class Initialized
INFO - 2016-10-09 17:52:47 --> Output Class Initialized
INFO - 2016-10-09 17:52:47 --> Security Class Initialized
DEBUG - 2016-10-09 17:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 17:52:47 --> Input Class Initialized
INFO - 2016-10-09 17:52:47 --> Language Class Initialized
INFO - 2016-10-09 17:52:47 --> Language Class Initialized
INFO - 2016-10-09 17:52:47 --> Config Class Initialized
INFO - 2016-10-09 17:52:47 --> Loader Class Initialized
INFO - 2016-10-09 17:52:47 --> Helper loaded: url_helper
INFO - 2016-10-09 17:52:47 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 17:52:47 --> Controller Class Initialized
DEBUG - 2016-10-09 17:52:47 --> Index MX_Controller Initialized
INFO - 2016-10-09 17:52:47 --> Model Class Initialized
INFO - 2016-10-09 17:52:47 --> Model Class Initialized
ERROR - 2016-10-09 17:52:47 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-10-09 17:52:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 17:52:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 17:52:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 17:52:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_umum.php
DEBUG - 2016-10-09 17:52:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 17:52:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 17:52:47 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:47 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:47 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:47 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:47 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:47 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:49 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:49 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:49 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:49 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:49 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:49 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:49 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:49 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:49 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:49 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:49 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:49 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:49 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:49 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:49 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:49 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:49 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:49 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:49 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:49 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:49 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:49 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:49 --> Database Driver Class Initialized
INFO - 2016-10-09 17:52:49 --> Database Driver Class Initialized
DEBUG - 2016-10-09 17:52:49 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 17:52:49 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 17:52:49 --> Final output sent to browser
DEBUG - 2016-10-09 17:52:50 --> Total execution time: 2.9840
INFO - 2016-10-09 17:53:01 --> Config Class Initialized
INFO - 2016-10-09 17:53:01 --> Hooks Class Initialized
DEBUG - 2016-10-09 17:53:01 --> UTF-8 Support Enabled
INFO - 2016-10-09 17:53:01 --> Utf8 Class Initialized
INFO - 2016-10-09 17:53:01 --> URI Class Initialized
INFO - 2016-10-09 17:53:01 --> Router Class Initialized
INFO - 2016-10-09 17:53:01 --> Output Class Initialized
INFO - 2016-10-09 17:53:01 --> Security Class Initialized
DEBUG - 2016-10-09 17:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 17:53:01 --> Input Class Initialized
INFO - 2016-10-09 17:53:01 --> Language Class Initialized
INFO - 2016-10-09 17:53:01 --> Language Class Initialized
INFO - 2016-10-09 17:53:01 --> Config Class Initialized
INFO - 2016-10-09 17:53:01 --> Loader Class Initialized
INFO - 2016-10-09 17:53:01 --> Helper loaded: url_helper
INFO - 2016-10-09 17:53:01 --> Database Driver Class Initialized
INFO - 2016-10-09 17:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 17:53:01 --> Controller Class Initialized
DEBUG - 2016-10-09 17:53:01 --> Index MX_Controller Initialized
INFO - 2016-10-09 17:53:01 --> Model Class Initialized
INFO - 2016-10-09 17:53:01 --> Model Class Initialized
ERROR - 2016-10-09 17:53:01 --> Unable to delete cache file for admin/index/do_ajukan_pinjaman
INFO - 2016-10-09 17:53:01 --> Database Driver Class Initialized
INFO - 2016-10-09 17:53:02 --> Database Driver Class Initialized
INFO - 2016-10-09 17:53:02 --> Final output sent to browser
DEBUG - 2016-10-09 17:53:02 --> Total execution time: 0.8136
INFO - 2016-10-09 17:54:57 --> Config Class Initialized
INFO - 2016-10-09 17:54:57 --> Hooks Class Initialized
DEBUG - 2016-10-09 17:54:57 --> UTF-8 Support Enabled
INFO - 2016-10-09 17:54:57 --> Utf8 Class Initialized
INFO - 2016-10-09 17:54:57 --> URI Class Initialized
INFO - 2016-10-09 17:54:57 --> Router Class Initialized
INFO - 2016-10-09 17:54:57 --> Output Class Initialized
INFO - 2016-10-09 17:54:57 --> Security Class Initialized
DEBUG - 2016-10-09 17:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 17:54:57 --> Input Class Initialized
INFO - 2016-10-09 17:54:57 --> Language Class Initialized
INFO - 2016-10-09 17:54:58 --> Language Class Initialized
INFO - 2016-10-09 17:54:58 --> Config Class Initialized
INFO - 2016-10-09 17:54:58 --> Loader Class Initialized
INFO - 2016-10-09 17:54:58 --> Helper loaded: url_helper
INFO - 2016-10-09 17:54:58 --> Database Driver Class Initialized
INFO - 2016-10-09 17:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 17:54:58 --> Controller Class Initialized
DEBUG - 2016-10-09 17:54:58 --> Index MX_Controller Initialized
INFO - 2016-10-09 17:54:58 --> Model Class Initialized
INFO - 2016-10-09 17:54:58 --> Model Class Initialized
ERROR - 2016-10-09 17:54:58 --> Unable to delete cache file for admin/index/do_save_jaminan/sertifikat
ERROR - 2016-10-09 17:54:58 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\modules\admin\controllers\Index.php 318
INFO - 2016-10-09 17:54:58 --> Database Driver Class Initialized
INFO - 2016-10-09 17:54:58 --> Final output sent to browser
DEBUG - 2016-10-09 17:54:58 --> Total execution time: 0.8787
INFO - 2016-10-09 17:55:21 --> Config Class Initialized
INFO - 2016-10-09 17:55:21 --> Hooks Class Initialized
DEBUG - 2016-10-09 17:55:21 --> UTF-8 Support Enabled
INFO - 2016-10-09 17:55:21 --> Utf8 Class Initialized
INFO - 2016-10-09 17:55:21 --> URI Class Initialized
INFO - 2016-10-09 17:55:21 --> Router Class Initialized
INFO - 2016-10-09 17:55:21 --> Output Class Initialized
INFO - 2016-10-09 17:55:21 --> Security Class Initialized
DEBUG - 2016-10-09 17:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 17:55:21 --> Input Class Initialized
INFO - 2016-10-09 17:55:21 --> Language Class Initialized
INFO - 2016-10-09 17:55:21 --> Language Class Initialized
INFO - 2016-10-09 17:55:21 --> Config Class Initialized
INFO - 2016-10-09 17:55:21 --> Loader Class Initialized
INFO - 2016-10-09 17:55:21 --> Helper loaded: url_helper
INFO - 2016-10-09 17:55:21 --> Database Driver Class Initialized
INFO - 2016-10-09 17:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 17:55:21 --> Controller Class Initialized
DEBUG - 2016-10-09 17:55:21 --> Index MX_Controller Initialized
INFO - 2016-10-09 17:55:21 --> Model Class Initialized
INFO - 2016-10-09 17:55:21 --> Model Class Initialized
ERROR - 2016-10-09 17:55:21 --> Unable to delete cache file for admin/index/do_save_jaminan/sertifikat
ERROR - 2016-10-09 17:55:21 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\modules\admin\controllers\Index.php 318
INFO - 2016-10-09 17:55:21 --> Database Driver Class Initialized
INFO - 2016-10-09 17:55:22 --> Final output sent to browser
DEBUG - 2016-10-09 17:55:22 --> Total execution time: 1.0289
INFO - 2016-10-09 17:58:10 --> Config Class Initialized
INFO - 2016-10-09 17:58:10 --> Hooks Class Initialized
DEBUG - 2016-10-09 17:58:10 --> UTF-8 Support Enabled
INFO - 2016-10-09 17:58:10 --> Utf8 Class Initialized
INFO - 2016-10-09 17:58:10 --> URI Class Initialized
INFO - 2016-10-09 17:58:10 --> Router Class Initialized
INFO - 2016-10-09 17:58:10 --> Output Class Initialized
INFO - 2016-10-09 17:58:10 --> Security Class Initialized
DEBUG - 2016-10-09 17:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 17:58:10 --> Input Class Initialized
INFO - 2016-10-09 17:58:10 --> Language Class Initialized
INFO - 2016-10-09 17:58:10 --> Language Class Initialized
INFO - 2016-10-09 17:58:10 --> Config Class Initialized
INFO - 2016-10-09 17:58:11 --> Loader Class Initialized
INFO - 2016-10-09 17:58:11 --> Helper loaded: url_helper
INFO - 2016-10-09 17:58:11 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 17:58:11 --> Controller Class Initialized
DEBUG - 2016-10-09 17:58:11 --> Index MX_Controller Initialized
INFO - 2016-10-09 17:58:11 --> Model Class Initialized
INFO - 2016-10-09 17:58:11 --> Model Class Initialized
ERROR - 2016-10-09 17:58:11 --> Unable to delete cache file for admin/index/batal/12c6fc06c99a462375eeb3f43dfd832b08ca9e17
INFO - 2016-10-09 17:58:11 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:11 --> Final output sent to browser
DEBUG - 2016-10-09 17:58:11 --> Total execution time: 1.0402
INFO - 2016-10-09 17:58:12 --> Config Class Initialized
INFO - 2016-10-09 17:58:12 --> Hooks Class Initialized
DEBUG - 2016-10-09 17:58:12 --> UTF-8 Support Enabled
INFO - 2016-10-09 17:58:12 --> Utf8 Class Initialized
INFO - 2016-10-09 17:58:12 --> URI Class Initialized
INFO - 2016-10-09 17:58:12 --> Router Class Initialized
INFO - 2016-10-09 17:58:12 --> Output Class Initialized
INFO - 2016-10-09 17:58:12 --> Security Class Initialized
DEBUG - 2016-10-09 17:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 17:58:12 --> Input Class Initialized
INFO - 2016-10-09 17:58:12 --> Language Class Initialized
INFO - 2016-10-09 17:58:12 --> Language Class Initialized
INFO - 2016-10-09 17:58:12 --> Config Class Initialized
INFO - 2016-10-09 17:58:12 --> Loader Class Initialized
INFO - 2016-10-09 17:58:12 --> Helper loaded: url_helper
INFO - 2016-10-09 17:58:12 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 17:58:12 --> Controller Class Initialized
DEBUG - 2016-10-09 17:58:12 --> Index MX_Controller Initialized
INFO - 2016-10-09 17:58:12 --> Model Class Initialized
INFO - 2016-10-09 17:58:12 --> Model Class Initialized
ERROR - 2016-10-09 17:58:12 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-10-09 17:58:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 17:58:13 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 17:58:13 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 17:58:13 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-10-09 17:58:13 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 17:58:13 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 17:58:13 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:13 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:13 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:13 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:13 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:13 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:13 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:13 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:13 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:13 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:13 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:13 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:13 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:13 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:13 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:13 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:13 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:13 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:14 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:14 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:14 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:14 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:14 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:14 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:14 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:14 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:14 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:14 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:14 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:14 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:14 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:14 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:14 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:14 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:14 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:14 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:14 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:14 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:14 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:14 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:14 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:14 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:14 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:14 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:15 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:15 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:15 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:15 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:15 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:15 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:15 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:15 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:15 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:15 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:15 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:15 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:15 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:15 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:15 --> Database Driver Class Initialized
DEBUG - 2016-10-09 17:58:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 17:58:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 17:58:15 --> Final output sent to browser
DEBUG - 2016-10-09 17:58:15 --> Total execution time: 3.4844
INFO - 2016-10-09 17:58:28 --> Config Class Initialized
INFO - 2016-10-09 17:58:28 --> Hooks Class Initialized
DEBUG - 2016-10-09 17:58:28 --> UTF-8 Support Enabled
INFO - 2016-10-09 17:58:28 --> Utf8 Class Initialized
INFO - 2016-10-09 17:58:28 --> URI Class Initialized
INFO - 2016-10-09 17:58:28 --> Router Class Initialized
INFO - 2016-10-09 17:58:29 --> Output Class Initialized
INFO - 2016-10-09 17:58:29 --> Security Class Initialized
DEBUG - 2016-10-09 17:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 17:58:29 --> Input Class Initialized
INFO - 2016-10-09 17:58:29 --> Language Class Initialized
INFO - 2016-10-09 17:58:29 --> Language Class Initialized
INFO - 2016-10-09 17:58:29 --> Config Class Initialized
INFO - 2016-10-09 17:58:29 --> Loader Class Initialized
INFO - 2016-10-09 17:58:29 --> Helper loaded: url_helper
INFO - 2016-10-09 17:58:29 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 17:58:29 --> Controller Class Initialized
DEBUG - 2016-10-09 17:58:29 --> Index MX_Controller Initialized
INFO - 2016-10-09 17:58:29 --> Model Class Initialized
INFO - 2016-10-09 17:58:29 --> Model Class Initialized
ERROR - 2016-10-09 17:58:29 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-09 17:58:29 --> Anggota MX_Controller Initialized
INFO - 2016-10-09 17:58:29 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:29 --> Final output sent to browser
DEBUG - 2016-10-09 17:58:29 --> Total execution time: 0.7875
INFO - 2016-10-09 17:58:33 --> Config Class Initialized
INFO - 2016-10-09 17:58:33 --> Hooks Class Initialized
DEBUG - 2016-10-09 17:58:33 --> UTF-8 Support Enabled
INFO - 2016-10-09 17:58:33 --> Utf8 Class Initialized
INFO - 2016-10-09 17:58:33 --> URI Class Initialized
INFO - 2016-10-09 17:58:33 --> Router Class Initialized
INFO - 2016-10-09 17:58:33 --> Output Class Initialized
INFO - 2016-10-09 17:58:33 --> Security Class Initialized
DEBUG - 2016-10-09 17:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 17:58:33 --> Input Class Initialized
INFO - 2016-10-09 17:58:33 --> Language Class Initialized
INFO - 2016-10-09 17:58:33 --> Language Class Initialized
INFO - 2016-10-09 17:58:33 --> Config Class Initialized
INFO - 2016-10-09 17:58:34 --> Loader Class Initialized
INFO - 2016-10-09 17:58:34 --> Helper loaded: url_helper
INFO - 2016-10-09 17:58:34 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 17:58:34 --> Controller Class Initialized
DEBUG - 2016-10-09 17:58:34 --> Index MX_Controller Initialized
INFO - 2016-10-09 17:58:34 --> Model Class Initialized
INFO - 2016-10-09 17:58:34 --> Model Class Initialized
ERROR - 2016-10-09 17:58:34 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-10-09 17:58:34 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 17:58:34 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 17:58:34 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 17:58:34 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_umum.php
DEBUG - 2016-10-09 17:58:34 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 17:58:34 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 17:58:34 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:34 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:34 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:34 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:34 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:34 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:34 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:34 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:34 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:34 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:34 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:34 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:34 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:35 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:35 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:35 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:35 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:35 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:35 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:35 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:35 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:35 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:35 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:35 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:35 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:35 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:35 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:35 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:35 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:35 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:35 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:35 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:35 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:35 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:35 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:35 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:35 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:35 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:35 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:36 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:36 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:36 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:36 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:36 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:36 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:36 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:36 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:36 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:36 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:36 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:36 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:36 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:36 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:36 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:36 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:36 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:36 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:36 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:36 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:36 --> Database Driver Class Initialized
DEBUG - 2016-10-09 17:58:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 17:58:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 17:58:36 --> Final output sent to browser
DEBUG - 2016-10-09 17:58:36 --> Total execution time: 3.3374
INFO - 2016-10-09 17:58:48 --> Config Class Initialized
INFO - 2016-10-09 17:58:48 --> Hooks Class Initialized
DEBUG - 2016-10-09 17:58:48 --> UTF-8 Support Enabled
INFO - 2016-10-09 17:58:48 --> Utf8 Class Initialized
INFO - 2016-10-09 17:58:48 --> URI Class Initialized
INFO - 2016-10-09 17:58:48 --> Router Class Initialized
INFO - 2016-10-09 17:58:48 --> Output Class Initialized
INFO - 2016-10-09 17:58:48 --> Security Class Initialized
DEBUG - 2016-10-09 17:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 17:58:48 --> Input Class Initialized
INFO - 2016-10-09 17:58:48 --> Language Class Initialized
INFO - 2016-10-09 17:58:48 --> Language Class Initialized
INFO - 2016-10-09 17:58:48 --> Config Class Initialized
INFO - 2016-10-09 17:58:48 --> Loader Class Initialized
INFO - 2016-10-09 17:58:48 --> Helper loaded: url_helper
INFO - 2016-10-09 17:58:49 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 17:58:49 --> Controller Class Initialized
DEBUG - 2016-10-09 17:58:49 --> Index MX_Controller Initialized
INFO - 2016-10-09 17:58:49 --> Model Class Initialized
INFO - 2016-10-09 17:58:49 --> Model Class Initialized
ERROR - 2016-10-09 17:58:49 --> Unable to delete cache file for admin/index/do_ajukan_pinjaman
INFO - 2016-10-09 17:58:49 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:49 --> Database Driver Class Initialized
INFO - 2016-10-09 17:58:49 --> Final output sent to browser
DEBUG - 2016-10-09 17:58:49 --> Total execution time: 0.8436
INFO - 2016-10-09 17:59:08 --> Config Class Initialized
INFO - 2016-10-09 17:59:08 --> Hooks Class Initialized
DEBUG - 2016-10-09 17:59:08 --> UTF-8 Support Enabled
INFO - 2016-10-09 17:59:08 --> Utf8 Class Initialized
INFO - 2016-10-09 17:59:08 --> URI Class Initialized
INFO - 2016-10-09 17:59:08 --> Router Class Initialized
INFO - 2016-10-09 17:59:08 --> Output Class Initialized
INFO - 2016-10-09 17:59:08 --> Security Class Initialized
DEBUG - 2016-10-09 17:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 17:59:08 --> Input Class Initialized
INFO - 2016-10-09 17:59:08 --> Language Class Initialized
INFO - 2016-10-09 17:59:08 --> Language Class Initialized
INFO - 2016-10-09 17:59:09 --> Config Class Initialized
INFO - 2016-10-09 17:59:09 --> Loader Class Initialized
INFO - 2016-10-09 17:59:09 --> Helper loaded: url_helper
INFO - 2016-10-09 17:59:09 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 17:59:09 --> Controller Class Initialized
DEBUG - 2016-10-09 17:59:09 --> Index MX_Controller Initialized
INFO - 2016-10-09 17:59:09 --> Model Class Initialized
INFO - 2016-10-09 17:59:09 --> Model Class Initialized
ERROR - 2016-10-09 17:59:09 --> Unable to delete cache file for admin/index/do_save_jaminan/sertifikat
INFO - 2016-10-09 17:59:09 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:09 --> Final output sent to browser
DEBUG - 2016-10-09 17:59:09 --> Total execution time: 0.9225
INFO - 2016-10-09 17:59:45 --> Config Class Initialized
INFO - 2016-10-09 17:59:45 --> Hooks Class Initialized
DEBUG - 2016-10-09 17:59:46 --> UTF-8 Support Enabled
INFO - 2016-10-09 17:59:46 --> Utf8 Class Initialized
INFO - 2016-10-09 17:59:46 --> URI Class Initialized
INFO - 2016-10-09 17:59:46 --> Router Class Initialized
INFO - 2016-10-09 17:59:46 --> Output Class Initialized
INFO - 2016-10-09 17:59:46 --> Security Class Initialized
DEBUG - 2016-10-09 17:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 17:59:46 --> Input Class Initialized
INFO - 2016-10-09 17:59:46 --> Language Class Initialized
INFO - 2016-10-09 17:59:46 --> Language Class Initialized
INFO - 2016-10-09 17:59:46 --> Config Class Initialized
INFO - 2016-10-09 17:59:46 --> Loader Class Initialized
INFO - 2016-10-09 17:59:46 --> Helper loaded: url_helper
INFO - 2016-10-09 17:59:46 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 17:59:46 --> Controller Class Initialized
DEBUG - 2016-10-09 17:59:46 --> Index MX_Controller Initialized
INFO - 2016-10-09 17:59:46 --> Model Class Initialized
INFO - 2016-10-09 17:59:46 --> Model Class Initialized
ERROR - 2016-10-09 17:59:46 --> Unable to delete cache file for admin/index/batal/d435a6cdd786300dff204ee7c2ef942d3e9034e2
INFO - 2016-10-09 17:59:46 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:46 --> Final output sent to browser
DEBUG - 2016-10-09 17:59:46 --> Total execution time: 0.8843
INFO - 2016-10-09 17:59:46 --> Config Class Initialized
INFO - 2016-10-09 17:59:47 --> Hooks Class Initialized
DEBUG - 2016-10-09 17:59:47 --> UTF-8 Support Enabled
INFO - 2016-10-09 17:59:47 --> Utf8 Class Initialized
INFO - 2016-10-09 17:59:47 --> URI Class Initialized
INFO - 2016-10-09 17:59:47 --> Router Class Initialized
INFO - 2016-10-09 17:59:47 --> Output Class Initialized
INFO - 2016-10-09 17:59:47 --> Security Class Initialized
DEBUG - 2016-10-09 17:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 17:59:47 --> Input Class Initialized
INFO - 2016-10-09 17:59:47 --> Language Class Initialized
INFO - 2016-10-09 17:59:47 --> Language Class Initialized
INFO - 2016-10-09 17:59:47 --> Config Class Initialized
INFO - 2016-10-09 17:59:47 --> Loader Class Initialized
INFO - 2016-10-09 17:59:47 --> Helper loaded: url_helper
INFO - 2016-10-09 17:59:47 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 17:59:47 --> Controller Class Initialized
DEBUG - 2016-10-09 17:59:47 --> Index MX_Controller Initialized
INFO - 2016-10-09 17:59:47 --> Model Class Initialized
INFO - 2016-10-09 17:59:47 --> Model Class Initialized
ERROR - 2016-10-09 17:59:47 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-10-09 17:59:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 17:59:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 17:59:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 17:59:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-10-09 17:59:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 17:59:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 17:59:47 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:47 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:47 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:49 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:49 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:49 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:49 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:49 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:49 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:49 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:49 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:49 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:49 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:49 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:49 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:49 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:49 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:49 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:49 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:49 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:49 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:49 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:49 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:49 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:49 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:49 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:49 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:49 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:50 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:50 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:50 --> Database Driver Class Initialized
DEBUG - 2016-10-09 17:59:50 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 17:59:50 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 17:59:50 --> Final output sent to browser
DEBUG - 2016-10-09 17:59:50 --> Total execution time: 3.3006
INFO - 2016-10-09 17:59:57 --> Config Class Initialized
INFO - 2016-10-09 17:59:57 --> Hooks Class Initialized
DEBUG - 2016-10-09 17:59:57 --> UTF-8 Support Enabled
INFO - 2016-10-09 17:59:57 --> Utf8 Class Initialized
INFO - 2016-10-09 17:59:57 --> URI Class Initialized
INFO - 2016-10-09 17:59:57 --> Router Class Initialized
INFO - 2016-10-09 17:59:57 --> Output Class Initialized
INFO - 2016-10-09 17:59:57 --> Security Class Initialized
DEBUG - 2016-10-09 17:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 17:59:57 --> Input Class Initialized
INFO - 2016-10-09 17:59:57 --> Language Class Initialized
INFO - 2016-10-09 17:59:57 --> Language Class Initialized
INFO - 2016-10-09 17:59:57 --> Config Class Initialized
INFO - 2016-10-09 17:59:57 --> Loader Class Initialized
INFO - 2016-10-09 17:59:57 --> Helper loaded: url_helper
INFO - 2016-10-09 17:59:57 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 17:59:57 --> Controller Class Initialized
DEBUG - 2016-10-09 17:59:57 --> Index MX_Controller Initialized
INFO - 2016-10-09 17:59:57 --> Model Class Initialized
INFO - 2016-10-09 17:59:57 --> Model Class Initialized
ERROR - 2016-10-09 17:59:58 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-09 17:59:58 --> Anggota MX_Controller Initialized
INFO - 2016-10-09 17:59:58 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:58 --> Final output sent to browser
DEBUG - 2016-10-09 17:59:58 --> Total execution time: 0.7792
INFO - 2016-10-09 18:00:00 --> Config Class Initialized
INFO - 2016-10-09 18:00:00 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:00:00 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:00:00 --> Utf8 Class Initialized
INFO - 2016-10-09 18:00:00 --> URI Class Initialized
INFO - 2016-10-09 18:00:00 --> Router Class Initialized
INFO - 2016-10-09 18:00:00 --> Output Class Initialized
INFO - 2016-10-09 18:00:00 --> Security Class Initialized
DEBUG - 2016-10-09 18:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:00:00 --> Input Class Initialized
INFO - 2016-10-09 18:00:00 --> Language Class Initialized
INFO - 2016-10-09 18:00:00 --> Language Class Initialized
INFO - 2016-10-09 18:00:00 --> Config Class Initialized
INFO - 2016-10-09 18:00:00 --> Loader Class Initialized
INFO - 2016-10-09 18:00:00 --> Helper loaded: url_helper
INFO - 2016-10-09 18:00:00 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:00:00 --> Controller Class Initialized
DEBUG - 2016-10-09 18:00:00 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:00:00 --> Model Class Initialized
INFO - 2016-10-09 18:00:00 --> Model Class Initialized
ERROR - 2016-10-09 18:00:00 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-10-09 18:00:00 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 18:00:00 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 18:00:00 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 18:00:00 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_umum.php
DEBUG - 2016-10-09 18:00:00 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 18:00:00 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 18:00:00 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:02 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:02 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:02 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:02 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:02 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:02 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:02 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:02 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:02 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:02 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:02 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:02 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:02 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:02 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:02 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:02 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:02 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:02 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:02 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:02 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:02 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:02 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:02 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:03 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:03 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:03 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:03 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:03 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:03 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:03 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:03 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:03 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:03 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:03 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:03 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:03 --> Database Driver Class Initialized
DEBUG - 2016-10-09 18:00:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 18:00:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 18:00:03 --> Final output sent to browser
DEBUG - 2016-10-09 18:00:03 --> Total execution time: 3.5276
INFO - 2016-10-09 18:00:12 --> Config Class Initialized
INFO - 2016-10-09 18:00:12 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:00:12 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:00:12 --> Utf8 Class Initialized
INFO - 2016-10-09 18:00:12 --> URI Class Initialized
INFO - 2016-10-09 18:00:12 --> Router Class Initialized
INFO - 2016-10-09 18:00:12 --> Output Class Initialized
INFO - 2016-10-09 18:00:12 --> Security Class Initialized
DEBUG - 2016-10-09 18:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:00:12 --> Input Class Initialized
INFO - 2016-10-09 18:00:12 --> Language Class Initialized
INFO - 2016-10-09 18:00:12 --> Language Class Initialized
INFO - 2016-10-09 18:00:12 --> Config Class Initialized
INFO - 2016-10-09 18:00:12 --> Loader Class Initialized
INFO - 2016-10-09 18:00:12 --> Helper loaded: url_helper
INFO - 2016-10-09 18:00:12 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:00:12 --> Controller Class Initialized
DEBUG - 2016-10-09 18:00:12 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:00:12 --> Model Class Initialized
INFO - 2016-10-09 18:00:13 --> Model Class Initialized
ERROR - 2016-10-09 18:00:13 --> Unable to delete cache file for admin/index/do_ajukan_pinjaman
INFO - 2016-10-09 18:00:13 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:13 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:13 --> Final output sent to browser
DEBUG - 2016-10-09 18:00:13 --> Total execution time: 0.8824
INFO - 2016-10-09 18:00:47 --> Config Class Initialized
INFO - 2016-10-09 18:00:47 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:00:47 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:00:47 --> Utf8 Class Initialized
INFO - 2016-10-09 18:00:47 --> URI Class Initialized
INFO - 2016-10-09 18:00:47 --> Router Class Initialized
INFO - 2016-10-09 18:00:48 --> Output Class Initialized
INFO - 2016-10-09 18:00:48 --> Security Class Initialized
DEBUG - 2016-10-09 18:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:00:48 --> Input Class Initialized
INFO - 2016-10-09 18:00:48 --> Language Class Initialized
INFO - 2016-10-09 18:00:48 --> Language Class Initialized
INFO - 2016-10-09 18:00:48 --> Config Class Initialized
INFO - 2016-10-09 18:00:48 --> Loader Class Initialized
INFO - 2016-10-09 18:00:48 --> Helper loaded: url_helper
INFO - 2016-10-09 18:00:48 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:00:48 --> Controller Class Initialized
DEBUG - 2016-10-09 18:00:48 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:00:48 --> Model Class Initialized
INFO - 2016-10-09 18:00:48 --> Model Class Initialized
ERROR - 2016-10-09 18:00:48 --> Unable to delete cache file for admin/index/do_save_jaminan
ERROR - 2016-10-09 18:00:48 --> Severity: Notice --> Undefined index: jaminan E:\SERVER\htdocs\kops\application\modules\admin\controllers\Index.php 286
INFO - 2016-10-09 18:00:48 --> Database Driver Class Initialized
INFO - 2016-10-09 18:00:48 --> Final output sent to browser
DEBUG - 2016-10-09 18:00:48 --> Total execution time: 0.8292
INFO - 2016-10-09 18:01:10 --> Config Class Initialized
INFO - 2016-10-09 18:01:10 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:01:10 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:01:10 --> Utf8 Class Initialized
INFO - 2016-10-09 18:01:10 --> URI Class Initialized
INFO - 2016-10-09 18:01:10 --> Router Class Initialized
INFO - 2016-10-09 18:01:10 --> Output Class Initialized
INFO - 2016-10-09 18:01:10 --> Security Class Initialized
DEBUG - 2016-10-09 18:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:01:10 --> Input Class Initialized
INFO - 2016-10-09 18:01:10 --> Language Class Initialized
INFO - 2016-10-09 18:01:10 --> Language Class Initialized
INFO - 2016-10-09 18:01:10 --> Config Class Initialized
INFO - 2016-10-09 18:01:10 --> Loader Class Initialized
INFO - 2016-10-09 18:01:10 --> Helper loaded: url_helper
INFO - 2016-10-09 18:01:10 --> Database Driver Class Initialized
INFO - 2016-10-09 18:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:01:10 --> Controller Class Initialized
DEBUG - 2016-10-09 18:01:10 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:01:11 --> Model Class Initialized
INFO - 2016-10-09 18:01:11 --> Model Class Initialized
ERROR - 2016-10-09 18:01:11 --> Unable to delete cache file for admin/index/do_save_jaminan
ERROR - 2016-10-09 18:01:11 --> Severity: Notice --> Undefined index: jaminan E:\SERVER\htdocs\kops\application\modules\admin\controllers\Index.php 286
INFO - 2016-10-09 18:01:11 --> Database Driver Class Initialized
INFO - 2016-10-09 18:01:11 --> Final output sent to browser
DEBUG - 2016-10-09 18:01:11 --> Total execution time: 0.9045
INFO - 2016-10-09 18:01:52 --> Config Class Initialized
INFO - 2016-10-09 18:01:52 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:01:52 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:01:52 --> Utf8 Class Initialized
INFO - 2016-10-09 18:01:52 --> URI Class Initialized
INFO - 2016-10-09 18:01:52 --> Router Class Initialized
INFO - 2016-10-09 18:01:52 --> Output Class Initialized
INFO - 2016-10-09 18:01:52 --> Security Class Initialized
DEBUG - 2016-10-09 18:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:01:52 --> Input Class Initialized
INFO - 2016-10-09 18:01:52 --> Language Class Initialized
INFO - 2016-10-09 18:01:52 --> Language Class Initialized
INFO - 2016-10-09 18:01:52 --> Config Class Initialized
INFO - 2016-10-09 18:01:53 --> Loader Class Initialized
INFO - 2016-10-09 18:01:53 --> Helper loaded: url_helper
INFO - 2016-10-09 18:01:53 --> Database Driver Class Initialized
INFO - 2016-10-09 18:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:01:53 --> Controller Class Initialized
DEBUG - 2016-10-09 18:01:53 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:01:53 --> Model Class Initialized
INFO - 2016-10-09 18:01:53 --> Model Class Initialized
ERROR - 2016-10-09 18:01:53 --> Unable to delete cache file for admin/index/do_save_jaminan
INFO - 2016-10-09 18:01:53 --> Database Driver Class Initialized
INFO - 2016-10-09 18:01:53 --> Final output sent to browser
DEBUG - 2016-10-09 18:01:53 --> Total execution time: 0.8515
INFO - 2016-10-09 18:14:17 --> Config Class Initialized
INFO - 2016-10-09 18:14:17 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:14:17 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:14:17 --> Utf8 Class Initialized
INFO - 2016-10-09 18:14:17 --> URI Class Initialized
INFO - 2016-10-09 18:14:17 --> Router Class Initialized
INFO - 2016-10-09 18:14:17 --> Output Class Initialized
INFO - 2016-10-09 18:14:17 --> Security Class Initialized
DEBUG - 2016-10-09 18:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:14:17 --> Input Class Initialized
INFO - 2016-10-09 18:14:17 --> Language Class Initialized
INFO - 2016-10-09 18:14:17 --> Language Class Initialized
INFO - 2016-10-09 18:14:17 --> Config Class Initialized
INFO - 2016-10-09 18:14:17 --> Loader Class Initialized
INFO - 2016-10-09 18:14:17 --> Helper loaded: url_helper
INFO - 2016-10-09 18:14:17 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:14:17 --> Controller Class Initialized
DEBUG - 2016-10-09 18:14:17 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:14:17 --> Model Class Initialized
INFO - 2016-10-09 18:14:17 --> Model Class Initialized
ERROR - 2016-10-09 18:14:17 --> Unable to delete cache file for admin/index/batal/4d134bc072212ace2df385dae143139da74ec0ef
INFO - 2016-10-09 18:14:17 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:18 --> Final output sent to browser
DEBUG - 2016-10-09 18:14:18 --> Total execution time: 0.9530
INFO - 2016-10-09 18:14:18 --> Config Class Initialized
INFO - 2016-10-09 18:14:18 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:14:18 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:14:18 --> Utf8 Class Initialized
INFO - 2016-10-09 18:14:18 --> URI Class Initialized
INFO - 2016-10-09 18:14:18 --> Router Class Initialized
INFO - 2016-10-09 18:14:18 --> Output Class Initialized
INFO - 2016-10-09 18:14:18 --> Security Class Initialized
DEBUG - 2016-10-09 18:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:14:18 --> Input Class Initialized
INFO - 2016-10-09 18:14:18 --> Language Class Initialized
INFO - 2016-10-09 18:14:18 --> Language Class Initialized
INFO - 2016-10-09 18:14:18 --> Config Class Initialized
INFO - 2016-10-09 18:14:18 --> Loader Class Initialized
INFO - 2016-10-09 18:14:18 --> Helper loaded: url_helper
INFO - 2016-10-09 18:14:18 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:14:18 --> Controller Class Initialized
DEBUG - 2016-10-09 18:14:18 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:14:18 --> Model Class Initialized
INFO - 2016-10-09 18:14:18 --> Model Class Initialized
ERROR - 2016-10-09 18:14:18 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-10-09 18:14:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 18:14:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 18:14:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 18:14:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-10-09 18:14:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 18:14:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 18:14:19 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:19 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:19 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:19 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:19 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:19 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:19 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:19 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:19 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:19 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:19 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:19 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:19 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:19 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:19 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:19 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:19 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:19 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:19 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:19 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:19 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:19 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:20 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:20 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:20 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:20 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:20 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:20 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:20 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:20 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:20 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:20 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:20 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:20 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:20 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:20 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:20 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:20 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:20 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:20 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:20 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:20 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:20 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:20 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:20 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:20 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:20 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:20 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:20 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:20 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:20 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:21 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:21 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:21 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:21 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:21 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:21 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:21 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:21 --> Database Driver Class Initialized
DEBUG - 2016-10-09 18:14:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 18:14:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 18:14:21 --> Final output sent to browser
DEBUG - 2016-10-09 18:14:21 --> Total execution time: 3.0528
INFO - 2016-10-09 18:14:27 --> Config Class Initialized
INFO - 2016-10-09 18:14:27 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:14:27 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:14:27 --> Utf8 Class Initialized
INFO - 2016-10-09 18:14:27 --> URI Class Initialized
INFO - 2016-10-09 18:14:27 --> Router Class Initialized
INFO - 2016-10-09 18:14:27 --> Output Class Initialized
INFO - 2016-10-09 18:14:27 --> Security Class Initialized
DEBUG - 2016-10-09 18:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:14:27 --> Input Class Initialized
INFO - 2016-10-09 18:14:27 --> Language Class Initialized
INFO - 2016-10-09 18:14:27 --> Language Class Initialized
INFO - 2016-10-09 18:14:27 --> Config Class Initialized
INFO - 2016-10-09 18:14:27 --> Loader Class Initialized
INFO - 2016-10-09 18:14:27 --> Helper loaded: url_helper
INFO - 2016-10-09 18:14:27 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:14:27 --> Controller Class Initialized
DEBUG - 2016-10-09 18:14:27 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:14:27 --> Model Class Initialized
INFO - 2016-10-09 18:14:27 --> Model Class Initialized
ERROR - 2016-10-09 18:14:27 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-09 18:14:27 --> Anggota MX_Controller Initialized
INFO - 2016-10-09 18:14:27 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:27 --> Final output sent to browser
DEBUG - 2016-10-09 18:14:27 --> Total execution time: 0.7809
INFO - 2016-10-09 18:14:30 --> Config Class Initialized
INFO - 2016-10-09 18:14:30 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:14:30 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:14:30 --> Utf8 Class Initialized
INFO - 2016-10-09 18:14:30 --> URI Class Initialized
INFO - 2016-10-09 18:14:30 --> Router Class Initialized
INFO - 2016-10-09 18:14:30 --> Output Class Initialized
INFO - 2016-10-09 18:14:30 --> Security Class Initialized
DEBUG - 2016-10-09 18:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:14:30 --> Input Class Initialized
INFO - 2016-10-09 18:14:30 --> Language Class Initialized
INFO - 2016-10-09 18:14:30 --> Language Class Initialized
INFO - 2016-10-09 18:14:30 --> Config Class Initialized
INFO - 2016-10-09 18:14:30 --> Loader Class Initialized
INFO - 2016-10-09 18:14:30 --> Helper loaded: url_helper
INFO - 2016-10-09 18:14:30 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:14:31 --> Controller Class Initialized
DEBUG - 2016-10-09 18:14:31 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:14:31 --> Model Class Initialized
INFO - 2016-10-09 18:14:31 --> Model Class Initialized
ERROR - 2016-10-09 18:14:31 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-10-09 18:14:31 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 18:14:31 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 18:14:31 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 18:14:31 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_umum.php
DEBUG - 2016-10-09 18:14:31 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 18:14:31 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 18:14:31 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:31 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:31 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:31 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:31 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:31 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:31 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:31 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:31 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:31 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:31 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:31 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:31 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:31 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:31 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:31 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:32 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:32 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:32 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:32 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:32 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:32 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:32 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:32 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:32 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:32 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:32 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:32 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:32 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:32 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:32 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:32 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:32 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:32 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:32 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:32 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:32 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:32 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:32 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:32 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:32 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:32 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:33 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:33 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:33 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:33 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:33 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:33 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:33 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:33 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:33 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:33 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:33 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:33 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:33 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:33 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:33 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:33 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:33 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:33 --> Database Driver Class Initialized
DEBUG - 2016-10-09 18:14:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 18:14:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 18:14:33 --> Final output sent to browser
DEBUG - 2016-10-09 18:14:33 --> Total execution time: 3.4760
INFO - 2016-10-09 18:14:43 --> Config Class Initialized
INFO - 2016-10-09 18:14:43 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:14:43 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:14:43 --> Utf8 Class Initialized
INFO - 2016-10-09 18:14:43 --> URI Class Initialized
INFO - 2016-10-09 18:14:43 --> Router Class Initialized
INFO - 2016-10-09 18:14:43 --> Output Class Initialized
INFO - 2016-10-09 18:14:44 --> Security Class Initialized
DEBUG - 2016-10-09 18:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:14:44 --> Input Class Initialized
INFO - 2016-10-09 18:14:44 --> Language Class Initialized
INFO - 2016-10-09 18:14:44 --> Language Class Initialized
INFO - 2016-10-09 18:14:44 --> Config Class Initialized
INFO - 2016-10-09 18:14:44 --> Loader Class Initialized
INFO - 2016-10-09 18:14:44 --> Helper loaded: url_helper
INFO - 2016-10-09 18:14:44 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:14:44 --> Controller Class Initialized
DEBUG - 2016-10-09 18:14:44 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:14:44 --> Model Class Initialized
INFO - 2016-10-09 18:14:44 --> Model Class Initialized
ERROR - 2016-10-09 18:14:44 --> Unable to delete cache file for admin/index/do_ajukan_pinjaman
INFO - 2016-10-09 18:14:44 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:44 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:44 --> Final output sent to browser
DEBUG - 2016-10-09 18:14:44 --> Total execution time: 0.8358
INFO - 2016-10-09 18:14:57 --> Config Class Initialized
INFO - 2016-10-09 18:14:57 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:14:57 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:14:57 --> Utf8 Class Initialized
INFO - 2016-10-09 18:14:57 --> URI Class Initialized
INFO - 2016-10-09 18:14:57 --> Router Class Initialized
INFO - 2016-10-09 18:14:57 --> Output Class Initialized
INFO - 2016-10-09 18:14:57 --> Security Class Initialized
DEBUG - 2016-10-09 18:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:14:57 --> Input Class Initialized
INFO - 2016-10-09 18:14:57 --> Language Class Initialized
INFO - 2016-10-09 18:14:57 --> Language Class Initialized
INFO - 2016-10-09 18:14:57 --> Config Class Initialized
INFO - 2016-10-09 18:14:57 --> Loader Class Initialized
INFO - 2016-10-09 18:14:57 --> Helper loaded: url_helper
INFO - 2016-10-09 18:14:57 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:14:57 --> Controller Class Initialized
DEBUG - 2016-10-09 18:14:57 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:14:57 --> Model Class Initialized
INFO - 2016-10-09 18:14:58 --> Model Class Initialized
ERROR - 2016-10-09 18:14:58 --> Unable to delete cache file for admin/index/do_save_jaminan/sertifikat
INFO - 2016-10-09 18:14:58 --> Database Driver Class Initialized
INFO - 2016-10-09 18:14:58 --> Final output sent to browser
DEBUG - 2016-10-09 18:14:58 --> Total execution time: 0.8197
INFO - 2016-10-09 18:17:25 --> Config Class Initialized
INFO - 2016-10-09 18:17:25 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:17:25 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:17:25 --> Utf8 Class Initialized
INFO - 2016-10-09 18:17:25 --> URI Class Initialized
INFO - 2016-10-09 18:17:25 --> Router Class Initialized
INFO - 2016-10-09 18:17:25 --> Output Class Initialized
INFO - 2016-10-09 18:17:25 --> Security Class Initialized
DEBUG - 2016-10-09 18:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:17:25 --> Input Class Initialized
INFO - 2016-10-09 18:17:25 --> Language Class Initialized
INFO - 2016-10-09 18:17:25 --> Language Class Initialized
INFO - 2016-10-09 18:17:25 --> Config Class Initialized
INFO - 2016-10-09 18:17:25 --> Loader Class Initialized
INFO - 2016-10-09 18:17:25 --> Helper loaded: url_helper
INFO - 2016-10-09 18:17:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:17:25 --> Controller Class Initialized
DEBUG - 2016-10-09 18:17:25 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:17:26 --> Model Class Initialized
INFO - 2016-10-09 18:17:26 --> Model Class Initialized
ERROR - 2016-10-09 18:17:26 --> Unable to delete cache file for admin/index/batal/f6e1126cedebf23e1463aee73f9df08783640400
INFO - 2016-10-09 18:17:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:26 --> Final output sent to browser
DEBUG - 2016-10-09 18:17:26 --> Total execution time: 1.0026
INFO - 2016-10-09 18:17:26 --> Config Class Initialized
INFO - 2016-10-09 18:17:26 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:17:26 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:17:26 --> Utf8 Class Initialized
INFO - 2016-10-09 18:17:26 --> URI Class Initialized
INFO - 2016-10-09 18:17:26 --> Router Class Initialized
INFO - 2016-10-09 18:17:26 --> Output Class Initialized
INFO - 2016-10-09 18:17:26 --> Security Class Initialized
DEBUG - 2016-10-09 18:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:17:26 --> Input Class Initialized
INFO - 2016-10-09 18:17:26 --> Language Class Initialized
INFO - 2016-10-09 18:17:27 --> Language Class Initialized
INFO - 2016-10-09 18:17:27 --> Config Class Initialized
INFO - 2016-10-09 18:17:27 --> Loader Class Initialized
INFO - 2016-10-09 18:17:27 --> Helper loaded: url_helper
INFO - 2016-10-09 18:17:27 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:17:27 --> Controller Class Initialized
DEBUG - 2016-10-09 18:17:27 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:17:27 --> Model Class Initialized
INFO - 2016-10-09 18:17:27 --> Model Class Initialized
ERROR - 2016-10-09 18:17:27 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-10-09 18:17:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 18:17:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 18:17:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 18:17:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-10-09 18:17:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 18:17:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 18:17:27 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:27 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:27 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:27 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:27 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:27 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:27 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:27 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:27 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:27 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:27 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:27 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:28 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:28 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:28 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:28 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:28 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:28 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:28 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:28 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:28 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:28 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:28 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:28 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:28 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:28 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:28 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:28 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:28 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:28 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:28 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:28 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:28 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:28 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:28 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:28 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:28 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:28 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:28 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:29 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:29 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:29 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:29 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:29 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:29 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:29 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:29 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:29 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:29 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:29 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:29 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:29 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:29 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:29 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:29 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:29 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:29 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:29 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:29 --> Database Driver Class Initialized
DEBUG - 2016-10-09 18:17:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 18:17:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 18:17:29 --> Final output sent to browser
DEBUG - 2016-10-09 18:17:29 --> Total execution time: 3.4124
INFO - 2016-10-09 18:17:34 --> Config Class Initialized
INFO - 2016-10-09 18:17:35 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:17:35 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:17:35 --> Utf8 Class Initialized
INFO - 2016-10-09 18:17:35 --> URI Class Initialized
INFO - 2016-10-09 18:17:35 --> Router Class Initialized
INFO - 2016-10-09 18:17:35 --> Output Class Initialized
INFO - 2016-10-09 18:17:35 --> Security Class Initialized
DEBUG - 2016-10-09 18:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:17:35 --> Input Class Initialized
INFO - 2016-10-09 18:17:35 --> Language Class Initialized
INFO - 2016-10-09 18:17:35 --> Language Class Initialized
INFO - 2016-10-09 18:17:35 --> Config Class Initialized
INFO - 2016-10-09 18:17:35 --> Loader Class Initialized
INFO - 2016-10-09 18:17:35 --> Helper loaded: url_helper
INFO - 2016-10-09 18:17:35 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:17:35 --> Controller Class Initialized
DEBUG - 2016-10-09 18:17:35 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:17:35 --> Model Class Initialized
INFO - 2016-10-09 18:17:35 --> Model Class Initialized
ERROR - 2016-10-09 18:17:35 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-09 18:17:35 --> Anggota MX_Controller Initialized
INFO - 2016-10-09 18:17:35 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:35 --> Final output sent to browser
DEBUG - 2016-10-09 18:17:35 --> Total execution time: 1.1173
INFO - 2016-10-09 18:17:38 --> Config Class Initialized
INFO - 2016-10-09 18:17:38 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:17:38 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:17:39 --> Utf8 Class Initialized
INFO - 2016-10-09 18:17:39 --> URI Class Initialized
INFO - 2016-10-09 18:17:39 --> Router Class Initialized
INFO - 2016-10-09 18:17:39 --> Output Class Initialized
INFO - 2016-10-09 18:17:39 --> Security Class Initialized
DEBUG - 2016-10-09 18:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:17:39 --> Input Class Initialized
INFO - 2016-10-09 18:17:39 --> Language Class Initialized
INFO - 2016-10-09 18:17:39 --> Language Class Initialized
INFO - 2016-10-09 18:17:39 --> Config Class Initialized
INFO - 2016-10-09 18:17:39 --> Loader Class Initialized
INFO - 2016-10-09 18:17:39 --> Helper loaded: url_helper
INFO - 2016-10-09 18:17:39 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:17:39 --> Controller Class Initialized
DEBUG - 2016-10-09 18:17:39 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:17:39 --> Model Class Initialized
INFO - 2016-10-09 18:17:39 --> Model Class Initialized
ERROR - 2016-10-09 18:17:39 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-10-09 18:17:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 18:17:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 18:17:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 18:17:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_umum.php
DEBUG - 2016-10-09 18:17:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 18:17:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 18:17:39 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:39 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:39 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:42 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:42 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:42 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:42 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:42 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:42 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:42 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:42 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:42 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:42 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:42 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:42 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:42 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:42 --> Database Driver Class Initialized
DEBUG - 2016-10-09 18:17:42 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 18:17:42 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 18:17:42 --> Final output sent to browser
DEBUG - 2016-10-09 18:17:42 --> Total execution time: 3.7564
INFO - 2016-10-09 18:17:49 --> Config Class Initialized
INFO - 2016-10-09 18:17:49 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:17:49 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:17:49 --> Utf8 Class Initialized
INFO - 2016-10-09 18:17:49 --> URI Class Initialized
INFO - 2016-10-09 18:17:49 --> Router Class Initialized
INFO - 2016-10-09 18:17:50 --> Output Class Initialized
INFO - 2016-10-09 18:17:50 --> Security Class Initialized
DEBUG - 2016-10-09 18:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:17:50 --> Input Class Initialized
INFO - 2016-10-09 18:17:50 --> Language Class Initialized
INFO - 2016-10-09 18:17:50 --> Language Class Initialized
INFO - 2016-10-09 18:17:50 --> Config Class Initialized
INFO - 2016-10-09 18:17:50 --> Loader Class Initialized
INFO - 2016-10-09 18:17:50 --> Helper loaded: url_helper
INFO - 2016-10-09 18:17:50 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:17:50 --> Controller Class Initialized
DEBUG - 2016-10-09 18:17:50 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:17:50 --> Model Class Initialized
INFO - 2016-10-09 18:17:50 --> Model Class Initialized
ERROR - 2016-10-09 18:17:50 --> Unable to delete cache file for admin/index/do_ajukan_pinjaman
INFO - 2016-10-09 18:17:50 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:50 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:50 --> Final output sent to browser
DEBUG - 2016-10-09 18:17:50 --> Total execution time: 0.9345
INFO - 2016-10-09 18:17:58 --> Config Class Initialized
INFO - 2016-10-09 18:17:58 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:17:58 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:17:58 --> Utf8 Class Initialized
INFO - 2016-10-09 18:17:58 --> URI Class Initialized
INFO - 2016-10-09 18:17:58 --> Router Class Initialized
INFO - 2016-10-09 18:17:58 --> Output Class Initialized
INFO - 2016-10-09 18:17:59 --> Security Class Initialized
DEBUG - 2016-10-09 18:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:17:59 --> Input Class Initialized
INFO - 2016-10-09 18:17:59 --> Language Class Initialized
INFO - 2016-10-09 18:17:59 --> Language Class Initialized
INFO - 2016-10-09 18:17:59 --> Config Class Initialized
INFO - 2016-10-09 18:17:59 --> Loader Class Initialized
INFO - 2016-10-09 18:17:59 --> Helper loaded: url_helper
INFO - 2016-10-09 18:17:59 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:17:59 --> Controller Class Initialized
DEBUG - 2016-10-09 18:17:59 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:17:59 --> Model Class Initialized
INFO - 2016-10-09 18:17:59 --> Model Class Initialized
ERROR - 2016-10-09 18:17:59 --> Unable to delete cache file for admin/index/do_save_jaminan/sertifikat
INFO - 2016-10-09 18:17:59 --> Database Driver Class Initialized
INFO - 2016-10-09 18:17:59 --> Final output sent to browser
DEBUG - 2016-10-09 18:17:59 --> Total execution time: 0.8969
INFO - 2016-10-09 18:18:34 --> Config Class Initialized
INFO - 2016-10-09 18:18:34 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:18:34 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:18:34 --> Utf8 Class Initialized
INFO - 2016-10-09 18:18:34 --> URI Class Initialized
INFO - 2016-10-09 18:18:35 --> Router Class Initialized
INFO - 2016-10-09 18:18:35 --> Output Class Initialized
INFO - 2016-10-09 18:18:35 --> Security Class Initialized
DEBUG - 2016-10-09 18:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:18:35 --> Input Class Initialized
INFO - 2016-10-09 18:18:35 --> Language Class Initialized
INFO - 2016-10-09 18:18:35 --> Language Class Initialized
INFO - 2016-10-09 18:18:35 --> Config Class Initialized
INFO - 2016-10-09 18:18:35 --> Loader Class Initialized
INFO - 2016-10-09 18:18:35 --> Helper loaded: url_helper
INFO - 2016-10-09 18:18:35 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:18:35 --> Controller Class Initialized
DEBUG - 2016-10-09 18:18:35 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:18:35 --> Model Class Initialized
INFO - 2016-10-09 18:18:35 --> Model Class Initialized
ERROR - 2016-10-09 18:18:35 --> Unable to delete cache file for admin/index/batal/887309d048beef83ad3eabf2a79a64a389ab1c9f
INFO - 2016-10-09 18:18:35 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:35 --> Final output sent to browser
DEBUG - 2016-10-09 18:18:35 --> Total execution time: 0.9869
INFO - 2016-10-09 18:18:35 --> Config Class Initialized
INFO - 2016-10-09 18:18:36 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:18:36 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:18:36 --> Utf8 Class Initialized
INFO - 2016-10-09 18:18:36 --> URI Class Initialized
INFO - 2016-10-09 18:18:36 --> Router Class Initialized
INFO - 2016-10-09 18:18:36 --> Output Class Initialized
INFO - 2016-10-09 18:18:36 --> Security Class Initialized
DEBUG - 2016-10-09 18:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:18:36 --> Input Class Initialized
INFO - 2016-10-09 18:18:36 --> Language Class Initialized
INFO - 2016-10-09 18:18:36 --> Language Class Initialized
INFO - 2016-10-09 18:18:36 --> Config Class Initialized
INFO - 2016-10-09 18:18:36 --> Loader Class Initialized
INFO - 2016-10-09 18:18:36 --> Helper loaded: url_helper
INFO - 2016-10-09 18:18:36 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:18:36 --> Controller Class Initialized
DEBUG - 2016-10-09 18:18:36 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:18:36 --> Model Class Initialized
INFO - 2016-10-09 18:18:36 --> Model Class Initialized
ERROR - 2016-10-09 18:18:36 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-10-09 18:18:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 18:18:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 18:18:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 18:18:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-10-09 18:18:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 18:18:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 18:18:36 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:36 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:37 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:37 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:37 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:37 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:37 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:37 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:37 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:37 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:37 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:37 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:37 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:37 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:37 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:37 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:37 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:37 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:37 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:37 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:37 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:37 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:37 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:37 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:37 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:37 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:37 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:38 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:38 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:38 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:38 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:38 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:38 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:38 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:38 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:38 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:38 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:38 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:38 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:38 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:38 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:38 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:38 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:38 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:38 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:38 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:38 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:38 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:38 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:38 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:38 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:38 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:38 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:38 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:38 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:39 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:39 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:39 --> Database Driver Class Initialized
INFO - 2016-10-09 18:18:39 --> Database Driver Class Initialized
DEBUG - 2016-10-09 18:18:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 18:18:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 18:18:39 --> Final output sent to browser
DEBUG - 2016-10-09 18:18:39 --> Total execution time: 3.2457
INFO - 2016-10-09 18:20:12 --> Config Class Initialized
INFO - 2016-10-09 18:20:12 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:20:12 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:20:12 --> Utf8 Class Initialized
INFO - 2016-10-09 18:20:12 --> URI Class Initialized
INFO - 2016-10-09 18:20:12 --> Router Class Initialized
INFO - 2016-10-09 18:20:12 --> Output Class Initialized
INFO - 2016-10-09 18:20:12 --> Security Class Initialized
DEBUG - 2016-10-09 18:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:20:12 --> Input Class Initialized
INFO - 2016-10-09 18:20:12 --> Language Class Initialized
INFO - 2016-10-09 18:20:12 --> Language Class Initialized
INFO - 2016-10-09 18:20:12 --> Config Class Initialized
INFO - 2016-10-09 18:20:12 --> Loader Class Initialized
INFO - 2016-10-09 18:20:12 --> Helper loaded: url_helper
INFO - 2016-10-09 18:20:12 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:20:13 --> Controller Class Initialized
DEBUG - 2016-10-09 18:20:13 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:20:13 --> Model Class Initialized
INFO - 2016-10-09 18:20:13 --> Model Class Initialized
ERROR - 2016-10-09 18:20:13 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-09 18:20:13 --> Anggota MX_Controller Initialized
INFO - 2016-10-09 18:20:13 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:13 --> Final output sent to browser
DEBUG - 2016-10-09 18:20:13 --> Total execution time: 0.8370
INFO - 2016-10-09 18:20:19 --> Config Class Initialized
INFO - 2016-10-09 18:20:19 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:20:19 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:20:19 --> Utf8 Class Initialized
INFO - 2016-10-09 18:20:19 --> URI Class Initialized
INFO - 2016-10-09 18:20:19 --> Router Class Initialized
INFO - 2016-10-09 18:20:19 --> Output Class Initialized
INFO - 2016-10-09 18:20:19 --> Security Class Initialized
DEBUG - 2016-10-09 18:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:20:19 --> Input Class Initialized
INFO - 2016-10-09 18:20:19 --> Language Class Initialized
INFO - 2016-10-09 18:20:19 --> Language Class Initialized
INFO - 2016-10-09 18:20:19 --> Config Class Initialized
INFO - 2016-10-09 18:20:19 --> Loader Class Initialized
INFO - 2016-10-09 18:20:19 --> Helper loaded: url_helper
INFO - 2016-10-09 18:20:19 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:20:19 --> Controller Class Initialized
DEBUG - 2016-10-09 18:20:19 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:20:19 --> Model Class Initialized
INFO - 2016-10-09 18:20:19 --> Model Class Initialized
ERROR - 2016-10-09 18:20:19 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-10-09 18:20:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 18:20:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 18:20:20 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 18:20:20 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_umum.php
DEBUG - 2016-10-09 18:20:20 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 18:20:20 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 18:20:20 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:20 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:20 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:20 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:20 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:20 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:20 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:20 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:20 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:20 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:20 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:20 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:20 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:20 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:20 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:20 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:20 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:20 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:20 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:20 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:20 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:20 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:20 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:21 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:21 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:21 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:21 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:21 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:21 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:21 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:21 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:21 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:21 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:21 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:21 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:21 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:21 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:21 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:21 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:21 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:21 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:21 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:21 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:21 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:21 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:21 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:21 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:21 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:21 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:21 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:22 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:22 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:22 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:22 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:22 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:22 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:22 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:22 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:22 --> Database Driver Class Initialized
INFO - 2016-10-09 18:20:22 --> Database Driver Class Initialized
DEBUG - 2016-10-09 18:20:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 18:20:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 18:20:22 --> Final output sent to browser
DEBUG - 2016-10-09 18:20:22 --> Total execution time: 3.2675
INFO - 2016-10-09 18:21:04 --> Config Class Initialized
INFO - 2016-10-09 18:21:04 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:21:04 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:21:04 --> Utf8 Class Initialized
INFO - 2016-10-09 18:21:04 --> URI Class Initialized
INFO - 2016-10-09 18:21:04 --> Router Class Initialized
INFO - 2016-10-09 18:21:04 --> Output Class Initialized
INFO - 2016-10-09 18:21:04 --> Security Class Initialized
DEBUG - 2016-10-09 18:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:21:04 --> Input Class Initialized
INFO - 2016-10-09 18:21:04 --> Language Class Initialized
INFO - 2016-10-09 18:21:05 --> Language Class Initialized
INFO - 2016-10-09 18:21:05 --> Config Class Initialized
INFO - 2016-10-09 18:21:05 --> Loader Class Initialized
INFO - 2016-10-09 18:21:05 --> Helper loaded: url_helper
INFO - 2016-10-09 18:21:05 --> Database Driver Class Initialized
INFO - 2016-10-09 18:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:21:05 --> Controller Class Initialized
DEBUG - 2016-10-09 18:21:05 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:21:05 --> Model Class Initialized
INFO - 2016-10-09 18:21:05 --> Model Class Initialized
ERROR - 2016-10-09 18:21:05 --> Unable to delete cache file for admin/index/do_ajukan_pinjaman
INFO - 2016-10-09 18:21:05 --> Database Driver Class Initialized
INFO - 2016-10-09 18:21:05 --> Database Driver Class Initialized
INFO - 2016-10-09 18:21:05 --> Final output sent to browser
DEBUG - 2016-10-09 18:21:05 --> Total execution time: 0.9414
INFO - 2016-10-09 18:21:21 --> Config Class Initialized
INFO - 2016-10-09 18:21:21 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:21:21 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:21:21 --> Utf8 Class Initialized
INFO - 2016-10-09 18:21:21 --> URI Class Initialized
INFO - 2016-10-09 18:21:21 --> Router Class Initialized
INFO - 2016-10-09 18:21:21 --> Output Class Initialized
INFO - 2016-10-09 18:21:21 --> Security Class Initialized
DEBUG - 2016-10-09 18:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:21:21 --> Input Class Initialized
INFO - 2016-10-09 18:21:21 --> Language Class Initialized
INFO - 2016-10-09 18:21:21 --> Language Class Initialized
INFO - 2016-10-09 18:21:22 --> Config Class Initialized
INFO - 2016-10-09 18:21:22 --> Loader Class Initialized
INFO - 2016-10-09 18:21:22 --> Helper loaded: url_helper
INFO - 2016-10-09 18:21:22 --> Database Driver Class Initialized
INFO - 2016-10-09 18:21:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:21:22 --> Controller Class Initialized
DEBUG - 2016-10-09 18:21:22 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:21:22 --> Model Class Initialized
INFO - 2016-10-09 18:21:22 --> Model Class Initialized
ERROR - 2016-10-09 18:21:22 --> Unable to delete cache file for admin/index/do_save_jaminan/sertifikat
INFO - 2016-10-09 18:21:22 --> Database Driver Class Initialized
INFO - 2016-10-09 18:21:22 --> Final output sent to browser
DEBUG - 2016-10-09 18:21:22 --> Total execution time: 0.9629
INFO - 2016-10-09 18:27:48 --> Config Class Initialized
INFO - 2016-10-09 18:27:48 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:27:48 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:27:48 --> Utf8 Class Initialized
INFO - 2016-10-09 18:27:48 --> URI Class Initialized
INFO - 2016-10-09 18:27:48 --> Router Class Initialized
INFO - 2016-10-09 18:27:48 --> Output Class Initialized
INFO - 2016-10-09 18:27:49 --> Security Class Initialized
DEBUG - 2016-10-09 18:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:27:49 --> Input Class Initialized
INFO - 2016-10-09 18:27:49 --> Language Class Initialized
INFO - 2016-10-09 18:27:49 --> Language Class Initialized
INFO - 2016-10-09 18:27:49 --> Config Class Initialized
INFO - 2016-10-09 18:27:49 --> Loader Class Initialized
INFO - 2016-10-09 18:27:49 --> Helper loaded: url_helper
INFO - 2016-10-09 18:27:49 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:27:49 --> Controller Class Initialized
DEBUG - 2016-10-09 18:27:49 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:27:49 --> Model Class Initialized
INFO - 2016-10-09 18:27:49 --> Model Class Initialized
ERROR - 2016-10-09 18:27:49 --> Unable to delete cache file for admin/index/batal/bc33ea4e26e5e1af1408321416956113a4658763
INFO - 2016-10-09 18:27:49 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:49 --> Final output sent to browser
DEBUG - 2016-10-09 18:27:49 --> Total execution time: 1.1487
INFO - 2016-10-09 18:27:50 --> Config Class Initialized
INFO - 2016-10-09 18:27:50 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:27:50 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:27:50 --> Utf8 Class Initialized
INFO - 2016-10-09 18:27:50 --> URI Class Initialized
INFO - 2016-10-09 18:27:50 --> Router Class Initialized
INFO - 2016-10-09 18:27:50 --> Output Class Initialized
INFO - 2016-10-09 18:27:50 --> Security Class Initialized
DEBUG - 2016-10-09 18:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:27:50 --> Input Class Initialized
INFO - 2016-10-09 18:27:50 --> Language Class Initialized
INFO - 2016-10-09 18:27:50 --> Language Class Initialized
INFO - 2016-10-09 18:27:50 --> Config Class Initialized
INFO - 2016-10-09 18:27:50 --> Loader Class Initialized
INFO - 2016-10-09 18:27:50 --> Helper loaded: url_helper
INFO - 2016-10-09 18:27:50 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:27:51 --> Controller Class Initialized
DEBUG - 2016-10-09 18:27:51 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:27:51 --> Model Class Initialized
INFO - 2016-10-09 18:27:51 --> Model Class Initialized
ERROR - 2016-10-09 18:27:51 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-10-09 18:27:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 18:27:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 18:27:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 18:27:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-10-09 18:27:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 18:27:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 18:27:51 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:51 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:51 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:51 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:51 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:51 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:51 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:51 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:51 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:51 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:51 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:51 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:51 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:51 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:51 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:52 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:52 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:52 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:52 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:52 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:52 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:52 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:52 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:52 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:52 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:52 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:52 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:52 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:52 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:52 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:52 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:52 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:52 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:52 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:52 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:52 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:52 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:53 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:53 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:53 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:53 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:53 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:53 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:53 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:53 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:53 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:53 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:53 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:53 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:53 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:53 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:53 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:53 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:53 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:53 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:53 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:53 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:53 --> Database Driver Class Initialized
INFO - 2016-10-09 18:27:53 --> Database Driver Class Initialized
DEBUG - 2016-10-09 18:27:53 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 18:27:53 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 18:27:54 --> Final output sent to browser
DEBUG - 2016-10-09 18:27:54 --> Total execution time: 3.5993
INFO - 2016-10-09 18:28:21 --> Config Class Initialized
INFO - 2016-10-09 18:28:21 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:28:21 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:28:21 --> Utf8 Class Initialized
INFO - 2016-10-09 18:28:21 --> URI Class Initialized
INFO - 2016-10-09 18:28:21 --> Router Class Initialized
INFO - 2016-10-09 18:28:21 --> Output Class Initialized
INFO - 2016-10-09 18:28:21 --> Security Class Initialized
DEBUG - 2016-10-09 18:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:28:21 --> Input Class Initialized
INFO - 2016-10-09 18:28:21 --> Language Class Initialized
INFO - 2016-10-09 18:28:21 --> Language Class Initialized
INFO - 2016-10-09 18:28:21 --> Config Class Initialized
INFO - 2016-10-09 18:28:21 --> Loader Class Initialized
INFO - 2016-10-09 18:28:21 --> Helper loaded: url_helper
INFO - 2016-10-09 18:28:21 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:28:21 --> Controller Class Initialized
DEBUG - 2016-10-09 18:28:21 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:28:21 --> Model Class Initialized
INFO - 2016-10-09 18:28:21 --> Model Class Initialized
ERROR - 2016-10-09 18:28:21 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-09 18:28:21 --> Anggota MX_Controller Initialized
INFO - 2016-10-09 18:28:21 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:21 --> Final output sent to browser
DEBUG - 2016-10-09 18:28:21 --> Total execution time: 0.9392
INFO - 2016-10-09 18:28:23 --> Config Class Initialized
INFO - 2016-10-09 18:28:23 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:28:23 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:28:23 --> Utf8 Class Initialized
INFO - 2016-10-09 18:28:23 --> URI Class Initialized
INFO - 2016-10-09 18:28:23 --> Router Class Initialized
INFO - 2016-10-09 18:28:23 --> Output Class Initialized
INFO - 2016-10-09 18:28:23 --> Security Class Initialized
DEBUG - 2016-10-09 18:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:28:24 --> Input Class Initialized
INFO - 2016-10-09 18:28:24 --> Language Class Initialized
INFO - 2016-10-09 18:28:24 --> Language Class Initialized
INFO - 2016-10-09 18:28:24 --> Config Class Initialized
INFO - 2016-10-09 18:28:24 --> Loader Class Initialized
INFO - 2016-10-09 18:28:24 --> Helper loaded: url_helper
INFO - 2016-10-09 18:28:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:28:24 --> Controller Class Initialized
DEBUG - 2016-10-09 18:28:24 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:28:24 --> Model Class Initialized
INFO - 2016-10-09 18:28:24 --> Model Class Initialized
ERROR - 2016-10-09 18:28:24 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-10-09 18:28:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 18:28:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 18:28:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 18:28:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_umum.php
DEBUG - 2016-10-09 18:28:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 18:28:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 18:28:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:27 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:27 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:27 --> Database Driver Class Initialized
DEBUG - 2016-10-09 18:28:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 18:28:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 18:28:27 --> Final output sent to browser
DEBUG - 2016-10-09 18:28:27 --> Total execution time: 3.5030
INFO - 2016-10-09 18:28:39 --> Config Class Initialized
INFO - 2016-10-09 18:28:39 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:28:39 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:28:39 --> Utf8 Class Initialized
INFO - 2016-10-09 18:28:39 --> URI Class Initialized
INFO - 2016-10-09 18:28:39 --> Router Class Initialized
INFO - 2016-10-09 18:28:39 --> Output Class Initialized
INFO - 2016-10-09 18:28:39 --> Security Class Initialized
DEBUG - 2016-10-09 18:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:28:39 --> Input Class Initialized
INFO - 2016-10-09 18:28:40 --> Language Class Initialized
INFO - 2016-10-09 18:28:40 --> Language Class Initialized
INFO - 2016-10-09 18:28:40 --> Config Class Initialized
INFO - 2016-10-09 18:28:40 --> Loader Class Initialized
INFO - 2016-10-09 18:28:40 --> Helper loaded: url_helper
INFO - 2016-10-09 18:28:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:28:40 --> Controller Class Initialized
DEBUG - 2016-10-09 18:28:40 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:28:40 --> Model Class Initialized
INFO - 2016-10-09 18:28:40 --> Model Class Initialized
ERROR - 2016-10-09 18:28:40 --> Unable to delete cache file for admin/index/do_ajukan_pinjaman
INFO - 2016-10-09 18:28:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:40 --> Final output sent to browser
DEBUG - 2016-10-09 18:28:40 --> Total execution time: 1.0136
INFO - 2016-10-09 18:28:49 --> Config Class Initialized
INFO - 2016-10-09 18:28:49 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:28:49 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:28:49 --> Utf8 Class Initialized
INFO - 2016-10-09 18:28:49 --> URI Class Initialized
INFO - 2016-10-09 18:28:49 --> Router Class Initialized
INFO - 2016-10-09 18:28:49 --> Output Class Initialized
INFO - 2016-10-09 18:28:49 --> Security Class Initialized
DEBUG - 2016-10-09 18:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:28:49 --> Input Class Initialized
INFO - 2016-10-09 18:28:49 --> Language Class Initialized
INFO - 2016-10-09 18:28:49 --> Language Class Initialized
INFO - 2016-10-09 18:28:49 --> Config Class Initialized
INFO - 2016-10-09 18:28:49 --> Loader Class Initialized
INFO - 2016-10-09 18:28:49 --> Helper loaded: url_helper
INFO - 2016-10-09 18:28:49 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:28:49 --> Controller Class Initialized
DEBUG - 2016-10-09 18:28:49 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:28:49 --> Model Class Initialized
INFO - 2016-10-09 18:28:50 --> Model Class Initialized
ERROR - 2016-10-09 18:28:50 --> Unable to delete cache file for admin/index/do_save_jaminan/sertifikat
INFO - 2016-10-09 18:28:50 --> Database Driver Class Initialized
INFO - 2016-10-09 18:28:50 --> Final output sent to browser
DEBUG - 2016-10-09 18:28:50 --> Total execution time: 0.9376
INFO - 2016-10-09 18:29:09 --> Config Class Initialized
INFO - 2016-10-09 18:29:09 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:29:10 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:29:10 --> Utf8 Class Initialized
INFO - 2016-10-09 18:29:10 --> URI Class Initialized
INFO - 2016-10-09 18:29:10 --> Router Class Initialized
INFO - 2016-10-09 18:29:10 --> Output Class Initialized
INFO - 2016-10-09 18:29:10 --> Security Class Initialized
DEBUG - 2016-10-09 18:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:29:10 --> Input Class Initialized
INFO - 2016-10-09 18:29:10 --> Language Class Initialized
INFO - 2016-10-09 18:29:10 --> Language Class Initialized
INFO - 2016-10-09 18:29:10 --> Config Class Initialized
INFO - 2016-10-09 18:29:10 --> Loader Class Initialized
INFO - 2016-10-09 18:29:10 --> Helper loaded: url_helper
INFO - 2016-10-09 18:29:10 --> Database Driver Class Initialized
INFO - 2016-10-09 18:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:29:10 --> Controller Class Initialized
DEBUG - 2016-10-09 18:29:10 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:29:10 --> Model Class Initialized
INFO - 2016-10-09 18:29:10 --> Model Class Initialized
ERROR - 2016-10-09 18:29:10 --> Unable to delete cache file for admin/index/do_save_jaminan/sertifikat
INFO - 2016-10-09 18:29:10 --> Database Driver Class Initialized
INFO - 2016-10-09 18:29:10 --> Final output sent to browser
DEBUG - 2016-10-09 18:29:11 --> Total execution time: 1.0545
INFO - 2016-10-09 18:31:37 --> Config Class Initialized
INFO - 2016-10-09 18:31:37 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:31:37 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:31:37 --> Utf8 Class Initialized
INFO - 2016-10-09 18:31:37 --> URI Class Initialized
INFO - 2016-10-09 18:31:37 --> Router Class Initialized
INFO - 2016-10-09 18:31:37 --> Output Class Initialized
INFO - 2016-10-09 18:31:37 --> Security Class Initialized
DEBUG - 2016-10-09 18:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:31:37 --> Input Class Initialized
INFO - 2016-10-09 18:31:37 --> Language Class Initialized
INFO - 2016-10-09 18:31:37 --> Language Class Initialized
INFO - 2016-10-09 18:31:37 --> Config Class Initialized
INFO - 2016-10-09 18:31:37 --> Loader Class Initialized
INFO - 2016-10-09 18:31:37 --> Helper loaded: url_helper
INFO - 2016-10-09 18:31:38 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:31:38 --> Controller Class Initialized
DEBUG - 2016-10-09 18:31:38 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:31:38 --> Model Class Initialized
INFO - 2016-10-09 18:31:38 --> Model Class Initialized
ERROR - 2016-10-09 18:31:38 --> Unable to delete cache file for admin/index/batal/0a57cb53ba59c46fc4b692527a38a87c78d84028
INFO - 2016-10-09 18:31:38 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:38 --> Final output sent to browser
DEBUG - 2016-10-09 18:31:38 --> Total execution time: 1.1872
INFO - 2016-10-09 18:31:39 --> Config Class Initialized
INFO - 2016-10-09 18:31:39 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:31:39 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:31:39 --> Utf8 Class Initialized
INFO - 2016-10-09 18:31:39 --> URI Class Initialized
INFO - 2016-10-09 18:31:39 --> Router Class Initialized
INFO - 2016-10-09 18:31:39 --> Output Class Initialized
INFO - 2016-10-09 18:31:39 --> Security Class Initialized
DEBUG - 2016-10-09 18:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:31:39 --> Input Class Initialized
INFO - 2016-10-09 18:31:39 --> Language Class Initialized
INFO - 2016-10-09 18:31:39 --> Language Class Initialized
INFO - 2016-10-09 18:31:39 --> Config Class Initialized
INFO - 2016-10-09 18:31:39 --> Loader Class Initialized
INFO - 2016-10-09 18:31:39 --> Helper loaded: url_helper
INFO - 2016-10-09 18:31:39 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:31:39 --> Controller Class Initialized
DEBUG - 2016-10-09 18:31:39 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:31:39 --> Model Class Initialized
INFO - 2016-10-09 18:31:39 --> Model Class Initialized
ERROR - 2016-10-09 18:31:39 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-10-09 18:31:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 18:31:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 18:31:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 18:31:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-10-09 18:31:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 18:31:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 18:31:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:42 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:42 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:42 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:42 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:42 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:42 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:42 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:42 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:42 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:42 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:42 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:42 --> Database Driver Class Initialized
INFO - 2016-10-09 18:31:42 --> Database Driver Class Initialized
DEBUG - 2016-10-09 18:31:42 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 18:31:42 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 18:31:42 --> Final output sent to browser
DEBUG - 2016-10-09 18:31:42 --> Total execution time: 3.7707
INFO - 2016-10-09 18:32:18 --> Config Class Initialized
INFO - 2016-10-09 18:32:18 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:32:18 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:32:18 --> Utf8 Class Initialized
INFO - 2016-10-09 18:32:18 --> URI Class Initialized
INFO - 2016-10-09 18:32:18 --> Router Class Initialized
INFO - 2016-10-09 18:32:18 --> Output Class Initialized
INFO - 2016-10-09 18:32:18 --> Security Class Initialized
DEBUG - 2016-10-09 18:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:32:18 --> Input Class Initialized
INFO - 2016-10-09 18:32:18 --> Language Class Initialized
INFO - 2016-10-09 18:32:18 --> Language Class Initialized
INFO - 2016-10-09 18:32:18 --> Config Class Initialized
INFO - 2016-10-09 18:32:18 --> Loader Class Initialized
INFO - 2016-10-09 18:32:18 --> Helper loaded: url_helper
INFO - 2016-10-09 18:32:18 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:32:19 --> Controller Class Initialized
DEBUG - 2016-10-09 18:32:19 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:32:19 --> Model Class Initialized
INFO - 2016-10-09 18:32:19 --> Model Class Initialized
ERROR - 2016-10-09 18:32:19 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-09 18:32:19 --> Anggota MX_Controller Initialized
INFO - 2016-10-09 18:32:19 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:19 --> Final output sent to browser
DEBUG - 2016-10-09 18:32:19 --> Total execution time: 0.8950
INFO - 2016-10-09 18:32:22 --> Config Class Initialized
INFO - 2016-10-09 18:32:22 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:32:22 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:32:22 --> Utf8 Class Initialized
INFO - 2016-10-09 18:32:22 --> URI Class Initialized
INFO - 2016-10-09 18:32:22 --> Router Class Initialized
INFO - 2016-10-09 18:32:22 --> Output Class Initialized
INFO - 2016-10-09 18:32:22 --> Security Class Initialized
DEBUG - 2016-10-09 18:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:32:22 --> Input Class Initialized
INFO - 2016-10-09 18:32:22 --> Language Class Initialized
INFO - 2016-10-09 18:32:22 --> Language Class Initialized
INFO - 2016-10-09 18:32:22 --> Config Class Initialized
INFO - 2016-10-09 18:32:22 --> Loader Class Initialized
INFO - 2016-10-09 18:32:22 --> Helper loaded: url_helper
INFO - 2016-10-09 18:32:22 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:32:23 --> Controller Class Initialized
DEBUG - 2016-10-09 18:32:23 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:32:23 --> Model Class Initialized
INFO - 2016-10-09 18:32:23 --> Model Class Initialized
ERROR - 2016-10-09 18:32:23 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-10-09 18:32:23 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 18:32:23 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 18:32:23 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 18:32:23 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_umum.php
DEBUG - 2016-10-09 18:32:23 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 18:32:23 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 18:32:23 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:23 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:23 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:23 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:23 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:23 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:23 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:23 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:23 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:23 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:23 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:23 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:23 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:23 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:23 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:25 --> Database Driver Class Initialized
DEBUG - 2016-10-09 18:32:25 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 18:32:25 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 18:32:25 --> Final output sent to browser
DEBUG - 2016-10-09 18:32:25 --> Total execution time: 3.5296
INFO - 2016-10-09 18:32:43 --> Config Class Initialized
INFO - 2016-10-09 18:32:43 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:32:43 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:32:43 --> Utf8 Class Initialized
INFO - 2016-10-09 18:32:43 --> URI Class Initialized
INFO - 2016-10-09 18:32:43 --> Router Class Initialized
INFO - 2016-10-09 18:32:43 --> Output Class Initialized
INFO - 2016-10-09 18:32:43 --> Security Class Initialized
DEBUG - 2016-10-09 18:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:32:43 --> Input Class Initialized
INFO - 2016-10-09 18:32:43 --> Language Class Initialized
INFO - 2016-10-09 18:32:43 --> Language Class Initialized
INFO - 2016-10-09 18:32:43 --> Config Class Initialized
INFO - 2016-10-09 18:32:44 --> Loader Class Initialized
INFO - 2016-10-09 18:32:44 --> Helper loaded: url_helper
INFO - 2016-10-09 18:32:44 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:32:44 --> Controller Class Initialized
DEBUG - 2016-10-09 18:32:44 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:32:44 --> Model Class Initialized
INFO - 2016-10-09 18:32:44 --> Model Class Initialized
ERROR - 2016-10-09 18:32:44 --> Unable to delete cache file for admin/index/do_ajukan_pinjaman
INFO - 2016-10-09 18:32:44 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:44 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:44 --> Final output sent to browser
DEBUG - 2016-10-09 18:32:44 --> Total execution time: 0.9730
INFO - 2016-10-09 18:32:52 --> Config Class Initialized
INFO - 2016-10-09 18:32:52 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:32:52 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:32:53 --> Utf8 Class Initialized
INFO - 2016-10-09 18:32:53 --> URI Class Initialized
INFO - 2016-10-09 18:32:53 --> Router Class Initialized
INFO - 2016-10-09 18:32:53 --> Output Class Initialized
INFO - 2016-10-09 18:32:53 --> Security Class Initialized
DEBUG - 2016-10-09 18:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:32:53 --> Input Class Initialized
INFO - 2016-10-09 18:32:53 --> Language Class Initialized
INFO - 2016-10-09 18:32:53 --> Language Class Initialized
INFO - 2016-10-09 18:32:53 --> Config Class Initialized
INFO - 2016-10-09 18:32:53 --> Loader Class Initialized
INFO - 2016-10-09 18:32:53 --> Helper loaded: url_helper
INFO - 2016-10-09 18:32:53 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:32:53 --> Controller Class Initialized
DEBUG - 2016-10-09 18:32:53 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:32:53 --> Model Class Initialized
INFO - 2016-10-09 18:32:53 --> Model Class Initialized
ERROR - 2016-10-09 18:32:53 --> Unable to delete cache file for admin/index/do_save_jaminan/sertifikat
INFO - 2016-10-09 18:32:53 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:53 --> Final output sent to browser
DEBUG - 2016-10-09 18:32:53 --> Total execution time: 0.9960
INFO - 2016-10-09 18:33:53 --> Config Class Initialized
INFO - 2016-10-09 18:33:53 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:33:53 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:33:53 --> Utf8 Class Initialized
INFO - 2016-10-09 18:33:53 --> URI Class Initialized
INFO - 2016-10-09 18:33:53 --> Router Class Initialized
INFO - 2016-10-09 18:33:54 --> Output Class Initialized
INFO - 2016-10-09 18:33:54 --> Security Class Initialized
DEBUG - 2016-10-09 18:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:33:54 --> Input Class Initialized
INFO - 2016-10-09 18:33:54 --> Language Class Initialized
INFO - 2016-10-09 18:33:54 --> Language Class Initialized
INFO - 2016-10-09 18:33:54 --> Config Class Initialized
INFO - 2016-10-09 18:33:54 --> Loader Class Initialized
INFO - 2016-10-09 18:33:54 --> Helper loaded: url_helper
INFO - 2016-10-09 18:33:54 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:33:54 --> Controller Class Initialized
DEBUG - 2016-10-09 18:33:54 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:33:54 --> Model Class Initialized
INFO - 2016-10-09 18:33:54 --> Model Class Initialized
ERROR - 2016-10-09 18:33:54 --> Unable to delete cache file for admin/index/batal/7719a1c782a1ba91c031a682a0a2f8658209adbf
INFO - 2016-10-09 18:33:54 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:54 --> Final output sent to browser
DEBUG - 2016-10-09 18:33:54 --> Total execution time: 0.9959
INFO - 2016-10-09 18:33:55 --> Config Class Initialized
INFO - 2016-10-09 18:33:55 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:33:55 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:33:55 --> Utf8 Class Initialized
INFO - 2016-10-09 18:33:55 --> URI Class Initialized
INFO - 2016-10-09 18:33:55 --> Router Class Initialized
INFO - 2016-10-09 18:33:55 --> Output Class Initialized
INFO - 2016-10-09 18:33:55 --> Security Class Initialized
DEBUG - 2016-10-09 18:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:33:55 --> Input Class Initialized
INFO - 2016-10-09 18:33:55 --> Language Class Initialized
INFO - 2016-10-09 18:33:55 --> Language Class Initialized
INFO - 2016-10-09 18:33:55 --> Config Class Initialized
INFO - 2016-10-09 18:33:55 --> Loader Class Initialized
INFO - 2016-10-09 18:33:55 --> Helper loaded: url_helper
INFO - 2016-10-09 18:33:55 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:33:55 --> Controller Class Initialized
DEBUG - 2016-10-09 18:33:55 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:33:55 --> Model Class Initialized
INFO - 2016-10-09 18:33:55 --> Model Class Initialized
ERROR - 2016-10-09 18:33:55 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-10-09 18:33:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 18:33:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 18:33:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 18:33:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-10-09 18:33:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 18:33:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 18:33:56 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:56 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:56 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:56 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:56 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:56 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:56 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:56 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:56 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:56 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:56 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:56 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:56 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:56 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:56 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:56 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:56 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:56 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:56 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:57 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:57 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:57 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:57 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:57 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:57 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:57 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:57 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:57 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:57 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:57 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:57 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:57 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:57 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:57 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:57 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:57 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:57 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:57 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:57 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:57 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:57 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:57 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:57 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:57 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:57 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:57 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:58 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:58 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:58 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:58 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:58 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:58 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:58 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:58 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:58 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:58 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:58 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:58 --> Database Driver Class Initialized
INFO - 2016-10-09 18:33:58 --> Database Driver Class Initialized
DEBUG - 2016-10-09 18:33:58 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 18:33:58 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 18:33:58 --> Final output sent to browser
DEBUG - 2016-10-09 18:33:58 --> Total execution time: 3.6340
INFO - 2016-10-09 18:34:15 --> Config Class Initialized
INFO - 2016-10-09 18:34:15 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:34:15 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:34:15 --> Utf8 Class Initialized
INFO - 2016-10-09 18:34:15 --> URI Class Initialized
INFO - 2016-10-09 18:34:15 --> Router Class Initialized
INFO - 2016-10-09 18:34:15 --> Output Class Initialized
INFO - 2016-10-09 18:34:15 --> Security Class Initialized
DEBUG - 2016-10-09 18:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:34:15 --> Input Class Initialized
INFO - 2016-10-09 18:34:15 --> Language Class Initialized
INFO - 2016-10-09 18:34:15 --> Language Class Initialized
INFO - 2016-10-09 18:34:15 --> Config Class Initialized
INFO - 2016-10-09 18:34:15 --> Loader Class Initialized
INFO - 2016-10-09 18:34:15 --> Helper loaded: url_helper
INFO - 2016-10-09 18:34:15 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:34:15 --> Controller Class Initialized
DEBUG - 2016-10-09 18:34:15 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:34:15 --> Model Class Initialized
INFO - 2016-10-09 18:34:15 --> Model Class Initialized
ERROR - 2016-10-09 18:34:15 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-09 18:34:16 --> Anggota MX_Controller Initialized
INFO - 2016-10-09 18:34:16 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:16 --> Final output sent to browser
DEBUG - 2016-10-09 18:34:16 --> Total execution time: 1.0523
INFO - 2016-10-09 18:34:21 --> Config Class Initialized
INFO - 2016-10-09 18:34:21 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:34:21 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:34:21 --> Utf8 Class Initialized
INFO - 2016-10-09 18:34:22 --> URI Class Initialized
INFO - 2016-10-09 18:34:22 --> Router Class Initialized
INFO - 2016-10-09 18:34:22 --> Output Class Initialized
INFO - 2016-10-09 18:34:22 --> Security Class Initialized
DEBUG - 2016-10-09 18:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:34:22 --> Input Class Initialized
INFO - 2016-10-09 18:34:22 --> Language Class Initialized
INFO - 2016-10-09 18:34:22 --> Language Class Initialized
INFO - 2016-10-09 18:34:22 --> Config Class Initialized
INFO - 2016-10-09 18:34:22 --> Loader Class Initialized
INFO - 2016-10-09 18:34:22 --> Helper loaded: url_helper
INFO - 2016-10-09 18:34:22 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:34:22 --> Controller Class Initialized
DEBUG - 2016-10-09 18:34:22 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:34:22 --> Model Class Initialized
INFO - 2016-10-09 18:34:22 --> Model Class Initialized
ERROR - 2016-10-09 18:34:22 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-10-09 18:34:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 18:34:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 18:34:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 18:34:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-10-09 18:34:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 18:34:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 18:34:22 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:22 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:22 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:23 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:23 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:23 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:23 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:23 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:23 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:23 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:23 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:23 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:23 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:23 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:23 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:23 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:23 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:23 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:23 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:23 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:23 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:23 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:23 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:23 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:23 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:23 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:25 --> Database Driver Class Initialized
DEBUG - 2016-10-09 18:34:25 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 18:34:25 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 18:34:25 --> Final output sent to browser
DEBUG - 2016-10-09 18:34:25 --> Total execution time: 3.7217
INFO - 2016-10-09 18:34:38 --> Config Class Initialized
INFO - 2016-10-09 18:34:38 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:34:38 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:34:38 --> Utf8 Class Initialized
INFO - 2016-10-09 18:34:38 --> URI Class Initialized
INFO - 2016-10-09 18:34:38 --> Router Class Initialized
INFO - 2016-10-09 18:34:38 --> Output Class Initialized
INFO - 2016-10-09 18:34:38 --> Security Class Initialized
DEBUG - 2016-10-09 18:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:34:38 --> Input Class Initialized
INFO - 2016-10-09 18:34:38 --> Language Class Initialized
INFO - 2016-10-09 18:34:39 --> Language Class Initialized
INFO - 2016-10-09 18:34:39 --> Config Class Initialized
INFO - 2016-10-09 18:34:39 --> Loader Class Initialized
INFO - 2016-10-09 18:34:39 --> Helper loaded: url_helper
INFO - 2016-10-09 18:34:39 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:34:39 --> Controller Class Initialized
DEBUG - 2016-10-09 18:34:39 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:34:39 --> Model Class Initialized
INFO - 2016-10-09 18:34:39 --> Model Class Initialized
ERROR - 2016-10-09 18:34:39 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-10-09 18:34:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 18:34:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 18:34:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 18:34:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-10-09 18:34:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 18:34:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 18:34:39 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:39 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:39 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:39 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:39 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:42 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:42 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:42 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:42 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:42 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:42 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:42 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:42 --> Database Driver Class Initialized
INFO - 2016-10-09 18:34:42 --> Database Driver Class Initialized
DEBUG - 2016-10-09 18:34:42 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 18:34:42 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 18:34:42 --> Final output sent to browser
DEBUG - 2016-10-09 18:34:42 --> Total execution time: 3.9777
INFO - 2016-10-09 18:35:22 --> Config Class Initialized
INFO - 2016-10-09 18:35:22 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:35:22 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:35:22 --> Utf8 Class Initialized
INFO - 2016-10-09 18:35:22 --> URI Class Initialized
INFO - 2016-10-09 18:35:22 --> Router Class Initialized
INFO - 2016-10-09 18:35:22 --> Output Class Initialized
INFO - 2016-10-09 18:35:22 --> Security Class Initialized
DEBUG - 2016-10-09 18:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:35:22 --> Input Class Initialized
INFO - 2016-10-09 18:35:22 --> Language Class Initialized
INFO - 2016-10-09 18:35:22 --> Language Class Initialized
INFO - 2016-10-09 18:35:22 --> Config Class Initialized
INFO - 2016-10-09 18:35:22 --> Loader Class Initialized
INFO - 2016-10-09 18:35:22 --> Helper loaded: url_helper
INFO - 2016-10-09 18:35:22 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:35:22 --> Controller Class Initialized
DEBUG - 2016-10-09 18:35:22 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:35:22 --> Model Class Initialized
INFO - 2016-10-09 18:35:23 --> Model Class Initialized
ERROR - 2016-10-09 18:35:23 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-09 18:35:23 --> Anggota MX_Controller Initialized
INFO - 2016-10-09 18:35:23 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:23 --> Final output sent to browser
DEBUG - 2016-10-09 18:35:23 --> Total execution time: 0.9556
INFO - 2016-10-09 18:35:31 --> Config Class Initialized
INFO - 2016-10-09 18:35:31 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:35:31 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:35:31 --> Utf8 Class Initialized
INFO - 2016-10-09 18:35:31 --> URI Class Initialized
INFO - 2016-10-09 18:35:32 --> Router Class Initialized
INFO - 2016-10-09 18:35:32 --> Output Class Initialized
INFO - 2016-10-09 18:35:32 --> Security Class Initialized
DEBUG - 2016-10-09 18:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:35:32 --> Input Class Initialized
INFO - 2016-10-09 18:35:32 --> Language Class Initialized
INFO - 2016-10-09 18:35:32 --> Language Class Initialized
INFO - 2016-10-09 18:35:32 --> Config Class Initialized
INFO - 2016-10-09 18:35:32 --> Loader Class Initialized
INFO - 2016-10-09 18:35:32 --> Helper loaded: url_helper
INFO - 2016-10-09 18:35:32 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:35:32 --> Controller Class Initialized
DEBUG - 2016-10-09 18:35:32 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:35:32 --> Model Class Initialized
INFO - 2016-10-09 18:35:32 --> Model Class Initialized
ERROR - 2016-10-09 18:35:32 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-10-09 18:35:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 18:35:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 18:35:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 18:35:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_umum.php
DEBUG - 2016-10-09 18:35:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 18:35:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 18:35:32 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:32 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:32 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:32 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:33 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:33 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:33 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:33 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:33 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:33 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:33 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:33 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:33 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:33 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:33 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:33 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:33 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:33 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:33 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:33 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:33 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:33 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:33 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:33 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:33 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:33 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:33 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:33 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:34 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:34 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:34 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:34 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:34 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:34 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:34 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:34 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:34 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:34 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:34 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:34 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:34 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:34 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:34 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:34 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:34 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:34 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:34 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:34 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:34 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:34 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:34 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:34 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:34 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:35 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:35 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:35 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:35 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:35 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:35 --> Database Driver Class Initialized
INFO - 2016-10-09 18:35:35 --> Database Driver Class Initialized
DEBUG - 2016-10-09 18:35:35 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 18:35:35 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 18:35:35 --> Final output sent to browser
DEBUG - 2016-10-09 18:35:35 --> Total execution time: 3.5094
INFO - 2016-10-09 18:36:05 --> Config Class Initialized
INFO - 2016-10-09 18:36:05 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:36:05 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:36:05 --> Utf8 Class Initialized
INFO - 2016-10-09 18:36:05 --> URI Class Initialized
INFO - 2016-10-09 18:36:05 --> Router Class Initialized
INFO - 2016-10-09 18:36:05 --> Output Class Initialized
INFO - 2016-10-09 18:36:05 --> Security Class Initialized
DEBUG - 2016-10-09 18:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:36:05 --> Input Class Initialized
INFO - 2016-10-09 18:36:05 --> Language Class Initialized
INFO - 2016-10-09 18:36:06 --> Language Class Initialized
INFO - 2016-10-09 18:36:06 --> Config Class Initialized
INFO - 2016-10-09 18:36:06 --> Loader Class Initialized
INFO - 2016-10-09 18:36:06 --> Helper loaded: url_helper
INFO - 2016-10-09 18:36:06 --> Database Driver Class Initialized
INFO - 2016-10-09 18:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:36:06 --> Controller Class Initialized
DEBUG - 2016-10-09 18:36:06 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:36:06 --> Model Class Initialized
INFO - 2016-10-09 18:36:06 --> Model Class Initialized
ERROR - 2016-10-09 18:36:06 --> Unable to delete cache file for admin/index/do_ajukan_pinjaman
INFO - 2016-10-09 18:36:06 --> Database Driver Class Initialized
INFO - 2016-10-09 18:36:06 --> Database Driver Class Initialized
INFO - 2016-10-09 18:36:06 --> Final output sent to browser
DEBUG - 2016-10-09 18:36:06 --> Total execution time: 1.1244
INFO - 2016-10-09 18:36:17 --> Config Class Initialized
INFO - 2016-10-09 18:36:17 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:36:17 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:36:17 --> Utf8 Class Initialized
INFO - 2016-10-09 18:36:17 --> URI Class Initialized
INFO - 2016-10-09 18:36:17 --> Router Class Initialized
INFO - 2016-10-09 18:36:17 --> Output Class Initialized
INFO - 2016-10-09 18:36:17 --> Security Class Initialized
DEBUG - 2016-10-09 18:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:36:18 --> Input Class Initialized
INFO - 2016-10-09 18:36:18 --> Language Class Initialized
INFO - 2016-10-09 18:36:18 --> Language Class Initialized
INFO - 2016-10-09 18:36:18 --> Config Class Initialized
INFO - 2016-10-09 18:36:18 --> Loader Class Initialized
INFO - 2016-10-09 18:36:18 --> Helper loaded: url_helper
INFO - 2016-10-09 18:36:18 --> Database Driver Class Initialized
INFO - 2016-10-09 18:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:36:18 --> Controller Class Initialized
DEBUG - 2016-10-09 18:36:18 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:36:18 --> Model Class Initialized
INFO - 2016-10-09 18:36:18 --> Model Class Initialized
ERROR - 2016-10-09 18:36:18 --> Unable to delete cache file for admin/index/do_save_jaminan/sertifikat
INFO - 2016-10-09 18:36:18 --> Database Driver Class Initialized
INFO - 2016-10-09 18:36:18 --> Final output sent to browser
DEBUG - 2016-10-09 18:36:18 --> Total execution time: 0.8819
INFO - 2016-10-09 18:38:57 --> Config Class Initialized
INFO - 2016-10-09 18:38:58 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:38:58 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:38:58 --> Utf8 Class Initialized
INFO - 2016-10-09 18:38:58 --> URI Class Initialized
INFO - 2016-10-09 18:38:58 --> Router Class Initialized
INFO - 2016-10-09 18:38:58 --> Output Class Initialized
INFO - 2016-10-09 18:38:58 --> Security Class Initialized
DEBUG - 2016-10-09 18:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:38:58 --> Input Class Initialized
INFO - 2016-10-09 18:38:58 --> Language Class Initialized
INFO - 2016-10-09 18:38:58 --> Language Class Initialized
INFO - 2016-10-09 18:38:58 --> Config Class Initialized
INFO - 2016-10-09 18:38:58 --> Loader Class Initialized
INFO - 2016-10-09 18:38:58 --> Helper loaded: url_helper
INFO - 2016-10-09 18:38:58 --> Database Driver Class Initialized
INFO - 2016-10-09 18:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:38:58 --> Controller Class Initialized
DEBUG - 2016-10-09 18:38:58 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:38:58 --> Model Class Initialized
INFO - 2016-10-09 18:38:58 --> Model Class Initialized
ERROR - 2016-10-09 18:38:59 --> Unable to delete cache file for admin/index/batal/22d200f8670dbdb3e253a90eee5098477c95c23d
INFO - 2016-10-09 18:38:59 --> Database Driver Class Initialized
INFO - 2016-10-09 18:38:59 --> Final output sent to browser
DEBUG - 2016-10-09 18:38:59 --> Total execution time: 1.8540
INFO - 2016-10-09 18:39:00 --> Config Class Initialized
INFO - 2016-10-09 18:39:00 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:39:00 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:39:00 --> Utf8 Class Initialized
INFO - 2016-10-09 18:39:00 --> URI Class Initialized
INFO - 2016-10-09 18:39:00 --> Router Class Initialized
INFO - 2016-10-09 18:39:00 --> Output Class Initialized
INFO - 2016-10-09 18:39:00 --> Security Class Initialized
DEBUG - 2016-10-09 18:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:39:00 --> Input Class Initialized
INFO - 2016-10-09 18:39:00 --> Language Class Initialized
INFO - 2016-10-09 18:39:00 --> Language Class Initialized
INFO - 2016-10-09 18:39:00 --> Config Class Initialized
INFO - 2016-10-09 18:39:00 --> Loader Class Initialized
INFO - 2016-10-09 18:39:00 --> Helper loaded: url_helper
INFO - 2016-10-09 18:39:00 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:39:01 --> Controller Class Initialized
DEBUG - 2016-10-09 18:39:01 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:39:01 --> Model Class Initialized
INFO - 2016-10-09 18:39:01 --> Model Class Initialized
ERROR - 2016-10-09 18:39:01 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-10-09 18:39:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 18:39:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 18:39:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 18:39:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-10-09 18:39:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 18:39:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 18:39:01 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:01 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:01 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:01 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:01 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:01 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:01 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:01 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:02 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:02 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:02 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:02 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:02 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:02 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:02 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:02 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:02 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:02 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:02 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:02 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:02 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:03 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:03 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:03 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:03 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:03 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:03 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:03 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:03 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:03 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:03 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:03 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:03 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:03 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:03 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:04 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:04 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:04 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:04 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:04 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:04 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:05 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:05 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:05 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:05 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:05 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:05 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:05 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:05 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:05 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:05 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:06 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:06 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:06 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:06 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:06 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:06 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:06 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:06 --> Database Driver Class Initialized
DEBUG - 2016-10-09 18:39:06 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 18:39:06 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 18:39:06 --> Final output sent to browser
DEBUG - 2016-10-09 18:39:06 --> Total execution time: 6.6997
INFO - 2016-10-09 18:39:15 --> Config Class Initialized
INFO - 2016-10-09 18:39:15 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:39:15 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:39:15 --> Utf8 Class Initialized
INFO - 2016-10-09 18:39:15 --> URI Class Initialized
INFO - 2016-10-09 18:39:15 --> Router Class Initialized
INFO - 2016-10-09 18:39:15 --> Output Class Initialized
INFO - 2016-10-09 18:39:15 --> Security Class Initialized
DEBUG - 2016-10-09 18:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:39:15 --> Input Class Initialized
INFO - 2016-10-09 18:39:15 --> Language Class Initialized
INFO - 2016-10-09 18:39:15 --> Language Class Initialized
INFO - 2016-10-09 18:39:15 --> Config Class Initialized
INFO - 2016-10-09 18:39:15 --> Loader Class Initialized
INFO - 2016-10-09 18:39:15 --> Helper loaded: url_helper
INFO - 2016-10-09 18:39:15 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:39:15 --> Controller Class Initialized
DEBUG - 2016-10-09 18:39:15 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:39:16 --> Model Class Initialized
INFO - 2016-10-09 18:39:16 --> Model Class Initialized
ERROR - 2016-10-09 18:39:16 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-09 18:39:16 --> Anggota MX_Controller Initialized
INFO - 2016-10-09 18:39:16 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:16 --> Final output sent to browser
DEBUG - 2016-10-09 18:39:16 --> Total execution time: 1.0751
INFO - 2016-10-09 18:39:20 --> Config Class Initialized
INFO - 2016-10-09 18:39:20 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:39:20 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:39:20 --> Utf8 Class Initialized
INFO - 2016-10-09 18:39:20 --> URI Class Initialized
INFO - 2016-10-09 18:39:20 --> Router Class Initialized
INFO - 2016-10-09 18:39:20 --> Output Class Initialized
INFO - 2016-10-09 18:39:21 --> Security Class Initialized
DEBUG - 2016-10-09 18:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:39:21 --> Input Class Initialized
INFO - 2016-10-09 18:39:21 --> Language Class Initialized
INFO - 2016-10-09 18:39:21 --> Language Class Initialized
INFO - 2016-10-09 18:39:21 --> Config Class Initialized
INFO - 2016-10-09 18:39:21 --> Loader Class Initialized
INFO - 2016-10-09 18:39:21 --> Helper loaded: url_helper
INFO - 2016-10-09 18:39:21 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:39:21 --> Controller Class Initialized
DEBUG - 2016-10-09 18:39:21 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:39:21 --> Model Class Initialized
INFO - 2016-10-09 18:39:21 --> Model Class Initialized
ERROR - 2016-10-09 18:39:21 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-10-09 18:39:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 18:39:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 18:39:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 18:39:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_umum.php
DEBUG - 2016-10-09 18:39:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 18:39:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 18:39:22 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:22 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:22 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:22 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:22 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:22 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:22 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:22 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:22 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:22 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:22 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:23 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:23 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:23 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:23 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:23 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:23 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:23 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:23 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:23 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:23 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:23 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:23 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:23 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:26 --> Database Driver Class Initialized
DEBUG - 2016-10-09 18:39:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 18:39:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 18:39:26 --> Final output sent to browser
DEBUG - 2016-10-09 18:39:26 --> Total execution time: 5.7997
INFO - 2016-10-09 18:39:43 --> Config Class Initialized
INFO - 2016-10-09 18:39:43 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:39:43 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:39:43 --> Utf8 Class Initialized
INFO - 2016-10-09 18:39:44 --> URI Class Initialized
INFO - 2016-10-09 18:39:44 --> Router Class Initialized
INFO - 2016-10-09 18:39:44 --> Output Class Initialized
INFO - 2016-10-09 18:39:44 --> Security Class Initialized
DEBUG - 2016-10-09 18:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:39:44 --> Input Class Initialized
INFO - 2016-10-09 18:39:44 --> Language Class Initialized
INFO - 2016-10-09 18:39:44 --> Language Class Initialized
INFO - 2016-10-09 18:39:44 --> Config Class Initialized
INFO - 2016-10-09 18:39:44 --> Loader Class Initialized
INFO - 2016-10-09 18:39:44 --> Helper loaded: url_helper
INFO - 2016-10-09 18:39:44 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:39:44 --> Controller Class Initialized
DEBUG - 2016-10-09 18:39:44 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:39:44 --> Model Class Initialized
INFO - 2016-10-09 18:39:44 --> Model Class Initialized
ERROR - 2016-10-09 18:39:44 --> Unable to delete cache file for admin/index/do_ajukan_pinjaman
INFO - 2016-10-09 18:39:44 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:44 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:44 --> Final output sent to browser
DEBUG - 2016-10-09 18:39:45 --> Total execution time: 1.1615
INFO - 2016-10-09 18:39:52 --> Config Class Initialized
INFO - 2016-10-09 18:39:53 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:39:53 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:39:53 --> Utf8 Class Initialized
INFO - 2016-10-09 18:39:53 --> URI Class Initialized
INFO - 2016-10-09 18:39:53 --> Router Class Initialized
INFO - 2016-10-09 18:39:53 --> Output Class Initialized
INFO - 2016-10-09 18:39:53 --> Security Class Initialized
DEBUG - 2016-10-09 18:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:39:53 --> Input Class Initialized
INFO - 2016-10-09 18:39:53 --> Language Class Initialized
INFO - 2016-10-09 18:39:53 --> Language Class Initialized
INFO - 2016-10-09 18:39:53 --> Config Class Initialized
INFO - 2016-10-09 18:39:53 --> Loader Class Initialized
INFO - 2016-10-09 18:39:53 --> Helper loaded: url_helper
INFO - 2016-10-09 18:39:53 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:39:53 --> Controller Class Initialized
DEBUG - 2016-10-09 18:39:53 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:39:53 --> Model Class Initialized
INFO - 2016-10-09 18:39:53 --> Model Class Initialized
ERROR - 2016-10-09 18:39:53 --> Unable to delete cache file for admin/index/do_save_jaminan/sertifikat
INFO - 2016-10-09 18:39:53 --> Database Driver Class Initialized
INFO - 2016-10-09 18:39:54 --> Final output sent to browser
DEBUG - 2016-10-09 18:39:54 --> Total execution time: 1.1696
INFO - 2016-10-09 18:41:21 --> Config Class Initialized
INFO - 2016-10-09 18:41:21 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:41:21 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:41:21 --> Utf8 Class Initialized
INFO - 2016-10-09 18:41:21 --> URI Class Initialized
INFO - 2016-10-09 18:41:21 --> Router Class Initialized
INFO - 2016-10-09 18:41:21 --> Output Class Initialized
INFO - 2016-10-09 18:41:21 --> Security Class Initialized
DEBUG - 2016-10-09 18:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:41:21 --> Input Class Initialized
INFO - 2016-10-09 18:41:21 --> Language Class Initialized
INFO - 2016-10-09 18:41:21 --> Language Class Initialized
INFO - 2016-10-09 18:41:21 --> Config Class Initialized
INFO - 2016-10-09 18:41:21 --> Loader Class Initialized
INFO - 2016-10-09 18:41:21 --> Helper loaded: url_helper
INFO - 2016-10-09 18:41:21 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:41:21 --> Controller Class Initialized
DEBUG - 2016-10-09 18:41:21 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:41:21 --> Model Class Initialized
INFO - 2016-10-09 18:41:22 --> Model Class Initialized
ERROR - 2016-10-09 18:41:22 --> Unable to delete cache file for admin/index/batal/632667547e7cd3e0466547863e1207a8c0c0c549
INFO - 2016-10-09 18:41:22 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:22 --> Final output sent to browser
DEBUG - 2016-10-09 18:41:22 --> Total execution time: 1.3053
INFO - 2016-10-09 18:41:22 --> Config Class Initialized
INFO - 2016-10-09 18:41:22 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:41:22 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:41:22 --> Utf8 Class Initialized
INFO - 2016-10-09 18:41:22 --> URI Class Initialized
INFO - 2016-10-09 18:41:22 --> Router Class Initialized
INFO - 2016-10-09 18:41:23 --> Output Class Initialized
INFO - 2016-10-09 18:41:23 --> Security Class Initialized
DEBUG - 2016-10-09 18:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:41:23 --> Input Class Initialized
INFO - 2016-10-09 18:41:23 --> Language Class Initialized
INFO - 2016-10-09 18:41:23 --> Language Class Initialized
INFO - 2016-10-09 18:41:23 --> Config Class Initialized
INFO - 2016-10-09 18:41:23 --> Loader Class Initialized
INFO - 2016-10-09 18:41:23 --> Helper loaded: url_helper
INFO - 2016-10-09 18:41:23 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:41:23 --> Controller Class Initialized
DEBUG - 2016-10-09 18:41:23 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:41:23 --> Model Class Initialized
INFO - 2016-10-09 18:41:23 --> Model Class Initialized
ERROR - 2016-10-09 18:41:23 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-10-09 18:41:23 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 18:41:23 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 18:41:23 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 18:41:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-10-09 18:41:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 18:41:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 18:41:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:27 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:27 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:27 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:27 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:27 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:27 --> Database Driver Class Initialized
DEBUG - 2016-10-09 18:41:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 18:41:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 18:41:27 --> Final output sent to browser
DEBUG - 2016-10-09 18:41:27 --> Total execution time: 4.7521
INFO - 2016-10-09 18:41:33 --> Config Class Initialized
INFO - 2016-10-09 18:41:33 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:41:33 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:41:33 --> Utf8 Class Initialized
INFO - 2016-10-09 18:41:33 --> URI Class Initialized
INFO - 2016-10-09 18:41:33 --> Router Class Initialized
INFO - 2016-10-09 18:41:33 --> Output Class Initialized
INFO - 2016-10-09 18:41:33 --> Security Class Initialized
DEBUG - 2016-10-09 18:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:41:33 --> Input Class Initialized
INFO - 2016-10-09 18:41:33 --> Language Class Initialized
INFO - 2016-10-09 18:41:33 --> Language Class Initialized
INFO - 2016-10-09 18:41:33 --> Config Class Initialized
INFO - 2016-10-09 18:41:34 --> Loader Class Initialized
INFO - 2016-10-09 18:41:34 --> Helper loaded: url_helper
INFO - 2016-10-09 18:41:34 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:41:34 --> Controller Class Initialized
DEBUG - 2016-10-09 18:41:34 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:41:34 --> Model Class Initialized
INFO - 2016-10-09 18:41:34 --> Model Class Initialized
ERROR - 2016-10-09 18:41:34 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-09 18:41:34 --> Anggota MX_Controller Initialized
INFO - 2016-10-09 18:41:34 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:34 --> Final output sent to browser
DEBUG - 2016-10-09 18:41:34 --> Total execution time: 1.5968
INFO - 2016-10-09 18:41:39 --> Config Class Initialized
INFO - 2016-10-09 18:41:39 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:41:39 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:41:39 --> Utf8 Class Initialized
INFO - 2016-10-09 18:41:39 --> URI Class Initialized
INFO - 2016-10-09 18:41:39 --> Router Class Initialized
INFO - 2016-10-09 18:41:39 --> Output Class Initialized
INFO - 2016-10-09 18:41:40 --> Security Class Initialized
DEBUG - 2016-10-09 18:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:41:40 --> Input Class Initialized
INFO - 2016-10-09 18:41:40 --> Language Class Initialized
INFO - 2016-10-09 18:41:40 --> Language Class Initialized
INFO - 2016-10-09 18:41:40 --> Config Class Initialized
INFO - 2016-10-09 18:41:40 --> Loader Class Initialized
INFO - 2016-10-09 18:41:40 --> Helper loaded: url_helper
INFO - 2016-10-09 18:41:40 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:41:40 --> Controller Class Initialized
DEBUG - 2016-10-09 18:41:40 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:41:40 --> Model Class Initialized
INFO - 2016-10-09 18:41:40 --> Model Class Initialized
ERROR - 2016-10-09 18:41:40 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-10-09 18:41:40 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 18:41:40 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 18:41:40 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 18:41:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_umum.php
DEBUG - 2016-10-09 18:41:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 18:41:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 18:41:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:41 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:42 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:42 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:42 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:42 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:42 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:42 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:42 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:42 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:42 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:42 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:42 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:42 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:42 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:42 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:42 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:42 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:42 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:43 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:43 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:43 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:43 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:43 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:43 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:43 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:43 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:43 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:43 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:43 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:43 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:43 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:43 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:43 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:43 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:44 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:44 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:44 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:44 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:44 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:44 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:44 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:44 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:44 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:44 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:44 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:44 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:45 --> Database Driver Class Initialized
INFO - 2016-10-09 18:41:45 --> Database Driver Class Initialized
DEBUG - 2016-10-09 18:41:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 18:41:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 18:41:45 --> Final output sent to browser
DEBUG - 2016-10-09 18:41:45 --> Total execution time: 5.4921
INFO - 2016-10-09 18:42:03 --> Config Class Initialized
INFO - 2016-10-09 18:42:03 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:42:03 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:42:03 --> Utf8 Class Initialized
INFO - 2016-10-09 18:42:03 --> URI Class Initialized
INFO - 2016-10-09 18:42:03 --> Router Class Initialized
INFO - 2016-10-09 18:42:03 --> Output Class Initialized
INFO - 2016-10-09 18:42:03 --> Security Class Initialized
DEBUG - 2016-10-09 18:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:42:03 --> Input Class Initialized
INFO - 2016-10-09 18:42:03 --> Language Class Initialized
INFO - 2016-10-09 18:42:03 --> Language Class Initialized
INFO - 2016-10-09 18:42:03 --> Config Class Initialized
INFO - 2016-10-09 18:42:03 --> Loader Class Initialized
INFO - 2016-10-09 18:42:03 --> Helper loaded: url_helper
INFO - 2016-10-09 18:42:03 --> Database Driver Class Initialized
INFO - 2016-10-09 18:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:42:04 --> Controller Class Initialized
DEBUG - 2016-10-09 18:42:04 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:42:04 --> Model Class Initialized
INFO - 2016-10-09 18:42:04 --> Model Class Initialized
ERROR - 2016-10-09 18:42:04 --> Unable to delete cache file for admin/index/do_ajukan_pinjaman
INFO - 2016-10-09 18:42:04 --> Database Driver Class Initialized
INFO - 2016-10-09 18:42:04 --> Database Driver Class Initialized
INFO - 2016-10-09 18:42:04 --> Final output sent to browser
DEBUG - 2016-10-09 18:42:04 --> Total execution time: 1.2945
INFO - 2016-10-09 18:42:16 --> Config Class Initialized
INFO - 2016-10-09 18:42:16 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:42:16 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:42:16 --> Utf8 Class Initialized
INFO - 2016-10-09 18:42:16 --> URI Class Initialized
INFO - 2016-10-09 18:42:16 --> Router Class Initialized
INFO - 2016-10-09 18:42:16 --> Output Class Initialized
INFO - 2016-10-09 18:42:16 --> Security Class Initialized
DEBUG - 2016-10-09 18:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:42:16 --> Input Class Initialized
INFO - 2016-10-09 18:42:16 --> Language Class Initialized
INFO - 2016-10-09 18:42:16 --> Language Class Initialized
INFO - 2016-10-09 18:42:16 --> Config Class Initialized
INFO - 2016-10-09 18:42:16 --> Loader Class Initialized
INFO - 2016-10-09 18:42:16 --> Helper loaded: url_helper
INFO - 2016-10-09 18:42:16 --> Database Driver Class Initialized
INFO - 2016-10-09 18:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:42:16 --> Controller Class Initialized
DEBUG - 2016-10-09 18:42:16 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:42:16 --> Model Class Initialized
INFO - 2016-10-09 18:42:16 --> Model Class Initialized
ERROR - 2016-10-09 18:42:16 --> Unable to delete cache file for admin/index/do_save_jaminan/sertifikat
INFO - 2016-10-09 18:42:17 --> Database Driver Class Initialized
INFO - 2016-10-09 18:42:17 --> Final output sent to browser
DEBUG - 2016-10-09 18:42:17 --> Total execution time: 1.1488
INFO - 2016-10-09 18:43:21 --> Config Class Initialized
INFO - 2016-10-09 18:43:21 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:43:21 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:43:21 --> Utf8 Class Initialized
INFO - 2016-10-09 18:43:21 --> URI Class Initialized
INFO - 2016-10-09 18:43:21 --> Router Class Initialized
INFO - 2016-10-09 18:43:21 --> Output Class Initialized
INFO - 2016-10-09 18:43:21 --> Security Class Initialized
DEBUG - 2016-10-09 18:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:43:21 --> Input Class Initialized
INFO - 2016-10-09 18:43:21 --> Language Class Initialized
INFO - 2016-10-09 18:43:22 --> Language Class Initialized
INFO - 2016-10-09 18:43:22 --> Config Class Initialized
INFO - 2016-10-09 18:43:22 --> Loader Class Initialized
INFO - 2016-10-09 18:43:22 --> Helper loaded: url_helper
INFO - 2016-10-09 18:43:22 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:43:22 --> Controller Class Initialized
DEBUG - 2016-10-09 18:43:22 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:43:22 --> Model Class Initialized
INFO - 2016-10-09 18:43:22 --> Model Class Initialized
ERROR - 2016-10-09 18:43:22 --> Unable to delete cache file for admin/index/batal/cb4e5208b4cd87268b208e49452ed6e89a68e0b8
INFO - 2016-10-09 18:43:22 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:22 --> Final output sent to browser
DEBUG - 2016-10-09 18:43:22 --> Total execution time: 1.3386
INFO - 2016-10-09 18:43:22 --> Config Class Initialized
INFO - 2016-10-09 18:43:22 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:43:23 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:43:23 --> Utf8 Class Initialized
INFO - 2016-10-09 18:43:23 --> URI Class Initialized
INFO - 2016-10-09 18:43:23 --> Router Class Initialized
INFO - 2016-10-09 18:43:23 --> Output Class Initialized
INFO - 2016-10-09 18:43:23 --> Security Class Initialized
DEBUG - 2016-10-09 18:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:43:23 --> Input Class Initialized
INFO - 2016-10-09 18:43:23 --> Language Class Initialized
INFO - 2016-10-09 18:43:23 --> Language Class Initialized
INFO - 2016-10-09 18:43:23 --> Config Class Initialized
INFO - 2016-10-09 18:43:23 --> Loader Class Initialized
INFO - 2016-10-09 18:43:23 --> Helper loaded: url_helper
INFO - 2016-10-09 18:43:23 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:43:23 --> Controller Class Initialized
DEBUG - 2016-10-09 18:43:24 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:43:24 --> Model Class Initialized
INFO - 2016-10-09 18:43:24 --> Model Class Initialized
ERROR - 2016-10-09 18:43:24 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-10-09 18:43:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 18:43:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 18:43:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 18:43:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-10-09 18:43:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 18:43:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 18:43:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:24 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:26 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:27 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:27 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:27 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:27 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:27 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:27 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:27 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:27 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:27 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:27 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:27 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:27 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:27 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:27 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:27 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:27 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:27 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:28 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:28 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:28 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:28 --> Database Driver Class Initialized
INFO - 2016-10-09 18:43:28 --> Database Driver Class Initialized
DEBUG - 2016-10-09 18:43:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 18:43:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 18:43:28 --> Final output sent to browser
DEBUG - 2016-10-09 18:43:28 --> Total execution time: 5.4075
INFO - 2016-10-09 18:44:06 --> Config Class Initialized
INFO - 2016-10-09 18:44:06 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:44:06 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:44:06 --> Utf8 Class Initialized
INFO - 2016-10-09 18:44:06 --> URI Class Initialized
INFO - 2016-10-09 18:44:06 --> Router Class Initialized
INFO - 2016-10-09 18:44:06 --> Output Class Initialized
INFO - 2016-10-09 18:44:06 --> Security Class Initialized
DEBUG - 2016-10-09 18:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:44:07 --> Input Class Initialized
INFO - 2016-10-09 18:44:07 --> Language Class Initialized
INFO - 2016-10-09 18:44:07 --> Language Class Initialized
INFO - 2016-10-09 18:44:07 --> Config Class Initialized
INFO - 2016-10-09 18:44:07 --> Loader Class Initialized
INFO - 2016-10-09 18:44:07 --> Helper loaded: url_helper
INFO - 2016-10-09 18:44:07 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:44:07 --> Controller Class Initialized
DEBUG - 2016-10-09 18:44:07 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:44:07 --> Model Class Initialized
INFO - 2016-10-09 18:44:08 --> Model Class Initialized
ERROR - 2016-10-09 18:44:08 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-09 18:44:08 --> Anggota MX_Controller Initialized
INFO - 2016-10-09 18:44:08 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:08 --> Final output sent to browser
DEBUG - 2016-10-09 18:44:08 --> Total execution time: 2.2066
INFO - 2016-10-09 18:44:10 --> Config Class Initialized
INFO - 2016-10-09 18:44:10 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:44:10 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:44:10 --> Utf8 Class Initialized
INFO - 2016-10-09 18:44:10 --> URI Class Initialized
INFO - 2016-10-09 18:44:10 --> Router Class Initialized
INFO - 2016-10-09 18:44:10 --> Output Class Initialized
INFO - 2016-10-09 18:44:10 --> Security Class Initialized
DEBUG - 2016-10-09 18:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:44:11 --> Input Class Initialized
INFO - 2016-10-09 18:44:11 --> Language Class Initialized
INFO - 2016-10-09 18:44:11 --> Language Class Initialized
INFO - 2016-10-09 18:44:11 --> Config Class Initialized
INFO - 2016-10-09 18:44:11 --> Loader Class Initialized
INFO - 2016-10-09 18:44:11 --> Helper loaded: url_helper
INFO - 2016-10-09 18:44:11 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:44:11 --> Controller Class Initialized
DEBUG - 2016-10-09 18:44:11 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:44:11 --> Model Class Initialized
INFO - 2016-10-09 18:44:11 --> Model Class Initialized
ERROR - 2016-10-09 18:44:11 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-10-09 18:44:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 18:44:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 18:44:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 18:44:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_umum.php
DEBUG - 2016-10-09 18:44:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 18:44:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 18:44:11 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:12 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:12 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:12 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:12 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:12 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:12 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:12 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:12 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:12 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:12 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:12 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:12 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:12 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:12 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:12 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:12 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:12 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:12 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:12 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:13 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:13 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:13 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:13 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:13 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:13 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:13 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:13 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:13 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:13 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:13 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:13 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:13 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:13 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:13 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:13 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:13 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:13 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:13 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:14 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:14 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:14 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:14 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:14 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:14 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:14 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:14 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:14 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:14 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:14 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:14 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:14 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:14 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:14 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:14 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:14 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:14 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:14 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:15 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:15 --> Database Driver Class Initialized
DEBUG - 2016-10-09 18:44:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 18:44:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 18:44:15 --> Final output sent to browser
DEBUG - 2016-10-09 18:44:15 --> Total execution time: 4.6495
INFO - 2016-10-09 18:44:26 --> Config Class Initialized
INFO - 2016-10-09 18:44:26 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:44:26 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:44:26 --> Utf8 Class Initialized
INFO - 2016-10-09 18:44:27 --> URI Class Initialized
INFO - 2016-10-09 18:44:27 --> Router Class Initialized
INFO - 2016-10-09 18:44:27 --> Output Class Initialized
INFO - 2016-10-09 18:44:27 --> Security Class Initialized
DEBUG - 2016-10-09 18:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:44:27 --> Input Class Initialized
INFO - 2016-10-09 18:44:27 --> Language Class Initialized
INFO - 2016-10-09 18:44:27 --> Language Class Initialized
INFO - 2016-10-09 18:44:27 --> Config Class Initialized
INFO - 2016-10-09 18:44:27 --> Loader Class Initialized
INFO - 2016-10-09 18:44:27 --> Helper loaded: url_helper
INFO - 2016-10-09 18:44:28 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:44:28 --> Controller Class Initialized
DEBUG - 2016-10-09 18:44:28 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:44:28 --> Model Class Initialized
INFO - 2016-10-09 18:44:28 --> Model Class Initialized
ERROR - 2016-10-09 18:44:28 --> Unable to delete cache file for admin/index/do_ajukan_pinjaman
INFO - 2016-10-09 18:44:28 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:28 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:29 --> Final output sent to browser
DEBUG - 2016-10-09 18:44:29 --> Total execution time: 2.2984
INFO - 2016-10-09 18:44:43 --> Config Class Initialized
INFO - 2016-10-09 18:44:44 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:44:44 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:44:44 --> Utf8 Class Initialized
INFO - 2016-10-09 18:44:44 --> URI Class Initialized
INFO - 2016-10-09 18:44:44 --> Router Class Initialized
INFO - 2016-10-09 18:44:44 --> Output Class Initialized
INFO - 2016-10-09 18:44:44 --> Security Class Initialized
DEBUG - 2016-10-09 18:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:44:44 --> Input Class Initialized
INFO - 2016-10-09 18:44:44 --> Language Class Initialized
INFO - 2016-10-09 18:44:44 --> Language Class Initialized
INFO - 2016-10-09 18:44:44 --> Config Class Initialized
INFO - 2016-10-09 18:44:44 --> Loader Class Initialized
INFO - 2016-10-09 18:44:44 --> Helper loaded: url_helper
INFO - 2016-10-09 18:44:44 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:44:45 --> Controller Class Initialized
DEBUG - 2016-10-09 18:44:45 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:44:45 --> Model Class Initialized
INFO - 2016-10-09 18:44:45 --> Model Class Initialized
ERROR - 2016-10-09 18:44:45 --> Unable to delete cache file for admin/index/do_save_jaminan/sertifikat
INFO - 2016-10-09 18:44:45 --> Database Driver Class Initialized
INFO - 2016-10-09 18:44:45 --> Final output sent to browser
DEBUG - 2016-10-09 18:44:45 --> Total execution time: 1.4739
INFO - 2016-10-09 18:45:30 --> Config Class Initialized
INFO - 2016-10-09 18:45:30 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:45:30 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:45:30 --> Utf8 Class Initialized
INFO - 2016-10-09 18:45:30 --> URI Class Initialized
INFO - 2016-10-09 18:45:30 --> Router Class Initialized
INFO - 2016-10-09 18:45:30 --> Output Class Initialized
INFO - 2016-10-09 18:45:30 --> Security Class Initialized
DEBUG - 2016-10-09 18:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:45:30 --> Input Class Initialized
INFO - 2016-10-09 18:45:30 --> Language Class Initialized
INFO - 2016-10-09 18:45:30 --> Language Class Initialized
INFO - 2016-10-09 18:45:30 --> Config Class Initialized
INFO - 2016-10-09 18:45:31 --> Loader Class Initialized
INFO - 2016-10-09 18:45:31 --> Helper loaded: url_helper
INFO - 2016-10-09 18:45:31 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:45:31 --> Controller Class Initialized
DEBUG - 2016-10-09 18:45:31 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:45:31 --> Model Class Initialized
INFO - 2016-10-09 18:45:31 --> Model Class Initialized
ERROR - 2016-10-09 18:45:31 --> Unable to delete cache file for admin/index/batal/b6692ea5df920cad691c20319a6fffd7a4a766b8
INFO - 2016-10-09 18:45:31 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:31 --> Final output sent to browser
DEBUG - 2016-10-09 18:45:31 --> Total execution time: 1.5445
INFO - 2016-10-09 18:45:32 --> Config Class Initialized
INFO - 2016-10-09 18:45:32 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:45:32 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:45:32 --> Utf8 Class Initialized
INFO - 2016-10-09 18:45:32 --> URI Class Initialized
INFO - 2016-10-09 18:45:32 --> Router Class Initialized
INFO - 2016-10-09 18:45:32 --> Output Class Initialized
INFO - 2016-10-09 18:45:32 --> Security Class Initialized
DEBUG - 2016-10-09 18:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:45:32 --> Input Class Initialized
INFO - 2016-10-09 18:45:32 --> Language Class Initialized
INFO - 2016-10-09 18:45:32 --> Language Class Initialized
INFO - 2016-10-09 18:45:32 --> Config Class Initialized
INFO - 2016-10-09 18:45:32 --> Loader Class Initialized
INFO - 2016-10-09 18:45:32 --> Helper loaded: url_helper
INFO - 2016-10-09 18:45:32 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:45:33 --> Controller Class Initialized
DEBUG - 2016-10-09 18:45:33 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:45:33 --> Model Class Initialized
INFO - 2016-10-09 18:45:33 --> Model Class Initialized
ERROR - 2016-10-09 18:45:33 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-10-09 18:45:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 18:45:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 18:45:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 18:45:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-10-09 18:45:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 18:45:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 18:45:33 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:33 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:33 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:33 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:33 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:33 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:33 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:34 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:34 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:34 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:34 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:34 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:34 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:34 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:34 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:34 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:34 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:34 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:34 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:34 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:34 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:34 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:34 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:34 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:34 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:34 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:35 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:35 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:35 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:35 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:35 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:35 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:35 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:35 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:35 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:35 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:35 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:35 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:35 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:35 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:35 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:35 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:35 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:35 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:35 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:36 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:36 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:36 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:36 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:36 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:36 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:36 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:36 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:36 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:36 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:36 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:36 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:36 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:36 --> Database Driver Class Initialized
DEBUG - 2016-10-09 18:45:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 18:45:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 18:45:36 --> Final output sent to browser
DEBUG - 2016-10-09 18:45:36 --> Total execution time: 4.7852
INFO - 2016-10-09 18:45:42 --> Config Class Initialized
INFO - 2016-10-09 18:45:42 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:45:43 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:45:43 --> Utf8 Class Initialized
INFO - 2016-10-09 18:45:43 --> URI Class Initialized
INFO - 2016-10-09 18:45:43 --> Router Class Initialized
INFO - 2016-10-09 18:45:43 --> Output Class Initialized
INFO - 2016-10-09 18:45:43 --> Security Class Initialized
DEBUG - 2016-10-09 18:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:45:43 --> Input Class Initialized
INFO - 2016-10-09 18:45:43 --> Language Class Initialized
INFO - 2016-10-09 18:45:43 --> Language Class Initialized
INFO - 2016-10-09 18:45:43 --> Config Class Initialized
INFO - 2016-10-09 18:45:43 --> Loader Class Initialized
INFO - 2016-10-09 18:45:43 --> Helper loaded: url_helper
INFO - 2016-10-09 18:45:43 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:45:43 --> Controller Class Initialized
DEBUG - 2016-10-09 18:45:43 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:45:43 --> Model Class Initialized
INFO - 2016-10-09 18:45:43 --> Model Class Initialized
ERROR - 2016-10-09 18:45:43 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-09 18:45:43 --> Anggota MX_Controller Initialized
INFO - 2016-10-09 18:45:44 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:44 --> Final output sent to browser
DEBUG - 2016-10-09 18:45:44 --> Total execution time: 1.2022
INFO - 2016-10-09 18:45:48 --> Config Class Initialized
INFO - 2016-10-09 18:45:48 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:45:49 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:45:49 --> Utf8 Class Initialized
INFO - 2016-10-09 18:45:49 --> URI Class Initialized
INFO - 2016-10-09 18:45:49 --> Router Class Initialized
INFO - 2016-10-09 18:45:49 --> Output Class Initialized
INFO - 2016-10-09 18:45:49 --> Security Class Initialized
DEBUG - 2016-10-09 18:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:45:49 --> Input Class Initialized
INFO - 2016-10-09 18:45:49 --> Language Class Initialized
INFO - 2016-10-09 18:45:49 --> Language Class Initialized
INFO - 2016-10-09 18:45:49 --> Config Class Initialized
INFO - 2016-10-09 18:45:49 --> Loader Class Initialized
INFO - 2016-10-09 18:45:49 --> Helper loaded: url_helper
INFO - 2016-10-09 18:45:49 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:45:49 --> Controller Class Initialized
DEBUG - 2016-10-09 18:45:50 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:45:50 --> Model Class Initialized
INFO - 2016-10-09 18:45:50 --> Model Class Initialized
ERROR - 2016-10-09 18:45:50 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-10-09 18:45:50 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 18:45:50 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 18:45:50 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 18:45:50 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_umum.php
DEBUG - 2016-10-09 18:45:50 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 18:45:50 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 18:45:50 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:50 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:50 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:50 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:50 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:50 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:50 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:50 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:50 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:51 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:51 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:51 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:51 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:51 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:51 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:51 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:51 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:51 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:51 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:51 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:51 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:51 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:51 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:51 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:51 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:51 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:51 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:52 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:52 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:52 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:52 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:52 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:52 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:52 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:52 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:52 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:52 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:52 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:52 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:52 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:52 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:52 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:52 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:52 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:53 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:53 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:53 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:53 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:53 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:53 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:53 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:53 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:53 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:53 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:53 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:53 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:53 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:54 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:54 --> Database Driver Class Initialized
INFO - 2016-10-09 18:45:54 --> Database Driver Class Initialized
DEBUG - 2016-10-09 18:45:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 18:45:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 18:45:54 --> Final output sent to browser
DEBUG - 2016-10-09 18:45:54 --> Total execution time: 5.3708
INFO - 2016-10-09 18:46:03 --> Config Class Initialized
INFO - 2016-10-09 18:46:04 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:46:04 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:46:04 --> Utf8 Class Initialized
INFO - 2016-10-09 18:46:04 --> URI Class Initialized
INFO - 2016-10-09 18:46:04 --> Router Class Initialized
INFO - 2016-10-09 18:46:04 --> Output Class Initialized
INFO - 2016-10-09 18:46:04 --> Security Class Initialized
DEBUG - 2016-10-09 18:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:46:04 --> Input Class Initialized
INFO - 2016-10-09 18:46:04 --> Language Class Initialized
INFO - 2016-10-09 18:46:04 --> Language Class Initialized
INFO - 2016-10-09 18:46:04 --> Config Class Initialized
INFO - 2016-10-09 18:46:04 --> Loader Class Initialized
INFO - 2016-10-09 18:46:04 --> Helper loaded: url_helper
INFO - 2016-10-09 18:46:04 --> Database Driver Class Initialized
INFO - 2016-10-09 18:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:46:04 --> Controller Class Initialized
DEBUG - 2016-10-09 18:46:04 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:46:04 --> Model Class Initialized
INFO - 2016-10-09 18:46:05 --> Model Class Initialized
ERROR - 2016-10-09 18:46:05 --> Unable to delete cache file for admin/index/do_ajukan_pinjaman
INFO - 2016-10-09 18:46:05 --> Database Driver Class Initialized
INFO - 2016-10-09 18:46:05 --> Database Driver Class Initialized
INFO - 2016-10-09 18:46:05 --> Final output sent to browser
DEBUG - 2016-10-09 18:46:05 --> Total execution time: 1.4746
INFO - 2016-10-09 18:46:20 --> Config Class Initialized
INFO - 2016-10-09 18:46:20 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:46:20 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:46:20 --> Utf8 Class Initialized
INFO - 2016-10-09 18:46:20 --> URI Class Initialized
INFO - 2016-10-09 18:46:21 --> Router Class Initialized
INFO - 2016-10-09 18:46:21 --> Output Class Initialized
INFO - 2016-10-09 18:46:21 --> Security Class Initialized
DEBUG - 2016-10-09 18:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:46:21 --> Input Class Initialized
INFO - 2016-10-09 18:46:21 --> Language Class Initialized
INFO - 2016-10-09 18:46:21 --> Language Class Initialized
INFO - 2016-10-09 18:46:21 --> Config Class Initialized
INFO - 2016-10-09 18:46:21 --> Loader Class Initialized
INFO - 2016-10-09 18:46:21 --> Helper loaded: url_helper
INFO - 2016-10-09 18:46:21 --> Database Driver Class Initialized
INFO - 2016-10-09 18:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:46:21 --> Controller Class Initialized
DEBUG - 2016-10-09 18:46:21 --> Index MX_Controller Initialized
INFO - 2016-10-09 18:46:21 --> Model Class Initialized
INFO - 2016-10-09 18:46:21 --> Model Class Initialized
ERROR - 2016-10-09 18:46:21 --> Unable to delete cache file for admin/index/do_save_jaminan/sertifikat
INFO - 2016-10-09 18:46:21 --> Database Driver Class Initialized
INFO - 2016-10-09 18:46:21 --> Final output sent to browser
DEBUG - 2016-10-09 18:46:22 --> Total execution time: 1.2031
INFO - 2016-10-09 19:04:51 --> Config Class Initialized
INFO - 2016-10-09 19:04:51 --> Hooks Class Initialized
DEBUG - 2016-10-09 19:04:52 --> UTF-8 Support Enabled
INFO - 2016-10-09 19:04:52 --> Utf8 Class Initialized
INFO - 2016-10-09 19:04:52 --> URI Class Initialized
INFO - 2016-10-09 19:04:52 --> Router Class Initialized
INFO - 2016-10-09 19:04:52 --> Output Class Initialized
INFO - 2016-10-09 19:04:52 --> Security Class Initialized
DEBUG - 2016-10-09 19:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 19:04:52 --> Input Class Initialized
INFO - 2016-10-09 19:04:52 --> Language Class Initialized
INFO - 2016-10-09 19:04:52 --> Language Class Initialized
INFO - 2016-10-09 19:04:52 --> Config Class Initialized
INFO - 2016-10-09 19:04:52 --> Loader Class Initialized
INFO - 2016-10-09 19:04:52 --> Helper loaded: url_helper
INFO - 2016-10-09 19:04:52 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 19:04:53 --> Controller Class Initialized
DEBUG - 2016-10-09 19:04:53 --> Index MX_Controller Initialized
INFO - 2016-10-09 19:04:53 --> Model Class Initialized
INFO - 2016-10-09 19:04:53 --> Model Class Initialized
ERROR - 2016-10-09 19:04:53 --> Unable to delete cache file for admin/index/finish_pinjaman/f1f836cb4ea6efb2a0b1b99f41ad8b103eff4b59
INFO - 2016-10-09 19:04:53 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:53 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:53 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:53 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:53 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:53 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:53 --> Final output sent to browser
DEBUG - 2016-10-09 19:04:54 --> Total execution time: 2.1352
INFO - 2016-10-09 19:04:54 --> Config Class Initialized
INFO - 2016-10-09 19:04:54 --> Hooks Class Initialized
DEBUG - 2016-10-09 19:04:54 --> UTF-8 Support Enabled
INFO - 2016-10-09 19:04:54 --> Utf8 Class Initialized
INFO - 2016-10-09 19:04:54 --> URI Class Initialized
INFO - 2016-10-09 19:04:54 --> Router Class Initialized
INFO - 2016-10-09 19:04:54 --> Output Class Initialized
INFO - 2016-10-09 19:04:55 --> Security Class Initialized
DEBUG - 2016-10-09 19:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 19:04:55 --> Input Class Initialized
INFO - 2016-10-09 19:04:55 --> Language Class Initialized
INFO - 2016-10-09 19:04:55 --> Language Class Initialized
INFO - 2016-10-09 19:04:55 --> Config Class Initialized
INFO - 2016-10-09 19:04:55 --> Loader Class Initialized
INFO - 2016-10-09 19:04:55 --> Helper loaded: url_helper
INFO - 2016-10-09 19:04:55 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 19:04:55 --> Controller Class Initialized
DEBUG - 2016-10-09 19:04:55 --> Index MX_Controller Initialized
INFO - 2016-10-09 19:04:55 --> Model Class Initialized
INFO - 2016-10-09 19:04:55 --> Model Class Initialized
ERROR - 2016-10-09 19:04:55 --> Unable to delete cache file for admin/index/data_peminjam
DEBUG - 2016-10-09 19:04:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 19:04:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 19:04:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 19:04:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_peminjam.php
DEBUG - 2016-10-09 19:04:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 19:04:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 19:04:56 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:56 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:56 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:56 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:56 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:56 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:56 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:56 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:56 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:56 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:56 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:56 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:56 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:57 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:57 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:57 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:57 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:57 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:57 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:57 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:57 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:57 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:57 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:57 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:57 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:57 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:57 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:58 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:58 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:58 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:58 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:58 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:58 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:58 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:58 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:58 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:58 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:58 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:58 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:58 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:58 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:58 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:58 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:58 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:58 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:59 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:59 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:59 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:59 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:59 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:59 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:59 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:59 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:59 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:59 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:59 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:59 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:59 --> Database Driver Class Initialized
INFO - 2016-10-09 19:04:59 --> Database Driver Class Initialized
DEBUG - 2016-10-09 19:05:00 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 19:05:00 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 19:05:00 --> Final output sent to browser
DEBUG - 2016-10-09 19:05:00 --> Total execution time: 5.6134
INFO - 2016-10-09 19:05:08 --> Config Class Initialized
INFO - 2016-10-09 19:05:08 --> Hooks Class Initialized
DEBUG - 2016-10-09 19:05:08 --> UTF-8 Support Enabled
INFO - 2016-10-09 19:05:08 --> Utf8 Class Initialized
INFO - 2016-10-09 19:05:08 --> URI Class Initialized
INFO - 2016-10-09 19:05:08 --> Router Class Initialized
INFO - 2016-10-09 19:05:08 --> Output Class Initialized
INFO - 2016-10-09 19:05:08 --> Security Class Initialized
DEBUG - 2016-10-09 19:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 19:05:08 --> Input Class Initialized
INFO - 2016-10-09 19:05:08 --> Language Class Initialized
INFO - 2016-10-09 19:05:08 --> Language Class Initialized
INFO - 2016-10-09 19:05:08 --> Config Class Initialized
INFO - 2016-10-09 19:05:08 --> Loader Class Initialized
INFO - 2016-10-09 19:05:08 --> Helper loaded: url_helper
INFO - 2016-10-09 19:05:08 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 19:05:09 --> Controller Class Initialized
DEBUG - 2016-10-09 19:05:09 --> Index MX_Controller Initialized
INFO - 2016-10-09 19:05:09 --> Model Class Initialized
INFO - 2016-10-09 19:05:09 --> Model Class Initialized
ERROR - 2016-10-09 19:05:09 --> Unable to delete cache file for admin/index/list_jaminan
DEBUG - 2016-10-09 19:05:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 19:05:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 19:05:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 19:05:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/jaminan.php
DEBUG - 2016-10-09 19:05:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 19:05:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 19:05:09 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:09 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:09 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:09 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:09 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:10 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:10 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:10 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:10 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:10 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:10 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:10 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:10 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:10 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:10 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:10 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:10 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:10 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:10 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:10 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:10 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:10 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:10 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:11 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:11 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:11 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:11 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:11 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:11 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:11 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:11 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:11 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:11 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:11 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:11 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:11 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:11 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:11 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:11 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:11 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:11 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:12 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:12 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:12 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:12 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:12 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:12 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:12 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:12 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:12 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:12 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:12 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:12 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:12 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:12 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:12 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:12 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:12 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:13 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:13 --> Database Driver Class Initialized
DEBUG - 2016-10-09 19:05:13 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 19:05:13 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 19:05:13 --> Final output sent to browser
DEBUG - 2016-10-09 19:05:13 --> Total execution time: 5.4467
INFO - 2016-10-09 19:05:40 --> Config Class Initialized
INFO - 2016-10-09 19:05:41 --> Hooks Class Initialized
DEBUG - 2016-10-09 19:05:41 --> UTF-8 Support Enabled
INFO - 2016-10-09 19:05:41 --> Utf8 Class Initialized
INFO - 2016-10-09 19:05:41 --> URI Class Initialized
INFO - 2016-10-09 19:05:41 --> Router Class Initialized
INFO - 2016-10-09 19:05:41 --> Output Class Initialized
INFO - 2016-10-09 19:05:41 --> Security Class Initialized
DEBUG - 2016-10-09 19:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 19:05:41 --> Input Class Initialized
INFO - 2016-10-09 19:05:41 --> Language Class Initialized
INFO - 2016-10-09 19:05:41 --> Language Class Initialized
INFO - 2016-10-09 19:05:41 --> Config Class Initialized
INFO - 2016-10-09 19:05:41 --> Loader Class Initialized
INFO - 2016-10-09 19:05:41 --> Helper loaded: url_helper
INFO - 2016-10-09 19:05:41 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 19:05:41 --> Controller Class Initialized
DEBUG - 2016-10-09 19:05:41 --> Index MX_Controller Initialized
INFO - 2016-10-09 19:05:42 --> Model Class Initialized
INFO - 2016-10-09 19:05:42 --> Model Class Initialized
ERROR - 2016-10-09 19:05:42 --> Unable to delete cache file for admin/index/list_jaminan
DEBUG - 2016-10-09 19:05:42 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 19:05:42 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 19:05:42 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 19:05:42 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/jaminan.php
DEBUG - 2016-10-09 19:05:42 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 19:05:42 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 19:05:42 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:42 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:42 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:42 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:42 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:42 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:42 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:42 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:42 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:42 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:43 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:43 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:43 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:43 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:43 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:43 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:43 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:43 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:43 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:43 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:43 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:43 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:43 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:43 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:43 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:44 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:44 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:44 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:44 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:44 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:44 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:44 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:44 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:44 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:44 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:44 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:44 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:44 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:45 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:45 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:45 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:45 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:45 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:45 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:45 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:45 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:45 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:45 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:45 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:45 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:45 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:45 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:45 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:45 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:45 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:45 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:46 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:46 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:46 --> Database Driver Class Initialized
INFO - 2016-10-09 19:05:46 --> Database Driver Class Initialized
DEBUG - 2016-10-09 19:05:46 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 19:05:46 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 19:05:46 --> Final output sent to browser
DEBUG - 2016-10-09 19:05:46 --> Total execution time: 5.4311
INFO - 2016-10-09 19:06:57 --> Config Class Initialized
INFO - 2016-10-09 19:06:57 --> Hooks Class Initialized
DEBUG - 2016-10-09 19:06:57 --> UTF-8 Support Enabled
INFO - 2016-10-09 19:06:57 --> Utf8 Class Initialized
INFO - 2016-10-09 19:06:57 --> URI Class Initialized
INFO - 2016-10-09 19:06:57 --> Router Class Initialized
INFO - 2016-10-09 19:06:57 --> Output Class Initialized
INFO - 2016-10-09 19:06:57 --> Security Class Initialized
DEBUG - 2016-10-09 19:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 19:06:57 --> Input Class Initialized
INFO - 2016-10-09 19:06:57 --> Language Class Initialized
INFO - 2016-10-09 19:06:57 --> Language Class Initialized
INFO - 2016-10-09 19:06:57 --> Config Class Initialized
INFO - 2016-10-09 19:06:57 --> Loader Class Initialized
INFO - 2016-10-09 19:06:57 --> Helper loaded: url_helper
INFO - 2016-10-09 19:06:58 --> Database Driver Class Initialized
INFO - 2016-10-09 19:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 19:06:58 --> Controller Class Initialized
DEBUG - 2016-10-09 19:06:58 --> Index MX_Controller Initialized
INFO - 2016-10-09 19:06:58 --> Model Class Initialized
INFO - 2016-10-09 19:06:58 --> Model Class Initialized
ERROR - 2016-10-09 19:06:58 --> Unable to delete cache file for admin/index/list_jaminan
DEBUG - 2016-10-09 19:06:58 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 19:06:58 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 19:06:58 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 19:06:58 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/jaminan.php
DEBUG - 2016-10-09 19:06:58 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 19:06:58 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 19:06:58 --> Database Driver Class Initialized
INFO - 2016-10-09 19:06:58 --> Database Driver Class Initialized
INFO - 2016-10-09 19:06:58 --> Database Driver Class Initialized
INFO - 2016-10-09 19:06:58 --> Database Driver Class Initialized
INFO - 2016-10-09 19:06:58 --> Database Driver Class Initialized
INFO - 2016-10-09 19:06:58 --> Database Driver Class Initialized
INFO - 2016-10-09 19:06:58 --> Database Driver Class Initialized
INFO - 2016-10-09 19:06:58 --> Database Driver Class Initialized
INFO - 2016-10-09 19:06:59 --> Database Driver Class Initialized
INFO - 2016-10-09 19:06:59 --> Database Driver Class Initialized
INFO - 2016-10-09 19:06:59 --> Database Driver Class Initialized
INFO - 2016-10-09 19:06:59 --> Database Driver Class Initialized
INFO - 2016-10-09 19:06:59 --> Database Driver Class Initialized
INFO - 2016-10-09 19:06:59 --> Database Driver Class Initialized
INFO - 2016-10-09 19:06:59 --> Database Driver Class Initialized
INFO - 2016-10-09 19:06:59 --> Database Driver Class Initialized
INFO - 2016-10-09 19:06:59 --> Database Driver Class Initialized
INFO - 2016-10-09 19:06:59 --> Database Driver Class Initialized
INFO - 2016-10-09 19:06:59 --> Database Driver Class Initialized
INFO - 2016-10-09 19:06:59 --> Database Driver Class Initialized
INFO - 2016-10-09 19:06:59 --> Database Driver Class Initialized
INFO - 2016-10-09 19:06:59 --> Database Driver Class Initialized
INFO - 2016-10-09 19:06:59 --> Database Driver Class Initialized
INFO - 2016-10-09 19:06:59 --> Database Driver Class Initialized
INFO - 2016-10-09 19:06:59 --> Database Driver Class Initialized
INFO - 2016-10-09 19:06:59 --> Database Driver Class Initialized
INFO - 2016-10-09 19:06:59 --> Database Driver Class Initialized
INFO - 2016-10-09 19:07:00 --> Database Driver Class Initialized
INFO - 2016-10-09 19:07:00 --> Database Driver Class Initialized
INFO - 2016-10-09 19:07:00 --> Database Driver Class Initialized
INFO - 2016-10-09 19:07:00 --> Database Driver Class Initialized
INFO - 2016-10-09 19:07:00 --> Database Driver Class Initialized
INFO - 2016-10-09 19:07:00 --> Database Driver Class Initialized
INFO - 2016-10-09 19:07:00 --> Database Driver Class Initialized
INFO - 2016-10-09 19:07:00 --> Database Driver Class Initialized
INFO - 2016-10-09 19:07:00 --> Database Driver Class Initialized
INFO - 2016-10-09 19:07:00 --> Database Driver Class Initialized
INFO - 2016-10-09 19:07:00 --> Database Driver Class Initialized
INFO - 2016-10-09 19:07:00 --> Database Driver Class Initialized
INFO - 2016-10-09 19:07:00 --> Database Driver Class Initialized
INFO - 2016-10-09 19:07:00 --> Database Driver Class Initialized
INFO - 2016-10-09 19:07:00 --> Database Driver Class Initialized
INFO - 2016-10-09 19:07:01 --> Database Driver Class Initialized
INFO - 2016-10-09 19:07:01 --> Database Driver Class Initialized
INFO - 2016-10-09 19:07:01 --> Database Driver Class Initialized
INFO - 2016-10-09 19:07:01 --> Database Driver Class Initialized
INFO - 2016-10-09 19:07:01 --> Database Driver Class Initialized
INFO - 2016-10-09 19:07:01 --> Database Driver Class Initialized
INFO - 2016-10-09 19:07:01 --> Database Driver Class Initialized
INFO - 2016-10-09 19:07:01 --> Database Driver Class Initialized
INFO - 2016-10-09 19:07:01 --> Database Driver Class Initialized
INFO - 2016-10-09 19:07:01 --> Database Driver Class Initialized
INFO - 2016-10-09 19:07:01 --> Database Driver Class Initialized
INFO - 2016-10-09 19:07:01 --> Database Driver Class Initialized
INFO - 2016-10-09 19:07:01 --> Database Driver Class Initialized
INFO - 2016-10-09 19:07:01 --> Database Driver Class Initialized
INFO - 2016-10-09 19:07:01 --> Database Driver Class Initialized
INFO - 2016-10-09 19:07:01 --> Database Driver Class Initialized
INFO - 2016-10-09 19:07:01 --> Database Driver Class Initialized
INFO - 2016-10-09 19:07:01 --> Database Driver Class Initialized
DEBUG - 2016-10-09 19:07:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 19:07:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 19:07:02 --> Final output sent to browser
DEBUG - 2016-10-09 19:07:02 --> Total execution time: 4.8283
INFO - 2016-10-09 19:09:20 --> Config Class Initialized
INFO - 2016-10-09 19:09:20 --> Hooks Class Initialized
DEBUG - 2016-10-09 19:09:20 --> UTF-8 Support Enabled
INFO - 2016-10-09 19:09:21 --> Utf8 Class Initialized
INFO - 2016-10-09 19:09:21 --> URI Class Initialized
INFO - 2016-10-09 19:09:21 --> Router Class Initialized
INFO - 2016-10-09 19:09:21 --> Output Class Initialized
INFO - 2016-10-09 19:09:21 --> Security Class Initialized
DEBUG - 2016-10-09 19:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 19:09:21 --> Input Class Initialized
INFO - 2016-10-09 19:09:21 --> Language Class Initialized
INFO - 2016-10-09 19:09:22 --> Language Class Initialized
INFO - 2016-10-09 19:09:22 --> Config Class Initialized
INFO - 2016-10-09 19:09:22 --> Loader Class Initialized
INFO - 2016-10-09 19:09:22 --> Helper loaded: url_helper
INFO - 2016-10-09 19:09:22 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 19:09:22 --> Controller Class Initialized
DEBUG - 2016-10-09 19:09:22 --> Index MX_Controller Initialized
INFO - 2016-10-09 19:09:22 --> Model Class Initialized
INFO - 2016-10-09 19:09:22 --> Model Class Initialized
ERROR - 2016-10-09 19:09:22 --> Unable to delete cache file for admin/index/list_jaminan
DEBUG - 2016-10-09 19:09:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 19:09:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 19:09:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 19:09:23 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/jaminan.php
DEBUG - 2016-10-09 19:09:23 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 19:09:23 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 19:09:23 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:23 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:23 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:23 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:23 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:23 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:23 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:23 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:23 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:23 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:23 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:23 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:23 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:23 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:23 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:24 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:24 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:24 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:24 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:24 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:24 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:24 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:24 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:24 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:24 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:24 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:24 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:24 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:24 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:24 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:25 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:25 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:25 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:25 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:25 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:25 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:25 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:25 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:25 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:25 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:25 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:25 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:25 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:25 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:25 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:25 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:25 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:26 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:26 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:26 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:26 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:26 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:26 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:26 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:26 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:26 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:26 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:26 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:26 --> Database Driver Class Initialized
INFO - 2016-10-09 19:09:26 --> Database Driver Class Initialized
DEBUG - 2016-10-09 19:09:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 19:09:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 19:09:27 --> Final output sent to browser
DEBUG - 2016-10-09 19:09:27 --> Total execution time: 6.2068
INFO - 2016-10-09 19:10:44 --> Config Class Initialized
INFO - 2016-10-09 19:10:44 --> Hooks Class Initialized
DEBUG - 2016-10-09 19:10:44 --> UTF-8 Support Enabled
INFO - 2016-10-09 19:10:44 --> Utf8 Class Initialized
INFO - 2016-10-09 19:10:44 --> URI Class Initialized
INFO - 2016-10-09 19:10:44 --> Router Class Initialized
INFO - 2016-10-09 19:10:44 --> Output Class Initialized
INFO - 2016-10-09 19:10:45 --> Security Class Initialized
DEBUG - 2016-10-09 19:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 19:10:45 --> Input Class Initialized
INFO - 2016-10-09 19:10:45 --> Language Class Initialized
INFO - 2016-10-09 19:10:45 --> Language Class Initialized
INFO - 2016-10-09 19:10:45 --> Config Class Initialized
INFO - 2016-10-09 19:10:45 --> Loader Class Initialized
INFO - 2016-10-09 19:10:45 --> Helper loaded: url_helper
INFO - 2016-10-09 19:10:45 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 19:10:45 --> Controller Class Initialized
DEBUG - 2016-10-09 19:10:45 --> Index MX_Controller Initialized
INFO - 2016-10-09 19:10:45 --> Model Class Initialized
INFO - 2016-10-09 19:10:45 --> Model Class Initialized
ERROR - 2016-10-09 19:10:45 --> Unable to delete cache file for admin/index/list_jaminan
DEBUG - 2016-10-09 19:10:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 19:10:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 19:10:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 19:10:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/jaminan.php
DEBUG - 2016-10-09 19:10:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 19:10:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 19:10:46 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:46 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:46 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:46 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:46 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:46 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:46 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:46 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:46 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:46 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:46 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:46 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:46 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:46 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:46 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:46 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:46 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:46 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:46 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:47 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:47 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:47 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:47 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:47 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:47 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:47 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:47 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:47 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:47 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:47 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:47 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:47 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:47 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:47 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:48 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:48 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:48 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:48 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:48 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:48 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:48 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:48 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:48 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:48 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:48 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:48 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:48 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:48 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:48 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:48 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:48 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:48 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:49 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:49 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:49 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:49 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:49 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:49 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:49 --> Database Driver Class Initialized
INFO - 2016-10-09 19:10:49 --> Database Driver Class Initialized
DEBUG - 2016-10-09 19:10:49 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 19:10:49 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 19:10:49 --> Final output sent to browser
DEBUG - 2016-10-09 19:10:49 --> Total execution time: 4.9580
INFO - 2016-10-09 19:12:01 --> Config Class Initialized
INFO - 2016-10-09 19:12:01 --> Hooks Class Initialized
DEBUG - 2016-10-09 19:12:01 --> UTF-8 Support Enabled
INFO - 2016-10-09 19:12:01 --> Utf8 Class Initialized
INFO - 2016-10-09 19:12:01 --> URI Class Initialized
INFO - 2016-10-09 19:12:01 --> Router Class Initialized
INFO - 2016-10-09 19:12:01 --> Output Class Initialized
INFO - 2016-10-09 19:12:01 --> Security Class Initialized
DEBUG - 2016-10-09 19:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 19:12:01 --> Input Class Initialized
INFO - 2016-10-09 19:12:01 --> Language Class Initialized
INFO - 2016-10-09 19:12:01 --> Language Class Initialized
INFO - 2016-10-09 19:12:02 --> Config Class Initialized
INFO - 2016-10-09 19:12:02 --> Loader Class Initialized
INFO - 2016-10-09 19:12:02 --> Helper loaded: url_helper
INFO - 2016-10-09 19:12:02 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 19:12:02 --> Controller Class Initialized
DEBUG - 2016-10-09 19:12:02 --> Index MX_Controller Initialized
INFO - 2016-10-09 19:12:02 --> Model Class Initialized
INFO - 2016-10-09 19:12:02 --> Model Class Initialized
ERROR - 2016-10-09 19:12:02 --> Unable to delete cache file for admin/index/list_jaminan
DEBUG - 2016-10-09 19:12:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 19:12:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 19:12:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 19:12:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/jaminan.php
DEBUG - 2016-10-09 19:12:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 19:12:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 19:12:02 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:02 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:02 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:02 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:02 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:03 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:03 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:03 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:03 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:03 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:03 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:03 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:03 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:03 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:03 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:03 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:03 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:03 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:03 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:03 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:03 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:04 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:04 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:04 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:04 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:04 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:04 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:04 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:04 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:04 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:04 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:04 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:04 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:04 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:04 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:04 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:05 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:05 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:05 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:05 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:05 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:05 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:05 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:05 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:05 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:05 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:05 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:05 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:05 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:05 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:05 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:05 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:06 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:06 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:06 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:06 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:06 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:06 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:07 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:07 --> Database Driver Class Initialized
DEBUG - 2016-10-09 19:12:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 19:12:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 19:12:07 --> Final output sent to browser
DEBUG - 2016-10-09 19:12:07 --> Total execution time: 5.8625
INFO - 2016-10-09 19:12:27 --> Config Class Initialized
INFO - 2016-10-09 19:12:27 --> Hooks Class Initialized
DEBUG - 2016-10-09 19:12:27 --> UTF-8 Support Enabled
INFO - 2016-10-09 19:12:28 --> Utf8 Class Initialized
INFO - 2016-10-09 19:12:28 --> URI Class Initialized
INFO - 2016-10-09 19:12:28 --> Router Class Initialized
INFO - 2016-10-09 19:12:28 --> Output Class Initialized
INFO - 2016-10-09 19:12:28 --> Security Class Initialized
DEBUG - 2016-10-09 19:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 19:12:28 --> Input Class Initialized
INFO - 2016-10-09 19:12:28 --> Language Class Initialized
INFO - 2016-10-09 19:12:28 --> Language Class Initialized
INFO - 2016-10-09 19:12:28 --> Config Class Initialized
INFO - 2016-10-09 19:12:28 --> Loader Class Initialized
INFO - 2016-10-09 19:12:28 --> Helper loaded: url_helper
INFO - 2016-10-09 19:12:28 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 19:12:28 --> Controller Class Initialized
DEBUG - 2016-10-09 19:12:28 --> Index MX_Controller Initialized
INFO - 2016-10-09 19:12:28 --> Model Class Initialized
INFO - 2016-10-09 19:12:28 --> Model Class Initialized
ERROR - 2016-10-09 19:12:28 --> Unable to delete cache file for admin/index/list_jaminan
DEBUG - 2016-10-09 19:12:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 19:12:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 19:12:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 19:12:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/jaminan.php
DEBUG - 2016-10-09 19:12:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 19:12:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 19:12:29 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:29 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:29 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:29 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:29 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:29 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:29 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:29 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:29 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:29 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:29 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:29 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:30 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:30 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:30 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:30 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:30 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:30 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:30 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:30 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:30 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:30 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:30 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:30 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:30 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:30 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:30 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:30 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:30 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:31 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:31 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:31 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:31 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:31 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:31 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:31 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:31 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:31 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:31 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:31 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:31 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:31 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:31 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:31 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:32 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:32 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:32 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:32 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:32 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:32 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:32 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:32 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:32 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:32 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:32 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:32 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:32 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:32 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:32 --> Database Driver Class Initialized
INFO - 2016-10-09 19:12:33 --> Database Driver Class Initialized
DEBUG - 2016-10-09 19:12:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 19:12:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 19:12:33 --> Final output sent to browser
DEBUG - 2016-10-09 19:12:33 --> Total execution time: 5.4477
INFO - 2016-10-09 19:13:04 --> Config Class Initialized
INFO - 2016-10-09 19:13:04 --> Hooks Class Initialized
DEBUG - 2016-10-09 19:13:04 --> UTF-8 Support Enabled
INFO - 2016-10-09 19:13:04 --> Utf8 Class Initialized
INFO - 2016-10-09 19:13:05 --> URI Class Initialized
INFO - 2016-10-09 19:13:05 --> Router Class Initialized
INFO - 2016-10-09 19:13:05 --> Output Class Initialized
INFO - 2016-10-09 19:13:05 --> Security Class Initialized
DEBUG - 2016-10-09 19:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 19:13:05 --> Input Class Initialized
INFO - 2016-10-09 19:13:05 --> Language Class Initialized
INFO - 2016-10-09 19:13:05 --> Language Class Initialized
INFO - 2016-10-09 19:13:05 --> Config Class Initialized
INFO - 2016-10-09 19:13:05 --> Loader Class Initialized
INFO - 2016-10-09 19:13:05 --> Helper loaded: url_helper
INFO - 2016-10-09 19:13:05 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 19:13:05 --> Controller Class Initialized
DEBUG - 2016-10-09 19:13:05 --> Index MX_Controller Initialized
INFO - 2016-10-09 19:13:05 --> Model Class Initialized
INFO - 2016-10-09 19:13:05 --> Model Class Initialized
ERROR - 2016-10-09 19:13:05 --> Unable to delete cache file for admin/index/list_jaminan
DEBUG - 2016-10-09 19:13:05 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 19:13:05 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 19:13:05 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 19:13:06 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/jaminan.php
DEBUG - 2016-10-09 19:13:06 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 19:13:06 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 19:13:06 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:06 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:06 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:06 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:06 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:06 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:06 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:06 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:06 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:06 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:06 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:06 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:06 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:06 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:06 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:06 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:07 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:07 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:07 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:07 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:07 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:07 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:07 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:07 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:07 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:07 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:07 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:07 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:07 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:07 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:07 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:07 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:07 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:07 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:07 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:08 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:08 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:08 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:08 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:08 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:08 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:08 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:08 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:08 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:08 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:08 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:08 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:08 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:08 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:08 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:08 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:08 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:08 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:09 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:09 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:09 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:09 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:09 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:09 --> Database Driver Class Initialized
INFO - 2016-10-09 19:13:09 --> Database Driver Class Initialized
DEBUG - 2016-10-09 19:13:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 19:13:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 19:13:09 --> Final output sent to browser
DEBUG - 2016-10-09 19:13:09 --> Total execution time: 4.7584
INFO - 2016-10-09 19:29:46 --> Config Class Initialized
INFO - 2016-10-09 19:29:46 --> Hooks Class Initialized
DEBUG - 2016-10-09 19:29:46 --> UTF-8 Support Enabled
INFO - 2016-10-09 19:29:46 --> Utf8 Class Initialized
INFO - 2016-10-09 19:29:47 --> URI Class Initialized
INFO - 2016-10-09 19:29:47 --> Router Class Initialized
INFO - 2016-10-09 19:29:47 --> Output Class Initialized
INFO - 2016-10-09 19:29:47 --> Security Class Initialized
DEBUG - 2016-10-09 19:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 19:29:47 --> Input Class Initialized
INFO - 2016-10-09 19:29:47 --> Language Class Initialized
ERROR - 2016-10-09 19:29:47 --> Severity: Parsing Error --> syntax error, unexpected '==' (T_IS_EQUAL), expecting ')' E:\SERVER\htdocs\kops\application\modules\admin\controllers\Index.php 1490
INFO - 2016-10-09 19:29:57 --> Config Class Initialized
INFO - 2016-10-09 19:29:57 --> Hooks Class Initialized
DEBUG - 2016-10-09 19:29:57 --> UTF-8 Support Enabled
INFO - 2016-10-09 19:29:57 --> Utf8 Class Initialized
INFO - 2016-10-09 19:29:57 --> URI Class Initialized
INFO - 2016-10-09 19:29:57 --> Router Class Initialized
INFO - 2016-10-09 19:29:57 --> Output Class Initialized
INFO - 2016-10-09 19:29:57 --> Security Class Initialized
DEBUG - 2016-10-09 19:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 19:29:57 --> Input Class Initialized
INFO - 2016-10-09 19:29:57 --> Language Class Initialized
INFO - 2016-10-09 19:29:57 --> Language Class Initialized
INFO - 2016-10-09 19:29:57 --> Config Class Initialized
INFO - 2016-10-09 19:29:57 --> Loader Class Initialized
INFO - 2016-10-09 19:29:58 --> Helper loaded: url_helper
INFO - 2016-10-09 19:29:58 --> Database Driver Class Initialized
INFO - 2016-10-09 19:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 19:29:58 --> Controller Class Initialized
DEBUG - 2016-10-09 19:29:58 --> Index MX_Controller Initialized
INFO - 2016-10-09 19:29:58 --> Model Class Initialized
INFO - 2016-10-09 19:29:58 --> Model Class Initialized
ERROR - 2016-10-09 19:29:58 --> Unable to delete cache file for admin/index/list_jaminan
DEBUG - 2016-10-09 19:29:58 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 19:29:58 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 19:29:58 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 19:29:58 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/jaminan.php
DEBUG - 2016-10-09 19:29:58 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 19:29:58 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 19:29:58 --> Database Driver Class Initialized
INFO - 2016-10-09 19:29:58 --> Database Driver Class Initialized
INFO - 2016-10-09 19:29:58 --> Database Driver Class Initialized
INFO - 2016-10-09 19:29:58 --> Database Driver Class Initialized
INFO - 2016-10-09 19:29:59 --> Database Driver Class Initialized
INFO - 2016-10-09 19:29:59 --> Database Driver Class Initialized
INFO - 2016-10-09 19:29:59 --> Database Driver Class Initialized
INFO - 2016-10-09 19:29:59 --> Database Driver Class Initialized
INFO - 2016-10-09 19:29:59 --> Database Driver Class Initialized
INFO - 2016-10-09 19:29:59 --> Database Driver Class Initialized
INFO - 2016-10-09 19:29:59 --> Database Driver Class Initialized
INFO - 2016-10-09 19:29:59 --> Database Driver Class Initialized
INFO - 2016-10-09 19:29:59 --> Database Driver Class Initialized
INFO - 2016-10-09 19:29:59 --> Database Driver Class Initialized
INFO - 2016-10-09 19:29:59 --> Database Driver Class Initialized
INFO - 2016-10-09 19:29:59 --> Database Driver Class Initialized
INFO - 2016-10-09 19:30:00 --> Database Driver Class Initialized
INFO - 2016-10-09 19:30:00 --> Database Driver Class Initialized
INFO - 2016-10-09 19:30:00 --> Database Driver Class Initialized
INFO - 2016-10-09 19:30:00 --> Database Driver Class Initialized
INFO - 2016-10-09 19:30:00 --> Database Driver Class Initialized
INFO - 2016-10-09 19:30:00 --> Database Driver Class Initialized
INFO - 2016-10-09 19:30:00 --> Database Driver Class Initialized
INFO - 2016-10-09 19:30:00 --> Database Driver Class Initialized
INFO - 2016-10-09 19:30:00 --> Database Driver Class Initialized
INFO - 2016-10-09 19:30:00 --> Database Driver Class Initialized
INFO - 2016-10-09 19:30:00 --> Database Driver Class Initialized
INFO - 2016-10-09 19:30:00 --> Database Driver Class Initialized
INFO - 2016-10-09 19:30:00 --> Database Driver Class Initialized
INFO - 2016-10-09 19:30:00 --> Database Driver Class Initialized
INFO - 2016-10-09 19:30:00 --> Database Driver Class Initialized
INFO - 2016-10-09 19:30:01 --> Database Driver Class Initialized
INFO - 2016-10-09 19:30:01 --> Database Driver Class Initialized
INFO - 2016-10-09 19:30:01 --> Database Driver Class Initialized
INFO - 2016-10-09 19:30:01 --> Database Driver Class Initialized
INFO - 2016-10-09 19:30:01 --> Database Driver Class Initialized
INFO - 2016-10-09 19:30:01 --> Database Driver Class Initialized
INFO - 2016-10-09 19:30:01 --> Database Driver Class Initialized
INFO - 2016-10-09 19:30:01 --> Database Driver Class Initialized
INFO - 2016-10-09 19:30:01 --> Database Driver Class Initialized
INFO - 2016-10-09 19:30:01 --> Database Driver Class Initialized
INFO - 2016-10-09 19:30:01 --> Database Driver Class Initialized
INFO - 2016-10-09 19:30:01 --> Database Driver Class Initialized
INFO - 2016-10-09 19:30:01 --> Database Driver Class Initialized
INFO - 2016-10-09 19:30:01 --> Database Driver Class Initialized
INFO - 2016-10-09 19:30:01 --> Database Driver Class Initialized
INFO - 2016-10-09 19:30:01 --> Database Driver Class Initialized
INFO - 2016-10-09 19:30:01 --> Database Driver Class Initialized
INFO - 2016-10-09 19:30:01 --> Database Driver Class Initialized
INFO - 2016-10-09 19:30:02 --> Database Driver Class Initialized
INFO - 2016-10-09 19:30:02 --> Database Driver Class Initialized
INFO - 2016-10-09 19:30:02 --> Database Driver Class Initialized
INFO - 2016-10-09 19:30:02 --> Database Driver Class Initialized
INFO - 2016-10-09 19:30:02 --> Database Driver Class Initialized
INFO - 2016-10-09 19:30:02 --> Database Driver Class Initialized
INFO - 2016-10-09 19:30:02 --> Database Driver Class Initialized
INFO - 2016-10-09 19:30:02 --> Database Driver Class Initialized
INFO - 2016-10-09 19:30:02 --> Database Driver Class Initialized
INFO - 2016-10-09 19:30:02 --> Database Driver Class Initialized
INFO - 2016-10-09 19:30:02 --> Database Driver Class Initialized
DEBUG - 2016-10-09 19:30:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 19:30:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 19:30:02 --> Final output sent to browser
DEBUG - 2016-10-09 19:30:02 --> Total execution time: 5.5436
INFO - 2016-10-09 19:31:46 --> Config Class Initialized
INFO - 2016-10-09 19:31:46 --> Hooks Class Initialized
DEBUG - 2016-10-09 19:31:46 --> UTF-8 Support Enabled
INFO - 2016-10-09 19:31:46 --> Utf8 Class Initialized
INFO - 2016-10-09 19:31:46 --> URI Class Initialized
INFO - 2016-10-09 19:31:46 --> Router Class Initialized
INFO - 2016-10-09 19:31:46 --> Output Class Initialized
INFO - 2016-10-09 19:31:46 --> Security Class Initialized
DEBUG - 2016-10-09 19:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 19:31:46 --> Input Class Initialized
INFO - 2016-10-09 19:31:46 --> Language Class Initialized
INFO - 2016-10-09 19:31:46 --> Language Class Initialized
INFO - 2016-10-09 19:31:46 --> Config Class Initialized
INFO - 2016-10-09 19:31:47 --> Loader Class Initialized
INFO - 2016-10-09 19:31:47 --> Helper loaded: url_helper
INFO - 2016-10-09 19:31:47 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 19:31:47 --> Controller Class Initialized
DEBUG - 2016-10-09 19:31:47 --> Index MX_Controller Initialized
INFO - 2016-10-09 19:31:47 --> Model Class Initialized
INFO - 2016-10-09 19:31:47 --> Model Class Initialized
ERROR - 2016-10-09 19:31:47 --> Unable to delete cache file for admin/index/list_jaminan
DEBUG - 2016-10-09 19:31:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 19:31:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 19:31:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 19:31:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/jaminan.php
DEBUG - 2016-10-09 19:31:48 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 19:31:48 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 19:31:48 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:48 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:48 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:48 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:48 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:48 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:48 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:48 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:49 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:49 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:49 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:49 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:49 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:49 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:49 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:50 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:50 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:50 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:50 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:50 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:50 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:50 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:50 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:50 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:50 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:50 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:50 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:50 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:50 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:50 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:51 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:51 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:51 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:51 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:51 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:51 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:51 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:51 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:51 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:51 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:51 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:51 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:51 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:51 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:51 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:51 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:52 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:52 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:52 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:52 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:52 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:52 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:52 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:52 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:52 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:52 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:52 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:52 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:52 --> Database Driver Class Initialized
INFO - 2016-10-09 19:31:52 --> Database Driver Class Initialized
DEBUG - 2016-10-09 19:31:52 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 19:31:52 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 19:31:53 --> Final output sent to browser
DEBUG - 2016-10-09 19:31:53 --> Total execution time: 6.7839
INFO - 2016-10-09 19:32:07 --> Config Class Initialized
INFO - 2016-10-09 19:32:07 --> Hooks Class Initialized
DEBUG - 2016-10-09 19:32:07 --> UTF-8 Support Enabled
INFO - 2016-10-09 19:32:07 --> Utf8 Class Initialized
INFO - 2016-10-09 19:32:07 --> URI Class Initialized
INFO - 2016-10-09 19:32:07 --> Router Class Initialized
INFO - 2016-10-09 19:32:07 --> Output Class Initialized
INFO - 2016-10-09 19:32:07 --> Security Class Initialized
DEBUG - 2016-10-09 19:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 19:32:08 --> Input Class Initialized
INFO - 2016-10-09 19:32:08 --> Language Class Initialized
INFO - 2016-10-09 19:32:08 --> Language Class Initialized
INFO - 2016-10-09 19:32:08 --> Config Class Initialized
INFO - 2016-10-09 19:32:08 --> Loader Class Initialized
INFO - 2016-10-09 19:32:08 --> Helper loaded: url_helper
INFO - 2016-10-09 19:32:08 --> Database Driver Class Initialized
INFO - 2016-10-09 19:32:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 19:32:08 --> Controller Class Initialized
DEBUG - 2016-10-09 19:32:08 --> Index MX_Controller Initialized
INFO - 2016-10-09 19:32:08 --> Model Class Initialized
INFO - 2016-10-09 19:32:08 --> Model Class Initialized
ERROR - 2016-10-09 19:32:08 --> Unable to delete cache file for admin/index/detail_jaminan/21
ERROR - 2016-10-09 19:32:08 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\modules\admin\controllers\Index.php 1497
ERROR - 2016-10-09 19:32:08 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\modules\admin\controllers\Index.php 1498
ERROR - 2016-10-09 19:32:09 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\modules\admin\controllers\Index.php 1499
ERROR - 2016-10-09 19:32:09 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\modules\admin\controllers\Index.php 1500
ERROR - 2016-10-09 19:32:09 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\modules\admin\controllers\Index.php 1501
ERROR - 2016-10-09 19:32:09 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\modules\admin\controllers\Index.php 1502
ERROR - 2016-10-09 19:32:09 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\modules\admin\controllers\Index.php 1503
ERROR - 2016-10-09 19:32:09 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\modules\admin\controllers\Index.php 1504
ERROR - 2016-10-09 19:32:09 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\modules\admin\controllers\Index.php 1505
ERROR - 2016-10-09 19:32:09 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\modules\admin\controllers\Index.php 1506
INFO - 2016-10-09 19:32:09 --> Final output sent to browser
DEBUG - 2016-10-09 19:32:09 --> Total execution time: 1.9711
INFO - 2016-10-09 19:33:20 --> Config Class Initialized
INFO - 2016-10-09 19:33:20 --> Hooks Class Initialized
DEBUG - 2016-10-09 19:33:20 --> UTF-8 Support Enabled
INFO - 2016-10-09 19:33:20 --> Utf8 Class Initialized
INFO - 2016-10-09 19:33:20 --> URI Class Initialized
INFO - 2016-10-09 19:33:20 --> Router Class Initialized
INFO - 2016-10-09 19:33:20 --> Output Class Initialized
INFO - 2016-10-09 19:33:20 --> Security Class Initialized
DEBUG - 2016-10-09 19:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 19:33:21 --> Input Class Initialized
INFO - 2016-10-09 19:33:21 --> Language Class Initialized
INFO - 2016-10-09 19:33:21 --> Language Class Initialized
INFO - 2016-10-09 19:33:21 --> Config Class Initialized
INFO - 2016-10-09 19:33:21 --> Loader Class Initialized
INFO - 2016-10-09 19:33:21 --> Helper loaded: url_helper
INFO - 2016-10-09 19:33:21 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 19:33:21 --> Controller Class Initialized
DEBUG - 2016-10-09 19:33:21 --> Index MX_Controller Initialized
INFO - 2016-10-09 19:33:21 --> Model Class Initialized
INFO - 2016-10-09 19:33:21 --> Model Class Initialized
ERROR - 2016-10-09 19:33:21 --> Unable to delete cache file for admin/index/detail_jaminan/21
ERROR - 2016-10-09 19:33:21 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\modules\admin\controllers\Index.php 1497
ERROR - 2016-10-09 19:33:21 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\modules\admin\controllers\Index.php 1498
ERROR - 2016-10-09 19:33:21 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\modules\admin\controllers\Index.php 1499
ERROR - 2016-10-09 19:33:21 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\modules\admin\controllers\Index.php 1500
ERROR - 2016-10-09 19:33:21 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\modules\admin\controllers\Index.php 1501
ERROR - 2016-10-09 19:33:21 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\modules\admin\controllers\Index.php 1502
ERROR - 2016-10-09 19:33:21 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\modules\admin\controllers\Index.php 1503
ERROR - 2016-10-09 19:33:22 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\modules\admin\controllers\Index.php 1504
ERROR - 2016-10-09 19:33:22 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\modules\admin\controllers\Index.php 1505
ERROR - 2016-10-09 19:33:22 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\modules\admin\controllers\Index.php 1506
INFO - 2016-10-09 19:33:22 --> Final output sent to browser
DEBUG - 2016-10-09 19:33:22 --> Total execution time: 1.6056
INFO - 2016-10-09 19:33:49 --> Config Class Initialized
INFO - 2016-10-09 19:33:49 --> Hooks Class Initialized
DEBUG - 2016-10-09 19:33:49 --> UTF-8 Support Enabled
INFO - 2016-10-09 19:33:49 --> Utf8 Class Initialized
INFO - 2016-10-09 19:33:49 --> URI Class Initialized
INFO - 2016-10-09 19:33:49 --> Router Class Initialized
INFO - 2016-10-09 19:33:49 --> Output Class Initialized
INFO - 2016-10-09 19:33:49 --> Security Class Initialized
DEBUG - 2016-10-09 19:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 19:33:49 --> Input Class Initialized
INFO - 2016-10-09 19:33:49 --> Language Class Initialized
INFO - 2016-10-09 19:33:49 --> Language Class Initialized
INFO - 2016-10-09 19:33:49 --> Config Class Initialized
INFO - 2016-10-09 19:33:49 --> Loader Class Initialized
INFO - 2016-10-09 19:33:49 --> Helper loaded: url_helper
INFO - 2016-10-09 19:33:49 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 19:33:50 --> Controller Class Initialized
DEBUG - 2016-10-09 19:33:50 --> Index MX_Controller Initialized
INFO - 2016-10-09 19:33:50 --> Model Class Initialized
INFO - 2016-10-09 19:33:50 --> Model Class Initialized
ERROR - 2016-10-09 19:33:50 --> Unable to delete cache file for admin/index/list_jaminan
DEBUG - 2016-10-09 19:33:50 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 19:33:50 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 19:33:50 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 19:33:50 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/jaminan.php
DEBUG - 2016-10-09 19:33:50 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 19:33:50 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 19:33:50 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:50 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:50 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:50 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:50 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:50 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:51 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:51 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:51 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:51 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:51 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:51 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:51 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:51 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:51 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:51 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:51 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:51 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:51 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:51 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:51 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:51 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:51 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:52 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:52 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:52 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:52 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:52 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:52 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:52 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:52 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:52 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:52 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:52 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:52 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:52 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:52 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:52 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:52 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:53 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:53 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:53 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:53 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:53 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:53 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:53 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:53 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:53 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:53 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:53 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:53 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:53 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:53 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:53 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:53 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:54 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:54 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:54 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:54 --> Database Driver Class Initialized
INFO - 2016-10-09 19:33:54 --> Database Driver Class Initialized
DEBUG - 2016-10-09 19:33:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 19:33:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 19:33:54 --> Final output sent to browser
DEBUG - 2016-10-09 19:33:54 --> Total execution time: 5.4165
INFO - 2016-10-09 19:34:09 --> Config Class Initialized
INFO - 2016-10-09 19:34:09 --> Hooks Class Initialized
DEBUG - 2016-10-09 19:34:09 --> UTF-8 Support Enabled
INFO - 2016-10-09 19:34:10 --> Utf8 Class Initialized
INFO - 2016-10-09 19:34:10 --> URI Class Initialized
INFO - 2016-10-09 19:34:10 --> Router Class Initialized
INFO - 2016-10-09 19:34:10 --> Output Class Initialized
INFO - 2016-10-09 19:34:10 --> Security Class Initialized
DEBUG - 2016-10-09 19:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 19:34:10 --> Input Class Initialized
INFO - 2016-10-09 19:34:10 --> Language Class Initialized
INFO - 2016-10-09 19:34:10 --> Language Class Initialized
INFO - 2016-10-09 19:34:10 --> Config Class Initialized
INFO - 2016-10-09 19:34:10 --> Loader Class Initialized
INFO - 2016-10-09 19:34:10 --> Helper loaded: url_helper
INFO - 2016-10-09 19:34:10 --> Database Driver Class Initialized
INFO - 2016-10-09 19:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 19:34:10 --> Controller Class Initialized
DEBUG - 2016-10-09 19:34:10 --> Index MX_Controller Initialized
INFO - 2016-10-09 19:34:11 --> Model Class Initialized
INFO - 2016-10-09 19:34:11 --> Model Class Initialized
ERROR - 2016-10-09 19:34:11 --> Unable to delete cache file for admin/index/detail_jaminan/472b07b9fcf2c2451e8781e944bf5f77cd8457c8
ERROR - 2016-10-09 19:34:11 --> Severity: Notice --> Undefined property: stdClass::$nosurat E:\SERVER\htdocs\kops\application\modules\admin\controllers\Index.php 1498
INFO - 2016-10-09 19:34:11 --> Final output sent to browser
DEBUG - 2016-10-09 19:34:11 --> Total execution time: 1.5272
INFO - 2016-10-09 19:34:23 --> Config Class Initialized
INFO - 2016-10-09 19:34:23 --> Hooks Class Initialized
DEBUG - 2016-10-09 19:34:23 --> UTF-8 Support Enabled
INFO - 2016-10-09 19:34:24 --> Utf8 Class Initialized
INFO - 2016-10-09 19:34:24 --> URI Class Initialized
INFO - 2016-10-09 19:34:24 --> Router Class Initialized
INFO - 2016-10-09 19:34:24 --> Output Class Initialized
INFO - 2016-10-09 19:34:24 --> Security Class Initialized
DEBUG - 2016-10-09 19:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 19:34:24 --> Input Class Initialized
INFO - 2016-10-09 19:34:24 --> Language Class Initialized
INFO - 2016-10-09 19:34:24 --> Language Class Initialized
INFO - 2016-10-09 19:34:24 --> Config Class Initialized
INFO - 2016-10-09 19:34:24 --> Loader Class Initialized
INFO - 2016-10-09 19:34:24 --> Helper loaded: url_helper
INFO - 2016-10-09 19:34:24 --> Database Driver Class Initialized
INFO - 2016-10-09 19:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 19:34:24 --> Controller Class Initialized
DEBUG - 2016-10-09 19:34:24 --> Index MX_Controller Initialized
INFO - 2016-10-09 19:34:24 --> Model Class Initialized
INFO - 2016-10-09 19:34:24 --> Model Class Initialized
ERROR - 2016-10-09 19:34:25 --> Unable to delete cache file for admin/index/detail_jaminan/472b07b9fcf2c2451e8781e944bf5f77cd8457c8
ERROR - 2016-10-09 19:34:25 --> Severity: Notice --> Undefined property: stdClass::$nosurat E:\SERVER\htdocs\kops\application\modules\admin\controllers\Index.php 1498
INFO - 2016-10-09 19:34:25 --> Final output sent to browser
DEBUG - 2016-10-09 19:34:25 --> Total execution time: 1.3376
INFO - 2016-10-09 19:34:56 --> Config Class Initialized
INFO - 2016-10-09 19:34:56 --> Hooks Class Initialized
DEBUG - 2016-10-09 19:34:56 --> UTF-8 Support Enabled
INFO - 2016-10-09 19:34:56 --> Utf8 Class Initialized
INFO - 2016-10-09 19:34:56 --> URI Class Initialized
INFO - 2016-10-09 19:34:56 --> Router Class Initialized
INFO - 2016-10-09 19:34:56 --> Output Class Initialized
INFO - 2016-10-09 19:34:56 --> Security Class Initialized
DEBUG - 2016-10-09 19:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 19:34:57 --> Input Class Initialized
INFO - 2016-10-09 19:34:57 --> Language Class Initialized
INFO - 2016-10-09 19:34:57 --> Language Class Initialized
INFO - 2016-10-09 19:34:57 --> Config Class Initialized
INFO - 2016-10-09 19:34:57 --> Loader Class Initialized
INFO - 2016-10-09 19:34:57 --> Helper loaded: url_helper
INFO - 2016-10-09 19:34:57 --> Database Driver Class Initialized
INFO - 2016-10-09 19:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 19:34:57 --> Controller Class Initialized
DEBUG - 2016-10-09 19:34:57 --> Index MX_Controller Initialized
INFO - 2016-10-09 19:34:57 --> Model Class Initialized
INFO - 2016-10-09 19:34:57 --> Model Class Initialized
ERROR - 2016-10-09 19:34:57 --> Unable to delete cache file for admin/index/detail_jaminan/472b07b9fcf2c2451e8781e944bf5f77cd8457c8
INFO - 2016-10-09 19:34:57 --> Final output sent to browser
DEBUG - 2016-10-09 19:34:57 --> Total execution time: 1.1698
INFO - 2016-10-09 19:35:06 --> Config Class Initialized
INFO - 2016-10-09 19:35:06 --> Hooks Class Initialized
DEBUG - 2016-10-09 19:35:06 --> UTF-8 Support Enabled
INFO - 2016-10-09 19:35:06 --> Utf8 Class Initialized
INFO - 2016-10-09 19:35:06 --> URI Class Initialized
INFO - 2016-10-09 19:35:06 --> Router Class Initialized
INFO - 2016-10-09 19:35:06 --> Output Class Initialized
INFO - 2016-10-09 19:35:06 --> Security Class Initialized
DEBUG - 2016-10-09 19:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 19:35:06 --> Input Class Initialized
INFO - 2016-10-09 19:35:06 --> Language Class Initialized
INFO - 2016-10-09 19:35:06 --> Language Class Initialized
INFO - 2016-10-09 19:35:06 --> Config Class Initialized
INFO - 2016-10-09 19:35:06 --> Loader Class Initialized
INFO - 2016-10-09 19:35:06 --> Helper loaded: url_helper
INFO - 2016-10-09 19:35:07 --> Database Driver Class Initialized
INFO - 2016-10-09 19:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 19:35:07 --> Controller Class Initialized
DEBUG - 2016-10-09 19:35:07 --> Index MX_Controller Initialized
INFO - 2016-10-09 19:35:07 --> Model Class Initialized
INFO - 2016-10-09 19:35:07 --> Model Class Initialized
ERROR - 2016-10-09 19:35:07 --> Unable to delete cache file for admin/index/detail_jaminan/472b07b9fcf2c2451e8781e944bf5f77cd8457c8
INFO - 2016-10-09 19:35:07 --> Final output sent to browser
DEBUG - 2016-10-09 19:35:07 --> Total execution time: 1.1667
INFO - 2016-10-09 19:36:32 --> Config Class Initialized
INFO - 2016-10-09 19:36:32 --> Hooks Class Initialized
DEBUG - 2016-10-09 19:36:32 --> UTF-8 Support Enabled
INFO - 2016-10-09 19:36:32 --> Utf8 Class Initialized
INFO - 2016-10-09 19:36:32 --> URI Class Initialized
INFO - 2016-10-09 19:36:32 --> Router Class Initialized
INFO - 2016-10-09 19:36:32 --> Output Class Initialized
INFO - 2016-10-09 19:36:32 --> Security Class Initialized
DEBUG - 2016-10-09 19:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 19:36:32 --> Input Class Initialized
INFO - 2016-10-09 19:36:32 --> Language Class Initialized
INFO - 2016-10-09 19:36:32 --> Language Class Initialized
INFO - 2016-10-09 19:36:32 --> Config Class Initialized
INFO - 2016-10-09 19:36:32 --> Loader Class Initialized
INFO - 2016-10-09 19:36:32 --> Helper loaded: url_helper
INFO - 2016-10-09 19:36:32 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 19:36:32 --> Controller Class Initialized
DEBUG - 2016-10-09 19:36:32 --> Index MX_Controller Initialized
INFO - 2016-10-09 19:36:33 --> Model Class Initialized
INFO - 2016-10-09 19:36:33 --> Model Class Initialized
ERROR - 2016-10-09 19:36:33 --> Unable to delete cache file for admin/index/list_jaminan
DEBUG - 2016-10-09 19:36:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 19:36:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 19:36:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 19:36:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/jaminan.php
DEBUG - 2016-10-09 19:36:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 19:36:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 19:36:33 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:33 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:33 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:33 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:33 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:33 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:33 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:33 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:33 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:33 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:34 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:34 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:34 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:34 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:34 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:34 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:34 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:34 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:34 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:34 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:34 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:34 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:34 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:34 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:34 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:34 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:34 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:34 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:35 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:35 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:35 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:35 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:35 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:35 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:35 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:35 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:35 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:35 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:35 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:35 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:35 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:35 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:35 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:35 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:36 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:36 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:36 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:36 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:36 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:36 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:36 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:36 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:36 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:36 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:36 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:36 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:36 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:36 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:36 --> Database Driver Class Initialized
INFO - 2016-10-09 19:36:36 --> Database Driver Class Initialized
DEBUG - 2016-10-09 19:36:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 19:36:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 19:36:36 --> Final output sent to browser
DEBUG - 2016-10-09 19:36:37 --> Total execution time: 4.9599
INFO - 2016-10-09 19:37:00 --> Config Class Initialized
INFO - 2016-10-09 19:37:00 --> Hooks Class Initialized
DEBUG - 2016-10-09 19:37:00 --> UTF-8 Support Enabled
INFO - 2016-10-09 19:37:00 --> Utf8 Class Initialized
INFO - 2016-10-09 19:37:00 --> URI Class Initialized
INFO - 2016-10-09 19:37:00 --> Router Class Initialized
INFO - 2016-10-09 19:37:00 --> Output Class Initialized
INFO - 2016-10-09 19:37:00 --> Security Class Initialized
DEBUG - 2016-10-09 19:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 19:37:01 --> Input Class Initialized
INFO - 2016-10-09 19:37:01 --> Language Class Initialized
INFO - 2016-10-09 19:37:01 --> Language Class Initialized
INFO - 2016-10-09 19:37:01 --> Config Class Initialized
INFO - 2016-10-09 19:37:01 --> Loader Class Initialized
INFO - 2016-10-09 19:37:01 --> Helper loaded: url_helper
INFO - 2016-10-09 19:37:01 --> Database Driver Class Initialized
INFO - 2016-10-09 19:37:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 19:37:01 --> Controller Class Initialized
DEBUG - 2016-10-09 19:37:01 --> Index MX_Controller Initialized
INFO - 2016-10-09 19:37:01 --> Model Class Initialized
INFO - 2016-10-09 19:37:01 --> Model Class Initialized
ERROR - 2016-10-09 19:37:01 --> Unable to delete cache file for admin/index/detail_jaminan/472b07b9fcf2c2451e8781e944bf5f77cd8457c8
INFO - 2016-10-09 19:37:01 --> Final output sent to browser
DEBUG - 2016-10-09 19:37:01 --> Total execution time: 1.3597
INFO - 2016-10-09 19:38:09 --> Config Class Initialized
INFO - 2016-10-09 19:38:09 --> Hooks Class Initialized
DEBUG - 2016-10-09 19:38:09 --> UTF-8 Support Enabled
INFO - 2016-10-09 19:38:09 --> Utf8 Class Initialized
INFO - 2016-10-09 19:38:10 --> URI Class Initialized
INFO - 2016-10-09 19:38:10 --> Router Class Initialized
INFO - 2016-10-09 19:38:10 --> Output Class Initialized
INFO - 2016-10-09 19:38:10 --> Security Class Initialized
DEBUG - 2016-10-09 19:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 19:38:10 --> Input Class Initialized
INFO - 2016-10-09 19:38:10 --> Language Class Initialized
INFO - 2016-10-09 19:38:10 --> Language Class Initialized
INFO - 2016-10-09 19:38:10 --> Config Class Initialized
INFO - 2016-10-09 19:38:10 --> Loader Class Initialized
INFO - 2016-10-09 19:38:10 --> Helper loaded: url_helper
INFO - 2016-10-09 19:38:10 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 19:38:10 --> Controller Class Initialized
DEBUG - 2016-10-09 19:38:10 --> Index MX_Controller Initialized
INFO - 2016-10-09 19:38:10 --> Model Class Initialized
INFO - 2016-10-09 19:38:10 --> Model Class Initialized
ERROR - 2016-10-09 19:38:11 --> Unable to delete cache file for admin/index/list_jaminan
DEBUG - 2016-10-09 19:38:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 19:38:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 19:38:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 19:38:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/jaminan.php
DEBUG - 2016-10-09 19:38:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 19:38:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 19:38:11 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:11 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:11 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:11 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:11 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:11 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:11 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:11 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:11 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:11 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:12 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:12 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:12 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:12 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:12 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:12 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:12 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:12 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:12 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:12 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:12 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:12 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:12 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:12 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:12 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:12 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:13 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:13 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:13 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:13 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:13 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:13 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:13 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:13 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:13 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:13 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:13 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:13 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:14 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:14 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:14 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:14 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:14 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:14 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:14 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:14 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:14 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:14 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:14 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:14 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:14 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:14 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:14 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:15 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:15 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:15 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:15 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:15 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:15 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:15 --> Database Driver Class Initialized
DEBUG - 2016-10-09 19:38:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 19:38:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 19:38:15 --> Final output sent to browser
DEBUG - 2016-10-09 19:38:15 --> Total execution time: 5.7624
INFO - 2016-10-09 19:38:38 --> Config Class Initialized
INFO - 2016-10-09 19:38:38 --> Hooks Class Initialized
DEBUG - 2016-10-09 19:38:38 --> UTF-8 Support Enabled
INFO - 2016-10-09 19:38:38 --> Utf8 Class Initialized
INFO - 2016-10-09 19:38:38 --> URI Class Initialized
INFO - 2016-10-09 19:38:38 --> Router Class Initialized
INFO - 2016-10-09 19:38:38 --> Output Class Initialized
INFO - 2016-10-09 19:38:38 --> Security Class Initialized
DEBUG - 2016-10-09 19:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 19:38:38 --> Input Class Initialized
INFO - 2016-10-09 19:38:38 --> Language Class Initialized
INFO - 2016-10-09 19:38:38 --> Language Class Initialized
INFO - 2016-10-09 19:38:38 --> Config Class Initialized
INFO - 2016-10-09 19:38:39 --> Loader Class Initialized
INFO - 2016-10-09 19:38:39 --> Helper loaded: url_helper
INFO - 2016-10-09 19:38:39 --> Database Driver Class Initialized
INFO - 2016-10-09 19:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 19:38:39 --> Controller Class Initialized
DEBUG - 2016-10-09 19:38:39 --> Index MX_Controller Initialized
INFO - 2016-10-09 19:38:39 --> Model Class Initialized
INFO - 2016-10-09 19:38:39 --> Model Class Initialized
ERROR - 2016-10-09 19:38:39 --> Unable to delete cache file for admin/index/detail_jaminan/472b07b9fcf2c2451e8781e944bf5f77cd8457c8
INFO - 2016-10-09 19:38:39 --> Final output sent to browser
DEBUG - 2016-10-09 19:38:39 --> Total execution time: 1.4009
INFO - 2016-10-09 19:39:05 --> Config Class Initialized
INFO - 2016-10-09 19:39:05 --> Hooks Class Initialized
DEBUG - 2016-10-09 19:39:05 --> UTF-8 Support Enabled
INFO - 2016-10-09 19:39:05 --> Utf8 Class Initialized
INFO - 2016-10-09 19:39:05 --> URI Class Initialized
INFO - 2016-10-09 19:39:05 --> Router Class Initialized
INFO - 2016-10-09 19:39:05 --> Output Class Initialized
INFO - 2016-10-09 19:39:05 --> Security Class Initialized
DEBUG - 2016-10-09 19:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 19:39:05 --> Input Class Initialized
INFO - 2016-10-09 19:39:05 --> Language Class Initialized
INFO - 2016-10-09 19:39:05 --> Language Class Initialized
INFO - 2016-10-09 19:39:05 --> Config Class Initialized
INFO - 2016-10-09 19:39:05 --> Loader Class Initialized
INFO - 2016-10-09 19:39:05 --> Helper loaded: url_helper
INFO - 2016-10-09 19:39:05 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 19:39:06 --> Controller Class Initialized
DEBUG - 2016-10-09 19:39:06 --> Index MX_Controller Initialized
INFO - 2016-10-09 19:39:06 --> Model Class Initialized
INFO - 2016-10-09 19:39:06 --> Model Class Initialized
ERROR - 2016-10-09 19:39:06 --> Unable to delete cache file for admin/index/list_jaminan
DEBUG - 2016-10-09 19:39:06 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 19:39:06 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 19:39:06 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 19:39:06 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/jaminan.php
DEBUG - 2016-10-09 19:39:06 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 19:39:06 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 19:39:06 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:06 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:06 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:06 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:06 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:07 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:07 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:07 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:07 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:07 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:07 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:07 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:07 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:07 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:07 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:07 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:07 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:07 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:07 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:07 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:08 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:08 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:08 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:08 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:08 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:08 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:08 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:08 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:08 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:08 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:08 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:08 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:08 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:09 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:09 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:09 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:09 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:09 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:09 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:09 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:09 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:09 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:09 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:09 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:09 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:09 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:09 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:09 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:10 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:10 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:10 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:10 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:10 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:10 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:10 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:10 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:10 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:10 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:10 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:10 --> Database Driver Class Initialized
DEBUG - 2016-10-09 19:39:10 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 19:39:10 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 19:39:10 --> Final output sent to browser
DEBUG - 2016-10-09 19:39:10 --> Total execution time: 5.8798
INFO - 2016-10-09 19:39:27 --> Config Class Initialized
INFO - 2016-10-09 19:39:27 --> Hooks Class Initialized
DEBUG - 2016-10-09 19:39:27 --> UTF-8 Support Enabled
INFO - 2016-10-09 19:39:27 --> Utf8 Class Initialized
INFO - 2016-10-09 19:39:27 --> URI Class Initialized
INFO - 2016-10-09 19:39:27 --> Router Class Initialized
INFO - 2016-10-09 19:39:27 --> Output Class Initialized
INFO - 2016-10-09 19:39:27 --> Security Class Initialized
DEBUG - 2016-10-09 19:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 19:39:27 --> Input Class Initialized
INFO - 2016-10-09 19:39:27 --> Language Class Initialized
INFO - 2016-10-09 19:39:28 --> Language Class Initialized
INFO - 2016-10-09 19:39:28 --> Config Class Initialized
INFO - 2016-10-09 19:39:28 --> Loader Class Initialized
INFO - 2016-10-09 19:39:28 --> Helper loaded: url_helper
INFO - 2016-10-09 19:39:28 --> Database Driver Class Initialized
INFO - 2016-10-09 19:39:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 19:39:28 --> Controller Class Initialized
DEBUG - 2016-10-09 19:39:28 --> Index MX_Controller Initialized
INFO - 2016-10-09 19:39:28 --> Model Class Initialized
INFO - 2016-10-09 19:39:28 --> Model Class Initialized
ERROR - 2016-10-09 19:39:28 --> Unable to delete cache file for admin/index/detail_jaminan/472b07b9fcf2c2451e8781e944bf5f77cd8457c8
INFO - 2016-10-09 19:39:28 --> Final output sent to browser
DEBUG - 2016-10-09 19:39:28 --> Total execution time: 0.9456
INFO - 2016-10-09 19:40:22 --> Config Class Initialized
INFO - 2016-10-09 19:40:22 --> Hooks Class Initialized
DEBUG - 2016-10-09 19:40:23 --> UTF-8 Support Enabled
INFO - 2016-10-09 19:40:23 --> Utf8 Class Initialized
INFO - 2016-10-09 19:40:23 --> URI Class Initialized
INFO - 2016-10-09 19:40:23 --> Router Class Initialized
INFO - 2016-10-09 19:40:23 --> Output Class Initialized
INFO - 2016-10-09 19:40:23 --> Security Class Initialized
DEBUG - 2016-10-09 19:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 19:40:23 --> Input Class Initialized
INFO - 2016-10-09 19:40:23 --> Language Class Initialized
INFO - 2016-10-09 19:40:23 --> Language Class Initialized
INFO - 2016-10-09 19:40:23 --> Config Class Initialized
INFO - 2016-10-09 19:40:24 --> Loader Class Initialized
INFO - 2016-10-09 19:40:24 --> Helper loaded: url_helper
INFO - 2016-10-09 19:40:24 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 19:40:24 --> Controller Class Initialized
DEBUG - 2016-10-09 19:40:24 --> Index MX_Controller Initialized
INFO - 2016-10-09 19:40:24 --> Model Class Initialized
INFO - 2016-10-09 19:40:24 --> Model Class Initialized
ERROR - 2016-10-09 19:40:24 --> Unable to delete cache file for admin/index/list_jaminan
DEBUG - 2016-10-09 19:40:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 19:40:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 19:40:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 19:40:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/jaminan.php
DEBUG - 2016-10-09 19:40:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 19:40:25 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 19:40:25 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:25 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:25 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:25 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:25 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:25 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:25 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:25 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:25 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:25 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:26 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:26 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:26 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:26 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:26 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:26 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:26 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:26 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:26 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:26 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:26 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:26 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:27 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:27 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:27 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:27 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:27 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:27 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:27 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:27 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:27 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:27 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:27 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:27 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:27 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:27 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:27 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:27 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:28 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:28 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:28 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:28 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:28 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:28 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:28 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:28 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:28 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:28 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:28 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:28 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:28 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:28 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:28 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:28 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:29 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:29 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:29 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:29 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:29 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:29 --> Database Driver Class Initialized
DEBUG - 2016-10-09 19:40:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 19:40:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 19:40:29 --> Final output sent to browser
DEBUG - 2016-10-09 19:40:29 --> Total execution time: 6.6502
INFO - 2016-10-09 19:40:41 --> Config Class Initialized
INFO - 2016-10-09 19:40:41 --> Hooks Class Initialized
DEBUG - 2016-10-09 19:40:41 --> UTF-8 Support Enabled
INFO - 2016-10-09 19:40:41 --> Utf8 Class Initialized
INFO - 2016-10-09 19:40:41 --> URI Class Initialized
INFO - 2016-10-09 19:40:42 --> Router Class Initialized
INFO - 2016-10-09 19:40:42 --> Output Class Initialized
INFO - 2016-10-09 19:40:42 --> Security Class Initialized
DEBUG - 2016-10-09 19:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 19:40:42 --> Input Class Initialized
INFO - 2016-10-09 19:40:42 --> Language Class Initialized
INFO - 2016-10-09 19:40:42 --> Language Class Initialized
INFO - 2016-10-09 19:40:42 --> Config Class Initialized
INFO - 2016-10-09 19:40:42 --> Loader Class Initialized
INFO - 2016-10-09 19:40:42 --> Helper loaded: url_helper
INFO - 2016-10-09 19:40:42 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 19:40:43 --> Controller Class Initialized
DEBUG - 2016-10-09 19:40:43 --> Index MX_Controller Initialized
INFO - 2016-10-09 19:40:43 --> Model Class Initialized
INFO - 2016-10-09 19:40:43 --> Model Class Initialized
ERROR - 2016-10-09 19:40:43 --> Unable to delete cache file for admin/index/detail_jaminan/472b07b9fcf2c2451e8781e944bf5f77cd8457c8
INFO - 2016-10-09 19:40:43 --> Final output sent to browser
DEBUG - 2016-10-09 19:40:43 --> Total execution time: 1.7529
INFO - 2016-10-09 19:40:51 --> Config Class Initialized
INFO - 2016-10-09 19:40:51 --> Hooks Class Initialized
DEBUG - 2016-10-09 19:40:51 --> UTF-8 Support Enabled
INFO - 2016-10-09 19:40:51 --> Utf8 Class Initialized
INFO - 2016-10-09 19:40:51 --> URI Class Initialized
INFO - 2016-10-09 19:40:51 --> Router Class Initialized
INFO - 2016-10-09 19:40:51 --> Output Class Initialized
INFO - 2016-10-09 19:40:52 --> Security Class Initialized
DEBUG - 2016-10-09 19:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 19:40:52 --> Input Class Initialized
INFO - 2016-10-09 19:40:52 --> Language Class Initialized
INFO - 2016-10-09 19:40:52 --> Language Class Initialized
INFO - 2016-10-09 19:40:52 --> Config Class Initialized
INFO - 2016-10-09 19:40:52 --> Loader Class Initialized
INFO - 2016-10-09 19:40:52 --> Helper loaded: url_helper
INFO - 2016-10-09 19:40:52 --> Database Driver Class Initialized
INFO - 2016-10-09 19:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 19:40:52 --> Controller Class Initialized
DEBUG - 2016-10-09 19:40:52 --> Index MX_Controller Initialized
INFO - 2016-10-09 19:40:52 --> Model Class Initialized
INFO - 2016-10-09 19:40:52 --> Model Class Initialized
ERROR - 2016-10-09 19:40:52 --> Unable to delete cache file for admin/index/update_jaminan
ERROR - 2016-10-09 19:40:52 --> Severity: Notice --> Undefined index: kd_jaminan E:\SERVER\htdocs\kops\application\modules\admin\controllers\Index.php 1448
INFO - 2016-10-09 19:40:52 --> Final output sent to browser
DEBUG - 2016-10-09 19:40:52 --> Total execution time: 1.1867
INFO - 2016-10-09 19:41:17 --> Config Class Initialized
INFO - 2016-10-09 19:41:17 --> Hooks Class Initialized
DEBUG - 2016-10-09 19:41:17 --> UTF-8 Support Enabled
INFO - 2016-10-09 19:41:17 --> Utf8 Class Initialized
INFO - 2016-10-09 19:41:17 --> URI Class Initialized
INFO - 2016-10-09 19:41:17 --> Router Class Initialized
INFO - 2016-10-09 19:41:18 --> Output Class Initialized
INFO - 2016-10-09 19:41:18 --> Security Class Initialized
DEBUG - 2016-10-09 19:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 19:41:18 --> Input Class Initialized
INFO - 2016-10-09 19:41:18 --> Language Class Initialized
INFO - 2016-10-09 19:41:18 --> Language Class Initialized
INFO - 2016-10-09 19:41:18 --> Config Class Initialized
INFO - 2016-10-09 19:41:18 --> Loader Class Initialized
INFO - 2016-10-09 19:41:18 --> Helper loaded: url_helper
INFO - 2016-10-09 19:41:19 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 19:41:19 --> Controller Class Initialized
DEBUG - 2016-10-09 19:41:19 --> Index MX_Controller Initialized
INFO - 2016-10-09 19:41:19 --> Model Class Initialized
INFO - 2016-10-09 19:41:19 --> Model Class Initialized
ERROR - 2016-10-09 19:41:19 --> Unable to delete cache file for admin/index/list_jaminan
DEBUG - 2016-10-09 19:41:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 19:41:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 19:41:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 19:41:20 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/jaminan.php
DEBUG - 2016-10-09 19:41:20 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 19:41:20 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 19:41:20 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:20 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:20 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:20 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:20 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:20 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:20 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:20 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:20 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:20 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:20 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:20 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:21 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:21 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:21 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:21 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:21 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:21 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:21 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:21 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:21 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:21 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:21 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:21 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:21 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:21 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:21 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:21 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:21 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:21 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:22 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:22 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:22 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:22 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:22 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:22 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:22 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:22 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:22 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:22 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:22 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:22 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:22 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:22 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:22 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:23 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:23 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:23 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:23 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:23 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:23 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:23 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:23 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:23 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:23 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:23 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:23 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:23 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:23 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:23 --> Database Driver Class Initialized
DEBUG - 2016-10-09 19:41:23 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 19:41:23 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 19:41:23 --> Final output sent to browser
DEBUG - 2016-10-09 19:41:24 --> Total execution time: 6.6489
INFO - 2016-10-09 19:41:50 --> Config Class Initialized
INFO - 2016-10-09 19:41:50 --> Hooks Class Initialized
DEBUG - 2016-10-09 19:41:50 --> UTF-8 Support Enabled
INFO - 2016-10-09 19:41:50 --> Utf8 Class Initialized
INFO - 2016-10-09 19:41:50 --> URI Class Initialized
INFO - 2016-10-09 19:41:50 --> Router Class Initialized
INFO - 2016-10-09 19:41:50 --> Output Class Initialized
INFO - 2016-10-09 19:41:50 --> Security Class Initialized
DEBUG - 2016-10-09 19:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 19:41:50 --> Input Class Initialized
INFO - 2016-10-09 19:41:50 --> Language Class Initialized
INFO - 2016-10-09 19:41:50 --> Language Class Initialized
INFO - 2016-10-09 19:41:50 --> Config Class Initialized
INFO - 2016-10-09 19:41:51 --> Loader Class Initialized
INFO - 2016-10-09 19:41:51 --> Helper loaded: url_helper
INFO - 2016-10-09 19:41:51 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 19:41:51 --> Controller Class Initialized
DEBUG - 2016-10-09 19:41:51 --> Index MX_Controller Initialized
INFO - 2016-10-09 19:41:51 --> Model Class Initialized
INFO - 2016-10-09 19:41:51 --> Model Class Initialized
ERROR - 2016-10-09 19:41:51 --> Unable to delete cache file for admin/index/detail_jaminan/472b07b9fcf2c2451e8781e944bf5f77cd8457c8
INFO - 2016-10-09 19:41:51 --> Final output sent to browser
DEBUG - 2016-10-09 19:41:51 --> Total execution time: 1.3151
INFO - 2016-10-09 19:41:56 --> Config Class Initialized
INFO - 2016-10-09 19:41:57 --> Hooks Class Initialized
DEBUG - 2016-10-09 19:41:57 --> UTF-8 Support Enabled
INFO - 2016-10-09 19:41:57 --> Utf8 Class Initialized
INFO - 2016-10-09 19:41:57 --> URI Class Initialized
INFO - 2016-10-09 19:41:57 --> Router Class Initialized
INFO - 2016-10-09 19:41:57 --> Output Class Initialized
INFO - 2016-10-09 19:41:57 --> Security Class Initialized
DEBUG - 2016-10-09 19:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 19:41:57 --> Input Class Initialized
INFO - 2016-10-09 19:41:57 --> Language Class Initialized
INFO - 2016-10-09 19:41:57 --> Language Class Initialized
INFO - 2016-10-09 19:41:57 --> Config Class Initialized
INFO - 2016-10-09 19:41:57 --> Loader Class Initialized
INFO - 2016-10-09 19:41:57 --> Helper loaded: url_helper
INFO - 2016-10-09 19:41:57 --> Database Driver Class Initialized
INFO - 2016-10-09 19:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 19:41:57 --> Controller Class Initialized
DEBUG - 2016-10-09 19:41:57 --> Index MX_Controller Initialized
INFO - 2016-10-09 19:41:58 --> Model Class Initialized
INFO - 2016-10-09 19:41:58 --> Model Class Initialized
ERROR - 2016-10-09 19:41:58 --> Unable to delete cache file for admin/index/update_jaminan
INFO - 2016-10-09 19:41:58 --> Final output sent to browser
DEBUG - 2016-10-09 19:41:58 --> Total execution time: 1.2102
INFO - 2016-10-09 19:42:29 --> Config Class Initialized
INFO - 2016-10-09 19:42:29 --> Hooks Class Initialized
DEBUG - 2016-10-09 19:42:29 --> UTF-8 Support Enabled
INFO - 2016-10-09 19:42:30 --> Utf8 Class Initialized
INFO - 2016-10-09 19:42:30 --> URI Class Initialized
INFO - 2016-10-09 19:42:30 --> Router Class Initialized
INFO - 2016-10-09 19:42:30 --> Output Class Initialized
INFO - 2016-10-09 19:42:30 --> Security Class Initialized
DEBUG - 2016-10-09 19:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 19:42:30 --> Input Class Initialized
INFO - 2016-10-09 19:42:30 --> Language Class Initialized
INFO - 2016-10-09 19:42:30 --> Language Class Initialized
INFO - 2016-10-09 19:42:30 --> Config Class Initialized
INFO - 2016-10-09 19:42:30 --> Loader Class Initialized
INFO - 2016-10-09 19:42:30 --> Helper loaded: url_helper
INFO - 2016-10-09 19:42:30 --> Database Driver Class Initialized
INFO - 2016-10-09 19:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 19:42:30 --> Controller Class Initialized
DEBUG - 2016-10-09 19:42:30 --> Index MX_Controller Initialized
INFO - 2016-10-09 19:42:30 --> Model Class Initialized
INFO - 2016-10-09 19:42:31 --> Model Class Initialized
ERROR - 2016-10-09 19:42:31 --> Unable to delete cache file for admin/index/update_jaminan
INFO - 2016-10-09 19:42:31 --> Final output sent to browser
DEBUG - 2016-10-09 19:42:31 --> Total execution time: 1.3052
INFO - 2016-10-09 19:43:03 --> Config Class Initialized
INFO - 2016-10-09 19:43:03 --> Hooks Class Initialized
DEBUG - 2016-10-09 19:43:03 --> UTF-8 Support Enabled
INFO - 2016-10-09 19:43:03 --> Utf8 Class Initialized
INFO - 2016-10-09 19:43:03 --> URI Class Initialized
INFO - 2016-10-09 19:43:03 --> Router Class Initialized
INFO - 2016-10-09 19:43:04 --> Output Class Initialized
INFO - 2016-10-09 19:43:04 --> Security Class Initialized
DEBUG - 2016-10-09 19:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 19:43:04 --> Input Class Initialized
INFO - 2016-10-09 19:43:04 --> Language Class Initialized
INFO - 2016-10-09 19:43:04 --> Language Class Initialized
INFO - 2016-10-09 19:43:04 --> Config Class Initialized
INFO - 2016-10-09 19:43:04 --> Loader Class Initialized
INFO - 2016-10-09 19:43:04 --> Helper loaded: url_helper
INFO - 2016-10-09 19:43:04 --> Database Driver Class Initialized
INFO - 2016-10-09 19:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 19:43:04 --> Controller Class Initialized
DEBUG - 2016-10-09 19:43:04 --> Index MX_Controller Initialized
INFO - 2016-10-09 19:43:04 --> Model Class Initialized
INFO - 2016-10-09 19:43:04 --> Model Class Initialized
ERROR - 2016-10-09 19:43:04 --> Unable to delete cache file for admin/index/update_jaminan
INFO - 2016-10-09 19:43:04 --> Final output sent to browser
DEBUG - 2016-10-09 19:43:04 --> Total execution time: 1.2475
INFO - 2016-10-09 19:43:34 --> Config Class Initialized
INFO - 2016-10-09 19:43:34 --> Hooks Class Initialized
DEBUG - 2016-10-09 19:43:34 --> UTF-8 Support Enabled
INFO - 2016-10-09 19:43:34 --> Utf8 Class Initialized
INFO - 2016-10-09 19:43:34 --> URI Class Initialized
INFO - 2016-10-09 19:43:35 --> Router Class Initialized
INFO - 2016-10-09 19:43:35 --> Output Class Initialized
INFO - 2016-10-09 19:43:35 --> Security Class Initialized
DEBUG - 2016-10-09 19:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 19:43:35 --> Input Class Initialized
INFO - 2016-10-09 19:43:35 --> Language Class Initialized
INFO - 2016-10-09 19:43:35 --> Language Class Initialized
INFO - 2016-10-09 19:43:35 --> Config Class Initialized
INFO - 2016-10-09 19:43:35 --> Loader Class Initialized
INFO - 2016-10-09 19:43:35 --> Helper loaded: url_helper
INFO - 2016-10-09 19:43:35 --> Database Driver Class Initialized
INFO - 2016-10-09 19:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 19:43:35 --> Controller Class Initialized
DEBUG - 2016-10-09 19:43:35 --> Index MX_Controller Initialized
INFO - 2016-10-09 19:43:35 --> Model Class Initialized
INFO - 2016-10-09 19:43:35 --> Model Class Initialized
ERROR - 2016-10-09 19:43:35 --> Unable to delete cache file for admin/index/detail_jaminan/472b07b9fcf2c2451e8781e944bf5f77cd8457c8
INFO - 2016-10-09 19:43:35 --> Final output sent to browser
DEBUG - 2016-10-09 19:43:36 --> Total execution time: 1.2070
INFO - 2016-10-09 19:43:46 --> Config Class Initialized
INFO - 2016-10-09 19:43:46 --> Hooks Class Initialized
DEBUG - 2016-10-09 19:43:46 --> UTF-8 Support Enabled
INFO - 2016-10-09 19:43:46 --> Utf8 Class Initialized
INFO - 2016-10-09 19:43:46 --> URI Class Initialized
INFO - 2016-10-09 19:43:46 --> Router Class Initialized
INFO - 2016-10-09 19:43:46 --> Output Class Initialized
INFO - 2016-10-09 19:43:46 --> Security Class Initialized
DEBUG - 2016-10-09 19:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 19:43:46 --> Input Class Initialized
INFO - 2016-10-09 19:43:46 --> Language Class Initialized
INFO - 2016-10-09 19:43:46 --> Language Class Initialized
INFO - 2016-10-09 19:43:46 --> Config Class Initialized
INFO - 2016-10-09 19:43:47 --> Loader Class Initialized
INFO - 2016-10-09 19:43:47 --> Helper loaded: url_helper
INFO - 2016-10-09 19:43:47 --> Database Driver Class Initialized
INFO - 2016-10-09 19:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 19:43:47 --> Controller Class Initialized
DEBUG - 2016-10-09 19:43:47 --> Index MX_Controller Initialized
INFO - 2016-10-09 19:43:47 --> Model Class Initialized
INFO - 2016-10-09 19:43:47 --> Model Class Initialized
ERROR - 2016-10-09 19:43:47 --> Unable to delete cache file for admin/index/update_jaminan
INFO - 2016-10-09 19:43:47 --> Final output sent to browser
DEBUG - 2016-10-09 19:43:47 --> Total execution time: 1.3156
INFO - 2016-10-09 19:45:36 --> Config Class Initialized
INFO - 2016-10-09 19:45:36 --> Hooks Class Initialized
DEBUG - 2016-10-09 19:45:36 --> UTF-8 Support Enabled
INFO - 2016-10-09 19:45:36 --> Utf8 Class Initialized
INFO - 2016-10-09 19:45:36 --> URI Class Initialized
INFO - 2016-10-09 19:45:36 --> Router Class Initialized
INFO - 2016-10-09 19:45:37 --> Output Class Initialized
INFO - 2016-10-09 19:45:37 --> Security Class Initialized
DEBUG - 2016-10-09 19:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 19:45:37 --> Input Class Initialized
INFO - 2016-10-09 19:45:37 --> Language Class Initialized
INFO - 2016-10-09 19:45:37 --> Language Class Initialized
INFO - 2016-10-09 19:45:37 --> Config Class Initialized
INFO - 2016-10-09 19:45:37 --> Loader Class Initialized
INFO - 2016-10-09 19:45:37 --> Helper loaded: url_helper
INFO - 2016-10-09 19:45:37 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 19:45:37 --> Controller Class Initialized
DEBUG - 2016-10-09 19:45:37 --> Index MX_Controller Initialized
INFO - 2016-10-09 19:45:37 --> Model Class Initialized
INFO - 2016-10-09 19:45:37 --> Model Class Initialized
ERROR - 2016-10-09 19:45:37 --> Unable to delete cache file for admin/index
DEBUG - 2016-10-09 19:45:37 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 19:45:37 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 19:45:37 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 19:45:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/dashboard.php
DEBUG - 2016-10-09 19:45:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 19:45:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 19:45:38 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:38 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:38 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:38 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:38 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:38 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:38 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:38 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:38 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:38 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:38 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:38 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:38 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:38 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:38 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:39 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:39 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:39 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:39 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:39 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:39 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:39 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:39 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:39 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:39 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:39 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:39 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:39 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:39 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:40 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:40 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:40 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:40 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:40 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:40 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:40 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:40 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:40 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:40 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:40 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:40 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:40 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:40 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:40 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:40 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:40 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:41 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:41 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:41 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:41 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:41 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:41 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:41 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:41 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:41 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:41 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:41 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:41 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:41 --> Database Driver Class Initialized
DEBUG - 2016-10-09 19:45:42 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 19:45:42 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 19:45:42 --> Final output sent to browser
DEBUG - 2016-10-09 19:45:42 --> Total execution time: 5.3863
INFO - 2016-10-09 19:45:47 --> Config Class Initialized
INFO - 2016-10-09 19:45:47 --> Hooks Class Initialized
DEBUG - 2016-10-09 19:45:47 --> UTF-8 Support Enabled
INFO - 2016-10-09 19:45:47 --> Utf8 Class Initialized
INFO - 2016-10-09 19:45:47 --> URI Class Initialized
INFO - 2016-10-09 19:45:47 --> Router Class Initialized
INFO - 2016-10-09 19:45:47 --> Output Class Initialized
INFO - 2016-10-09 19:45:47 --> Security Class Initialized
DEBUG - 2016-10-09 19:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 19:45:47 --> Input Class Initialized
INFO - 2016-10-09 19:45:48 --> Language Class Initialized
INFO - 2016-10-09 19:45:48 --> Language Class Initialized
INFO - 2016-10-09 19:45:48 --> Config Class Initialized
INFO - 2016-10-09 19:45:48 --> Loader Class Initialized
INFO - 2016-10-09 19:45:48 --> Helper loaded: url_helper
INFO - 2016-10-09 19:45:48 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 19:45:48 --> Controller Class Initialized
DEBUG - 2016-10-09 19:45:48 --> Index MX_Controller Initialized
INFO - 2016-10-09 19:45:48 --> Model Class Initialized
INFO - 2016-10-09 19:45:48 --> Model Class Initialized
ERROR - 2016-10-09 19:45:48 --> Unable to delete cache file for admin/index/list_jaminan
DEBUG - 2016-10-09 19:45:48 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-09 19:45:48 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-09 19:45:48 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-09 19:45:49 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/jaminan.php
DEBUG - 2016-10-09 19:45:49 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-09 19:45:49 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-09 19:45:49 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:49 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:49 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:49 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:49 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:49 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:49 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:49 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:49 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:49 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:49 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:49 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:50 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:50 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:50 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:50 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:50 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:50 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:50 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:50 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:50 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:50 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:50 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:51 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:51 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:51 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:51 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:51 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:51 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:51 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:51 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:51 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:51 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:51 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:52 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:52 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:52 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:52 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:52 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:52 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:52 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:52 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:52 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:52 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:52 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:52 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:52 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:52 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:52 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:53 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:53 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:53 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:53 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:53 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:53 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:53 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:53 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:53 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:53 --> Database Driver Class Initialized
INFO - 2016-10-09 19:45:53 --> Database Driver Class Initialized
DEBUG - 2016-10-09 19:45:53 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-09 19:45:53 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-09 19:45:53 --> Final output sent to browser
DEBUG - 2016-10-09 19:45:53 --> Total execution time: 6.4483
INFO - 2016-10-09 19:46:08 --> Config Class Initialized
INFO - 2016-10-09 19:46:08 --> Hooks Class Initialized
DEBUG - 2016-10-09 19:46:08 --> UTF-8 Support Enabled
INFO - 2016-10-09 19:46:08 --> Utf8 Class Initialized
INFO - 2016-10-09 19:46:08 --> URI Class Initialized
INFO - 2016-10-09 19:46:08 --> Router Class Initialized
INFO - 2016-10-09 19:46:08 --> Output Class Initialized
INFO - 2016-10-09 19:46:08 --> Security Class Initialized
DEBUG - 2016-10-09 19:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 19:46:08 --> Input Class Initialized
INFO - 2016-10-09 19:46:08 --> Language Class Initialized
INFO - 2016-10-09 19:46:09 --> Language Class Initialized
INFO - 2016-10-09 19:46:09 --> Config Class Initialized
INFO - 2016-10-09 19:46:09 --> Loader Class Initialized
INFO - 2016-10-09 19:46:09 --> Helper loaded: url_helper
INFO - 2016-10-09 19:46:09 --> Database Driver Class Initialized
INFO - 2016-10-09 19:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 19:46:09 --> Controller Class Initialized
DEBUG - 2016-10-09 19:46:09 --> Index MX_Controller Initialized
INFO - 2016-10-09 19:46:09 --> Model Class Initialized
INFO - 2016-10-09 19:46:09 --> Model Class Initialized
ERROR - 2016-10-09 19:46:09 --> Unable to delete cache file for admin/index/detail_jaminan/472b07b9fcf2c2451e8781e944bf5f77cd8457c8
INFO - 2016-10-09 19:46:09 --> Final output sent to browser
DEBUG - 2016-10-09 19:46:09 --> Total execution time: 1.4467
INFO - 2016-10-09 19:46:13 --> Config Class Initialized
INFO - 2016-10-09 19:46:13 --> Hooks Class Initialized
DEBUG - 2016-10-09 19:46:13 --> UTF-8 Support Enabled
INFO - 2016-10-09 19:46:13 --> Utf8 Class Initialized
INFO - 2016-10-09 19:46:13 --> URI Class Initialized
INFO - 2016-10-09 19:46:13 --> Router Class Initialized
INFO - 2016-10-09 19:46:13 --> Output Class Initialized
INFO - 2016-10-09 19:46:13 --> Security Class Initialized
DEBUG - 2016-10-09 19:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 19:46:13 --> Input Class Initialized
INFO - 2016-10-09 19:46:13 --> Language Class Initialized
INFO - 2016-10-09 19:46:13 --> Language Class Initialized
INFO - 2016-10-09 19:46:13 --> Config Class Initialized
INFO - 2016-10-09 19:46:13 --> Loader Class Initialized
INFO - 2016-10-09 19:46:14 --> Helper loaded: url_helper
INFO - 2016-10-09 19:46:14 --> Database Driver Class Initialized
INFO - 2016-10-09 19:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 19:46:14 --> Controller Class Initialized
DEBUG - 2016-10-09 19:46:14 --> Index MX_Controller Initialized
INFO - 2016-10-09 19:46:14 --> Model Class Initialized
INFO - 2016-10-09 19:46:14 --> Model Class Initialized
ERROR - 2016-10-09 19:46:14 --> Unable to delete cache file for admin/index/update_jaminan
INFO - 2016-10-09 19:46:14 --> Final output sent to browser
DEBUG - 2016-10-09 19:46:14 --> Total execution time: 1.3824
