<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-10-25 17:59:33 --> Config Class Initialized
INFO - 2016-10-25 17:59:33 --> Hooks Class Initialized
DEBUG - 2016-10-25 17:59:34 --> UTF-8 Support Enabled
INFO - 2016-10-25 17:59:34 --> Utf8 Class Initialized
INFO - 2016-10-25 17:59:34 --> URI Class Initialized
DEBUG - 2016-10-25 17:59:34 --> No URI present. Default controller set.
INFO - 2016-10-25 17:59:34 --> Router Class Initialized
INFO - 2016-10-25 17:59:34 --> Output Class Initialized
INFO - 2016-10-25 17:59:34 --> Security Class Initialized
DEBUG - 2016-10-25 17:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 17:59:34 --> Input Class Initialized
INFO - 2016-10-25 17:59:34 --> Language Class Initialized
INFO - 2016-10-25 17:59:34 --> Language Class Initialized
INFO - 2016-10-25 17:59:34 --> Config Class Initialized
INFO - 2016-10-25 17:59:34 --> Loader Class Initialized
INFO - 2016-10-25 17:59:34 --> Helper loaded: url_helper
INFO - 2016-10-25 17:59:35 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 17:59:35 --> Controller Class Initialized
DEBUG - 2016-10-25 17:59:35 --> Index MX_Controller Initialized
INFO - 2016-10-25 17:59:35 --> Model Class Initialized
INFO - 2016-10-25 17:59:35 --> Model Class Initialized
ERROR - 2016-10-25 17:59:35 --> Unable to delete cache file for 
DEBUG - 2016-10-25 17:59:35 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-25 17:59:35 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-25 17:59:35 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-25 17:59:35 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/dashboard.php
DEBUG - 2016-10-25 17:59:35 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-25 17:59:35 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-25 17:59:35 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:35 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:35 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:35 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:35 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:35 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:35 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:35 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:35 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:35 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:35 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:36 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:36 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:36 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:36 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:36 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:36 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:36 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:36 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:36 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:36 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:36 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:36 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:36 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:36 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:36 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:36 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:36 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:36 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:36 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:36 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:36 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:36 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:36 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:36 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:36 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:36 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:36 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:36 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:36 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:36 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:36 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:36 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:36 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:36 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:36 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:36 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:37 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:37 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:37 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:37 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:37 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:37 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:37 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:37 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:37 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:37 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:37 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:37 --> Database Driver Class Initialized
DEBUG - 2016-10-25 17:59:37 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-25 17:59:37 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-25 17:59:37 --> Final output sent to browser
INFO - 2016-10-25 17:59:37 --> Config Class Initialized
INFO - 2016-10-25 17:59:37 --> Hooks Class Initialized
DEBUG - 2016-10-25 17:59:37 --> Total execution time: 3.7775
DEBUG - 2016-10-25 17:59:37 --> UTF-8 Support Enabled
INFO - 2016-10-25 17:59:37 --> Utf8 Class Initialized
INFO - 2016-10-25 17:59:37 --> URI Class Initialized
INFO - 2016-10-25 17:59:37 --> Router Class Initialized
INFO - 2016-10-25 17:59:37 --> Output Class Initialized
INFO - 2016-10-25 17:59:37 --> Security Class Initialized
DEBUG - 2016-10-25 17:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 17:59:37 --> Input Class Initialized
INFO - 2016-10-25 17:59:37 --> Language Class Initialized
INFO - 2016-10-25 17:59:37 --> Language Class Initialized
INFO - 2016-10-25 17:59:37 --> Config Class Initialized
INFO - 2016-10-25 17:59:37 --> Loader Class Initialized
INFO - 2016-10-25 17:59:37 --> Helper loaded: url_helper
INFO - 2016-10-25 17:59:37 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 17:59:37 --> Controller Class Initialized
DEBUG - 2016-10-25 17:59:37 --> login MX_Controller Initialized
INFO - 2016-10-25 17:59:37 --> Model Class Initialized
INFO - 2016-10-25 17:59:37 --> Model Class Initialized
DEBUG - 2016-10-25 17:59:37 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/login.php
INFO - 2016-10-25 17:59:37 --> Final output sent to browser
DEBUG - 2016-10-25 17:59:37 --> Total execution time: 0.4436
INFO - 2016-10-25 17:59:46 --> Config Class Initialized
INFO - 2016-10-25 17:59:46 --> Hooks Class Initialized
DEBUG - 2016-10-25 17:59:46 --> UTF-8 Support Enabled
INFO - 2016-10-25 17:59:46 --> Utf8 Class Initialized
INFO - 2016-10-25 17:59:46 --> URI Class Initialized
INFO - 2016-10-25 17:59:46 --> Router Class Initialized
INFO - 2016-10-25 17:59:46 --> Output Class Initialized
INFO - 2016-10-25 17:59:46 --> Security Class Initialized
DEBUG - 2016-10-25 17:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 17:59:46 --> Input Class Initialized
INFO - 2016-10-25 17:59:46 --> Language Class Initialized
INFO - 2016-10-25 17:59:46 --> Language Class Initialized
INFO - 2016-10-25 17:59:46 --> Config Class Initialized
INFO - 2016-10-25 17:59:46 --> Loader Class Initialized
INFO - 2016-10-25 17:59:46 --> Helper loaded: url_helper
INFO - 2016-10-25 17:59:46 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 17:59:46 --> Controller Class Initialized
DEBUG - 2016-10-25 17:59:46 --> login MX_Controller Initialized
INFO - 2016-10-25 17:59:46 --> Model Class Initialized
INFO - 2016-10-25 17:59:46 --> Model Class Initialized
INFO - 2016-10-25 17:59:46 --> Final output sent to browser
DEBUG - 2016-10-25 17:59:46 --> Total execution time: 0.5546
INFO - 2016-10-25 17:59:47 --> Config Class Initialized
INFO - 2016-10-25 17:59:47 --> Hooks Class Initialized
DEBUG - 2016-10-25 17:59:47 --> UTF-8 Support Enabled
INFO - 2016-10-25 17:59:47 --> Utf8 Class Initialized
INFO - 2016-10-25 17:59:47 --> URI Class Initialized
INFO - 2016-10-25 17:59:47 --> Router Class Initialized
INFO - 2016-10-25 17:59:47 --> Output Class Initialized
INFO - 2016-10-25 17:59:47 --> Security Class Initialized
DEBUG - 2016-10-25 17:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 17:59:47 --> Input Class Initialized
INFO - 2016-10-25 17:59:47 --> Language Class Initialized
INFO - 2016-10-25 17:59:47 --> Language Class Initialized
INFO - 2016-10-25 17:59:47 --> Config Class Initialized
INFO - 2016-10-25 17:59:47 --> Loader Class Initialized
INFO - 2016-10-25 17:59:47 --> Helper loaded: url_helper
INFO - 2016-10-25 17:59:47 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 17:59:47 --> Controller Class Initialized
DEBUG - 2016-10-25 17:59:47 --> Index MX_Controller Initialized
INFO - 2016-10-25 17:59:47 --> Model Class Initialized
INFO - 2016-10-25 17:59:47 --> Model Class Initialized
ERROR - 2016-10-25 17:59:47 --> Unable to delete cache file for admin/index
DEBUG - 2016-10-25 17:59:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-25 17:59:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-25 17:59:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-25 17:59:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/dashboard.php
DEBUG - 2016-10-25 17:59:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-25 17:59:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-25 17:59:47 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:47 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:48 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:49 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:49 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:49 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:49 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:49 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:49 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:49 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:49 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:49 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:49 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:49 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:49 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:49 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:49 --> Database Driver Class Initialized
INFO - 2016-10-25 17:59:49 --> Database Driver Class Initialized
DEBUG - 2016-10-25 17:59:49 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-25 17:59:49 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-25 17:59:49 --> Final output sent to browser
DEBUG - 2016-10-25 17:59:49 --> Total execution time: 2.1856
INFO - 2016-10-25 18:00:00 --> Config Class Initialized
INFO - 2016-10-25 18:00:00 --> Hooks Class Initialized
DEBUG - 2016-10-25 18:00:00 --> UTF-8 Support Enabled
INFO - 2016-10-25 18:00:00 --> Utf8 Class Initialized
INFO - 2016-10-25 18:00:00 --> URI Class Initialized
INFO - 2016-10-25 18:00:00 --> Router Class Initialized
INFO - 2016-10-25 18:00:00 --> Output Class Initialized
INFO - 2016-10-25 18:00:00 --> Security Class Initialized
DEBUG - 2016-10-25 18:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 18:00:00 --> Input Class Initialized
INFO - 2016-10-25 18:00:00 --> Language Class Initialized
INFO - 2016-10-25 18:00:00 --> Language Class Initialized
INFO - 2016-10-25 18:00:00 --> Config Class Initialized
INFO - 2016-10-25 18:00:00 --> Loader Class Initialized
INFO - 2016-10-25 18:00:00 --> Helper loaded: url_helper
INFO - 2016-10-25 18:00:00 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 18:00:00 --> Controller Class Initialized
DEBUG - 2016-10-25 18:00:00 --> Index MX_Controller Initialized
INFO - 2016-10-25 18:00:00 --> Model Class Initialized
INFO - 2016-10-25 18:00:00 --> Model Class Initialized
ERROR - 2016-10-25 18:00:00 --> Unable to delete cache file for admin/index/list_jaminan
DEBUG - 2016-10-25 18:00:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-25 18:00:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-25 18:00:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-25 18:00:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/jaminan.php
DEBUG - 2016-10-25 18:00:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-25 18:00:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-25 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:01 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:02 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:02 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:02 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:02 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:02 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:02 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:02 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:02 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:02 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:02 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:02 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:02 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:02 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:02 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:02 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:02 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:02 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:02 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:02 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:02 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:02 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:02 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:02 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:02 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:02 --> Database Driver Class Initialized
INFO - 2016-10-25 18:00:02 --> Database Driver Class Initialized
DEBUG - 2016-10-25 18:00:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-25 18:00:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-25 18:00:02 --> Final output sent to browser
DEBUG - 2016-10-25 18:00:02 --> Total execution time: 2.2013
INFO - 2016-10-25 18:07:36 --> Config Class Initialized
INFO - 2016-10-25 18:07:36 --> Hooks Class Initialized
DEBUG - 2016-10-25 18:07:36 --> UTF-8 Support Enabled
INFO - 2016-10-25 18:07:36 --> Utf8 Class Initialized
INFO - 2016-10-25 18:07:36 --> URI Class Initialized
INFO - 2016-10-25 18:07:36 --> Router Class Initialized
INFO - 2016-10-25 18:07:36 --> Output Class Initialized
INFO - 2016-10-25 18:07:36 --> Security Class Initialized
DEBUG - 2016-10-25 18:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 18:07:36 --> Input Class Initialized
INFO - 2016-10-25 18:07:36 --> Language Class Initialized
INFO - 2016-10-25 18:07:36 --> Language Class Initialized
INFO - 2016-10-25 18:07:36 --> Config Class Initialized
INFO - 2016-10-25 18:07:36 --> Loader Class Initialized
INFO - 2016-10-25 18:07:36 --> Helper loaded: url_helper
INFO - 2016-10-25 18:07:36 --> Database Driver Class Initialized
INFO - 2016-10-25 18:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 18:07:36 --> Controller Class Initialized
DEBUG - 2016-10-25 18:07:36 --> Index MX_Controller Initialized
INFO - 2016-10-25 18:07:36 --> Model Class Initialized
INFO - 2016-10-25 18:07:36 --> Model Class Initialized
ERROR - 2016-10-25 18:07:36 --> Unable to delete cache file for admin/index/detail_jaminan/d435a6cdd786300dff204ee7c2ef942d3e9034e2
INFO - 2016-10-25 18:07:36 --> Final output sent to browser
DEBUG - 2016-10-25 18:07:36 --> Total execution time: 0.7116
INFO - 2016-10-25 18:13:55 --> Config Class Initialized
INFO - 2016-10-25 18:13:55 --> Hooks Class Initialized
DEBUG - 2016-10-25 18:13:55 --> UTF-8 Support Enabled
INFO - 2016-10-25 18:13:55 --> Utf8 Class Initialized
INFO - 2016-10-25 18:13:55 --> URI Class Initialized
INFO - 2016-10-25 18:13:55 --> Router Class Initialized
INFO - 2016-10-25 18:13:55 --> Output Class Initialized
INFO - 2016-10-25 18:13:55 --> Security Class Initialized
DEBUG - 2016-10-25 18:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 18:13:55 --> Input Class Initialized
INFO - 2016-10-25 18:13:55 --> Language Class Initialized
ERROR - 2016-10-25 18:13:55 --> Severity: Parsing Error --> syntax error, unexpected 'print' (T_PRINT), expecting identifier (T_STRING) E:\SERVER\htdocs\kops\application\modules\admin\controllers\Index.php 1521
INFO - 2016-10-25 18:14:08 --> Config Class Initialized
INFO - 2016-10-25 18:14:08 --> Hooks Class Initialized
DEBUG - 2016-10-25 18:14:08 --> UTF-8 Support Enabled
INFO - 2016-10-25 18:14:08 --> Utf8 Class Initialized
INFO - 2016-10-25 18:14:08 --> URI Class Initialized
INFO - 2016-10-25 18:14:08 --> Router Class Initialized
INFO - 2016-10-25 18:14:08 --> Output Class Initialized
INFO - 2016-10-25 18:14:08 --> Security Class Initialized
DEBUG - 2016-10-25 18:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 18:14:08 --> Input Class Initialized
INFO - 2016-10-25 18:14:08 --> Language Class Initialized
INFO - 2016-10-25 18:14:08 --> Language Class Initialized
INFO - 2016-10-25 18:14:08 --> Config Class Initialized
INFO - 2016-10-25 18:14:08 --> Loader Class Initialized
INFO - 2016-10-25 18:14:08 --> Helper loaded: url_helper
INFO - 2016-10-25 18:14:08 --> Database Driver Class Initialized
INFO - 2016-10-25 18:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 18:14:08 --> Controller Class Initialized
DEBUG - 2016-10-25 18:14:08 --> Index MX_Controller Initialized
INFO - 2016-10-25 18:14:08 --> Model Class Initialized
INFO - 2016-10-25 18:14:08 --> Model Class Initialized
ERROR - 2016-10-25 18:14:08 --> Unable to delete cache file for admin/index/toPdf
ERROR - 2016-10-25 18:14:08 --> Severity: Notice --> Undefined variable: type E:\SERVER\htdocs\kops\application\views\main_html\content\list_anggota.php 15
ERROR - 2016-10-25 18:14:08 --> Severity: Notice --> Undefined variable: type E:\SERVER\htdocs\kops\application\views\main_html\content\list_anggota.php 36
DEBUG - 2016-10-25 18:14:08 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-25 18:14:08 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-25 18:14:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
ERROR - 2016-10-25 18:14:09 --> Severity: Error --> Call to undefined method DOMText::getAttribute() E:\SERVER\htdocs\kops\application\third_party\dompdf\include\cellmap.cls.php 407
INFO - 2016-10-25 18:15:33 --> Config Class Initialized
INFO - 2016-10-25 18:15:33 --> Hooks Class Initialized
DEBUG - 2016-10-25 18:15:33 --> UTF-8 Support Enabled
INFO - 2016-10-25 18:15:33 --> Utf8 Class Initialized
INFO - 2016-10-25 18:15:33 --> URI Class Initialized
INFO - 2016-10-25 18:15:33 --> Router Class Initialized
INFO - 2016-10-25 18:15:33 --> Output Class Initialized
INFO - 2016-10-25 18:15:33 --> Security Class Initialized
DEBUG - 2016-10-25 18:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 18:15:33 --> Input Class Initialized
INFO - 2016-10-25 18:15:33 --> Language Class Initialized
INFO - 2016-10-25 18:15:33 --> Language Class Initialized
INFO - 2016-10-25 18:15:33 --> Config Class Initialized
INFO - 2016-10-25 18:15:33 --> Loader Class Initialized
INFO - 2016-10-25 18:15:33 --> Helper loaded: url_helper
INFO - 2016-10-25 18:15:33 --> Database Driver Class Initialized
INFO - 2016-10-25 18:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 18:15:33 --> Controller Class Initialized
DEBUG - 2016-10-25 18:15:33 --> Index MX_Controller Initialized
INFO - 2016-10-25 18:15:33 --> Model Class Initialized
INFO - 2016-10-25 18:15:33 --> Model Class Initialized
ERROR - 2016-10-25 18:15:33 --> Unable to delete cache file for admin/index/toPdf
ERROR - 2016-10-25 18:15:33 --> Severity: Notice --> Undefined variable: type E:\SERVER\htdocs\kops\application\views\main_html\content\list_anggota.php 15
ERROR - 2016-10-25 18:15:33 --> Severity: Notice --> Undefined variable: type E:\SERVER\htdocs\kops\application\views\main_html\content\list_anggota.php 36
DEBUG - 2016-10-25 18:15:33 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-25 18:15:33 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-25 18:15:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
ERROR - 2016-10-25 18:15:34 --> Severity: Error --> Call to undefined method DOMText::getAttribute() E:\SERVER\htdocs\kops\application\third_party\dompdf\include\cellmap.cls.php 407
