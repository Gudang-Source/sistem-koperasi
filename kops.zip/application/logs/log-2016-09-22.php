<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-09-22 23:33:13 --> Config Class Initialized
INFO - 2016-09-22 23:33:13 --> Hooks Class Initialized
DEBUG - 2016-09-22 23:33:13 --> UTF-8 Support Enabled
INFO - 2016-09-22 23:33:13 --> Utf8 Class Initialized
INFO - 2016-09-22 23:33:13 --> URI Class Initialized
INFO - 2016-09-22 23:33:13 --> Router Class Initialized
INFO - 2016-09-22 23:33:13 --> Output Class Initialized
INFO - 2016-09-22 23:33:13 --> Security Class Initialized
DEBUG - 2016-09-22 23:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 23:33:13 --> Input Class Initialized
INFO - 2016-09-22 23:33:13 --> Language Class Initialized
ERROR - 2016-09-22 23:33:13 --> 404 Page Not Found: /index
INFO - 2016-09-22 23:33:14 --> Config Class Initialized
INFO - 2016-09-22 23:33:14 --> Hooks Class Initialized
DEBUG - 2016-09-22 23:33:14 --> UTF-8 Support Enabled
INFO - 2016-09-22 23:33:14 --> Utf8 Class Initialized
INFO - 2016-09-22 23:33:14 --> URI Class Initialized
INFO - 2016-09-22 23:33:14 --> Router Class Initialized
INFO - 2016-09-22 23:33:14 --> Output Class Initialized
INFO - 2016-09-22 23:33:14 --> Security Class Initialized
DEBUG - 2016-09-22 23:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 23:33:14 --> Input Class Initialized
INFO - 2016-09-22 23:33:14 --> Language Class Initialized
ERROR - 2016-09-22 23:33:14 --> 404 Page Not Found: /index
INFO - 2016-09-22 23:33:15 --> Config Class Initialized
INFO - 2016-09-22 23:33:15 --> Hooks Class Initialized
DEBUG - 2016-09-22 23:33:15 --> UTF-8 Support Enabled
INFO - 2016-09-22 23:33:15 --> Utf8 Class Initialized
INFO - 2016-09-22 23:33:15 --> URI Class Initialized
INFO - 2016-09-22 23:33:15 --> Router Class Initialized
INFO - 2016-09-22 23:33:15 --> Output Class Initialized
INFO - 2016-09-22 23:33:15 --> Security Class Initialized
DEBUG - 2016-09-22 23:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 23:33:15 --> Input Class Initialized
INFO - 2016-09-22 23:33:15 --> Language Class Initialized
ERROR - 2016-09-22 23:33:15 --> 404 Page Not Found: /index
INFO - 2016-09-22 23:33:31 --> Config Class Initialized
INFO - 2016-09-22 23:33:31 --> Hooks Class Initialized
DEBUG - 2016-09-22 23:33:31 --> UTF-8 Support Enabled
INFO - 2016-09-22 23:33:31 --> Utf8 Class Initialized
INFO - 2016-09-22 23:33:31 --> URI Class Initialized
INFO - 2016-09-22 23:33:31 --> Router Class Initialized
INFO - 2016-09-22 23:33:31 --> Output Class Initialized
INFO - 2016-09-22 23:33:31 --> Security Class Initialized
DEBUG - 2016-09-22 23:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 23:33:31 --> Input Class Initialized
INFO - 2016-09-22 23:33:31 --> Language Class Initialized
ERROR - 2016-09-22 23:33:31 --> 404 Page Not Found: /index
INFO - 2016-09-22 23:33:39 --> Config Class Initialized
INFO - 2016-09-22 23:33:39 --> Hooks Class Initialized
DEBUG - 2016-09-22 23:33:39 --> UTF-8 Support Enabled
INFO - 2016-09-22 23:33:39 --> Utf8 Class Initialized
INFO - 2016-09-22 23:33:39 --> URI Class Initialized
INFO - 2016-09-22 23:33:39 --> Router Class Initialized
INFO - 2016-09-22 23:33:39 --> Output Class Initialized
INFO - 2016-09-22 23:33:39 --> Security Class Initialized
DEBUG - 2016-09-22 23:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 23:33:39 --> Input Class Initialized
INFO - 2016-09-22 23:33:39 --> Language Class Initialized
ERROR - 2016-09-22 23:33:39 --> 404 Page Not Found: /index
INFO - 2016-09-22 23:33:43 --> Config Class Initialized
INFO - 2016-09-22 23:33:43 --> Hooks Class Initialized
DEBUG - 2016-09-22 23:33:43 --> UTF-8 Support Enabled
INFO - 2016-09-22 23:33:43 --> Utf8 Class Initialized
INFO - 2016-09-22 23:33:43 --> URI Class Initialized
INFO - 2016-09-22 23:33:43 --> Router Class Initialized
INFO - 2016-09-22 23:33:43 --> Output Class Initialized
INFO - 2016-09-22 23:33:43 --> Security Class Initialized
DEBUG - 2016-09-22 23:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 23:33:43 --> Input Class Initialized
INFO - 2016-09-22 23:33:43 --> Language Class Initialized
ERROR - 2016-09-22 23:33:43 --> 404 Page Not Found: /index
INFO - 2016-09-22 23:34:02 --> Config Class Initialized
INFO - 2016-09-22 23:34:02 --> Hooks Class Initialized
DEBUG - 2016-09-22 23:34:02 --> UTF-8 Support Enabled
INFO - 2016-09-22 23:34:02 --> Utf8 Class Initialized
INFO - 2016-09-22 23:34:02 --> URI Class Initialized
INFO - 2016-09-22 23:34:02 --> Router Class Initialized
INFO - 2016-09-22 23:34:02 --> Output Class Initialized
INFO - 2016-09-22 23:34:02 --> Security Class Initialized
DEBUG - 2016-09-22 23:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 23:34:02 --> Input Class Initialized
INFO - 2016-09-22 23:34:02 --> Language Class Initialized
ERROR - 2016-09-22 23:34:02 --> 404 Page Not Found: /index
INFO - 2016-09-22 23:34:59 --> Config Class Initialized
INFO - 2016-09-22 23:34:59 --> Hooks Class Initialized
DEBUG - 2016-09-22 23:34:59 --> UTF-8 Support Enabled
INFO - 2016-09-22 23:34:59 --> Utf8 Class Initialized
INFO - 2016-09-22 23:34:59 --> URI Class Initialized
INFO - 2016-09-22 23:34:59 --> Router Class Initialized
INFO - 2016-09-22 23:34:59 --> Output Class Initialized
INFO - 2016-09-22 23:34:59 --> Security Class Initialized
DEBUG - 2016-09-22 23:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 23:34:59 --> Input Class Initialized
INFO - 2016-09-22 23:34:59 --> Language Class Initialized
ERROR - 2016-09-22 23:34:59 --> 404 Page Not Found: /index
INFO - 2016-09-22 23:39:20 --> Config Class Initialized
INFO - 2016-09-22 23:39:20 --> Hooks Class Initialized
DEBUG - 2016-09-22 23:39:20 --> UTF-8 Support Enabled
INFO - 2016-09-22 23:39:20 --> Utf8 Class Initialized
INFO - 2016-09-22 23:39:20 --> URI Class Initialized
INFO - 2016-09-22 23:39:20 --> Router Class Initialized
INFO - 2016-09-22 23:39:20 --> Output Class Initialized
INFO - 2016-09-22 23:39:20 --> Security Class Initialized
DEBUG - 2016-09-22 23:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 23:39:20 --> Input Class Initialized
INFO - 2016-09-22 23:39:20 --> Language Class Initialized
ERROR - 2016-09-22 23:39:20 --> 404 Page Not Found: /index
INFO - 2016-09-22 23:39:33 --> Config Class Initialized
INFO - 2016-09-22 23:39:33 --> Hooks Class Initialized
DEBUG - 2016-09-22 23:39:33 --> UTF-8 Support Enabled
INFO - 2016-09-22 23:39:33 --> Utf8 Class Initialized
INFO - 2016-09-22 23:39:33 --> URI Class Initialized
INFO - 2016-09-22 23:39:33 --> Router Class Initialized
INFO - 2016-09-22 23:39:33 --> Output Class Initialized
INFO - 2016-09-22 23:39:33 --> Security Class Initialized
DEBUG - 2016-09-22 23:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 23:39:33 --> Input Class Initialized
INFO - 2016-09-22 23:39:33 --> Language Class Initialized
INFO - 2016-09-22 23:39:33 --> Language Class Initialized
INFO - 2016-09-22 23:39:33 --> Config Class Initialized
INFO - 2016-09-22 23:39:33 --> Loader Class Initialized
INFO - 2016-09-22 23:39:33 --> Helper loaded: url_helper
INFO - 2016-09-22 23:39:33 --> Database Driver Class Initialized
INFO - 2016-09-22 23:39:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 23:39:33 --> Controller Class Initialized
DEBUG - 2016-09-22 23:39:33 --> Index MX_Controller Initialized
INFO - 2016-09-22 23:39:33 --> Model Class Initialized
INFO - 2016-09-22 23:39:48 --> Config Class Initialized
INFO - 2016-09-22 23:39:48 --> Hooks Class Initialized
DEBUG - 2016-09-22 23:39:48 --> UTF-8 Support Enabled
INFO - 2016-09-22 23:39:48 --> Utf8 Class Initialized
INFO - 2016-09-22 23:39:48 --> URI Class Initialized
INFO - 2016-09-22 23:39:48 --> Router Class Initialized
INFO - 2016-09-22 23:39:48 --> Output Class Initialized
INFO - 2016-09-22 23:39:48 --> Security Class Initialized
DEBUG - 2016-09-22 23:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 23:39:48 --> Input Class Initialized
INFO - 2016-09-22 23:39:48 --> Language Class Initialized
INFO - 2016-09-22 23:39:48 --> Language Class Initialized
INFO - 2016-09-22 23:39:48 --> Config Class Initialized
INFO - 2016-09-22 23:39:48 --> Loader Class Initialized
INFO - 2016-09-22 23:39:48 --> Helper loaded: url_helper
INFO - 2016-09-22 23:39:48 --> Database Driver Class Initialized
INFO - 2016-09-22 23:39:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 23:39:48 --> Controller Class Initialized
DEBUG - 2016-09-22 23:39:48 --> Index MX_Controller Initialized
INFO - 2016-09-22 23:39:48 --> Model Class Initialized
INFO - 2016-09-22 23:41:24 --> Config Class Initialized
INFO - 2016-09-22 23:41:24 --> Hooks Class Initialized
DEBUG - 2016-09-22 23:41:24 --> UTF-8 Support Enabled
INFO - 2016-09-22 23:41:24 --> Utf8 Class Initialized
INFO - 2016-09-22 23:41:24 --> URI Class Initialized
INFO - 2016-09-22 23:41:24 --> Router Class Initialized
INFO - 2016-09-22 23:41:24 --> Output Class Initialized
INFO - 2016-09-22 23:41:24 --> Security Class Initialized
DEBUG - 2016-09-22 23:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 23:41:24 --> Input Class Initialized
INFO - 2016-09-22 23:41:24 --> Language Class Initialized
INFO - 2016-09-22 23:41:24 --> Language Class Initialized
INFO - 2016-09-22 23:41:24 --> Config Class Initialized
INFO - 2016-09-22 23:41:24 --> Loader Class Initialized
INFO - 2016-09-22 23:41:24 --> Helper loaded: url_helper
INFO - 2016-09-22 23:41:24 --> Database Driver Class Initialized
INFO - 2016-09-22 23:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 23:41:24 --> Controller Class Initialized
DEBUG - 2016-09-22 23:41:24 --> Index MX_Controller Initialized
INFO - 2016-09-22 23:41:24 --> Model Class Initialized
INFO - 2016-09-22 23:43:18 --> Config Class Initialized
INFO - 2016-09-22 23:43:18 --> Hooks Class Initialized
DEBUG - 2016-09-22 23:43:18 --> UTF-8 Support Enabled
INFO - 2016-09-22 23:43:18 --> Utf8 Class Initialized
INFO - 2016-09-22 23:43:18 --> URI Class Initialized
INFO - 2016-09-22 23:43:18 --> Router Class Initialized
INFO - 2016-09-22 23:43:18 --> Output Class Initialized
INFO - 2016-09-22 23:43:18 --> Security Class Initialized
DEBUG - 2016-09-22 23:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 23:43:18 --> Input Class Initialized
INFO - 2016-09-22 23:43:18 --> Language Class Initialized
INFO - 2016-09-22 23:43:18 --> Language Class Initialized
INFO - 2016-09-22 23:43:18 --> Config Class Initialized
INFO - 2016-09-22 23:43:18 --> Loader Class Initialized
INFO - 2016-09-22 23:43:18 --> Helper loaded: url_helper
INFO - 2016-09-22 23:43:18 --> Database Driver Class Initialized
INFO - 2016-09-22 23:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 23:43:18 --> Controller Class Initialized
DEBUG - 2016-09-22 23:43:18 --> Index MX_Controller Initialized
INFO - 2016-09-22 23:43:18 --> Model Class Initialized
INFO - 2016-09-22 23:43:23 --> Config Class Initialized
INFO - 2016-09-22 23:43:23 --> Hooks Class Initialized
DEBUG - 2016-09-22 23:43:23 --> UTF-8 Support Enabled
INFO - 2016-09-22 23:43:23 --> Utf8 Class Initialized
INFO - 2016-09-22 23:43:23 --> URI Class Initialized
INFO - 2016-09-22 23:43:23 --> Router Class Initialized
INFO - 2016-09-22 23:43:23 --> Output Class Initialized
INFO - 2016-09-22 23:43:23 --> Security Class Initialized
DEBUG - 2016-09-22 23:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 23:43:23 --> Input Class Initialized
INFO - 2016-09-22 23:43:23 --> Language Class Initialized
INFO - 2016-09-22 23:43:23 --> Language Class Initialized
INFO - 2016-09-22 23:43:23 --> Config Class Initialized
INFO - 2016-09-22 23:43:23 --> Loader Class Initialized
INFO - 2016-09-22 23:43:23 --> Helper loaded: url_helper
INFO - 2016-09-22 23:43:23 --> Database Driver Class Initialized
INFO - 2016-09-22 23:43:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 23:43:23 --> Controller Class Initialized
DEBUG - 2016-09-22 23:43:23 --> Login MX_Controller Initialized
INFO - 2016-09-22 23:43:23 --> Model Class Initialized
INFO - 2016-09-22 23:46:54 --> Config Class Initialized
INFO - 2016-09-22 23:46:54 --> Hooks Class Initialized
DEBUG - 2016-09-22 23:46:54 --> UTF-8 Support Enabled
INFO - 2016-09-22 23:46:54 --> Utf8 Class Initialized
INFO - 2016-09-22 23:46:54 --> URI Class Initialized
INFO - 2016-09-22 23:46:54 --> Router Class Initialized
INFO - 2016-09-22 23:46:54 --> Output Class Initialized
INFO - 2016-09-22 23:46:54 --> Security Class Initialized
DEBUG - 2016-09-22 23:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 23:46:54 --> Input Class Initialized
INFO - 2016-09-22 23:46:54 --> Language Class Initialized
INFO - 2016-09-22 23:46:54 --> Language Class Initialized
INFO - 2016-09-22 23:46:54 --> Config Class Initialized
INFO - 2016-09-22 23:46:54 --> Loader Class Initialized
INFO - 2016-09-22 23:46:54 --> Helper loaded: url_helper
INFO - 2016-09-22 23:46:54 --> Database Driver Class Initialized
INFO - 2016-09-22 23:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 23:46:54 --> Controller Class Initialized
DEBUG - 2016-09-22 23:46:54 --> Login MX_Controller Initialized
INFO - 2016-09-22 23:46:54 --> Model Class Initialized
INFO - 2016-09-22 23:48:40 --> Config Class Initialized
INFO - 2016-09-22 23:48:40 --> Hooks Class Initialized
DEBUG - 2016-09-22 23:48:40 --> UTF-8 Support Enabled
INFO - 2016-09-22 23:48:40 --> Utf8 Class Initialized
INFO - 2016-09-22 23:48:40 --> URI Class Initialized
INFO - 2016-09-22 23:48:40 --> Router Class Initialized
INFO - 2016-09-22 23:48:40 --> Output Class Initialized
INFO - 2016-09-22 23:48:40 --> Security Class Initialized
DEBUG - 2016-09-22 23:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 23:48:40 --> Input Class Initialized
INFO - 2016-09-22 23:48:40 --> Language Class Initialized
INFO - 2016-09-22 23:48:40 --> Language Class Initialized
INFO - 2016-09-22 23:48:40 --> Config Class Initialized
INFO - 2016-09-22 23:48:40 --> Loader Class Initialized
INFO - 2016-09-22 23:48:40 --> Helper loaded: url_helper
INFO - 2016-09-22 23:48:40 --> Database Driver Class Initialized
INFO - 2016-09-22 23:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 23:48:40 --> Controller Class Initialized
DEBUG - 2016-09-22 23:48:40 --> Login MX_Controller Initialized
INFO - 2016-09-22 23:48:40 --> Model Class Initialized
INFO - 2016-09-22 23:50:28 --> Config Class Initialized
INFO - 2016-09-22 23:50:28 --> Hooks Class Initialized
DEBUG - 2016-09-22 23:50:28 --> UTF-8 Support Enabled
INFO - 2016-09-22 23:50:28 --> Utf8 Class Initialized
INFO - 2016-09-22 23:50:28 --> URI Class Initialized
INFO - 2016-09-22 23:50:28 --> Router Class Initialized
INFO - 2016-09-22 23:50:28 --> Output Class Initialized
INFO - 2016-09-22 23:50:28 --> Security Class Initialized
DEBUG - 2016-09-22 23:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 23:50:28 --> Input Class Initialized
INFO - 2016-09-22 23:50:28 --> Language Class Initialized
INFO - 2016-09-22 23:50:28 --> Language Class Initialized
INFO - 2016-09-22 23:50:28 --> Config Class Initialized
INFO - 2016-09-22 23:50:28 --> Loader Class Initialized
INFO - 2016-09-22 23:50:28 --> Helper loaded: url_helper
INFO - 2016-09-22 23:50:28 --> Database Driver Class Initialized
INFO - 2016-09-22 23:50:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 23:50:28 --> Controller Class Initialized
DEBUG - 2016-09-22 23:50:28 --> Login MX_Controller Initialized
INFO - 2016-09-22 23:50:28 --> Model Class Initialized
INFO - 2016-09-22 23:51:19 --> Config Class Initialized
INFO - 2016-09-22 23:51:19 --> Hooks Class Initialized
DEBUG - 2016-09-22 23:51:19 --> UTF-8 Support Enabled
INFO - 2016-09-22 23:51:19 --> Utf8 Class Initialized
INFO - 2016-09-22 23:51:19 --> URI Class Initialized
INFO - 2016-09-22 23:51:19 --> Router Class Initialized
INFO - 2016-09-22 23:51:19 --> Output Class Initialized
INFO - 2016-09-22 23:51:19 --> Security Class Initialized
DEBUG - 2016-09-22 23:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 23:51:19 --> Input Class Initialized
INFO - 2016-09-22 23:51:19 --> Language Class Initialized
INFO - 2016-09-22 23:51:19 --> Language Class Initialized
INFO - 2016-09-22 23:51:19 --> Config Class Initialized
INFO - 2016-09-22 23:51:19 --> Loader Class Initialized
INFO - 2016-09-22 23:51:19 --> Helper loaded: url_helper
INFO - 2016-09-22 23:51:19 --> Database Driver Class Initialized
INFO - 2016-09-22 23:51:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 23:51:19 --> Controller Class Initialized
DEBUG - 2016-09-22 23:51:19 --> Login MX_Controller Initialized
INFO - 2016-09-22 23:51:19 --> Model Class Initialized
INFO - 2016-09-22 23:52:39 --> Config Class Initialized
INFO - 2016-09-22 23:52:39 --> Hooks Class Initialized
DEBUG - 2016-09-22 23:52:39 --> UTF-8 Support Enabled
INFO - 2016-09-22 23:52:39 --> Utf8 Class Initialized
INFO - 2016-09-22 23:52:39 --> URI Class Initialized
INFO - 2016-09-22 23:52:39 --> Router Class Initialized
INFO - 2016-09-22 23:52:39 --> Output Class Initialized
INFO - 2016-09-22 23:52:39 --> Security Class Initialized
DEBUG - 2016-09-22 23:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 23:52:39 --> Input Class Initialized
INFO - 2016-09-22 23:52:39 --> Language Class Initialized
INFO - 2016-09-22 23:52:39 --> Language Class Initialized
INFO - 2016-09-22 23:52:39 --> Config Class Initialized
INFO - 2016-09-22 23:52:39 --> Loader Class Initialized
INFO - 2016-09-22 23:52:39 --> Helper loaded: url_helper
INFO - 2016-09-22 23:52:39 --> Database Driver Class Initialized
INFO - 2016-09-22 23:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 23:52:39 --> Controller Class Initialized
DEBUG - 2016-09-22 23:52:39 --> Index MX_Controller Initialized
INFO - 2016-09-22 23:52:39 --> Model Class Initialized
INFO - 2016-09-22 23:53:48 --> Config Class Initialized
INFO - 2016-09-22 23:53:48 --> Hooks Class Initialized
DEBUG - 2016-09-22 23:53:48 --> UTF-8 Support Enabled
INFO - 2016-09-22 23:53:48 --> Utf8 Class Initialized
INFO - 2016-09-22 23:53:48 --> URI Class Initialized
INFO - 2016-09-22 23:53:48 --> Router Class Initialized
INFO - 2016-09-22 23:53:48 --> Output Class Initialized
INFO - 2016-09-22 23:53:48 --> Security Class Initialized
DEBUG - 2016-09-22 23:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 23:53:48 --> Input Class Initialized
INFO - 2016-09-22 23:53:48 --> Language Class Initialized
INFO - 2016-09-22 23:53:48 --> Language Class Initialized
INFO - 2016-09-22 23:53:48 --> Config Class Initialized
INFO - 2016-09-22 23:53:48 --> Loader Class Initialized
INFO - 2016-09-22 23:53:48 --> Helper loaded: url_helper
INFO - 2016-09-22 23:53:48 --> Database Driver Class Initialized
INFO - 2016-09-22 23:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 23:53:48 --> Controller Class Initialized
DEBUG - 2016-09-22 23:53:48 --> Index MX_Controller Initialized
INFO - 2016-09-22 23:53:48 --> Model Class Initialized
INFO - 2016-09-22 23:53:48 --> Model Class Initialized
ERROR - 2016-09-22 23:53:48 --> Severity: Warning --> require_once(/home/koperasi/public_html/application/\modules\anggota\controllers\Anggota.php): failed to open stream: No such file or directory /home/koperasi/public_html/application/modules/Admin/controllers/Index.php 7
ERROR - 2016-09-22 23:53:48 --> Severity: Compile Error --> require_once(): Failed opening required '/home/koperasi/public_html/application/\modules\anggota\controllers\Anggota.php' (include_path='.:/usr/lib/php:/usr/local/lib/php') /home/koperasi/public_html/application/modules/Admin/controllers/Index.php 7
INFO - 2016-09-22 23:54:35 --> Config Class Initialized
INFO - 2016-09-22 23:54:35 --> Hooks Class Initialized
DEBUG - 2016-09-22 23:54:35 --> UTF-8 Support Enabled
INFO - 2016-09-22 23:54:35 --> Utf8 Class Initialized
INFO - 2016-09-22 23:54:35 --> URI Class Initialized
INFO - 2016-09-22 23:54:35 --> Router Class Initialized
INFO - 2016-09-22 23:54:35 --> Output Class Initialized
INFO - 2016-09-22 23:54:35 --> Security Class Initialized
DEBUG - 2016-09-22 23:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 23:54:35 --> Input Class Initialized
INFO - 2016-09-22 23:54:35 --> Language Class Initialized
INFO - 2016-09-22 23:54:35 --> Language Class Initialized
INFO - 2016-09-22 23:54:35 --> Config Class Initialized
INFO - 2016-09-22 23:54:35 --> Loader Class Initialized
INFO - 2016-09-22 23:54:35 --> Helper loaded: url_helper
INFO - 2016-09-22 23:54:35 --> Database Driver Class Initialized
INFO - 2016-09-22 23:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 23:54:35 --> Controller Class Initialized
DEBUG - 2016-09-22 23:54:35 --> Index MX_Controller Initialized
INFO - 2016-09-22 23:54:35 --> Model Class Initialized
INFO - 2016-09-22 23:54:35 --> Model Class Initialized
ERROR - 2016-09-22 23:54:35 --> Severity: Warning --> require_once(/home/koperasi/public_html/application/modules/anggota/controllers/Anggota.php): failed to open stream: No such file or directory /home/koperasi/public_html/application/modules/Admin/controllers/Index.php 7
ERROR - 2016-09-22 23:54:35 --> Severity: Compile Error --> require_once(): Failed opening required '/home/koperasi/public_html/application/modules/anggota/controllers/Anggota.php' (include_path='.:/usr/lib/php:/usr/local/lib/php') /home/koperasi/public_html/application/modules/Admin/controllers/Index.php 7
INFO - 2016-09-22 23:55:04 --> Config Class Initialized
INFO - 2016-09-22 23:55:04 --> Hooks Class Initialized
DEBUG - 2016-09-22 23:55:04 --> UTF-8 Support Enabled
INFO - 2016-09-22 23:55:04 --> Utf8 Class Initialized
INFO - 2016-09-22 23:55:04 --> URI Class Initialized
INFO - 2016-09-22 23:55:04 --> Router Class Initialized
INFO - 2016-09-22 23:55:04 --> Output Class Initialized
INFO - 2016-09-22 23:55:04 --> Security Class Initialized
DEBUG - 2016-09-22 23:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 23:55:04 --> Input Class Initialized
INFO - 2016-09-22 23:55:04 --> Language Class Initialized
INFO - 2016-09-22 23:55:04 --> Language Class Initialized
INFO - 2016-09-22 23:55:04 --> Config Class Initialized
INFO - 2016-09-22 23:55:04 --> Loader Class Initialized
INFO - 2016-09-22 23:55:04 --> Helper loaded: url_helper
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 23:55:04 --> Controller Class Initialized
DEBUG - 2016-09-22 23:55:04 --> Index MX_Controller Initialized
INFO - 2016-09-22 23:55:04 --> Model Class Initialized
INFO - 2016-09-22 23:55:04 --> Model Class Initialized
DEBUG - 2016-09-22 23:55:04 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-22 23:55:04 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-22 23:55:04 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-22 23:55:04 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-22 23:55:04 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-22 23:55:04 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:04 --> Database Driver Class Initialized
DEBUG - 2016-09-22 23:55:04 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-22 23:55:04 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-22 23:55:04 --> Final output sent to browser
DEBUG - 2016-09-22 23:55:04 --> Total execution time: 0.4373
INFO - 2016-09-22 23:55:05 --> Config Class Initialized
INFO - 2016-09-22 23:55:05 --> Hooks Class Initialized
DEBUG - 2016-09-22 23:55:05 --> UTF-8 Support Enabled
INFO - 2016-09-22 23:55:05 --> Utf8 Class Initialized
INFO - 2016-09-22 23:55:05 --> URI Class Initialized
INFO - 2016-09-22 23:55:05 --> Router Class Initialized
INFO - 2016-09-22 23:55:05 --> Output Class Initialized
INFO - 2016-09-22 23:55:05 --> Security Class Initialized
DEBUG - 2016-09-22 23:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 23:55:05 --> Input Class Initialized
INFO - 2016-09-22 23:55:05 --> Language Class Initialized
ERROR - 2016-09-22 23:55:05 --> 404 Page Not Found: /index
INFO - 2016-09-22 23:55:13 --> Config Class Initialized
INFO - 2016-09-22 23:55:13 --> Hooks Class Initialized
DEBUG - 2016-09-22 23:55:13 --> UTF-8 Support Enabled
INFO - 2016-09-22 23:55:13 --> Utf8 Class Initialized
INFO - 2016-09-22 23:55:13 --> URI Class Initialized
INFO - 2016-09-22 23:55:13 --> Router Class Initialized
INFO - 2016-09-22 23:55:13 --> Output Class Initialized
INFO - 2016-09-22 23:55:13 --> Security Class Initialized
DEBUG - 2016-09-22 23:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 23:55:13 --> Input Class Initialized
INFO - 2016-09-22 23:55:13 --> Language Class Initialized
INFO - 2016-09-22 23:55:13 --> Language Class Initialized
INFO - 2016-09-22 23:55:13 --> Config Class Initialized
INFO - 2016-09-22 23:55:13 --> Loader Class Initialized
INFO - 2016-09-22 23:55:13 --> Helper loaded: url_helper
INFO - 2016-09-22 23:55:13 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 23:55:13 --> Controller Class Initialized
DEBUG - 2016-09-22 23:55:13 --> Login MX_Controller Initialized
INFO - 2016-09-22 23:55:13 --> Model Class Initialized
INFO - 2016-09-22 23:55:49 --> Config Class Initialized
INFO - 2016-09-22 23:55:49 --> Hooks Class Initialized
DEBUG - 2016-09-22 23:55:49 --> UTF-8 Support Enabled
INFO - 2016-09-22 23:55:49 --> Utf8 Class Initialized
INFO - 2016-09-22 23:55:49 --> URI Class Initialized
INFO - 2016-09-22 23:55:49 --> Router Class Initialized
INFO - 2016-09-22 23:55:49 --> Output Class Initialized
INFO - 2016-09-22 23:55:49 --> Security Class Initialized
DEBUG - 2016-09-22 23:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 23:55:49 --> Input Class Initialized
INFO - 2016-09-22 23:55:49 --> Language Class Initialized
INFO - 2016-09-22 23:55:49 --> Language Class Initialized
INFO - 2016-09-22 23:55:49 --> Config Class Initialized
INFO - 2016-09-22 23:55:49 --> Loader Class Initialized
INFO - 2016-09-22 23:55:49 --> Helper loaded: url_helper
INFO - 2016-09-22 23:55:49 --> Database Driver Class Initialized
INFO - 2016-09-22 23:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 23:55:49 --> Controller Class Initialized
DEBUG - 2016-09-22 23:55:49 --> Login MX_Controller Initialized
INFO - 2016-09-22 23:55:49 --> Model Class Initialized
INFO - 2016-09-22 23:55:49 --> Model Class Initialized
DEBUG - 2016-09-22 23:55:49 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-22 23:55:49 --> Final output sent to browser
DEBUG - 2016-09-22 23:55:49 --> Total execution time: 0.0242
INFO - 2016-09-22 23:57:34 --> Config Class Initialized
INFO - 2016-09-22 23:57:34 --> Hooks Class Initialized
DEBUG - 2016-09-22 23:57:34 --> UTF-8 Support Enabled
INFO - 2016-09-22 23:57:34 --> Utf8 Class Initialized
INFO - 2016-09-22 23:57:34 --> URI Class Initialized
INFO - 2016-09-22 23:57:34 --> Router Class Initialized
INFO - 2016-09-22 23:57:34 --> Output Class Initialized
INFO - 2016-09-22 23:57:34 --> Security Class Initialized
DEBUG - 2016-09-22 23:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 23:57:34 --> Input Class Initialized
INFO - 2016-09-22 23:57:34 --> Language Class Initialized
ERROR - 2016-09-22 23:57:34 --> 404 Page Not Found: ../modules/admin/controllers//index
INFO - 2016-09-22 23:57:46 --> Config Class Initialized
INFO - 2016-09-22 23:57:46 --> Hooks Class Initialized
DEBUG - 2016-09-22 23:57:46 --> UTF-8 Support Enabled
INFO - 2016-09-22 23:57:46 --> Utf8 Class Initialized
INFO - 2016-09-22 23:57:46 --> URI Class Initialized
INFO - 2016-09-22 23:57:46 --> Router Class Initialized
INFO - 2016-09-22 23:57:46 --> Output Class Initialized
INFO - 2016-09-22 23:57:46 --> Security Class Initialized
DEBUG - 2016-09-22 23:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 23:57:46 --> Input Class Initialized
INFO - 2016-09-22 23:57:46 --> Language Class Initialized
ERROR - 2016-09-22 23:57:46 --> 404 Page Not Found: /index
INFO - 2016-09-22 23:58:03 --> Config Class Initialized
INFO - 2016-09-22 23:58:03 --> Hooks Class Initialized
DEBUG - 2016-09-22 23:58:03 --> UTF-8 Support Enabled
INFO - 2016-09-22 23:58:03 --> Utf8 Class Initialized
INFO - 2016-09-22 23:58:03 --> URI Class Initialized
INFO - 2016-09-22 23:58:03 --> Router Class Initialized
INFO - 2016-09-22 23:58:03 --> Output Class Initialized
INFO - 2016-09-22 23:58:03 --> Security Class Initialized
DEBUG - 2016-09-22 23:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 23:58:03 --> Input Class Initialized
INFO - 2016-09-22 23:58:03 --> Language Class Initialized
ERROR - 2016-09-22 23:58:03 --> 404 Page Not Found: ../modules/admin/controllers//index
INFO - 2016-09-22 23:59:14 --> Config Class Initialized
INFO - 2016-09-22 23:59:14 --> Hooks Class Initialized
DEBUG - 2016-09-22 23:59:14 --> UTF-8 Support Enabled
INFO - 2016-09-22 23:59:14 --> Utf8 Class Initialized
INFO - 2016-09-22 23:59:14 --> URI Class Initialized
INFO - 2016-09-22 23:59:14 --> Router Class Initialized
INFO - 2016-09-22 23:59:14 --> Output Class Initialized
INFO - 2016-09-22 23:59:14 --> Security Class Initialized
DEBUG - 2016-09-22 23:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 23:59:14 --> Input Class Initialized
INFO - 2016-09-22 23:59:14 --> Language Class Initialized
INFO - 2016-09-22 23:59:14 --> Language Class Initialized
INFO - 2016-09-22 23:59:14 --> Config Class Initialized
INFO - 2016-09-22 23:59:14 --> Loader Class Initialized
INFO - 2016-09-22 23:59:14 --> Helper loaded: url_helper
INFO - 2016-09-22 23:59:14 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 23:59:14 --> Controller Class Initialized
DEBUG - 2016-09-22 23:59:14 --> login MX_Controller Initialized
INFO - 2016-09-22 23:59:14 --> Model Class Initialized
INFO - 2016-09-22 23:59:14 --> Model Class Initialized
DEBUG - 2016-09-22 23:59:14 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-22 23:59:14 --> Final output sent to browser
DEBUG - 2016-09-22 23:59:14 --> Total execution time: 0.0220
INFO - 2016-09-22 23:59:21 --> Config Class Initialized
INFO - 2016-09-22 23:59:21 --> Hooks Class Initialized
DEBUG - 2016-09-22 23:59:21 --> UTF-8 Support Enabled
INFO - 2016-09-22 23:59:21 --> Utf8 Class Initialized
INFO - 2016-09-22 23:59:21 --> URI Class Initialized
INFO - 2016-09-22 23:59:21 --> Router Class Initialized
INFO - 2016-09-22 23:59:21 --> Output Class Initialized
INFO - 2016-09-22 23:59:21 --> Security Class Initialized
DEBUG - 2016-09-22 23:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 23:59:21 --> Input Class Initialized
INFO - 2016-09-22 23:59:21 --> Language Class Initialized
INFO - 2016-09-22 23:59:21 --> Language Class Initialized
INFO - 2016-09-22 23:59:21 --> Config Class Initialized
INFO - 2016-09-22 23:59:21 --> Loader Class Initialized
INFO - 2016-09-22 23:59:21 --> Helper loaded: url_helper
INFO - 2016-09-22 23:59:21 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 23:59:21 --> Controller Class Initialized
DEBUG - 2016-09-22 23:59:21 --> login MX_Controller Initialized
INFO - 2016-09-22 23:59:21 --> Model Class Initialized
INFO - 2016-09-22 23:59:21 --> Model Class Initialized
INFO - 2016-09-22 23:59:21 --> Final output sent to browser
DEBUG - 2016-09-22 23:59:21 --> Total execution time: 0.0255
INFO - 2016-09-22 23:59:22 --> Config Class Initialized
INFO - 2016-09-22 23:59:22 --> Hooks Class Initialized
DEBUG - 2016-09-22 23:59:22 --> UTF-8 Support Enabled
INFO - 2016-09-22 23:59:22 --> Utf8 Class Initialized
INFO - 2016-09-22 23:59:22 --> URI Class Initialized
INFO - 2016-09-22 23:59:22 --> Router Class Initialized
INFO - 2016-09-22 23:59:22 --> Output Class Initialized
INFO - 2016-09-22 23:59:22 --> Security Class Initialized
DEBUG - 2016-09-22 23:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 23:59:22 --> Input Class Initialized
INFO - 2016-09-22 23:59:22 --> Language Class Initialized
INFO - 2016-09-22 23:59:22 --> Language Class Initialized
INFO - 2016-09-22 23:59:22 --> Config Class Initialized
INFO - 2016-09-22 23:59:22 --> Loader Class Initialized
INFO - 2016-09-22 23:59:22 --> Helper loaded: url_helper
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 23:59:22 --> Controller Class Initialized
DEBUG - 2016-09-22 23:59:22 --> Index MX_Controller Initialized
INFO - 2016-09-22 23:59:22 --> Model Class Initialized
INFO - 2016-09-22 23:59:22 --> Model Class Initialized
DEBUG - 2016-09-22 23:59:22 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-22 23:59:22 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-22 23:59:22 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-22 23:59:22 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-22 23:59:22 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-22 23:59:22 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:22 --> Database Driver Class Initialized
DEBUG - 2016-09-22 23:59:22 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-22 23:59:22 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-22 23:59:22 --> Final output sent to browser
DEBUG - 2016-09-22 23:59:22 --> Total execution time: 0.0981
INFO - 2016-09-22 23:59:26 --> Config Class Initialized
INFO - 2016-09-22 23:59:26 --> Hooks Class Initialized
DEBUG - 2016-09-22 23:59:26 --> UTF-8 Support Enabled
INFO - 2016-09-22 23:59:26 --> Utf8 Class Initialized
INFO - 2016-09-22 23:59:26 --> URI Class Initialized
INFO - 2016-09-22 23:59:26 --> Router Class Initialized
INFO - 2016-09-22 23:59:26 --> Output Class Initialized
INFO - 2016-09-22 23:59:26 --> Security Class Initialized
DEBUG - 2016-09-22 23:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 23:59:26 --> Input Class Initialized
INFO - 2016-09-22 23:59:26 --> Language Class Initialized
ERROR - 2016-09-22 23:59:26 --> 404 Page Not Found: /index
INFO - 2016-09-22 23:59:27 --> Config Class Initialized
INFO - 2016-09-22 23:59:27 --> Hooks Class Initialized
DEBUG - 2016-09-22 23:59:27 --> UTF-8 Support Enabled
INFO - 2016-09-22 23:59:27 --> Utf8 Class Initialized
INFO - 2016-09-22 23:59:27 --> URI Class Initialized
INFO - 2016-09-22 23:59:27 --> Router Class Initialized
INFO - 2016-09-22 23:59:27 --> Output Class Initialized
INFO - 2016-09-22 23:59:27 --> Security Class Initialized
DEBUG - 2016-09-22 23:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 23:59:27 --> Input Class Initialized
INFO - 2016-09-22 23:59:27 --> Language Class Initialized
ERROR - 2016-09-22 23:59:27 --> 404 Page Not Found: /index
INFO - 2016-09-22 23:59:36 --> Config Class Initialized
INFO - 2016-09-22 23:59:36 --> Hooks Class Initialized
DEBUG - 2016-09-22 23:59:36 --> UTF-8 Support Enabled
INFO - 2016-09-22 23:59:36 --> Utf8 Class Initialized
INFO - 2016-09-22 23:59:36 --> URI Class Initialized
INFO - 2016-09-22 23:59:36 --> Router Class Initialized
INFO - 2016-09-22 23:59:36 --> Output Class Initialized
INFO - 2016-09-22 23:59:36 --> Security Class Initialized
DEBUG - 2016-09-22 23:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 23:59:36 --> Input Class Initialized
INFO - 2016-09-22 23:59:36 --> Language Class Initialized
INFO - 2016-09-22 23:59:36 --> Language Class Initialized
INFO - 2016-09-22 23:59:36 --> Config Class Initialized
INFO - 2016-09-22 23:59:36 --> Loader Class Initialized
INFO - 2016-09-22 23:59:36 --> Helper loaded: url_helper
INFO - 2016-09-22 23:59:36 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 23:59:36 --> Controller Class Initialized
DEBUG - 2016-09-22 23:59:36 --> Index MX_Controller Initialized
INFO - 2016-09-22 23:59:36 --> Model Class Initialized
INFO - 2016-09-22 23:59:36 --> Model Class Initialized
DEBUG - 2016-09-22 23:59:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-22 23:59:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-22 23:59:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-22 23:59:36 --> File already loaded: /home/koperasi/public_html/application/controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-22 23:59:36 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-22 23:59:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/list_anggota.php
DEBUG - 2016-09-22 23:59:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-22 23:59:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-22 23:59:36 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:36 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:36 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:36 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:36 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:36 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:36 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:36 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:36 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:36 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:36 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:36 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:36 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:36 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:37 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:37 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:37 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:37 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:37 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:37 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:37 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:37 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:37 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:37 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:37 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:37 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:37 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:37 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:37 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:37 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:37 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:37 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:37 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:37 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:37 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:37 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:37 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:37 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:37 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:37 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:37 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:37 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:37 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:37 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:37 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:37 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:37 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:37 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:37 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:37 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:37 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:37 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:37 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:37 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:37 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:37 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:37 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:37 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:37 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:37 --> Database Driver Class Initialized
DEBUG - 2016-09-22 23:59:37 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-22 23:59:37 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-22 23:59:37 --> Final output sent to browser
DEBUG - 2016-09-22 23:59:37 --> Total execution time: 0.1870
INFO - 2016-09-22 23:59:37 --> Config Class Initialized
INFO - 2016-09-22 23:59:37 --> Hooks Class Initialized
DEBUG - 2016-09-22 23:59:37 --> UTF-8 Support Enabled
INFO - 2016-09-22 23:59:37 --> Utf8 Class Initialized
INFO - 2016-09-22 23:59:37 --> URI Class Initialized
INFO - 2016-09-22 23:59:37 --> Router Class Initialized
INFO - 2016-09-22 23:59:37 --> Output Class Initialized
INFO - 2016-09-22 23:59:37 --> Security Class Initialized
DEBUG - 2016-09-22 23:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 23:59:37 --> Input Class Initialized
INFO - 2016-09-22 23:59:37 --> Language Class Initialized
ERROR - 2016-09-22 23:59:37 --> 404 Page Not Found: /index
INFO - 2016-09-22 23:59:39 --> Config Class Initialized
INFO - 2016-09-22 23:59:39 --> Hooks Class Initialized
DEBUG - 2016-09-22 23:59:39 --> UTF-8 Support Enabled
INFO - 2016-09-22 23:59:39 --> Utf8 Class Initialized
INFO - 2016-09-22 23:59:39 --> URI Class Initialized
INFO - 2016-09-22 23:59:39 --> Router Class Initialized
INFO - 2016-09-22 23:59:39 --> Output Class Initialized
INFO - 2016-09-22 23:59:39 --> Security Class Initialized
DEBUG - 2016-09-22 23:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 23:59:39 --> Input Class Initialized
INFO - 2016-09-22 23:59:39 --> Language Class Initialized
ERROR - 2016-09-22 23:59:39 --> 404 Page Not Found: /index
INFO - 2016-09-22 23:59:50 --> Config Class Initialized
INFO - 2016-09-22 23:59:50 --> Hooks Class Initialized
DEBUG - 2016-09-22 23:59:50 --> UTF-8 Support Enabled
INFO - 2016-09-22 23:59:50 --> Utf8 Class Initialized
INFO - 2016-09-22 23:59:50 --> URI Class Initialized
INFO - 2016-09-22 23:59:50 --> Router Class Initialized
INFO - 2016-09-22 23:59:50 --> Output Class Initialized
INFO - 2016-09-22 23:59:50 --> Security Class Initialized
DEBUG - 2016-09-22 23:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 23:59:50 --> Input Class Initialized
INFO - 2016-09-22 23:59:50 --> Language Class Initialized
INFO - 2016-09-22 23:59:50 --> Language Class Initialized
INFO - 2016-09-22 23:59:50 --> Config Class Initialized
INFO - 2016-09-22 23:59:50 --> Loader Class Initialized
INFO - 2016-09-22 23:59:50 --> Helper loaded: url_helper
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 23:59:50 --> Controller Class Initialized
DEBUG - 2016-09-22 23:59:50 --> Index MX_Controller Initialized
INFO - 2016-09-22 23:59:50 --> Model Class Initialized
INFO - 2016-09-22 23:59:50 --> Model Class Initialized
DEBUG - 2016-09-22 23:59:50 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-22 23:59:50 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-22 23:59:50 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-22 23:59:50 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/list_biaya.php
DEBUG - 2016-09-22 23:59:50 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-22 23:59:50 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:50 --> Database Driver Class Initialized
DEBUG - 2016-09-22 23:59:50 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-22 23:59:50 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-22 23:59:50 --> Final output sent to browser
DEBUG - 2016-09-22 23:59:50 --> Total execution time: 0.0992
INFO - 2016-09-22 23:59:50 --> Config Class Initialized
INFO - 2016-09-22 23:59:50 --> Hooks Class Initialized
DEBUG - 2016-09-22 23:59:50 --> UTF-8 Support Enabled
INFO - 2016-09-22 23:59:50 --> Utf8 Class Initialized
INFO - 2016-09-22 23:59:50 --> URI Class Initialized
INFO - 2016-09-22 23:59:50 --> Router Class Initialized
INFO - 2016-09-22 23:59:50 --> Output Class Initialized
INFO - 2016-09-22 23:59:50 --> Security Class Initialized
DEBUG - 2016-09-22 23:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 23:59:50 --> Input Class Initialized
INFO - 2016-09-22 23:59:50 --> Language Class Initialized
ERROR - 2016-09-22 23:59:50 --> 404 Page Not Found: /index
INFO - 2016-09-22 23:59:51 --> Config Class Initialized
INFO - 2016-09-22 23:59:51 --> Hooks Class Initialized
DEBUG - 2016-09-22 23:59:51 --> UTF-8 Support Enabled
INFO - 2016-09-22 23:59:51 --> Utf8 Class Initialized
INFO - 2016-09-22 23:59:51 --> URI Class Initialized
INFO - 2016-09-22 23:59:51 --> Router Class Initialized
INFO - 2016-09-22 23:59:51 --> Output Class Initialized
INFO - 2016-09-22 23:59:51 --> Security Class Initialized
DEBUG - 2016-09-22 23:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 23:59:51 --> Input Class Initialized
INFO - 2016-09-22 23:59:51 --> Language Class Initialized
ERROR - 2016-09-22 23:59:51 --> 404 Page Not Found: /index
INFO - 2016-09-22 23:59:57 --> Config Class Initialized
INFO - 2016-09-22 23:59:57 --> Hooks Class Initialized
DEBUG - 2016-09-22 23:59:57 --> UTF-8 Support Enabled
INFO - 2016-09-22 23:59:57 --> Utf8 Class Initialized
INFO - 2016-09-22 23:59:57 --> URI Class Initialized
INFO - 2016-09-22 23:59:57 --> Router Class Initialized
INFO - 2016-09-22 23:59:57 --> Output Class Initialized
INFO - 2016-09-22 23:59:57 --> Security Class Initialized
DEBUG - 2016-09-22 23:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 23:59:57 --> Input Class Initialized
INFO - 2016-09-22 23:59:57 --> Language Class Initialized
INFO - 2016-09-22 23:59:57 --> Language Class Initialized
INFO - 2016-09-22 23:59:57 --> Config Class Initialized
INFO - 2016-09-22 23:59:57 --> Loader Class Initialized
INFO - 2016-09-22 23:59:57 --> Helper loaded: url_helper
INFO - 2016-09-22 23:59:57 --> Database Driver Class Initialized
INFO - 2016-09-22 23:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 23:59:57 --> Controller Class Initialized
DEBUG - 2016-09-22 23:59:57 --> Index MX_Controller Initialized
INFO - 2016-09-22 23:59:57 --> Model Class Initialized
INFO - 2016-09-22 23:59:57 --> Model Class Initialized
DEBUG - 2016-09-22 23:59:57 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-22 23:59:57 --> Users MX_Controller Initialized
INFO - 2016-09-22 23:59:57 --> Final output sent to browser
DEBUG - 2016-09-22 23:59:57 --> Total execution time: 0.0341
