<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-09-23 00:00:05 --> Config Class Initialized
INFO - 2016-09-23 00:00:05 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:00:05 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:00:05 --> Utf8 Class Initialized
INFO - 2016-09-23 00:00:05 --> URI Class Initialized
INFO - 2016-09-23 00:00:05 --> Router Class Initialized
INFO - 2016-09-23 00:00:05 --> Output Class Initialized
INFO - 2016-09-23 00:00:05 --> Security Class Initialized
DEBUG - 2016-09-23 00:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:00:05 --> Input Class Initialized
INFO - 2016-09-23 00:00:05 --> Language Class Initialized
INFO - 2016-09-23 00:00:05 --> Language Class Initialized
INFO - 2016-09-23 00:00:05 --> Config Class Initialized
INFO - 2016-09-23 00:00:05 --> Loader Class Initialized
INFO - 2016-09-23 00:00:05 --> Helper loaded: url_helper
INFO - 2016-09-23 00:00:05 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:00:05 --> Controller Class Initialized
DEBUG - 2016-09-23 00:00:05 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:00:05 --> Model Class Initialized
INFO - 2016-09-23 00:00:05 --> Model Class Initialized
DEBUG - 2016-09-23 00:00:05 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-23 00:00:05 --> Users MX_Controller Initialized
INFO - 2016-09-23 00:00:05 --> Final output sent to browser
DEBUG - 2016-09-23 00:00:05 --> Total execution time: 0.0450
INFO - 2016-09-23 00:00:07 --> Config Class Initialized
INFO - 2016-09-23 00:00:07 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:00:07 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:00:07 --> Utf8 Class Initialized
INFO - 2016-09-23 00:00:07 --> URI Class Initialized
INFO - 2016-09-23 00:00:07 --> Router Class Initialized
INFO - 2016-09-23 00:00:07 --> Output Class Initialized
INFO - 2016-09-23 00:00:07 --> Security Class Initialized
DEBUG - 2016-09-23 00:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:00:07 --> Input Class Initialized
INFO - 2016-09-23 00:00:07 --> Language Class Initialized
INFO - 2016-09-23 00:00:07 --> Language Class Initialized
INFO - 2016-09-23 00:00:07 --> Config Class Initialized
INFO - 2016-09-23 00:00:07 --> Loader Class Initialized
INFO - 2016-09-23 00:00:07 --> Helper loaded: url_helper
INFO - 2016-09-23 00:00:07 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:00:07 --> Controller Class Initialized
DEBUG - 2016-09-23 00:00:07 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:00:07 --> Model Class Initialized
INFO - 2016-09-23 00:00:07 --> Model Class Initialized
DEBUG - 2016-09-23 00:00:07 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-23 00:00:11 --> Users MX_Controller Initialized
INFO - 2016-09-23 00:00:11 --> Config Class Initialized
INFO - 2016-09-23 00:00:11 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:00:11 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:00:11 --> Utf8 Class Initialized
INFO - 2016-09-23 00:00:11 --> URI Class Initialized
INFO - 2016-09-23 00:00:11 --> Final output sent to browser
DEBUG - 2016-09-23 00:00:11 --> Total execution time: 3.8574
INFO - 2016-09-23 00:00:11 --> Router Class Initialized
INFO - 2016-09-23 00:00:11 --> Output Class Initialized
INFO - 2016-09-23 00:00:11 --> Security Class Initialized
DEBUG - 2016-09-23 00:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:00:11 --> Input Class Initialized
INFO - 2016-09-23 00:00:11 --> Language Class Initialized
INFO - 2016-09-23 00:00:11 --> Language Class Initialized
INFO - 2016-09-23 00:00:11 --> Config Class Initialized
INFO - 2016-09-23 00:00:11 --> Loader Class Initialized
INFO - 2016-09-23 00:00:11 --> Helper loaded: url_helper
INFO - 2016-09-23 00:00:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:00:11 --> Controller Class Initialized
DEBUG - 2016-09-23 00:00:11 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:00:11 --> Model Class Initialized
INFO - 2016-09-23 00:00:11 --> Model Class Initialized
DEBUG - 2016-09-23 00:00:11 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-23 00:00:11 --> Users MX_Controller Initialized
INFO - 2016-09-23 00:00:11 --> Final output sent to browser
DEBUG - 2016-09-23 00:00:11 --> Total execution time: 0.7905
INFO - 2016-09-23 00:00:13 --> Config Class Initialized
INFO - 2016-09-23 00:00:13 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:00:13 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:00:13 --> Utf8 Class Initialized
INFO - 2016-09-23 00:00:13 --> URI Class Initialized
INFO - 2016-09-23 00:00:13 --> Router Class Initialized
INFO - 2016-09-23 00:00:13 --> Output Class Initialized
INFO - 2016-09-23 00:00:13 --> Security Class Initialized
DEBUG - 2016-09-23 00:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:00:13 --> Input Class Initialized
INFO - 2016-09-23 00:00:13 --> Language Class Initialized
INFO - 2016-09-23 00:00:13 --> Language Class Initialized
INFO - 2016-09-23 00:00:13 --> Config Class Initialized
INFO - 2016-09-23 00:00:13 --> Loader Class Initialized
INFO - 2016-09-23 00:00:14 --> Helper loaded: url_helper
INFO - 2016-09-23 00:00:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:00:14 --> Controller Class Initialized
DEBUG - 2016-09-23 00:00:14 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:00:14 --> Model Class Initialized
INFO - 2016-09-23 00:00:14 --> Model Class Initialized
DEBUG - 2016-09-23 00:00:14 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-23 00:00:14 --> Users MX_Controller Initialized
INFO - 2016-09-23 00:00:14 --> Final output sent to browser
DEBUG - 2016-09-23 00:00:14 --> Total execution time: 0.7231
INFO - 2016-09-23 00:00:15 --> Config Class Initialized
INFO - 2016-09-23 00:00:15 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:00:15 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:00:15 --> Utf8 Class Initialized
INFO - 2016-09-23 00:00:15 --> URI Class Initialized
INFO - 2016-09-23 00:00:15 --> Router Class Initialized
INFO - 2016-09-23 00:00:15 --> Output Class Initialized
INFO - 2016-09-23 00:00:15 --> Security Class Initialized
DEBUG - 2016-09-23 00:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:00:15 --> Input Class Initialized
INFO - 2016-09-23 00:00:15 --> Language Class Initialized
INFO - 2016-09-23 00:00:15 --> Language Class Initialized
INFO - 2016-09-23 00:00:15 --> Config Class Initialized
INFO - 2016-09-23 00:00:15 --> Loader Class Initialized
INFO - 2016-09-23 00:00:15 --> Helper loaded: url_helper
INFO - 2016-09-23 00:00:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:00:15 --> Controller Class Initialized
DEBUG - 2016-09-23 00:00:15 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:00:15 --> Model Class Initialized
INFO - 2016-09-23 00:00:15 --> Model Class Initialized
DEBUG - 2016-09-23 00:00:15 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-23 00:00:15 --> Users MX_Controller Initialized
INFO - 2016-09-23 00:00:15 --> Final output sent to browser
DEBUG - 2016-09-23 00:00:15 --> Total execution time: 0.0667
INFO - 2016-09-23 00:00:16 --> Config Class Initialized
INFO - 2016-09-23 00:00:16 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:00:16 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:00:16 --> Utf8 Class Initialized
INFO - 2016-09-23 00:00:16 --> URI Class Initialized
INFO - 2016-09-23 00:00:16 --> Router Class Initialized
INFO - 2016-09-23 00:00:16 --> Output Class Initialized
INFO - 2016-09-23 00:00:16 --> Security Class Initialized
DEBUG - 2016-09-23 00:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:00:16 --> Input Class Initialized
INFO - 2016-09-23 00:00:16 --> Language Class Initialized
INFO - 2016-09-23 00:00:16 --> Language Class Initialized
INFO - 2016-09-23 00:00:16 --> Config Class Initialized
INFO - 2016-09-23 00:00:16 --> Loader Class Initialized
INFO - 2016-09-23 00:00:16 --> Helper loaded: url_helper
INFO - 2016-09-23 00:00:17 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:00:17 --> Controller Class Initialized
DEBUG - 2016-09-23 00:00:17 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:00:17 --> Model Class Initialized
INFO - 2016-09-23 00:00:17 --> Model Class Initialized
DEBUG - 2016-09-23 00:00:17 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-23 00:00:17 --> Users MX_Controller Initialized
INFO - 2016-09-23 00:00:17 --> Final output sent to browser
DEBUG - 2016-09-23 00:00:17 --> Total execution time: 0.3823
INFO - 2016-09-23 00:00:18 --> Config Class Initialized
INFO - 2016-09-23 00:00:18 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:00:18 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:00:18 --> Utf8 Class Initialized
INFO - 2016-09-23 00:00:18 --> URI Class Initialized
INFO - 2016-09-23 00:00:19 --> Router Class Initialized
INFO - 2016-09-23 00:00:19 --> Output Class Initialized
INFO - 2016-09-23 00:00:19 --> Security Class Initialized
DEBUG - 2016-09-23 00:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:00:19 --> Input Class Initialized
INFO - 2016-09-23 00:00:19 --> Language Class Initialized
INFO - 2016-09-23 00:00:19 --> Language Class Initialized
INFO - 2016-09-23 00:00:19 --> Config Class Initialized
INFO - 2016-09-23 00:00:19 --> Loader Class Initialized
INFO - 2016-09-23 00:00:19 --> Helper loaded: url_helper
INFO - 2016-09-23 00:00:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:00:19 --> Controller Class Initialized
DEBUG - 2016-09-23 00:00:19 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:00:19 --> Model Class Initialized
INFO - 2016-09-23 00:00:19 --> Model Class Initialized
DEBUG - 2016-09-23 00:00:19 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-23 00:00:19 --> Users MX_Controller Initialized
INFO - 2016-09-23 00:00:19 --> Final output sent to browser
DEBUG - 2016-09-23 00:00:19 --> Total execution time: 0.8158
INFO - 2016-09-23 00:00:20 --> Config Class Initialized
INFO - 2016-09-23 00:00:20 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:00:20 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:00:20 --> Utf8 Class Initialized
INFO - 2016-09-23 00:00:20 --> URI Class Initialized
INFO - 2016-09-23 00:00:21 --> Router Class Initialized
INFO - 2016-09-23 00:00:21 --> Output Class Initialized
INFO - 2016-09-23 00:00:21 --> Security Class Initialized
DEBUG - 2016-09-23 00:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:00:21 --> Input Class Initialized
INFO - 2016-09-23 00:00:21 --> Language Class Initialized
INFO - 2016-09-23 00:00:21 --> Language Class Initialized
INFO - 2016-09-23 00:00:21 --> Config Class Initialized
INFO - 2016-09-23 00:00:21 --> Loader Class Initialized
INFO - 2016-09-23 00:00:21 --> Helper loaded: url_helper
INFO - 2016-09-23 00:00:22 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:00:22 --> Controller Class Initialized
DEBUG - 2016-09-23 00:00:22 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:00:22 --> Model Class Initialized
INFO - 2016-09-23 00:00:22 --> Model Class Initialized
DEBUG - 2016-09-23 00:00:22 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-23 00:00:22 --> Users MX_Controller Initialized
INFO - 2016-09-23 00:00:22 --> Final output sent to browser
DEBUG - 2016-09-23 00:00:22 --> Total execution time: 1.4302
INFO - 2016-09-23 00:00:26 --> Config Class Initialized
INFO - 2016-09-23 00:00:26 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:00:26 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:00:26 --> Utf8 Class Initialized
INFO - 2016-09-23 00:00:26 --> URI Class Initialized
INFO - 2016-09-23 00:00:26 --> Router Class Initialized
INFO - 2016-09-23 00:00:26 --> Output Class Initialized
INFO - 2016-09-23 00:00:26 --> Security Class Initialized
DEBUG - 2016-09-23 00:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:00:26 --> Input Class Initialized
INFO - 2016-09-23 00:00:26 --> Language Class Initialized
INFO - 2016-09-23 00:00:26 --> Language Class Initialized
INFO - 2016-09-23 00:00:26 --> Config Class Initialized
INFO - 2016-09-23 00:00:26 --> Loader Class Initialized
INFO - 2016-09-23 00:00:26 --> Helper loaded: url_helper
INFO - 2016-09-23 00:00:26 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:00:26 --> Controller Class Initialized
DEBUG - 2016-09-23 00:00:26 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:00:26 --> Model Class Initialized
INFO - 2016-09-23 00:00:26 --> Model Class Initialized
DEBUG - 2016-09-23 00:00:26 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-23 00:00:26 --> Users MX_Controller Initialized
INFO - 2016-09-23 00:00:26 --> Final output sent to browser
DEBUG - 2016-09-23 00:00:26 --> Total execution time: 0.4406
INFO - 2016-09-23 00:00:29 --> Config Class Initialized
INFO - 2016-09-23 00:00:29 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:00:29 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:00:29 --> Utf8 Class Initialized
INFO - 2016-09-23 00:00:29 --> URI Class Initialized
INFO - 2016-09-23 00:00:29 --> Router Class Initialized
INFO - 2016-09-23 00:00:29 --> Output Class Initialized
INFO - 2016-09-23 00:00:29 --> Security Class Initialized
DEBUG - 2016-09-23 00:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:00:29 --> Input Class Initialized
INFO - 2016-09-23 00:00:29 --> Language Class Initialized
INFO - 2016-09-23 00:00:29 --> Language Class Initialized
INFO - 2016-09-23 00:00:29 --> Config Class Initialized
INFO - 2016-09-23 00:00:29 --> Loader Class Initialized
INFO - 2016-09-23 00:00:29 --> Helper loaded: url_helper
INFO - 2016-09-23 00:00:29 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:00:29 --> Controller Class Initialized
DEBUG - 2016-09-23 00:00:29 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:00:29 --> Model Class Initialized
INFO - 2016-09-23 00:00:29 --> Model Class Initialized
DEBUG - 2016-09-23 00:00:29 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-23 00:00:29 --> Users MX_Controller Initialized
INFO - 2016-09-23 00:00:29 --> Final output sent to browser
DEBUG - 2016-09-23 00:00:29 --> Total execution time: 0.0533
INFO - 2016-09-23 00:00:31 --> Config Class Initialized
INFO - 2016-09-23 00:00:31 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:00:31 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:00:31 --> Utf8 Class Initialized
INFO - 2016-09-23 00:00:31 --> URI Class Initialized
INFO - 2016-09-23 00:00:31 --> Router Class Initialized
INFO - 2016-09-23 00:00:31 --> Output Class Initialized
INFO - 2016-09-23 00:00:31 --> Security Class Initialized
DEBUG - 2016-09-23 00:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:00:31 --> Input Class Initialized
INFO - 2016-09-23 00:00:31 --> Language Class Initialized
INFO - 2016-09-23 00:00:31 --> Language Class Initialized
INFO - 2016-09-23 00:00:31 --> Config Class Initialized
INFO - 2016-09-23 00:00:31 --> Loader Class Initialized
INFO - 2016-09-23 00:00:32 --> Helper loaded: url_helper
INFO - 2016-09-23 00:00:32 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:00:32 --> Controller Class Initialized
DEBUG - 2016-09-23 00:00:32 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:00:32 --> Model Class Initialized
INFO - 2016-09-23 00:00:32 --> Model Class Initialized
DEBUG - 2016-09-23 00:00:32 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-23 00:00:32 --> Users MX_Controller Initialized
INFO - 2016-09-23 00:00:32 --> Final output sent to browser
DEBUG - 2016-09-23 00:00:32 --> Total execution time: 0.8915
INFO - 2016-09-23 00:00:33 --> Config Class Initialized
INFO - 2016-09-23 00:00:33 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:00:33 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:00:33 --> Utf8 Class Initialized
INFO - 2016-09-23 00:00:33 --> URI Class Initialized
INFO - 2016-09-23 00:00:33 --> Router Class Initialized
INFO - 2016-09-23 00:00:33 --> Output Class Initialized
INFO - 2016-09-23 00:00:33 --> Security Class Initialized
DEBUG - 2016-09-23 00:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:00:33 --> Input Class Initialized
INFO - 2016-09-23 00:00:33 --> Language Class Initialized
INFO - 2016-09-23 00:00:33 --> Language Class Initialized
INFO - 2016-09-23 00:00:33 --> Config Class Initialized
INFO - 2016-09-23 00:00:33 --> Loader Class Initialized
INFO - 2016-09-23 00:00:33 --> Helper loaded: url_helper
INFO - 2016-09-23 00:00:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:00:33 --> Controller Class Initialized
DEBUG - 2016-09-23 00:00:33 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:00:33 --> Model Class Initialized
INFO - 2016-09-23 00:00:33 --> Model Class Initialized
DEBUG - 2016-09-23 00:00:33 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-23 00:00:33 --> Users MX_Controller Initialized
INFO - 2016-09-23 00:00:33 --> Final output sent to browser
DEBUG - 2016-09-23 00:00:33 --> Total execution time: 0.0482
INFO - 2016-09-23 00:00:35 --> Config Class Initialized
INFO - 2016-09-23 00:00:35 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:00:35 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:00:35 --> Utf8 Class Initialized
INFO - 2016-09-23 00:00:35 --> URI Class Initialized
INFO - 2016-09-23 00:00:35 --> Router Class Initialized
INFO - 2016-09-23 00:00:35 --> Output Class Initialized
INFO - 2016-09-23 00:00:35 --> Security Class Initialized
DEBUG - 2016-09-23 00:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:00:35 --> Input Class Initialized
INFO - 2016-09-23 00:00:35 --> Language Class Initialized
INFO - 2016-09-23 00:00:35 --> Language Class Initialized
INFO - 2016-09-23 00:00:35 --> Config Class Initialized
INFO - 2016-09-23 00:00:35 --> Loader Class Initialized
INFO - 2016-09-23 00:00:35 --> Helper loaded: url_helper
INFO - 2016-09-23 00:00:35 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:00:35 --> Controller Class Initialized
DEBUG - 2016-09-23 00:00:35 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:00:35 --> Model Class Initialized
INFO - 2016-09-23 00:00:35 --> Model Class Initialized
DEBUG - 2016-09-23 00:00:35 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-23 00:00:35 --> Users MX_Controller Initialized
INFO - 2016-09-23 00:00:35 --> Final output sent to browser
DEBUG - 2016-09-23 00:00:35 --> Total execution time: 0.0402
INFO - 2016-09-23 00:00:38 --> Config Class Initialized
INFO - 2016-09-23 00:00:38 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:00:38 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:00:38 --> Utf8 Class Initialized
INFO - 2016-09-23 00:00:38 --> URI Class Initialized
INFO - 2016-09-23 00:00:38 --> Router Class Initialized
INFO - 2016-09-23 00:00:38 --> Output Class Initialized
INFO - 2016-09-23 00:00:38 --> Security Class Initialized
DEBUG - 2016-09-23 00:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:00:38 --> Input Class Initialized
INFO - 2016-09-23 00:00:38 --> Language Class Initialized
INFO - 2016-09-23 00:00:38 --> Language Class Initialized
INFO - 2016-09-23 00:00:38 --> Config Class Initialized
INFO - 2016-09-23 00:00:38 --> Loader Class Initialized
INFO - 2016-09-23 00:00:38 --> Helper loaded: url_helper
INFO - 2016-09-23 00:00:38 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:00:38 --> Controller Class Initialized
DEBUG - 2016-09-23 00:00:38 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:00:38 --> Model Class Initialized
INFO - 2016-09-23 00:00:38 --> Model Class Initialized
DEBUG - 2016-09-23 00:00:38 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-23 00:00:38 --> Users MX_Controller Initialized
INFO - 2016-09-23 00:00:38 --> Final output sent to browser
DEBUG - 2016-09-23 00:00:38 --> Total execution time: 0.0383
INFO - 2016-09-23 00:00:52 --> Config Class Initialized
INFO - 2016-09-23 00:00:52 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:00:52 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:00:52 --> Utf8 Class Initialized
INFO - 2016-09-23 00:00:52 --> URI Class Initialized
INFO - 2016-09-23 00:00:52 --> Router Class Initialized
INFO - 2016-09-23 00:00:52 --> Output Class Initialized
INFO - 2016-09-23 00:00:52 --> Security Class Initialized
DEBUG - 2016-09-23 00:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:00:52 --> Input Class Initialized
INFO - 2016-09-23 00:00:52 --> Language Class Initialized
INFO - 2016-09-23 00:00:52 --> Language Class Initialized
INFO - 2016-09-23 00:00:52 --> Config Class Initialized
INFO - 2016-09-23 00:00:52 --> Loader Class Initialized
INFO - 2016-09-23 00:00:52 --> Helper loaded: url_helper
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:00:52 --> Controller Class Initialized
DEBUG - 2016-09-23 00:00:52 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:00:52 --> Model Class Initialized
INFO - 2016-09-23 00:00:52 --> Model Class Initialized
DEBUG - 2016-09-23 00:00:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-23 00:00:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-23 00:00:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-23 00:00:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-23 00:00:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-23 00:00:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 00:00:52 --> Database Driver Class Initialized
DEBUG - 2016-09-23 00:00:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-23 00:00:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-23 00:00:52 --> Final output sent to browser
DEBUG - 2016-09-23 00:00:52 --> Total execution time: 0.0999
INFO - 2016-09-23 00:00:53 --> Config Class Initialized
INFO - 2016-09-23 00:00:53 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:00:53 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:00:53 --> Utf8 Class Initialized
INFO - 2016-09-23 00:00:53 --> URI Class Initialized
INFO - 2016-09-23 00:00:53 --> Router Class Initialized
INFO - 2016-09-23 00:00:53 --> Output Class Initialized
INFO - 2016-09-23 00:00:53 --> Security Class Initialized
DEBUG - 2016-09-23 00:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:00:53 --> Input Class Initialized
INFO - 2016-09-23 00:00:53 --> Language Class Initialized
ERROR - 2016-09-23 00:00:53 --> 404 Page Not Found: /index
INFO - 2016-09-23 00:00:54 --> Config Class Initialized
INFO - 2016-09-23 00:00:54 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:00:54 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:00:54 --> Utf8 Class Initialized
INFO - 2016-09-23 00:00:54 --> URI Class Initialized
INFO - 2016-09-23 00:00:54 --> Router Class Initialized
INFO - 2016-09-23 00:00:54 --> Output Class Initialized
INFO - 2016-09-23 00:00:54 --> Security Class Initialized
DEBUG - 2016-09-23 00:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:00:54 --> Input Class Initialized
INFO - 2016-09-23 00:00:54 --> Language Class Initialized
ERROR - 2016-09-23 00:00:54 --> 404 Page Not Found: /index
INFO - 2016-09-23 00:01:01 --> Config Class Initialized
INFO - 2016-09-23 00:01:01 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:01:01 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:01:01 --> Utf8 Class Initialized
INFO - 2016-09-23 00:01:01 --> URI Class Initialized
INFO - 2016-09-23 00:01:01 --> Router Class Initialized
INFO - 2016-09-23 00:01:01 --> Output Class Initialized
INFO - 2016-09-23 00:01:01 --> Security Class Initialized
DEBUG - 2016-09-23 00:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:01:01 --> Input Class Initialized
INFO - 2016-09-23 00:01:01 --> Language Class Initialized
INFO - 2016-09-23 00:01:01 --> Language Class Initialized
INFO - 2016-09-23 00:01:01 --> Config Class Initialized
INFO - 2016-09-23 00:01:01 --> Loader Class Initialized
INFO - 2016-09-23 00:01:01 --> Helper loaded: url_helper
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:01:01 --> Controller Class Initialized
DEBUG - 2016-09-23 00:01:01 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:01:01 --> Model Class Initialized
INFO - 2016-09-23 00:01:01 --> Model Class Initialized
DEBUG - 2016-09-23 00:01:01 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-23 00:01:01 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-23 00:01:01 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-23 00:01:01 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/laporan/pinjaman.php
DEBUG - 2016-09-23 00:01:01 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-23 00:01:01 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:01 --> Database Driver Class Initialized
DEBUG - 2016-09-23 00:01:01 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-23 00:01:01 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-23 00:01:01 --> Final output sent to browser
DEBUG - 2016-09-23 00:01:01 --> Total execution time: 0.1581
INFO - 2016-09-23 00:01:02 --> Config Class Initialized
INFO - 2016-09-23 00:01:02 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:01:02 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:01:02 --> Utf8 Class Initialized
INFO - 2016-09-23 00:01:02 --> URI Class Initialized
INFO - 2016-09-23 00:01:02 --> Router Class Initialized
INFO - 2016-09-23 00:01:02 --> Output Class Initialized
INFO - 2016-09-23 00:01:02 --> Security Class Initialized
DEBUG - 2016-09-23 00:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:01:02 --> Input Class Initialized
INFO - 2016-09-23 00:01:02 --> Language Class Initialized
ERROR - 2016-09-23 00:01:02 --> 404 Page Not Found: /index
INFO - 2016-09-23 00:01:03 --> Config Class Initialized
INFO - 2016-09-23 00:01:03 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:01:03 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:01:03 --> Utf8 Class Initialized
INFO - 2016-09-23 00:01:03 --> URI Class Initialized
INFO - 2016-09-23 00:01:03 --> Router Class Initialized
INFO - 2016-09-23 00:01:03 --> Output Class Initialized
INFO - 2016-09-23 00:01:03 --> Security Class Initialized
DEBUG - 2016-09-23 00:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:01:03 --> Input Class Initialized
INFO - 2016-09-23 00:01:03 --> Language Class Initialized
ERROR - 2016-09-23 00:01:03 --> 404 Page Not Found: /index
INFO - 2016-09-23 00:01:09 --> Config Class Initialized
INFO - 2016-09-23 00:01:09 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:01:09 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:01:09 --> Utf8 Class Initialized
INFO - 2016-09-23 00:01:09 --> URI Class Initialized
INFO - 2016-09-23 00:01:09 --> Router Class Initialized
INFO - 2016-09-23 00:01:09 --> Output Class Initialized
INFO - 2016-09-23 00:01:09 --> Security Class Initialized
DEBUG - 2016-09-23 00:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:01:09 --> Input Class Initialized
INFO - 2016-09-23 00:01:09 --> Language Class Initialized
INFO - 2016-09-23 00:01:09 --> Language Class Initialized
INFO - 2016-09-23 00:01:09 --> Config Class Initialized
INFO - 2016-09-23 00:01:09 --> Loader Class Initialized
INFO - 2016-09-23 00:01:09 --> Helper loaded: url_helper
INFO - 2016-09-23 00:01:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:01:09 --> Controller Class Initialized
DEBUG - 2016-09-23 00:01:09 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:01:09 --> Model Class Initialized
INFO - 2016-09-23 00:01:09 --> Model Class Initialized
DEBUG - 2016-09-23 00:01:09 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/laporan/data_pinjaman.php
INFO - 2016-09-23 00:01:09 --> Final output sent to browser
DEBUG - 2016-09-23 00:01:09 --> Total execution time: 0.0540
INFO - 2016-09-23 00:01:15 --> Config Class Initialized
INFO - 2016-09-23 00:01:15 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:01:15 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:01:15 --> Utf8 Class Initialized
INFO - 2016-09-23 00:01:15 --> URI Class Initialized
INFO - 2016-09-23 00:01:15 --> Router Class Initialized
INFO - 2016-09-23 00:01:15 --> Output Class Initialized
INFO - 2016-09-23 00:01:15 --> Security Class Initialized
DEBUG - 2016-09-23 00:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:01:15 --> Input Class Initialized
INFO - 2016-09-23 00:01:15 --> Language Class Initialized
INFO - 2016-09-23 00:01:15 --> Language Class Initialized
INFO - 2016-09-23 00:01:15 --> Config Class Initialized
INFO - 2016-09-23 00:01:15 --> Loader Class Initialized
INFO - 2016-09-23 00:01:15 --> Helper loaded: url_helper
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:01:15 --> Controller Class Initialized
DEBUG - 2016-09-23 00:01:15 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:01:15 --> Model Class Initialized
INFO - 2016-09-23 00:01:15 --> Model Class Initialized
DEBUG - 2016-09-23 00:01:15 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-23 00:01:15 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-23 00:01:15 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-23 00:01:15 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/upload_foto.php
DEBUG - 2016-09-23 00:01:15 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-23 00:01:15 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:15 --> Database Driver Class Initialized
DEBUG - 2016-09-23 00:01:15 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-23 00:01:15 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-23 00:01:15 --> Final output sent to browser
DEBUG - 2016-09-23 00:01:15 --> Total execution time: 0.1123
INFO - 2016-09-23 00:01:16 --> Config Class Initialized
INFO - 2016-09-23 00:01:16 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:01:16 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:01:16 --> Utf8 Class Initialized
INFO - 2016-09-23 00:01:16 --> URI Class Initialized
INFO - 2016-09-23 00:01:16 --> Router Class Initialized
INFO - 2016-09-23 00:01:16 --> Output Class Initialized
INFO - 2016-09-23 00:01:16 --> Security Class Initialized
DEBUG - 2016-09-23 00:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:01:16 --> Input Class Initialized
INFO - 2016-09-23 00:01:16 --> Language Class Initialized
ERROR - 2016-09-23 00:01:16 --> 404 Page Not Found: /index
INFO - 2016-09-23 00:01:17 --> Config Class Initialized
INFO - 2016-09-23 00:01:17 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:01:17 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:01:17 --> Utf8 Class Initialized
INFO - 2016-09-23 00:01:17 --> URI Class Initialized
INFO - 2016-09-23 00:01:17 --> Router Class Initialized
INFO - 2016-09-23 00:01:17 --> Output Class Initialized
INFO - 2016-09-23 00:01:17 --> Security Class Initialized
DEBUG - 2016-09-23 00:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:01:17 --> Input Class Initialized
INFO - 2016-09-23 00:01:17 --> Language Class Initialized
ERROR - 2016-09-23 00:01:17 --> 404 Page Not Found: /index
INFO - 2016-09-23 00:01:35 --> Config Class Initialized
INFO - 2016-09-23 00:01:35 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:01:35 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:01:35 --> Utf8 Class Initialized
INFO - 2016-09-23 00:01:35 --> URI Class Initialized
INFO - 2016-09-23 00:01:35 --> Router Class Initialized
INFO - 2016-09-23 00:01:35 --> Output Class Initialized
INFO - 2016-09-23 00:01:35 --> Security Class Initialized
DEBUG - 2016-09-23 00:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:01:35 --> Input Class Initialized
INFO - 2016-09-23 00:01:35 --> Language Class Initialized
INFO - 2016-09-23 00:01:35 --> Language Class Initialized
INFO - 2016-09-23 00:01:35 --> Config Class Initialized
INFO - 2016-09-23 00:01:35 --> Loader Class Initialized
INFO - 2016-09-23 00:01:35 --> Helper loaded: url_helper
INFO - 2016-09-23 00:01:35 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:01:35 --> Controller Class Initialized
DEBUG - 2016-09-23 00:01:35 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:01:35 --> Model Class Initialized
INFO - 2016-09-23 00:01:35 --> Model Class Initialized
INFO - 2016-09-23 00:01:35 --> Upload Class Initialized
INFO - 2016-09-23 00:01:35 --> Final output sent to browser
DEBUG - 2016-09-23 00:01:35 --> Total execution time: 0.0744
INFO - 2016-09-23 00:01:41 --> Config Class Initialized
INFO - 2016-09-23 00:01:41 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:01:41 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:01:41 --> Utf8 Class Initialized
INFO - 2016-09-23 00:01:41 --> URI Class Initialized
INFO - 2016-09-23 00:01:41 --> Router Class Initialized
INFO - 2016-09-23 00:01:41 --> Output Class Initialized
INFO - 2016-09-23 00:01:41 --> Security Class Initialized
DEBUG - 2016-09-23 00:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:01:41 --> Input Class Initialized
INFO - 2016-09-23 00:01:41 --> Language Class Initialized
INFO - 2016-09-23 00:01:41 --> Language Class Initialized
INFO - 2016-09-23 00:01:41 --> Config Class Initialized
INFO - 2016-09-23 00:01:41 --> Loader Class Initialized
INFO - 2016-09-23 00:01:41 --> Helper loaded: url_helper
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:01:41 --> Controller Class Initialized
DEBUG - 2016-09-23 00:01:41 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:01:41 --> Model Class Initialized
INFO - 2016-09-23 00:01:41 --> Model Class Initialized
DEBUG - 2016-09-23 00:01:41 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-23 00:01:41 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-23 00:01:41 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-23 00:01:41 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-23 00:01:41 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-23 00:01:41 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:01:41 --> Database Driver Class Initialized
DEBUG - 2016-09-23 00:01:41 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-23 00:01:41 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-23 00:01:41 --> Final output sent to browser
DEBUG - 2016-09-23 00:01:41 --> Total execution time: 0.0827
INFO - 2016-09-23 00:01:41 --> Config Class Initialized
INFO - 2016-09-23 00:01:41 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:01:41 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:01:41 --> Utf8 Class Initialized
INFO - 2016-09-23 00:01:41 --> URI Class Initialized
INFO - 2016-09-23 00:01:41 --> Router Class Initialized
INFO - 2016-09-23 00:01:41 --> Output Class Initialized
INFO - 2016-09-23 00:01:41 --> Security Class Initialized
DEBUG - 2016-09-23 00:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:01:41 --> Input Class Initialized
INFO - 2016-09-23 00:01:41 --> Language Class Initialized
ERROR - 2016-09-23 00:01:41 --> 404 Page Not Found: /index
INFO - 2016-09-23 00:01:42 --> Config Class Initialized
INFO - 2016-09-23 00:01:42 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:01:42 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:01:42 --> Utf8 Class Initialized
INFO - 2016-09-23 00:01:42 --> URI Class Initialized
INFO - 2016-09-23 00:01:42 --> Router Class Initialized
INFO - 2016-09-23 00:01:42 --> Output Class Initialized
INFO - 2016-09-23 00:01:42 --> Security Class Initialized
DEBUG - 2016-09-23 00:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:01:42 --> Input Class Initialized
INFO - 2016-09-23 00:01:42 --> Language Class Initialized
ERROR - 2016-09-23 00:01:42 --> 404 Page Not Found: /index
INFO - 2016-09-23 00:03:18 --> Config Class Initialized
INFO - 2016-09-23 00:03:18 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:03:18 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:03:18 --> Utf8 Class Initialized
INFO - 2016-09-23 00:03:18 --> URI Class Initialized
INFO - 2016-09-23 00:03:18 --> Router Class Initialized
INFO - 2016-09-23 00:03:18 --> Output Class Initialized
INFO - 2016-09-23 00:03:18 --> Security Class Initialized
DEBUG - 2016-09-23 00:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:03:18 --> Input Class Initialized
INFO - 2016-09-23 00:03:18 --> Language Class Initialized
INFO - 2016-09-23 00:03:18 --> Language Class Initialized
INFO - 2016-09-23 00:03:18 --> Config Class Initialized
INFO - 2016-09-23 00:03:18 --> Loader Class Initialized
INFO - 2016-09-23 00:03:18 --> Helper loaded: url_helper
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:03:18 --> Controller Class Initialized
DEBUG - 2016-09-23 00:03:18 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:03:18 --> Model Class Initialized
INFO - 2016-09-23 00:03:18 --> Model Class Initialized
ERROR - 2016-09-23 00:03:18 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-23 00:03:18 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-23 00:03:18 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-23 00:03:18 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-23 00:03:18 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-23 00:03:18 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-23 00:03:18 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:18 --> Database Driver Class Initialized
DEBUG - 2016-09-23 00:03:18 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-23 00:03:18 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-23 00:03:18 --> Final output sent to browser
DEBUG - 2016-09-23 00:03:18 --> Total execution time: 0.1047
INFO - 2016-09-23 00:03:19 --> Config Class Initialized
INFO - 2016-09-23 00:03:19 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:03:19 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:03:19 --> Utf8 Class Initialized
INFO - 2016-09-23 00:03:19 --> URI Class Initialized
INFO - 2016-09-23 00:03:19 --> Router Class Initialized
INFO - 2016-09-23 00:03:19 --> Output Class Initialized
INFO - 2016-09-23 00:03:19 --> Security Class Initialized
DEBUG - 2016-09-23 00:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:03:19 --> Input Class Initialized
INFO - 2016-09-23 00:03:19 --> Language Class Initialized
ERROR - 2016-09-23 00:03:19 --> 404 Page Not Found: /index
INFO - 2016-09-23 00:03:26 --> Config Class Initialized
INFO - 2016-09-23 00:03:26 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:03:26 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:03:26 --> Utf8 Class Initialized
INFO - 2016-09-23 00:03:26 --> URI Class Initialized
INFO - 2016-09-23 00:03:26 --> Router Class Initialized
INFO - 2016-09-23 00:03:26 --> Output Class Initialized
INFO - 2016-09-23 00:03:26 --> Security Class Initialized
DEBUG - 2016-09-23 00:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:03:26 --> Input Class Initialized
INFO - 2016-09-23 00:03:26 --> Language Class Initialized
INFO - 2016-09-23 00:03:26 --> Language Class Initialized
INFO - 2016-09-23 00:03:26 --> Config Class Initialized
INFO - 2016-09-23 00:03:26 --> Loader Class Initialized
INFO - 2016-09-23 00:03:26 --> Helper loaded: url_helper
INFO - 2016-09-23 00:03:26 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:03:26 --> Controller Class Initialized
DEBUG - 2016-09-23 00:03:26 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:03:26 --> Model Class Initialized
INFO - 2016-09-23 00:03:26 --> Model Class Initialized
ERROR - 2016-09-23 00:03:26 --> Unable to delete cache file for admin/index/logout
INFO - 2016-09-23 00:03:26 --> Final output sent to browser
DEBUG - 2016-09-23 00:03:26 --> Total execution time: 0.0265
INFO - 2016-09-23 00:03:26 --> Config Class Initialized
INFO - 2016-09-23 00:03:26 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:03:26 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:03:26 --> Utf8 Class Initialized
INFO - 2016-09-23 00:03:26 --> URI Class Initialized
INFO - 2016-09-23 00:03:26 --> Router Class Initialized
INFO - 2016-09-23 00:03:26 --> Output Class Initialized
INFO - 2016-09-23 00:03:26 --> Security Class Initialized
DEBUG - 2016-09-23 00:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:03:26 --> Input Class Initialized
INFO - 2016-09-23 00:03:26 --> Language Class Initialized
INFO - 2016-09-23 00:03:26 --> Language Class Initialized
INFO - 2016-09-23 00:03:26 --> Config Class Initialized
INFO - 2016-09-23 00:03:26 --> Loader Class Initialized
INFO - 2016-09-23 00:03:26 --> Helper loaded: url_helper
INFO - 2016-09-23 00:03:26 --> Database Driver Class Initialized
INFO - 2016-09-23 00:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:03:26 --> Controller Class Initialized
DEBUG - 2016-09-23 00:03:26 --> login MX_Controller Initialized
INFO - 2016-09-23 00:03:26 --> Model Class Initialized
INFO - 2016-09-23 00:03:26 --> Model Class Initialized
DEBUG - 2016-09-23 00:03:26 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-23 00:03:26 --> Final output sent to browser
DEBUG - 2016-09-23 00:03:26 --> Total execution time: 0.0335
INFO - 2016-09-23 00:03:31 --> Config Class Initialized
INFO - 2016-09-23 00:03:31 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:03:31 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:03:31 --> Utf8 Class Initialized
INFO - 2016-09-23 00:03:31 --> URI Class Initialized
INFO - 2016-09-23 00:03:31 --> Router Class Initialized
INFO - 2016-09-23 00:03:31 --> Output Class Initialized
INFO - 2016-09-23 00:03:31 --> Security Class Initialized
DEBUG - 2016-09-23 00:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:03:31 --> Input Class Initialized
INFO - 2016-09-23 00:03:31 --> Language Class Initialized
ERROR - 2016-09-23 00:03:31 --> 404 Page Not Found: /index
INFO - 2016-09-23 00:04:03 --> Config Class Initialized
INFO - 2016-09-23 00:04:03 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:04:03 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:04:03 --> Utf8 Class Initialized
INFO - 2016-09-23 00:04:03 --> URI Class Initialized
DEBUG - 2016-09-23 00:04:03 --> No URI present. Default controller set.
INFO - 2016-09-23 00:04:03 --> Router Class Initialized
INFO - 2016-09-23 00:04:03 --> Output Class Initialized
INFO - 2016-09-23 00:04:03 --> Security Class Initialized
DEBUG - 2016-09-23 00:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:04:03 --> Input Class Initialized
INFO - 2016-09-23 00:04:03 --> Language Class Initialized
INFO - 2016-09-23 00:04:03 --> Language Class Initialized
INFO - 2016-09-23 00:04:03 --> Config Class Initialized
INFO - 2016-09-23 00:04:03 --> Loader Class Initialized
INFO - 2016-09-23 00:04:03 --> Helper loaded: url_helper
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:04:03 --> Controller Class Initialized
DEBUG - 2016-09-23 00:04:03 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:04:03 --> Model Class Initialized
INFO - 2016-09-23 00:04:03 --> Model Class Initialized
ERROR - 2016-09-23 00:04:03 --> Unable to delete cache file for 
DEBUG - 2016-09-23 00:04:03 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-23 00:04:03 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-23 00:04:03 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-23 00:04:03 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-23 00:04:03 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-23 00:04:03 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:03 --> Database Driver Class Initialized
DEBUG - 2016-09-23 00:04:03 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-23 00:04:03 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-23 00:04:03 --> Final output sent to browser
DEBUG - 2016-09-23 00:04:03 --> Total execution time: 0.1090
INFO - 2016-09-23 00:04:03 --> Config Class Initialized
INFO - 2016-09-23 00:04:03 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:04:03 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:04:03 --> Utf8 Class Initialized
INFO - 2016-09-23 00:04:03 --> URI Class Initialized
INFO - 2016-09-23 00:04:03 --> Router Class Initialized
INFO - 2016-09-23 00:04:04 --> Output Class Initialized
INFO - 2016-09-23 00:04:04 --> Security Class Initialized
DEBUG - 2016-09-23 00:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:04:04 --> Input Class Initialized
INFO - 2016-09-23 00:04:04 --> Language Class Initialized
INFO - 2016-09-23 00:04:04 --> Language Class Initialized
INFO - 2016-09-23 00:04:04 --> Config Class Initialized
INFO - 2016-09-23 00:04:04 --> Loader Class Initialized
INFO - 2016-09-23 00:04:04 --> Helper loaded: url_helper
INFO - 2016-09-23 00:04:04 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:04:04 --> Controller Class Initialized
DEBUG - 2016-09-23 00:04:04 --> login MX_Controller Initialized
INFO - 2016-09-23 00:04:04 --> Model Class Initialized
INFO - 2016-09-23 00:04:04 --> Model Class Initialized
DEBUG - 2016-09-23 00:04:04 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-23 00:04:04 --> Final output sent to browser
DEBUG - 2016-09-23 00:04:04 --> Total execution time: 0.0256
INFO - 2016-09-23 00:04:07 --> Config Class Initialized
INFO - 2016-09-23 00:04:07 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:04:07 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:04:07 --> Utf8 Class Initialized
INFO - 2016-09-23 00:04:07 --> URI Class Initialized
INFO - 2016-09-23 00:04:07 --> Router Class Initialized
INFO - 2016-09-23 00:04:07 --> Output Class Initialized
INFO - 2016-09-23 00:04:07 --> Security Class Initialized
DEBUG - 2016-09-23 00:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:04:07 --> Input Class Initialized
INFO - 2016-09-23 00:04:07 --> Language Class Initialized
INFO - 2016-09-23 00:04:07 --> Language Class Initialized
INFO - 2016-09-23 00:04:07 --> Config Class Initialized
INFO - 2016-09-23 00:04:07 --> Loader Class Initialized
INFO - 2016-09-23 00:04:07 --> Helper loaded: url_helper
INFO - 2016-09-23 00:04:07 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:04:07 --> Controller Class Initialized
DEBUG - 2016-09-23 00:04:07 --> login MX_Controller Initialized
INFO - 2016-09-23 00:04:07 --> Model Class Initialized
INFO - 2016-09-23 00:04:07 --> Model Class Initialized
INFO - 2016-09-23 00:04:07 --> Final output sent to browser
DEBUG - 2016-09-23 00:04:07 --> Total execution time: 0.0271
INFO - 2016-09-23 00:04:08 --> Config Class Initialized
INFO - 2016-09-23 00:04:08 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:04:08 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:04:08 --> Utf8 Class Initialized
INFO - 2016-09-23 00:04:08 --> URI Class Initialized
INFO - 2016-09-23 00:04:08 --> Router Class Initialized
INFO - 2016-09-23 00:04:08 --> Output Class Initialized
INFO - 2016-09-23 00:04:08 --> Security Class Initialized
DEBUG - 2016-09-23 00:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:04:08 --> Input Class Initialized
INFO - 2016-09-23 00:04:08 --> Language Class Initialized
INFO - 2016-09-23 00:04:08 --> Language Class Initialized
INFO - 2016-09-23 00:04:08 --> Config Class Initialized
INFO - 2016-09-23 00:04:08 --> Loader Class Initialized
INFO - 2016-09-23 00:04:08 --> Helper loaded: url_helper
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:04:08 --> Controller Class Initialized
DEBUG - 2016-09-23 00:04:08 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:04:08 --> Model Class Initialized
INFO - 2016-09-23 00:04:08 --> Model Class Initialized
ERROR - 2016-09-23 00:04:08 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-23 00:04:08 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-23 00:04:08 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-23 00:04:08 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-23 00:04:08 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-23 00:04:08 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-23 00:04:08 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:08 --> Database Driver Class Initialized
DEBUG - 2016-09-23 00:04:08 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-23 00:04:08 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-23 00:04:08 --> Final output sent to browser
DEBUG - 2016-09-23 00:04:08 --> Total execution time: 0.1357
INFO - 2016-09-23 00:04:09 --> Config Class Initialized
INFO - 2016-09-23 00:04:09 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:04:09 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:04:09 --> Utf8 Class Initialized
INFO - 2016-09-23 00:04:09 --> URI Class Initialized
INFO - 2016-09-23 00:04:09 --> Router Class Initialized
INFO - 2016-09-23 00:04:09 --> Output Class Initialized
INFO - 2016-09-23 00:04:09 --> Security Class Initialized
DEBUG - 2016-09-23 00:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:04:09 --> Input Class Initialized
INFO - 2016-09-23 00:04:09 --> Language Class Initialized
ERROR - 2016-09-23 00:04:09 --> 404 Page Not Found: /index
INFO - 2016-09-23 00:04:10 --> Config Class Initialized
INFO - 2016-09-23 00:04:10 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:04:10 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:04:10 --> Utf8 Class Initialized
INFO - 2016-09-23 00:04:10 --> URI Class Initialized
INFO - 2016-09-23 00:04:10 --> Router Class Initialized
INFO - 2016-09-23 00:04:10 --> Output Class Initialized
INFO - 2016-09-23 00:04:10 --> Security Class Initialized
DEBUG - 2016-09-23 00:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:04:10 --> Input Class Initialized
INFO - 2016-09-23 00:04:10 --> Language Class Initialized
ERROR - 2016-09-23 00:04:10 --> 404 Page Not Found: /index
INFO - 2016-09-23 00:04:21 --> Config Class Initialized
INFO - 2016-09-23 00:04:21 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:04:21 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:04:21 --> Utf8 Class Initialized
INFO - 2016-09-23 00:04:21 --> URI Class Initialized
INFO - 2016-09-23 00:04:21 --> Router Class Initialized
INFO - 2016-09-23 00:04:21 --> Output Class Initialized
INFO - 2016-09-23 00:04:21 --> Security Class Initialized
DEBUG - 2016-09-23 00:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:04:21 --> Input Class Initialized
INFO - 2016-09-23 00:04:21 --> Language Class Initialized
INFO - 2016-09-23 00:04:21 --> Language Class Initialized
INFO - 2016-09-23 00:04:21 --> Config Class Initialized
INFO - 2016-09-23 00:04:21 --> Loader Class Initialized
INFO - 2016-09-23 00:04:21 --> Helper loaded: url_helper
INFO - 2016-09-23 00:04:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:04:21 --> Controller Class Initialized
DEBUG - 2016-09-23 00:04:21 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:04:21 --> Model Class Initialized
INFO - 2016-09-23 00:04:21 --> Model Class Initialized
ERROR - 2016-09-23 00:04:21 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-23 00:04:21 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-23 00:04:21 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-23 00:04:21 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-23 00:04:21 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-23 00:04:21 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-23 00:04:21 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-23 00:04:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:22 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:22 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:22 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:22 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:22 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:22 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:22 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:22 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:22 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:22 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:22 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:22 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:22 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:22 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:22 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:22 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:22 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:22 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:22 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:22 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:22 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:22 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:22 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:22 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:22 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:22 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:22 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:22 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:22 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:22 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:22 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:22 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:22 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:22 --> Database Driver Class Initialized
DEBUG - 2016-09-23 00:04:22 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-23 00:04:22 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-23 00:04:22 --> Final output sent to browser
DEBUG - 2016-09-23 00:04:22 --> Total execution time: 0.1401
INFO - 2016-09-23 00:04:22 --> Config Class Initialized
INFO - 2016-09-23 00:04:22 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:04:22 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:04:22 --> Utf8 Class Initialized
INFO - 2016-09-23 00:04:22 --> URI Class Initialized
INFO - 2016-09-23 00:04:22 --> Router Class Initialized
INFO - 2016-09-23 00:04:22 --> Output Class Initialized
INFO - 2016-09-23 00:04:22 --> Security Class Initialized
DEBUG - 2016-09-23 00:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:04:22 --> Input Class Initialized
INFO - 2016-09-23 00:04:22 --> Language Class Initialized
INFO - 2016-09-23 00:04:22 --> Language Class Initialized
INFO - 2016-09-23 00:04:22 --> Config Class Initialized
INFO - 2016-09-23 00:04:22 --> Loader Class Initialized
INFO - 2016-09-23 00:04:22 --> Helper loaded: url_helper
INFO - 2016-09-23 00:04:22 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:04:22 --> Controller Class Initialized
DEBUG - 2016-09-23 00:04:22 --> login MX_Controller Initialized
INFO - 2016-09-23 00:04:22 --> Model Class Initialized
INFO - 2016-09-23 00:04:22 --> Model Class Initialized
DEBUG - 2016-09-23 00:04:22 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-23 00:04:22 --> Final output sent to browser
DEBUG - 2016-09-23 00:04:22 --> Total execution time: 0.0234
INFO - 2016-09-23 00:04:30 --> Config Class Initialized
INFO - 2016-09-23 00:04:30 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:04:30 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:04:30 --> Utf8 Class Initialized
INFO - 2016-09-23 00:04:30 --> URI Class Initialized
INFO - 2016-09-23 00:04:30 --> Router Class Initialized
INFO - 2016-09-23 00:04:30 --> Output Class Initialized
INFO - 2016-09-23 00:04:30 --> Security Class Initialized
DEBUG - 2016-09-23 00:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:04:30 --> Input Class Initialized
INFO - 2016-09-23 00:04:30 --> Language Class Initialized
INFO - 2016-09-23 00:04:30 --> Language Class Initialized
INFO - 2016-09-23 00:04:30 --> Config Class Initialized
INFO - 2016-09-23 00:04:30 --> Loader Class Initialized
INFO - 2016-09-23 00:04:30 --> Helper loaded: url_helper
INFO - 2016-09-23 00:04:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:04:30 --> Controller Class Initialized
DEBUG - 2016-09-23 00:04:30 --> login MX_Controller Initialized
INFO - 2016-09-23 00:04:30 --> Model Class Initialized
INFO - 2016-09-23 00:04:30 --> Model Class Initialized
INFO - 2016-09-23 00:04:30 --> Final output sent to browser
DEBUG - 2016-09-23 00:04:30 --> Total execution time: 0.0388
INFO - 2016-09-23 00:04:31 --> Config Class Initialized
INFO - 2016-09-23 00:04:31 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:04:31 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:04:31 --> Utf8 Class Initialized
INFO - 2016-09-23 00:04:31 --> URI Class Initialized
INFO - 2016-09-23 00:04:31 --> Router Class Initialized
INFO - 2016-09-23 00:04:31 --> Output Class Initialized
INFO - 2016-09-23 00:04:31 --> Security Class Initialized
DEBUG - 2016-09-23 00:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:04:31 --> Input Class Initialized
INFO - 2016-09-23 00:04:31 --> Language Class Initialized
INFO - 2016-09-23 00:04:31 --> Language Class Initialized
INFO - 2016-09-23 00:04:31 --> Config Class Initialized
INFO - 2016-09-23 00:04:31 --> Loader Class Initialized
INFO - 2016-09-23 00:04:31 --> Helper loaded: url_helper
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:04:31 --> Controller Class Initialized
DEBUG - 2016-09-23 00:04:31 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:04:31 --> Model Class Initialized
INFO - 2016-09-23 00:04:31 --> Model Class Initialized
ERROR - 2016-09-23 00:04:31 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-23 00:04:31 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-23 00:04:31 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-23 00:04:31 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-23 00:04:31 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-23 00:04:31 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-23 00:04:31 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:31 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:32 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:32 --> Database Driver Class Initialized
DEBUG - 2016-09-23 00:04:32 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-23 00:04:32 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-23 00:04:32 --> Final output sent to browser
DEBUG - 2016-09-23 00:04:32 --> Total execution time: 0.6034
INFO - 2016-09-23 00:04:40 --> Config Class Initialized
INFO - 2016-09-23 00:04:40 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:04:40 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:04:40 --> Utf8 Class Initialized
INFO - 2016-09-23 00:04:40 --> URI Class Initialized
INFO - 2016-09-23 00:04:40 --> Router Class Initialized
INFO - 2016-09-23 00:04:40 --> Output Class Initialized
INFO - 2016-09-23 00:04:40 --> Security Class Initialized
DEBUG - 2016-09-23 00:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:04:40 --> Input Class Initialized
INFO - 2016-09-23 00:04:40 --> Language Class Initialized
ERROR - 2016-09-23 00:04:40 --> 404 Page Not Found: /index
INFO - 2016-09-23 00:04:46 --> Config Class Initialized
INFO - 2016-09-23 00:04:46 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:04:46 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:04:46 --> Utf8 Class Initialized
INFO - 2016-09-23 00:04:46 --> URI Class Initialized
INFO - 2016-09-23 00:04:46 --> Router Class Initialized
INFO - 2016-09-23 00:04:46 --> Output Class Initialized
INFO - 2016-09-23 00:04:46 --> Security Class Initialized
DEBUG - 2016-09-23 00:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:04:46 --> Input Class Initialized
INFO - 2016-09-23 00:04:46 --> Language Class Initialized
INFO - 2016-09-23 00:04:46 --> Language Class Initialized
INFO - 2016-09-23 00:04:46 --> Config Class Initialized
INFO - 2016-09-23 00:04:46 --> Loader Class Initialized
INFO - 2016-09-23 00:04:46 --> Helper loaded: url_helper
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:04:46 --> Controller Class Initialized
DEBUG - 2016-09-23 00:04:46 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:04:46 --> Model Class Initialized
INFO - 2016-09-23 00:04:46 --> Model Class Initialized
ERROR - 2016-09-23 00:04:46 --> Unable to delete cache file for admin/index/upload_foto
DEBUG - 2016-09-23 00:04:46 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-23 00:04:46 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-23 00:04:46 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-23 00:04:46 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/upload_foto.php
DEBUG - 2016-09-23 00:04:46 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-23 00:04:46 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:46 --> Database Driver Class Initialized
DEBUG - 2016-09-23 00:04:46 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-23 00:04:46 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-23 00:04:46 --> Final output sent to browser
DEBUG - 2016-09-23 00:04:46 --> Total execution time: 0.0712
INFO - 2016-09-23 00:04:47 --> Config Class Initialized
INFO - 2016-09-23 00:04:47 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:04:47 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:04:47 --> Utf8 Class Initialized
INFO - 2016-09-23 00:04:47 --> URI Class Initialized
INFO - 2016-09-23 00:04:47 --> Router Class Initialized
INFO - 2016-09-23 00:04:47 --> Output Class Initialized
INFO - 2016-09-23 00:04:47 --> Security Class Initialized
DEBUG - 2016-09-23 00:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:04:47 --> Input Class Initialized
INFO - 2016-09-23 00:04:47 --> Language Class Initialized
ERROR - 2016-09-23 00:04:47 --> 404 Page Not Found: /index
INFO - 2016-09-23 00:04:48 --> Config Class Initialized
INFO - 2016-09-23 00:04:48 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:04:48 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:04:48 --> Utf8 Class Initialized
INFO - 2016-09-23 00:04:48 --> URI Class Initialized
INFO - 2016-09-23 00:04:48 --> Router Class Initialized
INFO - 2016-09-23 00:04:48 --> Output Class Initialized
INFO - 2016-09-23 00:04:48 --> Security Class Initialized
DEBUG - 2016-09-23 00:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:04:48 --> Input Class Initialized
INFO - 2016-09-23 00:04:48 --> Language Class Initialized
ERROR - 2016-09-23 00:04:48 --> 404 Page Not Found: /index
INFO - 2016-09-23 00:04:59 --> Config Class Initialized
INFO - 2016-09-23 00:04:59 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:04:59 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:04:59 --> Utf8 Class Initialized
INFO - 2016-09-23 00:04:59 --> URI Class Initialized
INFO - 2016-09-23 00:04:59 --> Router Class Initialized
INFO - 2016-09-23 00:04:59 --> Output Class Initialized
INFO - 2016-09-23 00:04:59 --> Security Class Initialized
DEBUG - 2016-09-23 00:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:04:59 --> Input Class Initialized
INFO - 2016-09-23 00:04:59 --> Language Class Initialized
INFO - 2016-09-23 00:04:59 --> Language Class Initialized
INFO - 2016-09-23 00:04:59 --> Config Class Initialized
INFO - 2016-09-23 00:04:59 --> Loader Class Initialized
INFO - 2016-09-23 00:04:59 --> Helper loaded: url_helper
INFO - 2016-09-23 00:04:59 --> Database Driver Class Initialized
INFO - 2016-09-23 00:04:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:04:59 --> Controller Class Initialized
DEBUG - 2016-09-23 00:04:59 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:04:59 --> Model Class Initialized
INFO - 2016-09-23 00:04:59 --> Model Class Initialized
ERROR - 2016-09-23 00:04:59 --> Unable to delete cache file for admin/index/do_upload_foto
INFO - 2016-09-23 00:04:59 --> Upload Class Initialized
INFO - 2016-09-23 00:04:59 --> Final output sent to browser
DEBUG - 2016-09-23 00:04:59 --> Total execution time: 0.0364
INFO - 2016-09-23 00:05:03 --> Config Class Initialized
INFO - 2016-09-23 00:05:03 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:05:03 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:05:03 --> Utf8 Class Initialized
INFO - 2016-09-23 00:05:03 --> URI Class Initialized
INFO - 2016-09-23 00:05:03 --> Router Class Initialized
INFO - 2016-09-23 00:05:03 --> Output Class Initialized
INFO - 2016-09-23 00:05:03 --> Security Class Initialized
DEBUG - 2016-09-23 00:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:05:03 --> Input Class Initialized
INFO - 2016-09-23 00:05:03 --> Language Class Initialized
INFO - 2016-09-23 00:05:03 --> Language Class Initialized
INFO - 2016-09-23 00:05:03 --> Config Class Initialized
INFO - 2016-09-23 00:05:03 --> Loader Class Initialized
INFO - 2016-09-23 00:05:03 --> Helper loaded: url_helper
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:05:03 --> Controller Class Initialized
DEBUG - 2016-09-23 00:05:03 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:05:03 --> Model Class Initialized
INFO - 2016-09-23 00:05:03 --> Model Class Initialized
ERROR - 2016-09-23 00:05:03 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-23 00:05:03 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-23 00:05:03 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-23 00:05:03 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-23 00:05:03 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-23 00:05:03 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-23 00:05:03 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:03 --> Database Driver Class Initialized
DEBUG - 2016-09-23 00:05:03 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-23 00:05:03 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-23 00:05:03 --> Final output sent to browser
DEBUG - 2016-09-23 00:05:03 --> Total execution time: 0.1025
INFO - 2016-09-23 00:05:04 --> Config Class Initialized
INFO - 2016-09-23 00:05:04 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:05:04 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:05:04 --> Utf8 Class Initialized
INFO - 2016-09-23 00:05:04 --> URI Class Initialized
INFO - 2016-09-23 00:05:04 --> Router Class Initialized
INFO - 2016-09-23 00:05:04 --> Output Class Initialized
INFO - 2016-09-23 00:05:04 --> Security Class Initialized
DEBUG - 2016-09-23 00:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:05:04 --> Input Class Initialized
INFO - 2016-09-23 00:05:04 --> Language Class Initialized
ERROR - 2016-09-23 00:05:04 --> 404 Page Not Found: /index
INFO - 2016-09-23 00:05:13 --> Config Class Initialized
INFO - 2016-09-23 00:05:13 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:05:13 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:05:13 --> Utf8 Class Initialized
INFO - 2016-09-23 00:05:13 --> URI Class Initialized
INFO - 2016-09-23 00:05:13 --> Router Class Initialized
INFO - 2016-09-23 00:05:13 --> Output Class Initialized
INFO - 2016-09-23 00:05:13 --> Security Class Initialized
DEBUG - 2016-09-23 00:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:05:13 --> Input Class Initialized
INFO - 2016-09-23 00:05:13 --> Language Class Initialized
INFO - 2016-09-23 00:05:13 --> Language Class Initialized
INFO - 2016-09-23 00:05:13 --> Config Class Initialized
INFO - 2016-09-23 00:05:13 --> Loader Class Initialized
INFO - 2016-09-23 00:05:13 --> Helper loaded: url_helper
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:05:14 --> Controller Class Initialized
DEBUG - 2016-09-23 00:05:14 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:05:14 --> Model Class Initialized
INFO - 2016-09-23 00:05:14 --> Model Class Initialized
ERROR - 2016-09-23 00:05:14 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-23 00:05:14 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-23 00:05:14 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-23 00:05:14 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-23 00:05:14 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-23 00:05:14 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-23 00:05:14 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:14 --> Database Driver Class Initialized
DEBUG - 2016-09-23 00:05:14 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-23 00:05:14 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-23 00:05:14 --> Final output sent to browser
DEBUG - 2016-09-23 00:05:14 --> Total execution time: 0.1388
INFO - 2016-09-23 00:05:14 --> Config Class Initialized
INFO - 2016-09-23 00:05:14 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:05:14 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:05:14 --> Utf8 Class Initialized
INFO - 2016-09-23 00:05:14 --> URI Class Initialized
INFO - 2016-09-23 00:05:14 --> Router Class Initialized
INFO - 2016-09-23 00:05:14 --> Output Class Initialized
INFO - 2016-09-23 00:05:14 --> Security Class Initialized
DEBUG - 2016-09-23 00:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:05:14 --> Input Class Initialized
INFO - 2016-09-23 00:05:14 --> Language Class Initialized
ERROR - 2016-09-23 00:05:14 --> 404 Page Not Found: /index
INFO - 2016-09-23 00:05:19 --> Config Class Initialized
INFO - 2016-09-23 00:05:19 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:05:19 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:05:19 --> Utf8 Class Initialized
INFO - 2016-09-23 00:05:19 --> URI Class Initialized
INFO - 2016-09-23 00:05:19 --> Router Class Initialized
INFO - 2016-09-23 00:05:19 --> Output Class Initialized
INFO - 2016-09-23 00:05:19 --> Security Class Initialized
DEBUG - 2016-09-23 00:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:05:19 --> Input Class Initialized
INFO - 2016-09-23 00:05:19 --> Language Class Initialized
INFO - 2016-09-23 00:05:19 --> Language Class Initialized
INFO - 2016-09-23 00:05:19 --> Config Class Initialized
INFO - 2016-09-23 00:05:19 --> Loader Class Initialized
INFO - 2016-09-23 00:05:19 --> Helper loaded: url_helper
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:05:19 --> Controller Class Initialized
DEBUG - 2016-09-23 00:05:19 --> login MX_Controller Initialized
INFO - 2016-09-23 00:05:19 --> Model Class Initialized
INFO - 2016-09-23 00:05:19 --> Model Class Initialized
DEBUG - 2016-09-23 00:05:19 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-23 00:05:19 --> Final output sent to browser
DEBUG - 2016-09-23 00:05:19 --> Total execution time: 0.0332
INFO - 2016-09-23 00:05:19 --> Config Class Initialized
INFO - 2016-09-23 00:05:19 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:05:19 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:05:19 --> Utf8 Class Initialized
INFO - 2016-09-23 00:05:19 --> URI Class Initialized
INFO - 2016-09-23 00:05:19 --> Router Class Initialized
INFO - 2016-09-23 00:05:19 --> Output Class Initialized
INFO - 2016-09-23 00:05:19 --> Security Class Initialized
DEBUG - 2016-09-23 00:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:05:19 --> Input Class Initialized
INFO - 2016-09-23 00:05:19 --> Language Class Initialized
INFO - 2016-09-23 00:05:19 --> Language Class Initialized
INFO - 2016-09-23 00:05:19 --> Config Class Initialized
INFO - 2016-09-23 00:05:19 --> Loader Class Initialized
INFO - 2016-09-23 00:05:19 --> Helper loaded: url_helper
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:05:19 --> Controller Class Initialized
DEBUG - 2016-09-23 00:05:19 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:05:19 --> Model Class Initialized
INFO - 2016-09-23 00:05:19 --> Model Class Initialized
ERROR - 2016-09-23 00:05:19 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-23 00:05:19 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-23 00:05:19 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-23 00:05:19 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-23 00:05:19 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-23 00:05:19 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-23 00:05:19 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:19 --> Database Driver Class Initialized
DEBUG - 2016-09-23 00:05:19 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-23 00:05:19 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-23 00:05:19 --> Final output sent to browser
DEBUG - 2016-09-23 00:05:19 --> Total execution time: 0.0809
INFO - 2016-09-23 00:05:20 --> Config Class Initialized
INFO - 2016-09-23 00:05:20 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:05:20 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:05:20 --> Utf8 Class Initialized
INFO - 2016-09-23 00:05:20 --> URI Class Initialized
INFO - 2016-09-23 00:05:20 --> Router Class Initialized
INFO - 2016-09-23 00:05:20 --> Output Class Initialized
INFO - 2016-09-23 00:05:20 --> Security Class Initialized
DEBUG - 2016-09-23 00:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:05:20 --> Input Class Initialized
INFO - 2016-09-23 00:05:20 --> Language Class Initialized
ERROR - 2016-09-23 00:05:20 --> 404 Page Not Found: /index
INFO - 2016-09-23 00:05:23 --> Config Class Initialized
INFO - 2016-09-23 00:05:23 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:05:23 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:05:23 --> Utf8 Class Initialized
INFO - 2016-09-23 00:05:23 --> URI Class Initialized
INFO - 2016-09-23 00:05:23 --> Router Class Initialized
INFO - 2016-09-23 00:05:23 --> Output Class Initialized
INFO - 2016-09-23 00:05:23 --> Security Class Initialized
DEBUG - 2016-09-23 00:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:05:23 --> Input Class Initialized
INFO - 2016-09-23 00:05:23 --> Language Class Initialized
INFO - 2016-09-23 00:05:23 --> Language Class Initialized
INFO - 2016-09-23 00:05:23 --> Config Class Initialized
INFO - 2016-09-23 00:05:23 --> Loader Class Initialized
INFO - 2016-09-23 00:05:23 --> Helper loaded: url_helper
INFO - 2016-09-23 00:05:23 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:05:23 --> Controller Class Initialized
DEBUG - 2016-09-23 00:05:23 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:05:23 --> Model Class Initialized
INFO - 2016-09-23 00:05:23 --> Model Class Initialized
ERROR - 2016-09-23 00:05:23 --> Unable to delete cache file for admin/index/logout
INFO - 2016-09-23 00:05:23 --> Final output sent to browser
DEBUG - 2016-09-23 00:05:23 --> Total execution time: 0.0279
INFO - 2016-09-23 00:05:23 --> Config Class Initialized
INFO - 2016-09-23 00:05:23 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:05:23 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:05:23 --> Utf8 Class Initialized
INFO - 2016-09-23 00:05:23 --> URI Class Initialized
INFO - 2016-09-23 00:05:23 --> Router Class Initialized
INFO - 2016-09-23 00:05:23 --> Output Class Initialized
INFO - 2016-09-23 00:05:23 --> Security Class Initialized
DEBUG - 2016-09-23 00:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:05:23 --> Input Class Initialized
INFO - 2016-09-23 00:05:23 --> Language Class Initialized
INFO - 2016-09-23 00:05:23 --> Language Class Initialized
INFO - 2016-09-23 00:05:23 --> Config Class Initialized
INFO - 2016-09-23 00:05:23 --> Loader Class Initialized
INFO - 2016-09-23 00:05:23 --> Helper loaded: url_helper
INFO - 2016-09-23 00:05:23 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:05:23 --> Controller Class Initialized
DEBUG - 2016-09-23 00:05:23 --> login MX_Controller Initialized
INFO - 2016-09-23 00:05:23 --> Model Class Initialized
INFO - 2016-09-23 00:05:23 --> Model Class Initialized
DEBUG - 2016-09-23 00:05:23 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-23 00:05:23 --> Final output sent to browser
DEBUG - 2016-09-23 00:05:23 --> Total execution time: 0.0276
INFO - 2016-09-23 00:05:25 --> Config Class Initialized
INFO - 2016-09-23 00:05:25 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:05:25 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:05:25 --> Utf8 Class Initialized
INFO - 2016-09-23 00:05:25 --> URI Class Initialized
INFO - 2016-09-23 00:05:25 --> Router Class Initialized
INFO - 2016-09-23 00:05:25 --> Output Class Initialized
INFO - 2016-09-23 00:05:25 --> Security Class Initialized
DEBUG - 2016-09-23 00:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:05:25 --> Input Class Initialized
INFO - 2016-09-23 00:05:25 --> Language Class Initialized
INFO - 2016-09-23 00:05:25 --> Language Class Initialized
INFO - 2016-09-23 00:05:25 --> Config Class Initialized
INFO - 2016-09-23 00:05:25 --> Loader Class Initialized
INFO - 2016-09-23 00:05:25 --> Helper loaded: url_helper
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:05:25 --> Controller Class Initialized
DEBUG - 2016-09-23 00:05:25 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:05:25 --> Model Class Initialized
INFO - 2016-09-23 00:05:25 --> Model Class Initialized
ERROR - 2016-09-23 00:05:25 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-23 00:05:25 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-23 00:05:25 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-23 00:05:25 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-23 00:05:25 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-23 00:05:25 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-23 00:05:25 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:25 --> Database Driver Class Initialized
DEBUG - 2016-09-23 00:05:25 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-23 00:05:25 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-23 00:05:25 --> Final output sent to browser
DEBUG - 2016-09-23 00:05:25 --> Total execution time: 0.1002
INFO - 2016-09-23 00:05:26 --> Config Class Initialized
INFO - 2016-09-23 00:05:26 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:05:26 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:05:26 --> Utf8 Class Initialized
INFO - 2016-09-23 00:05:26 --> URI Class Initialized
INFO - 2016-09-23 00:05:26 --> Router Class Initialized
INFO - 2016-09-23 00:05:26 --> Output Class Initialized
INFO - 2016-09-23 00:05:26 --> Security Class Initialized
DEBUG - 2016-09-23 00:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:05:26 --> Input Class Initialized
INFO - 2016-09-23 00:05:26 --> Language Class Initialized
INFO - 2016-09-23 00:05:26 --> Language Class Initialized
INFO - 2016-09-23 00:05:26 --> Config Class Initialized
INFO - 2016-09-23 00:05:26 --> Loader Class Initialized
INFO - 2016-09-23 00:05:26 --> Helper loaded: url_helper
INFO - 2016-09-23 00:05:26 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:05:26 --> Controller Class Initialized
DEBUG - 2016-09-23 00:05:26 --> login MX_Controller Initialized
INFO - 2016-09-23 00:05:26 --> Model Class Initialized
INFO - 2016-09-23 00:05:26 --> Model Class Initialized
DEBUG - 2016-09-23 00:05:26 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-23 00:05:26 --> Final output sent to browser
DEBUG - 2016-09-23 00:05:26 --> Total execution time: 0.0246
INFO - 2016-09-23 00:05:29 --> Config Class Initialized
INFO - 2016-09-23 00:05:29 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:05:29 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:05:29 --> Utf8 Class Initialized
INFO - 2016-09-23 00:05:29 --> URI Class Initialized
INFO - 2016-09-23 00:05:29 --> Router Class Initialized
INFO - 2016-09-23 00:05:29 --> Output Class Initialized
INFO - 2016-09-23 00:05:29 --> Security Class Initialized
DEBUG - 2016-09-23 00:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:05:29 --> Input Class Initialized
INFO - 2016-09-23 00:05:29 --> Language Class Initialized
INFO - 2016-09-23 00:05:29 --> Language Class Initialized
INFO - 2016-09-23 00:05:29 --> Config Class Initialized
INFO - 2016-09-23 00:05:29 --> Loader Class Initialized
INFO - 2016-09-23 00:05:29 --> Helper loaded: url_helper
INFO - 2016-09-23 00:05:29 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:05:29 --> Controller Class Initialized
DEBUG - 2016-09-23 00:05:29 --> login MX_Controller Initialized
INFO - 2016-09-23 00:05:29 --> Model Class Initialized
INFO - 2016-09-23 00:05:29 --> Model Class Initialized
INFO - 2016-09-23 00:05:29 --> Final output sent to browser
DEBUG - 2016-09-23 00:05:29 --> Total execution time: 0.0229
INFO - 2016-09-23 00:05:30 --> Config Class Initialized
INFO - 2016-09-23 00:05:30 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:05:30 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:05:30 --> Utf8 Class Initialized
INFO - 2016-09-23 00:05:30 --> URI Class Initialized
INFO - 2016-09-23 00:05:30 --> Router Class Initialized
INFO - 2016-09-23 00:05:30 --> Output Class Initialized
INFO - 2016-09-23 00:05:30 --> Security Class Initialized
DEBUG - 2016-09-23 00:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:05:30 --> Input Class Initialized
INFO - 2016-09-23 00:05:30 --> Language Class Initialized
INFO - 2016-09-23 00:05:30 --> Language Class Initialized
INFO - 2016-09-23 00:05:30 --> Config Class Initialized
INFO - 2016-09-23 00:05:30 --> Loader Class Initialized
INFO - 2016-09-23 00:05:30 --> Helper loaded: url_helper
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:05:30 --> Controller Class Initialized
DEBUG - 2016-09-23 00:05:30 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:05:30 --> Model Class Initialized
INFO - 2016-09-23 00:05:30 --> Model Class Initialized
ERROR - 2016-09-23 00:05:30 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-23 00:05:30 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-23 00:05:30 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-23 00:05:30 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-23 00:05:30 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-23 00:05:30 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-23 00:05:30 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:30 --> Database Driver Class Initialized
DEBUG - 2016-09-23 00:05:30 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-23 00:05:30 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-23 00:05:30 --> Final output sent to browser
DEBUG - 2016-09-23 00:05:30 --> Total execution time: 0.0794
INFO - 2016-09-23 00:05:31 --> Config Class Initialized
INFO - 2016-09-23 00:05:31 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:05:31 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:05:31 --> Utf8 Class Initialized
INFO - 2016-09-23 00:05:31 --> URI Class Initialized
INFO - 2016-09-23 00:05:31 --> Router Class Initialized
INFO - 2016-09-23 00:05:31 --> Output Class Initialized
INFO - 2016-09-23 00:05:31 --> Security Class Initialized
DEBUG - 2016-09-23 00:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:05:31 --> Input Class Initialized
INFO - 2016-09-23 00:05:31 --> Language Class Initialized
ERROR - 2016-09-23 00:05:31 --> 404 Page Not Found: /index
INFO - 2016-09-23 00:05:39 --> Config Class Initialized
INFO - 2016-09-23 00:05:39 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:05:39 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:05:39 --> Utf8 Class Initialized
INFO - 2016-09-23 00:05:39 --> URI Class Initialized
INFO - 2016-09-23 00:05:39 --> Router Class Initialized
INFO - 2016-09-23 00:05:39 --> Output Class Initialized
INFO - 2016-09-23 00:05:39 --> Security Class Initialized
DEBUG - 2016-09-23 00:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:05:39 --> Input Class Initialized
INFO - 2016-09-23 00:05:39 --> Language Class Initialized
INFO - 2016-09-23 00:05:39 --> Language Class Initialized
INFO - 2016-09-23 00:05:39 --> Config Class Initialized
INFO - 2016-09-23 00:05:39 --> Loader Class Initialized
INFO - 2016-09-23 00:05:39 --> Helper loaded: url_helper
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:05:39 --> Controller Class Initialized
DEBUG - 2016-09-23 00:05:39 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:05:39 --> Model Class Initialized
INFO - 2016-09-23 00:05:39 --> Model Class Initialized
ERROR - 2016-09-23 00:05:39 --> Unable to delete cache file for admin/index/add/user
DEBUG - 2016-09-23 00:05:39 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-23 00:05:39 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-23 00:05:39 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-23 00:05:39 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/form_user.php
DEBUG - 2016-09-23 00:05:39 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-23 00:05:39 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:05:39 --> Database Driver Class Initialized
DEBUG - 2016-09-23 00:05:39 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-23 00:05:39 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-23 00:05:39 --> Final output sent to browser
DEBUG - 2016-09-23 00:05:39 --> Total execution time: 0.1031
INFO - 2016-09-23 00:05:40 --> Config Class Initialized
INFO - 2016-09-23 00:05:40 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:05:40 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:05:40 --> Utf8 Class Initialized
INFO - 2016-09-23 00:05:40 --> URI Class Initialized
INFO - 2016-09-23 00:05:40 --> Router Class Initialized
INFO - 2016-09-23 00:05:40 --> Output Class Initialized
INFO - 2016-09-23 00:05:40 --> Security Class Initialized
DEBUG - 2016-09-23 00:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:05:40 --> Input Class Initialized
INFO - 2016-09-23 00:05:40 --> Language Class Initialized
ERROR - 2016-09-23 00:05:40 --> 404 Page Not Found: /index
INFO - 2016-09-23 00:05:41 --> Config Class Initialized
INFO - 2016-09-23 00:05:41 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:05:41 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:05:41 --> Utf8 Class Initialized
INFO - 2016-09-23 00:05:41 --> URI Class Initialized
INFO - 2016-09-23 00:05:41 --> Router Class Initialized
INFO - 2016-09-23 00:05:41 --> Output Class Initialized
INFO - 2016-09-23 00:05:41 --> Security Class Initialized
DEBUG - 2016-09-23 00:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:05:41 --> Input Class Initialized
INFO - 2016-09-23 00:05:41 --> Language Class Initialized
ERROR - 2016-09-23 00:05:41 --> 404 Page Not Found: /index
INFO - 2016-09-23 00:06:37 --> Config Class Initialized
INFO - 2016-09-23 00:06:37 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:06:37 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:06:37 --> Utf8 Class Initialized
INFO - 2016-09-23 00:06:37 --> URI Class Initialized
INFO - 2016-09-23 00:06:37 --> Router Class Initialized
INFO - 2016-09-23 00:06:37 --> Output Class Initialized
INFO - 2016-09-23 00:06:37 --> Security Class Initialized
DEBUG - 2016-09-23 00:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:06:37 --> Input Class Initialized
INFO - 2016-09-23 00:06:37 --> Language Class Initialized
INFO - 2016-09-23 00:06:37 --> Language Class Initialized
INFO - 2016-09-23 00:06:37 --> Config Class Initialized
INFO - 2016-09-23 00:06:37 --> Loader Class Initialized
INFO - 2016-09-23 00:06:37 --> Helper loaded: url_helper
INFO - 2016-09-23 00:06:37 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:06:37 --> Controller Class Initialized
DEBUG - 2016-09-23 00:06:37 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:06:37 --> Model Class Initialized
INFO - 2016-09-23 00:06:37 --> Model Class Initialized
ERROR - 2016-09-23 00:06:37 --> Unable to delete cache file for admin/index/post_add/user
DEBUG - 2016-09-23 00:06:37 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-23 00:06:37 --> Users MX_Controller Initialized
INFO - 2016-09-23 00:06:37 --> Database Driver Class Initialized
ERROR - 2016-09-23 00:06:38 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`koperasi_v1`.`tm_user`, CONSTRAINT `FK_tm_user_tm_level` FOREIGN KEY (`kd_level`) REFERENCES `tm_level` (`kd_level`)) - Invalid query: INSERT INTO `tm_user` (`nama`, `alamat`, `tanggal_lahir`, `tanggal_masuk`, `no_identitas`, `no_hp`, `username`, `password`, `kd_level`) VALUES ('Andrias Sofian Adinata', 'JL. Simpang Bandulan Barat', '1993-09-29', '2016-09-23', '008', '008', 'andrias', '827ccb0eea8a706c4c34a16891f84e7b', 2)
INFO - 2016-09-23 00:06:38 --> Language file loaded: language/english/db_lang.php
INFO - 2016-09-23 00:06:47 --> Config Class Initialized
INFO - 2016-09-23 00:06:47 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:06:47 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:06:47 --> Utf8 Class Initialized
INFO - 2016-09-23 00:06:47 --> URI Class Initialized
INFO - 2016-09-23 00:06:47 --> Router Class Initialized
INFO - 2016-09-23 00:06:47 --> Output Class Initialized
INFO - 2016-09-23 00:06:47 --> Security Class Initialized
DEBUG - 2016-09-23 00:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:06:47 --> Input Class Initialized
INFO - 2016-09-23 00:06:47 --> Language Class Initialized
INFO - 2016-09-23 00:06:47 --> Language Class Initialized
INFO - 2016-09-23 00:06:47 --> Config Class Initialized
INFO - 2016-09-23 00:06:47 --> Loader Class Initialized
INFO - 2016-09-23 00:06:47 --> Helper loaded: url_helper
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:06:47 --> Controller Class Initialized
DEBUG - 2016-09-23 00:06:47 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:06:47 --> Model Class Initialized
INFO - 2016-09-23 00:06:47 --> Model Class Initialized
ERROR - 2016-09-23 00:06:47 --> Unable to delete cache file for admin/index/data/user
DEBUG - 2016-09-23 00:06:47 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-23 00:06:47 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-23 00:06:47 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-23 00:06:47 --> File already loaded: /home/koperasi/public_html/application/controllers/../modules/user/controllers/Users.php
DEBUG - 2016-09-23 00:06:47 --> Users MX_Controller Initialized
DEBUG - 2016-09-23 00:06:47 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/list_user.php
DEBUG - 2016-09-23 00:06:47 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-23 00:06:47 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:47 --> Database Driver Class Initialized
DEBUG - 2016-09-23 00:06:47 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-23 00:06:47 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-23 00:06:47 --> Final output sent to browser
DEBUG - 2016-09-23 00:06:47 --> Total execution time: 0.2040
INFO - 2016-09-23 00:06:48 --> Config Class Initialized
INFO - 2016-09-23 00:06:48 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:06:48 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:06:48 --> Utf8 Class Initialized
INFO - 2016-09-23 00:06:48 --> URI Class Initialized
INFO - 2016-09-23 00:06:48 --> Router Class Initialized
INFO - 2016-09-23 00:06:48 --> Output Class Initialized
INFO - 2016-09-23 00:06:48 --> Security Class Initialized
DEBUG - 2016-09-23 00:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:06:48 --> Input Class Initialized
INFO - 2016-09-23 00:06:48 --> Language Class Initialized
ERROR - 2016-09-23 00:06:48 --> 404 Page Not Found: /index
INFO - 2016-09-23 00:06:48 --> Config Class Initialized
INFO - 2016-09-23 00:06:48 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:06:48 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:06:48 --> Utf8 Class Initialized
INFO - 2016-09-23 00:06:48 --> URI Class Initialized
INFO - 2016-09-23 00:06:48 --> Router Class Initialized
INFO - 2016-09-23 00:06:48 --> Output Class Initialized
INFO - 2016-09-23 00:06:48 --> Security Class Initialized
DEBUG - 2016-09-23 00:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:06:48 --> Input Class Initialized
INFO - 2016-09-23 00:06:48 --> Language Class Initialized
ERROR - 2016-09-23 00:06:48 --> 404 Page Not Found: /index
INFO - 2016-09-23 00:06:53 --> Config Class Initialized
INFO - 2016-09-23 00:06:53 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:06:53 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:06:53 --> Utf8 Class Initialized
INFO - 2016-09-23 00:06:53 --> URI Class Initialized
INFO - 2016-09-23 00:06:53 --> Router Class Initialized
INFO - 2016-09-23 00:06:53 --> Output Class Initialized
INFO - 2016-09-23 00:06:53 --> Security Class Initialized
DEBUG - 2016-09-23 00:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:06:53 --> Input Class Initialized
INFO - 2016-09-23 00:06:53 --> Language Class Initialized
INFO - 2016-09-23 00:06:53 --> Language Class Initialized
INFO - 2016-09-23 00:06:53 --> Config Class Initialized
INFO - 2016-09-23 00:06:53 --> Loader Class Initialized
INFO - 2016-09-23 00:06:53 --> Helper loaded: url_helper
INFO - 2016-09-23 00:06:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:06:53 --> Controller Class Initialized
DEBUG - 2016-09-23 00:06:53 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:06:53 --> Model Class Initialized
INFO - 2016-09-23 00:06:53 --> Model Class Initialized
ERROR - 2016-09-23 00:06:53 --> Unable to delete cache file for admin/index/post_add/user
DEBUG - 2016-09-23 00:06:53 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-23 00:06:53 --> Users MX_Controller Initialized
INFO - 2016-09-23 00:06:53 --> Database Driver Class Initialized
ERROR - 2016-09-23 00:06:53 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`koperasi_v1`.`tm_user`, CONSTRAINT `FK_tm_user_tm_level` FOREIGN KEY (`kd_level`) REFERENCES `tm_level` (`kd_level`)) - Invalid query: INSERT INTO `tm_user` (`nama`, `alamat`, `tanggal_lahir`, `tanggal_masuk`, `no_identitas`, `no_hp`, `username`, `password`, `kd_level`) VALUES ('Andrias Sofian Adinata', 'JL. Simpang Bandulan Barat', '1993-09-29', '2016-09-23', '008', '008', 'andrias', '827ccb0eea8a706c4c34a16891f84e7b', 2)
INFO - 2016-09-23 00:06:53 --> Language file loaded: language/english/db_lang.php
INFO - 2016-09-23 00:07:05 --> Config Class Initialized
INFO - 2016-09-23 00:07:05 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:07:05 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:07:05 --> Utf8 Class Initialized
INFO - 2016-09-23 00:07:05 --> URI Class Initialized
INFO - 2016-09-23 00:07:05 --> Router Class Initialized
INFO - 2016-09-23 00:07:05 --> Output Class Initialized
INFO - 2016-09-23 00:07:05 --> Security Class Initialized
DEBUG - 2016-09-23 00:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:07:05 --> Input Class Initialized
INFO - 2016-09-23 00:07:05 --> Language Class Initialized
INFO - 2016-09-23 00:07:05 --> Language Class Initialized
INFO - 2016-09-23 00:07:05 --> Config Class Initialized
INFO - 2016-09-23 00:07:05 --> Loader Class Initialized
INFO - 2016-09-23 00:07:05 --> Helper loaded: url_helper
INFO - 2016-09-23 00:07:05 --> Database Driver Class Initialized
INFO - 2016-09-23 00:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:07:05 --> Controller Class Initialized
DEBUG - 2016-09-23 00:07:05 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:07:05 --> Model Class Initialized
INFO - 2016-09-23 00:07:05 --> Model Class Initialized
ERROR - 2016-09-23 00:07:05 --> Unable to delete cache file for admin/index/post_add/user
DEBUG - 2016-09-23 00:07:05 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-23 00:07:05 --> Users MX_Controller Initialized
INFO - 2016-09-23 00:07:05 --> Database Driver Class Initialized
ERROR - 2016-09-23 00:07:05 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`koperasi_v1`.`tm_user`, CONSTRAINT `FK_tm_user_tm_level` FOREIGN KEY (`kd_level`) REFERENCES `tm_level` (`kd_level`)) - Invalid query: INSERT INTO `tm_user` (`nama`, `alamat`, `tanggal_lahir`, `tanggal_masuk`, `no_identitas`, `no_hp`, `username`, `password`, `kd_level`) VALUES ('Andrias Sofian Adinata', 'JL. Simpang Bandulan Barat', '1993-09-29', '2016-09-23', '008', '008', 'andrias', '827ccb0eea8a706c4c34a16891f84e7b', 2)
INFO - 2016-09-23 00:07:05 --> Language file loaded: language/english/db_lang.php
INFO - 2016-09-23 00:09:21 --> Config Class Initialized
INFO - 2016-09-23 00:09:21 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:09:21 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:09:21 --> Utf8 Class Initialized
INFO - 2016-09-23 00:09:21 --> URI Class Initialized
INFO - 2016-09-23 00:09:21 --> Router Class Initialized
INFO - 2016-09-23 00:09:21 --> Output Class Initialized
INFO - 2016-09-23 00:09:21 --> Security Class Initialized
DEBUG - 2016-09-23 00:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:09:21 --> Input Class Initialized
INFO - 2016-09-23 00:09:21 --> Language Class Initialized
INFO - 2016-09-23 00:09:21 --> Language Class Initialized
INFO - 2016-09-23 00:09:21 --> Config Class Initialized
INFO - 2016-09-23 00:09:21 --> Loader Class Initialized
INFO - 2016-09-23 00:09:21 --> Helper loaded: url_helper
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:09:21 --> Controller Class Initialized
DEBUG - 2016-09-23 00:09:21 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:09:21 --> Model Class Initialized
INFO - 2016-09-23 00:09:21 --> Model Class Initialized
ERROR - 2016-09-23 00:09:21 --> Unable to delete cache file for admin/index/add/user
DEBUG - 2016-09-23 00:09:21 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-23 00:09:21 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-23 00:09:21 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-23 00:09:21 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/form_user.php
DEBUG - 2016-09-23 00:09:21 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-23 00:09:21 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:09:21 --> Database Driver Class Initialized
DEBUG - 2016-09-23 00:09:21 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-23 00:09:21 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-23 00:09:21 --> Final output sent to browser
DEBUG - 2016-09-23 00:09:21 --> Total execution time: 0.1178
INFO - 2016-09-23 00:09:23 --> Config Class Initialized
INFO - 2016-09-23 00:09:23 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:09:23 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:09:23 --> Utf8 Class Initialized
INFO - 2016-09-23 00:09:23 --> URI Class Initialized
INFO - 2016-09-23 00:09:23 --> Router Class Initialized
INFO - 2016-09-23 00:09:23 --> Output Class Initialized
INFO - 2016-09-23 00:09:23 --> Security Class Initialized
DEBUG - 2016-09-23 00:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:09:23 --> Input Class Initialized
INFO - 2016-09-23 00:09:23 --> Language Class Initialized
ERROR - 2016-09-23 00:09:23 --> 404 Page Not Found: /index
INFO - 2016-09-23 00:09:28 --> Config Class Initialized
INFO - 2016-09-23 00:09:28 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:09:28 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:09:28 --> Utf8 Class Initialized
INFO - 2016-09-23 00:09:28 --> URI Class Initialized
INFO - 2016-09-23 00:09:28 --> Router Class Initialized
INFO - 2016-09-23 00:09:28 --> Output Class Initialized
INFO - 2016-09-23 00:09:28 --> Security Class Initialized
DEBUG - 2016-09-23 00:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:09:28 --> Input Class Initialized
INFO - 2016-09-23 00:09:28 --> Language Class Initialized
ERROR - 2016-09-23 00:09:28 --> 404 Page Not Found: /index
INFO - 2016-09-23 00:11:11 --> Config Class Initialized
INFO - 2016-09-23 00:11:11 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:11:11 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:11:11 --> Utf8 Class Initialized
INFO - 2016-09-23 00:11:11 --> URI Class Initialized
INFO - 2016-09-23 00:11:11 --> Router Class Initialized
INFO - 2016-09-23 00:11:11 --> Output Class Initialized
INFO - 2016-09-23 00:11:11 --> Security Class Initialized
DEBUG - 2016-09-23 00:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:11:11 --> Input Class Initialized
INFO - 2016-09-23 00:11:11 --> Language Class Initialized
INFO - 2016-09-23 00:11:11 --> Language Class Initialized
INFO - 2016-09-23 00:11:11 --> Config Class Initialized
INFO - 2016-09-23 00:11:11 --> Loader Class Initialized
INFO - 2016-09-23 00:11:11 --> Helper loaded: url_helper
INFO - 2016-09-23 00:11:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:11:11 --> Controller Class Initialized
DEBUG - 2016-09-23 00:11:11 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:11:11 --> Model Class Initialized
INFO - 2016-09-23 00:11:11 --> Model Class Initialized
ERROR - 2016-09-23 00:11:11 --> Unable to delete cache file for admin/index/post_add/user
DEBUG - 2016-09-23 00:11:11 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-23 00:11:11 --> Users MX_Controller Initialized
INFO - 2016-09-23 00:11:11 --> Database Driver Class Initialized
ERROR - 2016-09-23 00:11:11 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`koperasi_v1`.`tm_user`, CONSTRAINT `FK_tm_user_tm_level` FOREIGN KEY (`kd_level`) REFERENCES `tm_level` (`kd_level`)) - Invalid query: INSERT INTO `tm_user` (`nama`, `alamat`, `tanggal_lahir`, `tanggal_masuk`, `no_identitas`, `no_hp`, `username`, `password`, `kd_level`) VALUES ('Andrias Sofian Adinata', 'Jl. Simpang Bandulan Barat', '1992-09-29', '2016-09-23', '008', '008', 'andrias', '827ccb0eea8a706c4c34a16891f84e7b', 2)
INFO - 2016-09-23 00:11:11 --> Language file loaded: language/english/db_lang.php
INFO - 2016-09-23 00:11:53 --> Config Class Initialized
INFO - 2016-09-23 00:11:53 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:11:53 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:11:53 --> Utf8 Class Initialized
INFO - 2016-09-23 00:11:53 --> URI Class Initialized
INFO - 2016-09-23 00:11:53 --> Router Class Initialized
INFO - 2016-09-23 00:11:53 --> Output Class Initialized
INFO - 2016-09-23 00:11:53 --> Security Class Initialized
DEBUG - 2016-09-23 00:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:11:53 --> Input Class Initialized
INFO - 2016-09-23 00:11:53 --> Language Class Initialized
INFO - 2016-09-23 00:11:53 --> Language Class Initialized
INFO - 2016-09-23 00:11:53 --> Config Class Initialized
INFO - 2016-09-23 00:11:53 --> Loader Class Initialized
INFO - 2016-09-23 00:11:53 --> Helper loaded: url_helper
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:11:53 --> Controller Class Initialized
DEBUG - 2016-09-23 00:11:53 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:11:53 --> Model Class Initialized
INFO - 2016-09-23 00:11:53 --> Model Class Initialized
ERROR - 2016-09-23 00:11:53 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-23 00:11:53 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-23 00:11:53 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-23 00:11:53 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-23 00:11:53 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-23 00:11:53 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-23 00:11:53 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:11:53 --> Database Driver Class Initialized
DEBUG - 2016-09-23 00:11:53 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-23 00:11:53 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-23 00:11:53 --> Final output sent to browser
DEBUG - 2016-09-23 00:11:53 --> Total execution time: 0.0977
INFO - 2016-09-23 00:11:56 --> Config Class Initialized
INFO - 2016-09-23 00:11:56 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:11:56 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:11:56 --> Utf8 Class Initialized
INFO - 2016-09-23 00:11:56 --> URI Class Initialized
INFO - 2016-09-23 00:11:56 --> Router Class Initialized
INFO - 2016-09-23 00:11:56 --> Output Class Initialized
INFO - 2016-09-23 00:11:56 --> Security Class Initialized
DEBUG - 2016-09-23 00:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:11:56 --> Input Class Initialized
INFO - 2016-09-23 00:11:56 --> Language Class Initialized
ERROR - 2016-09-23 00:11:56 --> 404 Page Not Found: /index
INFO - 2016-09-23 00:11:59 --> Config Class Initialized
INFO - 2016-09-23 00:11:59 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:11:59 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:11:59 --> Utf8 Class Initialized
INFO - 2016-09-23 00:11:59 --> URI Class Initialized
INFO - 2016-09-23 00:11:59 --> Router Class Initialized
INFO - 2016-09-23 00:11:59 --> Output Class Initialized
INFO - 2016-09-23 00:11:59 --> Security Class Initialized
DEBUG - 2016-09-23 00:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:11:59 --> Input Class Initialized
INFO - 2016-09-23 00:11:59 --> Language Class Initialized
ERROR - 2016-09-23 00:11:59 --> 404 Page Not Found: /index
INFO - 2016-09-23 00:12:24 --> Config Class Initialized
INFO - 2016-09-23 00:12:24 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:12:24 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:12:24 --> Utf8 Class Initialized
INFO - 2016-09-23 00:12:24 --> URI Class Initialized
INFO - 2016-09-23 00:12:24 --> Router Class Initialized
INFO - 2016-09-23 00:12:24 --> Output Class Initialized
INFO - 2016-09-23 00:12:24 --> Security Class Initialized
DEBUG - 2016-09-23 00:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:12:24 --> Input Class Initialized
INFO - 2016-09-23 00:12:24 --> Language Class Initialized
INFO - 2016-09-23 00:12:24 --> Language Class Initialized
INFO - 2016-09-23 00:12:24 --> Config Class Initialized
INFO - 2016-09-23 00:12:24 --> Loader Class Initialized
INFO - 2016-09-23 00:12:24 --> Helper loaded: url_helper
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:12:24 --> Controller Class Initialized
DEBUG - 2016-09-23 00:12:24 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:12:24 --> Model Class Initialized
INFO - 2016-09-23 00:12:24 --> Model Class Initialized
ERROR - 2016-09-23 00:12:24 --> Unable to delete cache file for admin/index/add/user
DEBUG - 2016-09-23 00:12:24 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-23 00:12:24 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-23 00:12:24 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-23 00:12:24 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/form_user.php
DEBUG - 2016-09-23 00:12:24 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-23 00:12:24 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:12:24 --> Database Driver Class Initialized
DEBUG - 2016-09-23 00:12:24 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-23 00:12:24 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-23 00:12:24 --> Final output sent to browser
DEBUG - 2016-09-23 00:12:24 --> Total execution time: 0.0923
INFO - 2016-09-23 00:12:25 --> Config Class Initialized
INFO - 2016-09-23 00:12:25 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:12:25 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:12:25 --> Utf8 Class Initialized
INFO - 2016-09-23 00:12:25 --> URI Class Initialized
INFO - 2016-09-23 00:12:25 --> Router Class Initialized
INFO - 2016-09-23 00:12:25 --> Output Class Initialized
INFO - 2016-09-23 00:12:25 --> Security Class Initialized
DEBUG - 2016-09-23 00:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:12:25 --> Input Class Initialized
INFO - 2016-09-23 00:12:25 --> Language Class Initialized
ERROR - 2016-09-23 00:12:25 --> 404 Page Not Found: /index
INFO - 2016-09-23 00:12:33 --> Config Class Initialized
INFO - 2016-09-23 00:12:33 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:12:33 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:12:33 --> Utf8 Class Initialized
INFO - 2016-09-23 00:12:33 --> URI Class Initialized
INFO - 2016-09-23 00:12:33 --> Router Class Initialized
INFO - 2016-09-23 00:12:33 --> Output Class Initialized
INFO - 2016-09-23 00:12:33 --> Security Class Initialized
DEBUG - 2016-09-23 00:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:12:33 --> Input Class Initialized
INFO - 2016-09-23 00:12:33 --> Language Class Initialized
ERROR - 2016-09-23 00:12:33 --> 404 Page Not Found: /index
INFO - 2016-09-23 00:13:06 --> Config Class Initialized
INFO - 2016-09-23 00:13:06 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:13:06 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:13:06 --> Utf8 Class Initialized
INFO - 2016-09-23 00:13:06 --> URI Class Initialized
INFO - 2016-09-23 00:13:06 --> Router Class Initialized
INFO - 2016-09-23 00:13:06 --> Output Class Initialized
INFO - 2016-09-23 00:13:06 --> Security Class Initialized
DEBUG - 2016-09-23 00:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:13:06 --> Input Class Initialized
INFO - 2016-09-23 00:13:06 --> Language Class Initialized
INFO - 2016-09-23 00:13:06 --> Language Class Initialized
INFO - 2016-09-23 00:13:06 --> Config Class Initialized
INFO - 2016-09-23 00:13:06 --> Loader Class Initialized
INFO - 2016-09-23 00:13:06 --> Helper loaded: url_helper
INFO - 2016-09-23 00:13:06 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:13:06 --> Controller Class Initialized
DEBUG - 2016-09-23 00:13:06 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:13:06 --> Model Class Initialized
INFO - 2016-09-23 00:13:06 --> Model Class Initialized
ERROR - 2016-09-23 00:13:06 --> Unable to delete cache file for admin/index/post_add/user
DEBUG - 2016-09-23 00:13:06 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-23 00:13:06 --> Users MX_Controller Initialized
INFO - 2016-09-23 00:13:06 --> Final output sent to browser
DEBUG - 2016-09-23 00:13:06 --> Total execution time: 0.0446
INFO - 2016-09-23 00:13:19 --> Config Class Initialized
INFO - 2016-09-23 00:13:19 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:13:19 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:13:19 --> Utf8 Class Initialized
INFO - 2016-09-23 00:13:19 --> URI Class Initialized
INFO - 2016-09-23 00:13:19 --> Router Class Initialized
INFO - 2016-09-23 00:13:19 --> Output Class Initialized
INFO - 2016-09-23 00:13:19 --> Security Class Initialized
DEBUG - 2016-09-23 00:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:13:19 --> Input Class Initialized
INFO - 2016-09-23 00:13:19 --> Language Class Initialized
INFO - 2016-09-23 00:13:19 --> Language Class Initialized
INFO - 2016-09-23 00:13:19 --> Config Class Initialized
INFO - 2016-09-23 00:13:19 --> Loader Class Initialized
INFO - 2016-09-23 00:13:19 --> Helper loaded: url_helper
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:13:19 --> Controller Class Initialized
DEBUG - 2016-09-23 00:13:19 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:13:19 --> Model Class Initialized
INFO - 2016-09-23 00:13:19 --> Model Class Initialized
ERROR - 2016-09-23 00:13:19 --> Unable to delete cache file for admin/index/data/user
DEBUG - 2016-09-23 00:13:19 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-23 00:13:19 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-23 00:13:19 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-23 00:13:19 --> File already loaded: /home/koperasi/public_html/application/controllers/../modules/user/controllers/Users.php
DEBUG - 2016-09-23 00:13:19 --> Users MX_Controller Initialized
DEBUG - 2016-09-23 00:13:19 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/list_user.php
DEBUG - 2016-09-23 00:13:19 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-23 00:13:19 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:19 --> Database Driver Class Initialized
DEBUG - 2016-09-23 00:13:19 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-23 00:13:19 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-23 00:13:19 --> Final output sent to browser
DEBUG - 2016-09-23 00:13:19 --> Total execution time: 0.0989
INFO - 2016-09-23 00:13:20 --> Config Class Initialized
INFO - 2016-09-23 00:13:20 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:13:20 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:13:20 --> Utf8 Class Initialized
INFO - 2016-09-23 00:13:20 --> URI Class Initialized
INFO - 2016-09-23 00:13:20 --> Router Class Initialized
INFO - 2016-09-23 00:13:20 --> Output Class Initialized
INFO - 2016-09-23 00:13:20 --> Security Class Initialized
DEBUG - 2016-09-23 00:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:13:20 --> Input Class Initialized
INFO - 2016-09-23 00:13:20 --> Language Class Initialized
ERROR - 2016-09-23 00:13:20 --> 404 Page Not Found: /index
INFO - 2016-09-23 00:13:21 --> Config Class Initialized
INFO - 2016-09-23 00:13:21 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:13:21 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:13:21 --> Utf8 Class Initialized
INFO - 2016-09-23 00:13:21 --> URI Class Initialized
INFO - 2016-09-23 00:13:21 --> Router Class Initialized
INFO - 2016-09-23 00:13:21 --> Output Class Initialized
INFO - 2016-09-23 00:13:21 --> Security Class Initialized
DEBUG - 2016-09-23 00:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:13:21 --> Input Class Initialized
INFO - 2016-09-23 00:13:21 --> Language Class Initialized
ERROR - 2016-09-23 00:13:21 --> 404 Page Not Found: /index
INFO - 2016-09-23 00:13:41 --> Config Class Initialized
INFO - 2016-09-23 00:13:41 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:13:41 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:13:41 --> Utf8 Class Initialized
INFO - 2016-09-23 00:13:41 --> URI Class Initialized
INFO - 2016-09-23 00:13:41 --> Router Class Initialized
INFO - 2016-09-23 00:13:41 --> Output Class Initialized
INFO - 2016-09-23 00:13:41 --> Security Class Initialized
DEBUG - 2016-09-23 00:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:13:41 --> Input Class Initialized
INFO - 2016-09-23 00:13:41 --> Language Class Initialized
INFO - 2016-09-23 00:13:41 --> Language Class Initialized
INFO - 2016-09-23 00:13:41 --> Config Class Initialized
INFO - 2016-09-23 00:13:41 --> Loader Class Initialized
INFO - 2016-09-23 00:13:41 --> Helper loaded: url_helper
INFO - 2016-09-23 00:13:41 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:13:41 --> Controller Class Initialized
DEBUG - 2016-09-23 00:13:41 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:13:41 --> Model Class Initialized
INFO - 2016-09-23 00:13:41 --> Model Class Initialized
ERROR - 2016-09-23 00:13:41 --> Unable to delete cache file for admin/index/post_add/user
DEBUG - 2016-09-23 00:13:41 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-23 00:13:41 --> Users MX_Controller Initialized
INFO - 2016-09-23 00:13:41 --> Database Driver Class Initialized
ERROR - 2016-09-23 00:13:41 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`koperasi_v1`.`tm_user`, CONSTRAINT `FK_tm_user_tm_level` FOREIGN KEY (`kd_level`) REFERENCES `tm_level` (`kd_level`)) - Invalid query: INSERT INTO `tm_user` (`nama`, `alamat`, `tanggal_lahir`, `tanggal_masuk`, `no_identitas`, `no_hp`, `username`, `password`, `kd_level`) VALUES ('VIvi Atika Unnisyah', 'JL. BAUKSIT 31B', '1993-02-20', '2016-09-23', '35730320029300112', '081556617741', 'admin', '827ccb0eea8a706c4c34a16891f84e7b', 2)
INFO - 2016-09-23 00:13:41 --> Language file loaded: language/english/db_lang.php
INFO - 2016-09-23 00:13:57 --> Config Class Initialized
INFO - 2016-09-23 00:13:57 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:13:57 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:13:57 --> Utf8 Class Initialized
INFO - 2016-09-23 00:13:57 --> URI Class Initialized
INFO - 2016-09-23 00:13:57 --> Router Class Initialized
INFO - 2016-09-23 00:13:57 --> Output Class Initialized
INFO - 2016-09-23 00:13:57 --> Security Class Initialized
DEBUG - 2016-09-23 00:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:13:57 --> Input Class Initialized
INFO - 2016-09-23 00:13:57 --> Language Class Initialized
INFO - 2016-09-23 00:13:57 --> Language Class Initialized
INFO - 2016-09-23 00:13:57 --> Config Class Initialized
INFO - 2016-09-23 00:13:57 --> Loader Class Initialized
INFO - 2016-09-23 00:13:57 --> Helper loaded: url_helper
INFO - 2016-09-23 00:13:57 --> Database Driver Class Initialized
INFO - 2016-09-23 00:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:13:57 --> Controller Class Initialized
DEBUG - 2016-09-23 00:13:57 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:13:57 --> Model Class Initialized
INFO - 2016-09-23 00:13:57 --> Model Class Initialized
ERROR - 2016-09-23 00:13:57 --> Unable to delete cache file for admin/index/post_add/user
DEBUG - 2016-09-23 00:13:57 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-23 00:13:57 --> Users MX_Controller Initialized
INFO - 2016-09-23 00:13:57 --> Database Driver Class Initialized
ERROR - 2016-09-23 00:13:57 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`koperasi_v1`.`tm_user`, CONSTRAINT `FK_tm_user_tm_level` FOREIGN KEY (`kd_level`) REFERENCES `tm_level` (`kd_level`)) - Invalid query: INSERT INTO `tm_user` (`nama`, `alamat`, `tanggal_lahir`, `tanggal_masuk`, `no_identitas`, `no_hp`, `username`, `password`, `kd_level`) VALUES ('VIvi Atika Unnisyah', 'JL. BAUKSIT 31B', '1993-02-20', '2016-09-23', '35730320029300112', '081556617741', 'admin', '827ccb0eea8a706c4c34a16891f84e7b', 2)
INFO - 2016-09-23 00:13:57 --> Language file loaded: language/english/db_lang.php
INFO - 2016-09-23 00:14:47 --> Config Class Initialized
INFO - 2016-09-23 00:14:47 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:14:47 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:14:47 --> Utf8 Class Initialized
INFO - 2016-09-23 00:14:47 --> URI Class Initialized
INFO - 2016-09-23 00:14:47 --> Router Class Initialized
INFO - 2016-09-23 00:14:47 --> Output Class Initialized
INFO - 2016-09-23 00:14:47 --> Security Class Initialized
DEBUG - 2016-09-23 00:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:14:47 --> Input Class Initialized
INFO - 2016-09-23 00:14:47 --> Language Class Initialized
INFO - 2016-09-23 00:14:47 --> Language Class Initialized
INFO - 2016-09-23 00:14:47 --> Config Class Initialized
INFO - 2016-09-23 00:14:47 --> Loader Class Initialized
INFO - 2016-09-23 00:14:47 --> Helper loaded: url_helper
INFO - 2016-09-23 00:14:47 --> Database Driver Class Initialized
INFO - 2016-09-23 00:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:14:47 --> Controller Class Initialized
DEBUG - 2016-09-23 00:14:47 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:14:47 --> Model Class Initialized
INFO - 2016-09-23 00:14:47 --> Model Class Initialized
ERROR - 2016-09-23 00:14:47 --> Unable to delete cache file for admin/index/post_add/user
DEBUG - 2016-09-23 00:14:47 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-23 00:14:47 --> Users MX_Controller Initialized
INFO - 2016-09-23 00:14:47 --> Database Driver Class Initialized
ERROR - 2016-09-23 00:14:47 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`koperasi_v1`.`tm_user`, CONSTRAINT `FK_tm_user_tm_level` FOREIGN KEY (`kd_level`) REFERENCES `tm_level` (`kd_level`)) - Invalid query: INSERT INTO `tm_user` (`nama`, `alamat`, `tanggal_lahir`, `tanggal_masuk`, `no_identitas`, `no_hp`, `username`, `password`, `kd_level`) VALUES ('VIvi Atika Unnisyah', 'JL. BAUKSIT 31B', '1993-02-20', '2016-09-23', '357303200293001', '081556617741', 'admin', '827ccb0eea8a706c4c34a16891f84e7b', 2)
INFO - 2016-09-23 00:14:47 --> Language file loaded: language/english/db_lang.php
INFO - 2016-09-23 00:17:27 --> Config Class Initialized
INFO - 2016-09-23 00:17:27 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:17:27 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:17:27 --> Utf8 Class Initialized
INFO - 2016-09-23 00:17:27 --> URI Class Initialized
DEBUG - 2016-09-23 00:17:27 --> No URI present. Default controller set.
INFO - 2016-09-23 00:17:27 --> Router Class Initialized
INFO - 2016-09-23 00:17:27 --> Output Class Initialized
INFO - 2016-09-23 00:17:27 --> Security Class Initialized
DEBUG - 2016-09-23 00:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:17:27 --> Input Class Initialized
INFO - 2016-09-23 00:17:27 --> Language Class Initialized
INFO - 2016-09-23 00:17:27 --> Language Class Initialized
INFO - 2016-09-23 00:17:27 --> Config Class Initialized
INFO - 2016-09-23 00:17:27 --> Loader Class Initialized
INFO - 2016-09-23 00:17:27 --> Helper loaded: url_helper
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:17:27 --> Controller Class Initialized
DEBUG - 2016-09-23 00:17:27 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:17:27 --> Model Class Initialized
INFO - 2016-09-23 00:17:27 --> Model Class Initialized
ERROR - 2016-09-23 00:17:27 --> Unable to delete cache file for 
DEBUG - 2016-09-23 00:17:27 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-23 00:17:27 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-23 00:17:27 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-23 00:17:27 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-23 00:17:27 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-23 00:17:27 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
DEBUG - 2016-09-23 00:17:27 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-23 00:17:27 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-23 00:17:27 --> Final output sent to browser
DEBUG - 2016-09-23 00:17:27 --> Total execution time: 0.1033
INFO - 2016-09-23 00:17:27 --> Config Class Initialized
INFO - 2016-09-23 00:17:27 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:17:27 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:17:27 --> Utf8 Class Initialized
INFO - 2016-09-23 00:17:27 --> URI Class Initialized
INFO - 2016-09-23 00:17:27 --> Router Class Initialized
INFO - 2016-09-23 00:17:27 --> Output Class Initialized
INFO - 2016-09-23 00:17:27 --> Security Class Initialized
DEBUG - 2016-09-23 00:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:17:27 --> Input Class Initialized
INFO - 2016-09-23 00:17:27 --> Language Class Initialized
INFO - 2016-09-23 00:17:27 --> Language Class Initialized
INFO - 2016-09-23 00:17:27 --> Config Class Initialized
INFO - 2016-09-23 00:17:27 --> Loader Class Initialized
INFO - 2016-09-23 00:17:27 --> Helper loaded: url_helper
INFO - 2016-09-23 00:17:27 --> Database Driver Class Initialized
INFO - 2016-09-23 00:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:17:27 --> Controller Class Initialized
DEBUG - 2016-09-23 00:17:27 --> login MX_Controller Initialized
INFO - 2016-09-23 00:17:27 --> Model Class Initialized
INFO - 2016-09-23 00:17:27 --> Model Class Initialized
DEBUG - 2016-09-23 00:17:27 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-23 00:17:27 --> Final output sent to browser
DEBUG - 2016-09-23 00:17:27 --> Total execution time: 0.0232
INFO - 2016-09-23 00:18:10 --> Config Class Initialized
INFO - 2016-09-23 00:18:10 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:18:10 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:18:10 --> Utf8 Class Initialized
INFO - 2016-09-23 00:18:10 --> URI Class Initialized
INFO - 2016-09-23 00:18:10 --> Router Class Initialized
INFO - 2016-09-23 00:18:10 --> Output Class Initialized
INFO - 2016-09-23 00:18:10 --> Security Class Initialized
DEBUG - 2016-09-23 00:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:18:10 --> Input Class Initialized
INFO - 2016-09-23 00:18:10 --> Language Class Initialized
INFO - 2016-09-23 00:18:10 --> Language Class Initialized
INFO - 2016-09-23 00:18:10 --> Config Class Initialized
INFO - 2016-09-23 00:18:10 --> Loader Class Initialized
INFO - 2016-09-23 00:18:10 --> Helper loaded: url_helper
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:18:10 --> Controller Class Initialized
DEBUG - 2016-09-23 00:18:10 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:18:10 --> Model Class Initialized
INFO - 2016-09-23 00:18:10 --> Model Class Initialized
ERROR - 2016-09-23 00:18:10 --> Unable to delete cache file for admin/index/add/user
DEBUG - 2016-09-23 00:18:10 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-23 00:18:10 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-23 00:18:10 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-23 00:18:10 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/form_user.php
DEBUG - 2016-09-23 00:18:10 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-23 00:18:10 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:18:10 --> Database Driver Class Initialized
DEBUG - 2016-09-23 00:18:10 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-23 00:18:10 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-23 00:18:10 --> Final output sent to browser
DEBUG - 2016-09-23 00:18:10 --> Total execution time: 0.1185
INFO - 2016-09-23 00:18:11 --> Config Class Initialized
INFO - 2016-09-23 00:18:11 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:18:11 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:18:11 --> Utf8 Class Initialized
INFO - 2016-09-23 00:18:11 --> URI Class Initialized
INFO - 2016-09-23 00:18:11 --> Router Class Initialized
INFO - 2016-09-23 00:18:11 --> Output Class Initialized
INFO - 2016-09-23 00:18:11 --> Security Class Initialized
DEBUG - 2016-09-23 00:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:18:11 --> Input Class Initialized
INFO - 2016-09-23 00:18:11 --> Language Class Initialized
ERROR - 2016-09-23 00:18:11 --> 404 Page Not Found: /index
INFO - 2016-09-23 00:19:15 --> Config Class Initialized
INFO - 2016-09-23 00:19:15 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:19:15 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:19:15 --> Utf8 Class Initialized
INFO - 2016-09-23 00:19:15 --> URI Class Initialized
INFO - 2016-09-23 00:19:15 --> Router Class Initialized
INFO - 2016-09-23 00:19:15 --> Output Class Initialized
INFO - 2016-09-23 00:19:15 --> Security Class Initialized
DEBUG - 2016-09-23 00:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:19:15 --> Input Class Initialized
INFO - 2016-09-23 00:19:15 --> Language Class Initialized
INFO - 2016-09-23 00:19:15 --> Language Class Initialized
INFO - 2016-09-23 00:19:15 --> Config Class Initialized
INFO - 2016-09-23 00:19:15 --> Loader Class Initialized
INFO - 2016-09-23 00:19:15 --> Helper loaded: url_helper
INFO - 2016-09-23 00:19:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:19:15 --> Controller Class Initialized
DEBUG - 2016-09-23 00:19:15 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:19:15 --> Model Class Initialized
INFO - 2016-09-23 00:19:15 --> Model Class Initialized
ERROR - 2016-09-23 00:19:15 --> Unable to delete cache file for admin/index/post_add/user
DEBUG - 2016-09-23 00:19:15 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-23 00:19:15 --> Users MX_Controller Initialized
INFO - 2016-09-23 00:19:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:15 --> Final output sent to browser
DEBUG - 2016-09-23 00:19:15 --> Total execution time: 0.0334
INFO - 2016-09-23 00:19:16 --> Config Class Initialized
INFO - 2016-09-23 00:19:16 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:19:16 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:19:16 --> Utf8 Class Initialized
INFO - 2016-09-23 00:19:16 --> URI Class Initialized
INFO - 2016-09-23 00:19:16 --> Router Class Initialized
INFO - 2016-09-23 00:19:16 --> Output Class Initialized
INFO - 2016-09-23 00:19:16 --> Security Class Initialized
DEBUG - 2016-09-23 00:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:19:16 --> Input Class Initialized
INFO - 2016-09-23 00:19:16 --> Language Class Initialized
INFO - 2016-09-23 00:19:16 --> Language Class Initialized
INFO - 2016-09-23 00:19:16 --> Config Class Initialized
INFO - 2016-09-23 00:19:16 --> Loader Class Initialized
INFO - 2016-09-23 00:19:16 --> Helper loaded: url_helper
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:19:16 --> Controller Class Initialized
DEBUG - 2016-09-23 00:19:16 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:19:16 --> Model Class Initialized
INFO - 2016-09-23 00:19:16 --> Model Class Initialized
ERROR - 2016-09-23 00:19:16 --> Unable to delete cache file for admin/index/data/user
DEBUG - 2016-09-23 00:19:16 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-23 00:19:16 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-23 00:19:16 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-23 00:19:16 --> File already loaded: /home/koperasi/public_html/application/controllers/../modules/user/controllers/Users.php
DEBUG - 2016-09-23 00:19:16 --> Users MX_Controller Initialized
DEBUG - 2016-09-23 00:19:16 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/list_user.php
DEBUG - 2016-09-23 00:19:16 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-23 00:19:16 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:16 --> Database Driver Class Initialized
DEBUG - 2016-09-23 00:19:16 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-23 00:19:16 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-23 00:19:16 --> Final output sent to browser
DEBUG - 2016-09-23 00:19:16 --> Total execution time: 0.1034
INFO - 2016-09-23 00:19:16 --> Config Class Initialized
INFO - 2016-09-23 00:19:16 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:19:16 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:19:16 --> Utf8 Class Initialized
INFO - 2016-09-23 00:19:16 --> URI Class Initialized
INFO - 2016-09-23 00:19:16 --> Router Class Initialized
INFO - 2016-09-23 00:19:16 --> Output Class Initialized
INFO - 2016-09-23 00:19:16 --> Security Class Initialized
DEBUG - 2016-09-23 00:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:19:16 --> Input Class Initialized
INFO - 2016-09-23 00:19:16 --> Language Class Initialized
ERROR - 2016-09-23 00:19:16 --> 404 Page Not Found: /index
INFO - 2016-09-23 00:19:17 --> Config Class Initialized
INFO - 2016-09-23 00:19:17 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:19:17 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:19:17 --> Utf8 Class Initialized
INFO - 2016-09-23 00:19:17 --> URI Class Initialized
INFO - 2016-09-23 00:19:17 --> Router Class Initialized
INFO - 2016-09-23 00:19:17 --> Output Class Initialized
INFO - 2016-09-23 00:19:17 --> Security Class Initialized
DEBUG - 2016-09-23 00:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:19:17 --> Input Class Initialized
INFO - 2016-09-23 00:19:17 --> Language Class Initialized
ERROR - 2016-09-23 00:19:17 --> 404 Page Not Found: /index
INFO - 2016-09-23 00:19:21 --> Config Class Initialized
INFO - 2016-09-23 00:19:21 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:19:21 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:19:21 --> Utf8 Class Initialized
INFO - 2016-09-23 00:19:21 --> URI Class Initialized
INFO - 2016-09-23 00:19:21 --> Router Class Initialized
INFO - 2016-09-23 00:19:21 --> Output Class Initialized
INFO - 2016-09-23 00:19:21 --> Security Class Initialized
DEBUG - 2016-09-23 00:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:19:21 --> Input Class Initialized
INFO - 2016-09-23 00:19:21 --> Language Class Initialized
INFO - 2016-09-23 00:19:21 --> Language Class Initialized
INFO - 2016-09-23 00:19:21 --> Config Class Initialized
INFO - 2016-09-23 00:19:21 --> Loader Class Initialized
INFO - 2016-09-23 00:19:21 --> Helper loaded: url_helper
INFO - 2016-09-23 00:19:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:19:21 --> Controller Class Initialized
DEBUG - 2016-09-23 00:19:21 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:19:21 --> Model Class Initialized
INFO - 2016-09-23 00:19:21 --> Model Class Initialized
ERROR - 2016-09-23 00:19:21 --> Unable to delete cache file for admin/index/post_get/user/0ade7c2cf97f75d009975f4d720d1fa6c19f4897
DEBUG - 2016-09-23 00:19:21 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-23 00:19:21 --> Users MX_Controller Initialized
INFO - 2016-09-23 00:19:21 --> Final output sent to browser
DEBUG - 2016-09-23 00:19:21 --> Total execution time: 0.0287
INFO - 2016-09-23 00:19:55 --> Config Class Initialized
INFO - 2016-09-23 00:19:55 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:19:55 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:19:55 --> Utf8 Class Initialized
INFO - 2016-09-23 00:19:55 --> URI Class Initialized
INFO - 2016-09-23 00:19:55 --> Router Class Initialized
INFO - 2016-09-23 00:19:55 --> Output Class Initialized
INFO - 2016-09-23 00:19:55 --> Security Class Initialized
DEBUG - 2016-09-23 00:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:19:55 --> Input Class Initialized
INFO - 2016-09-23 00:19:55 --> Language Class Initialized
INFO - 2016-09-23 00:19:55 --> Language Class Initialized
INFO - 2016-09-23 00:19:55 --> Config Class Initialized
INFO - 2016-09-23 00:19:55 --> Loader Class Initialized
INFO - 2016-09-23 00:19:55 --> Helper loaded: url_helper
INFO - 2016-09-23 00:19:55 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:19:55 --> Controller Class Initialized
DEBUG - 2016-09-23 00:19:55 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:19:55 --> Model Class Initialized
INFO - 2016-09-23 00:19:55 --> Model Class Initialized
ERROR - 2016-09-23 00:19:55 --> Unable to delete cache file for admin/index/logout
INFO - 2016-09-23 00:19:55 --> Final output sent to browser
DEBUG - 2016-09-23 00:19:55 --> Total execution time: 0.0336
INFO - 2016-09-23 00:19:55 --> Config Class Initialized
INFO - 2016-09-23 00:19:55 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:19:55 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:19:55 --> Utf8 Class Initialized
INFO - 2016-09-23 00:19:55 --> URI Class Initialized
INFO - 2016-09-23 00:19:55 --> Router Class Initialized
INFO - 2016-09-23 00:19:55 --> Output Class Initialized
INFO - 2016-09-23 00:19:55 --> Security Class Initialized
DEBUG - 2016-09-23 00:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:19:55 --> Input Class Initialized
INFO - 2016-09-23 00:19:55 --> Language Class Initialized
INFO - 2016-09-23 00:19:55 --> Language Class Initialized
INFO - 2016-09-23 00:19:55 --> Config Class Initialized
INFO - 2016-09-23 00:19:55 --> Loader Class Initialized
INFO - 2016-09-23 00:19:55 --> Helper loaded: url_helper
INFO - 2016-09-23 00:19:55 --> Database Driver Class Initialized
INFO - 2016-09-23 00:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:19:55 --> Controller Class Initialized
DEBUG - 2016-09-23 00:19:55 --> login MX_Controller Initialized
INFO - 2016-09-23 00:19:55 --> Model Class Initialized
INFO - 2016-09-23 00:19:55 --> Model Class Initialized
DEBUG - 2016-09-23 00:19:55 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-23 00:19:55 --> Final output sent to browser
DEBUG - 2016-09-23 00:19:55 --> Total execution time: 0.0279
INFO - 2016-09-23 00:20:00 --> Config Class Initialized
INFO - 2016-09-23 00:20:00 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:20:00 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:20:00 --> Utf8 Class Initialized
INFO - 2016-09-23 00:20:00 --> URI Class Initialized
INFO - 2016-09-23 00:20:00 --> Router Class Initialized
INFO - 2016-09-23 00:20:00 --> Output Class Initialized
INFO - 2016-09-23 00:20:00 --> Security Class Initialized
DEBUG - 2016-09-23 00:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:20:00 --> Input Class Initialized
INFO - 2016-09-23 00:20:00 --> Language Class Initialized
INFO - 2016-09-23 00:20:00 --> Language Class Initialized
INFO - 2016-09-23 00:20:00 --> Config Class Initialized
INFO - 2016-09-23 00:20:00 --> Loader Class Initialized
INFO - 2016-09-23 00:20:00 --> Helper loaded: url_helper
INFO - 2016-09-23 00:20:00 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:20:00 --> Controller Class Initialized
DEBUG - 2016-09-23 00:20:00 --> login MX_Controller Initialized
INFO - 2016-09-23 00:20:00 --> Model Class Initialized
INFO - 2016-09-23 00:20:00 --> Model Class Initialized
INFO - 2016-09-23 00:20:00 --> Final output sent to browser
DEBUG - 2016-09-23 00:20:00 --> Total execution time: 0.0272
INFO - 2016-09-23 00:20:00 --> Config Class Initialized
INFO - 2016-09-23 00:20:00 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:20:00 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:20:00 --> Utf8 Class Initialized
INFO - 2016-09-23 00:20:00 --> URI Class Initialized
INFO - 2016-09-23 00:20:00 --> Router Class Initialized
INFO - 2016-09-23 00:20:00 --> Output Class Initialized
INFO - 2016-09-23 00:20:00 --> Security Class Initialized
DEBUG - 2016-09-23 00:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:20:00 --> Input Class Initialized
INFO - 2016-09-23 00:20:00 --> Language Class Initialized
INFO - 2016-09-23 00:20:00 --> Language Class Initialized
INFO - 2016-09-23 00:20:00 --> Config Class Initialized
INFO - 2016-09-23 00:20:00 --> Loader Class Initialized
INFO - 2016-09-23 00:20:00 --> Helper loaded: url_helper
INFO - 2016-09-23 00:20:00 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:20:00 --> Controller Class Initialized
DEBUG - 2016-09-23 00:20:00 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:20:00 --> Model Class Initialized
INFO - 2016-09-23 00:20:00 --> Model Class Initialized
ERROR - 2016-09-23 00:20:00 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-23 00:20:00 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-23 00:20:00 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-23 00:20:00 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-23 00:20:00 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-23 00:20:00 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-23 00:20:00 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-23 00:20:00 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
INFO - 2016-09-23 00:20:01 --> Database Driver Class Initialized
DEBUG - 2016-09-23 00:20:01 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-23 00:20:01 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-23 00:20:01 --> Final output sent to browser
DEBUG - 2016-09-23 00:20:01 --> Total execution time: 0.1056
INFO - 2016-09-23 00:20:01 --> Config Class Initialized
INFO - 2016-09-23 00:20:01 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:20:01 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:20:01 --> Utf8 Class Initialized
INFO - 2016-09-23 00:20:01 --> URI Class Initialized
INFO - 2016-09-23 00:20:01 --> Router Class Initialized
INFO - 2016-09-23 00:20:01 --> Output Class Initialized
INFO - 2016-09-23 00:20:01 --> Security Class Initialized
DEBUG - 2016-09-23 00:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:20:01 --> Input Class Initialized
INFO - 2016-09-23 00:20:01 --> Language Class Initialized
ERROR - 2016-09-23 00:20:01 --> 404 Page Not Found: /index
INFO - 2016-09-23 00:20:01 --> Config Class Initialized
INFO - 2016-09-23 00:20:01 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:20:01 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:20:01 --> Utf8 Class Initialized
INFO - 2016-09-23 00:20:01 --> URI Class Initialized
INFO - 2016-09-23 00:20:01 --> Router Class Initialized
INFO - 2016-09-23 00:20:01 --> Output Class Initialized
INFO - 2016-09-23 00:20:01 --> Security Class Initialized
DEBUG - 2016-09-23 00:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:20:01 --> Input Class Initialized
INFO - 2016-09-23 00:20:01 --> Language Class Initialized
ERROR - 2016-09-23 00:20:01 --> 404 Page Not Found: /index
INFO - 2016-09-23 00:21:09 --> Config Class Initialized
INFO - 2016-09-23 00:21:09 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:21:09 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:21:09 --> Utf8 Class Initialized
INFO - 2016-09-23 00:21:09 --> URI Class Initialized
INFO - 2016-09-23 00:21:09 --> Router Class Initialized
INFO - 2016-09-23 00:21:09 --> Output Class Initialized
INFO - 2016-09-23 00:21:09 --> Security Class Initialized
DEBUG - 2016-09-23 00:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:21:09 --> Input Class Initialized
INFO - 2016-09-23 00:21:09 --> Language Class Initialized
INFO - 2016-09-23 00:21:09 --> Language Class Initialized
INFO - 2016-09-23 00:21:09 --> Config Class Initialized
INFO - 2016-09-23 00:21:09 --> Loader Class Initialized
INFO - 2016-09-23 00:21:09 --> Helper loaded: url_helper
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:21:09 --> Controller Class Initialized
DEBUG - 2016-09-23 00:21:09 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:21:09 --> Model Class Initialized
INFO - 2016-09-23 00:21:09 --> Model Class Initialized
ERROR - 2016-09-23 00:21:09 --> Unable to delete cache file for admin/index/buku_besar
DEBUG - 2016-09-23 00:21:09 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-23 00:21:09 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-23 00:21:09 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-23 00:21:09 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/laporan/buku_besar.php
DEBUG - 2016-09-23 00:21:09 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-23 00:21:09 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:09 --> Database Driver Class Initialized
DEBUG - 2016-09-23 00:21:09 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-23 00:21:09 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-23 00:21:09 --> Final output sent to browser
DEBUG - 2016-09-23 00:21:09 --> Total execution time: 0.7016
INFO - 2016-09-23 00:21:10 --> Config Class Initialized
INFO - 2016-09-23 00:21:10 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:21:10 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:21:10 --> Utf8 Class Initialized
INFO - 2016-09-23 00:21:10 --> URI Class Initialized
INFO - 2016-09-23 00:21:10 --> Router Class Initialized
INFO - 2016-09-23 00:21:10 --> Output Class Initialized
INFO - 2016-09-23 00:21:10 --> Security Class Initialized
DEBUG - 2016-09-23 00:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:21:10 --> Input Class Initialized
INFO - 2016-09-23 00:21:10 --> Language Class Initialized
ERROR - 2016-09-23 00:21:10 --> 404 Page Not Found: /index
INFO - 2016-09-23 00:21:10 --> Config Class Initialized
INFO - 2016-09-23 00:21:10 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:21:10 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:21:10 --> Utf8 Class Initialized
INFO - 2016-09-23 00:21:10 --> URI Class Initialized
INFO - 2016-09-23 00:21:10 --> Router Class Initialized
INFO - 2016-09-23 00:21:10 --> Output Class Initialized
INFO - 2016-09-23 00:21:10 --> Security Class Initialized
DEBUG - 2016-09-23 00:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:21:10 --> Input Class Initialized
INFO - 2016-09-23 00:21:10 --> Language Class Initialized
ERROR - 2016-09-23 00:21:10 --> 404 Page Not Found: /index
INFO - 2016-09-23 00:21:11 --> Config Class Initialized
INFO - 2016-09-23 00:21:11 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:21:11 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:21:11 --> Utf8 Class Initialized
INFO - 2016-09-23 00:21:11 --> URI Class Initialized
INFO - 2016-09-23 00:21:11 --> Router Class Initialized
INFO - 2016-09-23 00:21:11 --> Output Class Initialized
INFO - 2016-09-23 00:21:11 --> Security Class Initialized
DEBUG - 2016-09-23 00:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:21:11 --> Input Class Initialized
INFO - 2016-09-23 00:21:11 --> Language Class Initialized
ERROR - 2016-09-23 00:21:11 --> 404 Page Not Found: /index
INFO - 2016-09-23 00:21:21 --> Config Class Initialized
INFO - 2016-09-23 00:21:21 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:21:21 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:21:21 --> Utf8 Class Initialized
INFO - 2016-09-23 00:21:21 --> URI Class Initialized
INFO - 2016-09-23 00:21:21 --> Router Class Initialized
INFO - 2016-09-23 00:21:21 --> Output Class Initialized
INFO - 2016-09-23 00:21:21 --> Security Class Initialized
DEBUG - 2016-09-23 00:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:21:21 --> Input Class Initialized
INFO - 2016-09-23 00:21:21 --> Language Class Initialized
INFO - 2016-09-23 00:21:21 --> Language Class Initialized
INFO - 2016-09-23 00:21:21 --> Config Class Initialized
INFO - 2016-09-23 00:21:21 --> Loader Class Initialized
INFO - 2016-09-23 00:21:21 --> Helper loaded: url_helper
INFO - 2016-09-23 00:21:21 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:21:21 --> Controller Class Initialized
DEBUG - 2016-09-23 00:21:21 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:21:21 --> Model Class Initialized
INFO - 2016-09-23 00:21:21 --> Model Class Initialized
ERROR - 2016-09-23 00:21:21 --> Unable to delete cache file for admin/index/do_laporan_buku_besar
ERROR - 2016-09-23 00:21:21 --> Severity: Notice --> Undefined variable: saldoDebit /home/koperasi/public_html/application/views/main_html/content/laporan/data_buku_besar.php 38
ERROR - 2016-09-23 00:21:21 --> Severity: Notice --> Undefined variable: saldoKredit /home/koperasi/public_html/application/views/main_html/content/laporan/data_buku_besar.php 39
DEBUG - 2016-09-23 00:21:21 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/laporan/data_buku_besar.php
INFO - 2016-09-23 00:21:21 --> Final output sent to browser
DEBUG - 2016-09-23 00:21:21 --> Total execution time: 0.0367
INFO - 2016-09-23 00:21:29 --> Config Class Initialized
INFO - 2016-09-23 00:21:29 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:21:29 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:21:29 --> Utf8 Class Initialized
INFO - 2016-09-23 00:21:29 --> URI Class Initialized
INFO - 2016-09-23 00:21:29 --> Router Class Initialized
INFO - 2016-09-23 00:21:29 --> Output Class Initialized
INFO - 2016-09-23 00:21:29 --> Security Class Initialized
DEBUG - 2016-09-23 00:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:21:29 --> Input Class Initialized
INFO - 2016-09-23 00:21:29 --> Language Class Initialized
INFO - 2016-09-23 00:21:29 --> Language Class Initialized
INFO - 2016-09-23 00:21:29 --> Config Class Initialized
INFO - 2016-09-23 00:21:29 --> Loader Class Initialized
INFO - 2016-09-23 00:21:29 --> Helper loaded: url_helper
INFO - 2016-09-23 00:21:29 --> Database Driver Class Initialized
INFO - 2016-09-23 00:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:21:29 --> Controller Class Initialized
DEBUG - 2016-09-23 00:21:29 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:21:29 --> Model Class Initialized
INFO - 2016-09-23 00:21:29 --> Model Class Initialized
ERROR - 2016-09-23 00:21:29 --> Unable to delete cache file for admin/index/do_laporan_buku_besar
ERROR - 2016-09-23 00:21:29 --> Severity: Notice --> Undefined variable: saldoDebit /home/koperasi/public_html/application/views/main_html/content/laporan/data_buku_besar.php 38
ERROR - 2016-09-23 00:21:29 --> Severity: Notice --> Undefined variable: saldoKredit /home/koperasi/public_html/application/views/main_html/content/laporan/data_buku_besar.php 39
DEBUG - 2016-09-23 00:21:29 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/laporan/data_buku_besar.php
INFO - 2016-09-23 00:21:29 --> Final output sent to browser
DEBUG - 2016-09-23 00:21:29 --> Total execution time: 0.0386
INFO - 2016-09-23 00:22:10 --> Config Class Initialized
INFO - 2016-09-23 00:22:10 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:22:10 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:22:10 --> Utf8 Class Initialized
INFO - 2016-09-23 00:22:10 --> URI Class Initialized
INFO - 2016-09-23 00:22:10 --> Router Class Initialized
INFO - 2016-09-23 00:22:10 --> Output Class Initialized
INFO - 2016-09-23 00:22:10 --> Security Class Initialized
DEBUG - 2016-09-23 00:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:22:10 --> Input Class Initialized
INFO - 2016-09-23 00:22:10 --> Language Class Initialized
INFO - 2016-09-23 00:22:10 --> Language Class Initialized
INFO - 2016-09-23 00:22:10 --> Config Class Initialized
INFO - 2016-09-23 00:22:10 --> Loader Class Initialized
INFO - 2016-09-23 00:22:10 --> Helper loaded: url_helper
INFO - 2016-09-23 00:22:10 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:22:10 --> Controller Class Initialized
DEBUG - 2016-09-23 00:22:10 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:22:10 --> Model Class Initialized
INFO - 2016-09-23 00:22:10 --> Model Class Initialized
ERROR - 2016-09-23 00:22:10 --> Unable to delete cache file for admin/index/do_laporan_buku_besar
DEBUG - 2016-09-23 00:22:10 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/laporan/data_buku_besar.php
INFO - 2016-09-23 00:22:10 --> Final output sent to browser
DEBUG - 2016-09-23 00:22:10 --> Total execution time: 0.0332
INFO - 2016-09-23 00:22:11 --> Config Class Initialized
INFO - 2016-09-23 00:22:11 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:22:11 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:22:11 --> Utf8 Class Initialized
INFO - 2016-09-23 00:22:11 --> URI Class Initialized
DEBUG - 2016-09-23 00:22:11 --> No URI present. Default controller set.
INFO - 2016-09-23 00:22:11 --> Router Class Initialized
INFO - 2016-09-23 00:22:11 --> Output Class Initialized
INFO - 2016-09-23 00:22:11 --> Security Class Initialized
DEBUG - 2016-09-23 00:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:22:11 --> Input Class Initialized
INFO - 2016-09-23 00:22:11 --> Language Class Initialized
INFO - 2016-09-23 00:22:11 --> Language Class Initialized
INFO - 2016-09-23 00:22:11 --> Config Class Initialized
INFO - 2016-09-23 00:22:11 --> Loader Class Initialized
INFO - 2016-09-23 00:22:11 --> Helper loaded: url_helper
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:22:11 --> Controller Class Initialized
DEBUG - 2016-09-23 00:22:11 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:22:11 --> Model Class Initialized
INFO - 2016-09-23 00:22:11 --> Model Class Initialized
ERROR - 2016-09-23 00:22:11 --> Unable to delete cache file for 
DEBUG - 2016-09-23 00:22:11 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-23 00:22:11 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-23 00:22:11 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-23 00:22:11 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-23 00:22:11 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-23 00:22:11 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:11 --> Database Driver Class Initialized
DEBUG - 2016-09-23 00:22:11 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-23 00:22:11 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-23 00:22:11 --> Final output sent to browser
DEBUG - 2016-09-23 00:22:11 --> Total execution time: 0.0991
INFO - 2016-09-23 00:22:12 --> Config Class Initialized
INFO - 2016-09-23 00:22:12 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:22:12 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:22:12 --> Utf8 Class Initialized
INFO - 2016-09-23 00:22:12 --> URI Class Initialized
INFO - 2016-09-23 00:22:12 --> Router Class Initialized
INFO - 2016-09-23 00:22:12 --> Output Class Initialized
INFO - 2016-09-23 00:22:12 --> Security Class Initialized
DEBUG - 2016-09-23 00:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:22:12 --> Input Class Initialized
INFO - 2016-09-23 00:22:12 --> Language Class Initialized
INFO - 2016-09-23 00:22:12 --> Language Class Initialized
INFO - 2016-09-23 00:22:12 --> Config Class Initialized
INFO - 2016-09-23 00:22:12 --> Loader Class Initialized
INFO - 2016-09-23 00:22:12 --> Helper loaded: url_helper
INFO - 2016-09-23 00:22:12 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:22:12 --> Controller Class Initialized
DEBUG - 2016-09-23 00:22:12 --> login MX_Controller Initialized
INFO - 2016-09-23 00:22:12 --> Model Class Initialized
INFO - 2016-09-23 00:22:12 --> Model Class Initialized
DEBUG - 2016-09-23 00:22:12 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-23 00:22:12 --> Final output sent to browser
DEBUG - 2016-09-23 00:22:12 --> Total execution time: 0.0242
INFO - 2016-09-23 00:22:17 --> Config Class Initialized
INFO - 2016-09-23 00:22:17 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:22:17 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:22:17 --> Utf8 Class Initialized
INFO - 2016-09-23 00:22:17 --> URI Class Initialized
INFO - 2016-09-23 00:22:17 --> Router Class Initialized
INFO - 2016-09-23 00:22:17 --> Output Class Initialized
INFO - 2016-09-23 00:22:17 --> Security Class Initialized
DEBUG - 2016-09-23 00:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:22:17 --> Input Class Initialized
INFO - 2016-09-23 00:22:17 --> Language Class Initialized
INFO - 2016-09-23 00:22:17 --> Language Class Initialized
INFO - 2016-09-23 00:22:17 --> Config Class Initialized
INFO - 2016-09-23 00:22:17 --> Loader Class Initialized
INFO - 2016-09-23 00:22:17 --> Helper loaded: url_helper
INFO - 2016-09-23 00:22:17 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:22:17 --> Controller Class Initialized
DEBUG - 2016-09-23 00:22:17 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:22:17 --> Model Class Initialized
INFO - 2016-09-23 00:22:17 --> Model Class Initialized
ERROR - 2016-09-23 00:22:17 --> Unable to delete cache file for admin/index/do_laporan_buku_besar
DEBUG - 2016-09-23 00:22:17 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/laporan/data_buku_besar.php
INFO - 2016-09-23 00:22:17 --> Final output sent to browser
DEBUG - 2016-09-23 00:22:17 --> Total execution time: 0.0362
INFO - 2016-09-23 00:22:18 --> Config Class Initialized
INFO - 2016-09-23 00:22:18 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:22:18 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:22:18 --> Utf8 Class Initialized
INFO - 2016-09-23 00:22:18 --> URI Class Initialized
INFO - 2016-09-23 00:22:18 --> Router Class Initialized
INFO - 2016-09-23 00:22:18 --> Output Class Initialized
INFO - 2016-09-23 00:22:18 --> Security Class Initialized
DEBUG - 2016-09-23 00:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:22:18 --> Input Class Initialized
INFO - 2016-09-23 00:22:18 --> Language Class Initialized
ERROR - 2016-09-23 00:22:18 --> 404 Page Not Found: /index
INFO - 2016-09-23 00:22:24 --> Config Class Initialized
INFO - 2016-09-23 00:22:24 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:22:24 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:22:24 --> Utf8 Class Initialized
INFO - 2016-09-23 00:22:24 --> URI Class Initialized
INFO - 2016-09-23 00:22:24 --> Router Class Initialized
INFO - 2016-09-23 00:22:24 --> Output Class Initialized
INFO - 2016-09-23 00:22:24 --> Security Class Initialized
DEBUG - 2016-09-23 00:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:22:24 --> Input Class Initialized
INFO - 2016-09-23 00:22:24 --> Language Class Initialized
INFO - 2016-09-23 00:22:24 --> Language Class Initialized
INFO - 2016-09-23 00:22:24 --> Config Class Initialized
INFO - 2016-09-23 00:22:24 --> Loader Class Initialized
INFO - 2016-09-23 00:22:24 --> Helper loaded: url_helper
INFO - 2016-09-23 00:22:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:22:24 --> Controller Class Initialized
DEBUG - 2016-09-23 00:22:24 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:22:24 --> Model Class Initialized
INFO - 2016-09-23 00:22:24 --> Model Class Initialized
ERROR - 2016-09-23 00:22:24 --> Unable to delete cache file for admin/index/do_laporan_buku_besar
DEBUG - 2016-09-23 00:22:24 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/laporan/data_buku_besar.php
INFO - 2016-09-23 00:22:24 --> Final output sent to browser
DEBUG - 2016-09-23 00:22:24 --> Total execution time: 0.0391
INFO - 2016-09-23 00:23:22 --> Config Class Initialized
INFO - 2016-09-23 00:23:22 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:23:22 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:23:22 --> Utf8 Class Initialized
INFO - 2016-09-23 00:23:22 --> URI Class Initialized
INFO - 2016-09-23 00:23:22 --> Router Class Initialized
INFO - 2016-09-23 00:23:22 --> Output Class Initialized
INFO - 2016-09-23 00:23:22 --> Security Class Initialized
DEBUG - 2016-09-23 00:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:23:22 --> Input Class Initialized
INFO - 2016-09-23 00:23:22 --> Language Class Initialized
INFO - 2016-09-23 00:23:22 --> Language Class Initialized
INFO - 2016-09-23 00:23:22 --> Config Class Initialized
INFO - 2016-09-23 00:23:22 --> Loader Class Initialized
INFO - 2016-09-23 00:23:22 --> Helper loaded: url_helper
INFO - 2016-09-23 00:23:22 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:23:22 --> Controller Class Initialized
DEBUG - 2016-09-23 00:23:22 --> login MX_Controller Initialized
INFO - 2016-09-23 00:23:22 --> Model Class Initialized
INFO - 2016-09-23 00:23:22 --> Model Class Initialized
INFO - 2016-09-23 00:23:22 --> Final output sent to browser
DEBUG - 2016-09-23 00:23:22 --> Total execution time: 0.0602
INFO - 2016-09-23 00:23:24 --> Config Class Initialized
INFO - 2016-09-23 00:23:24 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:23:24 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:23:24 --> Utf8 Class Initialized
INFO - 2016-09-23 00:23:24 --> URI Class Initialized
INFO - 2016-09-23 00:23:24 --> Router Class Initialized
INFO - 2016-09-23 00:23:24 --> Output Class Initialized
INFO - 2016-09-23 00:23:24 --> Security Class Initialized
DEBUG - 2016-09-23 00:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:23:24 --> Input Class Initialized
INFO - 2016-09-23 00:23:24 --> Language Class Initialized
INFO - 2016-09-23 00:23:24 --> Language Class Initialized
INFO - 2016-09-23 00:23:24 --> Config Class Initialized
INFO - 2016-09-23 00:23:24 --> Loader Class Initialized
INFO - 2016-09-23 00:23:24 --> Helper loaded: url_helper
INFO - 2016-09-23 00:23:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:23:24 --> Controller Class Initialized
DEBUG - 2016-09-23 00:23:24 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:23:24 --> Model Class Initialized
INFO - 2016-09-23 00:23:24 --> Model Class Initialized
ERROR - 2016-09-23 00:23:24 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-23 00:23:24 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-23 00:23:24 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-23 00:23:24 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-23 00:23:24 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-23 00:23:24 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-23 00:23:24 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-23 00:23:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:24 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
DEBUG - 2016-09-23 00:23:25 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-23 00:23:25 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-23 00:23:25 --> Final output sent to browser
DEBUG - 2016-09-23 00:23:25 --> Total execution time: 0.7776
INFO - 2016-09-23 00:23:25 --> Config Class Initialized
INFO - 2016-09-23 00:23:25 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:23:25 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:23:25 --> Utf8 Class Initialized
INFO - 2016-09-23 00:23:25 --> URI Class Initialized
DEBUG - 2016-09-23 00:23:25 --> No URI present. Default controller set.
INFO - 2016-09-23 00:23:25 --> Router Class Initialized
INFO - 2016-09-23 00:23:25 --> Output Class Initialized
INFO - 2016-09-23 00:23:25 --> Security Class Initialized
DEBUG - 2016-09-23 00:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:23:25 --> Input Class Initialized
INFO - 2016-09-23 00:23:25 --> Language Class Initialized
INFO - 2016-09-23 00:23:25 --> Language Class Initialized
INFO - 2016-09-23 00:23:25 --> Config Class Initialized
INFO - 2016-09-23 00:23:25 --> Loader Class Initialized
INFO - 2016-09-23 00:23:25 --> Helper loaded: url_helper
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:23:25 --> Controller Class Initialized
DEBUG - 2016-09-23 00:23:25 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:23:25 --> Model Class Initialized
INFO - 2016-09-23 00:23:25 --> Model Class Initialized
ERROR - 2016-09-23 00:23:25 --> Unable to delete cache file for 
DEBUG - 2016-09-23 00:23:25 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-23 00:23:25 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-23 00:23:25 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-23 00:23:25 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-23 00:23:25 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-23 00:23:25 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:25 --> Database Driver Class Initialized
DEBUG - 2016-09-23 00:23:25 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-23 00:23:25 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-23 00:23:25 --> Final output sent to browser
DEBUG - 2016-09-23 00:23:25 --> Total execution time: 0.1055
INFO - 2016-09-23 00:23:26 --> Config Class Initialized
INFO - 2016-09-23 00:23:26 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:23:26 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:23:26 --> Utf8 Class Initialized
INFO - 2016-09-23 00:23:26 --> URI Class Initialized
INFO - 2016-09-23 00:23:26 --> Router Class Initialized
INFO - 2016-09-23 00:23:26 --> Output Class Initialized
INFO - 2016-09-23 00:23:26 --> Security Class Initialized
DEBUG - 2016-09-23 00:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:23:26 --> Input Class Initialized
INFO - 2016-09-23 00:23:26 --> Language Class Initialized
INFO - 2016-09-23 00:23:26 --> Language Class Initialized
INFO - 2016-09-23 00:23:26 --> Config Class Initialized
INFO - 2016-09-23 00:23:26 --> Loader Class Initialized
INFO - 2016-09-23 00:23:26 --> Helper loaded: url_helper
INFO - 2016-09-23 00:23:26 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:23:26 --> Controller Class Initialized
DEBUG - 2016-09-23 00:23:26 --> login MX_Controller Initialized
INFO - 2016-09-23 00:23:26 --> Model Class Initialized
INFO - 2016-09-23 00:23:26 --> Model Class Initialized
DEBUG - 2016-09-23 00:23:26 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-23 00:23:26 --> Final output sent to browser
DEBUG - 2016-09-23 00:23:26 --> Total execution time: 0.0253
INFO - 2016-09-23 00:23:26 --> Config Class Initialized
INFO - 2016-09-23 00:23:26 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:23:26 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:23:26 --> Utf8 Class Initialized
INFO - 2016-09-23 00:23:26 --> URI Class Initialized
INFO - 2016-09-23 00:23:26 --> Router Class Initialized
INFO - 2016-09-23 00:23:27 --> Output Class Initialized
INFO - 2016-09-23 00:23:27 --> Security Class Initialized
DEBUG - 2016-09-23 00:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:23:27 --> Input Class Initialized
INFO - 2016-09-23 00:23:27 --> Language Class Initialized
ERROR - 2016-09-23 00:23:27 --> 404 Page Not Found: /index
INFO - 2016-09-23 00:23:27 --> Config Class Initialized
INFO - 2016-09-23 00:23:27 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:23:27 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:23:27 --> Utf8 Class Initialized
INFO - 2016-09-23 00:23:27 --> URI Class Initialized
INFO - 2016-09-23 00:23:27 --> Router Class Initialized
INFO - 2016-09-23 00:23:27 --> Output Class Initialized
INFO - 2016-09-23 00:23:27 --> Security Class Initialized
DEBUG - 2016-09-23 00:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:23:27 --> Input Class Initialized
INFO - 2016-09-23 00:23:27 --> Language Class Initialized
ERROR - 2016-09-23 00:23:27 --> 404 Page Not Found: /index
INFO - 2016-09-23 00:23:46 --> Config Class Initialized
INFO - 2016-09-23 00:23:46 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:23:46 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:23:46 --> Utf8 Class Initialized
INFO - 2016-09-23 00:23:46 --> URI Class Initialized
INFO - 2016-09-23 00:23:46 --> Router Class Initialized
INFO - 2016-09-23 00:23:46 --> Output Class Initialized
INFO - 2016-09-23 00:23:46 --> Security Class Initialized
DEBUG - 2016-09-23 00:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:23:46 --> Input Class Initialized
INFO - 2016-09-23 00:23:46 --> Language Class Initialized
INFO - 2016-09-23 00:23:46 --> Language Class Initialized
INFO - 2016-09-23 00:23:46 --> Config Class Initialized
INFO - 2016-09-23 00:23:46 --> Loader Class Initialized
INFO - 2016-09-23 00:23:46 --> Helper loaded: url_helper
INFO - 2016-09-23 00:23:46 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:23:46 --> Controller Class Initialized
DEBUG - 2016-09-23 00:23:46 --> login MX_Controller Initialized
INFO - 2016-09-23 00:23:46 --> Model Class Initialized
INFO - 2016-09-23 00:23:46 --> Model Class Initialized
INFO - 2016-09-23 00:23:46 --> Final output sent to browser
DEBUG - 2016-09-23 00:23:46 --> Total execution time: 0.0307
INFO - 2016-09-23 00:23:52 --> Config Class Initialized
INFO - 2016-09-23 00:23:52 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:23:52 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:23:52 --> Utf8 Class Initialized
INFO - 2016-09-23 00:23:52 --> URI Class Initialized
INFO - 2016-09-23 00:23:52 --> Router Class Initialized
INFO - 2016-09-23 00:23:52 --> Output Class Initialized
INFO - 2016-09-23 00:23:52 --> Security Class Initialized
DEBUG - 2016-09-23 00:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:23:52 --> Input Class Initialized
INFO - 2016-09-23 00:23:52 --> Language Class Initialized
INFO - 2016-09-23 00:23:53 --> Language Class Initialized
INFO - 2016-09-23 00:23:53 --> Config Class Initialized
INFO - 2016-09-23 00:23:53 --> Loader Class Initialized
INFO - 2016-09-23 00:23:53 --> Helper loaded: url_helper
INFO - 2016-09-23 00:23:53 --> Database Driver Class Initialized
INFO - 2016-09-23 00:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:23:53 --> Controller Class Initialized
DEBUG - 2016-09-23 00:23:53 --> login MX_Controller Initialized
INFO - 2016-09-23 00:23:53 --> Model Class Initialized
INFO - 2016-09-23 00:23:53 --> Model Class Initialized
INFO - 2016-09-23 00:23:53 --> Final output sent to browser
DEBUG - 2016-09-23 00:23:53 --> Total execution time: 0.0291
INFO - 2016-09-23 00:24:02 --> Config Class Initialized
INFO - 2016-09-23 00:24:02 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:24:02 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:24:02 --> Utf8 Class Initialized
INFO - 2016-09-23 00:24:02 --> URI Class Initialized
INFO - 2016-09-23 00:24:02 --> Router Class Initialized
INFO - 2016-09-23 00:24:02 --> Output Class Initialized
INFO - 2016-09-23 00:24:02 --> Security Class Initialized
DEBUG - 2016-09-23 00:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:24:02 --> Input Class Initialized
INFO - 2016-09-23 00:24:02 --> Language Class Initialized
INFO - 2016-09-23 00:24:02 --> Language Class Initialized
INFO - 2016-09-23 00:24:02 --> Config Class Initialized
INFO - 2016-09-23 00:24:02 --> Loader Class Initialized
INFO - 2016-09-23 00:24:02 --> Helper loaded: url_helper
INFO - 2016-09-23 00:24:02 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:24:02 --> Controller Class Initialized
DEBUG - 2016-09-23 00:24:02 --> login MX_Controller Initialized
INFO - 2016-09-23 00:24:02 --> Model Class Initialized
INFO - 2016-09-23 00:24:02 --> Model Class Initialized
INFO - 2016-09-23 00:24:02 --> Final output sent to browser
DEBUG - 2016-09-23 00:24:02 --> Total execution time: 0.0272
INFO - 2016-09-23 00:24:03 --> Config Class Initialized
INFO - 2016-09-23 00:24:03 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:24:03 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:24:03 --> Utf8 Class Initialized
INFO - 2016-09-23 00:24:03 --> URI Class Initialized
INFO - 2016-09-23 00:24:03 --> Router Class Initialized
INFO - 2016-09-23 00:24:03 --> Output Class Initialized
INFO - 2016-09-23 00:24:03 --> Security Class Initialized
DEBUG - 2016-09-23 00:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:24:03 --> Input Class Initialized
INFO - 2016-09-23 00:24:03 --> Language Class Initialized
INFO - 2016-09-23 00:24:03 --> Language Class Initialized
INFO - 2016-09-23 00:24:03 --> Config Class Initialized
INFO - 2016-09-23 00:24:03 --> Loader Class Initialized
INFO - 2016-09-23 00:24:03 --> Helper loaded: url_helper
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:24:03 --> Controller Class Initialized
DEBUG - 2016-09-23 00:24:03 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:24:03 --> Model Class Initialized
INFO - 2016-09-23 00:24:03 --> Model Class Initialized
ERROR - 2016-09-23 00:24:03 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-23 00:24:03 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-23 00:24:03 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-23 00:24:03 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-23 00:24:03 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-23 00:24:03 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-23 00:24:03 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:03 --> Database Driver Class Initialized
DEBUG - 2016-09-23 00:24:03 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-23 00:24:03 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-23 00:24:03 --> Final output sent to browser
DEBUG - 2016-09-23 00:24:03 --> Total execution time: 0.1027
INFO - 2016-09-23 00:24:08 --> Config Class Initialized
INFO - 2016-09-23 00:24:08 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:24:08 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:24:08 --> Utf8 Class Initialized
INFO - 2016-09-23 00:24:08 --> URI Class Initialized
INFO - 2016-09-23 00:24:08 --> Router Class Initialized
INFO - 2016-09-23 00:24:08 --> Output Class Initialized
INFO - 2016-09-23 00:24:08 --> Security Class Initialized
DEBUG - 2016-09-23 00:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:24:08 --> Input Class Initialized
INFO - 2016-09-23 00:24:08 --> Language Class Initialized
ERROR - 2016-09-23 00:24:08 --> 404 Page Not Found: /index
INFO - 2016-09-23 00:24:10 --> Config Class Initialized
INFO - 2016-09-23 00:24:10 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:24:10 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:24:10 --> Utf8 Class Initialized
INFO - 2016-09-23 00:24:10 --> URI Class Initialized
INFO - 2016-09-23 00:24:10 --> Router Class Initialized
INFO - 2016-09-23 00:24:10 --> Output Class Initialized
INFO - 2016-09-23 00:24:10 --> Security Class Initialized
DEBUG - 2016-09-23 00:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:24:10 --> Input Class Initialized
INFO - 2016-09-23 00:24:10 --> Language Class Initialized
ERROR - 2016-09-23 00:24:10 --> 404 Page Not Found: /index
INFO - 2016-09-23 00:24:51 --> Config Class Initialized
INFO - 2016-09-23 00:24:51 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:24:51 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:24:51 --> Utf8 Class Initialized
INFO - 2016-09-23 00:24:51 --> URI Class Initialized
INFO - 2016-09-23 00:24:51 --> Router Class Initialized
INFO - 2016-09-23 00:24:51 --> Output Class Initialized
INFO - 2016-09-23 00:24:51 --> Security Class Initialized
DEBUG - 2016-09-23 00:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:24:51 --> Input Class Initialized
INFO - 2016-09-23 00:24:51 --> Language Class Initialized
INFO - 2016-09-23 00:24:51 --> Language Class Initialized
INFO - 2016-09-23 00:24:51 --> Config Class Initialized
INFO - 2016-09-23 00:24:51 --> Loader Class Initialized
INFO - 2016-09-23 00:24:51 --> Helper loaded: url_helper
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:24:51 --> Controller Class Initialized
DEBUG - 2016-09-23 00:24:51 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:24:51 --> Model Class Initialized
INFO - 2016-09-23 00:24:51 --> Model Class Initialized
ERROR - 2016-09-23 00:24:51 --> Unable to delete cache file for admin/index/data/user
DEBUG - 2016-09-23 00:24:51 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-23 00:24:51 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-23 00:24:51 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-23 00:24:51 --> File already loaded: /home/koperasi/public_html/application/controllers/../modules/user/controllers/Users.php
DEBUG - 2016-09-23 00:24:51 --> Users MX_Controller Initialized
DEBUG - 2016-09-23 00:24:51 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/list_user.php
DEBUG - 2016-09-23 00:24:51 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-23 00:24:51 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
INFO - 2016-09-23 00:24:51 --> Database Driver Class Initialized
DEBUG - 2016-09-23 00:24:51 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-23 00:24:51 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-23 00:24:51 --> Final output sent to browser
DEBUG - 2016-09-23 00:24:51 --> Total execution time: 0.0866
INFO - 2016-09-23 00:24:52 --> Config Class Initialized
INFO - 2016-09-23 00:24:52 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:24:52 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:24:52 --> Utf8 Class Initialized
INFO - 2016-09-23 00:24:52 --> URI Class Initialized
INFO - 2016-09-23 00:24:52 --> Router Class Initialized
INFO - 2016-09-23 00:24:52 --> Output Class Initialized
INFO - 2016-09-23 00:24:52 --> Security Class Initialized
DEBUG - 2016-09-23 00:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:24:52 --> Input Class Initialized
INFO - 2016-09-23 00:24:52 --> Language Class Initialized
ERROR - 2016-09-23 00:24:52 --> 404 Page Not Found: /index
INFO - 2016-09-23 00:24:52 --> Config Class Initialized
INFO - 2016-09-23 00:24:52 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:24:52 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:24:52 --> Utf8 Class Initialized
INFO - 2016-09-23 00:24:52 --> URI Class Initialized
INFO - 2016-09-23 00:24:52 --> Router Class Initialized
INFO - 2016-09-23 00:24:52 --> Output Class Initialized
INFO - 2016-09-23 00:24:52 --> Security Class Initialized
DEBUG - 2016-09-23 00:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:24:52 --> Input Class Initialized
INFO - 2016-09-23 00:24:52 --> Language Class Initialized
ERROR - 2016-09-23 00:24:52 --> 404 Page Not Found: /index
INFO - 2016-09-23 00:25:15 --> Config Class Initialized
INFO - 2016-09-23 00:25:15 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:25:15 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:25:15 --> Utf8 Class Initialized
INFO - 2016-09-23 00:25:15 --> URI Class Initialized
INFO - 2016-09-23 00:25:15 --> Router Class Initialized
INFO - 2016-09-23 00:25:15 --> Output Class Initialized
INFO - 2016-09-23 00:25:15 --> Security Class Initialized
DEBUG - 2016-09-23 00:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:25:15 --> Input Class Initialized
INFO - 2016-09-23 00:25:15 --> Language Class Initialized
INFO - 2016-09-23 00:25:15 --> Language Class Initialized
INFO - 2016-09-23 00:25:15 --> Config Class Initialized
INFO - 2016-09-23 00:25:15 --> Loader Class Initialized
INFO - 2016-09-23 00:25:15 --> Helper loaded: url_helper
INFO - 2016-09-23 00:25:15 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:25:16 --> Controller Class Initialized
DEBUG - 2016-09-23 00:25:16 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:25:16 --> Model Class Initialized
INFO - 2016-09-23 00:25:16 --> Model Class Initialized
ERROR - 2016-09-23 00:25:16 --> Unable to delete cache file for admin/index/post_get/user/356a192b7913b04c54574d18c28d46e6395428ab
DEBUG - 2016-09-23 00:25:16 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-23 00:25:16 --> Users MX_Controller Initialized
INFO - 2016-09-23 00:25:16 --> Final output sent to browser
DEBUG - 2016-09-23 00:25:16 --> Total execution time: 0.0294
INFO - 2016-09-23 00:25:33 --> Config Class Initialized
INFO - 2016-09-23 00:25:33 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:25:33 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:25:33 --> Utf8 Class Initialized
INFO - 2016-09-23 00:25:33 --> URI Class Initialized
INFO - 2016-09-23 00:25:33 --> Router Class Initialized
INFO - 2016-09-23 00:25:33 --> Output Class Initialized
INFO - 2016-09-23 00:25:33 --> Security Class Initialized
DEBUG - 2016-09-23 00:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:25:33 --> Input Class Initialized
INFO - 2016-09-23 00:25:33 --> Language Class Initialized
INFO - 2016-09-23 00:25:33 --> Language Class Initialized
INFO - 2016-09-23 00:25:33 --> Config Class Initialized
INFO - 2016-09-23 00:25:33 --> Loader Class Initialized
INFO - 2016-09-23 00:25:33 --> Helper loaded: url_helper
INFO - 2016-09-23 00:25:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:25:33 --> Controller Class Initialized
DEBUG - 2016-09-23 00:25:33 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:25:33 --> Model Class Initialized
INFO - 2016-09-23 00:25:33 --> Model Class Initialized
ERROR - 2016-09-23 00:25:33 --> Unable to delete cache file for admin/index/post_del/user/356a192b7913b04c54574d18c28d46e6395428ab
DEBUG - 2016-09-23 00:25:33 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-23 00:25:33 --> Users MX_Controller Initialized
INFO - 2016-09-23 00:25:33 --> Final output sent to browser
DEBUG - 2016-09-23 00:25:33 --> Total execution time: 0.0300
INFO - 2016-09-23 00:25:39 --> Config Class Initialized
INFO - 2016-09-23 00:25:39 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:25:39 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:25:39 --> Utf8 Class Initialized
INFO - 2016-09-23 00:25:39 --> URI Class Initialized
INFO - 2016-09-23 00:25:39 --> Router Class Initialized
INFO - 2016-09-23 00:25:39 --> Output Class Initialized
INFO - 2016-09-23 00:25:39 --> Security Class Initialized
DEBUG - 2016-09-23 00:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:25:39 --> Input Class Initialized
INFO - 2016-09-23 00:25:39 --> Language Class Initialized
INFO - 2016-09-23 00:25:39 --> Language Class Initialized
INFO - 2016-09-23 00:25:39 --> Config Class Initialized
INFO - 2016-09-23 00:25:39 --> Loader Class Initialized
INFO - 2016-09-23 00:25:39 --> Helper loaded: url_helper
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:25:39 --> Controller Class Initialized
DEBUG - 2016-09-23 00:25:39 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:25:39 --> Model Class Initialized
INFO - 2016-09-23 00:25:39 --> Model Class Initialized
ERROR - 2016-09-23 00:25:39 --> Unable to delete cache file for admin/index/data/user
DEBUG - 2016-09-23 00:25:39 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-23 00:25:39 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-23 00:25:39 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-23 00:25:39 --> File already loaded: /home/koperasi/public_html/application/controllers/../modules/user/controllers/Users.php
DEBUG - 2016-09-23 00:25:39 --> Users MX_Controller Initialized
DEBUG - 2016-09-23 00:25:39 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/list_user.php
DEBUG - 2016-09-23 00:25:39 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-23 00:25:39 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
INFO - 2016-09-23 00:25:39 --> Database Driver Class Initialized
DEBUG - 2016-09-23 00:25:39 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-23 00:25:39 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-23 00:25:39 --> Final output sent to browser
DEBUG - 2016-09-23 00:25:39 --> Total execution time: 0.1542
INFO - 2016-09-23 00:25:42 --> Config Class Initialized
INFO - 2016-09-23 00:25:42 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:25:42 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:25:42 --> Utf8 Class Initialized
INFO - 2016-09-23 00:25:42 --> URI Class Initialized
INFO - 2016-09-23 00:25:42 --> Router Class Initialized
INFO - 2016-09-23 00:25:42 --> Output Class Initialized
INFO - 2016-09-23 00:25:42 --> Security Class Initialized
DEBUG - 2016-09-23 00:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:25:42 --> Input Class Initialized
INFO - 2016-09-23 00:25:42 --> Language Class Initialized
ERROR - 2016-09-23 00:25:42 --> 404 Page Not Found: /index
INFO - 2016-09-23 00:26:23 --> Config Class Initialized
INFO - 2016-09-23 00:26:23 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:26:23 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:26:23 --> Utf8 Class Initialized
INFO - 2016-09-23 00:26:23 --> URI Class Initialized
INFO - 2016-09-23 00:26:23 --> Router Class Initialized
INFO - 2016-09-23 00:26:23 --> Output Class Initialized
INFO - 2016-09-23 00:26:23 --> Security Class Initialized
DEBUG - 2016-09-23 00:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:26:23 --> Input Class Initialized
INFO - 2016-09-23 00:26:23 --> Language Class Initialized
INFO - 2016-09-23 00:26:23 --> Language Class Initialized
INFO - 2016-09-23 00:26:23 --> Config Class Initialized
INFO - 2016-09-23 00:26:23 --> Loader Class Initialized
INFO - 2016-09-23 00:26:23 --> Helper loaded: url_helper
INFO - 2016-09-23 00:26:23 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:26:23 --> Controller Class Initialized
DEBUG - 2016-09-23 00:26:23 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:26:23 --> Model Class Initialized
INFO - 2016-09-23 00:26:23 --> Model Class Initialized
ERROR - 2016-09-23 00:26:23 --> Unable to delete cache file for admin/index/logout
INFO - 2016-09-23 00:26:23 --> Final output sent to browser
DEBUG - 2016-09-23 00:26:23 --> Total execution time: 0.0287
INFO - 2016-09-23 00:26:23 --> Config Class Initialized
INFO - 2016-09-23 00:26:23 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:26:23 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:26:23 --> Utf8 Class Initialized
INFO - 2016-09-23 00:26:23 --> URI Class Initialized
INFO - 2016-09-23 00:26:23 --> Router Class Initialized
INFO - 2016-09-23 00:26:23 --> Output Class Initialized
INFO - 2016-09-23 00:26:23 --> Security Class Initialized
DEBUG - 2016-09-23 00:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:26:23 --> Input Class Initialized
INFO - 2016-09-23 00:26:23 --> Language Class Initialized
INFO - 2016-09-23 00:26:23 --> Language Class Initialized
INFO - 2016-09-23 00:26:23 --> Config Class Initialized
INFO - 2016-09-23 00:26:23 --> Loader Class Initialized
INFO - 2016-09-23 00:26:23 --> Helper loaded: url_helper
INFO - 2016-09-23 00:26:23 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:26:23 --> Controller Class Initialized
DEBUG - 2016-09-23 00:26:23 --> login MX_Controller Initialized
INFO - 2016-09-23 00:26:23 --> Model Class Initialized
INFO - 2016-09-23 00:26:23 --> Model Class Initialized
DEBUG - 2016-09-23 00:26:23 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-23 00:26:23 --> Final output sent to browser
DEBUG - 2016-09-23 00:26:23 --> Total execution time: 0.0224
INFO - 2016-09-23 00:26:33 --> Config Class Initialized
INFO - 2016-09-23 00:26:33 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:26:33 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:26:33 --> Utf8 Class Initialized
INFO - 2016-09-23 00:26:33 --> URI Class Initialized
INFO - 2016-09-23 00:26:33 --> Router Class Initialized
INFO - 2016-09-23 00:26:33 --> Output Class Initialized
INFO - 2016-09-23 00:26:33 --> Security Class Initialized
DEBUG - 2016-09-23 00:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:26:33 --> Input Class Initialized
INFO - 2016-09-23 00:26:33 --> Language Class Initialized
INFO - 2016-09-23 00:26:33 --> Language Class Initialized
INFO - 2016-09-23 00:26:33 --> Config Class Initialized
INFO - 2016-09-23 00:26:33 --> Loader Class Initialized
INFO - 2016-09-23 00:26:33 --> Helper loaded: url_helper
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:26:33 --> Controller Class Initialized
DEBUG - 2016-09-23 00:26:33 --> Index MX_Controller Initialized
INFO - 2016-09-23 00:26:33 --> Model Class Initialized
INFO - 2016-09-23 00:26:33 --> Model Class Initialized
ERROR - 2016-09-23 00:26:33 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-23 00:26:33 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-23 00:26:33 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-23 00:26:33 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-23 00:26:33 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-23 00:26:33 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-23 00:26:33 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:33 --> Database Driver Class Initialized
DEBUG - 2016-09-23 00:26:33 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-23 00:26:33 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-23 00:26:33 --> Final output sent to browser
DEBUG - 2016-09-23 00:26:33 --> Total execution time: 0.0965
INFO - 2016-09-23 00:26:34 --> Config Class Initialized
INFO - 2016-09-23 00:26:34 --> Hooks Class Initialized
DEBUG - 2016-09-23 00:26:34 --> UTF-8 Support Enabled
INFO - 2016-09-23 00:26:34 --> Utf8 Class Initialized
INFO - 2016-09-23 00:26:34 --> URI Class Initialized
INFO - 2016-09-23 00:26:34 --> Router Class Initialized
INFO - 2016-09-23 00:26:34 --> Output Class Initialized
INFO - 2016-09-23 00:26:34 --> Security Class Initialized
DEBUG - 2016-09-23 00:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 00:26:34 --> Input Class Initialized
INFO - 2016-09-23 00:26:34 --> Language Class Initialized
INFO - 2016-09-23 00:26:34 --> Language Class Initialized
INFO - 2016-09-23 00:26:34 --> Config Class Initialized
INFO - 2016-09-23 00:26:34 --> Loader Class Initialized
INFO - 2016-09-23 00:26:34 --> Helper loaded: url_helper
INFO - 2016-09-23 00:26:34 --> Database Driver Class Initialized
INFO - 2016-09-23 00:26:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 00:26:34 --> Controller Class Initialized
DEBUG - 2016-09-23 00:26:34 --> login MX_Controller Initialized
INFO - 2016-09-23 00:26:34 --> Model Class Initialized
INFO - 2016-09-23 00:26:34 --> Model Class Initialized
DEBUG - 2016-09-23 00:26:34 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-23 00:26:34 --> Final output sent to browser
DEBUG - 2016-09-23 00:26:34 --> Total execution time: 0.0258
INFO - 2016-09-23 09:51:36 --> Config Class Initialized
INFO - 2016-09-23 09:51:36 --> Hooks Class Initialized
DEBUG - 2016-09-23 09:51:36 --> UTF-8 Support Enabled
INFO - 2016-09-23 09:51:36 --> Utf8 Class Initialized
INFO - 2016-09-23 09:51:36 --> URI Class Initialized
INFO - 2016-09-23 09:51:36 --> Router Class Initialized
INFO - 2016-09-23 09:51:36 --> Output Class Initialized
INFO - 2016-09-23 09:51:36 --> Security Class Initialized
DEBUG - 2016-09-23 09:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 09:51:36 --> Input Class Initialized
INFO - 2016-09-23 09:51:36 --> Language Class Initialized
INFO - 2016-09-23 09:51:36 --> Language Class Initialized
INFO - 2016-09-23 09:51:36 --> Config Class Initialized
INFO - 2016-09-23 09:51:36 --> Loader Class Initialized
INFO - 2016-09-23 09:51:36 --> Helper loaded: url_helper
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 09:51:36 --> Controller Class Initialized
DEBUG - 2016-09-23 09:51:36 --> Index MX_Controller Initialized
INFO - 2016-09-23 09:51:36 --> Model Class Initialized
INFO - 2016-09-23 09:51:36 --> Model Class Initialized
ERROR - 2016-09-23 09:51:36 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-23 09:51:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-23 09:51:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-23 09:51:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-23 09:51:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-23 09:51:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-23 09:51:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:36 --> Database Driver Class Initialized
DEBUG - 2016-09-23 09:51:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-23 09:51:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-23 09:51:36 --> Final output sent to browser
DEBUG - 2016-09-23 09:51:36 --> Total execution time: 0.0931
INFO - 2016-09-23 09:51:37 --> Config Class Initialized
INFO - 2016-09-23 09:51:37 --> Hooks Class Initialized
DEBUG - 2016-09-23 09:51:37 --> UTF-8 Support Enabled
INFO - 2016-09-23 09:51:37 --> Utf8 Class Initialized
INFO - 2016-09-23 09:51:37 --> URI Class Initialized
INFO - 2016-09-23 09:51:37 --> Router Class Initialized
INFO - 2016-09-23 09:51:37 --> Output Class Initialized
INFO - 2016-09-23 09:51:37 --> Security Class Initialized
DEBUG - 2016-09-23 09:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 09:51:37 --> Input Class Initialized
INFO - 2016-09-23 09:51:37 --> Language Class Initialized
INFO - 2016-09-23 09:51:37 --> Language Class Initialized
INFO - 2016-09-23 09:51:37 --> Config Class Initialized
INFO - 2016-09-23 09:51:37 --> Loader Class Initialized
INFO - 2016-09-23 09:51:37 --> Helper loaded: url_helper
INFO - 2016-09-23 09:51:37 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 09:51:37 --> Controller Class Initialized
DEBUG - 2016-09-23 09:51:37 --> login MX_Controller Initialized
INFO - 2016-09-23 09:51:37 --> Model Class Initialized
INFO - 2016-09-23 09:51:37 --> Model Class Initialized
DEBUG - 2016-09-23 09:51:37 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-23 09:51:37 --> Final output sent to browser
DEBUG - 2016-09-23 09:51:37 --> Total execution time: 0.0204
INFO - 2016-09-23 09:51:48 --> Config Class Initialized
INFO - 2016-09-23 09:51:48 --> Hooks Class Initialized
DEBUG - 2016-09-23 09:51:48 --> UTF-8 Support Enabled
INFO - 2016-09-23 09:51:48 --> Utf8 Class Initialized
INFO - 2016-09-23 09:51:48 --> URI Class Initialized
INFO - 2016-09-23 09:51:48 --> Router Class Initialized
INFO - 2016-09-23 09:51:48 --> Output Class Initialized
INFO - 2016-09-23 09:51:48 --> Security Class Initialized
DEBUG - 2016-09-23 09:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 09:51:48 --> Input Class Initialized
INFO - 2016-09-23 09:51:48 --> Language Class Initialized
INFO - 2016-09-23 09:51:48 --> Language Class Initialized
INFO - 2016-09-23 09:51:48 --> Config Class Initialized
INFO - 2016-09-23 09:51:48 --> Loader Class Initialized
INFO - 2016-09-23 09:51:48 --> Helper loaded: url_helper
INFO - 2016-09-23 09:51:48 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 09:51:48 --> Controller Class Initialized
DEBUG - 2016-09-23 09:51:48 --> login MX_Controller Initialized
INFO - 2016-09-23 09:51:48 --> Model Class Initialized
INFO - 2016-09-23 09:51:48 --> Model Class Initialized
INFO - 2016-09-23 09:51:48 --> Final output sent to browser
DEBUG - 2016-09-23 09:51:48 --> Total execution time: 0.0239
INFO - 2016-09-23 09:51:52 --> Config Class Initialized
INFO - 2016-09-23 09:51:52 --> Hooks Class Initialized
DEBUG - 2016-09-23 09:51:52 --> UTF-8 Support Enabled
INFO - 2016-09-23 09:51:52 --> Utf8 Class Initialized
INFO - 2016-09-23 09:51:52 --> URI Class Initialized
INFO - 2016-09-23 09:51:52 --> Router Class Initialized
INFO - 2016-09-23 09:51:52 --> Output Class Initialized
INFO - 2016-09-23 09:51:52 --> Security Class Initialized
DEBUG - 2016-09-23 09:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 09:51:52 --> Input Class Initialized
INFO - 2016-09-23 09:51:52 --> Language Class Initialized
INFO - 2016-09-23 09:51:52 --> Language Class Initialized
INFO - 2016-09-23 09:51:52 --> Config Class Initialized
INFO - 2016-09-23 09:51:52 --> Loader Class Initialized
INFO - 2016-09-23 09:51:52 --> Helper loaded: url_helper
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 09:51:52 --> Controller Class Initialized
DEBUG - 2016-09-23 09:51:52 --> login MX_Controller Initialized
INFO - 2016-09-23 09:51:52 --> Model Class Initialized
INFO - 2016-09-23 09:51:52 --> Model Class Initialized
INFO - 2016-09-23 09:51:52 --> Final output sent to browser
DEBUG - 2016-09-23 09:51:52 --> Total execution time: 0.0233
INFO - 2016-09-23 09:51:52 --> Config Class Initialized
INFO - 2016-09-23 09:51:52 --> Hooks Class Initialized
DEBUG - 2016-09-23 09:51:52 --> UTF-8 Support Enabled
INFO - 2016-09-23 09:51:52 --> Utf8 Class Initialized
INFO - 2016-09-23 09:51:52 --> URI Class Initialized
INFO - 2016-09-23 09:51:52 --> Router Class Initialized
INFO - 2016-09-23 09:51:52 --> Output Class Initialized
INFO - 2016-09-23 09:51:52 --> Security Class Initialized
DEBUG - 2016-09-23 09:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 09:51:52 --> Input Class Initialized
INFO - 2016-09-23 09:51:52 --> Language Class Initialized
INFO - 2016-09-23 09:51:52 --> Language Class Initialized
INFO - 2016-09-23 09:51:52 --> Config Class Initialized
INFO - 2016-09-23 09:51:52 --> Loader Class Initialized
INFO - 2016-09-23 09:51:52 --> Helper loaded: url_helper
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 09:51:52 --> Controller Class Initialized
DEBUG - 2016-09-23 09:51:52 --> Index MX_Controller Initialized
INFO - 2016-09-23 09:51:52 --> Model Class Initialized
INFO - 2016-09-23 09:51:52 --> Model Class Initialized
ERROR - 2016-09-23 09:51:52 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-23 09:51:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-23 09:51:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-23 09:51:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-23 09:51:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-23 09:51:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-23 09:51:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-09-23 09:51:52 --> Database Driver Class Initialized
DEBUG - 2016-09-23 09:51:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-23 09:51:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-23 09:51:52 --> Final output sent to browser
DEBUG - 2016-09-23 09:51:52 --> Total execution time: 0.0832
INFO - 2016-09-23 09:51:53 --> Config Class Initialized
INFO - 2016-09-23 09:51:53 --> Hooks Class Initialized
DEBUG - 2016-09-23 09:51:53 --> UTF-8 Support Enabled
INFO - 2016-09-23 09:51:53 --> Utf8 Class Initialized
INFO - 2016-09-23 09:51:53 --> URI Class Initialized
INFO - 2016-09-23 09:51:53 --> Router Class Initialized
INFO - 2016-09-23 09:51:53 --> Output Class Initialized
INFO - 2016-09-23 09:51:53 --> Security Class Initialized
DEBUG - 2016-09-23 09:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 09:51:53 --> Input Class Initialized
INFO - 2016-09-23 09:51:53 --> Language Class Initialized
ERROR - 2016-09-23 09:51:53 --> 404 Page Not Found: /index
INFO - 2016-09-23 09:51:53 --> Config Class Initialized
INFO - 2016-09-23 09:51:53 --> Hooks Class Initialized
DEBUG - 2016-09-23 09:51:53 --> UTF-8 Support Enabled
INFO - 2016-09-23 09:51:53 --> Utf8 Class Initialized
INFO - 2016-09-23 09:51:53 --> URI Class Initialized
INFO - 2016-09-23 09:51:53 --> Router Class Initialized
INFO - 2016-09-23 09:51:53 --> Output Class Initialized
INFO - 2016-09-23 09:51:53 --> Security Class Initialized
DEBUG - 2016-09-23 09:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 09:51:53 --> Input Class Initialized
INFO - 2016-09-23 09:51:53 --> Language Class Initialized
ERROR - 2016-09-23 09:51:53 --> 404 Page Not Found: /index
INFO - 2016-09-23 09:52:19 --> Config Class Initialized
INFO - 2016-09-23 09:52:19 --> Hooks Class Initialized
DEBUG - 2016-09-23 09:52:19 --> UTF-8 Support Enabled
INFO - 2016-09-23 09:52:19 --> Utf8 Class Initialized
INFO - 2016-09-23 09:52:19 --> URI Class Initialized
INFO - 2016-09-23 09:52:19 --> Router Class Initialized
INFO - 2016-09-23 09:52:19 --> Output Class Initialized
INFO - 2016-09-23 09:52:19 --> Security Class Initialized
DEBUG - 2016-09-23 09:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 09:52:19 --> Input Class Initialized
INFO - 2016-09-23 09:52:19 --> Language Class Initialized
INFO - 2016-09-23 09:52:19 --> Language Class Initialized
INFO - 2016-09-23 09:52:19 --> Config Class Initialized
INFO - 2016-09-23 09:52:19 --> Loader Class Initialized
INFO - 2016-09-23 09:52:19 --> Helper loaded: url_helper
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 09:52:19 --> Controller Class Initialized
DEBUG - 2016-09-23 09:52:19 --> Index MX_Controller Initialized
INFO - 2016-09-23 09:52:19 --> Model Class Initialized
INFO - 2016-09-23 09:52:19 --> Model Class Initialized
ERROR - 2016-09-23 09:52:19 --> Unable to delete cache file for admin/index/add/user
DEBUG - 2016-09-23 09:52:19 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-23 09:52:19 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-23 09:52:19 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-23 09:52:19 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/form_user.php
DEBUG - 2016-09-23 09:52:19 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-23 09:52:19 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:19 --> Database Driver Class Initialized
DEBUG - 2016-09-23 09:52:19 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-23 09:52:19 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-23 09:52:19 --> Final output sent to browser
DEBUG - 2016-09-23 09:52:19 --> Total execution time: 0.0928
INFO - 2016-09-23 09:52:20 --> Config Class Initialized
INFO - 2016-09-23 09:52:20 --> Hooks Class Initialized
DEBUG - 2016-09-23 09:52:20 --> UTF-8 Support Enabled
INFO - 2016-09-23 09:52:20 --> Utf8 Class Initialized
INFO - 2016-09-23 09:52:20 --> URI Class Initialized
INFO - 2016-09-23 09:52:20 --> Router Class Initialized
INFO - 2016-09-23 09:52:20 --> Output Class Initialized
INFO - 2016-09-23 09:52:20 --> Security Class Initialized
DEBUG - 2016-09-23 09:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 09:52:20 --> Input Class Initialized
INFO - 2016-09-23 09:52:20 --> Language Class Initialized
ERROR - 2016-09-23 09:52:20 --> 404 Page Not Found: /index
INFO - 2016-09-23 09:52:20 --> Config Class Initialized
INFO - 2016-09-23 09:52:20 --> Hooks Class Initialized
DEBUG - 2016-09-23 09:52:20 --> UTF-8 Support Enabled
INFO - 2016-09-23 09:52:20 --> Utf8 Class Initialized
INFO - 2016-09-23 09:52:20 --> URI Class Initialized
INFO - 2016-09-23 09:52:20 --> Router Class Initialized
INFO - 2016-09-23 09:52:20 --> Output Class Initialized
INFO - 2016-09-23 09:52:20 --> Security Class Initialized
DEBUG - 2016-09-23 09:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 09:52:20 --> Input Class Initialized
INFO - 2016-09-23 09:52:20 --> Language Class Initialized
ERROR - 2016-09-23 09:52:20 --> 404 Page Not Found: /index
INFO - 2016-09-23 09:52:25 --> Config Class Initialized
INFO - 2016-09-23 09:52:25 --> Hooks Class Initialized
DEBUG - 2016-09-23 09:52:25 --> UTF-8 Support Enabled
INFO - 2016-09-23 09:52:25 --> Utf8 Class Initialized
INFO - 2016-09-23 09:52:25 --> URI Class Initialized
INFO - 2016-09-23 09:52:25 --> Router Class Initialized
INFO - 2016-09-23 09:52:25 --> Output Class Initialized
INFO - 2016-09-23 09:52:25 --> Security Class Initialized
DEBUG - 2016-09-23 09:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 09:52:25 --> Input Class Initialized
INFO - 2016-09-23 09:52:25 --> Language Class Initialized
INFO - 2016-09-23 09:52:25 --> Language Class Initialized
INFO - 2016-09-23 09:52:25 --> Config Class Initialized
INFO - 2016-09-23 09:52:25 --> Loader Class Initialized
INFO - 2016-09-23 09:52:25 --> Helper loaded: url_helper
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 09:52:25 --> Controller Class Initialized
DEBUG - 2016-09-23 09:52:25 --> Index MX_Controller Initialized
INFO - 2016-09-23 09:52:25 --> Model Class Initialized
INFO - 2016-09-23 09:52:25 --> Model Class Initialized
ERROR - 2016-09-23 09:52:25 --> Unable to delete cache file for admin/index/data/user
DEBUG - 2016-09-23 09:52:25 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-23 09:52:25 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-23 09:52:25 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-23 09:52:25 --> File already loaded: /home/koperasi/public_html/application/controllers/../modules/user/controllers/Users.php
DEBUG - 2016-09-23 09:52:25 --> Users MX_Controller Initialized
DEBUG - 2016-09-23 09:52:25 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/list_user.php
DEBUG - 2016-09-23 09:52:25 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-23 09:52:25 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:25 --> Database Driver Class Initialized
DEBUG - 2016-09-23 09:52:25 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-23 09:52:25 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-23 09:52:25 --> Final output sent to browser
DEBUG - 2016-09-23 09:52:25 --> Total execution time: 0.0832
INFO - 2016-09-23 09:52:26 --> Config Class Initialized
INFO - 2016-09-23 09:52:26 --> Hooks Class Initialized
INFO - 2016-09-23 09:52:26 --> Config Class Initialized
INFO - 2016-09-23 09:52:26 --> Hooks Class Initialized
DEBUG - 2016-09-23 09:52:26 --> UTF-8 Support Enabled
INFO - 2016-09-23 09:52:26 --> Utf8 Class Initialized
INFO - 2016-09-23 09:52:26 --> URI Class Initialized
INFO - 2016-09-23 09:52:26 --> Router Class Initialized
INFO - 2016-09-23 09:52:26 --> Output Class Initialized
INFO - 2016-09-23 09:52:26 --> Security Class Initialized
DEBUG - 2016-09-23 09:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 09:52:26 --> Input Class Initialized
INFO - 2016-09-23 09:52:26 --> Language Class Initialized
DEBUG - 2016-09-23 09:52:26 --> UTF-8 Support Enabled
INFO - 2016-09-23 09:52:26 --> Utf8 Class Initialized
INFO - 2016-09-23 09:52:26 --> URI Class Initialized
INFO - 2016-09-23 09:52:26 --> Router Class Initialized
INFO - 2016-09-23 09:52:26 --> Output Class Initialized
INFO - 2016-09-23 09:52:26 --> Security Class Initialized
DEBUG - 2016-09-23 09:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 09:52:26 --> Input Class Initialized
INFO - 2016-09-23 09:52:26 --> Language Class Initialized
ERROR - 2016-09-23 09:52:26 --> 404 Page Not Found: /index
ERROR - 2016-09-23 09:52:26 --> 404 Page Not Found: /index
INFO - 2016-09-23 09:52:30 --> Config Class Initialized
INFO - 2016-09-23 09:52:30 --> Hooks Class Initialized
DEBUG - 2016-09-23 09:52:30 --> UTF-8 Support Enabled
INFO - 2016-09-23 09:52:30 --> Utf8 Class Initialized
INFO - 2016-09-23 09:52:30 --> URI Class Initialized
INFO - 2016-09-23 09:52:30 --> Router Class Initialized
INFO - 2016-09-23 09:52:30 --> Output Class Initialized
INFO - 2016-09-23 09:52:30 --> Security Class Initialized
DEBUG - 2016-09-23 09:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 09:52:30 --> Input Class Initialized
INFO - 2016-09-23 09:52:30 --> Language Class Initialized
INFO - 2016-09-23 09:52:30 --> Language Class Initialized
INFO - 2016-09-23 09:52:30 --> Config Class Initialized
INFO - 2016-09-23 09:52:30 --> Loader Class Initialized
INFO - 2016-09-23 09:52:30 --> Helper loaded: url_helper
INFO - 2016-09-23 09:52:30 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 09:52:30 --> Controller Class Initialized
DEBUG - 2016-09-23 09:52:30 --> Index MX_Controller Initialized
INFO - 2016-09-23 09:52:30 --> Model Class Initialized
INFO - 2016-09-23 09:52:30 --> Model Class Initialized
ERROR - 2016-09-23 09:52:30 --> Unable to delete cache file for admin/index/post_get/user/0ade7c2cf97f75d009975f4d720d1fa6c19f4897
DEBUG - 2016-09-23 09:52:30 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-23 09:52:30 --> Users MX_Controller Initialized
INFO - 2016-09-23 09:52:30 --> Final output sent to browser
DEBUG - 2016-09-23 09:52:30 --> Total execution time: 0.0282
INFO - 2016-09-23 09:52:36 --> Config Class Initialized
INFO - 2016-09-23 09:52:36 --> Hooks Class Initialized
DEBUG - 2016-09-23 09:52:36 --> UTF-8 Support Enabled
INFO - 2016-09-23 09:52:36 --> Utf8 Class Initialized
INFO - 2016-09-23 09:52:36 --> URI Class Initialized
INFO - 2016-09-23 09:52:36 --> Router Class Initialized
INFO - 2016-09-23 09:52:36 --> Output Class Initialized
INFO - 2016-09-23 09:52:36 --> Security Class Initialized
DEBUG - 2016-09-23 09:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 09:52:36 --> Input Class Initialized
INFO - 2016-09-23 09:52:36 --> Language Class Initialized
INFO - 2016-09-23 09:52:36 --> Language Class Initialized
INFO - 2016-09-23 09:52:36 --> Config Class Initialized
INFO - 2016-09-23 09:52:36 --> Loader Class Initialized
INFO - 2016-09-23 09:52:36 --> Helper loaded: url_helper
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 09:52:36 --> Controller Class Initialized
DEBUG - 2016-09-23 09:52:36 --> Index MX_Controller Initialized
INFO - 2016-09-23 09:52:36 --> Model Class Initialized
INFO - 2016-09-23 09:52:36 --> Model Class Initialized
ERROR - 2016-09-23 09:52:36 --> Unable to delete cache file for admin/index/upload_foto
DEBUG - 2016-09-23 09:52:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-23 09:52:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-23 09:52:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-23 09:52:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/upload_foto.php
DEBUG - 2016-09-23 09:52:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-23 09:52:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:36 --> Database Driver Class Initialized
DEBUG - 2016-09-23 09:52:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-23 09:52:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-23 09:52:36 --> Final output sent to browser
DEBUG - 2016-09-23 09:52:36 --> Total execution time: 0.1191
INFO - 2016-09-23 09:52:37 --> Config Class Initialized
INFO - 2016-09-23 09:52:37 --> Hooks Class Initialized
DEBUG - 2016-09-23 09:52:37 --> UTF-8 Support Enabled
INFO - 2016-09-23 09:52:37 --> Utf8 Class Initialized
INFO - 2016-09-23 09:52:37 --> URI Class Initialized
INFO - 2016-09-23 09:52:37 --> Router Class Initialized
INFO - 2016-09-23 09:52:37 --> Output Class Initialized
INFO - 2016-09-23 09:52:37 --> Security Class Initialized
DEBUG - 2016-09-23 09:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 09:52:37 --> Input Class Initialized
INFO - 2016-09-23 09:52:37 --> Language Class Initialized
ERROR - 2016-09-23 09:52:37 --> 404 Page Not Found: /index
INFO - 2016-09-23 09:52:37 --> Config Class Initialized
INFO - 2016-09-23 09:52:37 --> Hooks Class Initialized
DEBUG - 2016-09-23 09:52:37 --> UTF-8 Support Enabled
INFO - 2016-09-23 09:52:37 --> Utf8 Class Initialized
INFO - 2016-09-23 09:52:37 --> URI Class Initialized
INFO - 2016-09-23 09:52:37 --> Router Class Initialized
INFO - 2016-09-23 09:52:37 --> Output Class Initialized
INFO - 2016-09-23 09:52:37 --> Security Class Initialized
DEBUG - 2016-09-23 09:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 09:52:37 --> Input Class Initialized
INFO - 2016-09-23 09:52:37 --> Language Class Initialized
ERROR - 2016-09-23 09:52:37 --> 404 Page Not Found: /index
INFO - 2016-09-23 09:52:47 --> Config Class Initialized
INFO - 2016-09-23 09:52:47 --> Hooks Class Initialized
DEBUG - 2016-09-23 09:52:47 --> UTF-8 Support Enabled
INFO - 2016-09-23 09:52:47 --> Utf8 Class Initialized
INFO - 2016-09-23 09:52:47 --> URI Class Initialized
INFO - 2016-09-23 09:52:47 --> Router Class Initialized
INFO - 2016-09-23 09:52:47 --> Output Class Initialized
INFO - 2016-09-23 09:52:47 --> Security Class Initialized
DEBUG - 2016-09-23 09:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 09:52:47 --> Input Class Initialized
INFO - 2016-09-23 09:52:47 --> Language Class Initialized
INFO - 2016-09-23 09:52:48 --> Language Class Initialized
INFO - 2016-09-23 09:52:48 --> Config Class Initialized
INFO - 2016-09-23 09:52:48 --> Loader Class Initialized
INFO - 2016-09-23 09:52:48 --> Helper loaded: url_helper
INFO - 2016-09-23 09:52:48 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 09:52:48 --> Controller Class Initialized
DEBUG - 2016-09-23 09:52:48 --> Index MX_Controller Initialized
INFO - 2016-09-23 09:52:48 --> Model Class Initialized
INFO - 2016-09-23 09:52:48 --> Model Class Initialized
ERROR - 2016-09-23 09:52:48 --> Unable to delete cache file for admin/index/do_upload_foto
INFO - 2016-09-23 09:52:48 --> Upload Class Initialized
INFO - 2016-09-23 09:52:48 --> Final output sent to browser
DEBUG - 2016-09-23 09:52:48 --> Total execution time: 0.0427
INFO - 2016-09-23 09:52:54 --> Config Class Initialized
INFO - 2016-09-23 09:52:54 --> Hooks Class Initialized
DEBUG - 2016-09-23 09:52:54 --> UTF-8 Support Enabled
INFO - 2016-09-23 09:52:54 --> Utf8 Class Initialized
INFO - 2016-09-23 09:52:54 --> URI Class Initialized
INFO - 2016-09-23 09:52:54 --> Router Class Initialized
INFO - 2016-09-23 09:52:54 --> Output Class Initialized
INFO - 2016-09-23 09:52:54 --> Security Class Initialized
DEBUG - 2016-09-23 09:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 09:52:54 --> Input Class Initialized
INFO - 2016-09-23 09:52:54 --> Language Class Initialized
INFO - 2016-09-23 09:52:54 --> Language Class Initialized
INFO - 2016-09-23 09:52:54 --> Config Class Initialized
INFO - 2016-09-23 09:52:54 --> Loader Class Initialized
INFO - 2016-09-23 09:52:54 --> Helper loaded: url_helper
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 09:52:54 --> Controller Class Initialized
DEBUG - 2016-09-23 09:52:54 --> Index MX_Controller Initialized
INFO - 2016-09-23 09:52:54 --> Model Class Initialized
INFO - 2016-09-23 09:52:54 --> Model Class Initialized
ERROR - 2016-09-23 09:52:54 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-23 09:52:54 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-23 09:52:54 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-23 09:52:54 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-23 09:52:54 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-23 09:52:54 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-23 09:52:54 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
INFO - 2016-09-23 09:52:54 --> Database Driver Class Initialized
DEBUG - 2016-09-23 09:52:54 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-23 09:52:54 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-23 09:52:54 --> Final output sent to browser
DEBUG - 2016-09-23 09:52:54 --> Total execution time: 0.0836
INFO - 2016-09-23 09:52:55 --> Config Class Initialized
INFO - 2016-09-23 09:52:55 --> Hooks Class Initialized
DEBUG - 2016-09-23 09:52:55 --> UTF-8 Support Enabled
INFO - 2016-09-23 09:52:55 --> Utf8 Class Initialized
INFO - 2016-09-23 09:52:55 --> URI Class Initialized
INFO - 2016-09-23 09:52:55 --> Router Class Initialized
INFO - 2016-09-23 09:52:55 --> Output Class Initialized
INFO - 2016-09-23 09:52:55 --> Security Class Initialized
DEBUG - 2016-09-23 09:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 09:52:55 --> Input Class Initialized
INFO - 2016-09-23 09:52:55 --> Language Class Initialized
ERROR - 2016-09-23 09:52:55 --> 404 Page Not Found: /index
INFO - 2016-09-23 11:33:15 --> Config Class Initialized
INFO - 2016-09-23 11:33:15 --> Hooks Class Initialized
DEBUG - 2016-09-23 11:33:15 --> UTF-8 Support Enabled
INFO - 2016-09-23 11:33:15 --> Utf8 Class Initialized
INFO - 2016-09-23 11:33:15 --> URI Class Initialized
DEBUG - 2016-09-23 11:33:15 --> No URI present. Default controller set.
INFO - 2016-09-23 11:33:15 --> Router Class Initialized
INFO - 2016-09-23 11:33:15 --> Output Class Initialized
INFO - 2016-09-23 11:33:15 --> Security Class Initialized
DEBUG - 2016-09-23 11:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 11:33:15 --> Input Class Initialized
INFO - 2016-09-23 11:33:15 --> Language Class Initialized
INFO - 2016-09-23 11:33:15 --> Language Class Initialized
INFO - 2016-09-23 11:33:15 --> Config Class Initialized
INFO - 2016-09-23 11:33:15 --> Loader Class Initialized
INFO - 2016-09-23 11:33:15 --> Helper loaded: url_helper
INFO - 2016-09-23 11:33:15 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 11:33:15 --> Controller Class Initialized
DEBUG - 2016-09-23 11:33:15 --> Index MX_Controller Initialized
INFO - 2016-09-23 11:33:15 --> Model Class Initialized
INFO - 2016-09-23 11:33:15 --> Model Class Initialized
ERROR - 2016-09-23 11:33:15 --> Unable to delete cache file for 
DEBUG - 2016-09-23 11:33:15 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-23 11:33:15 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-23 11:33:15 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-23 11:33:15 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-23 11:33:15 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-23 11:33:15 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-23 11:33:15 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:15 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:15 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:15 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:15 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:15 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:15 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:15 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:15 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:15 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:15 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:15 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:15 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:15 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:15 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:16 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:16 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:16 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:16 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:16 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:16 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:16 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:16 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:16 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:16 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:16 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:16 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:16 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:16 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:16 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:16 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:16 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:16 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:16 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:16 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:16 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:16 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:16 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:16 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:16 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:16 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:16 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:16 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:16 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:16 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:16 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:16 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:16 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:16 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:16 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:16 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:16 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:16 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:16 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:16 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:16 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:16 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:16 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:16 --> Database Driver Class Initialized
DEBUG - 2016-09-23 11:33:16 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-23 11:33:16 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-23 11:33:16 --> Final output sent to browser
DEBUG - 2016-09-23 11:33:16 --> Total execution time: 0.1245
INFO - 2016-09-23 11:33:16 --> Config Class Initialized
INFO - 2016-09-23 11:33:16 --> Hooks Class Initialized
DEBUG - 2016-09-23 11:33:16 --> UTF-8 Support Enabled
INFO - 2016-09-23 11:33:16 --> Utf8 Class Initialized
INFO - 2016-09-23 11:33:16 --> URI Class Initialized
INFO - 2016-09-23 11:33:16 --> Router Class Initialized
INFO - 2016-09-23 11:33:16 --> Output Class Initialized
INFO - 2016-09-23 11:33:16 --> Security Class Initialized
DEBUG - 2016-09-23 11:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 11:33:16 --> Input Class Initialized
INFO - 2016-09-23 11:33:16 --> Language Class Initialized
INFO - 2016-09-23 11:33:16 --> Language Class Initialized
INFO - 2016-09-23 11:33:16 --> Config Class Initialized
INFO - 2016-09-23 11:33:16 --> Loader Class Initialized
INFO - 2016-09-23 11:33:16 --> Helper loaded: url_helper
INFO - 2016-09-23 11:33:16 --> Database Driver Class Initialized
INFO - 2016-09-23 11:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 11:33:16 --> Controller Class Initialized
DEBUG - 2016-09-23 11:33:16 --> login MX_Controller Initialized
INFO - 2016-09-23 11:33:16 --> Model Class Initialized
INFO - 2016-09-23 11:33:16 --> Model Class Initialized
DEBUG - 2016-09-23 11:33:16 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-23 11:33:16 --> Final output sent to browser
DEBUG - 2016-09-23 11:33:16 --> Total execution time: 0.0253
INFO - 2016-09-23 11:34:08 --> Config Class Initialized
INFO - 2016-09-23 11:34:08 --> Hooks Class Initialized
DEBUG - 2016-09-23 11:34:08 --> UTF-8 Support Enabled
INFO - 2016-09-23 11:34:08 --> Utf8 Class Initialized
INFO - 2016-09-23 11:34:08 --> URI Class Initialized
INFO - 2016-09-23 11:34:08 --> Router Class Initialized
INFO - 2016-09-23 11:34:08 --> Output Class Initialized
INFO - 2016-09-23 11:34:08 --> Security Class Initialized
DEBUG - 2016-09-23 11:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 11:34:08 --> Input Class Initialized
INFO - 2016-09-23 11:34:08 --> Language Class Initialized
INFO - 2016-09-23 11:34:08 --> Language Class Initialized
INFO - 2016-09-23 11:34:08 --> Config Class Initialized
INFO - 2016-09-23 11:34:08 --> Loader Class Initialized
INFO - 2016-09-23 11:34:08 --> Helper loaded: url_helper
INFO - 2016-09-23 11:34:08 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 11:34:08 --> Controller Class Initialized
DEBUG - 2016-09-23 11:34:08 --> login MX_Controller Initialized
INFO - 2016-09-23 11:34:08 --> Model Class Initialized
INFO - 2016-09-23 11:34:08 --> Model Class Initialized
DEBUG - 2016-09-23 11:34:08 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-23 11:34:08 --> Final output sent to browser
DEBUG - 2016-09-23 11:34:08 --> Total execution time: 0.0228
INFO - 2016-09-23 11:34:54 --> Config Class Initialized
INFO - 2016-09-23 11:34:54 --> Hooks Class Initialized
DEBUG - 2016-09-23 11:34:54 --> UTF-8 Support Enabled
INFO - 2016-09-23 11:34:54 --> Utf8 Class Initialized
INFO - 2016-09-23 11:34:54 --> URI Class Initialized
DEBUG - 2016-09-23 11:34:54 --> No URI present. Default controller set.
INFO - 2016-09-23 11:34:54 --> Router Class Initialized
INFO - 2016-09-23 11:34:54 --> Output Class Initialized
INFO - 2016-09-23 11:34:54 --> Security Class Initialized
DEBUG - 2016-09-23 11:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 11:34:54 --> Input Class Initialized
INFO - 2016-09-23 11:34:54 --> Language Class Initialized
INFO - 2016-09-23 11:34:54 --> Language Class Initialized
INFO - 2016-09-23 11:34:54 --> Config Class Initialized
INFO - 2016-09-23 11:34:54 --> Loader Class Initialized
INFO - 2016-09-23 11:34:54 --> Helper loaded: url_helper
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 11:34:54 --> Controller Class Initialized
DEBUG - 2016-09-23 11:34:54 --> Index MX_Controller Initialized
INFO - 2016-09-23 11:34:54 --> Model Class Initialized
INFO - 2016-09-23 11:34:54 --> Model Class Initialized
ERROR - 2016-09-23 11:34:54 --> Unable to delete cache file for 
DEBUG - 2016-09-23 11:34:54 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-23 11:34:54 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-23 11:34:54 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-23 11:34:54 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-23 11:34:54 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-23 11:34:54 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:54 --> Database Driver Class Initialized
DEBUG - 2016-09-23 11:34:54 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-23 11:34:54 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-23 11:34:54 --> Final output sent to browser
DEBUG - 2016-09-23 11:34:54 --> Total execution time: 0.0974
INFO - 2016-09-23 11:34:55 --> Config Class Initialized
INFO - 2016-09-23 11:34:55 --> Hooks Class Initialized
DEBUG - 2016-09-23 11:34:55 --> UTF-8 Support Enabled
INFO - 2016-09-23 11:34:55 --> Utf8 Class Initialized
INFO - 2016-09-23 11:34:55 --> URI Class Initialized
INFO - 2016-09-23 11:34:55 --> Router Class Initialized
INFO - 2016-09-23 11:34:55 --> Output Class Initialized
INFO - 2016-09-23 11:34:55 --> Security Class Initialized
DEBUG - 2016-09-23 11:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 11:34:55 --> Input Class Initialized
INFO - 2016-09-23 11:34:55 --> Language Class Initialized
INFO - 2016-09-23 11:34:55 --> Language Class Initialized
INFO - 2016-09-23 11:34:55 --> Config Class Initialized
INFO - 2016-09-23 11:34:55 --> Loader Class Initialized
INFO - 2016-09-23 11:34:55 --> Helper loaded: url_helper
INFO - 2016-09-23 11:34:55 --> Database Driver Class Initialized
INFO - 2016-09-23 11:34:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 11:34:55 --> Controller Class Initialized
DEBUG - 2016-09-23 11:34:55 --> login MX_Controller Initialized
INFO - 2016-09-23 11:34:55 --> Model Class Initialized
INFO - 2016-09-23 11:34:55 --> Model Class Initialized
DEBUG - 2016-09-23 11:34:55 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-23 11:34:55 --> Final output sent to browser
DEBUG - 2016-09-23 11:34:55 --> Total execution time: 0.0251
INFO - 2016-09-23 11:36:17 --> Config Class Initialized
INFO - 2016-09-23 11:36:17 --> Hooks Class Initialized
DEBUG - 2016-09-23 11:36:17 --> UTF-8 Support Enabled
INFO - 2016-09-23 11:36:17 --> Utf8 Class Initialized
INFO - 2016-09-23 11:36:17 --> URI Class Initialized
DEBUG - 2016-09-23 11:36:17 --> No URI present. Default controller set.
INFO - 2016-09-23 11:36:17 --> Router Class Initialized
INFO - 2016-09-23 11:36:17 --> Output Class Initialized
INFO - 2016-09-23 11:36:17 --> Security Class Initialized
DEBUG - 2016-09-23 11:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 11:36:17 --> Input Class Initialized
INFO - 2016-09-23 11:36:17 --> Language Class Initialized
INFO - 2016-09-23 11:36:17 --> Language Class Initialized
INFO - 2016-09-23 11:36:17 --> Config Class Initialized
INFO - 2016-09-23 11:36:17 --> Loader Class Initialized
INFO - 2016-09-23 11:36:17 --> Helper loaded: url_helper
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 11:36:17 --> Controller Class Initialized
DEBUG - 2016-09-23 11:36:17 --> Index MX_Controller Initialized
INFO - 2016-09-23 11:36:17 --> Model Class Initialized
INFO - 2016-09-23 11:36:17 --> Model Class Initialized
ERROR - 2016-09-23 11:36:17 --> Unable to delete cache file for 
DEBUG - 2016-09-23 11:36:17 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-23 11:36:17 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-23 11:36:17 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-23 11:36:17 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-23 11:36:17 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-23 11:36:17 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:17 --> Database Driver Class Initialized
DEBUG - 2016-09-23 11:36:17 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-23 11:36:17 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-23 11:36:17 --> Final output sent to browser
DEBUG - 2016-09-23 11:36:17 --> Total execution time: 0.1003
INFO - 2016-09-23 11:36:18 --> Config Class Initialized
INFO - 2016-09-23 11:36:18 --> Hooks Class Initialized
DEBUG - 2016-09-23 11:36:18 --> UTF-8 Support Enabled
INFO - 2016-09-23 11:36:18 --> Utf8 Class Initialized
INFO - 2016-09-23 11:36:18 --> URI Class Initialized
INFO - 2016-09-23 11:36:18 --> Router Class Initialized
INFO - 2016-09-23 11:36:18 --> Output Class Initialized
INFO - 2016-09-23 11:36:18 --> Security Class Initialized
DEBUG - 2016-09-23 11:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 11:36:18 --> Input Class Initialized
INFO - 2016-09-23 11:36:18 --> Language Class Initialized
INFO - 2016-09-23 11:36:18 --> Language Class Initialized
INFO - 2016-09-23 11:36:18 --> Config Class Initialized
INFO - 2016-09-23 11:36:18 --> Loader Class Initialized
INFO - 2016-09-23 11:36:18 --> Helper loaded: url_helper
INFO - 2016-09-23 11:36:18 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 11:36:18 --> Controller Class Initialized
DEBUG - 2016-09-23 11:36:18 --> login MX_Controller Initialized
INFO - 2016-09-23 11:36:18 --> Model Class Initialized
INFO - 2016-09-23 11:36:18 --> Model Class Initialized
DEBUG - 2016-09-23 11:36:18 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-23 11:36:18 --> Final output sent to browser
DEBUG - 2016-09-23 11:36:18 --> Total execution time: 0.0209
INFO - 2016-09-23 11:36:27 --> Config Class Initialized
INFO - 2016-09-23 11:36:27 --> Hooks Class Initialized
DEBUG - 2016-09-23 11:36:27 --> UTF-8 Support Enabled
INFO - 2016-09-23 11:36:27 --> Utf8 Class Initialized
INFO - 2016-09-23 11:36:27 --> URI Class Initialized
INFO - 2016-09-23 11:36:27 --> Router Class Initialized
INFO - 2016-09-23 11:36:27 --> Output Class Initialized
INFO - 2016-09-23 11:36:27 --> Security Class Initialized
DEBUG - 2016-09-23 11:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 11:36:27 --> Input Class Initialized
INFO - 2016-09-23 11:36:27 --> Language Class Initialized
INFO - 2016-09-23 11:36:27 --> Language Class Initialized
INFO - 2016-09-23 11:36:27 --> Config Class Initialized
INFO - 2016-09-23 11:36:27 --> Loader Class Initialized
INFO - 2016-09-23 11:36:27 --> Helper loaded: url_helper
INFO - 2016-09-23 11:36:27 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 11:36:27 --> Controller Class Initialized
DEBUG - 2016-09-23 11:36:27 --> login MX_Controller Initialized
INFO - 2016-09-23 11:36:27 --> Model Class Initialized
INFO - 2016-09-23 11:36:27 --> Model Class Initialized
INFO - 2016-09-23 11:36:27 --> Final output sent to browser
DEBUG - 2016-09-23 11:36:27 --> Total execution time: 0.0269
INFO - 2016-09-23 11:36:37 --> Config Class Initialized
INFO - 2016-09-23 11:36:37 --> Hooks Class Initialized
DEBUG - 2016-09-23 11:36:37 --> UTF-8 Support Enabled
INFO - 2016-09-23 11:36:37 --> Utf8 Class Initialized
INFO - 2016-09-23 11:36:37 --> URI Class Initialized
INFO - 2016-09-23 11:36:37 --> Router Class Initialized
INFO - 2016-09-23 11:36:37 --> Output Class Initialized
INFO - 2016-09-23 11:36:37 --> Security Class Initialized
DEBUG - 2016-09-23 11:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 11:36:37 --> Input Class Initialized
INFO - 2016-09-23 11:36:37 --> Language Class Initialized
INFO - 2016-09-23 11:36:37 --> Language Class Initialized
INFO - 2016-09-23 11:36:37 --> Config Class Initialized
INFO - 2016-09-23 11:36:37 --> Loader Class Initialized
INFO - 2016-09-23 11:36:37 --> Helper loaded: url_helper
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 11:36:37 --> Controller Class Initialized
DEBUG - 2016-09-23 11:36:37 --> login MX_Controller Initialized
INFO - 2016-09-23 11:36:37 --> Model Class Initialized
INFO - 2016-09-23 11:36:37 --> Model Class Initialized
INFO - 2016-09-23 11:36:37 --> Final output sent to browser
DEBUG - 2016-09-23 11:36:37 --> Total execution time: 0.0264
INFO - 2016-09-23 11:36:37 --> Config Class Initialized
INFO - 2016-09-23 11:36:37 --> Hooks Class Initialized
DEBUG - 2016-09-23 11:36:37 --> UTF-8 Support Enabled
INFO - 2016-09-23 11:36:37 --> Utf8 Class Initialized
INFO - 2016-09-23 11:36:37 --> URI Class Initialized
INFO - 2016-09-23 11:36:37 --> Router Class Initialized
INFO - 2016-09-23 11:36:37 --> Output Class Initialized
INFO - 2016-09-23 11:36:37 --> Security Class Initialized
DEBUG - 2016-09-23 11:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 11:36:37 --> Input Class Initialized
INFO - 2016-09-23 11:36:37 --> Language Class Initialized
INFO - 2016-09-23 11:36:37 --> Language Class Initialized
INFO - 2016-09-23 11:36:37 --> Config Class Initialized
INFO - 2016-09-23 11:36:37 --> Loader Class Initialized
INFO - 2016-09-23 11:36:37 --> Helper loaded: url_helper
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 11:36:37 --> Controller Class Initialized
DEBUG - 2016-09-23 11:36:37 --> Index MX_Controller Initialized
INFO - 2016-09-23 11:36:37 --> Model Class Initialized
INFO - 2016-09-23 11:36:37 --> Model Class Initialized
ERROR - 2016-09-23 11:36:37 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-23 11:36:37 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-23 11:36:37 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-23 11:36:37 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-23 11:36:37 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-23 11:36:37 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-23 11:36:37 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
INFO - 2016-09-23 11:36:37 --> Database Driver Class Initialized
DEBUG - 2016-09-23 11:36:37 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-23 11:36:37 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-23 11:36:37 --> Final output sent to browser
DEBUG - 2016-09-23 11:36:37 --> Total execution time: 0.0799
INFO - 2016-09-23 11:36:42 --> Config Class Initialized
INFO - 2016-09-23 11:36:42 --> Hooks Class Initialized
DEBUG - 2016-09-23 11:36:42 --> UTF-8 Support Enabled
INFO - 2016-09-23 11:36:42 --> Utf8 Class Initialized
INFO - 2016-09-23 11:36:42 --> URI Class Initialized
INFO - 2016-09-23 11:36:42 --> Router Class Initialized
INFO - 2016-09-23 11:36:42 --> Output Class Initialized
INFO - 2016-09-23 11:36:42 --> Security Class Initialized
DEBUG - 2016-09-23 11:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 11:36:42 --> Input Class Initialized
INFO - 2016-09-23 11:36:42 --> Language Class Initialized
ERROR - 2016-09-23 11:36:42 --> 404 Page Not Found: /index
INFO - 2016-09-23 11:40:14 --> Config Class Initialized
INFO - 2016-09-23 11:40:14 --> Hooks Class Initialized
DEBUG - 2016-09-23 11:40:14 --> UTF-8 Support Enabled
INFO - 2016-09-23 11:40:14 --> Utf8 Class Initialized
INFO - 2016-09-23 11:40:14 --> URI Class Initialized
DEBUG - 2016-09-23 11:40:14 --> No URI present. Default controller set.
INFO - 2016-09-23 11:40:14 --> Router Class Initialized
INFO - 2016-09-23 11:40:14 --> Output Class Initialized
INFO - 2016-09-23 11:40:14 --> Security Class Initialized
DEBUG - 2016-09-23 11:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 11:40:14 --> Input Class Initialized
INFO - 2016-09-23 11:40:14 --> Language Class Initialized
INFO - 2016-09-23 11:40:14 --> Language Class Initialized
INFO - 2016-09-23 11:40:14 --> Config Class Initialized
INFO - 2016-09-23 11:40:14 --> Loader Class Initialized
INFO - 2016-09-23 11:40:14 --> Helper loaded: url_helper
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 11:40:14 --> Controller Class Initialized
DEBUG - 2016-09-23 11:40:14 --> Index MX_Controller Initialized
INFO - 2016-09-23 11:40:14 --> Model Class Initialized
INFO - 2016-09-23 11:40:14 --> Model Class Initialized
ERROR - 2016-09-23 11:40:14 --> Unable to delete cache file for 
DEBUG - 2016-09-23 11:40:14 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-23 11:40:14 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-23 11:40:14 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-23 11:40:14 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-23 11:40:14 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-23 11:40:14 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:14 --> Database Driver Class Initialized
DEBUG - 2016-09-23 11:40:14 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-23 11:40:14 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-23 11:40:14 --> Final output sent to browser
DEBUG - 2016-09-23 11:40:14 --> Total execution time: 0.1102
INFO - 2016-09-23 11:40:14 --> Config Class Initialized
INFO - 2016-09-23 11:40:14 --> Hooks Class Initialized
DEBUG - 2016-09-23 11:40:14 --> UTF-8 Support Enabled
INFO - 2016-09-23 11:40:14 --> Utf8 Class Initialized
INFO - 2016-09-23 11:40:14 --> URI Class Initialized
INFO - 2016-09-23 11:40:14 --> Router Class Initialized
INFO - 2016-09-23 11:40:14 --> Output Class Initialized
INFO - 2016-09-23 11:40:14 --> Security Class Initialized
DEBUG - 2016-09-23 11:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 11:40:14 --> Input Class Initialized
INFO - 2016-09-23 11:40:14 --> Language Class Initialized
ERROR - 2016-09-23 11:40:14 --> 404 Page Not Found: /index
INFO - 2016-09-23 11:40:25 --> Config Class Initialized
INFO - 2016-09-23 11:40:25 --> Hooks Class Initialized
DEBUG - 2016-09-23 11:40:25 --> UTF-8 Support Enabled
INFO - 2016-09-23 11:40:25 --> Utf8 Class Initialized
INFO - 2016-09-23 11:40:25 --> URI Class Initialized
INFO - 2016-09-23 11:40:25 --> Router Class Initialized
INFO - 2016-09-23 11:40:25 --> Output Class Initialized
INFO - 2016-09-23 11:40:25 --> Security Class Initialized
DEBUG - 2016-09-23 11:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 11:40:25 --> Input Class Initialized
INFO - 2016-09-23 11:40:25 --> Language Class Initialized
INFO - 2016-09-23 11:40:25 --> Language Class Initialized
INFO - 2016-09-23 11:40:25 --> Config Class Initialized
INFO - 2016-09-23 11:40:25 --> Loader Class Initialized
INFO - 2016-09-23 11:40:25 --> Helper loaded: url_helper
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 11:40:25 --> Controller Class Initialized
DEBUG - 2016-09-23 11:40:25 --> Index MX_Controller Initialized
INFO - 2016-09-23 11:40:25 --> Model Class Initialized
INFO - 2016-09-23 11:40:25 --> Model Class Initialized
ERROR - 2016-09-23 11:40:25 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-23 11:40:25 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-23 11:40:25 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-23 11:40:25 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-23 11:40:25 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-23 11:40:25 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-23 11:40:25 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:25 --> Database Driver Class Initialized
DEBUG - 2016-09-23 11:40:25 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-23 11:40:25 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-23 11:40:25 --> Final output sent to browser
DEBUG - 2016-09-23 11:40:25 --> Total execution time: 0.0884
INFO - 2016-09-23 11:40:25 --> Config Class Initialized
INFO - 2016-09-23 11:40:25 --> Hooks Class Initialized
DEBUG - 2016-09-23 11:40:25 --> UTF-8 Support Enabled
INFO - 2016-09-23 11:40:25 --> Utf8 Class Initialized
INFO - 2016-09-23 11:40:25 --> URI Class Initialized
INFO - 2016-09-23 11:40:25 --> Router Class Initialized
INFO - 2016-09-23 11:40:25 --> Output Class Initialized
INFO - 2016-09-23 11:40:25 --> Security Class Initialized
DEBUG - 2016-09-23 11:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 11:40:25 --> Input Class Initialized
INFO - 2016-09-23 11:40:25 --> Language Class Initialized
ERROR - 2016-09-23 11:40:25 --> 404 Page Not Found: /index
INFO - 2016-09-23 11:40:39 --> Config Class Initialized
INFO - 2016-09-23 11:40:39 --> Hooks Class Initialized
DEBUG - 2016-09-23 11:40:39 --> UTF-8 Support Enabled
INFO - 2016-09-23 11:40:39 --> Utf8 Class Initialized
INFO - 2016-09-23 11:40:39 --> URI Class Initialized
INFO - 2016-09-23 11:40:39 --> Router Class Initialized
INFO - 2016-09-23 11:40:39 --> Output Class Initialized
INFO - 2016-09-23 11:40:39 --> Security Class Initialized
DEBUG - 2016-09-23 11:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 11:40:39 --> Input Class Initialized
INFO - 2016-09-23 11:40:39 --> Language Class Initialized
INFO - 2016-09-23 11:40:39 --> Language Class Initialized
INFO - 2016-09-23 11:40:39 --> Config Class Initialized
INFO - 2016-09-23 11:40:39 --> Loader Class Initialized
INFO - 2016-09-23 11:40:39 --> Helper loaded: url_helper
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 11:40:39 --> Controller Class Initialized
DEBUG - 2016-09-23 11:40:39 --> Index MX_Controller Initialized
INFO - 2016-09-23 11:40:39 --> Model Class Initialized
INFO - 2016-09-23 11:40:39 --> Model Class Initialized
ERROR - 2016-09-23 11:40:39 --> Unable to delete cache file for admin/index/data_peminjam
DEBUG - 2016-09-23 11:40:39 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-23 11:40:39 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-23 11:40:39 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-23 11:40:39 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/list_peminjam.php
DEBUG - 2016-09-23 11:40:39 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-23 11:40:39 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:39 --> Database Driver Class Initialized
DEBUG - 2016-09-23 11:40:39 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-23 11:40:39 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-23 11:40:39 --> Final output sent to browser
DEBUG - 2016-09-23 11:40:39 --> Total execution time: 0.0953
INFO - 2016-09-23 11:40:39 --> Config Class Initialized
INFO - 2016-09-23 11:40:39 --> Hooks Class Initialized
DEBUG - 2016-09-23 11:40:39 --> UTF-8 Support Enabled
INFO - 2016-09-23 11:40:39 --> Utf8 Class Initialized
INFO - 2016-09-23 11:40:39 --> URI Class Initialized
INFO - 2016-09-23 11:40:39 --> Router Class Initialized
INFO - 2016-09-23 11:40:39 --> Output Class Initialized
INFO - 2016-09-23 11:40:39 --> Security Class Initialized
DEBUG - 2016-09-23 11:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 11:40:39 --> Input Class Initialized
INFO - 2016-09-23 11:40:39 --> Language Class Initialized
ERROR - 2016-09-23 11:40:39 --> 404 Page Not Found: /index
INFO - 2016-09-23 11:40:56 --> Config Class Initialized
INFO - 2016-09-23 11:40:56 --> Hooks Class Initialized
DEBUG - 2016-09-23 11:40:56 --> UTF-8 Support Enabled
INFO - 2016-09-23 11:40:56 --> Utf8 Class Initialized
INFO - 2016-09-23 11:40:56 --> URI Class Initialized
INFO - 2016-09-23 11:40:56 --> Router Class Initialized
INFO - 2016-09-23 11:40:56 --> Output Class Initialized
INFO - 2016-09-23 11:40:56 --> Security Class Initialized
DEBUG - 2016-09-23 11:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 11:40:56 --> Input Class Initialized
INFO - 2016-09-23 11:40:56 --> Language Class Initialized
INFO - 2016-09-23 11:40:56 --> Language Class Initialized
INFO - 2016-09-23 11:40:56 --> Config Class Initialized
INFO - 2016-09-23 11:40:56 --> Loader Class Initialized
INFO - 2016-09-23 11:40:56 --> Helper loaded: url_helper
INFO - 2016-09-23 11:40:56 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 11:40:56 --> Controller Class Initialized
DEBUG - 2016-09-23 11:40:56 --> Index MX_Controller Initialized
INFO - 2016-09-23 11:40:56 --> Model Class Initialized
INFO - 2016-09-23 11:40:56 --> Model Class Initialized
ERROR - 2016-09-23 11:40:56 --> Unable to delete cache file for admin/index/tabungan
DEBUG - 2016-09-23 11:40:57 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-23 11:40:57 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-23 11:40:57 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-23 11:40:57 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/list_nasabah_tabungan.php
DEBUG - 2016-09-23 11:40:57 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/form_tabungan.php
DEBUG - 2016-09-23 11:40:57 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-23 11:40:57 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
INFO - 2016-09-23 11:40:57 --> Database Driver Class Initialized
DEBUG - 2016-09-23 11:40:57 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-23 11:40:57 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-23 11:40:57 --> Final output sent to browser
DEBUG - 2016-09-23 11:40:57 --> Total execution time: 0.1025
INFO - 2016-09-23 11:40:57 --> Config Class Initialized
INFO - 2016-09-23 11:40:57 --> Hooks Class Initialized
DEBUG - 2016-09-23 11:40:57 --> UTF-8 Support Enabled
INFO - 2016-09-23 11:40:57 --> Utf8 Class Initialized
INFO - 2016-09-23 11:40:57 --> URI Class Initialized
INFO - 2016-09-23 11:40:57 --> Router Class Initialized
INFO - 2016-09-23 11:40:57 --> Output Class Initialized
INFO - 2016-09-23 11:40:57 --> Security Class Initialized
DEBUG - 2016-09-23 11:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 11:40:57 --> Input Class Initialized
INFO - 2016-09-23 11:40:57 --> Language Class Initialized
ERROR - 2016-09-23 11:40:57 --> 404 Page Not Found: /index
INFO - 2016-09-23 12:03:35 --> Config Class Initialized
INFO - 2016-09-23 12:03:35 --> Hooks Class Initialized
DEBUG - 2016-09-23 12:03:35 --> UTF-8 Support Enabled
INFO - 2016-09-23 12:03:35 --> Utf8 Class Initialized
INFO - 2016-09-23 12:03:35 --> URI Class Initialized
DEBUG - 2016-09-23 12:03:35 --> No URI present. Default controller set.
INFO - 2016-09-23 12:03:35 --> Router Class Initialized
INFO - 2016-09-23 12:03:35 --> Output Class Initialized
INFO - 2016-09-23 12:03:35 --> Security Class Initialized
DEBUG - 2016-09-23 12:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 12:03:35 --> Input Class Initialized
INFO - 2016-09-23 12:03:35 --> Language Class Initialized
INFO - 2016-09-23 12:03:35 --> Language Class Initialized
INFO - 2016-09-23 12:03:35 --> Config Class Initialized
INFO - 2016-09-23 12:03:35 --> Loader Class Initialized
INFO - 2016-09-23 12:03:35 --> Helper loaded: url_helper
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 12:03:35 --> Controller Class Initialized
DEBUG - 2016-09-23 12:03:35 --> Index MX_Controller Initialized
INFO - 2016-09-23 12:03:35 --> Model Class Initialized
INFO - 2016-09-23 12:03:35 --> Model Class Initialized
ERROR - 2016-09-23 12:03:35 --> Unable to delete cache file for 
DEBUG - 2016-09-23 12:03:35 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-23 12:03:35 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-23 12:03:35 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-23 12:03:35 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-23 12:03:35 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-23 12:03:35 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:35 --> Database Driver Class Initialized
DEBUG - 2016-09-23 12:03:35 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-23 12:03:35 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-23 12:03:35 --> Final output sent to browser
DEBUG - 2016-09-23 12:03:35 --> Total execution time: 0.1061
INFO - 2016-09-23 12:03:36 --> Config Class Initialized
INFO - 2016-09-23 12:03:36 --> Hooks Class Initialized
DEBUG - 2016-09-23 12:03:36 --> UTF-8 Support Enabled
INFO - 2016-09-23 12:03:36 --> Utf8 Class Initialized
INFO - 2016-09-23 12:03:36 --> URI Class Initialized
INFO - 2016-09-23 12:03:36 --> Router Class Initialized
INFO - 2016-09-23 12:03:36 --> Output Class Initialized
INFO - 2016-09-23 12:03:36 --> Security Class Initialized
DEBUG - 2016-09-23 12:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 12:03:36 --> Input Class Initialized
INFO - 2016-09-23 12:03:36 --> Language Class Initialized
INFO - 2016-09-23 12:03:36 --> Language Class Initialized
INFO - 2016-09-23 12:03:36 --> Config Class Initialized
INFO - 2016-09-23 12:03:36 --> Loader Class Initialized
INFO - 2016-09-23 12:03:36 --> Helper loaded: url_helper
INFO - 2016-09-23 12:03:36 --> Database Driver Class Initialized
INFO - 2016-09-23 12:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 12:03:36 --> Controller Class Initialized
DEBUG - 2016-09-23 12:03:36 --> login MX_Controller Initialized
INFO - 2016-09-23 12:03:36 --> Model Class Initialized
INFO - 2016-09-23 12:03:36 --> Model Class Initialized
DEBUG - 2016-09-23 12:03:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-23 12:03:36 --> Final output sent to browser
DEBUG - 2016-09-23 12:03:36 --> Total execution time: 0.0224
INFO - 2016-09-23 13:49:46 --> Config Class Initialized
INFO - 2016-09-23 13:49:46 --> Hooks Class Initialized
DEBUG - 2016-09-23 13:49:46 --> UTF-8 Support Enabled
INFO - 2016-09-23 13:49:46 --> Utf8 Class Initialized
INFO - 2016-09-23 13:49:46 --> URI Class Initialized
DEBUG - 2016-09-23 13:49:46 --> No URI present. Default controller set.
INFO - 2016-09-23 13:49:46 --> Router Class Initialized
INFO - 2016-09-23 13:49:46 --> Output Class Initialized
INFO - 2016-09-23 13:49:46 --> Security Class Initialized
DEBUG - 2016-09-23 13:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 13:49:46 --> Input Class Initialized
INFO - 2016-09-23 13:49:46 --> Language Class Initialized
INFO - 2016-09-23 13:49:46 --> Language Class Initialized
INFO - 2016-09-23 13:49:46 --> Config Class Initialized
INFO - 2016-09-23 13:49:46 --> Loader Class Initialized
INFO - 2016-09-23 13:49:46 --> Helper loaded: url_helper
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 13:49:46 --> Controller Class Initialized
DEBUG - 2016-09-23 13:49:46 --> Index MX_Controller Initialized
INFO - 2016-09-23 13:49:46 --> Model Class Initialized
INFO - 2016-09-23 13:49:46 --> Model Class Initialized
ERROR - 2016-09-23 13:49:46 --> Unable to delete cache file for 
DEBUG - 2016-09-23 13:49:46 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-23 13:49:46 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-23 13:49:46 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-23 13:49:46 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-23 13:49:46 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-23 13:49:46 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
DEBUG - 2016-09-23 13:49:46 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-23 13:49:46 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-23 13:49:46 --> Final output sent to browser
DEBUG - 2016-09-23 13:49:46 --> Total execution time: 0.0926
INFO - 2016-09-23 13:49:46 --> Config Class Initialized
INFO - 2016-09-23 13:49:46 --> Hooks Class Initialized
DEBUG - 2016-09-23 13:49:46 --> UTF-8 Support Enabled
INFO - 2016-09-23 13:49:46 --> Utf8 Class Initialized
INFO - 2016-09-23 13:49:46 --> URI Class Initialized
INFO - 2016-09-23 13:49:46 --> Router Class Initialized
INFO - 2016-09-23 13:49:46 --> Output Class Initialized
INFO - 2016-09-23 13:49:46 --> Security Class Initialized
DEBUG - 2016-09-23 13:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 13:49:46 --> Input Class Initialized
INFO - 2016-09-23 13:49:46 --> Language Class Initialized
INFO - 2016-09-23 13:49:46 --> Language Class Initialized
INFO - 2016-09-23 13:49:46 --> Config Class Initialized
INFO - 2016-09-23 13:49:46 --> Loader Class Initialized
INFO - 2016-09-23 13:49:46 --> Helper loaded: url_helper
INFO - 2016-09-23 13:49:46 --> Database Driver Class Initialized
INFO - 2016-09-23 13:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 13:49:46 --> Controller Class Initialized
DEBUG - 2016-09-23 13:49:46 --> login MX_Controller Initialized
INFO - 2016-09-23 13:49:46 --> Model Class Initialized
INFO - 2016-09-23 13:49:46 --> Model Class Initialized
DEBUG - 2016-09-23 13:49:46 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-23 13:49:46 --> Final output sent to browser
DEBUG - 2016-09-23 13:49:46 --> Total execution time: 0.0230
INFO - 2016-09-23 14:47:24 --> Config Class Initialized
INFO - 2016-09-23 14:47:24 --> Hooks Class Initialized
DEBUG - 2016-09-23 14:47:24 --> UTF-8 Support Enabled
INFO - 2016-09-23 14:47:24 --> Utf8 Class Initialized
INFO - 2016-09-23 14:47:24 --> URI Class Initialized
DEBUG - 2016-09-23 14:47:24 --> No URI present. Default controller set.
INFO - 2016-09-23 14:47:24 --> Router Class Initialized
INFO - 2016-09-23 14:47:24 --> Output Class Initialized
INFO - 2016-09-23 14:47:24 --> Security Class Initialized
DEBUG - 2016-09-23 14:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 14:47:24 --> Input Class Initialized
INFO - 2016-09-23 14:47:24 --> Language Class Initialized
INFO - 2016-09-23 14:47:24 --> Language Class Initialized
INFO - 2016-09-23 14:47:24 --> Config Class Initialized
INFO - 2016-09-23 14:47:24 --> Loader Class Initialized
INFO - 2016-09-23 14:47:24 --> Helper loaded: url_helper
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 14:47:24 --> Controller Class Initialized
DEBUG - 2016-09-23 14:47:24 --> Index MX_Controller Initialized
INFO - 2016-09-23 14:47:24 --> Model Class Initialized
INFO - 2016-09-23 14:47:24 --> Model Class Initialized
ERROR - 2016-09-23 14:47:24 --> Unable to delete cache file for 
DEBUG - 2016-09-23 14:47:24 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-23 14:47:24 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-23 14:47:24 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-23 14:47:24 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-23 14:47:24 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-23 14:47:24 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:24 --> Database Driver Class Initialized
DEBUG - 2016-09-23 14:47:24 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-23 14:47:24 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-23 14:47:24 --> Final output sent to browser
DEBUG - 2016-09-23 14:47:24 --> Total execution time: 0.1196
INFO - 2016-09-23 14:47:25 --> Config Class Initialized
INFO - 2016-09-23 14:47:25 --> Hooks Class Initialized
DEBUG - 2016-09-23 14:47:25 --> UTF-8 Support Enabled
INFO - 2016-09-23 14:47:25 --> Utf8 Class Initialized
INFO - 2016-09-23 14:47:25 --> URI Class Initialized
INFO - 2016-09-23 14:47:25 --> Router Class Initialized
INFO - 2016-09-23 14:47:25 --> Output Class Initialized
INFO - 2016-09-23 14:47:25 --> Security Class Initialized
DEBUG - 2016-09-23 14:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 14:47:25 --> Input Class Initialized
INFO - 2016-09-23 14:47:25 --> Language Class Initialized
INFO - 2016-09-23 14:47:25 --> Language Class Initialized
INFO - 2016-09-23 14:47:25 --> Config Class Initialized
INFO - 2016-09-23 14:47:25 --> Loader Class Initialized
INFO - 2016-09-23 14:47:25 --> Helper loaded: url_helper
INFO - 2016-09-23 14:47:25 --> Database Driver Class Initialized
INFO - 2016-09-23 14:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 14:47:25 --> Controller Class Initialized
DEBUG - 2016-09-23 14:47:25 --> login MX_Controller Initialized
INFO - 2016-09-23 14:47:25 --> Model Class Initialized
INFO - 2016-09-23 14:47:25 --> Model Class Initialized
DEBUG - 2016-09-23 14:47:25 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-23 14:47:25 --> Final output sent to browser
DEBUG - 2016-09-23 14:47:25 --> Total execution time: 0.0243
INFO - 2016-09-23 14:55:56 --> Config Class Initialized
INFO - 2016-09-23 14:55:56 --> Hooks Class Initialized
DEBUG - 2016-09-23 14:55:56 --> UTF-8 Support Enabled
INFO - 2016-09-23 14:55:56 --> Utf8 Class Initialized
INFO - 2016-09-23 14:55:56 --> URI Class Initialized
DEBUG - 2016-09-23 14:55:56 --> No URI present. Default controller set.
INFO - 2016-09-23 14:55:56 --> Router Class Initialized
INFO - 2016-09-23 14:55:56 --> Output Class Initialized
INFO - 2016-09-23 14:55:56 --> Security Class Initialized
DEBUG - 2016-09-23 14:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 14:55:56 --> Input Class Initialized
INFO - 2016-09-23 14:55:56 --> Language Class Initialized
INFO - 2016-09-23 14:55:56 --> Language Class Initialized
INFO - 2016-09-23 14:55:56 --> Config Class Initialized
INFO - 2016-09-23 14:55:56 --> Loader Class Initialized
INFO - 2016-09-23 14:55:56 --> Helper loaded: url_helper
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 14:55:56 --> Controller Class Initialized
DEBUG - 2016-09-23 14:55:56 --> Index MX_Controller Initialized
INFO - 2016-09-23 14:55:56 --> Model Class Initialized
INFO - 2016-09-23 14:55:56 --> Model Class Initialized
ERROR - 2016-09-23 14:55:56 --> Unable to delete cache file for 
DEBUG - 2016-09-23 14:55:56 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-23 14:55:56 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-23 14:55:56 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-23 14:55:56 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-23 14:55:56 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-23 14:55:56 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:56 --> Database Driver Class Initialized
DEBUG - 2016-09-23 14:55:56 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-23 14:55:56 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-23 14:55:56 --> Final output sent to browser
DEBUG - 2016-09-23 14:55:56 --> Total execution time: 0.1151
INFO - 2016-09-23 14:55:57 --> Config Class Initialized
INFO - 2016-09-23 14:55:57 --> Hooks Class Initialized
DEBUG - 2016-09-23 14:55:57 --> UTF-8 Support Enabled
INFO - 2016-09-23 14:55:57 --> Utf8 Class Initialized
INFO - 2016-09-23 14:55:57 --> URI Class Initialized
INFO - 2016-09-23 14:55:57 --> Router Class Initialized
INFO - 2016-09-23 14:55:57 --> Output Class Initialized
INFO - 2016-09-23 14:55:57 --> Security Class Initialized
DEBUG - 2016-09-23 14:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 14:55:57 --> Input Class Initialized
INFO - 2016-09-23 14:55:57 --> Language Class Initialized
INFO - 2016-09-23 14:55:57 --> Language Class Initialized
INFO - 2016-09-23 14:55:57 --> Config Class Initialized
INFO - 2016-09-23 14:55:57 --> Loader Class Initialized
INFO - 2016-09-23 14:55:57 --> Helper loaded: url_helper
INFO - 2016-09-23 14:55:57 --> Database Driver Class Initialized
INFO - 2016-09-23 14:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 14:55:57 --> Controller Class Initialized
DEBUG - 2016-09-23 14:55:57 --> login MX_Controller Initialized
INFO - 2016-09-23 14:55:57 --> Model Class Initialized
INFO - 2016-09-23 14:55:57 --> Model Class Initialized
DEBUG - 2016-09-23 14:55:57 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-23 14:55:57 --> Final output sent to browser
DEBUG - 2016-09-23 14:55:57 --> Total execution time: 0.0263
INFO - 2016-09-23 14:56:00 --> Config Class Initialized
INFO - 2016-09-23 14:56:00 --> Hooks Class Initialized
DEBUG - 2016-09-23 14:56:00 --> UTF-8 Support Enabled
INFO - 2016-09-23 14:56:00 --> Utf8 Class Initialized
INFO - 2016-09-23 14:56:00 --> URI Class Initialized
INFO - 2016-09-23 14:56:00 --> Router Class Initialized
INFO - 2016-09-23 14:56:00 --> Output Class Initialized
INFO - 2016-09-23 14:56:00 --> Security Class Initialized
DEBUG - 2016-09-23 14:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 14:56:00 --> Input Class Initialized
INFO - 2016-09-23 14:56:00 --> Language Class Initialized
ERROR - 2016-09-23 14:56:00 --> 404 Page Not Found: /index
INFO - 2016-09-23 16:31:11 --> Config Class Initialized
INFO - 2016-09-23 16:31:11 --> Hooks Class Initialized
DEBUG - 2016-09-23 16:31:11 --> UTF-8 Support Enabled
INFO - 2016-09-23 16:31:11 --> Utf8 Class Initialized
INFO - 2016-09-23 16:31:11 --> URI Class Initialized
DEBUG - 2016-09-23 16:31:11 --> No URI present. Default controller set.
INFO - 2016-09-23 16:31:11 --> Router Class Initialized
INFO - 2016-09-23 16:31:11 --> Output Class Initialized
INFO - 2016-09-23 16:31:11 --> Security Class Initialized
DEBUG - 2016-09-23 16:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 16:31:11 --> Input Class Initialized
INFO - 2016-09-23 16:31:11 --> Language Class Initialized
INFO - 2016-09-23 16:31:11 --> Language Class Initialized
INFO - 2016-09-23 16:31:11 --> Config Class Initialized
INFO - 2016-09-23 16:31:11 --> Loader Class Initialized
INFO - 2016-09-23 16:31:11 --> Helper loaded: url_helper
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 16:31:11 --> Controller Class Initialized
DEBUG - 2016-09-23 16:31:11 --> Index MX_Controller Initialized
INFO - 2016-09-23 16:31:11 --> Model Class Initialized
INFO - 2016-09-23 16:31:11 --> Model Class Initialized
ERROR - 2016-09-23 16:31:11 --> Unable to delete cache file for 
DEBUG - 2016-09-23 16:31:11 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-23 16:31:11 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-23 16:31:11 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-23 16:31:11 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-23 16:31:11 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-23 16:31:11 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
DEBUG - 2016-09-23 16:31:11 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-23 16:31:11 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-23 16:31:11 --> Final output sent to browser
DEBUG - 2016-09-23 16:31:11 --> Total execution time: 0.1637
INFO - 2016-09-23 16:31:11 --> Config Class Initialized
INFO - 2016-09-23 16:31:11 --> Hooks Class Initialized
DEBUG - 2016-09-23 16:31:11 --> UTF-8 Support Enabled
INFO - 2016-09-23 16:31:11 --> Utf8 Class Initialized
INFO - 2016-09-23 16:31:11 --> URI Class Initialized
INFO - 2016-09-23 16:31:11 --> Router Class Initialized
INFO - 2016-09-23 16:31:11 --> Output Class Initialized
INFO - 2016-09-23 16:31:11 --> Security Class Initialized
DEBUG - 2016-09-23 16:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 16:31:11 --> Input Class Initialized
INFO - 2016-09-23 16:31:11 --> Language Class Initialized
INFO - 2016-09-23 16:31:11 --> Language Class Initialized
INFO - 2016-09-23 16:31:11 --> Config Class Initialized
INFO - 2016-09-23 16:31:11 --> Loader Class Initialized
INFO - 2016-09-23 16:31:11 --> Helper loaded: url_helper
INFO - 2016-09-23 16:31:11 --> Database Driver Class Initialized
INFO - 2016-09-23 16:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 16:31:11 --> Controller Class Initialized
DEBUG - 2016-09-23 16:31:11 --> login MX_Controller Initialized
INFO - 2016-09-23 16:31:11 --> Model Class Initialized
INFO - 2016-09-23 16:31:11 --> Model Class Initialized
DEBUG - 2016-09-23 16:31:11 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-23 16:31:11 --> Final output sent to browser
DEBUG - 2016-09-23 16:31:11 --> Total execution time: 0.0383
