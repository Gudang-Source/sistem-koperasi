<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-09-19 04:12:49 --> Config Class Initialized
INFO - 2016-09-19 04:12:49 --> Hooks Class Initialized
DEBUG - 2016-09-19 04:12:49 --> UTF-8 Support Enabled
INFO - 2016-09-19 04:12:49 --> Utf8 Class Initialized
INFO - 2016-09-19 04:12:49 --> URI Class Initialized
INFO - 2016-09-19 04:12:49 --> Router Class Initialized
INFO - 2016-09-19 04:12:49 --> Output Class Initialized
INFO - 2016-09-19 04:12:49 --> Security Class Initialized
DEBUG - 2016-09-19 04:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 04:12:49 --> Input Class Initialized
INFO - 2016-09-19 04:12:49 --> Language Class Initialized
INFO - 2016-09-19 04:12:49 --> Language Class Initialized
INFO - 2016-09-19 04:12:49 --> Config Class Initialized
INFO - 2016-09-19 04:12:49 --> Loader Class Initialized
INFO - 2016-09-19 04:12:49 --> Helper loaded: url_helper
INFO - 2016-09-19 04:12:50 --> Database Driver Class Initialized
INFO - 2016-09-19 04:12:50 --> Controller Class Initialized
DEBUG - 2016-09-19 04:12:50 --> Index MX_Controller Initialized
INFO - 2016-09-19 04:12:50 --> Model Class Initialized
INFO - 2016-09-19 04:12:50 --> Model Class Initialized
DEBUG - 2016-09-19 04:12:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 04:12:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 04:12:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 04:12:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 04:12:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 04:12:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 04:12:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 04:12:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 04:12:50 --> Final output sent to browser
DEBUG - 2016-09-19 04:12:50 --> Total execution time: 0.6248
INFO - 2016-09-19 04:13:10 --> Config Class Initialized
INFO - 2016-09-19 04:13:10 --> Hooks Class Initialized
DEBUG - 2016-09-19 04:13:10 --> UTF-8 Support Enabled
INFO - 2016-09-19 04:13:10 --> Utf8 Class Initialized
INFO - 2016-09-19 04:13:10 --> URI Class Initialized
INFO - 2016-09-19 04:13:10 --> Router Class Initialized
INFO - 2016-09-19 04:13:10 --> Output Class Initialized
INFO - 2016-09-19 04:13:10 --> Security Class Initialized
DEBUG - 2016-09-19 04:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 04:13:11 --> Input Class Initialized
INFO - 2016-09-19 04:13:11 --> Language Class Initialized
INFO - 2016-09-19 04:13:11 --> Language Class Initialized
INFO - 2016-09-19 04:13:11 --> Config Class Initialized
INFO - 2016-09-19 04:13:11 --> Loader Class Initialized
INFO - 2016-09-19 04:13:11 --> Helper loaded: url_helper
INFO - 2016-09-19 04:13:11 --> Database Driver Class Initialized
INFO - 2016-09-19 04:13:11 --> Controller Class Initialized
DEBUG - 2016-09-19 04:13:11 --> Index MX_Controller Initialized
INFO - 2016-09-19 04:13:11 --> Model Class Initialized
INFO - 2016-09-19 04:13:11 --> Model Class Initialized
DEBUG - 2016-09-19 04:13:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 04:13:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 04:13:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 04:13:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_biaya.php
DEBUG - 2016-09-19 04:13:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 04:13:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 04:13:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 04:13:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 04:13:11 --> Final output sent to browser
DEBUG - 2016-09-19 04:13:11 --> Total execution time: 0.8052
INFO - 2016-09-19 04:13:43 --> Config Class Initialized
INFO - 2016-09-19 04:13:43 --> Hooks Class Initialized
DEBUG - 2016-09-19 04:13:43 --> UTF-8 Support Enabled
INFO - 2016-09-19 04:13:43 --> Utf8 Class Initialized
INFO - 2016-09-19 04:13:43 --> URI Class Initialized
INFO - 2016-09-19 04:13:43 --> Router Class Initialized
INFO - 2016-09-19 04:13:43 --> Output Class Initialized
INFO - 2016-09-19 04:13:43 --> Security Class Initialized
DEBUG - 2016-09-19 04:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 04:13:43 --> Input Class Initialized
INFO - 2016-09-19 04:13:43 --> Language Class Initialized
INFO - 2016-09-19 04:13:43 --> Language Class Initialized
INFO - 2016-09-19 04:13:43 --> Config Class Initialized
INFO - 2016-09-19 04:13:43 --> Loader Class Initialized
INFO - 2016-09-19 04:13:43 --> Helper loaded: url_helper
INFO - 2016-09-19 04:13:43 --> Database Driver Class Initialized
INFO - 2016-09-19 04:13:43 --> Controller Class Initialized
DEBUG - 2016-09-19 04:13:43 --> Index MX_Controller Initialized
INFO - 2016-09-19 04:13:43 --> Model Class Initialized
INFO - 2016-09-19 04:13:43 --> Model Class Initialized
DEBUG - 2016-09-19 04:13:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 04:13:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 04:13:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 04:13:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_biaya.php
DEBUG - 2016-09-19 04:13:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 04:13:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 04:13:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 04:13:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 04:13:43 --> Final output sent to browser
DEBUG - 2016-09-19 04:13:43 --> Total execution time: 0.5969
INFO - 2016-09-19 04:14:12 --> Config Class Initialized
INFO - 2016-09-19 04:14:12 --> Hooks Class Initialized
DEBUG - 2016-09-19 04:14:12 --> UTF-8 Support Enabled
INFO - 2016-09-19 04:14:12 --> Utf8 Class Initialized
INFO - 2016-09-19 04:14:12 --> URI Class Initialized
INFO - 2016-09-19 04:14:12 --> Router Class Initialized
INFO - 2016-09-19 04:14:12 --> Output Class Initialized
INFO - 2016-09-19 04:14:12 --> Security Class Initialized
DEBUG - 2016-09-19 04:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 04:14:12 --> Input Class Initialized
INFO - 2016-09-19 04:14:12 --> Language Class Initialized
INFO - 2016-09-19 04:14:12 --> Language Class Initialized
INFO - 2016-09-19 04:14:12 --> Config Class Initialized
INFO - 2016-09-19 04:14:12 --> Loader Class Initialized
INFO - 2016-09-19 04:14:12 --> Helper loaded: url_helper
INFO - 2016-09-19 04:14:12 --> Database Driver Class Initialized
INFO - 2016-09-19 04:14:12 --> Controller Class Initialized
DEBUG - 2016-09-19 04:14:12 --> Index MX_Controller Initialized
INFO - 2016-09-19 04:14:12 --> Model Class Initialized
INFO - 2016-09-19 04:14:12 --> Model Class Initialized
DEBUG - 2016-09-19 04:14:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 04:14:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 04:14:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 04:14:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/buku_besar.php
DEBUG - 2016-09-19 04:14:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 04:14:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 04:14:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 04:14:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 04:14:12 --> Final output sent to browser
DEBUG - 2016-09-19 04:14:12 --> Total execution time: 0.5182
INFO - 2016-09-19 04:14:25 --> Config Class Initialized
INFO - 2016-09-19 04:14:25 --> Hooks Class Initialized
DEBUG - 2016-09-19 04:14:25 --> UTF-8 Support Enabled
INFO - 2016-09-19 04:14:25 --> Utf8 Class Initialized
INFO - 2016-09-19 04:14:25 --> URI Class Initialized
INFO - 2016-09-19 04:14:25 --> Router Class Initialized
INFO - 2016-09-19 04:14:25 --> Output Class Initialized
INFO - 2016-09-19 04:14:25 --> Security Class Initialized
DEBUG - 2016-09-19 04:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 04:14:25 --> Input Class Initialized
INFO - 2016-09-19 04:14:25 --> Language Class Initialized
INFO - 2016-09-19 04:14:25 --> Language Class Initialized
INFO - 2016-09-19 04:14:25 --> Config Class Initialized
INFO - 2016-09-19 04:14:25 --> Loader Class Initialized
INFO - 2016-09-19 04:14:25 --> Helper loaded: url_helper
INFO - 2016-09-19 04:14:25 --> Database Driver Class Initialized
INFO - 2016-09-19 04:14:25 --> Controller Class Initialized
DEBUG - 2016-09-19 04:14:26 --> Index MX_Controller Initialized
INFO - 2016-09-19 04:14:26 --> Model Class Initialized
INFO - 2016-09-19 04:14:26 --> Model Class Initialized
DEBUG - 2016-09-19 04:14:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_buku_besar.php
INFO - 2016-09-19 04:14:26 --> Final output sent to browser
DEBUG - 2016-09-19 04:14:26 --> Total execution time: 0.4804
INFO - 2016-09-19 04:14:57 --> Config Class Initialized
INFO - 2016-09-19 04:14:57 --> Hooks Class Initialized
DEBUG - 2016-09-19 04:14:57 --> UTF-8 Support Enabled
INFO - 2016-09-19 04:14:57 --> Utf8 Class Initialized
INFO - 2016-09-19 04:14:57 --> URI Class Initialized
INFO - 2016-09-19 04:14:57 --> Router Class Initialized
INFO - 2016-09-19 04:14:57 --> Output Class Initialized
INFO - 2016-09-19 04:14:57 --> Security Class Initialized
DEBUG - 2016-09-19 04:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 04:14:57 --> Input Class Initialized
INFO - 2016-09-19 04:14:57 --> Language Class Initialized
INFO - 2016-09-19 04:14:57 --> Language Class Initialized
INFO - 2016-09-19 04:14:57 --> Config Class Initialized
INFO - 2016-09-19 04:14:57 --> Loader Class Initialized
INFO - 2016-09-19 04:14:57 --> Helper loaded: url_helper
INFO - 2016-09-19 04:14:57 --> Database Driver Class Initialized
INFO - 2016-09-19 04:14:57 --> Controller Class Initialized
DEBUG - 2016-09-19 04:14:57 --> Index MX_Controller Initialized
INFO - 2016-09-19 04:14:57 --> Model Class Initialized
INFO - 2016-09-19 04:14:57 --> Model Class Initialized
DEBUG - 2016-09-19 04:14:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 04:14:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 04:14:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 04:14:57 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-19 04:14:57 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-19 04:14:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-19 04:14:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 04:14:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 04:14:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 04:14:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 04:14:58 --> Final output sent to browser
DEBUG - 2016-09-19 04:14:58 --> Total execution time: 0.5889
INFO - 2016-09-19 04:15:21 --> Config Class Initialized
INFO - 2016-09-19 04:15:21 --> Hooks Class Initialized
DEBUG - 2016-09-19 04:15:21 --> UTF-8 Support Enabled
INFO - 2016-09-19 04:15:21 --> Utf8 Class Initialized
INFO - 2016-09-19 04:15:21 --> URI Class Initialized
INFO - 2016-09-19 04:15:21 --> Router Class Initialized
INFO - 2016-09-19 04:15:21 --> Output Class Initialized
INFO - 2016-09-19 04:15:21 --> Security Class Initialized
DEBUG - 2016-09-19 04:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 04:15:21 --> Input Class Initialized
INFO - 2016-09-19 04:15:21 --> Language Class Initialized
INFO - 2016-09-19 04:15:21 --> Language Class Initialized
INFO - 2016-09-19 04:15:21 --> Config Class Initialized
INFO - 2016-09-19 04:15:21 --> Loader Class Initialized
INFO - 2016-09-19 04:15:21 --> Helper loaded: url_helper
INFO - 2016-09-19 04:15:21 --> Database Driver Class Initialized
INFO - 2016-09-19 04:15:21 --> Controller Class Initialized
DEBUG - 2016-09-19 04:15:21 --> Index MX_Controller Initialized
INFO - 2016-09-19 04:15:21 --> Model Class Initialized
INFO - 2016-09-19 04:15:21 --> Model Class Initialized
DEBUG - 2016-09-19 04:15:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 04:15:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 04:15:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 04:15:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-19 04:15:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 04:15:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 04:15:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 04:15:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 04:15:21 --> Final output sent to browser
DEBUG - 2016-09-19 04:15:21 --> Total execution time: 0.6242
INFO - 2016-09-19 04:15:29 --> Config Class Initialized
INFO - 2016-09-19 04:15:29 --> Hooks Class Initialized
DEBUG - 2016-09-19 04:15:29 --> UTF-8 Support Enabled
INFO - 2016-09-19 04:15:29 --> Utf8 Class Initialized
INFO - 2016-09-19 04:15:29 --> URI Class Initialized
INFO - 2016-09-19 04:15:29 --> Router Class Initialized
INFO - 2016-09-19 04:15:29 --> Output Class Initialized
INFO - 2016-09-19 04:15:29 --> Security Class Initialized
DEBUG - 2016-09-19 04:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 04:15:29 --> Input Class Initialized
INFO - 2016-09-19 04:15:29 --> Language Class Initialized
INFO - 2016-09-19 04:15:29 --> Language Class Initialized
INFO - 2016-09-19 04:15:29 --> Config Class Initialized
INFO - 2016-09-19 04:15:29 --> Loader Class Initialized
INFO - 2016-09-19 04:15:29 --> Helper loaded: url_helper
INFO - 2016-09-19 04:15:29 --> Database Driver Class Initialized
INFO - 2016-09-19 04:15:29 --> Controller Class Initialized
DEBUG - 2016-09-19 04:15:29 --> Index MX_Controller Initialized
INFO - 2016-09-19 04:15:29 --> Model Class Initialized
INFO - 2016-09-19 04:15:29 --> Model Class Initialized
DEBUG - 2016-09-19 04:15:29 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-19 04:15:29 --> Users MX_Controller Initialized
INFO - 2016-09-19 04:15:29 --> Database Driver Class Initialized
INFO - 2016-09-19 04:15:29 --> Final output sent to browser
DEBUG - 2016-09-19 04:15:29 --> Total execution time: 0.6542
INFO - 2016-09-19 04:16:22 --> Config Class Initialized
INFO - 2016-09-19 04:16:22 --> Hooks Class Initialized
DEBUG - 2016-09-19 04:16:22 --> UTF-8 Support Enabled
INFO - 2016-09-19 04:16:22 --> Utf8 Class Initialized
INFO - 2016-09-19 04:16:22 --> URI Class Initialized
INFO - 2016-09-19 04:16:22 --> Router Class Initialized
INFO - 2016-09-19 04:16:22 --> Output Class Initialized
INFO - 2016-09-19 04:16:22 --> Security Class Initialized
DEBUG - 2016-09-19 04:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 04:16:22 --> Input Class Initialized
INFO - 2016-09-19 04:16:22 --> Language Class Initialized
INFO - 2016-09-19 04:16:22 --> Language Class Initialized
INFO - 2016-09-19 04:16:22 --> Config Class Initialized
INFO - 2016-09-19 04:16:22 --> Loader Class Initialized
INFO - 2016-09-19 04:16:22 --> Helper loaded: url_helper
INFO - 2016-09-19 04:16:22 --> Database Driver Class Initialized
INFO - 2016-09-19 04:16:22 --> Controller Class Initialized
DEBUG - 2016-09-19 04:16:22 --> Index MX_Controller Initialized
INFO - 2016-09-19 04:16:22 --> Model Class Initialized
INFO - 2016-09-19 04:16:22 --> Model Class Initialized
DEBUG - 2016-09-19 04:16:22 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-19 04:16:22 --> Users MX_Controller Initialized
INFO - 2016-09-19 04:16:22 --> Database Driver Class Initialized
INFO - 2016-09-19 04:16:23 --> Final output sent to browser
DEBUG - 2016-09-19 04:16:23 --> Total execution time: 0.5719
INFO - 2016-09-19 04:16:29 --> Config Class Initialized
INFO - 2016-09-19 04:16:29 --> Hooks Class Initialized
DEBUG - 2016-09-19 04:16:29 --> UTF-8 Support Enabled
INFO - 2016-09-19 04:16:29 --> Utf8 Class Initialized
INFO - 2016-09-19 04:16:29 --> URI Class Initialized
INFO - 2016-09-19 04:16:29 --> Router Class Initialized
INFO - 2016-09-19 04:16:29 --> Output Class Initialized
INFO - 2016-09-19 04:16:29 --> Security Class Initialized
DEBUG - 2016-09-19 04:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 04:16:29 --> Input Class Initialized
INFO - 2016-09-19 04:16:29 --> Language Class Initialized
INFO - 2016-09-19 04:16:29 --> Language Class Initialized
INFO - 2016-09-19 04:16:29 --> Config Class Initialized
INFO - 2016-09-19 04:16:29 --> Loader Class Initialized
INFO - 2016-09-19 04:16:29 --> Helper loaded: url_helper
INFO - 2016-09-19 04:16:29 --> Database Driver Class Initialized
INFO - 2016-09-19 04:16:29 --> Controller Class Initialized
DEBUG - 2016-09-19 04:16:29 --> Index MX_Controller Initialized
INFO - 2016-09-19 04:16:29 --> Model Class Initialized
INFO - 2016-09-19 04:16:29 --> Model Class Initialized
DEBUG - 2016-09-19 04:16:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 04:16:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 04:16:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 04:16:29 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-19 04:16:29 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-19 04:16:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-19 04:16:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 04:16:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 04:16:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 04:16:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 04:16:29 --> Final output sent to browser
DEBUG - 2016-09-19 04:16:30 --> Total execution time: 0.6142
INFO - 2016-09-19 04:16:41 --> Config Class Initialized
INFO - 2016-09-19 04:16:41 --> Hooks Class Initialized
DEBUG - 2016-09-19 04:16:41 --> UTF-8 Support Enabled
INFO - 2016-09-19 04:16:41 --> Utf8 Class Initialized
INFO - 2016-09-19 04:16:42 --> URI Class Initialized
INFO - 2016-09-19 04:16:42 --> Router Class Initialized
INFO - 2016-09-19 04:16:42 --> Output Class Initialized
INFO - 2016-09-19 04:16:42 --> Security Class Initialized
DEBUG - 2016-09-19 04:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 04:16:42 --> Input Class Initialized
INFO - 2016-09-19 04:16:42 --> Language Class Initialized
INFO - 2016-09-19 04:16:42 --> Language Class Initialized
INFO - 2016-09-19 04:16:42 --> Config Class Initialized
INFO - 2016-09-19 04:16:42 --> Loader Class Initialized
INFO - 2016-09-19 04:16:42 --> Helper loaded: url_helper
INFO - 2016-09-19 04:16:42 --> Database Driver Class Initialized
INFO - 2016-09-19 04:16:42 --> Controller Class Initialized
DEBUG - 2016-09-19 04:16:42 --> Index MX_Controller Initialized
INFO - 2016-09-19 04:16:42 --> Model Class Initialized
INFO - 2016-09-19 04:16:42 --> Model Class Initialized
DEBUG - 2016-09-19 04:16:42 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-19 04:16:42 --> Users MX_Controller Initialized
INFO - 2016-09-19 04:16:42 --> Final output sent to browser
DEBUG - 2016-09-19 04:16:42 --> Total execution time: 0.6323
INFO - 2016-09-19 04:16:49 --> Config Class Initialized
INFO - 2016-09-19 04:16:49 --> Hooks Class Initialized
DEBUG - 2016-09-19 04:16:49 --> UTF-8 Support Enabled
INFO - 2016-09-19 04:16:49 --> Utf8 Class Initialized
INFO - 2016-09-19 04:16:49 --> URI Class Initialized
INFO - 2016-09-19 04:16:49 --> Router Class Initialized
INFO - 2016-09-19 04:16:49 --> Output Class Initialized
INFO - 2016-09-19 04:16:49 --> Security Class Initialized
DEBUG - 2016-09-19 04:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 04:16:49 --> Input Class Initialized
INFO - 2016-09-19 04:16:49 --> Language Class Initialized
INFO - 2016-09-19 04:16:49 --> Language Class Initialized
INFO - 2016-09-19 04:16:49 --> Config Class Initialized
INFO - 2016-09-19 04:16:49 --> Loader Class Initialized
INFO - 2016-09-19 04:16:49 --> Helper loaded: url_helper
INFO - 2016-09-19 04:16:49 --> Database Driver Class Initialized
INFO - 2016-09-19 04:16:49 --> Controller Class Initialized
DEBUG - 2016-09-19 04:16:49 --> Index MX_Controller Initialized
INFO - 2016-09-19 04:16:49 --> Model Class Initialized
INFO - 2016-09-19 04:16:49 --> Model Class Initialized
DEBUG - 2016-09-19 04:16:49 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-19 04:16:49 --> Users MX_Controller Initialized
INFO - 2016-09-19 04:16:49 --> Final output sent to browser
DEBUG - 2016-09-19 04:16:49 --> Total execution time: 0.6644
INFO - 2016-09-19 04:16:58 --> Config Class Initialized
INFO - 2016-09-19 04:16:58 --> Hooks Class Initialized
DEBUG - 2016-09-19 04:16:58 --> UTF-8 Support Enabled
INFO - 2016-09-19 04:16:58 --> Utf8 Class Initialized
INFO - 2016-09-19 04:16:58 --> URI Class Initialized
INFO - 2016-09-19 04:16:58 --> Router Class Initialized
INFO - 2016-09-19 04:16:58 --> Output Class Initialized
INFO - 2016-09-19 04:16:58 --> Security Class Initialized
DEBUG - 2016-09-19 04:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 04:16:58 --> Input Class Initialized
INFO - 2016-09-19 04:16:58 --> Language Class Initialized
INFO - 2016-09-19 04:16:58 --> Language Class Initialized
INFO - 2016-09-19 04:16:58 --> Config Class Initialized
INFO - 2016-09-19 04:16:58 --> Loader Class Initialized
INFO - 2016-09-19 04:16:58 --> Helper loaded: url_helper
INFO - 2016-09-19 04:16:58 --> Database Driver Class Initialized
INFO - 2016-09-19 04:16:59 --> Controller Class Initialized
DEBUG - 2016-09-19 04:16:59 --> Index MX_Controller Initialized
INFO - 2016-09-19 04:16:59 --> Model Class Initialized
INFO - 2016-09-19 04:16:59 --> Model Class Initialized
DEBUG - 2016-09-19 04:16:59 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-19 04:16:59 --> Users MX_Controller Initialized
INFO - 2016-09-19 04:16:59 --> Final output sent to browser
DEBUG - 2016-09-19 04:16:59 --> Total execution time: 0.7219
INFO - 2016-09-19 04:17:05 --> Config Class Initialized
INFO - 2016-09-19 04:17:05 --> Hooks Class Initialized
DEBUG - 2016-09-19 04:17:06 --> UTF-8 Support Enabled
INFO - 2016-09-19 04:17:06 --> Utf8 Class Initialized
INFO - 2016-09-19 04:17:06 --> URI Class Initialized
INFO - 2016-09-19 04:17:06 --> Router Class Initialized
INFO - 2016-09-19 04:17:06 --> Output Class Initialized
INFO - 2016-09-19 04:17:06 --> Security Class Initialized
DEBUG - 2016-09-19 04:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 04:17:06 --> Input Class Initialized
INFO - 2016-09-19 04:17:06 --> Language Class Initialized
INFO - 2016-09-19 04:17:06 --> Language Class Initialized
INFO - 2016-09-19 04:17:06 --> Config Class Initialized
INFO - 2016-09-19 04:17:06 --> Loader Class Initialized
INFO - 2016-09-19 04:17:06 --> Helper loaded: url_helper
INFO - 2016-09-19 04:17:06 --> Database Driver Class Initialized
INFO - 2016-09-19 04:17:06 --> Controller Class Initialized
DEBUG - 2016-09-19 04:17:06 --> Index MX_Controller Initialized
INFO - 2016-09-19 04:17:06 --> Model Class Initialized
INFO - 2016-09-19 04:17:06 --> Model Class Initialized
DEBUG - 2016-09-19 04:17:06 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-19 04:17:06 --> Users MX_Controller Initialized
INFO - 2016-09-19 04:17:06 --> Final output sent to browser
DEBUG - 2016-09-19 04:17:06 --> Total execution time: 0.8218
INFO - 2016-09-19 04:20:16 --> Config Class Initialized
INFO - 2016-09-19 04:20:16 --> Hooks Class Initialized
DEBUG - 2016-09-19 04:20:16 --> UTF-8 Support Enabled
INFO - 2016-09-19 04:20:16 --> Utf8 Class Initialized
INFO - 2016-09-19 04:20:16 --> URI Class Initialized
INFO - 2016-09-19 04:20:16 --> Router Class Initialized
INFO - 2016-09-19 04:20:16 --> Output Class Initialized
INFO - 2016-09-19 04:20:16 --> Security Class Initialized
DEBUG - 2016-09-19 04:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 04:20:16 --> Input Class Initialized
INFO - 2016-09-19 04:20:16 --> Language Class Initialized
INFO - 2016-09-19 04:20:16 --> Language Class Initialized
INFO - 2016-09-19 04:20:16 --> Config Class Initialized
INFO - 2016-09-19 04:20:16 --> Loader Class Initialized
INFO - 2016-09-19 04:20:16 --> Helper loaded: url_helper
INFO - 2016-09-19 04:20:16 --> Database Driver Class Initialized
INFO - 2016-09-19 04:20:16 --> Controller Class Initialized
DEBUG - 2016-09-19 04:20:16 --> Index MX_Controller Initialized
INFO - 2016-09-19 04:20:16 --> Model Class Initialized
INFO - 2016-09-19 04:20:16 --> Model Class Initialized
DEBUG - 2016-09-19 04:20:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 04:20:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 04:20:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 04:20:17 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/user/controllers/Users.php
DEBUG - 2016-09-19 04:20:17 --> Users MX_Controller Initialized
DEBUG - 2016-09-19 04:20:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_user.php
DEBUG - 2016-09-19 04:20:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 04:20:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 04:20:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 04:20:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 04:20:17 --> Final output sent to browser
DEBUG - 2016-09-19 04:20:17 --> Total execution time: 0.6512
INFO - 2016-09-19 04:20:26 --> Config Class Initialized
INFO - 2016-09-19 04:20:26 --> Hooks Class Initialized
DEBUG - 2016-09-19 04:20:26 --> UTF-8 Support Enabled
INFO - 2016-09-19 04:20:26 --> Utf8 Class Initialized
INFO - 2016-09-19 04:20:26 --> URI Class Initialized
INFO - 2016-09-19 04:20:26 --> Router Class Initialized
INFO - 2016-09-19 04:20:26 --> Output Class Initialized
INFO - 2016-09-19 04:20:26 --> Security Class Initialized
DEBUG - 2016-09-19 04:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 04:20:26 --> Input Class Initialized
INFO - 2016-09-19 04:20:26 --> Language Class Initialized
INFO - 2016-09-19 04:20:27 --> Language Class Initialized
INFO - 2016-09-19 04:20:27 --> Config Class Initialized
INFO - 2016-09-19 04:20:27 --> Loader Class Initialized
INFO - 2016-09-19 04:20:27 --> Helper loaded: url_helper
INFO - 2016-09-19 04:20:27 --> Database Driver Class Initialized
INFO - 2016-09-19 04:20:27 --> Controller Class Initialized
DEBUG - 2016-09-19 04:20:27 --> Index MX_Controller Initialized
INFO - 2016-09-19 04:20:27 --> Model Class Initialized
INFO - 2016-09-19 04:20:27 --> Model Class Initialized
DEBUG - 2016-09-19 04:20:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 04:20:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 04:20:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 04:20:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_user.php
DEBUG - 2016-09-19 04:20:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 04:20:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 04:20:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 04:20:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 04:20:27 --> Final output sent to browser
DEBUG - 2016-09-19 04:20:27 --> Total execution time: 0.6685
INFO - 2016-09-19 04:21:32 --> Config Class Initialized
INFO - 2016-09-19 04:21:32 --> Hooks Class Initialized
DEBUG - 2016-09-19 04:21:32 --> UTF-8 Support Enabled
INFO - 2016-09-19 04:21:32 --> Utf8 Class Initialized
INFO - 2016-09-19 04:21:32 --> URI Class Initialized
INFO - 2016-09-19 04:21:32 --> Router Class Initialized
INFO - 2016-09-19 04:21:32 --> Output Class Initialized
INFO - 2016-09-19 04:21:32 --> Security Class Initialized
DEBUG - 2016-09-19 04:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 04:21:32 --> Input Class Initialized
INFO - 2016-09-19 04:21:32 --> Language Class Initialized
INFO - 2016-09-19 04:21:32 --> Language Class Initialized
INFO - 2016-09-19 04:21:32 --> Config Class Initialized
INFO - 2016-09-19 04:21:32 --> Loader Class Initialized
INFO - 2016-09-19 04:21:32 --> Helper loaded: url_helper
INFO - 2016-09-19 04:21:32 --> Database Driver Class Initialized
INFO - 2016-09-19 04:21:32 --> Controller Class Initialized
DEBUG - 2016-09-19 04:21:32 --> Index MX_Controller Initialized
INFO - 2016-09-19 04:21:32 --> Model Class Initialized
INFO - 2016-09-19 04:21:32 --> Model Class Initialized
DEBUG - 2016-09-19 04:21:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 04:21:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 04:21:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 04:21:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_peminjam.php
DEBUG - 2016-09-19 04:21:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 04:21:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 04:21:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 04:21:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 04:21:32 --> Final output sent to browser
DEBUG - 2016-09-19 04:21:32 --> Total execution time: 0.5679
INFO - 2016-09-19 04:21:39 --> Config Class Initialized
INFO - 2016-09-19 04:21:39 --> Hooks Class Initialized
DEBUG - 2016-09-19 04:21:39 --> UTF-8 Support Enabled
INFO - 2016-09-19 04:21:39 --> Utf8 Class Initialized
INFO - 2016-09-19 04:21:39 --> URI Class Initialized
INFO - 2016-09-19 04:21:39 --> Router Class Initialized
INFO - 2016-09-19 04:21:39 --> Output Class Initialized
INFO - 2016-09-19 04:21:39 --> Security Class Initialized
DEBUG - 2016-09-19 04:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 04:21:40 --> Input Class Initialized
INFO - 2016-09-19 04:21:40 --> Language Class Initialized
INFO - 2016-09-19 04:21:40 --> Language Class Initialized
INFO - 2016-09-19 04:21:40 --> Config Class Initialized
INFO - 2016-09-19 04:21:40 --> Loader Class Initialized
INFO - 2016-09-19 04:21:40 --> Helper loaded: url_helper
INFO - 2016-09-19 04:21:40 --> Database Driver Class Initialized
INFO - 2016-09-19 04:21:40 --> Controller Class Initialized
DEBUG - 2016-09-19 04:21:40 --> Index MX_Controller Initialized
INFO - 2016-09-19 04:21:40 --> Model Class Initialized
INFO - 2016-09-19 04:21:40 --> Model Class Initialized
DEBUG - 2016-09-19 04:21:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-19 04:21:40 --> Final output sent to browser
DEBUG - 2016-09-19 04:21:40 --> Total execution time: 0.4621
INFO - 2016-09-19 04:21:40 --> Config Class Initialized
INFO - 2016-09-19 04:21:40 --> Hooks Class Initialized
DEBUG - 2016-09-19 04:21:40 --> UTF-8 Support Enabled
INFO - 2016-09-19 04:21:40 --> Utf8 Class Initialized
INFO - 2016-09-19 04:21:40 --> URI Class Initialized
INFO - 2016-09-19 04:21:40 --> Router Class Initialized
INFO - 2016-09-19 04:21:40 --> Output Class Initialized
INFO - 2016-09-19 04:21:40 --> Security Class Initialized
DEBUG - 2016-09-19 04:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 04:21:40 --> Input Class Initialized
INFO - 2016-09-19 04:21:40 --> Language Class Initialized
INFO - 2016-09-19 04:21:40 --> Language Class Initialized
INFO - 2016-09-19 04:21:40 --> Config Class Initialized
INFO - 2016-09-19 04:21:40 --> Loader Class Initialized
INFO - 2016-09-19 04:21:40 --> Helper loaded: url_helper
INFO - 2016-09-19 04:21:41 --> Database Driver Class Initialized
INFO - 2016-09-19 04:21:41 --> Controller Class Initialized
DEBUG - 2016-09-19 04:21:41 --> Index MX_Controller Initialized
INFO - 2016-09-19 04:21:41 --> Model Class Initialized
INFO - 2016-09-19 04:21:41 --> Model Class Initialized
DEBUG - 2016-09-19 04:21:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-19 04:21:41 --> Final output sent to browser
DEBUG - 2016-09-19 04:21:41 --> Total execution time: 0.4904
INFO - 2016-09-19 04:21:41 --> Config Class Initialized
INFO - 2016-09-19 04:21:41 --> Hooks Class Initialized
DEBUG - 2016-09-19 04:21:41 --> UTF-8 Support Enabled
INFO - 2016-09-19 04:21:41 --> Utf8 Class Initialized
INFO - 2016-09-19 04:21:41 --> URI Class Initialized
INFO - 2016-09-19 04:21:41 --> Router Class Initialized
INFO - 2016-09-19 04:21:41 --> Output Class Initialized
INFO - 2016-09-19 04:21:41 --> Security Class Initialized
DEBUG - 2016-09-19 04:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 04:21:41 --> Input Class Initialized
INFO - 2016-09-19 04:21:41 --> Language Class Initialized
INFO - 2016-09-19 04:21:41 --> Language Class Initialized
INFO - 2016-09-19 04:21:41 --> Config Class Initialized
INFO - 2016-09-19 04:21:41 --> Loader Class Initialized
INFO - 2016-09-19 04:21:41 --> Helper loaded: url_helper
INFO - 2016-09-19 04:21:42 --> Database Driver Class Initialized
INFO - 2016-09-19 04:21:42 --> Controller Class Initialized
DEBUG - 2016-09-19 04:21:42 --> Index MX_Controller Initialized
INFO - 2016-09-19 04:21:42 --> Model Class Initialized
INFO - 2016-09-19 04:21:42 --> Model Class Initialized
DEBUG - 2016-09-19 04:21:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-19 04:21:42 --> Final output sent to browser
DEBUG - 2016-09-19 04:21:42 --> Total execution time: 0.4317
INFO - 2016-09-19 04:21:43 --> Config Class Initialized
INFO - 2016-09-19 04:21:43 --> Hooks Class Initialized
DEBUG - 2016-09-19 04:21:43 --> UTF-8 Support Enabled
INFO - 2016-09-19 04:21:44 --> Utf8 Class Initialized
INFO - 2016-09-19 04:21:44 --> URI Class Initialized
INFO - 2016-09-19 04:21:44 --> Router Class Initialized
INFO - 2016-09-19 04:21:44 --> Output Class Initialized
INFO - 2016-09-19 04:21:44 --> Security Class Initialized
DEBUG - 2016-09-19 04:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 04:21:44 --> Input Class Initialized
INFO - 2016-09-19 04:21:44 --> Language Class Initialized
INFO - 2016-09-19 04:21:44 --> Language Class Initialized
INFO - 2016-09-19 04:21:44 --> Config Class Initialized
INFO - 2016-09-19 04:21:44 --> Loader Class Initialized
INFO - 2016-09-19 04:21:44 --> Helper loaded: url_helper
INFO - 2016-09-19 04:21:44 --> Database Driver Class Initialized
INFO - 2016-09-19 04:21:44 --> Controller Class Initialized
DEBUG - 2016-09-19 04:21:44 --> Index MX_Controller Initialized
INFO - 2016-09-19 04:21:44 --> Model Class Initialized
INFO - 2016-09-19 04:21:44 --> Model Class Initialized
DEBUG - 2016-09-19 04:21:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-19 04:21:44 --> Final output sent to browser
DEBUG - 2016-09-19 04:21:44 --> Total execution time: 0.5009
INFO - 2016-09-19 04:21:44 --> Config Class Initialized
INFO - 2016-09-19 04:21:44 --> Hooks Class Initialized
DEBUG - 2016-09-19 04:21:44 --> UTF-8 Support Enabled
INFO - 2016-09-19 04:21:44 --> Utf8 Class Initialized
INFO - 2016-09-19 04:21:44 --> URI Class Initialized
INFO - 2016-09-19 04:21:44 --> Router Class Initialized
INFO - 2016-09-19 04:21:45 --> Output Class Initialized
INFO - 2016-09-19 04:21:45 --> Security Class Initialized
DEBUG - 2016-09-19 04:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 04:21:45 --> Input Class Initialized
INFO - 2016-09-19 04:21:45 --> Language Class Initialized
INFO - 2016-09-19 04:21:45 --> Language Class Initialized
INFO - 2016-09-19 04:21:45 --> Config Class Initialized
INFO - 2016-09-19 04:21:45 --> Loader Class Initialized
INFO - 2016-09-19 04:21:45 --> Helper loaded: url_helper
INFO - 2016-09-19 04:21:45 --> Database Driver Class Initialized
INFO - 2016-09-19 04:21:45 --> Controller Class Initialized
DEBUG - 2016-09-19 04:21:45 --> Index MX_Controller Initialized
INFO - 2016-09-19 04:21:45 --> Model Class Initialized
INFO - 2016-09-19 04:21:45 --> Model Class Initialized
DEBUG - 2016-09-19 04:21:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-19 04:21:45 --> Final output sent to browser
DEBUG - 2016-09-19 04:21:45 --> Total execution time: 0.4488
INFO - 2016-09-19 04:21:46 --> Config Class Initialized
INFO - 2016-09-19 04:21:46 --> Hooks Class Initialized
DEBUG - 2016-09-19 04:21:46 --> UTF-8 Support Enabled
INFO - 2016-09-19 04:21:46 --> Utf8 Class Initialized
INFO - 2016-09-19 04:21:46 --> URI Class Initialized
INFO - 2016-09-19 04:21:46 --> Router Class Initialized
INFO - 2016-09-19 04:21:46 --> Output Class Initialized
INFO - 2016-09-19 04:21:46 --> Security Class Initialized
DEBUG - 2016-09-19 04:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 04:21:46 --> Input Class Initialized
INFO - 2016-09-19 04:21:46 --> Language Class Initialized
INFO - 2016-09-19 04:21:46 --> Language Class Initialized
INFO - 2016-09-19 04:21:46 --> Config Class Initialized
INFO - 2016-09-19 04:21:46 --> Loader Class Initialized
INFO - 2016-09-19 04:21:46 --> Helper loaded: url_helper
INFO - 2016-09-19 04:21:46 --> Database Driver Class Initialized
INFO - 2016-09-19 04:21:46 --> Controller Class Initialized
DEBUG - 2016-09-19 04:21:47 --> Index MX_Controller Initialized
INFO - 2016-09-19 04:21:47 --> Model Class Initialized
INFO - 2016-09-19 04:21:47 --> Model Class Initialized
DEBUG - 2016-09-19 04:21:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-19 04:21:47 --> Final output sent to browser
DEBUG - 2016-09-19 04:21:47 --> Total execution time: 0.5479
INFO - 2016-09-19 04:21:47 --> Config Class Initialized
INFO - 2016-09-19 04:21:47 --> Hooks Class Initialized
DEBUG - 2016-09-19 04:21:47 --> UTF-8 Support Enabled
INFO - 2016-09-19 04:21:47 --> Utf8 Class Initialized
INFO - 2016-09-19 04:21:47 --> URI Class Initialized
INFO - 2016-09-19 04:21:47 --> Router Class Initialized
INFO - 2016-09-19 04:21:47 --> Output Class Initialized
INFO - 2016-09-19 04:21:47 --> Security Class Initialized
DEBUG - 2016-09-19 04:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 04:21:47 --> Input Class Initialized
INFO - 2016-09-19 04:21:47 --> Language Class Initialized
INFO - 2016-09-19 04:21:47 --> Language Class Initialized
INFO - 2016-09-19 04:21:47 --> Config Class Initialized
INFO - 2016-09-19 04:21:47 --> Loader Class Initialized
INFO - 2016-09-19 04:21:47 --> Helper loaded: url_helper
INFO - 2016-09-19 04:21:47 --> Database Driver Class Initialized
INFO - 2016-09-19 04:21:47 --> Controller Class Initialized
DEBUG - 2016-09-19 04:21:47 --> Index MX_Controller Initialized
INFO - 2016-09-19 04:21:47 --> Model Class Initialized
INFO - 2016-09-19 04:21:47 --> Model Class Initialized
DEBUG - 2016-09-19 04:21:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-19 04:21:47 --> Final output sent to browser
DEBUG - 2016-09-19 04:21:47 --> Total execution time: 0.4942
INFO - 2016-09-19 04:21:48 --> Config Class Initialized
INFO - 2016-09-19 04:21:48 --> Hooks Class Initialized
DEBUG - 2016-09-19 04:21:48 --> UTF-8 Support Enabled
INFO - 2016-09-19 04:21:48 --> Utf8 Class Initialized
INFO - 2016-09-19 04:21:48 --> URI Class Initialized
INFO - 2016-09-19 04:21:48 --> Router Class Initialized
INFO - 2016-09-19 04:21:48 --> Output Class Initialized
INFO - 2016-09-19 04:21:48 --> Security Class Initialized
DEBUG - 2016-09-19 04:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 04:21:48 --> Input Class Initialized
INFO - 2016-09-19 04:21:48 --> Language Class Initialized
INFO - 2016-09-19 04:21:48 --> Language Class Initialized
INFO - 2016-09-19 04:21:48 --> Config Class Initialized
INFO - 2016-09-19 04:21:48 --> Loader Class Initialized
INFO - 2016-09-19 04:21:48 --> Helper loaded: url_helper
INFO - 2016-09-19 04:21:48 --> Database Driver Class Initialized
INFO - 2016-09-19 04:21:48 --> Controller Class Initialized
DEBUG - 2016-09-19 04:21:48 --> Index MX_Controller Initialized
INFO - 2016-09-19 04:21:48 --> Model Class Initialized
INFO - 2016-09-19 04:21:48 --> Model Class Initialized
DEBUG - 2016-09-19 04:21:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-19 04:21:48 --> Final output sent to browser
DEBUG - 2016-09-19 04:21:48 --> Total execution time: 0.5430
INFO - 2016-09-19 04:21:49 --> Config Class Initialized
INFO - 2016-09-19 04:21:49 --> Hooks Class Initialized
DEBUG - 2016-09-19 04:21:49 --> UTF-8 Support Enabled
INFO - 2016-09-19 04:21:49 --> Utf8 Class Initialized
INFO - 2016-09-19 04:21:49 --> URI Class Initialized
INFO - 2016-09-19 04:21:49 --> Router Class Initialized
INFO - 2016-09-19 04:21:49 --> Output Class Initialized
INFO - 2016-09-19 04:21:49 --> Security Class Initialized
DEBUG - 2016-09-19 04:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 04:21:49 --> Input Class Initialized
INFO - 2016-09-19 04:21:49 --> Language Class Initialized
INFO - 2016-09-19 04:21:49 --> Language Class Initialized
INFO - 2016-09-19 04:21:49 --> Config Class Initialized
INFO - 2016-09-19 04:21:49 --> Loader Class Initialized
INFO - 2016-09-19 04:21:49 --> Helper loaded: url_helper
INFO - 2016-09-19 04:21:49 --> Database Driver Class Initialized
INFO - 2016-09-19 04:21:49 --> Controller Class Initialized
DEBUG - 2016-09-19 04:21:49 --> Index MX_Controller Initialized
INFO - 2016-09-19 04:21:49 --> Model Class Initialized
INFO - 2016-09-19 04:21:49 --> Model Class Initialized
DEBUG - 2016-09-19 04:21:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-19 04:21:49 --> Final output sent to browser
DEBUG - 2016-09-19 04:21:49 --> Total execution time: 0.4577
INFO - 2016-09-19 04:21:49 --> Config Class Initialized
INFO - 2016-09-19 04:21:49 --> Hooks Class Initialized
DEBUG - 2016-09-19 04:21:49 --> UTF-8 Support Enabled
INFO - 2016-09-19 04:21:49 --> Utf8 Class Initialized
INFO - 2016-09-19 04:21:49 --> URI Class Initialized
INFO - 2016-09-19 04:21:49 --> Router Class Initialized
INFO - 2016-09-19 04:21:49 --> Output Class Initialized
INFO - 2016-09-19 04:21:49 --> Security Class Initialized
DEBUG - 2016-09-19 04:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 04:21:49 --> Input Class Initialized
INFO - 2016-09-19 04:21:49 --> Language Class Initialized
INFO - 2016-09-19 04:21:49 --> Language Class Initialized
INFO - 2016-09-19 04:21:49 --> Config Class Initialized
INFO - 2016-09-19 04:21:49 --> Loader Class Initialized
INFO - 2016-09-19 04:21:49 --> Helper loaded: url_helper
INFO - 2016-09-19 04:21:50 --> Database Driver Class Initialized
INFO - 2016-09-19 04:21:50 --> Controller Class Initialized
DEBUG - 2016-09-19 04:21:50 --> Index MX_Controller Initialized
INFO - 2016-09-19 04:21:50 --> Model Class Initialized
INFO - 2016-09-19 04:21:50 --> Model Class Initialized
DEBUG - 2016-09-19 04:21:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-19 04:21:50 --> Final output sent to browser
DEBUG - 2016-09-19 04:21:50 --> Total execution time: 0.4431
INFO - 2016-09-19 04:21:50 --> Config Class Initialized
INFO - 2016-09-19 04:21:50 --> Hooks Class Initialized
DEBUG - 2016-09-19 04:21:50 --> UTF-8 Support Enabled
INFO - 2016-09-19 04:21:50 --> Utf8 Class Initialized
INFO - 2016-09-19 04:21:50 --> URI Class Initialized
INFO - 2016-09-19 04:21:50 --> Router Class Initialized
INFO - 2016-09-19 04:21:50 --> Output Class Initialized
INFO - 2016-09-19 04:21:50 --> Security Class Initialized
DEBUG - 2016-09-19 04:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 04:21:50 --> Input Class Initialized
INFO - 2016-09-19 04:21:50 --> Language Class Initialized
INFO - 2016-09-19 04:21:50 --> Language Class Initialized
INFO - 2016-09-19 04:21:50 --> Config Class Initialized
INFO - 2016-09-19 04:21:50 --> Loader Class Initialized
INFO - 2016-09-19 04:21:50 --> Helper loaded: url_helper
INFO - 2016-09-19 04:21:51 --> Database Driver Class Initialized
INFO - 2016-09-19 04:21:51 --> Config Class Initialized
INFO - 2016-09-19 04:21:51 --> Hooks Class Initialized
INFO - 2016-09-19 04:21:51 --> Controller Class Initialized
DEBUG - 2016-09-19 04:21:51 --> Index MX_Controller Initialized
DEBUG - 2016-09-19 04:21:51 --> UTF-8 Support Enabled
INFO - 2016-09-19 04:21:51 --> Utf8 Class Initialized
INFO - 2016-09-19 04:21:51 --> Model Class Initialized
INFO - 2016-09-19 04:21:51 --> Model Class Initialized
INFO - 2016-09-19 04:21:51 --> URI Class Initialized
INFO - 2016-09-19 04:21:51 --> Router Class Initialized
DEBUG - 2016-09-19 04:21:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-19 04:21:51 --> Final output sent to browser
INFO - 2016-09-19 04:21:51 --> Output Class Initialized
DEBUG - 2016-09-19 04:21:51 --> Total execution time: 0.6322
INFO - 2016-09-19 04:21:51 --> Security Class Initialized
DEBUG - 2016-09-19 04:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 04:21:51 --> Input Class Initialized
INFO - 2016-09-19 04:21:51 --> Language Class Initialized
INFO - 2016-09-19 04:21:51 --> Language Class Initialized
INFO - 2016-09-19 04:21:51 --> Config Class Initialized
INFO - 2016-09-19 04:21:51 --> Loader Class Initialized
INFO - 2016-09-19 04:21:51 --> Helper loaded: url_helper
INFO - 2016-09-19 04:21:51 --> Database Driver Class Initialized
INFO - 2016-09-19 04:21:51 --> Config Class Initialized
INFO - 2016-09-19 04:21:51 --> Hooks Class Initialized
INFO - 2016-09-19 04:21:51 --> Controller Class Initialized
DEBUG - 2016-09-19 04:21:51 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 04:21:51 --> Index MX_Controller Initialized
INFO - 2016-09-19 04:21:51 --> Utf8 Class Initialized
INFO - 2016-09-19 04:21:51 --> Model Class Initialized
INFO - 2016-09-19 04:21:51 --> URI Class Initialized
INFO - 2016-09-19 04:21:51 --> Model Class Initialized
INFO - 2016-09-19 04:21:51 --> Router Class Initialized
INFO - 2016-09-19 04:21:51 --> Output Class Initialized
DEBUG - 2016-09-19 04:21:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-19 04:21:51 --> Final output sent to browser
INFO - 2016-09-19 04:21:51 --> Security Class Initialized
DEBUG - 2016-09-19 04:21:51 --> Total execution time: 0.5866
DEBUG - 2016-09-19 04:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 04:21:51 --> Input Class Initialized
INFO - 2016-09-19 04:21:51 --> Language Class Initialized
INFO - 2016-09-19 04:21:51 --> Language Class Initialized
INFO - 2016-09-19 04:21:51 --> Config Class Initialized
INFO - 2016-09-19 04:21:51 --> Loader Class Initialized
INFO - 2016-09-19 04:21:51 --> Helper loaded: url_helper
INFO - 2016-09-19 04:21:51 --> Database Driver Class Initialized
INFO - 2016-09-19 04:21:51 --> Controller Class Initialized
DEBUG - 2016-09-19 04:21:51 --> Index MX_Controller Initialized
INFO - 2016-09-19 04:21:51 --> Model Class Initialized
INFO - 2016-09-19 04:21:51 --> Model Class Initialized
DEBUG - 2016-09-19 04:21:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-19 04:21:51 --> Final output sent to browser
DEBUG - 2016-09-19 04:21:52 --> Total execution time: 0.4900
INFO - 2016-09-19 04:21:52 --> Config Class Initialized
INFO - 2016-09-19 04:21:52 --> Hooks Class Initialized
DEBUG - 2016-09-19 04:21:52 --> UTF-8 Support Enabled
INFO - 2016-09-19 04:21:52 --> Utf8 Class Initialized
INFO - 2016-09-19 04:21:52 --> URI Class Initialized
INFO - 2016-09-19 04:21:52 --> Router Class Initialized
INFO - 2016-09-19 04:21:52 --> Output Class Initialized
INFO - 2016-09-19 04:21:52 --> Security Class Initialized
DEBUG - 2016-09-19 04:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 04:21:52 --> Input Class Initialized
INFO - 2016-09-19 04:21:52 --> Language Class Initialized
INFO - 2016-09-19 04:21:52 --> Language Class Initialized
INFO - 2016-09-19 04:21:52 --> Config Class Initialized
INFO - 2016-09-19 04:21:52 --> Loader Class Initialized
INFO - 2016-09-19 04:21:52 --> Helper loaded: url_helper
INFO - 2016-09-19 04:21:52 --> Database Driver Class Initialized
INFO - 2016-09-19 04:21:52 --> Controller Class Initialized
DEBUG - 2016-09-19 04:21:52 --> Index MX_Controller Initialized
INFO - 2016-09-19 04:21:52 --> Model Class Initialized
INFO - 2016-09-19 04:21:52 --> Model Class Initialized
DEBUG - 2016-09-19 04:21:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-19 04:21:52 --> Final output sent to browser
DEBUG - 2016-09-19 04:21:52 --> Total execution time: 0.5557
INFO - 2016-09-19 04:21:54 --> Config Class Initialized
INFO - 2016-09-19 04:21:54 --> Hooks Class Initialized
DEBUG - 2016-09-19 04:21:54 --> UTF-8 Support Enabled
INFO - 2016-09-19 04:21:54 --> Utf8 Class Initialized
INFO - 2016-09-19 04:21:54 --> URI Class Initialized
INFO - 2016-09-19 04:21:54 --> Router Class Initialized
INFO - 2016-09-19 04:21:55 --> Output Class Initialized
INFO - 2016-09-19 04:21:55 --> Security Class Initialized
DEBUG - 2016-09-19 04:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 04:21:55 --> Input Class Initialized
INFO - 2016-09-19 04:21:55 --> Language Class Initialized
INFO - 2016-09-19 04:21:55 --> Language Class Initialized
INFO - 2016-09-19 04:21:55 --> Config Class Initialized
INFO - 2016-09-19 04:21:55 --> Loader Class Initialized
INFO - 2016-09-19 04:21:55 --> Helper loaded: url_helper
INFO - 2016-09-19 04:21:55 --> Database Driver Class Initialized
INFO - 2016-09-19 04:21:55 --> Controller Class Initialized
DEBUG - 2016-09-19 04:21:55 --> Index MX_Controller Initialized
INFO - 2016-09-19 04:21:55 --> Model Class Initialized
INFO - 2016-09-19 04:21:55 --> Model Class Initialized
DEBUG - 2016-09-19 04:21:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_transaksi.php
INFO - 2016-09-19 04:21:55 --> Final output sent to browser
DEBUG - 2016-09-19 04:21:55 --> Total execution time: 0.6393
INFO - 2016-09-19 04:22:07 --> Config Class Initialized
INFO - 2016-09-19 04:22:07 --> Hooks Class Initialized
DEBUG - 2016-09-19 04:22:07 --> UTF-8 Support Enabled
INFO - 2016-09-19 04:22:07 --> Utf8 Class Initialized
INFO - 2016-09-19 04:22:07 --> URI Class Initialized
INFO - 2016-09-19 04:22:07 --> Router Class Initialized
INFO - 2016-09-19 04:22:07 --> Output Class Initialized
INFO - 2016-09-19 04:22:07 --> Security Class Initialized
DEBUG - 2016-09-19 04:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 04:22:07 --> Input Class Initialized
INFO - 2016-09-19 04:22:08 --> Language Class Initialized
INFO - 2016-09-19 04:22:08 --> Language Class Initialized
INFO - 2016-09-19 04:22:08 --> Config Class Initialized
INFO - 2016-09-19 04:22:08 --> Loader Class Initialized
INFO - 2016-09-19 04:22:08 --> Helper loaded: url_helper
INFO - 2016-09-19 04:22:08 --> Database Driver Class Initialized
INFO - 2016-09-19 04:22:08 --> Controller Class Initialized
DEBUG - 2016-09-19 04:22:08 --> Index MX_Controller Initialized
INFO - 2016-09-19 04:22:08 --> Model Class Initialized
INFO - 2016-09-19 04:22:08 --> Model Class Initialized
DEBUG - 2016-09-19 04:22:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_transaksi.php
INFO - 2016-09-19 04:22:08 --> Final output sent to browser
DEBUG - 2016-09-19 04:22:08 --> Total execution time: 0.6545
INFO - 2016-09-19 04:22:46 --> Config Class Initialized
INFO - 2016-09-19 04:22:46 --> Hooks Class Initialized
DEBUG - 2016-09-19 04:22:46 --> UTF-8 Support Enabled
INFO - 2016-09-19 04:22:46 --> Utf8 Class Initialized
INFO - 2016-09-19 04:22:46 --> URI Class Initialized
INFO - 2016-09-19 04:22:46 --> Router Class Initialized
INFO - 2016-09-19 04:22:46 --> Output Class Initialized
INFO - 2016-09-19 04:22:46 --> Security Class Initialized
DEBUG - 2016-09-19 04:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 04:22:46 --> Input Class Initialized
INFO - 2016-09-19 04:22:46 --> Language Class Initialized
INFO - 2016-09-19 04:22:46 --> Language Class Initialized
INFO - 2016-09-19 04:22:46 --> Config Class Initialized
INFO - 2016-09-19 04:22:46 --> Loader Class Initialized
INFO - 2016-09-19 04:22:46 --> Helper loaded: url_helper
INFO - 2016-09-19 04:22:47 --> Database Driver Class Initialized
INFO - 2016-09-19 04:22:47 --> Controller Class Initialized
DEBUG - 2016-09-19 04:22:47 --> Index MX_Controller Initialized
INFO - 2016-09-19 04:22:47 --> Model Class Initialized
INFO - 2016-09-19 04:22:47 --> Model Class Initialized
DEBUG - 2016-09-19 04:22:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_transaksi.php
INFO - 2016-09-19 04:22:47 --> Final output sent to browser
DEBUG - 2016-09-19 04:22:47 --> Total execution time: 0.7226
INFO - 2016-09-19 04:22:53 --> Config Class Initialized
INFO - 2016-09-19 04:22:53 --> Hooks Class Initialized
DEBUG - 2016-09-19 04:22:53 --> UTF-8 Support Enabled
INFO - 2016-09-19 04:22:53 --> Utf8 Class Initialized
INFO - 2016-09-19 04:22:53 --> URI Class Initialized
INFO - 2016-09-19 04:22:53 --> Router Class Initialized
INFO - 2016-09-19 04:22:53 --> Output Class Initialized
INFO - 2016-09-19 04:22:53 --> Security Class Initialized
DEBUG - 2016-09-19 04:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 04:22:53 --> Input Class Initialized
INFO - 2016-09-19 04:22:53 --> Language Class Initialized
INFO - 2016-09-19 04:22:53 --> Language Class Initialized
INFO - 2016-09-19 04:22:53 --> Config Class Initialized
INFO - 2016-09-19 04:22:53 --> Loader Class Initialized
INFO - 2016-09-19 04:22:53 --> Helper loaded: url_helper
INFO - 2016-09-19 04:22:53 --> Database Driver Class Initialized
INFO - 2016-09-19 04:22:53 --> Controller Class Initialized
DEBUG - 2016-09-19 04:22:53 --> Index MX_Controller Initialized
INFO - 2016-09-19 04:22:53 --> Model Class Initialized
INFO - 2016-09-19 04:22:54 --> Model Class Initialized
DEBUG - 2016-09-19 04:22:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 04:22:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 04:22:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 04:22:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 04:22:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 04:22:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 04:22:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 04:22:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 04:22:54 --> Final output sent to browser
DEBUG - 2016-09-19 04:22:54 --> Total execution time: 0.6258
INFO - 2016-09-19 04:23:16 --> Config Class Initialized
INFO - 2016-09-19 04:23:16 --> Hooks Class Initialized
DEBUG - 2016-09-19 04:23:16 --> UTF-8 Support Enabled
INFO - 2016-09-19 04:23:16 --> Utf8 Class Initialized
INFO - 2016-09-19 04:23:16 --> URI Class Initialized
INFO - 2016-09-19 04:23:16 --> Router Class Initialized
INFO - 2016-09-19 04:23:16 --> Output Class Initialized
INFO - 2016-09-19 04:23:16 --> Security Class Initialized
DEBUG - 2016-09-19 04:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 04:23:16 --> Input Class Initialized
INFO - 2016-09-19 04:23:16 --> Language Class Initialized
INFO - 2016-09-19 04:23:16 --> Language Class Initialized
INFO - 2016-09-19 04:23:16 --> Config Class Initialized
INFO - 2016-09-19 04:23:16 --> Loader Class Initialized
INFO - 2016-09-19 04:23:16 --> Helper loaded: url_helper
INFO - 2016-09-19 04:23:16 --> Database Driver Class Initialized
INFO - 2016-09-19 04:23:16 --> Controller Class Initialized
DEBUG - 2016-09-19 04:23:16 --> Index MX_Controller Initialized
INFO - 2016-09-19 04:23:16 --> Model Class Initialized
INFO - 2016-09-19 04:23:16 --> Model Class Initialized
DEBUG - 2016-09-19 04:23:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 04:23:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 04:23:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 04:23:17 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-19 04:23:17 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-19 04:23:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-19 04:23:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 04:23:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 04:23:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 04:23:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 04:23:17 --> Final output sent to browser
DEBUG - 2016-09-19 04:23:17 --> Total execution time: 0.6701
INFO - 2016-09-19 04:23:49 --> Config Class Initialized
INFO - 2016-09-19 04:23:49 --> Hooks Class Initialized
DEBUG - 2016-09-19 04:23:49 --> UTF-8 Support Enabled
INFO - 2016-09-19 04:23:49 --> Utf8 Class Initialized
INFO - 2016-09-19 04:23:49 --> URI Class Initialized
INFO - 2016-09-19 04:23:49 --> Router Class Initialized
INFO - 2016-09-19 04:23:49 --> Output Class Initialized
INFO - 2016-09-19 04:23:49 --> Security Class Initialized
DEBUG - 2016-09-19 04:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 04:23:49 --> Input Class Initialized
INFO - 2016-09-19 04:23:49 --> Language Class Initialized
INFO - 2016-09-19 04:23:49 --> Language Class Initialized
INFO - 2016-09-19 04:23:49 --> Config Class Initialized
INFO - 2016-09-19 04:23:50 --> Loader Class Initialized
INFO - 2016-09-19 04:23:50 --> Helper loaded: url_helper
INFO - 2016-09-19 04:23:50 --> Database Driver Class Initialized
INFO - 2016-09-19 04:23:50 --> Controller Class Initialized
DEBUG - 2016-09-19 04:23:50 --> Index MX_Controller Initialized
INFO - 2016-09-19 04:23:50 --> Model Class Initialized
INFO - 2016-09-19 04:23:50 --> Model Class Initialized
DEBUG - 2016-09-19 04:23:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 04:23:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 04:23:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 04:23:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-19 04:23:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 04:23:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 04:23:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 04:23:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 04:23:50 --> Final output sent to browser
DEBUG - 2016-09-19 04:23:50 --> Total execution time: 0.6714
INFO - 2016-09-19 04:27:27 --> Config Class Initialized
INFO - 2016-09-19 04:27:27 --> Hooks Class Initialized
DEBUG - 2016-09-19 04:27:27 --> UTF-8 Support Enabled
INFO - 2016-09-19 04:27:27 --> Utf8 Class Initialized
INFO - 2016-09-19 04:27:27 --> URI Class Initialized
INFO - 2016-09-19 04:27:27 --> Router Class Initialized
INFO - 2016-09-19 04:27:27 --> Output Class Initialized
INFO - 2016-09-19 04:27:27 --> Security Class Initialized
DEBUG - 2016-09-19 04:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 04:27:27 --> Input Class Initialized
INFO - 2016-09-19 04:27:27 --> Language Class Initialized
INFO - 2016-09-19 04:27:28 --> Language Class Initialized
INFO - 2016-09-19 04:27:28 --> Config Class Initialized
INFO - 2016-09-19 04:27:28 --> Loader Class Initialized
INFO - 2016-09-19 04:27:28 --> Helper loaded: url_helper
INFO - 2016-09-19 04:27:28 --> Database Driver Class Initialized
INFO - 2016-09-19 04:27:28 --> Controller Class Initialized
DEBUG - 2016-09-19 04:27:28 --> Index MX_Controller Initialized
INFO - 2016-09-19 04:27:28 --> Model Class Initialized
INFO - 2016-09-19 04:27:28 --> Model Class Initialized
DEBUG - 2016-09-19 04:27:28 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-19 04:27:28 --> Users MX_Controller Initialized
INFO - 2016-09-19 04:27:28 --> Database Driver Class Initialized
INFO - 2016-09-19 04:27:28 --> Final output sent to browser
DEBUG - 2016-09-19 04:27:28 --> Total execution time: 0.6132
INFO - 2016-09-19 04:28:12 --> Config Class Initialized
INFO - 2016-09-19 04:28:12 --> Hooks Class Initialized
DEBUG - 2016-09-19 04:28:13 --> UTF-8 Support Enabled
INFO - 2016-09-19 04:28:13 --> Utf8 Class Initialized
INFO - 2016-09-19 04:28:13 --> URI Class Initialized
INFO - 2016-09-19 04:28:13 --> Router Class Initialized
INFO - 2016-09-19 04:28:13 --> Output Class Initialized
INFO - 2016-09-19 04:28:13 --> Security Class Initialized
DEBUG - 2016-09-19 04:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 04:28:13 --> Input Class Initialized
INFO - 2016-09-19 04:28:13 --> Language Class Initialized
INFO - 2016-09-19 04:28:13 --> Language Class Initialized
INFO - 2016-09-19 04:28:13 --> Config Class Initialized
INFO - 2016-09-19 04:28:13 --> Loader Class Initialized
INFO - 2016-09-19 04:28:13 --> Helper loaded: url_helper
INFO - 2016-09-19 04:28:13 --> Database Driver Class Initialized
INFO - 2016-09-19 04:28:13 --> Controller Class Initialized
DEBUG - 2016-09-19 04:28:13 --> Index MX_Controller Initialized
INFO - 2016-09-19 04:28:13 --> Model Class Initialized
INFO - 2016-09-19 04:28:13 --> Model Class Initialized
DEBUG - 2016-09-19 04:28:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 04:28:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 04:28:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 04:28:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 04:28:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 04:28:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 04:28:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 04:28:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 04:28:13 --> Final output sent to browser
DEBUG - 2016-09-19 04:28:13 --> Total execution time: 0.6351
INFO - 2016-09-19 04:28:40 --> Config Class Initialized
INFO - 2016-09-19 04:28:40 --> Hooks Class Initialized
DEBUG - 2016-09-19 04:28:40 --> UTF-8 Support Enabled
INFO - 2016-09-19 04:28:40 --> Utf8 Class Initialized
INFO - 2016-09-19 04:28:40 --> URI Class Initialized
INFO - 2016-09-19 04:28:40 --> Router Class Initialized
INFO - 2016-09-19 04:28:40 --> Output Class Initialized
INFO - 2016-09-19 04:28:40 --> Security Class Initialized
DEBUG - 2016-09-19 04:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 04:28:40 --> Input Class Initialized
INFO - 2016-09-19 04:28:40 --> Language Class Initialized
INFO - 2016-09-19 04:28:40 --> Language Class Initialized
INFO - 2016-09-19 04:28:40 --> Config Class Initialized
INFO - 2016-09-19 04:28:40 --> Loader Class Initialized
INFO - 2016-09-19 04:28:40 --> Helper loaded: url_helper
INFO - 2016-09-19 04:28:40 --> Database Driver Class Initialized
INFO - 2016-09-19 04:28:40 --> Controller Class Initialized
DEBUG - 2016-09-19 04:28:40 --> Index MX_Controller Initialized
INFO - 2016-09-19 04:28:40 --> Model Class Initialized
INFO - 2016-09-19 04:28:40 --> Model Class Initialized
DEBUG - 2016-09-19 04:28:40 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 04:28:40 --> Database Driver Class Initialized
INFO - 2016-09-19 04:28:40 --> Final output sent to browser
DEBUG - 2016-09-19 04:28:40 --> Total execution time: 0.5471
INFO - 2016-09-19 04:28:44 --> Config Class Initialized
INFO - 2016-09-19 04:28:44 --> Hooks Class Initialized
DEBUG - 2016-09-19 04:28:44 --> UTF-8 Support Enabled
INFO - 2016-09-19 04:28:44 --> Utf8 Class Initialized
INFO - 2016-09-19 04:28:44 --> URI Class Initialized
INFO - 2016-09-19 04:28:44 --> Router Class Initialized
INFO - 2016-09-19 04:28:44 --> Output Class Initialized
INFO - 2016-09-19 04:28:44 --> Security Class Initialized
DEBUG - 2016-09-19 04:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 04:28:45 --> Input Class Initialized
INFO - 2016-09-19 04:28:45 --> Language Class Initialized
INFO - 2016-09-19 04:28:45 --> Language Class Initialized
INFO - 2016-09-19 04:28:45 --> Config Class Initialized
INFO - 2016-09-19 04:28:45 --> Loader Class Initialized
INFO - 2016-09-19 04:28:45 --> Helper loaded: url_helper
INFO - 2016-09-19 04:28:45 --> Database Driver Class Initialized
INFO - 2016-09-19 04:28:45 --> Controller Class Initialized
DEBUG - 2016-09-19 04:28:45 --> Index MX_Controller Initialized
INFO - 2016-09-19 04:28:45 --> Model Class Initialized
INFO - 2016-09-19 04:28:45 --> Model Class Initialized
DEBUG - 2016-09-19 04:28:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 04:28:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 04:28:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 04:28:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_umum.php
DEBUG - 2016-09-19 04:28:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 04:28:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 04:28:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 04:28:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 04:28:45 --> Final output sent to browser
DEBUG - 2016-09-19 04:28:45 --> Total execution time: 0.7408
INFO - 2016-09-19 05:59:42 --> Config Class Initialized
INFO - 2016-09-19 05:59:43 --> Hooks Class Initialized
DEBUG - 2016-09-19 05:59:43 --> UTF-8 Support Enabled
INFO - 2016-09-19 05:59:43 --> Utf8 Class Initialized
INFO - 2016-09-19 05:59:43 --> URI Class Initialized
INFO - 2016-09-19 05:59:43 --> Router Class Initialized
INFO - 2016-09-19 05:59:43 --> Output Class Initialized
INFO - 2016-09-19 05:59:43 --> Security Class Initialized
DEBUG - 2016-09-19 05:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 05:59:43 --> Input Class Initialized
INFO - 2016-09-19 05:59:43 --> Language Class Initialized
INFO - 2016-09-19 05:59:43 --> Language Class Initialized
INFO - 2016-09-19 05:59:43 --> Config Class Initialized
INFO - 2016-09-19 05:59:43 --> Loader Class Initialized
INFO - 2016-09-19 05:59:43 --> Helper loaded: url_helper
INFO - 2016-09-19 05:59:43 --> Database Driver Class Initialized
INFO - 2016-09-19 05:59:43 --> Controller Class Initialized
DEBUG - 2016-09-19 05:59:43 --> Index MX_Controller Initialized
INFO - 2016-09-19 05:59:43 --> Model Class Initialized
INFO - 2016-09-19 05:59:43 --> Model Class Initialized
INFO - 2016-09-19 05:59:43 --> Database Driver Class Initialized
INFO - 2016-09-19 05:59:43 --> Final output sent to browser
DEBUG - 2016-09-19 05:59:43 --> Total execution time: 0.8296
INFO - 2016-09-19 05:59:47 --> Config Class Initialized
INFO - 2016-09-19 05:59:47 --> Hooks Class Initialized
DEBUG - 2016-09-19 05:59:47 --> UTF-8 Support Enabled
INFO - 2016-09-19 05:59:47 --> Utf8 Class Initialized
INFO - 2016-09-19 05:59:47 --> URI Class Initialized
INFO - 2016-09-19 05:59:47 --> Router Class Initialized
INFO - 2016-09-19 05:59:48 --> Output Class Initialized
INFO - 2016-09-19 05:59:48 --> Security Class Initialized
DEBUG - 2016-09-19 05:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 05:59:48 --> Input Class Initialized
INFO - 2016-09-19 05:59:48 --> Language Class Initialized
INFO - 2016-09-19 05:59:48 --> Language Class Initialized
INFO - 2016-09-19 05:59:48 --> Config Class Initialized
INFO - 2016-09-19 05:59:48 --> Loader Class Initialized
INFO - 2016-09-19 05:59:48 --> Helper loaded: url_helper
INFO - 2016-09-19 05:59:48 --> Database Driver Class Initialized
INFO - 2016-09-19 05:59:48 --> Controller Class Initialized
DEBUG - 2016-09-19 05:59:48 --> Index MX_Controller Initialized
INFO - 2016-09-19 05:59:48 --> Model Class Initialized
INFO - 2016-09-19 05:59:48 --> Model Class Initialized
INFO - 2016-09-19 05:59:48 --> Database Driver Class Initialized
INFO - 2016-09-19 05:59:48 --> Final output sent to browser
DEBUG - 2016-09-19 05:59:48 --> Total execution time: 0.6636
INFO - 2016-09-19 05:59:54 --> Config Class Initialized
INFO - 2016-09-19 05:59:54 --> Hooks Class Initialized
DEBUG - 2016-09-19 05:59:54 --> UTF-8 Support Enabled
INFO - 2016-09-19 05:59:54 --> Utf8 Class Initialized
INFO - 2016-09-19 05:59:54 --> URI Class Initialized
INFO - 2016-09-19 05:59:54 --> Router Class Initialized
INFO - 2016-09-19 05:59:54 --> Output Class Initialized
INFO - 2016-09-19 05:59:54 --> Security Class Initialized
DEBUG - 2016-09-19 05:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 05:59:54 --> Input Class Initialized
INFO - 2016-09-19 05:59:54 --> Language Class Initialized
INFO - 2016-09-19 05:59:54 --> Language Class Initialized
INFO - 2016-09-19 05:59:54 --> Config Class Initialized
INFO - 2016-09-19 05:59:54 --> Loader Class Initialized
INFO - 2016-09-19 05:59:54 --> Helper loaded: url_helper
INFO - 2016-09-19 05:59:54 --> Database Driver Class Initialized
INFO - 2016-09-19 05:59:55 --> Controller Class Initialized
DEBUG - 2016-09-19 05:59:55 --> Index MX_Controller Initialized
INFO - 2016-09-19 05:59:55 --> Model Class Initialized
INFO - 2016-09-19 05:59:55 --> Model Class Initialized
INFO - 2016-09-19 05:59:55 --> Database Driver Class Initialized
INFO - 2016-09-19 05:59:55 --> Database Driver Class Initialized
INFO - 2016-09-19 05:59:55 --> Final output sent to browser
DEBUG - 2016-09-19 05:59:55 --> Total execution time: 0.5982
INFO - 2016-09-19 06:00:06 --> Config Class Initialized
INFO - 2016-09-19 06:00:06 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:00:06 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:00:06 --> Utf8 Class Initialized
INFO - 2016-09-19 06:00:06 --> URI Class Initialized
INFO - 2016-09-19 06:00:06 --> Router Class Initialized
INFO - 2016-09-19 06:00:07 --> Output Class Initialized
INFO - 2016-09-19 06:00:07 --> Security Class Initialized
DEBUG - 2016-09-19 06:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:00:07 --> Input Class Initialized
INFO - 2016-09-19 06:00:07 --> Language Class Initialized
INFO - 2016-09-19 06:00:07 --> Language Class Initialized
INFO - 2016-09-19 06:00:07 --> Config Class Initialized
INFO - 2016-09-19 06:00:07 --> Loader Class Initialized
INFO - 2016-09-19 06:00:07 --> Helper loaded: url_helper
INFO - 2016-09-19 06:00:07 --> Database Driver Class Initialized
INFO - 2016-09-19 06:00:07 --> Controller Class Initialized
DEBUG - 2016-09-19 06:00:07 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:00:07 --> Model Class Initialized
INFO - 2016-09-19 06:00:07 --> Model Class Initialized
DEBUG - 2016-09-19 06:00:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 06:00:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 06:00:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 06:00:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-19 06:00:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 06:00:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 06:00:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 06:00:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 06:00:07 --> Final output sent to browser
DEBUG - 2016-09-19 06:00:07 --> Total execution time: 0.6952
INFO - 2016-09-19 06:00:38 --> Config Class Initialized
INFO - 2016-09-19 06:00:38 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:00:38 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:00:38 --> Utf8 Class Initialized
INFO - 2016-09-19 06:00:38 --> URI Class Initialized
INFO - 2016-09-19 06:00:38 --> Router Class Initialized
INFO - 2016-09-19 06:00:38 --> Output Class Initialized
INFO - 2016-09-19 06:00:38 --> Security Class Initialized
DEBUG - 2016-09-19 06:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:00:38 --> Input Class Initialized
INFO - 2016-09-19 06:00:38 --> Language Class Initialized
INFO - 2016-09-19 06:00:38 --> Language Class Initialized
INFO - 2016-09-19 06:00:38 --> Config Class Initialized
INFO - 2016-09-19 06:00:38 --> Loader Class Initialized
INFO - 2016-09-19 06:00:38 --> Helper loaded: url_helper
INFO - 2016-09-19 06:00:38 --> Database Driver Class Initialized
INFO - 2016-09-19 06:00:38 --> Controller Class Initialized
DEBUG - 2016-09-19 06:00:38 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:00:38 --> Model Class Initialized
INFO - 2016-09-19 06:00:38 --> Model Class Initialized
DEBUG - 2016-09-19 06:00:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 06:00:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 06:00:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 06:00:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-19 06:00:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 06:00:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 06:00:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 06:00:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 06:00:38 --> Final output sent to browser
DEBUG - 2016-09-19 06:00:38 --> Total execution time: 0.7573
INFO - 2016-09-19 06:01:50 --> Config Class Initialized
INFO - 2016-09-19 06:01:50 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:01:50 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:01:50 --> Utf8 Class Initialized
INFO - 2016-09-19 06:01:50 --> URI Class Initialized
INFO - 2016-09-19 06:01:50 --> Router Class Initialized
INFO - 2016-09-19 06:01:50 --> Output Class Initialized
INFO - 2016-09-19 06:01:50 --> Security Class Initialized
DEBUG - 2016-09-19 06:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:01:50 --> Input Class Initialized
INFO - 2016-09-19 06:01:50 --> Language Class Initialized
INFO - 2016-09-19 06:01:50 --> Language Class Initialized
INFO - 2016-09-19 06:01:50 --> Config Class Initialized
INFO - 2016-09-19 06:01:50 --> Loader Class Initialized
INFO - 2016-09-19 06:01:50 --> Helper loaded: url_helper
INFO - 2016-09-19 06:01:50 --> Database Driver Class Initialized
INFO - 2016-09-19 06:01:50 --> Controller Class Initialized
DEBUG - 2016-09-19 06:01:50 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:01:50 --> Model Class Initialized
INFO - 2016-09-19 06:01:50 --> Model Class Initialized
DEBUG - 2016-09-19 06:01:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 06:01:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 06:01:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 06:01:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-19 06:01:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 06:01:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 06:01:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 06:01:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 06:01:51 --> Final output sent to browser
DEBUG - 2016-09-19 06:01:51 --> Total execution time: 0.7926
INFO - 2016-09-19 06:02:08 --> Config Class Initialized
INFO - 2016-09-19 06:02:08 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:02:08 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:02:08 --> Utf8 Class Initialized
INFO - 2016-09-19 06:02:08 --> URI Class Initialized
INFO - 2016-09-19 06:02:08 --> Router Class Initialized
INFO - 2016-09-19 06:02:08 --> Output Class Initialized
INFO - 2016-09-19 06:02:08 --> Security Class Initialized
DEBUG - 2016-09-19 06:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:02:08 --> Input Class Initialized
INFO - 2016-09-19 06:02:08 --> Language Class Initialized
INFO - 2016-09-19 06:02:08 --> Language Class Initialized
INFO - 2016-09-19 06:02:08 --> Config Class Initialized
INFO - 2016-09-19 06:02:08 --> Loader Class Initialized
INFO - 2016-09-19 06:02:08 --> Helper loaded: url_helper
INFO - 2016-09-19 06:02:08 --> Database Driver Class Initialized
INFO - 2016-09-19 06:02:08 --> Controller Class Initialized
DEBUG - 2016-09-19 06:02:08 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:02:08 --> Model Class Initialized
INFO - 2016-09-19 06:02:08 --> Model Class Initialized
DEBUG - 2016-09-19 06:02:08 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-19 06:02:08 --> Users MX_Controller Initialized
INFO - 2016-09-19 06:02:09 --> Final output sent to browser
DEBUG - 2016-09-19 06:02:09 --> Total execution time: 0.6428
INFO - 2016-09-19 06:02:42 --> Config Class Initialized
INFO - 2016-09-19 06:02:42 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:02:42 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:02:42 --> Utf8 Class Initialized
INFO - 2016-09-19 06:02:42 --> URI Class Initialized
INFO - 2016-09-19 06:02:42 --> Router Class Initialized
INFO - 2016-09-19 06:02:42 --> Output Class Initialized
INFO - 2016-09-19 06:02:42 --> Security Class Initialized
DEBUG - 2016-09-19 06:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:02:42 --> Input Class Initialized
INFO - 2016-09-19 06:02:42 --> Language Class Initialized
INFO - 2016-09-19 06:02:42 --> Language Class Initialized
INFO - 2016-09-19 06:02:42 --> Config Class Initialized
INFO - 2016-09-19 06:02:42 --> Loader Class Initialized
INFO - 2016-09-19 06:02:42 --> Helper loaded: url_helper
INFO - 2016-09-19 06:02:42 --> Database Driver Class Initialized
INFO - 2016-09-19 06:02:43 --> Controller Class Initialized
DEBUG - 2016-09-19 06:02:43 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:02:43 --> Model Class Initialized
INFO - 2016-09-19 06:02:43 --> Model Class Initialized
DEBUG - 2016-09-19 06:02:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 06:02:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 06:02:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 06:02:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_user.php
DEBUG - 2016-09-19 06:02:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 06:02:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 06:02:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 06:02:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 06:02:43 --> Final output sent to browser
DEBUG - 2016-09-19 06:02:43 --> Total execution time: 0.7281
INFO - 2016-09-19 06:03:21 --> Config Class Initialized
INFO - 2016-09-19 06:03:21 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:03:21 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:03:21 --> Utf8 Class Initialized
INFO - 2016-09-19 06:03:21 --> URI Class Initialized
INFO - 2016-09-19 06:03:21 --> Router Class Initialized
INFO - 2016-09-19 06:03:21 --> Output Class Initialized
INFO - 2016-09-19 06:03:21 --> Security Class Initialized
DEBUG - 2016-09-19 06:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:03:21 --> Input Class Initialized
INFO - 2016-09-19 06:03:21 --> Language Class Initialized
INFO - 2016-09-19 06:03:21 --> Language Class Initialized
INFO - 2016-09-19 06:03:21 --> Config Class Initialized
INFO - 2016-09-19 06:03:21 --> Loader Class Initialized
INFO - 2016-09-19 06:03:21 --> Helper loaded: url_helper
INFO - 2016-09-19 06:03:21 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:21 --> Controller Class Initialized
DEBUG - 2016-09-19 06:03:21 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:03:21 --> Model Class Initialized
INFO - 2016-09-19 06:03:21 --> Model Class Initialized
DEBUG - 2016-09-19 06:03:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 06:03:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 06:03:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 06:03:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/pinjaman.php
DEBUG - 2016-09-19 06:03:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 06:03:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 06:03:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 06:03:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 06:03:22 --> Final output sent to browser
DEBUG - 2016-09-19 06:03:22 --> Total execution time: 0.8006
INFO - 2016-09-19 06:03:38 --> Config Class Initialized
INFO - 2016-09-19 06:03:38 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:03:38 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:03:38 --> Utf8 Class Initialized
INFO - 2016-09-19 06:03:38 --> URI Class Initialized
INFO - 2016-09-19 06:03:38 --> Router Class Initialized
INFO - 2016-09-19 06:03:39 --> Output Class Initialized
INFO - 2016-09-19 06:03:39 --> Security Class Initialized
DEBUG - 2016-09-19 06:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:03:39 --> Input Class Initialized
INFO - 2016-09-19 06:03:39 --> Language Class Initialized
INFO - 2016-09-19 06:03:39 --> Language Class Initialized
INFO - 2016-09-19 06:03:39 --> Config Class Initialized
INFO - 2016-09-19 06:03:39 --> Loader Class Initialized
INFO - 2016-09-19 06:03:39 --> Helper loaded: url_helper
INFO - 2016-09-19 06:03:39 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:39 --> Controller Class Initialized
DEBUG - 2016-09-19 06:03:39 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:03:39 --> Model Class Initialized
INFO - 2016-09-19 06:03:39 --> Model Class Initialized
DEBUG - 2016-09-19 06:03:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_pinjaman.php
INFO - 2016-09-19 06:03:39 --> Final output sent to browser
DEBUG - 2016-09-19 06:03:39 --> Total execution time: 0.5588
INFO - 2016-09-19 06:03:42 --> Config Class Initialized
INFO - 2016-09-19 06:03:42 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:03:43 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:03:43 --> Utf8 Class Initialized
INFO - 2016-09-19 06:03:43 --> URI Class Initialized
INFO - 2016-09-19 06:03:43 --> Router Class Initialized
INFO - 2016-09-19 06:03:43 --> Output Class Initialized
INFO - 2016-09-19 06:03:43 --> Security Class Initialized
DEBUG - 2016-09-19 06:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:03:43 --> Input Class Initialized
INFO - 2016-09-19 06:03:43 --> Language Class Initialized
INFO - 2016-09-19 06:03:43 --> Language Class Initialized
INFO - 2016-09-19 06:03:43 --> Config Class Initialized
INFO - 2016-09-19 06:03:43 --> Loader Class Initialized
INFO - 2016-09-19 06:03:43 --> Helper loaded: url_helper
INFO - 2016-09-19 06:03:43 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:43 --> Controller Class Initialized
DEBUG - 2016-09-19 06:03:43 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:03:43 --> Model Class Initialized
INFO - 2016-09-19 06:03:43 --> Model Class Initialized
DEBUG - 2016-09-19 06:03:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 06:03:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 06:03:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 06:03:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/angsuran.php
DEBUG - 2016-09-19 06:03:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 06:03:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 06:03:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 06:03:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 06:03:43 --> Final output sent to browser
DEBUG - 2016-09-19 06:03:43 --> Total execution time: 0.7128
INFO - 2016-09-19 06:03:49 --> Config Class Initialized
INFO - 2016-09-19 06:03:50 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:03:50 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:03:50 --> Utf8 Class Initialized
INFO - 2016-09-19 06:03:50 --> URI Class Initialized
INFO - 2016-09-19 06:03:50 --> Router Class Initialized
INFO - 2016-09-19 06:03:50 --> Output Class Initialized
INFO - 2016-09-19 06:03:50 --> Security Class Initialized
DEBUG - 2016-09-19 06:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:03:50 --> Input Class Initialized
INFO - 2016-09-19 06:03:50 --> Language Class Initialized
INFO - 2016-09-19 06:03:50 --> Language Class Initialized
INFO - 2016-09-19 06:03:50 --> Config Class Initialized
INFO - 2016-09-19 06:03:50 --> Loader Class Initialized
INFO - 2016-09-19 06:03:50 --> Helper loaded: url_helper
INFO - 2016-09-19 06:03:50 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:50 --> Controller Class Initialized
DEBUG - 2016-09-19 06:03:50 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:03:50 --> Model Class Initialized
INFO - 2016-09-19 06:03:50 --> Model Class Initialized
INFO - 2016-09-19 06:03:50 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:50 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:50 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:50 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:50 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:50 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:50 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:50 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:50 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:50 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:50 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:50 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:50 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:50 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:50 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:50 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:50 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:50 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:50 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:51 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:51 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:51 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:51 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:51 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:51 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:51 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:51 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:51 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:51 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:51 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:51 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:51 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:51 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:51 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:51 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:51 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:51 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:51 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:51 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:51 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:51 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:51 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:51 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:51 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:51 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:51 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:51 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:51 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:51 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:52 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:52 --> Database Driver Class Initialized
INFO - 2016-09-19 06:03:52 --> Database Driver Class Initialized
DEBUG - 2016-09-19 06:03:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_angsuran.php
INFO - 2016-09-19 06:03:52 --> Final output sent to browser
DEBUG - 2016-09-19 06:03:52 --> Total execution time: 2.1327
INFO - 2016-09-19 06:04:24 --> Config Class Initialized
INFO - 2016-09-19 06:04:24 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:04:24 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:04:24 --> Utf8 Class Initialized
INFO - 2016-09-19 06:04:24 --> URI Class Initialized
INFO - 2016-09-19 06:04:24 --> Router Class Initialized
INFO - 2016-09-19 06:04:24 --> Output Class Initialized
INFO - 2016-09-19 06:04:24 --> Security Class Initialized
DEBUG - 2016-09-19 06:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:04:24 --> Input Class Initialized
INFO - 2016-09-19 06:04:24 --> Language Class Initialized
INFO - 2016-09-19 06:04:24 --> Language Class Initialized
INFO - 2016-09-19 06:04:24 --> Config Class Initialized
INFO - 2016-09-19 06:04:24 --> Loader Class Initialized
INFO - 2016-09-19 06:04:24 --> Helper loaded: url_helper
INFO - 2016-09-19 06:04:24 --> Database Driver Class Initialized
INFO - 2016-09-19 06:04:24 --> Controller Class Initialized
DEBUG - 2016-09-19 06:04:24 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:04:24 --> Model Class Initialized
INFO - 2016-09-19 06:04:24 --> Model Class Initialized
DEBUG - 2016-09-19 06:04:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 06:04:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 06:04:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 06:04:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/jurnal_umum.php
DEBUG - 2016-09-19 06:04:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 06:04:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 06:04:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 06:04:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 06:04:24 --> Final output sent to browser
DEBUG - 2016-09-19 06:04:24 --> Total execution time: 0.6989
INFO - 2016-09-19 06:04:30 --> Config Class Initialized
INFO - 2016-09-19 06:04:30 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:04:30 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:04:30 --> Utf8 Class Initialized
INFO - 2016-09-19 06:04:30 --> URI Class Initialized
INFO - 2016-09-19 06:04:30 --> Router Class Initialized
INFO - 2016-09-19 06:04:30 --> Output Class Initialized
INFO - 2016-09-19 06:04:30 --> Security Class Initialized
DEBUG - 2016-09-19 06:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:04:30 --> Input Class Initialized
INFO - 2016-09-19 06:04:30 --> Language Class Initialized
INFO - 2016-09-19 06:04:30 --> Language Class Initialized
INFO - 2016-09-19 06:04:30 --> Config Class Initialized
INFO - 2016-09-19 06:04:30 --> Loader Class Initialized
INFO - 2016-09-19 06:04:30 --> Helper loaded: url_helper
INFO - 2016-09-19 06:04:30 --> Database Driver Class Initialized
INFO - 2016-09-19 06:04:30 --> Controller Class Initialized
DEBUG - 2016-09-19 06:04:30 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:04:30 --> Model Class Initialized
INFO - 2016-09-19 06:04:30 --> Model Class Initialized
DEBUG - 2016-09-19 06:04:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_jurnal_umum.php
INFO - 2016-09-19 06:04:30 --> Final output sent to browser
DEBUG - 2016-09-19 06:04:30 --> Total execution time: 0.5058
INFO - 2016-09-19 06:04:51 --> Config Class Initialized
INFO - 2016-09-19 06:04:51 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:04:51 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:04:51 --> Utf8 Class Initialized
INFO - 2016-09-19 06:04:51 --> URI Class Initialized
INFO - 2016-09-19 06:04:51 --> Router Class Initialized
INFO - 2016-09-19 06:04:51 --> Output Class Initialized
INFO - 2016-09-19 06:04:51 --> Security Class Initialized
DEBUG - 2016-09-19 06:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:04:51 --> Input Class Initialized
INFO - 2016-09-19 06:04:51 --> Language Class Initialized
INFO - 2016-09-19 06:04:51 --> Language Class Initialized
INFO - 2016-09-19 06:04:51 --> Config Class Initialized
INFO - 2016-09-19 06:04:51 --> Loader Class Initialized
INFO - 2016-09-19 06:04:51 --> Helper loaded: url_helper
INFO - 2016-09-19 06:04:51 --> Database Driver Class Initialized
INFO - 2016-09-19 06:04:51 --> Controller Class Initialized
DEBUG - 2016-09-19 06:04:51 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:04:51 --> Model Class Initialized
INFO - 2016-09-19 06:04:51 --> Model Class Initialized
DEBUG - 2016-09-19 06:04:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 06:04:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 06:04:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 06:04:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/buku_besar.php
DEBUG - 2016-09-19 06:04:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 06:04:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 06:04:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 06:04:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 06:04:51 --> Final output sent to browser
DEBUG - 2016-09-19 06:04:51 --> Total execution time: 0.6680
INFO - 2016-09-19 06:05:00 --> Config Class Initialized
INFO - 2016-09-19 06:05:00 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:05:00 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:05:01 --> Utf8 Class Initialized
INFO - 2016-09-19 06:05:01 --> URI Class Initialized
INFO - 2016-09-19 06:05:01 --> Router Class Initialized
INFO - 2016-09-19 06:05:01 --> Output Class Initialized
INFO - 2016-09-19 06:05:01 --> Security Class Initialized
DEBUG - 2016-09-19 06:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:05:01 --> Input Class Initialized
INFO - 2016-09-19 06:05:01 --> Language Class Initialized
INFO - 2016-09-19 06:05:01 --> Language Class Initialized
INFO - 2016-09-19 06:05:01 --> Config Class Initialized
INFO - 2016-09-19 06:05:01 --> Loader Class Initialized
INFO - 2016-09-19 06:05:01 --> Helper loaded: url_helper
INFO - 2016-09-19 06:05:01 --> Database Driver Class Initialized
INFO - 2016-09-19 06:05:01 --> Controller Class Initialized
DEBUG - 2016-09-19 06:05:01 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:05:01 --> Model Class Initialized
INFO - 2016-09-19 06:05:01 --> Model Class Initialized
DEBUG - 2016-09-19 06:05:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_buku_besar.php
INFO - 2016-09-19 06:05:01 --> Final output sent to browser
DEBUG - 2016-09-19 06:05:01 --> Total execution time: 0.5225
INFO - 2016-09-19 06:05:12 --> Config Class Initialized
INFO - 2016-09-19 06:05:12 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:05:12 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:05:12 --> Utf8 Class Initialized
INFO - 2016-09-19 06:05:12 --> URI Class Initialized
INFO - 2016-09-19 06:05:12 --> Router Class Initialized
INFO - 2016-09-19 06:05:12 --> Output Class Initialized
INFO - 2016-09-19 06:05:12 --> Security Class Initialized
DEBUG - 2016-09-19 06:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:05:12 --> Input Class Initialized
INFO - 2016-09-19 06:05:12 --> Language Class Initialized
INFO - 2016-09-19 06:05:12 --> Language Class Initialized
INFO - 2016-09-19 06:05:12 --> Config Class Initialized
INFO - 2016-09-19 06:05:12 --> Loader Class Initialized
INFO - 2016-09-19 06:05:12 --> Helper loaded: url_helper
INFO - 2016-09-19 06:05:12 --> Database Driver Class Initialized
INFO - 2016-09-19 06:05:12 --> Controller Class Initialized
DEBUG - 2016-09-19 06:05:12 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:05:12 --> Model Class Initialized
INFO - 2016-09-19 06:05:12 --> Model Class Initialized
DEBUG - 2016-09-19 06:05:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_buku_besar.php
INFO - 2016-09-19 06:05:12 --> Final output sent to browser
DEBUG - 2016-09-19 06:05:12 --> Total execution time: 0.5199
INFO - 2016-09-19 06:05:22 --> Config Class Initialized
INFO - 2016-09-19 06:05:22 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:05:22 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:05:22 --> Utf8 Class Initialized
INFO - 2016-09-19 06:05:22 --> URI Class Initialized
INFO - 2016-09-19 06:05:22 --> Router Class Initialized
INFO - 2016-09-19 06:05:22 --> Output Class Initialized
INFO - 2016-09-19 06:05:22 --> Security Class Initialized
DEBUG - 2016-09-19 06:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:05:22 --> Input Class Initialized
INFO - 2016-09-19 06:05:22 --> Language Class Initialized
INFO - 2016-09-19 06:05:22 --> Language Class Initialized
INFO - 2016-09-19 06:05:22 --> Config Class Initialized
INFO - 2016-09-19 06:05:22 --> Loader Class Initialized
INFO - 2016-09-19 06:05:22 --> Helper loaded: url_helper
INFO - 2016-09-19 06:05:22 --> Database Driver Class Initialized
INFO - 2016-09-19 06:05:22 --> Controller Class Initialized
DEBUG - 2016-09-19 06:05:22 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:05:22 --> Model Class Initialized
INFO - 2016-09-19 06:05:22 --> Model Class Initialized
DEBUG - 2016-09-19 06:05:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_buku_besar.php
INFO - 2016-09-19 06:05:22 --> Final output sent to browser
DEBUG - 2016-09-19 06:05:22 --> Total execution time: 0.4941
INFO - 2016-09-19 06:05:31 --> Config Class Initialized
INFO - 2016-09-19 06:05:31 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:05:32 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:05:32 --> Utf8 Class Initialized
INFO - 2016-09-19 06:05:32 --> URI Class Initialized
INFO - 2016-09-19 06:05:32 --> Router Class Initialized
INFO - 2016-09-19 06:05:32 --> Output Class Initialized
INFO - 2016-09-19 06:05:32 --> Security Class Initialized
DEBUG - 2016-09-19 06:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:05:32 --> Input Class Initialized
INFO - 2016-09-19 06:05:32 --> Language Class Initialized
INFO - 2016-09-19 06:05:32 --> Language Class Initialized
INFO - 2016-09-19 06:05:32 --> Config Class Initialized
INFO - 2016-09-19 06:05:32 --> Loader Class Initialized
INFO - 2016-09-19 06:05:32 --> Helper loaded: url_helper
INFO - 2016-09-19 06:05:32 --> Database Driver Class Initialized
INFO - 2016-09-19 06:05:32 --> Controller Class Initialized
DEBUG - 2016-09-19 06:05:32 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:05:32 --> Model Class Initialized
INFO - 2016-09-19 06:05:32 --> Model Class Initialized
DEBUG - 2016-09-19 06:05:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_buku_besar.php
INFO - 2016-09-19 06:05:32 --> Final output sent to browser
DEBUG - 2016-09-19 06:05:32 --> Total execution time: 0.5292
INFO - 2016-09-19 06:05:42 --> Config Class Initialized
INFO - 2016-09-19 06:05:42 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:05:42 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:05:42 --> Utf8 Class Initialized
INFO - 2016-09-19 06:05:42 --> URI Class Initialized
INFO - 2016-09-19 06:05:42 --> Router Class Initialized
INFO - 2016-09-19 06:05:42 --> Output Class Initialized
INFO - 2016-09-19 06:05:42 --> Security Class Initialized
DEBUG - 2016-09-19 06:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:05:42 --> Input Class Initialized
INFO - 2016-09-19 06:05:42 --> Language Class Initialized
INFO - 2016-09-19 06:05:42 --> Language Class Initialized
INFO - 2016-09-19 06:05:42 --> Config Class Initialized
INFO - 2016-09-19 06:05:42 --> Loader Class Initialized
INFO - 2016-09-19 06:05:42 --> Helper loaded: url_helper
INFO - 2016-09-19 06:05:42 --> Database Driver Class Initialized
INFO - 2016-09-19 06:05:42 --> Controller Class Initialized
DEBUG - 2016-09-19 06:05:42 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:05:42 --> Model Class Initialized
INFO - 2016-09-19 06:05:42 --> Model Class Initialized
DEBUG - 2016-09-19 06:05:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_buku_besar.php
INFO - 2016-09-19 06:05:42 --> Final output sent to browser
DEBUG - 2016-09-19 06:05:43 --> Total execution time: 0.5630
INFO - 2016-09-19 06:05:47 --> Config Class Initialized
INFO - 2016-09-19 06:05:47 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:05:47 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:05:47 --> Utf8 Class Initialized
INFO - 2016-09-19 06:05:47 --> URI Class Initialized
INFO - 2016-09-19 06:05:47 --> Router Class Initialized
INFO - 2016-09-19 06:05:47 --> Output Class Initialized
INFO - 2016-09-19 06:05:47 --> Security Class Initialized
DEBUG - 2016-09-19 06:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:05:47 --> Input Class Initialized
INFO - 2016-09-19 06:05:47 --> Language Class Initialized
INFO - 2016-09-19 06:05:47 --> Language Class Initialized
INFO - 2016-09-19 06:05:47 --> Config Class Initialized
INFO - 2016-09-19 06:05:47 --> Loader Class Initialized
INFO - 2016-09-19 06:05:47 --> Helper loaded: url_helper
INFO - 2016-09-19 06:05:47 --> Database Driver Class Initialized
INFO - 2016-09-19 06:05:47 --> Controller Class Initialized
DEBUG - 2016-09-19 06:05:47 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:05:47 --> Model Class Initialized
INFO - 2016-09-19 06:05:48 --> Model Class Initialized
DEBUG - 2016-09-19 06:05:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_buku_besar.php
INFO - 2016-09-19 06:05:48 --> Final output sent to browser
DEBUG - 2016-09-19 06:05:48 --> Total execution time: 0.5069
INFO - 2016-09-19 06:06:11 --> Config Class Initialized
INFO - 2016-09-19 06:06:11 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:06:11 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:06:11 --> Utf8 Class Initialized
INFO - 2016-09-19 06:06:11 --> URI Class Initialized
INFO - 2016-09-19 06:06:11 --> Router Class Initialized
INFO - 2016-09-19 06:06:11 --> Output Class Initialized
INFO - 2016-09-19 06:06:11 --> Security Class Initialized
DEBUG - 2016-09-19 06:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:06:12 --> Input Class Initialized
INFO - 2016-09-19 06:06:12 --> Language Class Initialized
INFO - 2016-09-19 06:06:12 --> Language Class Initialized
INFO - 2016-09-19 06:06:12 --> Config Class Initialized
INFO - 2016-09-19 06:06:12 --> Loader Class Initialized
INFO - 2016-09-19 06:06:12 --> Helper loaded: url_helper
INFO - 2016-09-19 06:06:12 --> Database Driver Class Initialized
INFO - 2016-09-19 06:06:12 --> Controller Class Initialized
DEBUG - 2016-09-19 06:06:12 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:06:12 --> Model Class Initialized
INFO - 2016-09-19 06:06:12 --> Model Class Initialized
ERROR - 2016-09-19 06:06:12 --> Severity: Notice --> Undefined variable: saldoDebit E:\SERVER\htdocs\koperasiweda\application\views\main_html\content\laporan\data_buku_besar.php 38
ERROR - 2016-09-19 06:06:12 --> Severity: Notice --> Undefined variable: saldoKredit E:\SERVER\htdocs\koperasiweda\application\views\main_html\content\laporan\data_buku_besar.php 39
DEBUG - 2016-09-19 06:06:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_buku_besar.php
INFO - 2016-09-19 06:06:12 --> Final output sent to browser
DEBUG - 2016-09-19 06:06:12 --> Total execution time: 0.6465
INFO - 2016-09-19 06:07:18 --> Config Class Initialized
INFO - 2016-09-19 06:07:18 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:07:18 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:07:18 --> Utf8 Class Initialized
INFO - 2016-09-19 06:07:18 --> URI Class Initialized
INFO - 2016-09-19 06:07:18 --> Router Class Initialized
INFO - 2016-09-19 06:07:18 --> Output Class Initialized
INFO - 2016-09-19 06:07:18 --> Security Class Initialized
DEBUG - 2016-09-19 06:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:07:18 --> Input Class Initialized
INFO - 2016-09-19 06:07:18 --> Language Class Initialized
INFO - 2016-09-19 06:07:18 --> Language Class Initialized
INFO - 2016-09-19 06:07:18 --> Config Class Initialized
INFO - 2016-09-19 06:07:18 --> Loader Class Initialized
INFO - 2016-09-19 06:07:18 --> Helper loaded: url_helper
INFO - 2016-09-19 06:07:18 --> Database Driver Class Initialized
INFO - 2016-09-19 06:07:18 --> Controller Class Initialized
DEBUG - 2016-09-19 06:07:18 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:07:18 --> Model Class Initialized
INFO - 2016-09-19 06:07:18 --> Model Class Initialized
ERROR - 2016-09-19 06:07:18 --> Severity: Notice --> Undefined variable: saldoDebit E:\SERVER\htdocs\koperasiweda\application\views\main_html\content\laporan\data_buku_besar.php 38
ERROR - 2016-09-19 06:07:18 --> Severity: Notice --> Undefined variable: saldoKredit E:\SERVER\htdocs\koperasiweda\application\views\main_html\content\laporan\data_buku_besar.php 39
DEBUG - 2016-09-19 06:07:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_buku_besar.php
INFO - 2016-09-19 06:07:18 --> Final output sent to browser
DEBUG - 2016-09-19 06:07:18 --> Total execution time: 0.5748
INFO - 2016-09-19 06:07:21 --> Config Class Initialized
INFO - 2016-09-19 06:07:21 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:07:21 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:07:21 --> Utf8 Class Initialized
INFO - 2016-09-19 06:07:21 --> URI Class Initialized
INFO - 2016-09-19 06:07:21 --> Router Class Initialized
INFO - 2016-09-19 06:07:21 --> Output Class Initialized
INFO - 2016-09-19 06:07:21 --> Security Class Initialized
DEBUG - 2016-09-19 06:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:07:21 --> Input Class Initialized
INFO - 2016-09-19 06:07:21 --> Language Class Initialized
INFO - 2016-09-19 06:07:21 --> Language Class Initialized
INFO - 2016-09-19 06:07:21 --> Config Class Initialized
INFO - 2016-09-19 06:07:21 --> Loader Class Initialized
INFO - 2016-09-19 06:07:21 --> Helper loaded: url_helper
INFO - 2016-09-19 06:07:21 --> Database Driver Class Initialized
INFO - 2016-09-19 06:07:21 --> Controller Class Initialized
DEBUG - 2016-09-19 06:07:21 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:07:21 --> Model Class Initialized
INFO - 2016-09-19 06:07:21 --> Model Class Initialized
DEBUG - 2016-09-19 06:07:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 06:07:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 06:07:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 06:07:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_biaya.php
DEBUG - 2016-09-19 06:07:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 06:07:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 06:07:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 06:07:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 06:07:22 --> Final output sent to browser
DEBUG - 2016-09-19 06:07:22 --> Total execution time: 0.7872
INFO - 2016-09-19 06:07:28 --> Config Class Initialized
INFO - 2016-09-19 06:07:28 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:07:28 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:07:28 --> Utf8 Class Initialized
INFO - 2016-09-19 06:07:28 --> URI Class Initialized
INFO - 2016-09-19 06:07:28 --> Router Class Initialized
INFO - 2016-09-19 06:07:28 --> Output Class Initialized
INFO - 2016-09-19 06:07:28 --> Security Class Initialized
DEBUG - 2016-09-19 06:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:07:29 --> Input Class Initialized
INFO - 2016-09-19 06:07:29 --> Language Class Initialized
INFO - 2016-09-19 06:07:29 --> Language Class Initialized
INFO - 2016-09-19 06:07:29 --> Config Class Initialized
INFO - 2016-09-19 06:07:29 --> Loader Class Initialized
INFO - 2016-09-19 06:07:29 --> Helper loaded: url_helper
INFO - 2016-09-19 06:07:29 --> Database Driver Class Initialized
INFO - 2016-09-19 06:07:29 --> Controller Class Initialized
DEBUG - 2016-09-19 06:07:29 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:07:29 --> Model Class Initialized
INFO - 2016-09-19 06:07:29 --> Model Class Initialized
DEBUG - 2016-09-19 06:07:29 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-19 06:07:29 --> Users MX_Controller Initialized
INFO - 2016-09-19 06:07:29 --> Final output sent to browser
DEBUG - 2016-09-19 06:07:29 --> Total execution time: 0.9057
INFO - 2016-09-19 06:07:31 --> Config Class Initialized
INFO - 2016-09-19 06:07:31 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:07:31 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:07:31 --> Utf8 Class Initialized
INFO - 2016-09-19 06:07:31 --> URI Class Initialized
INFO - 2016-09-19 06:07:31 --> Router Class Initialized
INFO - 2016-09-19 06:07:31 --> Output Class Initialized
INFO - 2016-09-19 06:07:31 --> Security Class Initialized
DEBUG - 2016-09-19 06:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:07:31 --> Input Class Initialized
INFO - 2016-09-19 06:07:31 --> Language Class Initialized
INFO - 2016-09-19 06:07:31 --> Language Class Initialized
INFO - 2016-09-19 06:07:31 --> Config Class Initialized
INFO - 2016-09-19 06:07:31 --> Loader Class Initialized
INFO - 2016-09-19 06:07:31 --> Helper loaded: url_helper
INFO - 2016-09-19 06:07:31 --> Database Driver Class Initialized
INFO - 2016-09-19 06:07:31 --> Controller Class Initialized
DEBUG - 2016-09-19 06:07:32 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:07:32 --> Model Class Initialized
INFO - 2016-09-19 06:07:32 --> Model Class Initialized
DEBUG - 2016-09-19 06:07:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 06:07:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 06:07:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 06:07:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_biaya.php
DEBUG - 2016-09-19 06:07:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 06:07:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 06:07:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 06:07:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 06:07:32 --> Final output sent to browser
DEBUG - 2016-09-19 06:07:32 --> Total execution time: 0.7264
INFO - 2016-09-19 06:07:36 --> Config Class Initialized
INFO - 2016-09-19 06:07:36 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:07:36 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:07:36 --> Utf8 Class Initialized
INFO - 2016-09-19 06:07:36 --> URI Class Initialized
INFO - 2016-09-19 06:07:36 --> Router Class Initialized
INFO - 2016-09-19 06:07:36 --> Output Class Initialized
INFO - 2016-09-19 06:07:36 --> Security Class Initialized
DEBUG - 2016-09-19 06:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:07:36 --> Input Class Initialized
INFO - 2016-09-19 06:07:37 --> Language Class Initialized
INFO - 2016-09-19 06:07:37 --> Language Class Initialized
INFO - 2016-09-19 06:07:37 --> Config Class Initialized
INFO - 2016-09-19 06:07:37 --> Loader Class Initialized
INFO - 2016-09-19 06:07:37 --> Helper loaded: url_helper
INFO - 2016-09-19 06:07:37 --> Database Driver Class Initialized
INFO - 2016-09-19 06:07:37 --> Controller Class Initialized
DEBUG - 2016-09-19 06:07:37 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:07:37 --> Model Class Initialized
INFO - 2016-09-19 06:07:37 --> Model Class Initialized
INFO - 2016-09-19 06:07:37 --> Database Driver Class Initialized
INFO - 2016-09-19 06:07:37 --> Database Driver Class Initialized
INFO - 2016-09-19 06:07:37 --> Database Driver Class Initialized
INFO - 2016-09-19 06:07:37 --> Database Driver Class Initialized
INFO - 2016-09-19 06:07:37 --> Database Driver Class Initialized
INFO - 2016-09-19 06:07:37 --> Database Driver Class Initialized
INFO - 2016-09-19 06:07:37 --> Database Driver Class Initialized
INFO - 2016-09-19 06:07:37 --> Database Driver Class Initialized
INFO - 2016-09-19 06:07:37 --> Database Driver Class Initialized
INFO - 2016-09-19 06:07:37 --> Database Driver Class Initialized
INFO - 2016-09-19 06:07:38 --> Final output sent to browser
DEBUG - 2016-09-19 06:07:38 --> Total execution time: 1.3281
INFO - 2016-09-19 06:07:42 --> Config Class Initialized
INFO - 2016-09-19 06:07:42 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:07:42 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:07:42 --> Utf8 Class Initialized
INFO - 2016-09-19 06:07:42 --> URI Class Initialized
INFO - 2016-09-19 06:07:42 --> Router Class Initialized
INFO - 2016-09-19 06:07:42 --> Output Class Initialized
INFO - 2016-09-19 06:07:42 --> Security Class Initialized
DEBUG - 2016-09-19 06:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:07:42 --> Input Class Initialized
INFO - 2016-09-19 06:07:42 --> Language Class Initialized
INFO - 2016-09-19 06:07:42 --> Language Class Initialized
INFO - 2016-09-19 06:07:42 --> Config Class Initialized
INFO - 2016-09-19 06:07:42 --> Loader Class Initialized
INFO - 2016-09-19 06:07:42 --> Helper loaded: url_helper
INFO - 2016-09-19 06:07:42 --> Database Driver Class Initialized
INFO - 2016-09-19 06:07:42 --> Controller Class Initialized
DEBUG - 2016-09-19 06:07:42 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:07:42 --> Model Class Initialized
INFO - 2016-09-19 06:07:42 --> Model Class Initialized
DEBUG - 2016-09-19 06:07:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 06:07:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 06:07:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 06:07:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/buku_besar.php
DEBUG - 2016-09-19 06:07:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 06:07:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 06:07:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 06:07:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 06:07:43 --> Final output sent to browser
DEBUG - 2016-09-19 06:07:43 --> Total execution time: 0.7569
INFO - 2016-09-19 06:07:53 --> Config Class Initialized
INFO - 2016-09-19 06:07:53 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:07:53 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:07:53 --> Utf8 Class Initialized
INFO - 2016-09-19 06:07:53 --> URI Class Initialized
INFO - 2016-09-19 06:07:53 --> Router Class Initialized
INFO - 2016-09-19 06:07:53 --> Output Class Initialized
INFO - 2016-09-19 06:07:53 --> Security Class Initialized
DEBUG - 2016-09-19 06:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:07:53 --> Input Class Initialized
INFO - 2016-09-19 06:07:53 --> Language Class Initialized
INFO - 2016-09-19 06:07:53 --> Language Class Initialized
INFO - 2016-09-19 06:07:53 --> Config Class Initialized
INFO - 2016-09-19 06:07:53 --> Loader Class Initialized
INFO - 2016-09-19 06:07:53 --> Helper loaded: url_helper
INFO - 2016-09-19 06:07:53 --> Database Driver Class Initialized
INFO - 2016-09-19 06:07:53 --> Controller Class Initialized
DEBUG - 2016-09-19 06:07:53 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:07:54 --> Model Class Initialized
INFO - 2016-09-19 06:07:54 --> Model Class Initialized
DEBUG - 2016-09-19 06:07:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_buku_besar.php
INFO - 2016-09-19 06:07:54 --> Final output sent to browser
DEBUG - 2016-09-19 06:07:54 --> Total execution time: 0.5097
INFO - 2016-09-19 06:08:24 --> Config Class Initialized
INFO - 2016-09-19 06:08:24 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:08:24 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:08:24 --> Utf8 Class Initialized
INFO - 2016-09-19 06:08:24 --> URI Class Initialized
INFO - 2016-09-19 06:08:24 --> Router Class Initialized
INFO - 2016-09-19 06:08:24 --> Output Class Initialized
INFO - 2016-09-19 06:08:24 --> Security Class Initialized
DEBUG - 2016-09-19 06:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:08:24 --> Input Class Initialized
INFO - 2016-09-19 06:08:24 --> Language Class Initialized
INFO - 2016-09-19 06:08:24 --> Language Class Initialized
INFO - 2016-09-19 06:08:24 --> Config Class Initialized
INFO - 2016-09-19 06:08:24 --> Loader Class Initialized
INFO - 2016-09-19 06:08:24 --> Helper loaded: url_helper
INFO - 2016-09-19 06:08:24 --> Database Driver Class Initialized
INFO - 2016-09-19 06:08:24 --> Controller Class Initialized
DEBUG - 2016-09-19 06:08:24 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:08:24 --> Model Class Initialized
INFO - 2016-09-19 06:08:24 --> Model Class Initialized
DEBUG - 2016-09-19 06:08:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 06:08:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 06:08:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 06:08:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_peminjam.php
DEBUG - 2016-09-19 06:08:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 06:08:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 06:08:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 06:08:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 06:08:25 --> Final output sent to browser
DEBUG - 2016-09-19 06:08:25 --> Total execution time: 0.7456
INFO - 2016-09-19 06:08:28 --> Config Class Initialized
INFO - 2016-09-19 06:08:28 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:08:28 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:08:28 --> Utf8 Class Initialized
INFO - 2016-09-19 06:08:28 --> URI Class Initialized
INFO - 2016-09-19 06:08:28 --> Router Class Initialized
INFO - 2016-09-19 06:08:28 --> Output Class Initialized
INFO - 2016-09-19 06:08:28 --> Security Class Initialized
DEBUG - 2016-09-19 06:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:08:28 --> Input Class Initialized
INFO - 2016-09-19 06:08:28 --> Language Class Initialized
INFO - 2016-09-19 06:08:28 --> Language Class Initialized
INFO - 2016-09-19 06:08:28 --> Config Class Initialized
INFO - 2016-09-19 06:08:28 --> Loader Class Initialized
INFO - 2016-09-19 06:08:28 --> Helper loaded: url_helper
INFO - 2016-09-19 06:08:28 --> Database Driver Class Initialized
INFO - 2016-09-19 06:08:28 --> Controller Class Initialized
DEBUG - 2016-09-19 06:08:28 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:08:28 --> Model Class Initialized
INFO - 2016-09-19 06:08:28 --> Model Class Initialized
DEBUG - 2016-09-19 06:08:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 06:08:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 06:08:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 06:08:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 06:08:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 06:08:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 06:08:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 06:08:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 06:08:28 --> Final output sent to browser
DEBUG - 2016-09-19 06:08:28 --> Total execution time: 0.7275
INFO - 2016-09-19 06:12:10 --> Config Class Initialized
INFO - 2016-09-19 06:12:10 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:12:10 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:12:10 --> Utf8 Class Initialized
INFO - 2016-09-19 06:12:11 --> URI Class Initialized
INFO - 2016-09-19 06:12:11 --> Router Class Initialized
INFO - 2016-09-19 06:12:11 --> Output Class Initialized
INFO - 2016-09-19 06:12:11 --> Security Class Initialized
DEBUG - 2016-09-19 06:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:12:11 --> Input Class Initialized
INFO - 2016-09-19 06:12:11 --> Language Class Initialized
INFO - 2016-09-19 06:12:11 --> Language Class Initialized
INFO - 2016-09-19 06:12:11 --> Config Class Initialized
INFO - 2016-09-19 06:12:11 --> Loader Class Initialized
INFO - 2016-09-19 06:12:11 --> Helper loaded: url_helper
INFO - 2016-09-19 06:12:11 --> Database Driver Class Initialized
INFO - 2016-09-19 06:12:11 --> Controller Class Initialized
DEBUG - 2016-09-19 06:12:11 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:12:11 --> Model Class Initialized
INFO - 2016-09-19 06:12:11 --> Model Class Initialized
DEBUG - 2016-09-19 06:12:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 06:12:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 06:12:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 06:12:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 06:12:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 06:12:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 06:12:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 06:12:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 06:12:11 --> Final output sent to browser
DEBUG - 2016-09-19 06:12:11 --> Total execution time: 0.7144
INFO - 2016-09-19 06:15:10 --> Config Class Initialized
INFO - 2016-09-19 06:15:11 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:15:11 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:15:11 --> Utf8 Class Initialized
INFO - 2016-09-19 06:15:11 --> URI Class Initialized
INFO - 2016-09-19 06:15:11 --> Router Class Initialized
INFO - 2016-09-19 06:15:11 --> Output Class Initialized
INFO - 2016-09-19 06:15:11 --> Security Class Initialized
DEBUG - 2016-09-19 06:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:15:11 --> Input Class Initialized
INFO - 2016-09-19 06:15:11 --> Language Class Initialized
INFO - 2016-09-19 06:15:11 --> Language Class Initialized
INFO - 2016-09-19 06:15:11 --> Config Class Initialized
INFO - 2016-09-19 06:15:11 --> Loader Class Initialized
INFO - 2016-09-19 06:15:11 --> Helper loaded: url_helper
INFO - 2016-09-19 06:15:11 --> Database Driver Class Initialized
INFO - 2016-09-19 06:15:11 --> Controller Class Initialized
DEBUG - 2016-09-19 06:15:11 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:15:11 --> Model Class Initialized
INFO - 2016-09-19 06:15:11 --> Model Class Initialized
DEBUG - 2016-09-19 06:15:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 06:15:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 06:15:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 06:15:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 06:15:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 06:15:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 06:15:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 06:15:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 06:15:11 --> Final output sent to browser
DEBUG - 2016-09-19 06:15:11 --> Total execution time: 0.8670
INFO - 2016-09-19 06:15:16 --> Config Class Initialized
INFO - 2016-09-19 06:15:16 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:15:16 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:15:16 --> Utf8 Class Initialized
INFO - 2016-09-19 06:15:16 --> URI Class Initialized
INFO - 2016-09-19 06:15:16 --> Router Class Initialized
INFO - 2016-09-19 06:15:16 --> Output Class Initialized
INFO - 2016-09-19 06:15:16 --> Security Class Initialized
DEBUG - 2016-09-19 06:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:15:16 --> Input Class Initialized
INFO - 2016-09-19 06:15:16 --> Language Class Initialized
INFO - 2016-09-19 06:15:16 --> Language Class Initialized
INFO - 2016-09-19 06:15:16 --> Config Class Initialized
INFO - 2016-09-19 06:15:16 --> Loader Class Initialized
INFO - 2016-09-19 06:15:16 --> Helper loaded: url_helper
INFO - 2016-09-19 06:15:16 --> Database Driver Class Initialized
INFO - 2016-09-19 06:15:16 --> Controller Class Initialized
DEBUG - 2016-09-19 06:15:17 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:15:17 --> Model Class Initialized
INFO - 2016-09-19 06:15:17 --> Model Class Initialized
DEBUG - 2016-09-19 06:15:17 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:15:17 --> Database Driver Class Initialized
INFO - 2016-09-19 06:15:17 --> Final output sent to browser
DEBUG - 2016-09-19 06:15:17 --> Total execution time: 0.7236
INFO - 2016-09-19 06:15:20 --> Config Class Initialized
INFO - 2016-09-19 06:15:20 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:15:20 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:15:20 --> Utf8 Class Initialized
INFO - 2016-09-19 06:15:20 --> URI Class Initialized
INFO - 2016-09-19 06:15:20 --> Router Class Initialized
INFO - 2016-09-19 06:15:20 --> Output Class Initialized
INFO - 2016-09-19 06:15:20 --> Security Class Initialized
DEBUG - 2016-09-19 06:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:15:20 --> Input Class Initialized
INFO - 2016-09-19 06:15:20 --> Language Class Initialized
INFO - 2016-09-19 06:15:20 --> Language Class Initialized
INFO - 2016-09-19 06:15:20 --> Config Class Initialized
INFO - 2016-09-19 06:15:20 --> Loader Class Initialized
INFO - 2016-09-19 06:15:20 --> Helper loaded: url_helper
INFO - 2016-09-19 06:15:20 --> Database Driver Class Initialized
INFO - 2016-09-19 06:15:20 --> Controller Class Initialized
DEBUG - 2016-09-19 06:15:20 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:15:20 --> Model Class Initialized
INFO - 2016-09-19 06:15:20 --> Model Class Initialized
DEBUG - 2016-09-19 06:15:20 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:15:20 --> Database Driver Class Initialized
INFO - 2016-09-19 06:15:20 --> Final output sent to browser
DEBUG - 2016-09-19 06:15:20 --> Total execution time: 0.7331
INFO - 2016-09-19 06:15:28 --> Config Class Initialized
INFO - 2016-09-19 06:15:28 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:15:28 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:15:28 --> Utf8 Class Initialized
INFO - 2016-09-19 06:15:28 --> URI Class Initialized
INFO - 2016-09-19 06:15:28 --> Router Class Initialized
INFO - 2016-09-19 06:15:28 --> Output Class Initialized
INFO - 2016-09-19 06:15:28 --> Security Class Initialized
DEBUG - 2016-09-19 06:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:15:28 --> Input Class Initialized
INFO - 2016-09-19 06:15:28 --> Language Class Initialized
INFO - 2016-09-19 06:15:28 --> Language Class Initialized
INFO - 2016-09-19 06:15:29 --> Config Class Initialized
INFO - 2016-09-19 06:15:29 --> Loader Class Initialized
INFO - 2016-09-19 06:15:29 --> Helper loaded: url_helper
INFO - 2016-09-19 06:15:29 --> Database Driver Class Initialized
INFO - 2016-09-19 06:15:29 --> Controller Class Initialized
DEBUG - 2016-09-19 06:15:29 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:15:29 --> Model Class Initialized
INFO - 2016-09-19 06:15:29 --> Model Class Initialized
DEBUG - 2016-09-19 06:15:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 06:15:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 06:15:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 06:15:29 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-19 06:15:29 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-19 06:15:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-19 06:15:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 06:15:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 06:15:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 06:15:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 06:15:29 --> Final output sent to browser
DEBUG - 2016-09-19 06:15:29 --> Total execution time: 1.0952
INFO - 2016-09-19 06:16:04 --> Config Class Initialized
INFO - 2016-09-19 06:16:04 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:16:04 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:16:04 --> Utf8 Class Initialized
INFO - 2016-09-19 06:16:04 --> URI Class Initialized
INFO - 2016-09-19 06:16:04 --> Router Class Initialized
INFO - 2016-09-19 06:16:04 --> Output Class Initialized
INFO - 2016-09-19 06:16:04 --> Security Class Initialized
DEBUG - 2016-09-19 06:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:16:04 --> Input Class Initialized
INFO - 2016-09-19 06:16:04 --> Language Class Initialized
INFO - 2016-09-19 06:16:04 --> Language Class Initialized
INFO - 2016-09-19 06:16:04 --> Config Class Initialized
INFO - 2016-09-19 06:16:04 --> Loader Class Initialized
INFO - 2016-09-19 06:16:05 --> Helper loaded: url_helper
INFO - 2016-09-19 06:16:05 --> Database Driver Class Initialized
INFO - 2016-09-19 06:16:05 --> Controller Class Initialized
DEBUG - 2016-09-19 06:16:05 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:16:05 --> Model Class Initialized
INFO - 2016-09-19 06:16:05 --> Model Class Initialized
DEBUG - 2016-09-19 06:16:05 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:16:05 --> Database Driver Class Initialized
INFO - 2016-09-19 06:16:05 --> Final output sent to browser
DEBUG - 2016-09-19 06:16:05 --> Total execution time: 0.6308
INFO - 2016-09-19 06:16:48 --> Config Class Initialized
INFO - 2016-09-19 06:16:48 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:16:48 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:16:48 --> Utf8 Class Initialized
INFO - 2016-09-19 06:16:48 --> URI Class Initialized
INFO - 2016-09-19 06:16:48 --> Router Class Initialized
INFO - 2016-09-19 06:16:48 --> Output Class Initialized
INFO - 2016-09-19 06:16:48 --> Security Class Initialized
DEBUG - 2016-09-19 06:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:16:48 --> Input Class Initialized
INFO - 2016-09-19 06:16:48 --> Language Class Initialized
INFO - 2016-09-19 06:16:49 --> Language Class Initialized
INFO - 2016-09-19 06:16:49 --> Config Class Initialized
INFO - 2016-09-19 06:16:49 --> Loader Class Initialized
INFO - 2016-09-19 06:16:49 --> Helper loaded: url_helper
INFO - 2016-09-19 06:16:49 --> Database Driver Class Initialized
INFO - 2016-09-19 06:16:49 --> Controller Class Initialized
DEBUG - 2016-09-19 06:16:49 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:16:49 --> Model Class Initialized
INFO - 2016-09-19 06:16:49 --> Model Class Initialized
DEBUG - 2016-09-19 06:16:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 06:16:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 06:16:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 06:16:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 06:16:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 06:16:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 06:16:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 06:16:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 06:16:49 --> Final output sent to browser
DEBUG - 2016-09-19 06:16:49 --> Total execution time: 0.7352
INFO - 2016-09-19 06:16:57 --> Config Class Initialized
INFO - 2016-09-19 06:16:57 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:16:57 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:16:57 --> Utf8 Class Initialized
INFO - 2016-09-19 06:16:57 --> URI Class Initialized
INFO - 2016-09-19 06:16:57 --> Router Class Initialized
INFO - 2016-09-19 06:16:57 --> Output Class Initialized
INFO - 2016-09-19 06:16:57 --> Security Class Initialized
DEBUG - 2016-09-19 06:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:16:57 --> Input Class Initialized
INFO - 2016-09-19 06:16:57 --> Language Class Initialized
INFO - 2016-09-19 06:16:57 --> Language Class Initialized
INFO - 2016-09-19 06:16:57 --> Config Class Initialized
INFO - 2016-09-19 06:16:57 --> Loader Class Initialized
INFO - 2016-09-19 06:16:57 --> Helper loaded: url_helper
INFO - 2016-09-19 06:16:57 --> Database Driver Class Initialized
INFO - 2016-09-19 06:16:57 --> Controller Class Initialized
DEBUG - 2016-09-19 06:16:57 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:16:57 --> Model Class Initialized
INFO - 2016-09-19 06:16:57 --> Model Class Initialized
DEBUG - 2016-09-19 06:16:57 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:16:57 --> Database Driver Class Initialized
INFO - 2016-09-19 06:16:57 --> Final output sent to browser
DEBUG - 2016-09-19 06:16:57 --> Total execution time: 0.7256
INFO - 2016-09-19 06:17:02 --> Config Class Initialized
INFO - 2016-09-19 06:17:02 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:17:02 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:17:02 --> Utf8 Class Initialized
INFO - 2016-09-19 06:17:02 --> URI Class Initialized
INFO - 2016-09-19 06:17:02 --> Router Class Initialized
INFO - 2016-09-19 06:17:02 --> Output Class Initialized
INFO - 2016-09-19 06:17:02 --> Security Class Initialized
DEBUG - 2016-09-19 06:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:17:02 --> Input Class Initialized
INFO - 2016-09-19 06:17:02 --> Language Class Initialized
INFO - 2016-09-19 06:17:02 --> Language Class Initialized
INFO - 2016-09-19 06:17:02 --> Config Class Initialized
INFO - 2016-09-19 06:17:02 --> Loader Class Initialized
INFO - 2016-09-19 06:17:02 --> Helper loaded: url_helper
INFO - 2016-09-19 06:17:02 --> Database Driver Class Initialized
INFO - 2016-09-19 06:17:02 --> Controller Class Initialized
DEBUG - 2016-09-19 06:17:02 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:17:02 --> Model Class Initialized
INFO - 2016-09-19 06:17:02 --> Model Class Initialized
DEBUG - 2016-09-19 06:17:02 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:17:02 --> Database Driver Class Initialized
INFO - 2016-09-19 06:17:02 --> Final output sent to browser
DEBUG - 2016-09-19 06:17:02 --> Total execution time: 0.5690
INFO - 2016-09-19 06:17:08 --> Config Class Initialized
INFO - 2016-09-19 06:17:08 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:17:08 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:17:08 --> Utf8 Class Initialized
INFO - 2016-09-19 06:17:08 --> URI Class Initialized
INFO - 2016-09-19 06:17:08 --> Router Class Initialized
INFO - 2016-09-19 06:17:08 --> Output Class Initialized
INFO - 2016-09-19 06:17:08 --> Security Class Initialized
DEBUG - 2016-09-19 06:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:17:08 --> Input Class Initialized
INFO - 2016-09-19 06:17:08 --> Language Class Initialized
INFO - 2016-09-19 06:17:08 --> Language Class Initialized
INFO - 2016-09-19 06:17:08 --> Config Class Initialized
INFO - 2016-09-19 06:17:08 --> Loader Class Initialized
INFO - 2016-09-19 06:17:08 --> Helper loaded: url_helper
INFO - 2016-09-19 06:17:08 --> Database Driver Class Initialized
INFO - 2016-09-19 06:17:08 --> Controller Class Initialized
DEBUG - 2016-09-19 06:17:08 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:17:08 --> Model Class Initialized
INFO - 2016-09-19 06:17:08 --> Model Class Initialized
DEBUG - 2016-09-19 06:17:08 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:17:09 --> Database Driver Class Initialized
INFO - 2016-09-19 06:17:09 --> Final output sent to browser
DEBUG - 2016-09-19 06:17:09 --> Total execution time: 0.5917
INFO - 2016-09-19 06:17:40 --> Config Class Initialized
INFO - 2016-09-19 06:17:40 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:17:40 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:17:41 --> Utf8 Class Initialized
INFO - 2016-09-19 06:17:41 --> URI Class Initialized
INFO - 2016-09-19 06:17:41 --> Router Class Initialized
INFO - 2016-09-19 06:17:41 --> Output Class Initialized
INFO - 2016-09-19 06:17:41 --> Security Class Initialized
DEBUG - 2016-09-19 06:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:17:41 --> Input Class Initialized
INFO - 2016-09-19 06:17:41 --> Language Class Initialized
INFO - 2016-09-19 06:17:41 --> Language Class Initialized
INFO - 2016-09-19 06:17:41 --> Config Class Initialized
INFO - 2016-09-19 06:17:41 --> Loader Class Initialized
INFO - 2016-09-19 06:17:41 --> Helper loaded: url_helper
INFO - 2016-09-19 06:17:41 --> Database Driver Class Initialized
INFO - 2016-09-19 06:17:41 --> Controller Class Initialized
DEBUG - 2016-09-19 06:17:41 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:17:41 --> Model Class Initialized
INFO - 2016-09-19 06:17:41 --> Model Class Initialized
DEBUG - 2016-09-19 06:17:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 06:17:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 06:17:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 06:17:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 06:17:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 06:17:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 06:17:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 06:17:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 06:17:41 --> Final output sent to browser
DEBUG - 2016-09-19 06:17:42 --> Total execution time: 1.2086
INFO - 2016-09-19 06:17:49 --> Config Class Initialized
INFO - 2016-09-19 06:17:49 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:17:49 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:17:50 --> Utf8 Class Initialized
INFO - 2016-09-19 06:17:50 --> URI Class Initialized
INFO - 2016-09-19 06:17:50 --> Router Class Initialized
INFO - 2016-09-19 06:17:50 --> Output Class Initialized
INFO - 2016-09-19 06:17:50 --> Security Class Initialized
DEBUG - 2016-09-19 06:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:17:50 --> Input Class Initialized
INFO - 2016-09-19 06:17:50 --> Language Class Initialized
INFO - 2016-09-19 06:17:50 --> Language Class Initialized
INFO - 2016-09-19 06:17:50 --> Config Class Initialized
INFO - 2016-09-19 06:17:50 --> Loader Class Initialized
INFO - 2016-09-19 06:17:50 --> Helper loaded: url_helper
INFO - 2016-09-19 06:17:50 --> Database Driver Class Initialized
INFO - 2016-09-19 06:17:50 --> Controller Class Initialized
DEBUG - 2016-09-19 06:17:50 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:17:50 --> Model Class Initialized
INFO - 2016-09-19 06:17:50 --> Model Class Initialized
DEBUG - 2016-09-19 06:17:50 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:17:50 --> Database Driver Class Initialized
INFO - 2016-09-19 06:17:50 --> Final output sent to browser
DEBUG - 2016-09-19 06:17:50 --> Total execution time: 0.5877
INFO - 2016-09-19 06:17:54 --> Config Class Initialized
INFO - 2016-09-19 06:17:54 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:17:54 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:17:54 --> Utf8 Class Initialized
INFO - 2016-09-19 06:17:54 --> URI Class Initialized
INFO - 2016-09-19 06:17:54 --> Router Class Initialized
INFO - 2016-09-19 06:17:54 --> Output Class Initialized
INFO - 2016-09-19 06:17:54 --> Security Class Initialized
DEBUG - 2016-09-19 06:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:17:54 --> Input Class Initialized
INFO - 2016-09-19 06:17:54 --> Language Class Initialized
INFO - 2016-09-19 06:17:54 --> Language Class Initialized
INFO - 2016-09-19 06:17:54 --> Config Class Initialized
INFO - 2016-09-19 06:17:54 --> Loader Class Initialized
INFO - 2016-09-19 06:17:54 --> Helper loaded: url_helper
INFO - 2016-09-19 06:17:54 --> Database Driver Class Initialized
INFO - 2016-09-19 06:17:54 --> Controller Class Initialized
DEBUG - 2016-09-19 06:17:54 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:17:54 --> Model Class Initialized
INFO - 2016-09-19 06:17:54 --> Model Class Initialized
DEBUG - 2016-09-19 06:17:54 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:17:54 --> Database Driver Class Initialized
INFO - 2016-09-19 06:17:54 --> Final output sent to browser
DEBUG - 2016-09-19 06:17:54 --> Total execution time: 0.5788
INFO - 2016-09-19 06:19:11 --> Config Class Initialized
INFO - 2016-09-19 06:19:11 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:19:11 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:19:11 --> Utf8 Class Initialized
INFO - 2016-09-19 06:19:11 --> URI Class Initialized
INFO - 2016-09-19 06:19:11 --> Router Class Initialized
INFO - 2016-09-19 06:19:11 --> Output Class Initialized
INFO - 2016-09-19 06:19:11 --> Security Class Initialized
DEBUG - 2016-09-19 06:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:19:11 --> Input Class Initialized
INFO - 2016-09-19 06:19:11 --> Language Class Initialized
INFO - 2016-09-19 06:19:11 --> Language Class Initialized
INFO - 2016-09-19 06:19:12 --> Config Class Initialized
INFO - 2016-09-19 06:19:12 --> Loader Class Initialized
INFO - 2016-09-19 06:19:12 --> Helper loaded: url_helper
INFO - 2016-09-19 06:19:12 --> Database Driver Class Initialized
INFO - 2016-09-19 06:19:12 --> Controller Class Initialized
DEBUG - 2016-09-19 06:19:12 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:19:12 --> Model Class Initialized
INFO - 2016-09-19 06:19:12 --> Model Class Initialized
DEBUG - 2016-09-19 06:19:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 06:19:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 06:19:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 06:19:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 06:19:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 06:19:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 06:19:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 06:19:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 06:19:12 --> Final output sent to browser
DEBUG - 2016-09-19 06:19:12 --> Total execution time: 0.7253
INFO - 2016-09-19 06:19:16 --> Config Class Initialized
INFO - 2016-09-19 06:19:17 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:19:17 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:19:17 --> Utf8 Class Initialized
INFO - 2016-09-19 06:19:17 --> URI Class Initialized
INFO - 2016-09-19 06:19:17 --> Router Class Initialized
INFO - 2016-09-19 06:19:17 --> Output Class Initialized
INFO - 2016-09-19 06:19:17 --> Security Class Initialized
DEBUG - 2016-09-19 06:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:19:17 --> Input Class Initialized
INFO - 2016-09-19 06:19:17 --> Language Class Initialized
INFO - 2016-09-19 06:19:17 --> Language Class Initialized
INFO - 2016-09-19 06:19:17 --> Config Class Initialized
INFO - 2016-09-19 06:19:17 --> Loader Class Initialized
INFO - 2016-09-19 06:19:17 --> Helper loaded: url_helper
INFO - 2016-09-19 06:19:17 --> Database Driver Class Initialized
INFO - 2016-09-19 06:19:17 --> Controller Class Initialized
DEBUG - 2016-09-19 06:19:17 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:19:17 --> Model Class Initialized
INFO - 2016-09-19 06:19:17 --> Model Class Initialized
DEBUG - 2016-09-19 06:19:17 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:19:17 --> Database Driver Class Initialized
INFO - 2016-09-19 06:19:17 --> Final output sent to browser
DEBUG - 2016-09-19 06:19:17 --> Total execution time: 0.7639
INFO - 2016-09-19 06:19:19 --> Config Class Initialized
INFO - 2016-09-19 06:19:19 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:19:19 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:19:19 --> Utf8 Class Initialized
INFO - 2016-09-19 06:19:19 --> URI Class Initialized
INFO - 2016-09-19 06:19:19 --> Router Class Initialized
INFO - 2016-09-19 06:19:19 --> Output Class Initialized
INFO - 2016-09-19 06:19:19 --> Security Class Initialized
DEBUG - 2016-09-19 06:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:19:19 --> Input Class Initialized
INFO - 2016-09-19 06:19:19 --> Language Class Initialized
INFO - 2016-09-19 06:19:19 --> Language Class Initialized
INFO - 2016-09-19 06:19:19 --> Config Class Initialized
INFO - 2016-09-19 06:19:19 --> Loader Class Initialized
INFO - 2016-09-19 06:19:19 --> Helper loaded: url_helper
INFO - 2016-09-19 06:19:19 --> Database Driver Class Initialized
INFO - 2016-09-19 06:19:19 --> Controller Class Initialized
DEBUG - 2016-09-19 06:19:19 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:19:20 --> Model Class Initialized
INFO - 2016-09-19 06:19:20 --> Model Class Initialized
DEBUG - 2016-09-19 06:19:20 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:19:20 --> Database Driver Class Initialized
INFO - 2016-09-19 06:19:20 --> Final output sent to browser
DEBUG - 2016-09-19 06:19:20 --> Total execution time: 0.6153
INFO - 2016-09-19 06:19:22 --> Config Class Initialized
INFO - 2016-09-19 06:19:22 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:19:22 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:19:22 --> Utf8 Class Initialized
INFO - 2016-09-19 06:19:22 --> URI Class Initialized
INFO - 2016-09-19 06:19:22 --> Router Class Initialized
INFO - 2016-09-19 06:19:22 --> Output Class Initialized
INFO - 2016-09-19 06:19:22 --> Security Class Initialized
DEBUG - 2016-09-19 06:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:19:22 --> Input Class Initialized
INFO - 2016-09-19 06:19:22 --> Language Class Initialized
INFO - 2016-09-19 06:19:22 --> Language Class Initialized
INFO - 2016-09-19 06:19:22 --> Config Class Initialized
INFO - 2016-09-19 06:19:22 --> Loader Class Initialized
INFO - 2016-09-19 06:19:22 --> Helper loaded: url_helper
INFO - 2016-09-19 06:19:22 --> Database Driver Class Initialized
INFO - 2016-09-19 06:19:22 --> Controller Class Initialized
DEBUG - 2016-09-19 06:19:22 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:19:22 --> Model Class Initialized
INFO - 2016-09-19 06:19:22 --> Model Class Initialized
DEBUG - 2016-09-19 06:19:22 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:19:22 --> Database Driver Class Initialized
INFO - 2016-09-19 06:19:22 --> Final output sent to browser
DEBUG - 2016-09-19 06:19:22 --> Total execution time: 0.6655
INFO - 2016-09-19 06:20:30 --> Config Class Initialized
INFO - 2016-09-19 06:20:30 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:20:30 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:20:30 --> Utf8 Class Initialized
INFO - 2016-09-19 06:20:30 --> URI Class Initialized
INFO - 2016-09-19 06:20:30 --> Router Class Initialized
INFO - 2016-09-19 06:20:30 --> Output Class Initialized
INFO - 2016-09-19 06:20:30 --> Security Class Initialized
DEBUG - 2016-09-19 06:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:20:31 --> Input Class Initialized
INFO - 2016-09-19 06:20:31 --> Language Class Initialized
INFO - 2016-09-19 06:20:31 --> Language Class Initialized
INFO - 2016-09-19 06:20:31 --> Config Class Initialized
INFO - 2016-09-19 06:20:31 --> Loader Class Initialized
INFO - 2016-09-19 06:20:31 --> Helper loaded: url_helper
INFO - 2016-09-19 06:20:31 --> Database Driver Class Initialized
INFO - 2016-09-19 06:20:31 --> Controller Class Initialized
DEBUG - 2016-09-19 06:20:31 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:20:31 --> Model Class Initialized
INFO - 2016-09-19 06:20:31 --> Model Class Initialized
DEBUG - 2016-09-19 06:20:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 06:20:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 06:20:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 06:20:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 06:20:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 06:20:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 06:20:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 06:20:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 06:20:31 --> Final output sent to browser
DEBUG - 2016-09-19 06:20:31 --> Total execution time: 0.7655
INFO - 2016-09-19 06:20:36 --> Config Class Initialized
INFO - 2016-09-19 06:20:36 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:20:36 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:20:36 --> Utf8 Class Initialized
INFO - 2016-09-19 06:20:36 --> URI Class Initialized
INFO - 2016-09-19 06:20:36 --> Router Class Initialized
INFO - 2016-09-19 06:20:36 --> Output Class Initialized
INFO - 2016-09-19 06:20:36 --> Security Class Initialized
DEBUG - 2016-09-19 06:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:20:36 --> Input Class Initialized
INFO - 2016-09-19 06:20:36 --> Language Class Initialized
INFO - 2016-09-19 06:20:36 --> Language Class Initialized
INFO - 2016-09-19 06:20:36 --> Config Class Initialized
INFO - 2016-09-19 06:20:36 --> Loader Class Initialized
INFO - 2016-09-19 06:20:36 --> Helper loaded: url_helper
INFO - 2016-09-19 06:20:36 --> Database Driver Class Initialized
INFO - 2016-09-19 06:20:36 --> Controller Class Initialized
DEBUG - 2016-09-19 06:20:36 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:20:36 --> Model Class Initialized
INFO - 2016-09-19 06:20:36 --> Model Class Initialized
DEBUG - 2016-09-19 06:20:36 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:20:36 --> Database Driver Class Initialized
INFO - 2016-09-19 06:20:36 --> Final output sent to browser
DEBUG - 2016-09-19 06:20:36 --> Total execution time: 0.6988
INFO - 2016-09-19 06:20:41 --> Config Class Initialized
INFO - 2016-09-19 06:20:41 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:20:41 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:20:41 --> Utf8 Class Initialized
INFO - 2016-09-19 06:20:41 --> URI Class Initialized
INFO - 2016-09-19 06:20:41 --> Router Class Initialized
INFO - 2016-09-19 06:20:41 --> Output Class Initialized
INFO - 2016-09-19 06:20:41 --> Security Class Initialized
DEBUG - 2016-09-19 06:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:20:41 --> Input Class Initialized
INFO - 2016-09-19 06:20:41 --> Language Class Initialized
INFO - 2016-09-19 06:20:41 --> Language Class Initialized
INFO - 2016-09-19 06:20:41 --> Config Class Initialized
INFO - 2016-09-19 06:20:42 --> Loader Class Initialized
INFO - 2016-09-19 06:20:42 --> Helper loaded: url_helper
INFO - 2016-09-19 06:20:42 --> Database Driver Class Initialized
INFO - 2016-09-19 06:20:42 --> Controller Class Initialized
DEBUG - 2016-09-19 06:20:42 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:20:42 --> Model Class Initialized
INFO - 2016-09-19 06:20:42 --> Model Class Initialized
DEBUG - 2016-09-19 06:20:42 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:20:42 --> Database Driver Class Initialized
INFO - 2016-09-19 06:20:42 --> Final output sent to browser
DEBUG - 2016-09-19 06:20:42 --> Total execution time: 0.8038
INFO - 2016-09-19 06:25:24 --> Config Class Initialized
INFO - 2016-09-19 06:25:24 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:25:24 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:25:24 --> Utf8 Class Initialized
INFO - 2016-09-19 06:25:24 --> URI Class Initialized
INFO - 2016-09-19 06:25:24 --> Router Class Initialized
INFO - 2016-09-19 06:25:24 --> Output Class Initialized
INFO - 2016-09-19 06:25:24 --> Security Class Initialized
DEBUG - 2016-09-19 06:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:25:24 --> Input Class Initialized
INFO - 2016-09-19 06:25:24 --> Language Class Initialized
INFO - 2016-09-19 06:25:24 --> Language Class Initialized
INFO - 2016-09-19 06:25:24 --> Config Class Initialized
INFO - 2016-09-19 06:25:24 --> Loader Class Initialized
INFO - 2016-09-19 06:25:24 --> Helper loaded: url_helper
INFO - 2016-09-19 06:25:24 --> Database Driver Class Initialized
INFO - 2016-09-19 06:25:24 --> Controller Class Initialized
DEBUG - 2016-09-19 06:25:24 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:25:24 --> Model Class Initialized
INFO - 2016-09-19 06:25:24 --> Model Class Initialized
DEBUG - 2016-09-19 06:25:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 06:25:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 06:25:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 06:25:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 06:25:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 06:25:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 06:25:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 06:25:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 06:25:25 --> Final output sent to browser
DEBUG - 2016-09-19 06:25:25 --> Total execution time: 0.7727
INFO - 2016-09-19 06:25:29 --> Config Class Initialized
INFO - 2016-09-19 06:25:29 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:25:29 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:25:30 --> Utf8 Class Initialized
INFO - 2016-09-19 06:25:30 --> URI Class Initialized
INFO - 2016-09-19 06:25:30 --> Router Class Initialized
INFO - 2016-09-19 06:25:30 --> Output Class Initialized
INFO - 2016-09-19 06:25:30 --> Security Class Initialized
DEBUG - 2016-09-19 06:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:25:30 --> Input Class Initialized
INFO - 2016-09-19 06:25:30 --> Language Class Initialized
INFO - 2016-09-19 06:25:30 --> Language Class Initialized
INFO - 2016-09-19 06:25:30 --> Config Class Initialized
INFO - 2016-09-19 06:25:30 --> Loader Class Initialized
INFO - 2016-09-19 06:25:30 --> Helper loaded: url_helper
INFO - 2016-09-19 06:25:30 --> Database Driver Class Initialized
INFO - 2016-09-19 06:25:30 --> Controller Class Initialized
DEBUG - 2016-09-19 06:25:30 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:25:30 --> Model Class Initialized
INFO - 2016-09-19 06:25:30 --> Model Class Initialized
DEBUG - 2016-09-19 06:25:30 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:25:30 --> Database Driver Class Initialized
INFO - 2016-09-19 06:25:30 --> Final output sent to browser
DEBUG - 2016-09-19 06:25:30 --> Total execution time: 1.0341
INFO - 2016-09-19 06:25:32 --> Config Class Initialized
INFO - 2016-09-19 06:25:32 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:25:32 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:25:32 --> Utf8 Class Initialized
INFO - 2016-09-19 06:25:32 --> URI Class Initialized
INFO - 2016-09-19 06:25:32 --> Router Class Initialized
INFO - 2016-09-19 06:25:32 --> Output Class Initialized
INFO - 2016-09-19 06:25:32 --> Security Class Initialized
DEBUG - 2016-09-19 06:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:25:32 --> Input Class Initialized
INFO - 2016-09-19 06:25:32 --> Language Class Initialized
INFO - 2016-09-19 06:25:32 --> Language Class Initialized
INFO - 2016-09-19 06:25:32 --> Config Class Initialized
INFO - 2016-09-19 06:25:32 --> Loader Class Initialized
INFO - 2016-09-19 06:25:32 --> Helper loaded: url_helper
INFO - 2016-09-19 06:25:32 --> Database Driver Class Initialized
INFO - 2016-09-19 06:25:33 --> Controller Class Initialized
DEBUG - 2016-09-19 06:25:33 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:25:33 --> Model Class Initialized
INFO - 2016-09-19 06:25:33 --> Model Class Initialized
INFO - 2016-09-19 06:25:33 --> Config Class Initialized
INFO - 2016-09-19 06:25:33 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:25:33 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-19 06:25:33 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:25:33 --> Utf8 Class Initialized
INFO - 2016-09-19 06:25:33 --> URI Class Initialized
INFO - 2016-09-19 06:25:33 --> Router Class Initialized
INFO - 2016-09-19 06:25:33 --> Database Driver Class Initialized
INFO - 2016-09-19 06:25:33 --> Output Class Initialized
INFO - 2016-09-19 06:25:33 --> Security Class Initialized
INFO - 2016-09-19 06:25:33 --> Final output sent to browser
DEBUG - 2016-09-19 06:25:33 --> Total execution time: 1.0344
DEBUG - 2016-09-19 06:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:25:33 --> Input Class Initialized
INFO - 2016-09-19 06:25:33 --> Language Class Initialized
INFO - 2016-09-19 06:25:33 --> Language Class Initialized
INFO - 2016-09-19 06:25:33 --> Config Class Initialized
INFO - 2016-09-19 06:25:33 --> Loader Class Initialized
INFO - 2016-09-19 06:25:33 --> Helper loaded: url_helper
INFO - 2016-09-19 06:25:33 --> Config Class Initialized
INFO - 2016-09-19 06:25:33 --> Hooks Class Initialized
INFO - 2016-09-19 06:25:33 --> Database Driver Class Initialized
DEBUG - 2016-09-19 06:25:33 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:25:33 --> Utf8 Class Initialized
INFO - 2016-09-19 06:25:33 --> URI Class Initialized
INFO - 2016-09-19 06:25:33 --> Router Class Initialized
INFO - 2016-09-19 06:25:33 --> Controller Class Initialized
DEBUG - 2016-09-19 06:25:34 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:25:34 --> Output Class Initialized
INFO - 2016-09-19 06:25:34 --> Model Class Initialized
INFO - 2016-09-19 06:25:34 --> Model Class Initialized
DEBUG - 2016-09-19 06:25:34 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:25:34 --> Database Driver Class Initialized
INFO - 2016-09-19 06:25:34 --> Security Class Initialized
INFO - 2016-09-19 06:25:34 --> Final output sent to browser
DEBUG - 2016-09-19 06:25:34 --> Total execution time: 1.0603
DEBUG - 2016-09-19 06:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:25:34 --> Input Class Initialized
INFO - 2016-09-19 06:25:34 --> Config Class Initialized
INFO - 2016-09-19 06:25:34 --> Language Class Initialized
INFO - 2016-09-19 06:25:34 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:25:34 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:25:34 --> Utf8 Class Initialized
INFO - 2016-09-19 06:25:34 --> URI Class Initialized
INFO - 2016-09-19 06:25:34 --> Language Class Initialized
INFO - 2016-09-19 06:25:34 --> Config Class Initialized
INFO - 2016-09-19 06:25:34 --> Router Class Initialized
INFO - 2016-09-19 06:25:34 --> Output Class Initialized
INFO - 2016-09-19 06:25:34 --> Loader Class Initialized
INFO - 2016-09-19 06:25:34 --> Security Class Initialized
DEBUG - 2016-09-19 06:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:25:34 --> Input Class Initialized
INFO - 2016-09-19 06:25:34 --> Language Class Initialized
INFO - 2016-09-19 06:25:34 --> Language Class Initialized
INFO - 2016-09-19 06:25:34 --> Config Class Initialized
INFO - 2016-09-19 06:25:34 --> Loader Class Initialized
INFO - 2016-09-19 06:25:34 --> Config Class Initialized
INFO - 2016-09-19 06:25:34 --> Hooks Class Initialized
INFO - 2016-09-19 06:25:34 --> Helper loaded: url_helper
INFO - 2016-09-19 06:25:34 --> Helper loaded: url_helper
DEBUG - 2016-09-19 06:25:34 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:25:34 --> Utf8 Class Initialized
INFO - 2016-09-19 06:25:34 --> URI Class Initialized
INFO - 2016-09-19 06:25:35 --> Router Class Initialized
INFO - 2016-09-19 06:25:35 --> Config Class Initialized
INFO - 2016-09-19 06:25:35 --> Hooks Class Initialized
INFO - 2016-09-19 06:25:35 --> Output Class Initialized
INFO - 2016-09-19 06:25:35 --> Database Driver Class Initialized
INFO - 2016-09-19 06:25:35 --> Database Driver Class Initialized
DEBUG - 2016-09-19 06:25:35 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:25:35 --> Utf8 Class Initialized
INFO - 2016-09-19 06:25:35 --> URI Class Initialized
INFO - 2016-09-19 06:25:35 --> Controller Class Initialized
INFO - 2016-09-19 06:25:35 --> Router Class Initialized
INFO - 2016-09-19 06:25:35 --> Config Class Initialized
DEBUG - 2016-09-19 06:25:35 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:25:35 --> Security Class Initialized
INFO - 2016-09-19 06:25:35 --> Output Class Initialized
INFO - 2016-09-19 06:25:35 --> Config Class Initialized
INFO - 2016-09-19 06:25:35 --> Controller Class Initialized
DEBUG - 2016-09-19 06:25:35 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:25:35 --> Hooks Class Initialized
INFO - 2016-09-19 06:25:35 --> Model Class Initialized
DEBUG - 2016-09-19 06:25:35 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 06:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:25:35 --> Security Class Initialized
INFO - 2016-09-19 06:25:35 --> Hooks Class Initialized
INFO - 2016-09-19 06:25:35 --> Model Class Initialized
INFO - 2016-09-19 06:25:35 --> Model Class Initialized
DEBUG - 2016-09-19 06:25:35 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-19 06:25:35 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 06:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:25:35 --> Input Class Initialized
INFO - 2016-09-19 06:25:35 --> Utf8 Class Initialized
INFO - 2016-09-19 06:25:35 --> Model Class Initialized
INFO - 2016-09-19 06:25:35 --> URI Class Initialized
DEBUG - 2016-09-19 06:25:35 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:25:35 --> Utf8 Class Initialized
INFO - 2016-09-19 06:25:35 --> Input Class Initialized
INFO - 2016-09-19 06:25:35 --> Language Class Initialized
INFO - 2016-09-19 06:25:35 --> Database Driver Class Initialized
INFO - 2016-09-19 06:25:35 --> Database Driver Class Initialized
INFO - 2016-09-19 06:25:35 --> Router Class Initialized
INFO - 2016-09-19 06:25:35 --> Final output sent to browser
INFO - 2016-09-19 06:25:35 --> Final output sent to browser
DEBUG - 2016-09-19 06:25:35 --> Total execution time: 1.9544
DEBUG - 2016-09-19 06:25:35 --> Total execution time: 1.3003
INFO - 2016-09-19 06:25:35 --> Output Class Initialized
INFO - 2016-09-19 06:25:35 --> Language Class Initialized
INFO - 2016-09-19 06:25:35 --> URI Class Initialized
INFO - 2016-09-19 06:25:35 --> Router Class Initialized
INFO - 2016-09-19 06:25:35 --> Language Class Initialized
INFO - 2016-09-19 06:25:35 --> Output Class Initialized
INFO - 2016-09-19 06:25:35 --> Security Class Initialized
DEBUG - 2016-09-19 06:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:25:35 --> Input Class Initialized
INFO - 2016-09-19 06:25:35 --> Language Class Initialized
INFO - 2016-09-19 06:25:35 --> Language Class Initialized
INFO - 2016-09-19 06:25:35 --> Config Class Initialized
INFO - 2016-09-19 06:25:36 --> Loader Class Initialized
INFO - 2016-09-19 06:25:36 --> Language Class Initialized
INFO - 2016-09-19 06:25:36 --> Security Class Initialized
INFO - 2016-09-19 06:25:36 --> Config Class Initialized
INFO - 2016-09-19 06:25:36 --> Config Class Initialized
DEBUG - 2016-09-19 06:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:25:36 --> Loader Class Initialized
INFO - 2016-09-19 06:25:36 --> Loader Class Initialized
INFO - 2016-09-19 06:25:36 --> Helper loaded: url_helper
INFO - 2016-09-19 06:25:36 --> Input Class Initialized
INFO - 2016-09-19 06:25:36 --> Language Class Initialized
INFO - 2016-09-19 06:25:36 --> Language Class Initialized
INFO - 2016-09-19 06:25:36 --> Config Class Initialized
INFO - 2016-09-19 06:25:36 --> Loader Class Initialized
INFO - 2016-09-19 06:25:36 --> Helper loaded: url_helper
INFO - 2016-09-19 06:25:36 --> Database Driver Class Initialized
INFO - 2016-09-19 06:25:36 --> Helper loaded: url_helper
INFO - 2016-09-19 06:25:36 --> Helper loaded: url_helper
INFO - 2016-09-19 06:25:36 --> Database Driver Class Initialized
INFO - 2016-09-19 06:25:36 --> Database Driver Class Initialized
INFO - 2016-09-19 06:25:36 --> Controller Class Initialized
DEBUG - 2016-09-19 06:25:36 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:25:36 --> Model Class Initialized
INFO - 2016-09-19 06:25:36 --> Controller Class Initialized
INFO - 2016-09-19 06:25:36 --> Database Driver Class Initialized
INFO - 2016-09-19 06:25:36 --> Controller Class Initialized
DEBUG - 2016-09-19 06:25:36 --> Index MX_Controller Initialized
DEBUG - 2016-09-19 06:25:36 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:25:36 --> Model Class Initialized
INFO - 2016-09-19 06:25:36 --> Controller Class Initialized
DEBUG - 2016-09-19 06:25:36 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:25:36 --> Model Class Initialized
INFO - 2016-09-19 06:25:36 --> Model Class Initialized
DEBUG - 2016-09-19 06:25:36 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:25:36 --> Model Class Initialized
INFO - 2016-09-19 06:25:36 --> Model Class Initialized
DEBUG - 2016-09-19 06:25:36 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:25:36 --> Model Class Initialized
DEBUG - 2016-09-19 06:25:36 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:25:36 --> Database Driver Class Initialized
INFO - 2016-09-19 06:25:36 --> Database Driver Class Initialized
INFO - 2016-09-19 06:25:36 --> Model Class Initialized
INFO - 2016-09-19 06:25:36 --> Final output sent to browser
INFO - 2016-09-19 06:25:36 --> Final output sent to browser
INFO - 2016-09-19 06:25:36 --> Database Driver Class Initialized
DEBUG - 2016-09-19 06:25:36 --> Total execution time: 1.9360
DEBUG - 2016-09-19 06:25:36 --> Total execution time: 1.4118
DEBUG - 2016-09-19 06:25:36 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:25:36 --> Final output sent to browser
DEBUG - 2016-09-19 06:25:36 --> Total execution time: 1.7756
INFO - 2016-09-19 06:25:36 --> Database Driver Class Initialized
INFO - 2016-09-19 06:25:37 --> Final output sent to browser
DEBUG - 2016-09-19 06:25:37 --> Total execution time: 1.7284
INFO - 2016-09-19 06:25:56 --> Config Class Initialized
INFO - 2016-09-19 06:25:56 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:25:57 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:25:57 --> Utf8 Class Initialized
INFO - 2016-09-19 06:25:57 --> URI Class Initialized
INFO - 2016-09-19 06:25:57 --> Router Class Initialized
INFO - 2016-09-19 06:25:57 --> Output Class Initialized
INFO - 2016-09-19 06:25:57 --> Security Class Initialized
DEBUG - 2016-09-19 06:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:25:57 --> Input Class Initialized
INFO - 2016-09-19 06:25:57 --> Language Class Initialized
INFO - 2016-09-19 06:25:57 --> Language Class Initialized
INFO - 2016-09-19 06:25:57 --> Config Class Initialized
INFO - 2016-09-19 06:25:57 --> Loader Class Initialized
INFO - 2016-09-19 06:25:57 --> Helper loaded: url_helper
INFO - 2016-09-19 06:25:57 --> Database Driver Class Initialized
INFO - 2016-09-19 06:25:57 --> Controller Class Initialized
DEBUG - 2016-09-19 06:25:57 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:25:57 --> Model Class Initialized
INFO - 2016-09-19 06:25:57 --> Model Class Initialized
DEBUG - 2016-09-19 06:25:57 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:25:57 --> Database Driver Class Initialized
INFO - 2016-09-19 06:25:57 --> Final output sent to browser
DEBUG - 2016-09-19 06:25:57 --> Total execution time: 0.6140
INFO - 2016-09-19 06:26:00 --> Config Class Initialized
INFO - 2016-09-19 06:26:00 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:26:00 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:26:00 --> Utf8 Class Initialized
INFO - 2016-09-19 06:26:01 --> URI Class Initialized
INFO - 2016-09-19 06:26:01 --> Router Class Initialized
INFO - 2016-09-19 06:26:01 --> Output Class Initialized
INFO - 2016-09-19 06:26:01 --> Security Class Initialized
DEBUG - 2016-09-19 06:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:26:01 --> Input Class Initialized
INFO - 2016-09-19 06:26:01 --> Language Class Initialized
INFO - 2016-09-19 06:26:01 --> Language Class Initialized
INFO - 2016-09-19 06:26:01 --> Config Class Initialized
INFO - 2016-09-19 06:26:01 --> Loader Class Initialized
INFO - 2016-09-19 06:26:01 --> Helper loaded: url_helper
INFO - 2016-09-19 06:26:01 --> Database Driver Class Initialized
INFO - 2016-09-19 06:26:01 --> Controller Class Initialized
DEBUG - 2016-09-19 06:26:01 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:26:01 --> Model Class Initialized
INFO - 2016-09-19 06:26:01 --> Model Class Initialized
DEBUG - 2016-09-19 06:26:01 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:26:01 --> Database Driver Class Initialized
INFO - 2016-09-19 06:26:01 --> Final output sent to browser
DEBUG - 2016-09-19 06:26:01 --> Total execution time: 0.9219
INFO - 2016-09-19 06:26:03 --> Config Class Initialized
INFO - 2016-09-19 06:26:03 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:26:03 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:26:03 --> Utf8 Class Initialized
INFO - 2016-09-19 06:26:03 --> URI Class Initialized
INFO - 2016-09-19 06:26:03 --> Router Class Initialized
INFO - 2016-09-19 06:26:03 --> Output Class Initialized
INFO - 2016-09-19 06:26:03 --> Security Class Initialized
DEBUG - 2016-09-19 06:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:26:03 --> Input Class Initialized
INFO - 2016-09-19 06:26:03 --> Language Class Initialized
INFO - 2016-09-19 06:26:03 --> Language Class Initialized
INFO - 2016-09-19 06:26:03 --> Config Class Initialized
INFO - 2016-09-19 06:26:03 --> Loader Class Initialized
INFO - 2016-09-19 06:26:03 --> Helper loaded: url_helper
INFO - 2016-09-19 06:26:03 --> Database Driver Class Initialized
INFO - 2016-09-19 06:26:03 --> Controller Class Initialized
DEBUG - 2016-09-19 06:26:04 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:26:04 --> Model Class Initialized
INFO - 2016-09-19 06:26:04 --> Model Class Initialized
DEBUG - 2016-09-19 06:26:04 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:26:04 --> Database Driver Class Initialized
INFO - 2016-09-19 06:26:04 --> Final output sent to browser
DEBUG - 2016-09-19 06:26:04 --> Total execution time: 0.7817
INFO - 2016-09-19 06:26:05 --> Config Class Initialized
INFO - 2016-09-19 06:26:05 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:26:05 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:26:05 --> Utf8 Class Initialized
INFO - 2016-09-19 06:26:05 --> URI Class Initialized
INFO - 2016-09-19 06:26:05 --> Router Class Initialized
INFO - 2016-09-19 06:26:05 --> Output Class Initialized
INFO - 2016-09-19 06:26:05 --> Security Class Initialized
DEBUG - 2016-09-19 06:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:26:05 --> Input Class Initialized
INFO - 2016-09-19 06:26:05 --> Language Class Initialized
INFO - 2016-09-19 06:26:06 --> Language Class Initialized
INFO - 2016-09-19 06:26:06 --> Config Class Initialized
INFO - 2016-09-19 06:26:06 --> Loader Class Initialized
INFO - 2016-09-19 06:26:06 --> Helper loaded: url_helper
INFO - 2016-09-19 06:26:06 --> Database Driver Class Initialized
INFO - 2016-09-19 06:26:06 --> Controller Class Initialized
DEBUG - 2016-09-19 06:26:06 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:26:06 --> Config Class Initialized
INFO - 2016-09-19 06:26:06 --> Model Class Initialized
INFO - 2016-09-19 06:26:06 --> Model Class Initialized
INFO - 2016-09-19 06:26:06 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:26:06 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-19 06:26:06 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:26:06 --> Utf8 Class Initialized
INFO - 2016-09-19 06:26:06 --> Config Class Initialized
INFO - 2016-09-19 06:26:06 --> URI Class Initialized
INFO - 2016-09-19 06:26:06 --> Router Class Initialized
INFO - 2016-09-19 06:26:06 --> Hooks Class Initialized
INFO - 2016-09-19 06:26:06 --> Database Driver Class Initialized
INFO - 2016-09-19 06:26:06 --> Config Class Initialized
INFO - 2016-09-19 06:26:06 --> Hooks Class Initialized
INFO - 2016-09-19 06:26:06 --> Output Class Initialized
DEBUG - 2016-09-19 06:26:06 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:26:06 --> Final output sent to browser
DEBUG - 2016-09-19 06:26:06 --> Total execution time: 1.1336
DEBUG - 2016-09-19 06:26:06 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:26:06 --> Security Class Initialized
INFO - 2016-09-19 06:26:06 --> Utf8 Class Initialized
INFO - 2016-09-19 06:26:06 --> Config Class Initialized
INFO - 2016-09-19 06:26:06 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:26:06 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:26:06 --> Utf8 Class Initialized
INFO - 2016-09-19 06:26:07 --> URI Class Initialized
DEBUG - 2016-09-19 06:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:26:07 --> Utf8 Class Initialized
INFO - 2016-09-19 06:26:07 --> URI Class Initialized
INFO - 2016-09-19 06:26:07 --> Router Class Initialized
INFO - 2016-09-19 06:26:07 --> Config Class Initialized
INFO - 2016-09-19 06:26:07 --> URI Class Initialized
INFO - 2016-09-19 06:26:07 --> Router Class Initialized
INFO - 2016-09-19 06:26:07 --> Input Class Initialized
INFO - 2016-09-19 06:26:07 --> Router Class Initialized
INFO - 2016-09-19 06:26:07 --> Output Class Initialized
INFO - 2016-09-19 06:26:07 --> Output Class Initialized
INFO - 2016-09-19 06:26:07 --> Language Class Initialized
INFO - 2016-09-19 06:26:07 --> Hooks Class Initialized
INFO - 2016-09-19 06:26:07 --> Config Class Initialized
INFO - 2016-09-19 06:26:07 --> Security Class Initialized
INFO - 2016-09-19 06:26:07 --> Security Class Initialized
DEBUG - 2016-09-19 06:26:07 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:26:07 --> Language Class Initialized
INFO - 2016-09-19 06:26:07 --> Output Class Initialized
INFO - 2016-09-19 06:26:07 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:26:07 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:26:07 --> Utf8 Class Initialized
INFO - 2016-09-19 06:26:07 --> URI Class Initialized
INFO - 2016-09-19 06:26:07 --> Router Class Initialized
DEBUG - 2016-09-19 06:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:26:07 --> Output Class Initialized
INFO - 2016-09-19 06:26:07 --> Config Class Initialized
INFO - 2016-09-19 06:26:07 --> Utf8 Class Initialized
DEBUG - 2016-09-19 06:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:26:07 --> Security Class Initialized
INFO - 2016-09-19 06:26:07 --> Input Class Initialized
INFO - 2016-09-19 06:26:07 --> Language Class Initialized
INFO - 2016-09-19 06:26:07 --> Input Class Initialized
DEBUG - 2016-09-19 06:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:26:07 --> Language Class Initialized
INFO - 2016-09-19 06:26:07 --> Loader Class Initialized
INFO - 2016-09-19 06:26:07 --> URI Class Initialized
INFO - 2016-09-19 06:26:07 --> Security Class Initialized
INFO - 2016-09-19 06:26:07 --> Language Class Initialized
INFO - 2016-09-19 06:26:07 --> Input Class Initialized
INFO - 2016-09-19 06:26:07 --> Language Class Initialized
INFO - 2016-09-19 06:26:07 --> Helper loaded: url_helper
DEBUG - 2016-09-19 06:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:26:07 --> Router Class Initialized
INFO - 2016-09-19 06:26:07 --> Input Class Initialized
INFO - 2016-09-19 06:26:07 --> Language Class Initialized
INFO - 2016-09-19 06:26:07 --> Database Driver Class Initialized
INFO - 2016-09-19 06:26:07 --> Output Class Initialized
INFO - 2016-09-19 06:26:07 --> Config Class Initialized
INFO - 2016-09-19 06:26:07 --> Config Class Initialized
INFO - 2016-09-19 06:26:07 --> Language Class Initialized
INFO - 2016-09-19 06:26:07 --> Loader Class Initialized
INFO - 2016-09-19 06:26:07 --> Language Class Initialized
INFO - 2016-09-19 06:26:07 --> Security Class Initialized
INFO - 2016-09-19 06:26:07 --> Language Class Initialized
INFO - 2016-09-19 06:26:07 --> Helper loaded: url_helper
INFO - 2016-09-19 06:26:07 --> Loader Class Initialized
INFO - 2016-09-19 06:26:07 --> Config Class Initialized
INFO - 2016-09-19 06:26:07 --> Controller Class Initialized
INFO - 2016-09-19 06:26:07 --> Helper loaded: url_helper
INFO - 2016-09-19 06:26:07 --> Database Driver Class Initialized
INFO - 2016-09-19 06:26:07 --> Config Class Initialized
DEBUG - 2016-09-19 06:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-19 06:26:07 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:26:07 --> Loader Class Initialized
INFO - 2016-09-19 06:26:07 --> Model Class Initialized
INFO - 2016-09-19 06:26:07 --> Model Class Initialized
DEBUG - 2016-09-19 06:26:07 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:26:07 --> Input Class Initialized
INFO - 2016-09-19 06:26:07 --> Database Driver Class Initialized
INFO - 2016-09-19 06:26:08 --> Language Class Initialized
INFO - 2016-09-19 06:26:08 --> Language Class Initialized
INFO - 2016-09-19 06:26:08 --> Database Driver Class Initialized
INFO - 2016-09-19 06:26:08 --> Helper loaded: url_helper
INFO - 2016-09-19 06:26:08 --> Loader Class Initialized
INFO - 2016-09-19 06:26:08 --> Controller Class Initialized
INFO - 2016-09-19 06:26:08 --> Final output sent to browser
DEBUG - 2016-09-19 06:26:08 --> Total execution time: 1.7916
DEBUG - 2016-09-19 06:26:08 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:26:08 --> Config Class Initialized
INFO - 2016-09-19 06:26:08 --> Helper loaded: url_helper
INFO - 2016-09-19 06:26:08 --> Database Driver Class Initialized
INFO - 2016-09-19 06:26:08 --> Config Class Initialized
INFO - 2016-09-19 06:26:08 --> Controller Class Initialized
INFO - 2016-09-19 06:26:08 --> Database Driver Class Initialized
INFO - 2016-09-19 06:26:08 --> Loader Class Initialized
INFO - 2016-09-19 06:26:08 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:26:08 --> Index MX_Controller Initialized
DEBUG - 2016-09-19 06:26:08 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:26:08 --> Controller Class Initialized
DEBUG - 2016-09-19 06:26:08 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:26:08 --> Model Class Initialized
INFO - 2016-09-19 06:26:08 --> Utf8 Class Initialized
INFO - 2016-09-19 06:26:08 --> Model Class Initialized
INFO - 2016-09-19 06:26:08 --> Helper loaded: url_helper
INFO - 2016-09-19 06:26:08 --> Model Class Initialized
INFO - 2016-09-19 06:26:08 --> Model Class Initialized
INFO - 2016-09-19 06:26:08 --> Controller Class Initialized
DEBUG - 2016-09-19 06:26:08 --> Index MX_Controller Initialized
DEBUG - 2016-09-19 06:26:08 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:26:08 --> Model Class Initialized
INFO - 2016-09-19 06:26:08 --> Model Class Initialized
INFO - 2016-09-19 06:26:08 --> URI Class Initialized
INFO - 2016-09-19 06:26:08 --> Database Driver Class Initialized
DEBUG - 2016-09-19 06:26:08 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:26:08 --> Model Class Initialized
INFO - 2016-09-19 06:26:08 --> Router Class Initialized
DEBUG - 2016-09-19 06:26:08 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:26:08 --> Controller Class Initialized
INFO - 2016-09-19 06:26:08 --> Database Driver Class Initialized
DEBUG - 2016-09-19 06:26:08 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:26:08 --> Database Driver Class Initialized
INFO - 2016-09-19 06:26:08 --> Final output sent to browser
INFO - 2016-09-19 06:26:08 --> Output Class Initialized
INFO - 2016-09-19 06:26:08 --> Model Class Initialized
DEBUG - 2016-09-19 06:26:08 --> Total execution time: 1.4102
INFO - 2016-09-19 06:26:08 --> Security Class Initialized
INFO - 2016-09-19 06:26:08 --> Database Driver Class Initialized
INFO - 2016-09-19 06:26:08 --> Final output sent to browser
INFO - 2016-09-19 06:26:08 --> Model Class Initialized
DEBUG - 2016-09-19 06:26:08 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-19 06:26:08 --> Total execution time: 2.0824
INFO - 2016-09-19 06:26:08 --> Config Class Initialized
INFO - 2016-09-19 06:26:08 --> Model Class Initialized
DEBUG - 2016-09-19 06:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:26:08 --> Database Driver Class Initialized
INFO - 2016-09-19 06:26:08 --> Final output sent to browser
DEBUG - 2016-09-19 06:26:08 --> Total execution time: 1.9162
INFO - 2016-09-19 06:26:08 --> Config Class Initialized
INFO - 2016-09-19 06:26:08 --> Config Class Initialized
INFO - 2016-09-19 06:26:08 --> Hooks Class Initialized
INFO - 2016-09-19 06:26:08 --> Input Class Initialized
DEBUG - 2016-09-19 06:26:08 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:26:08 --> Final output sent to browser
DEBUG - 2016-09-19 06:26:08 --> Total execution time: 2.1889
INFO - 2016-09-19 06:26:08 --> Hooks Class Initialized
INFO - 2016-09-19 06:26:08 --> Language Class Initialized
DEBUG - 2016-09-19 06:26:08 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:26:08 --> Hooks Class Initialized
INFO - 2016-09-19 06:26:08 --> Database Driver Class Initialized
INFO - 2016-09-19 06:26:08 --> Config Class Initialized
DEBUG - 2016-09-19 06:26:08 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:26:08 --> Utf8 Class Initialized
INFO - 2016-09-19 06:26:08 --> Language Class Initialized
DEBUG - 2016-09-19 06:26:08 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:26:09 --> Hooks Class Initialized
INFO - 2016-09-19 06:26:09 --> Final output sent to browser
DEBUG - 2016-09-19 06:26:09 --> Total execution time: 2.0020
DEBUG - 2016-09-19 06:26:09 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:26:09 --> Config Class Initialized
INFO - 2016-09-19 06:26:09 --> Hooks Class Initialized
INFO - 2016-09-19 06:26:09 --> Utf8 Class Initialized
DEBUG - 2016-09-19 06:26:09 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:26:09 --> Config Class Initialized
INFO - 2016-09-19 06:26:09 --> Utf8 Class Initialized
INFO - 2016-09-19 06:26:09 --> URI Class Initialized
INFO - 2016-09-19 06:26:09 --> Utf8 Class Initialized
INFO - 2016-09-19 06:26:09 --> Loader Class Initialized
INFO - 2016-09-19 06:26:09 --> Utf8 Class Initialized
INFO - 2016-09-19 06:26:09 --> URI Class Initialized
INFO - 2016-09-19 06:26:09 --> URI Class Initialized
INFO - 2016-09-19 06:26:09 --> Router Class Initialized
INFO - 2016-09-19 06:26:09 --> URI Class Initialized
INFO - 2016-09-19 06:26:09 --> Router Class Initialized
INFO - 2016-09-19 06:26:09 --> Output Class Initialized
INFO - 2016-09-19 06:26:09 --> Security Class Initialized
DEBUG - 2016-09-19 06:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:26:09 --> Input Class Initialized
INFO - 2016-09-19 06:26:09 --> Language Class Initialized
INFO - 2016-09-19 06:26:09 --> Language Class Initialized
INFO - 2016-09-19 06:26:09 --> Config Class Initialized
INFO - 2016-09-19 06:26:09 --> Helper loaded: url_helper
INFO - 2016-09-19 06:26:09 --> URI Class Initialized
INFO - 2016-09-19 06:26:09 --> Router Class Initialized
INFO - 2016-09-19 06:26:09 --> Output Class Initialized
INFO - 2016-09-19 06:26:09 --> Router Class Initialized
INFO - 2016-09-19 06:26:09 --> Security Class Initialized
INFO - 2016-09-19 06:26:09 --> Loader Class Initialized
INFO - 2016-09-19 06:26:09 --> Output Class Initialized
INFO - 2016-09-19 06:26:09 --> Router Class Initialized
INFO - 2016-09-19 06:26:09 --> Output Class Initialized
INFO - 2016-09-19 06:26:09 --> Database Driver Class Initialized
DEBUG - 2016-09-19 06:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:26:09 --> Input Class Initialized
INFO - 2016-09-19 06:26:09 --> Language Class Initialized
INFO - 2016-09-19 06:26:09 --> Security Class Initialized
INFO - 2016-09-19 06:26:09 --> Controller Class Initialized
DEBUG - 2016-09-19 06:26:09 --> Index MX_Controller Initialized
DEBUG - 2016-09-19 06:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:26:09 --> Model Class Initialized
INFO - 2016-09-19 06:26:10 --> Model Class Initialized
INFO - 2016-09-19 06:26:10 --> Helper loaded: url_helper
INFO - 2016-09-19 06:26:10 --> Language Class Initialized
INFO - 2016-09-19 06:26:10 --> Output Class Initialized
INFO - 2016-09-19 06:26:10 --> Input Class Initialized
INFO - 2016-09-19 06:26:10 --> Config Class Initialized
DEBUG - 2016-09-19 06:26:10 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:26:10 --> Loader Class Initialized
INFO - 2016-09-19 06:26:10 --> Security Class Initialized
INFO - 2016-09-19 06:26:10 --> Security Class Initialized
INFO - 2016-09-19 06:26:10 --> Language Class Initialized
INFO - 2016-09-19 06:26:10 --> Database Driver Class Initialized
INFO - 2016-09-19 06:26:10 --> Database Driver Class Initialized
INFO - 2016-09-19 06:26:10 --> Helper loaded: url_helper
INFO - 2016-09-19 06:26:10 --> Controller Class Initialized
INFO - 2016-09-19 06:26:10 --> Final output sent to browser
DEBUG - 2016-09-19 06:26:10 --> Total execution time: 1.9631
DEBUG - 2016-09-19 06:26:10 --> Index MX_Controller Initialized
DEBUG - 2016-09-19 06:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-19 06:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:26:10 --> Language Class Initialized
INFO - 2016-09-19 06:26:10 --> Database Driver Class Initialized
INFO - 2016-09-19 06:26:10 --> Model Class Initialized
INFO - 2016-09-19 06:26:10 --> Input Class Initialized
INFO - 2016-09-19 06:26:10 --> Model Class Initialized
INFO - 2016-09-19 06:26:10 --> Language Class Initialized
DEBUG - 2016-09-19 06:26:10 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:26:10 --> Config Class Initialized
INFO - 2016-09-19 06:26:10 --> Input Class Initialized
INFO - 2016-09-19 06:26:10 --> Controller Class Initialized
DEBUG - 2016-09-19 06:26:10 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:26:10 --> Language Class Initialized
INFO - 2016-09-19 06:26:10 --> Language Class Initialized
INFO - 2016-09-19 06:26:10 --> Loader Class Initialized
INFO - 2016-09-19 06:26:10 --> Database Driver Class Initialized
INFO - 2016-09-19 06:26:10 --> Model Class Initialized
INFO - 2016-09-19 06:26:10 --> Model Class Initialized
DEBUG - 2016-09-19 06:26:10 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:26:10 --> Language Class Initialized
INFO - 2016-09-19 06:26:10 --> Helper loaded: url_helper
INFO - 2016-09-19 06:26:10 --> Config Class Initialized
INFO - 2016-09-19 06:26:10 --> Database Driver Class Initialized
INFO - 2016-09-19 06:26:10 --> Final output sent to browser
INFO - 2016-09-19 06:26:10 --> Config Class Initialized
DEBUG - 2016-09-19 06:26:10 --> Total execution time: 1.8038
INFO - 2016-09-19 06:26:10 --> Database Driver Class Initialized
INFO - 2016-09-19 06:26:10 --> Loader Class Initialized
INFO - 2016-09-19 06:26:10 --> Loader Class Initialized
INFO - 2016-09-19 06:26:10 --> Final output sent to browser
DEBUG - 2016-09-19 06:26:10 --> Total execution time: 2.0004
INFO - 2016-09-19 06:26:10 --> Helper loaded: url_helper
INFO - 2016-09-19 06:26:10 --> Controller Class Initialized
DEBUG - 2016-09-19 06:26:10 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:26:10 --> Database Driver Class Initialized
INFO - 2016-09-19 06:26:10 --> Model Class Initialized
INFO - 2016-09-19 06:26:10 --> Controller Class Initialized
INFO - 2016-09-19 06:26:10 --> Model Class Initialized
DEBUG - 2016-09-19 06:26:10 --> Index MX_Controller Initialized
DEBUG - 2016-09-19 06:26:10 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:26:10 --> Helper loaded: url_helper
INFO - 2016-09-19 06:26:10 --> Model Class Initialized
INFO - 2016-09-19 06:26:10 --> Database Driver Class Initialized
INFO - 2016-09-19 06:26:10 --> Database Driver Class Initialized
INFO - 2016-09-19 06:26:10 --> Model Class Initialized
DEBUG - 2016-09-19 06:26:10 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:26:10 --> Controller Class Initialized
INFO - 2016-09-19 06:26:10 --> Final output sent to browser
DEBUG - 2016-09-19 06:26:10 --> Total execution time: 2.1244
DEBUG - 2016-09-19 06:26:10 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:26:10 --> Database Driver Class Initialized
INFO - 2016-09-19 06:26:11 --> Model Class Initialized
INFO - 2016-09-19 06:26:11 --> Final output sent to browser
DEBUG - 2016-09-19 06:26:11 --> Total execution time: 2.0882
INFO - 2016-09-19 06:26:11 --> Model Class Initialized
DEBUG - 2016-09-19 06:26:11 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:26:11 --> Database Driver Class Initialized
INFO - 2016-09-19 06:26:11 --> Config Class Initialized
INFO - 2016-09-19 06:26:11 --> Hooks Class Initialized
INFO - 2016-09-19 06:26:11 --> Final output sent to browser
DEBUG - 2016-09-19 06:26:11 --> Total execution time: 2.1545
DEBUG - 2016-09-19 06:26:11 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:26:11 --> Utf8 Class Initialized
INFO - 2016-09-19 06:26:11 --> URI Class Initialized
INFO - 2016-09-19 06:26:11 --> Router Class Initialized
INFO - 2016-09-19 06:26:11 --> Output Class Initialized
INFO - 2016-09-19 06:26:11 --> Security Class Initialized
DEBUG - 2016-09-19 06:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:26:11 --> Input Class Initialized
INFO - 2016-09-19 06:26:11 --> Language Class Initialized
INFO - 2016-09-19 06:26:11 --> Language Class Initialized
INFO - 2016-09-19 06:26:11 --> Config Class Initialized
INFO - 2016-09-19 06:26:11 --> Loader Class Initialized
INFO - 2016-09-19 06:26:11 --> Helper loaded: url_helper
INFO - 2016-09-19 06:26:11 --> Database Driver Class Initialized
INFO - 2016-09-19 06:26:11 --> Controller Class Initialized
DEBUG - 2016-09-19 06:26:11 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:26:11 --> Model Class Initialized
INFO - 2016-09-19 06:26:11 --> Model Class Initialized
DEBUG - 2016-09-19 06:26:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 06:26:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 06:26:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 06:26:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 06:26:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 06:26:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 06:26:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 06:26:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 06:26:12 --> Final output sent to browser
DEBUG - 2016-09-19 06:26:12 --> Total execution time: 1.0921
INFO - 2016-09-19 06:27:53 --> Config Class Initialized
INFO - 2016-09-19 06:27:53 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:27:53 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:27:53 --> Utf8 Class Initialized
INFO - 2016-09-19 06:27:53 --> URI Class Initialized
INFO - 2016-09-19 06:27:53 --> Router Class Initialized
INFO - 2016-09-19 06:27:53 --> Output Class Initialized
INFO - 2016-09-19 06:27:53 --> Security Class Initialized
DEBUG - 2016-09-19 06:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:27:53 --> Input Class Initialized
INFO - 2016-09-19 06:27:53 --> Language Class Initialized
INFO - 2016-09-19 06:27:53 --> Language Class Initialized
INFO - 2016-09-19 06:27:53 --> Config Class Initialized
INFO - 2016-09-19 06:27:53 --> Loader Class Initialized
INFO - 2016-09-19 06:27:53 --> Helper loaded: url_helper
INFO - 2016-09-19 06:27:53 --> Database Driver Class Initialized
INFO - 2016-09-19 06:27:53 --> Controller Class Initialized
DEBUG - 2016-09-19 06:27:53 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:27:53 --> Model Class Initialized
INFO - 2016-09-19 06:27:53 --> Model Class Initialized
DEBUG - 2016-09-19 06:27:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 06:27:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 06:27:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 06:27:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 06:27:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 06:27:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 06:27:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 06:27:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 06:27:53 --> Final output sent to browser
DEBUG - 2016-09-19 06:27:54 --> Total execution time: 0.8067
INFO - 2016-09-19 06:27:58 --> Config Class Initialized
INFO - 2016-09-19 06:27:58 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:27:58 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:27:58 --> Utf8 Class Initialized
INFO - 2016-09-19 06:27:58 --> URI Class Initialized
INFO - 2016-09-19 06:27:58 --> Router Class Initialized
INFO - 2016-09-19 06:27:58 --> Output Class Initialized
INFO - 2016-09-19 06:27:58 --> Security Class Initialized
DEBUG - 2016-09-19 06:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:27:58 --> Input Class Initialized
INFO - 2016-09-19 06:27:58 --> Language Class Initialized
INFO - 2016-09-19 06:27:58 --> Language Class Initialized
INFO - 2016-09-19 06:27:58 --> Config Class Initialized
INFO - 2016-09-19 06:27:58 --> Loader Class Initialized
INFO - 2016-09-19 06:27:58 --> Helper loaded: url_helper
INFO - 2016-09-19 06:27:58 --> Database Driver Class Initialized
INFO - 2016-09-19 06:27:58 --> Controller Class Initialized
DEBUG - 2016-09-19 06:27:58 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:27:58 --> Model Class Initialized
INFO - 2016-09-19 06:27:58 --> Model Class Initialized
DEBUG - 2016-09-19 06:27:58 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:27:58 --> Database Driver Class Initialized
INFO - 2016-09-19 06:27:58 --> Final output sent to browser
DEBUG - 2016-09-19 06:27:58 --> Total execution time: 0.6851
INFO - 2016-09-19 06:28:01 --> Config Class Initialized
INFO - 2016-09-19 06:28:01 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:28:01 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:28:01 --> Utf8 Class Initialized
INFO - 2016-09-19 06:28:01 --> URI Class Initialized
INFO - 2016-09-19 06:28:01 --> Router Class Initialized
INFO - 2016-09-19 06:28:01 --> Output Class Initialized
INFO - 2016-09-19 06:28:01 --> Security Class Initialized
DEBUG - 2016-09-19 06:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:28:01 --> Input Class Initialized
INFO - 2016-09-19 06:28:01 --> Language Class Initialized
INFO - 2016-09-19 06:28:01 --> Language Class Initialized
INFO - 2016-09-19 06:28:01 --> Config Class Initialized
INFO - 2016-09-19 06:28:01 --> Loader Class Initialized
INFO - 2016-09-19 06:28:01 --> Helper loaded: url_helper
INFO - 2016-09-19 06:28:01 --> Database Driver Class Initialized
INFO - 2016-09-19 06:28:01 --> Controller Class Initialized
DEBUG - 2016-09-19 06:28:01 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:28:02 --> Model Class Initialized
INFO - 2016-09-19 06:28:02 --> Model Class Initialized
DEBUG - 2016-09-19 06:28:02 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:28:02 --> Database Driver Class Initialized
INFO - 2016-09-19 06:28:02 --> Final output sent to browser
DEBUG - 2016-09-19 06:28:02 --> Total execution time: 0.7048
INFO - 2016-09-19 06:37:53 --> Config Class Initialized
INFO - 2016-09-19 06:37:53 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:37:53 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:37:53 --> Utf8 Class Initialized
INFO - 2016-09-19 06:37:53 --> URI Class Initialized
INFO - 2016-09-19 06:37:53 --> Router Class Initialized
INFO - 2016-09-19 06:37:53 --> Output Class Initialized
INFO - 2016-09-19 06:37:53 --> Security Class Initialized
DEBUG - 2016-09-19 06:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:37:53 --> Input Class Initialized
INFO - 2016-09-19 06:37:53 --> Language Class Initialized
INFO - 2016-09-19 06:37:53 --> Language Class Initialized
INFO - 2016-09-19 06:37:53 --> Config Class Initialized
INFO - 2016-09-19 06:37:53 --> Loader Class Initialized
INFO - 2016-09-19 06:37:53 --> Helper loaded: url_helper
INFO - 2016-09-19 06:37:54 --> Database Driver Class Initialized
INFO - 2016-09-19 06:37:54 --> Controller Class Initialized
DEBUG - 2016-09-19 06:37:54 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:37:54 --> Model Class Initialized
INFO - 2016-09-19 06:37:54 --> Model Class Initialized
DEBUG - 2016-09-19 06:37:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 06:37:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 06:37:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 06:37:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 06:37:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 06:37:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 06:37:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 06:37:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 06:37:54 --> Final output sent to browser
DEBUG - 2016-09-19 06:37:54 --> Total execution time: 0.8607
INFO - 2016-09-19 06:40:09 --> Config Class Initialized
INFO - 2016-09-19 06:40:09 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:40:09 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:40:09 --> Utf8 Class Initialized
INFO - 2016-09-19 06:40:09 --> URI Class Initialized
INFO - 2016-09-19 06:40:09 --> Router Class Initialized
INFO - 2016-09-19 06:40:09 --> Output Class Initialized
INFO - 2016-09-19 06:40:09 --> Security Class Initialized
DEBUG - 2016-09-19 06:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:40:10 --> Input Class Initialized
INFO - 2016-09-19 06:40:10 --> Language Class Initialized
INFO - 2016-09-19 06:40:10 --> Language Class Initialized
INFO - 2016-09-19 06:40:10 --> Config Class Initialized
INFO - 2016-09-19 06:40:10 --> Loader Class Initialized
INFO - 2016-09-19 06:40:10 --> Helper loaded: url_helper
INFO - 2016-09-19 06:40:10 --> Database Driver Class Initialized
INFO - 2016-09-19 06:40:10 --> Controller Class Initialized
DEBUG - 2016-09-19 06:40:10 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:40:10 --> Model Class Initialized
INFO - 2016-09-19 06:40:10 --> Model Class Initialized
DEBUG - 2016-09-19 06:40:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 06:40:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 06:40:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 06:40:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 06:40:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 06:40:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 06:40:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 06:40:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 06:40:10 --> Final output sent to browser
DEBUG - 2016-09-19 06:40:10 --> Total execution time: 0.8173
INFO - 2016-09-19 06:41:06 --> Config Class Initialized
INFO - 2016-09-19 06:41:06 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:41:06 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:41:06 --> Utf8 Class Initialized
INFO - 2016-09-19 06:41:06 --> URI Class Initialized
INFO - 2016-09-19 06:41:06 --> Router Class Initialized
INFO - 2016-09-19 06:41:06 --> Output Class Initialized
INFO - 2016-09-19 06:41:06 --> Security Class Initialized
DEBUG - 2016-09-19 06:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:41:06 --> Input Class Initialized
INFO - 2016-09-19 06:41:07 --> Language Class Initialized
INFO - 2016-09-19 06:41:07 --> Language Class Initialized
INFO - 2016-09-19 06:41:07 --> Config Class Initialized
INFO - 2016-09-19 06:41:07 --> Loader Class Initialized
INFO - 2016-09-19 06:41:07 --> Helper loaded: url_helper
INFO - 2016-09-19 06:41:07 --> Database Driver Class Initialized
INFO - 2016-09-19 06:41:07 --> Controller Class Initialized
DEBUG - 2016-09-19 06:41:07 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:41:07 --> Model Class Initialized
INFO - 2016-09-19 06:41:07 --> Model Class Initialized
DEBUG - 2016-09-19 06:41:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 06:41:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 06:41:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 06:41:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 06:41:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 06:41:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 06:41:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 06:41:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 06:41:07 --> Final output sent to browser
DEBUG - 2016-09-19 06:41:07 --> Total execution time: 0.8444
INFO - 2016-09-19 06:41:45 --> Config Class Initialized
INFO - 2016-09-19 06:41:45 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:41:45 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:41:45 --> Utf8 Class Initialized
INFO - 2016-09-19 06:41:45 --> URI Class Initialized
INFO - 2016-09-19 06:41:45 --> Router Class Initialized
INFO - 2016-09-19 06:41:45 --> Output Class Initialized
INFO - 2016-09-19 06:41:45 --> Security Class Initialized
DEBUG - 2016-09-19 06:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:41:45 --> Input Class Initialized
INFO - 2016-09-19 06:41:45 --> Language Class Initialized
INFO - 2016-09-19 06:41:45 --> Language Class Initialized
INFO - 2016-09-19 06:41:45 --> Config Class Initialized
INFO - 2016-09-19 06:41:45 --> Loader Class Initialized
INFO - 2016-09-19 06:41:45 --> Helper loaded: url_helper
INFO - 2016-09-19 06:41:45 --> Database Driver Class Initialized
INFO - 2016-09-19 06:41:45 --> Controller Class Initialized
DEBUG - 2016-09-19 06:41:45 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:41:45 --> Model Class Initialized
INFO - 2016-09-19 06:41:45 --> Model Class Initialized
DEBUG - 2016-09-19 06:41:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 06:41:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 06:41:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 06:41:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 06:41:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 06:41:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 06:41:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 06:41:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 06:41:46 --> Final output sent to browser
DEBUG - 2016-09-19 06:41:46 --> Total execution time: 0.8084
INFO - 2016-09-19 06:44:21 --> Config Class Initialized
INFO - 2016-09-19 06:44:21 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:44:21 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:44:21 --> Utf8 Class Initialized
INFO - 2016-09-19 06:44:21 --> URI Class Initialized
INFO - 2016-09-19 06:44:21 --> Router Class Initialized
INFO - 2016-09-19 06:44:21 --> Output Class Initialized
INFO - 2016-09-19 06:44:21 --> Security Class Initialized
DEBUG - 2016-09-19 06:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:44:21 --> Input Class Initialized
INFO - 2016-09-19 06:44:21 --> Language Class Initialized
INFO - 2016-09-19 06:44:21 --> Language Class Initialized
INFO - 2016-09-19 06:44:21 --> Config Class Initialized
INFO - 2016-09-19 06:44:21 --> Loader Class Initialized
INFO - 2016-09-19 06:44:21 --> Helper loaded: url_helper
INFO - 2016-09-19 06:44:21 --> Database Driver Class Initialized
INFO - 2016-09-19 06:44:21 --> Controller Class Initialized
DEBUG - 2016-09-19 06:44:21 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:44:21 --> Model Class Initialized
INFO - 2016-09-19 06:44:22 --> Model Class Initialized
DEBUG - 2016-09-19 06:44:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 06:44:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 06:44:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 06:44:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 06:44:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 06:44:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 06:44:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 06:44:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 06:44:22 --> Final output sent to browser
DEBUG - 2016-09-19 06:44:22 --> Total execution time: 1.0412
INFO - 2016-09-19 06:44:28 --> Config Class Initialized
INFO - 2016-09-19 06:44:28 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:44:28 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:44:28 --> Utf8 Class Initialized
INFO - 2016-09-19 06:44:28 --> URI Class Initialized
INFO - 2016-09-19 06:44:28 --> Router Class Initialized
INFO - 2016-09-19 06:44:28 --> Output Class Initialized
INFO - 2016-09-19 06:44:28 --> Security Class Initialized
DEBUG - 2016-09-19 06:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:44:28 --> Input Class Initialized
INFO - 2016-09-19 06:44:28 --> Language Class Initialized
INFO - 2016-09-19 06:44:28 --> Language Class Initialized
INFO - 2016-09-19 06:44:28 --> Config Class Initialized
INFO - 2016-09-19 06:44:28 --> Loader Class Initialized
INFO - 2016-09-19 06:44:28 --> Helper loaded: url_helper
INFO - 2016-09-19 06:44:28 --> Database Driver Class Initialized
INFO - 2016-09-19 06:44:28 --> Controller Class Initialized
DEBUG - 2016-09-19 06:44:28 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:44:28 --> Model Class Initialized
INFO - 2016-09-19 06:44:28 --> Model Class Initialized
DEBUG - 2016-09-19 06:44:28 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:44:28 --> Database Driver Class Initialized
INFO - 2016-09-19 06:44:28 --> Final output sent to browser
DEBUG - 2016-09-19 06:44:28 --> Total execution time: 0.6648
INFO - 2016-09-19 06:45:41 --> Config Class Initialized
INFO - 2016-09-19 06:45:41 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:45:41 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:45:41 --> Utf8 Class Initialized
INFO - 2016-09-19 06:45:41 --> URI Class Initialized
INFO - 2016-09-19 06:45:41 --> Router Class Initialized
INFO - 2016-09-19 06:45:41 --> Output Class Initialized
INFO - 2016-09-19 06:45:41 --> Security Class Initialized
DEBUG - 2016-09-19 06:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:45:41 --> Input Class Initialized
INFO - 2016-09-19 06:45:41 --> Language Class Initialized
INFO - 2016-09-19 06:45:41 --> Language Class Initialized
INFO - 2016-09-19 06:45:41 --> Config Class Initialized
INFO - 2016-09-19 06:45:41 --> Loader Class Initialized
INFO - 2016-09-19 06:45:41 --> Helper loaded: url_helper
INFO - 2016-09-19 06:45:41 --> Database Driver Class Initialized
INFO - 2016-09-19 06:45:41 --> Controller Class Initialized
DEBUG - 2016-09-19 06:45:42 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:45:42 --> Model Class Initialized
INFO - 2016-09-19 06:45:42 --> Model Class Initialized
DEBUG - 2016-09-19 06:45:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 06:45:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 06:45:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 06:45:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 06:45:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 06:45:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 06:45:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 06:45:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 06:45:42 --> Final output sent to browser
DEBUG - 2016-09-19 06:45:42 --> Total execution time: 0.8265
INFO - 2016-09-19 06:45:46 --> Config Class Initialized
INFO - 2016-09-19 06:45:46 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:45:46 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:45:46 --> Utf8 Class Initialized
INFO - 2016-09-19 06:45:46 --> URI Class Initialized
INFO - 2016-09-19 06:45:46 --> Router Class Initialized
INFO - 2016-09-19 06:45:46 --> Output Class Initialized
INFO - 2016-09-19 06:45:46 --> Security Class Initialized
DEBUG - 2016-09-19 06:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:45:46 --> Input Class Initialized
INFO - 2016-09-19 06:45:46 --> Language Class Initialized
INFO - 2016-09-19 06:45:47 --> Language Class Initialized
INFO - 2016-09-19 06:45:47 --> Config Class Initialized
INFO - 2016-09-19 06:45:47 --> Loader Class Initialized
INFO - 2016-09-19 06:45:47 --> Helper loaded: url_helper
INFO - 2016-09-19 06:45:47 --> Database Driver Class Initialized
INFO - 2016-09-19 06:45:47 --> Controller Class Initialized
DEBUG - 2016-09-19 06:45:47 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:45:47 --> Model Class Initialized
INFO - 2016-09-19 06:45:47 --> Model Class Initialized
DEBUG - 2016-09-19 06:45:47 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:45:47 --> Database Driver Class Initialized
INFO - 2016-09-19 06:45:47 --> Final output sent to browser
DEBUG - 2016-09-19 06:45:47 --> Total execution time: 1.0874
INFO - 2016-09-19 06:45:50 --> Config Class Initialized
INFO - 2016-09-19 06:45:50 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:45:50 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:45:51 --> Utf8 Class Initialized
INFO - 2016-09-19 06:45:51 --> URI Class Initialized
INFO - 2016-09-19 06:45:51 --> Router Class Initialized
INFO - 2016-09-19 06:45:51 --> Output Class Initialized
INFO - 2016-09-19 06:45:51 --> Security Class Initialized
DEBUG - 2016-09-19 06:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:45:51 --> Input Class Initialized
INFO - 2016-09-19 06:45:51 --> Language Class Initialized
INFO - 2016-09-19 06:45:51 --> Language Class Initialized
INFO - 2016-09-19 06:45:51 --> Config Class Initialized
INFO - 2016-09-19 06:45:51 --> Loader Class Initialized
INFO - 2016-09-19 06:45:51 --> Helper loaded: url_helper
INFO - 2016-09-19 06:45:51 --> Database Driver Class Initialized
INFO - 2016-09-19 06:45:51 --> Controller Class Initialized
DEBUG - 2016-09-19 06:45:51 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:45:51 --> Model Class Initialized
INFO - 2016-09-19 06:45:51 --> Model Class Initialized
DEBUG - 2016-09-19 06:45:51 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:45:51 --> Database Driver Class Initialized
INFO - 2016-09-19 06:45:51 --> Final output sent to browser
DEBUG - 2016-09-19 06:45:51 --> Total execution time: 0.6816
INFO - 2016-09-19 06:45:58 --> Config Class Initialized
INFO - 2016-09-19 06:45:58 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:45:58 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:45:58 --> Utf8 Class Initialized
INFO - 2016-09-19 06:45:58 --> URI Class Initialized
INFO - 2016-09-19 06:45:58 --> Router Class Initialized
INFO - 2016-09-19 06:45:58 --> Output Class Initialized
INFO - 2016-09-19 06:45:58 --> Security Class Initialized
DEBUG - 2016-09-19 06:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:45:58 --> Input Class Initialized
INFO - 2016-09-19 06:45:58 --> Language Class Initialized
INFO - 2016-09-19 06:45:58 --> Language Class Initialized
INFO - 2016-09-19 06:45:58 --> Config Class Initialized
INFO - 2016-09-19 06:45:58 --> Loader Class Initialized
INFO - 2016-09-19 06:45:58 --> Helper loaded: url_helper
INFO - 2016-09-19 06:45:58 --> Database Driver Class Initialized
INFO - 2016-09-19 06:45:58 --> Controller Class Initialized
DEBUG - 2016-09-19 06:45:58 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:45:58 --> Model Class Initialized
INFO - 2016-09-19 06:45:58 --> Model Class Initialized
DEBUG - 2016-09-19 06:45:58 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:45:58 --> Database Driver Class Initialized
INFO - 2016-09-19 06:45:58 --> Final output sent to browser
DEBUG - 2016-09-19 06:45:58 --> Total execution time: 0.6773
INFO - 2016-09-19 06:47:10 --> Config Class Initialized
INFO - 2016-09-19 06:47:10 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:47:11 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:47:11 --> Utf8 Class Initialized
INFO - 2016-09-19 06:47:11 --> URI Class Initialized
INFO - 2016-09-19 06:47:11 --> Router Class Initialized
INFO - 2016-09-19 06:47:11 --> Output Class Initialized
INFO - 2016-09-19 06:47:11 --> Security Class Initialized
DEBUG - 2016-09-19 06:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:47:11 --> Input Class Initialized
INFO - 2016-09-19 06:47:11 --> Language Class Initialized
INFO - 2016-09-19 06:47:11 --> Language Class Initialized
INFO - 2016-09-19 06:47:11 --> Config Class Initialized
INFO - 2016-09-19 06:47:11 --> Loader Class Initialized
INFO - 2016-09-19 06:47:11 --> Helper loaded: url_helper
INFO - 2016-09-19 06:47:11 --> Database Driver Class Initialized
INFO - 2016-09-19 06:47:11 --> Controller Class Initialized
DEBUG - 2016-09-19 06:47:11 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:47:11 --> Model Class Initialized
INFO - 2016-09-19 06:47:11 --> Model Class Initialized
DEBUG - 2016-09-19 06:47:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 06:47:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 06:47:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 06:47:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 06:47:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 06:47:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 06:47:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 06:47:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 06:47:11 --> Final output sent to browser
DEBUG - 2016-09-19 06:47:11 --> Total execution time: 0.8219
INFO - 2016-09-19 06:47:16 --> Config Class Initialized
INFO - 2016-09-19 06:47:16 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:47:16 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:47:16 --> Utf8 Class Initialized
INFO - 2016-09-19 06:47:16 --> URI Class Initialized
INFO - 2016-09-19 06:47:16 --> Router Class Initialized
INFO - 2016-09-19 06:47:16 --> Output Class Initialized
INFO - 2016-09-19 06:47:16 --> Security Class Initialized
DEBUG - 2016-09-19 06:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:47:16 --> Input Class Initialized
INFO - 2016-09-19 06:47:16 --> Language Class Initialized
INFO - 2016-09-19 06:47:16 --> Language Class Initialized
INFO - 2016-09-19 06:47:16 --> Config Class Initialized
INFO - 2016-09-19 06:47:17 --> Loader Class Initialized
INFO - 2016-09-19 06:47:17 --> Helper loaded: url_helper
INFO - 2016-09-19 06:47:17 --> Database Driver Class Initialized
INFO - 2016-09-19 06:47:17 --> Controller Class Initialized
DEBUG - 2016-09-19 06:47:17 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:47:17 --> Model Class Initialized
INFO - 2016-09-19 06:47:17 --> Model Class Initialized
DEBUG - 2016-09-19 06:47:17 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:47:17 --> Database Driver Class Initialized
INFO - 2016-09-19 06:47:17 --> Final output sent to browser
DEBUG - 2016-09-19 06:47:17 --> Total execution time: 0.7475
INFO - 2016-09-19 06:47:34 --> Config Class Initialized
INFO - 2016-09-19 06:47:34 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:47:34 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:47:34 --> Utf8 Class Initialized
INFO - 2016-09-19 06:47:34 --> URI Class Initialized
INFO - 2016-09-19 06:47:34 --> Router Class Initialized
INFO - 2016-09-19 06:47:34 --> Output Class Initialized
INFO - 2016-09-19 06:47:34 --> Security Class Initialized
DEBUG - 2016-09-19 06:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:47:34 --> Input Class Initialized
INFO - 2016-09-19 06:47:34 --> Language Class Initialized
INFO - 2016-09-19 06:47:34 --> Language Class Initialized
INFO - 2016-09-19 06:47:34 --> Config Class Initialized
INFO - 2016-09-19 06:47:34 --> Loader Class Initialized
INFO - 2016-09-19 06:47:35 --> Helper loaded: url_helper
INFO - 2016-09-19 06:47:35 --> Database Driver Class Initialized
INFO - 2016-09-19 06:47:35 --> Controller Class Initialized
DEBUG - 2016-09-19 06:47:35 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:47:35 --> Model Class Initialized
INFO - 2016-09-19 06:47:35 --> Model Class Initialized
DEBUG - 2016-09-19 06:47:35 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:47:35 --> Database Driver Class Initialized
INFO - 2016-09-19 06:47:35 --> Final output sent to browser
DEBUG - 2016-09-19 06:47:35 --> Total execution time: 0.6872
INFO - 2016-09-19 06:48:11 --> Config Class Initialized
INFO - 2016-09-19 06:48:11 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:48:11 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:48:11 --> Utf8 Class Initialized
INFO - 2016-09-19 06:48:11 --> URI Class Initialized
INFO - 2016-09-19 06:48:11 --> Router Class Initialized
INFO - 2016-09-19 06:48:11 --> Output Class Initialized
INFO - 2016-09-19 06:48:11 --> Security Class Initialized
DEBUG - 2016-09-19 06:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:48:11 --> Input Class Initialized
INFO - 2016-09-19 06:48:11 --> Language Class Initialized
INFO - 2016-09-19 06:48:11 --> Language Class Initialized
INFO - 2016-09-19 06:48:11 --> Config Class Initialized
INFO - 2016-09-19 06:48:11 --> Loader Class Initialized
INFO - 2016-09-19 06:48:11 --> Helper loaded: url_helper
INFO - 2016-09-19 06:48:11 --> Database Driver Class Initialized
INFO - 2016-09-19 06:48:11 --> Controller Class Initialized
DEBUG - 2016-09-19 06:48:11 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:48:11 --> Model Class Initialized
INFO - 2016-09-19 06:48:11 --> Model Class Initialized
DEBUG - 2016-09-19 06:48:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 06:48:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 06:48:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 06:48:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 06:48:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 06:48:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 06:48:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 06:48:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 06:48:12 --> Final output sent to browser
DEBUG - 2016-09-19 06:48:12 --> Total execution time: 0.8389
INFO - 2016-09-19 06:48:18 --> Config Class Initialized
INFO - 2016-09-19 06:48:18 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:48:18 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:48:18 --> Utf8 Class Initialized
INFO - 2016-09-19 06:48:18 --> URI Class Initialized
INFO - 2016-09-19 06:48:18 --> Router Class Initialized
INFO - 2016-09-19 06:48:18 --> Output Class Initialized
INFO - 2016-09-19 06:48:18 --> Security Class Initialized
DEBUG - 2016-09-19 06:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:48:18 --> Input Class Initialized
INFO - 2016-09-19 06:48:18 --> Language Class Initialized
INFO - 2016-09-19 06:48:18 --> Language Class Initialized
INFO - 2016-09-19 06:48:18 --> Config Class Initialized
INFO - 2016-09-19 06:48:18 --> Loader Class Initialized
INFO - 2016-09-19 06:48:18 --> Helper loaded: url_helper
INFO - 2016-09-19 06:48:18 --> Database Driver Class Initialized
INFO - 2016-09-19 06:48:18 --> Controller Class Initialized
DEBUG - 2016-09-19 06:48:18 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:48:18 --> Model Class Initialized
INFO - 2016-09-19 06:48:19 --> Model Class Initialized
DEBUG - 2016-09-19 06:48:19 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:48:19 --> Database Driver Class Initialized
INFO - 2016-09-19 06:48:19 --> Final output sent to browser
DEBUG - 2016-09-19 06:48:19 --> Total execution time: 0.6638
INFO - 2016-09-19 06:48:37 --> Config Class Initialized
INFO - 2016-09-19 06:48:37 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:48:37 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:48:37 --> Utf8 Class Initialized
INFO - 2016-09-19 06:48:37 --> URI Class Initialized
INFO - 2016-09-19 06:48:37 --> Router Class Initialized
INFO - 2016-09-19 06:48:37 --> Output Class Initialized
INFO - 2016-09-19 06:48:37 --> Security Class Initialized
DEBUG - 2016-09-19 06:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:48:37 --> Input Class Initialized
INFO - 2016-09-19 06:48:37 --> Language Class Initialized
INFO - 2016-09-19 06:48:37 --> Language Class Initialized
INFO - 2016-09-19 06:48:37 --> Config Class Initialized
INFO - 2016-09-19 06:48:37 --> Loader Class Initialized
INFO - 2016-09-19 06:48:37 --> Helper loaded: url_helper
INFO - 2016-09-19 06:48:37 --> Database Driver Class Initialized
INFO - 2016-09-19 06:48:37 --> Controller Class Initialized
DEBUG - 2016-09-19 06:48:37 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:48:37 --> Model Class Initialized
INFO - 2016-09-19 06:48:37 --> Model Class Initialized
DEBUG - 2016-09-19 06:48:37 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:48:37 --> Database Driver Class Initialized
INFO - 2016-09-19 06:48:37 --> Final output sent to browser
DEBUG - 2016-09-19 06:48:37 --> Total execution time: 0.6913
INFO - 2016-09-19 06:48:53 --> Config Class Initialized
INFO - 2016-09-19 06:48:53 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:48:54 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:48:54 --> Utf8 Class Initialized
INFO - 2016-09-19 06:48:54 --> URI Class Initialized
INFO - 2016-09-19 06:48:54 --> Router Class Initialized
INFO - 2016-09-19 06:48:54 --> Output Class Initialized
INFO - 2016-09-19 06:48:54 --> Security Class Initialized
DEBUG - 2016-09-19 06:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:48:54 --> Input Class Initialized
INFO - 2016-09-19 06:48:54 --> Language Class Initialized
INFO - 2016-09-19 06:48:54 --> Language Class Initialized
INFO - 2016-09-19 06:48:54 --> Config Class Initialized
INFO - 2016-09-19 06:48:54 --> Loader Class Initialized
INFO - 2016-09-19 06:48:54 --> Helper loaded: url_helper
INFO - 2016-09-19 06:48:54 --> Database Driver Class Initialized
INFO - 2016-09-19 06:48:54 --> Controller Class Initialized
DEBUG - 2016-09-19 06:48:54 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:48:54 --> Model Class Initialized
INFO - 2016-09-19 06:48:54 --> Model Class Initialized
DEBUG - 2016-09-19 06:48:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 06:48:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 06:48:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 06:48:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 06:48:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 06:48:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 06:48:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 06:48:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 06:48:54 --> Final output sent to browser
DEBUG - 2016-09-19 06:48:54 --> Total execution time: 0.8454
INFO - 2016-09-19 06:49:00 --> Config Class Initialized
INFO - 2016-09-19 06:49:00 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:49:00 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:49:00 --> Utf8 Class Initialized
INFO - 2016-09-19 06:49:00 --> URI Class Initialized
INFO - 2016-09-19 06:49:00 --> Router Class Initialized
INFO - 2016-09-19 06:49:00 --> Output Class Initialized
INFO - 2016-09-19 06:49:00 --> Security Class Initialized
DEBUG - 2016-09-19 06:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:49:00 --> Input Class Initialized
INFO - 2016-09-19 06:49:00 --> Language Class Initialized
INFO - 2016-09-19 06:49:00 --> Language Class Initialized
INFO - 2016-09-19 06:49:00 --> Config Class Initialized
INFO - 2016-09-19 06:49:00 --> Loader Class Initialized
INFO - 2016-09-19 06:49:00 --> Helper loaded: url_helper
INFO - 2016-09-19 06:49:00 --> Database Driver Class Initialized
INFO - 2016-09-19 06:49:00 --> Controller Class Initialized
DEBUG - 2016-09-19 06:49:00 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:49:00 --> Model Class Initialized
INFO - 2016-09-19 06:49:00 --> Model Class Initialized
DEBUG - 2016-09-19 06:49:00 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:49:00 --> Database Driver Class Initialized
INFO - 2016-09-19 06:49:00 --> Final output sent to browser
DEBUG - 2016-09-19 06:49:01 --> Total execution time: 0.6877
INFO - 2016-09-19 06:49:04 --> Config Class Initialized
INFO - 2016-09-19 06:49:04 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:49:04 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:49:04 --> Utf8 Class Initialized
INFO - 2016-09-19 06:49:04 --> URI Class Initialized
INFO - 2016-09-19 06:49:04 --> Router Class Initialized
INFO - 2016-09-19 06:49:04 --> Output Class Initialized
INFO - 2016-09-19 06:49:04 --> Security Class Initialized
DEBUG - 2016-09-19 06:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:49:04 --> Input Class Initialized
INFO - 2016-09-19 06:49:04 --> Language Class Initialized
INFO - 2016-09-19 06:49:04 --> Language Class Initialized
INFO - 2016-09-19 06:49:04 --> Config Class Initialized
INFO - 2016-09-19 06:49:04 --> Loader Class Initialized
INFO - 2016-09-19 06:49:04 --> Helper loaded: url_helper
INFO - 2016-09-19 06:49:04 --> Database Driver Class Initialized
INFO - 2016-09-19 06:49:04 --> Controller Class Initialized
DEBUG - 2016-09-19 06:49:04 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:49:05 --> Model Class Initialized
INFO - 2016-09-19 06:49:05 --> Model Class Initialized
DEBUG - 2016-09-19 06:49:05 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:49:05 --> Database Driver Class Initialized
INFO - 2016-09-19 06:49:05 --> Final output sent to browser
DEBUG - 2016-09-19 06:49:05 --> Total execution time: 0.6753
INFO - 2016-09-19 06:49:17 --> Config Class Initialized
INFO - 2016-09-19 06:49:17 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:49:17 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:49:17 --> Utf8 Class Initialized
INFO - 2016-09-19 06:49:17 --> URI Class Initialized
INFO - 2016-09-19 06:49:17 --> Router Class Initialized
INFO - 2016-09-19 06:49:17 --> Output Class Initialized
INFO - 2016-09-19 06:49:17 --> Security Class Initialized
DEBUG - 2016-09-19 06:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:49:17 --> Input Class Initialized
INFO - 2016-09-19 06:49:17 --> Language Class Initialized
INFO - 2016-09-19 06:49:17 --> Language Class Initialized
INFO - 2016-09-19 06:49:17 --> Config Class Initialized
INFO - 2016-09-19 06:49:17 --> Loader Class Initialized
INFO - 2016-09-19 06:49:17 --> Helper loaded: url_helper
INFO - 2016-09-19 06:49:17 --> Database Driver Class Initialized
INFO - 2016-09-19 06:49:17 --> Controller Class Initialized
DEBUG - 2016-09-19 06:49:17 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:49:17 --> Model Class Initialized
INFO - 2016-09-19 06:49:17 --> Model Class Initialized
DEBUG - 2016-09-19 06:49:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 06:49:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 06:49:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 06:49:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 06:49:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 06:49:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 06:49:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 06:49:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 06:49:18 --> Final output sent to browser
DEBUG - 2016-09-19 06:49:18 --> Total execution time: 0.8572
INFO - 2016-09-19 06:49:25 --> Config Class Initialized
INFO - 2016-09-19 06:49:25 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:49:25 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:49:25 --> Utf8 Class Initialized
INFO - 2016-09-19 06:49:25 --> URI Class Initialized
INFO - 2016-09-19 06:49:25 --> Router Class Initialized
INFO - 2016-09-19 06:49:25 --> Output Class Initialized
INFO - 2016-09-19 06:49:25 --> Security Class Initialized
DEBUG - 2016-09-19 06:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:49:25 --> Input Class Initialized
INFO - 2016-09-19 06:49:25 --> Language Class Initialized
INFO - 2016-09-19 06:49:25 --> Language Class Initialized
INFO - 2016-09-19 06:49:25 --> Config Class Initialized
INFO - 2016-09-19 06:49:25 --> Loader Class Initialized
INFO - 2016-09-19 06:49:25 --> Helper loaded: url_helper
INFO - 2016-09-19 06:49:25 --> Database Driver Class Initialized
INFO - 2016-09-19 06:49:25 --> Controller Class Initialized
DEBUG - 2016-09-19 06:49:25 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:49:25 --> Model Class Initialized
INFO - 2016-09-19 06:49:26 --> Model Class Initialized
DEBUG - 2016-09-19 06:49:26 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:49:26 --> Database Driver Class Initialized
INFO - 2016-09-19 06:49:26 --> Final output sent to browser
DEBUG - 2016-09-19 06:49:26 --> Total execution time: 0.6600
INFO - 2016-09-19 06:49:29 --> Config Class Initialized
INFO - 2016-09-19 06:49:29 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:49:29 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:49:29 --> Utf8 Class Initialized
INFO - 2016-09-19 06:49:29 --> URI Class Initialized
INFO - 2016-09-19 06:49:29 --> Router Class Initialized
INFO - 2016-09-19 06:49:29 --> Output Class Initialized
INFO - 2016-09-19 06:49:29 --> Security Class Initialized
DEBUG - 2016-09-19 06:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:49:29 --> Input Class Initialized
INFO - 2016-09-19 06:49:29 --> Language Class Initialized
INFO - 2016-09-19 06:49:29 --> Language Class Initialized
INFO - 2016-09-19 06:49:29 --> Config Class Initialized
INFO - 2016-09-19 06:49:30 --> Loader Class Initialized
INFO - 2016-09-19 06:49:30 --> Helper loaded: url_helper
INFO - 2016-09-19 06:49:30 --> Database Driver Class Initialized
INFO - 2016-09-19 06:49:30 --> Controller Class Initialized
DEBUG - 2016-09-19 06:49:30 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:49:30 --> Model Class Initialized
INFO - 2016-09-19 06:49:30 --> Model Class Initialized
DEBUG - 2016-09-19 06:49:30 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:49:30 --> Database Driver Class Initialized
INFO - 2016-09-19 06:49:30 --> Final output sent to browser
DEBUG - 2016-09-19 06:49:30 --> Total execution time: 0.6521
INFO - 2016-09-19 06:56:04 --> Config Class Initialized
INFO - 2016-09-19 06:56:04 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:56:04 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:56:04 --> Utf8 Class Initialized
INFO - 2016-09-19 06:56:04 --> URI Class Initialized
INFO - 2016-09-19 06:56:04 --> Router Class Initialized
INFO - 2016-09-19 06:56:04 --> Output Class Initialized
INFO - 2016-09-19 06:56:04 --> Security Class Initialized
DEBUG - 2016-09-19 06:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:56:04 --> Input Class Initialized
INFO - 2016-09-19 06:56:04 --> Language Class Initialized
INFO - 2016-09-19 06:56:04 --> Language Class Initialized
INFO - 2016-09-19 06:56:04 --> Config Class Initialized
INFO - 2016-09-19 06:56:04 --> Loader Class Initialized
INFO - 2016-09-19 06:56:04 --> Helper loaded: url_helper
INFO - 2016-09-19 06:56:04 --> Database Driver Class Initialized
INFO - 2016-09-19 06:56:04 --> Controller Class Initialized
DEBUG - 2016-09-19 06:56:05 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:56:05 --> Model Class Initialized
INFO - 2016-09-19 06:56:05 --> Model Class Initialized
DEBUG - 2016-09-19 06:56:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 06:56:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 06:56:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 06:56:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 06:56:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 06:56:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 06:56:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 06:56:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 06:56:05 --> Final output sent to browser
DEBUG - 2016-09-19 06:56:05 --> Total execution time: 0.8865
INFO - 2016-09-19 06:56:11 --> Config Class Initialized
INFO - 2016-09-19 06:56:11 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:56:11 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:56:11 --> Utf8 Class Initialized
INFO - 2016-09-19 06:56:11 --> URI Class Initialized
INFO - 2016-09-19 06:56:11 --> Router Class Initialized
INFO - 2016-09-19 06:56:11 --> Output Class Initialized
INFO - 2016-09-19 06:56:11 --> Security Class Initialized
DEBUG - 2016-09-19 06:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:56:11 --> Input Class Initialized
INFO - 2016-09-19 06:56:11 --> Language Class Initialized
INFO - 2016-09-19 06:56:11 --> Language Class Initialized
INFO - 2016-09-19 06:56:11 --> Config Class Initialized
INFO - 2016-09-19 06:56:11 --> Loader Class Initialized
INFO - 2016-09-19 06:56:11 --> Helper loaded: url_helper
INFO - 2016-09-19 06:56:11 --> Database Driver Class Initialized
INFO - 2016-09-19 06:56:11 --> Controller Class Initialized
DEBUG - 2016-09-19 06:56:12 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:56:12 --> Model Class Initialized
INFO - 2016-09-19 06:56:12 --> Model Class Initialized
DEBUG - 2016-09-19 06:56:12 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:56:12 --> Database Driver Class Initialized
INFO - 2016-09-19 06:56:12 --> Final output sent to browser
DEBUG - 2016-09-19 06:56:12 --> Total execution time: 0.6599
INFO - 2016-09-19 06:56:25 --> Config Class Initialized
INFO - 2016-09-19 06:56:25 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:56:25 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:56:25 --> Utf8 Class Initialized
INFO - 2016-09-19 06:56:25 --> URI Class Initialized
INFO - 2016-09-19 06:56:25 --> Router Class Initialized
INFO - 2016-09-19 06:56:25 --> Output Class Initialized
INFO - 2016-09-19 06:56:25 --> Security Class Initialized
DEBUG - 2016-09-19 06:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:56:25 --> Input Class Initialized
INFO - 2016-09-19 06:56:25 --> Language Class Initialized
INFO - 2016-09-19 06:56:25 --> Language Class Initialized
INFO - 2016-09-19 06:56:25 --> Config Class Initialized
INFO - 2016-09-19 06:56:25 --> Loader Class Initialized
INFO - 2016-09-19 06:56:25 --> Helper loaded: url_helper
INFO - 2016-09-19 06:56:25 --> Database Driver Class Initialized
INFO - 2016-09-19 06:56:25 --> Controller Class Initialized
DEBUG - 2016-09-19 06:56:25 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:56:25 --> Model Class Initialized
INFO - 2016-09-19 06:56:25 --> Model Class Initialized
DEBUG - 2016-09-19 06:56:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 06:56:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 06:56:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 06:56:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 06:56:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 06:56:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 06:56:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 06:56:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 06:56:25 --> Final output sent to browser
DEBUG - 2016-09-19 06:56:26 --> Total execution time: 0.9090
INFO - 2016-09-19 06:56:31 --> Config Class Initialized
INFO - 2016-09-19 06:56:31 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:56:31 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:56:31 --> Utf8 Class Initialized
INFO - 2016-09-19 06:56:31 --> URI Class Initialized
INFO - 2016-09-19 06:56:31 --> Router Class Initialized
INFO - 2016-09-19 06:56:32 --> Output Class Initialized
INFO - 2016-09-19 06:56:32 --> Security Class Initialized
DEBUG - 2016-09-19 06:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:56:32 --> Input Class Initialized
INFO - 2016-09-19 06:56:32 --> Language Class Initialized
INFO - 2016-09-19 06:56:32 --> Language Class Initialized
INFO - 2016-09-19 06:56:32 --> Config Class Initialized
INFO - 2016-09-19 06:56:32 --> Loader Class Initialized
INFO - 2016-09-19 06:56:32 --> Helper loaded: url_helper
INFO - 2016-09-19 06:56:32 --> Database Driver Class Initialized
INFO - 2016-09-19 06:56:32 --> Controller Class Initialized
DEBUG - 2016-09-19 06:56:32 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:56:32 --> Model Class Initialized
INFO - 2016-09-19 06:56:32 --> Model Class Initialized
DEBUG - 2016-09-19 06:56:32 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:56:32 --> Database Driver Class Initialized
INFO - 2016-09-19 06:56:32 --> Final output sent to browser
DEBUG - 2016-09-19 06:56:32 --> Total execution time: 0.7271
INFO - 2016-09-19 06:56:36 --> Config Class Initialized
INFO - 2016-09-19 06:56:36 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:56:36 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:56:36 --> Utf8 Class Initialized
INFO - 2016-09-19 06:56:36 --> URI Class Initialized
INFO - 2016-09-19 06:56:36 --> Router Class Initialized
INFO - 2016-09-19 06:56:37 --> Output Class Initialized
INFO - 2016-09-19 06:56:37 --> Security Class Initialized
DEBUG - 2016-09-19 06:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:56:37 --> Input Class Initialized
INFO - 2016-09-19 06:56:37 --> Language Class Initialized
INFO - 2016-09-19 06:56:37 --> Language Class Initialized
INFO - 2016-09-19 06:56:37 --> Config Class Initialized
INFO - 2016-09-19 06:56:37 --> Loader Class Initialized
INFO - 2016-09-19 06:56:37 --> Helper loaded: url_helper
INFO - 2016-09-19 06:56:37 --> Database Driver Class Initialized
INFO - 2016-09-19 06:56:37 --> Controller Class Initialized
DEBUG - 2016-09-19 06:56:37 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:56:37 --> Model Class Initialized
INFO - 2016-09-19 06:56:37 --> Model Class Initialized
DEBUG - 2016-09-19 06:56:37 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:56:37 --> Database Driver Class Initialized
INFO - 2016-09-19 06:56:37 --> Final output sent to browser
DEBUG - 2016-09-19 06:56:37 --> Total execution time: 0.6769
INFO - 2016-09-19 06:56:48 --> Config Class Initialized
INFO - 2016-09-19 06:56:48 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:56:48 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:56:48 --> Utf8 Class Initialized
INFO - 2016-09-19 06:56:48 --> URI Class Initialized
INFO - 2016-09-19 06:56:48 --> Router Class Initialized
INFO - 2016-09-19 06:56:48 --> Output Class Initialized
INFO - 2016-09-19 06:56:48 --> Security Class Initialized
DEBUG - 2016-09-19 06:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:56:49 --> Input Class Initialized
INFO - 2016-09-19 06:56:49 --> Language Class Initialized
INFO - 2016-09-19 06:56:49 --> Language Class Initialized
INFO - 2016-09-19 06:56:49 --> Config Class Initialized
INFO - 2016-09-19 06:56:49 --> Loader Class Initialized
INFO - 2016-09-19 06:56:49 --> Helper loaded: url_helper
INFO - 2016-09-19 06:56:49 --> Database Driver Class Initialized
INFO - 2016-09-19 06:56:49 --> Controller Class Initialized
DEBUG - 2016-09-19 06:56:49 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:56:49 --> Model Class Initialized
INFO - 2016-09-19 06:56:49 --> Model Class Initialized
DEBUG - 2016-09-19 06:56:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 06:56:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 06:56:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 06:56:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 06:56:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 06:56:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 06:56:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 06:56:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 06:56:49 --> Final output sent to browser
DEBUG - 2016-09-19 06:56:49 --> Total execution time: 0.8724
INFO - 2016-09-19 06:56:54 --> Config Class Initialized
INFO - 2016-09-19 06:56:54 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:56:54 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:56:54 --> Utf8 Class Initialized
INFO - 2016-09-19 06:56:54 --> URI Class Initialized
INFO - 2016-09-19 06:56:54 --> Router Class Initialized
INFO - 2016-09-19 06:56:54 --> Output Class Initialized
INFO - 2016-09-19 06:56:54 --> Security Class Initialized
DEBUG - 2016-09-19 06:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:56:54 --> Input Class Initialized
INFO - 2016-09-19 06:56:54 --> Language Class Initialized
INFO - 2016-09-19 06:56:54 --> Language Class Initialized
INFO - 2016-09-19 06:56:54 --> Config Class Initialized
INFO - 2016-09-19 06:56:54 --> Loader Class Initialized
INFO - 2016-09-19 06:56:54 --> Helper loaded: url_helper
INFO - 2016-09-19 06:56:54 --> Database Driver Class Initialized
INFO - 2016-09-19 06:56:54 --> Controller Class Initialized
DEBUG - 2016-09-19 06:56:54 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:56:54 --> Model Class Initialized
INFO - 2016-09-19 06:56:54 --> Model Class Initialized
DEBUG - 2016-09-19 06:56:54 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:56:54 --> Database Driver Class Initialized
INFO - 2016-09-19 06:56:54 --> Final output sent to browser
DEBUG - 2016-09-19 06:56:54 --> Total execution time: 0.7464
INFO - 2016-09-19 06:56:58 --> Config Class Initialized
INFO - 2016-09-19 06:56:58 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:56:58 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:56:58 --> Utf8 Class Initialized
INFO - 2016-09-19 06:56:58 --> URI Class Initialized
INFO - 2016-09-19 06:56:58 --> Router Class Initialized
INFO - 2016-09-19 06:56:58 --> Output Class Initialized
INFO - 2016-09-19 06:56:58 --> Security Class Initialized
DEBUG - 2016-09-19 06:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:56:58 --> Input Class Initialized
INFO - 2016-09-19 06:56:58 --> Language Class Initialized
INFO - 2016-09-19 06:56:58 --> Language Class Initialized
INFO - 2016-09-19 06:56:58 --> Config Class Initialized
INFO - 2016-09-19 06:56:58 --> Loader Class Initialized
INFO - 2016-09-19 06:56:58 --> Helper loaded: url_helper
INFO - 2016-09-19 06:56:58 --> Database Driver Class Initialized
INFO - 2016-09-19 06:56:58 --> Controller Class Initialized
DEBUG - 2016-09-19 06:56:58 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:56:58 --> Model Class Initialized
INFO - 2016-09-19 06:56:59 --> Model Class Initialized
DEBUG - 2016-09-19 06:56:59 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:56:59 --> Database Driver Class Initialized
INFO - 2016-09-19 06:56:59 --> Final output sent to browser
DEBUG - 2016-09-19 06:56:59 --> Total execution time: 0.6572
INFO - 2016-09-19 06:57:01 --> Config Class Initialized
INFO - 2016-09-19 06:57:01 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:57:01 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:57:01 --> Utf8 Class Initialized
INFO - 2016-09-19 06:57:01 --> URI Class Initialized
INFO - 2016-09-19 06:57:01 --> Router Class Initialized
INFO - 2016-09-19 06:57:01 --> Output Class Initialized
INFO - 2016-09-19 06:57:01 --> Security Class Initialized
DEBUG - 2016-09-19 06:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:57:01 --> Input Class Initialized
INFO - 2016-09-19 06:57:01 --> Language Class Initialized
INFO - 2016-09-19 06:57:01 --> Language Class Initialized
INFO - 2016-09-19 06:57:01 --> Config Class Initialized
INFO - 2016-09-19 06:57:01 --> Loader Class Initialized
INFO - 2016-09-19 06:57:01 --> Helper loaded: url_helper
INFO - 2016-09-19 06:57:01 --> Database Driver Class Initialized
INFO - 2016-09-19 06:57:01 --> Controller Class Initialized
DEBUG - 2016-09-19 06:57:01 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:57:01 --> Model Class Initialized
INFO - 2016-09-19 06:57:01 --> Model Class Initialized
DEBUG - 2016-09-19 06:57:01 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:57:01 --> Database Driver Class Initialized
INFO - 2016-09-19 06:57:01 --> Final output sent to browser
DEBUG - 2016-09-19 06:57:01 --> Total execution time: 0.7838
INFO - 2016-09-19 06:57:02 --> Config Class Initialized
INFO - 2016-09-19 06:57:02 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:57:02 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:57:02 --> Utf8 Class Initialized
INFO - 2016-09-19 06:57:02 --> URI Class Initialized
INFO - 2016-09-19 06:57:02 --> Router Class Initialized
INFO - 2016-09-19 06:57:02 --> Output Class Initialized
INFO - 2016-09-19 06:57:02 --> Security Class Initialized
DEBUG - 2016-09-19 06:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:57:02 --> Input Class Initialized
INFO - 2016-09-19 06:57:02 --> Language Class Initialized
INFO - 2016-09-19 06:57:02 --> Language Class Initialized
INFO - 2016-09-19 06:57:02 --> Config Class Initialized
INFO - 2016-09-19 06:57:02 --> Loader Class Initialized
INFO - 2016-09-19 06:57:02 --> Helper loaded: url_helper
INFO - 2016-09-19 06:57:03 --> Database Driver Class Initialized
INFO - 2016-09-19 06:57:03 --> Controller Class Initialized
DEBUG - 2016-09-19 06:57:03 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:57:03 --> Model Class Initialized
INFO - 2016-09-19 06:57:03 --> Model Class Initialized
DEBUG - 2016-09-19 06:57:03 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:57:03 --> Database Driver Class Initialized
INFO - 2016-09-19 06:57:03 --> Final output sent to browser
DEBUG - 2016-09-19 06:57:03 --> Total execution time: 0.6637
INFO - 2016-09-19 06:57:03 --> Config Class Initialized
INFO - 2016-09-19 06:57:03 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:57:03 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:57:03 --> Utf8 Class Initialized
INFO - 2016-09-19 06:57:03 --> URI Class Initialized
INFO - 2016-09-19 06:57:03 --> Router Class Initialized
INFO - 2016-09-19 06:57:03 --> Output Class Initialized
INFO - 2016-09-19 06:57:03 --> Security Class Initialized
DEBUG - 2016-09-19 06:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:57:04 --> Input Class Initialized
INFO - 2016-09-19 06:57:04 --> Language Class Initialized
INFO - 2016-09-19 06:57:04 --> Language Class Initialized
INFO - 2016-09-19 06:57:04 --> Config Class Initialized
INFO - 2016-09-19 06:57:04 --> Loader Class Initialized
INFO - 2016-09-19 06:57:04 --> Helper loaded: url_helper
INFO - 2016-09-19 06:57:04 --> Database Driver Class Initialized
INFO - 2016-09-19 06:57:04 --> Controller Class Initialized
DEBUG - 2016-09-19 06:57:04 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:57:04 --> Model Class Initialized
INFO - 2016-09-19 06:57:04 --> Model Class Initialized
DEBUG - 2016-09-19 06:57:04 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:57:04 --> Database Driver Class Initialized
INFO - 2016-09-19 06:57:04 --> Final output sent to browser
DEBUG - 2016-09-19 06:57:04 --> Total execution time: 0.6564
INFO - 2016-09-19 06:57:04 --> Config Class Initialized
INFO - 2016-09-19 06:57:04 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:57:04 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:57:04 --> Utf8 Class Initialized
INFO - 2016-09-19 06:57:04 --> URI Class Initialized
INFO - 2016-09-19 06:57:05 --> Router Class Initialized
INFO - 2016-09-19 06:57:05 --> Output Class Initialized
INFO - 2016-09-19 06:57:05 --> Security Class Initialized
DEBUG - 2016-09-19 06:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:57:05 --> Input Class Initialized
INFO - 2016-09-19 06:57:05 --> Language Class Initialized
INFO - 2016-09-19 06:57:05 --> Language Class Initialized
INFO - 2016-09-19 06:57:05 --> Config Class Initialized
INFO - 2016-09-19 06:57:05 --> Loader Class Initialized
INFO - 2016-09-19 06:57:05 --> Helper loaded: url_helper
INFO - 2016-09-19 06:57:05 --> Database Driver Class Initialized
INFO - 2016-09-19 06:57:05 --> Controller Class Initialized
DEBUG - 2016-09-19 06:57:05 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:57:05 --> Model Class Initialized
INFO - 2016-09-19 06:57:05 --> Model Class Initialized
DEBUG - 2016-09-19 06:57:05 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:57:05 --> Database Driver Class Initialized
INFO - 2016-09-19 06:57:05 --> Final output sent to browser
DEBUG - 2016-09-19 06:57:05 --> Total execution time: 0.6602
INFO - 2016-09-19 06:58:57 --> Config Class Initialized
INFO - 2016-09-19 06:58:57 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:58:57 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:58:57 --> Utf8 Class Initialized
INFO - 2016-09-19 06:58:57 --> URI Class Initialized
INFO - 2016-09-19 06:58:57 --> Router Class Initialized
INFO - 2016-09-19 06:58:57 --> Output Class Initialized
INFO - 2016-09-19 06:58:57 --> Security Class Initialized
DEBUG - 2016-09-19 06:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:58:57 --> Input Class Initialized
INFO - 2016-09-19 06:58:57 --> Language Class Initialized
INFO - 2016-09-19 06:58:57 --> Language Class Initialized
INFO - 2016-09-19 06:58:57 --> Config Class Initialized
INFO - 2016-09-19 06:58:57 --> Loader Class Initialized
INFO - 2016-09-19 06:58:57 --> Helper loaded: url_helper
INFO - 2016-09-19 06:58:57 --> Database Driver Class Initialized
INFO - 2016-09-19 06:58:58 --> Controller Class Initialized
DEBUG - 2016-09-19 06:58:58 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:58:58 --> Model Class Initialized
INFO - 2016-09-19 06:58:58 --> Model Class Initialized
DEBUG - 2016-09-19 06:58:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 06:58:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 06:58:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 06:58:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 06:58:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 06:58:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 06:58:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 06:58:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 06:58:58 --> Final output sent to browser
DEBUG - 2016-09-19 06:58:58 --> Total execution time: 1.1334
INFO - 2016-09-19 06:59:05 --> Config Class Initialized
INFO - 2016-09-19 06:59:05 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:59:05 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:59:05 --> Utf8 Class Initialized
INFO - 2016-09-19 06:59:05 --> URI Class Initialized
INFO - 2016-09-19 06:59:05 --> Router Class Initialized
INFO - 2016-09-19 06:59:05 --> Output Class Initialized
INFO - 2016-09-19 06:59:05 --> Security Class Initialized
DEBUG - 2016-09-19 06:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:59:05 --> Input Class Initialized
INFO - 2016-09-19 06:59:05 --> Language Class Initialized
INFO - 2016-09-19 06:59:05 --> Language Class Initialized
INFO - 2016-09-19 06:59:05 --> Config Class Initialized
INFO - 2016-09-19 06:59:05 --> Loader Class Initialized
INFO - 2016-09-19 06:59:05 --> Helper loaded: url_helper
INFO - 2016-09-19 06:59:05 --> Database Driver Class Initialized
INFO - 2016-09-19 06:59:06 --> Controller Class Initialized
DEBUG - 2016-09-19 06:59:06 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:59:06 --> Model Class Initialized
INFO - 2016-09-19 06:59:06 --> Model Class Initialized
DEBUG - 2016-09-19 06:59:06 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:59:06 --> Database Driver Class Initialized
INFO - 2016-09-19 06:59:06 --> Final output sent to browser
DEBUG - 2016-09-19 06:59:06 --> Total execution time: 0.8012
INFO - 2016-09-19 06:59:15 --> Config Class Initialized
INFO - 2016-09-19 06:59:15 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:59:15 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:59:15 --> Utf8 Class Initialized
INFO - 2016-09-19 06:59:15 --> URI Class Initialized
INFO - 2016-09-19 06:59:15 --> Router Class Initialized
INFO - 2016-09-19 06:59:15 --> Output Class Initialized
INFO - 2016-09-19 06:59:15 --> Security Class Initialized
DEBUG - 2016-09-19 06:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:59:15 --> Input Class Initialized
INFO - 2016-09-19 06:59:15 --> Language Class Initialized
INFO - 2016-09-19 06:59:15 --> Language Class Initialized
INFO - 2016-09-19 06:59:15 --> Config Class Initialized
INFO - 2016-09-19 06:59:15 --> Loader Class Initialized
INFO - 2016-09-19 06:59:15 --> Helper loaded: url_helper
INFO - 2016-09-19 06:59:15 --> Database Driver Class Initialized
INFO - 2016-09-19 06:59:15 --> Controller Class Initialized
DEBUG - 2016-09-19 06:59:15 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:59:15 --> Model Class Initialized
INFO - 2016-09-19 06:59:16 --> Model Class Initialized
DEBUG - 2016-09-19 06:59:16 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:59:16 --> Database Driver Class Initialized
INFO - 2016-09-19 06:59:16 --> Final output sent to browser
DEBUG - 2016-09-19 06:59:16 --> Total execution time: 0.9823
INFO - 2016-09-19 06:59:16 --> Config Class Initialized
INFO - 2016-09-19 06:59:16 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:59:16 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:59:16 --> Utf8 Class Initialized
INFO - 2016-09-19 06:59:16 --> URI Class Initialized
INFO - 2016-09-19 06:59:16 --> Router Class Initialized
INFO - 2016-09-19 06:59:16 --> Output Class Initialized
INFO - 2016-09-19 06:59:16 --> Security Class Initialized
DEBUG - 2016-09-19 06:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:59:16 --> Input Class Initialized
INFO - 2016-09-19 06:59:17 --> Language Class Initialized
INFO - 2016-09-19 06:59:17 --> Language Class Initialized
INFO - 2016-09-19 06:59:17 --> Config Class Initialized
INFO - 2016-09-19 06:59:17 --> Loader Class Initialized
INFO - 2016-09-19 06:59:17 --> Helper loaded: url_helper
INFO - 2016-09-19 06:59:17 --> Database Driver Class Initialized
INFO - 2016-09-19 06:59:17 --> Controller Class Initialized
DEBUG - 2016-09-19 06:59:17 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:59:17 --> Model Class Initialized
INFO - 2016-09-19 06:59:17 --> Model Class Initialized
DEBUG - 2016-09-19 06:59:17 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:59:17 --> Database Driver Class Initialized
INFO - 2016-09-19 06:59:17 --> Final output sent to browser
DEBUG - 2016-09-19 06:59:17 --> Total execution time: 1.0271
INFO - 2016-09-19 06:59:19 --> Config Class Initialized
INFO - 2016-09-19 06:59:19 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:59:19 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:59:19 --> Utf8 Class Initialized
INFO - 2016-09-19 06:59:19 --> URI Class Initialized
INFO - 2016-09-19 06:59:19 --> Router Class Initialized
INFO - 2016-09-19 06:59:19 --> Output Class Initialized
INFO - 2016-09-19 06:59:19 --> Security Class Initialized
DEBUG - 2016-09-19 06:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:59:19 --> Input Class Initialized
INFO - 2016-09-19 06:59:19 --> Language Class Initialized
INFO - 2016-09-19 06:59:19 --> Language Class Initialized
INFO - 2016-09-19 06:59:19 --> Config Class Initialized
INFO - 2016-09-19 06:59:19 --> Loader Class Initialized
INFO - 2016-09-19 06:59:19 --> Helper loaded: url_helper
INFO - 2016-09-19 06:59:19 --> Database Driver Class Initialized
INFO - 2016-09-19 06:59:19 --> Controller Class Initialized
DEBUG - 2016-09-19 06:59:19 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:59:19 --> Model Class Initialized
INFO - 2016-09-19 06:59:19 --> Model Class Initialized
DEBUG - 2016-09-19 06:59:19 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:59:19 --> Database Driver Class Initialized
INFO - 2016-09-19 06:59:20 --> Final output sent to browser
DEBUG - 2016-09-19 06:59:20 --> Total execution time: 0.8604
INFO - 2016-09-19 06:59:22 --> Config Class Initialized
INFO - 2016-09-19 06:59:22 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:59:22 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:59:22 --> Utf8 Class Initialized
INFO - 2016-09-19 06:59:22 --> URI Class Initialized
INFO - 2016-09-19 06:59:22 --> Router Class Initialized
INFO - 2016-09-19 06:59:22 --> Output Class Initialized
INFO - 2016-09-19 06:59:22 --> Security Class Initialized
DEBUG - 2016-09-19 06:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:59:22 --> Input Class Initialized
INFO - 2016-09-19 06:59:22 --> Language Class Initialized
INFO - 2016-09-19 06:59:22 --> Language Class Initialized
INFO - 2016-09-19 06:59:22 --> Config Class Initialized
INFO - 2016-09-19 06:59:22 --> Loader Class Initialized
INFO - 2016-09-19 06:59:22 --> Helper loaded: url_helper
INFO - 2016-09-19 06:59:22 --> Database Driver Class Initialized
INFO - 2016-09-19 06:59:22 --> Controller Class Initialized
DEBUG - 2016-09-19 06:59:22 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:59:22 --> Model Class Initialized
INFO - 2016-09-19 06:59:22 --> Model Class Initialized
DEBUG - 2016-09-19 06:59:22 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:59:22 --> Database Driver Class Initialized
INFO - 2016-09-19 06:59:22 --> Final output sent to browser
DEBUG - 2016-09-19 06:59:22 --> Total execution time: 0.8107
INFO - 2016-09-19 06:59:41 --> Config Class Initialized
INFO - 2016-09-19 06:59:41 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:59:41 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:59:41 --> Utf8 Class Initialized
INFO - 2016-09-19 06:59:41 --> URI Class Initialized
INFO - 2016-09-19 06:59:41 --> Router Class Initialized
INFO - 2016-09-19 06:59:41 --> Output Class Initialized
INFO - 2016-09-19 06:59:41 --> Security Class Initialized
DEBUG - 2016-09-19 06:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:59:41 --> Input Class Initialized
INFO - 2016-09-19 06:59:41 --> Language Class Initialized
INFO - 2016-09-19 06:59:41 --> Language Class Initialized
INFO - 2016-09-19 06:59:41 --> Config Class Initialized
INFO - 2016-09-19 06:59:41 --> Loader Class Initialized
INFO - 2016-09-19 06:59:41 --> Helper loaded: url_helper
INFO - 2016-09-19 06:59:41 --> Database Driver Class Initialized
INFO - 2016-09-19 06:59:41 --> Controller Class Initialized
DEBUG - 2016-09-19 06:59:41 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:59:41 --> Model Class Initialized
INFO - 2016-09-19 06:59:41 --> Model Class Initialized
DEBUG - 2016-09-19 06:59:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 06:59:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 06:59:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 06:59:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 06:59:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 06:59:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 06:59:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 06:59:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 06:59:42 --> Final output sent to browser
DEBUG - 2016-09-19 06:59:42 --> Total execution time: 1.1089
INFO - 2016-09-19 06:59:47 --> Config Class Initialized
INFO - 2016-09-19 06:59:47 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:59:47 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:59:47 --> Utf8 Class Initialized
INFO - 2016-09-19 06:59:47 --> URI Class Initialized
INFO - 2016-09-19 06:59:47 --> Router Class Initialized
INFO - 2016-09-19 06:59:47 --> Output Class Initialized
INFO - 2016-09-19 06:59:47 --> Security Class Initialized
DEBUG - 2016-09-19 06:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:59:47 --> Input Class Initialized
INFO - 2016-09-19 06:59:47 --> Language Class Initialized
INFO - 2016-09-19 06:59:47 --> Language Class Initialized
INFO - 2016-09-19 06:59:47 --> Config Class Initialized
INFO - 2016-09-19 06:59:47 --> Loader Class Initialized
INFO - 2016-09-19 06:59:47 --> Helper loaded: url_helper
INFO - 2016-09-19 06:59:47 --> Database Driver Class Initialized
INFO - 2016-09-19 06:59:47 --> Controller Class Initialized
DEBUG - 2016-09-19 06:59:47 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:59:47 --> Model Class Initialized
INFO - 2016-09-19 06:59:47 --> Model Class Initialized
DEBUG - 2016-09-19 06:59:47 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:59:48 --> Database Driver Class Initialized
INFO - 2016-09-19 06:59:48 --> Final output sent to browser
DEBUG - 2016-09-19 06:59:48 --> Total execution time: 0.6999
INFO - 2016-09-19 06:59:50 --> Config Class Initialized
INFO - 2016-09-19 06:59:50 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:59:50 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:59:50 --> Utf8 Class Initialized
INFO - 2016-09-19 06:59:50 --> URI Class Initialized
INFO - 2016-09-19 06:59:50 --> Router Class Initialized
INFO - 2016-09-19 06:59:50 --> Output Class Initialized
INFO - 2016-09-19 06:59:50 --> Security Class Initialized
DEBUG - 2016-09-19 06:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:59:50 --> Input Class Initialized
INFO - 2016-09-19 06:59:50 --> Language Class Initialized
INFO - 2016-09-19 06:59:50 --> Language Class Initialized
INFO - 2016-09-19 06:59:50 --> Config Class Initialized
INFO - 2016-09-19 06:59:50 --> Loader Class Initialized
INFO - 2016-09-19 06:59:50 --> Helper loaded: url_helper
INFO - 2016-09-19 06:59:50 --> Database Driver Class Initialized
INFO - 2016-09-19 06:59:50 --> Controller Class Initialized
DEBUG - 2016-09-19 06:59:50 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:59:50 --> Model Class Initialized
INFO - 2016-09-19 06:59:50 --> Model Class Initialized
DEBUG - 2016-09-19 06:59:50 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:59:50 --> Database Driver Class Initialized
INFO - 2016-09-19 06:59:50 --> Final output sent to browser
DEBUG - 2016-09-19 06:59:50 --> Total execution time: 0.7692
INFO - 2016-09-19 06:59:53 --> Config Class Initialized
INFO - 2016-09-19 06:59:53 --> Hooks Class Initialized
DEBUG - 2016-09-19 06:59:53 --> UTF-8 Support Enabled
INFO - 2016-09-19 06:59:53 --> Utf8 Class Initialized
INFO - 2016-09-19 06:59:53 --> URI Class Initialized
INFO - 2016-09-19 06:59:53 --> Router Class Initialized
INFO - 2016-09-19 06:59:53 --> Output Class Initialized
INFO - 2016-09-19 06:59:53 --> Security Class Initialized
DEBUG - 2016-09-19 06:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 06:59:53 --> Input Class Initialized
INFO - 2016-09-19 06:59:53 --> Language Class Initialized
INFO - 2016-09-19 06:59:53 --> Language Class Initialized
INFO - 2016-09-19 06:59:53 --> Config Class Initialized
INFO - 2016-09-19 06:59:53 --> Loader Class Initialized
INFO - 2016-09-19 06:59:53 --> Helper loaded: url_helper
INFO - 2016-09-19 06:59:53 --> Database Driver Class Initialized
INFO - 2016-09-19 06:59:53 --> Controller Class Initialized
DEBUG - 2016-09-19 06:59:53 --> Index MX_Controller Initialized
INFO - 2016-09-19 06:59:53 --> Model Class Initialized
INFO - 2016-09-19 06:59:53 --> Model Class Initialized
DEBUG - 2016-09-19 06:59:53 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 06:59:53 --> Database Driver Class Initialized
INFO - 2016-09-19 06:59:54 --> Final output sent to browser
DEBUG - 2016-09-19 06:59:54 --> Total execution time: 0.7540
INFO - 2016-09-19 07:04:25 --> Config Class Initialized
INFO - 2016-09-19 07:04:25 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:04:25 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:04:25 --> Utf8 Class Initialized
INFO - 2016-09-19 07:04:25 --> URI Class Initialized
INFO - 2016-09-19 07:04:25 --> Router Class Initialized
INFO - 2016-09-19 07:04:25 --> Output Class Initialized
INFO - 2016-09-19 07:04:25 --> Security Class Initialized
DEBUG - 2016-09-19 07:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:04:25 --> Input Class Initialized
INFO - 2016-09-19 07:04:25 --> Language Class Initialized
INFO - 2016-09-19 07:04:25 --> Language Class Initialized
INFO - 2016-09-19 07:04:25 --> Config Class Initialized
INFO - 2016-09-19 07:04:25 --> Loader Class Initialized
INFO - 2016-09-19 07:04:25 --> Helper loaded: url_helper
INFO - 2016-09-19 07:04:25 --> Database Driver Class Initialized
INFO - 2016-09-19 07:04:25 --> Controller Class Initialized
DEBUG - 2016-09-19 07:04:25 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:04:25 --> Model Class Initialized
INFO - 2016-09-19 07:04:25 --> Model Class Initialized
DEBUG - 2016-09-19 07:04:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 07:04:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 07:04:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 07:04:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 07:04:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 07:04:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 07:04:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 07:04:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 07:04:25 --> Final output sent to browser
DEBUG - 2016-09-19 07:04:25 --> Total execution time: 0.8756
INFO - 2016-09-19 07:04:30 --> Config Class Initialized
INFO - 2016-09-19 07:04:30 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:04:30 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:04:30 --> Utf8 Class Initialized
INFO - 2016-09-19 07:04:30 --> URI Class Initialized
INFO - 2016-09-19 07:04:30 --> Router Class Initialized
INFO - 2016-09-19 07:04:30 --> Output Class Initialized
INFO - 2016-09-19 07:04:30 --> Security Class Initialized
DEBUG - 2016-09-19 07:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:04:30 --> Input Class Initialized
INFO - 2016-09-19 07:04:30 --> Language Class Initialized
INFO - 2016-09-19 07:04:30 --> Language Class Initialized
INFO - 2016-09-19 07:04:30 --> Config Class Initialized
INFO - 2016-09-19 07:04:30 --> Loader Class Initialized
INFO - 2016-09-19 07:04:30 --> Helper loaded: url_helper
INFO - 2016-09-19 07:04:30 --> Database Driver Class Initialized
INFO - 2016-09-19 07:04:30 --> Controller Class Initialized
DEBUG - 2016-09-19 07:04:31 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:04:31 --> Model Class Initialized
INFO - 2016-09-19 07:04:31 --> Model Class Initialized
DEBUG - 2016-09-19 07:04:31 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 07:04:31 --> Database Driver Class Initialized
INFO - 2016-09-19 07:04:31 --> Final output sent to browser
DEBUG - 2016-09-19 07:04:31 --> Total execution time: 0.7147
INFO - 2016-09-19 07:04:32 --> Config Class Initialized
INFO - 2016-09-19 07:04:33 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:04:33 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:04:33 --> Utf8 Class Initialized
INFO - 2016-09-19 07:04:33 --> URI Class Initialized
INFO - 2016-09-19 07:04:33 --> Router Class Initialized
INFO - 2016-09-19 07:04:33 --> Output Class Initialized
INFO - 2016-09-19 07:04:33 --> Security Class Initialized
DEBUG - 2016-09-19 07:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:04:33 --> Input Class Initialized
INFO - 2016-09-19 07:04:33 --> Language Class Initialized
INFO - 2016-09-19 07:04:33 --> Language Class Initialized
INFO - 2016-09-19 07:04:33 --> Config Class Initialized
INFO - 2016-09-19 07:04:33 --> Loader Class Initialized
INFO - 2016-09-19 07:04:33 --> Helper loaded: url_helper
INFO - 2016-09-19 07:04:33 --> Database Driver Class Initialized
INFO - 2016-09-19 07:04:33 --> Controller Class Initialized
DEBUG - 2016-09-19 07:04:33 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:04:33 --> Model Class Initialized
INFO - 2016-09-19 07:04:33 --> Model Class Initialized
DEBUG - 2016-09-19 07:04:33 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 07:04:33 --> Database Driver Class Initialized
INFO - 2016-09-19 07:04:33 --> Final output sent to browser
DEBUG - 2016-09-19 07:04:33 --> Total execution time: 0.6999
INFO - 2016-09-19 07:04:35 --> Config Class Initialized
INFO - 2016-09-19 07:04:35 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:04:35 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:04:35 --> Utf8 Class Initialized
INFO - 2016-09-19 07:04:35 --> URI Class Initialized
INFO - 2016-09-19 07:04:35 --> Router Class Initialized
INFO - 2016-09-19 07:04:35 --> Output Class Initialized
INFO - 2016-09-19 07:04:35 --> Security Class Initialized
DEBUG - 2016-09-19 07:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:04:35 --> Input Class Initialized
INFO - 2016-09-19 07:04:35 --> Language Class Initialized
INFO - 2016-09-19 07:04:35 --> Language Class Initialized
INFO - 2016-09-19 07:04:35 --> Config Class Initialized
INFO - 2016-09-19 07:04:35 --> Loader Class Initialized
INFO - 2016-09-19 07:04:35 --> Helper loaded: url_helper
INFO - 2016-09-19 07:04:35 --> Database Driver Class Initialized
INFO - 2016-09-19 07:04:35 --> Controller Class Initialized
DEBUG - 2016-09-19 07:04:35 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:04:35 --> Model Class Initialized
INFO - 2016-09-19 07:04:35 --> Model Class Initialized
DEBUG - 2016-09-19 07:04:35 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 07:04:35 --> Database Driver Class Initialized
INFO - 2016-09-19 07:04:35 --> Final output sent to browser
DEBUG - 2016-09-19 07:04:35 --> Total execution time: 0.7833
INFO - 2016-09-19 07:04:44 --> Config Class Initialized
INFO - 2016-09-19 07:04:44 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:04:44 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:04:44 --> Utf8 Class Initialized
INFO - 2016-09-19 07:04:44 --> URI Class Initialized
INFO - 2016-09-19 07:04:44 --> Router Class Initialized
INFO - 2016-09-19 07:04:44 --> Output Class Initialized
INFO - 2016-09-19 07:04:44 --> Security Class Initialized
DEBUG - 2016-09-19 07:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:04:44 --> Input Class Initialized
INFO - 2016-09-19 07:04:44 --> Language Class Initialized
INFO - 2016-09-19 07:04:44 --> Language Class Initialized
INFO - 2016-09-19 07:04:44 --> Config Class Initialized
INFO - 2016-09-19 07:04:44 --> Loader Class Initialized
INFO - 2016-09-19 07:04:45 --> Helper loaded: url_helper
INFO - 2016-09-19 07:04:45 --> Database Driver Class Initialized
INFO - 2016-09-19 07:04:45 --> Controller Class Initialized
DEBUG - 2016-09-19 07:04:45 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:04:45 --> Model Class Initialized
INFO - 2016-09-19 07:04:45 --> Model Class Initialized
DEBUG - 2016-09-19 07:04:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 07:04:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 07:04:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 07:04:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 07:04:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 07:04:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 07:04:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 07:04:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 07:04:45 --> Final output sent to browser
DEBUG - 2016-09-19 07:04:45 --> Total execution time: 0.8868
INFO - 2016-09-19 07:04:51 --> Config Class Initialized
INFO - 2016-09-19 07:04:51 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:04:51 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:04:51 --> Utf8 Class Initialized
INFO - 2016-09-19 07:04:51 --> URI Class Initialized
INFO - 2016-09-19 07:04:51 --> Router Class Initialized
INFO - 2016-09-19 07:04:51 --> Output Class Initialized
INFO - 2016-09-19 07:04:51 --> Security Class Initialized
DEBUG - 2016-09-19 07:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:04:51 --> Input Class Initialized
INFO - 2016-09-19 07:04:51 --> Language Class Initialized
INFO - 2016-09-19 07:04:51 --> Language Class Initialized
INFO - 2016-09-19 07:04:51 --> Config Class Initialized
INFO - 2016-09-19 07:04:51 --> Loader Class Initialized
INFO - 2016-09-19 07:04:52 --> Helper loaded: url_helper
INFO - 2016-09-19 07:04:52 --> Database Driver Class Initialized
INFO - 2016-09-19 07:04:52 --> Controller Class Initialized
DEBUG - 2016-09-19 07:04:52 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:04:52 --> Model Class Initialized
INFO - 2016-09-19 07:04:52 --> Model Class Initialized
DEBUG - 2016-09-19 07:04:52 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 07:04:52 --> Database Driver Class Initialized
INFO - 2016-09-19 07:04:52 --> Final output sent to browser
DEBUG - 2016-09-19 07:04:52 --> Total execution time: 0.7775
INFO - 2016-09-19 07:05:23 --> Config Class Initialized
INFO - 2016-09-19 07:05:23 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:05:23 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:05:23 --> Utf8 Class Initialized
INFO - 2016-09-19 07:05:23 --> URI Class Initialized
INFO - 2016-09-19 07:05:23 --> Router Class Initialized
INFO - 2016-09-19 07:05:23 --> Output Class Initialized
INFO - 2016-09-19 07:05:23 --> Security Class Initialized
DEBUG - 2016-09-19 07:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:05:23 --> Input Class Initialized
INFO - 2016-09-19 07:05:23 --> Language Class Initialized
INFO - 2016-09-19 07:05:23 --> Language Class Initialized
INFO - 2016-09-19 07:05:23 --> Config Class Initialized
INFO - 2016-09-19 07:05:23 --> Loader Class Initialized
INFO - 2016-09-19 07:05:23 --> Helper loaded: url_helper
INFO - 2016-09-19 07:05:23 --> Database Driver Class Initialized
INFO - 2016-09-19 07:05:23 --> Controller Class Initialized
DEBUG - 2016-09-19 07:05:23 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:05:23 --> Model Class Initialized
INFO - 2016-09-19 07:05:23 --> Model Class Initialized
DEBUG - 2016-09-19 07:05:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 07:05:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 07:05:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 07:05:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 07:05:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 07:05:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 07:05:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 07:05:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 07:05:24 --> Final output sent to browser
DEBUG - 2016-09-19 07:05:24 --> Total execution time: 0.9305
INFO - 2016-09-19 07:05:28 --> Config Class Initialized
INFO - 2016-09-19 07:05:29 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:05:29 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:05:29 --> Utf8 Class Initialized
INFO - 2016-09-19 07:05:29 --> URI Class Initialized
INFO - 2016-09-19 07:05:29 --> Router Class Initialized
INFO - 2016-09-19 07:05:29 --> Output Class Initialized
INFO - 2016-09-19 07:05:29 --> Security Class Initialized
DEBUG - 2016-09-19 07:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:05:29 --> Input Class Initialized
INFO - 2016-09-19 07:05:29 --> Language Class Initialized
INFO - 2016-09-19 07:05:29 --> Language Class Initialized
INFO - 2016-09-19 07:05:29 --> Config Class Initialized
INFO - 2016-09-19 07:05:29 --> Loader Class Initialized
INFO - 2016-09-19 07:05:29 --> Helper loaded: url_helper
INFO - 2016-09-19 07:05:29 --> Database Driver Class Initialized
INFO - 2016-09-19 07:05:29 --> Controller Class Initialized
DEBUG - 2016-09-19 07:05:29 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:05:29 --> Model Class Initialized
INFO - 2016-09-19 07:05:29 --> Model Class Initialized
DEBUG - 2016-09-19 07:05:29 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 07:05:29 --> Database Driver Class Initialized
INFO - 2016-09-19 07:05:29 --> Final output sent to browser
DEBUG - 2016-09-19 07:05:29 --> Total execution time: 0.8644
INFO - 2016-09-19 07:05:35 --> Config Class Initialized
INFO - 2016-09-19 07:05:35 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:05:35 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:05:35 --> Utf8 Class Initialized
INFO - 2016-09-19 07:05:35 --> URI Class Initialized
INFO - 2016-09-19 07:05:35 --> Router Class Initialized
INFO - 2016-09-19 07:05:35 --> Output Class Initialized
INFO - 2016-09-19 07:05:35 --> Security Class Initialized
DEBUG - 2016-09-19 07:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:05:35 --> Input Class Initialized
INFO - 2016-09-19 07:05:35 --> Language Class Initialized
INFO - 2016-09-19 07:05:35 --> Language Class Initialized
INFO - 2016-09-19 07:05:35 --> Config Class Initialized
INFO - 2016-09-19 07:05:35 --> Loader Class Initialized
INFO - 2016-09-19 07:05:35 --> Helper loaded: url_helper
INFO - 2016-09-19 07:05:35 --> Database Driver Class Initialized
INFO - 2016-09-19 07:05:35 --> Controller Class Initialized
DEBUG - 2016-09-19 07:05:35 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:05:35 --> Model Class Initialized
INFO - 2016-09-19 07:05:35 --> Model Class Initialized
DEBUG - 2016-09-19 07:05:35 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 07:05:35 --> Database Driver Class Initialized
INFO - 2016-09-19 07:05:35 --> Final output sent to browser
DEBUG - 2016-09-19 07:05:35 --> Total execution time: 0.6816
INFO - 2016-09-19 07:06:00 --> Config Class Initialized
INFO - 2016-09-19 07:06:00 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:06:00 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:06:00 --> Utf8 Class Initialized
INFO - 2016-09-19 07:06:01 --> URI Class Initialized
INFO - 2016-09-19 07:06:01 --> Router Class Initialized
INFO - 2016-09-19 07:06:01 --> Output Class Initialized
INFO - 2016-09-19 07:06:01 --> Security Class Initialized
DEBUG - 2016-09-19 07:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:06:01 --> Input Class Initialized
INFO - 2016-09-19 07:06:01 --> Language Class Initialized
INFO - 2016-09-19 07:06:01 --> Language Class Initialized
INFO - 2016-09-19 07:06:01 --> Config Class Initialized
INFO - 2016-09-19 07:06:01 --> Loader Class Initialized
INFO - 2016-09-19 07:06:01 --> Helper loaded: url_helper
INFO - 2016-09-19 07:06:01 --> Database Driver Class Initialized
INFO - 2016-09-19 07:06:01 --> Controller Class Initialized
DEBUG - 2016-09-19 07:06:01 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:06:01 --> Model Class Initialized
INFO - 2016-09-19 07:06:01 --> Model Class Initialized
DEBUG - 2016-09-19 07:06:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 07:06:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 07:06:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 07:06:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 07:06:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 07:06:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 07:06:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 07:06:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 07:06:01 --> Final output sent to browser
DEBUG - 2016-09-19 07:06:01 --> Total execution time: 0.9140
INFO - 2016-09-19 07:06:11 --> Config Class Initialized
INFO - 2016-09-19 07:06:11 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:06:11 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:06:11 --> Utf8 Class Initialized
INFO - 2016-09-19 07:06:11 --> URI Class Initialized
INFO - 2016-09-19 07:06:11 --> Router Class Initialized
INFO - 2016-09-19 07:06:11 --> Output Class Initialized
INFO - 2016-09-19 07:06:11 --> Security Class Initialized
DEBUG - 2016-09-19 07:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:06:11 --> Input Class Initialized
INFO - 2016-09-19 07:06:11 --> Language Class Initialized
INFO - 2016-09-19 07:06:11 --> Language Class Initialized
INFO - 2016-09-19 07:06:11 --> Config Class Initialized
INFO - 2016-09-19 07:06:11 --> Loader Class Initialized
INFO - 2016-09-19 07:06:12 --> Helper loaded: url_helper
INFO - 2016-09-19 07:06:12 --> Database Driver Class Initialized
INFO - 2016-09-19 07:06:12 --> Controller Class Initialized
DEBUG - 2016-09-19 07:06:12 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:06:12 --> Model Class Initialized
INFO - 2016-09-19 07:06:12 --> Model Class Initialized
DEBUG - 2016-09-19 07:06:12 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 07:06:12 --> Database Driver Class Initialized
INFO - 2016-09-19 07:06:12 --> Final output sent to browser
DEBUG - 2016-09-19 07:06:12 --> Total execution time: 0.7291
INFO - 2016-09-19 07:06:16 --> Config Class Initialized
INFO - 2016-09-19 07:06:16 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:06:16 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:06:16 --> Utf8 Class Initialized
INFO - 2016-09-19 07:06:16 --> URI Class Initialized
INFO - 2016-09-19 07:06:16 --> Router Class Initialized
INFO - 2016-09-19 07:06:16 --> Output Class Initialized
INFO - 2016-09-19 07:06:16 --> Security Class Initialized
DEBUG - 2016-09-19 07:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:06:16 --> Input Class Initialized
INFO - 2016-09-19 07:06:16 --> Language Class Initialized
INFO - 2016-09-19 07:06:16 --> Language Class Initialized
INFO - 2016-09-19 07:06:17 --> Config Class Initialized
INFO - 2016-09-19 07:06:17 --> Loader Class Initialized
INFO - 2016-09-19 07:06:17 --> Helper loaded: url_helper
INFO - 2016-09-19 07:06:17 --> Database Driver Class Initialized
INFO - 2016-09-19 07:06:17 --> Controller Class Initialized
DEBUG - 2016-09-19 07:06:17 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:06:17 --> Model Class Initialized
INFO - 2016-09-19 07:06:17 --> Model Class Initialized
DEBUG - 2016-09-19 07:06:17 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 07:06:17 --> Database Driver Class Initialized
INFO - 2016-09-19 07:06:17 --> Final output sent to browser
DEBUG - 2016-09-19 07:06:17 --> Total execution time: 0.6894
INFO - 2016-09-19 07:06:35 --> Config Class Initialized
INFO - 2016-09-19 07:06:35 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:06:35 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:06:35 --> Utf8 Class Initialized
INFO - 2016-09-19 07:06:35 --> URI Class Initialized
INFO - 2016-09-19 07:06:35 --> Router Class Initialized
INFO - 2016-09-19 07:06:35 --> Output Class Initialized
INFO - 2016-09-19 07:06:35 --> Security Class Initialized
DEBUG - 2016-09-19 07:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:06:35 --> Input Class Initialized
INFO - 2016-09-19 07:06:35 --> Language Class Initialized
INFO - 2016-09-19 07:06:35 --> Language Class Initialized
INFO - 2016-09-19 07:06:35 --> Config Class Initialized
INFO - 2016-09-19 07:06:35 --> Loader Class Initialized
INFO - 2016-09-19 07:06:35 --> Helper loaded: url_helper
INFO - 2016-09-19 07:06:36 --> Database Driver Class Initialized
INFO - 2016-09-19 07:06:36 --> Controller Class Initialized
DEBUG - 2016-09-19 07:06:36 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:06:36 --> Model Class Initialized
INFO - 2016-09-19 07:06:36 --> Model Class Initialized
DEBUG - 2016-09-19 07:06:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 07:06:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 07:06:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 07:06:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 07:06:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 07:06:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 07:06:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 07:06:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 07:06:36 --> Final output sent to browser
DEBUG - 2016-09-19 07:06:36 --> Total execution time: 0.9264
INFO - 2016-09-19 07:06:40 --> Config Class Initialized
INFO - 2016-09-19 07:06:40 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:06:40 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:06:40 --> Utf8 Class Initialized
INFO - 2016-09-19 07:06:40 --> URI Class Initialized
INFO - 2016-09-19 07:06:40 --> Router Class Initialized
INFO - 2016-09-19 07:06:40 --> Output Class Initialized
INFO - 2016-09-19 07:06:40 --> Security Class Initialized
DEBUG - 2016-09-19 07:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:06:40 --> Input Class Initialized
INFO - 2016-09-19 07:06:40 --> Language Class Initialized
INFO - 2016-09-19 07:06:41 --> Language Class Initialized
INFO - 2016-09-19 07:06:41 --> Config Class Initialized
INFO - 2016-09-19 07:06:41 --> Loader Class Initialized
INFO - 2016-09-19 07:06:41 --> Helper loaded: url_helper
INFO - 2016-09-19 07:06:41 --> Database Driver Class Initialized
INFO - 2016-09-19 07:06:41 --> Controller Class Initialized
DEBUG - 2016-09-19 07:06:41 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:06:41 --> Model Class Initialized
INFO - 2016-09-19 07:06:41 --> Model Class Initialized
DEBUG - 2016-09-19 07:06:41 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 07:06:41 --> Database Driver Class Initialized
INFO - 2016-09-19 07:06:41 --> Final output sent to browser
DEBUG - 2016-09-19 07:06:41 --> Total execution time: 0.7641
INFO - 2016-09-19 07:06:44 --> Config Class Initialized
INFO - 2016-09-19 07:06:44 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:06:45 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:06:45 --> Utf8 Class Initialized
INFO - 2016-09-19 07:06:45 --> URI Class Initialized
INFO - 2016-09-19 07:06:45 --> Router Class Initialized
INFO - 2016-09-19 07:06:45 --> Output Class Initialized
INFO - 2016-09-19 07:06:45 --> Security Class Initialized
DEBUG - 2016-09-19 07:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:06:45 --> Input Class Initialized
INFO - 2016-09-19 07:06:45 --> Language Class Initialized
INFO - 2016-09-19 07:06:45 --> Language Class Initialized
INFO - 2016-09-19 07:06:45 --> Config Class Initialized
INFO - 2016-09-19 07:06:45 --> Loader Class Initialized
INFO - 2016-09-19 07:06:45 --> Helper loaded: url_helper
INFO - 2016-09-19 07:06:45 --> Database Driver Class Initialized
INFO - 2016-09-19 07:06:45 --> Controller Class Initialized
DEBUG - 2016-09-19 07:06:45 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:06:45 --> Model Class Initialized
INFO - 2016-09-19 07:06:45 --> Model Class Initialized
DEBUG - 2016-09-19 07:06:45 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 07:06:45 --> Database Driver Class Initialized
INFO - 2016-09-19 07:06:45 --> Final output sent to browser
DEBUG - 2016-09-19 07:06:45 --> Total execution time: 0.6978
INFO - 2016-09-19 07:07:25 --> Config Class Initialized
INFO - 2016-09-19 07:07:25 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:07:25 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:07:26 --> Utf8 Class Initialized
INFO - 2016-09-19 07:07:26 --> URI Class Initialized
INFO - 2016-09-19 07:07:26 --> Router Class Initialized
INFO - 2016-09-19 07:07:26 --> Output Class Initialized
INFO - 2016-09-19 07:07:26 --> Security Class Initialized
DEBUG - 2016-09-19 07:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:07:26 --> Input Class Initialized
INFO - 2016-09-19 07:07:26 --> Language Class Initialized
INFO - 2016-09-19 07:07:26 --> Language Class Initialized
INFO - 2016-09-19 07:07:26 --> Config Class Initialized
INFO - 2016-09-19 07:07:26 --> Loader Class Initialized
INFO - 2016-09-19 07:07:26 --> Helper loaded: url_helper
INFO - 2016-09-19 07:07:26 --> Database Driver Class Initialized
INFO - 2016-09-19 07:07:26 --> Controller Class Initialized
DEBUG - 2016-09-19 07:07:26 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:07:26 --> Model Class Initialized
INFO - 2016-09-19 07:07:26 --> Model Class Initialized
DEBUG - 2016-09-19 07:07:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 07:07:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 07:07:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 07:07:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 07:07:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 07:07:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 07:07:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 07:07:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 07:07:26 --> Final output sent to browser
DEBUG - 2016-09-19 07:07:26 --> Total execution time: 0.9341
INFO - 2016-09-19 07:07:30 --> Config Class Initialized
INFO - 2016-09-19 07:07:30 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:07:30 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:07:30 --> Utf8 Class Initialized
INFO - 2016-09-19 07:07:31 --> URI Class Initialized
INFO - 2016-09-19 07:07:31 --> Router Class Initialized
INFO - 2016-09-19 07:07:31 --> Output Class Initialized
INFO - 2016-09-19 07:07:31 --> Security Class Initialized
DEBUG - 2016-09-19 07:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:07:31 --> Input Class Initialized
INFO - 2016-09-19 07:07:31 --> Language Class Initialized
INFO - 2016-09-19 07:07:31 --> Language Class Initialized
INFO - 2016-09-19 07:07:31 --> Config Class Initialized
INFO - 2016-09-19 07:07:31 --> Loader Class Initialized
INFO - 2016-09-19 07:07:31 --> Helper loaded: url_helper
INFO - 2016-09-19 07:07:31 --> Database Driver Class Initialized
INFO - 2016-09-19 07:07:31 --> Controller Class Initialized
DEBUG - 2016-09-19 07:07:31 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:07:31 --> Model Class Initialized
INFO - 2016-09-19 07:07:31 --> Model Class Initialized
DEBUG - 2016-09-19 07:07:31 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 07:07:31 --> Database Driver Class Initialized
INFO - 2016-09-19 07:07:31 --> Final output sent to browser
DEBUG - 2016-09-19 07:07:31 --> Total execution time: 0.7695
INFO - 2016-09-19 07:07:43 --> Config Class Initialized
INFO - 2016-09-19 07:07:43 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:07:43 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:07:43 --> Utf8 Class Initialized
INFO - 2016-09-19 07:07:43 --> URI Class Initialized
INFO - 2016-09-19 07:07:43 --> Router Class Initialized
INFO - 2016-09-19 07:07:43 --> Output Class Initialized
INFO - 2016-09-19 07:07:43 --> Security Class Initialized
DEBUG - 2016-09-19 07:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:07:43 --> Input Class Initialized
INFO - 2016-09-19 07:07:43 --> Language Class Initialized
INFO - 2016-09-19 07:07:43 --> Language Class Initialized
INFO - 2016-09-19 07:07:43 --> Config Class Initialized
INFO - 2016-09-19 07:07:43 --> Loader Class Initialized
INFO - 2016-09-19 07:07:43 --> Helper loaded: url_helper
INFO - 2016-09-19 07:07:43 --> Database Driver Class Initialized
INFO - 2016-09-19 07:07:43 --> Controller Class Initialized
DEBUG - 2016-09-19 07:07:43 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:07:43 --> Model Class Initialized
INFO - 2016-09-19 07:07:43 --> Model Class Initialized
DEBUG - 2016-09-19 07:07:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 07:07:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 07:07:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 07:07:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 07:07:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 07:07:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 07:07:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 07:07:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 07:07:44 --> Final output sent to browser
DEBUG - 2016-09-19 07:07:44 --> Total execution time: 0.8920
INFO - 2016-09-19 07:07:59 --> Config Class Initialized
INFO - 2016-09-19 07:07:59 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:07:59 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:07:59 --> Utf8 Class Initialized
INFO - 2016-09-19 07:07:59 --> URI Class Initialized
INFO - 2016-09-19 07:07:59 --> Router Class Initialized
INFO - 2016-09-19 07:07:59 --> Output Class Initialized
INFO - 2016-09-19 07:07:59 --> Security Class Initialized
DEBUG - 2016-09-19 07:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:07:59 --> Input Class Initialized
INFO - 2016-09-19 07:07:59 --> Language Class Initialized
INFO - 2016-09-19 07:07:59 --> Language Class Initialized
INFO - 2016-09-19 07:07:59 --> Config Class Initialized
INFO - 2016-09-19 07:08:00 --> Loader Class Initialized
INFO - 2016-09-19 07:08:00 --> Helper loaded: url_helper
INFO - 2016-09-19 07:08:00 --> Database Driver Class Initialized
INFO - 2016-09-19 07:08:00 --> Controller Class Initialized
DEBUG - 2016-09-19 07:08:00 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:08:00 --> Model Class Initialized
INFO - 2016-09-19 07:08:00 --> Model Class Initialized
DEBUG - 2016-09-19 07:08:00 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 07:08:00 --> Database Driver Class Initialized
INFO - 2016-09-19 07:08:00 --> Final output sent to browser
DEBUG - 2016-09-19 07:08:00 --> Total execution time: 0.7602
INFO - 2016-09-19 07:08:05 --> Config Class Initialized
INFO - 2016-09-19 07:08:05 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:08:05 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:08:05 --> Utf8 Class Initialized
INFO - 2016-09-19 07:08:05 --> URI Class Initialized
INFO - 2016-09-19 07:08:05 --> Router Class Initialized
INFO - 2016-09-19 07:08:05 --> Output Class Initialized
INFO - 2016-09-19 07:08:05 --> Security Class Initialized
DEBUG - 2016-09-19 07:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:08:05 --> Input Class Initialized
INFO - 2016-09-19 07:08:05 --> Language Class Initialized
INFO - 2016-09-19 07:08:05 --> Language Class Initialized
INFO - 2016-09-19 07:08:05 --> Config Class Initialized
INFO - 2016-09-19 07:08:05 --> Loader Class Initialized
INFO - 2016-09-19 07:08:05 --> Helper loaded: url_helper
INFO - 2016-09-19 07:08:05 --> Database Driver Class Initialized
INFO - 2016-09-19 07:08:05 --> Controller Class Initialized
DEBUG - 2016-09-19 07:08:05 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:08:05 --> Model Class Initialized
INFO - 2016-09-19 07:08:05 --> Model Class Initialized
DEBUG - 2016-09-19 07:08:05 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 07:08:05 --> Database Driver Class Initialized
INFO - 2016-09-19 07:08:05 --> Final output sent to browser
DEBUG - 2016-09-19 07:08:05 --> Total execution time: 0.7368
INFO - 2016-09-19 07:08:08 --> Config Class Initialized
INFO - 2016-09-19 07:08:08 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:08:09 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:08:09 --> Utf8 Class Initialized
INFO - 2016-09-19 07:08:09 --> URI Class Initialized
INFO - 2016-09-19 07:08:09 --> Router Class Initialized
INFO - 2016-09-19 07:08:09 --> Output Class Initialized
INFO - 2016-09-19 07:08:09 --> Security Class Initialized
DEBUG - 2016-09-19 07:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:08:09 --> Input Class Initialized
INFO - 2016-09-19 07:08:09 --> Language Class Initialized
INFO - 2016-09-19 07:08:09 --> Language Class Initialized
INFO - 2016-09-19 07:08:09 --> Config Class Initialized
INFO - 2016-09-19 07:08:09 --> Loader Class Initialized
INFO - 2016-09-19 07:08:09 --> Helper loaded: url_helper
INFO - 2016-09-19 07:08:09 --> Database Driver Class Initialized
INFO - 2016-09-19 07:08:09 --> Controller Class Initialized
DEBUG - 2016-09-19 07:08:09 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:08:09 --> Model Class Initialized
INFO - 2016-09-19 07:08:09 --> Model Class Initialized
DEBUG - 2016-09-19 07:08:09 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 07:08:09 --> Database Driver Class Initialized
INFO - 2016-09-19 07:08:09 --> Final output sent to browser
DEBUG - 2016-09-19 07:08:09 --> Total execution time: 0.7032
INFO - 2016-09-19 07:08:24 --> Config Class Initialized
INFO - 2016-09-19 07:08:24 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:08:24 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:08:24 --> Utf8 Class Initialized
INFO - 2016-09-19 07:08:24 --> URI Class Initialized
INFO - 2016-09-19 07:08:24 --> Router Class Initialized
INFO - 2016-09-19 07:08:24 --> Output Class Initialized
INFO - 2016-09-19 07:08:24 --> Security Class Initialized
DEBUG - 2016-09-19 07:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:08:24 --> Input Class Initialized
INFO - 2016-09-19 07:08:24 --> Language Class Initialized
INFO - 2016-09-19 07:08:24 --> Language Class Initialized
INFO - 2016-09-19 07:08:24 --> Config Class Initialized
INFO - 2016-09-19 07:08:24 --> Loader Class Initialized
INFO - 2016-09-19 07:08:24 --> Helper loaded: url_helper
INFO - 2016-09-19 07:08:24 --> Database Driver Class Initialized
INFO - 2016-09-19 07:08:24 --> Controller Class Initialized
DEBUG - 2016-09-19 07:08:24 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:08:25 --> Model Class Initialized
INFO - 2016-09-19 07:08:25 --> Model Class Initialized
DEBUG - 2016-09-19 07:08:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 07:08:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 07:08:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 07:08:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 07:08:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 07:08:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 07:08:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 07:08:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 07:08:25 --> Final output sent to browser
DEBUG - 2016-09-19 07:08:25 --> Total execution time: 0.9296
INFO - 2016-09-19 07:08:30 --> Config Class Initialized
INFO - 2016-09-19 07:08:30 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:08:30 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:08:30 --> Utf8 Class Initialized
INFO - 2016-09-19 07:08:30 --> URI Class Initialized
INFO - 2016-09-19 07:08:30 --> Router Class Initialized
INFO - 2016-09-19 07:08:30 --> Output Class Initialized
INFO - 2016-09-19 07:08:30 --> Security Class Initialized
DEBUG - 2016-09-19 07:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:08:30 --> Input Class Initialized
INFO - 2016-09-19 07:08:30 --> Language Class Initialized
INFO - 2016-09-19 07:08:30 --> Language Class Initialized
INFO - 2016-09-19 07:08:30 --> Config Class Initialized
INFO - 2016-09-19 07:08:30 --> Loader Class Initialized
INFO - 2016-09-19 07:08:30 --> Helper loaded: url_helper
INFO - 2016-09-19 07:08:30 --> Database Driver Class Initialized
INFO - 2016-09-19 07:08:30 --> Controller Class Initialized
DEBUG - 2016-09-19 07:08:30 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:08:30 --> Model Class Initialized
INFO - 2016-09-19 07:08:30 --> Model Class Initialized
DEBUG - 2016-09-19 07:08:30 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 07:08:30 --> Database Driver Class Initialized
INFO - 2016-09-19 07:08:31 --> Final output sent to browser
DEBUG - 2016-09-19 07:08:31 --> Total execution time: 0.7830
INFO - 2016-09-19 07:09:07 --> Config Class Initialized
INFO - 2016-09-19 07:09:07 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:09:07 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:09:07 --> Utf8 Class Initialized
INFO - 2016-09-19 07:09:07 --> URI Class Initialized
INFO - 2016-09-19 07:09:07 --> Router Class Initialized
INFO - 2016-09-19 07:09:07 --> Output Class Initialized
INFO - 2016-09-19 07:09:07 --> Security Class Initialized
DEBUG - 2016-09-19 07:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:09:07 --> Input Class Initialized
INFO - 2016-09-19 07:09:07 --> Language Class Initialized
INFO - 2016-09-19 07:09:07 --> Language Class Initialized
INFO - 2016-09-19 07:09:07 --> Config Class Initialized
INFO - 2016-09-19 07:09:07 --> Loader Class Initialized
INFO - 2016-09-19 07:09:07 --> Helper loaded: url_helper
INFO - 2016-09-19 07:09:07 --> Database Driver Class Initialized
INFO - 2016-09-19 07:09:07 --> Controller Class Initialized
DEBUG - 2016-09-19 07:09:07 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:09:07 --> Model Class Initialized
INFO - 2016-09-19 07:09:07 --> Model Class Initialized
DEBUG - 2016-09-19 07:09:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 07:09:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 07:09:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 07:09:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 07:09:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 07:09:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 07:09:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 07:09:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 07:09:08 --> Final output sent to browser
DEBUG - 2016-09-19 07:09:08 --> Total execution time: 0.9089
INFO - 2016-09-19 07:09:14 --> Config Class Initialized
INFO - 2016-09-19 07:09:14 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:09:14 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:09:14 --> Utf8 Class Initialized
INFO - 2016-09-19 07:09:14 --> URI Class Initialized
INFO - 2016-09-19 07:09:14 --> Router Class Initialized
INFO - 2016-09-19 07:09:14 --> Output Class Initialized
INFO - 2016-09-19 07:09:14 --> Security Class Initialized
DEBUG - 2016-09-19 07:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:09:14 --> Input Class Initialized
INFO - 2016-09-19 07:09:14 --> Language Class Initialized
INFO - 2016-09-19 07:09:14 --> Language Class Initialized
INFO - 2016-09-19 07:09:14 --> Config Class Initialized
INFO - 2016-09-19 07:09:14 --> Loader Class Initialized
INFO - 2016-09-19 07:09:14 --> Helper loaded: url_helper
INFO - 2016-09-19 07:09:14 --> Database Driver Class Initialized
INFO - 2016-09-19 07:09:14 --> Controller Class Initialized
DEBUG - 2016-09-19 07:09:14 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:09:14 --> Model Class Initialized
INFO - 2016-09-19 07:09:14 --> Model Class Initialized
DEBUG - 2016-09-19 07:09:14 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 07:09:15 --> Database Driver Class Initialized
INFO - 2016-09-19 07:09:15 --> Final output sent to browser
DEBUG - 2016-09-19 07:09:15 --> Total execution time: 0.7790
INFO - 2016-09-19 07:09:18 --> Config Class Initialized
INFO - 2016-09-19 07:09:19 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:09:19 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:09:19 --> Utf8 Class Initialized
INFO - 2016-09-19 07:09:19 --> URI Class Initialized
INFO - 2016-09-19 07:09:19 --> Router Class Initialized
INFO - 2016-09-19 07:09:19 --> Output Class Initialized
INFO - 2016-09-19 07:09:19 --> Security Class Initialized
DEBUG - 2016-09-19 07:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:09:19 --> Input Class Initialized
INFO - 2016-09-19 07:09:19 --> Language Class Initialized
INFO - 2016-09-19 07:09:19 --> Language Class Initialized
INFO - 2016-09-19 07:09:19 --> Config Class Initialized
INFO - 2016-09-19 07:09:19 --> Loader Class Initialized
INFO - 2016-09-19 07:09:19 --> Helper loaded: url_helper
INFO - 2016-09-19 07:09:19 --> Database Driver Class Initialized
INFO - 2016-09-19 07:09:19 --> Controller Class Initialized
DEBUG - 2016-09-19 07:09:19 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:09:19 --> Model Class Initialized
INFO - 2016-09-19 07:09:19 --> Model Class Initialized
DEBUG - 2016-09-19 07:09:19 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 07:09:19 --> Database Driver Class Initialized
INFO - 2016-09-19 07:09:19 --> Final output sent to browser
DEBUG - 2016-09-19 07:09:19 --> Total execution time: 0.7372
INFO - 2016-09-19 07:11:18 --> Config Class Initialized
INFO - 2016-09-19 07:11:18 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:11:18 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:11:18 --> Utf8 Class Initialized
INFO - 2016-09-19 07:11:18 --> URI Class Initialized
INFO - 2016-09-19 07:11:18 --> Router Class Initialized
INFO - 2016-09-19 07:11:18 --> Output Class Initialized
INFO - 2016-09-19 07:11:18 --> Security Class Initialized
DEBUG - 2016-09-19 07:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:11:18 --> Input Class Initialized
INFO - 2016-09-19 07:11:18 --> Language Class Initialized
INFO - 2016-09-19 07:11:18 --> Language Class Initialized
INFO - 2016-09-19 07:11:19 --> Config Class Initialized
INFO - 2016-09-19 07:11:19 --> Loader Class Initialized
INFO - 2016-09-19 07:11:19 --> Helper loaded: url_helper
INFO - 2016-09-19 07:11:19 --> Database Driver Class Initialized
INFO - 2016-09-19 07:11:19 --> Controller Class Initialized
DEBUG - 2016-09-19 07:11:19 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:11:19 --> Model Class Initialized
INFO - 2016-09-19 07:11:19 --> Model Class Initialized
DEBUG - 2016-09-19 07:11:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 07:11:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 07:11:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 07:11:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 07:11:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 07:11:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 07:11:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 07:11:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 07:11:19 --> Final output sent to browser
DEBUG - 2016-09-19 07:11:19 --> Total execution time: 0.9059
INFO - 2016-09-19 07:11:23 --> Config Class Initialized
INFO - 2016-09-19 07:11:23 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:11:24 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:11:24 --> Utf8 Class Initialized
INFO - 2016-09-19 07:11:24 --> URI Class Initialized
INFO - 2016-09-19 07:11:24 --> Router Class Initialized
INFO - 2016-09-19 07:11:24 --> Output Class Initialized
INFO - 2016-09-19 07:11:24 --> Security Class Initialized
DEBUG - 2016-09-19 07:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:11:24 --> Input Class Initialized
INFO - 2016-09-19 07:11:24 --> Language Class Initialized
INFO - 2016-09-19 07:11:24 --> Language Class Initialized
INFO - 2016-09-19 07:11:24 --> Config Class Initialized
INFO - 2016-09-19 07:11:24 --> Loader Class Initialized
INFO - 2016-09-19 07:11:24 --> Helper loaded: url_helper
INFO - 2016-09-19 07:11:24 --> Database Driver Class Initialized
INFO - 2016-09-19 07:11:24 --> Controller Class Initialized
DEBUG - 2016-09-19 07:11:24 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:11:24 --> Model Class Initialized
INFO - 2016-09-19 07:11:24 --> Model Class Initialized
DEBUG - 2016-09-19 07:11:24 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 07:11:24 --> Database Driver Class Initialized
INFO - 2016-09-19 07:11:24 --> Final output sent to browser
DEBUG - 2016-09-19 07:11:24 --> Total execution time: 0.8320
INFO - 2016-09-19 07:11:26 --> Config Class Initialized
INFO - 2016-09-19 07:11:26 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:11:26 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:11:26 --> Utf8 Class Initialized
INFO - 2016-09-19 07:11:26 --> URI Class Initialized
INFO - 2016-09-19 07:11:26 --> Router Class Initialized
INFO - 2016-09-19 07:11:27 --> Output Class Initialized
INFO - 2016-09-19 07:11:27 --> Security Class Initialized
DEBUG - 2016-09-19 07:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:11:27 --> Input Class Initialized
INFO - 2016-09-19 07:11:27 --> Language Class Initialized
INFO - 2016-09-19 07:11:27 --> Language Class Initialized
INFO - 2016-09-19 07:11:27 --> Config Class Initialized
INFO - 2016-09-19 07:11:27 --> Loader Class Initialized
INFO - 2016-09-19 07:11:27 --> Helper loaded: url_helper
INFO - 2016-09-19 07:11:27 --> Database Driver Class Initialized
INFO - 2016-09-19 07:11:27 --> Controller Class Initialized
DEBUG - 2016-09-19 07:11:27 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:11:27 --> Model Class Initialized
INFO - 2016-09-19 07:11:27 --> Model Class Initialized
DEBUG - 2016-09-19 07:11:27 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 07:11:27 --> Database Driver Class Initialized
INFO - 2016-09-19 07:11:27 --> Final output sent to browser
DEBUG - 2016-09-19 07:11:27 --> Total execution time: 0.9891
INFO - 2016-09-19 07:11:28 --> Config Class Initialized
INFO - 2016-09-19 07:11:28 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:11:28 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:11:28 --> Utf8 Class Initialized
INFO - 2016-09-19 07:11:28 --> URI Class Initialized
INFO - 2016-09-19 07:11:28 --> Router Class Initialized
INFO - 2016-09-19 07:11:28 --> Output Class Initialized
INFO - 2016-09-19 07:11:28 --> Security Class Initialized
DEBUG - 2016-09-19 07:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:11:28 --> Input Class Initialized
INFO - 2016-09-19 07:11:28 --> Language Class Initialized
INFO - 2016-09-19 07:11:28 --> Language Class Initialized
INFO - 2016-09-19 07:11:28 --> Config Class Initialized
INFO - 2016-09-19 07:11:28 --> Loader Class Initialized
INFO - 2016-09-19 07:11:28 --> Helper loaded: url_helper
INFO - 2016-09-19 07:11:28 --> Database Driver Class Initialized
INFO - 2016-09-19 07:11:28 --> Controller Class Initialized
DEBUG - 2016-09-19 07:11:29 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:11:29 --> Model Class Initialized
INFO - 2016-09-19 07:11:29 --> Model Class Initialized
DEBUG - 2016-09-19 07:11:29 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 07:11:29 --> Database Driver Class Initialized
INFO - 2016-09-19 07:11:29 --> Final output sent to browser
DEBUG - 2016-09-19 07:11:29 --> Total execution time: 0.8240
INFO - 2016-09-19 07:11:31 --> Config Class Initialized
INFO - 2016-09-19 07:11:31 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:11:31 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:11:31 --> Utf8 Class Initialized
INFO - 2016-09-19 07:11:31 --> URI Class Initialized
INFO - 2016-09-19 07:11:31 --> Router Class Initialized
INFO - 2016-09-19 07:11:31 --> Output Class Initialized
INFO - 2016-09-19 07:11:31 --> Security Class Initialized
DEBUG - 2016-09-19 07:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:11:31 --> Input Class Initialized
INFO - 2016-09-19 07:11:31 --> Language Class Initialized
INFO - 2016-09-19 07:11:31 --> Language Class Initialized
INFO - 2016-09-19 07:11:31 --> Config Class Initialized
INFO - 2016-09-19 07:11:31 --> Loader Class Initialized
INFO - 2016-09-19 07:11:31 --> Helper loaded: url_helper
INFO - 2016-09-19 07:11:31 --> Database Driver Class Initialized
INFO - 2016-09-19 07:11:31 --> Controller Class Initialized
DEBUG - 2016-09-19 07:11:31 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:11:31 --> Model Class Initialized
INFO - 2016-09-19 07:11:31 --> Model Class Initialized
DEBUG - 2016-09-19 07:11:31 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 07:11:32 --> Database Driver Class Initialized
INFO - 2016-09-19 07:11:32 --> Final output sent to browser
DEBUG - 2016-09-19 07:11:32 --> Total execution time: 0.7686
INFO - 2016-09-19 07:11:41 --> Config Class Initialized
INFO - 2016-09-19 07:11:41 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:11:41 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:11:41 --> Utf8 Class Initialized
INFO - 2016-09-19 07:11:41 --> URI Class Initialized
INFO - 2016-09-19 07:11:41 --> Router Class Initialized
INFO - 2016-09-19 07:11:41 --> Output Class Initialized
INFO - 2016-09-19 07:11:41 --> Security Class Initialized
DEBUG - 2016-09-19 07:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:11:41 --> Input Class Initialized
INFO - 2016-09-19 07:11:41 --> Language Class Initialized
INFO - 2016-09-19 07:11:41 --> Language Class Initialized
INFO - 2016-09-19 07:11:41 --> Config Class Initialized
INFO - 2016-09-19 07:11:41 --> Loader Class Initialized
INFO - 2016-09-19 07:11:41 --> Helper loaded: url_helper
INFO - 2016-09-19 07:11:41 --> Database Driver Class Initialized
INFO - 2016-09-19 07:11:41 --> Controller Class Initialized
DEBUG - 2016-09-19 07:11:41 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:11:41 --> Model Class Initialized
INFO - 2016-09-19 07:11:41 --> Model Class Initialized
DEBUG - 2016-09-19 07:11:42 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 07:11:42 --> Database Driver Class Initialized
INFO - 2016-09-19 07:11:42 --> Final output sent to browser
DEBUG - 2016-09-19 07:11:42 --> Total execution time: 0.7018
INFO - 2016-09-19 07:11:46 --> Config Class Initialized
INFO - 2016-09-19 07:11:46 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:11:46 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:11:46 --> Utf8 Class Initialized
INFO - 2016-09-19 07:11:46 --> URI Class Initialized
INFO - 2016-09-19 07:11:46 --> Router Class Initialized
INFO - 2016-09-19 07:11:46 --> Output Class Initialized
INFO - 2016-09-19 07:11:46 --> Security Class Initialized
DEBUG - 2016-09-19 07:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:11:46 --> Input Class Initialized
INFO - 2016-09-19 07:11:46 --> Language Class Initialized
INFO - 2016-09-19 07:11:47 --> Language Class Initialized
INFO - 2016-09-19 07:11:47 --> Config Class Initialized
INFO - 2016-09-19 07:11:47 --> Loader Class Initialized
INFO - 2016-09-19 07:11:47 --> Helper loaded: url_helper
INFO - 2016-09-19 07:11:47 --> Database Driver Class Initialized
INFO - 2016-09-19 07:11:47 --> Controller Class Initialized
DEBUG - 2016-09-19 07:11:47 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:11:47 --> Model Class Initialized
INFO - 2016-09-19 07:11:47 --> Model Class Initialized
DEBUG - 2016-09-19 07:11:47 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 07:11:47 --> Database Driver Class Initialized
INFO - 2016-09-19 07:11:47 --> Final output sent to browser
DEBUG - 2016-09-19 07:11:47 --> Total execution time: 0.7033
INFO - 2016-09-19 07:13:39 --> Config Class Initialized
INFO - 2016-09-19 07:13:39 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:13:39 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:13:39 --> Utf8 Class Initialized
INFO - 2016-09-19 07:13:39 --> URI Class Initialized
INFO - 2016-09-19 07:13:39 --> Router Class Initialized
INFO - 2016-09-19 07:13:39 --> Output Class Initialized
INFO - 2016-09-19 07:13:39 --> Security Class Initialized
DEBUG - 2016-09-19 07:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:13:39 --> Input Class Initialized
INFO - 2016-09-19 07:13:39 --> Language Class Initialized
INFO - 2016-09-19 07:13:39 --> Language Class Initialized
INFO - 2016-09-19 07:13:39 --> Config Class Initialized
INFO - 2016-09-19 07:13:39 --> Loader Class Initialized
INFO - 2016-09-19 07:13:39 --> Helper loaded: url_helper
INFO - 2016-09-19 07:13:39 --> Database Driver Class Initialized
INFO - 2016-09-19 07:13:39 --> Controller Class Initialized
DEBUG - 2016-09-19 07:13:39 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:13:40 --> Model Class Initialized
INFO - 2016-09-19 07:13:40 --> Model Class Initialized
DEBUG - 2016-09-19 07:13:40 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 07:13:40 --> Database Driver Class Initialized
INFO - 2016-09-19 07:13:40 --> Final output sent to browser
DEBUG - 2016-09-19 07:13:40 --> Total execution time: 0.6902
INFO - 2016-09-19 07:13:42 --> Config Class Initialized
INFO - 2016-09-19 07:13:42 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:13:42 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:13:42 --> Utf8 Class Initialized
INFO - 2016-09-19 07:13:42 --> URI Class Initialized
INFO - 2016-09-19 07:13:42 --> Router Class Initialized
INFO - 2016-09-19 07:13:42 --> Output Class Initialized
INFO - 2016-09-19 07:13:42 --> Security Class Initialized
DEBUG - 2016-09-19 07:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:13:42 --> Input Class Initialized
INFO - 2016-09-19 07:13:42 --> Language Class Initialized
INFO - 2016-09-19 07:13:42 --> Language Class Initialized
INFO - 2016-09-19 07:13:42 --> Config Class Initialized
INFO - 2016-09-19 07:13:42 --> Loader Class Initialized
INFO - 2016-09-19 07:13:42 --> Helper loaded: url_helper
INFO - 2016-09-19 07:13:42 --> Database Driver Class Initialized
INFO - 2016-09-19 07:13:42 --> Controller Class Initialized
DEBUG - 2016-09-19 07:13:43 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:13:43 --> Model Class Initialized
INFO - 2016-09-19 07:13:43 --> Model Class Initialized
DEBUG - 2016-09-19 07:13:43 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 07:13:43 --> Database Driver Class Initialized
INFO - 2016-09-19 07:13:43 --> Final output sent to browser
DEBUG - 2016-09-19 07:13:43 --> Total execution time: 0.7223
INFO - 2016-09-19 07:13:48 --> Config Class Initialized
INFO - 2016-09-19 07:13:48 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:13:48 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:13:48 --> Utf8 Class Initialized
INFO - 2016-09-19 07:13:48 --> URI Class Initialized
INFO - 2016-09-19 07:13:48 --> Router Class Initialized
INFO - 2016-09-19 07:13:48 --> Output Class Initialized
INFO - 2016-09-19 07:13:48 --> Security Class Initialized
DEBUG - 2016-09-19 07:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:13:48 --> Input Class Initialized
INFO - 2016-09-19 07:13:48 --> Language Class Initialized
INFO - 2016-09-19 07:13:48 --> Language Class Initialized
INFO - 2016-09-19 07:13:48 --> Config Class Initialized
INFO - 2016-09-19 07:13:48 --> Loader Class Initialized
INFO - 2016-09-19 07:13:48 --> Helper loaded: url_helper
INFO - 2016-09-19 07:13:48 --> Database Driver Class Initialized
INFO - 2016-09-19 07:13:48 --> Controller Class Initialized
DEBUG - 2016-09-19 07:13:48 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:13:48 --> Model Class Initialized
INFO - 2016-09-19 07:13:48 --> Model Class Initialized
DEBUG - 2016-09-19 07:13:48 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 07:13:48 --> Final output sent to browser
DEBUG - 2016-09-19 07:13:48 --> Total execution time: 0.6763
INFO - 2016-09-19 07:17:55 --> Config Class Initialized
INFO - 2016-09-19 07:17:55 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:17:55 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:17:55 --> Utf8 Class Initialized
INFO - 2016-09-19 07:17:55 --> URI Class Initialized
INFO - 2016-09-19 07:17:55 --> Router Class Initialized
INFO - 2016-09-19 07:17:55 --> Output Class Initialized
INFO - 2016-09-19 07:17:55 --> Security Class Initialized
DEBUG - 2016-09-19 07:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:17:55 --> Input Class Initialized
INFO - 2016-09-19 07:17:55 --> Language Class Initialized
INFO - 2016-09-19 07:17:55 --> Language Class Initialized
INFO - 2016-09-19 07:17:55 --> Config Class Initialized
INFO - 2016-09-19 07:17:55 --> Loader Class Initialized
INFO - 2016-09-19 07:17:55 --> Helper loaded: url_helper
INFO - 2016-09-19 07:17:56 --> Database Driver Class Initialized
INFO - 2016-09-19 07:17:56 --> Controller Class Initialized
DEBUG - 2016-09-19 07:17:56 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:17:56 --> Model Class Initialized
INFO - 2016-09-19 07:17:56 --> Model Class Initialized
DEBUG - 2016-09-19 07:17:56 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 07:17:56 --> Database Driver Class Initialized
INFO - 2016-09-19 07:17:56 --> Final output sent to browser
DEBUG - 2016-09-19 07:17:56 --> Total execution time: 0.7324
INFO - 2016-09-19 07:18:09 --> Config Class Initialized
INFO - 2016-09-19 07:18:09 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:18:09 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:18:09 --> Utf8 Class Initialized
INFO - 2016-09-19 07:18:09 --> URI Class Initialized
INFO - 2016-09-19 07:18:09 --> Router Class Initialized
INFO - 2016-09-19 07:18:09 --> Output Class Initialized
INFO - 2016-09-19 07:18:09 --> Security Class Initialized
DEBUG - 2016-09-19 07:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:18:09 --> Input Class Initialized
INFO - 2016-09-19 07:18:09 --> Language Class Initialized
INFO - 2016-09-19 07:18:09 --> Language Class Initialized
INFO - 2016-09-19 07:18:09 --> Config Class Initialized
INFO - 2016-09-19 07:18:10 --> Loader Class Initialized
INFO - 2016-09-19 07:18:10 --> Helper loaded: url_helper
INFO - 2016-09-19 07:18:10 --> Database Driver Class Initialized
INFO - 2016-09-19 07:18:10 --> Controller Class Initialized
DEBUG - 2016-09-19 07:18:10 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:18:10 --> Model Class Initialized
INFO - 2016-09-19 07:18:10 --> Model Class Initialized
DEBUG - 2016-09-19 07:18:10 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 07:18:10 --> Database Driver Class Initialized
INFO - 2016-09-19 07:18:10 --> Final output sent to browser
DEBUG - 2016-09-19 07:18:10 --> Total execution time: 0.6843
INFO - 2016-09-19 07:19:09 --> Config Class Initialized
INFO - 2016-09-19 07:19:10 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:19:10 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:19:10 --> Utf8 Class Initialized
INFO - 2016-09-19 07:19:10 --> URI Class Initialized
INFO - 2016-09-19 07:19:10 --> Router Class Initialized
INFO - 2016-09-19 07:19:10 --> Output Class Initialized
INFO - 2016-09-19 07:19:10 --> Security Class Initialized
DEBUG - 2016-09-19 07:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:19:10 --> Input Class Initialized
INFO - 2016-09-19 07:19:10 --> Language Class Initialized
INFO - 2016-09-19 07:19:10 --> Language Class Initialized
INFO - 2016-09-19 07:19:10 --> Config Class Initialized
INFO - 2016-09-19 07:19:10 --> Loader Class Initialized
INFO - 2016-09-19 07:19:10 --> Helper loaded: url_helper
INFO - 2016-09-19 07:19:10 --> Database Driver Class Initialized
INFO - 2016-09-19 07:19:10 --> Controller Class Initialized
DEBUG - 2016-09-19 07:19:10 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:19:10 --> Model Class Initialized
INFO - 2016-09-19 07:19:10 --> Model Class Initialized
DEBUG - 2016-09-19 07:19:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 07:19:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 07:19:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 07:19:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 07:19:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 07:19:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 07:19:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 07:19:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 07:19:10 --> Final output sent to browser
DEBUG - 2016-09-19 07:19:11 --> Total execution time: 0.9663
INFO - 2016-09-19 07:19:21 --> Config Class Initialized
INFO - 2016-09-19 07:19:21 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:19:21 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:19:21 --> Utf8 Class Initialized
INFO - 2016-09-19 07:19:21 --> URI Class Initialized
INFO - 2016-09-19 07:19:21 --> Router Class Initialized
INFO - 2016-09-19 07:19:21 --> Output Class Initialized
INFO - 2016-09-19 07:19:21 --> Security Class Initialized
DEBUG - 2016-09-19 07:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:19:21 --> Input Class Initialized
INFO - 2016-09-19 07:19:21 --> Language Class Initialized
INFO - 2016-09-19 07:19:22 --> Language Class Initialized
INFO - 2016-09-19 07:19:22 --> Config Class Initialized
INFO - 2016-09-19 07:19:22 --> Loader Class Initialized
INFO - 2016-09-19 07:19:22 --> Helper loaded: url_helper
INFO - 2016-09-19 07:19:22 --> Database Driver Class Initialized
INFO - 2016-09-19 07:19:22 --> Controller Class Initialized
DEBUG - 2016-09-19 07:19:22 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:19:22 --> Model Class Initialized
INFO - 2016-09-19 07:19:22 --> Model Class Initialized
DEBUG - 2016-09-19 07:19:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 07:19:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 07:19:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 07:19:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 07:19:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 07:19:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 07:19:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 07:19:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 07:19:22 --> Final output sent to browser
DEBUG - 2016-09-19 07:19:22 --> Total execution time: 0.9437
INFO - 2016-09-19 07:21:00 --> Config Class Initialized
INFO - 2016-09-19 07:21:00 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:21:00 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:21:00 --> Utf8 Class Initialized
INFO - 2016-09-19 07:21:00 --> URI Class Initialized
INFO - 2016-09-19 07:21:00 --> Router Class Initialized
INFO - 2016-09-19 07:21:00 --> Output Class Initialized
INFO - 2016-09-19 07:21:00 --> Security Class Initialized
DEBUG - 2016-09-19 07:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:21:00 --> Input Class Initialized
INFO - 2016-09-19 07:21:00 --> Language Class Initialized
INFO - 2016-09-19 07:21:00 --> Language Class Initialized
INFO - 2016-09-19 07:21:00 --> Config Class Initialized
INFO - 2016-09-19 07:21:00 --> Loader Class Initialized
INFO - 2016-09-19 07:21:00 --> Helper loaded: url_helper
INFO - 2016-09-19 07:21:00 --> Database Driver Class Initialized
INFO - 2016-09-19 07:21:00 --> Controller Class Initialized
DEBUG - 2016-09-19 07:21:00 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:21:00 --> Model Class Initialized
INFO - 2016-09-19 07:21:00 --> Model Class Initialized
DEBUG - 2016-09-19 07:21:00 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 07:21:00 --> Database Driver Class Initialized
INFO - 2016-09-19 07:21:00 --> Final output sent to browser
DEBUG - 2016-09-19 07:21:00 --> Total execution time: 0.8006
INFO - 2016-09-19 07:21:05 --> Config Class Initialized
INFO - 2016-09-19 07:21:05 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:21:05 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:21:05 --> Utf8 Class Initialized
INFO - 2016-09-19 07:21:05 --> URI Class Initialized
INFO - 2016-09-19 07:21:05 --> Router Class Initialized
INFO - 2016-09-19 07:21:05 --> Output Class Initialized
INFO - 2016-09-19 07:21:05 --> Security Class Initialized
DEBUG - 2016-09-19 07:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:21:05 --> Input Class Initialized
INFO - 2016-09-19 07:21:05 --> Language Class Initialized
INFO - 2016-09-19 07:21:05 --> Language Class Initialized
INFO - 2016-09-19 07:21:05 --> Config Class Initialized
INFO - 2016-09-19 07:21:05 --> Loader Class Initialized
INFO - 2016-09-19 07:21:05 --> Helper loaded: url_helper
INFO - 2016-09-19 07:21:05 --> Database Driver Class Initialized
INFO - 2016-09-19 07:21:05 --> Controller Class Initialized
DEBUG - 2016-09-19 07:21:05 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:21:05 --> Model Class Initialized
INFO - 2016-09-19 07:21:05 --> Model Class Initialized
DEBUG - 2016-09-19 07:21:05 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 07:21:05 --> Database Driver Class Initialized
INFO - 2016-09-19 07:21:06 --> Final output sent to browser
DEBUG - 2016-09-19 07:21:06 --> Total execution time: 0.7917
INFO - 2016-09-19 07:21:21 --> Config Class Initialized
INFO - 2016-09-19 07:21:22 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:21:22 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:21:22 --> Utf8 Class Initialized
INFO - 2016-09-19 07:21:22 --> URI Class Initialized
INFO - 2016-09-19 07:21:22 --> Router Class Initialized
INFO - 2016-09-19 07:21:22 --> Output Class Initialized
INFO - 2016-09-19 07:21:22 --> Security Class Initialized
DEBUG - 2016-09-19 07:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:21:22 --> Input Class Initialized
INFO - 2016-09-19 07:21:22 --> Language Class Initialized
INFO - 2016-09-19 07:21:22 --> Language Class Initialized
INFO - 2016-09-19 07:21:22 --> Config Class Initialized
INFO - 2016-09-19 07:21:22 --> Loader Class Initialized
INFO - 2016-09-19 07:21:22 --> Helper loaded: url_helper
INFO - 2016-09-19 07:21:22 --> Database Driver Class Initialized
INFO - 2016-09-19 07:21:22 --> Controller Class Initialized
DEBUG - 2016-09-19 07:21:22 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:21:22 --> Model Class Initialized
INFO - 2016-09-19 07:21:22 --> Model Class Initialized
DEBUG - 2016-09-19 07:21:22 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 07:21:22 --> Database Driver Class Initialized
INFO - 2016-09-19 07:21:22 --> Final output sent to browser
DEBUG - 2016-09-19 07:21:22 --> Total execution time: 0.8794
INFO - 2016-09-19 07:21:25 --> Config Class Initialized
INFO - 2016-09-19 07:21:25 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:21:25 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:21:25 --> Utf8 Class Initialized
INFO - 2016-09-19 07:21:25 --> URI Class Initialized
INFO - 2016-09-19 07:21:25 --> Router Class Initialized
INFO - 2016-09-19 07:21:25 --> Output Class Initialized
INFO - 2016-09-19 07:21:25 --> Security Class Initialized
DEBUG - 2016-09-19 07:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:21:25 --> Input Class Initialized
INFO - 2016-09-19 07:21:25 --> Language Class Initialized
INFO - 2016-09-19 07:21:25 --> Language Class Initialized
INFO - 2016-09-19 07:21:25 --> Config Class Initialized
INFO - 2016-09-19 07:21:25 --> Loader Class Initialized
INFO - 2016-09-19 07:21:25 --> Helper loaded: url_helper
INFO - 2016-09-19 07:21:25 --> Database Driver Class Initialized
INFO - 2016-09-19 07:21:25 --> Controller Class Initialized
DEBUG - 2016-09-19 07:21:25 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:21:25 --> Model Class Initialized
INFO - 2016-09-19 07:21:25 --> Model Class Initialized
DEBUG - 2016-09-19 07:21:26 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 07:21:26 --> Database Driver Class Initialized
INFO - 2016-09-19 07:21:26 --> Final output sent to browser
DEBUG - 2016-09-19 07:21:26 --> Total execution time: 0.7190
INFO - 2016-09-19 07:21:43 --> Config Class Initialized
INFO - 2016-09-19 07:21:43 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:21:43 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:21:43 --> Utf8 Class Initialized
INFO - 2016-09-19 07:21:43 --> URI Class Initialized
INFO - 2016-09-19 07:21:43 --> Router Class Initialized
INFO - 2016-09-19 07:21:43 --> Output Class Initialized
INFO - 2016-09-19 07:21:43 --> Security Class Initialized
DEBUG - 2016-09-19 07:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:21:43 --> Input Class Initialized
INFO - 2016-09-19 07:21:43 --> Language Class Initialized
INFO - 2016-09-19 07:21:43 --> Language Class Initialized
INFO - 2016-09-19 07:21:43 --> Config Class Initialized
INFO - 2016-09-19 07:21:43 --> Loader Class Initialized
INFO - 2016-09-19 07:21:43 --> Helper loaded: url_helper
INFO - 2016-09-19 07:21:43 --> Database Driver Class Initialized
INFO - 2016-09-19 07:21:43 --> Controller Class Initialized
DEBUG - 2016-09-19 07:21:43 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:21:43 --> Model Class Initialized
INFO - 2016-09-19 07:21:43 --> Model Class Initialized
DEBUG - 2016-09-19 07:21:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 07:21:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 07:21:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 07:21:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tabungan.php
DEBUG - 2016-09-19 07:21:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 07:21:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 07:21:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 07:21:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 07:21:44 --> Final output sent to browser
DEBUG - 2016-09-19 07:21:44 --> Total execution time: 0.9328
INFO - 2016-09-19 07:21:50 --> Config Class Initialized
INFO - 2016-09-19 07:21:50 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:21:50 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:21:50 --> Utf8 Class Initialized
INFO - 2016-09-19 07:21:50 --> URI Class Initialized
INFO - 2016-09-19 07:21:50 --> Router Class Initialized
INFO - 2016-09-19 07:21:50 --> Output Class Initialized
INFO - 2016-09-19 07:21:50 --> Security Class Initialized
DEBUG - 2016-09-19 07:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:21:50 --> Input Class Initialized
INFO - 2016-09-19 07:21:50 --> Language Class Initialized
INFO - 2016-09-19 07:21:50 --> Language Class Initialized
INFO - 2016-09-19 07:21:50 --> Config Class Initialized
INFO - 2016-09-19 07:21:50 --> Loader Class Initialized
INFO - 2016-09-19 07:21:50 --> Helper loaded: url_helper
INFO - 2016-09-19 07:21:51 --> Database Driver Class Initialized
INFO - 2016-09-19 07:21:51 --> Controller Class Initialized
DEBUG - 2016-09-19 07:21:51 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:21:51 --> Model Class Initialized
INFO - 2016-09-19 07:21:51 --> Model Class Initialized
INFO - 2016-09-19 07:21:51 --> Database Driver Class Initialized
INFO - 2016-09-19 07:21:51 --> Final output sent to browser
DEBUG - 2016-09-19 07:21:51 --> Total execution time: 0.7689
INFO - 2016-09-19 07:21:55 --> Config Class Initialized
INFO - 2016-09-19 07:21:55 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:21:55 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:21:55 --> Utf8 Class Initialized
INFO - 2016-09-19 07:21:55 --> URI Class Initialized
INFO - 2016-09-19 07:21:55 --> Router Class Initialized
INFO - 2016-09-19 07:21:55 --> Output Class Initialized
INFO - 2016-09-19 07:21:55 --> Security Class Initialized
DEBUG - 2016-09-19 07:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:21:55 --> Input Class Initialized
INFO - 2016-09-19 07:21:55 --> Language Class Initialized
INFO - 2016-09-19 07:21:55 --> Language Class Initialized
INFO - 2016-09-19 07:21:55 --> Config Class Initialized
INFO - 2016-09-19 07:21:55 --> Loader Class Initialized
INFO - 2016-09-19 07:21:56 --> Helper loaded: url_helper
INFO - 2016-09-19 07:21:56 --> Database Driver Class Initialized
INFO - 2016-09-19 07:21:56 --> Controller Class Initialized
DEBUG - 2016-09-19 07:21:56 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:21:56 --> Model Class Initialized
INFO - 2016-09-19 07:21:56 --> Model Class Initialized
INFO - 2016-09-19 07:21:56 --> Database Driver Class Initialized
DEBUG - 2016-09-19 07:21:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 07:21:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 07:21:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 07:21:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tarik_tabungan.php
DEBUG - 2016-09-19 07:21:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 07:21:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 07:21:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 07:21:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 07:21:56 --> Final output sent to browser
DEBUG - 2016-09-19 07:21:56 --> Total execution time: 1.1030
INFO - 2016-09-19 07:24:28 --> Config Class Initialized
INFO - 2016-09-19 07:24:28 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:24:28 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:24:28 --> Utf8 Class Initialized
INFO - 2016-09-19 07:24:28 --> URI Class Initialized
INFO - 2016-09-19 07:24:28 --> Router Class Initialized
INFO - 2016-09-19 07:24:28 --> Output Class Initialized
INFO - 2016-09-19 07:24:28 --> Security Class Initialized
DEBUG - 2016-09-19 07:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:24:28 --> Input Class Initialized
INFO - 2016-09-19 07:24:28 --> Language Class Initialized
INFO - 2016-09-19 07:24:28 --> Language Class Initialized
INFO - 2016-09-19 07:24:28 --> Config Class Initialized
INFO - 2016-09-19 07:24:28 --> Loader Class Initialized
INFO - 2016-09-19 07:24:28 --> Helper loaded: url_helper
INFO - 2016-09-19 07:24:28 --> Database Driver Class Initialized
INFO - 2016-09-19 07:24:28 --> Controller Class Initialized
DEBUG - 2016-09-19 07:24:28 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:24:28 --> Model Class Initialized
INFO - 2016-09-19 07:24:28 --> Model Class Initialized
INFO - 2016-09-19 07:24:28 --> Database Driver Class Initialized
DEBUG - 2016-09-19 07:24:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 07:24:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 07:24:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 07:24:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tarik_tabungan.php
DEBUG - 2016-09-19 07:24:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 07:24:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 07:24:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 07:24:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 07:24:29 --> Final output sent to browser
DEBUG - 2016-09-19 07:24:29 --> Total execution time: 1.0006
INFO - 2016-09-19 07:25:00 --> Config Class Initialized
INFO - 2016-09-19 07:25:00 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:25:00 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:25:00 --> Utf8 Class Initialized
INFO - 2016-09-19 07:25:00 --> URI Class Initialized
INFO - 2016-09-19 07:25:01 --> Router Class Initialized
INFO - 2016-09-19 07:25:01 --> Output Class Initialized
INFO - 2016-09-19 07:25:01 --> Security Class Initialized
DEBUG - 2016-09-19 07:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:25:01 --> Input Class Initialized
INFO - 2016-09-19 07:25:01 --> Language Class Initialized
INFO - 2016-09-19 07:25:01 --> Language Class Initialized
INFO - 2016-09-19 07:25:01 --> Config Class Initialized
INFO - 2016-09-19 07:25:01 --> Loader Class Initialized
INFO - 2016-09-19 07:25:01 --> Helper loaded: url_helper
INFO - 2016-09-19 07:25:01 --> Database Driver Class Initialized
INFO - 2016-09-19 07:25:01 --> Controller Class Initialized
DEBUG - 2016-09-19 07:25:01 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:25:01 --> Model Class Initialized
INFO - 2016-09-19 07:25:01 --> Model Class Initialized
INFO - 2016-09-19 07:25:01 --> Database Driver Class Initialized
DEBUG - 2016-09-19 07:25:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 07:25:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 07:25:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 07:25:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tarik_tabungan.php
DEBUG - 2016-09-19 07:25:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 07:25:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 07:25:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 07:25:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 07:25:01 --> Final output sent to browser
DEBUG - 2016-09-19 07:25:01 --> Total execution time: 1.0530
INFO - 2016-09-19 07:26:18 --> Config Class Initialized
INFO - 2016-09-19 07:26:18 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:26:18 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:26:18 --> Utf8 Class Initialized
INFO - 2016-09-19 07:26:18 --> URI Class Initialized
INFO - 2016-09-19 07:26:18 --> Router Class Initialized
INFO - 2016-09-19 07:26:18 --> Output Class Initialized
INFO - 2016-09-19 07:26:18 --> Security Class Initialized
DEBUG - 2016-09-19 07:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:26:18 --> Input Class Initialized
INFO - 2016-09-19 07:26:18 --> Language Class Initialized
INFO - 2016-09-19 07:26:18 --> Language Class Initialized
INFO - 2016-09-19 07:26:18 --> Config Class Initialized
INFO - 2016-09-19 07:26:18 --> Loader Class Initialized
INFO - 2016-09-19 07:26:18 --> Helper loaded: url_helper
INFO - 2016-09-19 07:26:18 --> Database Driver Class Initialized
INFO - 2016-09-19 07:26:18 --> Controller Class Initialized
DEBUG - 2016-09-19 07:26:18 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:26:18 --> Model Class Initialized
INFO - 2016-09-19 07:26:19 --> Model Class Initialized
INFO - 2016-09-19 07:26:19 --> Database Driver Class Initialized
DEBUG - 2016-09-19 07:26:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 07:26:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 07:26:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 07:26:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tarik_tabungan.php
DEBUG - 2016-09-19 07:26:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 07:26:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 07:26:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 07:26:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 07:26:19 --> Final output sent to browser
DEBUG - 2016-09-19 07:26:19 --> Total execution time: 1.1795
INFO - 2016-09-19 07:26:40 --> Config Class Initialized
INFO - 2016-09-19 07:26:41 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:26:41 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:26:41 --> Utf8 Class Initialized
INFO - 2016-09-19 07:26:41 --> URI Class Initialized
INFO - 2016-09-19 07:26:41 --> Router Class Initialized
INFO - 2016-09-19 07:26:41 --> Output Class Initialized
INFO - 2016-09-19 07:26:41 --> Security Class Initialized
DEBUG - 2016-09-19 07:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:26:41 --> Input Class Initialized
INFO - 2016-09-19 07:26:41 --> Language Class Initialized
INFO - 2016-09-19 07:26:41 --> Language Class Initialized
INFO - 2016-09-19 07:26:41 --> Config Class Initialized
INFO - 2016-09-19 07:26:41 --> Loader Class Initialized
INFO - 2016-09-19 07:26:41 --> Helper loaded: url_helper
INFO - 2016-09-19 07:26:41 --> Database Driver Class Initialized
INFO - 2016-09-19 07:26:41 --> Controller Class Initialized
DEBUG - 2016-09-19 07:26:41 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:26:41 --> Model Class Initialized
INFO - 2016-09-19 07:26:41 --> Model Class Initialized
INFO - 2016-09-19 07:26:41 --> Database Driver Class Initialized
DEBUG - 2016-09-19 07:26:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 07:26:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 07:26:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 07:26:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tarik_tabungan.php
DEBUG - 2016-09-19 07:26:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 07:26:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 07:26:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 07:26:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 07:26:42 --> Final output sent to browser
DEBUG - 2016-09-19 07:26:42 --> Total execution time: 1.0254
INFO - 2016-09-19 07:26:47 --> Config Class Initialized
INFO - 2016-09-19 07:26:47 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:26:47 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:26:47 --> Utf8 Class Initialized
INFO - 2016-09-19 07:26:47 --> URI Class Initialized
INFO - 2016-09-19 07:26:47 --> Router Class Initialized
INFO - 2016-09-19 07:26:47 --> Output Class Initialized
INFO - 2016-09-19 07:26:47 --> Security Class Initialized
DEBUG - 2016-09-19 07:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:26:47 --> Input Class Initialized
INFO - 2016-09-19 07:26:47 --> Language Class Initialized
INFO - 2016-09-19 07:26:47 --> Language Class Initialized
INFO - 2016-09-19 07:26:47 --> Config Class Initialized
INFO - 2016-09-19 07:26:47 --> Loader Class Initialized
INFO - 2016-09-19 07:26:47 --> Helper loaded: url_helper
INFO - 2016-09-19 07:26:47 --> Database Driver Class Initialized
INFO - 2016-09-19 07:26:47 --> Controller Class Initialized
DEBUG - 2016-09-19 07:26:47 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:26:47 --> Model Class Initialized
INFO - 2016-09-19 07:26:47 --> Model Class Initialized
INFO - 2016-09-19 07:26:48 --> Database Driver Class Initialized
INFO - 2016-09-19 07:26:48 --> Database Driver Class Initialized
INFO - 2016-09-19 07:26:48 --> Database Driver Class Initialized
INFO - 2016-09-19 07:26:48 --> Database Driver Class Initialized
INFO - 2016-09-19 07:26:48 --> Database Driver Class Initialized
INFO - 2016-09-19 07:26:48 --> Final output sent to browser
DEBUG - 2016-09-19 07:26:48 --> Total execution time: 1.0449
INFO - 2016-09-19 07:26:55 --> Config Class Initialized
INFO - 2016-09-19 07:26:55 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:26:56 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:26:56 --> Utf8 Class Initialized
INFO - 2016-09-19 07:26:56 --> URI Class Initialized
INFO - 2016-09-19 07:26:56 --> Router Class Initialized
INFO - 2016-09-19 07:26:56 --> Output Class Initialized
INFO - 2016-09-19 07:26:56 --> Security Class Initialized
DEBUG - 2016-09-19 07:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:26:56 --> Input Class Initialized
INFO - 2016-09-19 07:26:56 --> Language Class Initialized
INFO - 2016-09-19 07:26:56 --> Language Class Initialized
INFO - 2016-09-19 07:26:56 --> Config Class Initialized
INFO - 2016-09-19 07:26:56 --> Loader Class Initialized
INFO - 2016-09-19 07:26:56 --> Helper loaded: url_helper
INFO - 2016-09-19 07:26:56 --> Database Driver Class Initialized
INFO - 2016-09-19 07:26:56 --> Controller Class Initialized
DEBUG - 2016-09-19 07:26:56 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:26:56 --> Model Class Initialized
INFO - 2016-09-19 07:26:56 --> Model Class Initialized
DEBUG - 2016-09-19 07:26:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 07:26:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 07:26:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 07:26:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/buku_besar.php
DEBUG - 2016-09-19 07:26:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 07:26:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 07:26:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 07:26:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 07:26:56 --> Final output sent to browser
DEBUG - 2016-09-19 07:26:56 --> Total execution time: 0.9634
INFO - 2016-09-19 07:27:07 --> Config Class Initialized
INFO - 2016-09-19 07:27:07 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:27:07 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:27:07 --> Utf8 Class Initialized
INFO - 2016-09-19 07:27:07 --> URI Class Initialized
INFO - 2016-09-19 07:27:07 --> Router Class Initialized
INFO - 2016-09-19 07:27:07 --> Output Class Initialized
INFO - 2016-09-19 07:27:07 --> Security Class Initialized
DEBUG - 2016-09-19 07:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:27:07 --> Input Class Initialized
INFO - 2016-09-19 07:27:07 --> Language Class Initialized
INFO - 2016-09-19 07:27:07 --> Language Class Initialized
INFO - 2016-09-19 07:27:07 --> Config Class Initialized
INFO - 2016-09-19 07:27:07 --> Loader Class Initialized
INFO - 2016-09-19 07:27:07 --> Helper loaded: url_helper
INFO - 2016-09-19 07:27:07 --> Database Driver Class Initialized
INFO - 2016-09-19 07:27:07 --> Controller Class Initialized
DEBUG - 2016-09-19 07:27:07 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:27:07 --> Model Class Initialized
INFO - 2016-09-19 07:27:07 --> Model Class Initialized
DEBUG - 2016-09-19 07:27:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_buku_besar.php
INFO - 2016-09-19 07:27:07 --> Final output sent to browser
DEBUG - 2016-09-19 07:27:07 --> Total execution time: 0.8177
INFO - 2016-09-19 07:27:14 --> Config Class Initialized
INFO - 2016-09-19 07:27:14 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:27:14 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:27:14 --> Utf8 Class Initialized
INFO - 2016-09-19 07:27:14 --> URI Class Initialized
INFO - 2016-09-19 07:27:14 --> Router Class Initialized
INFO - 2016-09-19 07:27:14 --> Output Class Initialized
INFO - 2016-09-19 07:27:14 --> Security Class Initialized
DEBUG - 2016-09-19 07:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:27:15 --> Input Class Initialized
INFO - 2016-09-19 07:27:15 --> Language Class Initialized
INFO - 2016-09-19 07:27:15 --> Language Class Initialized
INFO - 2016-09-19 07:27:15 --> Config Class Initialized
INFO - 2016-09-19 07:27:15 --> Loader Class Initialized
INFO - 2016-09-19 07:27:15 --> Helper loaded: url_helper
INFO - 2016-09-19 07:27:15 --> Database Driver Class Initialized
INFO - 2016-09-19 07:27:15 --> Controller Class Initialized
DEBUG - 2016-09-19 07:27:15 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:27:15 --> Model Class Initialized
INFO - 2016-09-19 07:27:15 --> Model Class Initialized
DEBUG - 2016-09-19 07:27:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_buku_besar.php
INFO - 2016-09-19 07:27:15 --> Final output sent to browser
DEBUG - 2016-09-19 07:27:15 --> Total execution time: 0.7360
INFO - 2016-09-19 07:27:21 --> Config Class Initialized
INFO - 2016-09-19 07:27:21 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:27:21 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:27:21 --> Utf8 Class Initialized
INFO - 2016-09-19 07:27:21 --> URI Class Initialized
INFO - 2016-09-19 07:27:21 --> Router Class Initialized
INFO - 2016-09-19 07:27:21 --> Output Class Initialized
INFO - 2016-09-19 07:27:21 --> Security Class Initialized
DEBUG - 2016-09-19 07:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:27:21 --> Input Class Initialized
INFO - 2016-09-19 07:27:21 --> Language Class Initialized
INFO - 2016-09-19 07:27:21 --> Language Class Initialized
INFO - 2016-09-19 07:27:21 --> Config Class Initialized
INFO - 2016-09-19 07:27:21 --> Loader Class Initialized
INFO - 2016-09-19 07:27:21 --> Helper loaded: url_helper
INFO - 2016-09-19 07:27:21 --> Database Driver Class Initialized
INFO - 2016-09-19 07:27:21 --> Controller Class Initialized
DEBUG - 2016-09-19 07:27:21 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:27:21 --> Model Class Initialized
INFO - 2016-09-19 07:27:21 --> Model Class Initialized
DEBUG - 2016-09-19 07:27:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 07:27:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 07:27:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 07:27:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_biaya.php
DEBUG - 2016-09-19 07:27:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 07:27:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 07:27:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 07:27:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 07:27:21 --> Final output sent to browser
DEBUG - 2016-09-19 07:27:22 --> Total execution time: 0.9430
INFO - 2016-09-19 07:37:45 --> Config Class Initialized
INFO - 2016-09-19 07:37:45 --> Hooks Class Initialized
DEBUG - 2016-09-19 07:37:45 --> UTF-8 Support Enabled
INFO - 2016-09-19 07:37:45 --> Utf8 Class Initialized
INFO - 2016-09-19 07:37:45 --> URI Class Initialized
INFO - 2016-09-19 07:37:45 --> Router Class Initialized
INFO - 2016-09-19 07:37:45 --> Output Class Initialized
INFO - 2016-09-19 07:37:45 --> Security Class Initialized
DEBUG - 2016-09-19 07:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 07:37:45 --> Input Class Initialized
INFO - 2016-09-19 07:37:45 --> Language Class Initialized
INFO - 2016-09-19 07:37:45 --> Language Class Initialized
INFO - 2016-09-19 07:37:45 --> Config Class Initialized
INFO - 2016-09-19 07:37:45 --> Loader Class Initialized
INFO - 2016-09-19 07:37:45 --> Helper loaded: url_helper
INFO - 2016-09-19 07:37:45 --> Database Driver Class Initialized
INFO - 2016-09-19 07:37:45 --> Controller Class Initialized
DEBUG - 2016-09-19 07:37:45 --> Index MX_Controller Initialized
INFO - 2016-09-19 07:37:45 --> Model Class Initialized
INFO - 2016-09-19 07:37:45 --> Model Class Initialized
DEBUG - 2016-09-19 07:37:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 07:37:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 07:37:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 07:37:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_biaya.php
DEBUG - 2016-09-19 07:37:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 07:37:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 07:37:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 07:37:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 07:37:46 --> Final output sent to browser
DEBUG - 2016-09-19 07:37:46 --> Total execution time: 1.0413
INFO - 2016-09-19 08:50:25 --> Config Class Initialized
INFO - 2016-09-19 08:50:25 --> Hooks Class Initialized
DEBUG - 2016-09-19 08:50:25 --> UTF-8 Support Enabled
INFO - 2016-09-19 08:50:25 --> Utf8 Class Initialized
INFO - 2016-09-19 08:50:25 --> URI Class Initialized
INFO - 2016-09-19 08:50:25 --> Router Class Initialized
INFO - 2016-09-19 08:50:25 --> Output Class Initialized
INFO - 2016-09-19 08:50:26 --> Security Class Initialized
DEBUG - 2016-09-19 08:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 08:50:26 --> Input Class Initialized
INFO - 2016-09-19 08:50:26 --> Language Class Initialized
INFO - 2016-09-19 08:50:26 --> Language Class Initialized
INFO - 2016-09-19 08:50:26 --> Config Class Initialized
INFO - 2016-09-19 08:50:26 --> Loader Class Initialized
INFO - 2016-09-19 08:50:26 --> Helper loaded: url_helper
INFO - 2016-09-19 08:50:26 --> Database Driver Class Initialized
INFO - 2016-09-19 08:50:26 --> Controller Class Initialized
DEBUG - 2016-09-19 08:50:26 --> Index MX_Controller Initialized
INFO - 2016-09-19 08:50:26 --> Model Class Initialized
INFO - 2016-09-19 08:50:26 --> Model Class Initialized
DEBUG - 2016-09-19 08:50:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 08:50:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 08:50:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 08:50:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_peminjam.php
DEBUG - 2016-09-19 08:50:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 08:50:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 08:50:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 08:50:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 08:50:27 --> Final output sent to browser
DEBUG - 2016-09-19 08:50:27 --> Total execution time: 1.7630
INFO - 2016-09-19 08:50:34 --> Config Class Initialized
INFO - 2016-09-19 08:50:34 --> Hooks Class Initialized
DEBUG - 2016-09-19 08:50:34 --> UTF-8 Support Enabled
INFO - 2016-09-19 08:50:34 --> Utf8 Class Initialized
INFO - 2016-09-19 08:50:34 --> URI Class Initialized
INFO - 2016-09-19 08:50:34 --> Router Class Initialized
INFO - 2016-09-19 08:50:34 --> Output Class Initialized
INFO - 2016-09-19 08:50:34 --> Security Class Initialized
DEBUG - 2016-09-19 08:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 08:50:34 --> Input Class Initialized
INFO - 2016-09-19 08:50:34 --> Language Class Initialized
INFO - 2016-09-19 08:50:34 --> Language Class Initialized
INFO - 2016-09-19 08:50:34 --> Config Class Initialized
INFO - 2016-09-19 08:50:34 --> Loader Class Initialized
INFO - 2016-09-19 08:50:34 --> Helper loaded: url_helper
INFO - 2016-09-19 08:50:34 --> Database Driver Class Initialized
INFO - 2016-09-19 08:50:35 --> Controller Class Initialized
DEBUG - 2016-09-19 08:50:35 --> Index MX_Controller Initialized
INFO - 2016-09-19 08:50:35 --> Model Class Initialized
INFO - 2016-09-19 08:50:35 --> Model Class Initialized
DEBUG - 2016-09-19 08:50:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 08:50:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 08:50:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 08:50:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 08:50:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 08:50:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 08:50:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 08:50:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 08:50:35 --> Final output sent to browser
DEBUG - 2016-09-19 08:50:35 --> Total execution time: 1.0999
INFO - 2016-09-19 08:50:41 --> Config Class Initialized
INFO - 2016-09-19 08:50:41 --> Hooks Class Initialized
DEBUG - 2016-09-19 08:50:41 --> UTF-8 Support Enabled
INFO - 2016-09-19 08:50:41 --> Utf8 Class Initialized
INFO - 2016-09-19 08:50:42 --> URI Class Initialized
INFO - 2016-09-19 08:50:42 --> Router Class Initialized
INFO - 2016-09-19 08:50:42 --> Output Class Initialized
INFO - 2016-09-19 08:50:42 --> Security Class Initialized
DEBUG - 2016-09-19 08:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 08:50:42 --> Input Class Initialized
INFO - 2016-09-19 08:50:42 --> Language Class Initialized
INFO - 2016-09-19 08:50:42 --> Language Class Initialized
INFO - 2016-09-19 08:50:42 --> Config Class Initialized
INFO - 2016-09-19 08:50:42 --> Loader Class Initialized
INFO - 2016-09-19 08:50:42 --> Helper loaded: url_helper
INFO - 2016-09-19 08:50:42 --> Database Driver Class Initialized
INFO - 2016-09-19 08:50:42 --> Controller Class Initialized
DEBUG - 2016-09-19 08:50:42 --> Index MX_Controller Initialized
INFO - 2016-09-19 08:50:42 --> Model Class Initialized
INFO - 2016-09-19 08:50:42 --> Model Class Initialized
DEBUG - 2016-09-19 08:50:42 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 08:50:42 --> Database Driver Class Initialized
INFO - 2016-09-19 08:50:42 --> Final output sent to browser
DEBUG - 2016-09-19 08:50:42 --> Total execution time: 0.8070
INFO - 2016-09-19 08:50:46 --> Config Class Initialized
INFO - 2016-09-19 08:50:46 --> Hooks Class Initialized
DEBUG - 2016-09-19 08:50:46 --> UTF-8 Support Enabled
INFO - 2016-09-19 08:50:46 --> Utf8 Class Initialized
INFO - 2016-09-19 08:50:46 --> URI Class Initialized
INFO - 2016-09-19 08:50:46 --> Router Class Initialized
INFO - 2016-09-19 08:50:46 --> Output Class Initialized
INFO - 2016-09-19 08:50:47 --> Security Class Initialized
DEBUG - 2016-09-19 08:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 08:50:47 --> Input Class Initialized
INFO - 2016-09-19 08:50:47 --> Language Class Initialized
INFO - 2016-09-19 08:50:47 --> Language Class Initialized
INFO - 2016-09-19 08:50:47 --> Config Class Initialized
INFO - 2016-09-19 08:50:47 --> Loader Class Initialized
INFO - 2016-09-19 08:50:47 --> Helper loaded: url_helper
INFO - 2016-09-19 08:50:47 --> Database Driver Class Initialized
INFO - 2016-09-19 08:50:47 --> Controller Class Initialized
DEBUG - 2016-09-19 08:50:47 --> Index MX_Controller Initialized
INFO - 2016-09-19 08:50:47 --> Model Class Initialized
INFO - 2016-09-19 08:50:47 --> Model Class Initialized
DEBUG - 2016-09-19 08:50:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 08:50:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 08:50:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 08:50:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-09-19 08:50:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 08:50:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 08:50:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 08:50:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 08:50:47 --> Final output sent to browser
DEBUG - 2016-09-19 08:50:47 --> Total execution time: 1.2042
INFO - 2016-09-19 08:52:10 --> Config Class Initialized
INFO - 2016-09-19 08:52:10 --> Hooks Class Initialized
DEBUG - 2016-09-19 08:52:10 --> UTF-8 Support Enabled
INFO - 2016-09-19 08:52:10 --> Utf8 Class Initialized
INFO - 2016-09-19 08:52:10 --> URI Class Initialized
INFO - 2016-09-19 08:52:10 --> Router Class Initialized
INFO - 2016-09-19 08:52:10 --> Output Class Initialized
INFO - 2016-09-19 08:52:10 --> Security Class Initialized
DEBUG - 2016-09-19 08:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 08:52:10 --> Input Class Initialized
INFO - 2016-09-19 08:52:10 --> Language Class Initialized
INFO - 2016-09-19 08:52:10 --> Language Class Initialized
INFO - 2016-09-19 08:52:10 --> Config Class Initialized
INFO - 2016-09-19 08:52:10 --> Loader Class Initialized
INFO - 2016-09-19 08:52:10 --> Helper loaded: url_helper
INFO - 2016-09-19 08:52:10 --> Database Driver Class Initialized
INFO - 2016-09-19 08:52:10 --> Controller Class Initialized
DEBUG - 2016-09-19 08:52:10 --> Index MX_Controller Initialized
INFO - 2016-09-19 08:52:10 --> Model Class Initialized
INFO - 2016-09-19 08:52:10 --> Model Class Initialized
INFO - 2016-09-19 08:52:10 --> Final output sent to browser
DEBUG - 2016-09-19 08:52:10 --> Total execution time: 0.7265
INFO - 2016-09-19 08:54:53 --> Config Class Initialized
INFO - 2016-09-19 08:54:53 --> Hooks Class Initialized
DEBUG - 2016-09-19 08:54:53 --> UTF-8 Support Enabled
INFO - 2016-09-19 08:54:53 --> Utf8 Class Initialized
INFO - 2016-09-19 08:54:53 --> URI Class Initialized
INFO - 2016-09-19 08:54:53 --> Router Class Initialized
INFO - 2016-09-19 08:54:53 --> Output Class Initialized
INFO - 2016-09-19 08:54:53 --> Security Class Initialized
DEBUG - 2016-09-19 08:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 08:54:53 --> Input Class Initialized
INFO - 2016-09-19 08:54:53 --> Language Class Initialized
INFO - 2016-09-19 08:54:53 --> Language Class Initialized
INFO - 2016-09-19 08:54:53 --> Config Class Initialized
INFO - 2016-09-19 08:54:53 --> Loader Class Initialized
INFO - 2016-09-19 08:54:53 --> Helper loaded: url_helper
INFO - 2016-09-19 08:54:53 --> Database Driver Class Initialized
INFO - 2016-09-19 08:54:53 --> Controller Class Initialized
DEBUG - 2016-09-19 08:54:53 --> Index MX_Controller Initialized
INFO - 2016-09-19 08:54:53 --> Model Class Initialized
INFO - 2016-09-19 08:54:53 --> Model Class Initialized
DEBUG - 2016-09-19 08:54:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 08:54:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 08:54:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 08:54:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 08:54:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 08:54:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 08:54:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 08:54:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 08:54:54 --> Final output sent to browser
DEBUG - 2016-09-19 08:54:54 --> Total execution time: 0.9837
INFO - 2016-09-19 08:54:59 --> Config Class Initialized
INFO - 2016-09-19 08:54:59 --> Hooks Class Initialized
DEBUG - 2016-09-19 08:54:59 --> UTF-8 Support Enabled
INFO - 2016-09-19 08:54:59 --> Utf8 Class Initialized
INFO - 2016-09-19 08:54:59 --> URI Class Initialized
INFO - 2016-09-19 08:54:59 --> Router Class Initialized
INFO - 2016-09-19 08:54:59 --> Output Class Initialized
INFO - 2016-09-19 08:54:59 --> Security Class Initialized
DEBUG - 2016-09-19 08:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 08:54:59 --> Input Class Initialized
INFO - 2016-09-19 08:54:59 --> Language Class Initialized
INFO - 2016-09-19 08:54:59 --> Language Class Initialized
INFO - 2016-09-19 08:54:59 --> Config Class Initialized
INFO - 2016-09-19 08:54:59 --> Loader Class Initialized
INFO - 2016-09-19 08:54:59 --> Helper loaded: url_helper
INFO - 2016-09-19 08:54:59 --> Database Driver Class Initialized
INFO - 2016-09-19 08:54:59 --> Controller Class Initialized
DEBUG - 2016-09-19 08:54:59 --> Index MX_Controller Initialized
INFO - 2016-09-19 08:54:59 --> Model Class Initialized
INFO - 2016-09-19 08:54:59 --> Model Class Initialized
DEBUG - 2016-09-19 08:54:59 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 08:54:59 --> Database Driver Class Initialized
INFO - 2016-09-19 08:54:59 --> Final output sent to browser
DEBUG - 2016-09-19 08:54:59 --> Total execution time: 0.7901
INFO - 2016-09-19 08:56:36 --> Config Class Initialized
INFO - 2016-09-19 08:56:36 --> Hooks Class Initialized
DEBUG - 2016-09-19 08:56:36 --> UTF-8 Support Enabled
INFO - 2016-09-19 08:56:36 --> Utf8 Class Initialized
INFO - 2016-09-19 08:56:36 --> URI Class Initialized
INFO - 2016-09-19 08:56:36 --> Router Class Initialized
INFO - 2016-09-19 08:56:36 --> Output Class Initialized
INFO - 2016-09-19 08:56:36 --> Security Class Initialized
DEBUG - 2016-09-19 08:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 08:56:36 --> Input Class Initialized
INFO - 2016-09-19 08:56:36 --> Language Class Initialized
INFO - 2016-09-19 08:56:36 --> Language Class Initialized
INFO - 2016-09-19 08:56:36 --> Config Class Initialized
INFO - 2016-09-19 08:56:36 --> Loader Class Initialized
INFO - 2016-09-19 08:56:36 --> Helper loaded: url_helper
INFO - 2016-09-19 08:56:37 --> Database Driver Class Initialized
INFO - 2016-09-19 08:56:37 --> Controller Class Initialized
DEBUG - 2016-09-19 08:56:37 --> Index MX_Controller Initialized
INFO - 2016-09-19 08:56:37 --> Model Class Initialized
INFO - 2016-09-19 08:56:37 --> Model Class Initialized
DEBUG - 2016-09-19 08:56:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 08:56:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 08:56:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 08:56:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 08:56:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 08:56:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 08:56:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 08:56:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 08:56:37 --> Final output sent to browser
DEBUG - 2016-09-19 08:56:37 --> Total execution time: 1.0017
INFO - 2016-09-19 08:56:42 --> Config Class Initialized
INFO - 2016-09-19 08:56:42 --> Hooks Class Initialized
DEBUG - 2016-09-19 08:56:42 --> UTF-8 Support Enabled
INFO - 2016-09-19 08:56:42 --> Utf8 Class Initialized
INFO - 2016-09-19 08:56:42 --> URI Class Initialized
INFO - 2016-09-19 08:56:42 --> Router Class Initialized
INFO - 2016-09-19 08:56:42 --> Output Class Initialized
INFO - 2016-09-19 08:56:42 --> Security Class Initialized
DEBUG - 2016-09-19 08:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 08:56:42 --> Input Class Initialized
INFO - 2016-09-19 08:56:42 --> Language Class Initialized
INFO - 2016-09-19 08:56:42 --> Language Class Initialized
INFO - 2016-09-19 08:56:42 --> Config Class Initialized
INFO - 2016-09-19 08:56:42 --> Loader Class Initialized
INFO - 2016-09-19 08:56:42 --> Helper loaded: url_helper
INFO - 2016-09-19 08:56:42 --> Database Driver Class Initialized
INFO - 2016-09-19 08:56:42 --> Controller Class Initialized
DEBUG - 2016-09-19 08:56:42 --> Index MX_Controller Initialized
INFO - 2016-09-19 08:56:42 --> Model Class Initialized
INFO - 2016-09-19 08:56:42 --> Model Class Initialized
DEBUG - 2016-09-19 08:56:42 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 08:56:42 --> Database Driver Class Initialized
INFO - 2016-09-19 08:56:42 --> Final output sent to browser
DEBUG - 2016-09-19 08:56:42 --> Total execution time: 0.7951
INFO - 2016-09-19 08:56:47 --> Config Class Initialized
INFO - 2016-09-19 08:56:47 --> Hooks Class Initialized
DEBUG - 2016-09-19 08:56:47 --> UTF-8 Support Enabled
INFO - 2016-09-19 08:56:47 --> Utf8 Class Initialized
INFO - 2016-09-19 08:56:48 --> URI Class Initialized
INFO - 2016-09-19 08:56:48 --> Router Class Initialized
INFO - 2016-09-19 08:56:48 --> Output Class Initialized
INFO - 2016-09-19 08:56:48 --> Security Class Initialized
DEBUG - 2016-09-19 08:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 08:56:48 --> Input Class Initialized
INFO - 2016-09-19 08:56:48 --> Language Class Initialized
INFO - 2016-09-19 08:56:48 --> Language Class Initialized
INFO - 2016-09-19 08:56:48 --> Config Class Initialized
INFO - 2016-09-19 08:56:48 --> Loader Class Initialized
INFO - 2016-09-19 08:56:48 --> Helper loaded: url_helper
INFO - 2016-09-19 08:56:48 --> Database Driver Class Initialized
INFO - 2016-09-19 08:56:48 --> Controller Class Initialized
DEBUG - 2016-09-19 08:56:48 --> Index MX_Controller Initialized
INFO - 2016-09-19 08:56:48 --> Model Class Initialized
INFO - 2016-09-19 08:56:48 --> Model Class Initialized
INFO - 2016-09-19 08:56:48 --> Final output sent to browser
DEBUG - 2016-09-19 08:56:48 --> Total execution time: 0.7234
INFO - 2016-09-19 08:56:57 --> Config Class Initialized
INFO - 2016-09-19 08:56:57 --> Hooks Class Initialized
DEBUG - 2016-09-19 08:56:57 --> UTF-8 Support Enabled
INFO - 2016-09-19 08:56:58 --> Utf8 Class Initialized
INFO - 2016-09-19 08:56:58 --> URI Class Initialized
INFO - 2016-09-19 08:56:58 --> Router Class Initialized
INFO - 2016-09-19 08:56:58 --> Output Class Initialized
INFO - 2016-09-19 08:56:58 --> Security Class Initialized
DEBUG - 2016-09-19 08:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 08:56:58 --> Input Class Initialized
INFO - 2016-09-19 08:56:58 --> Language Class Initialized
INFO - 2016-09-19 08:56:58 --> Language Class Initialized
INFO - 2016-09-19 08:56:58 --> Config Class Initialized
INFO - 2016-09-19 08:56:58 --> Loader Class Initialized
INFO - 2016-09-19 08:56:58 --> Helper loaded: url_helper
INFO - 2016-09-19 08:56:58 --> Database Driver Class Initialized
INFO - 2016-09-19 08:56:58 --> Controller Class Initialized
DEBUG - 2016-09-19 08:56:58 --> Index MX_Controller Initialized
INFO - 2016-09-19 08:56:58 --> Model Class Initialized
INFO - 2016-09-19 08:56:58 --> Model Class Initialized
DEBUG - 2016-09-19 08:56:58 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 08:56:58 --> Database Driver Class Initialized
INFO - 2016-09-19 08:56:58 --> Final output sent to browser
DEBUG - 2016-09-19 08:56:58 --> Total execution time: 0.9012
INFO - 2016-09-19 08:57:01 --> Config Class Initialized
INFO - 2016-09-19 08:57:01 --> Hooks Class Initialized
DEBUG - 2016-09-19 08:57:01 --> UTF-8 Support Enabled
INFO - 2016-09-19 08:57:01 --> Utf8 Class Initialized
INFO - 2016-09-19 08:57:01 --> URI Class Initialized
INFO - 2016-09-19 08:57:01 --> Router Class Initialized
INFO - 2016-09-19 08:57:01 --> Output Class Initialized
INFO - 2016-09-19 08:57:01 --> Security Class Initialized
DEBUG - 2016-09-19 08:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 08:57:01 --> Input Class Initialized
INFO - 2016-09-19 08:57:01 --> Language Class Initialized
INFO - 2016-09-19 08:57:01 --> Language Class Initialized
INFO - 2016-09-19 08:57:01 --> Config Class Initialized
INFO - 2016-09-19 08:57:01 --> Loader Class Initialized
INFO - 2016-09-19 08:57:01 --> Helper loaded: url_helper
INFO - 2016-09-19 08:57:01 --> Database Driver Class Initialized
INFO - 2016-09-19 08:57:01 --> Controller Class Initialized
DEBUG - 2016-09-19 08:57:01 --> Index MX_Controller Initialized
INFO - 2016-09-19 08:57:01 --> Model Class Initialized
INFO - 2016-09-19 08:57:01 --> Model Class Initialized
INFO - 2016-09-19 08:57:01 --> Final output sent to browser
DEBUG - 2016-09-19 08:57:01 --> Total execution time: 0.7974
INFO - 2016-09-19 08:57:08 --> Config Class Initialized
INFO - 2016-09-19 08:57:08 --> Hooks Class Initialized
DEBUG - 2016-09-19 08:57:08 --> UTF-8 Support Enabled
INFO - 2016-09-19 08:57:09 --> Utf8 Class Initialized
INFO - 2016-09-19 08:57:09 --> URI Class Initialized
INFO - 2016-09-19 08:57:09 --> Router Class Initialized
INFO - 2016-09-19 08:57:09 --> Output Class Initialized
INFO - 2016-09-19 08:57:09 --> Security Class Initialized
DEBUG - 2016-09-19 08:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 08:57:09 --> Input Class Initialized
INFO - 2016-09-19 08:57:09 --> Language Class Initialized
INFO - 2016-09-19 08:57:09 --> Language Class Initialized
INFO - 2016-09-19 08:57:09 --> Config Class Initialized
INFO - 2016-09-19 08:57:09 --> Loader Class Initialized
INFO - 2016-09-19 08:57:09 --> Helper loaded: url_helper
INFO - 2016-09-19 08:57:09 --> Database Driver Class Initialized
INFO - 2016-09-19 08:57:09 --> Controller Class Initialized
DEBUG - 2016-09-19 08:57:09 --> Index MX_Controller Initialized
INFO - 2016-09-19 08:57:09 --> Model Class Initialized
INFO - 2016-09-19 08:57:09 --> Model Class Initialized
DEBUG - 2016-09-19 08:57:09 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 08:57:09 --> Database Driver Class Initialized
INFO - 2016-09-19 08:57:09 --> Final output sent to browser
DEBUG - 2016-09-19 08:57:09 --> Total execution time: 0.7534
INFO - 2016-09-19 08:57:12 --> Config Class Initialized
INFO - 2016-09-19 08:57:12 --> Hooks Class Initialized
DEBUG - 2016-09-19 08:57:12 --> UTF-8 Support Enabled
INFO - 2016-09-19 08:57:12 --> Utf8 Class Initialized
INFO - 2016-09-19 08:57:12 --> URI Class Initialized
INFO - 2016-09-19 08:57:12 --> Router Class Initialized
INFO - 2016-09-19 08:57:12 --> Output Class Initialized
INFO - 2016-09-19 08:57:12 --> Security Class Initialized
DEBUG - 2016-09-19 08:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 08:57:12 --> Input Class Initialized
INFO - 2016-09-19 08:57:12 --> Language Class Initialized
INFO - 2016-09-19 08:57:12 --> Language Class Initialized
INFO - 2016-09-19 08:57:12 --> Config Class Initialized
INFO - 2016-09-19 08:57:12 --> Loader Class Initialized
INFO - 2016-09-19 08:57:12 --> Helper loaded: url_helper
INFO - 2016-09-19 08:57:13 --> Database Driver Class Initialized
INFO - 2016-09-19 08:57:13 --> Controller Class Initialized
DEBUG - 2016-09-19 08:57:13 --> Index MX_Controller Initialized
INFO - 2016-09-19 08:57:13 --> Model Class Initialized
INFO - 2016-09-19 08:57:13 --> Model Class Initialized
INFO - 2016-09-19 08:57:13 --> Final output sent to browser
DEBUG - 2016-09-19 08:57:13 --> Total execution time: 0.8337
INFO - 2016-09-19 08:57:16 --> Config Class Initialized
INFO - 2016-09-19 08:57:16 --> Hooks Class Initialized
DEBUG - 2016-09-19 08:57:16 --> UTF-8 Support Enabled
INFO - 2016-09-19 08:57:16 --> Utf8 Class Initialized
INFO - 2016-09-19 08:57:16 --> URI Class Initialized
INFO - 2016-09-19 08:57:16 --> Router Class Initialized
INFO - 2016-09-19 08:57:16 --> Output Class Initialized
INFO - 2016-09-19 08:57:16 --> Security Class Initialized
DEBUG - 2016-09-19 08:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 08:57:16 --> Input Class Initialized
INFO - 2016-09-19 08:57:17 --> Language Class Initialized
INFO - 2016-09-19 08:57:17 --> Language Class Initialized
INFO - 2016-09-19 08:57:17 --> Config Class Initialized
INFO - 2016-09-19 08:57:17 --> Loader Class Initialized
INFO - 2016-09-19 08:57:17 --> Helper loaded: url_helper
INFO - 2016-09-19 08:57:17 --> Database Driver Class Initialized
INFO - 2016-09-19 08:57:17 --> Controller Class Initialized
DEBUG - 2016-09-19 08:57:17 --> Index MX_Controller Initialized
INFO - 2016-09-19 08:57:17 --> Model Class Initialized
INFO - 2016-09-19 08:57:17 --> Model Class Initialized
INFO - 2016-09-19 08:57:17 --> Final output sent to browser
DEBUG - 2016-09-19 08:57:17 --> Total execution time: 0.7222
INFO - 2016-09-19 08:57:59 --> Config Class Initialized
INFO - 2016-09-19 08:57:59 --> Hooks Class Initialized
DEBUG - 2016-09-19 08:57:59 --> UTF-8 Support Enabled
INFO - 2016-09-19 08:57:59 --> Utf8 Class Initialized
INFO - 2016-09-19 08:57:59 --> URI Class Initialized
INFO - 2016-09-19 08:57:59 --> Router Class Initialized
INFO - 2016-09-19 08:57:59 --> Output Class Initialized
INFO - 2016-09-19 08:57:59 --> Security Class Initialized
DEBUG - 2016-09-19 08:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 08:57:59 --> Input Class Initialized
INFO - 2016-09-19 08:57:59 --> Language Class Initialized
INFO - 2016-09-19 08:57:59 --> Language Class Initialized
INFO - 2016-09-19 08:57:59 --> Config Class Initialized
INFO - 2016-09-19 08:57:59 --> Loader Class Initialized
INFO - 2016-09-19 08:57:59 --> Helper loaded: url_helper
INFO - 2016-09-19 08:58:00 --> Database Driver Class Initialized
INFO - 2016-09-19 08:58:00 --> Controller Class Initialized
DEBUG - 2016-09-19 08:58:00 --> Index MX_Controller Initialized
INFO - 2016-09-19 08:58:00 --> Model Class Initialized
INFO - 2016-09-19 08:58:00 --> Model Class Initialized
DEBUG - 2016-09-19 08:58:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 08:58:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 08:58:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 08:58:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 08:58:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 08:58:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 08:58:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 08:58:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 08:58:00 --> Final output sent to browser
DEBUG - 2016-09-19 08:58:00 --> Total execution time: 1.0427
INFO - 2016-09-19 08:58:05 --> Config Class Initialized
INFO - 2016-09-19 08:58:06 --> Hooks Class Initialized
DEBUG - 2016-09-19 08:58:06 --> UTF-8 Support Enabled
INFO - 2016-09-19 08:58:06 --> Utf8 Class Initialized
INFO - 2016-09-19 08:58:06 --> URI Class Initialized
INFO - 2016-09-19 08:58:06 --> Router Class Initialized
INFO - 2016-09-19 08:58:06 --> Output Class Initialized
INFO - 2016-09-19 08:58:06 --> Security Class Initialized
DEBUG - 2016-09-19 08:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 08:58:06 --> Input Class Initialized
INFO - 2016-09-19 08:58:06 --> Language Class Initialized
INFO - 2016-09-19 08:58:06 --> Language Class Initialized
INFO - 2016-09-19 08:58:06 --> Config Class Initialized
INFO - 2016-09-19 08:58:06 --> Loader Class Initialized
INFO - 2016-09-19 08:58:06 --> Helper loaded: url_helper
INFO - 2016-09-19 08:58:06 --> Database Driver Class Initialized
INFO - 2016-09-19 08:58:06 --> Controller Class Initialized
DEBUG - 2016-09-19 08:58:06 --> Index MX_Controller Initialized
INFO - 2016-09-19 08:58:06 --> Model Class Initialized
INFO - 2016-09-19 08:58:06 --> Model Class Initialized
DEBUG - 2016-09-19 08:58:06 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 08:58:06 --> Database Driver Class Initialized
INFO - 2016-09-19 08:58:06 --> Final output sent to browser
DEBUG - 2016-09-19 08:58:06 --> Total execution time: 0.9250
INFO - 2016-09-19 08:58:11 --> Config Class Initialized
INFO - 2016-09-19 08:58:11 --> Hooks Class Initialized
DEBUG - 2016-09-19 08:58:11 --> UTF-8 Support Enabled
INFO - 2016-09-19 08:58:11 --> Utf8 Class Initialized
INFO - 2016-09-19 08:58:11 --> URI Class Initialized
INFO - 2016-09-19 08:58:11 --> Router Class Initialized
INFO - 2016-09-19 08:58:11 --> Output Class Initialized
INFO - 2016-09-19 08:58:11 --> Security Class Initialized
DEBUG - 2016-09-19 08:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 08:58:11 --> Input Class Initialized
INFO - 2016-09-19 08:58:11 --> Language Class Initialized
INFO - 2016-09-19 08:58:11 --> Language Class Initialized
INFO - 2016-09-19 08:58:11 --> Config Class Initialized
INFO - 2016-09-19 08:58:11 --> Loader Class Initialized
INFO - 2016-09-19 08:58:11 --> Helper loaded: url_helper
INFO - 2016-09-19 08:58:11 --> Database Driver Class Initialized
INFO - 2016-09-19 08:58:11 --> Controller Class Initialized
DEBUG - 2016-09-19 08:58:11 --> Index MX_Controller Initialized
INFO - 2016-09-19 08:58:11 --> Model Class Initialized
INFO - 2016-09-19 08:58:11 --> Model Class Initialized
DEBUG - 2016-09-19 08:58:11 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 08:58:11 --> Database Driver Class Initialized
INFO - 2016-09-19 08:58:11 --> Final output sent to browser
DEBUG - 2016-09-19 08:58:11 --> Total execution time: 0.8654
INFO - 2016-09-19 08:58:45 --> Config Class Initialized
INFO - 2016-09-19 08:58:45 --> Hooks Class Initialized
DEBUG - 2016-09-19 08:58:45 --> UTF-8 Support Enabled
INFO - 2016-09-19 08:58:45 --> Utf8 Class Initialized
INFO - 2016-09-19 08:58:45 --> URI Class Initialized
INFO - 2016-09-19 08:58:45 --> Router Class Initialized
INFO - 2016-09-19 08:58:45 --> Output Class Initialized
INFO - 2016-09-19 08:58:45 --> Security Class Initialized
DEBUG - 2016-09-19 08:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 08:58:45 --> Input Class Initialized
INFO - 2016-09-19 08:58:45 --> Language Class Initialized
INFO - 2016-09-19 08:58:45 --> Language Class Initialized
INFO - 2016-09-19 08:58:45 --> Config Class Initialized
INFO - 2016-09-19 08:58:45 --> Loader Class Initialized
INFO - 2016-09-19 08:58:45 --> Helper loaded: url_helper
INFO - 2016-09-19 08:58:45 --> Database Driver Class Initialized
INFO - 2016-09-19 08:58:45 --> Controller Class Initialized
DEBUG - 2016-09-19 08:58:45 --> Index MX_Controller Initialized
INFO - 2016-09-19 08:58:45 --> Model Class Initialized
INFO - 2016-09-19 08:58:45 --> Model Class Initialized
DEBUG - 2016-09-19 08:58:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 08:58:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 08:58:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 08:58:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 08:58:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 08:58:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 08:58:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 08:58:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 08:58:46 --> Final output sent to browser
DEBUG - 2016-09-19 08:58:46 --> Total execution time: 1.0182
INFO - 2016-09-19 08:59:13 --> Config Class Initialized
INFO - 2016-09-19 08:59:13 --> Hooks Class Initialized
DEBUG - 2016-09-19 08:59:13 --> UTF-8 Support Enabled
INFO - 2016-09-19 08:59:13 --> Utf8 Class Initialized
INFO - 2016-09-19 08:59:13 --> URI Class Initialized
INFO - 2016-09-19 08:59:13 --> Router Class Initialized
INFO - 2016-09-19 08:59:13 --> Output Class Initialized
INFO - 2016-09-19 08:59:13 --> Security Class Initialized
DEBUG - 2016-09-19 08:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 08:59:14 --> Input Class Initialized
INFO - 2016-09-19 08:59:14 --> Language Class Initialized
INFO - 2016-09-19 08:59:14 --> Language Class Initialized
INFO - 2016-09-19 08:59:14 --> Config Class Initialized
INFO - 2016-09-19 08:59:14 --> Loader Class Initialized
INFO - 2016-09-19 08:59:14 --> Helper loaded: url_helper
INFO - 2016-09-19 08:59:14 --> Database Driver Class Initialized
INFO - 2016-09-19 08:59:14 --> Controller Class Initialized
DEBUG - 2016-09-19 08:59:14 --> Index MX_Controller Initialized
INFO - 2016-09-19 08:59:14 --> Model Class Initialized
INFO - 2016-09-19 08:59:14 --> Model Class Initialized
DEBUG - 2016-09-19 08:59:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 08:59:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 08:59:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 08:59:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 08:59:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 08:59:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 08:59:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 08:59:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 08:59:14 --> Final output sent to browser
DEBUG - 2016-09-19 08:59:14 --> Total execution time: 1.0123
INFO - 2016-09-19 08:59:38 --> Config Class Initialized
INFO - 2016-09-19 08:59:39 --> Hooks Class Initialized
DEBUG - 2016-09-19 08:59:39 --> UTF-8 Support Enabled
INFO - 2016-09-19 08:59:39 --> Utf8 Class Initialized
INFO - 2016-09-19 08:59:39 --> URI Class Initialized
INFO - 2016-09-19 08:59:39 --> Router Class Initialized
INFO - 2016-09-19 08:59:39 --> Output Class Initialized
INFO - 2016-09-19 08:59:39 --> Security Class Initialized
DEBUG - 2016-09-19 08:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 08:59:39 --> Input Class Initialized
INFO - 2016-09-19 08:59:39 --> Language Class Initialized
INFO - 2016-09-19 08:59:39 --> Language Class Initialized
INFO - 2016-09-19 08:59:39 --> Config Class Initialized
INFO - 2016-09-19 08:59:39 --> Loader Class Initialized
INFO - 2016-09-19 08:59:39 --> Helper loaded: url_helper
INFO - 2016-09-19 08:59:39 --> Database Driver Class Initialized
INFO - 2016-09-19 08:59:39 --> Controller Class Initialized
DEBUG - 2016-09-19 08:59:39 --> Index MX_Controller Initialized
INFO - 2016-09-19 08:59:39 --> Model Class Initialized
INFO - 2016-09-19 08:59:39 --> Model Class Initialized
DEBUG - 2016-09-19 08:59:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 08:59:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 08:59:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 08:59:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 08:59:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 08:59:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 08:59:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 08:59:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 08:59:40 --> Final output sent to browser
DEBUG - 2016-09-19 08:59:40 --> Total execution time: 1.0650
INFO - 2016-09-19 08:59:44 --> Config Class Initialized
INFO - 2016-09-19 08:59:44 --> Hooks Class Initialized
DEBUG - 2016-09-19 08:59:45 --> UTF-8 Support Enabled
INFO - 2016-09-19 08:59:45 --> Utf8 Class Initialized
INFO - 2016-09-19 08:59:45 --> URI Class Initialized
INFO - 2016-09-19 08:59:45 --> Router Class Initialized
INFO - 2016-09-19 08:59:45 --> Output Class Initialized
INFO - 2016-09-19 08:59:45 --> Security Class Initialized
DEBUG - 2016-09-19 08:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 08:59:45 --> Input Class Initialized
INFO - 2016-09-19 08:59:45 --> Language Class Initialized
INFO - 2016-09-19 08:59:45 --> Language Class Initialized
INFO - 2016-09-19 08:59:45 --> Config Class Initialized
INFO - 2016-09-19 08:59:45 --> Loader Class Initialized
INFO - 2016-09-19 08:59:45 --> Helper loaded: url_helper
INFO - 2016-09-19 08:59:45 --> Database Driver Class Initialized
INFO - 2016-09-19 08:59:45 --> Controller Class Initialized
DEBUG - 2016-09-19 08:59:45 --> Index MX_Controller Initialized
INFO - 2016-09-19 08:59:45 --> Model Class Initialized
INFO - 2016-09-19 08:59:45 --> Model Class Initialized
DEBUG - 2016-09-19 08:59:45 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 08:59:45 --> Database Driver Class Initialized
INFO - 2016-09-19 08:59:45 --> Final output sent to browser
DEBUG - 2016-09-19 08:59:45 --> Total execution time: 0.9338
INFO - 2016-09-19 08:59:50 --> Config Class Initialized
INFO - 2016-09-19 08:59:51 --> Hooks Class Initialized
DEBUG - 2016-09-19 08:59:51 --> UTF-8 Support Enabled
INFO - 2016-09-19 08:59:51 --> Utf8 Class Initialized
INFO - 2016-09-19 08:59:51 --> URI Class Initialized
INFO - 2016-09-19 08:59:51 --> Router Class Initialized
INFO - 2016-09-19 08:59:51 --> Output Class Initialized
INFO - 2016-09-19 08:59:51 --> Security Class Initialized
DEBUG - 2016-09-19 08:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 08:59:51 --> Input Class Initialized
INFO - 2016-09-19 08:59:51 --> Language Class Initialized
INFO - 2016-09-19 08:59:51 --> Language Class Initialized
INFO - 2016-09-19 08:59:51 --> Config Class Initialized
INFO - 2016-09-19 08:59:51 --> Loader Class Initialized
INFO - 2016-09-19 08:59:51 --> Helper loaded: url_helper
INFO - 2016-09-19 08:59:51 --> Database Driver Class Initialized
INFO - 2016-09-19 08:59:51 --> Controller Class Initialized
DEBUG - 2016-09-19 08:59:51 --> Index MX_Controller Initialized
INFO - 2016-09-19 08:59:51 --> Model Class Initialized
INFO - 2016-09-19 08:59:51 --> Model Class Initialized
DEBUG - 2016-09-19 08:59:51 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 08:59:51 --> Final output sent to browser
DEBUG - 2016-09-19 08:59:51 --> Total execution time: 0.7452
INFO - 2016-09-19 08:59:57 --> Config Class Initialized
INFO - 2016-09-19 08:59:57 --> Hooks Class Initialized
DEBUG - 2016-09-19 08:59:57 --> UTF-8 Support Enabled
INFO - 2016-09-19 08:59:57 --> Utf8 Class Initialized
INFO - 2016-09-19 08:59:57 --> URI Class Initialized
INFO - 2016-09-19 08:59:57 --> Router Class Initialized
INFO - 2016-09-19 08:59:57 --> Output Class Initialized
INFO - 2016-09-19 08:59:58 --> Security Class Initialized
DEBUG - 2016-09-19 08:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 08:59:58 --> Input Class Initialized
INFO - 2016-09-19 08:59:58 --> Language Class Initialized
INFO - 2016-09-19 08:59:58 --> Language Class Initialized
INFO - 2016-09-19 08:59:58 --> Config Class Initialized
INFO - 2016-09-19 08:59:58 --> Loader Class Initialized
INFO - 2016-09-19 08:59:58 --> Helper loaded: url_helper
INFO - 2016-09-19 08:59:58 --> Database Driver Class Initialized
INFO - 2016-09-19 08:59:58 --> Controller Class Initialized
DEBUG - 2016-09-19 08:59:58 --> Index MX_Controller Initialized
INFO - 2016-09-19 08:59:58 --> Model Class Initialized
INFO - 2016-09-19 08:59:58 --> Model Class Initialized
DEBUG - 2016-09-19 08:59:58 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 08:59:58 --> Final output sent to browser
DEBUG - 2016-09-19 08:59:58 --> Total execution time: 0.7434
INFO - 2016-09-19 09:00:07 --> Config Class Initialized
INFO - 2016-09-19 09:00:07 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:00:07 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:00:07 --> Utf8 Class Initialized
INFO - 2016-09-19 09:00:07 --> URI Class Initialized
INFO - 2016-09-19 09:00:07 --> Router Class Initialized
INFO - 2016-09-19 09:00:07 --> Output Class Initialized
INFO - 2016-09-19 09:00:07 --> Security Class Initialized
DEBUG - 2016-09-19 09:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:00:07 --> Input Class Initialized
INFO - 2016-09-19 09:00:07 --> Language Class Initialized
INFO - 2016-09-19 09:00:07 --> Language Class Initialized
INFO - 2016-09-19 09:00:07 --> Config Class Initialized
INFO - 2016-09-19 09:00:07 --> Loader Class Initialized
INFO - 2016-09-19 09:00:07 --> Helper loaded: url_helper
INFO - 2016-09-19 09:00:07 --> Database Driver Class Initialized
INFO - 2016-09-19 09:00:07 --> Controller Class Initialized
DEBUG - 2016-09-19 09:00:07 --> Index MX_Controller Initialized
INFO - 2016-09-19 09:00:07 --> Model Class Initialized
INFO - 2016-09-19 09:00:07 --> Model Class Initialized
DEBUG - 2016-09-19 09:00:07 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 09:00:07 --> Database Driver Class Initialized
INFO - 2016-09-19 09:00:08 --> Final output sent to browser
DEBUG - 2016-09-19 09:00:08 --> Total execution time: 0.8284
INFO - 2016-09-19 09:00:11 --> Config Class Initialized
INFO - 2016-09-19 09:00:11 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:00:11 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:00:11 --> Utf8 Class Initialized
INFO - 2016-09-19 09:00:11 --> URI Class Initialized
INFO - 2016-09-19 09:00:11 --> Router Class Initialized
INFO - 2016-09-19 09:00:11 --> Output Class Initialized
INFO - 2016-09-19 09:00:12 --> Security Class Initialized
DEBUG - 2016-09-19 09:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:00:12 --> Input Class Initialized
INFO - 2016-09-19 09:00:12 --> Language Class Initialized
INFO - 2016-09-19 09:00:12 --> Language Class Initialized
INFO - 2016-09-19 09:00:12 --> Config Class Initialized
INFO - 2016-09-19 09:00:12 --> Loader Class Initialized
INFO - 2016-09-19 09:00:12 --> Helper loaded: url_helper
INFO - 2016-09-19 09:00:12 --> Database Driver Class Initialized
INFO - 2016-09-19 09:00:12 --> Controller Class Initialized
DEBUG - 2016-09-19 09:00:12 --> Index MX_Controller Initialized
INFO - 2016-09-19 09:00:12 --> Model Class Initialized
INFO - 2016-09-19 09:00:12 --> Model Class Initialized
DEBUG - 2016-09-19 09:00:12 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 09:00:12 --> Final output sent to browser
DEBUG - 2016-09-19 09:00:12 --> Total execution time: 0.7767
INFO - 2016-09-19 09:00:34 --> Config Class Initialized
INFO - 2016-09-19 09:00:34 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:00:34 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:00:34 --> Utf8 Class Initialized
INFO - 2016-09-19 09:00:34 --> URI Class Initialized
INFO - 2016-09-19 09:00:34 --> Router Class Initialized
INFO - 2016-09-19 09:00:34 --> Output Class Initialized
INFO - 2016-09-19 09:00:34 --> Security Class Initialized
DEBUG - 2016-09-19 09:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:00:34 --> Input Class Initialized
INFO - 2016-09-19 09:00:34 --> Language Class Initialized
INFO - 2016-09-19 09:00:34 --> Language Class Initialized
INFO - 2016-09-19 09:00:34 --> Config Class Initialized
INFO - 2016-09-19 09:00:34 --> Loader Class Initialized
INFO - 2016-09-19 09:00:34 --> Helper loaded: url_helper
INFO - 2016-09-19 09:00:34 --> Database Driver Class Initialized
INFO - 2016-09-19 09:00:34 --> Controller Class Initialized
DEBUG - 2016-09-19 09:00:34 --> Index MX_Controller Initialized
INFO - 2016-09-19 09:00:34 --> Model Class Initialized
INFO - 2016-09-19 09:00:34 --> Model Class Initialized
DEBUG - 2016-09-19 09:00:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 09:00:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 09:00:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 09:00:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 09:00:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 09:00:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 09:00:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 09:00:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 09:00:35 --> Final output sent to browser
DEBUG - 2016-09-19 09:00:35 --> Total execution time: 1.0944
INFO - 2016-09-19 09:00:42 --> Config Class Initialized
INFO - 2016-09-19 09:00:42 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:00:42 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:00:42 --> Utf8 Class Initialized
INFO - 2016-09-19 09:00:42 --> URI Class Initialized
INFO - 2016-09-19 09:00:42 --> Router Class Initialized
INFO - 2016-09-19 09:00:42 --> Output Class Initialized
INFO - 2016-09-19 09:00:42 --> Security Class Initialized
DEBUG - 2016-09-19 09:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:00:42 --> Input Class Initialized
INFO - 2016-09-19 09:00:42 --> Language Class Initialized
INFO - 2016-09-19 09:00:42 --> Language Class Initialized
INFO - 2016-09-19 09:00:42 --> Config Class Initialized
INFO - 2016-09-19 09:00:42 --> Loader Class Initialized
INFO - 2016-09-19 09:00:43 --> Helper loaded: url_helper
INFO - 2016-09-19 09:00:43 --> Database Driver Class Initialized
INFO - 2016-09-19 09:00:43 --> Controller Class Initialized
DEBUG - 2016-09-19 09:00:43 --> Index MX_Controller Initialized
INFO - 2016-09-19 09:00:43 --> Model Class Initialized
INFO - 2016-09-19 09:00:43 --> Model Class Initialized
DEBUG - 2016-09-19 09:00:43 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 09:00:43 --> Database Driver Class Initialized
INFO - 2016-09-19 09:00:43 --> Final output sent to browser
DEBUG - 2016-09-19 09:00:43 --> Total execution time: 0.9255
INFO - 2016-09-19 09:00:47 --> Config Class Initialized
INFO - 2016-09-19 09:00:48 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:00:48 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:00:48 --> Utf8 Class Initialized
INFO - 2016-09-19 09:00:48 --> URI Class Initialized
INFO - 2016-09-19 09:00:48 --> Router Class Initialized
INFO - 2016-09-19 09:00:48 --> Output Class Initialized
INFO - 2016-09-19 09:00:48 --> Security Class Initialized
DEBUG - 2016-09-19 09:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:00:48 --> Input Class Initialized
INFO - 2016-09-19 09:00:48 --> Language Class Initialized
INFO - 2016-09-19 09:00:48 --> Language Class Initialized
INFO - 2016-09-19 09:00:48 --> Config Class Initialized
INFO - 2016-09-19 09:00:48 --> Loader Class Initialized
INFO - 2016-09-19 09:00:48 --> Helper loaded: url_helper
INFO - 2016-09-19 09:00:48 --> Database Driver Class Initialized
INFO - 2016-09-19 09:00:48 --> Controller Class Initialized
DEBUG - 2016-09-19 09:00:48 --> Index MX_Controller Initialized
INFO - 2016-09-19 09:00:48 --> Model Class Initialized
INFO - 2016-09-19 09:00:48 --> Model Class Initialized
DEBUG - 2016-09-19 09:00:48 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 09:00:48 --> Final output sent to browser
DEBUG - 2016-09-19 09:00:48 --> Total execution time: 0.7340
INFO - 2016-09-19 09:00:54 --> Config Class Initialized
INFO - 2016-09-19 09:00:54 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:00:54 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:00:54 --> Utf8 Class Initialized
INFO - 2016-09-19 09:00:54 --> URI Class Initialized
INFO - 2016-09-19 09:00:54 --> Router Class Initialized
INFO - 2016-09-19 09:00:54 --> Output Class Initialized
INFO - 2016-09-19 09:00:54 --> Security Class Initialized
DEBUG - 2016-09-19 09:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:00:55 --> Input Class Initialized
INFO - 2016-09-19 09:00:55 --> Language Class Initialized
INFO - 2016-09-19 09:00:55 --> Language Class Initialized
INFO - 2016-09-19 09:00:55 --> Config Class Initialized
INFO - 2016-09-19 09:00:55 --> Loader Class Initialized
INFO - 2016-09-19 09:00:55 --> Helper loaded: url_helper
INFO - 2016-09-19 09:00:55 --> Database Driver Class Initialized
INFO - 2016-09-19 09:00:55 --> Controller Class Initialized
DEBUG - 2016-09-19 09:00:55 --> Index MX_Controller Initialized
INFO - 2016-09-19 09:00:55 --> Model Class Initialized
INFO - 2016-09-19 09:00:55 --> Model Class Initialized
DEBUG - 2016-09-19 09:00:55 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 09:00:55 --> Database Driver Class Initialized
INFO - 2016-09-19 09:00:55 --> Final output sent to browser
DEBUG - 2016-09-19 09:00:55 --> Total execution time: 0.7489
INFO - 2016-09-19 09:00:59 --> Config Class Initialized
INFO - 2016-09-19 09:00:59 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:00:59 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:00:59 --> Utf8 Class Initialized
INFO - 2016-09-19 09:00:59 --> URI Class Initialized
INFO - 2016-09-19 09:00:59 --> Router Class Initialized
INFO - 2016-09-19 09:00:59 --> Output Class Initialized
INFO - 2016-09-19 09:00:59 --> Security Class Initialized
DEBUG - 2016-09-19 09:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:00:59 --> Input Class Initialized
INFO - 2016-09-19 09:00:59 --> Language Class Initialized
INFO - 2016-09-19 09:00:59 --> Language Class Initialized
INFO - 2016-09-19 09:00:59 --> Config Class Initialized
INFO - 2016-09-19 09:00:59 --> Loader Class Initialized
INFO - 2016-09-19 09:00:59 --> Helper loaded: url_helper
INFO - 2016-09-19 09:00:59 --> Database Driver Class Initialized
INFO - 2016-09-19 09:00:59 --> Controller Class Initialized
DEBUG - 2016-09-19 09:00:59 --> Index MX_Controller Initialized
INFO - 2016-09-19 09:00:59 --> Model Class Initialized
INFO - 2016-09-19 09:00:59 --> Model Class Initialized
DEBUG - 2016-09-19 09:00:59 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 09:01:00 --> Database Driver Class Initialized
INFO - 2016-09-19 09:01:00 --> Final output sent to browser
DEBUG - 2016-09-19 09:01:00 --> Total execution time: 0.7702
INFO - 2016-09-19 09:01:54 --> Config Class Initialized
INFO - 2016-09-19 09:01:54 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:01:54 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:01:54 --> Utf8 Class Initialized
INFO - 2016-09-19 09:01:54 --> URI Class Initialized
INFO - 2016-09-19 09:01:54 --> Router Class Initialized
INFO - 2016-09-19 09:01:54 --> Output Class Initialized
INFO - 2016-09-19 09:01:54 --> Security Class Initialized
DEBUG - 2016-09-19 09:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:01:54 --> Input Class Initialized
INFO - 2016-09-19 09:01:54 --> Language Class Initialized
INFO - 2016-09-19 09:01:55 --> Language Class Initialized
INFO - 2016-09-19 09:01:55 --> Config Class Initialized
INFO - 2016-09-19 09:01:55 --> Loader Class Initialized
INFO - 2016-09-19 09:01:55 --> Helper loaded: url_helper
INFO - 2016-09-19 09:01:55 --> Database Driver Class Initialized
INFO - 2016-09-19 09:01:55 --> Controller Class Initialized
DEBUG - 2016-09-19 09:01:55 --> Index MX_Controller Initialized
INFO - 2016-09-19 09:01:55 --> Model Class Initialized
INFO - 2016-09-19 09:01:55 --> Model Class Initialized
DEBUG - 2016-09-19 09:01:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 09:01:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 09:01:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 09:01:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 09:01:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 09:01:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 09:01:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 09:01:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 09:01:55 --> Final output sent to browser
DEBUG - 2016-09-19 09:01:55 --> Total execution time: 1.2110
INFO - 2016-09-19 09:02:01 --> Config Class Initialized
INFO - 2016-09-19 09:02:01 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:02:01 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:02:01 --> Utf8 Class Initialized
INFO - 2016-09-19 09:02:01 --> URI Class Initialized
INFO - 2016-09-19 09:02:01 --> Router Class Initialized
INFO - 2016-09-19 09:02:01 --> Output Class Initialized
INFO - 2016-09-19 09:02:01 --> Security Class Initialized
DEBUG - 2016-09-19 09:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:02:02 --> Input Class Initialized
INFO - 2016-09-19 09:02:02 --> Language Class Initialized
INFO - 2016-09-19 09:02:02 --> Language Class Initialized
INFO - 2016-09-19 09:02:02 --> Config Class Initialized
INFO - 2016-09-19 09:02:02 --> Loader Class Initialized
INFO - 2016-09-19 09:02:02 --> Helper loaded: url_helper
INFO - 2016-09-19 09:02:02 --> Database Driver Class Initialized
INFO - 2016-09-19 09:02:02 --> Controller Class Initialized
DEBUG - 2016-09-19 09:02:02 --> Index MX_Controller Initialized
INFO - 2016-09-19 09:02:02 --> Model Class Initialized
INFO - 2016-09-19 09:02:02 --> Model Class Initialized
DEBUG - 2016-09-19 09:02:02 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 09:02:02 --> Database Driver Class Initialized
INFO - 2016-09-19 09:02:02 --> Final output sent to browser
DEBUG - 2016-09-19 09:02:02 --> Total execution time: 0.8223
INFO - 2016-09-19 09:02:04 --> Config Class Initialized
INFO - 2016-09-19 09:02:04 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:02:04 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:02:04 --> Utf8 Class Initialized
INFO - 2016-09-19 09:02:04 --> URI Class Initialized
INFO - 2016-09-19 09:02:04 --> Router Class Initialized
INFO - 2016-09-19 09:02:04 --> Output Class Initialized
INFO - 2016-09-19 09:02:04 --> Security Class Initialized
DEBUG - 2016-09-19 09:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:02:04 --> Input Class Initialized
INFO - 2016-09-19 09:02:04 --> Language Class Initialized
INFO - 2016-09-19 09:02:04 --> Language Class Initialized
INFO - 2016-09-19 09:02:04 --> Config Class Initialized
INFO - 2016-09-19 09:02:04 --> Loader Class Initialized
INFO - 2016-09-19 09:02:04 --> Helper loaded: url_helper
INFO - 2016-09-19 09:02:05 --> Database Driver Class Initialized
INFO - 2016-09-19 09:02:05 --> Controller Class Initialized
DEBUG - 2016-09-19 09:02:05 --> Index MX_Controller Initialized
INFO - 2016-09-19 09:02:05 --> Model Class Initialized
INFO - 2016-09-19 09:02:05 --> Model Class Initialized
INFO - 2016-09-19 09:02:05 --> Final output sent to browser
DEBUG - 2016-09-19 09:02:05 --> Total execution time: 0.8040
INFO - 2016-09-19 09:02:08 --> Config Class Initialized
INFO - 2016-09-19 09:02:08 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:02:08 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:02:08 --> Utf8 Class Initialized
INFO - 2016-09-19 09:02:08 --> URI Class Initialized
INFO - 2016-09-19 09:02:08 --> Router Class Initialized
INFO - 2016-09-19 09:02:08 --> Output Class Initialized
INFO - 2016-09-19 09:02:08 --> Security Class Initialized
DEBUG - 2016-09-19 09:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:02:08 --> Input Class Initialized
INFO - 2016-09-19 09:02:09 --> Language Class Initialized
INFO - 2016-09-19 09:02:09 --> Language Class Initialized
INFO - 2016-09-19 09:02:09 --> Config Class Initialized
INFO - 2016-09-19 09:02:09 --> Loader Class Initialized
INFO - 2016-09-19 09:02:09 --> Helper loaded: url_helper
INFO - 2016-09-19 09:02:09 --> Database Driver Class Initialized
INFO - 2016-09-19 09:02:09 --> Controller Class Initialized
DEBUG - 2016-09-19 09:02:09 --> Index MX_Controller Initialized
INFO - 2016-09-19 09:02:09 --> Model Class Initialized
INFO - 2016-09-19 09:02:09 --> Model Class Initialized
INFO - 2016-09-19 09:02:09 --> Final output sent to browser
DEBUG - 2016-09-19 09:02:09 --> Total execution time: 0.7588
INFO - 2016-09-19 09:02:12 --> Config Class Initialized
INFO - 2016-09-19 09:02:12 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:02:12 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:02:12 --> Utf8 Class Initialized
INFO - 2016-09-19 09:02:12 --> URI Class Initialized
INFO - 2016-09-19 09:02:12 --> Router Class Initialized
INFO - 2016-09-19 09:02:12 --> Output Class Initialized
INFO - 2016-09-19 09:02:12 --> Security Class Initialized
DEBUG - 2016-09-19 09:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:02:12 --> Input Class Initialized
INFO - 2016-09-19 09:02:12 --> Language Class Initialized
INFO - 2016-09-19 09:02:12 --> Language Class Initialized
INFO - 2016-09-19 09:02:12 --> Config Class Initialized
INFO - 2016-09-19 09:02:12 --> Loader Class Initialized
INFO - 2016-09-19 09:02:12 --> Helper loaded: url_helper
INFO - 2016-09-19 09:02:12 --> Database Driver Class Initialized
INFO - 2016-09-19 09:02:12 --> Controller Class Initialized
DEBUG - 2016-09-19 09:02:12 --> Index MX_Controller Initialized
INFO - 2016-09-19 09:02:13 --> Model Class Initialized
INFO - 2016-09-19 09:02:13 --> Model Class Initialized
INFO - 2016-09-19 09:02:13 --> Final output sent to browser
DEBUG - 2016-09-19 09:02:13 --> Total execution time: 0.9886
INFO - 2016-09-19 09:02:17 --> Config Class Initialized
INFO - 2016-09-19 09:02:17 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:02:17 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:02:17 --> Utf8 Class Initialized
INFO - 2016-09-19 09:02:17 --> URI Class Initialized
INFO - 2016-09-19 09:02:17 --> Router Class Initialized
INFO - 2016-09-19 09:02:17 --> Output Class Initialized
INFO - 2016-09-19 09:02:17 --> Security Class Initialized
DEBUG - 2016-09-19 09:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:02:17 --> Input Class Initialized
INFO - 2016-09-19 09:02:17 --> Language Class Initialized
INFO - 2016-09-19 09:02:17 --> Language Class Initialized
INFO - 2016-09-19 09:02:17 --> Config Class Initialized
INFO - 2016-09-19 09:02:17 --> Loader Class Initialized
INFO - 2016-09-19 09:02:17 --> Helper loaded: url_helper
INFO - 2016-09-19 09:02:17 --> Database Driver Class Initialized
INFO - 2016-09-19 09:02:17 --> Controller Class Initialized
DEBUG - 2016-09-19 09:02:17 --> Index MX_Controller Initialized
INFO - 2016-09-19 09:02:17 --> Model Class Initialized
INFO - 2016-09-19 09:02:18 --> Model Class Initialized
INFO - 2016-09-19 09:02:18 --> Final output sent to browser
DEBUG - 2016-09-19 09:02:18 --> Total execution time: 0.7607
INFO - 2016-09-19 09:06:00 --> Config Class Initialized
INFO - 2016-09-19 09:06:00 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:06:00 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:06:00 --> Utf8 Class Initialized
INFO - 2016-09-19 09:06:00 --> URI Class Initialized
INFO - 2016-09-19 09:06:00 --> Router Class Initialized
INFO - 2016-09-19 09:06:00 --> Output Class Initialized
INFO - 2016-09-19 09:06:00 --> Security Class Initialized
DEBUG - 2016-09-19 09:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:06:00 --> Input Class Initialized
INFO - 2016-09-19 09:06:00 --> Language Class Initialized
INFO - 2016-09-19 09:06:00 --> Language Class Initialized
INFO - 2016-09-19 09:06:00 --> Config Class Initialized
INFO - 2016-09-19 09:06:00 --> Loader Class Initialized
INFO - 2016-09-19 09:06:00 --> Helper loaded: url_helper
INFO - 2016-09-19 09:06:00 --> Database Driver Class Initialized
INFO - 2016-09-19 09:06:00 --> Controller Class Initialized
DEBUG - 2016-09-19 09:06:01 --> Index MX_Controller Initialized
INFO - 2016-09-19 09:06:01 --> Model Class Initialized
INFO - 2016-09-19 09:06:01 --> Model Class Initialized
DEBUG - 2016-09-19 09:06:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 09:06:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 09:06:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 09:06:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_umum.php
DEBUG - 2016-09-19 09:06:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 09:06:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 09:06:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 09:06:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 09:06:01 --> Final output sent to browser
DEBUG - 2016-09-19 09:06:01 --> Total execution time: 1.0446
INFO - 2016-09-19 09:06:08 --> Config Class Initialized
INFO - 2016-09-19 09:06:08 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:06:08 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:06:08 --> Utf8 Class Initialized
INFO - 2016-09-19 09:06:08 --> URI Class Initialized
INFO - 2016-09-19 09:06:08 --> Router Class Initialized
INFO - 2016-09-19 09:06:08 --> Output Class Initialized
INFO - 2016-09-19 09:06:08 --> Security Class Initialized
DEBUG - 2016-09-19 09:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:06:09 --> Input Class Initialized
INFO - 2016-09-19 09:06:09 --> Language Class Initialized
INFO - 2016-09-19 09:06:09 --> Language Class Initialized
INFO - 2016-09-19 09:06:09 --> Config Class Initialized
INFO - 2016-09-19 09:06:09 --> Loader Class Initialized
INFO - 2016-09-19 09:06:09 --> Helper loaded: url_helper
INFO - 2016-09-19 09:06:09 --> Database Driver Class Initialized
INFO - 2016-09-19 09:06:09 --> Controller Class Initialized
DEBUG - 2016-09-19 09:06:09 --> Index MX_Controller Initialized
INFO - 2016-09-19 09:06:09 --> Model Class Initialized
INFO - 2016-09-19 09:06:09 --> Model Class Initialized
DEBUG - 2016-09-19 09:06:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 09:06:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 09:06:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 09:06:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_umum.php
DEBUG - 2016-09-19 09:06:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 09:06:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 09:06:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 09:06:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 09:06:09 --> Final output sent to browser
DEBUG - 2016-09-19 09:06:09 --> Total execution time: 1.0967
INFO - 2016-09-19 09:18:35 --> Config Class Initialized
INFO - 2016-09-19 09:18:35 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:18:35 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:18:35 --> Utf8 Class Initialized
INFO - 2016-09-19 09:18:35 --> URI Class Initialized
INFO - 2016-09-19 09:18:35 --> Router Class Initialized
INFO - 2016-09-19 09:18:35 --> Output Class Initialized
INFO - 2016-09-19 09:18:35 --> Security Class Initialized
DEBUG - 2016-09-19 09:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:18:35 --> Input Class Initialized
INFO - 2016-09-19 09:18:35 --> Language Class Initialized
INFO - 2016-09-19 09:18:35 --> Language Class Initialized
INFO - 2016-09-19 09:18:35 --> Config Class Initialized
INFO - 2016-09-19 09:18:35 --> Loader Class Initialized
INFO - 2016-09-19 09:18:35 --> Helper loaded: url_helper
INFO - 2016-09-19 09:18:35 --> Database Driver Class Initialized
INFO - 2016-09-19 09:18:35 --> Controller Class Initialized
DEBUG - 2016-09-19 09:18:36 --> Index MX_Controller Initialized
INFO - 2016-09-19 09:18:36 --> Model Class Initialized
INFO - 2016-09-19 09:18:36 --> Model Class Initialized
INFO - 2016-09-19 09:18:36 --> Database Driver Class Initialized
INFO - 2016-09-19 09:18:36 --> Final output sent to browser
DEBUG - 2016-09-19 09:18:36 --> Total execution time: 0.8757
INFO - 2016-09-19 09:18:42 --> Config Class Initialized
INFO - 2016-09-19 09:18:42 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:18:42 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:18:42 --> Utf8 Class Initialized
INFO - 2016-09-19 09:18:42 --> URI Class Initialized
INFO - 2016-09-19 09:18:42 --> Router Class Initialized
INFO - 2016-09-19 09:18:42 --> Output Class Initialized
INFO - 2016-09-19 09:18:42 --> Security Class Initialized
DEBUG - 2016-09-19 09:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:18:42 --> Input Class Initialized
INFO - 2016-09-19 09:18:42 --> Language Class Initialized
INFO - 2016-09-19 09:18:42 --> Language Class Initialized
INFO - 2016-09-19 09:18:42 --> Config Class Initialized
INFO - 2016-09-19 09:18:42 --> Loader Class Initialized
INFO - 2016-09-19 09:18:42 --> Helper loaded: url_helper
INFO - 2016-09-19 09:18:42 --> Database Driver Class Initialized
INFO - 2016-09-19 09:18:43 --> Controller Class Initialized
DEBUG - 2016-09-19 09:18:43 --> Index MX_Controller Initialized
INFO - 2016-09-19 09:18:43 --> Model Class Initialized
INFO - 2016-09-19 09:18:43 --> Model Class Initialized
INFO - 2016-09-19 09:18:43 --> Database Driver Class Initialized
INFO - 2016-09-19 09:18:43 --> Final output sent to browser
DEBUG - 2016-09-19 09:18:43 --> Total execution time: 0.9440
INFO - 2016-09-19 09:18:59 --> Config Class Initialized
INFO - 2016-09-19 09:18:59 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:18:59 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:18:59 --> Utf8 Class Initialized
INFO - 2016-09-19 09:18:59 --> URI Class Initialized
INFO - 2016-09-19 09:18:59 --> Router Class Initialized
INFO - 2016-09-19 09:18:59 --> Output Class Initialized
INFO - 2016-09-19 09:18:59 --> Security Class Initialized
DEBUG - 2016-09-19 09:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:18:59 --> Input Class Initialized
INFO - 2016-09-19 09:18:59 --> Language Class Initialized
INFO - 2016-09-19 09:18:59 --> Language Class Initialized
INFO - 2016-09-19 09:18:59 --> Config Class Initialized
INFO - 2016-09-19 09:18:59 --> Loader Class Initialized
INFO - 2016-09-19 09:18:59 --> Helper loaded: url_helper
INFO - 2016-09-19 09:18:59 --> Database Driver Class Initialized
INFO - 2016-09-19 09:18:59 --> Controller Class Initialized
DEBUG - 2016-09-19 09:18:59 --> Index MX_Controller Initialized
INFO - 2016-09-19 09:18:59 --> Model Class Initialized
INFO - 2016-09-19 09:18:59 --> Model Class Initialized
INFO - 2016-09-19 09:18:59 --> Database Driver Class Initialized
INFO - 2016-09-19 09:18:59 --> Database Driver Class Initialized
INFO - 2016-09-19 09:19:00 --> Final output sent to browser
DEBUG - 2016-09-19 09:19:00 --> Total execution time: 0.9789
INFO - 2016-09-19 09:19:05 --> Config Class Initialized
INFO - 2016-09-19 09:19:05 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:19:05 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:19:05 --> Utf8 Class Initialized
INFO - 2016-09-19 09:19:05 --> URI Class Initialized
INFO - 2016-09-19 09:19:05 --> Router Class Initialized
INFO - 2016-09-19 09:19:05 --> Output Class Initialized
INFO - 2016-09-19 09:19:05 --> Security Class Initialized
DEBUG - 2016-09-19 09:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:19:05 --> Input Class Initialized
INFO - 2016-09-19 09:19:05 --> Language Class Initialized
INFO - 2016-09-19 09:19:05 --> Language Class Initialized
INFO - 2016-09-19 09:19:05 --> Config Class Initialized
INFO - 2016-09-19 09:19:05 --> Loader Class Initialized
INFO - 2016-09-19 09:19:05 --> Helper loaded: url_helper
INFO - 2016-09-19 09:19:05 --> Database Driver Class Initialized
INFO - 2016-09-19 09:19:05 --> Controller Class Initialized
DEBUG - 2016-09-19 09:19:05 --> Index MX_Controller Initialized
INFO - 2016-09-19 09:19:05 --> Model Class Initialized
INFO - 2016-09-19 09:19:06 --> Model Class Initialized
DEBUG - 2016-09-19 09:19:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 09:19:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 09:19:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 09:19:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_bayar_angsuran.php
DEBUG - 2016-09-19 09:19:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 09:19:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 09:19:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 09:19:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 09:19:06 --> Final output sent to browser
DEBUG - 2016-09-19 09:19:06 --> Total execution time: 1.0004
INFO - 2016-09-19 09:46:41 --> Config Class Initialized
INFO - 2016-09-19 09:46:41 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:46:41 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:46:41 --> Utf8 Class Initialized
INFO - 2016-09-19 09:46:41 --> URI Class Initialized
INFO - 2016-09-19 09:46:41 --> Router Class Initialized
INFO - 2016-09-19 09:46:41 --> Output Class Initialized
INFO - 2016-09-19 09:46:41 --> Security Class Initialized
DEBUG - 2016-09-19 09:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:46:41 --> Input Class Initialized
INFO - 2016-09-19 09:46:41 --> Language Class Initialized
INFO - 2016-09-19 09:46:41 --> Language Class Initialized
INFO - 2016-09-19 09:46:41 --> Config Class Initialized
INFO - 2016-09-19 09:46:41 --> Loader Class Initialized
INFO - 2016-09-19 09:46:41 --> Helper loaded: url_helper
INFO - 2016-09-19 09:46:41 --> Database Driver Class Initialized
INFO - 2016-09-19 09:46:41 --> Controller Class Initialized
DEBUG - 2016-09-19 09:46:41 --> Index MX_Controller Initialized
INFO - 2016-09-19 09:46:41 --> Model Class Initialized
INFO - 2016-09-19 09:46:41 --> Model Class Initialized
INFO - 2016-09-19 09:46:42 --> Final output sent to browser
DEBUG - 2016-09-19 09:46:42 --> Total execution time: 0.8028
INFO - 2016-09-19 09:46:44 --> Config Class Initialized
INFO - 2016-09-19 09:46:44 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:46:44 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:46:44 --> Utf8 Class Initialized
INFO - 2016-09-19 09:46:44 --> URI Class Initialized
INFO - 2016-09-19 09:46:44 --> Router Class Initialized
INFO - 2016-09-19 09:46:44 --> Output Class Initialized
INFO - 2016-09-19 09:46:44 --> Security Class Initialized
DEBUG - 2016-09-19 09:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:46:44 --> Input Class Initialized
INFO - 2016-09-19 09:46:44 --> Language Class Initialized
INFO - 2016-09-19 09:46:44 --> Language Class Initialized
INFO - 2016-09-19 09:46:44 --> Config Class Initialized
INFO - 2016-09-19 09:46:44 --> Loader Class Initialized
INFO - 2016-09-19 09:46:44 --> Helper loaded: url_helper
INFO - 2016-09-19 09:46:45 --> Database Driver Class Initialized
INFO - 2016-09-19 09:46:45 --> Controller Class Initialized
DEBUG - 2016-09-19 09:46:45 --> Index MX_Controller Initialized
INFO - 2016-09-19 09:46:45 --> Model Class Initialized
INFO - 2016-09-19 09:46:45 --> Model Class Initialized
INFO - 2016-09-19 09:46:45 --> Database Driver Class Initialized
INFO - 2016-09-19 09:46:45 --> Final output sent to browser
DEBUG - 2016-09-19 09:46:45 --> Total execution time: 0.7566
INFO - 2016-09-19 09:46:52 --> Config Class Initialized
INFO - 2016-09-19 09:46:52 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:46:52 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:46:52 --> Utf8 Class Initialized
INFO - 2016-09-19 09:46:52 --> URI Class Initialized
INFO - 2016-09-19 09:46:52 --> Router Class Initialized
INFO - 2016-09-19 09:46:52 --> Output Class Initialized
INFO - 2016-09-19 09:46:52 --> Security Class Initialized
DEBUG - 2016-09-19 09:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:46:52 --> Input Class Initialized
INFO - 2016-09-19 09:46:52 --> Language Class Initialized
INFO - 2016-09-19 09:46:52 --> Language Class Initialized
INFO - 2016-09-19 09:46:52 --> Config Class Initialized
INFO - 2016-09-19 09:46:52 --> Loader Class Initialized
INFO - 2016-09-19 09:46:52 --> Helper loaded: url_helper
INFO - 2016-09-19 09:46:52 --> Database Driver Class Initialized
INFO - 2016-09-19 09:46:52 --> Controller Class Initialized
DEBUG - 2016-09-19 09:46:52 --> Index MX_Controller Initialized
INFO - 2016-09-19 09:46:52 --> Model Class Initialized
INFO - 2016-09-19 09:46:52 --> Model Class Initialized
INFO - 2016-09-19 09:46:52 --> Database Driver Class Initialized
INFO - 2016-09-19 09:46:52 --> Database Driver Class Initialized
INFO - 2016-09-19 09:46:53 --> Database Driver Class Initialized
INFO - 2016-09-19 09:46:53 --> Database Driver Class Initialized
INFO - 2016-09-19 09:46:53 --> Final output sent to browser
DEBUG - 2016-09-19 09:46:53 --> Total execution time: 1.0022
INFO - 2016-09-19 09:46:55 --> Config Class Initialized
INFO - 2016-09-19 09:46:55 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:46:55 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:46:55 --> Utf8 Class Initialized
INFO - 2016-09-19 09:46:55 --> URI Class Initialized
INFO - 2016-09-19 09:46:55 --> Router Class Initialized
INFO - 2016-09-19 09:46:55 --> Output Class Initialized
INFO - 2016-09-19 09:46:55 --> Security Class Initialized
DEBUG - 2016-09-19 09:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:46:55 --> Input Class Initialized
INFO - 2016-09-19 09:46:55 --> Language Class Initialized
INFO - 2016-09-19 09:46:55 --> Language Class Initialized
INFO - 2016-09-19 09:46:55 --> Config Class Initialized
INFO - 2016-09-19 09:46:55 --> Loader Class Initialized
INFO - 2016-09-19 09:46:55 --> Helper loaded: url_helper
INFO - 2016-09-19 09:46:55 --> Database Driver Class Initialized
INFO - 2016-09-19 09:46:55 --> Controller Class Initialized
DEBUG - 2016-09-19 09:46:55 --> Index MX_Controller Initialized
INFO - 2016-09-19 09:46:55 --> Model Class Initialized
INFO - 2016-09-19 09:46:55 --> Model Class Initialized
INFO - 2016-09-19 09:46:55 --> Database Driver Class Initialized
INFO - 2016-09-19 09:46:55 --> Final output sent to browser
DEBUG - 2016-09-19 09:46:55 --> Total execution time: 0.8058
INFO - 2016-09-19 09:46:56 --> Config Class Initialized
INFO - 2016-09-19 09:46:56 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:46:56 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:46:56 --> Utf8 Class Initialized
INFO - 2016-09-19 09:46:56 --> URI Class Initialized
INFO - 2016-09-19 09:46:57 --> Router Class Initialized
INFO - 2016-09-19 09:46:57 --> Output Class Initialized
INFO - 2016-09-19 09:46:57 --> Security Class Initialized
DEBUG - 2016-09-19 09:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:46:57 --> Input Class Initialized
INFO - 2016-09-19 09:46:57 --> Language Class Initialized
INFO - 2016-09-19 09:46:57 --> Language Class Initialized
INFO - 2016-09-19 09:46:57 --> Config Class Initialized
INFO - 2016-09-19 09:46:57 --> Loader Class Initialized
INFO - 2016-09-19 09:46:57 --> Helper loaded: url_helper
INFO - 2016-09-19 09:46:57 --> Database Driver Class Initialized
INFO - 2016-09-19 09:46:57 --> Controller Class Initialized
DEBUG - 2016-09-19 09:46:57 --> Index MX_Controller Initialized
INFO - 2016-09-19 09:46:57 --> Model Class Initialized
INFO - 2016-09-19 09:46:57 --> Model Class Initialized
INFO - 2016-09-19 09:46:57 --> Database Driver Class Initialized
INFO - 2016-09-19 09:46:57 --> Database Driver Class Initialized
INFO - 2016-09-19 09:46:57 --> Database Driver Class Initialized
INFO - 2016-09-19 09:46:57 --> Database Driver Class Initialized
INFO - 2016-09-19 09:46:57 --> Final output sent to browser
DEBUG - 2016-09-19 09:46:57 --> Total execution time: 1.0606
INFO - 2016-09-19 09:46:58 --> Config Class Initialized
INFO - 2016-09-19 09:46:58 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:46:58 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:46:58 --> Utf8 Class Initialized
INFO - 2016-09-19 09:46:58 --> URI Class Initialized
INFO - 2016-09-19 09:46:58 --> Router Class Initialized
INFO - 2016-09-19 09:46:58 --> Output Class Initialized
INFO - 2016-09-19 09:46:59 --> Security Class Initialized
DEBUG - 2016-09-19 09:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:46:59 --> Input Class Initialized
INFO - 2016-09-19 09:46:59 --> Language Class Initialized
INFO - 2016-09-19 09:46:59 --> Language Class Initialized
INFO - 2016-09-19 09:46:59 --> Config Class Initialized
INFO - 2016-09-19 09:46:59 --> Loader Class Initialized
INFO - 2016-09-19 09:46:59 --> Helper loaded: url_helper
INFO - 2016-09-19 09:46:59 --> Database Driver Class Initialized
INFO - 2016-09-19 09:46:59 --> Controller Class Initialized
DEBUG - 2016-09-19 09:46:59 --> Index MX_Controller Initialized
INFO - 2016-09-19 09:46:59 --> Model Class Initialized
INFO - 2016-09-19 09:46:59 --> Model Class Initialized
INFO - 2016-09-19 09:46:59 --> Database Driver Class Initialized
INFO - 2016-09-19 09:46:59 --> Final output sent to browser
DEBUG - 2016-09-19 09:46:59 --> Total execution time: 0.8428
INFO - 2016-09-19 09:47:00 --> Config Class Initialized
INFO - 2016-09-19 09:47:00 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:47:00 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:47:00 --> Utf8 Class Initialized
INFO - 2016-09-19 09:47:00 --> URI Class Initialized
INFO - 2016-09-19 09:47:00 --> Router Class Initialized
INFO - 2016-09-19 09:47:00 --> Output Class Initialized
INFO - 2016-09-19 09:47:00 --> Security Class Initialized
DEBUG - 2016-09-19 09:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:47:00 --> Input Class Initialized
INFO - 2016-09-19 09:47:00 --> Language Class Initialized
INFO - 2016-09-19 09:47:00 --> Language Class Initialized
INFO - 2016-09-19 09:47:00 --> Config Class Initialized
INFO - 2016-09-19 09:47:00 --> Loader Class Initialized
INFO - 2016-09-19 09:47:00 --> Helper loaded: url_helper
INFO - 2016-09-19 09:47:00 --> Database Driver Class Initialized
INFO - 2016-09-19 09:47:00 --> Controller Class Initialized
DEBUG - 2016-09-19 09:47:00 --> Index MX_Controller Initialized
INFO - 2016-09-19 09:47:01 --> Model Class Initialized
INFO - 2016-09-19 09:47:01 --> Model Class Initialized
INFO - 2016-09-19 09:47:01 --> Database Driver Class Initialized
INFO - 2016-09-19 09:47:01 --> Database Driver Class Initialized
INFO - 2016-09-19 09:47:01 --> Database Driver Class Initialized
INFO - 2016-09-19 09:47:01 --> Database Driver Class Initialized
INFO - 2016-09-19 09:47:01 --> Final output sent to browser
DEBUG - 2016-09-19 09:47:01 --> Total execution time: 1.0179
INFO - 2016-09-19 09:47:02 --> Config Class Initialized
INFO - 2016-09-19 09:47:02 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:47:02 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:47:02 --> Utf8 Class Initialized
INFO - 2016-09-19 09:47:02 --> URI Class Initialized
INFO - 2016-09-19 09:47:02 --> Router Class Initialized
INFO - 2016-09-19 09:47:02 --> Output Class Initialized
INFO - 2016-09-19 09:47:02 --> Security Class Initialized
DEBUG - 2016-09-19 09:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:47:02 --> Input Class Initialized
INFO - 2016-09-19 09:47:02 --> Language Class Initialized
INFO - 2016-09-19 09:47:02 --> Language Class Initialized
INFO - 2016-09-19 09:47:02 --> Config Class Initialized
INFO - 2016-09-19 09:47:02 --> Loader Class Initialized
INFO - 2016-09-19 09:47:02 --> Helper loaded: url_helper
INFO - 2016-09-19 09:47:02 --> Database Driver Class Initialized
INFO - 2016-09-19 09:47:02 --> Controller Class Initialized
DEBUG - 2016-09-19 09:47:03 --> Index MX_Controller Initialized
INFO - 2016-09-19 09:47:03 --> Model Class Initialized
INFO - 2016-09-19 09:47:03 --> Model Class Initialized
INFO - 2016-09-19 09:47:03 --> Database Driver Class Initialized
INFO - 2016-09-19 09:47:03 --> Final output sent to browser
DEBUG - 2016-09-19 09:47:03 --> Total execution time: 1.0383
INFO - 2016-09-19 09:47:03 --> Config Class Initialized
INFO - 2016-09-19 09:47:03 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:47:03 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:47:03 --> Utf8 Class Initialized
INFO - 2016-09-19 09:47:03 --> URI Class Initialized
INFO - 2016-09-19 09:47:04 --> Router Class Initialized
INFO - 2016-09-19 09:47:04 --> Output Class Initialized
INFO - 2016-09-19 09:47:04 --> Security Class Initialized
DEBUG - 2016-09-19 09:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:47:04 --> Input Class Initialized
INFO - 2016-09-19 09:47:04 --> Language Class Initialized
INFO - 2016-09-19 09:47:04 --> Language Class Initialized
INFO - 2016-09-19 09:47:04 --> Config Class Initialized
INFO - 2016-09-19 09:47:04 --> Loader Class Initialized
INFO - 2016-09-19 09:47:04 --> Helper loaded: url_helper
INFO - 2016-09-19 09:47:04 --> Database Driver Class Initialized
INFO - 2016-09-19 09:47:04 --> Controller Class Initialized
DEBUG - 2016-09-19 09:47:04 --> Index MX_Controller Initialized
INFO - 2016-09-19 09:47:04 --> Model Class Initialized
INFO - 2016-09-19 09:47:04 --> Model Class Initialized
INFO - 2016-09-19 09:47:04 --> Database Driver Class Initialized
INFO - 2016-09-19 09:47:04 --> Database Driver Class Initialized
INFO - 2016-09-19 09:47:04 --> Database Driver Class Initialized
INFO - 2016-09-19 09:47:04 --> Database Driver Class Initialized
INFO - 2016-09-19 09:47:04 --> Final output sent to browser
DEBUG - 2016-09-19 09:47:04 --> Total execution time: 1.0688
INFO - 2016-09-19 09:47:05 --> Config Class Initialized
INFO - 2016-09-19 09:47:05 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:47:05 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:47:05 --> Utf8 Class Initialized
INFO - 2016-09-19 09:47:05 --> URI Class Initialized
INFO - 2016-09-19 09:47:05 --> Router Class Initialized
INFO - 2016-09-19 09:47:05 --> Output Class Initialized
INFO - 2016-09-19 09:47:05 --> Security Class Initialized
DEBUG - 2016-09-19 09:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:47:06 --> Input Class Initialized
INFO - 2016-09-19 09:47:06 --> Language Class Initialized
INFO - 2016-09-19 09:47:06 --> Language Class Initialized
INFO - 2016-09-19 09:47:06 --> Config Class Initialized
INFO - 2016-09-19 09:47:06 --> Loader Class Initialized
INFO - 2016-09-19 09:47:06 --> Helper loaded: url_helper
INFO - 2016-09-19 09:47:06 --> Database Driver Class Initialized
INFO - 2016-09-19 09:47:06 --> Controller Class Initialized
DEBUG - 2016-09-19 09:47:06 --> Index MX_Controller Initialized
INFO - 2016-09-19 09:47:06 --> Model Class Initialized
INFO - 2016-09-19 09:47:06 --> Model Class Initialized
INFO - 2016-09-19 09:47:06 --> Database Driver Class Initialized
INFO - 2016-09-19 09:47:06 --> Final output sent to browser
DEBUG - 2016-09-19 09:47:06 --> Total execution time: 0.8192
INFO - 2016-09-19 09:47:07 --> Config Class Initialized
INFO - 2016-09-19 09:47:07 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:47:07 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:47:07 --> Utf8 Class Initialized
INFO - 2016-09-19 09:47:07 --> URI Class Initialized
INFO - 2016-09-19 09:47:07 --> Router Class Initialized
INFO - 2016-09-19 09:47:07 --> Output Class Initialized
INFO - 2016-09-19 09:47:07 --> Security Class Initialized
DEBUG - 2016-09-19 09:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:47:07 --> Input Class Initialized
INFO - 2016-09-19 09:47:07 --> Language Class Initialized
INFO - 2016-09-19 09:47:07 --> Language Class Initialized
INFO - 2016-09-19 09:47:07 --> Config Class Initialized
INFO - 2016-09-19 09:47:07 --> Loader Class Initialized
INFO - 2016-09-19 09:47:07 --> Helper loaded: url_helper
INFO - 2016-09-19 09:47:07 --> Database Driver Class Initialized
INFO - 2016-09-19 09:47:08 --> Controller Class Initialized
DEBUG - 2016-09-19 09:47:08 --> Index MX_Controller Initialized
INFO - 2016-09-19 09:47:08 --> Model Class Initialized
INFO - 2016-09-19 09:47:08 --> Model Class Initialized
INFO - 2016-09-19 09:47:08 --> Database Driver Class Initialized
INFO - 2016-09-19 09:47:08 --> Database Driver Class Initialized
INFO - 2016-09-19 09:47:08 --> Database Driver Class Initialized
INFO - 2016-09-19 09:47:08 --> Database Driver Class Initialized
INFO - 2016-09-19 09:47:08 --> Final output sent to browser
DEBUG - 2016-09-19 09:47:08 --> Total execution time: 1.2030
INFO - 2016-09-19 09:47:09 --> Config Class Initialized
INFO - 2016-09-19 09:47:09 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:47:09 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:47:09 --> Utf8 Class Initialized
INFO - 2016-09-19 09:47:09 --> URI Class Initialized
INFO - 2016-09-19 09:47:09 --> Router Class Initialized
INFO - 2016-09-19 09:47:09 --> Output Class Initialized
INFO - 2016-09-19 09:47:09 --> Security Class Initialized
DEBUG - 2016-09-19 09:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:47:09 --> Input Class Initialized
INFO - 2016-09-19 09:47:09 --> Language Class Initialized
INFO - 2016-09-19 09:47:09 --> Language Class Initialized
INFO - 2016-09-19 09:47:09 --> Config Class Initialized
INFO - 2016-09-19 09:47:09 --> Loader Class Initialized
INFO - 2016-09-19 09:47:09 --> Helper loaded: url_helper
INFO - 2016-09-19 09:47:09 --> Database Driver Class Initialized
INFO - 2016-09-19 09:47:09 --> Controller Class Initialized
DEBUG - 2016-09-19 09:47:09 --> Index MX_Controller Initialized
INFO - 2016-09-19 09:47:10 --> Model Class Initialized
INFO - 2016-09-19 09:47:10 --> Model Class Initialized
INFO - 2016-09-19 09:47:10 --> Database Driver Class Initialized
INFO - 2016-09-19 09:47:10 --> Final output sent to browser
DEBUG - 2016-09-19 09:47:10 --> Total execution time: 1.0580
INFO - 2016-09-19 09:47:11 --> Config Class Initialized
INFO - 2016-09-19 09:47:11 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:47:11 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:47:11 --> Utf8 Class Initialized
INFO - 2016-09-19 09:47:11 --> URI Class Initialized
INFO - 2016-09-19 09:47:11 --> Router Class Initialized
INFO - 2016-09-19 09:47:11 --> Output Class Initialized
INFO - 2016-09-19 09:47:11 --> Security Class Initialized
DEBUG - 2016-09-19 09:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:47:11 --> Input Class Initialized
INFO - 2016-09-19 09:47:11 --> Language Class Initialized
INFO - 2016-09-19 09:47:11 --> Language Class Initialized
INFO - 2016-09-19 09:47:12 --> Config Class Initialized
INFO - 2016-09-19 09:47:12 --> Loader Class Initialized
INFO - 2016-09-19 09:47:12 --> Helper loaded: url_helper
INFO - 2016-09-19 09:47:12 --> Database Driver Class Initialized
INFO - 2016-09-19 09:47:12 --> Controller Class Initialized
DEBUG - 2016-09-19 09:47:12 --> Index MX_Controller Initialized
INFO - 2016-09-19 09:47:12 --> Model Class Initialized
INFO - 2016-09-19 09:47:12 --> Model Class Initialized
INFO - 2016-09-19 09:47:12 --> Database Driver Class Initialized
INFO - 2016-09-19 09:47:12 --> Database Driver Class Initialized
INFO - 2016-09-19 09:47:12 --> Database Driver Class Initialized
INFO - 2016-09-19 09:47:12 --> Database Driver Class Initialized
INFO - 2016-09-19 09:47:12 --> Final output sent to browser
DEBUG - 2016-09-19 09:47:12 --> Total execution time: 1.1847
INFO - 2016-09-19 09:47:13 --> Config Class Initialized
INFO - 2016-09-19 09:47:13 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:47:13 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:47:13 --> Utf8 Class Initialized
INFO - 2016-09-19 09:47:13 --> URI Class Initialized
INFO - 2016-09-19 09:47:13 --> Router Class Initialized
INFO - 2016-09-19 09:47:13 --> Output Class Initialized
INFO - 2016-09-19 09:47:13 --> Security Class Initialized
DEBUG - 2016-09-19 09:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:47:13 --> Input Class Initialized
INFO - 2016-09-19 09:47:13 --> Language Class Initialized
INFO - 2016-09-19 09:47:13 --> Language Class Initialized
INFO - 2016-09-19 09:47:14 --> Config Class Initialized
INFO - 2016-09-19 09:47:14 --> Loader Class Initialized
INFO - 2016-09-19 09:47:14 --> Helper loaded: url_helper
INFO - 2016-09-19 09:47:14 --> Database Driver Class Initialized
INFO - 2016-09-19 09:47:14 --> Controller Class Initialized
DEBUG - 2016-09-19 09:47:14 --> Index MX_Controller Initialized
INFO - 2016-09-19 09:47:14 --> Model Class Initialized
INFO - 2016-09-19 09:47:14 --> Model Class Initialized
INFO - 2016-09-19 09:47:14 --> Database Driver Class Initialized
INFO - 2016-09-19 09:47:14 --> Final output sent to browser
DEBUG - 2016-09-19 09:47:14 --> Total execution time: 1.0957
INFO - 2016-09-19 09:47:20 --> Config Class Initialized
INFO - 2016-09-19 09:47:20 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:47:20 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:47:20 --> Utf8 Class Initialized
INFO - 2016-09-19 09:47:20 --> URI Class Initialized
INFO - 2016-09-19 09:47:20 --> Router Class Initialized
INFO - 2016-09-19 09:47:20 --> Output Class Initialized
INFO - 2016-09-19 09:47:20 --> Security Class Initialized
DEBUG - 2016-09-19 09:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:47:20 --> Input Class Initialized
INFO - 2016-09-19 09:47:20 --> Language Class Initialized
INFO - 2016-09-19 09:47:21 --> Language Class Initialized
INFO - 2016-09-19 09:47:21 --> Config Class Initialized
INFO - 2016-09-19 09:47:21 --> Loader Class Initialized
INFO - 2016-09-19 09:47:21 --> Helper loaded: url_helper
INFO - 2016-09-19 09:47:21 --> Database Driver Class Initialized
INFO - 2016-09-19 09:47:21 --> Controller Class Initialized
DEBUG - 2016-09-19 09:47:21 --> Index MX_Controller Initialized
INFO - 2016-09-19 09:47:21 --> Model Class Initialized
INFO - 2016-09-19 09:47:21 --> Model Class Initialized
INFO - 2016-09-19 09:47:21 --> Database Driver Class Initialized
INFO - 2016-09-19 09:47:21 --> Database Driver Class Initialized
INFO - 2016-09-19 09:47:21 --> Database Driver Class Initialized
INFO - 2016-09-19 09:47:21 --> Database Driver Class Initialized
INFO - 2016-09-19 09:47:21 --> Final output sent to browser
DEBUG - 2016-09-19 09:47:21 --> Total execution time: 1.2016
INFO - 2016-09-19 09:47:37 --> Config Class Initialized
INFO - 2016-09-19 09:47:37 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:47:37 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:47:37 --> Utf8 Class Initialized
INFO - 2016-09-19 09:47:37 --> URI Class Initialized
INFO - 2016-09-19 09:47:37 --> Router Class Initialized
INFO - 2016-09-19 09:47:37 --> Output Class Initialized
INFO - 2016-09-19 09:47:37 --> Security Class Initialized
DEBUG - 2016-09-19 09:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:47:37 --> Input Class Initialized
INFO - 2016-09-19 09:47:37 --> Language Class Initialized
INFO - 2016-09-19 09:47:38 --> Language Class Initialized
INFO - 2016-09-19 09:47:38 --> Config Class Initialized
INFO - 2016-09-19 09:47:38 --> Loader Class Initialized
INFO - 2016-09-19 09:47:38 --> Helper loaded: url_helper
INFO - 2016-09-19 09:47:38 --> Database Driver Class Initialized
INFO - 2016-09-19 09:47:38 --> Controller Class Initialized
DEBUG - 2016-09-19 09:47:38 --> Index MX_Controller Initialized
INFO - 2016-09-19 09:47:38 --> Model Class Initialized
INFO - 2016-09-19 09:47:38 --> Model Class Initialized
DEBUG - 2016-09-19 09:47:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 09:47:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 09:47:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 09:47:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/jurnal_umum.php
DEBUG - 2016-09-19 09:47:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 09:47:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 09:47:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 09:47:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 09:47:38 --> Final output sent to browser
DEBUG - 2016-09-19 09:47:38 --> Total execution time: 1.1788
INFO - 2016-09-19 09:47:52 --> Config Class Initialized
INFO - 2016-09-19 09:47:52 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:47:53 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:47:53 --> Utf8 Class Initialized
INFO - 2016-09-19 09:47:53 --> URI Class Initialized
INFO - 2016-09-19 09:47:53 --> Router Class Initialized
INFO - 2016-09-19 09:47:53 --> Output Class Initialized
INFO - 2016-09-19 09:47:53 --> Security Class Initialized
DEBUG - 2016-09-19 09:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:47:53 --> Input Class Initialized
INFO - 2016-09-19 09:47:53 --> Language Class Initialized
INFO - 2016-09-19 09:47:53 --> Language Class Initialized
INFO - 2016-09-19 09:47:53 --> Config Class Initialized
INFO - 2016-09-19 09:47:53 --> Loader Class Initialized
INFO - 2016-09-19 09:47:53 --> Helper loaded: url_helper
INFO - 2016-09-19 09:47:53 --> Database Driver Class Initialized
INFO - 2016-09-19 09:47:53 --> Controller Class Initialized
DEBUG - 2016-09-19 09:47:53 --> Index MX_Controller Initialized
INFO - 2016-09-19 09:47:53 --> Model Class Initialized
INFO - 2016-09-19 09:47:53 --> Model Class Initialized
DEBUG - 2016-09-19 09:47:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_jurnal_umum.php
INFO - 2016-09-19 09:47:53 --> Final output sent to browser
DEBUG - 2016-09-19 09:47:53 --> Total execution time: 0.7976
INFO - 2016-09-19 09:50:22 --> Config Class Initialized
INFO - 2016-09-19 09:50:22 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:50:22 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:50:22 --> Utf8 Class Initialized
INFO - 2016-09-19 09:50:23 --> URI Class Initialized
INFO - 2016-09-19 09:50:23 --> Router Class Initialized
INFO - 2016-09-19 09:50:23 --> Output Class Initialized
INFO - 2016-09-19 09:50:23 --> Security Class Initialized
DEBUG - 2016-09-19 09:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:50:23 --> Input Class Initialized
INFO - 2016-09-19 09:50:23 --> Language Class Initialized
INFO - 2016-09-19 09:50:23 --> Language Class Initialized
INFO - 2016-09-19 09:50:23 --> Config Class Initialized
INFO - 2016-09-19 09:50:23 --> Loader Class Initialized
INFO - 2016-09-19 09:50:23 --> Helper loaded: url_helper
INFO - 2016-09-19 09:50:23 --> Database Driver Class Initialized
INFO - 2016-09-19 09:50:23 --> Controller Class Initialized
DEBUG - 2016-09-19 09:50:23 --> Index MX_Controller Initialized
INFO - 2016-09-19 09:50:23 --> Model Class Initialized
INFO - 2016-09-19 09:50:23 --> Model Class Initialized
DEBUG - 2016-09-19 09:50:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 09:50:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 09:50:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 09:50:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_bayar_angsuran.php
DEBUG - 2016-09-19 09:50:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 09:50:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 09:50:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 09:50:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 09:50:23 --> Final output sent to browser
DEBUG - 2016-09-19 09:50:23 --> Total execution time: 1.0319
INFO - 2016-09-19 09:50:27 --> Config Class Initialized
INFO - 2016-09-19 09:50:27 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:50:28 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:50:28 --> Utf8 Class Initialized
INFO - 2016-09-19 09:50:28 --> URI Class Initialized
INFO - 2016-09-19 09:50:28 --> Router Class Initialized
INFO - 2016-09-19 09:50:28 --> Output Class Initialized
INFO - 2016-09-19 09:50:28 --> Security Class Initialized
DEBUG - 2016-09-19 09:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:50:28 --> Input Class Initialized
INFO - 2016-09-19 09:50:28 --> Language Class Initialized
INFO - 2016-09-19 09:50:28 --> Language Class Initialized
INFO - 2016-09-19 09:50:28 --> Config Class Initialized
INFO - 2016-09-19 09:50:28 --> Loader Class Initialized
INFO - 2016-09-19 09:50:28 --> Helper loaded: url_helper
INFO - 2016-09-19 09:50:28 --> Database Driver Class Initialized
INFO - 2016-09-19 09:50:28 --> Controller Class Initialized
DEBUG - 2016-09-19 09:50:28 --> Index MX_Controller Initialized
INFO - 2016-09-19 09:50:28 --> Model Class Initialized
INFO - 2016-09-19 09:50:28 --> Model Class Initialized
INFO - 2016-09-19 09:50:28 --> Database Driver Class Initialized
INFO - 2016-09-19 09:50:28 --> Final output sent to browser
DEBUG - 2016-09-19 09:50:28 --> Total execution time: 0.8685
INFO - 2016-09-19 09:51:27 --> Config Class Initialized
INFO - 2016-09-19 09:51:27 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:51:27 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:51:27 --> Utf8 Class Initialized
INFO - 2016-09-19 09:51:27 --> URI Class Initialized
INFO - 2016-09-19 09:51:27 --> Router Class Initialized
INFO - 2016-09-19 09:51:27 --> Output Class Initialized
INFO - 2016-09-19 09:51:27 --> Security Class Initialized
DEBUG - 2016-09-19 09:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:51:27 --> Input Class Initialized
INFO - 2016-09-19 09:51:27 --> Language Class Initialized
ERROR - 2016-09-19 09:51:27 --> Severity: Parsing Error --> syntax error, unexpected ';' E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 409
INFO - 2016-09-19 09:51:29 --> Config Class Initialized
INFO - 2016-09-19 09:51:29 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:51:29 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:51:29 --> Utf8 Class Initialized
INFO - 2016-09-19 09:51:29 --> URI Class Initialized
INFO - 2016-09-19 09:51:29 --> Router Class Initialized
INFO - 2016-09-19 09:51:29 --> Output Class Initialized
INFO - 2016-09-19 09:51:29 --> Security Class Initialized
DEBUG - 2016-09-19 09:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:51:29 --> Input Class Initialized
INFO - 2016-09-19 09:51:29 --> Language Class Initialized
ERROR - 2016-09-19 09:51:29 --> Severity: Parsing Error --> syntax error, unexpected ';' E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 409
INFO - 2016-09-19 09:51:33 --> Config Class Initialized
INFO - 2016-09-19 09:51:33 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:51:33 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:51:33 --> Utf8 Class Initialized
INFO - 2016-09-19 09:51:33 --> URI Class Initialized
INFO - 2016-09-19 09:51:33 --> Router Class Initialized
INFO - 2016-09-19 09:51:33 --> Output Class Initialized
INFO - 2016-09-19 09:51:33 --> Security Class Initialized
DEBUG - 2016-09-19 09:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:51:33 --> Input Class Initialized
INFO - 2016-09-19 09:51:33 --> Language Class Initialized
ERROR - 2016-09-19 09:51:33 --> Severity: Parsing Error --> syntax error, unexpected ';' E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 409
INFO - 2016-09-19 09:51:51 --> Config Class Initialized
INFO - 2016-09-19 09:51:52 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:51:52 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:51:52 --> Utf8 Class Initialized
INFO - 2016-09-19 09:51:52 --> URI Class Initialized
INFO - 2016-09-19 09:51:52 --> Router Class Initialized
INFO - 2016-09-19 09:51:52 --> Output Class Initialized
INFO - 2016-09-19 09:51:52 --> Security Class Initialized
DEBUG - 2016-09-19 09:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:51:52 --> Input Class Initialized
INFO - 2016-09-19 09:51:52 --> Language Class Initialized
ERROR - 2016-09-19 09:51:52 --> Severity: Parsing Error --> syntax error, unexpected ';' E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 409
INFO - 2016-09-19 09:52:09 --> Config Class Initialized
INFO - 2016-09-19 09:52:09 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:52:09 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:52:09 --> Utf8 Class Initialized
INFO - 2016-09-19 09:52:09 --> URI Class Initialized
INFO - 2016-09-19 09:52:09 --> Router Class Initialized
INFO - 2016-09-19 09:52:09 --> Output Class Initialized
INFO - 2016-09-19 09:52:09 --> Security Class Initialized
DEBUG - 2016-09-19 09:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:52:09 --> Input Class Initialized
INFO - 2016-09-19 09:52:09 --> Language Class Initialized
INFO - 2016-09-19 09:52:09 --> Language Class Initialized
INFO - 2016-09-19 09:52:09 --> Config Class Initialized
INFO - 2016-09-19 09:52:10 --> Loader Class Initialized
INFO - 2016-09-19 09:52:10 --> Helper loaded: url_helper
INFO - 2016-09-19 09:52:10 --> Database Driver Class Initialized
INFO - 2016-09-19 09:52:10 --> Controller Class Initialized
DEBUG - 2016-09-19 09:52:10 --> Index MX_Controller Initialized
INFO - 2016-09-19 09:52:10 --> Model Class Initialized
INFO - 2016-09-19 09:52:10 --> Model Class Initialized
DEBUG - 2016-09-19 09:52:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 09:52:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 09:52:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 09:52:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_bayar_angsuran.php
DEBUG - 2016-09-19 09:52:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 09:52:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 09:52:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 09:52:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 09:52:10 --> Final output sent to browser
DEBUG - 2016-09-19 09:52:10 --> Total execution time: 1.3586
INFO - 2016-09-19 09:52:16 --> Config Class Initialized
INFO - 2016-09-19 09:52:16 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:52:16 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:52:16 --> Utf8 Class Initialized
INFO - 2016-09-19 09:52:16 --> URI Class Initialized
INFO - 2016-09-19 09:52:16 --> Router Class Initialized
INFO - 2016-09-19 09:52:16 --> Output Class Initialized
INFO - 2016-09-19 09:52:16 --> Security Class Initialized
DEBUG - 2016-09-19 09:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:52:16 --> Input Class Initialized
INFO - 2016-09-19 09:52:16 --> Language Class Initialized
INFO - 2016-09-19 09:52:16 --> Language Class Initialized
INFO - 2016-09-19 09:52:16 --> Config Class Initialized
INFO - 2016-09-19 09:52:16 --> Loader Class Initialized
INFO - 2016-09-19 09:52:17 --> Helper loaded: url_helper
INFO - 2016-09-19 09:52:17 --> Database Driver Class Initialized
INFO - 2016-09-19 09:52:17 --> Controller Class Initialized
DEBUG - 2016-09-19 09:52:17 --> Index MX_Controller Initialized
INFO - 2016-09-19 09:52:17 --> Model Class Initialized
INFO - 2016-09-19 09:52:17 --> Model Class Initialized
INFO - 2016-09-19 09:52:17 --> Database Driver Class Initialized
INFO - 2016-09-19 09:52:17 --> Final output sent to browser
DEBUG - 2016-09-19 09:52:17 --> Total execution time: 0.8126
INFO - 2016-09-19 09:52:24 --> Config Class Initialized
INFO - 2016-09-19 09:52:24 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:52:24 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:52:24 --> Utf8 Class Initialized
INFO - 2016-09-19 09:52:24 --> URI Class Initialized
INFO - 2016-09-19 09:52:24 --> Router Class Initialized
INFO - 2016-09-19 09:52:24 --> Output Class Initialized
INFO - 2016-09-19 09:52:24 --> Security Class Initialized
DEBUG - 2016-09-19 09:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:52:24 --> Input Class Initialized
INFO - 2016-09-19 09:52:24 --> Language Class Initialized
INFO - 2016-09-19 09:52:24 --> Language Class Initialized
INFO - 2016-09-19 09:52:24 --> Config Class Initialized
INFO - 2016-09-19 09:52:24 --> Loader Class Initialized
INFO - 2016-09-19 09:52:24 --> Helper loaded: url_helper
INFO - 2016-09-19 09:52:24 --> Database Driver Class Initialized
INFO - 2016-09-19 09:52:24 --> Controller Class Initialized
DEBUG - 2016-09-19 09:52:24 --> Index MX_Controller Initialized
INFO - 2016-09-19 09:52:24 --> Model Class Initialized
INFO - 2016-09-19 09:52:24 --> Model Class Initialized
INFO - 2016-09-19 09:52:24 --> Database Driver Class Initialized
INFO - 2016-09-19 09:52:24 --> Database Driver Class Initialized
INFO - 2016-09-19 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-19 09:52:25 --> Database Driver Class Initialized
INFO - 2016-09-19 09:52:25 --> Final output sent to browser
DEBUG - 2016-09-19 09:52:25 --> Total execution time: 1.0556
INFO - 2016-09-19 09:53:11 --> Config Class Initialized
INFO - 2016-09-19 09:53:11 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:53:11 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:53:11 --> Utf8 Class Initialized
INFO - 2016-09-19 09:53:11 --> URI Class Initialized
INFO - 2016-09-19 09:53:11 --> Router Class Initialized
INFO - 2016-09-19 09:53:11 --> Output Class Initialized
INFO - 2016-09-19 09:53:11 --> Security Class Initialized
DEBUG - 2016-09-19 09:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:53:11 --> Input Class Initialized
INFO - 2016-09-19 09:53:11 --> Language Class Initialized
INFO - 2016-09-19 09:53:11 --> Language Class Initialized
INFO - 2016-09-19 09:53:11 --> Config Class Initialized
INFO - 2016-09-19 09:53:11 --> Loader Class Initialized
INFO - 2016-09-19 09:53:11 --> Helper loaded: url_helper
INFO - 2016-09-19 09:53:12 --> Database Driver Class Initialized
INFO - 2016-09-19 09:53:12 --> Controller Class Initialized
DEBUG - 2016-09-19 09:53:12 --> Index MX_Controller Initialized
INFO - 2016-09-19 09:53:12 --> Model Class Initialized
INFO - 2016-09-19 09:53:12 --> Model Class Initialized
INFO - 2016-09-19 09:53:12 --> Database Driver Class Initialized
INFO - 2016-09-19 09:53:12 --> Final output sent to browser
DEBUG - 2016-09-19 09:53:12 --> Total execution time: 0.7521
INFO - 2016-09-19 09:55:06 --> Config Class Initialized
INFO - 2016-09-19 09:55:06 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:55:06 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:55:06 --> Utf8 Class Initialized
INFO - 2016-09-19 09:55:06 --> URI Class Initialized
INFO - 2016-09-19 09:55:06 --> Router Class Initialized
INFO - 2016-09-19 09:55:06 --> Output Class Initialized
INFO - 2016-09-19 09:55:06 --> Security Class Initialized
DEBUG - 2016-09-19 09:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:55:06 --> Input Class Initialized
INFO - 2016-09-19 09:55:07 --> Language Class Initialized
INFO - 2016-09-19 09:55:07 --> Language Class Initialized
INFO - 2016-09-19 09:55:07 --> Config Class Initialized
INFO - 2016-09-19 09:55:07 --> Loader Class Initialized
INFO - 2016-09-19 09:55:07 --> Helper loaded: url_helper
INFO - 2016-09-19 09:55:07 --> Database Driver Class Initialized
INFO - 2016-09-19 09:55:07 --> Controller Class Initialized
DEBUG - 2016-09-19 09:55:07 --> Index MX_Controller Initialized
INFO - 2016-09-19 09:55:07 --> Model Class Initialized
INFO - 2016-09-19 09:55:07 --> Model Class Initialized
INFO - 2016-09-19 09:55:07 --> Database Driver Class Initialized
INFO - 2016-09-19 09:55:07 --> Final output sent to browser
DEBUG - 2016-09-19 09:55:07 --> Total execution time: 0.7740
INFO - 2016-09-19 09:55:23 --> Config Class Initialized
INFO - 2016-09-19 09:55:23 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:55:23 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:55:23 --> Utf8 Class Initialized
INFO - 2016-09-19 09:55:23 --> URI Class Initialized
INFO - 2016-09-19 09:55:23 --> Router Class Initialized
INFO - 2016-09-19 09:55:23 --> Output Class Initialized
INFO - 2016-09-19 09:55:23 --> Security Class Initialized
DEBUG - 2016-09-19 09:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:55:23 --> Input Class Initialized
INFO - 2016-09-19 09:55:24 --> Language Class Initialized
INFO - 2016-09-19 09:55:24 --> Language Class Initialized
INFO - 2016-09-19 09:55:24 --> Config Class Initialized
INFO - 2016-09-19 09:55:24 --> Loader Class Initialized
INFO - 2016-09-19 09:55:24 --> Helper loaded: url_helper
INFO - 2016-09-19 09:55:24 --> Database Driver Class Initialized
INFO - 2016-09-19 09:55:24 --> Controller Class Initialized
DEBUG - 2016-09-19 09:55:24 --> Index MX_Controller Initialized
INFO - 2016-09-19 09:55:24 --> Model Class Initialized
INFO - 2016-09-19 09:55:24 --> Model Class Initialized
INFO - 2016-09-19 09:55:24 --> Database Driver Class Initialized
INFO - 2016-09-19 09:55:24 --> Final output sent to browser
DEBUG - 2016-09-19 09:55:24 --> Total execution time: 0.9886
INFO - 2016-09-19 09:55:25 --> Config Class Initialized
INFO - 2016-09-19 09:55:25 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:55:26 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:55:26 --> Utf8 Class Initialized
INFO - 2016-09-19 09:55:26 --> URI Class Initialized
INFO - 2016-09-19 09:55:26 --> Router Class Initialized
INFO - 2016-09-19 09:55:26 --> Output Class Initialized
INFO - 2016-09-19 09:55:26 --> Security Class Initialized
DEBUG - 2016-09-19 09:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:55:26 --> Input Class Initialized
INFO - 2016-09-19 09:55:26 --> Language Class Initialized
INFO - 2016-09-19 09:55:26 --> Language Class Initialized
INFO - 2016-09-19 09:55:26 --> Config Class Initialized
INFO - 2016-09-19 09:55:26 --> Loader Class Initialized
INFO - 2016-09-19 09:55:26 --> Helper loaded: url_helper
INFO - 2016-09-19 09:55:26 --> Database Driver Class Initialized
INFO - 2016-09-19 09:55:26 --> Controller Class Initialized
DEBUG - 2016-09-19 09:55:26 --> Index MX_Controller Initialized
INFO - 2016-09-19 09:55:26 --> Model Class Initialized
INFO - 2016-09-19 09:55:26 --> Model Class Initialized
INFO - 2016-09-19 09:55:26 --> Database Driver Class Initialized
INFO - 2016-09-19 09:55:27 --> Database Driver Class Initialized
INFO - 2016-09-19 09:55:27 --> Database Driver Class Initialized
INFO - 2016-09-19 09:55:27 --> Database Driver Class Initialized
INFO - 2016-09-19 09:55:27 --> Final output sent to browser
DEBUG - 2016-09-19 09:55:27 --> Total execution time: 1.4819
INFO - 2016-09-19 09:57:33 --> Config Class Initialized
INFO - 2016-09-19 09:57:33 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:57:33 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:57:33 --> Utf8 Class Initialized
INFO - 2016-09-19 09:57:33 --> URI Class Initialized
INFO - 2016-09-19 09:57:33 --> Router Class Initialized
INFO - 2016-09-19 09:57:33 --> Output Class Initialized
INFO - 2016-09-19 09:57:33 --> Security Class Initialized
DEBUG - 2016-09-19 09:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:57:33 --> Input Class Initialized
INFO - 2016-09-19 09:57:33 --> Language Class Initialized
INFO - 2016-09-19 09:57:33 --> Language Class Initialized
INFO - 2016-09-19 09:57:33 --> Config Class Initialized
INFO - 2016-09-19 09:57:33 --> Loader Class Initialized
INFO - 2016-09-19 09:57:33 --> Helper loaded: url_helper
INFO - 2016-09-19 09:57:33 --> Database Driver Class Initialized
INFO - 2016-09-19 09:57:33 --> Controller Class Initialized
DEBUG - 2016-09-19 09:57:33 --> Index MX_Controller Initialized
INFO - 2016-09-19 09:57:33 --> Model Class Initialized
INFO - 2016-09-19 09:57:33 --> Model Class Initialized
INFO - 2016-09-19 09:57:33 --> Database Driver Class Initialized
INFO - 2016-09-19 09:57:33 --> Final output sent to browser
DEBUG - 2016-09-19 09:57:34 --> Total execution time: 0.8019
INFO - 2016-09-19 09:57:35 --> Config Class Initialized
INFO - 2016-09-19 09:57:35 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:57:35 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:57:35 --> Utf8 Class Initialized
INFO - 2016-09-19 09:57:35 --> URI Class Initialized
INFO - 2016-09-19 09:57:35 --> Router Class Initialized
INFO - 2016-09-19 09:57:35 --> Output Class Initialized
INFO - 2016-09-19 09:57:35 --> Security Class Initialized
DEBUG - 2016-09-19 09:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:57:35 --> Input Class Initialized
INFO - 2016-09-19 09:57:35 --> Language Class Initialized
INFO - 2016-09-19 09:57:35 --> Language Class Initialized
INFO - 2016-09-19 09:57:35 --> Config Class Initialized
INFO - 2016-09-19 09:57:35 --> Loader Class Initialized
INFO - 2016-09-19 09:57:35 --> Helper loaded: url_helper
INFO - 2016-09-19 09:57:35 --> Database Driver Class Initialized
INFO - 2016-09-19 09:57:35 --> Controller Class Initialized
DEBUG - 2016-09-19 09:57:35 --> Index MX_Controller Initialized
INFO - 2016-09-19 09:57:35 --> Model Class Initialized
INFO - 2016-09-19 09:57:35 --> Model Class Initialized
INFO - 2016-09-19 09:57:35 --> Database Driver Class Initialized
INFO - 2016-09-19 09:57:35 --> Database Driver Class Initialized
INFO - 2016-09-19 09:57:36 --> Database Driver Class Initialized
INFO - 2016-09-19 09:57:36 --> Database Driver Class Initialized
INFO - 2016-09-19 09:57:36 --> Final output sent to browser
DEBUG - 2016-09-19 09:57:36 --> Total execution time: 1.0758
INFO - 2016-09-19 09:58:07 --> Config Class Initialized
INFO - 2016-09-19 09:58:07 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:58:07 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:58:07 --> Utf8 Class Initialized
INFO - 2016-09-19 09:58:07 --> URI Class Initialized
INFO - 2016-09-19 09:58:08 --> Router Class Initialized
INFO - 2016-09-19 09:58:08 --> Output Class Initialized
INFO - 2016-09-19 09:58:08 --> Security Class Initialized
DEBUG - 2016-09-19 09:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:58:08 --> Input Class Initialized
INFO - 2016-09-19 09:58:08 --> Language Class Initialized
INFO - 2016-09-19 09:58:08 --> Language Class Initialized
INFO - 2016-09-19 09:58:08 --> Config Class Initialized
INFO - 2016-09-19 09:58:08 --> Loader Class Initialized
INFO - 2016-09-19 09:58:08 --> Helper loaded: url_helper
INFO - 2016-09-19 09:58:08 --> Database Driver Class Initialized
INFO - 2016-09-19 09:58:08 --> Controller Class Initialized
DEBUG - 2016-09-19 09:58:08 --> Index MX_Controller Initialized
INFO - 2016-09-19 09:58:08 --> Model Class Initialized
INFO - 2016-09-19 09:58:08 --> Model Class Initialized
INFO - 2016-09-19 09:58:08 --> Database Driver Class Initialized
INFO - 2016-09-19 09:58:08 --> Final output sent to browser
DEBUG - 2016-09-19 09:58:08 --> Total execution time: 0.8062
INFO - 2016-09-19 09:58:09 --> Config Class Initialized
INFO - 2016-09-19 09:58:09 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:58:09 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:58:09 --> Utf8 Class Initialized
INFO - 2016-09-19 09:58:09 --> URI Class Initialized
INFO - 2016-09-19 09:58:09 --> Router Class Initialized
INFO - 2016-09-19 09:58:09 --> Output Class Initialized
INFO - 2016-09-19 09:58:09 --> Security Class Initialized
DEBUG - 2016-09-19 09:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:58:09 --> Input Class Initialized
INFO - 2016-09-19 09:58:09 --> Language Class Initialized
INFO - 2016-09-19 09:58:10 --> Language Class Initialized
INFO - 2016-09-19 09:58:10 --> Config Class Initialized
INFO - 2016-09-19 09:58:10 --> Loader Class Initialized
INFO - 2016-09-19 09:58:10 --> Helper loaded: url_helper
INFO - 2016-09-19 09:58:10 --> Database Driver Class Initialized
INFO - 2016-09-19 09:58:10 --> Controller Class Initialized
DEBUG - 2016-09-19 09:58:10 --> Index MX_Controller Initialized
INFO - 2016-09-19 09:58:10 --> Model Class Initialized
INFO - 2016-09-19 09:58:10 --> Model Class Initialized
INFO - 2016-09-19 09:58:10 --> Database Driver Class Initialized
INFO - 2016-09-19 09:58:10 --> Database Driver Class Initialized
INFO - 2016-09-19 09:58:10 --> Database Driver Class Initialized
INFO - 2016-09-19 09:58:10 --> Database Driver Class Initialized
INFO - 2016-09-19 09:58:10 --> Final output sent to browser
DEBUG - 2016-09-19 09:58:10 --> Total execution time: 1.1769
INFO - 2016-09-19 09:59:36 --> Config Class Initialized
INFO - 2016-09-19 09:59:36 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:59:36 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:59:36 --> Utf8 Class Initialized
INFO - 2016-09-19 09:59:36 --> URI Class Initialized
INFO - 2016-09-19 09:59:36 --> Router Class Initialized
INFO - 2016-09-19 09:59:36 --> Output Class Initialized
INFO - 2016-09-19 09:59:36 --> Security Class Initialized
DEBUG - 2016-09-19 09:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:59:36 --> Input Class Initialized
INFO - 2016-09-19 09:59:36 --> Language Class Initialized
INFO - 2016-09-19 09:59:36 --> Language Class Initialized
INFO - 2016-09-19 09:59:36 --> Config Class Initialized
INFO - 2016-09-19 09:59:36 --> Loader Class Initialized
INFO - 2016-09-19 09:59:36 --> Helper loaded: url_helper
INFO - 2016-09-19 09:59:36 --> Database Driver Class Initialized
INFO - 2016-09-19 09:59:36 --> Controller Class Initialized
DEBUG - 2016-09-19 09:59:36 --> Index MX_Controller Initialized
INFO - 2016-09-19 09:59:37 --> Model Class Initialized
INFO - 2016-09-19 09:59:37 --> Model Class Initialized
INFO - 2016-09-19 09:59:37 --> Database Driver Class Initialized
INFO - 2016-09-19 09:59:37 --> Final output sent to browser
DEBUG - 2016-09-19 09:59:37 --> Total execution time: 0.7667
INFO - 2016-09-19 09:59:38 --> Config Class Initialized
INFO - 2016-09-19 09:59:38 --> Hooks Class Initialized
DEBUG - 2016-09-19 09:59:38 --> UTF-8 Support Enabled
INFO - 2016-09-19 09:59:38 --> Utf8 Class Initialized
INFO - 2016-09-19 09:59:38 --> URI Class Initialized
INFO - 2016-09-19 09:59:38 --> Router Class Initialized
INFO - 2016-09-19 09:59:38 --> Output Class Initialized
INFO - 2016-09-19 09:59:38 --> Security Class Initialized
DEBUG - 2016-09-19 09:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 09:59:38 --> Input Class Initialized
INFO - 2016-09-19 09:59:38 --> Language Class Initialized
INFO - 2016-09-19 09:59:38 --> Language Class Initialized
INFO - 2016-09-19 09:59:38 --> Config Class Initialized
INFO - 2016-09-19 09:59:38 --> Loader Class Initialized
INFO - 2016-09-19 09:59:38 --> Helper loaded: url_helper
INFO - 2016-09-19 09:59:38 --> Database Driver Class Initialized
INFO - 2016-09-19 09:59:38 --> Controller Class Initialized
DEBUG - 2016-09-19 09:59:38 --> Index MX_Controller Initialized
INFO - 2016-09-19 09:59:39 --> Model Class Initialized
INFO - 2016-09-19 09:59:39 --> Model Class Initialized
INFO - 2016-09-19 09:59:39 --> Database Driver Class Initialized
INFO - 2016-09-19 09:59:39 --> Database Driver Class Initialized
INFO - 2016-09-19 09:59:39 --> Database Driver Class Initialized
INFO - 2016-09-19 09:59:39 --> Database Driver Class Initialized
INFO - 2016-09-19 09:59:39 --> Final output sent to browser
DEBUG - 2016-09-19 09:59:39 --> Total execution time: 1.1375
INFO - 2016-09-19 10:00:50 --> Config Class Initialized
INFO - 2016-09-19 10:00:50 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:00:50 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:00:50 --> Utf8 Class Initialized
INFO - 2016-09-19 10:00:50 --> URI Class Initialized
INFO - 2016-09-19 10:00:50 --> Router Class Initialized
INFO - 2016-09-19 10:00:50 --> Output Class Initialized
INFO - 2016-09-19 10:00:50 --> Security Class Initialized
DEBUG - 2016-09-19 10:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:00:50 --> Input Class Initialized
INFO - 2016-09-19 10:00:50 --> Language Class Initialized
INFO - 2016-09-19 10:00:50 --> Language Class Initialized
INFO - 2016-09-19 10:00:50 --> Config Class Initialized
INFO - 2016-09-19 10:00:50 --> Loader Class Initialized
INFO - 2016-09-19 10:00:51 --> Helper loaded: url_helper
INFO - 2016-09-19 10:00:51 --> Database Driver Class Initialized
INFO - 2016-09-19 10:00:51 --> Controller Class Initialized
DEBUG - 2016-09-19 10:00:51 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:00:51 --> Model Class Initialized
INFO - 2016-09-19 10:00:51 --> Model Class Initialized
INFO - 2016-09-19 10:00:51 --> Database Driver Class Initialized
INFO - 2016-09-19 10:00:51 --> Final output sent to browser
DEBUG - 2016-09-19 10:00:51 --> Total execution time: 0.8103
INFO - 2016-09-19 10:00:54 --> Config Class Initialized
INFO - 2016-09-19 10:00:54 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:00:54 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:00:54 --> Utf8 Class Initialized
INFO - 2016-09-19 10:00:54 --> URI Class Initialized
INFO - 2016-09-19 10:00:54 --> Router Class Initialized
INFO - 2016-09-19 10:00:54 --> Output Class Initialized
INFO - 2016-09-19 10:00:54 --> Security Class Initialized
DEBUG - 2016-09-19 10:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:00:54 --> Input Class Initialized
INFO - 2016-09-19 10:00:54 --> Language Class Initialized
INFO - 2016-09-19 10:00:54 --> Language Class Initialized
INFO - 2016-09-19 10:00:54 --> Config Class Initialized
INFO - 2016-09-19 10:00:54 --> Loader Class Initialized
INFO - 2016-09-19 10:00:54 --> Helper loaded: url_helper
INFO - 2016-09-19 10:00:54 --> Database Driver Class Initialized
INFO - 2016-09-19 10:00:54 --> Controller Class Initialized
DEBUG - 2016-09-19 10:00:54 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:00:54 --> Model Class Initialized
INFO - 2016-09-19 10:00:54 --> Model Class Initialized
INFO - 2016-09-19 10:00:54 --> Database Driver Class Initialized
INFO - 2016-09-19 10:00:55 --> Database Driver Class Initialized
INFO - 2016-09-19 10:00:55 --> Database Driver Class Initialized
INFO - 2016-09-19 10:00:55 --> Database Driver Class Initialized
INFO - 2016-09-19 10:00:55 --> Final output sent to browser
DEBUG - 2016-09-19 10:00:55 --> Total execution time: 1.1437
INFO - 2016-09-19 10:02:03 --> Config Class Initialized
INFO - 2016-09-19 10:02:04 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:02:04 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:02:04 --> Utf8 Class Initialized
INFO - 2016-09-19 10:02:04 --> URI Class Initialized
INFO - 2016-09-19 10:02:04 --> Router Class Initialized
INFO - 2016-09-19 10:02:04 --> Output Class Initialized
INFO - 2016-09-19 10:02:04 --> Security Class Initialized
DEBUG - 2016-09-19 10:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:02:04 --> Input Class Initialized
INFO - 2016-09-19 10:02:04 --> Language Class Initialized
INFO - 2016-09-19 10:02:04 --> Language Class Initialized
INFO - 2016-09-19 10:02:04 --> Config Class Initialized
INFO - 2016-09-19 10:02:04 --> Loader Class Initialized
INFO - 2016-09-19 10:02:04 --> Helper loaded: url_helper
INFO - 2016-09-19 10:02:04 --> Database Driver Class Initialized
INFO - 2016-09-19 10:02:04 --> Controller Class Initialized
DEBUG - 2016-09-19 10:02:04 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:02:04 --> Model Class Initialized
INFO - 2016-09-19 10:02:04 --> Model Class Initialized
INFO - 2016-09-19 10:02:04 --> Database Driver Class Initialized
INFO - 2016-09-19 10:02:04 --> Final output sent to browser
DEBUG - 2016-09-19 10:02:04 --> Total execution time: 0.7656
INFO - 2016-09-19 10:02:06 --> Config Class Initialized
INFO - 2016-09-19 10:02:06 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:02:07 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:02:07 --> Utf8 Class Initialized
INFO - 2016-09-19 10:02:07 --> URI Class Initialized
INFO - 2016-09-19 10:02:07 --> Router Class Initialized
INFO - 2016-09-19 10:02:07 --> Output Class Initialized
INFO - 2016-09-19 10:02:07 --> Security Class Initialized
DEBUG - 2016-09-19 10:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:02:07 --> Input Class Initialized
INFO - 2016-09-19 10:02:07 --> Language Class Initialized
INFO - 2016-09-19 10:02:07 --> Language Class Initialized
INFO - 2016-09-19 10:02:07 --> Config Class Initialized
INFO - 2016-09-19 10:02:07 --> Loader Class Initialized
INFO - 2016-09-19 10:02:07 --> Helper loaded: url_helper
INFO - 2016-09-19 10:02:07 --> Database Driver Class Initialized
INFO - 2016-09-19 10:02:07 --> Controller Class Initialized
DEBUG - 2016-09-19 10:02:07 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:02:07 --> Model Class Initialized
INFO - 2016-09-19 10:02:07 --> Model Class Initialized
INFO - 2016-09-19 10:02:07 --> Database Driver Class Initialized
INFO - 2016-09-19 10:02:07 --> Database Driver Class Initialized
INFO - 2016-09-19 10:02:07 --> Database Driver Class Initialized
INFO - 2016-09-19 10:02:07 --> Database Driver Class Initialized
INFO - 2016-09-19 10:02:07 --> Final output sent to browser
DEBUG - 2016-09-19 10:02:08 --> Total execution time: 1.0645
INFO - 2016-09-19 10:02:58 --> Config Class Initialized
INFO - 2016-09-19 10:02:58 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:02:58 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:02:58 --> Utf8 Class Initialized
INFO - 2016-09-19 10:02:58 --> URI Class Initialized
INFO - 2016-09-19 10:02:58 --> Router Class Initialized
INFO - 2016-09-19 10:02:58 --> Output Class Initialized
INFO - 2016-09-19 10:02:58 --> Security Class Initialized
DEBUG - 2016-09-19 10:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:02:58 --> Input Class Initialized
INFO - 2016-09-19 10:02:58 --> Language Class Initialized
INFO - 2016-09-19 10:02:58 --> Language Class Initialized
INFO - 2016-09-19 10:02:58 --> Config Class Initialized
INFO - 2016-09-19 10:02:58 --> Loader Class Initialized
INFO - 2016-09-19 10:02:58 --> Helper loaded: url_helper
INFO - 2016-09-19 10:02:58 --> Database Driver Class Initialized
INFO - 2016-09-19 10:02:58 --> Controller Class Initialized
DEBUG - 2016-09-19 10:02:58 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:02:58 --> Model Class Initialized
INFO - 2016-09-19 10:02:59 --> Model Class Initialized
INFO - 2016-09-19 10:02:59 --> Database Driver Class Initialized
INFO - 2016-09-19 10:02:59 --> Final output sent to browser
DEBUG - 2016-09-19 10:02:59 --> Total execution time: 0.8336
INFO - 2016-09-19 10:03:06 --> Config Class Initialized
INFO - 2016-09-19 10:03:06 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:03:06 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:03:06 --> Utf8 Class Initialized
INFO - 2016-09-19 10:03:06 --> URI Class Initialized
INFO - 2016-09-19 10:03:06 --> Router Class Initialized
INFO - 2016-09-19 10:03:06 --> Output Class Initialized
INFO - 2016-09-19 10:03:06 --> Security Class Initialized
DEBUG - 2016-09-19 10:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:03:06 --> Input Class Initialized
INFO - 2016-09-19 10:03:06 --> Language Class Initialized
INFO - 2016-09-19 10:03:06 --> Language Class Initialized
INFO - 2016-09-19 10:03:06 --> Config Class Initialized
INFO - 2016-09-19 10:03:06 --> Loader Class Initialized
INFO - 2016-09-19 10:03:06 --> Helper loaded: url_helper
INFO - 2016-09-19 10:03:06 --> Database Driver Class Initialized
INFO - 2016-09-19 10:03:06 --> Controller Class Initialized
DEBUG - 2016-09-19 10:03:06 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:03:07 --> Model Class Initialized
INFO - 2016-09-19 10:03:07 --> Model Class Initialized
INFO - 2016-09-19 10:03:07 --> Database Driver Class Initialized
INFO - 2016-09-19 10:03:07 --> Final output sent to browser
DEBUG - 2016-09-19 10:03:07 --> Total execution time: 0.8189
INFO - 2016-09-19 10:03:08 --> Config Class Initialized
INFO - 2016-09-19 10:03:09 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:03:09 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:03:09 --> Utf8 Class Initialized
INFO - 2016-09-19 10:03:09 --> URI Class Initialized
INFO - 2016-09-19 10:03:09 --> Router Class Initialized
INFO - 2016-09-19 10:03:09 --> Output Class Initialized
INFO - 2016-09-19 10:03:09 --> Security Class Initialized
DEBUG - 2016-09-19 10:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:03:09 --> Input Class Initialized
INFO - 2016-09-19 10:03:09 --> Language Class Initialized
INFO - 2016-09-19 10:03:09 --> Language Class Initialized
INFO - 2016-09-19 10:03:09 --> Config Class Initialized
INFO - 2016-09-19 10:03:09 --> Loader Class Initialized
INFO - 2016-09-19 10:03:09 --> Helper loaded: url_helper
INFO - 2016-09-19 10:03:09 --> Database Driver Class Initialized
INFO - 2016-09-19 10:03:09 --> Controller Class Initialized
DEBUG - 2016-09-19 10:03:09 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:03:09 --> Model Class Initialized
INFO - 2016-09-19 10:03:09 --> Model Class Initialized
INFO - 2016-09-19 10:03:09 --> Database Driver Class Initialized
INFO - 2016-09-19 10:03:09 --> Final output sent to browser
DEBUG - 2016-09-19 10:03:09 --> Total execution time: 0.8351
INFO - 2016-09-19 10:07:22 --> Config Class Initialized
INFO - 2016-09-19 10:07:22 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:07:22 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:07:22 --> Utf8 Class Initialized
INFO - 2016-09-19 10:07:22 --> URI Class Initialized
INFO - 2016-09-19 10:07:22 --> Router Class Initialized
INFO - 2016-09-19 10:07:22 --> Output Class Initialized
INFO - 2016-09-19 10:07:22 --> Security Class Initialized
DEBUG - 2016-09-19 10:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:07:22 --> Input Class Initialized
INFO - 2016-09-19 10:07:22 --> Language Class Initialized
INFO - 2016-09-19 10:07:22 --> Language Class Initialized
INFO - 2016-09-19 10:07:22 --> Config Class Initialized
INFO - 2016-09-19 10:07:23 --> Loader Class Initialized
INFO - 2016-09-19 10:07:23 --> Helper loaded: url_helper
INFO - 2016-09-19 10:07:23 --> Database Driver Class Initialized
INFO - 2016-09-19 10:07:23 --> Controller Class Initialized
DEBUG - 2016-09-19 10:07:23 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:07:23 --> Model Class Initialized
INFO - 2016-09-19 10:07:23 --> Model Class Initialized
INFO - 2016-09-19 10:07:23 --> Database Driver Class Initialized
INFO - 2016-09-19 10:07:23 --> Final output sent to browser
DEBUG - 2016-09-19 10:07:23 --> Total execution time: 0.7930
INFO - 2016-09-19 10:07:30 --> Config Class Initialized
INFO - 2016-09-19 10:07:30 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:07:30 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:07:31 --> Utf8 Class Initialized
INFO - 2016-09-19 10:07:31 --> URI Class Initialized
INFO - 2016-09-19 10:07:31 --> Router Class Initialized
INFO - 2016-09-19 10:07:31 --> Output Class Initialized
INFO - 2016-09-19 10:07:31 --> Security Class Initialized
DEBUG - 2016-09-19 10:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:07:31 --> Input Class Initialized
INFO - 2016-09-19 10:07:31 --> Language Class Initialized
INFO - 2016-09-19 10:07:31 --> Language Class Initialized
INFO - 2016-09-19 10:07:31 --> Config Class Initialized
INFO - 2016-09-19 10:07:31 --> Loader Class Initialized
INFO - 2016-09-19 10:07:31 --> Helper loaded: url_helper
INFO - 2016-09-19 10:07:31 --> Database Driver Class Initialized
INFO - 2016-09-19 10:07:31 --> Controller Class Initialized
DEBUG - 2016-09-19 10:07:31 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:07:31 --> Model Class Initialized
INFO - 2016-09-19 10:07:31 --> Model Class Initialized
DEBUG - 2016-09-19 10:07:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 10:07:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 10:07:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 10:07:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 10:07:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 10:07:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 10:07:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 10:07:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 10:07:32 --> Final output sent to browser
DEBUG - 2016-09-19 10:07:32 --> Total execution time: 1.1947
INFO - 2016-09-19 10:07:36 --> Config Class Initialized
INFO - 2016-09-19 10:07:36 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:07:36 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:07:36 --> Utf8 Class Initialized
INFO - 2016-09-19 10:07:36 --> URI Class Initialized
INFO - 2016-09-19 10:07:36 --> Router Class Initialized
INFO - 2016-09-19 10:07:36 --> Output Class Initialized
INFO - 2016-09-19 10:07:36 --> Security Class Initialized
DEBUG - 2016-09-19 10:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:07:36 --> Input Class Initialized
INFO - 2016-09-19 10:07:36 --> Language Class Initialized
INFO - 2016-09-19 10:07:36 --> Language Class Initialized
INFO - 2016-09-19 10:07:36 --> Config Class Initialized
INFO - 2016-09-19 10:07:36 --> Loader Class Initialized
INFO - 2016-09-19 10:07:36 --> Helper loaded: url_helper
INFO - 2016-09-19 10:07:37 --> Database Driver Class Initialized
INFO - 2016-09-19 10:07:37 --> Controller Class Initialized
DEBUG - 2016-09-19 10:07:37 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:07:37 --> Model Class Initialized
INFO - 2016-09-19 10:07:37 --> Model Class Initialized
DEBUG - 2016-09-19 10:07:37 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 10:07:37 --> Database Driver Class Initialized
INFO - 2016-09-19 10:07:37 --> Final output sent to browser
DEBUG - 2016-09-19 10:07:37 --> Total execution time: 1.0232
INFO - 2016-09-19 10:08:42 --> Config Class Initialized
INFO - 2016-09-19 10:08:42 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:08:42 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:08:42 --> Utf8 Class Initialized
INFO - 2016-09-19 10:08:42 --> URI Class Initialized
INFO - 2016-09-19 10:08:42 --> Router Class Initialized
INFO - 2016-09-19 10:08:43 --> Output Class Initialized
INFO - 2016-09-19 10:08:43 --> Security Class Initialized
DEBUG - 2016-09-19 10:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:08:43 --> Input Class Initialized
INFO - 2016-09-19 10:08:43 --> Language Class Initialized
INFO - 2016-09-19 10:08:43 --> Language Class Initialized
INFO - 2016-09-19 10:08:43 --> Config Class Initialized
INFO - 2016-09-19 10:08:43 --> Loader Class Initialized
INFO - 2016-09-19 10:08:43 --> Helper loaded: url_helper
INFO - 2016-09-19 10:08:43 --> Database Driver Class Initialized
INFO - 2016-09-19 10:08:43 --> Controller Class Initialized
DEBUG - 2016-09-19 10:08:43 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:08:43 --> Model Class Initialized
INFO - 2016-09-19 10:08:43 --> Model Class Initialized
DEBUG - 2016-09-19 10:08:43 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 10:08:43 --> Database Driver Class Initialized
INFO - 2016-09-19 10:08:43 --> Final output sent to browser
DEBUG - 2016-09-19 10:08:43 --> Total execution time: 0.8665
INFO - 2016-09-19 10:09:40 --> Config Class Initialized
INFO - 2016-09-19 10:09:40 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:09:40 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:09:40 --> Utf8 Class Initialized
INFO - 2016-09-19 10:09:40 --> URI Class Initialized
INFO - 2016-09-19 10:09:40 --> Router Class Initialized
INFO - 2016-09-19 10:09:40 --> Output Class Initialized
INFO - 2016-09-19 10:09:40 --> Security Class Initialized
DEBUG - 2016-09-19 10:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:09:41 --> Input Class Initialized
INFO - 2016-09-19 10:09:41 --> Language Class Initialized
INFO - 2016-09-19 10:09:41 --> Language Class Initialized
INFO - 2016-09-19 10:09:41 --> Config Class Initialized
INFO - 2016-09-19 10:09:41 --> Loader Class Initialized
INFO - 2016-09-19 10:09:41 --> Helper loaded: url_helper
INFO - 2016-09-19 10:09:41 --> Database Driver Class Initialized
INFO - 2016-09-19 10:09:41 --> Controller Class Initialized
DEBUG - 2016-09-19 10:09:41 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:09:41 --> Model Class Initialized
INFO - 2016-09-19 10:09:41 --> Model Class Initialized
DEBUG - 2016-09-19 10:09:41 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 10:09:41 --> Database Driver Class Initialized
INFO - 2016-09-19 10:09:41 --> Final output sent to browser
DEBUG - 2016-09-19 10:09:41 --> Total execution time: 0.8660
INFO - 2016-09-19 10:09:41 --> Config Class Initialized
INFO - 2016-09-19 10:09:42 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:09:42 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:09:42 --> Utf8 Class Initialized
INFO - 2016-09-19 10:09:42 --> URI Class Initialized
INFO - 2016-09-19 10:09:42 --> Router Class Initialized
INFO - 2016-09-19 10:09:42 --> Output Class Initialized
INFO - 2016-09-19 10:09:42 --> Security Class Initialized
DEBUG - 2016-09-19 10:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:09:42 --> Input Class Initialized
INFO - 2016-09-19 10:09:42 --> Language Class Initialized
INFO - 2016-09-19 10:09:42 --> Language Class Initialized
INFO - 2016-09-19 10:09:42 --> Config Class Initialized
INFO - 2016-09-19 10:09:42 --> Loader Class Initialized
INFO - 2016-09-19 10:09:42 --> Helper loaded: url_helper
INFO - 2016-09-19 10:09:42 --> Database Driver Class Initialized
INFO - 2016-09-19 10:09:42 --> Controller Class Initialized
DEBUG - 2016-09-19 10:09:42 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:09:42 --> Model Class Initialized
INFO - 2016-09-19 10:09:42 --> Model Class Initialized
DEBUG - 2016-09-19 10:09:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 10:09:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 10:09:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 10:09:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_umum.php
DEBUG - 2016-09-19 10:09:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 10:09:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 10:09:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 10:09:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 10:09:43 --> Final output sent to browser
DEBUG - 2016-09-19 10:09:43 --> Total execution time: 1.1309
INFO - 2016-09-19 10:09:47 --> Config Class Initialized
INFO - 2016-09-19 10:09:47 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:09:47 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:09:47 --> Utf8 Class Initialized
INFO - 2016-09-19 10:09:47 --> URI Class Initialized
INFO - 2016-09-19 10:09:47 --> Router Class Initialized
INFO - 2016-09-19 10:09:47 --> Output Class Initialized
INFO - 2016-09-19 10:09:47 --> Security Class Initialized
DEBUG - 2016-09-19 10:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:09:47 --> Input Class Initialized
INFO - 2016-09-19 10:09:48 --> Language Class Initialized
INFO - 2016-09-19 10:09:48 --> Language Class Initialized
INFO - 2016-09-19 10:09:48 --> Config Class Initialized
INFO - 2016-09-19 10:09:48 --> Loader Class Initialized
INFO - 2016-09-19 10:09:48 --> Helper loaded: url_helper
INFO - 2016-09-19 10:09:48 --> Database Driver Class Initialized
INFO - 2016-09-19 10:09:48 --> Controller Class Initialized
DEBUG - 2016-09-19 10:09:48 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:09:48 --> Model Class Initialized
INFO - 2016-09-19 10:09:48 --> Model Class Initialized
DEBUG - 2016-09-19 10:09:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 10:09:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 10:09:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 10:09:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_umum.php
DEBUG - 2016-09-19 10:09:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 10:09:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 10:09:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 10:09:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 10:09:48 --> Final output sent to browser
DEBUG - 2016-09-19 10:09:48 --> Total execution time: 1.1678
INFO - 2016-09-19 10:12:51 --> Config Class Initialized
INFO - 2016-09-19 10:12:51 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:12:51 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:12:51 --> Utf8 Class Initialized
INFO - 2016-09-19 10:12:51 --> URI Class Initialized
INFO - 2016-09-19 10:12:51 --> Router Class Initialized
INFO - 2016-09-19 10:12:51 --> Output Class Initialized
INFO - 2016-09-19 10:12:51 --> Security Class Initialized
DEBUG - 2016-09-19 10:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:12:51 --> Input Class Initialized
INFO - 2016-09-19 10:12:51 --> Language Class Initialized
INFO - 2016-09-19 10:12:51 --> Language Class Initialized
INFO - 2016-09-19 10:12:51 --> Config Class Initialized
INFO - 2016-09-19 10:12:51 --> Loader Class Initialized
INFO - 2016-09-19 10:12:51 --> Helper loaded: url_helper
INFO - 2016-09-19 10:12:51 --> Database Driver Class Initialized
INFO - 2016-09-19 10:12:51 --> Controller Class Initialized
DEBUG - 2016-09-19 10:12:51 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:12:52 --> Model Class Initialized
INFO - 2016-09-19 10:12:52 --> Model Class Initialized
DEBUG - 2016-09-19 10:12:52 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 10:12:52 --> Database Driver Class Initialized
INFO - 2016-09-19 10:12:52 --> Final output sent to browser
DEBUG - 2016-09-19 10:12:52 --> Total execution time: 0.8129
INFO - 2016-09-19 10:13:07 --> Config Class Initialized
INFO - 2016-09-19 10:13:07 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:13:07 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:13:07 --> Utf8 Class Initialized
INFO - 2016-09-19 10:13:07 --> URI Class Initialized
INFO - 2016-09-19 10:13:07 --> Router Class Initialized
INFO - 2016-09-19 10:13:07 --> Output Class Initialized
INFO - 2016-09-19 10:13:07 --> Security Class Initialized
DEBUG - 2016-09-19 10:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:13:07 --> Input Class Initialized
INFO - 2016-09-19 10:13:07 --> Language Class Initialized
INFO - 2016-09-19 10:13:07 --> Language Class Initialized
INFO - 2016-09-19 10:13:07 --> Config Class Initialized
INFO - 2016-09-19 10:13:08 --> Loader Class Initialized
INFO - 2016-09-19 10:13:08 --> Helper loaded: url_helper
INFO - 2016-09-19 10:13:08 --> Database Driver Class Initialized
INFO - 2016-09-19 10:13:08 --> Controller Class Initialized
DEBUG - 2016-09-19 10:13:08 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:13:08 --> Model Class Initialized
INFO - 2016-09-19 10:13:08 --> Model Class Initialized
DEBUG - 2016-09-19 10:13:08 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 10:13:08 --> Database Driver Class Initialized
INFO - 2016-09-19 10:13:08 --> Final output sent to browser
DEBUG - 2016-09-19 10:13:08 --> Total execution time: 0.7871
INFO - 2016-09-19 10:13:12 --> Config Class Initialized
INFO - 2016-09-19 10:13:12 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:13:12 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:13:12 --> Utf8 Class Initialized
INFO - 2016-09-19 10:13:12 --> URI Class Initialized
INFO - 2016-09-19 10:13:12 --> Router Class Initialized
INFO - 2016-09-19 10:13:12 --> Output Class Initialized
INFO - 2016-09-19 10:13:12 --> Security Class Initialized
DEBUG - 2016-09-19 10:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:13:12 --> Input Class Initialized
INFO - 2016-09-19 10:13:12 --> Language Class Initialized
INFO - 2016-09-19 10:13:12 --> Language Class Initialized
INFO - 2016-09-19 10:13:12 --> Config Class Initialized
INFO - 2016-09-19 10:13:12 --> Loader Class Initialized
INFO - 2016-09-19 10:13:12 --> Helper loaded: url_helper
INFO - 2016-09-19 10:13:12 --> Database Driver Class Initialized
INFO - 2016-09-19 10:13:12 --> Controller Class Initialized
DEBUG - 2016-09-19 10:13:12 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:13:12 --> Model Class Initialized
INFO - 2016-09-19 10:13:12 --> Model Class Initialized
DEBUG - 2016-09-19 10:13:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 10:13:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 10:13:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 10:13:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_bayar_angsuran.php
DEBUG - 2016-09-19 10:13:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 10:13:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 10:13:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 10:13:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 10:13:13 --> Final output sent to browser
DEBUG - 2016-09-19 10:13:13 --> Total execution time: 1.0215
INFO - 2016-09-19 10:13:17 --> Config Class Initialized
INFO - 2016-09-19 10:13:17 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:13:17 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:13:17 --> Utf8 Class Initialized
INFO - 2016-09-19 10:13:17 --> URI Class Initialized
INFO - 2016-09-19 10:13:17 --> Router Class Initialized
INFO - 2016-09-19 10:13:17 --> Output Class Initialized
INFO - 2016-09-19 10:13:17 --> Security Class Initialized
DEBUG - 2016-09-19 10:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:13:17 --> Input Class Initialized
INFO - 2016-09-19 10:13:17 --> Language Class Initialized
INFO - 2016-09-19 10:13:17 --> Language Class Initialized
INFO - 2016-09-19 10:13:17 --> Config Class Initialized
INFO - 2016-09-19 10:13:17 --> Loader Class Initialized
INFO - 2016-09-19 10:13:17 --> Helper loaded: url_helper
INFO - 2016-09-19 10:13:17 --> Database Driver Class Initialized
INFO - 2016-09-19 10:13:17 --> Controller Class Initialized
DEBUG - 2016-09-19 10:13:17 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:13:17 --> Model Class Initialized
INFO - 2016-09-19 10:13:17 --> Model Class Initialized
INFO - 2016-09-19 10:13:18 --> Database Driver Class Initialized
INFO - 2016-09-19 10:13:18 --> Final output sent to browser
DEBUG - 2016-09-19 10:13:18 --> Total execution time: 0.8191
INFO - 2016-09-19 10:13:28 --> Config Class Initialized
INFO - 2016-09-19 10:13:28 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:13:28 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:13:28 --> Utf8 Class Initialized
INFO - 2016-09-19 10:13:28 --> URI Class Initialized
INFO - 2016-09-19 10:13:28 --> Router Class Initialized
INFO - 2016-09-19 10:13:28 --> Output Class Initialized
INFO - 2016-09-19 10:13:28 --> Security Class Initialized
DEBUG - 2016-09-19 10:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:13:29 --> Input Class Initialized
INFO - 2016-09-19 10:13:29 --> Language Class Initialized
INFO - 2016-09-19 10:13:29 --> Language Class Initialized
INFO - 2016-09-19 10:13:29 --> Config Class Initialized
INFO - 2016-09-19 10:13:29 --> Loader Class Initialized
INFO - 2016-09-19 10:13:29 --> Helper loaded: url_helper
INFO - 2016-09-19 10:13:29 --> Database Driver Class Initialized
INFO - 2016-09-19 10:13:29 --> Controller Class Initialized
DEBUG - 2016-09-19 10:13:29 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:13:29 --> Model Class Initialized
INFO - 2016-09-19 10:13:29 --> Model Class Initialized
INFO - 2016-09-19 10:13:29 --> Database Driver Class Initialized
INFO - 2016-09-19 10:13:29 --> Database Driver Class Initialized
INFO - 2016-09-19 10:13:29 --> Database Driver Class Initialized
INFO - 2016-09-19 10:13:29 --> Database Driver Class Initialized
INFO - 2016-09-19 10:13:29 --> Final output sent to browser
DEBUG - 2016-09-19 10:13:29 --> Total execution time: 1.0984
INFO - 2016-09-19 10:13:31 --> Config Class Initialized
INFO - 2016-09-19 10:13:31 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:13:31 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:13:31 --> Utf8 Class Initialized
INFO - 2016-09-19 10:13:31 --> URI Class Initialized
INFO - 2016-09-19 10:13:31 --> Router Class Initialized
INFO - 2016-09-19 10:13:31 --> Output Class Initialized
INFO - 2016-09-19 10:13:31 --> Security Class Initialized
DEBUG - 2016-09-19 10:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:13:31 --> Input Class Initialized
INFO - 2016-09-19 10:13:32 --> Language Class Initialized
INFO - 2016-09-19 10:13:32 --> Language Class Initialized
INFO - 2016-09-19 10:13:32 --> Config Class Initialized
INFO - 2016-09-19 10:13:32 --> Loader Class Initialized
INFO - 2016-09-19 10:13:32 --> Helper loaded: url_helper
INFO - 2016-09-19 10:13:32 --> Database Driver Class Initialized
INFO - 2016-09-19 10:13:32 --> Controller Class Initialized
DEBUG - 2016-09-19 10:13:32 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:13:32 --> Model Class Initialized
INFO - 2016-09-19 10:13:32 --> Model Class Initialized
INFO - 2016-09-19 10:13:32 --> Database Driver Class Initialized
INFO - 2016-09-19 10:13:32 --> Final output sent to browser
DEBUG - 2016-09-19 10:13:32 --> Total execution time: 0.8578
INFO - 2016-09-19 10:13:36 --> Config Class Initialized
INFO - 2016-09-19 10:13:36 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:13:36 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:13:36 --> Utf8 Class Initialized
INFO - 2016-09-19 10:13:36 --> URI Class Initialized
INFO - 2016-09-19 10:13:36 --> Router Class Initialized
INFO - 2016-09-19 10:13:36 --> Output Class Initialized
INFO - 2016-09-19 10:13:36 --> Security Class Initialized
DEBUG - 2016-09-19 10:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:13:36 --> Input Class Initialized
INFO - 2016-09-19 10:13:36 --> Language Class Initialized
INFO - 2016-09-19 10:13:36 --> Language Class Initialized
INFO - 2016-09-19 10:13:36 --> Config Class Initialized
INFO - 2016-09-19 10:13:36 --> Loader Class Initialized
INFO - 2016-09-19 10:13:36 --> Helper loaded: url_helper
INFO - 2016-09-19 10:13:36 --> Database Driver Class Initialized
INFO - 2016-09-19 10:13:36 --> Controller Class Initialized
DEBUG - 2016-09-19 10:13:37 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:13:37 --> Model Class Initialized
INFO - 2016-09-19 10:13:37 --> Model Class Initialized
DEBUG - 2016-09-19 10:13:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 10:13:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 10:13:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 10:13:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 10:13:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 10:13:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 10:13:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 10:13:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 10:13:37 --> Final output sent to browser
DEBUG - 2016-09-19 10:13:37 --> Total execution time: 1.1875
INFO - 2016-09-19 10:13:42 --> Config Class Initialized
INFO - 2016-09-19 10:13:42 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:13:42 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:13:42 --> Utf8 Class Initialized
INFO - 2016-09-19 10:13:42 --> URI Class Initialized
INFO - 2016-09-19 10:13:42 --> Router Class Initialized
INFO - 2016-09-19 10:13:42 --> Output Class Initialized
INFO - 2016-09-19 10:13:42 --> Security Class Initialized
DEBUG - 2016-09-19 10:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:13:42 --> Input Class Initialized
INFO - 2016-09-19 10:13:42 --> Language Class Initialized
INFO - 2016-09-19 10:13:42 --> Language Class Initialized
INFO - 2016-09-19 10:13:42 --> Config Class Initialized
INFO - 2016-09-19 10:13:42 --> Loader Class Initialized
INFO - 2016-09-19 10:13:42 --> Helper loaded: url_helper
INFO - 2016-09-19 10:13:42 --> Database Driver Class Initialized
INFO - 2016-09-19 10:13:42 --> Controller Class Initialized
DEBUG - 2016-09-19 10:13:42 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:13:42 --> Model Class Initialized
INFO - 2016-09-19 10:13:42 --> Model Class Initialized
DEBUG - 2016-09-19 10:13:42 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 10:13:42 --> Database Driver Class Initialized
INFO - 2016-09-19 10:13:43 --> Final output sent to browser
DEBUG - 2016-09-19 10:13:43 --> Total execution time: 0.8952
INFO - 2016-09-19 10:13:51 --> Config Class Initialized
INFO - 2016-09-19 10:13:51 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:13:51 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:13:51 --> Utf8 Class Initialized
INFO - 2016-09-19 10:13:51 --> URI Class Initialized
INFO - 2016-09-19 10:13:52 --> Router Class Initialized
INFO - 2016-09-19 10:13:52 --> Output Class Initialized
INFO - 2016-09-19 10:13:52 --> Security Class Initialized
DEBUG - 2016-09-19 10:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:13:52 --> Input Class Initialized
INFO - 2016-09-19 10:13:52 --> Language Class Initialized
INFO - 2016-09-19 10:13:52 --> Language Class Initialized
INFO - 2016-09-19 10:13:52 --> Config Class Initialized
INFO - 2016-09-19 10:13:52 --> Loader Class Initialized
INFO - 2016-09-19 10:13:52 --> Helper loaded: url_helper
INFO - 2016-09-19 10:13:52 --> Database Driver Class Initialized
INFO - 2016-09-19 10:13:52 --> Controller Class Initialized
DEBUG - 2016-09-19 10:13:52 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:13:52 --> Model Class Initialized
INFO - 2016-09-19 10:13:52 --> Model Class Initialized
DEBUG - 2016-09-19 10:13:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 10:13:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 10:13:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 10:13:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_bayar_angsuran.php
DEBUG - 2016-09-19 10:13:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 10:13:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 10:13:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 10:13:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 10:13:53 --> Final output sent to browser
DEBUG - 2016-09-19 10:13:53 --> Total execution time: 1.1914
INFO - 2016-09-19 10:13:57 --> Config Class Initialized
INFO - 2016-09-19 10:13:57 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:13:57 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:13:57 --> Utf8 Class Initialized
INFO - 2016-09-19 10:13:57 --> URI Class Initialized
INFO - 2016-09-19 10:13:57 --> Router Class Initialized
INFO - 2016-09-19 10:13:57 --> Output Class Initialized
INFO - 2016-09-19 10:13:57 --> Security Class Initialized
DEBUG - 2016-09-19 10:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:13:57 --> Input Class Initialized
INFO - 2016-09-19 10:13:57 --> Language Class Initialized
INFO - 2016-09-19 10:13:57 --> Language Class Initialized
INFO - 2016-09-19 10:13:57 --> Config Class Initialized
INFO - 2016-09-19 10:13:57 --> Loader Class Initialized
INFO - 2016-09-19 10:13:57 --> Helper loaded: url_helper
INFO - 2016-09-19 10:13:57 --> Database Driver Class Initialized
INFO - 2016-09-19 10:13:57 --> Controller Class Initialized
DEBUG - 2016-09-19 10:13:57 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:13:57 --> Model Class Initialized
INFO - 2016-09-19 10:13:57 --> Model Class Initialized
INFO - 2016-09-19 10:13:57 --> Database Driver Class Initialized
INFO - 2016-09-19 10:13:57 --> Final output sent to browser
DEBUG - 2016-09-19 10:13:58 --> Total execution time: 0.8500
INFO - 2016-09-19 10:20:13 --> Config Class Initialized
INFO - 2016-09-19 10:20:13 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:20:13 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:20:13 --> Utf8 Class Initialized
INFO - 2016-09-19 10:20:13 --> URI Class Initialized
INFO - 2016-09-19 10:20:13 --> Router Class Initialized
INFO - 2016-09-19 10:20:13 --> Output Class Initialized
INFO - 2016-09-19 10:20:13 --> Security Class Initialized
DEBUG - 2016-09-19 10:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:20:13 --> Input Class Initialized
INFO - 2016-09-19 10:20:13 --> Language Class Initialized
INFO - 2016-09-19 10:20:13 --> Language Class Initialized
INFO - 2016-09-19 10:20:13 --> Config Class Initialized
INFO - 2016-09-19 10:20:13 --> Loader Class Initialized
INFO - 2016-09-19 10:20:13 --> Helper loaded: url_helper
INFO - 2016-09-19 10:20:13 --> Database Driver Class Initialized
INFO - 2016-09-19 10:20:13 --> Controller Class Initialized
DEBUG - 2016-09-19 10:20:13 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:20:13 --> Model Class Initialized
INFO - 2016-09-19 10:20:13 --> Model Class Initialized
INFO - 2016-09-19 10:20:13 --> Database Driver Class Initialized
INFO - 2016-09-19 10:20:13 --> Final output sent to browser
DEBUG - 2016-09-19 10:20:13 --> Total execution time: 0.8384
INFO - 2016-09-19 10:20:19 --> Config Class Initialized
INFO - 2016-09-19 10:20:20 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:20:20 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:20:20 --> Utf8 Class Initialized
INFO - 2016-09-19 10:20:20 --> URI Class Initialized
INFO - 2016-09-19 10:20:20 --> Router Class Initialized
INFO - 2016-09-19 10:20:20 --> Output Class Initialized
INFO - 2016-09-19 10:20:20 --> Security Class Initialized
DEBUG - 2016-09-19 10:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:20:20 --> Input Class Initialized
INFO - 2016-09-19 10:20:20 --> Language Class Initialized
INFO - 2016-09-19 10:20:20 --> Language Class Initialized
INFO - 2016-09-19 10:20:20 --> Config Class Initialized
INFO - 2016-09-19 10:20:20 --> Loader Class Initialized
INFO - 2016-09-19 10:20:20 --> Helper loaded: url_helper
INFO - 2016-09-19 10:20:20 --> Database Driver Class Initialized
INFO - 2016-09-19 10:20:20 --> Controller Class Initialized
DEBUG - 2016-09-19 10:20:20 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:20:20 --> Model Class Initialized
INFO - 2016-09-19 10:20:20 --> Model Class Initialized
INFO - 2016-09-19 10:20:20 --> Database Driver Class Initialized
INFO - 2016-09-19 10:20:20 --> Database Driver Class Initialized
INFO - 2016-09-19 10:20:20 --> Database Driver Class Initialized
INFO - 2016-09-19 10:20:20 --> Database Driver Class Initialized
INFO - 2016-09-19 10:20:20 --> Database Driver Class Initialized
INFO - 2016-09-19 10:20:21 --> Final output sent to browser
DEBUG - 2016-09-19 10:20:21 --> Total execution time: 1.1288
INFO - 2016-09-19 10:20:23 --> Config Class Initialized
INFO - 2016-09-19 10:20:23 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:20:23 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:20:23 --> Utf8 Class Initialized
INFO - 2016-09-19 10:20:23 --> URI Class Initialized
INFO - 2016-09-19 10:20:23 --> Router Class Initialized
INFO - 2016-09-19 10:20:23 --> Output Class Initialized
INFO - 2016-09-19 10:20:24 --> Security Class Initialized
DEBUG - 2016-09-19 10:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:20:24 --> Input Class Initialized
INFO - 2016-09-19 10:20:24 --> Language Class Initialized
INFO - 2016-09-19 10:20:24 --> Language Class Initialized
INFO - 2016-09-19 10:20:24 --> Config Class Initialized
INFO - 2016-09-19 10:20:24 --> Loader Class Initialized
INFO - 2016-09-19 10:20:24 --> Helper loaded: url_helper
INFO - 2016-09-19 10:20:24 --> Database Driver Class Initialized
INFO - 2016-09-19 10:20:24 --> Controller Class Initialized
DEBUG - 2016-09-19 10:20:24 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:20:24 --> Model Class Initialized
INFO - 2016-09-19 10:20:24 --> Model Class Initialized
INFO - 2016-09-19 10:20:24 --> Final output sent to browser
DEBUG - 2016-09-19 10:20:24 --> Total execution time: 0.7712
INFO - 2016-09-19 10:20:54 --> Config Class Initialized
INFO - 2016-09-19 10:20:54 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:20:54 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:20:54 --> Utf8 Class Initialized
INFO - 2016-09-19 10:20:54 --> URI Class Initialized
INFO - 2016-09-19 10:20:54 --> Router Class Initialized
INFO - 2016-09-19 10:20:54 --> Output Class Initialized
INFO - 2016-09-19 10:20:54 --> Security Class Initialized
DEBUG - 2016-09-19 10:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:20:54 --> Input Class Initialized
INFO - 2016-09-19 10:20:54 --> Language Class Initialized
INFO - 2016-09-19 10:20:54 --> Language Class Initialized
INFO - 2016-09-19 10:20:54 --> Config Class Initialized
INFO - 2016-09-19 10:20:54 --> Loader Class Initialized
INFO - 2016-09-19 10:20:54 --> Helper loaded: url_helper
INFO - 2016-09-19 10:20:54 --> Database Driver Class Initialized
INFO - 2016-09-19 10:20:54 --> Controller Class Initialized
DEBUG - 2016-09-19 10:20:54 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:20:54 --> Model Class Initialized
INFO - 2016-09-19 10:20:54 --> Model Class Initialized
INFO - 2016-09-19 10:20:54 --> Final output sent to browser
DEBUG - 2016-09-19 10:20:54 --> Total execution time: 0.7217
INFO - 2016-09-19 10:20:56 --> Config Class Initialized
INFO - 2016-09-19 10:20:56 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:20:56 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:20:56 --> Utf8 Class Initialized
INFO - 2016-09-19 10:20:56 --> URI Class Initialized
INFO - 2016-09-19 10:20:56 --> Router Class Initialized
INFO - 2016-09-19 10:20:57 --> Output Class Initialized
INFO - 2016-09-19 10:20:57 --> Security Class Initialized
DEBUG - 2016-09-19 10:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:20:57 --> Input Class Initialized
INFO - 2016-09-19 10:20:57 --> Language Class Initialized
INFO - 2016-09-19 10:20:57 --> Language Class Initialized
INFO - 2016-09-19 10:20:57 --> Config Class Initialized
INFO - 2016-09-19 10:20:57 --> Loader Class Initialized
INFO - 2016-09-19 10:20:57 --> Helper loaded: url_helper
INFO - 2016-09-19 10:20:57 --> Database Driver Class Initialized
INFO - 2016-09-19 10:20:57 --> Controller Class Initialized
DEBUG - 2016-09-19 10:20:57 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:20:57 --> Model Class Initialized
INFO - 2016-09-19 10:20:57 --> Model Class Initialized
INFO - 2016-09-19 10:20:57 --> Final output sent to browser
DEBUG - 2016-09-19 10:20:57 --> Total execution time: 1.0033
INFO - 2016-09-19 10:21:05 --> Config Class Initialized
INFO - 2016-09-19 10:21:05 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:21:05 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:21:05 --> Utf8 Class Initialized
INFO - 2016-09-19 10:21:05 --> URI Class Initialized
INFO - 2016-09-19 10:21:05 --> Router Class Initialized
INFO - 2016-09-19 10:21:05 --> Output Class Initialized
INFO - 2016-09-19 10:21:05 --> Security Class Initialized
DEBUG - 2016-09-19 10:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:21:06 --> Input Class Initialized
INFO - 2016-09-19 10:21:06 --> Language Class Initialized
INFO - 2016-09-19 10:21:06 --> Language Class Initialized
INFO - 2016-09-19 10:21:06 --> Config Class Initialized
INFO - 2016-09-19 10:21:06 --> Loader Class Initialized
INFO - 2016-09-19 10:21:06 --> Helper loaded: url_helper
INFO - 2016-09-19 10:21:06 --> Database Driver Class Initialized
INFO - 2016-09-19 10:21:06 --> Controller Class Initialized
DEBUG - 2016-09-19 10:21:06 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:21:06 --> Model Class Initialized
INFO - 2016-09-19 10:21:06 --> Model Class Initialized
INFO - 2016-09-19 10:21:06 --> Database Driver Class Initialized
INFO - 2016-09-19 10:21:06 --> Final output sent to browser
DEBUG - 2016-09-19 10:21:06 --> Total execution time: 0.8175
INFO - 2016-09-19 10:21:12 --> Config Class Initialized
INFO - 2016-09-19 10:21:12 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:21:12 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:21:12 --> Utf8 Class Initialized
INFO - 2016-09-19 10:21:12 --> URI Class Initialized
INFO - 2016-09-19 10:21:13 --> Router Class Initialized
INFO - 2016-09-19 10:21:13 --> Output Class Initialized
INFO - 2016-09-19 10:21:13 --> Security Class Initialized
DEBUG - 2016-09-19 10:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:21:13 --> Input Class Initialized
INFO - 2016-09-19 10:21:13 --> Language Class Initialized
INFO - 2016-09-19 10:21:13 --> Language Class Initialized
INFO - 2016-09-19 10:21:13 --> Config Class Initialized
INFO - 2016-09-19 10:21:13 --> Loader Class Initialized
INFO - 2016-09-19 10:21:13 --> Helper loaded: url_helper
INFO - 2016-09-19 10:21:13 --> Database Driver Class Initialized
INFO - 2016-09-19 10:21:13 --> Controller Class Initialized
DEBUG - 2016-09-19 10:21:13 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:21:13 --> Model Class Initialized
INFO - 2016-09-19 10:21:13 --> Model Class Initialized
INFO - 2016-09-19 10:21:13 --> Database Driver Class Initialized
INFO - 2016-09-19 10:21:13 --> Database Driver Class Initialized
INFO - 2016-09-19 10:21:13 --> Database Driver Class Initialized
INFO - 2016-09-19 10:21:13 --> Database Driver Class Initialized
INFO - 2016-09-19 10:21:13 --> Database Driver Class Initialized
INFO - 2016-09-19 10:21:13 --> Final output sent to browser
DEBUG - 2016-09-19 10:21:13 --> Total execution time: 1.1387
INFO - 2016-09-19 10:21:14 --> Config Class Initialized
INFO - 2016-09-19 10:21:14 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:21:14 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:21:14 --> Utf8 Class Initialized
INFO - 2016-09-19 10:21:14 --> URI Class Initialized
INFO - 2016-09-19 10:21:14 --> Router Class Initialized
INFO - 2016-09-19 10:21:15 --> Output Class Initialized
INFO - 2016-09-19 10:21:15 --> Security Class Initialized
DEBUG - 2016-09-19 10:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:21:15 --> Input Class Initialized
INFO - 2016-09-19 10:21:15 --> Language Class Initialized
INFO - 2016-09-19 10:21:15 --> Language Class Initialized
INFO - 2016-09-19 10:21:15 --> Config Class Initialized
INFO - 2016-09-19 10:21:15 --> Loader Class Initialized
INFO - 2016-09-19 10:21:15 --> Helper loaded: url_helper
INFO - 2016-09-19 10:21:15 --> Database Driver Class Initialized
INFO - 2016-09-19 10:21:15 --> Controller Class Initialized
DEBUG - 2016-09-19 10:21:15 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:21:15 --> Model Class Initialized
INFO - 2016-09-19 10:21:15 --> Model Class Initialized
INFO - 2016-09-19 10:21:15 --> Database Driver Class Initialized
INFO - 2016-09-19 10:21:15 --> Final output sent to browser
DEBUG - 2016-09-19 10:21:15 --> Total execution time: 0.7947
INFO - 2016-09-19 10:21:17 --> Config Class Initialized
INFO - 2016-09-19 10:21:17 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:21:17 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:21:17 --> Utf8 Class Initialized
INFO - 2016-09-19 10:21:17 --> URI Class Initialized
INFO - 2016-09-19 10:21:17 --> Router Class Initialized
INFO - 2016-09-19 10:21:17 --> Output Class Initialized
INFO - 2016-09-19 10:21:17 --> Security Class Initialized
DEBUG - 2016-09-19 10:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:21:17 --> Input Class Initialized
INFO - 2016-09-19 10:21:17 --> Language Class Initialized
INFO - 2016-09-19 10:21:17 --> Language Class Initialized
INFO - 2016-09-19 10:21:17 --> Config Class Initialized
INFO - 2016-09-19 10:21:17 --> Loader Class Initialized
INFO - 2016-09-19 10:21:17 --> Helper loaded: url_helper
INFO - 2016-09-19 10:21:17 --> Database Driver Class Initialized
INFO - 2016-09-19 10:21:17 --> Controller Class Initialized
DEBUG - 2016-09-19 10:21:17 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:21:17 --> Model Class Initialized
INFO - 2016-09-19 10:21:17 --> Model Class Initialized
INFO - 2016-09-19 10:21:17 --> Database Driver Class Initialized
INFO - 2016-09-19 10:21:17 --> Database Driver Class Initialized
INFO - 2016-09-19 10:21:18 --> Database Driver Class Initialized
INFO - 2016-09-19 10:21:18 --> Database Driver Class Initialized
INFO - 2016-09-19 10:21:18 --> Database Driver Class Initialized
INFO - 2016-09-19 10:21:18 --> Final output sent to browser
DEBUG - 2016-09-19 10:21:18 --> Total execution time: 1.2703
INFO - 2016-09-19 10:21:19 --> Config Class Initialized
INFO - 2016-09-19 10:21:19 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:21:19 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:21:19 --> Utf8 Class Initialized
INFO - 2016-09-19 10:21:19 --> URI Class Initialized
INFO - 2016-09-19 10:21:19 --> Router Class Initialized
INFO - 2016-09-19 10:21:19 --> Output Class Initialized
INFO - 2016-09-19 10:21:19 --> Security Class Initialized
DEBUG - 2016-09-19 10:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:21:19 --> Input Class Initialized
INFO - 2016-09-19 10:21:19 --> Language Class Initialized
INFO - 2016-09-19 10:21:19 --> Language Class Initialized
INFO - 2016-09-19 10:21:19 --> Config Class Initialized
INFO - 2016-09-19 10:21:19 --> Loader Class Initialized
INFO - 2016-09-19 10:21:19 --> Helper loaded: url_helper
INFO - 2016-09-19 10:21:19 --> Database Driver Class Initialized
INFO - 2016-09-19 10:21:19 --> Controller Class Initialized
DEBUG - 2016-09-19 10:21:19 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:21:19 --> Model Class Initialized
INFO - 2016-09-19 10:21:19 --> Model Class Initialized
INFO - 2016-09-19 10:21:19 --> Database Driver Class Initialized
INFO - 2016-09-19 10:21:20 --> Final output sent to browser
DEBUG - 2016-09-19 10:21:20 --> Total execution time: 0.8876
INFO - 2016-09-19 10:21:21 --> Config Class Initialized
INFO - 2016-09-19 10:21:21 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:21:21 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:21:21 --> Utf8 Class Initialized
INFO - 2016-09-19 10:21:21 --> URI Class Initialized
INFO - 2016-09-19 10:21:22 --> Router Class Initialized
INFO - 2016-09-19 10:21:22 --> Output Class Initialized
INFO - 2016-09-19 10:21:22 --> Security Class Initialized
DEBUG - 2016-09-19 10:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:21:22 --> Input Class Initialized
INFO - 2016-09-19 10:21:22 --> Language Class Initialized
INFO - 2016-09-19 10:21:22 --> Language Class Initialized
INFO - 2016-09-19 10:21:22 --> Config Class Initialized
INFO - 2016-09-19 10:21:22 --> Loader Class Initialized
INFO - 2016-09-19 10:21:22 --> Helper loaded: url_helper
INFO - 2016-09-19 10:21:22 --> Database Driver Class Initialized
INFO - 2016-09-19 10:21:22 --> Controller Class Initialized
DEBUG - 2016-09-19 10:21:22 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:21:22 --> Model Class Initialized
INFO - 2016-09-19 10:21:22 --> Model Class Initialized
INFO - 2016-09-19 10:21:22 --> Database Driver Class Initialized
INFO - 2016-09-19 10:21:22 --> Database Driver Class Initialized
INFO - 2016-09-19 10:21:22 --> Database Driver Class Initialized
INFO - 2016-09-19 10:21:23 --> Database Driver Class Initialized
INFO - 2016-09-19 10:21:23 --> Database Driver Class Initialized
INFO - 2016-09-19 10:21:23 --> Final output sent to browser
DEBUG - 2016-09-19 10:21:23 --> Total execution time: 1.6206
INFO - 2016-09-19 10:21:25 --> Config Class Initialized
INFO - 2016-09-19 10:21:25 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:21:25 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:21:25 --> Utf8 Class Initialized
INFO - 2016-09-19 10:21:25 --> URI Class Initialized
INFO - 2016-09-19 10:21:25 --> Router Class Initialized
INFO - 2016-09-19 10:21:25 --> Output Class Initialized
INFO - 2016-09-19 10:21:25 --> Security Class Initialized
DEBUG - 2016-09-19 10:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:21:26 --> Input Class Initialized
INFO - 2016-09-19 10:21:26 --> Language Class Initialized
INFO - 2016-09-19 10:21:26 --> Language Class Initialized
INFO - 2016-09-19 10:21:26 --> Config Class Initialized
INFO - 2016-09-19 10:21:26 --> Loader Class Initialized
INFO - 2016-09-19 10:21:26 --> Helper loaded: url_helper
INFO - 2016-09-19 10:21:26 --> Database Driver Class Initialized
INFO - 2016-09-19 10:21:26 --> Controller Class Initialized
DEBUG - 2016-09-19 10:21:26 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:21:26 --> Model Class Initialized
INFO - 2016-09-19 10:21:26 --> Model Class Initialized
INFO - 2016-09-19 10:21:26 --> Final output sent to browser
DEBUG - 2016-09-19 10:21:26 --> Total execution time: 0.8408
INFO - 2016-09-19 10:22:18 --> Config Class Initialized
INFO - 2016-09-19 10:22:18 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:22:18 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:22:18 --> Utf8 Class Initialized
INFO - 2016-09-19 10:22:18 --> URI Class Initialized
INFO - 2016-09-19 10:22:18 --> Router Class Initialized
INFO - 2016-09-19 10:22:18 --> Output Class Initialized
INFO - 2016-09-19 10:22:18 --> Security Class Initialized
DEBUG - 2016-09-19 10:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:22:18 --> Input Class Initialized
INFO - 2016-09-19 10:22:18 --> Language Class Initialized
INFO - 2016-09-19 10:22:18 --> Language Class Initialized
INFO - 2016-09-19 10:22:18 --> Config Class Initialized
INFO - 2016-09-19 10:22:18 --> Loader Class Initialized
INFO - 2016-09-19 10:22:18 --> Helper loaded: url_helper
INFO - 2016-09-19 10:22:19 --> Database Driver Class Initialized
INFO - 2016-09-19 10:22:19 --> Controller Class Initialized
DEBUG - 2016-09-19 10:22:19 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:22:19 --> Model Class Initialized
INFO - 2016-09-19 10:22:19 --> Model Class Initialized
INFO - 2016-09-19 10:22:19 --> Database Driver Class Initialized
INFO - 2016-09-19 10:22:19 --> Final output sent to browser
DEBUG - 2016-09-19 10:22:19 --> Total execution time: 0.9222
INFO - 2016-09-19 10:22:22 --> Config Class Initialized
INFO - 2016-09-19 10:22:22 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:22:22 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:22:22 --> Utf8 Class Initialized
INFO - 2016-09-19 10:22:22 --> URI Class Initialized
INFO - 2016-09-19 10:22:22 --> Router Class Initialized
INFO - 2016-09-19 10:22:22 --> Output Class Initialized
INFO - 2016-09-19 10:22:22 --> Security Class Initialized
DEBUG - 2016-09-19 10:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:22:22 --> Input Class Initialized
INFO - 2016-09-19 10:22:22 --> Language Class Initialized
INFO - 2016-09-19 10:22:22 --> Language Class Initialized
INFO - 2016-09-19 10:22:22 --> Config Class Initialized
INFO - 2016-09-19 10:22:22 --> Loader Class Initialized
INFO - 2016-09-19 10:22:22 --> Helper loaded: url_helper
INFO - 2016-09-19 10:22:22 --> Database Driver Class Initialized
INFO - 2016-09-19 10:22:22 --> Controller Class Initialized
DEBUG - 2016-09-19 10:22:22 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:22:22 --> Model Class Initialized
INFO - 2016-09-19 10:22:23 --> Model Class Initialized
INFO - 2016-09-19 10:22:23 --> Database Driver Class Initialized
INFO - 2016-09-19 10:22:23 --> Database Driver Class Initialized
INFO - 2016-09-19 10:22:23 --> Database Driver Class Initialized
INFO - 2016-09-19 10:22:23 --> Database Driver Class Initialized
INFO - 2016-09-19 10:22:23 --> Database Driver Class Initialized
INFO - 2016-09-19 10:22:23 --> Final output sent to browser
DEBUG - 2016-09-19 10:22:23 --> Total execution time: 1.1613
INFO - 2016-09-19 10:22:24 --> Config Class Initialized
INFO - 2016-09-19 10:22:24 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:22:24 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:22:24 --> Utf8 Class Initialized
INFO - 2016-09-19 10:22:24 --> URI Class Initialized
INFO - 2016-09-19 10:22:24 --> Router Class Initialized
INFO - 2016-09-19 10:22:25 --> Output Class Initialized
INFO - 2016-09-19 10:22:25 --> Security Class Initialized
DEBUG - 2016-09-19 10:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:22:25 --> Input Class Initialized
INFO - 2016-09-19 10:22:25 --> Language Class Initialized
INFO - 2016-09-19 10:22:25 --> Language Class Initialized
INFO - 2016-09-19 10:22:25 --> Config Class Initialized
INFO - 2016-09-19 10:22:25 --> Loader Class Initialized
INFO - 2016-09-19 10:22:25 --> Helper loaded: url_helper
INFO - 2016-09-19 10:22:25 --> Database Driver Class Initialized
INFO - 2016-09-19 10:22:25 --> Controller Class Initialized
DEBUG - 2016-09-19 10:22:25 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:22:25 --> Model Class Initialized
INFO - 2016-09-19 10:22:25 --> Model Class Initialized
INFO - 2016-09-19 10:22:25 --> Database Driver Class Initialized
INFO - 2016-09-19 10:22:25 --> Final output sent to browser
DEBUG - 2016-09-19 10:22:25 --> Total execution time: 0.8084
INFO - 2016-09-19 10:22:26 --> Config Class Initialized
INFO - 2016-09-19 10:22:26 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:22:26 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:22:26 --> Utf8 Class Initialized
INFO - 2016-09-19 10:22:26 --> URI Class Initialized
INFO - 2016-09-19 10:22:26 --> Router Class Initialized
INFO - 2016-09-19 10:22:26 --> Output Class Initialized
INFO - 2016-09-19 10:22:26 --> Security Class Initialized
DEBUG - 2016-09-19 10:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:22:26 --> Input Class Initialized
INFO - 2016-09-19 10:22:26 --> Language Class Initialized
INFO - 2016-09-19 10:22:26 --> Language Class Initialized
INFO - 2016-09-19 10:22:26 --> Config Class Initialized
INFO - 2016-09-19 10:22:27 --> Loader Class Initialized
INFO - 2016-09-19 10:22:27 --> Helper loaded: url_helper
INFO - 2016-09-19 10:22:27 --> Database Driver Class Initialized
INFO - 2016-09-19 10:22:27 --> Controller Class Initialized
DEBUG - 2016-09-19 10:22:27 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:22:27 --> Model Class Initialized
INFO - 2016-09-19 10:22:27 --> Model Class Initialized
INFO - 2016-09-19 10:22:27 --> Database Driver Class Initialized
INFO - 2016-09-19 10:22:27 --> Database Driver Class Initialized
INFO - 2016-09-19 10:22:27 --> Database Driver Class Initialized
INFO - 2016-09-19 10:22:27 --> Database Driver Class Initialized
INFO - 2016-09-19 10:22:27 --> Database Driver Class Initialized
INFO - 2016-09-19 10:22:27 --> Final output sent to browser
DEBUG - 2016-09-19 10:22:27 --> Total execution time: 1.2379
INFO - 2016-09-19 10:22:28 --> Config Class Initialized
INFO - 2016-09-19 10:22:28 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:22:28 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:22:28 --> Utf8 Class Initialized
INFO - 2016-09-19 10:22:28 --> URI Class Initialized
INFO - 2016-09-19 10:22:28 --> Router Class Initialized
INFO - 2016-09-19 10:22:28 --> Output Class Initialized
INFO - 2016-09-19 10:22:28 --> Security Class Initialized
DEBUG - 2016-09-19 10:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:22:28 --> Input Class Initialized
INFO - 2016-09-19 10:22:28 --> Language Class Initialized
INFO - 2016-09-19 10:22:28 --> Language Class Initialized
INFO - 2016-09-19 10:22:28 --> Config Class Initialized
INFO - 2016-09-19 10:22:29 --> Loader Class Initialized
INFO - 2016-09-19 10:22:29 --> Helper loaded: url_helper
INFO - 2016-09-19 10:22:29 --> Database Driver Class Initialized
INFO - 2016-09-19 10:22:29 --> Controller Class Initialized
DEBUG - 2016-09-19 10:22:29 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:22:29 --> Model Class Initialized
INFO - 2016-09-19 10:22:29 --> Model Class Initialized
INFO - 2016-09-19 10:22:29 --> Database Driver Class Initialized
INFO - 2016-09-19 10:22:29 --> Final output sent to browser
DEBUG - 2016-09-19 10:22:29 --> Total execution time: 0.8079
INFO - 2016-09-19 10:22:30 --> Config Class Initialized
INFO - 2016-09-19 10:22:30 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:22:30 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:22:30 --> Utf8 Class Initialized
INFO - 2016-09-19 10:22:30 --> URI Class Initialized
INFO - 2016-09-19 10:22:30 --> Router Class Initialized
INFO - 2016-09-19 10:22:30 --> Output Class Initialized
INFO - 2016-09-19 10:22:30 --> Security Class Initialized
DEBUG - 2016-09-19 10:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:22:30 --> Input Class Initialized
INFO - 2016-09-19 10:22:30 --> Language Class Initialized
INFO - 2016-09-19 10:22:30 --> Language Class Initialized
INFO - 2016-09-19 10:22:30 --> Config Class Initialized
INFO - 2016-09-19 10:22:30 --> Loader Class Initialized
INFO - 2016-09-19 10:22:30 --> Helper loaded: url_helper
INFO - 2016-09-19 10:22:30 --> Database Driver Class Initialized
INFO - 2016-09-19 10:22:30 --> Controller Class Initialized
DEBUG - 2016-09-19 10:22:30 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:22:31 --> Model Class Initialized
INFO - 2016-09-19 10:22:31 --> Model Class Initialized
INFO - 2016-09-19 10:22:31 --> Database Driver Class Initialized
INFO - 2016-09-19 10:22:31 --> Database Driver Class Initialized
INFO - 2016-09-19 10:22:31 --> Database Driver Class Initialized
INFO - 2016-09-19 10:22:31 --> Database Driver Class Initialized
INFO - 2016-09-19 10:22:31 --> Database Driver Class Initialized
INFO - 2016-09-19 10:22:31 --> Final output sent to browser
DEBUG - 2016-09-19 10:22:31 --> Total execution time: 1.2016
INFO - 2016-09-19 10:22:33 --> Config Class Initialized
INFO - 2016-09-19 10:22:33 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:22:33 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:22:33 --> Utf8 Class Initialized
INFO - 2016-09-19 10:22:33 --> URI Class Initialized
INFO - 2016-09-19 10:22:33 --> Router Class Initialized
INFO - 2016-09-19 10:22:33 --> Output Class Initialized
INFO - 2016-09-19 10:22:33 --> Security Class Initialized
DEBUG - 2016-09-19 10:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:22:33 --> Input Class Initialized
INFO - 2016-09-19 10:22:33 --> Language Class Initialized
INFO - 2016-09-19 10:22:33 --> Language Class Initialized
INFO - 2016-09-19 10:22:33 --> Config Class Initialized
INFO - 2016-09-19 10:22:33 --> Loader Class Initialized
INFO - 2016-09-19 10:22:33 --> Helper loaded: url_helper
INFO - 2016-09-19 10:22:34 --> Database Driver Class Initialized
INFO - 2016-09-19 10:22:34 --> Controller Class Initialized
DEBUG - 2016-09-19 10:22:34 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:22:34 --> Model Class Initialized
INFO - 2016-09-19 10:22:34 --> Model Class Initialized
INFO - 2016-09-19 10:22:34 --> Database Driver Class Initialized
INFO - 2016-09-19 10:22:34 --> Final output sent to browser
DEBUG - 2016-09-19 10:22:34 --> Total execution time: 0.9116
INFO - 2016-09-19 10:22:38 --> Config Class Initialized
INFO - 2016-09-19 10:22:38 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:22:38 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:22:38 --> Utf8 Class Initialized
INFO - 2016-09-19 10:22:38 --> URI Class Initialized
INFO - 2016-09-19 10:22:38 --> Router Class Initialized
INFO - 2016-09-19 10:22:38 --> Output Class Initialized
INFO - 2016-09-19 10:22:38 --> Security Class Initialized
DEBUG - 2016-09-19 10:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:22:38 --> Input Class Initialized
INFO - 2016-09-19 10:22:38 --> Language Class Initialized
INFO - 2016-09-19 10:22:38 --> Language Class Initialized
INFO - 2016-09-19 10:22:38 --> Config Class Initialized
INFO - 2016-09-19 10:22:38 --> Loader Class Initialized
INFO - 2016-09-19 10:22:38 --> Helper loaded: url_helper
INFO - 2016-09-19 10:22:38 --> Database Driver Class Initialized
INFO - 2016-09-19 10:22:38 --> Controller Class Initialized
DEBUG - 2016-09-19 10:22:38 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:22:38 --> Model Class Initialized
INFO - 2016-09-19 10:22:38 --> Model Class Initialized
INFO - 2016-09-19 10:22:38 --> Database Driver Class Initialized
INFO - 2016-09-19 10:22:39 --> Database Driver Class Initialized
INFO - 2016-09-19 10:22:39 --> Database Driver Class Initialized
INFO - 2016-09-19 10:22:39 --> Database Driver Class Initialized
INFO - 2016-09-19 10:22:39 --> Database Driver Class Initialized
INFO - 2016-09-19 10:22:39 --> Final output sent to browser
DEBUG - 2016-09-19 10:22:39 --> Total execution time: 1.2604
INFO - 2016-09-19 10:22:41 --> Config Class Initialized
INFO - 2016-09-19 10:22:41 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:22:41 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:22:41 --> Utf8 Class Initialized
INFO - 2016-09-19 10:22:41 --> URI Class Initialized
INFO - 2016-09-19 10:22:41 --> Router Class Initialized
INFO - 2016-09-19 10:22:41 --> Output Class Initialized
INFO - 2016-09-19 10:22:41 --> Security Class Initialized
DEBUG - 2016-09-19 10:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:22:41 --> Input Class Initialized
INFO - 2016-09-19 10:22:41 --> Language Class Initialized
INFO - 2016-09-19 10:22:41 --> Language Class Initialized
INFO - 2016-09-19 10:22:41 --> Config Class Initialized
INFO - 2016-09-19 10:22:41 --> Loader Class Initialized
INFO - 2016-09-19 10:22:41 --> Helper loaded: url_helper
INFO - 2016-09-19 10:22:42 --> Database Driver Class Initialized
INFO - 2016-09-19 10:22:42 --> Controller Class Initialized
DEBUG - 2016-09-19 10:22:42 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:22:42 --> Model Class Initialized
INFO - 2016-09-19 10:22:42 --> Model Class Initialized
INFO - 2016-09-19 10:22:42 --> Final output sent to browser
DEBUG - 2016-09-19 10:22:42 --> Total execution time: 0.7691
INFO - 2016-09-19 10:22:46 --> Config Class Initialized
INFO - 2016-09-19 10:22:46 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:22:46 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:22:46 --> Utf8 Class Initialized
INFO - 2016-09-19 10:22:46 --> URI Class Initialized
INFO - 2016-09-19 10:22:46 --> Router Class Initialized
INFO - 2016-09-19 10:22:46 --> Output Class Initialized
INFO - 2016-09-19 10:22:46 --> Security Class Initialized
DEBUG - 2016-09-19 10:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:22:46 --> Input Class Initialized
INFO - 2016-09-19 10:22:46 --> Language Class Initialized
INFO - 2016-09-19 10:22:46 --> Language Class Initialized
INFO - 2016-09-19 10:22:46 --> Config Class Initialized
INFO - 2016-09-19 10:22:46 --> Loader Class Initialized
INFO - 2016-09-19 10:22:46 --> Helper loaded: url_helper
INFO - 2016-09-19 10:22:46 --> Database Driver Class Initialized
INFO - 2016-09-19 10:22:46 --> Controller Class Initialized
DEBUG - 2016-09-19 10:22:46 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:22:46 --> Model Class Initialized
INFO - 2016-09-19 10:22:46 --> Model Class Initialized
DEBUG - 2016-09-19 10:22:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 10:22:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 10:22:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 10:22:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 10:22:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 10:22:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 10:22:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 10:22:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 10:22:47 --> Final output sent to browser
DEBUG - 2016-09-19 10:22:47 --> Total execution time: 1.1542
INFO - 2016-09-19 10:22:51 --> Config Class Initialized
INFO - 2016-09-19 10:22:51 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:22:51 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:22:51 --> Utf8 Class Initialized
INFO - 2016-09-19 10:22:51 --> URI Class Initialized
INFO - 2016-09-19 10:22:51 --> Router Class Initialized
INFO - 2016-09-19 10:22:52 --> Output Class Initialized
INFO - 2016-09-19 10:22:52 --> Security Class Initialized
DEBUG - 2016-09-19 10:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:22:52 --> Input Class Initialized
INFO - 2016-09-19 10:22:52 --> Language Class Initialized
INFO - 2016-09-19 10:22:52 --> Language Class Initialized
INFO - 2016-09-19 10:22:52 --> Config Class Initialized
INFO - 2016-09-19 10:22:52 --> Loader Class Initialized
INFO - 2016-09-19 10:22:52 --> Helper loaded: url_helper
INFO - 2016-09-19 10:22:52 --> Database Driver Class Initialized
INFO - 2016-09-19 10:22:52 --> Controller Class Initialized
DEBUG - 2016-09-19 10:22:52 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:22:52 --> Model Class Initialized
INFO - 2016-09-19 10:22:52 --> Model Class Initialized
DEBUG - 2016-09-19 10:22:52 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 10:22:52 --> Database Driver Class Initialized
INFO - 2016-09-19 10:22:52 --> Final output sent to browser
DEBUG - 2016-09-19 10:22:52 --> Total execution time: 0.9180
INFO - 2016-09-19 10:22:54 --> Config Class Initialized
INFO - 2016-09-19 10:22:54 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:22:54 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:22:54 --> Utf8 Class Initialized
INFO - 2016-09-19 10:22:54 --> URI Class Initialized
INFO - 2016-09-19 10:22:54 --> Router Class Initialized
INFO - 2016-09-19 10:22:54 --> Output Class Initialized
INFO - 2016-09-19 10:22:55 --> Security Class Initialized
DEBUG - 2016-09-19 10:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:22:55 --> Input Class Initialized
INFO - 2016-09-19 10:22:55 --> Language Class Initialized
INFO - 2016-09-19 10:22:55 --> Language Class Initialized
INFO - 2016-09-19 10:22:55 --> Config Class Initialized
INFO - 2016-09-19 10:22:55 --> Loader Class Initialized
INFO - 2016-09-19 10:22:55 --> Helper loaded: url_helper
INFO - 2016-09-19 10:22:55 --> Database Driver Class Initialized
INFO - 2016-09-19 10:22:55 --> Controller Class Initialized
DEBUG - 2016-09-19 10:22:55 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:22:55 --> Model Class Initialized
INFO - 2016-09-19 10:22:55 --> Model Class Initialized
DEBUG - 2016-09-19 10:22:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 10:22:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 10:22:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 10:22:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_umum.php
DEBUG - 2016-09-19 10:22:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 10:22:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 10:22:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 10:22:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 10:22:55 --> Final output sent to browser
DEBUG - 2016-09-19 10:22:56 --> Total execution time: 1.3065
INFO - 2016-09-19 10:23:09 --> Config Class Initialized
INFO - 2016-09-19 10:23:09 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:23:09 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:23:09 --> Utf8 Class Initialized
INFO - 2016-09-19 10:23:09 --> URI Class Initialized
INFO - 2016-09-19 10:23:09 --> Router Class Initialized
INFO - 2016-09-19 10:23:09 --> Output Class Initialized
INFO - 2016-09-19 10:23:09 --> Security Class Initialized
DEBUG - 2016-09-19 10:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:23:09 --> Input Class Initialized
INFO - 2016-09-19 10:23:09 --> Language Class Initialized
INFO - 2016-09-19 10:23:10 --> Language Class Initialized
INFO - 2016-09-19 10:23:10 --> Config Class Initialized
INFO - 2016-09-19 10:23:10 --> Loader Class Initialized
INFO - 2016-09-19 10:23:10 --> Helper loaded: url_helper
INFO - 2016-09-19 10:23:10 --> Database Driver Class Initialized
INFO - 2016-09-19 10:23:10 --> Controller Class Initialized
DEBUG - 2016-09-19 10:23:10 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:23:10 --> Model Class Initialized
INFO - 2016-09-19 10:23:10 --> Model Class Initialized
INFO - 2016-09-19 10:23:10 --> Database Driver Class Initialized
INFO - 2016-09-19 10:23:10 --> Final output sent to browser
DEBUG - 2016-09-19 10:23:10 --> Total execution time: 1.0306
INFO - 2016-09-19 10:23:16 --> Config Class Initialized
INFO - 2016-09-19 10:23:16 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:23:16 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:23:16 --> Utf8 Class Initialized
INFO - 2016-09-19 10:23:16 --> URI Class Initialized
INFO - 2016-09-19 10:23:16 --> Router Class Initialized
INFO - 2016-09-19 10:23:16 --> Output Class Initialized
INFO - 2016-09-19 10:23:16 --> Security Class Initialized
DEBUG - 2016-09-19 10:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:23:16 --> Input Class Initialized
INFO - 2016-09-19 10:23:16 --> Language Class Initialized
INFO - 2016-09-19 10:23:16 --> Language Class Initialized
INFO - 2016-09-19 10:23:16 --> Config Class Initialized
INFO - 2016-09-19 10:23:16 --> Loader Class Initialized
INFO - 2016-09-19 10:23:16 --> Helper loaded: url_helper
INFO - 2016-09-19 10:23:16 --> Database Driver Class Initialized
INFO - 2016-09-19 10:23:16 --> Controller Class Initialized
DEBUG - 2016-09-19 10:23:16 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:23:16 --> Model Class Initialized
INFO - 2016-09-19 10:23:16 --> Model Class Initialized
INFO - 2016-09-19 10:23:17 --> Database Driver Class Initialized
INFO - 2016-09-19 10:23:17 --> Final output sent to browser
DEBUG - 2016-09-19 10:23:17 --> Total execution time: 0.9912
INFO - 2016-09-19 10:23:23 --> Config Class Initialized
INFO - 2016-09-19 10:23:23 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:23:23 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:23:23 --> Utf8 Class Initialized
INFO - 2016-09-19 10:23:23 --> URI Class Initialized
INFO - 2016-09-19 10:23:23 --> Router Class Initialized
INFO - 2016-09-19 10:23:23 --> Output Class Initialized
INFO - 2016-09-19 10:23:23 --> Security Class Initialized
DEBUG - 2016-09-19 10:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:23:23 --> Input Class Initialized
INFO - 2016-09-19 10:23:23 --> Language Class Initialized
INFO - 2016-09-19 10:23:23 --> Language Class Initialized
INFO - 2016-09-19 10:23:23 --> Config Class Initialized
INFO - 2016-09-19 10:23:23 --> Loader Class Initialized
INFO - 2016-09-19 10:23:23 --> Helper loaded: url_helper
INFO - 2016-09-19 10:23:23 --> Database Driver Class Initialized
INFO - 2016-09-19 10:23:23 --> Controller Class Initialized
DEBUG - 2016-09-19 10:23:23 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:23:23 --> Model Class Initialized
INFO - 2016-09-19 10:23:23 --> Model Class Initialized
INFO - 2016-09-19 10:23:23 --> Database Driver Class Initialized
INFO - 2016-09-19 10:23:23 --> Database Driver Class Initialized
INFO - 2016-09-19 10:23:24 --> Final output sent to browser
DEBUG - 2016-09-19 10:23:24 --> Total execution time: 1.0645
INFO - 2016-09-19 10:23:28 --> Config Class Initialized
INFO - 2016-09-19 10:23:28 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:23:28 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:23:28 --> Utf8 Class Initialized
INFO - 2016-09-19 10:23:28 --> URI Class Initialized
INFO - 2016-09-19 10:23:28 --> Router Class Initialized
INFO - 2016-09-19 10:23:28 --> Output Class Initialized
INFO - 2016-09-19 10:23:28 --> Security Class Initialized
DEBUG - 2016-09-19 10:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:23:28 --> Input Class Initialized
INFO - 2016-09-19 10:23:28 --> Language Class Initialized
INFO - 2016-09-19 10:23:28 --> Language Class Initialized
INFO - 2016-09-19 10:23:28 --> Config Class Initialized
INFO - 2016-09-19 10:23:28 --> Loader Class Initialized
INFO - 2016-09-19 10:23:28 --> Helper loaded: url_helper
INFO - 2016-09-19 10:23:28 --> Database Driver Class Initialized
INFO - 2016-09-19 10:23:28 --> Controller Class Initialized
DEBUG - 2016-09-19 10:23:29 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:23:29 --> Model Class Initialized
INFO - 2016-09-19 10:23:29 --> Model Class Initialized
DEBUG - 2016-09-19 10:23:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 10:23:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 10:23:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 10:23:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_bayar_angsuran.php
DEBUG - 2016-09-19 10:23:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 10:23:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 10:23:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 10:23:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 10:23:29 --> Final output sent to browser
DEBUG - 2016-09-19 10:23:29 --> Total execution time: 1.1556
INFO - 2016-09-19 10:23:33 --> Config Class Initialized
INFO - 2016-09-19 10:23:33 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:23:33 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:23:33 --> Utf8 Class Initialized
INFO - 2016-09-19 10:23:33 --> URI Class Initialized
INFO - 2016-09-19 10:23:33 --> Router Class Initialized
INFO - 2016-09-19 10:23:33 --> Output Class Initialized
INFO - 2016-09-19 10:23:33 --> Security Class Initialized
DEBUG - 2016-09-19 10:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:23:33 --> Input Class Initialized
INFO - 2016-09-19 10:23:33 --> Language Class Initialized
INFO - 2016-09-19 10:23:33 --> Language Class Initialized
INFO - 2016-09-19 10:23:33 --> Config Class Initialized
INFO - 2016-09-19 10:23:33 --> Loader Class Initialized
INFO - 2016-09-19 10:23:33 --> Helper loaded: url_helper
INFO - 2016-09-19 10:23:33 --> Database Driver Class Initialized
INFO - 2016-09-19 10:23:33 --> Controller Class Initialized
DEBUG - 2016-09-19 10:23:33 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:23:33 --> Model Class Initialized
INFO - 2016-09-19 10:23:34 --> Model Class Initialized
INFO - 2016-09-19 10:23:34 --> Database Driver Class Initialized
INFO - 2016-09-19 10:23:34 --> Final output sent to browser
DEBUG - 2016-09-19 10:23:34 --> Total execution time: 0.9317
INFO - 2016-09-19 10:23:38 --> Config Class Initialized
INFO - 2016-09-19 10:23:38 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:23:38 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:23:39 --> Utf8 Class Initialized
INFO - 2016-09-19 10:23:39 --> URI Class Initialized
INFO - 2016-09-19 10:23:39 --> Router Class Initialized
INFO - 2016-09-19 10:23:39 --> Output Class Initialized
INFO - 2016-09-19 10:23:39 --> Security Class Initialized
DEBUG - 2016-09-19 10:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:23:39 --> Input Class Initialized
INFO - 2016-09-19 10:23:39 --> Language Class Initialized
INFO - 2016-09-19 10:23:39 --> Language Class Initialized
INFO - 2016-09-19 10:23:39 --> Config Class Initialized
INFO - 2016-09-19 10:23:39 --> Loader Class Initialized
INFO - 2016-09-19 10:23:39 --> Helper loaded: url_helper
INFO - 2016-09-19 10:23:39 --> Database Driver Class Initialized
INFO - 2016-09-19 10:23:39 --> Controller Class Initialized
DEBUG - 2016-09-19 10:23:39 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:23:39 --> Model Class Initialized
INFO - 2016-09-19 10:23:39 --> Model Class Initialized
INFO - 2016-09-19 10:23:39 --> Database Driver Class Initialized
INFO - 2016-09-19 10:23:39 --> Database Driver Class Initialized
INFO - 2016-09-19 10:23:39 --> Database Driver Class Initialized
INFO - 2016-09-19 10:23:39 --> Database Driver Class Initialized
INFO - 2016-09-19 10:23:39 --> Database Driver Class Initialized
INFO - 2016-09-19 10:23:40 --> Final output sent to browser
DEBUG - 2016-09-19 10:23:40 --> Total execution time: 1.1636
INFO - 2016-09-19 10:23:40 --> Config Class Initialized
INFO - 2016-09-19 10:23:40 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:23:40 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:23:40 --> Utf8 Class Initialized
INFO - 2016-09-19 10:23:40 --> URI Class Initialized
INFO - 2016-09-19 10:23:41 --> Router Class Initialized
INFO - 2016-09-19 10:23:41 --> Output Class Initialized
INFO - 2016-09-19 10:23:41 --> Security Class Initialized
DEBUG - 2016-09-19 10:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:23:41 --> Input Class Initialized
INFO - 2016-09-19 10:23:41 --> Language Class Initialized
INFO - 2016-09-19 10:23:41 --> Language Class Initialized
INFO - 2016-09-19 10:23:41 --> Config Class Initialized
INFO - 2016-09-19 10:23:41 --> Loader Class Initialized
INFO - 2016-09-19 10:23:41 --> Helper loaded: url_helper
INFO - 2016-09-19 10:23:41 --> Database Driver Class Initialized
INFO - 2016-09-19 10:23:41 --> Controller Class Initialized
DEBUG - 2016-09-19 10:23:41 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:23:41 --> Model Class Initialized
INFO - 2016-09-19 10:23:41 --> Model Class Initialized
INFO - 2016-09-19 10:23:41 --> Database Driver Class Initialized
INFO - 2016-09-19 10:23:41 --> Final output sent to browser
DEBUG - 2016-09-19 10:23:41 --> Total execution time: 0.9287
INFO - 2016-09-19 10:23:42 --> Config Class Initialized
INFO - 2016-09-19 10:23:43 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:23:43 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:23:43 --> Utf8 Class Initialized
INFO - 2016-09-19 10:23:43 --> URI Class Initialized
INFO - 2016-09-19 10:23:43 --> Router Class Initialized
INFO - 2016-09-19 10:23:43 --> Output Class Initialized
INFO - 2016-09-19 10:23:43 --> Security Class Initialized
DEBUG - 2016-09-19 10:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:23:43 --> Input Class Initialized
INFO - 2016-09-19 10:23:43 --> Language Class Initialized
INFO - 2016-09-19 10:23:43 --> Language Class Initialized
INFO - 2016-09-19 10:23:43 --> Config Class Initialized
INFO - 2016-09-19 10:23:43 --> Loader Class Initialized
INFO - 2016-09-19 10:23:43 --> Helper loaded: url_helper
INFO - 2016-09-19 10:23:43 --> Database Driver Class Initialized
INFO - 2016-09-19 10:23:43 --> Controller Class Initialized
DEBUG - 2016-09-19 10:23:43 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:23:43 --> Model Class Initialized
INFO - 2016-09-19 10:23:43 --> Model Class Initialized
INFO - 2016-09-19 10:23:43 --> Database Driver Class Initialized
INFO - 2016-09-19 10:23:43 --> Database Driver Class Initialized
INFO - 2016-09-19 10:23:44 --> Database Driver Class Initialized
INFO - 2016-09-19 10:23:44 --> Database Driver Class Initialized
INFO - 2016-09-19 10:23:44 --> Database Driver Class Initialized
INFO - 2016-09-19 10:23:44 --> Final output sent to browser
DEBUG - 2016-09-19 10:23:44 --> Total execution time: 1.3399
INFO - 2016-09-19 10:23:45 --> Config Class Initialized
INFO - 2016-09-19 10:23:45 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:23:45 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:23:45 --> Utf8 Class Initialized
INFO - 2016-09-19 10:23:45 --> URI Class Initialized
INFO - 2016-09-19 10:23:45 --> Router Class Initialized
INFO - 2016-09-19 10:23:45 --> Output Class Initialized
INFO - 2016-09-19 10:23:45 --> Security Class Initialized
DEBUG - 2016-09-19 10:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:23:45 --> Input Class Initialized
INFO - 2016-09-19 10:23:45 --> Language Class Initialized
INFO - 2016-09-19 10:23:45 --> Language Class Initialized
INFO - 2016-09-19 10:23:45 --> Config Class Initialized
INFO - 2016-09-19 10:23:45 --> Loader Class Initialized
INFO - 2016-09-19 10:23:45 --> Helper loaded: url_helper
INFO - 2016-09-19 10:23:45 --> Database Driver Class Initialized
INFO - 2016-09-19 10:23:45 --> Controller Class Initialized
DEBUG - 2016-09-19 10:23:45 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:23:45 --> Model Class Initialized
INFO - 2016-09-19 10:23:45 --> Model Class Initialized
INFO - 2016-09-19 10:23:45 --> Database Driver Class Initialized
INFO - 2016-09-19 10:23:45 --> Final output sent to browser
DEBUG - 2016-09-19 10:23:45 --> Total execution time: 0.8514
INFO - 2016-09-19 10:23:46 --> Config Class Initialized
INFO - 2016-09-19 10:23:46 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:23:46 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:23:46 --> Utf8 Class Initialized
INFO - 2016-09-19 10:23:46 --> URI Class Initialized
INFO - 2016-09-19 10:23:46 --> Router Class Initialized
INFO - 2016-09-19 10:23:46 --> Output Class Initialized
INFO - 2016-09-19 10:23:46 --> Security Class Initialized
DEBUG - 2016-09-19 10:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:23:47 --> Input Class Initialized
INFO - 2016-09-19 10:23:47 --> Language Class Initialized
INFO - 2016-09-19 10:23:47 --> Language Class Initialized
INFO - 2016-09-19 10:23:47 --> Config Class Initialized
INFO - 2016-09-19 10:23:47 --> Loader Class Initialized
INFO - 2016-09-19 10:23:47 --> Helper loaded: url_helper
INFO - 2016-09-19 10:23:47 --> Database Driver Class Initialized
INFO - 2016-09-19 10:23:47 --> Controller Class Initialized
DEBUG - 2016-09-19 10:23:47 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:23:47 --> Model Class Initialized
INFO - 2016-09-19 10:23:47 --> Model Class Initialized
INFO - 2016-09-19 10:23:47 --> Database Driver Class Initialized
INFO - 2016-09-19 10:23:47 --> Database Driver Class Initialized
INFO - 2016-09-19 10:23:47 --> Database Driver Class Initialized
INFO - 2016-09-19 10:23:47 --> Database Driver Class Initialized
INFO - 2016-09-19 10:23:47 --> Database Driver Class Initialized
INFO - 2016-09-19 10:23:47 --> Final output sent to browser
DEBUG - 2016-09-19 10:23:47 --> Total execution time: 1.2455
INFO - 2016-09-19 10:23:48 --> Config Class Initialized
INFO - 2016-09-19 10:23:48 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:23:48 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:23:49 --> Utf8 Class Initialized
INFO - 2016-09-19 10:23:49 --> URI Class Initialized
INFO - 2016-09-19 10:23:49 --> Router Class Initialized
INFO - 2016-09-19 10:23:49 --> Output Class Initialized
INFO - 2016-09-19 10:23:49 --> Security Class Initialized
DEBUG - 2016-09-19 10:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:23:49 --> Input Class Initialized
INFO - 2016-09-19 10:23:49 --> Language Class Initialized
INFO - 2016-09-19 10:23:49 --> Language Class Initialized
INFO - 2016-09-19 10:23:49 --> Config Class Initialized
INFO - 2016-09-19 10:23:49 --> Loader Class Initialized
INFO - 2016-09-19 10:23:49 --> Helper loaded: url_helper
INFO - 2016-09-19 10:23:49 --> Database Driver Class Initialized
INFO - 2016-09-19 10:23:49 --> Controller Class Initialized
DEBUG - 2016-09-19 10:23:49 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:23:49 --> Model Class Initialized
INFO - 2016-09-19 10:23:49 --> Model Class Initialized
INFO - 2016-09-19 10:23:49 --> Database Driver Class Initialized
INFO - 2016-09-19 10:23:49 --> Final output sent to browser
DEBUG - 2016-09-19 10:23:49 --> Total execution time: 1.0616
INFO - 2016-09-19 10:23:51 --> Config Class Initialized
INFO - 2016-09-19 10:23:51 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:23:51 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:23:51 --> Utf8 Class Initialized
INFO - 2016-09-19 10:23:51 --> URI Class Initialized
INFO - 2016-09-19 10:23:51 --> Router Class Initialized
INFO - 2016-09-19 10:23:51 --> Output Class Initialized
INFO - 2016-09-19 10:23:51 --> Security Class Initialized
DEBUG - 2016-09-19 10:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:23:51 --> Input Class Initialized
INFO - 2016-09-19 10:23:51 --> Language Class Initialized
INFO - 2016-09-19 10:23:51 --> Language Class Initialized
INFO - 2016-09-19 10:23:51 --> Config Class Initialized
INFO - 2016-09-19 10:23:51 --> Loader Class Initialized
INFO - 2016-09-19 10:23:51 --> Helper loaded: url_helper
INFO - 2016-09-19 10:23:51 --> Database Driver Class Initialized
INFO - 2016-09-19 10:23:51 --> Controller Class Initialized
DEBUG - 2016-09-19 10:23:51 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:23:51 --> Model Class Initialized
INFO - 2016-09-19 10:23:51 --> Model Class Initialized
INFO - 2016-09-19 10:23:51 --> Database Driver Class Initialized
INFO - 2016-09-19 10:23:52 --> Database Driver Class Initialized
INFO - 2016-09-19 10:23:52 --> Database Driver Class Initialized
INFO - 2016-09-19 10:23:52 --> Database Driver Class Initialized
INFO - 2016-09-19 10:23:52 --> Database Driver Class Initialized
INFO - 2016-09-19 10:23:52 --> Final output sent to browser
DEBUG - 2016-09-19 10:23:52 --> Total execution time: 1.3444
INFO - 2016-09-19 10:23:53 --> Config Class Initialized
INFO - 2016-09-19 10:23:53 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:23:53 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:23:53 --> Utf8 Class Initialized
INFO - 2016-09-19 10:23:53 --> URI Class Initialized
INFO - 2016-09-19 10:23:53 --> Router Class Initialized
INFO - 2016-09-19 10:23:53 --> Output Class Initialized
INFO - 2016-09-19 10:23:53 --> Security Class Initialized
DEBUG - 2016-09-19 10:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:23:53 --> Input Class Initialized
INFO - 2016-09-19 10:23:53 --> Language Class Initialized
INFO - 2016-09-19 10:23:54 --> Language Class Initialized
INFO - 2016-09-19 10:23:54 --> Config Class Initialized
INFO - 2016-09-19 10:23:54 --> Loader Class Initialized
INFO - 2016-09-19 10:23:54 --> Helper loaded: url_helper
INFO - 2016-09-19 10:23:54 --> Database Driver Class Initialized
INFO - 2016-09-19 10:23:54 --> Controller Class Initialized
DEBUG - 2016-09-19 10:23:54 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:23:54 --> Model Class Initialized
INFO - 2016-09-19 10:23:54 --> Model Class Initialized
INFO - 2016-09-19 10:23:54 --> Database Driver Class Initialized
INFO - 2016-09-19 10:23:54 --> Final output sent to browser
DEBUG - 2016-09-19 10:23:54 --> Total execution time: 1.0670
INFO - 2016-09-19 10:23:55 --> Config Class Initialized
INFO - 2016-09-19 10:23:55 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:23:55 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:23:55 --> Utf8 Class Initialized
INFO - 2016-09-19 10:23:55 --> URI Class Initialized
INFO - 2016-09-19 10:23:55 --> Router Class Initialized
INFO - 2016-09-19 10:23:55 --> Output Class Initialized
INFO - 2016-09-19 10:23:55 --> Security Class Initialized
DEBUG - 2016-09-19 10:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:23:55 --> Input Class Initialized
INFO - 2016-09-19 10:23:55 --> Language Class Initialized
INFO - 2016-09-19 10:23:55 --> Language Class Initialized
INFO - 2016-09-19 10:23:55 --> Config Class Initialized
INFO - 2016-09-19 10:23:55 --> Loader Class Initialized
INFO - 2016-09-19 10:23:55 --> Helper loaded: url_helper
INFO - 2016-09-19 10:23:55 --> Database Driver Class Initialized
INFO - 2016-09-19 10:23:55 --> Controller Class Initialized
DEBUG - 2016-09-19 10:23:55 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:23:55 --> Model Class Initialized
INFO - 2016-09-19 10:23:56 --> Model Class Initialized
INFO - 2016-09-19 10:23:56 --> Database Driver Class Initialized
INFO - 2016-09-19 10:23:56 --> Database Driver Class Initialized
INFO - 2016-09-19 10:23:56 --> Database Driver Class Initialized
INFO - 2016-09-19 10:23:56 --> Database Driver Class Initialized
INFO - 2016-09-19 10:23:56 --> Database Driver Class Initialized
INFO - 2016-09-19 10:23:56 --> Final output sent to browser
DEBUG - 2016-09-19 10:23:56 --> Total execution time: 1.1852
INFO - 2016-09-19 10:23:57 --> Config Class Initialized
INFO - 2016-09-19 10:23:57 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:23:57 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:23:57 --> Utf8 Class Initialized
INFO - 2016-09-19 10:23:57 --> URI Class Initialized
INFO - 2016-09-19 10:23:57 --> Router Class Initialized
INFO - 2016-09-19 10:23:57 --> Output Class Initialized
INFO - 2016-09-19 10:23:57 --> Security Class Initialized
DEBUG - 2016-09-19 10:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:23:57 --> Input Class Initialized
INFO - 2016-09-19 10:23:57 --> Language Class Initialized
INFO - 2016-09-19 10:23:57 --> Language Class Initialized
INFO - 2016-09-19 10:23:57 --> Config Class Initialized
INFO - 2016-09-19 10:23:57 --> Loader Class Initialized
INFO - 2016-09-19 10:23:57 --> Helper loaded: url_helper
INFO - 2016-09-19 10:23:57 --> Database Driver Class Initialized
INFO - 2016-09-19 10:23:57 --> Controller Class Initialized
DEBUG - 2016-09-19 10:23:58 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:23:58 --> Model Class Initialized
INFO - 2016-09-19 10:23:58 --> Model Class Initialized
INFO - 2016-09-19 10:23:58 --> Database Driver Class Initialized
INFO - 2016-09-19 10:23:58 --> Final output sent to browser
DEBUG - 2016-09-19 10:23:58 --> Total execution time: 0.8330
INFO - 2016-09-19 10:23:59 --> Config Class Initialized
INFO - 2016-09-19 10:23:59 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:23:59 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:23:59 --> Utf8 Class Initialized
INFO - 2016-09-19 10:23:59 --> URI Class Initialized
INFO - 2016-09-19 10:23:59 --> Router Class Initialized
INFO - 2016-09-19 10:23:59 --> Output Class Initialized
INFO - 2016-09-19 10:23:59 --> Security Class Initialized
DEBUG - 2016-09-19 10:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:23:59 --> Input Class Initialized
INFO - 2016-09-19 10:23:59 --> Language Class Initialized
INFO - 2016-09-19 10:23:59 --> Language Class Initialized
INFO - 2016-09-19 10:23:59 --> Config Class Initialized
INFO - 2016-09-19 10:23:59 --> Loader Class Initialized
INFO - 2016-09-19 10:23:59 --> Helper loaded: url_helper
INFO - 2016-09-19 10:23:59 --> Database Driver Class Initialized
INFO - 2016-09-19 10:23:59 --> Controller Class Initialized
DEBUG - 2016-09-19 10:23:59 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:23:59 --> Model Class Initialized
INFO - 2016-09-19 10:23:59 --> Model Class Initialized
INFO - 2016-09-19 10:23:59 --> Database Driver Class Initialized
INFO - 2016-09-19 10:23:59 --> Database Driver Class Initialized
INFO - 2016-09-19 10:23:59 --> Database Driver Class Initialized
INFO - 2016-09-19 10:24:00 --> Database Driver Class Initialized
INFO - 2016-09-19 10:24:00 --> Database Driver Class Initialized
INFO - 2016-09-19 10:24:00 --> Final output sent to browser
DEBUG - 2016-09-19 10:24:00 --> Total execution time: 1.1779
INFO - 2016-09-19 10:24:01 --> Config Class Initialized
INFO - 2016-09-19 10:24:01 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:24:01 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:24:01 --> Utf8 Class Initialized
INFO - 2016-09-19 10:24:01 --> URI Class Initialized
INFO - 2016-09-19 10:24:01 --> Router Class Initialized
INFO - 2016-09-19 10:24:01 --> Output Class Initialized
INFO - 2016-09-19 10:24:01 --> Security Class Initialized
DEBUG - 2016-09-19 10:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:24:01 --> Input Class Initialized
INFO - 2016-09-19 10:24:01 --> Language Class Initialized
INFO - 2016-09-19 10:24:01 --> Language Class Initialized
INFO - 2016-09-19 10:24:01 --> Config Class Initialized
INFO - 2016-09-19 10:24:02 --> Loader Class Initialized
INFO - 2016-09-19 10:24:02 --> Helper loaded: url_helper
INFO - 2016-09-19 10:24:02 --> Database Driver Class Initialized
INFO - 2016-09-19 10:24:02 --> Controller Class Initialized
DEBUG - 2016-09-19 10:24:02 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:24:02 --> Model Class Initialized
INFO - 2016-09-19 10:24:02 --> Model Class Initialized
INFO - 2016-09-19 10:24:02 --> Database Driver Class Initialized
INFO - 2016-09-19 10:24:02 --> Final output sent to browser
DEBUG - 2016-09-19 10:24:02 --> Total execution time: 1.1348
INFO - 2016-09-19 10:24:08 --> Config Class Initialized
INFO - 2016-09-19 10:24:08 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:24:08 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:24:08 --> Utf8 Class Initialized
INFO - 2016-09-19 10:24:08 --> URI Class Initialized
INFO - 2016-09-19 10:24:08 --> Router Class Initialized
INFO - 2016-09-19 10:24:08 --> Output Class Initialized
INFO - 2016-09-19 10:24:08 --> Security Class Initialized
DEBUG - 2016-09-19 10:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:24:08 --> Input Class Initialized
INFO - 2016-09-19 10:24:09 --> Language Class Initialized
INFO - 2016-09-19 10:24:09 --> Language Class Initialized
INFO - 2016-09-19 10:24:09 --> Config Class Initialized
INFO - 2016-09-19 10:24:09 --> Loader Class Initialized
INFO - 2016-09-19 10:24:09 --> Helper loaded: url_helper
INFO - 2016-09-19 10:24:09 --> Database Driver Class Initialized
INFO - 2016-09-19 10:24:09 --> Controller Class Initialized
DEBUG - 2016-09-19 10:24:09 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:24:09 --> Model Class Initialized
INFO - 2016-09-19 10:24:09 --> Model Class Initialized
DEBUG - 2016-09-19 10:24:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 10:24:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 10:24:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 10:24:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/buku_besar.php
DEBUG - 2016-09-19 10:24:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 10:24:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 10:24:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 10:24:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 10:24:10 --> Final output sent to browser
DEBUG - 2016-09-19 10:24:10 --> Total execution time: 1.5917
INFO - 2016-09-19 10:24:20 --> Config Class Initialized
INFO - 2016-09-19 10:24:20 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:24:20 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:24:20 --> Utf8 Class Initialized
INFO - 2016-09-19 10:24:20 --> URI Class Initialized
INFO - 2016-09-19 10:24:20 --> Router Class Initialized
INFO - 2016-09-19 10:24:20 --> Output Class Initialized
INFO - 2016-09-19 10:24:20 --> Security Class Initialized
DEBUG - 2016-09-19 10:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:24:20 --> Input Class Initialized
INFO - 2016-09-19 10:24:20 --> Language Class Initialized
INFO - 2016-09-19 10:24:20 --> Language Class Initialized
INFO - 2016-09-19 10:24:20 --> Config Class Initialized
INFO - 2016-09-19 10:24:20 --> Loader Class Initialized
INFO - 2016-09-19 10:24:20 --> Helper loaded: url_helper
INFO - 2016-09-19 10:24:20 --> Database Driver Class Initialized
INFO - 2016-09-19 10:24:20 --> Controller Class Initialized
DEBUG - 2016-09-19 10:24:21 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:24:21 --> Model Class Initialized
INFO - 2016-09-19 10:24:21 --> Model Class Initialized
DEBUG - 2016-09-19 10:24:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_buku_besar.php
INFO - 2016-09-19 10:24:21 --> Final output sent to browser
DEBUG - 2016-09-19 10:24:21 --> Total execution time: 1.0113
INFO - 2016-09-19 10:24:37 --> Config Class Initialized
INFO - 2016-09-19 10:24:37 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:24:37 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:24:37 --> Utf8 Class Initialized
INFO - 2016-09-19 10:24:38 --> URI Class Initialized
INFO - 2016-09-19 10:24:38 --> Router Class Initialized
INFO - 2016-09-19 10:24:38 --> Output Class Initialized
INFO - 2016-09-19 10:24:38 --> Security Class Initialized
DEBUG - 2016-09-19 10:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:24:38 --> Input Class Initialized
INFO - 2016-09-19 10:24:38 --> Language Class Initialized
INFO - 2016-09-19 10:24:38 --> Language Class Initialized
INFO - 2016-09-19 10:24:38 --> Config Class Initialized
INFO - 2016-09-19 10:24:38 --> Loader Class Initialized
INFO - 2016-09-19 10:24:38 --> Helper loaded: url_helper
INFO - 2016-09-19 10:24:38 --> Database Driver Class Initialized
INFO - 2016-09-19 10:24:38 --> Controller Class Initialized
DEBUG - 2016-09-19 10:24:38 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:24:38 --> Model Class Initialized
INFO - 2016-09-19 10:24:38 --> Model Class Initialized
DEBUG - 2016-09-19 10:24:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 10:24:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 10:24:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 10:24:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/jurnal_umum.php
DEBUG - 2016-09-19 10:24:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 10:24:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 10:24:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 10:24:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 10:24:38 --> Final output sent to browser
DEBUG - 2016-09-19 10:24:39 --> Total execution time: 1.0937
INFO - 2016-09-19 10:24:45 --> Config Class Initialized
INFO - 2016-09-19 10:24:45 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:24:45 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:24:45 --> Utf8 Class Initialized
INFO - 2016-09-19 10:24:45 --> URI Class Initialized
INFO - 2016-09-19 10:24:45 --> Router Class Initialized
INFO - 2016-09-19 10:24:45 --> Output Class Initialized
INFO - 2016-09-19 10:24:45 --> Security Class Initialized
DEBUG - 2016-09-19 10:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:24:45 --> Input Class Initialized
INFO - 2016-09-19 10:24:45 --> Language Class Initialized
INFO - 2016-09-19 10:24:46 --> Language Class Initialized
INFO - 2016-09-19 10:24:46 --> Config Class Initialized
INFO - 2016-09-19 10:24:46 --> Loader Class Initialized
INFO - 2016-09-19 10:24:46 --> Helper loaded: url_helper
INFO - 2016-09-19 10:24:46 --> Database Driver Class Initialized
INFO - 2016-09-19 10:24:46 --> Controller Class Initialized
DEBUG - 2016-09-19 10:24:46 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:24:46 --> Model Class Initialized
INFO - 2016-09-19 10:24:46 --> Model Class Initialized
DEBUG - 2016-09-19 10:24:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_jurnal_umum.php
INFO - 2016-09-19 10:24:46 --> Final output sent to browser
DEBUG - 2016-09-19 10:24:46 --> Total execution time: 0.8268
INFO - 2016-09-19 10:25:58 --> Config Class Initialized
INFO - 2016-09-19 10:25:58 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:25:58 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:25:58 --> Utf8 Class Initialized
INFO - 2016-09-19 10:25:58 --> URI Class Initialized
INFO - 2016-09-19 10:25:58 --> Router Class Initialized
INFO - 2016-09-19 10:25:58 --> Output Class Initialized
INFO - 2016-09-19 10:25:58 --> Security Class Initialized
DEBUG - 2016-09-19 10:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:25:58 --> Input Class Initialized
INFO - 2016-09-19 10:25:58 --> Language Class Initialized
INFO - 2016-09-19 10:25:59 --> Language Class Initialized
INFO - 2016-09-19 10:25:59 --> Config Class Initialized
INFO - 2016-09-19 10:25:59 --> Loader Class Initialized
INFO - 2016-09-19 10:25:59 --> Helper loaded: url_helper
INFO - 2016-09-19 10:25:59 --> Database Driver Class Initialized
INFO - 2016-09-19 10:25:59 --> Controller Class Initialized
DEBUG - 2016-09-19 10:25:59 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:25:59 --> Model Class Initialized
INFO - 2016-09-19 10:25:59 --> Model Class Initialized
DEBUG - 2016-09-19 10:25:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 10:25:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 10:25:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 10:25:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tutup_angsuran.php
DEBUG - 2016-09-19 10:25:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 10:25:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 10:25:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 10:25:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 10:25:59 --> Final output sent to browser
DEBUG - 2016-09-19 10:25:59 --> Total execution time: 1.1502
INFO - 2016-09-19 10:49:46 --> Config Class Initialized
INFO - 2016-09-19 10:49:46 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:49:46 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:49:46 --> Utf8 Class Initialized
INFO - 2016-09-19 10:49:46 --> URI Class Initialized
INFO - 2016-09-19 10:49:46 --> Router Class Initialized
INFO - 2016-09-19 10:49:46 --> Output Class Initialized
INFO - 2016-09-19 10:49:46 --> Security Class Initialized
DEBUG - 2016-09-19 10:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:49:46 --> Input Class Initialized
INFO - 2016-09-19 10:49:46 --> Language Class Initialized
INFO - 2016-09-19 10:49:46 --> Language Class Initialized
INFO - 2016-09-19 10:49:46 --> Config Class Initialized
INFO - 2016-09-19 10:49:46 --> Loader Class Initialized
INFO - 2016-09-19 10:49:46 --> Helper loaded: url_helper
INFO - 2016-09-19 10:49:46 --> Database Driver Class Initialized
INFO - 2016-09-19 10:49:46 --> Controller Class Initialized
DEBUG - 2016-09-19 10:49:47 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:49:47 --> Model Class Initialized
INFO - 2016-09-19 10:49:47 --> Model Class Initialized
INFO - 2016-09-19 10:49:47 --> Database Driver Class Initialized
INFO - 2016-09-19 10:49:47 --> Final output sent to browser
DEBUG - 2016-09-19 10:49:47 --> Total execution time: 1.0019
INFO - 2016-09-19 10:49:48 --> Config Class Initialized
INFO - 2016-09-19 10:49:48 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:49:49 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:49:49 --> Utf8 Class Initialized
INFO - 2016-09-19 10:49:49 --> URI Class Initialized
INFO - 2016-09-19 10:49:49 --> Router Class Initialized
INFO - 2016-09-19 10:49:49 --> Output Class Initialized
INFO - 2016-09-19 10:49:49 --> Security Class Initialized
DEBUG - 2016-09-19 10:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:49:49 --> Input Class Initialized
INFO - 2016-09-19 10:49:49 --> Language Class Initialized
INFO - 2016-09-19 10:49:49 --> Language Class Initialized
INFO - 2016-09-19 10:49:49 --> Config Class Initialized
INFO - 2016-09-19 10:49:49 --> Loader Class Initialized
INFO - 2016-09-19 10:49:49 --> Helper loaded: url_helper
INFO - 2016-09-19 10:49:49 --> Database Driver Class Initialized
INFO - 2016-09-19 10:49:49 --> Controller Class Initialized
DEBUG - 2016-09-19 10:49:49 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:49:49 --> Model Class Initialized
INFO - 2016-09-19 10:49:49 --> Model Class Initialized
DEBUG - 2016-09-19 10:49:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 10:49:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 10:49:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 10:49:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 10:49:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 10:49:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 10:49:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 10:49:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 10:49:50 --> Final output sent to browser
DEBUG - 2016-09-19 10:49:50 --> Total execution time: 1.1437
INFO - 2016-09-19 10:49:55 --> Config Class Initialized
INFO - 2016-09-19 10:49:55 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:49:55 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:49:55 --> Utf8 Class Initialized
INFO - 2016-09-19 10:49:55 --> URI Class Initialized
INFO - 2016-09-19 10:49:55 --> Router Class Initialized
INFO - 2016-09-19 10:49:55 --> Output Class Initialized
INFO - 2016-09-19 10:49:55 --> Security Class Initialized
DEBUG - 2016-09-19 10:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:49:55 --> Input Class Initialized
INFO - 2016-09-19 10:49:55 --> Language Class Initialized
INFO - 2016-09-19 10:49:56 --> Language Class Initialized
INFO - 2016-09-19 10:49:56 --> Config Class Initialized
INFO - 2016-09-19 10:49:56 --> Loader Class Initialized
INFO - 2016-09-19 10:49:56 --> Helper loaded: url_helper
INFO - 2016-09-19 10:49:56 --> Database Driver Class Initialized
INFO - 2016-09-19 10:49:56 --> Controller Class Initialized
DEBUG - 2016-09-19 10:49:56 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:49:56 --> Model Class Initialized
INFO - 2016-09-19 10:49:56 --> Model Class Initialized
DEBUG - 2016-09-19 10:49:56 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 10:49:56 --> Database Driver Class Initialized
INFO - 2016-09-19 10:49:56 --> Final output sent to browser
DEBUG - 2016-09-19 10:49:56 --> Total execution time: 0.8743
INFO - 2016-09-19 10:50:36 --> Config Class Initialized
INFO - 2016-09-19 10:50:36 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:50:36 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:50:36 --> Utf8 Class Initialized
INFO - 2016-09-19 10:50:36 --> URI Class Initialized
INFO - 2016-09-19 10:50:36 --> Router Class Initialized
INFO - 2016-09-19 10:50:36 --> Output Class Initialized
INFO - 2016-09-19 10:50:36 --> Security Class Initialized
DEBUG - 2016-09-19 10:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:50:36 --> Input Class Initialized
INFO - 2016-09-19 10:50:36 --> Language Class Initialized
INFO - 2016-09-19 10:50:36 --> Language Class Initialized
INFO - 2016-09-19 10:50:36 --> Config Class Initialized
INFO - 2016-09-19 10:50:36 --> Loader Class Initialized
INFO - 2016-09-19 10:50:36 --> Helper loaded: url_helper
INFO - 2016-09-19 10:50:36 --> Database Driver Class Initialized
INFO - 2016-09-19 10:50:36 --> Controller Class Initialized
DEBUG - 2016-09-19 10:50:36 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:50:36 --> Model Class Initialized
INFO - 2016-09-19 10:50:36 --> Model Class Initialized
DEBUG - 2016-09-19 10:50:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 10:50:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 10:50:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 10:50:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_bayar_angsuran.php
DEBUG - 2016-09-19 10:50:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 10:50:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 10:50:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 10:50:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 10:50:37 --> Final output sent to browser
DEBUG - 2016-09-19 10:50:37 --> Total execution time: 1.1561
INFO - 2016-09-19 10:50:41 --> Config Class Initialized
INFO - 2016-09-19 10:50:41 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:50:41 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:50:41 --> Utf8 Class Initialized
INFO - 2016-09-19 10:50:41 --> URI Class Initialized
INFO - 2016-09-19 10:50:41 --> Router Class Initialized
INFO - 2016-09-19 10:50:41 --> Output Class Initialized
INFO - 2016-09-19 10:50:41 --> Security Class Initialized
DEBUG - 2016-09-19 10:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:50:41 --> Input Class Initialized
INFO - 2016-09-19 10:50:41 --> Language Class Initialized
INFO - 2016-09-19 10:50:41 --> Language Class Initialized
INFO - 2016-09-19 10:50:41 --> Config Class Initialized
INFO - 2016-09-19 10:50:41 --> Loader Class Initialized
INFO - 2016-09-19 10:50:41 --> Helper loaded: url_helper
INFO - 2016-09-19 10:50:41 --> Database Driver Class Initialized
INFO - 2016-09-19 10:50:41 --> Controller Class Initialized
DEBUG - 2016-09-19 10:50:41 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:50:41 --> Model Class Initialized
INFO - 2016-09-19 10:50:41 --> Model Class Initialized
INFO - 2016-09-19 10:50:41 --> Database Driver Class Initialized
INFO - 2016-09-19 10:50:41 --> Final output sent to browser
DEBUG - 2016-09-19 10:50:42 --> Total execution time: 0.8964
INFO - 2016-09-19 10:50:45 --> Config Class Initialized
INFO - 2016-09-19 10:50:45 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:50:45 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:50:45 --> Utf8 Class Initialized
INFO - 2016-09-19 10:50:45 --> URI Class Initialized
INFO - 2016-09-19 10:50:45 --> Router Class Initialized
INFO - 2016-09-19 10:50:45 --> Output Class Initialized
INFO - 2016-09-19 10:50:45 --> Security Class Initialized
DEBUG - 2016-09-19 10:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:50:46 --> Input Class Initialized
INFO - 2016-09-19 10:50:46 --> Language Class Initialized
INFO - 2016-09-19 10:50:46 --> Language Class Initialized
INFO - 2016-09-19 10:50:46 --> Config Class Initialized
INFO - 2016-09-19 10:50:46 --> Loader Class Initialized
INFO - 2016-09-19 10:50:46 --> Helper loaded: url_helper
INFO - 2016-09-19 10:50:46 --> Database Driver Class Initialized
INFO - 2016-09-19 10:50:46 --> Controller Class Initialized
DEBUG - 2016-09-19 10:50:46 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:50:46 --> Model Class Initialized
INFO - 2016-09-19 10:50:46 --> Model Class Initialized
DEBUG - 2016-09-19 10:50:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 10:50:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 10:50:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 10:50:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tutup_angsuran.php
DEBUG - 2016-09-19 10:50:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 10:50:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 10:50:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 10:50:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 10:50:46 --> Final output sent to browser
DEBUG - 2016-09-19 10:50:46 --> Total execution time: 1.1171
INFO - 2016-09-19 10:50:50 --> Config Class Initialized
INFO - 2016-09-19 10:50:50 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:50:50 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:50:50 --> Utf8 Class Initialized
INFO - 2016-09-19 10:50:51 --> URI Class Initialized
INFO - 2016-09-19 10:50:51 --> Router Class Initialized
INFO - 2016-09-19 10:50:51 --> Output Class Initialized
INFO - 2016-09-19 10:50:51 --> Security Class Initialized
DEBUG - 2016-09-19 10:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:50:51 --> Input Class Initialized
INFO - 2016-09-19 10:50:51 --> Language Class Initialized
INFO - 2016-09-19 10:50:51 --> Language Class Initialized
INFO - 2016-09-19 10:50:51 --> Config Class Initialized
INFO - 2016-09-19 10:50:51 --> Loader Class Initialized
INFO - 2016-09-19 10:50:51 --> Helper loaded: url_helper
INFO - 2016-09-19 10:50:51 --> Database Driver Class Initialized
INFO - 2016-09-19 10:50:51 --> Controller Class Initialized
DEBUG - 2016-09-19 10:50:51 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:50:51 --> Model Class Initialized
INFO - 2016-09-19 10:50:51 --> Model Class Initialized
INFO - 2016-09-19 10:50:51 --> Database Driver Class Initialized
INFO - 2016-09-19 10:50:51 --> Final output sent to browser
DEBUG - 2016-09-19 10:50:51 --> Total execution time: 1.2518
INFO - 2016-09-19 10:51:39 --> Config Class Initialized
INFO - 2016-09-19 10:51:39 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:51:39 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:51:39 --> Utf8 Class Initialized
INFO - 2016-09-19 10:51:39 --> URI Class Initialized
INFO - 2016-09-19 10:51:39 --> Router Class Initialized
INFO - 2016-09-19 10:51:39 --> Output Class Initialized
INFO - 2016-09-19 10:51:40 --> Security Class Initialized
DEBUG - 2016-09-19 10:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:51:40 --> Input Class Initialized
INFO - 2016-09-19 10:51:40 --> Language Class Initialized
INFO - 2016-09-19 10:51:40 --> Language Class Initialized
INFO - 2016-09-19 10:51:40 --> Config Class Initialized
INFO - 2016-09-19 10:51:40 --> Loader Class Initialized
INFO - 2016-09-19 10:51:40 --> Helper loaded: url_helper
INFO - 2016-09-19 10:51:40 --> Database Driver Class Initialized
INFO - 2016-09-19 10:51:40 --> Controller Class Initialized
DEBUG - 2016-09-19 10:51:40 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:51:40 --> Model Class Initialized
INFO - 2016-09-19 10:51:40 --> Model Class Initialized
INFO - 2016-09-19 10:51:40 --> Database Driver Class Initialized
INFO - 2016-09-19 10:51:40 --> Final output sent to browser
DEBUG - 2016-09-19 10:51:40 --> Total execution time: 0.8670
INFO - 2016-09-19 10:51:42 --> Config Class Initialized
INFO - 2016-09-19 10:51:42 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:51:42 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:51:42 --> Utf8 Class Initialized
INFO - 2016-09-19 10:51:42 --> URI Class Initialized
INFO - 2016-09-19 10:51:42 --> Router Class Initialized
INFO - 2016-09-19 10:51:42 --> Output Class Initialized
INFO - 2016-09-19 10:51:42 --> Security Class Initialized
DEBUG - 2016-09-19 10:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:51:42 --> Input Class Initialized
INFO - 2016-09-19 10:51:42 --> Language Class Initialized
INFO - 2016-09-19 10:51:42 --> Language Class Initialized
INFO - 2016-09-19 10:51:42 --> Config Class Initialized
INFO - 2016-09-19 10:51:43 --> Loader Class Initialized
INFO - 2016-09-19 10:51:43 --> Helper loaded: url_helper
INFO - 2016-09-19 10:51:43 --> Database Driver Class Initialized
INFO - 2016-09-19 10:51:43 --> Controller Class Initialized
DEBUG - 2016-09-19 10:51:43 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:51:43 --> Model Class Initialized
INFO - 2016-09-19 10:51:43 --> Model Class Initialized
INFO - 2016-09-19 10:51:43 --> Final output sent to browser
DEBUG - 2016-09-19 10:51:43 --> Total execution time: 0.8490
INFO - 2016-09-19 10:51:45 --> Config Class Initialized
INFO - 2016-09-19 10:51:45 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:51:45 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:51:45 --> Utf8 Class Initialized
INFO - 2016-09-19 10:51:45 --> URI Class Initialized
INFO - 2016-09-19 10:51:45 --> Router Class Initialized
INFO - 2016-09-19 10:51:45 --> Output Class Initialized
INFO - 2016-09-19 10:51:45 --> Security Class Initialized
DEBUG - 2016-09-19 10:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:51:45 --> Input Class Initialized
INFO - 2016-09-19 10:51:45 --> Language Class Initialized
INFO - 2016-09-19 10:51:45 --> Language Class Initialized
INFO - 2016-09-19 10:51:45 --> Config Class Initialized
INFO - 2016-09-19 10:51:45 --> Loader Class Initialized
INFO - 2016-09-19 10:51:45 --> Helper loaded: url_helper
INFO - 2016-09-19 10:51:45 --> Database Driver Class Initialized
INFO - 2016-09-19 10:51:45 --> Controller Class Initialized
DEBUG - 2016-09-19 10:51:45 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:51:45 --> Model Class Initialized
INFO - 2016-09-19 10:51:45 --> Model Class Initialized
DEBUG - 2016-09-19 10:51:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 10:51:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 10:51:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 10:51:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 10:51:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 10:51:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 10:51:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 10:51:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 10:51:46 --> Final output sent to browser
DEBUG - 2016-09-19 10:51:46 --> Total execution time: 1.1399
INFO - 2016-09-19 10:52:33 --> Config Class Initialized
INFO - 2016-09-19 10:52:33 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:52:33 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:52:33 --> Utf8 Class Initialized
INFO - 2016-09-19 10:52:33 --> URI Class Initialized
INFO - 2016-09-19 10:52:33 --> Router Class Initialized
INFO - 2016-09-19 10:52:33 --> Output Class Initialized
INFO - 2016-09-19 10:52:33 --> Security Class Initialized
DEBUG - 2016-09-19 10:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:52:34 --> Input Class Initialized
INFO - 2016-09-19 10:52:34 --> Language Class Initialized
INFO - 2016-09-19 10:52:34 --> Language Class Initialized
INFO - 2016-09-19 10:52:34 --> Config Class Initialized
INFO - 2016-09-19 10:52:34 --> Loader Class Initialized
INFO - 2016-09-19 10:52:34 --> Helper loaded: url_helper
INFO - 2016-09-19 10:52:34 --> Database Driver Class Initialized
INFO - 2016-09-19 10:52:34 --> Controller Class Initialized
DEBUG - 2016-09-19 10:52:34 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:52:34 --> Model Class Initialized
INFO - 2016-09-19 10:52:34 --> Model Class Initialized
DEBUG - 2016-09-19 10:52:34 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 10:52:34 --> Database Driver Class Initialized
INFO - 2016-09-19 10:52:34 --> Final output sent to browser
DEBUG - 2016-09-19 10:52:34 --> Total execution time: 0.8684
INFO - 2016-09-19 10:52:38 --> Config Class Initialized
INFO - 2016-09-19 10:52:39 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:52:39 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:52:39 --> Utf8 Class Initialized
INFO - 2016-09-19 10:52:39 --> URI Class Initialized
INFO - 2016-09-19 10:52:39 --> Router Class Initialized
INFO - 2016-09-19 10:52:39 --> Output Class Initialized
INFO - 2016-09-19 10:52:39 --> Security Class Initialized
DEBUG - 2016-09-19 10:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:52:39 --> Input Class Initialized
INFO - 2016-09-19 10:52:39 --> Language Class Initialized
INFO - 2016-09-19 10:52:39 --> Language Class Initialized
INFO - 2016-09-19 10:52:39 --> Config Class Initialized
INFO - 2016-09-19 10:52:39 --> Loader Class Initialized
INFO - 2016-09-19 10:52:39 --> Helper loaded: url_helper
INFO - 2016-09-19 10:52:39 --> Database Driver Class Initialized
INFO - 2016-09-19 10:52:39 --> Controller Class Initialized
DEBUG - 2016-09-19 10:52:39 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:52:39 --> Model Class Initialized
INFO - 2016-09-19 10:52:39 --> Model Class Initialized
DEBUG - 2016-09-19 10:52:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 10:52:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 10:52:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 10:52:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_umum.php
DEBUG - 2016-09-19 10:52:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 10:52:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 10:52:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 10:52:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 10:52:40 --> Final output sent to browser
DEBUG - 2016-09-19 10:52:40 --> Total execution time: 1.1353
INFO - 2016-09-19 10:52:51 --> Config Class Initialized
INFO - 2016-09-19 10:52:52 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:52:52 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:52:52 --> Utf8 Class Initialized
INFO - 2016-09-19 10:52:52 --> URI Class Initialized
INFO - 2016-09-19 10:52:52 --> Router Class Initialized
INFO - 2016-09-19 10:52:52 --> Output Class Initialized
INFO - 2016-09-19 10:52:52 --> Security Class Initialized
DEBUG - 2016-09-19 10:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:52:52 --> Input Class Initialized
INFO - 2016-09-19 10:52:52 --> Language Class Initialized
INFO - 2016-09-19 10:52:52 --> Language Class Initialized
INFO - 2016-09-19 10:52:52 --> Config Class Initialized
INFO - 2016-09-19 10:52:52 --> Loader Class Initialized
INFO - 2016-09-19 10:52:52 --> Helper loaded: url_helper
INFO - 2016-09-19 10:52:52 --> Database Driver Class Initialized
INFO - 2016-09-19 10:52:52 --> Controller Class Initialized
DEBUG - 2016-09-19 10:52:52 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:52:52 --> Model Class Initialized
INFO - 2016-09-19 10:52:52 --> Model Class Initialized
INFO - 2016-09-19 10:52:52 --> Database Driver Class Initialized
INFO - 2016-09-19 10:52:52 --> Final output sent to browser
DEBUG - 2016-09-19 10:52:53 --> Total execution time: 1.0235
INFO - 2016-09-19 10:52:57 --> Config Class Initialized
INFO - 2016-09-19 10:52:57 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:52:57 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:52:57 --> Utf8 Class Initialized
INFO - 2016-09-19 10:52:58 --> URI Class Initialized
INFO - 2016-09-19 10:52:58 --> Router Class Initialized
INFO - 2016-09-19 10:52:58 --> Output Class Initialized
INFO - 2016-09-19 10:52:58 --> Security Class Initialized
DEBUG - 2016-09-19 10:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:52:58 --> Input Class Initialized
INFO - 2016-09-19 10:52:58 --> Language Class Initialized
INFO - 2016-09-19 10:52:58 --> Language Class Initialized
INFO - 2016-09-19 10:52:58 --> Config Class Initialized
INFO - 2016-09-19 10:52:58 --> Loader Class Initialized
INFO - 2016-09-19 10:52:58 --> Helper loaded: url_helper
INFO - 2016-09-19 10:52:58 --> Database Driver Class Initialized
INFO - 2016-09-19 10:52:58 --> Controller Class Initialized
DEBUG - 2016-09-19 10:52:58 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:52:58 --> Model Class Initialized
INFO - 2016-09-19 10:52:58 --> Model Class Initialized
INFO - 2016-09-19 10:52:58 --> Database Driver Class Initialized
INFO - 2016-09-19 10:52:58 --> Final output sent to browser
DEBUG - 2016-09-19 10:52:58 --> Total execution time: 1.1654
INFO - 2016-09-19 10:53:16 --> Config Class Initialized
INFO - 2016-09-19 10:53:16 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:53:16 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:53:16 --> Utf8 Class Initialized
INFO - 2016-09-19 10:53:16 --> URI Class Initialized
INFO - 2016-09-19 10:53:16 --> Router Class Initialized
INFO - 2016-09-19 10:53:16 --> Output Class Initialized
INFO - 2016-09-19 10:53:16 --> Security Class Initialized
DEBUG - 2016-09-19 10:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:53:16 --> Input Class Initialized
INFO - 2016-09-19 10:53:16 --> Language Class Initialized
INFO - 2016-09-19 10:53:16 --> Language Class Initialized
INFO - 2016-09-19 10:53:16 --> Config Class Initialized
INFO - 2016-09-19 10:53:16 --> Loader Class Initialized
INFO - 2016-09-19 10:53:16 --> Helper loaded: url_helper
INFO - 2016-09-19 10:53:17 --> Database Driver Class Initialized
INFO - 2016-09-19 10:53:17 --> Controller Class Initialized
DEBUG - 2016-09-19 10:53:17 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:53:17 --> Model Class Initialized
INFO - 2016-09-19 10:53:17 --> Model Class Initialized
INFO - 2016-09-19 10:53:17 --> Database Driver Class Initialized
INFO - 2016-09-19 10:53:17 --> Database Driver Class Initialized
INFO - 2016-09-19 10:53:17 --> Final output sent to browser
DEBUG - 2016-09-19 10:53:17 --> Total execution time: 1.1358
INFO - 2016-09-19 10:53:21 --> Config Class Initialized
INFO - 2016-09-19 10:53:21 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:53:21 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:53:21 --> Utf8 Class Initialized
INFO - 2016-09-19 10:53:21 --> URI Class Initialized
INFO - 2016-09-19 10:53:21 --> Router Class Initialized
INFO - 2016-09-19 10:53:21 --> Output Class Initialized
INFO - 2016-09-19 10:53:21 --> Security Class Initialized
DEBUG - 2016-09-19 10:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:53:21 --> Input Class Initialized
INFO - 2016-09-19 10:53:21 --> Language Class Initialized
INFO - 2016-09-19 10:53:21 --> Language Class Initialized
INFO - 2016-09-19 10:53:21 --> Config Class Initialized
INFO - 2016-09-19 10:53:21 --> Loader Class Initialized
INFO - 2016-09-19 10:53:21 --> Helper loaded: url_helper
INFO - 2016-09-19 10:53:21 --> Database Driver Class Initialized
INFO - 2016-09-19 10:53:21 --> Controller Class Initialized
DEBUG - 2016-09-19 10:53:21 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:53:21 --> Model Class Initialized
INFO - 2016-09-19 10:53:21 --> Model Class Initialized
DEBUG - 2016-09-19 10:53:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 10:53:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 10:53:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 10:53:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tutup_angsuran.php
DEBUG - 2016-09-19 10:53:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 10:53:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 10:53:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 10:53:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 10:53:22 --> Final output sent to browser
DEBUG - 2016-09-19 10:53:22 --> Total execution time: 1.1057
INFO - 2016-09-19 10:53:25 --> Config Class Initialized
INFO - 2016-09-19 10:53:25 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:53:25 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:53:25 --> Utf8 Class Initialized
INFO - 2016-09-19 10:53:26 --> URI Class Initialized
INFO - 2016-09-19 10:53:26 --> Router Class Initialized
INFO - 2016-09-19 10:53:26 --> Output Class Initialized
INFO - 2016-09-19 10:53:26 --> Security Class Initialized
DEBUG - 2016-09-19 10:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:53:26 --> Input Class Initialized
INFO - 2016-09-19 10:53:26 --> Language Class Initialized
INFO - 2016-09-19 10:53:26 --> Language Class Initialized
INFO - 2016-09-19 10:53:26 --> Config Class Initialized
INFO - 2016-09-19 10:53:26 --> Loader Class Initialized
INFO - 2016-09-19 10:53:26 --> Helper loaded: url_helper
INFO - 2016-09-19 10:53:26 --> Database Driver Class Initialized
INFO - 2016-09-19 10:53:26 --> Controller Class Initialized
DEBUG - 2016-09-19 10:53:26 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:53:26 --> Model Class Initialized
INFO - 2016-09-19 10:53:26 --> Model Class Initialized
INFO - 2016-09-19 10:53:26 --> Database Driver Class Initialized
INFO - 2016-09-19 10:53:26 --> Final output sent to browser
DEBUG - 2016-09-19 10:53:26 --> Total execution time: 0.9942
INFO - 2016-09-19 10:54:53 --> Config Class Initialized
INFO - 2016-09-19 10:54:53 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:54:53 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:54:53 --> Utf8 Class Initialized
INFO - 2016-09-19 10:54:53 --> URI Class Initialized
INFO - 2016-09-19 10:54:53 --> Router Class Initialized
INFO - 2016-09-19 10:54:53 --> Output Class Initialized
INFO - 2016-09-19 10:54:53 --> Security Class Initialized
DEBUG - 2016-09-19 10:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:54:53 --> Input Class Initialized
INFO - 2016-09-19 10:54:53 --> Language Class Initialized
INFO - 2016-09-19 10:54:53 --> Language Class Initialized
INFO - 2016-09-19 10:54:54 --> Config Class Initialized
INFO - 2016-09-19 10:54:54 --> Loader Class Initialized
INFO - 2016-09-19 10:54:54 --> Helper loaded: url_helper
INFO - 2016-09-19 10:54:54 --> Database Driver Class Initialized
INFO - 2016-09-19 10:54:54 --> Controller Class Initialized
DEBUG - 2016-09-19 10:54:54 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:54:54 --> Model Class Initialized
INFO - 2016-09-19 10:54:54 --> Model Class Initialized
INFO - 2016-09-19 10:54:54 --> Database Driver Class Initialized
INFO - 2016-09-19 10:54:54 --> Final output sent to browser
DEBUG - 2016-09-19 10:54:54 --> Total execution time: 0.8546
INFO - 2016-09-19 10:54:59 --> Config Class Initialized
INFO - 2016-09-19 10:54:59 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:54:59 --> UTF-8 Support Enabled
INFO - 2016-09-19 10:54:59 --> Utf8 Class Initialized
INFO - 2016-09-19 10:54:59 --> URI Class Initialized
INFO - 2016-09-19 10:54:59 --> Router Class Initialized
INFO - 2016-09-19 10:54:59 --> Output Class Initialized
INFO - 2016-09-19 10:54:59 --> Security Class Initialized
DEBUG - 2016-09-19 10:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 10:54:59 --> Input Class Initialized
INFO - 2016-09-19 10:54:59 --> Language Class Initialized
INFO - 2016-09-19 10:54:59 --> Language Class Initialized
INFO - 2016-09-19 10:54:59 --> Config Class Initialized
INFO - 2016-09-19 10:54:59 --> Loader Class Initialized
INFO - 2016-09-19 10:54:59 --> Helper loaded: url_helper
INFO - 2016-09-19 10:54:59 --> Database Driver Class Initialized
INFO - 2016-09-19 10:54:59 --> Controller Class Initialized
DEBUG - 2016-09-19 10:54:59 --> Index MX_Controller Initialized
INFO - 2016-09-19 10:54:59 --> Model Class Initialized
INFO - 2016-09-19 10:54:59 --> Model Class Initialized
INFO - 2016-09-19 10:54:59 --> Database Driver Class Initialized
INFO - 2016-09-19 10:55:00 --> Database Driver Class Initialized
INFO - 2016-09-19 10:55:00 --> Database Driver Class Initialized
INFO - 2016-09-19 10:55:00 --> Database Driver Class Initialized
INFO - 2016-09-19 10:55:00 --> Database Driver Class Initialized
INFO - 2016-09-19 10:55:00 --> Database Driver Class Initialized
INFO - 2016-09-19 10:55:00 --> Database Driver Class Initialized
INFO - 2016-09-19 10:55:00 --> Database Driver Class Initialized
INFO - 2016-09-19 10:55:00 --> Database Driver Class Initialized
INFO - 2016-09-19 10:55:00 --> Database Driver Class Initialized
INFO - 2016-09-19 10:55:00 --> Database Driver Class Initialized
INFO - 2016-09-19 10:55:00 --> Database Driver Class Initialized
INFO - 2016-09-19 10:55:00 --> Database Driver Class Initialized
INFO - 2016-09-19 10:55:00 --> Database Driver Class Initialized
INFO - 2016-09-19 10:55:01 --> Database Driver Class Initialized
INFO - 2016-09-19 10:55:01 --> Database Driver Class Initialized
INFO - 2016-09-19 10:55:01 --> Database Driver Class Initialized
INFO - 2016-09-19 10:55:01 --> Database Driver Class Initialized
INFO - 2016-09-19 10:55:01 --> Database Driver Class Initialized
INFO - 2016-09-19 10:55:01 --> Database Driver Class Initialized
INFO - 2016-09-19 10:55:01 --> Database Driver Class Initialized
INFO - 2016-09-19 10:55:01 --> Database Driver Class Initialized
INFO - 2016-09-19 10:55:01 --> Database Driver Class Initialized
INFO - 2016-09-19 10:55:01 --> Database Driver Class Initialized
INFO - 2016-09-19 10:55:01 --> Database Driver Class Initialized
INFO - 2016-09-19 10:55:02 --> Final output sent to browser
DEBUG - 2016-09-19 10:55:02 --> Total execution time: 3.0981
INFO - 2016-09-19 11:02:58 --> Config Class Initialized
INFO - 2016-09-19 11:02:58 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:02:58 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:02:58 --> Utf8 Class Initialized
INFO - 2016-09-19 11:02:58 --> URI Class Initialized
INFO - 2016-09-19 11:02:58 --> Router Class Initialized
INFO - 2016-09-19 11:02:58 --> Output Class Initialized
INFO - 2016-09-19 11:02:58 --> Security Class Initialized
DEBUG - 2016-09-19 11:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:02:58 --> Input Class Initialized
INFO - 2016-09-19 11:02:58 --> Language Class Initialized
INFO - 2016-09-19 11:02:58 --> Language Class Initialized
INFO - 2016-09-19 11:02:58 --> Config Class Initialized
INFO - 2016-09-19 11:02:59 --> Loader Class Initialized
INFO - 2016-09-19 11:02:59 --> Helper loaded: url_helper
INFO - 2016-09-19 11:02:59 --> Database Driver Class Initialized
INFO - 2016-09-19 11:02:59 --> Controller Class Initialized
DEBUG - 2016-09-19 11:02:59 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:02:59 --> Model Class Initialized
INFO - 2016-09-19 11:02:59 --> Model Class Initialized
INFO - 2016-09-19 11:02:59 --> Final output sent to browser
DEBUG - 2016-09-19 11:02:59 --> Total execution time: 0.7938
INFO - 2016-09-19 11:03:09 --> Config Class Initialized
INFO - 2016-09-19 11:03:09 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:03:09 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:03:09 --> Utf8 Class Initialized
INFO - 2016-09-19 11:03:09 --> URI Class Initialized
INFO - 2016-09-19 11:03:10 --> Router Class Initialized
INFO - 2016-09-19 11:03:10 --> Output Class Initialized
INFO - 2016-09-19 11:03:10 --> Security Class Initialized
DEBUG - 2016-09-19 11:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:03:10 --> Input Class Initialized
INFO - 2016-09-19 11:03:10 --> Language Class Initialized
INFO - 2016-09-19 11:03:10 --> Language Class Initialized
INFO - 2016-09-19 11:03:10 --> Config Class Initialized
INFO - 2016-09-19 11:03:10 --> Loader Class Initialized
INFO - 2016-09-19 11:03:10 --> Helper loaded: url_helper
INFO - 2016-09-19 11:03:10 --> Database Driver Class Initialized
INFO - 2016-09-19 11:03:10 --> Controller Class Initialized
DEBUG - 2016-09-19 11:03:10 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:03:10 --> Model Class Initialized
INFO - 2016-09-19 11:03:10 --> Model Class Initialized
INFO - 2016-09-19 11:03:10 --> Database Driver Class Initialized
INFO - 2016-09-19 11:03:10 --> Final output sent to browser
DEBUG - 2016-09-19 11:03:10 --> Total execution time: 0.8635
INFO - 2016-09-19 11:03:12 --> Config Class Initialized
INFO - 2016-09-19 11:03:12 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:03:12 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:03:13 --> Utf8 Class Initialized
INFO - 2016-09-19 11:03:13 --> URI Class Initialized
INFO - 2016-09-19 11:03:13 --> Router Class Initialized
INFO - 2016-09-19 11:03:13 --> Output Class Initialized
INFO - 2016-09-19 11:03:13 --> Security Class Initialized
DEBUG - 2016-09-19 11:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:03:13 --> Input Class Initialized
INFO - 2016-09-19 11:03:13 --> Language Class Initialized
INFO - 2016-09-19 11:03:13 --> Language Class Initialized
INFO - 2016-09-19 11:03:13 --> Config Class Initialized
INFO - 2016-09-19 11:03:13 --> Loader Class Initialized
INFO - 2016-09-19 11:03:13 --> Helper loaded: url_helper
INFO - 2016-09-19 11:03:13 --> Database Driver Class Initialized
INFO - 2016-09-19 11:03:13 --> Controller Class Initialized
DEBUG - 2016-09-19 11:03:13 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:03:13 --> Model Class Initialized
INFO - 2016-09-19 11:03:13 --> Model Class Initialized
INFO - 2016-09-19 11:03:13 --> Database Driver Class Initialized
INFO - 2016-09-19 11:03:13 --> Database Driver Class Initialized
INFO - 2016-09-19 11:03:13 --> Database Driver Class Initialized
INFO - 2016-09-19 11:03:14 --> Database Driver Class Initialized
INFO - 2016-09-19 11:03:14 --> Database Driver Class Initialized
INFO - 2016-09-19 11:03:14 --> Database Driver Class Initialized
INFO - 2016-09-19 11:03:14 --> Database Driver Class Initialized
INFO - 2016-09-19 11:03:14 --> Database Driver Class Initialized
INFO - 2016-09-19 11:03:14 --> Database Driver Class Initialized
INFO - 2016-09-19 11:03:14 --> Database Driver Class Initialized
INFO - 2016-09-19 11:03:14 --> Database Driver Class Initialized
INFO - 2016-09-19 11:03:14 --> Database Driver Class Initialized
INFO - 2016-09-19 11:03:14 --> Database Driver Class Initialized
INFO - 2016-09-19 11:03:14 --> Database Driver Class Initialized
INFO - 2016-09-19 11:03:14 --> Database Driver Class Initialized
INFO - 2016-09-19 11:03:15 --> Database Driver Class Initialized
INFO - 2016-09-19 11:03:15 --> Database Driver Class Initialized
INFO - 2016-09-19 11:03:15 --> Database Driver Class Initialized
INFO - 2016-09-19 11:03:15 --> Database Driver Class Initialized
INFO - 2016-09-19 11:03:15 --> Database Driver Class Initialized
INFO - 2016-09-19 11:03:15 --> Database Driver Class Initialized
INFO - 2016-09-19 11:03:15 --> Database Driver Class Initialized
INFO - 2016-09-19 11:03:15 --> Final output sent to browser
DEBUG - 2016-09-19 11:03:15 --> Total execution time: 2.7135
INFO - 2016-09-19 11:04:44 --> Config Class Initialized
INFO - 2016-09-19 11:04:44 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:04:44 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:04:44 --> Utf8 Class Initialized
INFO - 2016-09-19 11:04:44 --> URI Class Initialized
INFO - 2016-09-19 11:04:44 --> Router Class Initialized
INFO - 2016-09-19 11:04:44 --> Output Class Initialized
INFO - 2016-09-19 11:04:45 --> Security Class Initialized
DEBUG - 2016-09-19 11:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:04:45 --> Input Class Initialized
INFO - 2016-09-19 11:04:45 --> Language Class Initialized
INFO - 2016-09-19 11:04:45 --> Language Class Initialized
INFO - 2016-09-19 11:04:45 --> Config Class Initialized
INFO - 2016-09-19 11:04:45 --> Loader Class Initialized
INFO - 2016-09-19 11:04:45 --> Helper loaded: url_helper
INFO - 2016-09-19 11:04:45 --> Database Driver Class Initialized
INFO - 2016-09-19 11:04:45 --> Controller Class Initialized
DEBUG - 2016-09-19 11:04:45 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:04:45 --> Model Class Initialized
INFO - 2016-09-19 11:04:45 --> Model Class Initialized
INFO - 2016-09-19 11:04:45 --> Database Driver Class Initialized
INFO - 2016-09-19 11:04:45 --> Final output sent to browser
DEBUG - 2016-09-19 11:04:45 --> Total execution time: 0.8959
INFO - 2016-09-19 11:04:47 --> Config Class Initialized
INFO - 2016-09-19 11:04:47 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:04:47 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:04:47 --> Utf8 Class Initialized
INFO - 2016-09-19 11:04:47 --> URI Class Initialized
INFO - 2016-09-19 11:04:47 --> Router Class Initialized
INFO - 2016-09-19 11:04:47 --> Output Class Initialized
INFO - 2016-09-19 11:04:47 --> Security Class Initialized
DEBUG - 2016-09-19 11:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:04:47 --> Input Class Initialized
INFO - 2016-09-19 11:04:47 --> Language Class Initialized
INFO - 2016-09-19 11:04:47 --> Language Class Initialized
INFO - 2016-09-19 11:04:47 --> Config Class Initialized
INFO - 2016-09-19 11:04:47 --> Loader Class Initialized
INFO - 2016-09-19 11:04:47 --> Helper loaded: url_helper
INFO - 2016-09-19 11:04:47 --> Database Driver Class Initialized
INFO - 2016-09-19 11:04:47 --> Controller Class Initialized
DEBUG - 2016-09-19 11:04:47 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:04:48 --> Model Class Initialized
INFO - 2016-09-19 11:04:48 --> Model Class Initialized
INFO - 2016-09-19 11:04:48 --> Database Driver Class Initialized
INFO - 2016-09-19 11:04:48 --> Database Driver Class Initialized
INFO - 2016-09-19 11:04:48 --> Database Driver Class Initialized
INFO - 2016-09-19 11:04:48 --> Database Driver Class Initialized
INFO - 2016-09-19 11:04:48 --> Database Driver Class Initialized
INFO - 2016-09-19 11:04:48 --> Database Driver Class Initialized
INFO - 2016-09-19 11:04:48 --> Database Driver Class Initialized
INFO - 2016-09-19 11:04:48 --> Database Driver Class Initialized
INFO - 2016-09-19 11:04:48 --> Database Driver Class Initialized
INFO - 2016-09-19 11:04:49 --> Database Driver Class Initialized
INFO - 2016-09-19 11:04:49 --> Database Driver Class Initialized
INFO - 2016-09-19 11:04:49 --> Database Driver Class Initialized
INFO - 2016-09-19 11:04:49 --> Database Driver Class Initialized
INFO - 2016-09-19 11:04:49 --> Database Driver Class Initialized
INFO - 2016-09-19 11:04:49 --> Database Driver Class Initialized
INFO - 2016-09-19 11:04:49 --> Database Driver Class Initialized
INFO - 2016-09-19 11:04:49 --> Database Driver Class Initialized
INFO - 2016-09-19 11:04:49 --> Database Driver Class Initialized
INFO - 2016-09-19 11:04:49 --> Database Driver Class Initialized
INFO - 2016-09-19 11:04:49 --> Database Driver Class Initialized
INFO - 2016-09-19 11:04:49 --> Database Driver Class Initialized
INFO - 2016-09-19 11:04:50 --> Database Driver Class Initialized
INFO - 2016-09-19 11:04:50 --> Final output sent to browser
DEBUG - 2016-09-19 11:04:50 --> Total execution time: 3.0056
INFO - 2016-09-19 11:05:14 --> Config Class Initialized
INFO - 2016-09-19 11:05:14 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:05:14 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:05:14 --> Utf8 Class Initialized
INFO - 2016-09-19 11:05:14 --> URI Class Initialized
INFO - 2016-09-19 11:05:14 --> Router Class Initialized
INFO - 2016-09-19 11:05:15 --> Output Class Initialized
INFO - 2016-09-19 11:05:15 --> Security Class Initialized
DEBUG - 2016-09-19 11:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:05:15 --> Input Class Initialized
INFO - 2016-09-19 11:05:15 --> Language Class Initialized
INFO - 2016-09-19 11:05:15 --> Language Class Initialized
INFO - 2016-09-19 11:05:15 --> Config Class Initialized
INFO - 2016-09-19 11:05:15 --> Loader Class Initialized
INFO - 2016-09-19 11:05:15 --> Helper loaded: url_helper
INFO - 2016-09-19 11:05:15 --> Database Driver Class Initialized
INFO - 2016-09-19 11:05:15 --> Controller Class Initialized
DEBUG - 2016-09-19 11:05:15 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:05:15 --> Model Class Initialized
INFO - 2016-09-19 11:05:15 --> Model Class Initialized
DEBUG - 2016-09-19 11:05:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 11:05:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 11:05:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 11:05:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-19 11:05:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 11:05:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 11:05:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 11:05:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 11:05:15 --> Final output sent to browser
DEBUG - 2016-09-19 11:05:15 --> Total execution time: 1.1424
INFO - 2016-09-19 11:05:20 --> Config Class Initialized
INFO - 2016-09-19 11:05:20 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:05:20 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:05:20 --> Utf8 Class Initialized
INFO - 2016-09-19 11:05:20 --> URI Class Initialized
INFO - 2016-09-19 11:05:20 --> Router Class Initialized
INFO - 2016-09-19 11:05:20 --> Output Class Initialized
INFO - 2016-09-19 11:05:20 --> Security Class Initialized
DEBUG - 2016-09-19 11:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:05:20 --> Input Class Initialized
INFO - 2016-09-19 11:05:20 --> Language Class Initialized
INFO - 2016-09-19 11:05:20 --> Language Class Initialized
INFO - 2016-09-19 11:05:20 --> Config Class Initialized
INFO - 2016-09-19 11:05:20 --> Loader Class Initialized
INFO - 2016-09-19 11:05:21 --> Helper loaded: url_helper
INFO - 2016-09-19 11:05:21 --> Database Driver Class Initialized
INFO - 2016-09-19 11:05:21 --> Controller Class Initialized
DEBUG - 2016-09-19 11:05:21 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:05:21 --> Model Class Initialized
INFO - 2016-09-19 11:05:21 --> Model Class Initialized
DEBUG - 2016-09-19 11:05:21 --> Anggota MX_Controller Initialized
INFO - 2016-09-19 11:05:21 --> Database Driver Class Initialized
INFO - 2016-09-19 11:05:21 --> Final output sent to browser
DEBUG - 2016-09-19 11:05:21 --> Total execution time: 0.8930
INFO - 2016-09-19 11:05:22 --> Config Class Initialized
INFO - 2016-09-19 11:05:22 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:05:22 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:05:22 --> Utf8 Class Initialized
INFO - 2016-09-19 11:05:22 --> URI Class Initialized
INFO - 2016-09-19 11:05:22 --> Router Class Initialized
INFO - 2016-09-19 11:05:22 --> Output Class Initialized
INFO - 2016-09-19 11:05:22 --> Security Class Initialized
DEBUG - 2016-09-19 11:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:05:22 --> Input Class Initialized
INFO - 2016-09-19 11:05:22 --> Language Class Initialized
INFO - 2016-09-19 11:05:22 --> Language Class Initialized
INFO - 2016-09-19 11:05:22 --> Config Class Initialized
INFO - 2016-09-19 11:05:22 --> Loader Class Initialized
INFO - 2016-09-19 11:05:22 --> Helper loaded: url_helper
INFO - 2016-09-19 11:05:22 --> Database Driver Class Initialized
INFO - 2016-09-19 11:05:22 --> Controller Class Initialized
DEBUG - 2016-09-19 11:05:23 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:05:23 --> Model Class Initialized
INFO - 2016-09-19 11:05:23 --> Model Class Initialized
DEBUG - 2016-09-19 11:05:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 11:05:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 11:05:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 11:05:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_umum.php
DEBUG - 2016-09-19 11:05:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 11:05:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 11:05:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 11:05:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 11:05:23 --> Final output sent to browser
DEBUG - 2016-09-19 11:05:23 --> Total execution time: 1.1732
INFO - 2016-09-19 11:05:36 --> Config Class Initialized
INFO - 2016-09-19 11:05:36 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:05:36 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:05:36 --> Utf8 Class Initialized
INFO - 2016-09-19 11:05:36 --> URI Class Initialized
INFO - 2016-09-19 11:05:36 --> Router Class Initialized
INFO - 2016-09-19 11:05:36 --> Output Class Initialized
INFO - 2016-09-19 11:05:36 --> Security Class Initialized
DEBUG - 2016-09-19 11:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:05:36 --> Input Class Initialized
INFO - 2016-09-19 11:05:36 --> Language Class Initialized
INFO - 2016-09-19 11:05:36 --> Language Class Initialized
INFO - 2016-09-19 11:05:36 --> Config Class Initialized
INFO - 2016-09-19 11:05:36 --> Loader Class Initialized
INFO - 2016-09-19 11:05:36 --> Helper loaded: url_helper
INFO - 2016-09-19 11:05:36 --> Database Driver Class Initialized
INFO - 2016-09-19 11:05:36 --> Controller Class Initialized
DEBUG - 2016-09-19 11:05:36 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:05:36 --> Model Class Initialized
INFO - 2016-09-19 11:05:36 --> Model Class Initialized
INFO - 2016-09-19 11:05:36 --> Database Driver Class Initialized
INFO - 2016-09-19 11:05:37 --> Final output sent to browser
DEBUG - 2016-09-19 11:05:37 --> Total execution time: 1.0376
INFO - 2016-09-19 11:05:40 --> Config Class Initialized
INFO - 2016-09-19 11:05:41 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:05:41 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:05:41 --> Utf8 Class Initialized
INFO - 2016-09-19 11:05:41 --> URI Class Initialized
INFO - 2016-09-19 11:05:41 --> Router Class Initialized
INFO - 2016-09-19 11:05:41 --> Output Class Initialized
INFO - 2016-09-19 11:05:41 --> Security Class Initialized
DEBUG - 2016-09-19 11:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:05:41 --> Input Class Initialized
INFO - 2016-09-19 11:05:41 --> Language Class Initialized
INFO - 2016-09-19 11:05:41 --> Language Class Initialized
INFO - 2016-09-19 11:05:41 --> Config Class Initialized
INFO - 2016-09-19 11:05:41 --> Loader Class Initialized
INFO - 2016-09-19 11:05:41 --> Helper loaded: url_helper
INFO - 2016-09-19 11:05:41 --> Database Driver Class Initialized
INFO - 2016-09-19 11:05:41 --> Controller Class Initialized
DEBUG - 2016-09-19 11:05:41 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:05:41 --> Model Class Initialized
INFO - 2016-09-19 11:05:41 --> Model Class Initialized
INFO - 2016-09-19 11:05:41 --> Database Driver Class Initialized
INFO - 2016-09-19 11:05:41 --> Final output sent to browser
DEBUG - 2016-09-19 11:05:42 --> Total execution time: 1.0316
INFO - 2016-09-19 11:05:48 --> Config Class Initialized
INFO - 2016-09-19 11:05:48 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:05:49 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:05:49 --> Utf8 Class Initialized
INFO - 2016-09-19 11:05:49 --> URI Class Initialized
INFO - 2016-09-19 11:05:49 --> Router Class Initialized
INFO - 2016-09-19 11:05:49 --> Output Class Initialized
INFO - 2016-09-19 11:05:49 --> Security Class Initialized
DEBUG - 2016-09-19 11:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:05:49 --> Input Class Initialized
INFO - 2016-09-19 11:05:49 --> Language Class Initialized
INFO - 2016-09-19 11:05:49 --> Language Class Initialized
INFO - 2016-09-19 11:05:49 --> Config Class Initialized
INFO - 2016-09-19 11:05:49 --> Loader Class Initialized
INFO - 2016-09-19 11:05:49 --> Helper loaded: url_helper
INFO - 2016-09-19 11:05:49 --> Database Driver Class Initialized
INFO - 2016-09-19 11:05:49 --> Controller Class Initialized
DEBUG - 2016-09-19 11:05:49 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:05:49 --> Model Class Initialized
INFO - 2016-09-19 11:05:49 --> Model Class Initialized
INFO - 2016-09-19 11:05:49 --> Database Driver Class Initialized
INFO - 2016-09-19 11:05:49 --> Database Driver Class Initialized
INFO - 2016-09-19 11:05:49 --> Final output sent to browser
DEBUG - 2016-09-19 11:05:50 --> Total execution time: 1.0538
INFO - 2016-09-19 11:05:56 --> Config Class Initialized
INFO - 2016-09-19 11:05:56 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:05:56 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:05:56 --> Utf8 Class Initialized
INFO - 2016-09-19 11:05:56 --> URI Class Initialized
INFO - 2016-09-19 11:05:56 --> Router Class Initialized
INFO - 2016-09-19 11:05:56 --> Output Class Initialized
INFO - 2016-09-19 11:05:56 --> Security Class Initialized
DEBUG - 2016-09-19 11:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:05:56 --> Input Class Initialized
INFO - 2016-09-19 11:05:56 --> Language Class Initialized
INFO - 2016-09-19 11:05:56 --> Language Class Initialized
INFO - 2016-09-19 11:05:57 --> Config Class Initialized
INFO - 2016-09-19 11:05:57 --> Loader Class Initialized
INFO - 2016-09-19 11:05:57 --> Helper loaded: url_helper
INFO - 2016-09-19 11:05:57 --> Database Driver Class Initialized
INFO - 2016-09-19 11:05:57 --> Controller Class Initialized
DEBUG - 2016-09-19 11:05:57 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:05:57 --> Model Class Initialized
INFO - 2016-09-19 11:05:57 --> Model Class Initialized
DEBUG - 2016-09-19 11:05:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 11:05:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 11:05:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 11:05:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_bayar_angsuran.php
DEBUG - 2016-09-19 11:05:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 11:05:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 11:05:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 11:05:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 11:05:57 --> Final output sent to browser
DEBUG - 2016-09-19 11:05:57 --> Total execution time: 1.1211
INFO - 2016-09-19 11:06:01 --> Config Class Initialized
INFO - 2016-09-19 11:06:01 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:06:01 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:06:01 --> Utf8 Class Initialized
INFO - 2016-09-19 11:06:01 --> URI Class Initialized
INFO - 2016-09-19 11:06:01 --> Router Class Initialized
INFO - 2016-09-19 11:06:01 --> Output Class Initialized
INFO - 2016-09-19 11:06:01 --> Security Class Initialized
DEBUG - 2016-09-19 11:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:06:01 --> Input Class Initialized
INFO - 2016-09-19 11:06:01 --> Language Class Initialized
INFO - 2016-09-19 11:06:02 --> Language Class Initialized
INFO - 2016-09-19 11:06:02 --> Config Class Initialized
INFO - 2016-09-19 11:06:02 --> Loader Class Initialized
INFO - 2016-09-19 11:06:02 --> Helper loaded: url_helper
INFO - 2016-09-19 11:06:02 --> Database Driver Class Initialized
INFO - 2016-09-19 11:06:02 --> Controller Class Initialized
DEBUG - 2016-09-19 11:06:02 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:06:02 --> Model Class Initialized
INFO - 2016-09-19 11:06:02 --> Model Class Initialized
DEBUG - 2016-09-19 11:06:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 11:06:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 11:06:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 11:06:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tutup_angsuran.php
DEBUG - 2016-09-19 11:06:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 11:06:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 11:06:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 11:06:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 11:06:02 --> Final output sent to browser
DEBUG - 2016-09-19 11:06:02 --> Total execution time: 1.2402
INFO - 2016-09-19 11:06:09 --> Config Class Initialized
INFO - 2016-09-19 11:06:10 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:06:10 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:06:10 --> Utf8 Class Initialized
INFO - 2016-09-19 11:06:10 --> URI Class Initialized
INFO - 2016-09-19 11:06:10 --> Router Class Initialized
INFO - 2016-09-19 11:06:10 --> Output Class Initialized
INFO - 2016-09-19 11:06:10 --> Security Class Initialized
DEBUG - 2016-09-19 11:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:06:10 --> Input Class Initialized
INFO - 2016-09-19 11:06:10 --> Language Class Initialized
INFO - 2016-09-19 11:06:10 --> Language Class Initialized
INFO - 2016-09-19 11:06:10 --> Config Class Initialized
INFO - 2016-09-19 11:06:10 --> Loader Class Initialized
INFO - 2016-09-19 11:06:10 --> Helper loaded: url_helper
INFO - 2016-09-19 11:06:10 --> Database Driver Class Initialized
INFO - 2016-09-19 11:06:10 --> Controller Class Initialized
DEBUG - 2016-09-19 11:06:10 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:06:10 --> Model Class Initialized
INFO - 2016-09-19 11:06:10 --> Model Class Initialized
DEBUG - 2016-09-19 11:06:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 11:06:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 11:06:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 11:06:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_bayar_angsuran.php
DEBUG - 2016-09-19 11:06:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 11:06:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 11:06:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 11:06:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 11:06:11 --> Final output sent to browser
DEBUG - 2016-09-19 11:06:11 --> Total execution time: 1.2045
INFO - 2016-09-19 11:06:14 --> Config Class Initialized
INFO - 2016-09-19 11:06:14 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:06:15 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:06:15 --> Utf8 Class Initialized
INFO - 2016-09-19 11:06:15 --> URI Class Initialized
INFO - 2016-09-19 11:06:15 --> Router Class Initialized
INFO - 2016-09-19 11:06:15 --> Output Class Initialized
INFO - 2016-09-19 11:06:15 --> Security Class Initialized
DEBUG - 2016-09-19 11:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:06:15 --> Input Class Initialized
INFO - 2016-09-19 11:06:15 --> Language Class Initialized
INFO - 2016-09-19 11:06:15 --> Language Class Initialized
INFO - 2016-09-19 11:06:15 --> Config Class Initialized
INFO - 2016-09-19 11:06:15 --> Loader Class Initialized
INFO - 2016-09-19 11:06:15 --> Helper loaded: url_helper
INFO - 2016-09-19 11:06:15 --> Database Driver Class Initialized
INFO - 2016-09-19 11:06:15 --> Controller Class Initialized
DEBUG - 2016-09-19 11:06:15 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:06:15 --> Model Class Initialized
INFO - 2016-09-19 11:06:15 --> Model Class Initialized
INFO - 2016-09-19 11:06:15 --> Database Driver Class Initialized
INFO - 2016-09-19 11:06:15 --> Final output sent to browser
DEBUG - 2016-09-19 11:06:15 --> Total execution time: 0.9571
INFO - 2016-09-19 11:06:21 --> Config Class Initialized
INFO - 2016-09-19 11:06:21 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:06:21 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:06:22 --> Utf8 Class Initialized
INFO - 2016-09-19 11:06:22 --> URI Class Initialized
INFO - 2016-09-19 11:06:22 --> Router Class Initialized
INFO - 2016-09-19 11:06:22 --> Output Class Initialized
INFO - 2016-09-19 11:06:22 --> Security Class Initialized
DEBUG - 2016-09-19 11:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:06:22 --> Input Class Initialized
INFO - 2016-09-19 11:06:22 --> Language Class Initialized
INFO - 2016-09-19 11:06:22 --> Language Class Initialized
INFO - 2016-09-19 11:06:22 --> Config Class Initialized
INFO - 2016-09-19 11:06:22 --> Loader Class Initialized
INFO - 2016-09-19 11:06:22 --> Helper loaded: url_helper
INFO - 2016-09-19 11:06:22 --> Database Driver Class Initialized
INFO - 2016-09-19 11:06:22 --> Controller Class Initialized
DEBUG - 2016-09-19 11:06:22 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:06:22 --> Model Class Initialized
INFO - 2016-09-19 11:06:22 --> Model Class Initialized
INFO - 2016-09-19 11:06:22 --> Database Driver Class Initialized
INFO - 2016-09-19 11:06:22 --> Database Driver Class Initialized
INFO - 2016-09-19 11:06:22 --> Database Driver Class Initialized
INFO - 2016-09-19 11:06:23 --> Database Driver Class Initialized
INFO - 2016-09-19 11:06:23 --> Database Driver Class Initialized
INFO - 2016-09-19 11:06:23 --> Final output sent to browser
DEBUG - 2016-09-19 11:06:23 --> Total execution time: 1.3672
INFO - 2016-09-19 11:06:24 --> Config Class Initialized
INFO - 2016-09-19 11:06:24 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:06:24 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:06:24 --> Utf8 Class Initialized
INFO - 2016-09-19 11:06:24 --> URI Class Initialized
INFO - 2016-09-19 11:06:25 --> Router Class Initialized
INFO - 2016-09-19 11:06:25 --> Output Class Initialized
INFO - 2016-09-19 11:06:25 --> Security Class Initialized
DEBUG - 2016-09-19 11:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:06:25 --> Input Class Initialized
INFO - 2016-09-19 11:06:25 --> Language Class Initialized
INFO - 2016-09-19 11:06:25 --> Language Class Initialized
INFO - 2016-09-19 11:06:25 --> Config Class Initialized
INFO - 2016-09-19 11:06:25 --> Loader Class Initialized
INFO - 2016-09-19 11:06:25 --> Helper loaded: url_helper
INFO - 2016-09-19 11:06:25 --> Database Driver Class Initialized
INFO - 2016-09-19 11:06:25 --> Controller Class Initialized
DEBUG - 2016-09-19 11:06:25 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:06:25 --> Model Class Initialized
INFO - 2016-09-19 11:06:25 --> Model Class Initialized
INFO - 2016-09-19 11:06:25 --> Database Driver Class Initialized
INFO - 2016-09-19 11:06:25 --> Final output sent to browser
DEBUG - 2016-09-19 11:06:25 --> Total execution time: 1.0084
INFO - 2016-09-19 11:06:27 --> Config Class Initialized
INFO - 2016-09-19 11:06:27 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:06:27 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:06:27 --> Utf8 Class Initialized
INFO - 2016-09-19 11:06:27 --> URI Class Initialized
INFO - 2016-09-19 11:06:27 --> Router Class Initialized
INFO - 2016-09-19 11:06:27 --> Output Class Initialized
INFO - 2016-09-19 11:06:27 --> Security Class Initialized
DEBUG - 2016-09-19 11:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:06:27 --> Input Class Initialized
INFO - 2016-09-19 11:06:27 --> Language Class Initialized
INFO - 2016-09-19 11:06:27 --> Language Class Initialized
INFO - 2016-09-19 11:06:27 --> Config Class Initialized
INFO - 2016-09-19 11:06:27 --> Loader Class Initialized
INFO - 2016-09-19 11:06:27 --> Helper loaded: url_helper
INFO - 2016-09-19 11:06:27 --> Database Driver Class Initialized
INFO - 2016-09-19 11:06:27 --> Controller Class Initialized
DEBUG - 2016-09-19 11:06:28 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:06:28 --> Model Class Initialized
INFO - 2016-09-19 11:06:28 --> Model Class Initialized
INFO - 2016-09-19 11:06:28 --> Database Driver Class Initialized
INFO - 2016-09-19 11:06:28 --> Database Driver Class Initialized
INFO - 2016-09-19 11:06:28 --> Database Driver Class Initialized
INFO - 2016-09-19 11:06:28 --> Database Driver Class Initialized
INFO - 2016-09-19 11:06:28 --> Database Driver Class Initialized
INFO - 2016-09-19 11:06:28 --> Final output sent to browser
DEBUG - 2016-09-19 11:06:28 --> Total execution time: 1.4424
INFO - 2016-09-19 11:06:30 --> Config Class Initialized
INFO - 2016-09-19 11:06:30 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:06:30 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:06:30 --> Utf8 Class Initialized
INFO - 2016-09-19 11:06:30 --> URI Class Initialized
INFO - 2016-09-19 11:06:30 --> Router Class Initialized
INFO - 2016-09-19 11:06:30 --> Output Class Initialized
INFO - 2016-09-19 11:06:30 --> Security Class Initialized
DEBUG - 2016-09-19 11:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:06:30 --> Input Class Initialized
INFO - 2016-09-19 11:06:30 --> Language Class Initialized
INFO - 2016-09-19 11:06:30 --> Language Class Initialized
INFO - 2016-09-19 11:06:30 --> Config Class Initialized
INFO - 2016-09-19 11:06:30 --> Loader Class Initialized
INFO - 2016-09-19 11:06:30 --> Helper loaded: url_helper
INFO - 2016-09-19 11:06:30 --> Database Driver Class Initialized
INFO - 2016-09-19 11:06:30 --> Controller Class Initialized
DEBUG - 2016-09-19 11:06:30 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:06:30 --> Model Class Initialized
INFO - 2016-09-19 11:06:30 --> Model Class Initialized
INFO - 2016-09-19 11:06:30 --> Database Driver Class Initialized
INFO - 2016-09-19 11:06:30 --> Final output sent to browser
DEBUG - 2016-09-19 11:06:31 --> Total execution time: 0.9976
INFO - 2016-09-19 11:06:32 --> Config Class Initialized
INFO - 2016-09-19 11:06:32 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:06:32 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:06:32 --> Utf8 Class Initialized
INFO - 2016-09-19 11:06:32 --> URI Class Initialized
INFO - 2016-09-19 11:06:32 --> Router Class Initialized
INFO - 2016-09-19 11:06:32 --> Output Class Initialized
INFO - 2016-09-19 11:06:32 --> Security Class Initialized
DEBUG - 2016-09-19 11:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:06:32 --> Input Class Initialized
INFO - 2016-09-19 11:06:32 --> Language Class Initialized
INFO - 2016-09-19 11:06:32 --> Language Class Initialized
INFO - 2016-09-19 11:06:33 --> Config Class Initialized
INFO - 2016-09-19 11:06:33 --> Loader Class Initialized
INFO - 2016-09-19 11:06:33 --> Helper loaded: url_helper
INFO - 2016-09-19 11:06:33 --> Database Driver Class Initialized
INFO - 2016-09-19 11:06:33 --> Controller Class Initialized
DEBUG - 2016-09-19 11:06:33 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:06:33 --> Model Class Initialized
INFO - 2016-09-19 11:06:33 --> Model Class Initialized
INFO - 2016-09-19 11:06:33 --> Database Driver Class Initialized
INFO - 2016-09-19 11:06:33 --> Database Driver Class Initialized
INFO - 2016-09-19 11:06:33 --> Database Driver Class Initialized
INFO - 2016-09-19 11:06:33 --> Database Driver Class Initialized
INFO - 2016-09-19 11:06:33 --> Database Driver Class Initialized
INFO - 2016-09-19 11:06:33 --> Final output sent to browser
DEBUG - 2016-09-19 11:06:33 --> Total execution time: 1.4982
INFO - 2016-09-19 11:06:35 --> Config Class Initialized
INFO - 2016-09-19 11:06:35 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:06:35 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:06:35 --> Utf8 Class Initialized
INFO - 2016-09-19 11:06:35 --> URI Class Initialized
INFO - 2016-09-19 11:06:35 --> Router Class Initialized
INFO - 2016-09-19 11:06:35 --> Output Class Initialized
INFO - 2016-09-19 11:06:35 --> Security Class Initialized
DEBUG - 2016-09-19 11:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:06:35 --> Input Class Initialized
INFO - 2016-09-19 11:06:35 --> Language Class Initialized
INFO - 2016-09-19 11:06:35 --> Language Class Initialized
INFO - 2016-09-19 11:06:35 --> Config Class Initialized
INFO - 2016-09-19 11:06:35 --> Loader Class Initialized
INFO - 2016-09-19 11:06:35 --> Helper loaded: url_helper
INFO - 2016-09-19 11:06:35 --> Database Driver Class Initialized
INFO - 2016-09-19 11:06:35 --> Controller Class Initialized
DEBUG - 2016-09-19 11:06:35 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:06:35 --> Model Class Initialized
INFO - 2016-09-19 11:06:35 --> Model Class Initialized
INFO - 2016-09-19 11:06:36 --> Database Driver Class Initialized
INFO - 2016-09-19 11:06:36 --> Final output sent to browser
DEBUG - 2016-09-19 11:06:36 --> Total execution time: 1.0433
INFO - 2016-09-19 11:06:37 --> Config Class Initialized
INFO - 2016-09-19 11:06:37 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:06:37 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:06:37 --> Utf8 Class Initialized
INFO - 2016-09-19 11:06:37 --> URI Class Initialized
INFO - 2016-09-19 11:06:37 --> Router Class Initialized
INFO - 2016-09-19 11:06:37 --> Output Class Initialized
INFO - 2016-09-19 11:06:37 --> Security Class Initialized
DEBUG - 2016-09-19 11:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:06:37 --> Input Class Initialized
INFO - 2016-09-19 11:06:37 --> Language Class Initialized
INFO - 2016-09-19 11:06:37 --> Language Class Initialized
INFO - 2016-09-19 11:06:37 --> Config Class Initialized
INFO - 2016-09-19 11:06:37 --> Loader Class Initialized
INFO - 2016-09-19 11:06:38 --> Helper loaded: url_helper
INFO - 2016-09-19 11:06:38 --> Database Driver Class Initialized
INFO - 2016-09-19 11:06:38 --> Controller Class Initialized
DEBUG - 2016-09-19 11:06:38 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:06:38 --> Model Class Initialized
INFO - 2016-09-19 11:06:38 --> Model Class Initialized
INFO - 2016-09-19 11:06:38 --> Database Driver Class Initialized
INFO - 2016-09-19 11:06:38 --> Database Driver Class Initialized
INFO - 2016-09-19 11:06:38 --> Database Driver Class Initialized
INFO - 2016-09-19 11:06:38 --> Database Driver Class Initialized
INFO - 2016-09-19 11:06:38 --> Database Driver Class Initialized
INFO - 2016-09-19 11:06:38 --> Final output sent to browser
DEBUG - 2016-09-19 11:06:38 --> Total execution time: 1.4766
INFO - 2016-09-19 11:06:40 --> Config Class Initialized
INFO - 2016-09-19 11:06:40 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:06:40 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:06:40 --> Utf8 Class Initialized
INFO - 2016-09-19 11:06:40 --> URI Class Initialized
INFO - 2016-09-19 11:06:40 --> Router Class Initialized
INFO - 2016-09-19 11:06:40 --> Output Class Initialized
INFO - 2016-09-19 11:06:40 --> Security Class Initialized
DEBUG - 2016-09-19 11:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:06:40 --> Input Class Initialized
INFO - 2016-09-19 11:06:40 --> Language Class Initialized
INFO - 2016-09-19 11:06:40 --> Language Class Initialized
INFO - 2016-09-19 11:06:40 --> Config Class Initialized
INFO - 2016-09-19 11:06:40 --> Loader Class Initialized
INFO - 2016-09-19 11:06:40 --> Helper loaded: url_helper
INFO - 2016-09-19 11:06:40 --> Database Driver Class Initialized
INFO - 2016-09-19 11:06:40 --> Controller Class Initialized
DEBUG - 2016-09-19 11:06:40 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:06:40 --> Model Class Initialized
INFO - 2016-09-19 11:06:40 --> Model Class Initialized
INFO - 2016-09-19 11:06:41 --> Database Driver Class Initialized
INFO - 2016-09-19 11:06:41 --> Final output sent to browser
DEBUG - 2016-09-19 11:06:41 --> Total execution time: 0.9837
INFO - 2016-09-19 11:06:42 --> Config Class Initialized
INFO - 2016-09-19 11:06:42 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:06:42 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:06:42 --> Utf8 Class Initialized
INFO - 2016-09-19 11:06:42 --> URI Class Initialized
INFO - 2016-09-19 11:06:42 --> Router Class Initialized
INFO - 2016-09-19 11:06:42 --> Output Class Initialized
INFO - 2016-09-19 11:06:42 --> Security Class Initialized
DEBUG - 2016-09-19 11:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:06:42 --> Input Class Initialized
INFO - 2016-09-19 11:06:42 --> Language Class Initialized
INFO - 2016-09-19 11:06:42 --> Language Class Initialized
INFO - 2016-09-19 11:06:42 --> Config Class Initialized
INFO - 2016-09-19 11:06:42 --> Loader Class Initialized
INFO - 2016-09-19 11:06:42 --> Helper loaded: url_helper
INFO - 2016-09-19 11:06:42 --> Database Driver Class Initialized
INFO - 2016-09-19 11:06:43 --> Controller Class Initialized
DEBUG - 2016-09-19 11:06:43 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:06:43 --> Model Class Initialized
INFO - 2016-09-19 11:06:43 --> Model Class Initialized
INFO - 2016-09-19 11:06:43 --> Database Driver Class Initialized
INFO - 2016-09-19 11:06:43 --> Database Driver Class Initialized
INFO - 2016-09-19 11:06:43 --> Database Driver Class Initialized
INFO - 2016-09-19 11:06:43 --> Database Driver Class Initialized
INFO - 2016-09-19 11:06:43 --> Database Driver Class Initialized
INFO - 2016-09-19 11:06:43 --> Final output sent to browser
DEBUG - 2016-09-19 11:06:43 --> Total execution time: 1.5911
INFO - 2016-09-19 11:06:44 --> Config Class Initialized
INFO - 2016-09-19 11:06:44 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:06:44 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:06:44 --> Utf8 Class Initialized
INFO - 2016-09-19 11:06:44 --> URI Class Initialized
INFO - 2016-09-19 11:06:44 --> Router Class Initialized
INFO - 2016-09-19 11:06:44 --> Output Class Initialized
INFO - 2016-09-19 11:06:44 --> Security Class Initialized
DEBUG - 2016-09-19 11:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:06:45 --> Input Class Initialized
INFO - 2016-09-19 11:06:45 --> Language Class Initialized
INFO - 2016-09-19 11:06:45 --> Language Class Initialized
INFO - 2016-09-19 11:06:45 --> Config Class Initialized
INFO - 2016-09-19 11:06:45 --> Loader Class Initialized
INFO - 2016-09-19 11:06:45 --> Helper loaded: url_helper
INFO - 2016-09-19 11:06:45 --> Database Driver Class Initialized
INFO - 2016-09-19 11:06:45 --> Controller Class Initialized
DEBUG - 2016-09-19 11:06:45 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:06:45 --> Model Class Initialized
INFO - 2016-09-19 11:06:45 --> Model Class Initialized
INFO - 2016-09-19 11:06:45 --> Database Driver Class Initialized
INFO - 2016-09-19 11:06:45 --> Final output sent to browser
DEBUG - 2016-09-19 11:06:45 --> Total execution time: 0.9746
INFO - 2016-09-19 11:06:46 --> Config Class Initialized
INFO - 2016-09-19 11:06:46 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:06:46 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:06:46 --> Utf8 Class Initialized
INFO - 2016-09-19 11:06:46 --> URI Class Initialized
INFO - 2016-09-19 11:06:46 --> Router Class Initialized
INFO - 2016-09-19 11:06:46 --> Output Class Initialized
INFO - 2016-09-19 11:06:46 --> Security Class Initialized
DEBUG - 2016-09-19 11:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:06:47 --> Input Class Initialized
INFO - 2016-09-19 11:06:47 --> Language Class Initialized
INFO - 2016-09-19 11:06:47 --> Language Class Initialized
INFO - 2016-09-19 11:06:47 --> Config Class Initialized
INFO - 2016-09-19 11:06:47 --> Loader Class Initialized
INFO - 2016-09-19 11:06:47 --> Helper loaded: url_helper
INFO - 2016-09-19 11:06:47 --> Database Driver Class Initialized
INFO - 2016-09-19 11:06:47 --> Controller Class Initialized
DEBUG - 2016-09-19 11:06:47 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:06:47 --> Model Class Initialized
INFO - 2016-09-19 11:06:47 --> Model Class Initialized
INFO - 2016-09-19 11:06:47 --> Database Driver Class Initialized
INFO - 2016-09-19 11:06:47 --> Database Driver Class Initialized
INFO - 2016-09-19 11:06:47 --> Database Driver Class Initialized
INFO - 2016-09-19 11:06:47 --> Database Driver Class Initialized
INFO - 2016-09-19 11:06:47 --> Database Driver Class Initialized
INFO - 2016-09-19 11:06:48 --> Final output sent to browser
DEBUG - 2016-09-19 11:06:48 --> Total execution time: 1.4095
INFO - 2016-09-19 11:06:49 --> Config Class Initialized
INFO - 2016-09-19 11:06:49 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:06:49 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:06:49 --> Utf8 Class Initialized
INFO - 2016-09-19 11:06:50 --> URI Class Initialized
INFO - 2016-09-19 11:06:50 --> Router Class Initialized
INFO - 2016-09-19 11:06:50 --> Output Class Initialized
INFO - 2016-09-19 11:06:50 --> Security Class Initialized
DEBUG - 2016-09-19 11:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:06:50 --> Input Class Initialized
INFO - 2016-09-19 11:06:50 --> Language Class Initialized
INFO - 2016-09-19 11:06:50 --> Language Class Initialized
INFO - 2016-09-19 11:06:50 --> Config Class Initialized
INFO - 2016-09-19 11:06:50 --> Loader Class Initialized
INFO - 2016-09-19 11:06:50 --> Helper loaded: url_helper
INFO - 2016-09-19 11:06:50 --> Database Driver Class Initialized
INFO - 2016-09-19 11:06:50 --> Controller Class Initialized
DEBUG - 2016-09-19 11:06:50 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:06:50 --> Model Class Initialized
INFO - 2016-09-19 11:06:50 --> Model Class Initialized
INFO - 2016-09-19 11:06:50 --> Database Driver Class Initialized
INFO - 2016-09-19 11:06:50 --> Final output sent to browser
DEBUG - 2016-09-19 11:06:50 --> Total execution time: 1.0060
INFO - 2016-09-19 11:07:00 --> Config Class Initialized
INFO - 2016-09-19 11:07:00 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:07:00 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:07:00 --> Utf8 Class Initialized
INFO - 2016-09-19 11:07:00 --> URI Class Initialized
INFO - 2016-09-19 11:07:00 --> Router Class Initialized
INFO - 2016-09-19 11:07:00 --> Output Class Initialized
INFO - 2016-09-19 11:07:00 --> Security Class Initialized
DEBUG - 2016-09-19 11:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:07:00 --> Input Class Initialized
INFO - 2016-09-19 11:07:00 --> Language Class Initialized
INFO - 2016-09-19 11:07:00 --> Language Class Initialized
INFO - 2016-09-19 11:07:00 --> Config Class Initialized
INFO - 2016-09-19 11:07:00 --> Loader Class Initialized
INFO - 2016-09-19 11:07:00 --> Helper loaded: url_helper
INFO - 2016-09-19 11:07:01 --> Database Driver Class Initialized
INFO - 2016-09-19 11:07:01 --> Controller Class Initialized
DEBUG - 2016-09-19 11:07:01 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:07:01 --> Model Class Initialized
INFO - 2016-09-19 11:07:01 --> Model Class Initialized
DEBUG - 2016-09-19 11:07:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 11:07:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 11:07:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 11:07:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/buku_besar.php
DEBUG - 2016-09-19 11:07:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 11:07:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 11:07:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 11:07:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 11:07:01 --> Final output sent to browser
DEBUG - 2016-09-19 11:07:01 --> Total execution time: 1.2165
INFO - 2016-09-19 11:07:13 --> Config Class Initialized
INFO - 2016-09-19 11:07:13 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:07:13 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:07:13 --> Utf8 Class Initialized
INFO - 2016-09-19 11:07:13 --> URI Class Initialized
INFO - 2016-09-19 11:07:13 --> Router Class Initialized
INFO - 2016-09-19 11:07:13 --> Output Class Initialized
INFO - 2016-09-19 11:07:13 --> Security Class Initialized
DEBUG - 2016-09-19 11:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:07:13 --> Input Class Initialized
INFO - 2016-09-19 11:07:13 --> Language Class Initialized
INFO - 2016-09-19 11:07:13 --> Language Class Initialized
INFO - 2016-09-19 11:07:13 --> Config Class Initialized
INFO - 2016-09-19 11:07:13 --> Loader Class Initialized
INFO - 2016-09-19 11:07:13 --> Helper loaded: url_helper
INFO - 2016-09-19 11:07:13 --> Database Driver Class Initialized
INFO - 2016-09-19 11:07:13 --> Controller Class Initialized
DEBUG - 2016-09-19 11:07:13 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:07:13 --> Model Class Initialized
INFO - 2016-09-19 11:07:14 --> Model Class Initialized
DEBUG - 2016-09-19 11:07:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_buku_besar.php
INFO - 2016-09-19 11:07:14 --> Final output sent to browser
DEBUG - 2016-09-19 11:07:14 --> Total execution time: 0.9208
INFO - 2016-09-19 11:07:21 --> Config Class Initialized
INFO - 2016-09-19 11:07:21 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:07:21 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:07:21 --> Utf8 Class Initialized
INFO - 2016-09-19 11:07:22 --> URI Class Initialized
INFO - 2016-09-19 11:07:22 --> Router Class Initialized
INFO - 2016-09-19 11:07:22 --> Output Class Initialized
INFO - 2016-09-19 11:07:22 --> Security Class Initialized
DEBUG - 2016-09-19 11:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:07:22 --> Input Class Initialized
INFO - 2016-09-19 11:07:22 --> Language Class Initialized
INFO - 2016-09-19 11:07:22 --> Language Class Initialized
INFO - 2016-09-19 11:07:22 --> Config Class Initialized
INFO - 2016-09-19 11:07:22 --> Loader Class Initialized
INFO - 2016-09-19 11:07:22 --> Helper loaded: url_helper
INFO - 2016-09-19 11:07:22 --> Database Driver Class Initialized
INFO - 2016-09-19 11:07:22 --> Controller Class Initialized
DEBUG - 2016-09-19 11:07:22 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:07:22 --> Model Class Initialized
INFO - 2016-09-19 11:07:22 --> Model Class Initialized
DEBUG - 2016-09-19 11:07:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 11:07:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 11:07:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 11:07:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/jurnal_umum.php
DEBUG - 2016-09-19 11:07:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 11:07:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 11:07:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 11:07:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 11:07:23 --> Final output sent to browser
DEBUG - 2016-09-19 11:07:23 --> Total execution time: 1.3570
INFO - 2016-09-19 11:07:30 --> Config Class Initialized
INFO - 2016-09-19 11:07:30 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:07:30 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:07:30 --> Utf8 Class Initialized
INFO - 2016-09-19 11:07:30 --> URI Class Initialized
INFO - 2016-09-19 11:07:30 --> Router Class Initialized
INFO - 2016-09-19 11:07:30 --> Output Class Initialized
INFO - 2016-09-19 11:07:30 --> Security Class Initialized
DEBUG - 2016-09-19 11:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:07:30 --> Input Class Initialized
INFO - 2016-09-19 11:07:30 --> Language Class Initialized
INFO - 2016-09-19 11:07:30 --> Language Class Initialized
INFO - 2016-09-19 11:07:30 --> Config Class Initialized
INFO - 2016-09-19 11:07:31 --> Loader Class Initialized
INFO - 2016-09-19 11:07:31 --> Helper loaded: url_helper
INFO - 2016-09-19 11:07:31 --> Database Driver Class Initialized
INFO - 2016-09-19 11:07:31 --> Controller Class Initialized
DEBUG - 2016-09-19 11:07:31 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:07:31 --> Model Class Initialized
INFO - 2016-09-19 11:07:31 --> Model Class Initialized
DEBUG - 2016-09-19 11:07:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_jurnal_umum.php
INFO - 2016-09-19 11:07:31 --> Final output sent to browser
DEBUG - 2016-09-19 11:07:31 --> Total execution time: 0.8425
INFO - 2016-09-19 11:08:49 --> Config Class Initialized
INFO - 2016-09-19 11:08:49 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:08:49 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:08:49 --> Utf8 Class Initialized
INFO - 2016-09-19 11:08:49 --> URI Class Initialized
INFO - 2016-09-19 11:08:49 --> Router Class Initialized
INFO - 2016-09-19 11:08:49 --> Output Class Initialized
INFO - 2016-09-19 11:08:49 --> Security Class Initialized
DEBUG - 2016-09-19 11:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:08:49 --> Input Class Initialized
INFO - 2016-09-19 11:08:49 --> Language Class Initialized
INFO - 2016-09-19 11:08:49 --> Language Class Initialized
INFO - 2016-09-19 11:08:49 --> Config Class Initialized
INFO - 2016-09-19 11:08:49 --> Loader Class Initialized
INFO - 2016-09-19 11:08:49 --> Helper loaded: url_helper
INFO - 2016-09-19 11:08:49 --> Database Driver Class Initialized
INFO - 2016-09-19 11:08:50 --> Controller Class Initialized
DEBUG - 2016-09-19 11:08:50 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:08:50 --> Model Class Initialized
INFO - 2016-09-19 11:08:50 --> Model Class Initialized
DEBUG - 2016-09-19 11:08:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 11:08:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 11:08:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 11:08:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tabungan.php
DEBUG - 2016-09-19 11:08:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 11:08:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 11:08:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 11:08:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 11:08:50 --> Final output sent to browser
DEBUG - 2016-09-19 11:08:50 --> Total execution time: 1.5043
INFO - 2016-09-19 11:14:29 --> Config Class Initialized
INFO - 2016-09-19 11:14:30 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:14:30 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:14:30 --> Utf8 Class Initialized
INFO - 2016-09-19 11:14:30 --> URI Class Initialized
INFO - 2016-09-19 11:14:30 --> Router Class Initialized
INFO - 2016-09-19 11:14:30 --> Output Class Initialized
INFO - 2016-09-19 11:14:30 --> Security Class Initialized
DEBUG - 2016-09-19 11:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:14:30 --> Input Class Initialized
INFO - 2016-09-19 11:14:30 --> Language Class Initialized
INFO - 2016-09-19 11:14:30 --> Language Class Initialized
INFO - 2016-09-19 11:14:30 --> Config Class Initialized
INFO - 2016-09-19 11:14:30 --> Loader Class Initialized
INFO - 2016-09-19 11:14:30 --> Helper loaded: url_helper
INFO - 2016-09-19 11:14:30 --> Database Driver Class Initialized
INFO - 2016-09-19 11:14:30 --> Controller Class Initialized
DEBUG - 2016-09-19 11:14:30 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:14:30 --> Model Class Initialized
INFO - 2016-09-19 11:14:30 --> Model Class Initialized
INFO - 2016-09-19 11:14:30 --> Final output sent to browser
DEBUG - 2016-09-19 11:14:30 --> Total execution time: 0.8713
INFO - 2016-09-19 11:14:37 --> Config Class Initialized
INFO - 2016-09-19 11:14:38 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:14:38 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:14:38 --> Utf8 Class Initialized
INFO - 2016-09-19 11:14:38 --> URI Class Initialized
INFO - 2016-09-19 11:14:38 --> Router Class Initialized
INFO - 2016-09-19 11:14:38 --> Output Class Initialized
INFO - 2016-09-19 11:14:38 --> Security Class Initialized
DEBUG - 2016-09-19 11:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:14:38 --> Input Class Initialized
INFO - 2016-09-19 11:14:38 --> Language Class Initialized
INFO - 2016-09-19 11:14:38 --> Language Class Initialized
INFO - 2016-09-19 11:14:38 --> Config Class Initialized
INFO - 2016-09-19 11:14:38 --> Loader Class Initialized
INFO - 2016-09-19 11:14:38 --> Helper loaded: url_helper
INFO - 2016-09-19 11:14:38 --> Database Driver Class Initialized
INFO - 2016-09-19 11:14:38 --> Controller Class Initialized
DEBUG - 2016-09-19 11:14:38 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:14:38 --> Model Class Initialized
INFO - 2016-09-19 11:14:38 --> Model Class Initialized
INFO - 2016-09-19 11:14:38 --> Final output sent to browser
DEBUG - 2016-09-19 11:14:38 --> Total execution time: 0.8663
INFO - 2016-09-19 11:14:43 --> Config Class Initialized
INFO - 2016-09-19 11:14:43 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:14:43 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:14:43 --> Utf8 Class Initialized
INFO - 2016-09-19 11:14:43 --> URI Class Initialized
INFO - 2016-09-19 11:14:43 --> Router Class Initialized
INFO - 2016-09-19 11:14:43 --> Output Class Initialized
INFO - 2016-09-19 11:14:43 --> Security Class Initialized
DEBUG - 2016-09-19 11:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:14:43 --> Input Class Initialized
INFO - 2016-09-19 11:14:43 --> Language Class Initialized
INFO - 2016-09-19 11:14:43 --> Language Class Initialized
INFO - 2016-09-19 11:14:43 --> Config Class Initialized
INFO - 2016-09-19 11:14:43 --> Loader Class Initialized
INFO - 2016-09-19 11:14:43 --> Helper loaded: url_helper
INFO - 2016-09-19 11:14:43 --> Database Driver Class Initialized
INFO - 2016-09-19 11:14:43 --> Controller Class Initialized
DEBUG - 2016-09-19 11:14:43 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:14:43 --> Model Class Initialized
INFO - 2016-09-19 11:14:43 --> Model Class Initialized
INFO - 2016-09-19 11:14:44 --> Final output sent to browser
DEBUG - 2016-09-19 11:14:44 --> Total execution time: 0.8871
INFO - 2016-09-19 11:27:40 --> Config Class Initialized
INFO - 2016-09-19 11:27:40 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:27:41 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:27:41 --> Utf8 Class Initialized
INFO - 2016-09-19 11:27:41 --> URI Class Initialized
INFO - 2016-09-19 11:27:41 --> Router Class Initialized
INFO - 2016-09-19 11:27:41 --> Output Class Initialized
INFO - 2016-09-19 11:27:41 --> Security Class Initialized
DEBUG - 2016-09-19 11:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:27:41 --> Input Class Initialized
INFO - 2016-09-19 11:27:41 --> Language Class Initialized
INFO - 2016-09-19 11:27:41 --> Language Class Initialized
INFO - 2016-09-19 11:27:41 --> Config Class Initialized
INFO - 2016-09-19 11:27:41 --> Loader Class Initialized
INFO - 2016-09-19 11:27:41 --> Helper loaded: url_helper
INFO - 2016-09-19 11:27:41 --> Database Driver Class Initialized
INFO - 2016-09-19 11:27:41 --> Controller Class Initialized
DEBUG - 2016-09-19 11:27:41 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:27:41 --> Model Class Initialized
INFO - 2016-09-19 11:27:41 --> Model Class Initialized
INFO - 2016-09-19 11:27:41 --> Database Driver Class Initialized
INFO - 2016-09-19 11:27:41 --> Database Driver Class Initialized
INFO - 2016-09-19 11:27:41 --> Database Driver Class Initialized
INFO - 2016-09-19 11:27:41 --> Database Driver Class Initialized
INFO - 2016-09-19 11:27:42 --> Database Driver Class Initialized
INFO - 2016-09-19 11:27:42 --> Database Driver Class Initialized
INFO - 2016-09-19 11:27:42 --> Database Driver Class Initialized
INFO - 2016-09-19 11:27:42 --> Database Driver Class Initialized
INFO - 2016-09-19 11:27:42 --> Final output sent to browser
DEBUG - 2016-09-19 11:27:42 --> Total execution time: 1.5645
INFO - 2016-09-19 11:27:47 --> Config Class Initialized
INFO - 2016-09-19 11:27:47 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:27:47 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:27:47 --> Utf8 Class Initialized
INFO - 2016-09-19 11:27:47 --> URI Class Initialized
INFO - 2016-09-19 11:27:47 --> Router Class Initialized
INFO - 2016-09-19 11:27:47 --> Output Class Initialized
INFO - 2016-09-19 11:27:47 --> Security Class Initialized
DEBUG - 2016-09-19 11:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:27:47 --> Input Class Initialized
INFO - 2016-09-19 11:27:47 --> Language Class Initialized
INFO - 2016-09-19 11:27:47 --> Language Class Initialized
INFO - 2016-09-19 11:27:47 --> Config Class Initialized
INFO - 2016-09-19 11:27:47 --> Loader Class Initialized
INFO - 2016-09-19 11:27:47 --> Helper loaded: url_helper
INFO - 2016-09-19 11:27:47 --> Database Driver Class Initialized
INFO - 2016-09-19 11:27:47 --> Controller Class Initialized
DEBUG - 2016-09-19 11:27:47 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:27:47 --> Model Class Initialized
INFO - 2016-09-19 11:27:47 --> Model Class Initialized
INFO - 2016-09-19 11:27:47 --> Final output sent to browser
DEBUG - 2016-09-19 11:27:48 --> Total execution time: 0.8410
INFO - 2016-09-19 11:28:38 --> Config Class Initialized
INFO - 2016-09-19 11:28:38 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:28:38 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:28:38 --> Utf8 Class Initialized
INFO - 2016-09-19 11:28:38 --> URI Class Initialized
INFO - 2016-09-19 11:28:38 --> Router Class Initialized
INFO - 2016-09-19 11:28:38 --> Output Class Initialized
INFO - 2016-09-19 11:28:38 --> Security Class Initialized
DEBUG - 2016-09-19 11:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:28:38 --> Input Class Initialized
INFO - 2016-09-19 11:28:38 --> Language Class Initialized
INFO - 2016-09-19 11:28:38 --> Language Class Initialized
INFO - 2016-09-19 11:28:38 --> Config Class Initialized
INFO - 2016-09-19 11:28:38 --> Loader Class Initialized
INFO - 2016-09-19 11:28:38 --> Helper loaded: url_helper
INFO - 2016-09-19 11:28:38 --> Database Driver Class Initialized
INFO - 2016-09-19 11:28:38 --> Controller Class Initialized
DEBUG - 2016-09-19 11:28:38 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:28:38 --> Model Class Initialized
INFO - 2016-09-19 11:28:39 --> Model Class Initialized
INFO - 2016-09-19 11:28:39 --> Database Driver Class Initialized
INFO - 2016-09-19 11:28:39 --> Database Driver Class Initialized
INFO - 2016-09-19 11:28:39 --> Database Driver Class Initialized
ERROR - 2016-09-19 11:28:39 --> Query error: Unknown column 'nama' in 'where clause' - Invalid query: SELECT *
FROM `tm_tabungan`
WHERE `nama` = 'Bunga Bank'
INFO - 2016-09-19 11:28:39 --> Language file loaded: language/english/db_lang.php
INFO - 2016-09-19 11:29:24 --> Config Class Initialized
INFO - 2016-09-19 11:29:25 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:29:25 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:29:25 --> Utf8 Class Initialized
INFO - 2016-09-19 11:29:25 --> URI Class Initialized
INFO - 2016-09-19 11:29:25 --> Router Class Initialized
INFO - 2016-09-19 11:29:25 --> Output Class Initialized
INFO - 2016-09-19 11:29:25 --> Security Class Initialized
DEBUG - 2016-09-19 11:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:29:25 --> Input Class Initialized
INFO - 2016-09-19 11:29:25 --> Language Class Initialized
INFO - 2016-09-19 11:29:25 --> Language Class Initialized
INFO - 2016-09-19 11:29:25 --> Config Class Initialized
INFO - 2016-09-19 11:29:25 --> Loader Class Initialized
INFO - 2016-09-19 11:29:25 --> Helper loaded: url_helper
INFO - 2016-09-19 11:29:25 --> Database Driver Class Initialized
INFO - 2016-09-19 11:29:25 --> Controller Class Initialized
DEBUG - 2016-09-19 11:29:25 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:29:25 --> Model Class Initialized
INFO - 2016-09-19 11:29:25 --> Model Class Initialized
INFO - 2016-09-19 11:29:25 --> Database Driver Class Initialized
INFO - 2016-09-19 11:29:25 --> Database Driver Class Initialized
INFO - 2016-09-19 11:29:25 --> Database Driver Class Initialized
INFO - 2016-09-19 11:29:26 --> Database Driver Class Initialized
INFO - 2016-09-19 11:29:26 --> Database Driver Class Initialized
INFO - 2016-09-19 11:29:26 --> Database Driver Class Initialized
INFO - 2016-09-19 11:29:26 --> Database Driver Class Initialized
INFO - 2016-09-19 11:29:26 --> Database Driver Class Initialized
INFO - 2016-09-19 11:29:26 --> Database Driver Class Initialized
INFO - 2016-09-19 11:29:26 --> Database Driver Class Initialized
INFO - 2016-09-19 11:29:26 --> Final output sent to browser
DEBUG - 2016-09-19 11:29:26 --> Total execution time: 1.6710
INFO - 2016-09-19 11:31:08 --> Config Class Initialized
INFO - 2016-09-19 11:31:08 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:31:08 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:31:08 --> Utf8 Class Initialized
INFO - 2016-09-19 11:31:09 --> URI Class Initialized
INFO - 2016-09-19 11:31:09 --> Router Class Initialized
INFO - 2016-09-19 11:31:09 --> Output Class Initialized
INFO - 2016-09-19 11:31:09 --> Security Class Initialized
DEBUG - 2016-09-19 11:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:31:09 --> Input Class Initialized
INFO - 2016-09-19 11:31:09 --> Language Class Initialized
INFO - 2016-09-19 11:31:09 --> Language Class Initialized
INFO - 2016-09-19 11:31:09 --> Config Class Initialized
INFO - 2016-09-19 11:31:09 --> Loader Class Initialized
INFO - 2016-09-19 11:31:09 --> Helper loaded: url_helper
INFO - 2016-09-19 11:31:09 --> Database Driver Class Initialized
INFO - 2016-09-19 11:31:09 --> Controller Class Initialized
DEBUG - 2016-09-19 11:31:09 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:31:09 --> Model Class Initialized
INFO - 2016-09-19 11:31:09 --> Model Class Initialized
DEBUG - 2016-09-19 11:31:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 11:31:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 11:31:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 11:31:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tabungan.php
DEBUG - 2016-09-19 11:31:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 11:31:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 11:31:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 11:31:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 11:31:10 --> Final output sent to browser
DEBUG - 2016-09-19 11:31:10 --> Total execution time: 1.1946
INFO - 2016-09-19 11:36:22 --> Config Class Initialized
INFO - 2016-09-19 11:36:22 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:36:22 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:36:22 --> Utf8 Class Initialized
INFO - 2016-09-19 11:36:22 --> URI Class Initialized
INFO - 2016-09-19 11:36:22 --> Router Class Initialized
INFO - 2016-09-19 11:36:22 --> Output Class Initialized
INFO - 2016-09-19 11:36:22 --> Security Class Initialized
DEBUG - 2016-09-19 11:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:36:23 --> Input Class Initialized
INFO - 2016-09-19 11:36:23 --> Language Class Initialized
INFO - 2016-09-19 11:36:23 --> Language Class Initialized
INFO - 2016-09-19 11:36:23 --> Config Class Initialized
INFO - 2016-09-19 11:36:23 --> Loader Class Initialized
INFO - 2016-09-19 11:36:23 --> Helper loaded: url_helper
INFO - 2016-09-19 11:36:23 --> Database Driver Class Initialized
INFO - 2016-09-19 11:36:23 --> Controller Class Initialized
DEBUG - 2016-09-19 11:36:23 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:36:23 --> Model Class Initialized
INFO - 2016-09-19 11:36:23 --> Model Class Initialized
DEBUG - 2016-09-19 11:36:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 11:36:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 11:36:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
ERROR - 2016-09-19 11:36:23 --> Severity: Notice --> Undefined variable: table E:\SERVER\htdocs\koperasiweda\application\views\main_html\content\list_nasabah_tabungan.php 21
ERROR - 2016-09-19 11:36:23 --> Severity: Error --> Call to a member function result_array() on null E:\SERVER\htdocs\koperasiweda\application\views\main_html\content\list_nasabah_tabungan.php 21
INFO - 2016-09-19 11:36:46 --> Config Class Initialized
INFO - 2016-09-19 11:36:46 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:36:46 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:36:46 --> Utf8 Class Initialized
INFO - 2016-09-19 11:36:46 --> URI Class Initialized
INFO - 2016-09-19 11:36:46 --> Router Class Initialized
INFO - 2016-09-19 11:36:47 --> Output Class Initialized
INFO - 2016-09-19 11:36:47 --> Security Class Initialized
DEBUG - 2016-09-19 11:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:36:47 --> Input Class Initialized
INFO - 2016-09-19 11:36:47 --> Language Class Initialized
INFO - 2016-09-19 11:36:47 --> Language Class Initialized
INFO - 2016-09-19 11:36:47 --> Config Class Initialized
INFO - 2016-09-19 11:36:47 --> Loader Class Initialized
INFO - 2016-09-19 11:36:47 --> Helper loaded: url_helper
INFO - 2016-09-19 11:36:47 --> Database Driver Class Initialized
INFO - 2016-09-19 11:36:47 --> Controller Class Initialized
DEBUG - 2016-09-19 11:36:47 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:36:47 --> Model Class Initialized
INFO - 2016-09-19 11:36:47 --> Model Class Initialized
DEBUG - 2016-09-19 11:36:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 11:36:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 11:36:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 11:36:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_nasabah_tabungan.php
DEBUG - 2016-09-19 11:36:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tabungan.php
DEBUG - 2016-09-19 11:36:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 11:36:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 11:36:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 11:36:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 11:36:47 --> Final output sent to browser
DEBUG - 2016-09-19 11:36:48 --> Total execution time: 1.2230
INFO - 2016-09-19 11:38:14 --> Config Class Initialized
INFO - 2016-09-19 11:38:14 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:38:14 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:38:14 --> Utf8 Class Initialized
INFO - 2016-09-19 11:38:14 --> URI Class Initialized
INFO - 2016-09-19 11:38:14 --> Router Class Initialized
INFO - 2016-09-19 11:38:14 --> Output Class Initialized
INFO - 2016-09-19 11:38:14 --> Security Class Initialized
DEBUG - 2016-09-19 11:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:38:14 --> Input Class Initialized
INFO - 2016-09-19 11:38:15 --> Language Class Initialized
INFO - 2016-09-19 11:38:15 --> Language Class Initialized
INFO - 2016-09-19 11:38:15 --> Config Class Initialized
INFO - 2016-09-19 11:38:15 --> Loader Class Initialized
INFO - 2016-09-19 11:38:15 --> Helper loaded: url_helper
INFO - 2016-09-19 11:38:15 --> Database Driver Class Initialized
INFO - 2016-09-19 11:38:15 --> Controller Class Initialized
DEBUG - 2016-09-19 11:38:15 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:38:15 --> Model Class Initialized
INFO - 2016-09-19 11:38:15 --> Model Class Initialized
DEBUG - 2016-09-19 11:38:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 11:38:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 11:38:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 11:38:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_nasabah_tabungan.php
DEBUG - 2016-09-19 11:38:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tabungan.php
DEBUG - 2016-09-19 11:38:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 11:38:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 11:38:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 11:38:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 11:38:15 --> Final output sent to browser
DEBUG - 2016-09-19 11:38:15 --> Total execution time: 1.2645
INFO - 2016-09-19 11:38:23 --> Config Class Initialized
INFO - 2016-09-19 11:38:23 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:38:23 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:38:23 --> Utf8 Class Initialized
INFO - 2016-09-19 11:38:23 --> URI Class Initialized
INFO - 2016-09-19 11:38:23 --> Router Class Initialized
INFO - 2016-09-19 11:38:23 --> Output Class Initialized
INFO - 2016-09-19 11:38:23 --> Security Class Initialized
DEBUG - 2016-09-19 11:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:38:23 --> Input Class Initialized
INFO - 2016-09-19 11:38:23 --> Language Class Initialized
INFO - 2016-09-19 11:38:24 --> Language Class Initialized
INFO - 2016-09-19 11:38:24 --> Config Class Initialized
INFO - 2016-09-19 11:38:24 --> Loader Class Initialized
INFO - 2016-09-19 11:38:24 --> Helper loaded: url_helper
INFO - 2016-09-19 11:38:24 --> Database Driver Class Initialized
INFO - 2016-09-19 11:38:24 --> Controller Class Initialized
DEBUG - 2016-09-19 11:38:24 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:38:24 --> Model Class Initialized
INFO - 2016-09-19 11:38:24 --> Model Class Initialized
INFO - 2016-09-19 11:38:24 --> Database Driver Class Initialized
INFO - 2016-09-19 11:38:24 --> Final output sent to browser
DEBUG - 2016-09-19 11:38:24 --> Total execution time: 0.9072
INFO - 2016-09-19 11:39:10 --> Config Class Initialized
INFO - 2016-09-19 11:39:10 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:39:10 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:39:10 --> Utf8 Class Initialized
INFO - 2016-09-19 11:39:10 --> URI Class Initialized
INFO - 2016-09-19 11:39:10 --> Router Class Initialized
INFO - 2016-09-19 11:39:10 --> Output Class Initialized
INFO - 2016-09-19 11:39:10 --> Security Class Initialized
DEBUG - 2016-09-19 11:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:39:10 --> Input Class Initialized
INFO - 2016-09-19 11:39:11 --> Language Class Initialized
INFO - 2016-09-19 11:39:11 --> Language Class Initialized
INFO - 2016-09-19 11:39:11 --> Config Class Initialized
INFO - 2016-09-19 11:39:11 --> Loader Class Initialized
INFO - 2016-09-19 11:39:11 --> Helper loaded: url_helper
INFO - 2016-09-19 11:39:11 --> Database Driver Class Initialized
INFO - 2016-09-19 11:39:11 --> Controller Class Initialized
DEBUG - 2016-09-19 11:39:11 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:39:11 --> Model Class Initialized
INFO - 2016-09-19 11:39:11 --> Model Class Initialized
DEBUG - 2016-09-19 11:39:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 11:39:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 11:39:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 11:39:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_nasabah_tabungan.php
DEBUG - 2016-09-19 11:39:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tabungan.php
DEBUG - 2016-09-19 11:39:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 11:39:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 11:39:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 11:39:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 11:39:11 --> Final output sent to browser
DEBUG - 2016-09-19 11:39:11 --> Total execution time: 1.2330
INFO - 2016-09-19 11:39:27 --> Config Class Initialized
INFO - 2016-09-19 11:39:27 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:39:27 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:39:27 --> Utf8 Class Initialized
INFO - 2016-09-19 11:39:27 --> URI Class Initialized
INFO - 2016-09-19 11:39:27 --> Router Class Initialized
INFO - 2016-09-19 11:39:27 --> Output Class Initialized
INFO - 2016-09-19 11:39:27 --> Security Class Initialized
DEBUG - 2016-09-19 11:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:39:27 --> Input Class Initialized
INFO - 2016-09-19 11:39:27 --> Language Class Initialized
INFO - 2016-09-19 11:39:28 --> Language Class Initialized
INFO - 2016-09-19 11:39:28 --> Config Class Initialized
INFO - 2016-09-19 11:39:28 --> Loader Class Initialized
INFO - 2016-09-19 11:39:28 --> Helper loaded: url_helper
INFO - 2016-09-19 11:39:28 --> Database Driver Class Initialized
INFO - 2016-09-19 11:39:28 --> Controller Class Initialized
DEBUG - 2016-09-19 11:39:28 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:39:28 --> Model Class Initialized
INFO - 2016-09-19 11:39:28 --> Model Class Initialized
DEBUG - 2016-09-19 11:39:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 11:39:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 11:39:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
INFO - 2016-09-19 11:39:28 --> Database Driver Class Initialized
INFO - 2016-09-19 11:39:28 --> Database Driver Class Initialized
DEBUG - 2016-09-19 11:39:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_nasabah_tabungan.php
DEBUG - 2016-09-19 11:39:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tabungan.php
DEBUG - 2016-09-19 11:39:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 11:39:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 11:39:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 11:39:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 11:39:28 --> Final output sent to browser
DEBUG - 2016-09-19 11:39:29 --> Total execution time: 1.3603
INFO - 2016-09-19 11:39:45 --> Config Class Initialized
INFO - 2016-09-19 11:39:45 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:39:45 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:39:45 --> Utf8 Class Initialized
INFO - 2016-09-19 11:39:45 --> URI Class Initialized
INFO - 2016-09-19 11:39:45 --> Router Class Initialized
INFO - 2016-09-19 11:39:45 --> Output Class Initialized
INFO - 2016-09-19 11:39:46 --> Security Class Initialized
DEBUG - 2016-09-19 11:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:39:46 --> Input Class Initialized
INFO - 2016-09-19 11:39:46 --> Language Class Initialized
INFO - 2016-09-19 11:39:46 --> Language Class Initialized
INFO - 2016-09-19 11:39:46 --> Config Class Initialized
INFO - 2016-09-19 11:39:46 --> Loader Class Initialized
INFO - 2016-09-19 11:39:46 --> Helper loaded: url_helper
INFO - 2016-09-19 11:39:46 --> Database Driver Class Initialized
INFO - 2016-09-19 11:39:46 --> Controller Class Initialized
DEBUG - 2016-09-19 11:39:46 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:39:46 --> Model Class Initialized
INFO - 2016-09-19 11:39:46 --> Model Class Initialized
DEBUG - 2016-09-19 11:39:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 11:39:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 11:39:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
INFO - 2016-09-19 11:39:46 --> Database Driver Class Initialized
INFO - 2016-09-19 11:39:46 --> Database Driver Class Initialized
DEBUG - 2016-09-19 11:39:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_nasabah_tabungan.php
DEBUG - 2016-09-19 11:39:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tabungan.php
DEBUG - 2016-09-19 11:39:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 11:39:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 11:39:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 11:39:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 11:39:47 --> Final output sent to browser
DEBUG - 2016-09-19 11:39:47 --> Total execution time: 1.3932
INFO - 2016-09-19 11:40:48 --> Config Class Initialized
INFO - 2016-09-19 11:40:48 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:40:48 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:40:48 --> Utf8 Class Initialized
INFO - 2016-09-19 11:40:48 --> URI Class Initialized
INFO - 2016-09-19 11:40:48 --> Router Class Initialized
INFO - 2016-09-19 11:40:48 --> Output Class Initialized
INFO - 2016-09-19 11:40:48 --> Security Class Initialized
DEBUG - 2016-09-19 11:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:40:49 --> Input Class Initialized
INFO - 2016-09-19 11:40:49 --> Language Class Initialized
INFO - 2016-09-19 11:40:49 --> Language Class Initialized
INFO - 2016-09-19 11:40:49 --> Config Class Initialized
INFO - 2016-09-19 11:40:49 --> Loader Class Initialized
INFO - 2016-09-19 11:40:49 --> Helper loaded: url_helper
INFO - 2016-09-19 11:40:49 --> Database Driver Class Initialized
INFO - 2016-09-19 11:40:49 --> Controller Class Initialized
DEBUG - 2016-09-19 11:40:49 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:40:49 --> Model Class Initialized
INFO - 2016-09-19 11:40:49 --> Model Class Initialized
DEBUG - 2016-09-19 11:40:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 11:40:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 11:40:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
INFO - 2016-09-19 11:40:49 --> Database Driver Class Initialized
INFO - 2016-09-19 11:40:49 --> Database Driver Class Initialized
DEBUG - 2016-09-19 11:40:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_nasabah_tabungan.php
DEBUG - 2016-09-19 11:40:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tabungan.php
DEBUG - 2016-09-19 11:40:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 11:40:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 11:40:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 11:40:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 11:40:49 --> Final output sent to browser
DEBUG - 2016-09-19 11:40:50 --> Total execution time: 1.3240
INFO - 2016-09-19 11:41:00 --> Config Class Initialized
INFO - 2016-09-19 11:41:00 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:41:00 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:41:00 --> Utf8 Class Initialized
INFO - 2016-09-19 11:41:00 --> URI Class Initialized
INFO - 2016-09-19 11:41:00 --> Router Class Initialized
INFO - 2016-09-19 11:41:00 --> Output Class Initialized
INFO - 2016-09-19 11:41:00 --> Security Class Initialized
DEBUG - 2016-09-19 11:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:41:00 --> Input Class Initialized
INFO - 2016-09-19 11:41:00 --> Language Class Initialized
INFO - 2016-09-19 11:41:00 --> Language Class Initialized
INFO - 2016-09-19 11:41:01 --> Config Class Initialized
INFO - 2016-09-19 11:41:01 --> Loader Class Initialized
INFO - 2016-09-19 11:41:01 --> Helper loaded: url_helper
INFO - 2016-09-19 11:41:01 --> Database Driver Class Initialized
INFO - 2016-09-19 11:41:01 --> Controller Class Initialized
DEBUG - 2016-09-19 11:41:01 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:41:01 --> Model Class Initialized
INFO - 2016-09-19 11:41:01 --> Model Class Initialized
DEBUG - 2016-09-19 11:41:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 11:41:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 11:41:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
INFO - 2016-09-19 11:41:01 --> Database Driver Class Initialized
INFO - 2016-09-19 11:41:01 --> Database Driver Class Initialized
DEBUG - 2016-09-19 11:41:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_nasabah_tabungan.php
DEBUG - 2016-09-19 11:41:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tabungan.php
DEBUG - 2016-09-19 11:41:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 11:41:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 11:41:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 11:41:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 11:41:01 --> Final output sent to browser
DEBUG - 2016-09-19 11:41:01 --> Total execution time: 1.3849
INFO - 2016-09-19 11:41:30 --> Config Class Initialized
INFO - 2016-09-19 11:41:30 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:41:30 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:41:30 --> Utf8 Class Initialized
INFO - 2016-09-19 11:41:30 --> URI Class Initialized
INFO - 2016-09-19 11:41:30 --> Router Class Initialized
INFO - 2016-09-19 11:41:30 --> Output Class Initialized
INFO - 2016-09-19 11:41:30 --> Security Class Initialized
DEBUG - 2016-09-19 11:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:41:31 --> Input Class Initialized
INFO - 2016-09-19 11:41:31 --> Language Class Initialized
INFO - 2016-09-19 11:41:31 --> Language Class Initialized
INFO - 2016-09-19 11:41:31 --> Config Class Initialized
INFO - 2016-09-19 11:41:31 --> Loader Class Initialized
INFO - 2016-09-19 11:41:31 --> Helper loaded: url_helper
INFO - 2016-09-19 11:41:31 --> Database Driver Class Initialized
INFO - 2016-09-19 11:41:31 --> Controller Class Initialized
DEBUG - 2016-09-19 11:41:31 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:41:31 --> Model Class Initialized
INFO - 2016-09-19 11:41:31 --> Model Class Initialized
DEBUG - 2016-09-19 11:41:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 11:41:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 11:41:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
INFO - 2016-09-19 11:41:31 --> Database Driver Class Initialized
INFO - 2016-09-19 11:41:31 --> Database Driver Class Initialized
DEBUG - 2016-09-19 11:41:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_nasabah_tabungan.php
DEBUG - 2016-09-19 11:41:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tabungan.php
DEBUG - 2016-09-19 11:41:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 11:41:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 11:41:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 11:41:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 11:41:32 --> Final output sent to browser
DEBUG - 2016-09-19 11:41:32 --> Total execution time: 1.4068
INFO - 2016-09-19 11:41:48 --> Config Class Initialized
INFO - 2016-09-19 11:41:48 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:41:48 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:41:48 --> Utf8 Class Initialized
INFO - 2016-09-19 11:41:48 --> URI Class Initialized
INFO - 2016-09-19 11:41:48 --> Router Class Initialized
INFO - 2016-09-19 11:41:48 --> Output Class Initialized
INFO - 2016-09-19 11:41:48 --> Security Class Initialized
DEBUG - 2016-09-19 11:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:41:48 --> Input Class Initialized
INFO - 2016-09-19 11:41:48 --> Language Class Initialized
INFO - 2016-09-19 11:41:48 --> Language Class Initialized
INFO - 2016-09-19 11:41:48 --> Config Class Initialized
INFO - 2016-09-19 11:41:48 --> Loader Class Initialized
INFO - 2016-09-19 11:41:48 --> Helper loaded: url_helper
INFO - 2016-09-19 11:41:48 --> Database Driver Class Initialized
INFO - 2016-09-19 11:41:48 --> Controller Class Initialized
DEBUG - 2016-09-19 11:41:48 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:41:48 --> Model Class Initialized
INFO - 2016-09-19 11:41:48 --> Model Class Initialized
DEBUG - 2016-09-19 11:41:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 11:41:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 11:41:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
INFO - 2016-09-19 11:41:49 --> Database Driver Class Initialized
INFO - 2016-09-19 11:41:49 --> Database Driver Class Initialized
DEBUG - 2016-09-19 11:41:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_nasabah_tabungan.php
DEBUG - 2016-09-19 11:41:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tabungan.php
DEBUG - 2016-09-19 11:41:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 11:41:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 11:41:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 11:41:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 11:41:49 --> Final output sent to browser
DEBUG - 2016-09-19 11:41:49 --> Total execution time: 1.3690
INFO - 2016-09-19 11:50:55 --> Config Class Initialized
INFO - 2016-09-19 11:50:55 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:50:55 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:50:55 --> Utf8 Class Initialized
INFO - 2016-09-19 11:50:55 --> URI Class Initialized
INFO - 2016-09-19 11:50:55 --> Router Class Initialized
INFO - 2016-09-19 11:50:55 --> Output Class Initialized
INFO - 2016-09-19 11:50:55 --> Security Class Initialized
DEBUG - 2016-09-19 11:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:50:55 --> Input Class Initialized
INFO - 2016-09-19 11:50:56 --> Language Class Initialized
INFO - 2016-09-19 11:50:56 --> Language Class Initialized
INFO - 2016-09-19 11:50:56 --> Config Class Initialized
INFO - 2016-09-19 11:50:56 --> Loader Class Initialized
INFO - 2016-09-19 11:50:56 --> Helper loaded: url_helper
INFO - 2016-09-19 11:50:56 --> Database Driver Class Initialized
INFO - 2016-09-19 11:50:56 --> Controller Class Initialized
DEBUG - 2016-09-19 11:50:56 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:50:56 --> Model Class Initialized
INFO - 2016-09-19 11:50:56 --> Model Class Initialized
DEBUG - 2016-09-19 11:50:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 11:50:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 11:50:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
INFO - 2016-09-19 11:50:56 --> Database Driver Class Initialized
INFO - 2016-09-19 11:50:56 --> Database Driver Class Initialized
DEBUG - 2016-09-19 11:50:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_nasabah_tabungan.php
DEBUG - 2016-09-19 11:50:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tabungan.php
DEBUG - 2016-09-19 11:50:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 11:50:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 11:50:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 11:50:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 11:50:56 --> Final output sent to browser
DEBUG - 2016-09-19 11:50:57 --> Total execution time: 1.3441
INFO - 2016-09-19 11:51:11 --> Config Class Initialized
INFO - 2016-09-19 11:51:11 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:51:11 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:51:11 --> Utf8 Class Initialized
INFO - 2016-09-19 11:51:11 --> URI Class Initialized
INFO - 2016-09-19 11:51:11 --> Router Class Initialized
INFO - 2016-09-19 11:51:11 --> Output Class Initialized
INFO - 2016-09-19 11:51:11 --> Security Class Initialized
DEBUG - 2016-09-19 11:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:51:11 --> Input Class Initialized
INFO - 2016-09-19 11:51:11 --> Language Class Initialized
INFO - 2016-09-19 11:51:11 --> Language Class Initialized
INFO - 2016-09-19 11:51:11 --> Config Class Initialized
INFO - 2016-09-19 11:51:11 --> Loader Class Initialized
INFO - 2016-09-19 11:51:12 --> Helper loaded: url_helper
INFO - 2016-09-19 11:51:12 --> Database Driver Class Initialized
INFO - 2016-09-19 11:51:12 --> Controller Class Initialized
DEBUG - 2016-09-19 11:51:12 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:51:12 --> Model Class Initialized
INFO - 2016-09-19 11:51:12 --> Model Class Initialized
INFO - 2016-09-19 11:51:12 --> Final output sent to browser
DEBUG - 2016-09-19 11:51:12 --> Total execution time: 0.9228
INFO - 2016-09-19 11:58:10 --> Config Class Initialized
INFO - 2016-09-19 11:58:11 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:58:11 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:58:11 --> Utf8 Class Initialized
INFO - 2016-09-19 11:58:11 --> URI Class Initialized
INFO - 2016-09-19 11:58:11 --> Router Class Initialized
INFO - 2016-09-19 11:58:11 --> Output Class Initialized
INFO - 2016-09-19 11:58:11 --> Security Class Initialized
DEBUG - 2016-09-19 11:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:58:11 --> Input Class Initialized
INFO - 2016-09-19 11:58:11 --> Language Class Initialized
INFO - 2016-09-19 11:58:11 --> Language Class Initialized
INFO - 2016-09-19 11:58:11 --> Config Class Initialized
INFO - 2016-09-19 11:58:11 --> Loader Class Initialized
INFO - 2016-09-19 11:58:11 --> Helper loaded: url_helper
INFO - 2016-09-19 11:58:11 --> Database Driver Class Initialized
INFO - 2016-09-19 11:58:11 --> Controller Class Initialized
DEBUG - 2016-09-19 11:58:11 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:58:11 --> Model Class Initialized
INFO - 2016-09-19 11:58:11 --> Model Class Initialized
DEBUG - 2016-09-19 11:58:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 11:58:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 11:58:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
INFO - 2016-09-19 11:58:12 --> Database Driver Class Initialized
INFO - 2016-09-19 11:58:12 --> Database Driver Class Initialized
DEBUG - 2016-09-19 11:58:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_nasabah_tabungan.php
DEBUG - 2016-09-19 11:58:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tabungan.php
DEBUG - 2016-09-19 11:58:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 11:58:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 11:58:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 11:58:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 11:58:12 --> Final output sent to browser
DEBUG - 2016-09-19 11:58:12 --> Total execution time: 1.4524
INFO - 2016-09-19 11:58:21 --> Config Class Initialized
INFO - 2016-09-19 11:58:21 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:58:21 --> UTF-8 Support Enabled
INFO - 2016-09-19 11:58:21 --> Utf8 Class Initialized
INFO - 2016-09-19 11:58:21 --> URI Class Initialized
INFO - 2016-09-19 11:58:21 --> Router Class Initialized
INFO - 2016-09-19 11:58:21 --> Output Class Initialized
INFO - 2016-09-19 11:58:21 --> Security Class Initialized
DEBUG - 2016-09-19 11:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 11:58:21 --> Input Class Initialized
INFO - 2016-09-19 11:58:21 --> Language Class Initialized
INFO - 2016-09-19 11:58:21 --> Language Class Initialized
INFO - 2016-09-19 11:58:21 --> Config Class Initialized
INFO - 2016-09-19 11:58:21 --> Loader Class Initialized
INFO - 2016-09-19 11:58:21 --> Helper loaded: url_helper
INFO - 2016-09-19 11:58:21 --> Database Driver Class Initialized
INFO - 2016-09-19 11:58:22 --> Controller Class Initialized
DEBUG - 2016-09-19 11:58:22 --> Index MX_Controller Initialized
INFO - 2016-09-19 11:58:22 --> Model Class Initialized
INFO - 2016-09-19 11:58:22 --> Model Class Initialized
INFO - 2016-09-19 11:58:22 --> Final output sent to browser
DEBUG - 2016-09-19 11:58:22 --> Total execution time: 0.9732
INFO - 2016-09-19 12:53:44 --> Config Class Initialized
INFO - 2016-09-19 12:53:45 --> Hooks Class Initialized
DEBUG - 2016-09-19 12:53:45 --> UTF-8 Support Enabled
INFO - 2016-09-19 12:53:45 --> Utf8 Class Initialized
INFO - 2016-09-19 12:53:45 --> URI Class Initialized
INFO - 2016-09-19 12:53:45 --> Router Class Initialized
INFO - 2016-09-19 12:53:45 --> Output Class Initialized
INFO - 2016-09-19 12:53:45 --> Security Class Initialized
DEBUG - 2016-09-19 12:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 12:53:45 --> Input Class Initialized
INFO - 2016-09-19 12:53:46 --> Language Class Initialized
INFO - 2016-09-19 12:53:46 --> Language Class Initialized
INFO - 2016-09-19 12:53:46 --> Config Class Initialized
INFO - 2016-09-19 12:53:46 --> Loader Class Initialized
INFO - 2016-09-19 12:53:46 --> Helper loaded: url_helper
INFO - 2016-09-19 12:53:46 --> Database Driver Class Initialized
INFO - 2016-09-19 12:53:47 --> Controller Class Initialized
DEBUG - 2016-09-19 12:53:47 --> Index MX_Controller Initialized
INFO - 2016-09-19 12:53:47 --> Model Class Initialized
INFO - 2016-09-19 12:53:47 --> Model Class Initialized
DEBUG - 2016-09-19 12:53:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 12:53:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 12:53:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 12:53:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/dashboard.php
DEBUG - 2016-09-19 12:53:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 12:53:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 12:53:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 12:53:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 12:53:47 --> Final output sent to browser
DEBUG - 2016-09-19 12:53:47 --> Total execution time: 3.0049
INFO - 2016-09-19 12:54:13 --> Config Class Initialized
INFO - 2016-09-19 12:54:13 --> Hooks Class Initialized
DEBUG - 2016-09-19 12:54:13 --> UTF-8 Support Enabled
INFO - 2016-09-19 12:54:13 --> Utf8 Class Initialized
INFO - 2016-09-19 12:54:13 --> URI Class Initialized
INFO - 2016-09-19 12:54:13 --> Router Class Initialized
INFO - 2016-09-19 12:54:13 --> Output Class Initialized
INFO - 2016-09-19 12:54:13 --> Security Class Initialized
DEBUG - 2016-09-19 12:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 12:54:13 --> Input Class Initialized
INFO - 2016-09-19 12:54:13 --> Language Class Initialized
INFO - 2016-09-19 12:54:13 --> Language Class Initialized
INFO - 2016-09-19 12:54:13 --> Config Class Initialized
INFO - 2016-09-19 12:54:13 --> Loader Class Initialized
INFO - 2016-09-19 12:54:13 --> Helper loaded: url_helper
INFO - 2016-09-19 12:54:13 --> Database Driver Class Initialized
INFO - 2016-09-19 12:54:13 --> Controller Class Initialized
DEBUG - 2016-09-19 12:54:14 --> Index MX_Controller Initialized
INFO - 2016-09-19 12:54:14 --> Model Class Initialized
INFO - 2016-09-19 12:54:14 --> Model Class Initialized
DEBUG - 2016-09-19 12:54:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 12:54:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 12:54:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 12:54:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/dashboard.php
DEBUG - 2016-09-19 12:54:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 12:54:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 12:54:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 12:54:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 12:54:14 --> Final output sent to browser
DEBUG - 2016-09-19 12:54:14 --> Total execution time: 1.3642
INFO - 2016-09-19 12:57:10 --> Config Class Initialized
INFO - 2016-09-19 12:57:10 --> Hooks Class Initialized
DEBUG - 2016-09-19 12:57:10 --> UTF-8 Support Enabled
INFO - 2016-09-19 12:57:10 --> Utf8 Class Initialized
INFO - 2016-09-19 12:57:11 --> URI Class Initialized
INFO - 2016-09-19 12:57:11 --> Router Class Initialized
INFO - 2016-09-19 12:57:11 --> Output Class Initialized
INFO - 2016-09-19 12:57:11 --> Security Class Initialized
DEBUG - 2016-09-19 12:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 12:57:11 --> Input Class Initialized
INFO - 2016-09-19 12:57:11 --> Language Class Initialized
INFO - 2016-09-19 12:57:11 --> Language Class Initialized
INFO - 2016-09-19 12:57:11 --> Config Class Initialized
INFO - 2016-09-19 12:57:11 --> Loader Class Initialized
INFO - 2016-09-19 12:57:11 --> Helper loaded: url_helper
INFO - 2016-09-19 12:57:11 --> Database Driver Class Initialized
INFO - 2016-09-19 12:57:11 --> Controller Class Initialized
DEBUG - 2016-09-19 12:57:11 --> Index MX_Controller Initialized
INFO - 2016-09-19 12:57:11 --> Model Class Initialized
INFO - 2016-09-19 12:57:11 --> Model Class Initialized
DEBUG - 2016-09-19 12:57:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 12:57:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 12:57:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 12:57:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/dashboard.php
DEBUG - 2016-09-19 12:57:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 12:57:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 12:57:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 12:57:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 12:57:12 --> Final output sent to browser
DEBUG - 2016-09-19 12:57:12 --> Total execution time: 1.1781
INFO - 2016-09-19 12:57:36 --> Config Class Initialized
INFO - 2016-09-19 12:57:36 --> Hooks Class Initialized
DEBUG - 2016-09-19 12:57:36 --> UTF-8 Support Enabled
INFO - 2016-09-19 12:57:36 --> Utf8 Class Initialized
INFO - 2016-09-19 12:57:36 --> URI Class Initialized
INFO - 2016-09-19 12:57:36 --> Router Class Initialized
INFO - 2016-09-19 12:57:36 --> Output Class Initialized
INFO - 2016-09-19 12:57:36 --> Security Class Initialized
DEBUG - 2016-09-19 12:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 12:57:36 --> Input Class Initialized
INFO - 2016-09-19 12:57:36 --> Language Class Initialized
INFO - 2016-09-19 12:57:36 --> Language Class Initialized
INFO - 2016-09-19 12:57:36 --> Config Class Initialized
INFO - 2016-09-19 12:57:36 --> Loader Class Initialized
INFO - 2016-09-19 12:57:36 --> Helper loaded: url_helper
INFO - 2016-09-19 12:57:36 --> Database Driver Class Initialized
INFO - 2016-09-19 12:57:36 --> Controller Class Initialized
DEBUG - 2016-09-19 12:57:36 --> Index MX_Controller Initialized
INFO - 2016-09-19 12:57:36 --> Model Class Initialized
INFO - 2016-09-19 12:57:36 --> Model Class Initialized
DEBUG - 2016-09-19 12:57:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 12:57:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 12:57:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 12:57:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/dashboard.php
DEBUG - 2016-09-19 12:57:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 12:57:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 12:57:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 12:57:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 12:57:37 --> Final output sent to browser
DEBUG - 2016-09-19 12:57:37 --> Total execution time: 1.1826
INFO - 2016-09-19 12:57:59 --> Config Class Initialized
INFO - 2016-09-19 12:57:59 --> Hooks Class Initialized
DEBUG - 2016-09-19 12:57:59 --> UTF-8 Support Enabled
INFO - 2016-09-19 12:57:59 --> Utf8 Class Initialized
INFO - 2016-09-19 12:57:59 --> URI Class Initialized
INFO - 2016-09-19 12:57:59 --> Router Class Initialized
INFO - 2016-09-19 12:57:59 --> Output Class Initialized
INFO - 2016-09-19 12:57:59 --> Security Class Initialized
DEBUG - 2016-09-19 12:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 12:57:59 --> Input Class Initialized
INFO - 2016-09-19 12:57:59 --> Language Class Initialized
INFO - 2016-09-19 12:57:59 --> Language Class Initialized
INFO - 2016-09-19 12:57:59 --> Config Class Initialized
INFO - 2016-09-19 12:57:59 --> Loader Class Initialized
INFO - 2016-09-19 12:57:59 --> Helper loaded: url_helper
INFO - 2016-09-19 12:57:59 --> Database Driver Class Initialized
INFO - 2016-09-19 12:57:59 --> Controller Class Initialized
DEBUG - 2016-09-19 12:57:59 --> Index MX_Controller Initialized
INFO - 2016-09-19 12:58:00 --> Model Class Initialized
INFO - 2016-09-19 12:58:00 --> Model Class Initialized
DEBUG - 2016-09-19 12:58:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 12:58:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 12:58:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 12:58:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/dashboard.php
DEBUG - 2016-09-19 12:58:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 12:58:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 12:58:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 12:58:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 12:58:00 --> Final output sent to browser
DEBUG - 2016-09-19 12:58:00 --> Total execution time: 1.2491
INFO - 2016-09-19 12:58:23 --> Config Class Initialized
INFO - 2016-09-19 12:58:23 --> Hooks Class Initialized
DEBUG - 2016-09-19 12:58:23 --> UTF-8 Support Enabled
INFO - 2016-09-19 12:58:23 --> Utf8 Class Initialized
INFO - 2016-09-19 12:58:23 --> URI Class Initialized
INFO - 2016-09-19 12:58:23 --> Router Class Initialized
INFO - 2016-09-19 12:58:23 --> Output Class Initialized
INFO - 2016-09-19 12:58:23 --> Security Class Initialized
DEBUG - 2016-09-19 12:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 12:58:23 --> Input Class Initialized
INFO - 2016-09-19 12:58:23 --> Language Class Initialized
INFO - 2016-09-19 12:58:23 --> Language Class Initialized
INFO - 2016-09-19 12:58:24 --> Config Class Initialized
INFO - 2016-09-19 12:58:24 --> Loader Class Initialized
INFO - 2016-09-19 12:58:24 --> Helper loaded: url_helper
INFO - 2016-09-19 12:58:24 --> Database Driver Class Initialized
INFO - 2016-09-19 12:58:24 --> Controller Class Initialized
DEBUG - 2016-09-19 12:58:24 --> Index MX_Controller Initialized
INFO - 2016-09-19 12:58:24 --> Model Class Initialized
INFO - 2016-09-19 12:58:24 --> Model Class Initialized
DEBUG - 2016-09-19 12:58:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 12:58:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 12:58:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 12:58:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/dashboard.php
DEBUG - 2016-09-19 12:58:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 12:58:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 12:58:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 12:58:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 12:58:24 --> Final output sent to browser
DEBUG - 2016-09-19 12:58:24 --> Total execution time: 1.2133
INFO - 2016-09-19 12:58:35 --> Config Class Initialized
INFO - 2016-09-19 12:58:35 --> Hooks Class Initialized
DEBUG - 2016-09-19 12:58:35 --> UTF-8 Support Enabled
INFO - 2016-09-19 12:58:35 --> Utf8 Class Initialized
INFO - 2016-09-19 12:58:35 --> URI Class Initialized
INFO - 2016-09-19 12:58:35 --> Router Class Initialized
INFO - 2016-09-19 12:58:35 --> Output Class Initialized
INFO - 2016-09-19 12:58:35 --> Security Class Initialized
DEBUG - 2016-09-19 12:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 12:58:35 --> Input Class Initialized
INFO - 2016-09-19 12:58:35 --> Language Class Initialized
INFO - 2016-09-19 12:58:35 --> Language Class Initialized
INFO - 2016-09-19 12:58:35 --> Config Class Initialized
INFO - 2016-09-19 12:58:35 --> Loader Class Initialized
INFO - 2016-09-19 12:58:36 --> Helper loaded: url_helper
INFO - 2016-09-19 12:58:36 --> Database Driver Class Initialized
INFO - 2016-09-19 12:58:36 --> Controller Class Initialized
DEBUG - 2016-09-19 12:58:36 --> Index MX_Controller Initialized
INFO - 2016-09-19 12:58:36 --> Model Class Initialized
INFO - 2016-09-19 12:58:36 --> Model Class Initialized
DEBUG - 2016-09-19 12:58:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 12:58:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 12:58:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 12:58:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/dashboard.php
DEBUG - 2016-09-19 12:58:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 12:58:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 12:58:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 12:58:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 12:58:36 --> Final output sent to browser
DEBUG - 2016-09-19 12:58:36 --> Total execution time: 1.2420
INFO - 2016-09-19 12:59:05 --> Config Class Initialized
INFO - 2016-09-19 12:59:05 --> Hooks Class Initialized
DEBUG - 2016-09-19 12:59:05 --> UTF-8 Support Enabled
INFO - 2016-09-19 12:59:05 --> Utf8 Class Initialized
INFO - 2016-09-19 12:59:05 --> URI Class Initialized
INFO - 2016-09-19 12:59:05 --> Router Class Initialized
INFO - 2016-09-19 12:59:05 --> Output Class Initialized
INFO - 2016-09-19 12:59:05 --> Security Class Initialized
DEBUG - 2016-09-19 12:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 12:59:06 --> Input Class Initialized
INFO - 2016-09-19 12:59:06 --> Language Class Initialized
INFO - 2016-09-19 12:59:06 --> Language Class Initialized
INFO - 2016-09-19 12:59:06 --> Config Class Initialized
INFO - 2016-09-19 12:59:06 --> Loader Class Initialized
INFO - 2016-09-19 12:59:06 --> Helper loaded: url_helper
INFO - 2016-09-19 12:59:06 --> Database Driver Class Initialized
INFO - 2016-09-19 12:59:06 --> Controller Class Initialized
DEBUG - 2016-09-19 12:59:06 --> Index MX_Controller Initialized
INFO - 2016-09-19 12:59:06 --> Model Class Initialized
INFO - 2016-09-19 12:59:06 --> Model Class Initialized
DEBUG - 2016-09-19 12:59:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 12:59:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 12:59:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 12:59:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/dashboard.php
DEBUG - 2016-09-19 12:59:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 12:59:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 12:59:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 12:59:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 12:59:06 --> Final output sent to browser
DEBUG - 2016-09-19 12:59:07 --> Total execution time: 1.5238
INFO - 2016-09-19 12:59:39 --> Config Class Initialized
INFO - 2016-09-19 12:59:39 --> Hooks Class Initialized
DEBUG - 2016-09-19 12:59:40 --> UTF-8 Support Enabled
INFO - 2016-09-19 12:59:40 --> Utf8 Class Initialized
INFO - 2016-09-19 12:59:40 --> URI Class Initialized
INFO - 2016-09-19 12:59:40 --> Router Class Initialized
INFO - 2016-09-19 12:59:40 --> Output Class Initialized
INFO - 2016-09-19 12:59:40 --> Security Class Initialized
DEBUG - 2016-09-19 12:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 12:59:40 --> Input Class Initialized
INFO - 2016-09-19 12:59:40 --> Language Class Initialized
INFO - 2016-09-19 12:59:40 --> Language Class Initialized
INFO - 2016-09-19 12:59:40 --> Config Class Initialized
INFO - 2016-09-19 12:59:40 --> Loader Class Initialized
INFO - 2016-09-19 12:59:40 --> Helper loaded: url_helper
INFO - 2016-09-19 12:59:40 --> Database Driver Class Initialized
INFO - 2016-09-19 12:59:40 --> Controller Class Initialized
DEBUG - 2016-09-19 12:59:40 --> Index MX_Controller Initialized
INFO - 2016-09-19 12:59:40 --> Model Class Initialized
INFO - 2016-09-19 12:59:40 --> Model Class Initialized
DEBUG - 2016-09-19 12:59:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 12:59:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 12:59:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 12:59:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/dashboard.php
DEBUG - 2016-09-19 12:59:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 12:59:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 12:59:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 12:59:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 12:59:41 --> Final output sent to browser
DEBUG - 2016-09-19 12:59:41 --> Total execution time: 1.2198
INFO - 2016-09-19 13:00:02 --> Config Class Initialized
INFO - 2016-09-19 13:00:02 --> Hooks Class Initialized
DEBUG - 2016-09-19 13:00:02 --> UTF-8 Support Enabled
INFO - 2016-09-19 13:00:02 --> Utf8 Class Initialized
INFO - 2016-09-19 13:00:02 --> URI Class Initialized
INFO - 2016-09-19 13:00:02 --> Router Class Initialized
INFO - 2016-09-19 13:00:03 --> Output Class Initialized
INFO - 2016-09-19 13:00:03 --> Security Class Initialized
DEBUG - 2016-09-19 13:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 13:00:03 --> Input Class Initialized
INFO - 2016-09-19 13:00:03 --> Language Class Initialized
INFO - 2016-09-19 13:00:03 --> Language Class Initialized
INFO - 2016-09-19 13:00:03 --> Config Class Initialized
INFO - 2016-09-19 13:00:03 --> Loader Class Initialized
INFO - 2016-09-19 13:00:03 --> Helper loaded: url_helper
INFO - 2016-09-19 13:00:03 --> Database Driver Class Initialized
INFO - 2016-09-19 13:00:03 --> Controller Class Initialized
DEBUG - 2016-09-19 13:00:03 --> Index MX_Controller Initialized
INFO - 2016-09-19 13:00:03 --> Model Class Initialized
INFO - 2016-09-19 13:00:03 --> Model Class Initialized
DEBUG - 2016-09-19 13:00:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 13:00:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 13:00:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 13:00:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/dashboard.php
DEBUG - 2016-09-19 13:00:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 13:00:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 13:00:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 13:00:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 13:00:03 --> Final output sent to browser
DEBUG - 2016-09-19 13:00:04 --> Total execution time: 1.1976
INFO - 2016-09-19 13:02:26 --> Config Class Initialized
INFO - 2016-09-19 13:02:26 --> Hooks Class Initialized
DEBUG - 2016-09-19 13:02:26 --> UTF-8 Support Enabled
INFO - 2016-09-19 13:02:26 --> Utf8 Class Initialized
INFO - 2016-09-19 13:02:27 --> URI Class Initialized
INFO - 2016-09-19 13:02:27 --> Router Class Initialized
INFO - 2016-09-19 13:02:27 --> Output Class Initialized
INFO - 2016-09-19 13:02:27 --> Security Class Initialized
DEBUG - 2016-09-19 13:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 13:02:27 --> Input Class Initialized
INFO - 2016-09-19 13:02:27 --> Language Class Initialized
INFO - 2016-09-19 13:02:27 --> Language Class Initialized
INFO - 2016-09-19 13:02:27 --> Config Class Initialized
INFO - 2016-09-19 13:02:27 --> Loader Class Initialized
INFO - 2016-09-19 13:02:27 --> Helper loaded: url_helper
INFO - 2016-09-19 13:02:27 --> Database Driver Class Initialized
INFO - 2016-09-19 13:02:27 --> Controller Class Initialized
DEBUG - 2016-09-19 13:02:27 --> Index MX_Controller Initialized
INFO - 2016-09-19 13:02:27 --> Model Class Initialized
INFO - 2016-09-19 13:02:27 --> Model Class Initialized
DEBUG - 2016-09-19 13:02:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 13:02:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 13:02:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 13:02:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/dashboard.php
DEBUG - 2016-09-19 13:02:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 13:02:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 13:02:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 13:02:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 13:02:28 --> Final output sent to browser
DEBUG - 2016-09-19 13:02:28 --> Total execution time: 1.2203
INFO - 2016-09-19 13:02:36 --> Config Class Initialized
INFO - 2016-09-19 13:02:36 --> Hooks Class Initialized
DEBUG - 2016-09-19 13:02:36 --> UTF-8 Support Enabled
INFO - 2016-09-19 13:02:36 --> Utf8 Class Initialized
INFO - 2016-09-19 13:02:36 --> URI Class Initialized
INFO - 2016-09-19 13:02:37 --> Router Class Initialized
INFO - 2016-09-19 13:02:37 --> Output Class Initialized
INFO - 2016-09-19 13:02:37 --> Security Class Initialized
DEBUG - 2016-09-19 13:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 13:02:37 --> Input Class Initialized
INFO - 2016-09-19 13:02:37 --> Language Class Initialized
INFO - 2016-09-19 13:02:37 --> Language Class Initialized
INFO - 2016-09-19 13:02:37 --> Config Class Initialized
INFO - 2016-09-19 13:02:37 --> Loader Class Initialized
INFO - 2016-09-19 13:02:37 --> Helper loaded: url_helper
INFO - 2016-09-19 13:02:37 --> Database Driver Class Initialized
INFO - 2016-09-19 13:02:37 --> Controller Class Initialized
DEBUG - 2016-09-19 13:02:37 --> Index MX_Controller Initialized
INFO - 2016-09-19 13:02:37 --> Model Class Initialized
INFO - 2016-09-19 13:02:37 --> Model Class Initialized
DEBUG - 2016-09-19 13:02:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 13:02:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 13:02:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 13:02:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/dashboard.php
DEBUG - 2016-09-19 13:02:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 13:02:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 13:02:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 13:02:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 13:02:38 --> Final output sent to browser
DEBUG - 2016-09-19 13:02:38 --> Total execution time: 1.2523
INFO - 2016-09-19 13:03:18 --> Config Class Initialized
INFO - 2016-09-19 13:03:18 --> Hooks Class Initialized
DEBUG - 2016-09-19 13:03:19 --> UTF-8 Support Enabled
INFO - 2016-09-19 13:03:19 --> Utf8 Class Initialized
INFO - 2016-09-19 13:03:19 --> URI Class Initialized
INFO - 2016-09-19 13:03:19 --> Router Class Initialized
INFO - 2016-09-19 13:03:19 --> Output Class Initialized
INFO - 2016-09-19 13:03:19 --> Security Class Initialized
DEBUG - 2016-09-19 13:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 13:03:19 --> Input Class Initialized
INFO - 2016-09-19 13:03:19 --> Language Class Initialized
INFO - 2016-09-19 13:03:19 --> Language Class Initialized
INFO - 2016-09-19 13:03:19 --> Config Class Initialized
INFO - 2016-09-19 13:03:19 --> Loader Class Initialized
INFO - 2016-09-19 13:03:19 --> Helper loaded: url_helper
INFO - 2016-09-19 13:03:19 --> Database Driver Class Initialized
INFO - 2016-09-19 13:03:19 --> Controller Class Initialized
DEBUG - 2016-09-19 13:03:19 --> Index MX_Controller Initialized
INFO - 2016-09-19 13:03:19 --> Model Class Initialized
INFO - 2016-09-19 13:03:19 --> Model Class Initialized
DEBUG - 2016-09-19 13:03:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 13:03:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 13:03:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 13:03:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/dashboard.php
DEBUG - 2016-09-19 13:03:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 13:03:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 13:03:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 13:03:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 13:03:20 --> Final output sent to browser
DEBUG - 2016-09-19 13:03:20 --> Total execution time: 1.2473
INFO - 2016-09-19 13:03:32 --> Config Class Initialized
INFO - 2016-09-19 13:03:32 --> Hooks Class Initialized
DEBUG - 2016-09-19 13:03:32 --> UTF-8 Support Enabled
INFO - 2016-09-19 13:03:32 --> Utf8 Class Initialized
INFO - 2016-09-19 13:03:32 --> URI Class Initialized
INFO - 2016-09-19 13:03:32 --> Router Class Initialized
INFO - 2016-09-19 13:03:32 --> Output Class Initialized
INFO - 2016-09-19 13:03:32 --> Security Class Initialized
DEBUG - 2016-09-19 13:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-19 13:03:32 --> Input Class Initialized
INFO - 2016-09-19 13:03:32 --> Language Class Initialized
INFO - 2016-09-19 13:03:32 --> Language Class Initialized
INFO - 2016-09-19 13:03:32 --> Config Class Initialized
INFO - 2016-09-19 13:03:32 --> Loader Class Initialized
INFO - 2016-09-19 13:03:32 --> Helper loaded: url_helper
INFO - 2016-09-19 13:03:32 --> Database Driver Class Initialized
INFO - 2016-09-19 13:03:32 --> Controller Class Initialized
DEBUG - 2016-09-19 13:03:32 --> Index MX_Controller Initialized
INFO - 2016-09-19 13:03:32 --> Model Class Initialized
INFO - 2016-09-19 13:03:33 --> Model Class Initialized
DEBUG - 2016-09-19 13:03:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-19 13:03:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-19 13:03:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-19 13:03:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/dashboard.php
DEBUG - 2016-09-19 13:03:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-19 13:03:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-19 13:03:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-19 13:03:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-19 13:03:33 --> Final output sent to browser
DEBUG - 2016-09-19 13:03:33 --> Total execution time: 1.1934
