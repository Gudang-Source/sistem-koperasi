<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-10-03 02:06:54 --> Config Class Initialized
INFO - 2016-10-03 02:06:54 --> Hooks Class Initialized
DEBUG - 2016-10-03 02:06:54 --> UTF-8 Support Enabled
INFO - 2016-10-03 02:06:54 --> Utf8 Class Initialized
INFO - 2016-10-03 02:06:54 --> URI Class Initialized
INFO - 2016-10-03 02:06:54 --> Router Class Initialized
INFO - 2016-10-03 02:06:54 --> Output Class Initialized
INFO - 2016-10-03 02:06:54 --> Security Class Initialized
DEBUG - 2016-10-03 02:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 02:06:54 --> Input Class Initialized
INFO - 2016-10-03 02:06:54 --> Language Class Initialized
ERROR - 2016-10-03 02:06:54 --> 404 Page Not Found: /index
INFO - 2016-10-03 02:08:43 --> Config Class Initialized
INFO - 2016-10-03 02:08:43 --> Hooks Class Initialized
DEBUG - 2016-10-03 02:08:43 --> UTF-8 Support Enabled
INFO - 2016-10-03 02:08:43 --> Utf8 Class Initialized
INFO - 2016-10-03 02:08:43 --> URI Class Initialized
INFO - 2016-10-03 02:08:43 --> Router Class Initialized
INFO - 2016-10-03 02:08:43 --> Output Class Initialized
INFO - 2016-10-03 02:08:43 --> Security Class Initialized
DEBUG - 2016-10-03 02:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 02:08:43 --> Input Class Initialized
INFO - 2016-10-03 02:08:43 --> Language Class Initialized
ERROR - 2016-10-03 02:08:43 --> 404 Page Not Found: /index
INFO - 2016-10-03 03:36:41 --> Config Class Initialized
INFO - 2016-10-03 03:36:41 --> Hooks Class Initialized
DEBUG - 2016-10-03 03:36:41 --> UTF-8 Support Enabled
INFO - 2016-10-03 03:36:41 --> Utf8 Class Initialized
INFO - 2016-10-03 03:36:41 --> URI Class Initialized
INFO - 2016-10-03 03:36:41 --> Router Class Initialized
INFO - 2016-10-03 03:36:41 --> Output Class Initialized
INFO - 2016-10-03 03:36:41 --> Security Class Initialized
DEBUG - 2016-10-03 03:36:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 03:36:41 --> Input Class Initialized
INFO - 2016-10-03 03:36:41 --> Language Class Initialized
ERROR - 2016-10-03 03:36:41 --> 404 Page Not Found: /index
INFO - 2016-10-03 18:28:43 --> Config Class Initialized
INFO - 2016-10-03 18:28:43 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:28:43 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:28:43 --> Utf8 Class Initialized
INFO - 2016-10-03 18:28:43 --> URI Class Initialized
DEBUG - 2016-10-03 18:28:43 --> No URI present. Default controller set.
INFO - 2016-10-03 18:28:43 --> Router Class Initialized
INFO - 2016-10-03 18:28:43 --> Output Class Initialized
INFO - 2016-10-03 18:28:43 --> Security Class Initialized
DEBUG - 2016-10-03 18:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:28:43 --> Input Class Initialized
INFO - 2016-10-03 18:28:43 --> Language Class Initialized
INFO - 2016-10-03 18:28:43 --> Language Class Initialized
INFO - 2016-10-03 18:28:43 --> Config Class Initialized
INFO - 2016-10-03 18:28:43 --> Loader Class Initialized
INFO - 2016-10-03 18:28:43 --> Helper loaded: url_helper
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 18:28:43 --> Controller Class Initialized
DEBUG - 2016-10-03 18:28:43 --> Index MX_Controller Initialized
INFO - 2016-10-03 18:28:43 --> Model Class Initialized
INFO - 2016-10-03 18:28:43 --> Model Class Initialized
ERROR - 2016-10-03 18:28:43 --> Unable to delete cache file for 
DEBUG - 2016-10-03 18:28:43 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-10-03 18:28:43 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-10-03 18:28:43 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-10-03 18:28:43 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-10-03 18:28:43 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-10-03 18:28:43 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:28:43 --> Database Driver Class Initialized
DEBUG - 2016-10-03 18:28:43 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-10-03 18:28:43 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-10-03 18:28:43 --> Final output sent to browser
DEBUG - 2016-10-03 18:28:43 --> Total execution time: 0.2169
INFO - 2016-10-03 18:28:43 --> Config Class Initialized
INFO - 2016-10-03 18:28:43 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:28:43 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:28:43 --> Utf8 Class Initialized
INFO - 2016-10-03 18:28:43 --> URI Class Initialized
INFO - 2016-10-03 18:28:43 --> Router Class Initialized
INFO - 2016-10-03 18:28:43 --> Output Class Initialized
INFO - 2016-10-03 18:28:43 --> Security Class Initialized
DEBUG - 2016-10-03 18:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:28:43 --> Input Class Initialized
INFO - 2016-10-03 18:28:43 --> Language Class Initialized
ERROR - 2016-10-03 18:28:43 --> 404 Page Not Found: /index
INFO - 2016-10-03 18:28:43 --> Config Class Initialized
INFO - 2016-10-03 18:28:43 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:28:43 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:28:43 --> Utf8 Class Initialized
INFO - 2016-10-03 18:28:43 --> URI Class Initialized
INFO - 2016-10-03 18:28:43 --> Router Class Initialized
INFO - 2016-10-03 18:28:43 --> Output Class Initialized
INFO - 2016-10-03 18:28:43 --> Security Class Initialized
DEBUG - 2016-10-03 18:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:28:43 --> Input Class Initialized
INFO - 2016-10-03 18:28:43 --> Language Class Initialized
ERROR - 2016-10-03 18:28:43 --> 404 Page Not Found: /index
INFO - 2016-10-03 18:28:43 --> Config Class Initialized
INFO - 2016-10-03 18:28:43 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:28:43 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:28:43 --> Utf8 Class Initialized
INFO - 2016-10-03 18:28:43 --> URI Class Initialized
INFO - 2016-10-03 18:28:43 --> Router Class Initialized
INFO - 2016-10-03 18:28:43 --> Output Class Initialized
INFO - 2016-10-03 18:28:43 --> Security Class Initialized
DEBUG - 2016-10-03 18:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:28:43 --> Input Class Initialized
INFO - 2016-10-03 18:28:43 --> Language Class Initialized
ERROR - 2016-10-03 18:28:43 --> 404 Page Not Found: /index
INFO - 2016-10-03 18:28:43 --> Config Class Initialized
INFO - 2016-10-03 18:28:43 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:28:43 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:28:43 --> Utf8 Class Initialized
INFO - 2016-10-03 18:28:43 --> URI Class Initialized
INFO - 2016-10-03 18:28:43 --> Router Class Initialized
INFO - 2016-10-03 18:28:43 --> Output Class Initialized
INFO - 2016-10-03 18:28:43 --> Security Class Initialized
DEBUG - 2016-10-03 18:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:28:43 --> Input Class Initialized
INFO - 2016-10-03 18:28:43 --> Language Class Initialized
ERROR - 2016-10-03 18:28:43 --> 404 Page Not Found: /index
INFO - 2016-10-03 18:28:43 --> Config Class Initialized
INFO - 2016-10-03 18:28:43 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:28:43 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:28:43 --> Utf8 Class Initialized
INFO - 2016-10-03 18:28:43 --> URI Class Initialized
INFO - 2016-10-03 18:28:43 --> Router Class Initialized
INFO - 2016-10-03 18:28:43 --> Output Class Initialized
INFO - 2016-10-03 18:28:43 --> Security Class Initialized
DEBUG - 2016-10-03 18:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:28:43 --> Input Class Initialized
INFO - 2016-10-03 18:28:43 --> Language Class Initialized
ERROR - 2016-10-03 18:28:43 --> 404 Page Not Found: /index
INFO - 2016-10-03 18:28:43 --> Config Class Initialized
INFO - 2016-10-03 18:28:43 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:28:43 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:28:43 --> Utf8 Class Initialized
INFO - 2016-10-03 18:28:43 --> URI Class Initialized
INFO - 2016-10-03 18:28:43 --> Router Class Initialized
INFO - 2016-10-03 18:28:43 --> Output Class Initialized
INFO - 2016-10-03 18:28:43 --> Security Class Initialized
DEBUG - 2016-10-03 18:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:28:43 --> Input Class Initialized
INFO - 2016-10-03 18:28:43 --> Language Class Initialized
ERROR - 2016-10-03 18:28:43 --> 404 Page Not Found: /index
INFO - 2016-10-03 18:28:43 --> Config Class Initialized
INFO - 2016-10-03 18:28:43 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:28:43 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:28:43 --> Utf8 Class Initialized
INFO - 2016-10-03 18:28:43 --> URI Class Initialized
INFO - 2016-10-03 18:28:43 --> Router Class Initialized
INFO - 2016-10-03 18:28:43 --> Output Class Initialized
INFO - 2016-10-03 18:28:43 --> Security Class Initialized
DEBUG - 2016-10-03 18:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:28:43 --> Input Class Initialized
INFO - 2016-10-03 18:28:43 --> Language Class Initialized
ERROR - 2016-10-03 18:28:43 --> 404 Page Not Found: /index
INFO - 2016-10-03 18:28:43 --> Config Class Initialized
INFO - 2016-10-03 18:28:43 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:28:43 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:28:43 --> Utf8 Class Initialized
INFO - 2016-10-03 18:28:43 --> URI Class Initialized
INFO - 2016-10-03 18:28:43 --> Router Class Initialized
INFO - 2016-10-03 18:28:43 --> Output Class Initialized
INFO - 2016-10-03 18:28:43 --> Security Class Initialized
DEBUG - 2016-10-03 18:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:28:43 --> Input Class Initialized
INFO - 2016-10-03 18:28:43 --> Language Class Initialized
ERROR - 2016-10-03 18:28:43 --> 404 Page Not Found: /index
INFO - 2016-10-03 18:28:43 --> Config Class Initialized
INFO - 2016-10-03 18:28:43 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:28:43 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:28:43 --> Utf8 Class Initialized
INFO - 2016-10-03 18:28:43 --> URI Class Initialized
INFO - 2016-10-03 18:28:43 --> Router Class Initialized
INFO - 2016-10-03 18:28:43 --> Output Class Initialized
INFO - 2016-10-03 18:28:43 --> Security Class Initialized
DEBUG - 2016-10-03 18:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:28:43 --> Input Class Initialized
INFO - 2016-10-03 18:28:43 --> Language Class Initialized
ERROR - 2016-10-03 18:28:43 --> 404 Page Not Found: /index
INFO - 2016-10-03 18:28:43 --> Config Class Initialized
INFO - 2016-10-03 18:28:43 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:28:43 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:28:43 --> Utf8 Class Initialized
INFO - 2016-10-03 18:28:43 --> URI Class Initialized
INFO - 2016-10-03 18:28:43 --> Router Class Initialized
INFO - 2016-10-03 18:28:43 --> Output Class Initialized
INFO - 2016-10-03 18:28:43 --> Security Class Initialized
DEBUG - 2016-10-03 18:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:28:43 --> Input Class Initialized
INFO - 2016-10-03 18:28:43 --> Language Class Initialized
ERROR - 2016-10-03 18:28:43 --> 404 Page Not Found: /index
INFO - 2016-10-03 18:28:43 --> Config Class Initialized
INFO - 2016-10-03 18:28:43 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:28:43 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:28:43 --> Utf8 Class Initialized
INFO - 2016-10-03 18:28:43 --> URI Class Initialized
INFO - 2016-10-03 18:28:43 --> Router Class Initialized
INFO - 2016-10-03 18:28:43 --> Output Class Initialized
INFO - 2016-10-03 18:28:43 --> Security Class Initialized
DEBUG - 2016-10-03 18:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:28:43 --> Input Class Initialized
INFO - 2016-10-03 18:28:43 --> Language Class Initialized
ERROR - 2016-10-03 18:28:43 --> 404 Page Not Found: /index
INFO - 2016-10-03 18:28:44 --> Config Class Initialized
INFO - 2016-10-03 18:28:44 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:28:44 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:28:44 --> Utf8 Class Initialized
INFO - 2016-10-03 18:28:44 --> URI Class Initialized
INFO - 2016-10-03 18:28:44 --> Router Class Initialized
INFO - 2016-10-03 18:28:44 --> Output Class Initialized
INFO - 2016-10-03 18:28:44 --> Security Class Initialized
DEBUG - 2016-10-03 18:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:28:44 --> Input Class Initialized
INFO - 2016-10-03 18:28:44 --> Language Class Initialized
ERROR - 2016-10-03 18:28:44 --> 404 Page Not Found: /index
INFO - 2016-10-03 18:28:44 --> Config Class Initialized
INFO - 2016-10-03 18:28:44 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:28:44 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:28:44 --> Utf8 Class Initialized
INFO - 2016-10-03 18:28:44 --> URI Class Initialized
INFO - 2016-10-03 18:28:44 --> Router Class Initialized
INFO - 2016-10-03 18:28:44 --> Output Class Initialized
INFO - 2016-10-03 18:28:44 --> Security Class Initialized
DEBUG - 2016-10-03 18:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:28:44 --> Input Class Initialized
INFO - 2016-10-03 18:28:44 --> Language Class Initialized
ERROR - 2016-10-03 18:28:44 --> 404 Page Not Found: /index
INFO - 2016-10-03 18:28:44 --> Config Class Initialized
INFO - 2016-10-03 18:28:44 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:28:44 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:28:44 --> Utf8 Class Initialized
INFO - 2016-10-03 18:28:44 --> URI Class Initialized
INFO - 2016-10-03 18:28:44 --> Router Class Initialized
INFO - 2016-10-03 18:28:44 --> Output Class Initialized
INFO - 2016-10-03 18:28:44 --> Security Class Initialized
DEBUG - 2016-10-03 18:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:28:44 --> Input Class Initialized
INFO - 2016-10-03 18:28:44 --> Language Class Initialized
ERROR - 2016-10-03 18:28:44 --> 404 Page Not Found: /index
INFO - 2016-10-03 20:30:36 --> Config Class Initialized
INFO - 2016-10-03 20:30:36 --> Hooks Class Initialized
DEBUG - 2016-10-03 20:30:36 --> UTF-8 Support Enabled
INFO - 2016-10-03 20:30:36 --> Utf8 Class Initialized
INFO - 2016-10-03 20:30:36 --> URI Class Initialized
DEBUG - 2016-10-03 20:30:36 --> No URI present. Default controller set.
INFO - 2016-10-03 20:30:36 --> Router Class Initialized
INFO - 2016-10-03 20:30:36 --> Output Class Initialized
INFO - 2016-10-03 20:30:36 --> Security Class Initialized
DEBUG - 2016-10-03 20:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 20:30:36 --> Input Class Initialized
INFO - 2016-10-03 20:30:36 --> Language Class Initialized
INFO - 2016-10-03 20:30:36 --> Language Class Initialized
INFO - 2016-10-03 20:30:36 --> Config Class Initialized
INFO - 2016-10-03 20:30:36 --> Loader Class Initialized
INFO - 2016-10-03 20:30:36 --> Helper loaded: url_helper
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 20:30:36 --> Controller Class Initialized
DEBUG - 2016-10-03 20:30:36 --> Index MX_Controller Initialized
INFO - 2016-10-03 20:30:36 --> Model Class Initialized
INFO - 2016-10-03 20:30:36 --> Model Class Initialized
ERROR - 2016-10-03 20:30:36 --> Unable to delete cache file for 
DEBUG - 2016-10-03 20:30:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-10-03 20:30:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-10-03 20:30:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-10-03 20:30:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-10-03 20:30:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-10-03 20:30:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
INFO - 2016-10-03 20:30:36 --> Database Driver Class Initialized
DEBUG - 2016-10-03 20:30:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-10-03 20:30:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-10-03 20:30:36 --> Final output sent to browser
DEBUG - 2016-10-03 20:30:36 --> Total execution time: 0.4782
INFO - 2016-10-03 20:30:37 --> Config Class Initialized
INFO - 2016-10-03 20:30:37 --> Hooks Class Initialized
DEBUG - 2016-10-03 20:30:37 --> UTF-8 Support Enabled
INFO - 2016-10-03 20:30:37 --> Utf8 Class Initialized
INFO - 2016-10-03 20:30:37 --> URI Class Initialized
INFO - 2016-10-03 20:30:37 --> Router Class Initialized
INFO - 2016-10-03 20:30:37 --> Output Class Initialized
INFO - 2016-10-03 20:30:37 --> Security Class Initialized
DEBUG - 2016-10-03 20:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 20:30:37 --> Input Class Initialized
INFO - 2016-10-03 20:30:37 --> Language Class Initialized
ERROR - 2016-10-03 20:30:37 --> 404 Page Not Found: /index
INFO - 2016-10-03 20:30:37 --> Config Class Initialized
INFO - 2016-10-03 20:30:37 --> Hooks Class Initialized
DEBUG - 2016-10-03 20:30:37 --> UTF-8 Support Enabled
INFO - 2016-10-03 20:30:37 --> Utf8 Class Initialized
INFO - 2016-10-03 20:30:37 --> URI Class Initialized
INFO - 2016-10-03 20:30:37 --> Router Class Initialized
INFO - 2016-10-03 20:30:37 --> Output Class Initialized
INFO - 2016-10-03 20:30:37 --> Security Class Initialized
DEBUG - 2016-10-03 20:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 20:30:37 --> Input Class Initialized
INFO - 2016-10-03 20:30:37 --> Language Class Initialized
ERROR - 2016-10-03 20:30:37 --> 404 Page Not Found: /index
INFO - 2016-10-03 20:30:37 --> Config Class Initialized
INFO - 2016-10-03 20:30:37 --> Hooks Class Initialized
DEBUG - 2016-10-03 20:30:37 --> UTF-8 Support Enabled
INFO - 2016-10-03 20:30:37 --> Utf8 Class Initialized
INFO - 2016-10-03 20:30:37 --> URI Class Initialized
INFO - 2016-10-03 20:30:37 --> Router Class Initialized
INFO - 2016-10-03 20:30:37 --> Output Class Initialized
INFO - 2016-10-03 20:30:37 --> Security Class Initialized
DEBUG - 2016-10-03 20:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 20:30:37 --> Input Class Initialized
INFO - 2016-10-03 20:30:37 --> Language Class Initialized
ERROR - 2016-10-03 20:30:37 --> 404 Page Not Found: /index
INFO - 2016-10-03 20:30:38 --> Config Class Initialized
INFO - 2016-10-03 20:30:38 --> Hooks Class Initialized
DEBUG - 2016-10-03 20:30:38 --> UTF-8 Support Enabled
INFO - 2016-10-03 20:30:38 --> Utf8 Class Initialized
INFO - 2016-10-03 20:30:38 --> URI Class Initialized
INFO - 2016-10-03 20:30:38 --> Router Class Initialized
INFO - 2016-10-03 20:30:38 --> Output Class Initialized
INFO - 2016-10-03 20:30:38 --> Security Class Initialized
DEBUG - 2016-10-03 20:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 20:30:38 --> Input Class Initialized
INFO - 2016-10-03 20:30:38 --> Language Class Initialized
ERROR - 2016-10-03 20:30:38 --> 404 Page Not Found: /index
INFO - 2016-10-03 20:30:38 --> Config Class Initialized
INFO - 2016-10-03 20:30:38 --> Hooks Class Initialized
DEBUG - 2016-10-03 20:30:38 --> UTF-8 Support Enabled
INFO - 2016-10-03 20:30:38 --> Utf8 Class Initialized
INFO - 2016-10-03 20:30:38 --> URI Class Initialized
INFO - 2016-10-03 20:30:38 --> Router Class Initialized
INFO - 2016-10-03 20:30:38 --> Output Class Initialized
INFO - 2016-10-03 20:30:38 --> Security Class Initialized
DEBUG - 2016-10-03 20:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 20:30:38 --> Input Class Initialized
INFO - 2016-10-03 20:30:38 --> Language Class Initialized
ERROR - 2016-10-03 20:30:38 --> 404 Page Not Found: /index
INFO - 2016-10-03 20:30:38 --> Config Class Initialized
INFO - 2016-10-03 20:30:38 --> Hooks Class Initialized
DEBUG - 2016-10-03 20:30:38 --> UTF-8 Support Enabled
INFO - 2016-10-03 20:30:38 --> Utf8 Class Initialized
INFO - 2016-10-03 20:30:38 --> URI Class Initialized
INFO - 2016-10-03 20:30:38 --> Router Class Initialized
INFO - 2016-10-03 20:30:38 --> Output Class Initialized
INFO - 2016-10-03 20:30:38 --> Security Class Initialized
DEBUG - 2016-10-03 20:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 20:30:38 --> Input Class Initialized
INFO - 2016-10-03 20:30:38 --> Language Class Initialized
ERROR - 2016-10-03 20:30:38 --> 404 Page Not Found: /index
INFO - 2016-10-03 20:30:38 --> Config Class Initialized
INFO - 2016-10-03 20:30:38 --> Hooks Class Initialized
DEBUG - 2016-10-03 20:30:38 --> UTF-8 Support Enabled
INFO - 2016-10-03 20:30:38 --> Utf8 Class Initialized
INFO - 2016-10-03 20:30:38 --> URI Class Initialized
INFO - 2016-10-03 20:30:38 --> Router Class Initialized
INFO - 2016-10-03 20:30:39 --> Output Class Initialized
INFO - 2016-10-03 20:30:39 --> Security Class Initialized
DEBUG - 2016-10-03 20:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 20:30:39 --> Input Class Initialized
INFO - 2016-10-03 20:30:39 --> Language Class Initialized
ERROR - 2016-10-03 20:30:39 --> 404 Page Not Found: /index
INFO - 2016-10-03 20:30:39 --> Config Class Initialized
INFO - 2016-10-03 20:30:39 --> Hooks Class Initialized
DEBUG - 2016-10-03 20:30:39 --> UTF-8 Support Enabled
INFO - 2016-10-03 20:30:39 --> Utf8 Class Initialized
INFO - 2016-10-03 20:30:39 --> URI Class Initialized
INFO - 2016-10-03 20:30:39 --> Router Class Initialized
INFO - 2016-10-03 20:30:39 --> Output Class Initialized
INFO - 2016-10-03 20:30:39 --> Security Class Initialized
DEBUG - 2016-10-03 20:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 20:30:39 --> Input Class Initialized
INFO - 2016-10-03 20:30:39 --> Language Class Initialized
ERROR - 2016-10-03 20:30:39 --> 404 Page Not Found: /index
INFO - 2016-10-03 20:30:39 --> Config Class Initialized
INFO - 2016-10-03 20:30:39 --> Hooks Class Initialized
DEBUG - 2016-10-03 20:30:39 --> UTF-8 Support Enabled
INFO - 2016-10-03 20:30:39 --> Utf8 Class Initialized
INFO - 2016-10-03 20:30:39 --> URI Class Initialized
INFO - 2016-10-03 20:30:39 --> Router Class Initialized
INFO - 2016-10-03 20:30:39 --> Output Class Initialized
INFO - 2016-10-03 20:30:39 --> Security Class Initialized
DEBUG - 2016-10-03 20:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 20:30:39 --> Input Class Initialized
INFO - 2016-10-03 20:30:39 --> Language Class Initialized
ERROR - 2016-10-03 20:30:39 --> 404 Page Not Found: /index
INFO - 2016-10-03 20:30:39 --> Config Class Initialized
INFO - 2016-10-03 20:30:39 --> Hooks Class Initialized
DEBUG - 2016-10-03 20:30:39 --> UTF-8 Support Enabled
INFO - 2016-10-03 20:30:39 --> Utf8 Class Initialized
INFO - 2016-10-03 20:30:39 --> URI Class Initialized
INFO - 2016-10-03 20:30:39 --> Router Class Initialized
INFO - 2016-10-03 20:30:39 --> Output Class Initialized
INFO - 2016-10-03 20:30:39 --> Security Class Initialized
DEBUG - 2016-10-03 20:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 20:30:39 --> Input Class Initialized
INFO - 2016-10-03 20:30:39 --> Language Class Initialized
ERROR - 2016-10-03 20:30:39 --> 404 Page Not Found: /index
INFO - 2016-10-03 20:30:40 --> Config Class Initialized
INFO - 2016-10-03 20:30:40 --> Hooks Class Initialized
DEBUG - 2016-10-03 20:30:40 --> UTF-8 Support Enabled
INFO - 2016-10-03 20:30:40 --> Utf8 Class Initialized
INFO - 2016-10-03 20:30:40 --> URI Class Initialized
INFO - 2016-10-03 20:30:40 --> Router Class Initialized
INFO - 2016-10-03 20:30:40 --> Output Class Initialized
INFO - 2016-10-03 20:30:40 --> Security Class Initialized
DEBUG - 2016-10-03 20:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 20:30:40 --> Input Class Initialized
INFO - 2016-10-03 20:30:40 --> Language Class Initialized
ERROR - 2016-10-03 20:30:40 --> 404 Page Not Found: /index
INFO - 2016-10-03 20:30:40 --> Config Class Initialized
INFO - 2016-10-03 20:30:40 --> Hooks Class Initialized
DEBUG - 2016-10-03 20:30:40 --> UTF-8 Support Enabled
INFO - 2016-10-03 20:30:40 --> Utf8 Class Initialized
INFO - 2016-10-03 20:30:40 --> URI Class Initialized
INFO - 2016-10-03 20:30:40 --> Router Class Initialized
INFO - 2016-10-03 20:30:40 --> Output Class Initialized
INFO - 2016-10-03 20:30:40 --> Security Class Initialized
DEBUG - 2016-10-03 20:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 20:30:40 --> Input Class Initialized
INFO - 2016-10-03 20:30:40 --> Language Class Initialized
ERROR - 2016-10-03 20:30:40 --> 404 Page Not Found: /index
INFO - 2016-10-03 20:30:40 --> Config Class Initialized
INFO - 2016-10-03 20:30:40 --> Hooks Class Initialized
DEBUG - 2016-10-03 20:30:40 --> UTF-8 Support Enabled
INFO - 2016-10-03 20:30:40 --> Utf8 Class Initialized
INFO - 2016-10-03 20:30:40 --> URI Class Initialized
INFO - 2016-10-03 20:30:40 --> Router Class Initialized
INFO - 2016-10-03 20:30:40 --> Output Class Initialized
INFO - 2016-10-03 20:30:40 --> Security Class Initialized
DEBUG - 2016-10-03 20:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 20:30:40 --> Input Class Initialized
INFO - 2016-10-03 20:30:40 --> Language Class Initialized
ERROR - 2016-10-03 20:30:40 --> 404 Page Not Found: /index
INFO - 2016-10-03 20:30:41 --> Config Class Initialized
INFO - 2016-10-03 20:30:41 --> Hooks Class Initialized
DEBUG - 2016-10-03 20:30:41 --> UTF-8 Support Enabled
INFO - 2016-10-03 20:30:41 --> Utf8 Class Initialized
INFO - 2016-10-03 20:30:41 --> URI Class Initialized
INFO - 2016-10-03 20:30:41 --> Router Class Initialized
INFO - 2016-10-03 20:30:41 --> Output Class Initialized
INFO - 2016-10-03 20:30:41 --> Security Class Initialized
DEBUG - 2016-10-03 20:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 20:30:41 --> Input Class Initialized
INFO - 2016-10-03 20:30:41 --> Language Class Initialized
ERROR - 2016-10-03 20:30:41 --> 404 Page Not Found: /index
INFO - 2016-10-03 22:31:10 --> Config Class Initialized
INFO - 2016-10-03 22:31:10 --> Hooks Class Initialized
DEBUG - 2016-10-03 22:31:10 --> UTF-8 Support Enabled
INFO - 2016-10-03 22:31:10 --> Utf8 Class Initialized
INFO - 2016-10-03 22:31:10 --> URI Class Initialized
INFO - 2016-10-03 22:31:10 --> Router Class Initialized
INFO - 2016-10-03 22:31:10 --> Output Class Initialized
INFO - 2016-10-03 22:31:10 --> Security Class Initialized
DEBUG - 2016-10-03 22:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 22:31:10 --> Input Class Initialized
INFO - 2016-10-03 22:31:10 --> Language Class Initialized
ERROR - 2016-10-03 22:31:10 --> 404 Page Not Found: /index
INFO - 2016-10-03 22:31:26 --> Config Class Initialized
INFO - 2016-10-03 22:31:26 --> Hooks Class Initialized
DEBUG - 2016-10-03 22:31:26 --> UTF-8 Support Enabled
INFO - 2016-10-03 22:31:26 --> Utf8 Class Initialized
INFO - 2016-10-03 22:31:26 --> URI Class Initialized
DEBUG - 2016-10-03 22:31:26 --> No URI present. Default controller set.
INFO - 2016-10-03 22:31:26 --> Router Class Initialized
INFO - 2016-10-03 22:31:26 --> Output Class Initialized
INFO - 2016-10-03 22:31:26 --> Security Class Initialized
DEBUG - 2016-10-03 22:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 22:31:26 --> Input Class Initialized
INFO - 2016-10-03 22:31:26 --> Language Class Initialized
INFO - 2016-10-03 22:31:26 --> Language Class Initialized
INFO - 2016-10-03 22:31:26 --> Config Class Initialized
INFO - 2016-10-03 22:31:26 --> Loader Class Initialized
INFO - 2016-10-03 22:31:26 --> Helper loaded: url_helper
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 22:31:27 --> Controller Class Initialized
DEBUG - 2016-10-03 22:31:27 --> Index MX_Controller Initialized
INFO - 2016-10-03 22:31:27 --> Model Class Initialized
INFO - 2016-10-03 22:31:27 --> Model Class Initialized
ERROR - 2016-10-03 22:31:27 --> Unable to delete cache file for 
DEBUG - 2016-10-03 22:31:27 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-10-03 22:31:27 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-10-03 22:31:27 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-10-03 22:31:27 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-10-03 22:31:27 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-10-03 22:31:27 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:27 --> Database Driver Class Initialized
DEBUG - 2016-10-03 22:31:27 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-10-03 22:31:27 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-10-03 22:31:27 --> Final output sent to browser
DEBUG - 2016-10-03 22:31:27 --> Total execution time: 0.2678
INFO - 2016-10-03 22:31:43 --> Config Class Initialized
INFO - 2016-10-03 22:31:43 --> Hooks Class Initialized
DEBUG - 2016-10-03 22:31:43 --> UTF-8 Support Enabled
INFO - 2016-10-03 22:31:43 --> Utf8 Class Initialized
INFO - 2016-10-03 22:31:43 --> URI Class Initialized
INFO - 2016-10-03 22:31:43 --> Router Class Initialized
INFO - 2016-10-03 22:31:43 --> Output Class Initialized
INFO - 2016-10-03 22:31:43 --> Security Class Initialized
DEBUG - 2016-10-03 22:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 22:31:43 --> Input Class Initialized
INFO - 2016-10-03 22:31:43 --> Language Class Initialized
INFO - 2016-10-03 22:31:43 --> Language Class Initialized
INFO - 2016-10-03 22:31:43 --> Config Class Initialized
INFO - 2016-10-03 22:31:43 --> Loader Class Initialized
INFO - 2016-10-03 22:31:43 --> Helper loaded: url_helper
INFO - 2016-10-03 22:31:43 --> Database Driver Class Initialized
INFO - 2016-10-03 22:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 22:31:43 --> Controller Class Initialized
DEBUG - 2016-10-03 22:31:43 --> login MX_Controller Initialized
INFO - 2016-10-03 22:31:43 --> Model Class Initialized
INFO - 2016-10-03 22:31:43 --> Model Class Initialized
DEBUG - 2016-10-03 22:31:43 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-10-03 22:31:43 --> Final output sent to browser
DEBUG - 2016-10-03 22:31:43 --> Total execution time: 0.0467
INFO - 2016-10-03 18:52:39 --> Config Class Initialized
INFO - 2016-10-03 18:52:40 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:52:40 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:52:40 --> Utf8 Class Initialized
INFO - 2016-10-03 18:52:40 --> URI Class Initialized
DEBUG - 2016-10-03 18:52:40 --> No URI present. Default controller set.
INFO - 2016-10-03 18:52:40 --> Router Class Initialized
INFO - 2016-10-03 18:52:40 --> Output Class Initialized
INFO - 2016-10-03 18:52:40 --> Security Class Initialized
DEBUG - 2016-10-03 18:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:52:40 --> Input Class Initialized
INFO - 2016-10-03 18:52:40 --> Language Class Initialized
INFO - 2016-10-03 18:52:40 --> Language Class Initialized
INFO - 2016-10-03 18:52:40 --> Config Class Initialized
INFO - 2016-10-03 18:52:40 --> Loader Class Initialized
INFO - 2016-10-03 18:52:40 --> Helper loaded: url_helper
INFO - 2016-10-03 18:52:40 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 18:52:41 --> Controller Class Initialized
DEBUG - 2016-10-03 18:52:41 --> Index MX_Controller Initialized
INFO - 2016-10-03 18:52:41 --> Model Class Initialized
INFO - 2016-10-03 18:52:41 --> Model Class Initialized
ERROR - 2016-10-03 18:52:41 --> Unable to delete cache file for 
DEBUG - 2016-10-03 18:52:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-03 18:52:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-03 18:52:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-03 18:52:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/dashboard.php
DEBUG - 2016-10-03 18:52:42 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-03 18:52:42 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-03 18:52:42 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:42 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:42 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:42 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:43 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:44 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:44 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:44 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:44 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:44 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:44 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:44 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:44 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:44 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:44 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:44 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:45 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:45 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:45 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:45 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:45 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:45 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:45 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:45 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:45 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:45 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:45 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:45 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:45 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:45 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:45 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:45 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:45 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:45 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:45 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:46 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:46 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:46 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:46 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:46 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:46 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:46 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:46 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:46 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:46 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:46 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:46 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:46 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:46 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:46 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:46 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:46 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:46 --> Database Driver Class Initialized
INFO - 2016-10-03 18:52:46 --> Database Driver Class Initialized
DEBUG - 2016-10-03 18:52:46 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-03 18:52:46 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-03 18:52:47 --> Final output sent to browser
DEBUG - 2016-10-03 18:52:47 --> Total execution time: 7.2472
INFO - 2016-10-03 18:53:18 --> Config Class Initialized
INFO - 2016-10-03 18:53:18 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:53:18 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:53:18 --> Utf8 Class Initialized
INFO - 2016-10-03 18:53:18 --> URI Class Initialized
INFO - 2016-10-03 18:53:18 --> Router Class Initialized
INFO - 2016-10-03 18:53:18 --> Output Class Initialized
INFO - 2016-10-03 18:53:18 --> Security Class Initialized
DEBUG - 2016-10-03 18:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:53:18 --> Input Class Initialized
INFO - 2016-10-03 18:53:18 --> Language Class Initialized
INFO - 2016-10-03 18:53:18 --> Language Class Initialized
INFO - 2016-10-03 18:53:18 --> Config Class Initialized
INFO - 2016-10-03 18:53:18 --> Loader Class Initialized
INFO - 2016-10-03 18:53:18 --> Helper loaded: url_helper
INFO - 2016-10-03 18:53:18 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 18:53:18 --> Controller Class Initialized
DEBUG - 2016-10-03 18:53:18 --> Index MX_Controller Initialized
INFO - 2016-10-03 18:53:18 --> Model Class Initialized
INFO - 2016-10-03 18:53:18 --> Model Class Initialized
ERROR - 2016-10-03 18:53:18 --> Unable to delete cache file for admin/index
DEBUG - 2016-10-03 18:53:18 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-03 18:53:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-03 18:53:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-03 18:53:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/dashboard.php
DEBUG - 2016-10-03 18:53:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-03 18:53:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-03 18:53:19 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:19 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:19 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:19 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:19 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:19 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:19 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:19 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:19 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:19 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:19 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:19 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:19 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:19 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:19 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:19 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:19 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:19 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:19 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:19 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:19 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:19 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:19 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:19 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:19 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:20 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:20 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:20 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:20 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:20 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:20 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:20 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:20 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:20 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:20 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:20 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:20 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:20 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:20 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:20 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:20 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:20 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:20 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:20 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:20 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:20 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:20 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:20 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:20 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:20 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:20 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:20 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:20 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:20 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:20 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:21 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:21 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:21 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:21 --> Database Driver Class Initialized
DEBUG - 2016-10-03 18:53:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-03 18:53:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-03 18:53:21 --> Final output sent to browser
DEBUG - 2016-10-03 18:53:21 --> Total execution time: 2.8076
INFO - 2016-10-03 18:53:27 --> Config Class Initialized
INFO - 2016-10-03 18:53:27 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:53:27 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:53:27 --> Utf8 Class Initialized
INFO - 2016-10-03 18:53:27 --> URI Class Initialized
INFO - 2016-10-03 18:53:27 --> Router Class Initialized
INFO - 2016-10-03 18:53:27 --> Output Class Initialized
INFO - 2016-10-03 18:53:27 --> Security Class Initialized
DEBUG - 2016-10-03 18:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:53:27 --> Input Class Initialized
INFO - 2016-10-03 18:53:27 --> Language Class Initialized
INFO - 2016-10-03 18:53:27 --> Language Class Initialized
INFO - 2016-10-03 18:53:27 --> Config Class Initialized
INFO - 2016-10-03 18:53:27 --> Loader Class Initialized
INFO - 2016-10-03 18:53:27 --> Helper loaded: url_helper
INFO - 2016-10-03 18:53:27 --> Database Driver Class Initialized
INFO - 2016-10-03 18:53:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 18:53:27 --> Controller Class Initialized
DEBUG - 2016-10-03 18:53:27 --> login MX_Controller Initialized
INFO - 2016-10-03 18:53:27 --> Model Class Initialized
INFO - 2016-10-03 18:53:27 --> Model Class Initialized
DEBUG - 2016-10-03 18:53:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/login.php
INFO - 2016-10-03 18:53:27 --> Final output sent to browser
DEBUG - 2016-10-03 18:53:27 --> Total execution time: 0.5213
INFO - 2016-10-03 18:55:32 --> Config Class Initialized
INFO - 2016-10-03 18:55:32 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:55:32 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:55:32 --> Utf8 Class Initialized
INFO - 2016-10-03 18:55:32 --> URI Class Initialized
INFO - 2016-10-03 18:55:32 --> Router Class Initialized
INFO - 2016-10-03 18:55:32 --> Output Class Initialized
INFO - 2016-10-03 18:55:32 --> Security Class Initialized
DEBUG - 2016-10-03 18:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:55:33 --> Input Class Initialized
INFO - 2016-10-03 18:55:33 --> Language Class Initialized
INFO - 2016-10-03 18:55:33 --> Language Class Initialized
INFO - 2016-10-03 18:55:33 --> Config Class Initialized
INFO - 2016-10-03 18:55:33 --> Loader Class Initialized
INFO - 2016-10-03 18:55:33 --> Helper loaded: url_helper
INFO - 2016-10-03 18:55:33 --> Database Driver Class Initialized
INFO - 2016-10-03 18:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 18:55:33 --> Controller Class Initialized
DEBUG - 2016-10-03 18:55:33 --> login MX_Controller Initialized
INFO - 2016-10-03 18:55:33 --> Model Class Initialized
INFO - 2016-10-03 18:55:33 --> Model Class Initialized
DEBUG - 2016-10-03 18:55:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/login.php
INFO - 2016-10-03 18:55:33 --> Final output sent to browser
DEBUG - 2016-10-03 18:55:33 --> Total execution time: 0.5531
INFO - 2016-10-03 18:55:40 --> Config Class Initialized
INFO - 2016-10-03 18:55:40 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:55:40 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:55:40 --> Utf8 Class Initialized
INFO - 2016-10-03 18:55:40 --> URI Class Initialized
INFO - 2016-10-03 18:55:40 --> Router Class Initialized
INFO - 2016-10-03 18:55:40 --> Output Class Initialized
INFO - 2016-10-03 18:55:40 --> Security Class Initialized
DEBUG - 2016-10-03 18:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:55:40 --> Input Class Initialized
INFO - 2016-10-03 18:55:40 --> Language Class Initialized
INFO - 2016-10-03 18:55:40 --> Language Class Initialized
INFO - 2016-10-03 18:55:40 --> Config Class Initialized
INFO - 2016-10-03 18:55:40 --> Loader Class Initialized
INFO - 2016-10-03 18:55:40 --> Helper loaded: url_helper
INFO - 2016-10-03 18:55:41 --> Database Driver Class Initialized
INFO - 2016-10-03 18:55:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 18:55:41 --> Controller Class Initialized
DEBUG - 2016-10-03 18:55:41 --> login MX_Controller Initialized
INFO - 2016-10-03 18:55:41 --> Model Class Initialized
INFO - 2016-10-03 18:55:41 --> Model Class Initialized
INFO - 2016-10-03 18:55:41 --> Final output sent to browser
DEBUG - 2016-10-03 18:55:41 --> Total execution time: 0.4837
INFO - 2016-10-03 18:55:44 --> Config Class Initialized
INFO - 2016-10-03 18:55:44 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:55:44 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:55:44 --> Utf8 Class Initialized
INFO - 2016-10-03 18:55:44 --> URI Class Initialized
INFO - 2016-10-03 18:55:44 --> Router Class Initialized
INFO - 2016-10-03 18:55:44 --> Output Class Initialized
INFO - 2016-10-03 18:55:44 --> Security Class Initialized
DEBUG - 2016-10-03 18:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:55:44 --> Input Class Initialized
INFO - 2016-10-03 18:55:44 --> Language Class Initialized
INFO - 2016-10-03 18:55:44 --> Language Class Initialized
INFO - 2016-10-03 18:55:44 --> Config Class Initialized
INFO - 2016-10-03 18:55:44 --> Loader Class Initialized
INFO - 2016-10-03 18:55:44 --> Helper loaded: url_helper
INFO - 2016-10-03 18:55:44 --> Database Driver Class Initialized
INFO - 2016-10-03 18:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 18:55:45 --> Controller Class Initialized
DEBUG - 2016-10-03 18:55:45 --> login MX_Controller Initialized
INFO - 2016-10-03 18:55:45 --> Model Class Initialized
INFO - 2016-10-03 18:55:45 --> Model Class Initialized
INFO - 2016-10-03 18:55:45 --> Final output sent to browser
DEBUG - 2016-10-03 18:55:45 --> Total execution time: 0.4972
INFO - 2016-10-03 18:55:49 --> Config Class Initialized
INFO - 2016-10-03 18:55:49 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:55:49 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:55:49 --> Utf8 Class Initialized
INFO - 2016-10-03 18:55:49 --> URI Class Initialized
INFO - 2016-10-03 18:55:49 --> Router Class Initialized
INFO - 2016-10-03 18:55:49 --> Output Class Initialized
INFO - 2016-10-03 18:55:49 --> Security Class Initialized
DEBUG - 2016-10-03 18:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:55:49 --> Input Class Initialized
INFO - 2016-10-03 18:55:49 --> Language Class Initialized
INFO - 2016-10-03 18:55:49 --> Language Class Initialized
INFO - 2016-10-03 18:55:49 --> Config Class Initialized
INFO - 2016-10-03 18:55:49 --> Loader Class Initialized
INFO - 2016-10-03 18:55:50 --> Helper loaded: url_helper
INFO - 2016-10-03 18:55:50 --> Database Driver Class Initialized
INFO - 2016-10-03 18:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 18:55:50 --> Controller Class Initialized
DEBUG - 2016-10-03 18:55:50 --> login MX_Controller Initialized
INFO - 2016-10-03 18:55:50 --> Model Class Initialized
INFO - 2016-10-03 18:55:50 --> Model Class Initialized
INFO - 2016-10-03 18:55:50 --> Final output sent to browser
DEBUG - 2016-10-03 18:55:50 --> Total execution time: 0.5343
INFO - 2016-10-03 18:56:20 --> Config Class Initialized
INFO - 2016-10-03 18:56:20 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:56:20 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:56:20 --> Utf8 Class Initialized
INFO - 2016-10-03 18:56:21 --> URI Class Initialized
INFO - 2016-10-03 18:56:21 --> Router Class Initialized
INFO - 2016-10-03 18:56:21 --> Output Class Initialized
INFO - 2016-10-03 18:56:21 --> Security Class Initialized
DEBUG - 2016-10-03 18:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:56:21 --> Input Class Initialized
INFO - 2016-10-03 18:56:21 --> Language Class Initialized
INFO - 2016-10-03 18:56:21 --> Language Class Initialized
INFO - 2016-10-03 18:56:21 --> Config Class Initialized
INFO - 2016-10-03 18:56:21 --> Loader Class Initialized
INFO - 2016-10-03 18:56:21 --> Helper loaded: url_helper
INFO - 2016-10-03 18:56:21 --> Database Driver Class Initialized
INFO - 2016-10-03 18:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 18:56:21 --> Controller Class Initialized
DEBUG - 2016-10-03 18:56:21 --> login MX_Controller Initialized
INFO - 2016-10-03 18:56:21 --> Model Class Initialized
INFO - 2016-10-03 18:56:21 --> Model Class Initialized
INFO - 2016-10-03 18:56:21 --> Final output sent to browser
DEBUG - 2016-10-03 18:56:21 --> Total execution time: 0.4340
INFO - 2016-10-03 18:56:23 --> Config Class Initialized
INFO - 2016-10-03 18:56:23 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:56:23 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:56:23 --> Utf8 Class Initialized
INFO - 2016-10-03 18:56:23 --> URI Class Initialized
INFO - 2016-10-03 18:56:23 --> Router Class Initialized
INFO - 2016-10-03 18:56:23 --> Output Class Initialized
INFO - 2016-10-03 18:56:23 --> Security Class Initialized
DEBUG - 2016-10-03 18:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:56:23 --> Input Class Initialized
INFO - 2016-10-03 18:56:23 --> Language Class Initialized
INFO - 2016-10-03 18:56:23 --> Language Class Initialized
INFO - 2016-10-03 18:56:23 --> Config Class Initialized
INFO - 2016-10-03 18:56:23 --> Loader Class Initialized
INFO - 2016-10-03 18:56:23 --> Helper loaded: url_helper
INFO - 2016-10-03 18:56:23 --> Database Driver Class Initialized
INFO - 2016-10-03 18:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 18:56:23 --> Controller Class Initialized
DEBUG - 2016-10-03 18:56:23 --> login MX_Controller Initialized
INFO - 2016-10-03 18:56:23 --> Model Class Initialized
INFO - 2016-10-03 18:56:23 --> Model Class Initialized
INFO - 2016-10-03 18:56:23 --> Final output sent to browser
DEBUG - 2016-10-03 18:56:23 --> Total execution time: 0.4478
INFO - 2016-10-03 18:57:03 --> Config Class Initialized
INFO - 2016-10-03 18:57:03 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:57:03 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:57:03 --> Utf8 Class Initialized
INFO - 2016-10-03 18:57:03 --> URI Class Initialized
INFO - 2016-10-03 18:57:03 --> Router Class Initialized
INFO - 2016-10-03 18:57:03 --> Output Class Initialized
INFO - 2016-10-03 18:57:03 --> Security Class Initialized
DEBUG - 2016-10-03 18:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:57:03 --> Input Class Initialized
INFO - 2016-10-03 18:57:03 --> Language Class Initialized
INFO - 2016-10-03 18:57:03 --> Language Class Initialized
INFO - 2016-10-03 18:57:03 --> Config Class Initialized
INFO - 2016-10-03 18:57:03 --> Loader Class Initialized
INFO - 2016-10-03 18:57:03 --> Helper loaded: url_helper
INFO - 2016-10-03 18:57:03 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 18:57:03 --> Controller Class Initialized
DEBUG - 2016-10-03 18:57:03 --> login MX_Controller Initialized
INFO - 2016-10-03 18:57:03 --> Model Class Initialized
INFO - 2016-10-03 18:57:04 --> Model Class Initialized
INFO - 2016-10-03 18:57:04 --> Final output sent to browser
DEBUG - 2016-10-03 18:57:04 --> Total execution time: 0.5431
INFO - 2016-10-03 18:57:04 --> Config Class Initialized
INFO - 2016-10-03 18:57:04 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:57:04 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:57:04 --> Utf8 Class Initialized
INFO - 2016-10-03 18:57:04 --> URI Class Initialized
INFO - 2016-10-03 18:57:04 --> Router Class Initialized
INFO - 2016-10-03 18:57:04 --> Output Class Initialized
INFO - 2016-10-03 18:57:04 --> Security Class Initialized
DEBUG - 2016-10-03 18:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:57:04 --> Input Class Initialized
INFO - 2016-10-03 18:57:04 --> Language Class Initialized
INFO - 2016-10-03 18:57:04 --> Language Class Initialized
INFO - 2016-10-03 18:57:04 --> Config Class Initialized
INFO - 2016-10-03 18:57:04 --> Loader Class Initialized
INFO - 2016-10-03 18:57:04 --> Helper loaded: url_helper
INFO - 2016-10-03 18:57:04 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 18:57:04 --> Controller Class Initialized
DEBUG - 2016-10-03 18:57:04 --> Index MX_Controller Initialized
INFO - 2016-10-03 18:57:04 --> Model Class Initialized
INFO - 2016-10-03 18:57:04 --> Model Class Initialized
ERROR - 2016-10-03 18:57:04 --> Unable to delete cache file for admin/index
DEBUG - 2016-10-03 18:57:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-03 18:57:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-03 18:57:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-03 18:57:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/dashboard.php
DEBUG - 2016-10-03 18:57:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-03 18:57:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-03 18:57:04 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:04 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:04 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:04 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:05 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:05 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:05 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:05 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:05 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:05 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:05 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:05 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:05 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:05 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:05 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:05 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:05 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:05 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:05 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:05 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:05 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:05 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:05 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:05 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:05 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:05 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:05 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:05 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:05 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:05 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:05 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:05 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:05 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:05 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:05 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:05 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:06 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:06 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:06 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:06 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:06 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:06 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:06 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:06 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:06 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:06 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:06 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:06 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:06 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:06 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:06 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:06 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:06 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:06 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:06 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:06 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:06 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:06 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:06 --> Database Driver Class Initialized
DEBUG - 2016-10-03 18:57:06 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-03 18:57:06 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-03 18:57:06 --> Final output sent to browser
DEBUG - 2016-10-03 18:57:06 --> Total execution time: 2.5817
INFO - 2016-10-03 18:57:28 --> Config Class Initialized
INFO - 2016-10-03 18:57:28 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:57:28 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:57:28 --> Utf8 Class Initialized
INFO - 2016-10-03 18:57:28 --> URI Class Initialized
INFO - 2016-10-03 18:57:28 --> Router Class Initialized
INFO - 2016-10-03 18:57:28 --> Output Class Initialized
INFO - 2016-10-03 18:57:28 --> Security Class Initialized
DEBUG - 2016-10-03 18:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:57:28 --> Input Class Initialized
INFO - 2016-10-03 18:57:28 --> Language Class Initialized
INFO - 2016-10-03 18:57:28 --> Language Class Initialized
INFO - 2016-10-03 18:57:28 --> Config Class Initialized
INFO - 2016-10-03 18:57:28 --> Loader Class Initialized
INFO - 2016-10-03 18:57:28 --> Helper loaded: url_helper
INFO - 2016-10-03 18:57:29 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 18:57:29 --> Controller Class Initialized
DEBUG - 2016-10-03 18:57:29 --> Index MX_Controller Initialized
INFO - 2016-10-03 18:57:29 --> Model Class Initialized
INFO - 2016-10-03 18:57:29 --> Model Class Initialized
ERROR - 2016-10-03 18:57:29 --> Unable to delete cache file for admin/index/data/anggota
DEBUG - 2016-10-03 18:57:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-03 18:57:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-03 18:57:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-03 18:57:29 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-03 18:57:29 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-03 18:57:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-03 18:57:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-03 18:57:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-03 18:57:29 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:29 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:29 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:29 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:29 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:29 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:29 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:30 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:30 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:30 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:30 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:30 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:30 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:30 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:30 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:30 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:30 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:30 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:30 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:30 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:30 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:30 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:30 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:30 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:30 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:30 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:31 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:31 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:31 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:31 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:31 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:31 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:31 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:31 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:31 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:31 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:31 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:31 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:31 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:32 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:32 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:32 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:32 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:32 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:32 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:32 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:32 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:32 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:33 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:33 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:33 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:33 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:33 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:33 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:33 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:33 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:33 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:33 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:33 --> Database Driver Class Initialized
INFO - 2016-10-03 18:57:33 --> Database Driver Class Initialized
DEBUG - 2016-10-03 18:57:34 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-03 18:57:34 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-03 18:57:34 --> Final output sent to browser
DEBUG - 2016-10-03 18:57:34 --> Total execution time: 5.8733
