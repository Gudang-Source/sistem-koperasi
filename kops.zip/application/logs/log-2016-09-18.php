<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-09-18 16:00:40 --> Config Class Initialized
INFO - 2016-09-18 16:00:40 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:00:40 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:00:40 --> Utf8 Class Initialized
INFO - 2016-09-18 16:00:40 --> URI Class Initialized
INFO - 2016-09-18 16:00:40 --> Router Class Initialized
INFO - 2016-09-18 16:00:40 --> Output Class Initialized
INFO - 2016-09-18 16:00:40 --> Security Class Initialized
DEBUG - 2016-09-18 16:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:00:41 --> Input Class Initialized
INFO - 2016-09-18 16:00:41 --> Language Class Initialized
INFO - 2016-09-18 16:00:41 --> Language Class Initialized
INFO - 2016-09-18 16:00:41 --> Config Class Initialized
INFO - 2016-09-18 16:00:41 --> Loader Class Initialized
INFO - 2016-09-18 16:00:41 --> Helper loaded: url_helper
INFO - 2016-09-18 16:00:41 --> Database Driver Class Initialized
INFO - 2016-09-18 16:00:42 --> Controller Class Initialized
DEBUG - 2016-09-18 16:00:42 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:00:42 --> Model Class Initialized
INFO - 2016-09-18 16:00:42 --> Model Class Initialized
DEBUG - 2016-09-18 16:00:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 16:00:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 16:00:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 16:00:42 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-18 16:00:42 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-18 16:00:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-18 16:00:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 16:00:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 16:00:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 16:00:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 16:00:43 --> Final output sent to browser
DEBUG - 2016-09-18 16:00:43 --> Total execution time: 3.0694
INFO - 2016-09-18 16:02:32 --> Config Class Initialized
INFO - 2016-09-18 16:02:32 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:02:32 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:02:32 --> Utf8 Class Initialized
INFO - 2016-09-18 16:02:32 --> URI Class Initialized
INFO - 2016-09-18 16:02:32 --> Router Class Initialized
INFO - 2016-09-18 16:02:32 --> Output Class Initialized
INFO - 2016-09-18 16:02:32 --> Security Class Initialized
DEBUG - 2016-09-18 16:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:02:32 --> Input Class Initialized
INFO - 2016-09-18 16:02:32 --> Language Class Initialized
INFO - 2016-09-18 16:02:32 --> Language Class Initialized
INFO - 2016-09-18 16:02:32 --> Config Class Initialized
INFO - 2016-09-18 16:02:32 --> Loader Class Initialized
INFO - 2016-09-18 16:02:32 --> Helper loaded: url_helper
INFO - 2016-09-18 16:02:33 --> Database Driver Class Initialized
INFO - 2016-09-18 16:02:33 --> Controller Class Initialized
DEBUG - 2016-09-18 16:02:33 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:02:33 --> Model Class Initialized
INFO - 2016-09-18 16:02:33 --> Model Class Initialized
DEBUG - 2016-09-18 16:02:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 16:02:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 16:02:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 16:02:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_peminjam.php
DEBUG - 2016-09-18 16:02:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 16:02:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 16:02:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 16:02:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 16:02:33 --> Final output sent to browser
DEBUG - 2016-09-18 16:02:33 --> Total execution time: 0.7292
INFO - 2016-09-18 16:02:35 --> Config Class Initialized
INFO - 2016-09-18 16:02:35 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:02:35 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:02:35 --> Utf8 Class Initialized
INFO - 2016-09-18 16:02:35 --> URI Class Initialized
INFO - 2016-09-18 16:02:35 --> Router Class Initialized
INFO - 2016-09-18 16:02:35 --> Output Class Initialized
INFO - 2016-09-18 16:02:35 --> Security Class Initialized
DEBUG - 2016-09-18 16:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:02:35 --> Input Class Initialized
INFO - 2016-09-18 16:02:35 --> Language Class Initialized
INFO - 2016-09-18 16:02:35 --> Language Class Initialized
INFO - 2016-09-18 16:02:35 --> Config Class Initialized
INFO - 2016-09-18 16:02:35 --> Loader Class Initialized
INFO - 2016-09-18 16:02:35 --> Helper loaded: url_helper
INFO - 2016-09-18 16:02:35 --> Database Driver Class Initialized
INFO - 2016-09-18 16:02:35 --> Controller Class Initialized
DEBUG - 2016-09-18 16:02:35 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:02:35 --> Model Class Initialized
INFO - 2016-09-18 16:02:36 --> Model Class Initialized
DEBUG - 2016-09-18 16:02:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-18 16:02:36 --> Final output sent to browser
DEBUG - 2016-09-18 16:02:36 --> Total execution time: 0.8983
INFO - 2016-09-18 16:02:36 --> Config Class Initialized
INFO - 2016-09-18 16:02:36 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:02:36 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:02:36 --> Utf8 Class Initialized
INFO - 2016-09-18 16:02:36 --> URI Class Initialized
INFO - 2016-09-18 16:02:36 --> Router Class Initialized
INFO - 2016-09-18 16:02:36 --> Output Class Initialized
INFO - 2016-09-18 16:02:36 --> Security Class Initialized
DEBUG - 2016-09-18 16:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:02:36 --> Input Class Initialized
INFO - 2016-09-18 16:02:36 --> Language Class Initialized
INFO - 2016-09-18 16:02:36 --> Language Class Initialized
INFO - 2016-09-18 16:02:36 --> Config Class Initialized
INFO - 2016-09-18 16:02:36 --> Loader Class Initialized
INFO - 2016-09-18 16:02:36 --> Helper loaded: url_helper
INFO - 2016-09-18 16:02:36 --> Database Driver Class Initialized
INFO - 2016-09-18 16:02:36 --> Controller Class Initialized
DEBUG - 2016-09-18 16:02:36 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:02:36 --> Model Class Initialized
INFO - 2016-09-18 16:02:36 --> Model Class Initialized
DEBUG - 2016-09-18 16:02:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-18 16:02:36 --> Final output sent to browser
DEBUG - 2016-09-18 16:02:37 --> Total execution time: 0.4442
INFO - 2016-09-18 16:02:38 --> Config Class Initialized
INFO - 2016-09-18 16:02:38 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:02:38 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:02:38 --> Utf8 Class Initialized
INFO - 2016-09-18 16:02:38 --> URI Class Initialized
INFO - 2016-09-18 16:02:38 --> Router Class Initialized
INFO - 2016-09-18 16:02:38 --> Output Class Initialized
INFO - 2016-09-18 16:02:38 --> Security Class Initialized
DEBUG - 2016-09-18 16:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:02:38 --> Input Class Initialized
INFO - 2016-09-18 16:02:38 --> Language Class Initialized
INFO - 2016-09-18 16:02:38 --> Language Class Initialized
INFO - 2016-09-18 16:02:38 --> Config Class Initialized
INFO - 2016-09-18 16:02:38 --> Loader Class Initialized
INFO - 2016-09-18 16:02:38 --> Helper loaded: url_helper
INFO - 2016-09-18 16:02:38 --> Database Driver Class Initialized
INFO - 2016-09-18 16:02:38 --> Controller Class Initialized
DEBUG - 2016-09-18 16:02:38 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:02:38 --> Model Class Initialized
INFO - 2016-09-18 16:02:38 --> Model Class Initialized
DEBUG - 2016-09-18 16:02:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-18 16:02:38 --> Final output sent to browser
DEBUG - 2016-09-18 16:02:38 --> Total execution time: 0.4818
INFO - 2016-09-18 16:02:39 --> Config Class Initialized
INFO - 2016-09-18 16:02:40 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:02:40 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:02:40 --> Utf8 Class Initialized
INFO - 2016-09-18 16:02:40 --> URI Class Initialized
INFO - 2016-09-18 16:02:40 --> Router Class Initialized
INFO - 2016-09-18 16:02:40 --> Output Class Initialized
INFO - 2016-09-18 16:02:40 --> Security Class Initialized
DEBUG - 2016-09-18 16:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:02:40 --> Input Class Initialized
INFO - 2016-09-18 16:02:40 --> Language Class Initialized
INFO - 2016-09-18 16:02:40 --> Language Class Initialized
INFO - 2016-09-18 16:02:40 --> Config Class Initialized
INFO - 2016-09-18 16:02:40 --> Loader Class Initialized
INFO - 2016-09-18 16:02:40 --> Helper loaded: url_helper
INFO - 2016-09-18 16:02:40 --> Database Driver Class Initialized
INFO - 2016-09-18 16:02:40 --> Controller Class Initialized
DEBUG - 2016-09-18 16:02:40 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:02:40 --> Model Class Initialized
INFO - 2016-09-18 16:02:40 --> Model Class Initialized
DEBUG - 2016-09-18 16:02:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_transaksi.php
INFO - 2016-09-18 16:02:40 --> Final output sent to browser
DEBUG - 2016-09-18 16:02:40 --> Total execution time: 0.8564
INFO - 2016-09-18 16:12:04 --> Config Class Initialized
INFO - 2016-09-18 16:12:04 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:12:04 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:12:04 --> Utf8 Class Initialized
INFO - 2016-09-18 16:12:04 --> URI Class Initialized
INFO - 2016-09-18 16:12:04 --> Router Class Initialized
INFO - 2016-09-18 16:12:04 --> Output Class Initialized
INFO - 2016-09-18 16:12:04 --> Security Class Initialized
DEBUG - 2016-09-18 16:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:12:04 --> Input Class Initialized
INFO - 2016-09-18 16:12:04 --> Language Class Initialized
INFO - 2016-09-18 16:12:04 --> Language Class Initialized
INFO - 2016-09-18 16:12:04 --> Config Class Initialized
INFO - 2016-09-18 16:12:04 --> Loader Class Initialized
INFO - 2016-09-18 16:12:04 --> Helper loaded: url_helper
INFO - 2016-09-18 16:12:04 --> Database Driver Class Initialized
INFO - 2016-09-18 16:12:04 --> Controller Class Initialized
DEBUG - 2016-09-18 16:12:04 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:12:04 --> Model Class Initialized
INFO - 2016-09-18 16:12:04 --> Model Class Initialized
ERROR - 2016-09-18 16:12:04 --> Severity: Error --> Call to undefined function addMonth() E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 325
INFO - 2016-09-18 16:12:15 --> Config Class Initialized
INFO - 2016-09-18 16:12:15 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:12:15 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:12:15 --> Utf8 Class Initialized
INFO - 2016-09-18 16:12:16 --> URI Class Initialized
INFO - 2016-09-18 16:12:16 --> Router Class Initialized
INFO - 2016-09-18 16:12:16 --> Output Class Initialized
INFO - 2016-09-18 16:12:16 --> Security Class Initialized
DEBUG - 2016-09-18 16:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:12:16 --> Input Class Initialized
INFO - 2016-09-18 16:12:16 --> Language Class Initialized
INFO - 2016-09-18 16:12:16 --> Language Class Initialized
INFO - 2016-09-18 16:12:16 --> Config Class Initialized
INFO - 2016-09-18 16:12:16 --> Loader Class Initialized
INFO - 2016-09-18 16:12:16 --> Helper loaded: url_helper
INFO - 2016-09-18 16:12:16 --> Database Driver Class Initialized
INFO - 2016-09-18 16:12:16 --> Controller Class Initialized
DEBUG - 2016-09-18 16:12:16 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:12:16 --> Model Class Initialized
INFO - 2016-09-18 16:12:16 --> Model Class Initialized
ERROR - 2016-09-18 16:12:16 --> Severity: error --> Exception: DateTime::__construct(): Failed to parse time string (1474207936) at position 7 (9): Unexpected character E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 313
INFO - 2016-09-18 16:13:59 --> Config Class Initialized
INFO - 2016-09-18 16:13:59 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:14:00 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:14:00 --> Utf8 Class Initialized
INFO - 2016-09-18 16:14:00 --> URI Class Initialized
INFO - 2016-09-18 16:14:00 --> Router Class Initialized
INFO - 2016-09-18 16:14:00 --> Output Class Initialized
INFO - 2016-09-18 16:14:00 --> Security Class Initialized
DEBUG - 2016-09-18 16:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:14:00 --> Input Class Initialized
INFO - 2016-09-18 16:14:00 --> Language Class Initialized
INFO - 2016-09-18 16:14:00 --> Language Class Initialized
INFO - 2016-09-18 16:14:00 --> Config Class Initialized
INFO - 2016-09-18 16:14:00 --> Loader Class Initialized
INFO - 2016-09-18 16:14:00 --> Helper loaded: url_helper
INFO - 2016-09-18 16:14:00 --> Database Driver Class Initialized
INFO - 2016-09-18 16:14:00 --> Controller Class Initialized
DEBUG - 2016-09-18 16:14:00 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:14:00 --> Model Class Initialized
INFO - 2016-09-18 16:14:00 --> Model Class Initialized
INFO - 2016-09-18 16:14:00 --> Final output sent to browser
DEBUG - 2016-09-18 16:14:00 --> Total execution time: 0.5287
INFO - 2016-09-18 16:14:35 --> Config Class Initialized
INFO - 2016-09-18 16:14:35 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:14:35 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:14:35 --> Utf8 Class Initialized
INFO - 2016-09-18 16:14:35 --> URI Class Initialized
INFO - 2016-09-18 16:14:35 --> Router Class Initialized
INFO - 2016-09-18 16:14:35 --> Output Class Initialized
INFO - 2016-09-18 16:14:35 --> Security Class Initialized
DEBUG - 2016-09-18 16:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:14:35 --> Input Class Initialized
INFO - 2016-09-18 16:14:35 --> Language Class Initialized
INFO - 2016-09-18 16:14:35 --> Language Class Initialized
INFO - 2016-09-18 16:14:35 --> Config Class Initialized
INFO - 2016-09-18 16:14:35 --> Loader Class Initialized
INFO - 2016-09-18 16:14:35 --> Helper loaded: url_helper
INFO - 2016-09-18 16:14:35 --> Database Driver Class Initialized
INFO - 2016-09-18 16:14:35 --> Controller Class Initialized
DEBUG - 2016-09-18 16:14:35 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:14:35 --> Model Class Initialized
INFO - 2016-09-18 16:14:35 --> Model Class Initialized
INFO - 2016-09-18 16:14:35 --> Final output sent to browser
DEBUG - 2016-09-18 16:14:35 --> Total execution time: 0.4932
INFO - 2016-09-18 16:15:36 --> Config Class Initialized
INFO - 2016-09-18 16:15:36 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:15:36 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:15:36 --> Utf8 Class Initialized
INFO - 2016-09-18 16:15:36 --> URI Class Initialized
INFO - 2016-09-18 16:15:36 --> Router Class Initialized
INFO - 2016-09-18 16:15:36 --> Output Class Initialized
INFO - 2016-09-18 16:15:36 --> Security Class Initialized
DEBUG - 2016-09-18 16:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:15:37 --> Input Class Initialized
INFO - 2016-09-18 16:15:37 --> Language Class Initialized
INFO - 2016-09-18 16:15:37 --> Language Class Initialized
INFO - 2016-09-18 16:15:37 --> Config Class Initialized
INFO - 2016-09-18 16:15:37 --> Loader Class Initialized
INFO - 2016-09-18 16:15:37 --> Helper loaded: url_helper
INFO - 2016-09-18 16:15:37 --> Database Driver Class Initialized
INFO - 2016-09-18 16:15:37 --> Controller Class Initialized
DEBUG - 2016-09-18 16:15:37 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:15:37 --> Model Class Initialized
INFO - 2016-09-18 16:15:37 --> Model Class Initialized
ERROR - 2016-09-18 16:15:37 --> Severity: Notice --> Undefined variable: today E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 332
INFO - 2016-09-18 16:15:37 --> Final output sent to browser
DEBUG - 2016-09-18 16:15:37 --> Total execution time: 0.7614
INFO - 2016-09-18 16:15:47 --> Config Class Initialized
INFO - 2016-09-18 16:15:47 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:15:47 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:15:47 --> Utf8 Class Initialized
INFO - 2016-09-18 16:15:47 --> URI Class Initialized
INFO - 2016-09-18 16:15:47 --> Router Class Initialized
INFO - 2016-09-18 16:15:47 --> Output Class Initialized
INFO - 2016-09-18 16:15:47 --> Security Class Initialized
DEBUG - 2016-09-18 16:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:15:47 --> Input Class Initialized
INFO - 2016-09-18 16:15:47 --> Language Class Initialized
INFO - 2016-09-18 16:15:47 --> Language Class Initialized
INFO - 2016-09-18 16:15:47 --> Config Class Initialized
INFO - 2016-09-18 16:15:47 --> Loader Class Initialized
INFO - 2016-09-18 16:15:47 --> Helper loaded: url_helper
INFO - 2016-09-18 16:15:47 --> Database Driver Class Initialized
INFO - 2016-09-18 16:15:47 --> Controller Class Initialized
DEBUG - 2016-09-18 16:15:47 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:15:47 --> Model Class Initialized
INFO - 2016-09-18 16:15:47 --> Model Class Initialized
INFO - 2016-09-18 16:15:47 --> Final output sent to browser
DEBUG - 2016-09-18 16:15:47 --> Total execution time: 0.5424
INFO - 2016-09-18 16:16:07 --> Config Class Initialized
INFO - 2016-09-18 16:16:07 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:16:07 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:16:07 --> Utf8 Class Initialized
INFO - 2016-09-18 16:16:07 --> URI Class Initialized
INFO - 2016-09-18 16:16:07 --> Router Class Initialized
INFO - 2016-09-18 16:16:07 --> Output Class Initialized
INFO - 2016-09-18 16:16:07 --> Security Class Initialized
DEBUG - 2016-09-18 16:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:16:07 --> Input Class Initialized
INFO - 2016-09-18 16:16:07 --> Language Class Initialized
INFO - 2016-09-18 16:16:07 --> Language Class Initialized
INFO - 2016-09-18 16:16:07 --> Config Class Initialized
INFO - 2016-09-18 16:16:07 --> Loader Class Initialized
INFO - 2016-09-18 16:16:07 --> Helper loaded: url_helper
INFO - 2016-09-18 16:16:07 --> Database Driver Class Initialized
INFO - 2016-09-18 16:16:07 --> Controller Class Initialized
DEBUG - 2016-09-18 16:16:07 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:16:07 --> Model Class Initialized
INFO - 2016-09-18 16:16:07 --> Model Class Initialized
INFO - 2016-09-18 16:16:07 --> Final output sent to browser
DEBUG - 2016-09-18 16:16:07 --> Total execution time: 0.5018
INFO - 2016-09-18 16:16:14 --> Config Class Initialized
INFO - 2016-09-18 16:16:14 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:16:14 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:16:14 --> Utf8 Class Initialized
INFO - 2016-09-18 16:16:14 --> URI Class Initialized
INFO - 2016-09-18 16:16:14 --> Router Class Initialized
INFO - 2016-09-18 16:16:14 --> Output Class Initialized
INFO - 2016-09-18 16:16:14 --> Security Class Initialized
DEBUG - 2016-09-18 16:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:16:14 --> Input Class Initialized
INFO - 2016-09-18 16:16:14 --> Language Class Initialized
INFO - 2016-09-18 16:16:14 --> Language Class Initialized
INFO - 2016-09-18 16:16:14 --> Config Class Initialized
INFO - 2016-09-18 16:16:14 --> Loader Class Initialized
INFO - 2016-09-18 16:16:14 --> Helper loaded: url_helper
INFO - 2016-09-18 16:16:14 --> Database Driver Class Initialized
INFO - 2016-09-18 16:16:14 --> Controller Class Initialized
DEBUG - 2016-09-18 16:16:14 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:16:14 --> Model Class Initialized
INFO - 2016-09-18 16:16:14 --> Model Class Initialized
INFO - 2016-09-18 16:16:14 --> Final output sent to browser
DEBUG - 2016-09-18 16:16:14 --> Total execution time: 0.5059
INFO - 2016-09-18 16:16:26 --> Config Class Initialized
INFO - 2016-09-18 16:16:26 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:16:26 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:16:26 --> Utf8 Class Initialized
INFO - 2016-09-18 16:16:26 --> URI Class Initialized
INFO - 2016-09-18 16:16:26 --> Router Class Initialized
INFO - 2016-09-18 16:16:26 --> Output Class Initialized
INFO - 2016-09-18 16:16:26 --> Security Class Initialized
DEBUG - 2016-09-18 16:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:16:26 --> Input Class Initialized
INFO - 2016-09-18 16:16:26 --> Language Class Initialized
INFO - 2016-09-18 16:16:26 --> Language Class Initialized
INFO - 2016-09-18 16:16:26 --> Config Class Initialized
INFO - 2016-09-18 16:16:26 --> Loader Class Initialized
INFO - 2016-09-18 16:16:26 --> Helper loaded: url_helper
INFO - 2016-09-18 16:16:26 --> Database Driver Class Initialized
INFO - 2016-09-18 16:16:26 --> Controller Class Initialized
DEBUG - 2016-09-18 16:16:26 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:16:26 --> Model Class Initialized
INFO - 2016-09-18 16:16:26 --> Model Class Initialized
INFO - 2016-09-18 16:16:26 --> Final output sent to browser
DEBUG - 2016-09-18 16:16:26 --> Total execution time: 0.5048
INFO - 2016-09-18 16:16:34 --> Config Class Initialized
INFO - 2016-09-18 16:16:34 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:16:34 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:16:34 --> Utf8 Class Initialized
INFO - 2016-09-18 16:16:34 --> URI Class Initialized
INFO - 2016-09-18 16:16:34 --> Router Class Initialized
INFO - 2016-09-18 16:16:34 --> Output Class Initialized
INFO - 2016-09-18 16:16:34 --> Security Class Initialized
DEBUG - 2016-09-18 16:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:16:34 --> Input Class Initialized
INFO - 2016-09-18 16:16:34 --> Language Class Initialized
INFO - 2016-09-18 16:16:34 --> Language Class Initialized
INFO - 2016-09-18 16:16:34 --> Config Class Initialized
INFO - 2016-09-18 16:16:34 --> Loader Class Initialized
INFO - 2016-09-18 16:16:34 --> Helper loaded: url_helper
INFO - 2016-09-18 16:16:34 --> Database Driver Class Initialized
INFO - 2016-09-18 16:16:34 --> Controller Class Initialized
DEBUG - 2016-09-18 16:16:34 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:16:34 --> Model Class Initialized
INFO - 2016-09-18 16:16:34 --> Model Class Initialized
INFO - 2016-09-18 16:16:34 --> Final output sent to browser
DEBUG - 2016-09-18 16:16:34 --> Total execution time: 0.5099
INFO - 2016-09-18 16:16:47 --> Config Class Initialized
INFO - 2016-09-18 16:16:47 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:16:47 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:16:47 --> Utf8 Class Initialized
INFO - 2016-09-18 16:16:47 --> URI Class Initialized
INFO - 2016-09-18 16:16:47 --> Router Class Initialized
INFO - 2016-09-18 16:16:47 --> Output Class Initialized
INFO - 2016-09-18 16:16:47 --> Security Class Initialized
DEBUG - 2016-09-18 16:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:16:47 --> Input Class Initialized
INFO - 2016-09-18 16:16:47 --> Language Class Initialized
INFO - 2016-09-18 16:16:47 --> Language Class Initialized
INFO - 2016-09-18 16:16:47 --> Config Class Initialized
INFO - 2016-09-18 16:16:47 --> Loader Class Initialized
INFO - 2016-09-18 16:16:47 --> Helper loaded: url_helper
INFO - 2016-09-18 16:16:47 --> Database Driver Class Initialized
INFO - 2016-09-18 16:16:47 --> Controller Class Initialized
DEBUG - 2016-09-18 16:16:47 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:16:47 --> Model Class Initialized
INFO - 2016-09-18 16:16:47 --> Model Class Initialized
INFO - 2016-09-18 16:16:47 --> Final output sent to browser
DEBUG - 2016-09-18 16:16:47 --> Total execution time: 0.5167
INFO - 2016-09-18 16:18:59 --> Config Class Initialized
INFO - 2016-09-18 16:18:59 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:18:59 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:18:59 --> Utf8 Class Initialized
INFO - 2016-09-18 16:18:59 --> URI Class Initialized
INFO - 2016-09-18 16:19:00 --> Router Class Initialized
INFO - 2016-09-18 16:19:00 --> Output Class Initialized
INFO - 2016-09-18 16:19:00 --> Security Class Initialized
DEBUG - 2016-09-18 16:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:19:00 --> Input Class Initialized
INFO - 2016-09-18 16:19:00 --> Language Class Initialized
ERROR - 2016-09-18 16:19:00 --> Severity: Parsing Error --> syntax error, unexpected '(', expecting ')' E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 324
INFO - 2016-09-18 16:19:29 --> Config Class Initialized
INFO - 2016-09-18 16:19:29 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:19:29 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:19:29 --> Utf8 Class Initialized
INFO - 2016-09-18 16:19:29 --> URI Class Initialized
INFO - 2016-09-18 16:19:29 --> Router Class Initialized
INFO - 2016-09-18 16:19:29 --> Output Class Initialized
INFO - 2016-09-18 16:19:29 --> Security Class Initialized
DEBUG - 2016-09-18 16:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:19:29 --> Input Class Initialized
INFO - 2016-09-18 16:19:29 --> Language Class Initialized
ERROR - 2016-09-18 16:19:29 --> Severity: Parsing Error --> syntax error, unexpected '(', expecting ')' E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 324
INFO - 2016-09-18 16:19:47 --> Config Class Initialized
INFO - 2016-09-18 16:19:47 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:19:47 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:19:47 --> Utf8 Class Initialized
INFO - 2016-09-18 16:19:47 --> URI Class Initialized
INFO - 2016-09-18 16:19:47 --> Router Class Initialized
INFO - 2016-09-18 16:19:47 --> Output Class Initialized
INFO - 2016-09-18 16:19:47 --> Security Class Initialized
DEBUG - 2016-09-18 16:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:19:47 --> Input Class Initialized
INFO - 2016-09-18 16:19:47 --> Language Class Initialized
INFO - 2016-09-18 16:19:47 --> Language Class Initialized
INFO - 2016-09-18 16:19:47 --> Config Class Initialized
INFO - 2016-09-18 16:19:47 --> Loader Class Initialized
INFO - 2016-09-18 16:19:47 --> Helper loaded: url_helper
INFO - 2016-09-18 16:19:47 --> Database Driver Class Initialized
INFO - 2016-09-18 16:19:47 --> Controller Class Initialized
DEBUG - 2016-09-18 16:19:47 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:19:47 --> Model Class Initialized
INFO - 2016-09-18 16:19:47 --> Model Class Initialized
INFO - 2016-09-18 16:19:47 --> Final output sent to browser
DEBUG - 2016-09-18 16:19:47 --> Total execution time: 0.4460
INFO - 2016-09-18 16:20:10 --> Config Class Initialized
INFO - 2016-09-18 16:20:10 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:20:10 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:20:10 --> Utf8 Class Initialized
INFO - 2016-09-18 16:20:10 --> URI Class Initialized
INFO - 2016-09-18 16:20:10 --> Router Class Initialized
INFO - 2016-09-18 16:20:10 --> Output Class Initialized
INFO - 2016-09-18 16:20:10 --> Security Class Initialized
DEBUG - 2016-09-18 16:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:20:10 --> Input Class Initialized
INFO - 2016-09-18 16:20:10 --> Language Class Initialized
INFO - 2016-09-18 16:20:10 --> Language Class Initialized
INFO - 2016-09-18 16:20:10 --> Config Class Initialized
INFO - 2016-09-18 16:20:10 --> Loader Class Initialized
INFO - 2016-09-18 16:20:10 --> Helper loaded: url_helper
INFO - 2016-09-18 16:20:10 --> Database Driver Class Initialized
INFO - 2016-09-18 16:20:10 --> Controller Class Initialized
DEBUG - 2016-09-18 16:20:10 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:20:10 --> Model Class Initialized
INFO - 2016-09-18 16:20:10 --> Model Class Initialized
INFO - 2016-09-18 16:20:10 --> Final output sent to browser
DEBUG - 2016-09-18 16:20:10 --> Total execution time: 0.4827
INFO - 2016-09-18 16:20:53 --> Config Class Initialized
INFO - 2016-09-18 16:20:53 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:20:53 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:20:53 --> Utf8 Class Initialized
INFO - 2016-09-18 16:20:53 --> URI Class Initialized
INFO - 2016-09-18 16:20:53 --> Router Class Initialized
INFO - 2016-09-18 16:20:53 --> Output Class Initialized
INFO - 2016-09-18 16:20:53 --> Security Class Initialized
DEBUG - 2016-09-18 16:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:20:53 --> Input Class Initialized
INFO - 2016-09-18 16:20:53 --> Language Class Initialized
ERROR - 2016-09-18 16:20:53 --> Severity: Parsing Error --> syntax error, unexpected '(', expecting ')' E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 324
INFO - 2016-09-18 16:21:06 --> Config Class Initialized
INFO - 2016-09-18 16:21:06 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:21:06 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:21:06 --> Utf8 Class Initialized
INFO - 2016-09-18 16:21:06 --> URI Class Initialized
INFO - 2016-09-18 16:21:06 --> Router Class Initialized
INFO - 2016-09-18 16:21:06 --> Output Class Initialized
INFO - 2016-09-18 16:21:06 --> Security Class Initialized
DEBUG - 2016-09-18 16:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:21:06 --> Input Class Initialized
INFO - 2016-09-18 16:21:06 --> Language Class Initialized
INFO - 2016-09-18 16:21:06 --> Language Class Initialized
INFO - 2016-09-18 16:21:06 --> Config Class Initialized
INFO - 2016-09-18 16:21:06 --> Loader Class Initialized
INFO - 2016-09-18 16:21:06 --> Helper loaded: url_helper
INFO - 2016-09-18 16:21:06 --> Database Driver Class Initialized
INFO - 2016-09-18 16:21:06 --> Controller Class Initialized
DEBUG - 2016-09-18 16:21:06 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:21:06 --> Model Class Initialized
INFO - 2016-09-18 16:21:06 --> Model Class Initialized
INFO - 2016-09-18 16:21:06 --> Final output sent to browser
DEBUG - 2016-09-18 16:21:06 --> Total execution time: 0.5399
INFO - 2016-09-18 16:21:34 --> Config Class Initialized
INFO - 2016-09-18 16:21:34 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:21:34 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:21:34 --> Utf8 Class Initialized
INFO - 2016-09-18 16:21:34 --> URI Class Initialized
INFO - 2016-09-18 16:21:34 --> Router Class Initialized
INFO - 2016-09-18 16:21:34 --> Output Class Initialized
INFO - 2016-09-18 16:21:34 --> Security Class Initialized
DEBUG - 2016-09-18 16:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:21:34 --> Input Class Initialized
INFO - 2016-09-18 16:21:34 --> Language Class Initialized
INFO - 2016-09-18 16:21:34 --> Language Class Initialized
INFO - 2016-09-18 16:21:34 --> Config Class Initialized
INFO - 2016-09-18 16:21:34 --> Loader Class Initialized
INFO - 2016-09-18 16:21:35 --> Helper loaded: url_helper
INFO - 2016-09-18 16:21:35 --> Database Driver Class Initialized
INFO - 2016-09-18 16:21:35 --> Controller Class Initialized
DEBUG - 2016-09-18 16:21:35 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:21:35 --> Model Class Initialized
INFO - 2016-09-18 16:21:35 --> Model Class Initialized
INFO - 2016-09-18 16:21:35 --> Final output sent to browser
DEBUG - 2016-09-18 16:21:35 --> Total execution time: 0.5093
INFO - 2016-09-18 16:21:47 --> Config Class Initialized
INFO - 2016-09-18 16:21:47 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:21:47 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:21:47 --> Utf8 Class Initialized
INFO - 2016-09-18 16:21:47 --> URI Class Initialized
INFO - 2016-09-18 16:21:47 --> Router Class Initialized
INFO - 2016-09-18 16:21:47 --> Output Class Initialized
INFO - 2016-09-18 16:21:47 --> Security Class Initialized
DEBUG - 2016-09-18 16:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:21:47 --> Input Class Initialized
INFO - 2016-09-18 16:21:47 --> Language Class Initialized
INFO - 2016-09-18 16:21:47 --> Language Class Initialized
INFO - 2016-09-18 16:21:47 --> Config Class Initialized
INFO - 2016-09-18 16:21:47 --> Loader Class Initialized
INFO - 2016-09-18 16:21:47 --> Helper loaded: url_helper
INFO - 2016-09-18 16:21:47 --> Database Driver Class Initialized
INFO - 2016-09-18 16:21:47 --> Controller Class Initialized
DEBUG - 2016-09-18 16:21:47 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:21:47 --> Model Class Initialized
INFO - 2016-09-18 16:21:48 --> Model Class Initialized
INFO - 2016-09-18 16:21:48 --> Final output sent to browser
DEBUG - 2016-09-18 16:21:48 --> Total execution time: 0.7622
INFO - 2016-09-18 16:22:28 --> Config Class Initialized
INFO - 2016-09-18 16:22:28 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:22:28 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:22:28 --> Utf8 Class Initialized
INFO - 2016-09-18 16:22:28 --> URI Class Initialized
INFO - 2016-09-18 16:22:28 --> Router Class Initialized
INFO - 2016-09-18 16:22:28 --> Output Class Initialized
INFO - 2016-09-18 16:22:28 --> Security Class Initialized
DEBUG - 2016-09-18 16:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:22:28 --> Input Class Initialized
INFO - 2016-09-18 16:22:28 --> Language Class Initialized
INFO - 2016-09-18 16:22:28 --> Language Class Initialized
INFO - 2016-09-18 16:22:28 --> Config Class Initialized
INFO - 2016-09-18 16:22:28 --> Loader Class Initialized
INFO - 2016-09-18 16:22:28 --> Helper loaded: url_helper
INFO - 2016-09-18 16:22:28 --> Database Driver Class Initialized
INFO - 2016-09-18 16:22:28 --> Controller Class Initialized
DEBUG - 2016-09-18 16:22:28 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:22:28 --> Model Class Initialized
INFO - 2016-09-18 16:22:28 --> Model Class Initialized
INFO - 2016-09-18 16:22:28 --> Final output sent to browser
DEBUG - 2016-09-18 16:22:28 --> Total execution time: 0.4997
INFO - 2016-09-18 16:23:18 --> Config Class Initialized
INFO - 2016-09-18 16:23:18 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:23:18 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:23:18 --> Utf8 Class Initialized
INFO - 2016-09-18 16:23:18 --> URI Class Initialized
INFO - 2016-09-18 16:23:18 --> Router Class Initialized
INFO - 2016-09-18 16:23:18 --> Output Class Initialized
INFO - 2016-09-18 16:23:18 --> Security Class Initialized
DEBUG - 2016-09-18 16:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:23:18 --> Input Class Initialized
INFO - 2016-09-18 16:23:18 --> Language Class Initialized
INFO - 2016-09-18 16:23:18 --> Language Class Initialized
INFO - 2016-09-18 16:23:18 --> Config Class Initialized
INFO - 2016-09-18 16:23:18 --> Loader Class Initialized
INFO - 2016-09-18 16:23:18 --> Helper loaded: url_helper
INFO - 2016-09-18 16:23:18 --> Database Driver Class Initialized
INFO - 2016-09-18 16:23:18 --> Controller Class Initialized
DEBUG - 2016-09-18 16:23:18 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:23:18 --> Model Class Initialized
INFO - 2016-09-18 16:23:18 --> Model Class Initialized
ERROR - 2016-09-18 16:23:18 --> Severity: Warning --> date_diff() expects parameter 1 to be DateTimeInterface, string given E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 333
INFO - 2016-09-18 16:23:18 --> Final output sent to browser
DEBUG - 2016-09-18 16:23:19 --> Total execution time: 0.5120
INFO - 2016-09-18 16:23:47 --> Config Class Initialized
INFO - 2016-09-18 16:23:47 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:23:47 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:23:47 --> Utf8 Class Initialized
INFO - 2016-09-18 16:23:47 --> URI Class Initialized
INFO - 2016-09-18 16:23:47 --> Router Class Initialized
INFO - 2016-09-18 16:23:47 --> Output Class Initialized
INFO - 2016-09-18 16:23:47 --> Security Class Initialized
DEBUG - 2016-09-18 16:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:23:47 --> Input Class Initialized
INFO - 2016-09-18 16:23:47 --> Language Class Initialized
INFO - 2016-09-18 16:23:47 --> Language Class Initialized
INFO - 2016-09-18 16:23:47 --> Config Class Initialized
INFO - 2016-09-18 16:23:47 --> Loader Class Initialized
INFO - 2016-09-18 16:23:47 --> Helper loaded: url_helper
INFO - 2016-09-18 16:23:47 --> Database Driver Class Initialized
INFO - 2016-09-18 16:23:48 --> Controller Class Initialized
DEBUG - 2016-09-18 16:23:48 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:23:48 --> Model Class Initialized
INFO - 2016-09-18 16:23:48 --> Model Class Initialized
ERROR - 2016-09-18 16:23:48 --> Severity: 4096 --> Object of class DateInterval could not be converted to string E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 333
INFO - 2016-09-18 16:23:48 --> Final output sent to browser
DEBUG - 2016-09-18 16:23:48 --> Total execution time: 0.5417
INFO - 2016-09-18 16:26:20 --> Config Class Initialized
INFO - 2016-09-18 16:26:20 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:26:20 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:26:20 --> Utf8 Class Initialized
INFO - 2016-09-18 16:26:20 --> URI Class Initialized
INFO - 2016-09-18 16:26:20 --> Router Class Initialized
INFO - 2016-09-18 16:26:20 --> Output Class Initialized
INFO - 2016-09-18 16:26:20 --> Security Class Initialized
DEBUG - 2016-09-18 16:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:26:20 --> Input Class Initialized
INFO - 2016-09-18 16:26:20 --> Language Class Initialized
INFO - 2016-09-18 16:26:20 --> Language Class Initialized
INFO - 2016-09-18 16:26:20 --> Config Class Initialized
INFO - 2016-09-18 16:26:20 --> Loader Class Initialized
INFO - 2016-09-18 16:26:20 --> Helper loaded: url_helper
INFO - 2016-09-18 16:26:20 --> Database Driver Class Initialized
INFO - 2016-09-18 16:26:20 --> Controller Class Initialized
ERROR - 2016-09-18 16:26:20 --> 404 Page Not Found: ../modules/admin/controllers/Index/diff_date
INFO - 2016-09-18 16:26:36 --> Config Class Initialized
INFO - 2016-09-18 16:26:36 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:26:36 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:26:36 --> Utf8 Class Initialized
INFO - 2016-09-18 16:26:36 --> URI Class Initialized
INFO - 2016-09-18 16:26:36 --> Router Class Initialized
INFO - 2016-09-18 16:26:36 --> Output Class Initialized
INFO - 2016-09-18 16:26:36 --> Security Class Initialized
DEBUG - 2016-09-18 16:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:26:37 --> Input Class Initialized
INFO - 2016-09-18 16:26:37 --> Language Class Initialized
INFO - 2016-09-18 16:26:37 --> Language Class Initialized
INFO - 2016-09-18 16:26:37 --> Config Class Initialized
INFO - 2016-09-18 16:26:37 --> Loader Class Initialized
INFO - 2016-09-18 16:26:37 --> Helper loaded: url_helper
INFO - 2016-09-18 16:26:37 --> Database Driver Class Initialized
INFO - 2016-09-18 16:26:37 --> Controller Class Initialized
DEBUG - 2016-09-18 16:26:37 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:26:37 --> Model Class Initialized
INFO - 2016-09-18 16:26:37 --> Model Class Initialized
INFO - 2016-09-18 16:26:37 --> Final output sent to browser
DEBUG - 2016-09-18 16:26:37 --> Total execution time: 0.5144
INFO - 2016-09-18 16:27:16 --> Config Class Initialized
INFO - 2016-09-18 16:27:16 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:27:16 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:27:16 --> Utf8 Class Initialized
INFO - 2016-09-18 16:27:16 --> URI Class Initialized
INFO - 2016-09-18 16:27:16 --> Router Class Initialized
INFO - 2016-09-18 16:27:16 --> Output Class Initialized
INFO - 2016-09-18 16:27:16 --> Security Class Initialized
DEBUG - 2016-09-18 16:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:27:16 --> Input Class Initialized
INFO - 2016-09-18 16:27:16 --> Language Class Initialized
INFO - 2016-09-18 16:27:16 --> Language Class Initialized
INFO - 2016-09-18 16:27:16 --> Config Class Initialized
INFO - 2016-09-18 16:27:16 --> Loader Class Initialized
INFO - 2016-09-18 16:27:16 --> Helper loaded: url_helper
INFO - 2016-09-18 16:27:16 --> Database Driver Class Initialized
INFO - 2016-09-18 16:27:16 --> Controller Class Initialized
DEBUG - 2016-09-18 16:27:16 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:27:16 --> Model Class Initialized
INFO - 2016-09-18 16:27:16 --> Model Class Initialized
ERROR - 2016-09-18 16:27:16 --> Severity: Error --> Call to undefined function different_date() E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 346
INFO - 2016-09-18 16:27:24 --> Config Class Initialized
INFO - 2016-09-18 16:27:24 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:27:24 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:27:24 --> Utf8 Class Initialized
INFO - 2016-09-18 16:27:24 --> URI Class Initialized
INFO - 2016-09-18 16:27:24 --> Router Class Initialized
INFO - 2016-09-18 16:27:24 --> Output Class Initialized
INFO - 2016-09-18 16:27:24 --> Security Class Initialized
DEBUG - 2016-09-18 16:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:27:24 --> Input Class Initialized
INFO - 2016-09-18 16:27:24 --> Language Class Initialized
INFO - 2016-09-18 16:27:24 --> Language Class Initialized
INFO - 2016-09-18 16:27:24 --> Config Class Initialized
INFO - 2016-09-18 16:27:24 --> Loader Class Initialized
INFO - 2016-09-18 16:27:24 --> Helper loaded: url_helper
INFO - 2016-09-18 16:27:24 --> Database Driver Class Initialized
INFO - 2016-09-18 16:27:24 --> Controller Class Initialized
DEBUG - 2016-09-18 16:27:24 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:27:24 --> Model Class Initialized
INFO - 2016-09-18 16:27:24 --> Model Class Initialized
INFO - 2016-09-18 16:27:24 --> Final output sent to browser
DEBUG - 2016-09-18 16:27:24 --> Total execution time: 0.5559
INFO - 2016-09-18 16:27:43 --> Config Class Initialized
INFO - 2016-09-18 16:27:43 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:27:43 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:27:43 --> Utf8 Class Initialized
INFO - 2016-09-18 16:27:43 --> URI Class Initialized
INFO - 2016-09-18 16:27:43 --> Router Class Initialized
INFO - 2016-09-18 16:27:43 --> Output Class Initialized
INFO - 2016-09-18 16:27:43 --> Security Class Initialized
DEBUG - 2016-09-18 16:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:27:43 --> Input Class Initialized
INFO - 2016-09-18 16:27:43 --> Language Class Initialized
INFO - 2016-09-18 16:27:43 --> Language Class Initialized
INFO - 2016-09-18 16:27:43 --> Config Class Initialized
INFO - 2016-09-18 16:27:43 --> Loader Class Initialized
INFO - 2016-09-18 16:27:43 --> Helper loaded: url_helper
INFO - 2016-09-18 16:27:43 --> Database Driver Class Initialized
INFO - 2016-09-18 16:27:43 --> Controller Class Initialized
DEBUG - 2016-09-18 16:27:43 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:27:43 --> Model Class Initialized
INFO - 2016-09-18 16:27:43 --> Model Class Initialized
INFO - 2016-09-18 16:27:43 --> Final output sent to browser
DEBUG - 2016-09-18 16:27:43 --> Total execution time: 0.4696
INFO - 2016-09-18 16:28:04 --> Config Class Initialized
INFO - 2016-09-18 16:28:04 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:28:04 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:28:04 --> Utf8 Class Initialized
INFO - 2016-09-18 16:28:04 --> URI Class Initialized
INFO - 2016-09-18 16:28:04 --> Router Class Initialized
INFO - 2016-09-18 16:28:04 --> Output Class Initialized
INFO - 2016-09-18 16:28:04 --> Security Class Initialized
DEBUG - 2016-09-18 16:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:28:04 --> Input Class Initialized
INFO - 2016-09-18 16:28:04 --> Language Class Initialized
INFO - 2016-09-18 16:28:04 --> Language Class Initialized
INFO - 2016-09-18 16:28:04 --> Config Class Initialized
INFO - 2016-09-18 16:28:04 --> Loader Class Initialized
INFO - 2016-09-18 16:28:04 --> Helper loaded: url_helper
INFO - 2016-09-18 16:28:04 --> Database Driver Class Initialized
INFO - 2016-09-18 16:28:04 --> Controller Class Initialized
DEBUG - 2016-09-18 16:28:04 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:28:04 --> Model Class Initialized
INFO - 2016-09-18 16:28:04 --> Model Class Initialized
INFO - 2016-09-18 16:28:04 --> Final output sent to browser
DEBUG - 2016-09-18 16:28:04 --> Total execution time: 0.4832
INFO - 2016-09-18 16:28:45 --> Config Class Initialized
INFO - 2016-09-18 16:28:45 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:28:45 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:28:45 --> Utf8 Class Initialized
INFO - 2016-09-18 16:28:45 --> URI Class Initialized
INFO - 2016-09-18 16:28:45 --> Router Class Initialized
INFO - 2016-09-18 16:28:45 --> Output Class Initialized
INFO - 2016-09-18 16:28:45 --> Security Class Initialized
DEBUG - 2016-09-18 16:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:28:45 --> Input Class Initialized
INFO - 2016-09-18 16:28:45 --> Language Class Initialized
INFO - 2016-09-18 16:28:45 --> Language Class Initialized
INFO - 2016-09-18 16:28:45 --> Config Class Initialized
INFO - 2016-09-18 16:28:45 --> Loader Class Initialized
INFO - 2016-09-18 16:28:45 --> Helper loaded: url_helper
INFO - 2016-09-18 16:28:45 --> Database Driver Class Initialized
INFO - 2016-09-18 16:28:45 --> Controller Class Initialized
DEBUG - 2016-09-18 16:28:45 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:28:45 --> Model Class Initialized
INFO - 2016-09-18 16:28:45 --> Model Class Initialized
INFO - 2016-09-18 16:28:45 --> Final output sent to browser
DEBUG - 2016-09-18 16:28:45 --> Total execution time: 0.4726
INFO - 2016-09-18 16:31:56 --> Config Class Initialized
INFO - 2016-09-18 16:31:56 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:31:56 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:31:56 --> Utf8 Class Initialized
INFO - 2016-09-18 16:31:56 --> URI Class Initialized
INFO - 2016-09-18 16:31:56 --> Router Class Initialized
INFO - 2016-09-18 16:31:56 --> Output Class Initialized
INFO - 2016-09-18 16:31:56 --> Security Class Initialized
DEBUG - 2016-09-18 16:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:31:56 --> Input Class Initialized
INFO - 2016-09-18 16:31:56 --> Language Class Initialized
INFO - 2016-09-18 16:31:56 --> Language Class Initialized
INFO - 2016-09-18 16:31:56 --> Config Class Initialized
INFO - 2016-09-18 16:31:56 --> Loader Class Initialized
INFO - 2016-09-18 16:31:56 --> Helper loaded: url_helper
INFO - 2016-09-18 16:31:56 --> Database Driver Class Initialized
INFO - 2016-09-18 16:31:56 --> Controller Class Initialized
DEBUG - 2016-09-18 16:31:56 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:31:56 --> Model Class Initialized
INFO - 2016-09-18 16:31:56 --> Model Class Initialized
DEBUG - 2016-09-18 16:31:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 16:31:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 16:31:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 16:31:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-18 16:31:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 16:31:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 16:31:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 16:31:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 16:31:57 --> Final output sent to browser
DEBUG - 2016-09-18 16:31:57 --> Total execution time: 0.6921
INFO - 2016-09-18 16:32:04 --> Config Class Initialized
INFO - 2016-09-18 16:32:04 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:32:04 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:32:04 --> Utf8 Class Initialized
INFO - 2016-09-18 16:32:04 --> URI Class Initialized
INFO - 2016-09-18 16:32:04 --> Router Class Initialized
INFO - 2016-09-18 16:32:04 --> Output Class Initialized
INFO - 2016-09-18 16:32:04 --> Security Class Initialized
DEBUG - 2016-09-18 16:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:32:04 --> Input Class Initialized
INFO - 2016-09-18 16:32:04 --> Language Class Initialized
INFO - 2016-09-18 16:32:04 --> Language Class Initialized
INFO - 2016-09-18 16:32:04 --> Config Class Initialized
INFO - 2016-09-18 16:32:04 --> Loader Class Initialized
INFO - 2016-09-18 16:32:04 --> Helper loaded: url_helper
INFO - 2016-09-18 16:32:04 --> Database Driver Class Initialized
INFO - 2016-09-18 16:32:04 --> Controller Class Initialized
DEBUG - 2016-09-18 16:32:04 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:32:04 --> Model Class Initialized
INFO - 2016-09-18 16:32:04 --> Model Class Initialized
DEBUG - 2016-09-18 16:32:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 16:32:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 16:32:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 16:32:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_bayar_angsuran.php
DEBUG - 2016-09-18 16:32:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 16:32:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 16:32:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 16:32:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 16:32:05 --> Final output sent to browser
DEBUG - 2016-09-18 16:32:05 --> Total execution time: 0.6928
INFO - 2016-09-18 16:32:08 --> Config Class Initialized
INFO - 2016-09-18 16:32:08 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:32:08 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:32:08 --> Utf8 Class Initialized
INFO - 2016-09-18 16:32:08 --> URI Class Initialized
INFO - 2016-09-18 16:32:08 --> Router Class Initialized
INFO - 2016-09-18 16:32:08 --> Output Class Initialized
INFO - 2016-09-18 16:32:08 --> Security Class Initialized
DEBUG - 2016-09-18 16:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:32:08 --> Input Class Initialized
INFO - 2016-09-18 16:32:08 --> Language Class Initialized
INFO - 2016-09-18 16:32:08 --> Language Class Initialized
INFO - 2016-09-18 16:32:08 --> Config Class Initialized
INFO - 2016-09-18 16:32:08 --> Loader Class Initialized
INFO - 2016-09-18 16:32:08 --> Helper loaded: url_helper
INFO - 2016-09-18 16:32:08 --> Database Driver Class Initialized
INFO - 2016-09-18 16:32:09 --> Controller Class Initialized
DEBUG - 2016-09-18 16:32:09 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:32:09 --> Model Class Initialized
INFO - 2016-09-18 16:32:09 --> Model Class Initialized
INFO - 2016-09-18 16:32:09 --> Database Driver Class Initialized
INFO - 2016-09-18 16:32:09 --> Final output sent to browser
DEBUG - 2016-09-18 16:32:09 --> Total execution time: 0.6465
INFO - 2016-09-18 16:32:12 --> Config Class Initialized
INFO - 2016-09-18 16:32:12 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:32:12 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:32:12 --> Utf8 Class Initialized
INFO - 2016-09-18 16:32:12 --> URI Class Initialized
INFO - 2016-09-18 16:32:12 --> Router Class Initialized
INFO - 2016-09-18 16:32:12 --> Output Class Initialized
INFO - 2016-09-18 16:32:12 --> Security Class Initialized
DEBUG - 2016-09-18 16:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:32:12 --> Input Class Initialized
INFO - 2016-09-18 16:32:12 --> Language Class Initialized
INFO - 2016-09-18 16:32:12 --> Language Class Initialized
INFO - 2016-09-18 16:32:12 --> Config Class Initialized
INFO - 2016-09-18 16:32:12 --> Loader Class Initialized
INFO - 2016-09-18 16:32:12 --> Helper loaded: url_helper
INFO - 2016-09-18 16:32:12 --> Database Driver Class Initialized
INFO - 2016-09-18 16:32:12 --> Controller Class Initialized
DEBUG - 2016-09-18 16:32:12 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:32:12 --> Model Class Initialized
INFO - 2016-09-18 16:32:12 --> Model Class Initialized
INFO - 2016-09-18 16:32:12 --> Final output sent to browser
DEBUG - 2016-09-18 16:32:12 --> Total execution time: 0.5659
INFO - 2016-09-18 16:32:15 --> Config Class Initialized
INFO - 2016-09-18 16:32:15 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:32:15 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:32:15 --> Utf8 Class Initialized
INFO - 2016-09-18 16:32:15 --> URI Class Initialized
INFO - 2016-09-18 16:32:15 --> Router Class Initialized
INFO - 2016-09-18 16:32:15 --> Output Class Initialized
INFO - 2016-09-18 16:32:15 --> Security Class Initialized
DEBUG - 2016-09-18 16:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:32:15 --> Input Class Initialized
INFO - 2016-09-18 16:32:15 --> Language Class Initialized
INFO - 2016-09-18 16:32:15 --> Language Class Initialized
INFO - 2016-09-18 16:32:15 --> Config Class Initialized
INFO - 2016-09-18 16:32:15 --> Loader Class Initialized
INFO - 2016-09-18 16:32:15 --> Helper loaded: url_helper
INFO - 2016-09-18 16:32:16 --> Database Driver Class Initialized
INFO - 2016-09-18 16:32:16 --> Controller Class Initialized
DEBUG - 2016-09-18 16:32:16 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:32:16 --> Model Class Initialized
INFO - 2016-09-18 16:32:16 --> Model Class Initialized
INFO - 2016-09-18 16:32:16 --> Final output sent to browser
DEBUG - 2016-09-18 16:32:16 --> Total execution time: 0.5666
INFO - 2016-09-18 16:32:18 --> Config Class Initialized
INFO - 2016-09-18 16:32:18 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:32:18 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:32:18 --> Utf8 Class Initialized
INFO - 2016-09-18 16:32:18 --> URI Class Initialized
INFO - 2016-09-18 16:32:18 --> Router Class Initialized
INFO - 2016-09-18 16:32:18 --> Output Class Initialized
INFO - 2016-09-18 16:32:18 --> Security Class Initialized
DEBUG - 2016-09-18 16:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:32:18 --> Input Class Initialized
INFO - 2016-09-18 16:32:18 --> Language Class Initialized
INFO - 2016-09-18 16:32:18 --> Language Class Initialized
INFO - 2016-09-18 16:32:18 --> Config Class Initialized
INFO - 2016-09-18 16:32:18 --> Loader Class Initialized
INFO - 2016-09-18 16:32:18 --> Helper loaded: url_helper
INFO - 2016-09-18 16:32:18 --> Database Driver Class Initialized
INFO - 2016-09-18 16:32:18 --> Controller Class Initialized
DEBUG - 2016-09-18 16:32:18 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:32:18 --> Model Class Initialized
INFO - 2016-09-18 16:32:18 --> Model Class Initialized
DEBUG - 2016-09-18 16:32:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 16:32:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 16:32:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 16:32:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_peminjam.php
DEBUG - 2016-09-18 16:32:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 16:32:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 16:32:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 16:32:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 16:32:19 --> Final output sent to browser
DEBUG - 2016-09-18 16:32:19 --> Total execution time: 0.9761
INFO - 2016-09-18 16:32:21 --> Config Class Initialized
INFO - 2016-09-18 16:32:21 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:32:21 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:32:21 --> Utf8 Class Initialized
INFO - 2016-09-18 16:32:21 --> URI Class Initialized
INFO - 2016-09-18 16:32:22 --> Router Class Initialized
INFO - 2016-09-18 16:32:22 --> Output Class Initialized
INFO - 2016-09-18 16:32:22 --> Security Class Initialized
DEBUG - 2016-09-18 16:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:32:22 --> Input Class Initialized
INFO - 2016-09-18 16:32:22 --> Language Class Initialized
INFO - 2016-09-18 16:32:22 --> Language Class Initialized
INFO - 2016-09-18 16:32:22 --> Config Class Initialized
INFO - 2016-09-18 16:32:22 --> Loader Class Initialized
INFO - 2016-09-18 16:32:22 --> Helper loaded: url_helper
INFO - 2016-09-18 16:32:22 --> Database Driver Class Initialized
INFO - 2016-09-18 16:32:22 --> Controller Class Initialized
DEBUG - 2016-09-18 16:32:22 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:32:22 --> Model Class Initialized
INFO - 2016-09-18 16:32:22 --> Model Class Initialized
DEBUG - 2016-09-18 16:32:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-18 16:32:22 --> Final output sent to browser
DEBUG - 2016-09-18 16:32:22 --> Total execution time: 0.8159
INFO - 2016-09-18 16:32:26 --> Config Class Initialized
INFO - 2016-09-18 16:32:26 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:32:27 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:32:27 --> Utf8 Class Initialized
INFO - 2016-09-18 16:32:27 --> URI Class Initialized
INFO - 2016-09-18 16:32:27 --> Router Class Initialized
INFO - 2016-09-18 16:32:27 --> Output Class Initialized
INFO - 2016-09-18 16:32:27 --> Security Class Initialized
DEBUG - 2016-09-18 16:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:32:27 --> Input Class Initialized
INFO - 2016-09-18 16:32:27 --> Language Class Initialized
INFO - 2016-09-18 16:32:27 --> Language Class Initialized
INFO - 2016-09-18 16:32:27 --> Config Class Initialized
INFO - 2016-09-18 16:32:27 --> Loader Class Initialized
INFO - 2016-09-18 16:32:27 --> Helper loaded: url_helper
INFO - 2016-09-18 16:32:27 --> Database Driver Class Initialized
INFO - 2016-09-18 16:32:27 --> Controller Class Initialized
DEBUG - 2016-09-18 16:32:27 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:32:27 --> Model Class Initialized
INFO - 2016-09-18 16:32:27 --> Model Class Initialized
DEBUG - 2016-09-18 16:32:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_transaksi.php
INFO - 2016-09-18 16:32:27 --> Final output sent to browser
DEBUG - 2016-09-18 16:32:27 --> Total execution time: 0.7402
INFO - 2016-09-18 16:32:38 --> Config Class Initialized
INFO - 2016-09-18 16:32:38 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:32:38 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:32:38 --> Utf8 Class Initialized
INFO - 2016-09-18 16:32:38 --> URI Class Initialized
INFO - 2016-09-18 16:32:38 --> Router Class Initialized
INFO - 2016-09-18 16:32:38 --> Output Class Initialized
INFO - 2016-09-18 16:32:38 --> Security Class Initialized
DEBUG - 2016-09-18 16:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:32:38 --> Input Class Initialized
INFO - 2016-09-18 16:32:38 --> Language Class Initialized
INFO - 2016-09-18 16:32:38 --> Language Class Initialized
INFO - 2016-09-18 16:32:38 --> Config Class Initialized
INFO - 2016-09-18 16:32:38 --> Loader Class Initialized
INFO - 2016-09-18 16:32:38 --> Helper loaded: url_helper
INFO - 2016-09-18 16:32:38 --> Database Driver Class Initialized
INFO - 2016-09-18 16:32:38 --> Controller Class Initialized
DEBUG - 2016-09-18 16:32:38 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:32:38 --> Model Class Initialized
INFO - 2016-09-18 16:32:38 --> Model Class Initialized
DEBUG - 2016-09-18 16:32:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 16:32:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 16:32:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 16:32:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-18 16:32:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 16:32:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 16:32:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 16:32:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 16:32:39 --> Final output sent to browser
DEBUG - 2016-09-18 16:32:39 --> Total execution time: 0.7494
INFO - 2016-09-18 16:32:43 --> Config Class Initialized
INFO - 2016-09-18 16:32:43 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:32:43 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:32:43 --> Utf8 Class Initialized
INFO - 2016-09-18 16:32:43 --> URI Class Initialized
INFO - 2016-09-18 16:32:43 --> Router Class Initialized
INFO - 2016-09-18 16:32:43 --> Output Class Initialized
INFO - 2016-09-18 16:32:43 --> Security Class Initialized
DEBUG - 2016-09-18 16:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:32:43 --> Input Class Initialized
INFO - 2016-09-18 16:32:43 --> Language Class Initialized
INFO - 2016-09-18 16:32:43 --> Language Class Initialized
INFO - 2016-09-18 16:32:43 --> Config Class Initialized
INFO - 2016-09-18 16:32:43 --> Loader Class Initialized
INFO - 2016-09-18 16:32:43 --> Helper loaded: url_helper
INFO - 2016-09-18 16:32:43 --> Database Driver Class Initialized
INFO - 2016-09-18 16:32:43 --> Controller Class Initialized
DEBUG - 2016-09-18 16:32:43 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:32:43 --> Model Class Initialized
INFO - 2016-09-18 16:32:43 --> Model Class Initialized
DEBUG - 2016-09-18 16:32:43 --> Anggota MX_Controller Initialized
INFO - 2016-09-18 16:32:43 --> Database Driver Class Initialized
INFO - 2016-09-18 16:32:43 --> Final output sent to browser
DEBUG - 2016-09-18 16:32:43 --> Total execution time: 0.6145
INFO - 2016-09-18 16:32:45 --> Config Class Initialized
INFO - 2016-09-18 16:32:45 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:32:45 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:32:45 --> Utf8 Class Initialized
INFO - 2016-09-18 16:32:45 --> URI Class Initialized
INFO - 2016-09-18 16:32:45 --> Router Class Initialized
INFO - 2016-09-18 16:32:45 --> Output Class Initialized
INFO - 2016-09-18 16:32:45 --> Security Class Initialized
DEBUG - 2016-09-18 16:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:32:45 --> Input Class Initialized
INFO - 2016-09-18 16:32:45 --> Language Class Initialized
INFO - 2016-09-18 16:32:45 --> Language Class Initialized
INFO - 2016-09-18 16:32:45 --> Config Class Initialized
INFO - 2016-09-18 16:32:46 --> Loader Class Initialized
INFO - 2016-09-18 16:32:46 --> Helper loaded: url_helper
INFO - 2016-09-18 16:32:46 --> Database Driver Class Initialized
INFO - 2016-09-18 16:32:46 --> Controller Class Initialized
DEBUG - 2016-09-18 16:32:46 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:32:46 --> Model Class Initialized
INFO - 2016-09-18 16:32:46 --> Model Class Initialized
DEBUG - 2016-09-18 16:32:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 16:32:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 16:32:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 16:32:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_bayar_angsuran.php
DEBUG - 2016-09-18 16:32:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 16:32:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 16:32:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 16:32:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 16:32:46 --> Final output sent to browser
DEBUG - 2016-09-18 16:32:46 --> Total execution time: 1.0317
INFO - 2016-09-18 16:32:50 --> Config Class Initialized
INFO - 2016-09-18 16:32:50 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:32:50 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:32:50 --> Utf8 Class Initialized
INFO - 2016-09-18 16:32:50 --> URI Class Initialized
INFO - 2016-09-18 16:32:50 --> Router Class Initialized
INFO - 2016-09-18 16:32:50 --> Output Class Initialized
INFO - 2016-09-18 16:32:50 --> Security Class Initialized
DEBUG - 2016-09-18 16:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:32:50 --> Input Class Initialized
INFO - 2016-09-18 16:32:50 --> Language Class Initialized
INFO - 2016-09-18 16:32:50 --> Language Class Initialized
INFO - 2016-09-18 16:32:50 --> Config Class Initialized
INFO - 2016-09-18 16:32:51 --> Loader Class Initialized
INFO - 2016-09-18 16:32:51 --> Helper loaded: url_helper
INFO - 2016-09-18 16:32:51 --> Database Driver Class Initialized
INFO - 2016-09-18 16:32:51 --> Controller Class Initialized
DEBUG - 2016-09-18 16:32:51 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:32:51 --> Model Class Initialized
INFO - 2016-09-18 16:32:51 --> Model Class Initialized
INFO - 2016-09-18 16:32:51 --> Database Driver Class Initialized
INFO - 2016-09-18 16:32:51 --> Final output sent to browser
DEBUG - 2016-09-18 16:32:51 --> Total execution time: 0.7174
INFO - 2016-09-18 16:32:55 --> Config Class Initialized
INFO - 2016-09-18 16:32:55 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:32:55 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:32:55 --> Utf8 Class Initialized
INFO - 2016-09-18 16:32:55 --> URI Class Initialized
INFO - 2016-09-18 16:32:56 --> Router Class Initialized
INFO - 2016-09-18 16:32:56 --> Output Class Initialized
INFO - 2016-09-18 16:32:56 --> Security Class Initialized
DEBUG - 2016-09-18 16:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:32:56 --> Input Class Initialized
INFO - 2016-09-18 16:32:56 --> Language Class Initialized
INFO - 2016-09-18 16:32:56 --> Language Class Initialized
INFO - 2016-09-18 16:32:56 --> Config Class Initialized
INFO - 2016-09-18 16:32:56 --> Loader Class Initialized
INFO - 2016-09-18 16:32:56 --> Helper loaded: url_helper
INFO - 2016-09-18 16:32:56 --> Database Driver Class Initialized
INFO - 2016-09-18 16:32:56 --> Controller Class Initialized
DEBUG - 2016-09-18 16:32:56 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:32:56 --> Model Class Initialized
INFO - 2016-09-18 16:32:56 --> Model Class Initialized
DEBUG - 2016-09-18 16:32:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 16:32:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 16:32:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 16:32:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tutup_angsuran.php
DEBUG - 2016-09-18 16:32:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 16:32:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 16:32:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 16:32:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 16:32:56 --> Final output sent to browser
DEBUG - 2016-09-18 16:32:56 --> Total execution time: 0.7652
INFO - 2016-09-18 16:33:00 --> Config Class Initialized
INFO - 2016-09-18 16:33:00 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:33:00 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:33:00 --> Utf8 Class Initialized
INFO - 2016-09-18 16:33:00 --> URI Class Initialized
INFO - 2016-09-18 16:33:00 --> Router Class Initialized
INFO - 2016-09-18 16:33:00 --> Output Class Initialized
INFO - 2016-09-18 16:33:00 --> Security Class Initialized
DEBUG - 2016-09-18 16:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:00 --> Input Class Initialized
INFO - 2016-09-18 16:33:00 --> Language Class Initialized
INFO - 2016-09-18 16:33:00 --> Language Class Initialized
INFO - 2016-09-18 16:33:00 --> Config Class Initialized
INFO - 2016-09-18 16:33:00 --> Loader Class Initialized
INFO - 2016-09-18 16:33:00 --> Helper loaded: url_helper
INFO - 2016-09-18 16:33:00 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:00 --> Controller Class Initialized
DEBUG - 2016-09-18 16:33:00 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:33:00 --> Model Class Initialized
INFO - 2016-09-18 16:33:00 --> Model Class Initialized
DEBUG - 2016-09-18 16:33:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 16:33:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 16:33:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 16:33:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-18 16:33:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 16:33:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 16:33:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 16:33:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 16:33:01 --> Final output sent to browser
DEBUG - 2016-09-18 16:33:01 --> Total execution time: 0.7828
INFO - 2016-09-18 16:33:04 --> Config Class Initialized
INFO - 2016-09-18 16:33:04 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:33:04 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:33:04 --> Utf8 Class Initialized
INFO - 2016-09-18 16:33:04 --> URI Class Initialized
INFO - 2016-09-18 16:33:04 --> Router Class Initialized
INFO - 2016-09-18 16:33:04 --> Output Class Initialized
INFO - 2016-09-18 16:33:04 --> Security Class Initialized
DEBUG - 2016-09-18 16:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:04 --> Input Class Initialized
INFO - 2016-09-18 16:33:04 --> Language Class Initialized
INFO - 2016-09-18 16:33:04 --> Language Class Initialized
INFO - 2016-09-18 16:33:04 --> Config Class Initialized
INFO - 2016-09-18 16:33:04 --> Loader Class Initialized
INFO - 2016-09-18 16:33:04 --> Helper loaded: url_helper
INFO - 2016-09-18 16:33:04 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:04 --> Controller Class Initialized
DEBUG - 2016-09-18 16:33:04 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:33:04 --> Model Class Initialized
INFO - 2016-09-18 16:33:04 --> Model Class Initialized
DEBUG - 2016-09-18 16:33:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 16:33:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 16:33:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 16:33:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tutup_angsuran.php
DEBUG - 2016-09-18 16:33:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 16:33:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 16:33:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 16:33:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 16:33:05 --> Final output sent to browser
DEBUG - 2016-09-18 16:33:05 --> Total execution time: 0.8067
INFO - 2016-09-18 16:33:09 --> Config Class Initialized
INFO - 2016-09-18 16:33:09 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:33:09 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:33:09 --> Utf8 Class Initialized
INFO - 2016-09-18 16:33:09 --> URI Class Initialized
INFO - 2016-09-18 16:33:09 --> Router Class Initialized
INFO - 2016-09-18 16:33:09 --> Output Class Initialized
INFO - 2016-09-18 16:33:09 --> Security Class Initialized
DEBUG - 2016-09-18 16:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:09 --> Input Class Initialized
INFO - 2016-09-18 16:33:09 --> Language Class Initialized
INFO - 2016-09-18 16:33:09 --> Language Class Initialized
INFO - 2016-09-18 16:33:09 --> Config Class Initialized
INFO - 2016-09-18 16:33:09 --> Loader Class Initialized
INFO - 2016-09-18 16:33:09 --> Helper loaded: url_helper
INFO - 2016-09-18 16:33:09 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:09 --> Controller Class Initialized
DEBUG - 2016-09-18 16:33:10 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:33:10 --> Model Class Initialized
INFO - 2016-09-18 16:33:10 --> Model Class Initialized
INFO - 2016-09-18 16:33:10 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:10 --> Final output sent to browser
DEBUG - 2016-09-18 16:33:10 --> Total execution time: 0.5652
INFO - 2016-09-18 16:33:14 --> Config Class Initialized
INFO - 2016-09-18 16:33:14 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:33:14 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:33:14 --> Utf8 Class Initialized
INFO - 2016-09-18 16:33:14 --> URI Class Initialized
INFO - 2016-09-18 16:33:14 --> Router Class Initialized
INFO - 2016-09-18 16:33:14 --> Output Class Initialized
INFO - 2016-09-18 16:33:14 --> Security Class Initialized
DEBUG - 2016-09-18 16:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:14 --> Input Class Initialized
INFO - 2016-09-18 16:33:14 --> Language Class Initialized
INFO - 2016-09-18 16:33:14 --> Language Class Initialized
INFO - 2016-09-18 16:33:14 --> Config Class Initialized
INFO - 2016-09-18 16:33:14 --> Loader Class Initialized
INFO - 2016-09-18 16:33:14 --> Helper loaded: url_helper
INFO - 2016-09-18 16:33:14 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:14 --> Controller Class Initialized
DEBUG - 2016-09-18 16:33:14 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:33:14 --> Model Class Initialized
INFO - 2016-09-18 16:33:14 --> Model Class Initialized
INFO - 2016-09-18 16:33:14 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:14 --> Final output sent to browser
DEBUG - 2016-09-18 16:33:14 --> Total execution time: 0.5382
INFO - 2016-09-18 16:33:19 --> Config Class Initialized
INFO - 2016-09-18 16:33:19 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:33:19 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:33:19 --> Utf8 Class Initialized
INFO - 2016-09-18 16:33:19 --> URI Class Initialized
INFO - 2016-09-18 16:33:19 --> Router Class Initialized
INFO - 2016-09-18 16:33:19 --> Output Class Initialized
INFO - 2016-09-18 16:33:19 --> Security Class Initialized
DEBUG - 2016-09-18 16:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:19 --> Input Class Initialized
INFO - 2016-09-18 16:33:19 --> Language Class Initialized
INFO - 2016-09-18 16:33:19 --> Language Class Initialized
INFO - 2016-09-18 16:33:19 --> Config Class Initialized
INFO - 2016-09-18 16:33:19 --> Loader Class Initialized
INFO - 2016-09-18 16:33:19 --> Helper loaded: url_helper
INFO - 2016-09-18 16:33:19 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:19 --> Controller Class Initialized
DEBUG - 2016-09-18 16:33:19 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:33:19 --> Model Class Initialized
INFO - 2016-09-18 16:33:19 --> Model Class Initialized
INFO - 2016-09-18 16:33:19 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:19 --> Final output sent to browser
DEBUG - 2016-09-18 16:33:19 --> Total execution time: 0.5340
INFO - 2016-09-18 16:33:20 --> Config Class Initialized
INFO - 2016-09-18 16:33:20 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:33:20 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:33:20 --> Utf8 Class Initialized
INFO - 2016-09-18 16:33:20 --> URI Class Initialized
INFO - 2016-09-18 16:33:20 --> Router Class Initialized
INFO - 2016-09-18 16:33:20 --> Output Class Initialized
INFO - 2016-09-18 16:33:20 --> Security Class Initialized
DEBUG - 2016-09-18 16:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:20 --> Input Class Initialized
INFO - 2016-09-18 16:33:20 --> Language Class Initialized
INFO - 2016-09-18 16:33:20 --> Language Class Initialized
INFO - 2016-09-18 16:33:20 --> Config Class Initialized
INFO - 2016-09-18 16:33:20 --> Loader Class Initialized
INFO - 2016-09-18 16:33:20 --> Helper loaded: url_helper
INFO - 2016-09-18 16:33:20 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:20 --> Controller Class Initialized
DEBUG - 2016-09-18 16:33:20 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:33:21 --> Model Class Initialized
INFO - 2016-09-18 16:33:21 --> Model Class Initialized
INFO - 2016-09-18 16:33:21 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:21 --> Final output sent to browser
DEBUG - 2016-09-18 16:33:21 --> Total execution time: 0.6043
INFO - 2016-09-18 16:33:21 --> Config Class Initialized
INFO - 2016-09-18 16:33:21 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:33:21 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:33:21 --> Utf8 Class Initialized
INFO - 2016-09-18 16:33:21 --> URI Class Initialized
INFO - 2016-09-18 16:33:21 --> Router Class Initialized
INFO - 2016-09-18 16:33:21 --> Output Class Initialized
INFO - 2016-09-18 16:33:21 --> Security Class Initialized
DEBUG - 2016-09-18 16:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:21 --> Input Class Initialized
INFO - 2016-09-18 16:33:21 --> Language Class Initialized
INFO - 2016-09-18 16:33:21 --> Language Class Initialized
INFO - 2016-09-18 16:33:21 --> Config Class Initialized
INFO - 2016-09-18 16:33:21 --> Loader Class Initialized
INFO - 2016-09-18 16:33:21 --> Helper loaded: url_helper
INFO - 2016-09-18 16:33:21 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:22 --> Controller Class Initialized
DEBUG - 2016-09-18 16:33:22 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:33:22 --> Model Class Initialized
INFO - 2016-09-18 16:33:22 --> Model Class Initialized
INFO - 2016-09-18 16:33:22 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:22 --> Final output sent to browser
DEBUG - 2016-09-18 16:33:22 --> Total execution time: 0.6336
INFO - 2016-09-18 16:33:22 --> Config Class Initialized
INFO - 2016-09-18 16:33:22 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:33:22 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:33:22 --> Utf8 Class Initialized
INFO - 2016-09-18 16:33:22 --> URI Class Initialized
INFO - 2016-09-18 16:33:22 --> Router Class Initialized
INFO - 2016-09-18 16:33:22 --> Output Class Initialized
INFO - 2016-09-18 16:33:22 --> Security Class Initialized
DEBUG - 2016-09-18 16:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:23 --> Input Class Initialized
INFO - 2016-09-18 16:33:23 --> Language Class Initialized
INFO - 2016-09-18 16:33:23 --> Language Class Initialized
INFO - 2016-09-18 16:33:23 --> Config Class Initialized
INFO - 2016-09-18 16:33:23 --> Loader Class Initialized
INFO - 2016-09-18 16:33:23 --> Helper loaded: url_helper
INFO - 2016-09-18 16:33:23 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:23 --> Controller Class Initialized
DEBUG - 2016-09-18 16:33:23 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:33:23 --> Model Class Initialized
INFO - 2016-09-18 16:33:23 --> Model Class Initialized
INFO - 2016-09-18 16:33:23 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:23 --> Final output sent to browser
DEBUG - 2016-09-18 16:33:23 --> Total execution time: 0.5724
INFO - 2016-09-18 16:33:23 --> Config Class Initialized
INFO - 2016-09-18 16:33:23 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:33:23 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:33:23 --> Utf8 Class Initialized
INFO - 2016-09-18 16:33:23 --> URI Class Initialized
INFO - 2016-09-18 16:33:23 --> Router Class Initialized
INFO - 2016-09-18 16:33:23 --> Output Class Initialized
INFO - 2016-09-18 16:33:24 --> Security Class Initialized
DEBUG - 2016-09-18 16:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:24 --> Input Class Initialized
INFO - 2016-09-18 16:33:24 --> Language Class Initialized
INFO - 2016-09-18 16:33:24 --> Language Class Initialized
INFO - 2016-09-18 16:33:24 --> Config Class Initialized
INFO - 2016-09-18 16:33:24 --> Loader Class Initialized
INFO - 2016-09-18 16:33:24 --> Helper loaded: url_helper
INFO - 2016-09-18 16:33:24 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:24 --> Controller Class Initialized
DEBUG - 2016-09-18 16:33:24 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:33:24 --> Model Class Initialized
INFO - 2016-09-18 16:33:24 --> Model Class Initialized
INFO - 2016-09-18 16:33:24 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:24 --> Final output sent to browser
DEBUG - 2016-09-18 16:33:24 --> Total execution time: 0.5884
INFO - 2016-09-18 16:33:24 --> Config Class Initialized
INFO - 2016-09-18 16:33:25 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:33:25 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:33:25 --> Utf8 Class Initialized
INFO - 2016-09-18 16:33:25 --> URI Class Initialized
INFO - 2016-09-18 16:33:25 --> Router Class Initialized
INFO - 2016-09-18 16:33:25 --> Output Class Initialized
INFO - 2016-09-18 16:33:25 --> Security Class Initialized
DEBUG - 2016-09-18 16:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:25 --> Input Class Initialized
INFO - 2016-09-18 16:33:25 --> Language Class Initialized
INFO - 2016-09-18 16:33:25 --> Language Class Initialized
INFO - 2016-09-18 16:33:25 --> Config Class Initialized
INFO - 2016-09-18 16:33:25 --> Loader Class Initialized
INFO - 2016-09-18 16:33:25 --> Helper loaded: url_helper
INFO - 2016-09-18 16:33:25 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:25 --> Controller Class Initialized
DEBUG - 2016-09-18 16:33:25 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:33:25 --> Model Class Initialized
INFO - 2016-09-18 16:33:25 --> Model Class Initialized
INFO - 2016-09-18 16:33:25 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:25 --> Final output sent to browser
DEBUG - 2016-09-18 16:33:25 --> Total execution time: 0.7989
INFO - 2016-09-18 16:33:26 --> Config Class Initialized
INFO - 2016-09-18 16:33:26 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:33:26 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:33:26 --> Utf8 Class Initialized
INFO - 2016-09-18 16:33:26 --> URI Class Initialized
INFO - 2016-09-18 16:33:26 --> Router Class Initialized
INFO - 2016-09-18 16:33:26 --> Output Class Initialized
INFO - 2016-09-18 16:33:26 --> Security Class Initialized
DEBUG - 2016-09-18 16:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:26 --> Input Class Initialized
INFO - 2016-09-18 16:33:26 --> Language Class Initialized
INFO - 2016-09-18 16:33:26 --> Language Class Initialized
INFO - 2016-09-18 16:33:26 --> Config Class Initialized
INFO - 2016-09-18 16:33:26 --> Loader Class Initialized
INFO - 2016-09-18 16:33:26 --> Helper loaded: url_helper
INFO - 2016-09-18 16:33:26 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:26 --> Controller Class Initialized
DEBUG - 2016-09-18 16:33:26 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:33:26 --> Model Class Initialized
INFO - 2016-09-18 16:33:26 --> Model Class Initialized
INFO - 2016-09-18 16:33:26 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:26 --> Final output sent to browser
DEBUG - 2016-09-18 16:33:26 --> Total execution time: 0.7982
INFO - 2016-09-18 16:33:27 --> Config Class Initialized
INFO - 2016-09-18 16:33:27 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:33:27 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:33:27 --> Utf8 Class Initialized
INFO - 2016-09-18 16:33:27 --> URI Class Initialized
INFO - 2016-09-18 16:33:27 --> Router Class Initialized
INFO - 2016-09-18 16:33:27 --> Output Class Initialized
INFO - 2016-09-18 16:33:27 --> Security Class Initialized
DEBUG - 2016-09-18 16:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:27 --> Input Class Initialized
INFO - 2016-09-18 16:33:27 --> Language Class Initialized
INFO - 2016-09-18 16:33:27 --> Language Class Initialized
INFO - 2016-09-18 16:33:27 --> Config Class Initialized
INFO - 2016-09-18 16:33:27 --> Loader Class Initialized
INFO - 2016-09-18 16:33:27 --> Helper loaded: url_helper
INFO - 2016-09-18 16:33:27 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:27 --> Controller Class Initialized
DEBUG - 2016-09-18 16:33:27 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:33:27 --> Model Class Initialized
INFO - 2016-09-18 16:33:27 --> Model Class Initialized
INFO - 2016-09-18 16:33:27 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:27 --> Final output sent to browser
DEBUG - 2016-09-18 16:33:27 --> Total execution time: 0.5923
INFO - 2016-09-18 16:33:28 --> Config Class Initialized
INFO - 2016-09-18 16:33:28 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:33:28 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:33:28 --> Utf8 Class Initialized
INFO - 2016-09-18 16:33:28 --> URI Class Initialized
INFO - 2016-09-18 16:33:28 --> Router Class Initialized
INFO - 2016-09-18 16:33:28 --> Output Class Initialized
INFO - 2016-09-18 16:33:28 --> Security Class Initialized
DEBUG - 2016-09-18 16:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:28 --> Input Class Initialized
INFO - 2016-09-18 16:33:28 --> Language Class Initialized
INFO - 2016-09-18 16:33:28 --> Language Class Initialized
INFO - 2016-09-18 16:33:28 --> Config Class Initialized
INFO - 2016-09-18 16:33:28 --> Loader Class Initialized
INFO - 2016-09-18 16:33:28 --> Helper loaded: url_helper
INFO - 2016-09-18 16:33:28 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:28 --> Controller Class Initialized
DEBUG - 2016-09-18 16:33:28 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:33:29 --> Model Class Initialized
INFO - 2016-09-18 16:33:29 --> Model Class Initialized
INFO - 2016-09-18 16:33:29 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:29 --> Final output sent to browser
DEBUG - 2016-09-18 16:33:29 --> Total execution time: 0.8886
INFO - 2016-09-18 16:33:29 --> Config Class Initialized
INFO - 2016-09-18 16:33:29 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:33:29 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:33:29 --> Utf8 Class Initialized
INFO - 2016-09-18 16:33:29 --> URI Class Initialized
INFO - 2016-09-18 16:33:29 --> Router Class Initialized
INFO - 2016-09-18 16:33:29 --> Output Class Initialized
INFO - 2016-09-18 16:33:29 --> Security Class Initialized
DEBUG - 2016-09-18 16:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:29 --> Input Class Initialized
INFO - 2016-09-18 16:33:29 --> Language Class Initialized
INFO - 2016-09-18 16:33:29 --> Language Class Initialized
INFO - 2016-09-18 16:33:29 --> Config Class Initialized
INFO - 2016-09-18 16:33:29 --> Loader Class Initialized
INFO - 2016-09-18 16:33:29 --> Helper loaded: url_helper
INFO - 2016-09-18 16:33:29 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:29 --> Controller Class Initialized
DEBUG - 2016-09-18 16:33:29 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:33:30 --> Model Class Initialized
INFO - 2016-09-18 16:33:30 --> Config Class Initialized
INFO - 2016-09-18 16:33:30 --> Hooks Class Initialized
INFO - 2016-09-18 16:33:30 --> Model Class Initialized
DEBUG - 2016-09-18 16:33:30 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:33:30 --> Utf8 Class Initialized
INFO - 2016-09-18 16:33:30 --> URI Class Initialized
INFO - 2016-09-18 16:33:30 --> Router Class Initialized
INFO - 2016-09-18 16:33:30 --> Output Class Initialized
INFO - 2016-09-18 16:33:30 --> Security Class Initialized
DEBUG - 2016-09-18 16:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:30 --> Input Class Initialized
INFO - 2016-09-18 16:33:30 --> Language Class Initialized
INFO - 2016-09-18 16:33:30 --> Language Class Initialized
INFO - 2016-09-18 16:33:30 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:30 --> Final output sent to browser
INFO - 2016-09-18 16:33:30 --> Config Class Initialized
DEBUG - 2016-09-18 16:33:30 --> Total execution time: 1.2413
INFO - 2016-09-18 16:33:30 --> Config Class Initialized
INFO - 2016-09-18 16:33:30 --> Loader Class Initialized
INFO - 2016-09-18 16:33:30 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:33:30 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:33:30 --> Utf8 Class Initialized
INFO - 2016-09-18 16:33:30 --> URI Class Initialized
INFO - 2016-09-18 16:33:30 --> Config Class Initialized
INFO - 2016-09-18 16:33:30 --> Helper loaded: url_helper
INFO - 2016-09-18 16:33:30 --> Hooks Class Initialized
INFO - 2016-09-18 16:33:30 --> Router Class Initialized
DEBUG - 2016-09-18 16:33:30 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:33:30 --> Utf8 Class Initialized
INFO - 2016-09-18 16:33:31 --> URI Class Initialized
INFO - 2016-09-18 16:33:31 --> Router Class Initialized
INFO - 2016-09-18 16:33:31 --> Output Class Initialized
INFO - 2016-09-18 16:33:31 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:31 --> Config Class Initialized
INFO - 2016-09-18 16:33:31 --> Output Class Initialized
INFO - 2016-09-18 16:33:31 --> Config Class Initialized
INFO - 2016-09-18 16:33:31 --> Hooks Class Initialized
INFO - 2016-09-18 16:33:31 --> Security Class Initialized
INFO - 2016-09-18 16:33:31 --> Hooks Class Initialized
INFO - 2016-09-18 16:33:31 --> Security Class Initialized
DEBUG - 2016-09-18 16:33:31 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:33:31 --> Controller Class Initialized
DEBUG - 2016-09-18 16:33:31 --> UTF-8 Support Enabled
DEBUG - 2016-09-18 16:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-18 16:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-18 16:33:31 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:33:31 --> Config Class Initialized
INFO - 2016-09-18 16:33:31 --> Utf8 Class Initialized
INFO - 2016-09-18 16:33:31 --> Hooks Class Initialized
INFO - 2016-09-18 16:33:31 --> Model Class Initialized
INFO - 2016-09-18 16:33:31 --> URI Class Initialized
INFO - 2016-09-18 16:33:31 --> Utf8 Class Initialized
INFO - 2016-09-18 16:33:31 --> Input Class Initialized
INFO - 2016-09-18 16:33:31 --> Input Class Initialized
DEBUG - 2016-09-18 16:33:31 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:33:31 --> Model Class Initialized
INFO - 2016-09-18 16:33:31 --> Utf8 Class Initialized
INFO - 2016-09-18 16:33:31 --> URI Class Initialized
INFO - 2016-09-18 16:33:31 --> Language Class Initialized
INFO - 2016-09-18 16:33:31 --> Router Class Initialized
INFO - 2016-09-18 16:33:31 --> Language Class Initialized
INFO - 2016-09-18 16:33:31 --> Language Class Initialized
INFO - 2016-09-18 16:33:31 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:31 --> Config Class Initialized
INFO - 2016-09-18 16:33:31 --> Final output sent to browser
INFO - 2016-09-18 16:33:31 --> URI Class Initialized
INFO - 2016-09-18 16:33:31 --> Output Class Initialized
INFO - 2016-09-18 16:33:31 --> Router Class Initialized
INFO - 2016-09-18 16:33:31 --> Language Class Initialized
DEBUG - 2016-09-18 16:33:31 --> Total execution time: 1.6622
INFO - 2016-09-18 16:33:31 --> Loader Class Initialized
INFO - 2016-09-18 16:33:31 --> Config Class Initialized
INFO - 2016-09-18 16:33:31 --> Output Class Initialized
INFO - 2016-09-18 16:33:31 --> Router Class Initialized
INFO - 2016-09-18 16:33:31 --> Security Class Initialized
INFO - 2016-09-18 16:33:31 --> Helper loaded: url_helper
DEBUG - 2016-09-18 16:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:32 --> Config Class Initialized
INFO - 2016-09-18 16:33:32 --> Output Class Initialized
INFO - 2016-09-18 16:33:32 --> Security Class Initialized
INFO - 2016-09-18 16:33:32 --> Loader Class Initialized
INFO - 2016-09-18 16:33:32 --> Helper loaded: url_helper
INFO - 2016-09-18 16:33:32 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:32 --> Input Class Initialized
INFO - 2016-09-18 16:33:32 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:32 --> Security Class Initialized
DEBUG - 2016-09-18 16:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:32 --> Controller Class Initialized
DEBUG - 2016-09-18 16:33:32 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:33:32 --> Language Class Initialized
INFO - 2016-09-18 16:33:32 --> Input Class Initialized
INFO - 2016-09-18 16:33:32 --> Controller Class Initialized
DEBUG - 2016-09-18 16:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:32 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:33:32 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:33:32 --> Model Class Initialized
INFO - 2016-09-18 16:33:32 --> Input Class Initialized
DEBUG - 2016-09-18 16:33:32 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:33:32 --> Language Class Initialized
INFO - 2016-09-18 16:33:32 --> Language Class Initialized
INFO - 2016-09-18 16:33:32 --> Model Class Initialized
INFO - 2016-09-18 16:33:32 --> Model Class Initialized
INFO - 2016-09-18 16:33:32 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:32 --> Config Class Initialized
INFO - 2016-09-18 16:33:32 --> Language Class Initialized
INFO - 2016-09-18 16:33:32 --> Model Class Initialized
INFO - 2016-09-18 16:33:32 --> Language Class Initialized
INFO - 2016-09-18 16:33:32 --> Final output sent to browser
DEBUG - 2016-09-18 16:33:32 --> Total execution time: 1.8607
INFO - 2016-09-18 16:33:32 --> Loader Class Initialized
INFO - 2016-09-18 16:33:32 --> Language Class Initialized
INFO - 2016-09-18 16:33:32 --> Config Class Initialized
INFO - 2016-09-18 16:33:32 --> Utf8 Class Initialized
INFO - 2016-09-18 16:33:32 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:32 --> Config Class Initialized
INFO - 2016-09-18 16:33:32 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:33:32 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:33:32 --> Utf8 Class Initialized
INFO - 2016-09-18 16:33:32 --> URI Class Initialized
INFO - 2016-09-18 16:33:33 --> Router Class Initialized
INFO - 2016-09-18 16:33:33 --> Output Class Initialized
INFO - 2016-09-18 16:33:33 --> Security Class Initialized
DEBUG - 2016-09-18 16:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:33 --> Input Class Initialized
INFO - 2016-09-18 16:33:33 --> Language Class Initialized
INFO - 2016-09-18 16:33:33 --> URI Class Initialized
INFO - 2016-09-18 16:33:33 --> Language Class Initialized
INFO - 2016-09-18 16:33:33 --> Config Class Initialized
INFO - 2016-09-18 16:33:33 --> Helper loaded: url_helper
INFO - 2016-09-18 16:33:33 --> Final output sent to browser
DEBUG - 2016-09-18 16:33:33 --> Total execution time: 2.8675
INFO - 2016-09-18 16:33:33 --> Router Class Initialized
INFO - 2016-09-18 16:33:33 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:33 --> Loader Class Initialized
INFO - 2016-09-18 16:33:33 --> Config Class Initialized
INFO - 2016-09-18 16:33:33 --> Loader Class Initialized
INFO - 2016-09-18 16:33:33 --> Config Class Initialized
INFO - 2016-09-18 16:33:33 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:33:33 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:33:33 --> Utf8 Class Initialized
INFO - 2016-09-18 16:33:33 --> URI Class Initialized
INFO - 2016-09-18 16:33:33 --> Helper loaded: url_helper
INFO - 2016-09-18 16:33:33 --> Loader Class Initialized
INFO - 2016-09-18 16:33:33 --> Helper loaded: url_helper
INFO - 2016-09-18 16:33:33 --> Output Class Initialized
INFO - 2016-09-18 16:33:33 --> Router Class Initialized
INFO - 2016-09-18 16:33:33 --> Output Class Initialized
INFO - 2016-09-18 16:33:34 --> Controller Class Initialized
DEBUG - 2016-09-18 16:33:34 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:33:34 --> Security Class Initialized
INFO - 2016-09-18 16:33:34 --> Helper loaded: url_helper
INFO - 2016-09-18 16:33:34 --> Security Class Initialized
INFO - 2016-09-18 16:33:34 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:34 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:34 --> Model Class Initialized
INFO - 2016-09-18 16:33:34 --> Model Class Initialized
DEBUG - 2016-09-18 16:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:34 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:34 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:34 --> Controller Class Initialized
INFO - 2016-09-18 16:33:34 --> Controller Class Initialized
DEBUG - 2016-09-18 16:33:34 --> Index MX_Controller Initialized
DEBUG - 2016-09-18 16:33:34 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:33:34 --> Input Class Initialized
DEBUG - 2016-09-18 16:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:34 --> Final output sent to browser
INFO - 2016-09-18 16:33:34 --> Controller Class Initialized
DEBUG - 2016-09-18 16:33:34 --> Index MX_Controller Initialized
DEBUG - 2016-09-18 16:33:34 --> Total execution time: 3.1689
INFO - 2016-09-18 16:33:34 --> Model Class Initialized
INFO - 2016-09-18 16:33:34 --> Input Class Initialized
INFO - 2016-09-18 16:33:34 --> Model Class Initialized
INFO - 2016-09-18 16:33:34 --> Language Class Initialized
INFO - 2016-09-18 16:33:34 --> Model Class Initialized
INFO - 2016-09-18 16:33:34 --> Language Class Initialized
INFO - 2016-09-18 16:33:34 --> Config Class Initialized
INFO - 2016-09-18 16:33:34 --> Model Class Initialized
INFO - 2016-09-18 16:33:34 --> Model Class Initialized
INFO - 2016-09-18 16:33:34 --> Model Class Initialized
INFO - 2016-09-18 16:33:34 --> Language Class Initialized
INFO - 2016-09-18 16:33:34 --> Config Class Initialized
INFO - 2016-09-18 16:33:34 --> Hooks Class Initialized
INFO - 2016-09-18 16:33:34 --> Loader Class Initialized
INFO - 2016-09-18 16:33:34 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:34 --> Language Class Initialized
INFO - 2016-09-18 16:33:34 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:34 --> Config Class Initialized
INFO - 2016-09-18 16:33:34 --> Database Driver Class Initialized
DEBUG - 2016-09-18 16:33:34 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:33:34 --> Loader Class Initialized
INFO - 2016-09-18 16:33:34 --> Helper loaded: url_helper
INFO - 2016-09-18 16:33:34 --> Final output sent to browser
INFO - 2016-09-18 16:33:34 --> Final output sent to browser
INFO - 2016-09-18 16:33:34 --> Final output sent to browser
INFO - 2016-09-18 16:33:34 --> Utf8 Class Initialized
INFO - 2016-09-18 16:33:34 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:34 --> Helper loaded: url_helper
DEBUG - 2016-09-18 16:33:34 --> Total execution time: 2.0822
DEBUG - 2016-09-18 16:33:34 --> Total execution time: 3.7117
DEBUG - 2016-09-18 16:33:34 --> Total execution time: 3.4084
INFO - 2016-09-18 16:33:35 --> URI Class Initialized
INFO - 2016-09-18 16:33:35 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:35 --> Controller Class Initialized
DEBUG - 2016-09-18 16:33:35 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:33:35 --> Model Class Initialized
INFO - 2016-09-18 16:33:35 --> Model Class Initialized
INFO - 2016-09-18 16:33:35 --> Config Class Initialized
INFO - 2016-09-18 16:33:35 --> Router Class Initialized
INFO - 2016-09-18 16:33:35 --> Config Class Initialized
INFO - 2016-09-18 16:33:35 --> Hooks Class Initialized
INFO - 2016-09-18 16:33:35 --> Controller Class Initialized
INFO - 2016-09-18 16:33:35 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:35 --> Hooks Class Initialized
INFO - 2016-09-18 16:33:35 --> Output Class Initialized
DEBUG - 2016-09-18 16:33:35 --> Index MX_Controller Initialized
DEBUG - 2016-09-18 16:33:35 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:33:35 --> Config Class Initialized
DEBUG - 2016-09-18 16:33:35 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:33:35 --> Security Class Initialized
INFO - 2016-09-18 16:33:35 --> Model Class Initialized
INFO - 2016-09-18 16:33:35 --> Model Class Initialized
INFO - 2016-09-18 16:33:35 --> Final output sent to browser
INFO - 2016-09-18 16:33:35 --> Database Driver Class Initialized
DEBUG - 2016-09-18 16:33:35 --> Total execution time: 3.7388
INFO - 2016-09-18 16:33:35 --> Final output sent to browser
DEBUG - 2016-09-18 16:33:35 --> Total execution time: 2.0401
INFO - 2016-09-18 16:33:35 --> Config Class Initialized
INFO - 2016-09-18 16:33:35 --> Config Class Initialized
INFO - 2016-09-18 16:33:35 --> Utf8 Class Initialized
DEBUG - 2016-09-18 16:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:35 --> Utf8 Class Initialized
INFO - 2016-09-18 16:33:35 --> Hooks Class Initialized
INFO - 2016-09-18 16:33:35 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:33:35 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:33:35 --> Utf8 Class Initialized
INFO - 2016-09-18 16:33:36 --> URI Class Initialized
INFO - 2016-09-18 16:33:36 --> Router Class Initialized
INFO - 2016-09-18 16:33:36 --> Output Class Initialized
INFO - 2016-09-18 16:33:36 --> Security Class Initialized
DEBUG - 2016-09-18 16:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:36 --> Input Class Initialized
INFO - 2016-09-18 16:33:36 --> Language Class Initialized
INFO - 2016-09-18 16:33:36 --> Language Class Initialized
INFO - 2016-09-18 16:33:36 --> Input Class Initialized
INFO - 2016-09-18 16:33:36 --> URI Class Initialized
INFO - 2016-09-18 16:33:36 --> URI Class Initialized
INFO - 2016-09-18 16:33:36 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:33:36 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:33:36 --> Language Class Initialized
INFO - 2016-09-18 16:33:36 --> Config Class Initialized
INFO - 2016-09-18 16:33:36 --> Utf8 Class Initialized
DEBUG - 2016-09-18 16:33:36 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:33:36 --> Router Class Initialized
INFO - 2016-09-18 16:33:36 --> Router Class Initialized
INFO - 2016-09-18 16:33:36 --> Output Class Initialized
INFO - 2016-09-18 16:33:36 --> Output Class Initialized
INFO - 2016-09-18 16:33:36 --> URI Class Initialized
INFO - 2016-09-18 16:33:36 --> Utf8 Class Initialized
INFO - 2016-09-18 16:33:36 --> Loader Class Initialized
INFO - 2016-09-18 16:33:36 --> Language Class Initialized
INFO - 2016-09-18 16:33:36 --> Security Class Initialized
DEBUG - 2016-09-18 16:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:36 --> Input Class Initialized
INFO - 2016-09-18 16:33:36 --> Language Class Initialized
INFO - 2016-09-18 16:33:36 --> Language Class Initialized
INFO - 2016-09-18 16:33:36 --> Config Class Initialized
INFO - 2016-09-18 16:33:36 --> Loader Class Initialized
INFO - 2016-09-18 16:33:37 --> Helper loaded: url_helper
INFO - 2016-09-18 16:33:37 --> Security Class Initialized
INFO - 2016-09-18 16:33:37 --> Router Class Initialized
INFO - 2016-09-18 16:33:37 --> Helper loaded: url_helper
INFO - 2016-09-18 16:33:37 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:37 --> Config Class Initialized
INFO - 2016-09-18 16:33:37 --> URI Class Initialized
DEBUG - 2016-09-18 16:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:37 --> Input Class Initialized
INFO - 2016-09-18 16:33:37 --> Language Class Initialized
INFO - 2016-09-18 16:33:37 --> Language Class Initialized
INFO - 2016-09-18 16:33:37 --> Config Class Initialized
INFO - 2016-09-18 16:33:37 --> Loader Class Initialized
INFO - 2016-09-18 16:33:37 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:37 --> Output Class Initialized
INFO - 2016-09-18 16:33:37 --> Loader Class Initialized
INFO - 2016-09-18 16:33:37 --> Router Class Initialized
INFO - 2016-09-18 16:33:37 --> Helper loaded: url_helper
INFO - 2016-09-18 16:33:37 --> Helper loaded: url_helper
INFO - 2016-09-18 16:33:37 --> Security Class Initialized
INFO - 2016-09-18 16:33:37 --> Output Class Initialized
INFO - 2016-09-18 16:33:37 --> Controller Class Initialized
INFO - 2016-09-18 16:33:37 --> Controller Class Initialized
DEBUG - 2016-09-18 16:33:37 --> Index MX_Controller Initialized
DEBUG - 2016-09-18 16:33:37 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:33:37 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:37 --> Security Class Initialized
INFO - 2016-09-18 16:33:37 --> Database Driver Class Initialized
DEBUG - 2016-09-18 16:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:37 --> Model Class Initialized
INFO - 2016-09-18 16:33:37 --> Model Class Initialized
INFO - 2016-09-18 16:33:37 --> Model Class Initialized
DEBUG - 2016-09-18 16:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:37 --> Input Class Initialized
INFO - 2016-09-18 16:33:37 --> Controller Class Initialized
INFO - 2016-09-18 16:33:37 --> Controller Class Initialized
DEBUG - 2016-09-18 16:33:37 --> Index MX_Controller Initialized
DEBUG - 2016-09-18 16:33:37 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:33:37 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:37 --> Model Class Initialized
INFO - 2016-09-18 16:33:37 --> Language Class Initialized
INFO - 2016-09-18 16:33:37 --> Input Class Initialized
INFO - 2016-09-18 16:33:37 --> Model Class Initialized
INFO - 2016-09-18 16:33:37 --> Model Class Initialized
INFO - 2016-09-18 16:33:37 --> Final output sent to browser
INFO - 2016-09-18 16:33:37 --> Language Class Initialized
INFO - 2016-09-18 16:33:37 --> Language Class Initialized
INFO - 2016-09-18 16:33:37 --> Database Driver Class Initialized
DEBUG - 2016-09-18 16:33:37 --> Total execution time: 2.6811
INFO - 2016-09-18 16:33:37 --> Model Class Initialized
INFO - 2016-09-18 16:33:37 --> Config Class Initialized
INFO - 2016-09-18 16:33:37 --> Model Class Initialized
INFO - 2016-09-18 16:33:37 --> Language Class Initialized
INFO - 2016-09-18 16:33:38 --> Final output sent to browser
INFO - 2016-09-18 16:33:38 --> Config Class Initialized
DEBUG - 2016-09-18 16:33:38 --> Total execution time: 2.2366
INFO - 2016-09-18 16:33:38 --> Hooks Class Initialized
INFO - 2016-09-18 16:33:38 --> Config Class Initialized
INFO - 2016-09-18 16:33:38 --> Config Class Initialized
INFO - 2016-09-18 16:33:38 --> Loader Class Initialized
INFO - 2016-09-18 16:33:38 --> Database Driver Class Initialized
DEBUG - 2016-09-18 16:33:38 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:33:38 --> Final output sent to browser
INFO - 2016-09-18 16:33:38 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:38 --> Helper loaded: url_helper
INFO - 2016-09-18 16:33:38 --> Loader Class Initialized
INFO - 2016-09-18 16:33:38 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:33:38 --> Total execution time: 3.5803
INFO - 2016-09-18 16:33:38 --> Utf8 Class Initialized
INFO - 2016-09-18 16:33:38 --> Helper loaded: url_helper
DEBUG - 2016-09-18 16:33:38 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:33:38 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:38 --> Final output sent to browser
INFO - 2016-09-18 16:33:38 --> Config Class Initialized
DEBUG - 2016-09-18 16:33:38 --> Total execution time: 3.2982
INFO - 2016-09-18 16:33:38 --> Utf8 Class Initialized
INFO - 2016-09-18 16:33:38 --> Config Class Initialized
INFO - 2016-09-18 16:33:38 --> Hooks Class Initialized
INFO - 2016-09-18 16:33:38 --> URI Class Initialized
INFO - 2016-09-18 16:33:38 --> Controller Class Initialized
INFO - 2016-09-18 16:33:38 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:33:38 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:33:38 --> URI Class Initialized
DEBUG - 2016-09-18 16:33:38 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:33:38 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:38 --> Router Class Initialized
INFO - 2016-09-18 16:33:38 --> Utf8 Class Initialized
INFO - 2016-09-18 16:33:38 --> Router Class Initialized
DEBUG - 2016-09-18 16:33:38 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:33:38 --> Model Class Initialized
INFO - 2016-09-18 16:33:38 --> Model Class Initialized
INFO - 2016-09-18 16:33:39 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:39 --> Output Class Initialized
INFO - 2016-09-18 16:33:39 --> Controller Class Initialized
INFO - 2016-09-18 16:33:39 --> Final output sent to browser
DEBUG - 2016-09-18 16:33:39 --> Index MX_Controller Initialized
DEBUG - 2016-09-18 16:33:39 --> Total execution time: 3.9981
INFO - 2016-09-18 16:33:39 --> Security Class Initialized
INFO - 2016-09-18 16:33:39 --> Utf8 Class Initialized
INFO - 2016-09-18 16:33:39 --> URI Class Initialized
INFO - 2016-09-18 16:33:39 --> Output Class Initialized
INFO - 2016-09-18 16:33:39 --> Model Class Initialized
INFO - 2016-09-18 16:33:39 --> Router Class Initialized
INFO - 2016-09-18 16:33:39 --> Security Class Initialized
INFO - 2016-09-18 16:33:39 --> URI Class Initialized
DEBUG - 2016-09-18 16:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:39 --> Config Class Initialized
INFO - 2016-09-18 16:33:39 --> Model Class Initialized
INFO - 2016-09-18 16:33:39 --> Output Class Initialized
DEBUG - 2016-09-18 16:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:39 --> Security Class Initialized
INFO - 2016-09-18 16:33:39 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:39 --> Input Class Initialized
INFO - 2016-09-18 16:33:39 --> Language Class Initialized
INFO - 2016-09-18 16:33:39 --> Language Class Initialized
INFO - 2016-09-18 16:33:39 --> Final output sent to browser
INFO - 2016-09-18 16:33:39 --> Input Class Initialized
INFO - 2016-09-18 16:33:39 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:39 --> Router Class Initialized
DEBUG - 2016-09-18 16:33:39 --> Total execution time: 3.7973
INFO - 2016-09-18 16:33:39 --> Language Class Initialized
INFO - 2016-09-18 16:33:39 --> Config Class Initialized
INFO - 2016-09-18 16:33:39 --> Output Class Initialized
INFO - 2016-09-18 16:33:39 --> Input Class Initialized
DEBUG - 2016-09-18 16:33:39 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:33:39 --> Config Class Initialized
INFO - 2016-09-18 16:33:39 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:33:39 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:33:39 --> Utf8 Class Initialized
INFO - 2016-09-18 16:33:40 --> Utf8 Class Initialized
INFO - 2016-09-18 16:33:40 --> URI Class Initialized
INFO - 2016-09-18 16:33:40 --> Security Class Initialized
INFO - 2016-09-18 16:33:40 --> Language Class Initialized
INFO - 2016-09-18 16:33:40 --> Loader Class Initialized
INFO - 2016-09-18 16:33:40 --> Language Class Initialized
INFO - 2016-09-18 16:33:40 --> Config Class Initialized
INFO - 2016-09-18 16:33:40 --> Helper loaded: url_helper
INFO - 2016-09-18 16:33:40 --> URI Class Initialized
DEBUG - 2016-09-18 16:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:40 --> Language Class Initialized
INFO - 2016-09-18 16:33:40 --> Router Class Initialized
INFO - 2016-09-18 16:33:40 --> Loader Class Initialized
INFO - 2016-09-18 16:33:40 --> Helper loaded: url_helper
INFO - 2016-09-18 16:33:40 --> Output Class Initialized
INFO - 2016-09-18 16:33:40 --> Config Class Initialized
INFO - 2016-09-18 16:33:40 --> Security Class Initialized
INFO - 2016-09-18 16:33:40 --> Loader Class Initialized
INFO - 2016-09-18 16:33:40 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:40 --> Router Class Initialized
INFO - 2016-09-18 16:33:40 --> Helper loaded: url_helper
INFO - 2016-09-18 16:33:40 --> Database Driver Class Initialized
DEBUG - 2016-09-18 16:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:40 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:40 --> Output Class Initialized
INFO - 2016-09-18 16:33:40 --> Controller Class Initialized
INFO - 2016-09-18 16:33:40 --> Input Class Initialized
INFO - 2016-09-18 16:33:40 --> Controller Class Initialized
INFO - 2016-09-18 16:33:40 --> Input Class Initialized
INFO - 2016-09-18 16:33:40 --> Language Class Initialized
INFO - 2016-09-18 16:33:40 --> Language Class Initialized
INFO - 2016-09-18 16:33:40 --> Language Class Initialized
DEBUG - 2016-09-18 16:33:40 --> Index MX_Controller Initialized
DEBUG - 2016-09-18 16:33:40 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:33:40 --> Controller Class Initialized
DEBUG - 2016-09-18 16:33:40 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:33:40 --> Security Class Initialized
INFO - 2016-09-18 16:33:40 --> Model Class Initialized
INFO - 2016-09-18 16:33:40 --> Language Class Initialized
INFO - 2016-09-18 16:33:40 --> Config Class Initialized
INFO - 2016-09-18 16:33:40 --> Model Class Initialized
INFO - 2016-09-18 16:33:40 --> Model Class Initialized
INFO - 2016-09-18 16:33:40 --> Model Class Initialized
INFO - 2016-09-18 16:33:40 --> Config Class Initialized
INFO - 2016-09-18 16:33:40 --> Model Class Initialized
INFO - 2016-09-18 16:33:40 --> Model Class Initialized
DEBUG - 2016-09-18 16:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:40 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:40 --> Loader Class Initialized
INFO - 2016-09-18 16:33:40 --> Input Class Initialized
INFO - 2016-09-18 16:33:40 --> Helper loaded: url_helper
INFO - 2016-09-18 16:33:40 --> Loader Class Initialized
INFO - 2016-09-18 16:33:40 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:40 --> Final output sent to browser
INFO - 2016-09-18 16:33:40 --> Database Driver Class Initialized
DEBUG - 2016-09-18 16:33:40 --> Total execution time: 2.4367
INFO - 2016-09-18 16:33:40 --> Language Class Initialized
INFO - 2016-09-18 16:33:40 --> Final output sent to browser
INFO - 2016-09-18 16:33:40 --> Final output sent to browser
INFO - 2016-09-18 16:33:40 --> Helper loaded: url_helper
INFO - 2016-09-18 16:33:40 --> Database Driver Class Initialized
DEBUG - 2016-09-18 16:33:40 --> Total execution time: 2.8683
DEBUG - 2016-09-18 16:33:40 --> Total execution time: 2.7689
INFO - 2016-09-18 16:33:40 --> Config Class Initialized
INFO - 2016-09-18 16:33:40 --> Language Class Initialized
INFO - 2016-09-18 16:33:40 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:41 --> Controller Class Initialized
DEBUG - 2016-09-18 16:33:41 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:33:41 --> Hooks Class Initialized
INFO - 2016-09-18 16:33:41 --> Config Class Initialized
INFO - 2016-09-18 16:33:41 --> Config Class Initialized
INFO - 2016-09-18 16:33:41 --> Config Class Initialized
INFO - 2016-09-18 16:33:41 --> Hooks Class Initialized
INFO - 2016-09-18 16:33:41 --> Model Class Initialized
INFO - 2016-09-18 16:33:41 --> Controller Class Initialized
INFO - 2016-09-18 16:33:41 --> Loader Class Initialized
INFO - 2016-09-18 16:33:41 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:33:41 --> UTF-8 Support Enabled
DEBUG - 2016-09-18 16:33:41 --> Index MX_Controller Initialized
DEBUG - 2016-09-18 16:33:41 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:33:41 --> Utf8 Class Initialized
INFO - 2016-09-18 16:33:41 --> Model Class Initialized
INFO - 2016-09-18 16:33:41 --> Helper loaded: url_helper
DEBUG - 2016-09-18 16:33:41 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:33:41 --> Model Class Initialized
INFO - 2016-09-18 16:33:41 --> Model Class Initialized
INFO - 2016-09-18 16:33:41 --> Utf8 Class Initialized
INFO - 2016-09-18 16:33:41 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:41 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:41 --> URI Class Initialized
INFO - 2016-09-18 16:33:41 --> Utf8 Class Initialized
INFO - 2016-09-18 16:33:41 --> URI Class Initialized
INFO - 2016-09-18 16:33:41 --> Router Class Initialized
INFO - 2016-09-18 16:33:41 --> Output Class Initialized
INFO - 2016-09-18 16:33:41 --> Final output sent to browser
INFO - 2016-09-18 16:33:41 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:41 --> URI Class Initialized
INFO - 2016-09-18 16:33:41 --> Router Class Initialized
DEBUG - 2016-09-18 16:33:41 --> Total execution time: 1.8226
INFO - 2016-09-18 16:33:41 --> Router Class Initialized
INFO - 2016-09-18 16:33:41 --> Security Class Initialized
INFO - 2016-09-18 16:33:41 --> Final output sent to browser
INFO - 2016-09-18 16:33:41 --> Output Class Initialized
INFO - 2016-09-18 16:33:41 --> Controller Class Initialized
DEBUG - 2016-09-18 16:33:41 --> Index MX_Controller Initialized
DEBUG - 2016-09-18 16:33:41 --> Total execution time: 2.9974
INFO - 2016-09-18 16:33:41 --> Security Class Initialized
INFO - 2016-09-18 16:33:41 --> Output Class Initialized
DEBUG - 2016-09-18 16:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:41 --> Model Class Initialized
INFO - 2016-09-18 16:33:41 --> Config Class Initialized
INFO - 2016-09-18 16:33:41 --> Input Class Initialized
INFO - 2016-09-18 16:33:41 --> Security Class Initialized
INFO - 2016-09-18 16:33:41 --> Config Class Initialized
DEBUG - 2016-09-18 16:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:41 --> Hooks Class Initialized
INFO - 2016-09-18 16:33:41 --> Model Class Initialized
DEBUG - 2016-09-18 16:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:41 --> Input Class Initialized
INFO - 2016-09-18 16:33:41 --> Hooks Class Initialized
INFO - 2016-09-18 16:33:41 --> Language Class Initialized
DEBUG - 2016-09-18 16:33:41 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:33:41 --> Utf8 Class Initialized
INFO - 2016-09-18 16:33:41 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:41 --> Input Class Initialized
INFO - 2016-09-18 16:33:41 --> Language Class Initialized
DEBUG - 2016-09-18 16:33:41 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:33:41 --> Language Class Initialized
INFO - 2016-09-18 16:33:41 --> Config Class Initialized
INFO - 2016-09-18 16:33:41 --> URI Class Initialized
INFO - 2016-09-18 16:33:41 --> Utf8 Class Initialized
INFO - 2016-09-18 16:33:41 --> Language Class Initialized
INFO - 2016-09-18 16:33:41 --> Language Class Initialized
INFO - 2016-09-18 16:33:42 --> Final output sent to browser
DEBUG - 2016-09-18 16:33:42 --> Total execution time: 2.7189
INFO - 2016-09-18 16:33:42 --> Loader Class Initialized
INFO - 2016-09-18 16:33:42 --> URI Class Initialized
INFO - 2016-09-18 16:33:42 --> Config Class Initialized
INFO - 2016-09-18 16:33:42 --> Router Class Initialized
INFO - 2016-09-18 16:33:42 --> Language Class Initialized
INFO - 2016-09-18 16:33:42 --> Router Class Initialized
INFO - 2016-09-18 16:33:42 --> Helper loaded: url_helper
INFO - 2016-09-18 16:33:42 --> Output Class Initialized
INFO - 2016-09-18 16:33:42 --> Loader Class Initialized
INFO - 2016-09-18 16:33:42 --> Config Class Initialized
INFO - 2016-09-18 16:33:42 --> Config Class Initialized
INFO - 2016-09-18 16:33:42 --> Output Class Initialized
INFO - 2016-09-18 16:33:42 --> Security Class Initialized
DEBUG - 2016-09-18 16:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:42 --> Input Class Initialized
INFO - 2016-09-18 16:33:42 --> Hooks Class Initialized
INFO - 2016-09-18 16:33:42 --> Helper loaded: url_helper
INFO - 2016-09-18 16:33:42 --> Language Class Initialized
INFO - 2016-09-18 16:33:42 --> Security Class Initialized
INFO - 2016-09-18 16:33:42 --> Loader Class Initialized
INFO - 2016-09-18 16:33:42 --> Database Driver Class Initialized
DEBUG - 2016-09-18 16:33:42 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:33:42 --> Utf8 Class Initialized
INFO - 2016-09-18 16:33:42 --> URI Class Initialized
INFO - 2016-09-18 16:33:42 --> Router Class Initialized
INFO - 2016-09-18 16:33:42 --> Language Class Initialized
INFO - 2016-09-18 16:33:42 --> Helper loaded: url_helper
INFO - 2016-09-18 16:33:42 --> Database Driver Class Initialized
DEBUG - 2016-09-18 16:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:42 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:42 --> Output Class Initialized
INFO - 2016-09-18 16:33:42 --> Input Class Initialized
INFO - 2016-09-18 16:33:42 --> Config Class Initialized
INFO - 2016-09-18 16:33:42 --> Controller Class Initialized
DEBUG - 2016-09-18 16:33:42 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:33:42 --> Model Class Initialized
INFO - 2016-09-18 16:33:42 --> Controller Class Initialized
INFO - 2016-09-18 16:33:42 --> Controller Class Initialized
INFO - 2016-09-18 16:33:42 --> Language Class Initialized
INFO - 2016-09-18 16:33:42 --> Loader Class Initialized
INFO - 2016-09-18 16:33:42 --> Security Class Initialized
DEBUG - 2016-09-18 16:33:42 --> Index MX_Controller Initialized
DEBUG - 2016-09-18 16:33:42 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:33:42 --> Model Class Initialized
INFO - 2016-09-18 16:33:42 --> Helper loaded: url_helper
DEBUG - 2016-09-18 16:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:42 --> Language Class Initialized
INFO - 2016-09-18 16:33:42 --> Model Class Initialized
INFO - 2016-09-18 16:33:42 --> Model Class Initialized
INFO - 2016-09-18 16:33:43 --> Input Class Initialized
INFO - 2016-09-18 16:33:43 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:43 --> Model Class Initialized
INFO - 2016-09-18 16:33:43 --> Config Class Initialized
INFO - 2016-09-18 16:33:43 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:43 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:43 --> Model Class Initialized
INFO - 2016-09-18 16:33:43 --> Language Class Initialized
INFO - 2016-09-18 16:33:43 --> Final output sent to browser
INFO - 2016-09-18 16:33:43 --> Final output sent to browser
INFO - 2016-09-18 16:33:43 --> Loader Class Initialized
INFO - 2016-09-18 16:33:43 --> Controller Class Initialized
DEBUG - 2016-09-18 16:33:43 --> Total execution time: 2.1338
DEBUG - 2016-09-18 16:33:43 --> Total execution time: 1.9953
DEBUG - 2016-09-18 16:33:43 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:33:43 --> Model Class Initialized
INFO - 2016-09-18 16:33:43 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:43 --> Helper loaded: url_helper
INFO - 2016-09-18 16:33:43 --> Language Class Initialized
INFO - 2016-09-18 16:33:43 --> Config Class Initialized
INFO - 2016-09-18 16:33:43 --> Config Class Initialized
INFO - 2016-09-18 16:33:43 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:43 --> Loader Class Initialized
INFO - 2016-09-18 16:33:43 --> Model Class Initialized
INFO - 2016-09-18 16:33:43 --> Hooks Class Initialized
INFO - 2016-09-18 16:33:43 --> Final output sent to browser
DEBUG - 2016-09-18 16:33:43 --> Total execution time: 2.2596
INFO - 2016-09-18 16:33:43 --> Config Class Initialized
INFO - 2016-09-18 16:33:43 --> Controller Class Initialized
INFO - 2016-09-18 16:33:43 --> Config Class Initialized
INFO - 2016-09-18 16:33:43 --> Helper loaded: url_helper
DEBUG - 2016-09-18 16:33:43 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:33:43 --> Hooks Class Initialized
INFO - 2016-09-18 16:33:43 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:33:43 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:33:43 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:43 --> Utf8 Class Initialized
INFO - 2016-09-18 16:33:43 --> Database Driver Class Initialized
DEBUG - 2016-09-18 16:33:43 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:33:43 --> URI Class Initialized
DEBUG - 2016-09-18 16:33:43 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:33:43 --> Model Class Initialized
INFO - 2016-09-18 16:33:43 --> Utf8 Class Initialized
INFO - 2016-09-18 16:33:43 --> Controller Class Initialized
INFO - 2016-09-18 16:33:43 --> Final output sent to browser
INFO - 2016-09-18 16:33:43 --> Model Class Initialized
INFO - 2016-09-18 16:33:43 --> Utf8 Class Initialized
INFO - 2016-09-18 16:33:43 --> Router Class Initialized
DEBUG - 2016-09-18 16:33:43 --> Total execution time: 1.9095
DEBUG - 2016-09-18 16:33:43 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:33:43 --> URI Class Initialized
INFO - 2016-09-18 16:33:43 --> URI Class Initialized
INFO - 2016-09-18 16:33:43 --> Output Class Initialized
INFO - 2016-09-18 16:33:43 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:43 --> Final output sent to browser
DEBUG - 2016-09-18 16:33:43 --> Total execution time: 1.9854
INFO - 2016-09-18 16:33:43 --> Config Class Initialized
INFO - 2016-09-18 16:33:43 --> Security Class Initialized
INFO - 2016-09-18 16:33:43 --> Router Class Initialized
INFO - 2016-09-18 16:33:43 --> Router Class Initialized
INFO - 2016-09-18 16:33:43 --> Model Class Initialized
INFO - 2016-09-18 16:33:43 --> Output Class Initialized
INFO - 2016-09-18 16:33:43 --> Config Class Initialized
INFO - 2016-09-18 16:33:43 --> Security Class Initialized
DEBUG - 2016-09-18 16:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:44 --> Input Class Initialized
INFO - 2016-09-18 16:33:44 --> Language Class Initialized
INFO - 2016-09-18 16:33:44 --> Language Class Initialized
INFO - 2016-09-18 16:33:44 --> Config Class Initialized
INFO - 2016-09-18 16:33:44 --> Model Class Initialized
DEBUG - 2016-09-18 16:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:44 --> Hooks Class Initialized
INFO - 2016-09-18 16:33:44 --> Hooks Class Initialized
INFO - 2016-09-18 16:33:44 --> Output Class Initialized
INFO - 2016-09-18 16:33:44 --> Loader Class Initialized
INFO - 2016-09-18 16:33:44 --> Helper loaded: url_helper
INFO - 2016-09-18 16:33:44 --> Database Driver Class Initialized
DEBUG - 2016-09-18 16:33:44 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:33:44 --> Input Class Initialized
INFO - 2016-09-18 16:33:44 --> Security Class Initialized
DEBUG - 2016-09-18 16:33:44 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:33:44 --> Controller Class Initialized
INFO - 2016-09-18 16:33:44 --> Database Driver Class Initialized
DEBUG - 2016-09-18 16:33:44 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:33:44 --> Utf8 Class Initialized
DEBUG - 2016-09-18 16:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:44 --> Final output sent to browser
INFO - 2016-09-18 16:33:44 --> Language Class Initialized
INFO - 2016-09-18 16:33:44 --> Utf8 Class Initialized
DEBUG - 2016-09-18 16:33:44 --> Total execution time: 2.2135
INFO - 2016-09-18 16:33:44 --> Model Class Initialized
INFO - 2016-09-18 16:33:44 --> Language Class Initialized
INFO - 2016-09-18 16:33:44 --> URI Class Initialized
INFO - 2016-09-18 16:33:44 --> URI Class Initialized
INFO - 2016-09-18 16:33:44 --> Input Class Initialized
INFO - 2016-09-18 16:33:44 --> Config Class Initialized
INFO - 2016-09-18 16:33:44 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:33:44 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:33:44 --> Utf8 Class Initialized
INFO - 2016-09-18 16:33:44 --> URI Class Initialized
INFO - 2016-09-18 16:33:44 --> Router Class Initialized
INFO - 2016-09-18 16:33:44 --> Output Class Initialized
INFO - 2016-09-18 16:33:44 --> Security Class Initialized
DEBUG - 2016-09-18 16:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:44 --> Input Class Initialized
INFO - 2016-09-18 16:33:44 --> Language Class Initialized
INFO - 2016-09-18 16:33:45 --> Language Class Initialized
INFO - 2016-09-18 16:33:45 --> Config Class Initialized
INFO - 2016-09-18 16:33:45 --> Model Class Initialized
INFO - 2016-09-18 16:33:45 --> Config Class Initialized
INFO - 2016-09-18 16:33:45 --> Router Class Initialized
INFO - 2016-09-18 16:33:45 --> Language Class Initialized
INFO - 2016-09-18 16:33:45 --> Router Class Initialized
INFO - 2016-09-18 16:33:45 --> Output Class Initialized
INFO - 2016-09-18 16:33:45 --> Language Class Initialized
INFO - 2016-09-18 16:33:45 --> Output Class Initialized
INFO - 2016-09-18 16:33:45 --> Loader Class Initialized
INFO - 2016-09-18 16:33:45 --> Loader Class Initialized
INFO - 2016-09-18 16:33:45 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:45 --> Security Class Initialized
DEBUG - 2016-09-18 16:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:45 --> Input Class Initialized
INFO - 2016-09-18 16:33:45 --> Final output sent to browser
DEBUG - 2016-09-18 16:33:45 --> Total execution time: 2.0004
INFO - 2016-09-18 16:33:45 --> Language Class Initialized
INFO - 2016-09-18 16:33:45 --> Config Class Initialized
INFO - 2016-09-18 16:33:45 --> Helper loaded: url_helper
INFO - 2016-09-18 16:33:45 --> Security Class Initialized
INFO - 2016-09-18 16:33:45 --> Helper loaded: url_helper
INFO - 2016-09-18 16:33:45 --> Config Class Initialized
INFO - 2016-09-18 16:33:45 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:45 --> Language Class Initialized
INFO - 2016-09-18 16:33:45 --> Loader Class Initialized
INFO - 2016-09-18 16:33:45 --> Config Class Initialized
INFO - 2016-09-18 16:33:45 --> Hooks Class Initialized
INFO - 2016-09-18 16:33:45 --> Helper loaded: url_helper
DEBUG - 2016-09-18 16:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:45 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:45 --> Input Class Initialized
INFO - 2016-09-18 16:33:45 --> Loader Class Initialized
DEBUG - 2016-09-18 16:33:45 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:33:45 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:45 --> Controller Class Initialized
INFO - 2016-09-18 16:33:45 --> Controller Class Initialized
DEBUG - 2016-09-18 16:33:45 --> Index MX_Controller Initialized
DEBUG - 2016-09-18 16:33:45 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:33:45 --> Language Class Initialized
INFO - 2016-09-18 16:33:45 --> Utf8 Class Initialized
INFO - 2016-09-18 16:33:45 --> Helper loaded: url_helper
INFO - 2016-09-18 16:33:45 --> Controller Class Initialized
DEBUG - 2016-09-18 16:33:45 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:33:45 --> Model Class Initialized
INFO - 2016-09-18 16:33:45 --> URI Class Initialized
INFO - 2016-09-18 16:33:45 --> Model Class Initialized
INFO - 2016-09-18 16:33:45 --> Language Class Initialized
INFO - 2016-09-18 16:33:45 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:45 --> Model Class Initialized
INFO - 2016-09-18 16:33:45 --> Model Class Initialized
INFO - 2016-09-18 16:33:45 --> Model Class Initialized
INFO - 2016-09-18 16:33:45 --> Router Class Initialized
INFO - 2016-09-18 16:33:45 --> Model Class Initialized
INFO - 2016-09-18 16:33:45 --> Config Class Initialized
INFO - 2016-09-18 16:33:45 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:45 --> Controller Class Initialized
DEBUG - 2016-09-18 16:33:45 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:33:45 --> Output Class Initialized
INFO - 2016-09-18 16:33:45 --> Final output sent to browser
INFO - 2016-09-18 16:33:45 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:45 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:46 --> Loader Class Initialized
INFO - 2016-09-18 16:33:46 --> Model Class Initialized
DEBUG - 2016-09-18 16:33:46 --> Total execution time: 2.5339
INFO - 2016-09-18 16:33:46 --> Final output sent to browser
INFO - 2016-09-18 16:33:46 --> Final output sent to browser
INFO - 2016-09-18 16:33:46 --> Security Class Initialized
INFO - 2016-09-18 16:33:46 --> Helper loaded: url_helper
DEBUG - 2016-09-18 16:33:46 --> Total execution time: 1.4601
INFO - 2016-09-18 16:33:46 --> Model Class Initialized
DEBUG - 2016-09-18 16:33:46 --> Total execution time: 2.8256
DEBUG - 2016-09-18 16:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:46 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:46 --> Config Class Initialized
INFO - 2016-09-18 16:33:46 --> Hooks Class Initialized
INFO - 2016-09-18 16:33:46 --> Config Class Initialized
DEBUG - 2016-09-18 16:33:46 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:33:46 --> Config Class Initialized
INFO - 2016-09-18 16:33:46 --> Input Class Initialized
INFO - 2016-09-18 16:33:46 --> Controller Class Initialized
INFO - 2016-09-18 16:33:46 --> Hooks Class Initialized
INFO - 2016-09-18 16:33:46 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:33:46 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:33:46 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:46 --> Language Class Initialized
DEBUG - 2016-09-18 16:33:46 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:33:46 --> Utf8 Class Initialized
DEBUG - 2016-09-18 16:33:46 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:33:46 --> Utf8 Class Initialized
INFO - 2016-09-18 16:33:46 --> URI Class Initialized
INFO - 2016-09-18 16:33:46 --> Final output sent to browser
INFO - 2016-09-18 16:33:46 --> Model Class Initialized
INFO - 2016-09-18 16:33:46 --> Utf8 Class Initialized
INFO - 2016-09-18 16:33:46 --> Language Class Initialized
DEBUG - 2016-09-18 16:33:46 --> Total execution time: 2.9097
INFO - 2016-09-18 16:33:46 --> URI Class Initialized
INFO - 2016-09-18 16:33:46 --> Router Class Initialized
INFO - 2016-09-18 16:33:46 --> Router Class Initialized
INFO - 2016-09-18 16:33:46 --> URI Class Initialized
INFO - 2016-09-18 16:33:46 --> Config Class Initialized
INFO - 2016-09-18 16:33:46 --> Output Class Initialized
INFO - 2016-09-18 16:33:46 --> Model Class Initialized
INFO - 2016-09-18 16:33:46 --> Config Class Initialized
INFO - 2016-09-18 16:33:46 --> Hooks Class Initialized
INFO - 2016-09-18 16:33:46 --> Output Class Initialized
INFO - 2016-09-18 16:33:46 --> Loader Class Initialized
INFO - 2016-09-18 16:33:46 --> Security Class Initialized
INFO - 2016-09-18 16:33:46 --> Router Class Initialized
INFO - 2016-09-18 16:33:46 --> Database Driver Class Initialized
DEBUG - 2016-09-18 16:33:46 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:33:46 --> Output Class Initialized
DEBUG - 2016-09-18 16:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:46 --> Helper loaded: url_helper
INFO - 2016-09-18 16:33:46 --> Security Class Initialized
INFO - 2016-09-18 16:33:46 --> Utf8 Class Initialized
INFO - 2016-09-18 16:33:46 --> Security Class Initialized
INFO - 2016-09-18 16:33:46 --> Final output sent to browser
DEBUG - 2016-09-18 16:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:46 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:46 --> Input Class Initialized
DEBUG - 2016-09-18 16:33:46 --> Total execution time: 3.0448
INFO - 2016-09-18 16:33:46 --> URI Class Initialized
INFO - 2016-09-18 16:33:47 --> Input Class Initialized
DEBUG - 2016-09-18 16:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:47 --> Language Class Initialized
INFO - 2016-09-18 16:33:47 --> Controller Class Initialized
DEBUG - 2016-09-18 16:33:47 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:33:47 --> Config Class Initialized
INFO - 2016-09-18 16:33:47 --> Input Class Initialized
INFO - 2016-09-18 16:33:47 --> Language Class Initialized
INFO - 2016-09-18 16:33:47 --> Router Class Initialized
INFO - 2016-09-18 16:33:47 --> Language Class Initialized
INFO - 2016-09-18 16:33:47 --> Hooks Class Initialized
INFO - 2016-09-18 16:33:47 --> Model Class Initialized
INFO - 2016-09-18 16:33:47 --> Output Class Initialized
INFO - 2016-09-18 16:33:47 --> Config Class Initialized
INFO - 2016-09-18 16:33:47 --> Language Class Initialized
INFO - 2016-09-18 16:33:47 --> Language Class Initialized
DEBUG - 2016-09-18 16:33:47 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:33:47 --> Utf8 Class Initialized
INFO - 2016-09-18 16:33:47 --> URI Class Initialized
INFO - 2016-09-18 16:33:47 --> Router Class Initialized
INFO - 2016-09-18 16:33:47 --> Output Class Initialized
INFO - 2016-09-18 16:33:47 --> Language Class Initialized
INFO - 2016-09-18 16:33:47 --> Loader Class Initialized
INFO - 2016-09-18 16:33:47 --> Config Class Initialized
INFO - 2016-09-18 16:33:47 --> Security Class Initialized
INFO - 2016-09-18 16:33:47 --> Model Class Initialized
INFO - 2016-09-18 16:33:47 --> Security Class Initialized
INFO - 2016-09-18 16:33:47 --> Helper loaded: url_helper
INFO - 2016-09-18 16:33:47 --> Config Class Initialized
DEBUG - 2016-09-18 16:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:47 --> Loader Class Initialized
INFO - 2016-09-18 16:33:47 --> Database Driver Class Initialized
DEBUG - 2016-09-18 16:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:47 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:47 --> Input Class Initialized
INFO - 2016-09-18 16:33:47 --> Loader Class Initialized
INFO - 2016-09-18 16:33:47 --> Helper loaded: url_helper
INFO - 2016-09-18 16:33:47 --> Input Class Initialized
INFO - 2016-09-18 16:33:47 --> Language Class Initialized
INFO - 2016-09-18 16:33:47 --> Final output sent to browser
DEBUG - 2016-09-18 16:33:47 --> Total execution time: 2.1022
INFO - 2016-09-18 16:33:47 --> Language Class Initialized
INFO - 2016-09-18 16:33:47 --> Helper loaded: url_helper
INFO - 2016-09-18 16:33:47 --> Language Class Initialized
INFO - 2016-09-18 16:33:47 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:47 --> Config Class Initialized
INFO - 2016-09-18 16:33:47 --> Controller Class Initialized
INFO - 2016-09-18 16:33:47 --> Language Class Initialized
INFO - 2016-09-18 16:33:47 --> Config Class Initialized
INFO - 2016-09-18 16:33:47 --> Database Driver Class Initialized
DEBUG - 2016-09-18 16:33:47 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:33:47 --> Hooks Class Initialized
INFO - 2016-09-18 16:33:47 --> Controller Class Initialized
INFO - 2016-09-18 16:33:47 --> Loader Class Initialized
INFO - 2016-09-18 16:33:48 --> Config Class Initialized
INFO - 2016-09-18 16:33:48 --> Controller Class Initialized
DEBUG - 2016-09-18 16:33:48 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:33:48 --> Model Class Initialized
INFO - 2016-09-18 16:33:48 --> Loader Class Initialized
INFO - 2016-09-18 16:33:48 --> Helper loaded: url_helper
DEBUG - 2016-09-18 16:33:48 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:33:48 --> Model Class Initialized
INFO - 2016-09-18 16:33:48 --> Model Class Initialized
INFO - 2016-09-18 16:33:48 --> Database Driver Class Initialized
DEBUG - 2016-09-18 16:33:48 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:33:48 --> Model Class Initialized
INFO - 2016-09-18 16:33:48 --> Final output sent to browser
DEBUG - 2016-09-18 16:33:48 --> Total execution time: 2.1860
INFO - 2016-09-18 16:33:48 --> Model Class Initialized
INFO - 2016-09-18 16:33:48 --> Model Class Initialized
INFO - 2016-09-18 16:33:48 --> Helper loaded: url_helper
INFO - 2016-09-18 16:33:48 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:48 --> Utf8 Class Initialized
INFO - 2016-09-18 16:33:48 --> Config Class Initialized
INFO - 2016-09-18 16:33:48 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:33:48 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:33:48 --> Utf8 Class Initialized
INFO - 2016-09-18 16:33:48 --> URI Class Initialized
INFO - 2016-09-18 16:33:48 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:48 --> Router Class Initialized
INFO - 2016-09-18 16:33:48 --> Final output sent to browser
DEBUG - 2016-09-18 16:33:48 --> Total execution time: 2.6446
INFO - 2016-09-18 16:33:48 --> Output Class Initialized
INFO - 2016-09-18 16:33:48 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:48 --> Controller Class Initialized
INFO - 2016-09-18 16:33:48 --> URI Class Initialized
INFO - 2016-09-18 16:33:48 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:49 --> Config Class Initialized
INFO - 2016-09-18 16:33:49 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:33:49 --> UTF-8 Support Enabled
DEBUG - 2016-09-18 16:33:49 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:33:49 --> Router Class Initialized
INFO - 2016-09-18 16:33:49 --> Security Class Initialized
INFO - 2016-09-18 16:33:49 --> Controller Class Initialized
INFO - 2016-09-18 16:33:49 --> Final output sent to browser
DEBUG - 2016-09-18 16:33:49 --> Total execution time: 2.7972
DEBUG - 2016-09-18 16:33:49 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:33:49 --> Utf8 Class Initialized
DEBUG - 2016-09-18 16:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:49 --> Output Class Initialized
INFO - 2016-09-18 16:33:49 --> Model Class Initialized
INFO - 2016-09-18 16:33:49 --> Config Class Initialized
INFO - 2016-09-18 16:33:49 --> Model Class Initialized
INFO - 2016-09-18 16:33:49 --> Model Class Initialized
INFO - 2016-09-18 16:33:49 --> Security Class Initialized
INFO - 2016-09-18 16:33:49 --> Input Class Initialized
INFO - 2016-09-18 16:33:49 --> URI Class Initialized
INFO - 2016-09-18 16:33:49 --> Hooks Class Initialized
INFO - 2016-09-18 16:33:49 --> Model Class Initialized
DEBUG - 2016-09-18 16:33:49 --> UTF-8 Support Enabled
DEBUG - 2016-09-18 16:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:49 --> Router Class Initialized
INFO - 2016-09-18 16:33:49 --> Language Class Initialized
INFO - 2016-09-18 16:33:49 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:49 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:49 --> Input Class Initialized
INFO - 2016-09-18 16:33:49 --> Utf8 Class Initialized
INFO - 2016-09-18 16:33:49 --> Output Class Initialized
INFO - 2016-09-18 16:33:49 --> Language Class Initialized
INFO - 2016-09-18 16:33:49 --> Security Class Initialized
INFO - 2016-09-18 16:33:49 --> Config Class Initialized
INFO - 2016-09-18 16:33:49 --> Language Class Initialized
INFO - 2016-09-18 16:33:49 --> URI Class Initialized
INFO - 2016-09-18 16:33:49 --> Final output sent to browser
INFO - 2016-09-18 16:33:49 --> Final output sent to browser
DEBUG - 2016-09-18 16:33:49 --> Total execution time: 2.7785
DEBUG - 2016-09-18 16:33:49 --> Total execution time: 2.4778
DEBUG - 2016-09-18 16:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:49 --> Language Class Initialized
INFO - 2016-09-18 16:33:49 --> Router Class Initialized
INFO - 2016-09-18 16:33:49 --> Loader Class Initialized
INFO - 2016-09-18 16:33:49 --> Config Class Initialized
INFO - 2016-09-18 16:33:49 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:33:49 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:33:49 --> Utf8 Class Initialized
INFO - 2016-09-18 16:33:50 --> URI Class Initialized
INFO - 2016-09-18 16:33:50 --> Router Class Initialized
INFO - 2016-09-18 16:33:50 --> Helper loaded: url_helper
INFO - 2016-09-18 16:33:50 --> Output Class Initialized
INFO - 2016-09-18 16:33:50 --> Output Class Initialized
INFO - 2016-09-18 16:33:50 --> Config Class Initialized
INFO - 2016-09-18 16:33:50 --> Input Class Initialized
INFO - 2016-09-18 16:33:50 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:50 --> Security Class Initialized
INFO - 2016-09-18 16:33:50 --> Security Class Initialized
INFO - 2016-09-18 16:33:50 --> Language Class Initialized
INFO - 2016-09-18 16:33:50 --> Controller Class Initialized
DEBUG - 2016-09-18 16:33:50 --> Index MX_Controller Initialized
DEBUG - 2016-09-18 16:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-18 16:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:33:50 --> Loader Class Initialized
INFO - 2016-09-18 16:33:50 --> Language Class Initialized
INFO - 2016-09-18 16:33:50 --> Model Class Initialized
INFO - 2016-09-18 16:33:50 --> Helper loaded: url_helper
INFO - 2016-09-18 16:33:50 --> Input Class Initialized
INFO - 2016-09-18 16:33:50 --> Config Class Initialized
INFO - 2016-09-18 16:33:50 --> Input Class Initialized
INFO - 2016-09-18 16:33:50 --> Model Class Initialized
INFO - 2016-09-18 16:33:50 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:50 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:50 --> Controller Class Initialized
INFO - 2016-09-18 16:33:50 --> Final output sent to browser
INFO - 2016-09-18 16:33:50 --> Language Class Initialized
INFO - 2016-09-18 16:33:50 --> Loader Class Initialized
INFO - 2016-09-18 16:33:50 --> Language Class Initialized
DEBUG - 2016-09-18 16:33:50 --> Total execution time: 2.0037
DEBUG - 2016-09-18 16:33:50 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:33:50 --> Language Class Initialized
INFO - 2016-09-18 16:33:50 --> Language Class Initialized
INFO - 2016-09-18 16:33:50 --> Helper loaded: url_helper
INFO - 2016-09-18 16:33:50 --> Config Class Initialized
INFO - 2016-09-18 16:33:50 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:50 --> Config Class Initialized
INFO - 2016-09-18 16:33:50 --> Model Class Initialized
INFO - 2016-09-18 16:33:50 --> Loader Class Initialized
INFO - 2016-09-18 16:33:50 --> Helper loaded: url_helper
INFO - 2016-09-18 16:33:50 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:50 --> Loader Class Initialized
INFO - 2016-09-18 16:33:50 --> Model Class Initialized
INFO - 2016-09-18 16:33:50 --> Controller Class Initialized
DEBUG - 2016-09-18 16:33:50 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:33:50 --> Controller Class Initialized
DEBUG - 2016-09-18 16:33:50 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:33:50 --> Model Class Initialized
INFO - 2016-09-18 16:33:50 --> Model Class Initialized
INFO - 2016-09-18 16:33:50 --> Helper loaded: url_helper
INFO - 2016-09-18 16:33:50 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:50 --> Model Class Initialized
INFO - 2016-09-18 16:33:50 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:50 --> Model Class Initialized
INFO - 2016-09-18 16:33:50 --> Final output sent to browser
DEBUG - 2016-09-18 16:33:50 --> Total execution time: 3.0835
INFO - 2016-09-18 16:33:50 --> Controller Class Initialized
INFO - 2016-09-18 16:33:50 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:50 --> Final output sent to browser
DEBUG - 2016-09-18 16:33:50 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:33:50 --> Database Driver Class Initialized
DEBUG - 2016-09-18 16:33:51 --> Total execution time: 1.7221
INFO - 2016-09-18 16:33:51 --> Final output sent to browser
DEBUG - 2016-09-18 16:33:51 --> Total execution time: 2.0610
INFO - 2016-09-18 16:33:51 --> Model Class Initialized
INFO - 2016-09-18 16:33:51 --> Model Class Initialized
INFO - 2016-09-18 16:33:51 --> Database Driver Class Initialized
INFO - 2016-09-18 16:33:51 --> Final output sent to browser
DEBUG - 2016-09-18 16:33:51 --> Total execution time: 1.6516
INFO - 2016-09-18 16:45:46 --> Config Class Initialized
INFO - 2016-09-18 16:45:46 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:45:46 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:45:46 --> Utf8 Class Initialized
INFO - 2016-09-18 16:45:46 --> URI Class Initialized
INFO - 2016-09-18 16:45:46 --> Router Class Initialized
INFO - 2016-09-18 16:45:46 --> Output Class Initialized
INFO - 2016-09-18 16:45:46 --> Security Class Initialized
DEBUG - 2016-09-18 16:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:45:46 --> Input Class Initialized
INFO - 2016-09-18 16:45:46 --> Language Class Initialized
INFO - 2016-09-18 16:45:46 --> Language Class Initialized
INFO - 2016-09-18 16:45:46 --> Config Class Initialized
INFO - 2016-09-18 16:45:46 --> Loader Class Initialized
INFO - 2016-09-18 16:45:46 --> Helper loaded: url_helper
INFO - 2016-09-18 16:45:47 --> Database Driver Class Initialized
INFO - 2016-09-18 16:45:47 --> Controller Class Initialized
DEBUG - 2016-09-18 16:45:47 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:45:47 --> Model Class Initialized
INFO - 2016-09-18 16:45:47 --> Model Class Initialized
ERROR - 2016-09-18 16:45:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '.kd_anggota
                                                        WHERE tm_an' at line 2 - Invalid query: SELECT * FROM tm_tabungan
                                                        INNER JOIN tm_anggota.kd_anggota = tm_tabungan.kd_anggota
                                                        WHERE tm_anggota.no_identitas = '1'
INFO - 2016-09-18 16:45:47 --> Language file loaded: language/english/db_lang.php
INFO - 2016-09-18 16:46:14 --> Config Class Initialized
INFO - 2016-09-18 16:46:14 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:46:14 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:46:14 --> Utf8 Class Initialized
INFO - 2016-09-18 16:46:14 --> URI Class Initialized
INFO - 2016-09-18 16:46:14 --> Router Class Initialized
INFO - 2016-09-18 16:46:14 --> Output Class Initialized
INFO - 2016-09-18 16:46:14 --> Security Class Initialized
DEBUG - 2016-09-18 16:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:46:14 --> Input Class Initialized
INFO - 2016-09-18 16:46:14 --> Language Class Initialized
INFO - 2016-09-18 16:46:14 --> Language Class Initialized
INFO - 2016-09-18 16:46:14 --> Config Class Initialized
INFO - 2016-09-18 16:46:14 --> Loader Class Initialized
INFO - 2016-09-18 16:46:14 --> Helper loaded: url_helper
INFO - 2016-09-18 16:46:14 --> Database Driver Class Initialized
INFO - 2016-09-18 16:46:14 --> Controller Class Initialized
DEBUG - 2016-09-18 16:46:14 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:46:14 --> Model Class Initialized
INFO - 2016-09-18 16:46:14 --> Model Class Initialized
INFO - 2016-09-18 16:46:14 --> Final output sent to browser
DEBUG - 2016-09-18 16:46:14 --> Total execution time: 0.6358
INFO - 2016-09-18 16:46:30 --> Config Class Initialized
INFO - 2016-09-18 16:46:30 --> Hooks Class Initialized
DEBUG - 2016-09-18 16:46:30 --> UTF-8 Support Enabled
INFO - 2016-09-18 16:46:30 --> Utf8 Class Initialized
INFO - 2016-09-18 16:46:30 --> URI Class Initialized
INFO - 2016-09-18 16:46:30 --> Router Class Initialized
INFO - 2016-09-18 16:46:30 --> Output Class Initialized
INFO - 2016-09-18 16:46:30 --> Security Class Initialized
DEBUG - 2016-09-18 16:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 16:46:30 --> Input Class Initialized
INFO - 2016-09-18 16:46:30 --> Language Class Initialized
INFO - 2016-09-18 16:46:30 --> Language Class Initialized
INFO - 2016-09-18 16:46:30 --> Config Class Initialized
INFO - 2016-09-18 16:46:30 --> Loader Class Initialized
INFO - 2016-09-18 16:46:30 --> Helper loaded: url_helper
INFO - 2016-09-18 16:46:30 --> Database Driver Class Initialized
INFO - 2016-09-18 16:46:30 --> Controller Class Initialized
DEBUG - 2016-09-18 16:46:30 --> Index MX_Controller Initialized
INFO - 2016-09-18 16:46:30 --> Model Class Initialized
INFO - 2016-09-18 16:46:30 --> Model Class Initialized
INFO - 2016-09-18 16:46:31 --> Final output sent to browser
DEBUG - 2016-09-18 16:46:31 --> Total execution time: 0.6208
INFO - 2016-09-18 17:06:27 --> Config Class Initialized
INFO - 2016-09-18 17:06:27 --> Hooks Class Initialized
DEBUG - 2016-09-18 17:06:28 --> UTF-8 Support Enabled
INFO - 2016-09-18 17:06:28 --> Utf8 Class Initialized
INFO - 2016-09-18 17:06:28 --> URI Class Initialized
INFO - 2016-09-18 17:06:28 --> Router Class Initialized
INFO - 2016-09-18 17:06:28 --> Output Class Initialized
INFO - 2016-09-18 17:06:28 --> Security Class Initialized
DEBUG - 2016-09-18 17:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 17:06:28 --> Input Class Initialized
INFO - 2016-09-18 17:06:28 --> Language Class Initialized
INFO - 2016-09-18 17:06:28 --> Language Class Initialized
INFO - 2016-09-18 17:06:28 --> Config Class Initialized
INFO - 2016-09-18 17:06:28 --> Loader Class Initialized
INFO - 2016-09-18 17:06:28 --> Helper loaded: url_helper
INFO - 2016-09-18 17:06:28 --> Database Driver Class Initialized
INFO - 2016-09-18 17:06:28 --> Controller Class Initialized
DEBUG - 2016-09-18 17:06:28 --> Index MX_Controller Initialized
INFO - 2016-09-18 17:06:28 --> Model Class Initialized
INFO - 2016-09-18 17:06:28 --> Model Class Initialized
DEBUG - 2016-09-18 17:06:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 17:06:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 17:06:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 17:06:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tabungan.php
DEBUG - 2016-09-18 17:06:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 17:06:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 17:06:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 17:06:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 17:06:28 --> Final output sent to browser
DEBUG - 2016-09-18 17:06:28 --> Total execution time: 0.8346
INFO - 2016-09-18 17:06:33 --> Config Class Initialized
INFO - 2016-09-18 17:06:33 --> Hooks Class Initialized
DEBUG - 2016-09-18 17:06:33 --> UTF-8 Support Enabled
INFO - 2016-09-18 17:06:33 --> Utf8 Class Initialized
INFO - 2016-09-18 17:06:33 --> URI Class Initialized
INFO - 2016-09-18 17:06:33 --> Router Class Initialized
INFO - 2016-09-18 17:06:33 --> Output Class Initialized
INFO - 2016-09-18 17:06:33 --> Security Class Initialized
DEBUG - 2016-09-18 17:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 17:06:34 --> Input Class Initialized
INFO - 2016-09-18 17:06:34 --> Language Class Initialized
ERROR - 2016-09-18 17:06:34 --> 404 Page Not Found: /index
INFO - 2016-09-18 17:06:54 --> Config Class Initialized
INFO - 2016-09-18 17:06:54 --> Hooks Class Initialized
DEBUG - 2016-09-18 17:06:54 --> UTF-8 Support Enabled
INFO - 2016-09-18 17:06:54 --> Utf8 Class Initialized
INFO - 2016-09-18 17:06:54 --> URI Class Initialized
INFO - 2016-09-18 17:06:55 --> Router Class Initialized
INFO - 2016-09-18 17:06:55 --> Output Class Initialized
INFO - 2016-09-18 17:06:55 --> Security Class Initialized
DEBUG - 2016-09-18 17:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 17:06:55 --> Input Class Initialized
INFO - 2016-09-18 17:06:55 --> Language Class Initialized
INFO - 2016-09-18 17:06:55 --> Language Class Initialized
INFO - 2016-09-18 17:06:55 --> Config Class Initialized
INFO - 2016-09-18 17:06:55 --> Loader Class Initialized
INFO - 2016-09-18 17:06:55 --> Helper loaded: url_helper
INFO - 2016-09-18 17:06:55 --> Database Driver Class Initialized
INFO - 2016-09-18 17:06:55 --> Controller Class Initialized
DEBUG - 2016-09-18 17:06:55 --> Index MX_Controller Initialized
INFO - 2016-09-18 17:06:55 --> Model Class Initialized
INFO - 2016-09-18 17:06:55 --> Model Class Initialized
DEBUG - 2016-09-18 17:06:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 17:06:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 17:06:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 17:06:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tabungan.php
DEBUG - 2016-09-18 17:06:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 17:06:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 17:06:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 17:06:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 17:06:55 --> Final output sent to browser
DEBUG - 2016-09-18 17:06:55 --> Total execution time: 0.9461
INFO - 2016-09-18 17:06:59 --> Config Class Initialized
INFO - 2016-09-18 17:06:59 --> Hooks Class Initialized
DEBUG - 2016-09-18 17:06:59 --> UTF-8 Support Enabled
INFO - 2016-09-18 17:06:59 --> Utf8 Class Initialized
INFO - 2016-09-18 17:06:59 --> URI Class Initialized
INFO - 2016-09-18 17:06:59 --> Router Class Initialized
INFO - 2016-09-18 17:06:59 --> Output Class Initialized
INFO - 2016-09-18 17:06:59 --> Security Class Initialized
DEBUG - 2016-09-18 17:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 17:06:59 --> Input Class Initialized
INFO - 2016-09-18 17:06:59 --> Language Class Initialized
ERROR - 2016-09-18 17:07:00 --> 404 Page Not Found: /index
INFO - 2016-09-18 17:07:08 --> Config Class Initialized
INFO - 2016-09-18 17:07:08 --> Hooks Class Initialized
DEBUG - 2016-09-18 17:07:08 --> UTF-8 Support Enabled
INFO - 2016-09-18 17:07:08 --> Utf8 Class Initialized
INFO - 2016-09-18 17:07:08 --> URI Class Initialized
INFO - 2016-09-18 17:07:08 --> Router Class Initialized
INFO - 2016-09-18 17:07:08 --> Output Class Initialized
INFO - 2016-09-18 17:07:08 --> Security Class Initialized
DEBUG - 2016-09-18 17:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 17:07:08 --> Input Class Initialized
INFO - 2016-09-18 17:07:08 --> Language Class Initialized
ERROR - 2016-09-18 17:07:08 --> 404 Page Not Found: /index
INFO - 2016-09-18 17:07:41 --> Config Class Initialized
INFO - 2016-09-18 17:07:41 --> Hooks Class Initialized
DEBUG - 2016-09-18 17:07:41 --> UTF-8 Support Enabled
INFO - 2016-09-18 17:07:41 --> Utf8 Class Initialized
INFO - 2016-09-18 17:07:41 --> URI Class Initialized
INFO - 2016-09-18 17:07:41 --> Router Class Initialized
INFO - 2016-09-18 17:07:41 --> Output Class Initialized
INFO - 2016-09-18 17:07:41 --> Security Class Initialized
DEBUG - 2016-09-18 17:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 17:07:41 --> Input Class Initialized
INFO - 2016-09-18 17:07:41 --> Language Class Initialized
INFO - 2016-09-18 17:07:41 --> Language Class Initialized
INFO - 2016-09-18 17:07:41 --> Config Class Initialized
INFO - 2016-09-18 17:07:41 --> Loader Class Initialized
INFO - 2016-09-18 17:07:41 --> Helper loaded: url_helper
INFO - 2016-09-18 17:07:41 --> Database Driver Class Initialized
INFO - 2016-09-18 17:07:41 --> Controller Class Initialized
DEBUG - 2016-09-18 17:07:41 --> Index MX_Controller Initialized
INFO - 2016-09-18 17:07:41 --> Model Class Initialized
INFO - 2016-09-18 17:07:41 --> Model Class Initialized
DEBUG - 2016-09-18 17:07:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 17:07:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 17:07:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 17:07:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tabungan.php
DEBUG - 2016-09-18 17:07:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 17:07:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 17:07:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 17:07:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 17:07:42 --> Final output sent to browser
DEBUG - 2016-09-18 17:07:42 --> Total execution time: 0.9697
INFO - 2016-09-18 17:08:01 --> Config Class Initialized
INFO - 2016-09-18 17:08:01 --> Hooks Class Initialized
DEBUG - 2016-09-18 17:08:01 --> UTF-8 Support Enabled
INFO - 2016-09-18 17:08:01 --> Utf8 Class Initialized
INFO - 2016-09-18 17:08:01 --> URI Class Initialized
INFO - 2016-09-18 17:08:01 --> Router Class Initialized
INFO - 2016-09-18 17:08:01 --> Output Class Initialized
INFO - 2016-09-18 17:08:01 --> Security Class Initialized
DEBUG - 2016-09-18 17:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 17:08:01 --> Input Class Initialized
INFO - 2016-09-18 17:08:01 --> Language Class Initialized
INFO - 2016-09-18 17:08:01 --> Language Class Initialized
INFO - 2016-09-18 17:08:01 --> Config Class Initialized
INFO - 2016-09-18 17:08:01 --> Loader Class Initialized
INFO - 2016-09-18 17:08:01 --> Helper loaded: url_helper
INFO - 2016-09-18 17:08:01 --> Database Driver Class Initialized
INFO - 2016-09-18 17:08:01 --> Controller Class Initialized
DEBUG - 2016-09-18 17:08:02 --> Index MX_Controller Initialized
INFO - 2016-09-18 17:08:02 --> Model Class Initialized
INFO - 2016-09-18 17:08:02 --> Model Class Initialized
INFO - 2016-09-18 17:08:02 --> Database Driver Class Initialized
INFO - 2016-09-18 17:08:02 --> Final output sent to browser
DEBUG - 2016-09-18 17:08:02 --> Total execution time: 0.7887
INFO - 2016-09-18 17:08:40 --> Config Class Initialized
INFO - 2016-09-18 17:08:40 --> Hooks Class Initialized
DEBUG - 2016-09-18 17:08:40 --> UTF-8 Support Enabled
INFO - 2016-09-18 17:08:40 --> Utf8 Class Initialized
INFO - 2016-09-18 17:08:40 --> URI Class Initialized
INFO - 2016-09-18 17:08:40 --> Router Class Initialized
INFO - 2016-09-18 17:08:40 --> Output Class Initialized
INFO - 2016-09-18 17:08:40 --> Security Class Initialized
DEBUG - 2016-09-18 17:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 17:08:40 --> Input Class Initialized
INFO - 2016-09-18 17:08:40 --> Language Class Initialized
INFO - 2016-09-18 17:08:40 --> Language Class Initialized
INFO - 2016-09-18 17:08:40 --> Config Class Initialized
INFO - 2016-09-18 17:08:40 --> Loader Class Initialized
INFO - 2016-09-18 17:08:40 --> Helper loaded: url_helper
INFO - 2016-09-18 17:08:40 --> Database Driver Class Initialized
INFO - 2016-09-18 17:08:40 --> Controller Class Initialized
DEBUG - 2016-09-18 17:08:40 --> Index MX_Controller Initialized
INFO - 2016-09-18 17:08:40 --> Model Class Initialized
INFO - 2016-09-18 17:08:40 --> Model Class Initialized
DEBUG - 2016-09-18 17:08:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 17:08:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 17:08:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 17:08:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tabungan.php
DEBUG - 2016-09-18 17:08:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 17:08:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 17:08:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 17:08:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 17:08:40 --> Final output sent to browser
DEBUG - 2016-09-18 17:08:41 --> Total execution time: 0.9298
INFO - 2016-09-18 17:08:54 --> Config Class Initialized
INFO - 2016-09-18 17:08:54 --> Hooks Class Initialized
DEBUG - 2016-09-18 17:08:54 --> UTF-8 Support Enabled
INFO - 2016-09-18 17:08:54 --> Utf8 Class Initialized
INFO - 2016-09-18 17:08:54 --> URI Class Initialized
INFO - 2016-09-18 17:08:54 --> Router Class Initialized
INFO - 2016-09-18 17:08:54 --> Output Class Initialized
INFO - 2016-09-18 17:08:54 --> Security Class Initialized
DEBUG - 2016-09-18 17:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 17:08:54 --> Input Class Initialized
INFO - 2016-09-18 17:08:54 --> Language Class Initialized
INFO - 2016-09-18 17:08:54 --> Language Class Initialized
INFO - 2016-09-18 17:08:54 --> Config Class Initialized
INFO - 2016-09-18 17:08:54 --> Loader Class Initialized
INFO - 2016-09-18 17:08:54 --> Helper loaded: url_helper
INFO - 2016-09-18 17:08:54 --> Database Driver Class Initialized
INFO - 2016-09-18 17:08:54 --> Controller Class Initialized
DEBUG - 2016-09-18 17:08:55 --> Index MX_Controller Initialized
INFO - 2016-09-18 17:08:55 --> Model Class Initialized
INFO - 2016-09-18 17:08:55 --> Model Class Initialized
INFO - 2016-09-18 17:08:55 --> Database Driver Class Initialized
INFO - 2016-09-18 17:08:55 --> Final output sent to browser
DEBUG - 2016-09-18 17:08:55 --> Total execution time: 0.6240
INFO - 2016-09-18 17:09:09 --> Config Class Initialized
INFO - 2016-09-18 17:09:09 --> Hooks Class Initialized
DEBUG - 2016-09-18 17:09:09 --> UTF-8 Support Enabled
INFO - 2016-09-18 17:09:10 --> Utf8 Class Initialized
INFO - 2016-09-18 17:09:10 --> URI Class Initialized
INFO - 2016-09-18 17:09:10 --> Router Class Initialized
INFO - 2016-09-18 17:09:10 --> Output Class Initialized
INFO - 2016-09-18 17:09:10 --> Security Class Initialized
DEBUG - 2016-09-18 17:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 17:09:10 --> Input Class Initialized
INFO - 2016-09-18 17:09:10 --> Language Class Initialized
INFO - 2016-09-18 17:09:10 --> Language Class Initialized
INFO - 2016-09-18 17:09:10 --> Config Class Initialized
INFO - 2016-09-18 17:09:10 --> Loader Class Initialized
INFO - 2016-09-18 17:09:10 --> Helper loaded: url_helper
INFO - 2016-09-18 17:09:10 --> Database Driver Class Initialized
INFO - 2016-09-18 17:09:10 --> Controller Class Initialized
DEBUG - 2016-09-18 17:09:10 --> Index MX_Controller Initialized
INFO - 2016-09-18 17:09:10 --> Model Class Initialized
INFO - 2016-09-18 17:09:10 --> Model Class Initialized
INFO - 2016-09-18 17:09:10 --> Database Driver Class Initialized
INFO - 2016-09-18 17:09:10 --> Final output sent to browser
DEBUG - 2016-09-18 17:09:10 --> Total execution time: 0.6414
INFO - 2016-09-18 17:09:31 --> Config Class Initialized
INFO - 2016-09-18 17:09:31 --> Hooks Class Initialized
DEBUG - 2016-09-18 17:09:31 --> UTF-8 Support Enabled
INFO - 2016-09-18 17:09:31 --> Utf8 Class Initialized
INFO - 2016-09-18 17:09:31 --> URI Class Initialized
INFO - 2016-09-18 17:09:31 --> Router Class Initialized
INFO - 2016-09-18 17:09:31 --> Output Class Initialized
INFO - 2016-09-18 17:09:31 --> Security Class Initialized
DEBUG - 2016-09-18 17:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 17:09:31 --> Input Class Initialized
INFO - 2016-09-18 17:09:31 --> Language Class Initialized
INFO - 2016-09-18 17:09:31 --> Language Class Initialized
INFO - 2016-09-18 17:09:31 --> Config Class Initialized
INFO - 2016-09-18 17:09:31 --> Loader Class Initialized
INFO - 2016-09-18 17:09:31 --> Helper loaded: url_helper
INFO - 2016-09-18 17:09:31 --> Database Driver Class Initialized
INFO - 2016-09-18 17:09:31 --> Controller Class Initialized
DEBUG - 2016-09-18 17:09:31 --> Index MX_Controller Initialized
INFO - 2016-09-18 17:09:31 --> Model Class Initialized
INFO - 2016-09-18 17:09:32 --> Model Class Initialized
INFO - 2016-09-18 17:09:32 --> Database Driver Class Initialized
INFO - 2016-09-18 17:09:32 --> Final output sent to browser
DEBUG - 2016-09-18 17:09:32 --> Total execution time: 0.5719
INFO - 2016-09-18 17:09:36 --> Config Class Initialized
INFO - 2016-09-18 17:09:36 --> Hooks Class Initialized
DEBUG - 2016-09-18 17:09:36 --> UTF-8 Support Enabled
INFO - 2016-09-18 17:09:36 --> Utf8 Class Initialized
INFO - 2016-09-18 17:09:36 --> URI Class Initialized
INFO - 2016-09-18 17:09:36 --> Router Class Initialized
INFO - 2016-09-18 17:09:36 --> Output Class Initialized
INFO - 2016-09-18 17:09:36 --> Security Class Initialized
DEBUG - 2016-09-18 17:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 17:09:36 --> Input Class Initialized
INFO - 2016-09-18 17:09:36 --> Language Class Initialized
INFO - 2016-09-18 17:09:36 --> Language Class Initialized
INFO - 2016-09-18 17:09:36 --> Config Class Initialized
INFO - 2016-09-18 17:09:36 --> Loader Class Initialized
INFO - 2016-09-18 17:09:36 --> Helper loaded: url_helper
INFO - 2016-09-18 17:09:36 --> Database Driver Class Initialized
INFO - 2016-09-18 17:09:36 --> Controller Class Initialized
DEBUG - 2016-09-18 17:09:36 --> Index MX_Controller Initialized
INFO - 2016-09-18 17:09:36 --> Model Class Initialized
INFO - 2016-09-18 17:09:36 --> Model Class Initialized
INFO - 2016-09-18 17:09:36 --> Database Driver Class Initialized
INFO - 2016-09-18 17:09:36 --> Final output sent to browser
DEBUG - 2016-09-18 17:09:36 --> Total execution time: 0.6019
INFO - 2016-09-18 17:09:41 --> Config Class Initialized
INFO - 2016-09-18 17:09:41 --> Hooks Class Initialized
DEBUG - 2016-09-18 17:09:41 --> UTF-8 Support Enabled
INFO - 2016-09-18 17:09:41 --> Utf8 Class Initialized
INFO - 2016-09-18 17:09:41 --> URI Class Initialized
INFO - 2016-09-18 17:09:41 --> Router Class Initialized
INFO - 2016-09-18 17:09:41 --> Output Class Initialized
INFO - 2016-09-18 17:09:41 --> Security Class Initialized
DEBUG - 2016-09-18 17:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 17:09:41 --> Input Class Initialized
INFO - 2016-09-18 17:09:41 --> Language Class Initialized
INFO - 2016-09-18 17:09:41 --> Language Class Initialized
INFO - 2016-09-18 17:09:41 --> Config Class Initialized
INFO - 2016-09-18 17:09:41 --> Loader Class Initialized
INFO - 2016-09-18 17:09:41 --> Helper loaded: url_helper
INFO - 2016-09-18 17:09:41 --> Database Driver Class Initialized
INFO - 2016-09-18 17:09:41 --> Controller Class Initialized
DEBUG - 2016-09-18 17:09:41 --> Index MX_Controller Initialized
INFO - 2016-09-18 17:09:41 --> Model Class Initialized
INFO - 2016-09-18 17:09:41 --> Model Class Initialized
INFO - 2016-09-18 17:09:41 --> Database Driver Class Initialized
INFO - 2016-09-18 17:09:41 --> Final output sent to browser
DEBUG - 2016-09-18 17:09:41 --> Total execution time: 0.5808
INFO - 2016-09-18 17:48:21 --> Config Class Initialized
INFO - 2016-09-18 17:48:21 --> Hooks Class Initialized
DEBUG - 2016-09-18 17:48:21 --> UTF-8 Support Enabled
INFO - 2016-09-18 17:48:21 --> Utf8 Class Initialized
INFO - 2016-09-18 17:48:21 --> URI Class Initialized
INFO - 2016-09-18 17:48:21 --> Router Class Initialized
INFO - 2016-09-18 17:48:21 --> Output Class Initialized
INFO - 2016-09-18 17:48:21 --> Security Class Initialized
DEBUG - 2016-09-18 17:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 17:48:21 --> Input Class Initialized
INFO - 2016-09-18 17:48:21 --> Language Class Initialized
INFO - 2016-09-18 17:48:21 --> Language Class Initialized
INFO - 2016-09-18 17:48:21 --> Config Class Initialized
INFO - 2016-09-18 17:48:21 --> Loader Class Initialized
INFO - 2016-09-18 17:48:21 --> Helper loaded: url_helper
INFO - 2016-09-18 17:48:21 --> Database Driver Class Initialized
INFO - 2016-09-18 17:48:21 --> Controller Class Initialized
DEBUG - 2016-09-18 17:48:21 --> Index MX_Controller Initialized
INFO - 2016-09-18 17:48:21 --> Model Class Initialized
INFO - 2016-09-18 17:48:21 --> Model Class Initialized
DEBUG - 2016-09-18 17:48:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 17:48:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 17:48:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 17:48:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tabungan.php
DEBUG - 2016-09-18 17:48:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 17:48:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 17:48:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 17:48:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 17:48:22 --> Final output sent to browser
DEBUG - 2016-09-18 17:48:22 --> Total execution time: 0.9620
INFO - 2016-09-18 17:48:27 --> Config Class Initialized
INFO - 2016-09-18 17:48:27 --> Hooks Class Initialized
DEBUG - 2016-09-18 17:48:27 --> UTF-8 Support Enabled
INFO - 2016-09-18 17:48:27 --> Utf8 Class Initialized
INFO - 2016-09-18 17:48:27 --> URI Class Initialized
INFO - 2016-09-18 17:48:27 --> Router Class Initialized
INFO - 2016-09-18 17:48:27 --> Output Class Initialized
INFO - 2016-09-18 17:48:27 --> Security Class Initialized
DEBUG - 2016-09-18 17:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 17:48:27 --> Input Class Initialized
INFO - 2016-09-18 17:48:27 --> Language Class Initialized
INFO - 2016-09-18 17:48:27 --> Language Class Initialized
INFO - 2016-09-18 17:48:27 --> Config Class Initialized
INFO - 2016-09-18 17:48:27 --> Loader Class Initialized
INFO - 2016-09-18 17:48:27 --> Helper loaded: url_helper
INFO - 2016-09-18 17:48:27 --> Database Driver Class Initialized
INFO - 2016-09-18 17:48:27 --> Controller Class Initialized
DEBUG - 2016-09-18 17:48:27 --> Index MX_Controller Initialized
INFO - 2016-09-18 17:48:27 --> Model Class Initialized
INFO - 2016-09-18 17:48:27 --> Model Class Initialized
INFO - 2016-09-18 17:48:27 --> Database Driver Class Initialized
INFO - 2016-09-18 17:48:27 --> Final output sent to browser
DEBUG - 2016-09-18 17:48:27 --> Total execution time: 0.7280
INFO - 2016-09-18 18:03:41 --> Config Class Initialized
INFO - 2016-09-18 18:03:41 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:03:41 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:03:42 --> Utf8 Class Initialized
INFO - 2016-09-18 18:03:42 --> URI Class Initialized
INFO - 2016-09-18 18:03:42 --> Router Class Initialized
INFO - 2016-09-18 18:03:42 --> Output Class Initialized
INFO - 2016-09-18 18:03:42 --> Security Class Initialized
DEBUG - 2016-09-18 18:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:03:42 --> Input Class Initialized
INFO - 2016-09-18 18:03:42 --> Language Class Initialized
INFO - 2016-09-18 18:03:42 --> Language Class Initialized
INFO - 2016-09-18 18:03:42 --> Config Class Initialized
INFO - 2016-09-18 18:03:42 --> Loader Class Initialized
INFO - 2016-09-18 18:03:42 --> Helper loaded: url_helper
INFO - 2016-09-18 18:03:42 --> Database Driver Class Initialized
INFO - 2016-09-18 18:03:42 --> Controller Class Initialized
DEBUG - 2016-09-18 18:03:42 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:03:42 --> Model Class Initialized
INFO - 2016-09-18 18:03:42 --> Model Class Initialized
DEBUG - 2016-09-18 18:03:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 18:03:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 18:03:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 18:03:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tabungan.php
DEBUG - 2016-09-18 18:03:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 18:03:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 18:03:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 18:03:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 18:03:42 --> Final output sent to browser
DEBUG - 2016-09-18 18:03:42 --> Total execution time: 0.8291
INFO - 2016-09-18 18:03:46 --> Config Class Initialized
INFO - 2016-09-18 18:03:46 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:03:46 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:03:46 --> Utf8 Class Initialized
INFO - 2016-09-18 18:03:46 --> URI Class Initialized
INFO - 2016-09-18 18:03:46 --> Router Class Initialized
INFO - 2016-09-18 18:03:46 --> Output Class Initialized
INFO - 2016-09-18 18:03:46 --> Security Class Initialized
DEBUG - 2016-09-18 18:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:03:46 --> Input Class Initialized
INFO - 2016-09-18 18:03:46 --> Language Class Initialized
INFO - 2016-09-18 18:03:46 --> Language Class Initialized
INFO - 2016-09-18 18:03:46 --> Config Class Initialized
INFO - 2016-09-18 18:03:47 --> Loader Class Initialized
INFO - 2016-09-18 18:03:47 --> Helper loaded: url_helper
INFO - 2016-09-18 18:03:47 --> Database Driver Class Initialized
INFO - 2016-09-18 18:03:47 --> Controller Class Initialized
DEBUG - 2016-09-18 18:03:47 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:03:47 --> Model Class Initialized
INFO - 2016-09-18 18:03:47 --> Model Class Initialized
INFO - 2016-09-18 18:03:47 --> Database Driver Class Initialized
INFO - 2016-09-18 18:03:47 --> Final output sent to browser
DEBUG - 2016-09-18 18:03:47 --> Total execution time: 0.7783
INFO - 2016-09-18 18:04:11 --> Config Class Initialized
INFO - 2016-09-18 18:04:11 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:04:11 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:04:11 --> Utf8 Class Initialized
INFO - 2016-09-18 18:04:11 --> URI Class Initialized
INFO - 2016-09-18 18:04:11 --> Router Class Initialized
INFO - 2016-09-18 18:04:11 --> Output Class Initialized
INFO - 2016-09-18 18:04:12 --> Security Class Initialized
DEBUG - 2016-09-18 18:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:04:12 --> Input Class Initialized
INFO - 2016-09-18 18:04:12 --> Language Class Initialized
INFO - 2016-09-18 18:04:12 --> Language Class Initialized
INFO - 2016-09-18 18:04:12 --> Config Class Initialized
INFO - 2016-09-18 18:04:12 --> Loader Class Initialized
INFO - 2016-09-18 18:04:12 --> Helper loaded: url_helper
INFO - 2016-09-18 18:04:12 --> Database Driver Class Initialized
INFO - 2016-09-18 18:04:12 --> Controller Class Initialized
DEBUG - 2016-09-18 18:04:12 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:04:12 --> Model Class Initialized
INFO - 2016-09-18 18:04:12 --> Model Class Initialized
DEBUG - 2016-09-18 18:04:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 18:04:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 18:04:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 18:04:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tabungan.php
DEBUG - 2016-09-18 18:04:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 18:04:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 18:04:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 18:04:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 18:04:12 --> Final output sent to browser
DEBUG - 2016-09-18 18:04:12 --> Total execution time: 0.9413
INFO - 2016-09-18 18:04:16 --> Config Class Initialized
INFO - 2016-09-18 18:04:16 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:04:16 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:04:16 --> Utf8 Class Initialized
INFO - 2016-09-18 18:04:16 --> URI Class Initialized
INFO - 2016-09-18 18:04:16 --> Router Class Initialized
INFO - 2016-09-18 18:04:16 --> Output Class Initialized
INFO - 2016-09-18 18:04:16 --> Security Class Initialized
DEBUG - 2016-09-18 18:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:04:16 --> Input Class Initialized
INFO - 2016-09-18 18:04:17 --> Language Class Initialized
INFO - 2016-09-18 18:04:17 --> Language Class Initialized
INFO - 2016-09-18 18:04:17 --> Config Class Initialized
INFO - 2016-09-18 18:04:17 --> Loader Class Initialized
INFO - 2016-09-18 18:04:17 --> Helper loaded: url_helper
INFO - 2016-09-18 18:04:17 --> Database Driver Class Initialized
INFO - 2016-09-18 18:04:17 --> Controller Class Initialized
DEBUG - 2016-09-18 18:04:17 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:04:17 --> Model Class Initialized
INFO - 2016-09-18 18:04:17 --> Model Class Initialized
INFO - 2016-09-18 18:04:17 --> Database Driver Class Initialized
INFO - 2016-09-18 18:04:17 --> Final output sent to browser
DEBUG - 2016-09-18 18:04:17 --> Total execution time: 1.0352
INFO - 2016-09-18 18:04:33 --> Config Class Initialized
INFO - 2016-09-18 18:04:33 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:04:33 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:04:33 --> Utf8 Class Initialized
INFO - 2016-09-18 18:04:33 --> URI Class Initialized
INFO - 2016-09-18 18:04:33 --> Router Class Initialized
INFO - 2016-09-18 18:04:33 --> Output Class Initialized
INFO - 2016-09-18 18:04:33 --> Security Class Initialized
DEBUG - 2016-09-18 18:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:04:33 --> Input Class Initialized
INFO - 2016-09-18 18:04:33 --> Language Class Initialized
INFO - 2016-09-18 18:04:33 --> Language Class Initialized
INFO - 2016-09-18 18:04:33 --> Config Class Initialized
INFO - 2016-09-18 18:04:33 --> Loader Class Initialized
INFO - 2016-09-18 18:04:33 --> Helper loaded: url_helper
INFO - 2016-09-18 18:04:33 --> Database Driver Class Initialized
INFO - 2016-09-18 18:04:34 --> Controller Class Initialized
DEBUG - 2016-09-18 18:04:34 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:04:34 --> Model Class Initialized
INFO - 2016-09-18 18:04:34 --> Model Class Initialized
DEBUG - 2016-09-18 18:04:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 18:04:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 18:04:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 18:04:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tabungan.php
DEBUG - 2016-09-18 18:04:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 18:04:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 18:04:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 18:04:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 18:04:34 --> Final output sent to browser
DEBUG - 2016-09-18 18:04:34 --> Total execution time: 0.8836
INFO - 2016-09-18 18:04:38 --> Config Class Initialized
INFO - 2016-09-18 18:04:38 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:04:38 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:04:38 --> Utf8 Class Initialized
INFO - 2016-09-18 18:04:38 --> URI Class Initialized
INFO - 2016-09-18 18:04:38 --> Router Class Initialized
INFO - 2016-09-18 18:04:38 --> Output Class Initialized
INFO - 2016-09-18 18:04:38 --> Security Class Initialized
DEBUG - 2016-09-18 18:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:04:38 --> Input Class Initialized
INFO - 2016-09-18 18:04:38 --> Language Class Initialized
INFO - 2016-09-18 18:04:38 --> Language Class Initialized
INFO - 2016-09-18 18:04:38 --> Config Class Initialized
INFO - 2016-09-18 18:04:38 --> Loader Class Initialized
INFO - 2016-09-18 18:04:38 --> Helper loaded: url_helper
INFO - 2016-09-18 18:04:38 --> Database Driver Class Initialized
INFO - 2016-09-18 18:04:38 --> Controller Class Initialized
DEBUG - 2016-09-18 18:04:38 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:04:38 --> Model Class Initialized
INFO - 2016-09-18 18:04:38 --> Model Class Initialized
INFO - 2016-09-18 18:04:38 --> Database Driver Class Initialized
INFO - 2016-09-18 18:04:38 --> Final output sent to browser
DEBUG - 2016-09-18 18:04:38 --> Total execution time: 0.7939
INFO - 2016-09-18 18:05:29 --> Config Class Initialized
INFO - 2016-09-18 18:05:29 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:05:29 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:05:29 --> Utf8 Class Initialized
INFO - 2016-09-18 18:05:29 --> URI Class Initialized
INFO - 2016-09-18 18:05:29 --> Router Class Initialized
INFO - 2016-09-18 18:05:29 --> Output Class Initialized
INFO - 2016-09-18 18:05:29 --> Security Class Initialized
DEBUG - 2016-09-18 18:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:05:29 --> Input Class Initialized
INFO - 2016-09-18 18:05:29 --> Language Class Initialized
INFO - 2016-09-18 18:05:29 --> Language Class Initialized
INFO - 2016-09-18 18:05:29 --> Config Class Initialized
INFO - 2016-09-18 18:05:29 --> Loader Class Initialized
INFO - 2016-09-18 18:05:29 --> Helper loaded: url_helper
INFO - 2016-09-18 18:05:29 --> Database Driver Class Initialized
INFO - 2016-09-18 18:05:29 --> Controller Class Initialized
DEBUG - 2016-09-18 18:05:29 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:05:29 --> Model Class Initialized
INFO - 2016-09-18 18:05:29 --> Model Class Initialized
DEBUG - 2016-09-18 18:05:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 18:05:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 18:05:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 18:05:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tabungan.php
DEBUG - 2016-09-18 18:05:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 18:05:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 18:05:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 18:05:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 18:05:29 --> Final output sent to browser
DEBUG - 2016-09-18 18:05:29 --> Total execution time: 0.8039
INFO - 2016-09-18 18:05:43 --> Config Class Initialized
INFO - 2016-09-18 18:05:43 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:05:43 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:05:43 --> Utf8 Class Initialized
INFO - 2016-09-18 18:05:43 --> URI Class Initialized
INFO - 2016-09-18 18:05:43 --> Router Class Initialized
INFO - 2016-09-18 18:05:43 --> Output Class Initialized
INFO - 2016-09-18 18:05:43 --> Security Class Initialized
DEBUG - 2016-09-18 18:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:05:43 --> Input Class Initialized
INFO - 2016-09-18 18:05:43 --> Language Class Initialized
INFO - 2016-09-18 18:05:43 --> Language Class Initialized
INFO - 2016-09-18 18:05:43 --> Config Class Initialized
INFO - 2016-09-18 18:05:44 --> Loader Class Initialized
INFO - 2016-09-18 18:05:44 --> Helper loaded: url_helper
INFO - 2016-09-18 18:05:44 --> Database Driver Class Initialized
INFO - 2016-09-18 18:05:44 --> Controller Class Initialized
DEBUG - 2016-09-18 18:05:44 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:05:44 --> Model Class Initialized
INFO - 2016-09-18 18:05:44 --> Model Class Initialized
DEBUG - 2016-09-18 18:05:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 18:05:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 18:05:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 18:05:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tabungan.php
DEBUG - 2016-09-18 18:05:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 18:05:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 18:05:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 18:05:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 18:05:44 --> Final output sent to browser
DEBUG - 2016-09-18 18:05:44 --> Total execution time: 1.0988
INFO - 2016-09-18 18:05:57 --> Config Class Initialized
INFO - 2016-09-18 18:05:57 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:05:57 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:05:57 --> Utf8 Class Initialized
INFO - 2016-09-18 18:05:58 --> URI Class Initialized
INFO - 2016-09-18 18:05:58 --> Router Class Initialized
INFO - 2016-09-18 18:05:58 --> Output Class Initialized
INFO - 2016-09-18 18:05:58 --> Security Class Initialized
DEBUG - 2016-09-18 18:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:05:58 --> Input Class Initialized
INFO - 2016-09-18 18:05:58 --> Language Class Initialized
INFO - 2016-09-18 18:05:58 --> Language Class Initialized
INFO - 2016-09-18 18:05:58 --> Config Class Initialized
INFO - 2016-09-18 18:05:58 --> Loader Class Initialized
INFO - 2016-09-18 18:05:58 --> Helper loaded: url_helper
INFO - 2016-09-18 18:05:58 --> Database Driver Class Initialized
INFO - 2016-09-18 18:05:58 --> Controller Class Initialized
DEBUG - 2016-09-18 18:05:58 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:05:58 --> Model Class Initialized
INFO - 2016-09-18 18:05:58 --> Model Class Initialized
INFO - 2016-09-18 18:05:58 --> Database Driver Class Initialized
INFO - 2016-09-18 18:05:58 --> Final output sent to browser
DEBUG - 2016-09-18 18:05:58 --> Total execution time: 0.6941
INFO - 2016-09-18 18:06:22 --> Config Class Initialized
INFO - 2016-09-18 18:06:22 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:06:22 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:06:22 --> Utf8 Class Initialized
INFO - 2016-09-18 18:06:22 --> URI Class Initialized
INFO - 2016-09-18 18:06:22 --> Router Class Initialized
INFO - 2016-09-18 18:06:22 --> Output Class Initialized
INFO - 2016-09-18 18:06:22 --> Security Class Initialized
DEBUG - 2016-09-18 18:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:06:22 --> Input Class Initialized
INFO - 2016-09-18 18:06:22 --> Language Class Initialized
INFO - 2016-09-18 18:06:22 --> Language Class Initialized
INFO - 2016-09-18 18:06:22 --> Config Class Initialized
INFO - 2016-09-18 18:06:22 --> Loader Class Initialized
INFO - 2016-09-18 18:06:22 --> Helper loaded: url_helper
INFO - 2016-09-18 18:06:22 --> Database Driver Class Initialized
INFO - 2016-09-18 18:06:22 --> Controller Class Initialized
DEBUG - 2016-09-18 18:06:22 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:06:22 --> Model Class Initialized
INFO - 2016-09-18 18:06:22 --> Model Class Initialized
DEBUG - 2016-09-18 18:06:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 18:06:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 18:06:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 18:06:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tabungan.php
DEBUG - 2016-09-18 18:06:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 18:06:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 18:06:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 18:06:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 18:06:23 --> Final output sent to browser
DEBUG - 2016-09-18 18:06:23 --> Total execution time: 1.0975
INFO - 2016-09-18 18:06:29 --> Config Class Initialized
INFO - 2016-09-18 18:06:30 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:06:30 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:06:30 --> Utf8 Class Initialized
INFO - 2016-09-18 18:06:30 --> URI Class Initialized
INFO - 2016-09-18 18:06:30 --> Router Class Initialized
INFO - 2016-09-18 18:06:30 --> Output Class Initialized
INFO - 2016-09-18 18:06:30 --> Security Class Initialized
DEBUG - 2016-09-18 18:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:06:30 --> Input Class Initialized
INFO - 2016-09-18 18:06:30 --> Language Class Initialized
INFO - 2016-09-18 18:06:30 --> Language Class Initialized
INFO - 2016-09-18 18:06:30 --> Config Class Initialized
INFO - 2016-09-18 18:06:30 --> Loader Class Initialized
INFO - 2016-09-18 18:06:30 --> Helper loaded: url_helper
INFO - 2016-09-18 18:06:30 --> Database Driver Class Initialized
INFO - 2016-09-18 18:06:30 --> Controller Class Initialized
DEBUG - 2016-09-18 18:06:30 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:06:30 --> Model Class Initialized
INFO - 2016-09-18 18:06:30 --> Model Class Initialized
INFO - 2016-09-18 18:06:30 --> Database Driver Class Initialized
INFO - 2016-09-18 18:06:30 --> Final output sent to browser
DEBUG - 2016-09-18 18:06:30 --> Total execution time: 0.7245
INFO - 2016-09-18 18:06:33 --> Config Class Initialized
INFO - 2016-09-18 18:06:33 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:06:33 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:06:33 --> Utf8 Class Initialized
INFO - 2016-09-18 18:06:33 --> URI Class Initialized
INFO - 2016-09-18 18:06:33 --> Router Class Initialized
INFO - 2016-09-18 18:06:33 --> Output Class Initialized
INFO - 2016-09-18 18:06:33 --> Security Class Initialized
DEBUG - 2016-09-18 18:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:06:33 --> Input Class Initialized
INFO - 2016-09-18 18:06:34 --> Language Class Initialized
INFO - 2016-09-18 18:06:34 --> Language Class Initialized
INFO - 2016-09-18 18:06:34 --> Config Class Initialized
INFO - 2016-09-18 18:06:34 --> Loader Class Initialized
INFO - 2016-09-18 18:06:34 --> Helper loaded: url_helper
INFO - 2016-09-18 18:06:34 --> Database Driver Class Initialized
INFO - 2016-09-18 18:06:34 --> Controller Class Initialized
DEBUG - 2016-09-18 18:06:34 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:06:34 --> Model Class Initialized
INFO - 2016-09-18 18:06:34 --> Model Class Initialized
INFO - 2016-09-18 18:06:34 --> Database Driver Class Initialized
DEBUG - 2016-09-18 18:06:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 18:06:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 18:06:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 18:06:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_simpan_tabungan.php
DEBUG - 2016-09-18 18:06:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 18:06:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 18:06:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 18:06:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 18:06:34 --> Final output sent to browser
DEBUG - 2016-09-18 18:06:34 --> Total execution time: 1.0216
INFO - 2016-09-18 18:19:12 --> Config Class Initialized
INFO - 2016-09-18 18:19:12 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:19:13 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:19:13 --> Utf8 Class Initialized
INFO - 2016-09-18 18:19:13 --> URI Class Initialized
INFO - 2016-09-18 18:19:13 --> Router Class Initialized
INFO - 2016-09-18 18:19:13 --> Output Class Initialized
INFO - 2016-09-18 18:19:13 --> Security Class Initialized
DEBUG - 2016-09-18 18:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:19:13 --> Input Class Initialized
INFO - 2016-09-18 18:19:13 --> Language Class Initialized
INFO - 2016-09-18 18:19:13 --> Language Class Initialized
INFO - 2016-09-18 18:19:13 --> Config Class Initialized
INFO - 2016-09-18 18:19:13 --> Loader Class Initialized
INFO - 2016-09-18 18:19:13 --> Helper loaded: url_helper
INFO - 2016-09-18 18:19:13 --> Database Driver Class Initialized
INFO - 2016-09-18 18:19:13 --> Controller Class Initialized
DEBUG - 2016-09-18 18:19:13 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:19:13 --> Model Class Initialized
INFO - 2016-09-18 18:19:13 --> Model Class Initialized
INFO - 2016-09-18 18:19:13 --> Database Driver Class Initialized
DEBUG - 2016-09-18 18:19:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 18:19:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 18:19:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 18:19:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_simpan_tabungan.php
DEBUG - 2016-09-18 18:19:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 18:19:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 18:19:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 18:19:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 18:19:13 --> Final output sent to browser
DEBUG - 2016-09-18 18:19:14 --> Total execution time: 1.1081
INFO - 2016-09-18 18:19:21 --> Config Class Initialized
INFO - 2016-09-18 18:19:21 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:19:21 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:19:21 --> Utf8 Class Initialized
INFO - 2016-09-18 18:19:21 --> URI Class Initialized
INFO - 2016-09-18 18:19:21 --> Router Class Initialized
INFO - 2016-09-18 18:19:22 --> Output Class Initialized
INFO - 2016-09-18 18:19:22 --> Security Class Initialized
DEBUG - 2016-09-18 18:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:19:22 --> Input Class Initialized
INFO - 2016-09-18 18:19:22 --> Language Class Initialized
INFO - 2016-09-18 18:19:22 --> Language Class Initialized
INFO - 2016-09-18 18:19:22 --> Config Class Initialized
INFO - 2016-09-18 18:19:22 --> Loader Class Initialized
INFO - 2016-09-18 18:19:22 --> Helper loaded: url_helper
INFO - 2016-09-18 18:19:22 --> Database Driver Class Initialized
INFO - 2016-09-18 18:19:22 --> Controller Class Initialized
DEBUG - 2016-09-18 18:19:22 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:19:22 --> Model Class Initialized
INFO - 2016-09-18 18:19:22 --> Model Class Initialized
ERROR - 2016-09-18 18:19:22 --> Severity: Notice --> Undefined index: no_identitas E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 127
ERROR - 2016-09-18 18:19:22 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 129
DEBUG - 2016-09-18 18:19:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 18:19:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 18:19:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 18:19:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-09-18 18:19:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 18:19:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 18:19:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 18:19:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 18:19:22 --> Final output sent to browser
DEBUG - 2016-09-18 18:19:22 --> Total execution time: 0.9676
INFO - 2016-09-18 18:19:40 --> Config Class Initialized
INFO - 2016-09-18 18:19:40 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:19:40 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:19:40 --> Utf8 Class Initialized
INFO - 2016-09-18 18:19:40 --> URI Class Initialized
INFO - 2016-09-18 18:19:40 --> Router Class Initialized
INFO - 2016-09-18 18:19:40 --> Output Class Initialized
INFO - 2016-09-18 18:19:40 --> Security Class Initialized
DEBUG - 2016-09-18 18:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:19:40 --> Input Class Initialized
INFO - 2016-09-18 18:19:40 --> Language Class Initialized
INFO - 2016-09-18 18:19:40 --> Language Class Initialized
INFO - 2016-09-18 18:19:40 --> Config Class Initialized
INFO - 2016-09-18 18:19:40 --> Loader Class Initialized
INFO - 2016-09-18 18:19:40 --> Helper loaded: url_helper
INFO - 2016-09-18 18:19:40 --> Database Driver Class Initialized
INFO - 2016-09-18 18:19:40 --> Controller Class Initialized
DEBUG - 2016-09-18 18:19:40 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:19:41 --> Model Class Initialized
INFO - 2016-09-18 18:19:41 --> Model Class Initialized
ERROR - 2016-09-18 18:19:41 --> Severity: Notice --> Undefined index: no_identitas E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 127
ERROR - 2016-09-18 18:19:41 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 129
DEBUG - 2016-09-18 18:19:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 18:19:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 18:19:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 18:19:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-09-18 18:19:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 18:19:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 18:19:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 18:19:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 18:19:41 --> Final output sent to browser
DEBUG - 2016-09-18 18:19:41 --> Total execution time: 1.2873
INFO - 2016-09-18 18:20:36 --> Config Class Initialized
INFO - 2016-09-18 18:20:36 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:20:36 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:20:36 --> Utf8 Class Initialized
INFO - 2016-09-18 18:20:36 --> URI Class Initialized
INFO - 2016-09-18 18:20:36 --> Router Class Initialized
INFO - 2016-09-18 18:20:36 --> Output Class Initialized
INFO - 2016-09-18 18:20:36 --> Security Class Initialized
DEBUG - 2016-09-18 18:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:20:36 --> Input Class Initialized
INFO - 2016-09-18 18:20:36 --> Language Class Initialized
INFO - 2016-09-18 18:20:36 --> Language Class Initialized
INFO - 2016-09-18 18:20:36 --> Config Class Initialized
INFO - 2016-09-18 18:20:36 --> Loader Class Initialized
INFO - 2016-09-18 18:20:36 --> Helper loaded: url_helper
INFO - 2016-09-18 18:20:36 --> Database Driver Class Initialized
INFO - 2016-09-18 18:20:36 --> Controller Class Initialized
DEBUG - 2016-09-18 18:20:36 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:20:36 --> Model Class Initialized
INFO - 2016-09-18 18:20:36 --> Model Class Initialized
INFO - 2016-09-18 18:20:36 --> Database Driver Class Initialized
DEBUG - 2016-09-18 18:20:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 18:20:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 18:20:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 18:20:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_simpan_tabungan.php
DEBUG - 2016-09-18 18:20:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 18:20:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 18:20:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 18:20:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 18:20:37 --> Final output sent to browser
DEBUG - 2016-09-18 18:20:37 --> Total execution time: 1.0504
INFO - 2016-09-18 18:20:50 --> Config Class Initialized
INFO - 2016-09-18 18:20:50 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:20:50 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:20:50 --> Utf8 Class Initialized
INFO - 2016-09-18 18:20:50 --> URI Class Initialized
INFO - 2016-09-18 18:20:50 --> Router Class Initialized
INFO - 2016-09-18 18:20:50 --> Output Class Initialized
INFO - 2016-09-18 18:20:50 --> Security Class Initialized
DEBUG - 2016-09-18 18:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:20:50 --> Input Class Initialized
INFO - 2016-09-18 18:20:50 --> Language Class Initialized
INFO - 2016-09-18 18:20:50 --> Language Class Initialized
INFO - 2016-09-18 18:20:50 --> Config Class Initialized
INFO - 2016-09-18 18:20:50 --> Loader Class Initialized
INFO - 2016-09-18 18:20:50 --> Helper loaded: url_helper
INFO - 2016-09-18 18:20:50 --> Database Driver Class Initialized
INFO - 2016-09-18 18:20:51 --> Controller Class Initialized
DEBUG - 2016-09-18 18:20:51 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:20:51 --> Model Class Initialized
INFO - 2016-09-18 18:20:51 --> Model Class Initialized
INFO - 2016-09-18 18:20:51 --> Database Driver Class Initialized
INFO - 2016-09-18 18:20:51 --> Database Driver Class Initialized
ERROR - 2016-09-18 18:20:51 --> Severity: Notice --> Undefined index: nama E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 687
INFO - 2016-09-18 18:20:51 --> Database Driver Class Initialized
INFO - 2016-09-18 18:20:51 --> Final output sent to browser
DEBUG - 2016-09-18 18:20:51 --> Total execution time: 1.3389
INFO - 2016-09-18 18:21:52 --> Config Class Initialized
INFO - 2016-09-18 18:21:52 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:21:52 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:21:52 --> Utf8 Class Initialized
INFO - 2016-09-18 18:21:52 --> URI Class Initialized
INFO - 2016-09-18 18:21:53 --> Router Class Initialized
INFO - 2016-09-18 18:21:53 --> Output Class Initialized
INFO - 2016-09-18 18:21:53 --> Security Class Initialized
DEBUG - 2016-09-18 18:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:21:53 --> Input Class Initialized
INFO - 2016-09-18 18:21:53 --> Language Class Initialized
INFO - 2016-09-18 18:21:53 --> Language Class Initialized
INFO - 2016-09-18 18:21:53 --> Config Class Initialized
INFO - 2016-09-18 18:21:53 --> Loader Class Initialized
INFO - 2016-09-18 18:21:53 --> Helper loaded: url_helper
INFO - 2016-09-18 18:21:53 --> Database Driver Class Initialized
INFO - 2016-09-18 18:21:53 --> Controller Class Initialized
DEBUG - 2016-09-18 18:21:53 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:21:53 --> Model Class Initialized
INFO - 2016-09-18 18:21:53 --> Model Class Initialized
INFO - 2016-09-18 18:21:53 --> Database Driver Class Initialized
DEBUG - 2016-09-18 18:21:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 18:21:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 18:21:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 18:21:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_simpan_tabungan.php
DEBUG - 2016-09-18 18:21:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 18:21:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 18:21:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 18:21:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 18:21:53 --> Final output sent to browser
DEBUG - 2016-09-18 18:21:53 --> Total execution time: 1.1175
INFO - 2016-09-18 18:22:05 --> Config Class Initialized
INFO - 2016-09-18 18:22:05 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:22:05 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:22:05 --> Utf8 Class Initialized
INFO - 2016-09-18 18:22:05 --> URI Class Initialized
INFO - 2016-09-18 18:22:05 --> Router Class Initialized
INFO - 2016-09-18 18:22:05 --> Output Class Initialized
INFO - 2016-09-18 18:22:05 --> Security Class Initialized
DEBUG - 2016-09-18 18:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:22:05 --> Input Class Initialized
INFO - 2016-09-18 18:22:05 --> Language Class Initialized
INFO - 2016-09-18 18:22:05 --> Language Class Initialized
INFO - 2016-09-18 18:22:05 --> Config Class Initialized
INFO - 2016-09-18 18:22:05 --> Loader Class Initialized
INFO - 2016-09-18 18:22:05 --> Helper loaded: url_helper
INFO - 2016-09-18 18:22:05 --> Database Driver Class Initialized
INFO - 2016-09-18 18:22:05 --> Controller Class Initialized
DEBUG - 2016-09-18 18:22:05 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:22:06 --> Model Class Initialized
INFO - 2016-09-18 18:22:06 --> Model Class Initialized
INFO - 2016-09-18 18:22:06 --> Database Driver Class Initialized
INFO - 2016-09-18 18:22:06 --> Database Driver Class Initialized
INFO - 2016-09-18 18:22:06 --> Database Driver Class Initialized
INFO - 2016-09-18 18:22:06 --> Final output sent to browser
DEBUG - 2016-09-18 18:22:06 --> Total execution time: 0.9913
INFO - 2016-09-18 18:22:30 --> Config Class Initialized
INFO - 2016-09-18 18:22:30 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:22:30 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:22:30 --> Utf8 Class Initialized
INFO - 2016-09-18 18:22:30 --> URI Class Initialized
INFO - 2016-09-18 18:22:30 --> Router Class Initialized
INFO - 2016-09-18 18:22:30 --> Output Class Initialized
INFO - 2016-09-18 18:22:30 --> Security Class Initialized
DEBUG - 2016-09-18 18:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:22:31 --> Input Class Initialized
INFO - 2016-09-18 18:22:31 --> Language Class Initialized
INFO - 2016-09-18 18:22:31 --> Language Class Initialized
INFO - 2016-09-18 18:22:31 --> Config Class Initialized
INFO - 2016-09-18 18:22:31 --> Loader Class Initialized
INFO - 2016-09-18 18:22:31 --> Helper loaded: url_helper
INFO - 2016-09-18 18:22:31 --> Database Driver Class Initialized
INFO - 2016-09-18 18:22:31 --> Controller Class Initialized
DEBUG - 2016-09-18 18:22:31 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:22:31 --> Model Class Initialized
INFO - 2016-09-18 18:22:31 --> Model Class Initialized
INFO - 2016-09-18 18:22:31 --> Database Driver Class Initialized
INFO - 2016-09-18 18:22:31 --> Database Driver Class Initialized
INFO - 2016-09-18 18:22:31 --> Database Driver Class Initialized
INFO - 2016-09-18 18:22:31 --> Final output sent to browser
DEBUG - 2016-09-18 18:22:31 --> Total execution time: 0.8552
INFO - 2016-09-18 18:22:42 --> Config Class Initialized
INFO - 2016-09-18 18:22:42 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:22:42 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:22:42 --> Utf8 Class Initialized
INFO - 2016-09-18 18:22:42 --> URI Class Initialized
INFO - 2016-09-18 18:22:42 --> Router Class Initialized
INFO - 2016-09-18 18:22:42 --> Output Class Initialized
INFO - 2016-09-18 18:22:42 --> Security Class Initialized
DEBUG - 2016-09-18 18:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:22:42 --> Input Class Initialized
INFO - 2016-09-18 18:22:42 --> Language Class Initialized
INFO - 2016-09-18 18:22:42 --> Language Class Initialized
INFO - 2016-09-18 18:22:42 --> Config Class Initialized
INFO - 2016-09-18 18:22:42 --> Loader Class Initialized
INFO - 2016-09-18 18:22:42 --> Helper loaded: url_helper
INFO - 2016-09-18 18:22:42 --> Database Driver Class Initialized
INFO - 2016-09-18 18:22:42 --> Controller Class Initialized
DEBUG - 2016-09-18 18:22:42 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:22:42 --> Model Class Initialized
INFO - 2016-09-18 18:22:43 --> Model Class Initialized
INFO - 2016-09-18 18:22:43 --> Database Driver Class Initialized
INFO - 2016-09-18 18:22:43 --> Database Driver Class Initialized
INFO - 2016-09-18 18:22:43 --> Database Driver Class Initialized
INFO - 2016-09-18 18:22:43 --> Final output sent to browser
DEBUG - 2016-09-18 18:22:43 --> Total execution time: 1.1096
INFO - 2016-09-18 18:23:25 --> Config Class Initialized
INFO - 2016-09-18 18:23:25 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:23:25 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:23:25 --> Utf8 Class Initialized
INFO - 2016-09-18 18:23:25 --> URI Class Initialized
INFO - 2016-09-18 18:23:25 --> Router Class Initialized
INFO - 2016-09-18 18:23:25 --> Output Class Initialized
INFO - 2016-09-18 18:23:25 --> Security Class Initialized
DEBUG - 2016-09-18 18:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:23:25 --> Input Class Initialized
INFO - 2016-09-18 18:23:25 --> Language Class Initialized
INFO - 2016-09-18 18:23:25 --> Language Class Initialized
INFO - 2016-09-18 18:23:25 --> Config Class Initialized
INFO - 2016-09-18 18:23:25 --> Loader Class Initialized
INFO - 2016-09-18 18:23:25 --> Helper loaded: url_helper
INFO - 2016-09-18 18:23:25 --> Database Driver Class Initialized
INFO - 2016-09-18 18:23:25 --> Controller Class Initialized
DEBUG - 2016-09-18 18:23:25 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:23:25 --> Model Class Initialized
INFO - 2016-09-18 18:23:25 --> Model Class Initialized
INFO - 2016-09-18 18:23:25 --> Database Driver Class Initialized
DEBUG - 2016-09-18 18:23:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 18:23:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 18:23:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 18:23:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_simpan_tabungan.php
DEBUG - 2016-09-18 18:23:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 18:23:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 18:23:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 18:23:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 18:23:26 --> Final output sent to browser
DEBUG - 2016-09-18 18:23:26 --> Total execution time: 0.9309
INFO - 2016-09-18 18:23:30 --> Config Class Initialized
INFO - 2016-09-18 18:23:30 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:23:30 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:23:30 --> Utf8 Class Initialized
INFO - 2016-09-18 18:23:30 --> URI Class Initialized
INFO - 2016-09-18 18:23:30 --> Router Class Initialized
INFO - 2016-09-18 18:23:31 --> Output Class Initialized
INFO - 2016-09-18 18:23:31 --> Security Class Initialized
DEBUG - 2016-09-18 18:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:23:31 --> Input Class Initialized
INFO - 2016-09-18 18:23:31 --> Language Class Initialized
INFO - 2016-09-18 18:23:31 --> Language Class Initialized
INFO - 2016-09-18 18:23:31 --> Config Class Initialized
INFO - 2016-09-18 18:23:31 --> Loader Class Initialized
INFO - 2016-09-18 18:23:31 --> Helper loaded: url_helper
INFO - 2016-09-18 18:23:31 --> Database Driver Class Initialized
INFO - 2016-09-18 18:23:31 --> Controller Class Initialized
DEBUG - 2016-09-18 18:23:31 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:23:31 --> Model Class Initialized
INFO - 2016-09-18 18:23:31 --> Model Class Initialized
INFO - 2016-09-18 18:23:31 --> Database Driver Class Initialized
INFO - 2016-09-18 18:23:31 --> Database Driver Class Initialized
INFO - 2016-09-18 18:23:31 --> Database Driver Class Initialized
INFO - 2016-09-18 18:23:31 --> Final output sent to browser
DEBUG - 2016-09-18 18:23:31 --> Total execution time: 0.9309
INFO - 2016-09-18 18:23:42 --> Config Class Initialized
INFO - 2016-09-18 18:23:43 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:23:43 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:23:43 --> Utf8 Class Initialized
INFO - 2016-09-18 18:23:43 --> URI Class Initialized
INFO - 2016-09-18 18:23:43 --> Router Class Initialized
INFO - 2016-09-18 18:23:43 --> Output Class Initialized
INFO - 2016-09-18 18:23:43 --> Security Class Initialized
DEBUG - 2016-09-18 18:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:23:43 --> Input Class Initialized
INFO - 2016-09-18 18:23:43 --> Language Class Initialized
INFO - 2016-09-18 18:23:43 --> Language Class Initialized
INFO - 2016-09-18 18:23:43 --> Config Class Initialized
INFO - 2016-09-18 18:23:43 --> Loader Class Initialized
INFO - 2016-09-18 18:23:43 --> Helper loaded: url_helper
INFO - 2016-09-18 18:23:43 --> Database Driver Class Initialized
INFO - 2016-09-18 18:23:43 --> Controller Class Initialized
DEBUG - 2016-09-18 18:23:43 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:23:43 --> Model Class Initialized
INFO - 2016-09-18 18:23:43 --> Model Class Initialized
DEBUG - 2016-09-18 18:23:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 18:23:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 18:23:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 18:23:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tabungan.php
DEBUG - 2016-09-18 18:23:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 18:23:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 18:23:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 18:23:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 18:23:44 --> Final output sent to browser
DEBUG - 2016-09-18 18:23:44 --> Total execution time: 1.1360
INFO - 2016-09-18 18:23:47 --> Config Class Initialized
INFO - 2016-09-18 18:23:47 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:23:47 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:23:47 --> Utf8 Class Initialized
INFO - 2016-09-18 18:23:47 --> URI Class Initialized
INFO - 2016-09-18 18:23:47 --> Router Class Initialized
INFO - 2016-09-18 18:23:47 --> Output Class Initialized
INFO - 2016-09-18 18:23:47 --> Security Class Initialized
DEBUG - 2016-09-18 18:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:23:47 --> Input Class Initialized
INFO - 2016-09-18 18:23:47 --> Language Class Initialized
INFO - 2016-09-18 18:23:47 --> Language Class Initialized
INFO - 2016-09-18 18:23:47 --> Config Class Initialized
INFO - 2016-09-18 18:23:47 --> Loader Class Initialized
INFO - 2016-09-18 18:23:48 --> Helper loaded: url_helper
INFO - 2016-09-18 18:23:48 --> Database Driver Class Initialized
INFO - 2016-09-18 18:23:48 --> Controller Class Initialized
DEBUG - 2016-09-18 18:23:48 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:23:48 --> Model Class Initialized
INFO - 2016-09-18 18:23:48 --> Model Class Initialized
INFO - 2016-09-18 18:23:48 --> Database Driver Class Initialized
INFO - 2016-09-18 18:23:48 --> Final output sent to browser
DEBUG - 2016-09-18 18:23:48 --> Total execution time: 0.8013
INFO - 2016-09-18 18:23:54 --> Config Class Initialized
INFO - 2016-09-18 18:23:54 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:23:54 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:23:54 --> Utf8 Class Initialized
INFO - 2016-09-18 18:23:54 --> URI Class Initialized
INFO - 2016-09-18 18:23:54 --> Router Class Initialized
INFO - 2016-09-18 18:23:54 --> Output Class Initialized
INFO - 2016-09-18 18:23:54 --> Security Class Initialized
DEBUG - 2016-09-18 18:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:23:54 --> Input Class Initialized
INFO - 2016-09-18 18:23:54 --> Language Class Initialized
INFO - 2016-09-18 18:23:54 --> Language Class Initialized
INFO - 2016-09-18 18:23:54 --> Config Class Initialized
INFO - 2016-09-18 18:23:55 --> Loader Class Initialized
INFO - 2016-09-18 18:23:55 --> Helper loaded: url_helper
INFO - 2016-09-18 18:23:55 --> Database Driver Class Initialized
INFO - 2016-09-18 18:23:55 --> Controller Class Initialized
DEBUG - 2016-09-18 18:23:55 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:23:55 --> Model Class Initialized
INFO - 2016-09-18 18:23:55 --> Model Class Initialized
INFO - 2016-09-18 18:23:55 --> Database Driver Class Initialized
INFO - 2016-09-18 18:23:55 --> Final output sent to browser
DEBUG - 2016-09-18 18:23:55 --> Total execution time: 0.6633
INFO - 2016-09-18 18:24:31 --> Config Class Initialized
INFO - 2016-09-18 18:24:31 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:24:31 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:24:31 --> Utf8 Class Initialized
INFO - 2016-09-18 18:24:31 --> URI Class Initialized
INFO - 2016-09-18 18:24:31 --> Router Class Initialized
INFO - 2016-09-18 18:24:31 --> Output Class Initialized
INFO - 2016-09-18 18:24:31 --> Security Class Initialized
DEBUG - 2016-09-18 18:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:24:31 --> Input Class Initialized
INFO - 2016-09-18 18:24:31 --> Language Class Initialized
INFO - 2016-09-18 18:24:31 --> Language Class Initialized
INFO - 2016-09-18 18:24:31 --> Config Class Initialized
INFO - 2016-09-18 18:24:32 --> Loader Class Initialized
INFO - 2016-09-18 18:24:32 --> Helper loaded: url_helper
INFO - 2016-09-18 18:24:32 --> Database Driver Class Initialized
INFO - 2016-09-18 18:24:32 --> Controller Class Initialized
DEBUG - 2016-09-18 18:24:32 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:24:32 --> Model Class Initialized
INFO - 2016-09-18 18:24:32 --> Model Class Initialized
DEBUG - 2016-09-18 18:24:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 18:24:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 18:24:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 18:24:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/jurnal_umum.php
DEBUG - 2016-09-18 18:24:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 18:24:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 18:24:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 18:24:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 18:24:32 --> Final output sent to browser
DEBUG - 2016-09-18 18:24:32 --> Total execution time: 0.9040
INFO - 2016-09-18 18:24:38 --> Config Class Initialized
INFO - 2016-09-18 18:24:38 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:24:38 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:24:38 --> Utf8 Class Initialized
INFO - 2016-09-18 18:24:38 --> URI Class Initialized
INFO - 2016-09-18 18:24:38 --> Router Class Initialized
INFO - 2016-09-18 18:24:39 --> Output Class Initialized
INFO - 2016-09-18 18:24:39 --> Security Class Initialized
DEBUG - 2016-09-18 18:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:24:39 --> Input Class Initialized
INFO - 2016-09-18 18:24:39 --> Language Class Initialized
INFO - 2016-09-18 18:24:39 --> Language Class Initialized
INFO - 2016-09-18 18:24:39 --> Config Class Initialized
INFO - 2016-09-18 18:24:39 --> Loader Class Initialized
INFO - 2016-09-18 18:24:39 --> Helper loaded: url_helper
INFO - 2016-09-18 18:24:39 --> Database Driver Class Initialized
INFO - 2016-09-18 18:24:39 --> Controller Class Initialized
DEBUG - 2016-09-18 18:24:39 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:24:39 --> Model Class Initialized
INFO - 2016-09-18 18:24:39 --> Model Class Initialized
DEBUG - 2016-09-18 18:24:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_jurnal_umum.php
INFO - 2016-09-18 18:24:39 --> Final output sent to browser
DEBUG - 2016-09-18 18:24:39 --> Total execution time: 0.6642
INFO - 2016-09-18 18:25:05 --> Config Class Initialized
INFO - 2016-09-18 18:25:05 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:25:05 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:25:05 --> Utf8 Class Initialized
INFO - 2016-09-18 18:25:05 --> URI Class Initialized
INFO - 2016-09-18 18:25:05 --> Router Class Initialized
INFO - 2016-09-18 18:25:05 --> Output Class Initialized
INFO - 2016-09-18 18:25:05 --> Security Class Initialized
DEBUG - 2016-09-18 18:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:25:05 --> Input Class Initialized
INFO - 2016-09-18 18:25:05 --> Language Class Initialized
INFO - 2016-09-18 18:25:05 --> Language Class Initialized
INFO - 2016-09-18 18:25:06 --> Config Class Initialized
INFO - 2016-09-18 18:25:06 --> Loader Class Initialized
INFO - 2016-09-18 18:25:06 --> Helper loaded: url_helper
INFO - 2016-09-18 18:25:06 --> Database Driver Class Initialized
INFO - 2016-09-18 18:25:06 --> Controller Class Initialized
DEBUG - 2016-09-18 18:25:06 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:25:06 --> Model Class Initialized
INFO - 2016-09-18 18:25:06 --> Model Class Initialized
DEBUG - 2016-09-18 18:25:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_jurnal_umum.php
INFO - 2016-09-18 18:25:06 --> Final output sent to browser
DEBUG - 2016-09-18 18:25:06 --> Total execution time: 0.7822
INFO - 2016-09-18 18:25:27 --> Config Class Initialized
INFO - 2016-09-18 18:25:27 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:25:27 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:25:27 --> Utf8 Class Initialized
INFO - 2016-09-18 18:25:27 --> URI Class Initialized
INFO - 2016-09-18 18:25:27 --> Router Class Initialized
INFO - 2016-09-18 18:25:27 --> Output Class Initialized
INFO - 2016-09-18 18:25:27 --> Security Class Initialized
DEBUG - 2016-09-18 18:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:25:27 --> Input Class Initialized
INFO - 2016-09-18 18:25:27 --> Language Class Initialized
INFO - 2016-09-18 18:25:27 --> Language Class Initialized
INFO - 2016-09-18 18:25:27 --> Config Class Initialized
INFO - 2016-09-18 18:25:27 --> Loader Class Initialized
INFO - 2016-09-18 18:25:27 --> Helper loaded: url_helper
INFO - 2016-09-18 18:25:27 --> Database Driver Class Initialized
INFO - 2016-09-18 18:25:27 --> Controller Class Initialized
DEBUG - 2016-09-18 18:25:27 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:25:27 --> Model Class Initialized
INFO - 2016-09-18 18:25:27 --> Model Class Initialized
DEBUG - 2016-09-18 18:25:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 18:25:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 18:25:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 18:25:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/jurnal_umum.php
DEBUG - 2016-09-18 18:25:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 18:25:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 18:25:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 18:25:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 18:25:28 --> Final output sent to browser
DEBUG - 2016-09-18 18:25:28 --> Total execution time: 0.9823
INFO - 2016-09-18 18:25:33 --> Config Class Initialized
INFO - 2016-09-18 18:25:33 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:25:33 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:25:33 --> Utf8 Class Initialized
INFO - 2016-09-18 18:25:33 --> URI Class Initialized
INFO - 2016-09-18 18:25:33 --> Router Class Initialized
INFO - 2016-09-18 18:25:33 --> Output Class Initialized
INFO - 2016-09-18 18:25:33 --> Security Class Initialized
DEBUG - 2016-09-18 18:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:25:33 --> Input Class Initialized
INFO - 2016-09-18 18:25:33 --> Language Class Initialized
INFO - 2016-09-18 18:25:33 --> Language Class Initialized
INFO - 2016-09-18 18:25:33 --> Config Class Initialized
INFO - 2016-09-18 18:25:33 --> Loader Class Initialized
INFO - 2016-09-18 18:25:33 --> Helper loaded: url_helper
INFO - 2016-09-18 18:25:33 --> Database Driver Class Initialized
INFO - 2016-09-18 18:25:33 --> Controller Class Initialized
DEBUG - 2016-09-18 18:25:33 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:25:33 --> Model Class Initialized
INFO - 2016-09-18 18:25:33 --> Model Class Initialized
DEBUG - 2016-09-18 18:25:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_jurnal_umum.php
INFO - 2016-09-18 18:25:33 --> Final output sent to browser
DEBUG - 2016-09-18 18:25:33 --> Total execution time: 0.7909
INFO - 2016-09-18 18:26:15 --> Config Class Initialized
INFO - 2016-09-18 18:26:16 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:26:16 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:26:16 --> Utf8 Class Initialized
INFO - 2016-09-18 18:26:16 --> URI Class Initialized
INFO - 2016-09-18 18:26:16 --> Router Class Initialized
INFO - 2016-09-18 18:26:16 --> Output Class Initialized
INFO - 2016-09-18 18:26:16 --> Security Class Initialized
DEBUG - 2016-09-18 18:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:26:16 --> Input Class Initialized
INFO - 2016-09-18 18:26:16 --> Language Class Initialized
INFO - 2016-09-18 18:26:16 --> Language Class Initialized
INFO - 2016-09-18 18:26:16 --> Config Class Initialized
INFO - 2016-09-18 18:26:16 --> Loader Class Initialized
INFO - 2016-09-18 18:26:16 --> Helper loaded: url_helper
INFO - 2016-09-18 18:26:16 --> Database Driver Class Initialized
INFO - 2016-09-18 18:26:16 --> Controller Class Initialized
DEBUG - 2016-09-18 18:26:16 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:26:16 --> Model Class Initialized
INFO - 2016-09-18 18:26:16 --> Model Class Initialized
DEBUG - 2016-09-18 18:26:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 18:26:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 18:26:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 18:26:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tabungan.php
DEBUG - 2016-09-18 18:26:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 18:26:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 18:26:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 18:26:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 18:26:16 --> Final output sent to browser
DEBUG - 2016-09-18 18:26:16 --> Total execution time: 0.9437
INFO - 2016-09-18 18:26:22 --> Config Class Initialized
INFO - 2016-09-18 18:26:22 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:26:22 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:26:22 --> Utf8 Class Initialized
INFO - 2016-09-18 18:26:22 --> URI Class Initialized
INFO - 2016-09-18 18:26:22 --> Router Class Initialized
INFO - 2016-09-18 18:26:22 --> Output Class Initialized
INFO - 2016-09-18 18:26:22 --> Security Class Initialized
DEBUG - 2016-09-18 18:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:26:23 --> Input Class Initialized
INFO - 2016-09-18 18:26:23 --> Language Class Initialized
INFO - 2016-09-18 18:26:23 --> Language Class Initialized
INFO - 2016-09-18 18:26:23 --> Config Class Initialized
INFO - 2016-09-18 18:26:23 --> Loader Class Initialized
INFO - 2016-09-18 18:26:23 --> Helper loaded: url_helper
INFO - 2016-09-18 18:26:23 --> Database Driver Class Initialized
INFO - 2016-09-18 18:26:23 --> Controller Class Initialized
DEBUG - 2016-09-18 18:26:23 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:26:23 --> Model Class Initialized
INFO - 2016-09-18 18:26:23 --> Model Class Initialized
INFO - 2016-09-18 18:26:23 --> Database Driver Class Initialized
INFO - 2016-09-18 18:26:23 --> Final output sent to browser
DEBUG - 2016-09-18 18:26:23 --> Total execution time: 0.6928
INFO - 2016-09-18 18:26:25 --> Config Class Initialized
INFO - 2016-09-18 18:26:25 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:26:25 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:26:25 --> Utf8 Class Initialized
INFO - 2016-09-18 18:26:25 --> URI Class Initialized
INFO - 2016-09-18 18:26:25 --> Router Class Initialized
INFO - 2016-09-18 18:26:25 --> Output Class Initialized
INFO - 2016-09-18 18:26:25 --> Security Class Initialized
DEBUG - 2016-09-18 18:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:26:25 --> Input Class Initialized
INFO - 2016-09-18 18:26:25 --> Language Class Initialized
INFO - 2016-09-18 18:26:25 --> Language Class Initialized
INFO - 2016-09-18 18:26:25 --> Config Class Initialized
INFO - 2016-09-18 18:26:25 --> Loader Class Initialized
INFO - 2016-09-18 18:26:25 --> Helper loaded: url_helper
INFO - 2016-09-18 18:26:25 --> Database Driver Class Initialized
INFO - 2016-09-18 18:26:25 --> Controller Class Initialized
DEBUG - 2016-09-18 18:26:25 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:26:25 --> Model Class Initialized
INFO - 2016-09-18 18:26:25 --> Model Class Initialized
INFO - 2016-09-18 18:26:25 --> Database Driver Class Initialized
DEBUG - 2016-09-18 18:26:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 18:26:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 18:26:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 18:26:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tarik_tabungan.php
DEBUG - 2016-09-18 18:26:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 18:26:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 18:26:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 18:26:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 18:26:26 --> Final output sent to browser
DEBUG - 2016-09-18 18:26:26 --> Total execution time: 0.9713
INFO - 2016-09-18 18:30:42 --> Config Class Initialized
INFO - 2016-09-18 18:30:42 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:30:42 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:30:42 --> Utf8 Class Initialized
INFO - 2016-09-18 18:30:42 --> URI Class Initialized
INFO - 2016-09-18 18:30:42 --> Router Class Initialized
INFO - 2016-09-18 18:30:42 --> Output Class Initialized
INFO - 2016-09-18 18:30:42 --> Security Class Initialized
DEBUG - 2016-09-18 18:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:30:42 --> Input Class Initialized
INFO - 2016-09-18 18:30:42 --> Language Class Initialized
INFO - 2016-09-18 18:30:42 --> Language Class Initialized
INFO - 2016-09-18 18:30:42 --> Config Class Initialized
INFO - 2016-09-18 18:30:42 --> Loader Class Initialized
INFO - 2016-09-18 18:30:42 --> Helper loaded: url_helper
INFO - 2016-09-18 18:30:42 --> Database Driver Class Initialized
INFO - 2016-09-18 18:30:42 --> Controller Class Initialized
DEBUG - 2016-09-18 18:30:42 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:30:42 --> Model Class Initialized
INFO - 2016-09-18 18:30:42 --> Model Class Initialized
INFO - 2016-09-18 18:30:42 --> Database Driver Class Initialized
DEBUG - 2016-09-18 18:30:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 18:30:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 18:30:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 18:30:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tarik_tabungan.php
DEBUG - 2016-09-18 18:30:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 18:30:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 18:30:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 18:30:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 18:30:43 --> Final output sent to browser
DEBUG - 2016-09-18 18:30:43 --> Total execution time: 1.1215
INFO - 2016-09-18 18:30:50 --> Config Class Initialized
INFO - 2016-09-18 18:30:50 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:30:50 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:30:50 --> Utf8 Class Initialized
INFO - 2016-09-18 18:30:50 --> URI Class Initialized
INFO - 2016-09-18 18:30:50 --> Router Class Initialized
INFO - 2016-09-18 18:30:50 --> Output Class Initialized
INFO - 2016-09-18 18:30:51 --> Security Class Initialized
DEBUG - 2016-09-18 18:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:30:51 --> Input Class Initialized
INFO - 2016-09-18 18:30:51 --> Language Class Initialized
INFO - 2016-09-18 18:30:51 --> Language Class Initialized
INFO - 2016-09-18 18:30:51 --> Config Class Initialized
INFO - 2016-09-18 18:30:51 --> Loader Class Initialized
INFO - 2016-09-18 18:30:51 --> Helper loaded: url_helper
INFO - 2016-09-18 18:30:51 --> Database Driver Class Initialized
INFO - 2016-09-18 18:30:51 --> Controller Class Initialized
DEBUG - 2016-09-18 18:30:51 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:30:51 --> Model Class Initialized
INFO - 2016-09-18 18:30:51 --> Model Class Initialized
INFO - 2016-09-18 18:30:51 --> Database Driver Class Initialized
INFO - 2016-09-18 18:30:51 --> Database Driver Class Initialized
INFO - 2016-09-18 18:30:51 --> Database Driver Class Initialized
INFO - 2016-09-18 18:30:51 --> Final output sent to browser
DEBUG - 2016-09-18 18:30:51 --> Total execution time: 0.9203
INFO - 2016-09-18 18:34:27 --> Config Class Initialized
INFO - 2016-09-18 18:34:27 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:34:27 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:34:28 --> Utf8 Class Initialized
INFO - 2016-09-18 18:34:28 --> URI Class Initialized
INFO - 2016-09-18 18:34:28 --> Router Class Initialized
INFO - 2016-09-18 18:34:28 --> Output Class Initialized
INFO - 2016-09-18 18:34:28 --> Security Class Initialized
DEBUG - 2016-09-18 18:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:34:28 --> Input Class Initialized
INFO - 2016-09-18 18:34:28 --> Language Class Initialized
INFO - 2016-09-18 18:34:28 --> Language Class Initialized
INFO - 2016-09-18 18:34:28 --> Config Class Initialized
INFO - 2016-09-18 18:34:28 --> Loader Class Initialized
INFO - 2016-09-18 18:34:28 --> Helper loaded: url_helper
INFO - 2016-09-18 18:34:28 --> Database Driver Class Initialized
INFO - 2016-09-18 18:34:28 --> Controller Class Initialized
DEBUG - 2016-09-18 18:34:28 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:34:28 --> Model Class Initialized
INFO - 2016-09-18 18:34:28 --> Model Class Initialized
ERROR - 2016-09-18 18:34:28 --> Severity: Error --> Call to undefined method GlobalModel::selectData() E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 718
INFO - 2016-09-18 18:34:45 --> Config Class Initialized
INFO - 2016-09-18 18:34:45 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:34:45 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:34:45 --> Utf8 Class Initialized
INFO - 2016-09-18 18:34:45 --> URI Class Initialized
INFO - 2016-09-18 18:34:45 --> Router Class Initialized
INFO - 2016-09-18 18:34:45 --> Output Class Initialized
INFO - 2016-09-18 18:34:45 --> Security Class Initialized
DEBUG - 2016-09-18 18:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:34:45 --> Input Class Initialized
INFO - 2016-09-18 18:34:45 --> Language Class Initialized
INFO - 2016-09-18 18:34:45 --> Language Class Initialized
INFO - 2016-09-18 18:34:45 --> Config Class Initialized
INFO - 2016-09-18 18:34:46 --> Loader Class Initialized
INFO - 2016-09-18 18:34:46 --> Helper loaded: url_helper
INFO - 2016-09-18 18:34:46 --> Database Driver Class Initialized
INFO - 2016-09-18 18:34:46 --> Controller Class Initialized
DEBUG - 2016-09-18 18:34:46 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:34:46 --> Model Class Initialized
INFO - 2016-09-18 18:34:46 --> Model Class Initialized
ERROR - 2016-09-18 18:34:46 --> Severity: Error --> Call to undefined method GlobalModel::selectData() E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 718
INFO - 2016-09-18 18:35:01 --> Config Class Initialized
INFO - 2016-09-18 18:35:01 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:35:01 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:35:01 --> Utf8 Class Initialized
INFO - 2016-09-18 18:35:01 --> URI Class Initialized
INFO - 2016-09-18 18:35:01 --> Router Class Initialized
INFO - 2016-09-18 18:35:01 --> Output Class Initialized
INFO - 2016-09-18 18:35:01 --> Security Class Initialized
DEBUG - 2016-09-18 18:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:35:01 --> Input Class Initialized
INFO - 2016-09-18 18:35:01 --> Language Class Initialized
INFO - 2016-09-18 18:35:01 --> Language Class Initialized
INFO - 2016-09-18 18:35:01 --> Config Class Initialized
INFO - 2016-09-18 18:35:01 --> Loader Class Initialized
INFO - 2016-09-18 18:35:01 --> Helper loaded: url_helper
INFO - 2016-09-18 18:35:01 --> Database Driver Class Initialized
INFO - 2016-09-18 18:35:01 --> Controller Class Initialized
DEBUG - 2016-09-18 18:35:01 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:35:01 --> Model Class Initialized
INFO - 2016-09-18 18:35:01 --> Model Class Initialized
INFO - 2016-09-18 18:35:01 --> Database Driver Class Initialized
INFO - 2016-09-18 18:35:01 --> Final output sent to browser
DEBUG - 2016-09-18 18:35:01 --> Total execution time: 0.7701
INFO - 2016-09-18 18:36:01 --> Config Class Initialized
INFO - 2016-09-18 18:36:01 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:36:01 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:36:02 --> Utf8 Class Initialized
INFO - 2016-09-18 18:36:02 --> URI Class Initialized
INFO - 2016-09-18 18:36:02 --> Router Class Initialized
INFO - 2016-09-18 18:36:02 --> Output Class Initialized
INFO - 2016-09-18 18:36:02 --> Security Class Initialized
DEBUG - 2016-09-18 18:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:36:02 --> Input Class Initialized
INFO - 2016-09-18 18:36:02 --> Language Class Initialized
INFO - 2016-09-18 18:36:02 --> Language Class Initialized
INFO - 2016-09-18 18:36:02 --> Config Class Initialized
INFO - 2016-09-18 18:36:02 --> Loader Class Initialized
INFO - 2016-09-18 18:36:02 --> Helper loaded: url_helper
INFO - 2016-09-18 18:36:02 --> Database Driver Class Initialized
INFO - 2016-09-18 18:36:02 --> Controller Class Initialized
DEBUG - 2016-09-18 18:36:02 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:36:02 --> Model Class Initialized
INFO - 2016-09-18 18:36:02 --> Model Class Initialized
INFO - 2016-09-18 18:36:02 --> Database Driver Class Initialized
DEBUG - 2016-09-18 18:36:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 18:36:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 18:36:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 18:36:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tarik_tabungan.php
DEBUG - 2016-09-18 18:36:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 18:36:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 18:36:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 18:36:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 18:36:03 --> Final output sent to browser
DEBUG - 2016-09-18 18:36:03 --> Total execution time: 1.1789
INFO - 2016-09-18 18:36:31 --> Config Class Initialized
INFO - 2016-09-18 18:36:31 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:36:31 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:36:31 --> Utf8 Class Initialized
INFO - 2016-09-18 18:36:31 --> URI Class Initialized
INFO - 2016-09-18 18:36:31 --> Router Class Initialized
INFO - 2016-09-18 18:36:31 --> Output Class Initialized
INFO - 2016-09-18 18:36:31 --> Security Class Initialized
DEBUG - 2016-09-18 18:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:36:32 --> Input Class Initialized
INFO - 2016-09-18 18:36:32 --> Language Class Initialized
INFO - 2016-09-18 18:36:32 --> Language Class Initialized
INFO - 2016-09-18 18:36:32 --> Config Class Initialized
INFO - 2016-09-18 18:36:32 --> Loader Class Initialized
INFO - 2016-09-18 18:36:32 --> Helper loaded: url_helper
INFO - 2016-09-18 18:36:32 --> Database Driver Class Initialized
INFO - 2016-09-18 18:36:32 --> Controller Class Initialized
DEBUG - 2016-09-18 18:36:32 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:36:32 --> Model Class Initialized
INFO - 2016-09-18 18:36:32 --> Model Class Initialized
INFO - 2016-09-18 18:36:32 --> Database Driver Class Initialized
INFO - 2016-09-18 18:36:32 --> Database Driver Class Initialized
INFO - 2016-09-18 18:36:32 --> Database Driver Class Initialized
INFO - 2016-09-18 18:36:32 --> Database Driver Class Initialized
INFO - 2016-09-18 18:36:32 --> Database Driver Class Initialized
INFO - 2016-09-18 18:36:33 --> Final output sent to browser
DEBUG - 2016-09-18 18:36:33 --> Total execution time: 1.4025
INFO - 2016-09-18 18:36:59 --> Config Class Initialized
INFO - 2016-09-18 18:36:59 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:36:59 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:36:59 --> Utf8 Class Initialized
INFO - 2016-09-18 18:36:59 --> URI Class Initialized
INFO - 2016-09-18 18:36:59 --> Router Class Initialized
INFO - 2016-09-18 18:36:59 --> Output Class Initialized
INFO - 2016-09-18 18:36:59 --> Security Class Initialized
DEBUG - 2016-09-18 18:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:36:59 --> Input Class Initialized
INFO - 2016-09-18 18:36:59 --> Language Class Initialized
INFO - 2016-09-18 18:36:59 --> Language Class Initialized
INFO - 2016-09-18 18:36:59 --> Config Class Initialized
INFO - 2016-09-18 18:37:00 --> Loader Class Initialized
INFO - 2016-09-18 18:37:00 --> Helper loaded: url_helper
INFO - 2016-09-18 18:37:00 --> Database Driver Class Initialized
INFO - 2016-09-18 18:37:00 --> Controller Class Initialized
DEBUG - 2016-09-18 18:37:00 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:37:00 --> Model Class Initialized
INFO - 2016-09-18 18:37:00 --> Model Class Initialized
INFO - 2016-09-18 18:37:00 --> Database Driver Class Initialized
INFO - 2016-09-18 18:37:00 --> Final output sent to browser
DEBUG - 2016-09-18 18:37:00 --> Total execution time: 0.7785
INFO - 2016-09-18 18:37:07 --> Config Class Initialized
INFO - 2016-09-18 18:37:07 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:37:07 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:37:07 --> Utf8 Class Initialized
INFO - 2016-09-18 18:37:07 --> URI Class Initialized
INFO - 2016-09-18 18:37:07 --> Router Class Initialized
INFO - 2016-09-18 18:37:07 --> Output Class Initialized
INFO - 2016-09-18 18:37:07 --> Security Class Initialized
DEBUG - 2016-09-18 18:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:37:07 --> Input Class Initialized
INFO - 2016-09-18 18:37:08 --> Language Class Initialized
INFO - 2016-09-18 18:37:08 --> Language Class Initialized
INFO - 2016-09-18 18:37:08 --> Config Class Initialized
INFO - 2016-09-18 18:37:08 --> Loader Class Initialized
INFO - 2016-09-18 18:37:08 --> Helper loaded: url_helper
INFO - 2016-09-18 18:37:08 --> Database Driver Class Initialized
INFO - 2016-09-18 18:37:08 --> Controller Class Initialized
DEBUG - 2016-09-18 18:37:08 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:37:08 --> Model Class Initialized
INFO - 2016-09-18 18:37:08 --> Model Class Initialized
INFO - 2016-09-18 18:37:08 --> Database Driver Class Initialized
DEBUG - 2016-09-18 18:37:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 18:37:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 18:37:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 18:37:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tarik_tabungan.php
DEBUG - 2016-09-18 18:37:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 18:37:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 18:37:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 18:37:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 18:37:08 --> Final output sent to browser
DEBUG - 2016-09-18 18:37:08 --> Total execution time: 1.2137
INFO - 2016-09-18 18:38:30 --> Config Class Initialized
INFO - 2016-09-18 18:38:30 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:38:30 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:38:30 --> Utf8 Class Initialized
INFO - 2016-09-18 18:38:30 --> URI Class Initialized
INFO - 2016-09-18 18:38:30 --> Router Class Initialized
INFO - 2016-09-18 18:38:30 --> Output Class Initialized
INFO - 2016-09-18 18:38:30 --> Security Class Initialized
DEBUG - 2016-09-18 18:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:38:30 --> Input Class Initialized
INFO - 2016-09-18 18:38:30 --> Language Class Initialized
INFO - 2016-09-18 18:38:30 --> Language Class Initialized
INFO - 2016-09-18 18:38:30 --> Config Class Initialized
INFO - 2016-09-18 18:38:30 --> Loader Class Initialized
INFO - 2016-09-18 18:38:30 --> Helper loaded: url_helper
INFO - 2016-09-18 18:38:30 --> Database Driver Class Initialized
INFO - 2016-09-18 18:38:30 --> Controller Class Initialized
DEBUG - 2016-09-18 18:38:30 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:38:30 --> Model Class Initialized
INFO - 2016-09-18 18:38:30 --> Model Class Initialized
INFO - 2016-09-18 18:38:30 --> Database Driver Class Initialized
DEBUG - 2016-09-18 18:38:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 18:38:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 18:38:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 18:38:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tarik_tabungan.php
DEBUG - 2016-09-18 18:38:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 18:38:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 18:38:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 18:38:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 18:38:31 --> Final output sent to browser
DEBUG - 2016-09-18 18:38:31 --> Total execution time: 1.0071
INFO - 2016-09-18 18:38:35 --> Config Class Initialized
INFO - 2016-09-18 18:38:35 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:38:35 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:38:35 --> Utf8 Class Initialized
INFO - 2016-09-18 18:38:35 --> URI Class Initialized
INFO - 2016-09-18 18:38:35 --> Router Class Initialized
INFO - 2016-09-18 18:38:35 --> Output Class Initialized
INFO - 2016-09-18 18:38:35 --> Security Class Initialized
DEBUG - 2016-09-18 18:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:38:35 --> Input Class Initialized
INFO - 2016-09-18 18:38:35 --> Language Class Initialized
INFO - 2016-09-18 18:38:35 --> Language Class Initialized
INFO - 2016-09-18 18:38:35 --> Config Class Initialized
INFO - 2016-09-18 18:38:35 --> Loader Class Initialized
INFO - 2016-09-18 18:38:35 --> Helper loaded: url_helper
INFO - 2016-09-18 18:38:35 --> Database Driver Class Initialized
INFO - 2016-09-18 18:38:35 --> Controller Class Initialized
DEBUG - 2016-09-18 18:38:35 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:38:36 --> Model Class Initialized
INFO - 2016-09-18 18:38:36 --> Model Class Initialized
DEBUG - 2016-09-18 18:38:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 18:38:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 18:38:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 18:38:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tabungan.php
DEBUG - 2016-09-18 18:38:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 18:38:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 18:38:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 18:38:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 18:38:36 --> Final output sent to browser
DEBUG - 2016-09-18 18:38:36 --> Total execution time: 1.0797
INFO - 2016-09-18 18:38:40 --> Config Class Initialized
INFO - 2016-09-18 18:38:40 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:38:40 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:38:40 --> Utf8 Class Initialized
INFO - 2016-09-18 18:38:40 --> URI Class Initialized
INFO - 2016-09-18 18:38:40 --> Router Class Initialized
INFO - 2016-09-18 18:38:40 --> Output Class Initialized
INFO - 2016-09-18 18:38:40 --> Security Class Initialized
DEBUG - 2016-09-18 18:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:38:40 --> Input Class Initialized
INFO - 2016-09-18 18:38:40 --> Language Class Initialized
INFO - 2016-09-18 18:38:40 --> Language Class Initialized
INFO - 2016-09-18 18:38:41 --> Config Class Initialized
INFO - 2016-09-18 18:38:41 --> Loader Class Initialized
INFO - 2016-09-18 18:38:41 --> Helper loaded: url_helper
INFO - 2016-09-18 18:38:41 --> Database Driver Class Initialized
INFO - 2016-09-18 18:38:41 --> Controller Class Initialized
DEBUG - 2016-09-18 18:38:41 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:38:41 --> Model Class Initialized
INFO - 2016-09-18 18:38:41 --> Model Class Initialized
INFO - 2016-09-18 18:38:41 --> Database Driver Class Initialized
INFO - 2016-09-18 18:38:41 --> Final output sent to browser
DEBUG - 2016-09-18 18:38:41 --> Total execution time: 0.8186
INFO - 2016-09-18 18:38:44 --> Config Class Initialized
INFO - 2016-09-18 18:38:44 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:38:44 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:38:44 --> Utf8 Class Initialized
INFO - 2016-09-18 18:38:44 --> URI Class Initialized
INFO - 2016-09-18 18:38:44 --> Router Class Initialized
INFO - 2016-09-18 18:38:44 --> Output Class Initialized
INFO - 2016-09-18 18:38:44 --> Security Class Initialized
DEBUG - 2016-09-18 18:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:38:44 --> Input Class Initialized
INFO - 2016-09-18 18:38:44 --> Language Class Initialized
INFO - 2016-09-18 18:38:44 --> Language Class Initialized
INFO - 2016-09-18 18:38:44 --> Config Class Initialized
INFO - 2016-09-18 18:38:44 --> Loader Class Initialized
INFO - 2016-09-18 18:38:44 --> Helper loaded: url_helper
INFO - 2016-09-18 18:38:44 --> Database Driver Class Initialized
INFO - 2016-09-18 18:38:44 --> Controller Class Initialized
DEBUG - 2016-09-18 18:38:44 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:38:44 --> Model Class Initialized
INFO - 2016-09-18 18:38:45 --> Model Class Initialized
INFO - 2016-09-18 18:38:45 --> Database Driver Class Initialized
INFO - 2016-09-18 18:38:45 --> Final output sent to browser
DEBUG - 2016-09-18 18:38:45 --> Total execution time: 0.6764
INFO - 2016-09-18 18:38:47 --> Config Class Initialized
INFO - 2016-09-18 18:38:47 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:38:47 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:38:47 --> Utf8 Class Initialized
INFO - 2016-09-18 18:38:47 --> URI Class Initialized
INFO - 2016-09-18 18:38:47 --> Router Class Initialized
INFO - 2016-09-18 18:38:47 --> Output Class Initialized
INFO - 2016-09-18 18:38:47 --> Security Class Initialized
DEBUG - 2016-09-18 18:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:38:47 --> Input Class Initialized
INFO - 2016-09-18 18:38:47 --> Language Class Initialized
INFO - 2016-09-18 18:38:47 --> Language Class Initialized
INFO - 2016-09-18 18:38:47 --> Config Class Initialized
INFO - 2016-09-18 18:38:47 --> Loader Class Initialized
INFO - 2016-09-18 18:38:47 --> Helper loaded: url_helper
INFO - 2016-09-18 18:38:47 --> Database Driver Class Initialized
INFO - 2016-09-18 18:38:47 --> Controller Class Initialized
DEBUG - 2016-09-18 18:38:47 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:38:47 --> Model Class Initialized
INFO - 2016-09-18 18:38:48 --> Model Class Initialized
INFO - 2016-09-18 18:38:48 --> Database Driver Class Initialized
DEBUG - 2016-09-18 18:38:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 18:38:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 18:38:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 18:38:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_simpan_tabungan.php
DEBUG - 2016-09-18 18:38:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 18:38:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 18:38:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 18:38:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 18:38:48 --> Final output sent to browser
DEBUG - 2016-09-18 18:38:48 --> Total execution time: 1.0010
INFO - 2016-09-18 18:38:55 --> Config Class Initialized
INFO - 2016-09-18 18:38:55 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:38:55 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:38:55 --> Utf8 Class Initialized
INFO - 2016-09-18 18:38:55 --> URI Class Initialized
INFO - 2016-09-18 18:38:55 --> Router Class Initialized
INFO - 2016-09-18 18:38:55 --> Output Class Initialized
INFO - 2016-09-18 18:38:55 --> Security Class Initialized
DEBUG - 2016-09-18 18:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:38:55 --> Input Class Initialized
INFO - 2016-09-18 18:38:55 --> Language Class Initialized
INFO - 2016-09-18 18:38:55 --> Language Class Initialized
INFO - 2016-09-18 18:38:55 --> Config Class Initialized
INFO - 2016-09-18 18:38:55 --> Loader Class Initialized
INFO - 2016-09-18 18:38:55 --> Helper loaded: url_helper
INFO - 2016-09-18 18:38:56 --> Database Driver Class Initialized
INFO - 2016-09-18 18:38:56 --> Controller Class Initialized
DEBUG - 2016-09-18 18:38:56 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:38:56 --> Model Class Initialized
INFO - 2016-09-18 18:38:56 --> Model Class Initialized
INFO - 2016-09-18 18:38:56 --> Database Driver Class Initialized
INFO - 2016-09-18 18:38:56 --> Database Driver Class Initialized
INFO - 2016-09-18 18:38:56 --> Database Driver Class Initialized
INFO - 2016-09-18 18:38:56 --> Final output sent to browser
DEBUG - 2016-09-18 18:38:56 --> Total execution time: 1.0081
INFO - 2016-09-18 18:39:01 --> Config Class Initialized
INFO - 2016-09-18 18:39:01 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:39:01 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:39:01 --> Utf8 Class Initialized
INFO - 2016-09-18 18:39:01 --> URI Class Initialized
INFO - 2016-09-18 18:39:01 --> Router Class Initialized
INFO - 2016-09-18 18:39:01 --> Output Class Initialized
INFO - 2016-09-18 18:39:01 --> Security Class Initialized
DEBUG - 2016-09-18 18:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:39:01 --> Input Class Initialized
INFO - 2016-09-18 18:39:01 --> Language Class Initialized
INFO - 2016-09-18 18:39:01 --> Language Class Initialized
INFO - 2016-09-18 18:39:01 --> Config Class Initialized
INFO - 2016-09-18 18:39:01 --> Loader Class Initialized
INFO - 2016-09-18 18:39:01 --> Helper loaded: url_helper
INFO - 2016-09-18 18:39:01 --> Database Driver Class Initialized
INFO - 2016-09-18 18:39:01 --> Controller Class Initialized
DEBUG - 2016-09-18 18:39:01 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:39:02 --> Model Class Initialized
INFO - 2016-09-18 18:39:02 --> Model Class Initialized
DEBUG - 2016-09-18 18:39:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 18:39:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 18:39:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 18:39:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tabungan.php
DEBUG - 2016-09-18 18:39:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 18:39:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 18:39:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 18:39:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 18:39:02 --> Final output sent to browser
DEBUG - 2016-09-18 18:39:02 --> Total execution time: 1.1975
INFO - 2016-09-18 18:39:06 --> Config Class Initialized
INFO - 2016-09-18 18:39:06 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:39:06 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:39:06 --> Utf8 Class Initialized
INFO - 2016-09-18 18:39:06 --> URI Class Initialized
INFO - 2016-09-18 18:39:06 --> Router Class Initialized
INFO - 2016-09-18 18:39:06 --> Output Class Initialized
INFO - 2016-09-18 18:39:06 --> Security Class Initialized
DEBUG - 2016-09-18 18:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:39:06 --> Input Class Initialized
INFO - 2016-09-18 18:39:06 --> Language Class Initialized
INFO - 2016-09-18 18:39:06 --> Language Class Initialized
INFO - 2016-09-18 18:39:06 --> Config Class Initialized
INFO - 2016-09-18 18:39:07 --> Loader Class Initialized
INFO - 2016-09-18 18:39:07 --> Helper loaded: url_helper
INFO - 2016-09-18 18:39:07 --> Database Driver Class Initialized
INFO - 2016-09-18 18:39:07 --> Controller Class Initialized
DEBUG - 2016-09-18 18:39:07 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:39:07 --> Model Class Initialized
INFO - 2016-09-18 18:39:07 --> Model Class Initialized
INFO - 2016-09-18 18:39:07 --> Database Driver Class Initialized
INFO - 2016-09-18 18:39:07 --> Final output sent to browser
DEBUG - 2016-09-18 18:39:07 --> Total execution time: 0.7730
INFO - 2016-09-18 18:39:11 --> Config Class Initialized
INFO - 2016-09-18 18:39:11 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:39:11 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:39:11 --> Utf8 Class Initialized
INFO - 2016-09-18 18:39:11 --> URI Class Initialized
INFO - 2016-09-18 18:39:11 --> Router Class Initialized
INFO - 2016-09-18 18:39:11 --> Output Class Initialized
INFO - 2016-09-18 18:39:11 --> Security Class Initialized
DEBUG - 2016-09-18 18:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:39:11 --> Input Class Initialized
INFO - 2016-09-18 18:39:11 --> Language Class Initialized
INFO - 2016-09-18 18:39:11 --> Language Class Initialized
INFO - 2016-09-18 18:39:11 --> Config Class Initialized
INFO - 2016-09-18 18:39:11 --> Loader Class Initialized
INFO - 2016-09-18 18:39:11 --> Helper loaded: url_helper
INFO - 2016-09-18 18:39:11 --> Database Driver Class Initialized
INFO - 2016-09-18 18:39:11 --> Controller Class Initialized
DEBUG - 2016-09-18 18:39:11 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:39:11 --> Model Class Initialized
INFO - 2016-09-18 18:39:11 --> Model Class Initialized
INFO - 2016-09-18 18:39:11 --> Database Driver Class Initialized
INFO - 2016-09-18 18:39:11 --> Final output sent to browser
DEBUG - 2016-09-18 18:39:11 --> Total execution time: 0.6687
INFO - 2016-09-18 18:44:29 --> Config Class Initialized
INFO - 2016-09-18 18:44:29 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:44:29 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:44:29 --> Utf8 Class Initialized
INFO - 2016-09-18 18:44:29 --> URI Class Initialized
INFO - 2016-09-18 18:44:29 --> Router Class Initialized
INFO - 2016-09-18 18:44:29 --> Output Class Initialized
INFO - 2016-09-18 18:44:29 --> Security Class Initialized
DEBUG - 2016-09-18 18:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:44:29 --> Input Class Initialized
INFO - 2016-09-18 18:44:29 --> Language Class Initialized
INFO - 2016-09-18 18:44:29 --> Language Class Initialized
INFO - 2016-09-18 18:44:29 --> Config Class Initialized
INFO - 2016-09-18 18:44:29 --> Loader Class Initialized
INFO - 2016-09-18 18:44:29 --> Helper loaded: url_helper
INFO - 2016-09-18 18:44:29 --> Database Driver Class Initialized
INFO - 2016-09-18 18:44:29 --> Controller Class Initialized
DEBUG - 2016-09-18 18:44:29 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:44:29 --> Model Class Initialized
INFO - 2016-09-18 18:44:29 --> Model Class Initialized
DEBUG - 2016-09-18 18:44:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 18:44:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 18:44:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 18:44:29 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-18 18:44:29 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-18 18:44:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-18 18:44:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 18:44:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 18:44:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 18:44:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 18:44:30 --> Final output sent to browser
DEBUG - 2016-09-18 18:44:30 --> Total execution time: 0.9988
INFO - 2016-09-18 18:48:41 --> Config Class Initialized
INFO - 2016-09-18 18:48:41 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:48:41 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:48:41 --> Utf8 Class Initialized
INFO - 2016-09-18 18:48:41 --> URI Class Initialized
INFO - 2016-09-18 18:48:41 --> Router Class Initialized
INFO - 2016-09-18 18:48:41 --> Output Class Initialized
INFO - 2016-09-18 18:48:41 --> Security Class Initialized
DEBUG - 2016-09-18 18:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:48:41 --> Input Class Initialized
INFO - 2016-09-18 18:48:41 --> Language Class Initialized
INFO - 2016-09-18 18:48:41 --> Language Class Initialized
INFO - 2016-09-18 18:48:41 --> Config Class Initialized
INFO - 2016-09-18 18:48:41 --> Loader Class Initialized
INFO - 2016-09-18 18:48:41 --> Helper loaded: url_helper
INFO - 2016-09-18 18:48:41 --> Database Driver Class Initialized
INFO - 2016-09-18 18:48:41 --> Controller Class Initialized
DEBUG - 2016-09-18 18:48:41 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:48:41 --> Model Class Initialized
INFO - 2016-09-18 18:48:41 --> Model Class Initialized
DEBUG - 2016-09-18 18:48:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 18:48:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 18:48:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 18:48:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_biaya.php
DEBUG - 2016-09-18 18:48:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 18:48:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 18:48:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 18:48:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 18:48:42 --> Final output sent to browser
DEBUG - 2016-09-18 18:48:42 --> Total execution time: 1.0349
INFO - 2016-09-18 18:49:16 --> Config Class Initialized
INFO - 2016-09-18 18:49:16 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:49:16 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:49:16 --> Utf8 Class Initialized
INFO - 2016-09-18 18:49:16 --> URI Class Initialized
INFO - 2016-09-18 18:49:16 --> Router Class Initialized
INFO - 2016-09-18 18:49:16 --> Output Class Initialized
INFO - 2016-09-18 18:49:16 --> Security Class Initialized
DEBUG - 2016-09-18 18:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:49:16 --> Input Class Initialized
INFO - 2016-09-18 18:49:16 --> Language Class Initialized
INFO - 2016-09-18 18:49:16 --> Language Class Initialized
INFO - 2016-09-18 18:49:16 --> Config Class Initialized
INFO - 2016-09-18 18:49:16 --> Loader Class Initialized
INFO - 2016-09-18 18:49:16 --> Helper loaded: url_helper
INFO - 2016-09-18 18:49:16 --> Database Driver Class Initialized
INFO - 2016-09-18 18:49:16 --> Controller Class Initialized
DEBUG - 2016-09-18 18:49:16 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:49:16 --> Model Class Initialized
INFO - 2016-09-18 18:49:16 --> Model Class Initialized
DEBUG - 2016-09-18 18:49:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 18:49:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 18:49:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
ERROR - 2016-09-18 18:49:17 --> Severity: Notice --> Undefined variable: i E:\SERVER\htdocs\koperasiweda\application\views\main_html\content\list_biaya.php 31
DEBUG - 2016-09-18 18:49:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_biaya.php
DEBUG - 2016-09-18 18:49:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 18:49:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 18:49:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 18:49:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 18:49:17 --> Final output sent to browser
DEBUG - 2016-09-18 18:49:17 --> Total execution time: 1.0884
INFO - 2016-09-18 18:49:26 --> Config Class Initialized
INFO - 2016-09-18 18:49:26 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:49:26 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:49:26 --> Utf8 Class Initialized
INFO - 2016-09-18 18:49:26 --> URI Class Initialized
INFO - 2016-09-18 18:49:26 --> Router Class Initialized
INFO - 2016-09-18 18:49:26 --> Output Class Initialized
INFO - 2016-09-18 18:49:26 --> Security Class Initialized
DEBUG - 2016-09-18 18:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:49:26 --> Input Class Initialized
INFO - 2016-09-18 18:49:26 --> Language Class Initialized
INFO - 2016-09-18 18:49:26 --> Language Class Initialized
INFO - 2016-09-18 18:49:26 --> Config Class Initialized
INFO - 2016-09-18 18:49:26 --> Loader Class Initialized
INFO - 2016-09-18 18:49:26 --> Helper loaded: url_helper
INFO - 2016-09-18 18:49:26 --> Database Driver Class Initialized
INFO - 2016-09-18 18:49:27 --> Controller Class Initialized
DEBUG - 2016-09-18 18:49:27 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:49:27 --> Model Class Initialized
INFO - 2016-09-18 18:49:27 --> Model Class Initialized
DEBUG - 2016-09-18 18:49:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 18:49:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 18:49:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 18:49:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_biaya.php
DEBUG - 2016-09-18 18:49:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 18:49:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 18:49:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 18:49:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 18:49:27 --> Final output sent to browser
DEBUG - 2016-09-18 18:49:27 --> Total execution time: 1.1101
INFO - 2016-09-18 18:49:36 --> Config Class Initialized
INFO - 2016-09-18 18:49:36 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:49:36 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:49:36 --> Utf8 Class Initialized
INFO - 2016-09-18 18:49:36 --> URI Class Initialized
INFO - 2016-09-18 18:49:36 --> Router Class Initialized
INFO - 2016-09-18 18:49:36 --> Output Class Initialized
INFO - 2016-09-18 18:49:36 --> Security Class Initialized
DEBUG - 2016-09-18 18:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:49:37 --> Input Class Initialized
INFO - 2016-09-18 18:49:37 --> Language Class Initialized
INFO - 2016-09-18 18:49:37 --> Language Class Initialized
INFO - 2016-09-18 18:49:37 --> Config Class Initialized
INFO - 2016-09-18 18:49:37 --> Loader Class Initialized
INFO - 2016-09-18 18:49:37 --> Helper loaded: url_helper
INFO - 2016-09-18 18:49:37 --> Database Driver Class Initialized
INFO - 2016-09-18 18:49:37 --> Controller Class Initialized
DEBUG - 2016-09-18 18:49:37 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:49:37 --> Model Class Initialized
INFO - 2016-09-18 18:49:37 --> Model Class Initialized
DEBUG - 2016-09-18 18:49:37 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-18 18:49:37 --> Users MX_Controller Initialized
ERROR - 2016-09-18 18:49:37 --> Severity: Notice --> Undefined variable: item E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 116
INFO - 2016-09-18 18:49:37 --> Final output sent to browser
DEBUG - 2016-09-18 18:49:37 --> Total execution time: 1.1555
INFO - 2016-09-18 18:55:54 --> Config Class Initialized
INFO - 2016-09-18 18:55:54 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:55:54 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:55:54 --> Utf8 Class Initialized
INFO - 2016-09-18 18:55:54 --> URI Class Initialized
INFO - 2016-09-18 18:55:54 --> Router Class Initialized
INFO - 2016-09-18 18:55:54 --> Output Class Initialized
INFO - 2016-09-18 18:55:54 --> Security Class Initialized
DEBUG - 2016-09-18 18:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:55:54 --> Input Class Initialized
INFO - 2016-09-18 18:55:54 --> Language Class Initialized
INFO - 2016-09-18 18:55:54 --> Language Class Initialized
INFO - 2016-09-18 18:55:54 --> Config Class Initialized
INFO - 2016-09-18 18:55:54 --> Loader Class Initialized
INFO - 2016-09-18 18:55:54 --> Helper loaded: url_helper
INFO - 2016-09-18 18:55:54 --> Database Driver Class Initialized
INFO - 2016-09-18 18:55:54 --> Controller Class Initialized
DEBUG - 2016-09-18 18:55:54 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:55:54 --> Model Class Initialized
INFO - 2016-09-18 18:55:54 --> Model Class Initialized
DEBUG - 2016-09-18 18:55:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 18:55:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 18:55:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 18:55:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_biaya.php
DEBUG - 2016-09-18 18:55:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 18:55:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 18:55:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 18:55:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 18:55:55 --> Final output sent to browser
DEBUG - 2016-09-18 18:55:55 --> Total execution time: 0.9920
INFO - 2016-09-18 18:56:00 --> Config Class Initialized
INFO - 2016-09-18 18:56:00 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:56:00 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:56:00 --> Utf8 Class Initialized
INFO - 2016-09-18 18:56:01 --> URI Class Initialized
INFO - 2016-09-18 18:56:01 --> Router Class Initialized
INFO - 2016-09-18 18:56:01 --> Output Class Initialized
INFO - 2016-09-18 18:56:01 --> Security Class Initialized
DEBUG - 2016-09-18 18:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:56:01 --> Input Class Initialized
INFO - 2016-09-18 18:56:01 --> Language Class Initialized
INFO - 2016-09-18 18:56:01 --> Language Class Initialized
INFO - 2016-09-18 18:56:01 --> Config Class Initialized
INFO - 2016-09-18 18:56:01 --> Loader Class Initialized
INFO - 2016-09-18 18:56:01 --> Helper loaded: url_helper
INFO - 2016-09-18 18:56:01 --> Database Driver Class Initialized
INFO - 2016-09-18 18:56:01 --> Controller Class Initialized
DEBUG - 2016-09-18 18:56:01 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:56:01 --> Model Class Initialized
INFO - 2016-09-18 18:56:01 --> Model Class Initialized
DEBUG - 2016-09-18 18:56:01 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-18 18:56:01 --> Users MX_Controller Initialized
INFO - 2016-09-18 18:56:01 --> Final output sent to browser
DEBUG - 2016-09-18 18:56:01 --> Total execution time: 1.0130
INFO - 2016-09-18 18:56:04 --> Config Class Initialized
INFO - 2016-09-18 18:56:04 --> Hooks Class Initialized
DEBUG - 2016-09-18 18:56:04 --> UTF-8 Support Enabled
INFO - 2016-09-18 18:56:04 --> Utf8 Class Initialized
INFO - 2016-09-18 18:56:04 --> URI Class Initialized
INFO - 2016-09-18 18:56:04 --> Router Class Initialized
INFO - 2016-09-18 18:56:05 --> Output Class Initialized
INFO - 2016-09-18 18:56:05 --> Security Class Initialized
DEBUG - 2016-09-18 18:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 18:56:05 --> Input Class Initialized
INFO - 2016-09-18 18:56:05 --> Language Class Initialized
INFO - 2016-09-18 18:56:05 --> Language Class Initialized
INFO - 2016-09-18 18:56:05 --> Config Class Initialized
INFO - 2016-09-18 18:56:05 --> Loader Class Initialized
INFO - 2016-09-18 18:56:05 --> Helper loaded: url_helper
INFO - 2016-09-18 18:56:05 --> Database Driver Class Initialized
INFO - 2016-09-18 18:56:05 --> Controller Class Initialized
DEBUG - 2016-09-18 18:56:05 --> Index MX_Controller Initialized
INFO - 2016-09-18 18:56:05 --> Model Class Initialized
INFO - 2016-09-18 18:56:05 --> Model Class Initialized
DEBUG - 2016-09-18 18:56:05 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-18 18:56:05 --> Users MX_Controller Initialized
INFO - 2016-09-18 18:56:05 --> Final output sent to browser
DEBUG - 2016-09-18 18:56:05 --> Total execution time: 1.1576
INFO - 2016-09-18 19:01:19 --> Config Class Initialized
INFO - 2016-09-18 19:01:19 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:01:19 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:01:19 --> Utf8 Class Initialized
INFO - 2016-09-18 19:01:19 --> URI Class Initialized
INFO - 2016-09-18 19:01:19 --> Router Class Initialized
INFO - 2016-09-18 19:01:19 --> Output Class Initialized
INFO - 2016-09-18 19:01:19 --> Security Class Initialized
DEBUG - 2016-09-18 19:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:01:19 --> Input Class Initialized
INFO - 2016-09-18 19:01:19 --> Language Class Initialized
ERROR - 2016-09-18 19:01:19 --> Severity: Parsing Error --> syntax error, unexpected ')' E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 63
INFO - 2016-09-18 19:01:41 --> Config Class Initialized
INFO - 2016-09-18 19:01:41 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:01:41 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:01:41 --> Utf8 Class Initialized
INFO - 2016-09-18 19:01:41 --> URI Class Initialized
INFO - 2016-09-18 19:01:41 --> Router Class Initialized
INFO - 2016-09-18 19:01:42 --> Output Class Initialized
INFO - 2016-09-18 19:01:42 --> Security Class Initialized
DEBUG - 2016-09-18 19:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:01:42 --> Input Class Initialized
INFO - 2016-09-18 19:01:42 --> Language Class Initialized
INFO - 2016-09-18 19:01:42 --> Language Class Initialized
INFO - 2016-09-18 19:01:42 --> Config Class Initialized
INFO - 2016-09-18 19:01:42 --> Loader Class Initialized
INFO - 2016-09-18 19:01:42 --> Helper loaded: url_helper
INFO - 2016-09-18 19:01:42 --> Database Driver Class Initialized
INFO - 2016-09-18 19:01:42 --> Controller Class Initialized
DEBUG - 2016-09-18 19:01:42 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:01:42 --> Model Class Initialized
INFO - 2016-09-18 19:01:42 --> Model Class Initialized
DEBUG - 2016-09-18 19:01:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 19:01:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 19:01:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 19:01:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_biaya.php
DEBUG - 2016-09-18 19:01:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 19:01:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 19:01:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 19:01:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 19:01:43 --> Final output sent to browser
DEBUG - 2016-09-18 19:01:43 --> Total execution time: 1.3117
INFO - 2016-09-18 19:01:47 --> Config Class Initialized
INFO - 2016-09-18 19:01:47 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:01:47 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:01:48 --> Utf8 Class Initialized
INFO - 2016-09-18 19:01:48 --> URI Class Initialized
INFO - 2016-09-18 19:01:48 --> Router Class Initialized
INFO - 2016-09-18 19:01:48 --> Output Class Initialized
INFO - 2016-09-18 19:01:48 --> Security Class Initialized
DEBUG - 2016-09-18 19:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:01:48 --> Input Class Initialized
INFO - 2016-09-18 19:01:48 --> Language Class Initialized
INFO - 2016-09-18 19:01:48 --> Language Class Initialized
INFO - 2016-09-18 19:01:48 --> Config Class Initialized
INFO - 2016-09-18 19:01:48 --> Loader Class Initialized
INFO - 2016-09-18 19:01:48 --> Helper loaded: url_helper
INFO - 2016-09-18 19:01:48 --> Database Driver Class Initialized
INFO - 2016-09-18 19:01:48 --> Controller Class Initialized
DEBUG - 2016-09-18 19:01:48 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:01:48 --> Model Class Initialized
INFO - 2016-09-18 19:01:48 --> Model Class Initialized
DEBUG - 2016-09-18 19:01:48 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-18 19:01:49 --> Users MX_Controller Initialized
INFO - 2016-09-18 19:01:49 --> Final output sent to browser
DEBUG - 2016-09-18 19:01:49 --> Total execution time: 1.2766
INFO - 2016-09-18 19:01:58 --> Config Class Initialized
INFO - 2016-09-18 19:01:58 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:01:58 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:01:58 --> Utf8 Class Initialized
INFO - 2016-09-18 19:01:58 --> URI Class Initialized
INFO - 2016-09-18 19:01:58 --> Router Class Initialized
INFO - 2016-09-18 19:01:58 --> Output Class Initialized
INFO - 2016-09-18 19:01:58 --> Security Class Initialized
DEBUG - 2016-09-18 19:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:01:58 --> Input Class Initialized
INFO - 2016-09-18 19:01:58 --> Language Class Initialized
INFO - 2016-09-18 19:01:58 --> Language Class Initialized
INFO - 2016-09-18 19:01:58 --> Config Class Initialized
INFO - 2016-09-18 19:01:58 --> Loader Class Initialized
INFO - 2016-09-18 19:01:58 --> Helper loaded: url_helper
INFO - 2016-09-18 19:01:58 --> Database Driver Class Initialized
INFO - 2016-09-18 19:01:58 --> Controller Class Initialized
DEBUG - 2016-09-18 19:01:58 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:01:58 --> Model Class Initialized
INFO - 2016-09-18 19:01:58 --> Model Class Initialized
DEBUG - 2016-09-18 19:01:58 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-18 19:01:58 --> Users MX_Controller Initialized
INFO - 2016-09-18 19:01:59 --> Final output sent to browser
DEBUG - 2016-09-18 19:01:59 --> Total execution time: 0.9436
INFO - 2016-09-18 19:02:06 --> Config Class Initialized
INFO - 2016-09-18 19:02:06 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:02:06 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:02:06 --> Utf8 Class Initialized
INFO - 2016-09-18 19:02:06 --> URI Class Initialized
INFO - 2016-09-18 19:02:06 --> Router Class Initialized
INFO - 2016-09-18 19:02:06 --> Output Class Initialized
INFO - 2016-09-18 19:02:06 --> Security Class Initialized
DEBUG - 2016-09-18 19:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:02:06 --> Input Class Initialized
INFO - 2016-09-18 19:02:06 --> Language Class Initialized
INFO - 2016-09-18 19:02:06 --> Language Class Initialized
INFO - 2016-09-18 19:02:06 --> Config Class Initialized
INFO - 2016-09-18 19:02:06 --> Loader Class Initialized
INFO - 2016-09-18 19:02:06 --> Helper loaded: url_helper
INFO - 2016-09-18 19:02:06 --> Database Driver Class Initialized
INFO - 2016-09-18 19:02:07 --> Controller Class Initialized
DEBUG - 2016-09-18 19:02:07 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:02:07 --> Model Class Initialized
INFO - 2016-09-18 19:02:07 --> Model Class Initialized
DEBUG - 2016-09-18 19:02:07 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-18 19:02:07 --> Users MX_Controller Initialized
INFO - 2016-09-18 19:02:07 --> Final output sent to browser
DEBUG - 2016-09-18 19:02:07 --> Total execution time: 1.0975
INFO - 2016-09-18 19:02:12 --> Config Class Initialized
INFO - 2016-09-18 19:02:12 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:02:12 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:02:12 --> Utf8 Class Initialized
INFO - 2016-09-18 19:02:12 --> URI Class Initialized
INFO - 2016-09-18 19:02:12 --> Router Class Initialized
INFO - 2016-09-18 19:02:12 --> Output Class Initialized
INFO - 2016-09-18 19:02:12 --> Security Class Initialized
DEBUG - 2016-09-18 19:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:02:12 --> Input Class Initialized
INFO - 2016-09-18 19:02:12 --> Language Class Initialized
INFO - 2016-09-18 19:02:12 --> Language Class Initialized
INFO - 2016-09-18 19:02:12 --> Config Class Initialized
INFO - 2016-09-18 19:02:12 --> Loader Class Initialized
INFO - 2016-09-18 19:02:12 --> Helper loaded: url_helper
INFO - 2016-09-18 19:02:12 --> Database Driver Class Initialized
INFO - 2016-09-18 19:02:12 --> Controller Class Initialized
DEBUG - 2016-09-18 19:02:12 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:02:12 --> Model Class Initialized
INFO - 2016-09-18 19:02:12 --> Model Class Initialized
DEBUG - 2016-09-18 19:02:12 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-18 19:02:12 --> Users MX_Controller Initialized
INFO - 2016-09-18 19:02:12 --> Final output sent to browser
DEBUG - 2016-09-18 19:02:12 --> Total execution time: 0.7881
INFO - 2016-09-18 19:02:18 --> Config Class Initialized
INFO - 2016-09-18 19:02:18 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:02:18 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:02:18 --> Utf8 Class Initialized
INFO - 2016-09-18 19:02:18 --> URI Class Initialized
INFO - 2016-09-18 19:02:18 --> Router Class Initialized
INFO - 2016-09-18 19:02:18 --> Output Class Initialized
INFO - 2016-09-18 19:02:18 --> Security Class Initialized
DEBUG - 2016-09-18 19:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:02:18 --> Input Class Initialized
INFO - 2016-09-18 19:02:19 --> Language Class Initialized
INFO - 2016-09-18 19:02:19 --> Language Class Initialized
INFO - 2016-09-18 19:02:19 --> Config Class Initialized
INFO - 2016-09-18 19:02:19 --> Loader Class Initialized
INFO - 2016-09-18 19:02:19 --> Helper loaded: url_helper
INFO - 2016-09-18 19:02:19 --> Database Driver Class Initialized
INFO - 2016-09-18 19:02:19 --> Controller Class Initialized
DEBUG - 2016-09-18 19:02:19 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:02:19 --> Model Class Initialized
INFO - 2016-09-18 19:02:19 --> Model Class Initialized
DEBUG - 2016-09-18 19:02:19 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-18 19:02:19 --> Users MX_Controller Initialized
INFO - 2016-09-18 19:02:19 --> Final output sent to browser
DEBUG - 2016-09-18 19:02:19 --> Total execution time: 1.0329
INFO - 2016-09-18 19:02:24 --> Config Class Initialized
INFO - 2016-09-18 19:02:24 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:02:24 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:02:24 --> Utf8 Class Initialized
INFO - 2016-09-18 19:02:24 --> URI Class Initialized
INFO - 2016-09-18 19:02:24 --> Router Class Initialized
INFO - 2016-09-18 19:02:24 --> Output Class Initialized
INFO - 2016-09-18 19:02:24 --> Security Class Initialized
DEBUG - 2016-09-18 19:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:02:24 --> Input Class Initialized
INFO - 2016-09-18 19:02:24 --> Language Class Initialized
INFO - 2016-09-18 19:02:24 --> Language Class Initialized
INFO - 2016-09-18 19:02:24 --> Config Class Initialized
INFO - 2016-09-18 19:02:24 --> Loader Class Initialized
INFO - 2016-09-18 19:02:24 --> Helper loaded: url_helper
INFO - 2016-09-18 19:02:24 --> Database Driver Class Initialized
INFO - 2016-09-18 19:02:24 --> Controller Class Initialized
DEBUG - 2016-09-18 19:02:24 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:02:24 --> Model Class Initialized
INFO - 2016-09-18 19:02:24 --> Model Class Initialized
DEBUG - 2016-09-18 19:02:24 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-18 19:02:24 --> Users MX_Controller Initialized
INFO - 2016-09-18 19:02:25 --> Final output sent to browser
DEBUG - 2016-09-18 19:02:25 --> Total execution time: 0.7948
INFO - 2016-09-18 19:02:26 --> Config Class Initialized
INFO - 2016-09-18 19:02:26 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:02:26 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:02:27 --> Utf8 Class Initialized
INFO - 2016-09-18 19:02:27 --> URI Class Initialized
INFO - 2016-09-18 19:02:27 --> Router Class Initialized
INFO - 2016-09-18 19:02:27 --> Output Class Initialized
INFO - 2016-09-18 19:02:27 --> Security Class Initialized
DEBUG - 2016-09-18 19:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:02:27 --> Input Class Initialized
INFO - 2016-09-18 19:02:27 --> Language Class Initialized
INFO - 2016-09-18 19:02:27 --> Language Class Initialized
INFO - 2016-09-18 19:02:27 --> Config Class Initialized
INFO - 2016-09-18 19:02:27 --> Loader Class Initialized
INFO - 2016-09-18 19:02:27 --> Helper loaded: url_helper
INFO - 2016-09-18 19:02:27 --> Database Driver Class Initialized
INFO - 2016-09-18 19:02:27 --> Controller Class Initialized
DEBUG - 2016-09-18 19:02:27 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:02:27 --> Model Class Initialized
INFO - 2016-09-18 19:02:27 --> Model Class Initialized
DEBUG - 2016-09-18 19:02:27 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-18 19:02:27 --> Users MX_Controller Initialized
INFO - 2016-09-18 19:02:28 --> Final output sent to browser
DEBUG - 2016-09-18 19:02:28 --> Total execution time: 1.1343
INFO - 2016-09-18 19:02:29 --> Config Class Initialized
INFO - 2016-09-18 19:02:29 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:02:29 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:02:29 --> Utf8 Class Initialized
INFO - 2016-09-18 19:02:29 --> URI Class Initialized
INFO - 2016-09-18 19:02:29 --> Router Class Initialized
INFO - 2016-09-18 19:02:29 --> Output Class Initialized
INFO - 2016-09-18 19:02:29 --> Security Class Initialized
DEBUG - 2016-09-18 19:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:02:29 --> Input Class Initialized
INFO - 2016-09-18 19:02:30 --> Language Class Initialized
INFO - 2016-09-18 19:02:30 --> Language Class Initialized
INFO - 2016-09-18 19:02:30 --> Config Class Initialized
INFO - 2016-09-18 19:02:30 --> Loader Class Initialized
INFO - 2016-09-18 19:02:30 --> Helper loaded: url_helper
INFO - 2016-09-18 19:02:30 --> Database Driver Class Initialized
INFO - 2016-09-18 19:02:30 --> Controller Class Initialized
DEBUG - 2016-09-18 19:02:30 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:02:30 --> Model Class Initialized
INFO - 2016-09-18 19:02:30 --> Model Class Initialized
DEBUG - 2016-09-18 19:02:30 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-18 19:02:30 --> Users MX_Controller Initialized
INFO - 2016-09-18 19:02:30 --> Final output sent to browser
DEBUG - 2016-09-18 19:02:30 --> Total execution time: 0.8717
INFO - 2016-09-18 19:02:32 --> Config Class Initialized
INFO - 2016-09-18 19:02:32 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:02:32 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:02:32 --> Utf8 Class Initialized
INFO - 2016-09-18 19:02:32 --> URI Class Initialized
INFO - 2016-09-18 19:02:32 --> Router Class Initialized
INFO - 2016-09-18 19:02:32 --> Output Class Initialized
INFO - 2016-09-18 19:02:32 --> Security Class Initialized
DEBUG - 2016-09-18 19:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:02:32 --> Input Class Initialized
INFO - 2016-09-18 19:02:32 --> Language Class Initialized
INFO - 2016-09-18 19:02:32 --> Language Class Initialized
INFO - 2016-09-18 19:02:32 --> Config Class Initialized
INFO - 2016-09-18 19:02:33 --> Loader Class Initialized
INFO - 2016-09-18 19:02:33 --> Helper loaded: url_helper
INFO - 2016-09-18 19:02:33 --> Database Driver Class Initialized
INFO - 2016-09-18 19:02:33 --> Controller Class Initialized
DEBUG - 2016-09-18 19:02:33 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:02:33 --> Model Class Initialized
INFO - 2016-09-18 19:02:33 --> Model Class Initialized
DEBUG - 2016-09-18 19:02:33 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-18 19:02:33 --> Users MX_Controller Initialized
INFO - 2016-09-18 19:02:33 --> Final output sent to browser
DEBUG - 2016-09-18 19:02:33 --> Total execution time: 0.9964
INFO - 2016-09-18 19:02:39 --> Config Class Initialized
INFO - 2016-09-18 19:02:39 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:02:39 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:02:39 --> Utf8 Class Initialized
INFO - 2016-09-18 19:02:39 --> URI Class Initialized
INFO - 2016-09-18 19:02:39 --> Router Class Initialized
INFO - 2016-09-18 19:02:39 --> Output Class Initialized
INFO - 2016-09-18 19:02:39 --> Security Class Initialized
DEBUG - 2016-09-18 19:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:02:40 --> Input Class Initialized
INFO - 2016-09-18 19:02:40 --> Language Class Initialized
INFO - 2016-09-18 19:02:40 --> Language Class Initialized
INFO - 2016-09-18 19:02:40 --> Config Class Initialized
INFO - 2016-09-18 19:02:40 --> Loader Class Initialized
INFO - 2016-09-18 19:02:40 --> Helper loaded: url_helper
INFO - 2016-09-18 19:02:40 --> Database Driver Class Initialized
INFO - 2016-09-18 19:02:40 --> Controller Class Initialized
DEBUG - 2016-09-18 19:02:40 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:02:40 --> Model Class Initialized
INFO - 2016-09-18 19:02:40 --> Model Class Initialized
DEBUG - 2016-09-18 19:02:40 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-18 19:02:40 --> Users MX_Controller Initialized
INFO - 2016-09-18 19:02:40 --> Final output sent to browser
DEBUG - 2016-09-18 19:02:40 --> Total execution time: 0.8352
INFO - 2016-09-18 19:05:58 --> Config Class Initialized
INFO - 2016-09-18 19:05:58 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:05:58 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:05:58 --> Utf8 Class Initialized
INFO - 2016-09-18 19:05:59 --> URI Class Initialized
INFO - 2016-09-18 19:05:59 --> Router Class Initialized
INFO - 2016-09-18 19:05:59 --> Output Class Initialized
INFO - 2016-09-18 19:05:59 --> Security Class Initialized
DEBUG - 2016-09-18 19:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:05:59 --> Input Class Initialized
INFO - 2016-09-18 19:05:59 --> Language Class Initialized
INFO - 2016-09-18 19:05:59 --> Language Class Initialized
INFO - 2016-09-18 19:05:59 --> Config Class Initialized
INFO - 2016-09-18 19:05:59 --> Loader Class Initialized
INFO - 2016-09-18 19:05:59 --> Helper loaded: url_helper
INFO - 2016-09-18 19:05:59 --> Database Driver Class Initialized
INFO - 2016-09-18 19:05:59 --> Controller Class Initialized
DEBUG - 2016-09-18 19:05:59 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:05:59 --> Model Class Initialized
INFO - 2016-09-18 19:05:59 --> Model Class Initialized
DEBUG - 2016-09-18 19:05:59 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-18 19:05:59 --> Users MX_Controller Initialized
INFO - 2016-09-18 19:05:59 --> Final output sent to browser
DEBUG - 2016-09-18 19:05:59 --> Total execution time: 1.1072
INFO - 2016-09-18 19:06:29 --> Config Class Initialized
INFO - 2016-09-18 19:06:29 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:06:29 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:06:29 --> Utf8 Class Initialized
INFO - 2016-09-18 19:06:29 --> URI Class Initialized
INFO - 2016-09-18 19:06:29 --> Router Class Initialized
INFO - 2016-09-18 19:06:29 --> Output Class Initialized
INFO - 2016-09-18 19:06:29 --> Security Class Initialized
DEBUG - 2016-09-18 19:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:06:29 --> Input Class Initialized
INFO - 2016-09-18 19:06:30 --> Language Class Initialized
INFO - 2016-09-18 19:06:30 --> Language Class Initialized
INFO - 2016-09-18 19:06:30 --> Config Class Initialized
INFO - 2016-09-18 19:06:30 --> Loader Class Initialized
INFO - 2016-09-18 19:06:30 --> Helper loaded: url_helper
INFO - 2016-09-18 19:06:30 --> Database Driver Class Initialized
INFO - 2016-09-18 19:06:30 --> Controller Class Initialized
DEBUG - 2016-09-18 19:06:30 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:06:30 --> Model Class Initialized
INFO - 2016-09-18 19:06:30 --> Model Class Initialized
DEBUG - 2016-09-18 19:06:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 19:06:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 19:06:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 19:06:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_biaya.php
DEBUG - 2016-09-18 19:06:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 19:06:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 19:06:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 19:06:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 19:06:30 --> Final output sent to browser
DEBUG - 2016-09-18 19:06:30 --> Total execution time: 1.0300
INFO - 2016-09-18 19:06:34 --> Config Class Initialized
INFO - 2016-09-18 19:06:34 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:06:34 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:06:34 --> Utf8 Class Initialized
INFO - 2016-09-18 19:06:34 --> URI Class Initialized
INFO - 2016-09-18 19:06:34 --> Router Class Initialized
INFO - 2016-09-18 19:06:34 --> Output Class Initialized
INFO - 2016-09-18 19:06:34 --> Security Class Initialized
DEBUG - 2016-09-18 19:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:06:34 --> Input Class Initialized
INFO - 2016-09-18 19:06:34 --> Language Class Initialized
INFO - 2016-09-18 19:06:34 --> Language Class Initialized
INFO - 2016-09-18 19:06:34 --> Config Class Initialized
INFO - 2016-09-18 19:06:34 --> Loader Class Initialized
INFO - 2016-09-18 19:06:35 --> Helper loaded: url_helper
INFO - 2016-09-18 19:06:35 --> Database Driver Class Initialized
INFO - 2016-09-18 19:06:35 --> Controller Class Initialized
DEBUG - 2016-09-18 19:06:35 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:06:35 --> Model Class Initialized
INFO - 2016-09-18 19:06:35 --> Model Class Initialized
DEBUG - 2016-09-18 19:06:35 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-18 19:06:35 --> Users MX_Controller Initialized
INFO - 2016-09-18 19:06:35 --> Final output sent to browser
DEBUG - 2016-09-18 19:06:35 --> Total execution time: 1.1158
INFO - 2016-09-18 19:06:39 --> Config Class Initialized
INFO - 2016-09-18 19:06:39 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:06:39 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:06:39 --> Utf8 Class Initialized
INFO - 2016-09-18 19:06:39 --> URI Class Initialized
INFO - 2016-09-18 19:06:39 --> Router Class Initialized
INFO - 2016-09-18 19:06:39 --> Output Class Initialized
INFO - 2016-09-18 19:06:39 --> Security Class Initialized
DEBUG - 2016-09-18 19:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:06:39 --> Input Class Initialized
INFO - 2016-09-18 19:06:39 --> Language Class Initialized
INFO - 2016-09-18 19:06:40 --> Language Class Initialized
INFO - 2016-09-18 19:06:40 --> Config Class Initialized
INFO - 2016-09-18 19:06:40 --> Loader Class Initialized
INFO - 2016-09-18 19:06:40 --> Helper loaded: url_helper
INFO - 2016-09-18 19:06:40 --> Database Driver Class Initialized
INFO - 2016-09-18 19:06:40 --> Controller Class Initialized
DEBUG - 2016-09-18 19:06:40 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:06:40 --> Model Class Initialized
INFO - 2016-09-18 19:06:40 --> Model Class Initialized
DEBUG - 2016-09-18 19:06:40 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-18 19:06:40 --> Users MX_Controller Initialized
INFO - 2016-09-18 19:06:40 --> Final output sent to browser
DEBUG - 2016-09-18 19:06:40 --> Total execution time: 1.0885
INFO - 2016-09-18 19:06:45 --> Config Class Initialized
INFO - 2016-09-18 19:06:45 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:06:45 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:06:45 --> Utf8 Class Initialized
INFO - 2016-09-18 19:06:45 --> URI Class Initialized
INFO - 2016-09-18 19:06:45 --> Router Class Initialized
INFO - 2016-09-18 19:06:45 --> Output Class Initialized
INFO - 2016-09-18 19:06:45 --> Security Class Initialized
DEBUG - 2016-09-18 19:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:06:46 --> Input Class Initialized
INFO - 2016-09-18 19:06:46 --> Language Class Initialized
INFO - 2016-09-18 19:06:46 --> Language Class Initialized
INFO - 2016-09-18 19:06:46 --> Config Class Initialized
INFO - 2016-09-18 19:06:46 --> Loader Class Initialized
INFO - 2016-09-18 19:06:46 --> Helper loaded: url_helper
INFO - 2016-09-18 19:06:46 --> Database Driver Class Initialized
INFO - 2016-09-18 19:06:46 --> Controller Class Initialized
DEBUG - 2016-09-18 19:06:46 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:06:46 --> Model Class Initialized
INFO - 2016-09-18 19:06:46 --> Model Class Initialized
DEBUG - 2016-09-18 19:06:46 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-18 19:06:46 --> Users MX_Controller Initialized
INFO - 2016-09-18 19:06:46 --> Final output sent to browser
DEBUG - 2016-09-18 19:06:46 --> Total execution time: 0.8980
INFO - 2016-09-18 19:06:50 --> Config Class Initialized
INFO - 2016-09-18 19:06:50 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:06:50 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:06:50 --> Utf8 Class Initialized
INFO - 2016-09-18 19:06:50 --> URI Class Initialized
INFO - 2016-09-18 19:06:50 --> Router Class Initialized
INFO - 2016-09-18 19:06:50 --> Output Class Initialized
INFO - 2016-09-18 19:06:51 --> Security Class Initialized
DEBUG - 2016-09-18 19:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:06:51 --> Input Class Initialized
INFO - 2016-09-18 19:06:51 --> Language Class Initialized
INFO - 2016-09-18 19:06:51 --> Language Class Initialized
INFO - 2016-09-18 19:06:51 --> Config Class Initialized
INFO - 2016-09-18 19:06:51 --> Loader Class Initialized
INFO - 2016-09-18 19:06:51 --> Helper loaded: url_helper
INFO - 2016-09-18 19:06:51 --> Database Driver Class Initialized
INFO - 2016-09-18 19:06:51 --> Controller Class Initialized
DEBUG - 2016-09-18 19:06:51 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:06:51 --> Model Class Initialized
INFO - 2016-09-18 19:06:51 --> Model Class Initialized
DEBUG - 2016-09-18 19:06:51 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-18 19:06:51 --> Users MX_Controller Initialized
INFO - 2016-09-18 19:06:51 --> Final output sent to browser
DEBUG - 2016-09-18 19:06:51 --> Total execution time: 1.1186
INFO - 2016-09-18 19:06:54 --> Config Class Initialized
INFO - 2016-09-18 19:06:54 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:06:54 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:06:54 --> Utf8 Class Initialized
INFO - 2016-09-18 19:06:54 --> URI Class Initialized
INFO - 2016-09-18 19:06:54 --> Router Class Initialized
INFO - 2016-09-18 19:06:54 --> Output Class Initialized
INFO - 2016-09-18 19:06:54 --> Security Class Initialized
DEBUG - 2016-09-18 19:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:06:54 --> Input Class Initialized
INFO - 2016-09-18 19:06:54 --> Language Class Initialized
INFO - 2016-09-18 19:06:54 --> Language Class Initialized
INFO - 2016-09-18 19:06:54 --> Config Class Initialized
INFO - 2016-09-18 19:06:54 --> Loader Class Initialized
INFO - 2016-09-18 19:06:54 --> Helper loaded: url_helper
INFO - 2016-09-18 19:06:54 --> Database Driver Class Initialized
INFO - 2016-09-18 19:06:54 --> Controller Class Initialized
DEBUG - 2016-09-18 19:06:54 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:06:54 --> Model Class Initialized
INFO - 2016-09-18 19:06:54 --> Model Class Initialized
DEBUG - 2016-09-18 19:06:54 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-18 19:06:54 --> Users MX_Controller Initialized
INFO - 2016-09-18 19:06:55 --> Final output sent to browser
DEBUG - 2016-09-18 19:06:55 --> Total execution time: 0.8087
INFO - 2016-09-18 19:07:38 --> Config Class Initialized
INFO - 2016-09-18 19:07:38 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:07:38 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:07:38 --> Utf8 Class Initialized
INFO - 2016-09-18 19:07:39 --> URI Class Initialized
INFO - 2016-09-18 19:07:39 --> Router Class Initialized
INFO - 2016-09-18 19:07:39 --> Output Class Initialized
INFO - 2016-09-18 19:07:39 --> Security Class Initialized
DEBUG - 2016-09-18 19:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:07:39 --> Input Class Initialized
INFO - 2016-09-18 19:07:39 --> Language Class Initialized
INFO - 2016-09-18 19:07:39 --> Language Class Initialized
INFO - 2016-09-18 19:07:39 --> Config Class Initialized
INFO - 2016-09-18 19:07:39 --> Loader Class Initialized
INFO - 2016-09-18 19:07:39 --> Helper loaded: url_helper
INFO - 2016-09-18 19:07:39 --> Database Driver Class Initialized
INFO - 2016-09-18 19:07:39 --> Controller Class Initialized
DEBUG - 2016-09-18 19:07:39 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:07:39 --> Model Class Initialized
INFO - 2016-09-18 19:07:39 --> Model Class Initialized
DEBUG - 2016-09-18 19:07:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 19:07:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 19:07:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 19:07:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_biaya.php
DEBUG - 2016-09-18 19:07:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 19:07:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 19:07:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 19:07:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 19:07:39 --> Final output sent to browser
DEBUG - 2016-09-18 19:07:39 --> Total execution time: 1.0835
INFO - 2016-09-18 19:08:02 --> Config Class Initialized
INFO - 2016-09-18 19:08:02 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:08:02 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:08:02 --> Utf8 Class Initialized
INFO - 2016-09-18 19:08:02 --> URI Class Initialized
INFO - 2016-09-18 19:08:02 --> Router Class Initialized
INFO - 2016-09-18 19:08:02 --> Output Class Initialized
INFO - 2016-09-18 19:08:02 --> Security Class Initialized
DEBUG - 2016-09-18 19:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:08:03 --> Input Class Initialized
INFO - 2016-09-18 19:08:03 --> Language Class Initialized
INFO - 2016-09-18 19:08:03 --> Language Class Initialized
INFO - 2016-09-18 19:08:03 --> Config Class Initialized
INFO - 2016-09-18 19:08:03 --> Loader Class Initialized
INFO - 2016-09-18 19:08:03 --> Helper loaded: url_helper
INFO - 2016-09-18 19:08:03 --> Database Driver Class Initialized
INFO - 2016-09-18 19:08:03 --> Controller Class Initialized
DEBUG - 2016-09-18 19:08:03 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:08:03 --> Model Class Initialized
INFO - 2016-09-18 19:08:03 --> Model Class Initialized
DEBUG - 2016-09-18 19:08:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 19:08:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 19:08:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 19:08:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_biaya.php
DEBUG - 2016-09-18 19:08:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 19:08:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 19:08:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 19:08:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 19:08:03 --> Final output sent to browser
DEBUG - 2016-09-18 19:08:03 --> Total execution time: 1.0297
INFO - 2016-09-18 19:08:37 --> Config Class Initialized
INFO - 2016-09-18 19:08:37 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:08:37 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:08:37 --> Utf8 Class Initialized
INFO - 2016-09-18 19:08:38 --> URI Class Initialized
INFO - 2016-09-18 19:08:38 --> Router Class Initialized
INFO - 2016-09-18 19:08:38 --> Output Class Initialized
INFO - 2016-09-18 19:08:38 --> Security Class Initialized
DEBUG - 2016-09-18 19:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:08:38 --> Input Class Initialized
INFO - 2016-09-18 19:08:38 --> Language Class Initialized
INFO - 2016-09-18 19:08:38 --> Language Class Initialized
INFO - 2016-09-18 19:08:38 --> Config Class Initialized
INFO - 2016-09-18 19:08:38 --> Loader Class Initialized
INFO - 2016-09-18 19:08:38 --> Helper loaded: url_helper
INFO - 2016-09-18 19:08:38 --> Database Driver Class Initialized
INFO - 2016-09-18 19:08:38 --> Controller Class Initialized
DEBUG - 2016-09-18 19:08:38 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:08:38 --> Model Class Initialized
INFO - 2016-09-18 19:08:38 --> Model Class Initialized
DEBUG - 2016-09-18 19:08:38 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-18 19:08:38 --> Users MX_Controller Initialized
INFO - 2016-09-18 19:08:38 --> Final output sent to browser
DEBUG - 2016-09-18 19:08:38 --> Total execution time: 1.1135
INFO - 2016-09-18 19:09:18 --> Config Class Initialized
INFO - 2016-09-18 19:09:18 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:09:18 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:09:18 --> Utf8 Class Initialized
INFO - 2016-09-18 19:09:18 --> URI Class Initialized
INFO - 2016-09-18 19:09:18 --> Router Class Initialized
INFO - 2016-09-18 19:09:18 --> Output Class Initialized
INFO - 2016-09-18 19:09:18 --> Security Class Initialized
DEBUG - 2016-09-18 19:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:09:19 --> Input Class Initialized
INFO - 2016-09-18 19:09:19 --> Language Class Initialized
INFO - 2016-09-18 19:09:19 --> Language Class Initialized
INFO - 2016-09-18 19:09:19 --> Config Class Initialized
INFO - 2016-09-18 19:09:19 --> Loader Class Initialized
INFO - 2016-09-18 19:09:19 --> Helper loaded: url_helper
INFO - 2016-09-18 19:09:19 --> Database Driver Class Initialized
INFO - 2016-09-18 19:09:19 --> Controller Class Initialized
DEBUG - 2016-09-18 19:09:19 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:09:19 --> Model Class Initialized
INFO - 2016-09-18 19:09:19 --> Model Class Initialized
DEBUG - 2016-09-18 19:09:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 19:09:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 19:09:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 19:09:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_biaya.php
DEBUG - 2016-09-18 19:09:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 19:09:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 19:09:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 19:09:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 19:09:19 --> Final output sent to browser
DEBUG - 2016-09-18 19:09:19 --> Total execution time: 1.1483
INFO - 2016-09-18 19:09:33 --> Config Class Initialized
INFO - 2016-09-18 19:09:33 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:09:33 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:09:33 --> Utf8 Class Initialized
INFO - 2016-09-18 19:09:33 --> URI Class Initialized
INFO - 2016-09-18 19:09:33 --> Router Class Initialized
INFO - 2016-09-18 19:09:33 --> Output Class Initialized
INFO - 2016-09-18 19:09:33 --> Security Class Initialized
DEBUG - 2016-09-18 19:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:09:34 --> Input Class Initialized
INFO - 2016-09-18 19:09:34 --> Language Class Initialized
INFO - 2016-09-18 19:09:34 --> Language Class Initialized
INFO - 2016-09-18 19:09:34 --> Config Class Initialized
INFO - 2016-09-18 19:09:34 --> Loader Class Initialized
INFO - 2016-09-18 19:09:34 --> Helper loaded: url_helper
INFO - 2016-09-18 19:09:34 --> Database Driver Class Initialized
INFO - 2016-09-18 19:09:34 --> Controller Class Initialized
DEBUG - 2016-09-18 19:09:34 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:09:34 --> Model Class Initialized
INFO - 2016-09-18 19:09:34 --> Model Class Initialized
DEBUG - 2016-09-18 19:09:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 19:09:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 19:09:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 19:09:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_biaya.php
DEBUG - 2016-09-18 19:09:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 19:09:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 19:09:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 19:09:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 19:09:34 --> Final output sent to browser
DEBUG - 2016-09-18 19:09:34 --> Total execution time: 1.1391
INFO - 2016-09-18 19:18:43 --> Config Class Initialized
INFO - 2016-09-18 19:18:44 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:18:44 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:18:44 --> Utf8 Class Initialized
INFO - 2016-09-18 19:18:44 --> URI Class Initialized
INFO - 2016-09-18 19:18:44 --> Router Class Initialized
INFO - 2016-09-18 19:18:44 --> Output Class Initialized
INFO - 2016-09-18 19:18:44 --> Security Class Initialized
DEBUG - 2016-09-18 19:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:18:44 --> Input Class Initialized
INFO - 2016-09-18 19:18:44 --> Language Class Initialized
INFO - 2016-09-18 19:18:44 --> Language Class Initialized
INFO - 2016-09-18 19:18:44 --> Config Class Initialized
INFO - 2016-09-18 19:18:44 --> Loader Class Initialized
INFO - 2016-09-18 19:18:44 --> Helper loaded: url_helper
INFO - 2016-09-18 19:18:44 --> Database Driver Class Initialized
INFO - 2016-09-18 19:18:44 --> Controller Class Initialized
DEBUG - 2016-09-18 19:18:44 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:18:44 --> Model Class Initialized
INFO - 2016-09-18 19:18:44 --> Model Class Initialized
DEBUG - 2016-09-18 19:18:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 19:18:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 19:18:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 19:18:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_biaya.php
DEBUG - 2016-09-18 19:18:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 19:18:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 19:18:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 19:18:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 19:18:44 --> Final output sent to browser
DEBUG - 2016-09-18 19:18:45 --> Total execution time: 1.0643
INFO - 2016-09-18 19:18:52 --> Config Class Initialized
INFO - 2016-09-18 19:18:52 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:18:52 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:18:52 --> Utf8 Class Initialized
INFO - 2016-09-18 19:18:52 --> URI Class Initialized
INFO - 2016-09-18 19:18:52 --> Router Class Initialized
INFO - 2016-09-18 19:18:52 --> Output Class Initialized
INFO - 2016-09-18 19:18:53 --> Security Class Initialized
DEBUG - 2016-09-18 19:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:18:53 --> Input Class Initialized
INFO - 2016-09-18 19:18:53 --> Language Class Initialized
INFO - 2016-09-18 19:18:53 --> Language Class Initialized
INFO - 2016-09-18 19:18:53 --> Config Class Initialized
INFO - 2016-09-18 19:18:53 --> Loader Class Initialized
INFO - 2016-09-18 19:18:53 --> Helper loaded: url_helper
INFO - 2016-09-18 19:18:53 --> Database Driver Class Initialized
INFO - 2016-09-18 19:18:53 --> Controller Class Initialized
DEBUG - 2016-09-18 19:18:53 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:18:53 --> Model Class Initialized
INFO - 2016-09-18 19:18:53 --> Model Class Initialized
ERROR - 2016-09-18 19:18:53 --> Severity: Notice --> Undefined index: tt_biaya.value E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 779
ERROR - 2016-09-18 19:18:53 --> Severity: Notice --> Undefined index: tt_biaya.value E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 779
ERROR - 2016-09-18 19:18:53 --> Severity: Notice --> Undefined index: tt_biaya.value E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 779
ERROR - 2016-09-18 19:18:53 --> Severity: Notice --> Undefined index: tt_biaya.value E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 779
ERROR - 2016-09-18 19:18:53 --> Severity: Notice --> Undefined index: tt_biaya.value E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 779
ERROR - 2016-09-18 19:18:53 --> Severity: Notice --> Undefined index: tt_biaya.value E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 779
ERROR - 2016-09-18 19:18:53 --> Severity: Notice --> Undefined index: tt_biaya.value E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 779
ERROR - 2016-09-18 19:18:53 --> Severity: Notice --> Undefined index: tt_biaya.value E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 779
ERROR - 2016-09-18 19:18:53 --> Severity: Notice --> Undefined index: tt_biaya.value E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 779
ERROR - 2016-09-18 19:18:53 --> Severity: Notice --> Undefined index: tt_biaya.value E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 779
INFO - 2016-09-18 19:18:53 --> Final output sent to browser
DEBUG - 2016-09-18 19:18:53 --> Total execution time: 1.1530
INFO - 2016-09-18 19:19:13 --> Config Class Initialized
INFO - 2016-09-18 19:19:13 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:19:13 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:19:13 --> Utf8 Class Initialized
INFO - 2016-09-18 19:19:13 --> URI Class Initialized
INFO - 2016-09-18 19:19:13 --> Router Class Initialized
INFO - 2016-09-18 19:19:13 --> Output Class Initialized
INFO - 2016-09-18 19:19:13 --> Security Class Initialized
DEBUG - 2016-09-18 19:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:19:13 --> Input Class Initialized
INFO - 2016-09-18 19:19:13 --> Language Class Initialized
INFO - 2016-09-18 19:19:13 --> Language Class Initialized
INFO - 2016-09-18 19:19:13 --> Config Class Initialized
INFO - 2016-09-18 19:19:13 --> Loader Class Initialized
INFO - 2016-09-18 19:19:13 --> Helper loaded: url_helper
INFO - 2016-09-18 19:19:14 --> Database Driver Class Initialized
INFO - 2016-09-18 19:19:14 --> Controller Class Initialized
DEBUG - 2016-09-18 19:19:14 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:19:14 --> Model Class Initialized
INFO - 2016-09-18 19:19:14 --> Model Class Initialized
ERROR - 2016-09-18 19:19:14 --> Severity: Notice --> Undefined index: tt_biaya.value E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 779
ERROR - 2016-09-18 19:19:14 --> Severity: Notice --> Undefined index: tt_biaya.value E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 779
ERROR - 2016-09-18 19:19:14 --> Severity: Notice --> Undefined index: tt_biaya.value E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 779
ERROR - 2016-09-18 19:19:14 --> Severity: Notice --> Undefined index: tt_biaya.value E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 779
ERROR - 2016-09-18 19:19:14 --> Severity: Notice --> Undefined index: tt_biaya.value E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 779
ERROR - 2016-09-18 19:19:14 --> Severity: Notice --> Undefined index: tt_biaya.value E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 779
ERROR - 2016-09-18 19:19:14 --> Severity: Notice --> Undefined index: tt_biaya.value E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 779
ERROR - 2016-09-18 19:19:14 --> Severity: Notice --> Undefined index: tt_biaya.value E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 779
ERROR - 2016-09-18 19:19:14 --> Severity: Notice --> Undefined index: tt_biaya.value E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 779
ERROR - 2016-09-18 19:19:14 --> Severity: Notice --> Undefined index: tt_biaya.value E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 779
INFO - 2016-09-18 19:19:14 --> Final output sent to browser
DEBUG - 2016-09-18 19:19:14 --> Total execution time: 1.2814
INFO - 2016-09-18 19:19:47 --> Config Class Initialized
INFO - 2016-09-18 19:19:47 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:19:47 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:19:47 --> Utf8 Class Initialized
INFO - 2016-09-18 19:19:47 --> URI Class Initialized
INFO - 2016-09-18 19:19:47 --> Router Class Initialized
INFO - 2016-09-18 19:19:47 --> Output Class Initialized
INFO - 2016-09-18 19:19:47 --> Security Class Initialized
DEBUG - 2016-09-18 19:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:19:47 --> Input Class Initialized
INFO - 2016-09-18 19:19:47 --> Language Class Initialized
INFO - 2016-09-18 19:19:47 --> Language Class Initialized
INFO - 2016-09-18 19:19:47 --> Config Class Initialized
INFO - 2016-09-18 19:19:47 --> Loader Class Initialized
INFO - 2016-09-18 19:19:47 --> Helper loaded: url_helper
INFO - 2016-09-18 19:19:48 --> Database Driver Class Initialized
INFO - 2016-09-18 19:19:48 --> Controller Class Initialized
DEBUG - 2016-09-18 19:19:48 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:19:48 --> Model Class Initialized
INFO - 2016-09-18 19:19:48 --> Model Class Initialized
INFO - 2016-09-18 19:19:48 --> Database Driver Class Initialized
ERROR - 2016-09-18 19:19:48 --> Severity: Notice --> Undefined variable: params E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 788
INFO - 2016-09-18 19:19:48 --> Database Driver Class Initialized
INFO - 2016-09-18 19:19:48 --> Database Driver Class Initialized
ERROR - 2016-09-18 19:19:48 --> Severity: Notice --> Undefined variable: params E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 788
INFO - 2016-09-18 19:19:48 --> Database Driver Class Initialized
INFO - 2016-09-18 19:19:48 --> Database Driver Class Initialized
ERROR - 2016-09-18 19:19:48 --> Severity: Notice --> Undefined variable: params E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 788
INFO - 2016-09-18 19:19:48 --> Database Driver Class Initialized
INFO - 2016-09-18 19:19:48 --> Database Driver Class Initialized
ERROR - 2016-09-18 19:19:48 --> Severity: Notice --> Undefined variable: params E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 788
INFO - 2016-09-18 19:19:49 --> Database Driver Class Initialized
INFO - 2016-09-18 19:19:49 --> Database Driver Class Initialized
ERROR - 2016-09-18 19:19:49 --> Severity: Notice --> Undefined variable: params E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 788
INFO - 2016-09-18 19:19:49 --> Database Driver Class Initialized
INFO - 2016-09-18 19:19:49 --> Final output sent to browser
DEBUG - 2016-09-18 19:19:49 --> Total execution time: 1.9381
INFO - 2016-09-18 19:20:14 --> Config Class Initialized
INFO - 2016-09-18 19:20:14 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:20:14 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:20:14 --> Utf8 Class Initialized
INFO - 2016-09-18 19:20:14 --> URI Class Initialized
INFO - 2016-09-18 19:20:14 --> Router Class Initialized
INFO - 2016-09-18 19:20:14 --> Output Class Initialized
INFO - 2016-09-18 19:20:14 --> Security Class Initialized
DEBUG - 2016-09-18 19:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:20:14 --> Input Class Initialized
INFO - 2016-09-18 19:20:14 --> Language Class Initialized
INFO - 2016-09-18 19:20:15 --> Language Class Initialized
INFO - 2016-09-18 19:20:15 --> Config Class Initialized
INFO - 2016-09-18 19:20:15 --> Loader Class Initialized
INFO - 2016-09-18 19:20:15 --> Helper loaded: url_helper
INFO - 2016-09-18 19:20:15 --> Database Driver Class Initialized
INFO - 2016-09-18 19:20:15 --> Controller Class Initialized
DEBUG - 2016-09-18 19:20:15 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:20:15 --> Model Class Initialized
INFO - 2016-09-18 19:20:15 --> Model Class Initialized
INFO - 2016-09-18 19:20:15 --> Database Driver Class Initialized
INFO - 2016-09-18 19:20:15 --> Database Driver Class Initialized
INFO - 2016-09-18 19:20:15 --> Database Driver Class Initialized
INFO - 2016-09-18 19:20:15 --> Database Driver Class Initialized
INFO - 2016-09-18 19:20:16 --> Database Driver Class Initialized
INFO - 2016-09-18 19:20:16 --> Database Driver Class Initialized
INFO - 2016-09-18 19:20:16 --> Database Driver Class Initialized
INFO - 2016-09-18 19:20:16 --> Database Driver Class Initialized
INFO - 2016-09-18 19:20:16 --> Database Driver Class Initialized
INFO - 2016-09-18 19:20:16 --> Database Driver Class Initialized
INFO - 2016-09-18 19:20:16 --> Final output sent to browser
DEBUG - 2016-09-18 19:20:16 --> Total execution time: 1.8619
INFO - 2016-09-18 19:22:01 --> Config Class Initialized
INFO - 2016-09-18 19:22:01 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:22:01 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:22:01 --> Utf8 Class Initialized
INFO - 2016-09-18 19:22:01 --> URI Class Initialized
INFO - 2016-09-18 19:22:01 --> Router Class Initialized
INFO - 2016-09-18 19:22:01 --> Output Class Initialized
INFO - 2016-09-18 19:22:01 --> Security Class Initialized
DEBUG - 2016-09-18 19:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:22:01 --> Input Class Initialized
INFO - 2016-09-18 19:22:01 --> Language Class Initialized
INFO - 2016-09-18 19:22:01 --> Language Class Initialized
INFO - 2016-09-18 19:22:01 --> Config Class Initialized
INFO - 2016-09-18 19:22:01 --> Loader Class Initialized
INFO - 2016-09-18 19:22:01 --> Helper loaded: url_helper
INFO - 2016-09-18 19:22:01 --> Database Driver Class Initialized
INFO - 2016-09-18 19:22:01 --> Controller Class Initialized
DEBUG - 2016-09-18 19:22:02 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:22:02 --> Model Class Initialized
INFO - 2016-09-18 19:22:02 --> Model Class Initialized
DEBUG - 2016-09-18 19:22:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 19:22:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 19:22:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 19:22:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_biaya.php
DEBUG - 2016-09-18 19:22:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 19:22:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 19:22:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 19:22:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 19:22:02 --> Final output sent to browser
DEBUG - 2016-09-18 19:22:02 --> Total execution time: 1.3882
INFO - 2016-09-18 19:22:10 --> Config Class Initialized
INFO - 2016-09-18 19:22:10 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:22:10 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:22:10 --> Utf8 Class Initialized
INFO - 2016-09-18 19:22:10 --> URI Class Initialized
INFO - 2016-09-18 19:22:10 --> Router Class Initialized
INFO - 2016-09-18 19:22:10 --> Output Class Initialized
INFO - 2016-09-18 19:22:10 --> Security Class Initialized
DEBUG - 2016-09-18 19:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:22:10 --> Input Class Initialized
INFO - 2016-09-18 19:22:10 --> Language Class Initialized
INFO - 2016-09-18 19:22:10 --> Language Class Initialized
INFO - 2016-09-18 19:22:10 --> Config Class Initialized
INFO - 2016-09-18 19:22:10 --> Loader Class Initialized
INFO - 2016-09-18 19:22:10 --> Helper loaded: url_helper
INFO - 2016-09-18 19:22:10 --> Database Driver Class Initialized
INFO - 2016-09-18 19:22:10 --> Controller Class Initialized
DEBUG - 2016-09-18 19:22:10 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:22:11 --> Model Class Initialized
INFO - 2016-09-18 19:22:11 --> Model Class Initialized
INFO - 2016-09-18 19:22:11 --> Database Driver Class Initialized
INFO - 2016-09-18 19:22:11 --> Database Driver Class Initialized
INFO - 2016-09-18 19:22:11 --> Database Driver Class Initialized
INFO - 2016-09-18 19:22:11 --> Database Driver Class Initialized
INFO - 2016-09-18 19:22:11 --> Database Driver Class Initialized
INFO - 2016-09-18 19:22:11 --> Database Driver Class Initialized
INFO - 2016-09-18 19:22:11 --> Database Driver Class Initialized
INFO - 2016-09-18 19:22:11 --> Database Driver Class Initialized
INFO - 2016-09-18 19:22:11 --> Database Driver Class Initialized
INFO - 2016-09-18 19:22:11 --> Database Driver Class Initialized
INFO - 2016-09-18 19:22:11 --> Final output sent to browser
DEBUG - 2016-09-18 19:22:11 --> Total execution time: 1.5239
INFO - 2016-09-18 19:22:37 --> Config Class Initialized
INFO - 2016-09-18 19:22:37 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:22:38 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:22:38 --> Utf8 Class Initialized
INFO - 2016-09-18 19:22:38 --> URI Class Initialized
INFO - 2016-09-18 19:22:38 --> Router Class Initialized
INFO - 2016-09-18 19:22:38 --> Output Class Initialized
INFO - 2016-09-18 19:22:38 --> Security Class Initialized
DEBUG - 2016-09-18 19:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:22:38 --> Input Class Initialized
INFO - 2016-09-18 19:22:38 --> Language Class Initialized
INFO - 2016-09-18 19:22:38 --> Language Class Initialized
INFO - 2016-09-18 19:22:38 --> Config Class Initialized
INFO - 2016-09-18 19:22:38 --> Loader Class Initialized
INFO - 2016-09-18 19:22:38 --> Helper loaded: url_helper
INFO - 2016-09-18 19:22:38 --> Database Driver Class Initialized
INFO - 2016-09-18 19:22:38 --> Controller Class Initialized
DEBUG - 2016-09-18 19:22:38 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:22:38 --> Model Class Initialized
INFO - 2016-09-18 19:22:38 --> Model Class Initialized
INFO - 2016-09-18 19:22:38 --> Database Driver Class Initialized
INFO - 2016-09-18 19:22:38 --> Database Driver Class Initialized
INFO - 2016-09-18 19:22:38 --> Database Driver Class Initialized
INFO - 2016-09-18 19:22:38 --> Database Driver Class Initialized
INFO - 2016-09-18 19:22:39 --> Database Driver Class Initialized
INFO - 2016-09-18 19:22:39 --> Database Driver Class Initialized
INFO - 2016-09-18 19:22:39 --> Database Driver Class Initialized
INFO - 2016-09-18 19:22:39 --> Database Driver Class Initialized
INFO - 2016-09-18 19:22:39 --> Database Driver Class Initialized
INFO - 2016-09-18 19:22:39 --> Database Driver Class Initialized
INFO - 2016-09-18 19:22:39 --> Final output sent to browser
DEBUG - 2016-09-18 19:22:39 --> Total execution time: 1.6129
INFO - 2016-09-18 19:23:16 --> Config Class Initialized
INFO - 2016-09-18 19:23:16 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:23:16 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:23:16 --> Utf8 Class Initialized
INFO - 2016-09-18 19:23:16 --> URI Class Initialized
INFO - 2016-09-18 19:23:16 --> Router Class Initialized
INFO - 2016-09-18 19:23:16 --> Output Class Initialized
INFO - 2016-09-18 19:23:16 --> Security Class Initialized
DEBUG - 2016-09-18 19:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:23:16 --> Input Class Initialized
INFO - 2016-09-18 19:23:16 --> Language Class Initialized
INFO - 2016-09-18 19:23:16 --> Language Class Initialized
INFO - 2016-09-18 19:23:17 --> Config Class Initialized
INFO - 2016-09-18 19:23:17 --> Loader Class Initialized
INFO - 2016-09-18 19:23:17 --> Helper loaded: url_helper
INFO - 2016-09-18 19:23:17 --> Database Driver Class Initialized
INFO - 2016-09-18 19:23:17 --> Controller Class Initialized
DEBUG - 2016-09-18 19:23:17 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:23:17 --> Model Class Initialized
INFO - 2016-09-18 19:23:17 --> Model Class Initialized
INFO - 2016-09-18 19:23:17 --> Database Driver Class Initialized
INFO - 2016-09-18 19:23:17 --> Database Driver Class Initialized
INFO - 2016-09-18 19:23:17 --> Database Driver Class Initialized
INFO - 2016-09-18 19:23:17 --> Database Driver Class Initialized
INFO - 2016-09-18 19:23:17 --> Database Driver Class Initialized
INFO - 2016-09-18 19:23:17 --> Database Driver Class Initialized
INFO - 2016-09-18 19:23:17 --> Database Driver Class Initialized
INFO - 2016-09-18 19:23:18 --> Database Driver Class Initialized
INFO - 2016-09-18 19:23:18 --> Database Driver Class Initialized
INFO - 2016-09-18 19:23:18 --> Database Driver Class Initialized
INFO - 2016-09-18 19:23:18 --> Final output sent to browser
DEBUG - 2016-09-18 19:23:18 --> Total execution time: 1.7429
INFO - 2016-09-18 19:23:50 --> Config Class Initialized
INFO - 2016-09-18 19:23:50 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:23:50 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:23:50 --> Utf8 Class Initialized
INFO - 2016-09-18 19:23:51 --> URI Class Initialized
INFO - 2016-09-18 19:23:51 --> Router Class Initialized
INFO - 2016-09-18 19:23:51 --> Output Class Initialized
INFO - 2016-09-18 19:23:51 --> Security Class Initialized
DEBUG - 2016-09-18 19:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:23:51 --> Input Class Initialized
INFO - 2016-09-18 19:23:51 --> Language Class Initialized
INFO - 2016-09-18 19:23:51 --> Language Class Initialized
INFO - 2016-09-18 19:23:51 --> Config Class Initialized
INFO - 2016-09-18 19:23:51 --> Loader Class Initialized
INFO - 2016-09-18 19:23:51 --> Helper loaded: url_helper
INFO - 2016-09-18 19:23:51 --> Database Driver Class Initialized
INFO - 2016-09-18 19:23:51 --> Controller Class Initialized
DEBUG - 2016-09-18 19:23:51 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:23:51 --> Model Class Initialized
INFO - 2016-09-18 19:23:51 --> Model Class Initialized
DEBUG - 2016-09-18 19:23:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 19:23:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 19:23:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 19:23:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_biaya.php
DEBUG - 2016-09-18 19:23:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 19:23:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 19:23:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 19:23:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 19:23:52 --> Final output sent to browser
DEBUG - 2016-09-18 19:23:52 --> Total execution time: 1.3518
INFO - 2016-09-18 19:24:21 --> Config Class Initialized
INFO - 2016-09-18 19:24:21 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:24:21 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:24:21 --> Utf8 Class Initialized
INFO - 2016-09-18 19:24:21 --> URI Class Initialized
INFO - 2016-09-18 19:24:21 --> Router Class Initialized
INFO - 2016-09-18 19:24:21 --> Output Class Initialized
INFO - 2016-09-18 19:24:21 --> Security Class Initialized
DEBUG - 2016-09-18 19:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:24:21 --> Input Class Initialized
INFO - 2016-09-18 19:24:21 --> Language Class Initialized
INFO - 2016-09-18 19:24:22 --> Language Class Initialized
INFO - 2016-09-18 19:24:22 --> Config Class Initialized
INFO - 2016-09-18 19:24:22 --> Loader Class Initialized
INFO - 2016-09-18 19:24:22 --> Helper loaded: url_helper
INFO - 2016-09-18 19:24:22 --> Database Driver Class Initialized
INFO - 2016-09-18 19:24:22 --> Controller Class Initialized
DEBUG - 2016-09-18 19:24:22 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:24:22 --> Model Class Initialized
INFO - 2016-09-18 19:24:22 --> Model Class Initialized
INFO - 2016-09-18 19:24:22 --> Database Driver Class Initialized
INFO - 2016-09-18 19:24:22 --> Database Driver Class Initialized
INFO - 2016-09-18 19:24:22 --> Database Driver Class Initialized
INFO - 2016-09-18 19:24:22 --> Database Driver Class Initialized
INFO - 2016-09-18 19:24:22 --> Database Driver Class Initialized
INFO - 2016-09-18 19:24:22 --> Database Driver Class Initialized
INFO - 2016-09-18 19:24:22 --> Database Driver Class Initialized
INFO - 2016-09-18 19:24:22 --> Database Driver Class Initialized
INFO - 2016-09-18 19:24:23 --> Database Driver Class Initialized
INFO - 2016-09-18 19:24:23 --> Database Driver Class Initialized
INFO - 2016-09-18 19:24:23 --> Final output sent to browser
DEBUG - 2016-09-18 19:24:23 --> Total execution time: 1.6352
INFO - 2016-09-18 19:24:34 --> Config Class Initialized
INFO - 2016-09-18 19:24:34 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:24:34 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:24:34 --> Utf8 Class Initialized
INFO - 2016-09-18 19:24:34 --> URI Class Initialized
INFO - 2016-09-18 19:24:34 --> Router Class Initialized
INFO - 2016-09-18 19:24:34 --> Output Class Initialized
INFO - 2016-09-18 19:24:34 --> Security Class Initialized
DEBUG - 2016-09-18 19:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:24:35 --> Input Class Initialized
INFO - 2016-09-18 19:24:35 --> Language Class Initialized
INFO - 2016-09-18 19:24:35 --> Language Class Initialized
INFO - 2016-09-18 19:24:35 --> Config Class Initialized
INFO - 2016-09-18 19:24:35 --> Loader Class Initialized
INFO - 2016-09-18 19:24:35 --> Helper loaded: url_helper
INFO - 2016-09-18 19:24:35 --> Database Driver Class Initialized
INFO - 2016-09-18 19:24:35 --> Controller Class Initialized
DEBUG - 2016-09-18 19:24:35 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:24:35 --> Model Class Initialized
INFO - 2016-09-18 19:24:35 --> Model Class Initialized
DEBUG - 2016-09-18 19:24:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 19:24:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 19:24:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 19:24:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/jurnal_umum.php
DEBUG - 2016-09-18 19:24:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 19:24:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 19:24:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 19:24:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 19:24:35 --> Final output sent to browser
DEBUG - 2016-09-18 19:24:35 --> Total execution time: 1.1720
INFO - 2016-09-18 19:24:41 --> Config Class Initialized
INFO - 2016-09-18 19:24:41 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:24:41 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:24:41 --> Utf8 Class Initialized
INFO - 2016-09-18 19:24:41 --> URI Class Initialized
INFO - 2016-09-18 19:24:41 --> Router Class Initialized
INFO - 2016-09-18 19:24:41 --> Output Class Initialized
INFO - 2016-09-18 19:24:41 --> Security Class Initialized
DEBUG - 2016-09-18 19:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:24:41 --> Input Class Initialized
INFO - 2016-09-18 19:24:41 --> Language Class Initialized
INFO - 2016-09-18 19:24:41 --> Language Class Initialized
INFO - 2016-09-18 19:24:41 --> Config Class Initialized
INFO - 2016-09-18 19:24:41 --> Loader Class Initialized
INFO - 2016-09-18 19:24:41 --> Helper loaded: url_helper
INFO - 2016-09-18 19:24:41 --> Database Driver Class Initialized
INFO - 2016-09-18 19:24:41 --> Controller Class Initialized
DEBUG - 2016-09-18 19:24:41 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:24:41 --> Model Class Initialized
INFO - 2016-09-18 19:24:42 --> Model Class Initialized
DEBUG - 2016-09-18 19:24:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_jurnal_umum.php
INFO - 2016-09-18 19:24:42 --> Final output sent to browser
DEBUG - 2016-09-18 19:24:42 --> Total execution time: 0.9140
INFO - 2016-09-18 19:27:30 --> Config Class Initialized
INFO - 2016-09-18 19:27:30 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:27:30 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:27:30 --> Utf8 Class Initialized
INFO - 2016-09-18 19:27:30 --> URI Class Initialized
INFO - 2016-09-18 19:27:30 --> Router Class Initialized
INFO - 2016-09-18 19:27:30 --> Output Class Initialized
INFO - 2016-09-18 19:27:30 --> Security Class Initialized
DEBUG - 2016-09-18 19:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:27:30 --> Input Class Initialized
INFO - 2016-09-18 19:27:30 --> Language Class Initialized
INFO - 2016-09-18 19:27:30 --> Language Class Initialized
INFO - 2016-09-18 19:27:30 --> Config Class Initialized
INFO - 2016-09-18 19:27:30 --> Loader Class Initialized
INFO - 2016-09-18 19:27:30 --> Helper loaded: url_helper
INFO - 2016-09-18 19:27:30 --> Database Driver Class Initialized
INFO - 2016-09-18 19:27:30 --> Controller Class Initialized
DEBUG - 2016-09-18 19:27:30 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:27:30 --> Model Class Initialized
INFO - 2016-09-18 19:27:30 --> Model Class Initialized
DEBUG - 2016-09-18 19:27:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 19:27:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 19:27:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 19:27:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-18 19:27:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 19:27:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 19:27:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 19:27:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 19:27:31 --> Final output sent to browser
DEBUG - 2016-09-18 19:27:31 --> Total execution time: 0.9933
INFO - 2016-09-18 19:27:38 --> Config Class Initialized
INFO - 2016-09-18 19:27:38 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:27:38 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:27:38 --> Utf8 Class Initialized
INFO - 2016-09-18 19:27:38 --> URI Class Initialized
INFO - 2016-09-18 19:27:38 --> Router Class Initialized
INFO - 2016-09-18 19:27:38 --> Output Class Initialized
INFO - 2016-09-18 19:27:38 --> Security Class Initialized
DEBUG - 2016-09-18 19:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:27:39 --> Input Class Initialized
INFO - 2016-09-18 19:27:39 --> Language Class Initialized
INFO - 2016-09-18 19:27:39 --> Language Class Initialized
INFO - 2016-09-18 19:27:39 --> Config Class Initialized
INFO - 2016-09-18 19:27:39 --> Loader Class Initialized
INFO - 2016-09-18 19:27:39 --> Helper loaded: url_helper
INFO - 2016-09-18 19:27:39 --> Database Driver Class Initialized
INFO - 2016-09-18 19:27:39 --> Controller Class Initialized
DEBUG - 2016-09-18 19:27:39 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:27:39 --> Model Class Initialized
INFO - 2016-09-18 19:27:39 --> Model Class Initialized
DEBUG - 2016-09-18 19:27:39 --> Anggota MX_Controller Initialized
INFO - 2016-09-18 19:27:39 --> Database Driver Class Initialized
INFO - 2016-09-18 19:27:39 --> Final output sent to browser
DEBUG - 2016-09-18 19:27:39 --> Total execution time: 1.1114
INFO - 2016-09-18 19:27:41 --> Config Class Initialized
INFO - 2016-09-18 19:27:41 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:27:41 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:27:41 --> Utf8 Class Initialized
INFO - 2016-09-18 19:27:41 --> URI Class Initialized
INFO - 2016-09-18 19:27:41 --> Router Class Initialized
INFO - 2016-09-18 19:27:41 --> Output Class Initialized
INFO - 2016-09-18 19:27:41 --> Security Class Initialized
DEBUG - 2016-09-18 19:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:27:41 --> Input Class Initialized
INFO - 2016-09-18 19:27:42 --> Language Class Initialized
INFO - 2016-09-18 19:27:42 --> Language Class Initialized
INFO - 2016-09-18 19:27:42 --> Config Class Initialized
INFO - 2016-09-18 19:27:42 --> Loader Class Initialized
INFO - 2016-09-18 19:27:42 --> Helper loaded: url_helper
INFO - 2016-09-18 19:27:42 --> Database Driver Class Initialized
INFO - 2016-09-18 19:27:42 --> Controller Class Initialized
DEBUG - 2016-09-18 19:27:42 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:27:42 --> Model Class Initialized
INFO - 2016-09-18 19:27:42 --> Model Class Initialized
DEBUG - 2016-09-18 19:27:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 19:27:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 19:27:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 19:27:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_umum.php
DEBUG - 2016-09-18 19:27:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 19:27:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 19:27:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 19:27:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 19:27:42 --> Final output sent to browser
DEBUG - 2016-09-18 19:27:42 --> Total execution time: 1.3465
INFO - 2016-09-18 19:27:53 --> Config Class Initialized
INFO - 2016-09-18 19:27:53 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:27:53 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:27:53 --> Utf8 Class Initialized
INFO - 2016-09-18 19:27:53 --> URI Class Initialized
INFO - 2016-09-18 19:27:53 --> Router Class Initialized
INFO - 2016-09-18 19:27:53 --> Output Class Initialized
INFO - 2016-09-18 19:27:53 --> Security Class Initialized
DEBUG - 2016-09-18 19:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:27:53 --> Input Class Initialized
INFO - 2016-09-18 19:27:53 --> Language Class Initialized
INFO - 2016-09-18 19:27:53 --> Language Class Initialized
INFO - 2016-09-18 19:27:53 --> Config Class Initialized
INFO - 2016-09-18 19:27:53 --> Loader Class Initialized
INFO - 2016-09-18 19:27:53 --> Helper loaded: url_helper
INFO - 2016-09-18 19:27:53 --> Database Driver Class Initialized
INFO - 2016-09-18 19:27:53 --> Controller Class Initialized
DEBUG - 2016-09-18 19:27:53 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:27:53 --> Model Class Initialized
INFO - 2016-09-18 19:27:53 --> Model Class Initialized
INFO - 2016-09-18 19:27:54 --> Database Driver Class Initialized
INFO - 2016-09-18 19:27:54 --> Final output sent to browser
DEBUG - 2016-09-18 19:27:54 --> Total execution time: 1.0442
INFO - 2016-09-18 19:28:01 --> Config Class Initialized
INFO - 2016-09-18 19:28:01 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:28:01 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:28:01 --> Utf8 Class Initialized
INFO - 2016-09-18 19:28:01 --> URI Class Initialized
INFO - 2016-09-18 19:28:01 --> Router Class Initialized
INFO - 2016-09-18 19:28:01 --> Output Class Initialized
INFO - 2016-09-18 19:28:01 --> Security Class Initialized
DEBUG - 2016-09-18 19:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:28:01 --> Input Class Initialized
INFO - 2016-09-18 19:28:01 --> Language Class Initialized
INFO - 2016-09-18 19:28:01 --> Language Class Initialized
INFO - 2016-09-18 19:28:01 --> Config Class Initialized
INFO - 2016-09-18 19:28:01 --> Loader Class Initialized
INFO - 2016-09-18 19:28:01 --> Helper loaded: url_helper
INFO - 2016-09-18 19:28:01 --> Database Driver Class Initialized
INFO - 2016-09-18 19:28:01 --> Controller Class Initialized
DEBUG - 2016-09-18 19:28:01 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:28:01 --> Model Class Initialized
INFO - 2016-09-18 19:28:01 --> Model Class Initialized
INFO - 2016-09-18 19:28:01 --> Database Driver Class Initialized
INFO - 2016-09-18 19:28:01 --> Final output sent to browser
DEBUG - 2016-09-18 19:28:01 --> Total execution time: 0.8891
INFO - 2016-09-18 19:28:22 --> Config Class Initialized
INFO - 2016-09-18 19:28:22 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:28:22 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:28:22 --> Utf8 Class Initialized
INFO - 2016-09-18 19:28:22 --> URI Class Initialized
INFO - 2016-09-18 19:28:22 --> Router Class Initialized
INFO - 2016-09-18 19:28:22 --> Output Class Initialized
INFO - 2016-09-18 19:28:22 --> Security Class Initialized
DEBUG - 2016-09-18 19:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:28:22 --> Input Class Initialized
INFO - 2016-09-18 19:28:22 --> Language Class Initialized
INFO - 2016-09-18 19:28:22 --> Language Class Initialized
INFO - 2016-09-18 19:28:22 --> Config Class Initialized
INFO - 2016-09-18 19:28:22 --> Loader Class Initialized
INFO - 2016-09-18 19:28:23 --> Helper loaded: url_helper
INFO - 2016-09-18 19:28:23 --> Database Driver Class Initialized
INFO - 2016-09-18 19:28:23 --> Controller Class Initialized
DEBUG - 2016-09-18 19:28:23 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:28:23 --> Model Class Initialized
INFO - 2016-09-18 19:28:23 --> Model Class Initialized
INFO - 2016-09-18 19:28:23 --> Database Driver Class Initialized
INFO - 2016-09-18 19:28:23 --> Database Driver Class Initialized
INFO - 2016-09-18 19:28:23 --> Final output sent to browser
DEBUG - 2016-09-18 19:28:23 --> Total execution time: 0.9353
INFO - 2016-09-18 19:28:32 --> Config Class Initialized
INFO - 2016-09-18 19:28:32 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:28:32 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:28:32 --> Utf8 Class Initialized
INFO - 2016-09-18 19:28:33 --> URI Class Initialized
INFO - 2016-09-18 19:28:33 --> Router Class Initialized
INFO - 2016-09-18 19:28:33 --> Output Class Initialized
INFO - 2016-09-18 19:28:33 --> Security Class Initialized
DEBUG - 2016-09-18 19:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:28:33 --> Input Class Initialized
INFO - 2016-09-18 19:28:33 --> Language Class Initialized
INFO - 2016-09-18 19:28:33 --> Language Class Initialized
INFO - 2016-09-18 19:28:33 --> Config Class Initialized
INFO - 2016-09-18 19:28:33 --> Loader Class Initialized
INFO - 2016-09-18 19:28:33 --> Helper loaded: url_helper
INFO - 2016-09-18 19:28:33 --> Database Driver Class Initialized
INFO - 2016-09-18 19:28:33 --> Controller Class Initialized
DEBUG - 2016-09-18 19:28:33 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:28:33 --> Model Class Initialized
INFO - 2016-09-18 19:28:33 --> Model Class Initialized
DEBUG - 2016-09-18 19:28:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 19:28:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 19:28:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 19:28:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_bayar_angsuran.php
DEBUG - 2016-09-18 19:28:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 19:28:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 19:28:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 19:28:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 19:28:34 --> Final output sent to browser
DEBUG - 2016-09-18 19:28:34 --> Total execution time: 1.1700
INFO - 2016-09-18 19:28:38 --> Config Class Initialized
INFO - 2016-09-18 19:28:38 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:28:38 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:28:38 --> Utf8 Class Initialized
INFO - 2016-09-18 19:28:38 --> URI Class Initialized
INFO - 2016-09-18 19:28:38 --> Router Class Initialized
INFO - 2016-09-18 19:28:38 --> Output Class Initialized
INFO - 2016-09-18 19:28:38 --> Security Class Initialized
DEBUG - 2016-09-18 19:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:28:38 --> Input Class Initialized
INFO - 2016-09-18 19:28:38 --> Language Class Initialized
INFO - 2016-09-18 19:28:38 --> Language Class Initialized
INFO - 2016-09-18 19:28:38 --> Config Class Initialized
INFO - 2016-09-18 19:28:38 --> Loader Class Initialized
INFO - 2016-09-18 19:28:38 --> Helper loaded: url_helper
INFO - 2016-09-18 19:28:38 --> Database Driver Class Initialized
INFO - 2016-09-18 19:28:38 --> Controller Class Initialized
DEBUG - 2016-09-18 19:28:38 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:28:39 --> Model Class Initialized
INFO - 2016-09-18 19:28:39 --> Model Class Initialized
INFO - 2016-09-18 19:28:39 --> Database Driver Class Initialized
INFO - 2016-09-18 19:28:39 --> Final output sent to browser
DEBUG - 2016-09-18 19:28:39 --> Total execution time: 0.9219
INFO - 2016-09-18 19:28:47 --> Config Class Initialized
INFO - 2016-09-18 19:28:47 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:28:47 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:28:47 --> Utf8 Class Initialized
INFO - 2016-09-18 19:28:47 --> URI Class Initialized
INFO - 2016-09-18 19:28:47 --> Router Class Initialized
INFO - 2016-09-18 19:28:47 --> Output Class Initialized
INFO - 2016-09-18 19:28:47 --> Security Class Initialized
DEBUG - 2016-09-18 19:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:28:47 --> Input Class Initialized
INFO - 2016-09-18 19:28:47 --> Language Class Initialized
INFO - 2016-09-18 19:28:48 --> Language Class Initialized
INFO - 2016-09-18 19:28:48 --> Config Class Initialized
INFO - 2016-09-18 19:28:48 --> Loader Class Initialized
INFO - 2016-09-18 19:28:48 --> Helper loaded: url_helper
INFO - 2016-09-18 19:28:48 --> Database Driver Class Initialized
INFO - 2016-09-18 19:28:48 --> Controller Class Initialized
DEBUG - 2016-09-18 19:28:48 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:28:48 --> Model Class Initialized
INFO - 2016-09-18 19:28:48 --> Model Class Initialized
INFO - 2016-09-18 19:28:48 --> Database Driver Class Initialized
INFO - 2016-09-18 19:28:48 --> Database Driver Class Initialized
INFO - 2016-09-18 19:28:48 --> Database Driver Class Initialized
INFO - 2016-09-18 19:28:48 --> Database Driver Class Initialized
INFO - 2016-09-18 19:28:48 --> Final output sent to browser
DEBUG - 2016-09-18 19:28:48 --> Total execution time: 1.4177
INFO - 2016-09-18 19:28:50 --> Config Class Initialized
INFO - 2016-09-18 19:28:50 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:28:50 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:28:50 --> Utf8 Class Initialized
INFO - 2016-09-18 19:28:50 --> URI Class Initialized
INFO - 2016-09-18 19:28:51 --> Router Class Initialized
INFO - 2016-09-18 19:28:51 --> Output Class Initialized
INFO - 2016-09-18 19:28:51 --> Security Class Initialized
DEBUG - 2016-09-18 19:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:28:51 --> Input Class Initialized
INFO - 2016-09-18 19:28:51 --> Language Class Initialized
INFO - 2016-09-18 19:28:51 --> Language Class Initialized
INFO - 2016-09-18 19:28:51 --> Config Class Initialized
INFO - 2016-09-18 19:28:51 --> Loader Class Initialized
INFO - 2016-09-18 19:28:51 --> Helper loaded: url_helper
INFO - 2016-09-18 19:28:51 --> Database Driver Class Initialized
INFO - 2016-09-18 19:28:51 --> Controller Class Initialized
DEBUG - 2016-09-18 19:28:51 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:28:51 --> Model Class Initialized
INFO - 2016-09-18 19:28:51 --> Model Class Initialized
INFO - 2016-09-18 19:28:51 --> Database Driver Class Initialized
INFO - 2016-09-18 19:28:51 --> Final output sent to browser
DEBUG - 2016-09-18 19:28:51 --> Total execution time: 0.9216
INFO - 2016-09-18 19:28:52 --> Config Class Initialized
INFO - 2016-09-18 19:28:52 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:28:52 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:28:52 --> Utf8 Class Initialized
INFO - 2016-09-18 19:28:52 --> URI Class Initialized
INFO - 2016-09-18 19:28:52 --> Router Class Initialized
INFO - 2016-09-18 19:28:52 --> Output Class Initialized
INFO - 2016-09-18 19:28:52 --> Security Class Initialized
DEBUG - 2016-09-18 19:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:28:52 --> Input Class Initialized
INFO - 2016-09-18 19:28:52 --> Language Class Initialized
INFO - 2016-09-18 19:28:52 --> Language Class Initialized
INFO - 2016-09-18 19:28:53 --> Config Class Initialized
INFO - 2016-09-18 19:28:53 --> Loader Class Initialized
INFO - 2016-09-18 19:28:53 --> Helper loaded: url_helper
INFO - 2016-09-18 19:28:53 --> Database Driver Class Initialized
INFO - 2016-09-18 19:28:53 --> Controller Class Initialized
DEBUG - 2016-09-18 19:28:53 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:28:53 --> Model Class Initialized
INFO - 2016-09-18 19:28:53 --> Model Class Initialized
INFO - 2016-09-18 19:28:53 --> Database Driver Class Initialized
INFO - 2016-09-18 19:28:53 --> Database Driver Class Initialized
INFO - 2016-09-18 19:28:53 --> Database Driver Class Initialized
INFO - 2016-09-18 19:28:53 --> Database Driver Class Initialized
INFO - 2016-09-18 19:28:53 --> Final output sent to browser
DEBUG - 2016-09-18 19:28:53 --> Total execution time: 1.2872
INFO - 2016-09-18 19:28:55 --> Config Class Initialized
INFO - 2016-09-18 19:28:55 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:28:55 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:28:55 --> Utf8 Class Initialized
INFO - 2016-09-18 19:28:55 --> URI Class Initialized
INFO - 2016-09-18 19:28:55 --> Router Class Initialized
INFO - 2016-09-18 19:28:55 --> Output Class Initialized
INFO - 2016-09-18 19:28:55 --> Security Class Initialized
DEBUG - 2016-09-18 19:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:28:55 --> Input Class Initialized
INFO - 2016-09-18 19:28:55 --> Language Class Initialized
INFO - 2016-09-18 19:28:55 --> Language Class Initialized
INFO - 2016-09-18 19:28:55 --> Config Class Initialized
INFO - 2016-09-18 19:28:55 --> Loader Class Initialized
INFO - 2016-09-18 19:28:55 --> Helper loaded: url_helper
INFO - 2016-09-18 19:28:56 --> Database Driver Class Initialized
INFO - 2016-09-18 19:28:56 --> Controller Class Initialized
DEBUG - 2016-09-18 19:28:56 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:28:56 --> Model Class Initialized
INFO - 2016-09-18 19:28:56 --> Model Class Initialized
DEBUG - 2016-09-18 19:28:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 19:28:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 19:28:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 19:28:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tutup_angsuran.php
DEBUG - 2016-09-18 19:28:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 19:28:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 19:28:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 19:28:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 19:28:56 --> Final output sent to browser
DEBUG - 2016-09-18 19:28:56 --> Total execution time: 1.2710
INFO - 2016-09-18 19:29:02 --> Config Class Initialized
INFO - 2016-09-18 19:29:02 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:29:02 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:29:02 --> Utf8 Class Initialized
INFO - 2016-09-18 19:29:02 --> URI Class Initialized
INFO - 2016-09-18 19:29:02 --> Router Class Initialized
INFO - 2016-09-18 19:29:02 --> Output Class Initialized
INFO - 2016-09-18 19:29:02 --> Security Class Initialized
DEBUG - 2016-09-18 19:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:29:02 --> Input Class Initialized
INFO - 2016-09-18 19:29:02 --> Language Class Initialized
INFO - 2016-09-18 19:29:02 --> Language Class Initialized
INFO - 2016-09-18 19:29:02 --> Config Class Initialized
INFO - 2016-09-18 19:29:02 --> Loader Class Initialized
INFO - 2016-09-18 19:29:02 --> Helper loaded: url_helper
INFO - 2016-09-18 19:29:02 --> Database Driver Class Initialized
INFO - 2016-09-18 19:29:02 --> Controller Class Initialized
DEBUG - 2016-09-18 19:29:02 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:29:02 --> Model Class Initialized
INFO - 2016-09-18 19:29:02 --> Model Class Initialized
INFO - 2016-09-18 19:29:02 --> Database Driver Class Initialized
INFO - 2016-09-18 19:29:02 --> Final output sent to browser
DEBUG - 2016-09-18 19:29:02 --> Total execution time: 0.7473
INFO - 2016-09-18 19:29:08 --> Config Class Initialized
INFO - 2016-09-18 19:29:08 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:29:09 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:29:09 --> Utf8 Class Initialized
INFO - 2016-09-18 19:29:09 --> URI Class Initialized
INFO - 2016-09-18 19:29:09 --> Router Class Initialized
INFO - 2016-09-18 19:29:09 --> Output Class Initialized
INFO - 2016-09-18 19:29:09 --> Security Class Initialized
DEBUG - 2016-09-18 19:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:29:09 --> Input Class Initialized
INFO - 2016-09-18 19:29:09 --> Language Class Initialized
INFO - 2016-09-18 19:29:09 --> Language Class Initialized
INFO - 2016-09-18 19:29:09 --> Config Class Initialized
INFO - 2016-09-18 19:29:09 --> Loader Class Initialized
INFO - 2016-09-18 19:29:09 --> Helper loaded: url_helper
INFO - 2016-09-18 19:29:09 --> Database Driver Class Initialized
INFO - 2016-09-18 19:29:09 --> Controller Class Initialized
DEBUG - 2016-09-18 19:29:09 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:29:09 --> Model Class Initialized
INFO - 2016-09-18 19:29:09 --> Model Class Initialized
INFO - 2016-09-18 19:29:09 --> Database Driver Class Initialized
INFO - 2016-09-18 19:29:09 --> Database Driver Class Initialized
INFO - 2016-09-18 19:29:09 --> Database Driver Class Initialized
INFO - 2016-09-18 19:29:09 --> Database Driver Class Initialized
INFO - 2016-09-18 19:29:10 --> Database Driver Class Initialized
INFO - 2016-09-18 19:29:10 --> Database Driver Class Initialized
INFO - 2016-09-18 19:29:10 --> Database Driver Class Initialized
INFO - 2016-09-18 19:29:10 --> Database Driver Class Initialized
INFO - 2016-09-18 19:29:10 --> Database Driver Class Initialized
INFO - 2016-09-18 19:29:10 --> Database Driver Class Initialized
INFO - 2016-09-18 19:29:10 --> Database Driver Class Initialized
INFO - 2016-09-18 19:29:10 --> Database Driver Class Initialized
INFO - 2016-09-18 19:29:10 --> Database Driver Class Initialized
INFO - 2016-09-18 19:29:10 --> Database Driver Class Initialized
INFO - 2016-09-18 19:29:11 --> Database Driver Class Initialized
INFO - 2016-09-18 19:29:11 --> Database Driver Class Initialized
INFO - 2016-09-18 19:29:11 --> Database Driver Class Initialized
INFO - 2016-09-18 19:29:11 --> Database Driver Class Initialized
INFO - 2016-09-18 19:29:11 --> Database Driver Class Initialized
INFO - 2016-09-18 19:29:11 --> Database Driver Class Initialized
INFO - 2016-09-18 19:29:11 --> Database Driver Class Initialized
INFO - 2016-09-18 19:29:11 --> Database Driver Class Initialized
INFO - 2016-09-18 19:29:11 --> Database Driver Class Initialized
INFO - 2016-09-18 19:29:11 --> Database Driver Class Initialized
INFO - 2016-09-18 19:29:11 --> Database Driver Class Initialized
INFO - 2016-09-18 19:29:12 --> Database Driver Class Initialized
INFO - 2016-09-18 19:29:12 --> Database Driver Class Initialized
INFO - 2016-09-18 19:29:12 --> Database Driver Class Initialized
INFO - 2016-09-18 19:29:12 --> Database Driver Class Initialized
INFO - 2016-09-18 19:29:12 --> Database Driver Class Initialized
INFO - 2016-09-18 19:29:12 --> Database Driver Class Initialized
INFO - 2016-09-18 19:29:12 --> Database Driver Class Initialized
INFO - 2016-09-18 19:29:12 --> Database Driver Class Initialized
INFO - 2016-09-18 19:29:12 --> Database Driver Class Initialized
INFO - 2016-09-18 19:29:12 --> Database Driver Class Initialized
INFO - 2016-09-18 19:29:13 --> Database Driver Class Initialized
INFO - 2016-09-18 19:29:13 --> Database Driver Class Initialized
INFO - 2016-09-18 19:29:13 --> Database Driver Class Initialized
INFO - 2016-09-18 19:29:13 --> Database Driver Class Initialized
INFO - 2016-09-18 19:29:13 --> Database Driver Class Initialized
INFO - 2016-09-18 19:29:13 --> Database Driver Class Initialized
INFO - 2016-09-18 19:29:13 --> Final output sent to browser
DEBUG - 2016-09-18 19:29:13 --> Total execution time: 4.9341
INFO - 2016-09-18 19:29:42 --> Config Class Initialized
INFO - 2016-09-18 19:29:42 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:29:42 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:29:43 --> Utf8 Class Initialized
INFO - 2016-09-18 19:29:43 --> URI Class Initialized
INFO - 2016-09-18 19:29:43 --> Router Class Initialized
INFO - 2016-09-18 19:29:43 --> Output Class Initialized
INFO - 2016-09-18 19:29:43 --> Security Class Initialized
DEBUG - 2016-09-18 19:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:29:43 --> Input Class Initialized
INFO - 2016-09-18 19:29:43 --> Language Class Initialized
INFO - 2016-09-18 19:29:43 --> Language Class Initialized
INFO - 2016-09-18 19:29:43 --> Config Class Initialized
INFO - 2016-09-18 19:29:43 --> Loader Class Initialized
INFO - 2016-09-18 19:29:43 --> Helper loaded: url_helper
INFO - 2016-09-18 19:29:43 --> Database Driver Class Initialized
INFO - 2016-09-18 19:29:43 --> Controller Class Initialized
DEBUG - 2016-09-18 19:29:43 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:29:43 --> Model Class Initialized
INFO - 2016-09-18 19:29:43 --> Model Class Initialized
DEBUG - 2016-09-18 19:29:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 19:29:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 19:29:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 19:29:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/jurnal_umum.php
DEBUG - 2016-09-18 19:29:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 19:29:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 19:29:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 19:29:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 19:29:44 --> Final output sent to browser
DEBUG - 2016-09-18 19:29:44 --> Total execution time: 1.1239
INFO - 2016-09-18 19:29:49 --> Config Class Initialized
INFO - 2016-09-18 19:29:49 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:29:49 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:29:49 --> Utf8 Class Initialized
INFO - 2016-09-18 19:29:49 --> URI Class Initialized
INFO - 2016-09-18 19:29:49 --> Router Class Initialized
INFO - 2016-09-18 19:29:49 --> Output Class Initialized
INFO - 2016-09-18 19:29:50 --> Security Class Initialized
DEBUG - 2016-09-18 19:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:29:50 --> Input Class Initialized
INFO - 2016-09-18 19:29:50 --> Language Class Initialized
INFO - 2016-09-18 19:29:50 --> Language Class Initialized
INFO - 2016-09-18 19:29:50 --> Config Class Initialized
INFO - 2016-09-18 19:29:50 --> Loader Class Initialized
INFO - 2016-09-18 19:29:50 --> Helper loaded: url_helper
INFO - 2016-09-18 19:29:50 --> Database Driver Class Initialized
INFO - 2016-09-18 19:29:50 --> Controller Class Initialized
DEBUG - 2016-09-18 19:29:50 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:29:50 --> Model Class Initialized
INFO - 2016-09-18 19:29:50 --> Model Class Initialized
DEBUG - 2016-09-18 19:29:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_jurnal_umum.php
INFO - 2016-09-18 19:29:50 --> Final output sent to browser
DEBUG - 2016-09-18 19:29:50 --> Total execution time: 0.8031
INFO - 2016-09-18 19:36:54 --> Config Class Initialized
INFO - 2016-09-18 19:36:54 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:36:54 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:36:54 --> Utf8 Class Initialized
INFO - 2016-09-18 19:36:54 --> URI Class Initialized
INFO - 2016-09-18 19:36:54 --> Router Class Initialized
INFO - 2016-09-18 19:36:54 --> Output Class Initialized
INFO - 2016-09-18 19:36:54 --> Security Class Initialized
DEBUG - 2016-09-18 19:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:36:54 --> Input Class Initialized
INFO - 2016-09-18 19:36:54 --> Language Class Initialized
INFO - 2016-09-18 19:36:54 --> Language Class Initialized
INFO - 2016-09-18 19:36:54 --> Config Class Initialized
INFO - 2016-09-18 19:36:54 --> Loader Class Initialized
INFO - 2016-09-18 19:36:54 --> Helper loaded: url_helper
INFO - 2016-09-18 19:36:54 --> Database Driver Class Initialized
INFO - 2016-09-18 19:36:54 --> Controller Class Initialized
DEBUG - 2016-09-18 19:36:54 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:36:54 --> Model Class Initialized
INFO - 2016-09-18 19:36:54 --> Model Class Initialized
DEBUG - 2016-09-18 19:36:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 19:36:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 19:36:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
ERROR - 2016-09-18 19:36:55 --> Severity: Notice --> Undefined index: kd_akun E:\SERVER\htdocs\koperasiweda\application\views\main_html\content\laporan\buku_besar.php 26
ERROR - 2016-09-18 19:36:55 --> Severity: Notice --> Undefined index: kd_akun E:\SERVER\htdocs\koperasiweda\application\views\main_html\content\laporan\buku_besar.php 26
ERROR - 2016-09-18 19:36:55 --> Severity: Notice --> Undefined index: kd_akun E:\SERVER\htdocs\koperasiweda\application\views\main_html\content\laporan\buku_besar.php 26
ERROR - 2016-09-18 19:36:55 --> Severity: Notice --> Undefined index: kd_akun E:\SERVER\htdocs\koperasiweda\application\views\main_html\content\laporan\buku_besar.php 26
ERROR - 2016-09-18 19:36:55 --> Severity: Notice --> Undefined index: kd_akun E:\SERVER\htdocs\koperasiweda\application\views\main_html\content\laporan\buku_besar.php 26
DEBUG - 2016-09-18 19:36:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/buku_besar.php
DEBUG - 2016-09-18 19:36:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 19:36:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 19:36:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 19:36:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 19:36:55 --> Final output sent to browser
DEBUG - 2016-09-18 19:36:55 --> Total execution time: 1.2592
INFO - 2016-09-18 19:37:18 --> Config Class Initialized
INFO - 2016-09-18 19:37:18 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:37:18 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:37:18 --> Utf8 Class Initialized
INFO - 2016-09-18 19:37:18 --> URI Class Initialized
INFO - 2016-09-18 19:37:18 --> Router Class Initialized
INFO - 2016-09-18 19:37:18 --> Output Class Initialized
INFO - 2016-09-18 19:37:18 --> Security Class Initialized
DEBUG - 2016-09-18 19:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:37:18 --> Input Class Initialized
INFO - 2016-09-18 19:37:18 --> Language Class Initialized
INFO - 2016-09-18 19:37:18 --> Language Class Initialized
INFO - 2016-09-18 19:37:18 --> Config Class Initialized
INFO - 2016-09-18 19:37:18 --> Loader Class Initialized
INFO - 2016-09-18 19:37:19 --> Helper loaded: url_helper
INFO - 2016-09-18 19:37:19 --> Database Driver Class Initialized
INFO - 2016-09-18 19:37:19 --> Controller Class Initialized
DEBUG - 2016-09-18 19:37:19 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:37:19 --> Model Class Initialized
INFO - 2016-09-18 19:37:19 --> Model Class Initialized
DEBUG - 2016-09-18 19:37:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 19:37:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 19:37:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 19:37:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/buku_besar.php
DEBUG - 2016-09-18 19:37:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 19:37:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 19:37:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 19:37:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 19:37:19 --> Final output sent to browser
DEBUG - 2016-09-18 19:37:19 --> Total execution time: 1.4649
INFO - 2016-09-18 19:39:18 --> Config Class Initialized
INFO - 2016-09-18 19:39:18 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:39:18 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:39:18 --> Utf8 Class Initialized
INFO - 2016-09-18 19:39:18 --> URI Class Initialized
INFO - 2016-09-18 19:39:18 --> Router Class Initialized
INFO - 2016-09-18 19:39:19 --> Output Class Initialized
INFO - 2016-09-18 19:39:19 --> Security Class Initialized
DEBUG - 2016-09-18 19:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:39:19 --> Input Class Initialized
INFO - 2016-09-18 19:39:19 --> Language Class Initialized
INFO - 2016-09-18 19:39:19 --> Language Class Initialized
INFO - 2016-09-18 19:39:19 --> Config Class Initialized
INFO - 2016-09-18 19:39:19 --> Loader Class Initialized
INFO - 2016-09-18 19:39:19 --> Helper loaded: url_helper
INFO - 2016-09-18 19:39:19 --> Database Driver Class Initialized
INFO - 2016-09-18 19:39:19 --> Controller Class Initialized
DEBUG - 2016-09-18 19:39:19 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:39:19 --> Model Class Initialized
INFO - 2016-09-18 19:39:19 --> Model Class Initialized
DEBUG - 2016-09-18 19:39:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 19:39:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 19:39:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 19:39:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/buku_besar.php
DEBUG - 2016-09-18 19:39:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 19:39:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 19:39:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 19:39:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 19:39:19 --> Final output sent to browser
DEBUG - 2016-09-18 19:39:19 --> Total execution time: 1.0594
INFO - 2016-09-18 19:40:36 --> Config Class Initialized
INFO - 2016-09-18 19:40:36 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:40:36 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:40:36 --> Utf8 Class Initialized
INFO - 2016-09-18 19:40:36 --> URI Class Initialized
INFO - 2016-09-18 19:40:36 --> Router Class Initialized
INFO - 2016-09-18 19:40:36 --> Output Class Initialized
INFO - 2016-09-18 19:40:36 --> Security Class Initialized
DEBUG - 2016-09-18 19:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:40:36 --> Input Class Initialized
INFO - 2016-09-18 19:40:36 --> Language Class Initialized
INFO - 2016-09-18 19:40:36 --> Language Class Initialized
INFO - 2016-09-18 19:40:37 --> Config Class Initialized
INFO - 2016-09-18 19:40:37 --> Loader Class Initialized
INFO - 2016-09-18 19:40:37 --> Helper loaded: url_helper
INFO - 2016-09-18 19:40:37 --> Database Driver Class Initialized
INFO - 2016-09-18 19:40:37 --> Controller Class Initialized
DEBUG - 2016-09-18 19:40:37 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:40:37 --> Model Class Initialized
INFO - 2016-09-18 19:40:37 --> Model Class Initialized
DEBUG - 2016-09-18 19:40:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 19:40:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 19:40:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 19:40:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/buku_besar.php
DEBUG - 2016-09-18 19:40:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 19:40:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 19:40:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 19:40:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 19:40:37 --> Final output sent to browser
DEBUG - 2016-09-18 19:40:37 --> Total execution time: 1.2267
INFO - 2016-09-18 19:41:22 --> Config Class Initialized
INFO - 2016-09-18 19:41:23 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:41:23 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:41:23 --> Utf8 Class Initialized
INFO - 2016-09-18 19:41:23 --> URI Class Initialized
INFO - 2016-09-18 19:41:23 --> Router Class Initialized
INFO - 2016-09-18 19:41:23 --> Output Class Initialized
INFO - 2016-09-18 19:41:23 --> Security Class Initialized
DEBUG - 2016-09-18 19:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:41:23 --> Input Class Initialized
INFO - 2016-09-18 19:41:23 --> Language Class Initialized
INFO - 2016-09-18 19:41:23 --> Language Class Initialized
INFO - 2016-09-18 19:41:23 --> Config Class Initialized
INFO - 2016-09-18 19:41:23 --> Loader Class Initialized
INFO - 2016-09-18 19:41:23 --> Helper loaded: url_helper
INFO - 2016-09-18 19:41:23 --> Database Driver Class Initialized
INFO - 2016-09-18 19:41:23 --> Controller Class Initialized
DEBUG - 2016-09-18 19:41:23 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:41:23 --> Model Class Initialized
INFO - 2016-09-18 19:41:23 --> Model Class Initialized
DEBUG - 2016-09-18 19:41:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 19:41:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 19:41:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 19:41:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/buku_besar.php
DEBUG - 2016-09-18 19:41:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 19:41:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 19:41:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 19:41:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 19:41:24 --> Final output sent to browser
DEBUG - 2016-09-18 19:41:24 --> Total execution time: 1.2257
INFO - 2016-09-18 19:47:59 --> Config Class Initialized
INFO - 2016-09-18 19:47:59 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:47:59 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:47:59 --> Utf8 Class Initialized
INFO - 2016-09-18 19:47:59 --> URI Class Initialized
INFO - 2016-09-18 19:47:59 --> Router Class Initialized
INFO - 2016-09-18 19:48:00 --> Output Class Initialized
INFO - 2016-09-18 19:48:00 --> Security Class Initialized
DEBUG - 2016-09-18 19:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:48:00 --> Input Class Initialized
INFO - 2016-09-18 19:48:00 --> Language Class Initialized
INFO - 2016-09-18 19:48:00 --> Language Class Initialized
INFO - 2016-09-18 19:48:00 --> Config Class Initialized
INFO - 2016-09-18 19:48:00 --> Loader Class Initialized
INFO - 2016-09-18 19:48:00 --> Helper loaded: url_helper
INFO - 2016-09-18 19:48:00 --> Database Driver Class Initialized
INFO - 2016-09-18 19:48:00 --> Controller Class Initialized
DEBUG - 2016-09-18 19:48:00 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:48:00 --> Model Class Initialized
INFO - 2016-09-18 19:48:00 --> Model Class Initialized
DEBUG - 2016-09-18 19:48:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-18 19:48:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-18 19:48:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-18 19:48:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/buku_besar.php
DEBUG - 2016-09-18 19:48:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-18 19:48:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-18 19:48:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-18 19:48:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-18 19:48:00 --> Final output sent to browser
DEBUG - 2016-09-18 19:48:01 --> Total execution time: 1.2105
INFO - 2016-09-18 19:48:11 --> Config Class Initialized
INFO - 2016-09-18 19:48:11 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:48:11 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:48:11 --> Utf8 Class Initialized
INFO - 2016-09-18 19:48:11 --> URI Class Initialized
INFO - 2016-09-18 19:48:11 --> Router Class Initialized
INFO - 2016-09-18 19:48:11 --> Output Class Initialized
INFO - 2016-09-18 19:48:11 --> Security Class Initialized
DEBUG - 2016-09-18 19:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:48:11 --> Input Class Initialized
INFO - 2016-09-18 19:48:11 --> Language Class Initialized
INFO - 2016-09-18 19:48:11 --> Language Class Initialized
INFO - 2016-09-18 19:48:11 --> Config Class Initialized
INFO - 2016-09-18 19:48:11 --> Loader Class Initialized
INFO - 2016-09-18 19:48:11 --> Helper loaded: url_helper
INFO - 2016-09-18 19:48:11 --> Database Driver Class Initialized
INFO - 2016-09-18 19:48:11 --> Controller Class Initialized
DEBUG - 2016-09-18 19:48:11 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:48:11 --> Model Class Initialized
INFO - 2016-09-18 19:48:12 --> Model Class Initialized
DEBUG - 2016-09-18 19:48:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_buku_besar.php
INFO - 2016-09-18 19:48:12 --> Final output sent to browser
DEBUG - 2016-09-18 19:48:12 --> Total execution time: 1.0054
INFO - 2016-09-18 19:48:18 --> Config Class Initialized
INFO - 2016-09-18 19:48:18 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:48:18 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:48:18 --> Utf8 Class Initialized
INFO - 2016-09-18 19:48:18 --> URI Class Initialized
INFO - 2016-09-18 19:48:18 --> Router Class Initialized
INFO - 2016-09-18 19:48:19 --> Output Class Initialized
INFO - 2016-09-18 19:48:19 --> Security Class Initialized
DEBUG - 2016-09-18 19:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:48:19 --> Input Class Initialized
INFO - 2016-09-18 19:48:19 --> Language Class Initialized
INFO - 2016-09-18 19:48:19 --> Language Class Initialized
INFO - 2016-09-18 19:48:19 --> Config Class Initialized
INFO - 2016-09-18 19:48:19 --> Loader Class Initialized
INFO - 2016-09-18 19:48:19 --> Helper loaded: url_helper
INFO - 2016-09-18 19:48:19 --> Database Driver Class Initialized
INFO - 2016-09-18 19:48:19 --> Controller Class Initialized
DEBUG - 2016-09-18 19:48:19 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:48:19 --> Model Class Initialized
INFO - 2016-09-18 19:48:19 --> Model Class Initialized
DEBUG - 2016-09-18 19:48:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_buku_besar.php
INFO - 2016-09-18 19:48:19 --> Final output sent to browser
DEBUG - 2016-09-18 19:48:19 --> Total execution time: 0.9632
INFO - 2016-09-18 19:48:31 --> Config Class Initialized
INFO - 2016-09-18 19:48:31 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:48:31 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:48:31 --> Utf8 Class Initialized
INFO - 2016-09-18 19:48:31 --> URI Class Initialized
INFO - 2016-09-18 19:48:31 --> Router Class Initialized
INFO - 2016-09-18 19:48:31 --> Output Class Initialized
INFO - 2016-09-18 19:48:31 --> Security Class Initialized
DEBUG - 2016-09-18 19:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:48:31 --> Input Class Initialized
INFO - 2016-09-18 19:48:31 --> Language Class Initialized
INFO - 2016-09-18 19:48:31 --> Language Class Initialized
INFO - 2016-09-18 19:48:31 --> Config Class Initialized
INFO - 2016-09-18 19:48:31 --> Loader Class Initialized
INFO - 2016-09-18 19:48:32 --> Helper loaded: url_helper
INFO - 2016-09-18 19:48:32 --> Database Driver Class Initialized
INFO - 2016-09-18 19:48:32 --> Controller Class Initialized
DEBUG - 2016-09-18 19:48:32 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:48:32 --> Model Class Initialized
INFO - 2016-09-18 19:48:32 --> Model Class Initialized
DEBUG - 2016-09-18 19:48:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_buku_besar.php
INFO - 2016-09-18 19:48:32 --> Final output sent to browser
DEBUG - 2016-09-18 19:48:32 --> Total execution time: 1.0368
INFO - 2016-09-18 19:48:36 --> Config Class Initialized
INFO - 2016-09-18 19:48:36 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:48:36 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:48:36 --> Utf8 Class Initialized
INFO - 2016-09-18 19:48:36 --> URI Class Initialized
INFO - 2016-09-18 19:48:36 --> Router Class Initialized
INFO - 2016-09-18 19:48:36 --> Output Class Initialized
INFO - 2016-09-18 19:48:36 --> Security Class Initialized
DEBUG - 2016-09-18 19:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:48:36 --> Input Class Initialized
INFO - 2016-09-18 19:48:36 --> Language Class Initialized
INFO - 2016-09-18 19:48:36 --> Language Class Initialized
INFO - 2016-09-18 19:48:36 --> Config Class Initialized
INFO - 2016-09-18 19:48:36 --> Loader Class Initialized
INFO - 2016-09-18 19:48:36 --> Helper loaded: url_helper
INFO - 2016-09-18 19:48:36 --> Database Driver Class Initialized
INFO - 2016-09-18 19:48:36 --> Controller Class Initialized
DEBUG - 2016-09-18 19:48:36 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:48:36 --> Model Class Initialized
INFO - 2016-09-18 19:48:36 --> Model Class Initialized
DEBUG - 2016-09-18 19:48:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_buku_besar.php
INFO - 2016-09-18 19:48:37 --> Final output sent to browser
DEBUG - 2016-09-18 19:48:37 --> Total execution time: 0.8394
INFO - 2016-09-18 19:48:39 --> Config Class Initialized
INFO - 2016-09-18 19:48:39 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:48:39 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:48:39 --> Utf8 Class Initialized
INFO - 2016-09-18 19:48:39 --> URI Class Initialized
INFO - 2016-09-18 19:48:40 --> Router Class Initialized
INFO - 2016-09-18 19:48:40 --> Output Class Initialized
INFO - 2016-09-18 19:48:40 --> Security Class Initialized
DEBUG - 2016-09-18 19:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:48:40 --> Input Class Initialized
INFO - 2016-09-18 19:48:40 --> Language Class Initialized
INFO - 2016-09-18 19:48:40 --> Language Class Initialized
INFO - 2016-09-18 19:48:40 --> Config Class Initialized
INFO - 2016-09-18 19:48:40 --> Loader Class Initialized
INFO - 2016-09-18 19:48:40 --> Helper loaded: url_helper
INFO - 2016-09-18 19:48:40 --> Database Driver Class Initialized
INFO - 2016-09-18 19:48:40 --> Controller Class Initialized
DEBUG - 2016-09-18 19:48:40 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:48:40 --> Model Class Initialized
INFO - 2016-09-18 19:48:40 --> Model Class Initialized
DEBUG - 2016-09-18 19:48:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_buku_besar.php
INFO - 2016-09-18 19:48:40 --> Final output sent to browser
DEBUG - 2016-09-18 19:48:40 --> Total execution time: 0.9841
INFO - 2016-09-18 19:48:48 --> Config Class Initialized
INFO - 2016-09-18 19:48:48 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:48:48 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:48:48 --> Utf8 Class Initialized
INFO - 2016-09-18 19:48:48 --> URI Class Initialized
INFO - 2016-09-18 19:48:48 --> Router Class Initialized
INFO - 2016-09-18 19:48:48 --> Output Class Initialized
INFO - 2016-09-18 19:48:48 --> Security Class Initialized
DEBUG - 2016-09-18 19:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:48:48 --> Input Class Initialized
INFO - 2016-09-18 19:48:48 --> Language Class Initialized
INFO - 2016-09-18 19:48:48 --> Language Class Initialized
INFO - 2016-09-18 19:48:48 --> Config Class Initialized
INFO - 2016-09-18 19:48:48 --> Loader Class Initialized
INFO - 2016-09-18 19:48:48 --> Helper loaded: url_helper
INFO - 2016-09-18 19:48:48 --> Database Driver Class Initialized
INFO - 2016-09-18 19:48:48 --> Controller Class Initialized
DEBUG - 2016-09-18 19:48:48 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:48:48 --> Model Class Initialized
INFO - 2016-09-18 19:48:48 --> Model Class Initialized
DEBUG - 2016-09-18 19:48:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_buku_besar.php
INFO - 2016-09-18 19:48:48 --> Final output sent to browser
DEBUG - 2016-09-18 19:48:48 --> Total execution time: 0.7824
INFO - 2016-09-18 19:49:39 --> Config Class Initialized
INFO - 2016-09-18 19:49:39 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:49:39 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:49:39 --> Utf8 Class Initialized
INFO - 2016-09-18 19:49:39 --> URI Class Initialized
INFO - 2016-09-18 19:49:39 --> Router Class Initialized
INFO - 2016-09-18 19:49:39 --> Output Class Initialized
INFO - 2016-09-18 19:49:39 --> Security Class Initialized
DEBUG - 2016-09-18 19:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:49:39 --> Input Class Initialized
INFO - 2016-09-18 19:49:39 --> Language Class Initialized
INFO - 2016-09-18 19:49:39 --> Language Class Initialized
INFO - 2016-09-18 19:49:39 --> Config Class Initialized
INFO - 2016-09-18 19:49:40 --> Loader Class Initialized
INFO - 2016-09-18 19:49:40 --> Helper loaded: url_helper
INFO - 2016-09-18 19:49:40 --> Database Driver Class Initialized
INFO - 2016-09-18 19:49:40 --> Controller Class Initialized
DEBUG - 2016-09-18 19:49:40 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:49:40 --> Model Class Initialized
INFO - 2016-09-18 19:49:40 --> Model Class Initialized
DEBUG - 2016-09-18 19:49:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_buku_besar.php
INFO - 2016-09-18 19:49:40 --> Final output sent to browser
DEBUG - 2016-09-18 19:49:40 --> Total execution time: 0.8936
INFO - 2016-09-18 19:50:03 --> Config Class Initialized
INFO - 2016-09-18 19:50:03 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:50:03 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:50:03 --> Utf8 Class Initialized
INFO - 2016-09-18 19:50:03 --> URI Class Initialized
INFO - 2016-09-18 19:50:03 --> Router Class Initialized
INFO - 2016-09-18 19:50:03 --> Output Class Initialized
INFO - 2016-09-18 19:50:03 --> Security Class Initialized
DEBUG - 2016-09-18 19:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:50:03 --> Input Class Initialized
INFO - 2016-09-18 19:50:03 --> Language Class Initialized
INFO - 2016-09-18 19:50:04 --> Language Class Initialized
INFO - 2016-09-18 19:50:04 --> Config Class Initialized
INFO - 2016-09-18 19:50:04 --> Loader Class Initialized
INFO - 2016-09-18 19:50:04 --> Helper loaded: url_helper
INFO - 2016-09-18 19:50:04 --> Database Driver Class Initialized
INFO - 2016-09-18 19:50:04 --> Controller Class Initialized
DEBUG - 2016-09-18 19:50:04 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:50:04 --> Model Class Initialized
INFO - 2016-09-18 19:50:04 --> Model Class Initialized
DEBUG - 2016-09-18 19:50:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_buku_besar.php
INFO - 2016-09-18 19:50:04 --> Final output sent to browser
DEBUG - 2016-09-18 19:50:04 --> Total execution time: 0.8137
INFO - 2016-09-18 19:50:21 --> Config Class Initialized
INFO - 2016-09-18 19:50:21 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:50:21 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:50:21 --> Utf8 Class Initialized
INFO - 2016-09-18 19:50:21 --> URI Class Initialized
INFO - 2016-09-18 19:50:21 --> Router Class Initialized
INFO - 2016-09-18 19:50:21 --> Output Class Initialized
INFO - 2016-09-18 19:50:21 --> Security Class Initialized
DEBUG - 2016-09-18 19:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:50:21 --> Input Class Initialized
INFO - 2016-09-18 19:50:21 --> Language Class Initialized
INFO - 2016-09-18 19:50:21 --> Language Class Initialized
INFO - 2016-09-18 19:50:22 --> Config Class Initialized
INFO - 2016-09-18 19:50:22 --> Loader Class Initialized
INFO - 2016-09-18 19:50:22 --> Helper loaded: url_helper
INFO - 2016-09-18 19:50:22 --> Database Driver Class Initialized
INFO - 2016-09-18 19:50:22 --> Controller Class Initialized
DEBUG - 2016-09-18 19:50:22 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:50:22 --> Model Class Initialized
INFO - 2016-09-18 19:50:22 --> Model Class Initialized
DEBUG - 2016-09-18 19:50:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_buku_besar.php
INFO - 2016-09-18 19:50:22 --> Final output sent to browser
DEBUG - 2016-09-18 19:50:22 --> Total execution time: 1.0317
INFO - 2016-09-18 19:51:43 --> Config Class Initialized
INFO - 2016-09-18 19:51:43 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:51:43 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:51:43 --> Utf8 Class Initialized
INFO - 2016-09-18 19:51:43 --> URI Class Initialized
INFO - 2016-09-18 19:51:43 --> Router Class Initialized
INFO - 2016-09-18 19:51:43 --> Output Class Initialized
INFO - 2016-09-18 19:51:43 --> Security Class Initialized
DEBUG - 2016-09-18 19:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:51:44 --> Input Class Initialized
INFO - 2016-09-18 19:51:44 --> Language Class Initialized
INFO - 2016-09-18 19:51:44 --> Language Class Initialized
INFO - 2016-09-18 19:51:44 --> Config Class Initialized
INFO - 2016-09-18 19:51:44 --> Loader Class Initialized
INFO - 2016-09-18 19:51:44 --> Helper loaded: url_helper
INFO - 2016-09-18 19:51:44 --> Database Driver Class Initialized
INFO - 2016-09-18 19:51:44 --> Controller Class Initialized
DEBUG - 2016-09-18 19:51:44 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:51:44 --> Model Class Initialized
INFO - 2016-09-18 19:51:44 --> Model Class Initialized
DEBUG - 2016-09-18 19:51:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_buku_besar.php
INFO - 2016-09-18 19:51:44 --> Final output sent to browser
DEBUG - 2016-09-18 19:51:44 --> Total execution time: 0.8668
INFO - 2016-09-18 19:52:10 --> Config Class Initialized
INFO - 2016-09-18 19:52:10 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:52:10 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:52:10 --> Utf8 Class Initialized
INFO - 2016-09-18 19:52:10 --> URI Class Initialized
INFO - 2016-09-18 19:52:10 --> Router Class Initialized
INFO - 2016-09-18 19:52:10 --> Output Class Initialized
INFO - 2016-09-18 19:52:10 --> Security Class Initialized
DEBUG - 2016-09-18 19:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:52:10 --> Input Class Initialized
INFO - 2016-09-18 19:52:10 --> Language Class Initialized
INFO - 2016-09-18 19:52:10 --> Language Class Initialized
INFO - 2016-09-18 19:52:10 --> Config Class Initialized
INFO - 2016-09-18 19:52:10 --> Loader Class Initialized
INFO - 2016-09-18 19:52:10 --> Helper loaded: url_helper
INFO - 2016-09-18 19:52:11 --> Database Driver Class Initialized
INFO - 2016-09-18 19:52:11 --> Controller Class Initialized
DEBUG - 2016-09-18 19:52:11 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:52:11 --> Model Class Initialized
INFO - 2016-09-18 19:52:11 --> Model Class Initialized
DEBUG - 2016-09-18 19:52:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_buku_besar.php
INFO - 2016-09-18 19:52:11 --> Final output sent to browser
DEBUG - 2016-09-18 19:52:11 --> Total execution time: 0.8760
INFO - 2016-09-18 19:52:44 --> Config Class Initialized
INFO - 2016-09-18 19:52:44 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:52:44 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:52:44 --> Utf8 Class Initialized
INFO - 2016-09-18 19:52:44 --> URI Class Initialized
INFO - 2016-09-18 19:52:44 --> Router Class Initialized
INFO - 2016-09-18 19:52:44 --> Output Class Initialized
INFO - 2016-09-18 19:52:44 --> Security Class Initialized
DEBUG - 2016-09-18 19:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:52:44 --> Input Class Initialized
INFO - 2016-09-18 19:52:44 --> Language Class Initialized
INFO - 2016-09-18 19:52:44 --> Language Class Initialized
INFO - 2016-09-18 19:52:44 --> Config Class Initialized
INFO - 2016-09-18 19:52:44 --> Loader Class Initialized
INFO - 2016-09-18 19:52:44 --> Helper loaded: url_helper
INFO - 2016-09-18 19:52:44 --> Database Driver Class Initialized
INFO - 2016-09-18 19:52:44 --> Controller Class Initialized
DEBUG - 2016-09-18 19:52:45 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:52:45 --> Model Class Initialized
INFO - 2016-09-18 19:52:45 --> Model Class Initialized
DEBUG - 2016-09-18 19:52:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_buku_besar.php
INFO - 2016-09-18 19:52:45 --> Final output sent to browser
DEBUG - 2016-09-18 19:52:45 --> Total execution time: 0.8912
INFO - 2016-09-18 19:53:08 --> Config Class Initialized
INFO - 2016-09-18 19:53:08 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:53:08 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:53:08 --> Utf8 Class Initialized
INFO - 2016-09-18 19:53:08 --> URI Class Initialized
INFO - 2016-09-18 19:53:08 --> Router Class Initialized
INFO - 2016-09-18 19:53:09 --> Output Class Initialized
INFO - 2016-09-18 19:53:09 --> Security Class Initialized
DEBUG - 2016-09-18 19:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:53:09 --> Input Class Initialized
INFO - 2016-09-18 19:53:09 --> Language Class Initialized
INFO - 2016-09-18 19:53:09 --> Language Class Initialized
INFO - 2016-09-18 19:53:09 --> Config Class Initialized
INFO - 2016-09-18 19:53:09 --> Loader Class Initialized
INFO - 2016-09-18 19:53:09 --> Helper loaded: url_helper
INFO - 2016-09-18 19:53:09 --> Database Driver Class Initialized
INFO - 2016-09-18 19:53:09 --> Controller Class Initialized
DEBUG - 2016-09-18 19:53:09 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:53:09 --> Model Class Initialized
INFO - 2016-09-18 19:53:09 --> Model Class Initialized
DEBUG - 2016-09-18 19:53:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_buku_besar.php
INFO - 2016-09-18 19:53:09 --> Final output sent to browser
DEBUG - 2016-09-18 19:53:09 --> Total execution time: 1.2268
INFO - 2016-09-18 19:53:20 --> Config Class Initialized
INFO - 2016-09-18 19:53:20 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:53:20 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:53:20 --> Utf8 Class Initialized
INFO - 2016-09-18 19:53:20 --> URI Class Initialized
INFO - 2016-09-18 19:53:20 --> Router Class Initialized
INFO - 2016-09-18 19:53:20 --> Output Class Initialized
INFO - 2016-09-18 19:53:20 --> Security Class Initialized
DEBUG - 2016-09-18 19:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:53:20 --> Input Class Initialized
INFO - 2016-09-18 19:53:20 --> Language Class Initialized
INFO - 2016-09-18 19:53:20 --> Language Class Initialized
INFO - 2016-09-18 19:53:20 --> Config Class Initialized
INFO - 2016-09-18 19:53:20 --> Loader Class Initialized
INFO - 2016-09-18 19:53:20 --> Helper loaded: url_helper
INFO - 2016-09-18 19:53:20 --> Database Driver Class Initialized
INFO - 2016-09-18 19:53:20 --> Controller Class Initialized
DEBUG - 2016-09-18 19:53:20 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:53:20 --> Model Class Initialized
INFO - 2016-09-18 19:53:20 --> Model Class Initialized
DEBUG - 2016-09-18 19:53:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_buku_besar.php
INFO - 2016-09-18 19:53:20 --> Final output sent to browser
DEBUG - 2016-09-18 19:53:20 --> Total execution time: 0.7526
INFO - 2016-09-18 19:53:26 --> Config Class Initialized
INFO - 2016-09-18 19:53:26 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:53:26 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:53:26 --> Utf8 Class Initialized
INFO - 2016-09-18 19:53:26 --> URI Class Initialized
INFO - 2016-09-18 19:53:27 --> Router Class Initialized
INFO - 2016-09-18 19:53:27 --> Output Class Initialized
INFO - 2016-09-18 19:53:27 --> Security Class Initialized
DEBUG - 2016-09-18 19:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:53:27 --> Input Class Initialized
INFO - 2016-09-18 19:53:27 --> Language Class Initialized
INFO - 2016-09-18 19:53:27 --> Language Class Initialized
INFO - 2016-09-18 19:53:27 --> Config Class Initialized
INFO - 2016-09-18 19:53:27 --> Loader Class Initialized
INFO - 2016-09-18 19:53:27 --> Helper loaded: url_helper
INFO - 2016-09-18 19:53:27 --> Database Driver Class Initialized
INFO - 2016-09-18 19:53:27 --> Controller Class Initialized
DEBUG - 2016-09-18 19:53:27 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:53:27 --> Model Class Initialized
INFO - 2016-09-18 19:53:27 --> Model Class Initialized
DEBUG - 2016-09-18 19:53:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_buku_besar.php
INFO - 2016-09-18 19:53:27 --> Final output sent to browser
DEBUG - 2016-09-18 19:53:27 --> Total execution time: 1.0921
INFO - 2016-09-18 19:53:46 --> Config Class Initialized
INFO - 2016-09-18 19:53:46 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:53:46 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:53:46 --> Utf8 Class Initialized
INFO - 2016-09-18 19:53:46 --> URI Class Initialized
INFO - 2016-09-18 19:53:46 --> Router Class Initialized
INFO - 2016-09-18 19:53:46 --> Output Class Initialized
INFO - 2016-09-18 19:53:46 --> Security Class Initialized
DEBUG - 2016-09-18 19:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:53:46 --> Input Class Initialized
INFO - 2016-09-18 19:53:46 --> Language Class Initialized
INFO - 2016-09-18 19:53:46 --> Language Class Initialized
INFO - 2016-09-18 19:53:46 --> Config Class Initialized
INFO - 2016-09-18 19:53:46 --> Loader Class Initialized
INFO - 2016-09-18 19:53:46 --> Helper loaded: url_helper
INFO - 2016-09-18 19:53:46 --> Database Driver Class Initialized
INFO - 2016-09-18 19:53:46 --> Controller Class Initialized
DEBUG - 2016-09-18 19:53:46 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:53:46 --> Model Class Initialized
INFO - 2016-09-18 19:53:46 --> Model Class Initialized
ERROR - 2016-09-18 19:53:46 --> Severity: Notice --> Undefined index: akun E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 813
ERROR - 2016-09-18 19:53:46 --> Severity: Notice --> Undefined variable: saldoDebit E:\SERVER\htdocs\koperasiweda\application\views\main_html\content\laporan\data_buku_besar.php 38
ERROR - 2016-09-18 19:53:47 --> Severity: Notice --> Undefined variable: saldoKredit E:\SERVER\htdocs\koperasiweda\application\views\main_html\content\laporan\data_buku_besar.php 39
DEBUG - 2016-09-18 19:53:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_buku_besar.php
INFO - 2016-09-18 19:53:47 --> Final output sent to browser
DEBUG - 2016-09-18 19:53:47 --> Total execution time: 0.9253
INFO - 2016-09-18 19:53:54 --> Config Class Initialized
INFO - 2016-09-18 19:53:54 --> Hooks Class Initialized
DEBUG - 2016-09-18 19:53:54 --> UTF-8 Support Enabled
INFO - 2016-09-18 19:53:54 --> Utf8 Class Initialized
INFO - 2016-09-18 19:53:54 --> URI Class Initialized
INFO - 2016-09-18 19:53:54 --> Router Class Initialized
INFO - 2016-09-18 19:53:54 --> Output Class Initialized
INFO - 2016-09-18 19:53:54 --> Security Class Initialized
DEBUG - 2016-09-18 19:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-18 19:53:54 --> Input Class Initialized
INFO - 2016-09-18 19:53:54 --> Language Class Initialized
INFO - 2016-09-18 19:53:54 --> Language Class Initialized
INFO - 2016-09-18 19:53:54 --> Config Class Initialized
INFO - 2016-09-18 19:53:54 --> Loader Class Initialized
INFO - 2016-09-18 19:53:54 --> Helper loaded: url_helper
INFO - 2016-09-18 19:53:54 --> Database Driver Class Initialized
INFO - 2016-09-18 19:53:54 --> Controller Class Initialized
DEBUG - 2016-09-18 19:53:54 --> Index MX_Controller Initialized
INFO - 2016-09-18 19:53:54 --> Model Class Initialized
INFO - 2016-09-18 19:53:54 --> Model Class Initialized
DEBUG - 2016-09-18 19:53:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_buku_besar.php
INFO - 2016-09-18 19:53:55 --> Final output sent to browser
DEBUG - 2016-09-18 19:53:55 --> Total execution time: 0.7427
