<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-09-15 00:05:28 --> Config Class Initialized
INFO - 2016-09-15 00:05:28 --> Hooks Class Initialized
DEBUG - 2016-09-15 00:05:28 --> UTF-8 Support Enabled
INFO - 2016-09-15 00:05:28 --> Utf8 Class Initialized
INFO - 2016-09-15 00:05:28 --> URI Class Initialized
INFO - 2016-09-15 00:05:28 --> Router Class Initialized
INFO - 2016-09-15 00:05:28 --> Output Class Initialized
INFO - 2016-09-15 00:05:28 --> Security Class Initialized
DEBUG - 2016-09-15 00:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 00:05:28 --> Input Class Initialized
INFO - 2016-09-15 00:05:28 --> Language Class Initialized
INFO - 2016-09-15 00:05:28 --> Language Class Initialized
INFO - 2016-09-15 00:05:28 --> Config Class Initialized
INFO - 2016-09-15 00:05:28 --> Loader Class Initialized
INFO - 2016-09-15 00:05:28 --> Helper loaded: url_helper
INFO - 2016-09-15 00:05:28 --> Database Driver Class Initialized
INFO - 2016-09-15 00:05:28 --> Controller Class Initialized
DEBUG - 2016-09-15 00:05:28 --> Index MX_Controller Initialized
INFO - 2016-09-15 00:05:28 --> Model Class Initialized
INFO - 2016-09-15 00:05:28 --> Model Class Initialized
DEBUG - 2016-09-15 00:05:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 00:05:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 00:05:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 00:05:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_bayar_angsuran.php
DEBUG - 2016-09-15 00:05:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 00:05:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 00:05:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 00:05:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 00:05:28 --> Final output sent to browser
DEBUG - 2016-09-15 00:05:28 --> Total execution time: 0.4867
INFO - 2016-09-15 00:05:32 --> Config Class Initialized
INFO - 2016-09-15 00:05:32 --> Hooks Class Initialized
DEBUG - 2016-09-15 00:05:32 --> UTF-8 Support Enabled
INFO - 2016-09-15 00:05:32 --> Utf8 Class Initialized
INFO - 2016-09-15 00:05:32 --> URI Class Initialized
INFO - 2016-09-15 00:05:32 --> Router Class Initialized
INFO - 2016-09-15 00:05:32 --> Output Class Initialized
INFO - 2016-09-15 00:05:32 --> Security Class Initialized
DEBUG - 2016-09-15 00:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 00:05:32 --> Input Class Initialized
INFO - 2016-09-15 00:05:32 --> Language Class Initialized
INFO - 2016-09-15 00:05:32 --> Language Class Initialized
INFO - 2016-09-15 00:05:32 --> Config Class Initialized
INFO - 2016-09-15 00:05:32 --> Loader Class Initialized
INFO - 2016-09-15 00:05:32 --> Helper loaded: url_helper
INFO - 2016-09-15 00:05:32 --> Database Driver Class Initialized
INFO - 2016-09-15 00:05:32 --> Controller Class Initialized
DEBUG - 2016-09-15 00:05:32 --> Index MX_Controller Initialized
INFO - 2016-09-15 00:05:32 --> Model Class Initialized
INFO - 2016-09-15 00:05:32 --> Model Class Initialized
DEBUG - 2016-09-15 00:05:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 00:05:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 00:05:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 00:05:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tutup_angsuran.php
DEBUG - 2016-09-15 00:05:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 00:05:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 00:05:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 00:05:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 00:05:33 --> Final output sent to browser
DEBUG - 2016-09-15 00:05:33 --> Total execution time: 0.6665
INFO - 2016-09-15 00:12:52 --> Config Class Initialized
INFO - 2016-09-15 00:12:52 --> Hooks Class Initialized
DEBUG - 2016-09-15 00:12:52 --> UTF-8 Support Enabled
INFO - 2016-09-15 00:12:52 --> Utf8 Class Initialized
INFO - 2016-09-15 00:12:52 --> URI Class Initialized
INFO - 2016-09-15 00:12:52 --> Router Class Initialized
INFO - 2016-09-15 00:12:52 --> Output Class Initialized
INFO - 2016-09-15 00:12:52 --> Security Class Initialized
DEBUG - 2016-09-15 00:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 00:12:52 --> Input Class Initialized
INFO - 2016-09-15 00:12:52 --> Language Class Initialized
INFO - 2016-09-15 00:12:52 --> Language Class Initialized
INFO - 2016-09-15 00:12:52 --> Config Class Initialized
INFO - 2016-09-15 00:12:52 --> Loader Class Initialized
INFO - 2016-09-15 00:12:52 --> Helper loaded: url_helper
INFO - 2016-09-15 00:12:52 --> Database Driver Class Initialized
INFO - 2016-09-15 00:12:52 --> Controller Class Initialized
DEBUG - 2016-09-15 00:12:52 --> Index MX_Controller Initialized
INFO - 2016-09-15 00:12:52 --> Model Class Initialized
INFO - 2016-09-15 00:12:52 --> Model Class Initialized
INFO - 2016-09-15 00:12:52 --> Database Driver Class Initialized
INFO - 2016-09-15 00:12:52 --> Final output sent to browser
DEBUG - 2016-09-15 00:12:52 --> Total execution time: 0.4349
INFO - 2016-09-15 00:13:21 --> Config Class Initialized
INFO - 2016-09-15 00:13:21 --> Hooks Class Initialized
DEBUG - 2016-09-15 00:13:21 --> UTF-8 Support Enabled
INFO - 2016-09-15 00:13:21 --> Utf8 Class Initialized
INFO - 2016-09-15 00:13:21 --> URI Class Initialized
INFO - 2016-09-15 00:13:21 --> Router Class Initialized
INFO - 2016-09-15 00:13:21 --> Output Class Initialized
INFO - 2016-09-15 00:13:21 --> Security Class Initialized
DEBUG - 2016-09-15 00:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 00:13:21 --> Input Class Initialized
INFO - 2016-09-15 00:13:21 --> Language Class Initialized
INFO - 2016-09-15 00:13:21 --> Language Class Initialized
INFO - 2016-09-15 00:13:21 --> Config Class Initialized
INFO - 2016-09-15 00:13:21 --> Loader Class Initialized
INFO - 2016-09-15 00:13:21 --> Helper loaded: url_helper
INFO - 2016-09-15 00:13:21 --> Database Driver Class Initialized
INFO - 2016-09-15 00:13:21 --> Controller Class Initialized
DEBUG - 2016-09-15 00:13:21 --> Index MX_Controller Initialized
INFO - 2016-09-15 00:13:21 --> Model Class Initialized
INFO - 2016-09-15 00:13:21 --> Model Class Initialized
DEBUG - 2016-09-15 00:13:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 00:13:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 00:13:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 00:13:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_bayar_angsuran.php
DEBUG - 2016-09-15 00:13:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 00:13:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 00:13:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 00:13:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 00:13:21 --> Final output sent to browser
DEBUG - 2016-09-15 00:13:21 --> Total execution time: 0.5144
INFO - 2016-09-15 00:13:25 --> Config Class Initialized
INFO - 2016-09-15 00:13:25 --> Hooks Class Initialized
DEBUG - 2016-09-15 00:13:25 --> UTF-8 Support Enabled
INFO - 2016-09-15 00:13:25 --> Utf8 Class Initialized
INFO - 2016-09-15 00:13:25 --> URI Class Initialized
INFO - 2016-09-15 00:13:25 --> Router Class Initialized
INFO - 2016-09-15 00:13:25 --> Output Class Initialized
INFO - 2016-09-15 00:13:25 --> Security Class Initialized
DEBUG - 2016-09-15 00:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 00:13:25 --> Input Class Initialized
INFO - 2016-09-15 00:13:25 --> Language Class Initialized
INFO - 2016-09-15 00:13:25 --> Language Class Initialized
INFO - 2016-09-15 00:13:26 --> Config Class Initialized
INFO - 2016-09-15 00:13:26 --> Loader Class Initialized
INFO - 2016-09-15 00:13:26 --> Helper loaded: url_helper
INFO - 2016-09-15 00:13:26 --> Database Driver Class Initialized
INFO - 2016-09-15 00:13:26 --> Controller Class Initialized
DEBUG - 2016-09-15 00:13:26 --> Index MX_Controller Initialized
INFO - 2016-09-15 00:13:26 --> Model Class Initialized
INFO - 2016-09-15 00:13:26 --> Model Class Initialized
INFO - 2016-09-15 00:13:26 --> Database Driver Class Initialized
INFO - 2016-09-15 00:13:26 --> Final output sent to browser
DEBUG - 2016-09-15 00:13:26 --> Total execution time: 0.3953
INFO - 2016-09-15 00:14:42 --> Config Class Initialized
INFO - 2016-09-15 00:14:42 --> Hooks Class Initialized
DEBUG - 2016-09-15 00:14:42 --> UTF-8 Support Enabled
INFO - 2016-09-15 00:14:42 --> Utf8 Class Initialized
INFO - 2016-09-15 00:14:42 --> URI Class Initialized
INFO - 2016-09-15 00:14:42 --> Router Class Initialized
INFO - 2016-09-15 00:14:42 --> Output Class Initialized
INFO - 2016-09-15 00:14:42 --> Security Class Initialized
DEBUG - 2016-09-15 00:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 00:14:42 --> Input Class Initialized
INFO - 2016-09-15 00:14:42 --> Language Class Initialized
INFO - 2016-09-15 00:14:42 --> Language Class Initialized
INFO - 2016-09-15 00:14:42 --> Config Class Initialized
INFO - 2016-09-15 00:14:42 --> Loader Class Initialized
INFO - 2016-09-15 00:14:42 --> Helper loaded: url_helper
INFO - 2016-09-15 00:14:42 --> Database Driver Class Initialized
INFO - 2016-09-15 00:14:42 --> Controller Class Initialized
DEBUG - 2016-09-15 00:14:42 --> Index MX_Controller Initialized
INFO - 2016-09-15 00:14:42 --> Model Class Initialized
INFO - 2016-09-15 00:14:42 --> Model Class Initialized
INFO - 2016-09-15 00:14:42 --> Database Driver Class Initialized
INFO - 2016-09-15 00:14:42 --> Final output sent to browser
DEBUG - 2016-09-15 00:14:42 --> Total execution time: 0.5694
INFO - 2016-09-15 00:14:47 --> Config Class Initialized
INFO - 2016-09-15 00:14:47 --> Hooks Class Initialized
DEBUG - 2016-09-15 00:14:47 --> UTF-8 Support Enabled
INFO - 2016-09-15 00:14:47 --> Utf8 Class Initialized
INFO - 2016-09-15 00:14:47 --> URI Class Initialized
INFO - 2016-09-15 00:14:47 --> Router Class Initialized
INFO - 2016-09-15 00:14:47 --> Output Class Initialized
INFO - 2016-09-15 00:14:47 --> Security Class Initialized
DEBUG - 2016-09-15 00:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 00:14:47 --> Input Class Initialized
INFO - 2016-09-15 00:14:47 --> Language Class Initialized
INFO - 2016-09-15 00:14:47 --> Language Class Initialized
INFO - 2016-09-15 00:14:47 --> Config Class Initialized
INFO - 2016-09-15 00:14:47 --> Loader Class Initialized
INFO - 2016-09-15 00:14:47 --> Helper loaded: url_helper
INFO - 2016-09-15 00:14:47 --> Database Driver Class Initialized
INFO - 2016-09-15 00:14:47 --> Controller Class Initialized
DEBUG - 2016-09-15 00:14:47 --> Index MX_Controller Initialized
INFO - 2016-09-15 00:14:47 --> Model Class Initialized
INFO - 2016-09-15 00:14:47 --> Model Class Initialized
DEBUG - 2016-09-15 00:14:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 00:14:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 00:14:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 00:14:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tutup_angsuran.php
DEBUG - 2016-09-15 00:14:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 00:14:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 00:14:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 00:14:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 00:14:48 --> Final output sent to browser
DEBUG - 2016-09-15 00:14:48 --> Total execution time: 0.5311
INFO - 2016-09-15 00:14:51 --> Config Class Initialized
INFO - 2016-09-15 00:14:51 --> Hooks Class Initialized
DEBUG - 2016-09-15 00:14:51 --> UTF-8 Support Enabled
INFO - 2016-09-15 00:14:51 --> Utf8 Class Initialized
INFO - 2016-09-15 00:14:51 --> URI Class Initialized
INFO - 2016-09-15 00:14:51 --> Router Class Initialized
INFO - 2016-09-15 00:14:51 --> Output Class Initialized
INFO - 2016-09-15 00:14:51 --> Security Class Initialized
DEBUG - 2016-09-15 00:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 00:14:51 --> Input Class Initialized
INFO - 2016-09-15 00:14:51 --> Language Class Initialized
INFO - 2016-09-15 00:14:51 --> Language Class Initialized
INFO - 2016-09-15 00:14:51 --> Config Class Initialized
INFO - 2016-09-15 00:14:51 --> Loader Class Initialized
INFO - 2016-09-15 00:14:51 --> Helper loaded: url_helper
INFO - 2016-09-15 00:14:51 --> Database Driver Class Initialized
INFO - 2016-09-15 00:14:51 --> Controller Class Initialized
DEBUG - 2016-09-15 00:14:52 --> Index MX_Controller Initialized
INFO - 2016-09-15 00:14:52 --> Model Class Initialized
INFO - 2016-09-15 00:14:52 --> Model Class Initialized
INFO - 2016-09-15 00:14:52 --> Database Driver Class Initialized
INFO - 2016-09-15 00:14:52 --> Final output sent to browser
DEBUG - 2016-09-15 00:14:52 --> Total execution time: 0.4260
INFO - 2016-09-15 00:15:01 --> Config Class Initialized
INFO - 2016-09-15 00:15:01 --> Hooks Class Initialized
DEBUG - 2016-09-15 00:15:01 --> UTF-8 Support Enabled
INFO - 2016-09-15 00:15:01 --> Utf8 Class Initialized
INFO - 2016-09-15 00:15:01 --> URI Class Initialized
INFO - 2016-09-15 00:15:01 --> Router Class Initialized
INFO - 2016-09-15 00:15:01 --> Output Class Initialized
INFO - 2016-09-15 00:15:01 --> Security Class Initialized
DEBUG - 2016-09-15 00:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 00:15:01 --> Input Class Initialized
INFO - 2016-09-15 00:15:01 --> Language Class Initialized
INFO - 2016-09-15 00:15:01 --> Language Class Initialized
INFO - 2016-09-15 00:15:01 --> Config Class Initialized
INFO - 2016-09-15 00:15:01 --> Loader Class Initialized
INFO - 2016-09-15 00:15:01 --> Helper loaded: url_helper
INFO - 2016-09-15 00:15:01 --> Database Driver Class Initialized
INFO - 2016-09-15 00:15:01 --> Controller Class Initialized
DEBUG - 2016-09-15 00:15:01 --> Index MX_Controller Initialized
INFO - 2016-09-15 00:15:01 --> Model Class Initialized
INFO - 2016-09-15 00:15:01 --> Model Class Initialized
INFO - 2016-09-15 00:15:01 --> Database Driver Class Initialized
INFO - 2016-09-15 00:15:01 --> Database Driver Class Initialized
INFO - 2016-09-15 00:15:02 --> Database Driver Class Initialized
INFO - 2016-09-15 00:15:02 --> Database Driver Class Initialized
INFO - 2016-09-15 00:15:02 --> Database Driver Class Initialized
INFO - 2016-09-15 00:15:02 --> Database Driver Class Initialized
INFO - 2016-09-15 00:15:02 --> Database Driver Class Initialized
INFO - 2016-09-15 00:15:02 --> Database Driver Class Initialized
INFO - 2016-09-15 00:15:02 --> Database Driver Class Initialized
INFO - 2016-09-15 00:15:02 --> Database Driver Class Initialized
INFO - 2016-09-15 00:15:03 --> Database Driver Class Initialized
INFO - 2016-09-15 00:15:03 --> Database Driver Class Initialized
INFO - 2016-09-15 00:15:03 --> Final output sent to browser
DEBUG - 2016-09-15 00:15:03 --> Total execution time: 1.8091
INFO - 2016-09-15 00:37:43 --> Config Class Initialized
INFO - 2016-09-15 00:37:43 --> Hooks Class Initialized
DEBUG - 2016-09-15 00:37:43 --> UTF-8 Support Enabled
INFO - 2016-09-15 00:37:43 --> Utf8 Class Initialized
INFO - 2016-09-15 00:37:43 --> URI Class Initialized
INFO - 2016-09-15 00:37:43 --> Router Class Initialized
INFO - 2016-09-15 00:37:43 --> Output Class Initialized
INFO - 2016-09-15 00:37:43 --> Security Class Initialized
DEBUG - 2016-09-15 00:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 00:37:43 --> Input Class Initialized
INFO - 2016-09-15 00:37:43 --> Language Class Initialized
INFO - 2016-09-15 00:37:43 --> Language Class Initialized
INFO - 2016-09-15 00:37:43 --> Config Class Initialized
INFO - 2016-09-15 00:37:43 --> Loader Class Initialized
INFO - 2016-09-15 00:37:43 --> Helper loaded: url_helper
INFO - 2016-09-15 00:37:43 --> Database Driver Class Initialized
INFO - 2016-09-15 00:37:43 --> Controller Class Initialized
DEBUG - 2016-09-15 00:37:43 --> Index MX_Controller Initialized
INFO - 2016-09-15 00:37:43 --> Model Class Initialized
INFO - 2016-09-15 00:37:43 --> Model Class Initialized
INFO - 2016-09-15 00:37:43 --> Final output sent to browser
DEBUG - 2016-09-15 00:37:43 --> Total execution time: 0.3739
INFO - 2016-09-15 00:37:45 --> Config Class Initialized
INFO - 2016-09-15 00:37:45 --> Hooks Class Initialized
DEBUG - 2016-09-15 00:37:45 --> UTF-8 Support Enabled
INFO - 2016-09-15 00:37:45 --> Utf8 Class Initialized
INFO - 2016-09-15 00:37:45 --> URI Class Initialized
INFO - 2016-09-15 00:37:45 --> Router Class Initialized
INFO - 2016-09-15 00:37:45 --> Output Class Initialized
INFO - 2016-09-15 00:37:45 --> Security Class Initialized
DEBUG - 2016-09-15 00:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 00:37:45 --> Input Class Initialized
INFO - 2016-09-15 00:37:45 --> Language Class Initialized
INFO - 2016-09-15 00:37:45 --> Language Class Initialized
INFO - 2016-09-15 00:37:45 --> Config Class Initialized
INFO - 2016-09-15 00:37:45 --> Loader Class Initialized
INFO - 2016-09-15 00:37:45 --> Helper loaded: url_helper
INFO - 2016-09-15 00:37:45 --> Database Driver Class Initialized
INFO - 2016-09-15 00:37:45 --> Controller Class Initialized
ERROR - 2016-09-15 00:37:45 --> 404 Page Not Found: ../modules/admin/controllers/Index/form.html
INFO - 2016-09-15 00:37:48 --> Config Class Initialized
INFO - 2016-09-15 00:37:48 --> Hooks Class Initialized
DEBUG - 2016-09-15 00:37:48 --> UTF-8 Support Enabled
INFO - 2016-09-15 00:37:48 --> Utf8 Class Initialized
INFO - 2016-09-15 00:37:48 --> URI Class Initialized
INFO - 2016-09-15 00:37:49 --> Router Class Initialized
INFO - 2016-09-15 00:37:49 --> Output Class Initialized
INFO - 2016-09-15 00:37:49 --> Security Class Initialized
DEBUG - 2016-09-15 00:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 00:37:49 --> Input Class Initialized
INFO - 2016-09-15 00:37:49 --> Language Class Initialized
INFO - 2016-09-15 00:37:49 --> Language Class Initialized
INFO - 2016-09-15 00:37:49 --> Config Class Initialized
INFO - 2016-09-15 00:37:49 --> Loader Class Initialized
INFO - 2016-09-15 00:37:49 --> Helper loaded: url_helper
INFO - 2016-09-15 00:37:49 --> Database Driver Class Initialized
INFO - 2016-09-15 00:37:49 --> Controller Class Initialized
DEBUG - 2016-09-15 00:37:49 --> Index MX_Controller Initialized
INFO - 2016-09-15 00:37:49 --> Model Class Initialized
INFO - 2016-09-15 00:37:49 --> Model Class Initialized
DEBUG - 2016-09-15 00:37:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 00:37:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 00:37:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 00:37:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-15 00:37:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 00:37:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 00:37:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 00:37:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 00:37:49 --> Final output sent to browser
DEBUG - 2016-09-15 00:37:49 --> Total execution time: 0.5426
INFO - 2016-09-15 00:37:56 --> Config Class Initialized
INFO - 2016-09-15 00:37:56 --> Hooks Class Initialized
DEBUG - 2016-09-15 00:37:56 --> UTF-8 Support Enabled
INFO - 2016-09-15 00:37:56 --> Utf8 Class Initialized
INFO - 2016-09-15 00:37:56 --> URI Class Initialized
INFO - 2016-09-15 00:37:57 --> Router Class Initialized
INFO - 2016-09-15 00:37:57 --> Output Class Initialized
INFO - 2016-09-15 00:37:57 --> Security Class Initialized
DEBUG - 2016-09-15 00:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 00:37:57 --> Input Class Initialized
INFO - 2016-09-15 00:37:57 --> Language Class Initialized
INFO - 2016-09-15 00:37:57 --> Language Class Initialized
INFO - 2016-09-15 00:37:57 --> Config Class Initialized
INFO - 2016-09-15 00:37:57 --> Loader Class Initialized
INFO - 2016-09-15 00:37:57 --> Helper loaded: url_helper
INFO - 2016-09-15 00:37:57 --> Database Driver Class Initialized
INFO - 2016-09-15 00:37:57 --> Controller Class Initialized
DEBUG - 2016-09-15 00:37:57 --> Index MX_Controller Initialized
INFO - 2016-09-15 00:37:57 --> Model Class Initialized
INFO - 2016-09-15 00:37:57 --> Model Class Initialized
DEBUG - 2016-09-15 00:37:57 --> Anggota MX_Controller Initialized
INFO - 2016-09-15 00:37:57 --> Database Driver Class Initialized
INFO - 2016-09-15 00:37:57 --> Final output sent to browser
DEBUG - 2016-09-15 00:37:57 --> Total execution time: 0.4610
INFO - 2016-09-15 00:37:59 --> Config Class Initialized
INFO - 2016-09-15 00:37:59 --> Hooks Class Initialized
DEBUG - 2016-09-15 00:37:59 --> UTF-8 Support Enabled
INFO - 2016-09-15 00:37:59 --> Utf8 Class Initialized
INFO - 2016-09-15 00:37:59 --> URI Class Initialized
INFO - 2016-09-15 00:37:59 --> Router Class Initialized
INFO - 2016-09-15 00:37:59 --> Output Class Initialized
INFO - 2016-09-15 00:37:59 --> Security Class Initialized
DEBUG - 2016-09-15 00:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 00:37:59 --> Input Class Initialized
INFO - 2016-09-15 00:38:00 --> Language Class Initialized
INFO - 2016-09-15 00:38:00 --> Language Class Initialized
INFO - 2016-09-15 00:38:00 --> Config Class Initialized
INFO - 2016-09-15 00:38:00 --> Loader Class Initialized
INFO - 2016-09-15 00:38:00 --> Helper loaded: url_helper
INFO - 2016-09-15 00:38:00 --> Database Driver Class Initialized
INFO - 2016-09-15 00:38:00 --> Controller Class Initialized
DEBUG - 2016-09-15 00:38:00 --> Index MX_Controller Initialized
INFO - 2016-09-15 00:38:00 --> Model Class Initialized
INFO - 2016-09-15 00:38:00 --> Model Class Initialized
DEBUG - 2016-09-15 00:38:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 00:38:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 00:38:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 00:38:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_umum.php
DEBUG - 2016-09-15 00:38:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 00:38:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 00:38:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 00:38:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 00:38:00 --> Final output sent to browser
DEBUG - 2016-09-15 00:38:00 --> Total execution time: 0.5195
INFO - 2016-09-15 00:38:09 --> Config Class Initialized
INFO - 2016-09-15 00:38:09 --> Hooks Class Initialized
DEBUG - 2016-09-15 00:38:09 --> UTF-8 Support Enabled
INFO - 2016-09-15 00:38:09 --> Utf8 Class Initialized
INFO - 2016-09-15 00:38:09 --> URI Class Initialized
INFO - 2016-09-15 00:38:09 --> Router Class Initialized
INFO - 2016-09-15 00:38:09 --> Output Class Initialized
INFO - 2016-09-15 00:38:09 --> Security Class Initialized
DEBUG - 2016-09-15 00:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 00:38:09 --> Input Class Initialized
INFO - 2016-09-15 00:38:09 --> Language Class Initialized
INFO - 2016-09-15 00:38:09 --> Language Class Initialized
INFO - 2016-09-15 00:38:09 --> Config Class Initialized
INFO - 2016-09-15 00:38:09 --> Loader Class Initialized
INFO - 2016-09-15 00:38:09 --> Helper loaded: url_helper
INFO - 2016-09-15 00:38:09 --> Database Driver Class Initialized
INFO - 2016-09-15 00:38:09 --> Controller Class Initialized
DEBUG - 2016-09-15 00:38:09 --> Index MX_Controller Initialized
INFO - 2016-09-15 00:38:10 --> Model Class Initialized
INFO - 2016-09-15 00:38:10 --> Model Class Initialized
INFO - 2016-09-15 00:38:10 --> Database Driver Class Initialized
ERROR - 2016-09-15 00:38:10 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 174
INFO - 2016-09-15 00:38:10 --> Final output sent to browser
DEBUG - 2016-09-15 00:38:10 --> Total execution time: 0.6008
INFO - 2016-09-15 00:38:39 --> Config Class Initialized
INFO - 2016-09-15 00:38:39 --> Hooks Class Initialized
DEBUG - 2016-09-15 00:38:39 --> UTF-8 Support Enabled
INFO - 2016-09-15 00:38:39 --> Utf8 Class Initialized
INFO - 2016-09-15 00:38:39 --> URI Class Initialized
INFO - 2016-09-15 00:38:39 --> Router Class Initialized
INFO - 2016-09-15 00:38:40 --> Output Class Initialized
INFO - 2016-09-15 00:38:40 --> Security Class Initialized
DEBUG - 2016-09-15 00:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 00:38:40 --> Input Class Initialized
INFO - 2016-09-15 00:38:40 --> Language Class Initialized
INFO - 2016-09-15 00:38:40 --> Language Class Initialized
INFO - 2016-09-15 00:38:40 --> Config Class Initialized
INFO - 2016-09-15 00:38:40 --> Loader Class Initialized
INFO - 2016-09-15 00:38:40 --> Helper loaded: url_helper
INFO - 2016-09-15 00:38:40 --> Database Driver Class Initialized
INFO - 2016-09-15 00:38:40 --> Controller Class Initialized
DEBUG - 2016-09-15 00:38:40 --> Index MX_Controller Initialized
INFO - 2016-09-15 00:38:40 --> Model Class Initialized
INFO - 2016-09-15 00:38:40 --> Model Class Initialized
INFO - 2016-09-15 00:38:40 --> Final output sent to browser
DEBUG - 2016-09-15 00:38:40 --> Total execution time: 0.4474
INFO - 2016-09-15 00:39:05 --> Config Class Initialized
INFO - 2016-09-15 00:39:05 --> Hooks Class Initialized
DEBUG - 2016-09-15 00:39:05 --> UTF-8 Support Enabled
INFO - 2016-09-15 00:39:05 --> Utf8 Class Initialized
INFO - 2016-09-15 00:39:05 --> URI Class Initialized
INFO - 2016-09-15 00:39:05 --> Router Class Initialized
INFO - 2016-09-15 00:39:05 --> Output Class Initialized
INFO - 2016-09-15 00:39:05 --> Security Class Initialized
DEBUG - 2016-09-15 00:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 00:39:05 --> Input Class Initialized
INFO - 2016-09-15 00:39:05 --> Language Class Initialized
INFO - 2016-09-15 00:39:05 --> Language Class Initialized
INFO - 2016-09-15 00:39:05 --> Config Class Initialized
INFO - 2016-09-15 00:39:05 --> Loader Class Initialized
INFO - 2016-09-15 00:39:05 --> Helper loaded: url_helper
INFO - 2016-09-15 00:39:05 --> Database Driver Class Initialized
INFO - 2016-09-15 00:39:05 --> Controller Class Initialized
DEBUG - 2016-09-15 00:39:05 --> Index MX_Controller Initialized
INFO - 2016-09-15 00:39:05 --> Model Class Initialized
INFO - 2016-09-15 00:39:05 --> Model Class Initialized
INFO - 2016-09-15 00:39:06 --> Database Driver Class Initialized
ERROR - 2016-09-15 00:39:06 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 174
INFO - 2016-09-15 00:39:06 --> Final output sent to browser
DEBUG - 2016-09-15 00:39:06 --> Total execution time: 0.5403
INFO - 2016-09-15 00:41:29 --> Config Class Initialized
INFO - 2016-09-15 00:41:29 --> Hooks Class Initialized
DEBUG - 2016-09-15 00:41:29 --> UTF-8 Support Enabled
INFO - 2016-09-15 00:41:29 --> Utf8 Class Initialized
INFO - 2016-09-15 00:41:29 --> URI Class Initialized
INFO - 2016-09-15 00:41:29 --> Router Class Initialized
INFO - 2016-09-15 00:41:29 --> Output Class Initialized
INFO - 2016-09-15 00:41:29 --> Security Class Initialized
DEBUG - 2016-09-15 00:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 00:41:29 --> Input Class Initialized
INFO - 2016-09-15 00:41:29 --> Language Class Initialized
INFO - 2016-09-15 00:41:29 --> Language Class Initialized
INFO - 2016-09-15 00:41:29 --> Config Class Initialized
INFO - 2016-09-15 00:41:29 --> Loader Class Initialized
INFO - 2016-09-15 00:41:29 --> Helper loaded: url_helper
INFO - 2016-09-15 00:41:29 --> Database Driver Class Initialized
INFO - 2016-09-15 00:41:29 --> Controller Class Initialized
DEBUG - 2016-09-15 00:41:29 --> Index MX_Controller Initialized
INFO - 2016-09-15 00:41:29 --> Model Class Initialized
INFO - 2016-09-15 00:41:29 --> Model Class Initialized
INFO - 2016-09-15 00:41:30 --> Database Driver Class Initialized
ERROR - 2016-09-15 00:41:30 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 174
INFO - 2016-09-15 00:41:30 --> Final output sent to browser
DEBUG - 2016-09-15 00:41:30 --> Total execution time: 0.7047
INFO - 2016-09-15 00:41:45 --> Config Class Initialized
INFO - 2016-09-15 00:41:45 --> Hooks Class Initialized
DEBUG - 2016-09-15 00:41:45 --> UTF-8 Support Enabled
INFO - 2016-09-15 00:41:45 --> Utf8 Class Initialized
INFO - 2016-09-15 00:41:45 --> URI Class Initialized
INFO - 2016-09-15 00:41:45 --> Router Class Initialized
INFO - 2016-09-15 00:41:45 --> Output Class Initialized
INFO - 2016-09-15 00:41:45 --> Security Class Initialized
DEBUG - 2016-09-15 00:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 00:41:45 --> Input Class Initialized
INFO - 2016-09-15 00:41:45 --> Language Class Initialized
INFO - 2016-09-15 00:41:45 --> Language Class Initialized
INFO - 2016-09-15 00:41:45 --> Config Class Initialized
INFO - 2016-09-15 00:41:45 --> Loader Class Initialized
INFO - 2016-09-15 00:41:45 --> Helper loaded: url_helper
INFO - 2016-09-15 00:41:45 --> Database Driver Class Initialized
INFO - 2016-09-15 00:41:45 --> Controller Class Initialized
DEBUG - 2016-09-15 00:41:45 --> Index MX_Controller Initialized
INFO - 2016-09-15 00:41:45 --> Model Class Initialized
INFO - 2016-09-15 00:41:45 --> Model Class Initialized
INFO - 2016-09-15 00:41:45 --> Database Driver Class Initialized
ERROR - 2016-09-15 00:41:45 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 174
INFO - 2016-09-15 00:41:45 --> Final output sent to browser
DEBUG - 2016-09-15 00:41:45 --> Total execution time: 0.5610
INFO - 2016-09-15 00:43:16 --> Config Class Initialized
INFO - 2016-09-15 00:43:16 --> Hooks Class Initialized
DEBUG - 2016-09-15 00:43:16 --> UTF-8 Support Enabled
INFO - 2016-09-15 00:43:16 --> Utf8 Class Initialized
INFO - 2016-09-15 00:43:16 --> URI Class Initialized
INFO - 2016-09-15 00:43:16 --> Router Class Initialized
INFO - 2016-09-15 00:43:16 --> Output Class Initialized
INFO - 2016-09-15 00:43:16 --> Security Class Initialized
DEBUG - 2016-09-15 00:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 00:43:16 --> Input Class Initialized
INFO - 2016-09-15 00:43:16 --> Language Class Initialized
INFO - 2016-09-15 00:43:16 --> Language Class Initialized
INFO - 2016-09-15 00:43:16 --> Config Class Initialized
INFO - 2016-09-15 00:43:16 --> Loader Class Initialized
INFO - 2016-09-15 00:43:16 --> Helper loaded: url_helper
INFO - 2016-09-15 00:43:16 --> Database Driver Class Initialized
INFO - 2016-09-15 00:43:16 --> Controller Class Initialized
DEBUG - 2016-09-15 00:43:16 --> Index MX_Controller Initialized
INFO - 2016-09-15 00:43:16 --> Model Class Initialized
INFO - 2016-09-15 00:43:16 --> Model Class Initialized
INFO - 2016-09-15 00:43:16 --> Database Driver Class Initialized
ERROR - 2016-09-15 00:43:16 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 174
INFO - 2016-09-15 00:43:16 --> Final output sent to browser
DEBUG - 2016-09-15 00:43:16 --> Total execution time: 0.5713
INFO - 2016-09-15 00:45:40 --> Config Class Initialized
INFO - 2016-09-15 00:45:40 --> Hooks Class Initialized
DEBUG - 2016-09-15 00:45:40 --> UTF-8 Support Enabled
INFO - 2016-09-15 00:45:40 --> Utf8 Class Initialized
INFO - 2016-09-15 00:45:40 --> URI Class Initialized
INFO - 2016-09-15 00:45:40 --> Router Class Initialized
INFO - 2016-09-15 00:45:40 --> Output Class Initialized
INFO - 2016-09-15 00:45:40 --> Security Class Initialized
DEBUG - 2016-09-15 00:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 00:45:40 --> Input Class Initialized
INFO - 2016-09-15 00:45:40 --> Language Class Initialized
INFO - 2016-09-15 00:45:40 --> Language Class Initialized
INFO - 2016-09-15 00:45:40 --> Config Class Initialized
INFO - 2016-09-15 00:45:40 --> Loader Class Initialized
INFO - 2016-09-15 00:45:40 --> Helper loaded: url_helper
INFO - 2016-09-15 00:45:40 --> Database Driver Class Initialized
INFO - 2016-09-15 00:45:40 --> Controller Class Initialized
DEBUG - 2016-09-15 00:45:40 --> Index MX_Controller Initialized
INFO - 2016-09-15 00:45:40 --> Model Class Initialized
INFO - 2016-09-15 00:45:40 --> Model Class Initialized
INFO - 2016-09-15 00:45:40 --> Database Driver Class Initialized
ERROR - 2016-09-15 00:45:40 --> Query error: Table 'koperasi.tm_pinjama' doesn't exist - Invalid query: SELECT *
FROM `tm_pinjama`
WHERE `kd_anggota` = '22'
AND `jumlah_pinjaman` = '10000000'
AND `bunga` = '3'
AND `jenis_pinjaman` = 1
AND `jangka_waktu` = '12'
AND `jaminan` =0
AND `pokok_angsuran` = 833333.33333333
AND `bunga_angsuran` = 300000
AND `tanggal_pinjam` = '2016-09-15'
AND `provision` = 100000
AND `administrasi` = 200000
AND `status` =0
AND `kd_user` = 1
INFO - 2016-09-15 00:45:40 --> Language file loaded: language/english/db_lang.php
INFO - 2016-09-15 00:50:58 --> Config Class Initialized
INFO - 2016-09-15 00:50:58 --> Hooks Class Initialized
DEBUG - 2016-09-15 00:50:58 --> UTF-8 Support Enabled
INFO - 2016-09-15 00:50:58 --> Utf8 Class Initialized
INFO - 2016-09-15 00:50:58 --> URI Class Initialized
INFO - 2016-09-15 00:50:59 --> Router Class Initialized
INFO - 2016-09-15 00:50:59 --> Output Class Initialized
INFO - 2016-09-15 00:50:59 --> Security Class Initialized
DEBUG - 2016-09-15 00:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 00:50:59 --> Input Class Initialized
INFO - 2016-09-15 00:50:59 --> Language Class Initialized
INFO - 2016-09-15 00:50:59 --> Language Class Initialized
INFO - 2016-09-15 00:50:59 --> Config Class Initialized
INFO - 2016-09-15 00:50:59 --> Loader Class Initialized
INFO - 2016-09-15 00:50:59 --> Helper loaded: url_helper
INFO - 2016-09-15 00:50:59 --> Database Driver Class Initialized
INFO - 2016-09-15 00:50:59 --> Controller Class Initialized
DEBUG - 2016-09-15 00:50:59 --> Index MX_Controller Initialized
INFO - 2016-09-15 00:50:59 --> Model Class Initialized
INFO - 2016-09-15 00:50:59 --> Model Class Initialized
INFO - 2016-09-15 00:50:59 --> Database Driver Class Initialized
INFO - 2016-09-15 00:50:59 --> Final output sent to browser
DEBUG - 2016-09-15 00:50:59 --> Total execution time: 0.6652
INFO - 2016-09-15 00:51:17 --> Config Class Initialized
INFO - 2016-09-15 00:51:17 --> Hooks Class Initialized
DEBUG - 2016-09-15 00:51:17 --> UTF-8 Support Enabled
INFO - 2016-09-15 00:51:17 --> Utf8 Class Initialized
INFO - 2016-09-15 00:51:17 --> URI Class Initialized
INFO - 2016-09-15 00:51:17 --> Router Class Initialized
INFO - 2016-09-15 00:51:17 --> Output Class Initialized
INFO - 2016-09-15 00:51:17 --> Security Class Initialized
DEBUG - 2016-09-15 00:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 00:51:17 --> Input Class Initialized
INFO - 2016-09-15 00:51:17 --> Language Class Initialized
INFO - 2016-09-15 00:51:17 --> Language Class Initialized
INFO - 2016-09-15 00:51:17 --> Config Class Initialized
INFO - 2016-09-15 00:51:17 --> Loader Class Initialized
INFO - 2016-09-15 00:51:17 --> Helper loaded: url_helper
INFO - 2016-09-15 00:51:17 --> Database Driver Class Initialized
INFO - 2016-09-15 00:51:18 --> Controller Class Initialized
DEBUG - 2016-09-15 00:51:18 --> Index MX_Controller Initialized
INFO - 2016-09-15 00:51:18 --> Model Class Initialized
INFO - 2016-09-15 00:51:18 --> Model Class Initialized
INFO - 2016-09-15 00:51:18 --> Database Driver Class Initialized
INFO - 2016-09-15 00:51:18 --> Final output sent to browser
DEBUG - 2016-09-15 00:51:18 --> Total execution time: 0.5043
INFO - 2016-09-15 10:55:19 --> Config Class Initialized
INFO - 2016-09-15 10:55:19 --> Hooks Class Initialized
DEBUG - 2016-09-15 10:55:19 --> UTF-8 Support Enabled
INFO - 2016-09-15 10:55:19 --> Utf8 Class Initialized
INFO - 2016-09-15 10:55:19 --> URI Class Initialized
INFO - 2016-09-15 10:55:20 --> Router Class Initialized
INFO - 2016-09-15 10:55:20 --> Output Class Initialized
INFO - 2016-09-15 10:55:20 --> Security Class Initialized
DEBUG - 2016-09-15 10:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 10:55:20 --> Input Class Initialized
INFO - 2016-09-15 10:55:20 --> Language Class Initialized
ERROR - 2016-09-15 10:55:20 --> 404 Page Not Found: /index
INFO - 2016-09-15 10:55:27 --> Config Class Initialized
INFO - 2016-09-15 10:55:27 --> Hooks Class Initialized
DEBUG - 2016-09-15 10:55:27 --> UTF-8 Support Enabled
INFO - 2016-09-15 10:55:27 --> Utf8 Class Initialized
INFO - 2016-09-15 10:55:27 --> URI Class Initialized
INFO - 2016-09-15 10:55:27 --> Router Class Initialized
INFO - 2016-09-15 10:55:27 --> Output Class Initialized
INFO - 2016-09-15 10:55:28 --> Security Class Initialized
DEBUG - 2016-09-15 10:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 10:55:28 --> Input Class Initialized
INFO - 2016-09-15 10:55:28 --> Language Class Initialized
INFO - 2016-09-15 10:55:28 --> Language Class Initialized
INFO - 2016-09-15 10:55:28 --> Config Class Initialized
INFO - 2016-09-15 10:55:28 --> Loader Class Initialized
INFO - 2016-09-15 10:55:28 --> Helper loaded: url_helper
INFO - 2016-09-15 10:55:28 --> Database Driver Class Initialized
INFO - 2016-09-15 10:55:28 --> Controller Class Initialized
DEBUG - 2016-09-15 10:55:28 --> Index MX_Controller Initialized
INFO - 2016-09-15 10:55:28 --> Model Class Initialized
INFO - 2016-09-15 10:55:28 --> Model Class Initialized
DEBUG - 2016-09-15 10:55:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 10:55:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 10:55:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 10:55:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/dashboard.php
DEBUG - 2016-09-15 10:55:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 10:55:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 10:55:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 10:55:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 10:55:29 --> Final output sent to browser
DEBUG - 2016-09-15 10:55:29 --> Total execution time: 1.6921
INFO - 2016-09-15 10:55:40 --> Config Class Initialized
INFO - 2016-09-15 10:55:41 --> Hooks Class Initialized
DEBUG - 2016-09-15 10:55:41 --> UTF-8 Support Enabled
INFO - 2016-09-15 10:55:41 --> Utf8 Class Initialized
INFO - 2016-09-15 10:55:41 --> URI Class Initialized
INFO - 2016-09-15 10:55:41 --> Router Class Initialized
INFO - 2016-09-15 10:55:41 --> Output Class Initialized
INFO - 2016-09-15 10:55:41 --> Security Class Initialized
DEBUG - 2016-09-15 10:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 10:55:41 --> Input Class Initialized
INFO - 2016-09-15 10:55:41 --> Language Class Initialized
INFO - 2016-09-15 10:55:41 --> Language Class Initialized
INFO - 2016-09-15 10:55:41 --> Config Class Initialized
INFO - 2016-09-15 10:55:41 --> Loader Class Initialized
INFO - 2016-09-15 10:55:41 --> Helper loaded: url_helper
INFO - 2016-09-15 10:55:41 --> Database Driver Class Initialized
INFO - 2016-09-15 10:55:41 --> Controller Class Initialized
DEBUG - 2016-09-15 10:55:41 --> Index MX_Controller Initialized
INFO - 2016-09-15 10:55:41 --> Model Class Initialized
INFO - 2016-09-15 10:55:41 --> Model Class Initialized
DEBUG - 2016-09-15 10:55:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 10:55:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 10:55:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 10:55:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-15 10:55:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 10:55:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 10:55:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 10:55:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 10:55:41 --> Final output sent to browser
DEBUG - 2016-09-15 10:55:41 --> Total execution time: 0.5544
INFO - 2016-09-15 10:55:45 --> Config Class Initialized
INFO - 2016-09-15 10:55:45 --> Hooks Class Initialized
DEBUG - 2016-09-15 10:55:45 --> UTF-8 Support Enabled
INFO - 2016-09-15 10:55:45 --> Utf8 Class Initialized
INFO - 2016-09-15 10:55:45 --> URI Class Initialized
INFO - 2016-09-15 10:55:45 --> Router Class Initialized
INFO - 2016-09-15 10:55:45 --> Output Class Initialized
INFO - 2016-09-15 10:55:45 --> Security Class Initialized
DEBUG - 2016-09-15 10:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 10:55:45 --> Input Class Initialized
INFO - 2016-09-15 10:55:45 --> Language Class Initialized
INFO - 2016-09-15 10:55:45 --> Language Class Initialized
INFO - 2016-09-15 10:55:45 --> Config Class Initialized
INFO - 2016-09-15 10:55:45 --> Loader Class Initialized
INFO - 2016-09-15 10:55:45 --> Helper loaded: url_helper
INFO - 2016-09-15 10:55:46 --> Database Driver Class Initialized
INFO - 2016-09-15 10:55:46 --> Controller Class Initialized
DEBUG - 2016-09-15 10:55:46 --> Index MX_Controller Initialized
INFO - 2016-09-15 10:55:46 --> Model Class Initialized
INFO - 2016-09-15 10:55:46 --> Model Class Initialized
DEBUG - 2016-09-15 10:55:46 --> Anggota MX_Controller Initialized
INFO - 2016-09-15 10:55:46 --> Database Driver Class Initialized
INFO - 2016-09-15 10:55:46 --> Final output sent to browser
DEBUG - 2016-09-15 10:55:46 --> Total execution time: 0.6950
INFO - 2016-09-15 10:55:48 --> Config Class Initialized
INFO - 2016-09-15 10:55:48 --> Hooks Class Initialized
DEBUG - 2016-09-15 10:55:48 --> UTF-8 Support Enabled
INFO - 2016-09-15 10:55:48 --> Utf8 Class Initialized
INFO - 2016-09-15 10:55:48 --> URI Class Initialized
INFO - 2016-09-15 10:55:48 --> Router Class Initialized
INFO - 2016-09-15 10:55:48 --> Output Class Initialized
INFO - 2016-09-15 10:55:48 --> Security Class Initialized
DEBUG - 2016-09-15 10:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 10:55:48 --> Input Class Initialized
INFO - 2016-09-15 10:55:48 --> Language Class Initialized
INFO - 2016-09-15 10:55:48 --> Language Class Initialized
INFO - 2016-09-15 10:55:48 --> Config Class Initialized
INFO - 2016-09-15 10:55:48 --> Loader Class Initialized
INFO - 2016-09-15 10:55:48 --> Helper loaded: url_helper
INFO - 2016-09-15 10:55:48 --> Database Driver Class Initialized
INFO - 2016-09-15 10:55:48 --> Controller Class Initialized
DEBUG - 2016-09-15 10:55:48 --> Index MX_Controller Initialized
INFO - 2016-09-15 10:55:48 --> Model Class Initialized
INFO - 2016-09-15 10:55:48 --> Model Class Initialized
DEBUG - 2016-09-15 10:55:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 10:55:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 10:55:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 10:55:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_umum.php
DEBUG - 2016-09-15 10:55:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 10:55:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 10:55:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 10:55:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 10:55:49 --> Final output sent to browser
DEBUG - 2016-09-15 10:55:49 --> Total execution time: 0.6219
INFO - 2016-09-15 10:56:15 --> Config Class Initialized
INFO - 2016-09-15 10:56:15 --> Hooks Class Initialized
DEBUG - 2016-09-15 10:56:15 --> UTF-8 Support Enabled
INFO - 2016-09-15 10:56:15 --> Utf8 Class Initialized
INFO - 2016-09-15 10:56:15 --> URI Class Initialized
INFO - 2016-09-15 10:56:15 --> Router Class Initialized
INFO - 2016-09-15 10:56:15 --> Output Class Initialized
INFO - 2016-09-15 10:56:15 --> Security Class Initialized
DEBUG - 2016-09-15 10:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 10:56:15 --> Input Class Initialized
INFO - 2016-09-15 10:56:15 --> Language Class Initialized
INFO - 2016-09-15 10:56:15 --> Language Class Initialized
INFO - 2016-09-15 10:56:15 --> Config Class Initialized
INFO - 2016-09-15 10:56:16 --> Loader Class Initialized
INFO - 2016-09-15 10:56:16 --> Helper loaded: url_helper
INFO - 2016-09-15 10:56:16 --> Database Driver Class Initialized
INFO - 2016-09-15 10:56:16 --> Controller Class Initialized
DEBUG - 2016-09-15 10:56:16 --> Index MX_Controller Initialized
INFO - 2016-09-15 10:56:16 --> Model Class Initialized
INFO - 2016-09-15 10:56:16 --> Model Class Initialized
INFO - 2016-09-15 10:56:16 --> Database Driver Class Initialized
INFO - 2016-09-15 10:56:16 --> Final output sent to browser
DEBUG - 2016-09-15 10:56:16 --> Total execution time: 0.5102
INFO - 2016-09-15 10:56:25 --> Config Class Initialized
INFO - 2016-09-15 10:56:25 --> Hooks Class Initialized
DEBUG - 2016-09-15 10:56:25 --> UTF-8 Support Enabled
INFO - 2016-09-15 10:56:25 --> Utf8 Class Initialized
INFO - 2016-09-15 10:56:25 --> URI Class Initialized
INFO - 2016-09-15 10:56:25 --> Router Class Initialized
INFO - 2016-09-15 10:56:25 --> Output Class Initialized
INFO - 2016-09-15 10:56:25 --> Security Class Initialized
DEBUG - 2016-09-15 10:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 10:56:25 --> Input Class Initialized
INFO - 2016-09-15 10:56:25 --> Language Class Initialized
INFO - 2016-09-15 10:56:25 --> Language Class Initialized
INFO - 2016-09-15 10:56:25 --> Config Class Initialized
INFO - 2016-09-15 10:56:25 --> Loader Class Initialized
INFO - 2016-09-15 10:56:25 --> Helper loaded: url_helper
INFO - 2016-09-15 10:56:25 --> Database Driver Class Initialized
INFO - 2016-09-15 10:56:25 --> Controller Class Initialized
DEBUG - 2016-09-15 10:56:25 --> Index MX_Controller Initialized
INFO - 2016-09-15 10:56:25 --> Model Class Initialized
INFO - 2016-09-15 10:56:25 --> Model Class Initialized
INFO - 2016-09-15 10:56:25 --> Database Driver Class Initialized
INFO - 2016-09-15 10:56:25 --> Final output sent to browser
DEBUG - 2016-09-15 10:56:25 --> Total execution time: 0.4946
INFO - 2016-09-15 11:30:15 --> Config Class Initialized
INFO - 2016-09-15 11:30:15 --> Hooks Class Initialized
DEBUG - 2016-09-15 11:30:15 --> UTF-8 Support Enabled
INFO - 2016-09-15 11:30:15 --> Utf8 Class Initialized
INFO - 2016-09-15 11:30:15 --> URI Class Initialized
INFO - 2016-09-15 11:30:15 --> Router Class Initialized
INFO - 2016-09-15 11:30:16 --> Output Class Initialized
INFO - 2016-09-15 11:30:16 --> Security Class Initialized
DEBUG - 2016-09-15 11:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 11:30:16 --> Input Class Initialized
INFO - 2016-09-15 11:30:16 --> Language Class Initialized
INFO - 2016-09-15 11:30:16 --> Language Class Initialized
INFO - 2016-09-15 11:30:16 --> Config Class Initialized
INFO - 2016-09-15 11:30:16 --> Loader Class Initialized
INFO - 2016-09-15 11:30:16 --> Helper loaded: url_helper
INFO - 2016-09-15 11:30:17 --> Database Driver Class Initialized
INFO - 2016-09-15 11:30:17 --> Controller Class Initialized
DEBUG - 2016-09-15 11:30:17 --> Index MX_Controller Initialized
INFO - 2016-09-15 11:30:17 --> Model Class Initialized
INFO - 2016-09-15 11:30:17 --> Model Class Initialized
INFO - 2016-09-15 11:30:17 --> Final output sent to browser
DEBUG - 2016-09-15 11:30:17 --> Total execution time: 2.1899
INFO - 2016-09-15 11:30:17 --> Config Class Initialized
INFO - 2016-09-15 11:30:17 --> Hooks Class Initialized
DEBUG - 2016-09-15 11:30:18 --> UTF-8 Support Enabled
INFO - 2016-09-15 11:30:18 --> Utf8 Class Initialized
INFO - 2016-09-15 11:30:18 --> URI Class Initialized
INFO - 2016-09-15 11:30:18 --> Router Class Initialized
INFO - 2016-09-15 11:30:18 --> Output Class Initialized
INFO - 2016-09-15 11:30:18 --> Security Class Initialized
DEBUG - 2016-09-15 11:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 11:30:18 --> Input Class Initialized
INFO - 2016-09-15 11:30:18 --> Language Class Initialized
INFO - 2016-09-15 11:30:18 --> Language Class Initialized
INFO - 2016-09-15 11:30:18 --> Config Class Initialized
INFO - 2016-09-15 11:30:18 --> Loader Class Initialized
INFO - 2016-09-15 11:30:18 --> Helper loaded: url_helper
INFO - 2016-09-15 11:30:18 --> Database Driver Class Initialized
INFO - 2016-09-15 11:30:18 --> Controller Class Initialized
DEBUG - 2016-09-15 11:30:18 --> Index MX_Controller Initialized
INFO - 2016-09-15 11:30:18 --> Model Class Initialized
INFO - 2016-09-15 11:30:18 --> Model Class Initialized
DEBUG - 2016-09-15 11:30:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 11:30:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 11:30:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 11:30:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-15 11:30:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 11:30:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 11:30:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 11:30:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 11:30:18 --> Final output sent to browser
DEBUG - 2016-09-15 11:30:18 --> Total execution time: 0.8052
INFO - 2016-09-15 11:30:25 --> Config Class Initialized
INFO - 2016-09-15 11:30:25 --> Hooks Class Initialized
DEBUG - 2016-09-15 11:30:25 --> UTF-8 Support Enabled
INFO - 2016-09-15 11:30:25 --> Utf8 Class Initialized
INFO - 2016-09-15 11:30:25 --> URI Class Initialized
INFO - 2016-09-15 11:30:25 --> Router Class Initialized
INFO - 2016-09-15 11:30:25 --> Output Class Initialized
INFO - 2016-09-15 11:30:26 --> Security Class Initialized
DEBUG - 2016-09-15 11:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 11:30:26 --> Input Class Initialized
INFO - 2016-09-15 11:30:26 --> Language Class Initialized
INFO - 2016-09-15 11:30:26 --> Language Class Initialized
INFO - 2016-09-15 11:30:26 --> Config Class Initialized
INFO - 2016-09-15 11:30:26 --> Loader Class Initialized
INFO - 2016-09-15 11:30:26 --> Helper loaded: url_helper
INFO - 2016-09-15 11:30:26 --> Database Driver Class Initialized
INFO - 2016-09-15 11:30:26 --> Controller Class Initialized
DEBUG - 2016-09-15 11:30:26 --> Index MX_Controller Initialized
INFO - 2016-09-15 11:30:26 --> Model Class Initialized
INFO - 2016-09-15 11:30:26 --> Model Class Initialized
DEBUG - 2016-09-15 11:30:26 --> Anggota MX_Controller Initialized
INFO - 2016-09-15 11:30:26 --> Database Driver Class Initialized
INFO - 2016-09-15 11:30:26 --> Final output sent to browser
DEBUG - 2016-09-15 11:30:26 --> Total execution time: 0.9115
INFO - 2016-09-15 11:30:31 --> Config Class Initialized
INFO - 2016-09-15 11:30:31 --> Hooks Class Initialized
DEBUG - 2016-09-15 11:30:31 --> UTF-8 Support Enabled
INFO - 2016-09-15 11:30:31 --> Utf8 Class Initialized
INFO - 2016-09-15 11:30:31 --> URI Class Initialized
INFO - 2016-09-15 11:30:31 --> Router Class Initialized
INFO - 2016-09-15 11:30:31 --> Output Class Initialized
INFO - 2016-09-15 11:30:31 --> Security Class Initialized
DEBUG - 2016-09-15 11:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 11:30:31 --> Input Class Initialized
INFO - 2016-09-15 11:30:31 --> Language Class Initialized
INFO - 2016-09-15 11:30:31 --> Language Class Initialized
INFO - 2016-09-15 11:30:31 --> Config Class Initialized
INFO - 2016-09-15 11:30:31 --> Loader Class Initialized
INFO - 2016-09-15 11:30:31 --> Helper loaded: url_helper
INFO - 2016-09-15 11:30:31 --> Database Driver Class Initialized
INFO - 2016-09-15 11:30:31 --> Controller Class Initialized
DEBUG - 2016-09-15 11:30:31 --> Index MX_Controller Initialized
INFO - 2016-09-15 11:30:31 --> Model Class Initialized
INFO - 2016-09-15 11:30:31 --> Model Class Initialized
DEBUG - 2016-09-15 11:30:31 --> Anggota MX_Controller Initialized
INFO - 2016-09-15 11:30:31 --> Database Driver Class Initialized
INFO - 2016-09-15 11:30:31 --> Final output sent to browser
DEBUG - 2016-09-15 11:30:32 --> Total execution time: 0.5051
INFO - 2016-09-15 11:32:05 --> Config Class Initialized
INFO - 2016-09-15 11:32:05 --> Hooks Class Initialized
DEBUG - 2016-09-15 11:32:05 --> UTF-8 Support Enabled
INFO - 2016-09-15 11:32:05 --> Utf8 Class Initialized
INFO - 2016-09-15 11:32:05 --> URI Class Initialized
INFO - 2016-09-15 11:32:06 --> Router Class Initialized
INFO - 2016-09-15 11:32:06 --> Output Class Initialized
INFO - 2016-09-15 11:32:06 --> Security Class Initialized
DEBUG - 2016-09-15 11:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 11:32:06 --> Input Class Initialized
INFO - 2016-09-15 11:32:06 --> Language Class Initialized
INFO - 2016-09-15 11:32:06 --> Language Class Initialized
INFO - 2016-09-15 11:32:06 --> Config Class Initialized
INFO - 2016-09-15 11:32:06 --> Loader Class Initialized
INFO - 2016-09-15 11:32:06 --> Helper loaded: url_helper
INFO - 2016-09-15 11:32:06 --> Database Driver Class Initialized
INFO - 2016-09-15 11:32:06 --> Controller Class Initialized
DEBUG - 2016-09-15 11:32:06 --> Index MX_Controller Initialized
INFO - 2016-09-15 11:32:06 --> Model Class Initialized
INFO - 2016-09-15 11:32:06 --> Model Class Initialized
DEBUG - 2016-09-15 11:32:06 --> Anggota MX_Controller Initialized
INFO - 2016-09-15 11:32:06 --> Database Driver Class Initialized
INFO - 2016-09-15 11:32:06 --> Final output sent to browser
DEBUG - 2016-09-15 11:32:06 --> Total execution time: 0.4326
INFO - 2016-09-15 11:33:19 --> Config Class Initialized
INFO - 2016-09-15 11:33:19 --> Hooks Class Initialized
DEBUG - 2016-09-15 11:33:19 --> UTF-8 Support Enabled
INFO - 2016-09-15 11:33:19 --> Utf8 Class Initialized
INFO - 2016-09-15 11:33:19 --> URI Class Initialized
INFO - 2016-09-15 11:33:19 --> Router Class Initialized
INFO - 2016-09-15 11:33:19 --> Output Class Initialized
INFO - 2016-09-15 11:33:19 --> Security Class Initialized
DEBUG - 2016-09-15 11:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 11:33:19 --> Input Class Initialized
INFO - 2016-09-15 11:33:19 --> Language Class Initialized
INFO - 2016-09-15 11:33:19 --> Language Class Initialized
INFO - 2016-09-15 11:33:19 --> Config Class Initialized
INFO - 2016-09-15 11:33:19 --> Loader Class Initialized
INFO - 2016-09-15 11:33:19 --> Helper loaded: url_helper
INFO - 2016-09-15 11:33:19 --> Database Driver Class Initialized
INFO - 2016-09-15 11:33:19 --> Controller Class Initialized
DEBUG - 2016-09-15 11:33:19 --> Index MX_Controller Initialized
INFO - 2016-09-15 11:33:19 --> Model Class Initialized
INFO - 2016-09-15 11:33:19 --> Model Class Initialized
DEBUG - 2016-09-15 11:33:19 --> Anggota MX_Controller Initialized
INFO - 2016-09-15 11:33:19 --> Database Driver Class Initialized
INFO - 2016-09-15 11:33:19 --> Final output sent to browser
DEBUG - 2016-09-15 11:33:19 --> Total execution time: 0.4404
INFO - 2016-09-15 11:33:22 --> Config Class Initialized
INFO - 2016-09-15 11:33:22 --> Hooks Class Initialized
DEBUG - 2016-09-15 11:33:22 --> UTF-8 Support Enabled
INFO - 2016-09-15 11:33:22 --> Utf8 Class Initialized
INFO - 2016-09-15 11:33:22 --> URI Class Initialized
INFO - 2016-09-15 11:33:22 --> Router Class Initialized
INFO - 2016-09-15 11:33:22 --> Output Class Initialized
INFO - 2016-09-15 11:33:22 --> Security Class Initialized
DEBUG - 2016-09-15 11:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 11:33:22 --> Input Class Initialized
INFO - 2016-09-15 11:33:22 --> Language Class Initialized
INFO - 2016-09-15 11:33:22 --> Language Class Initialized
INFO - 2016-09-15 11:33:22 --> Config Class Initialized
INFO - 2016-09-15 11:33:22 --> Loader Class Initialized
INFO - 2016-09-15 11:33:22 --> Helper loaded: url_helper
INFO - 2016-09-15 11:33:22 --> Database Driver Class Initialized
INFO - 2016-09-15 11:33:22 --> Controller Class Initialized
DEBUG - 2016-09-15 11:33:22 --> Index MX_Controller Initialized
INFO - 2016-09-15 11:33:22 --> Model Class Initialized
INFO - 2016-09-15 11:33:22 --> Model Class Initialized
DEBUG - 2016-09-15 11:33:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 11:33:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 11:33:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 11:33:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_umum.php
DEBUG - 2016-09-15 11:33:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 11:33:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 11:33:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 11:33:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 11:33:23 --> Final output sent to browser
DEBUG - 2016-09-15 11:33:23 --> Total execution time: 0.6163
INFO - 2016-09-15 11:33:32 --> Config Class Initialized
INFO - 2016-09-15 11:33:32 --> Hooks Class Initialized
DEBUG - 2016-09-15 11:33:32 --> UTF-8 Support Enabled
INFO - 2016-09-15 11:33:32 --> Utf8 Class Initialized
INFO - 2016-09-15 11:33:32 --> URI Class Initialized
INFO - 2016-09-15 11:33:32 --> Router Class Initialized
INFO - 2016-09-15 11:33:32 --> Output Class Initialized
INFO - 2016-09-15 11:33:32 --> Security Class Initialized
DEBUG - 2016-09-15 11:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 11:33:32 --> Input Class Initialized
INFO - 2016-09-15 11:33:32 --> Language Class Initialized
INFO - 2016-09-15 11:33:32 --> Language Class Initialized
INFO - 2016-09-15 11:33:32 --> Config Class Initialized
INFO - 2016-09-15 11:33:32 --> Loader Class Initialized
INFO - 2016-09-15 11:33:32 --> Helper loaded: url_helper
INFO - 2016-09-15 11:33:32 --> Database Driver Class Initialized
INFO - 2016-09-15 11:33:32 --> Controller Class Initialized
DEBUG - 2016-09-15 11:33:32 --> Index MX_Controller Initialized
INFO - 2016-09-15 11:33:32 --> Model Class Initialized
INFO - 2016-09-15 11:33:32 --> Model Class Initialized
INFO - 2016-09-15 11:33:32 --> Final output sent to browser
DEBUG - 2016-09-15 11:33:32 --> Total execution time: 0.4802
INFO - 2016-09-15 11:33:33 --> Config Class Initialized
INFO - 2016-09-15 11:33:33 --> Hooks Class Initialized
DEBUG - 2016-09-15 11:33:33 --> UTF-8 Support Enabled
INFO - 2016-09-15 11:33:33 --> Utf8 Class Initialized
INFO - 2016-09-15 11:33:33 --> URI Class Initialized
INFO - 2016-09-15 11:33:33 --> Router Class Initialized
INFO - 2016-09-15 11:33:33 --> Output Class Initialized
INFO - 2016-09-15 11:33:33 --> Security Class Initialized
DEBUG - 2016-09-15 11:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 11:33:33 --> Input Class Initialized
INFO - 2016-09-15 11:33:33 --> Language Class Initialized
INFO - 2016-09-15 11:33:33 --> Language Class Initialized
INFO - 2016-09-15 11:33:33 --> Config Class Initialized
INFO - 2016-09-15 11:33:33 --> Loader Class Initialized
INFO - 2016-09-15 11:33:33 --> Helper loaded: url_helper
INFO - 2016-09-15 11:33:33 --> Database Driver Class Initialized
INFO - 2016-09-15 11:33:33 --> Controller Class Initialized
DEBUG - 2016-09-15 11:33:33 --> Index MX_Controller Initialized
INFO - 2016-09-15 11:33:33 --> Model Class Initialized
INFO - 2016-09-15 11:33:33 --> Model Class Initialized
DEBUG - 2016-09-15 11:33:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 11:33:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 11:33:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 11:33:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/dashboard.php
DEBUG - 2016-09-15 11:33:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 11:33:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 11:33:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 11:33:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 11:33:33 --> Final output sent to browser
DEBUG - 2016-09-15 11:33:33 --> Total execution time: 0.5697
INFO - 2016-09-15 11:33:39 --> Config Class Initialized
INFO - 2016-09-15 11:33:39 --> Hooks Class Initialized
DEBUG - 2016-09-15 11:33:39 --> UTF-8 Support Enabled
INFO - 2016-09-15 11:33:39 --> Utf8 Class Initialized
INFO - 2016-09-15 11:33:39 --> URI Class Initialized
INFO - 2016-09-15 11:33:39 --> Router Class Initialized
INFO - 2016-09-15 11:33:39 --> Output Class Initialized
INFO - 2016-09-15 11:33:39 --> Security Class Initialized
DEBUG - 2016-09-15 11:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 11:33:39 --> Input Class Initialized
INFO - 2016-09-15 11:33:39 --> Language Class Initialized
INFO - 2016-09-15 11:33:39 --> Language Class Initialized
INFO - 2016-09-15 11:33:39 --> Config Class Initialized
INFO - 2016-09-15 11:33:39 --> Loader Class Initialized
INFO - 2016-09-15 11:33:39 --> Helper loaded: url_helper
INFO - 2016-09-15 11:33:39 --> Database Driver Class Initialized
INFO - 2016-09-15 11:33:39 --> Controller Class Initialized
DEBUG - 2016-09-15 11:33:39 --> Index MX_Controller Initialized
INFO - 2016-09-15 11:33:39 --> Model Class Initialized
INFO - 2016-09-15 11:33:39 --> Model Class Initialized
DEBUG - 2016-09-15 11:33:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 11:33:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 11:33:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 11:33:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-15 11:33:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 11:33:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 11:33:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 11:33:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 11:33:39 --> Final output sent to browser
DEBUG - 2016-09-15 11:33:39 --> Total execution time: 0.6375
INFO - 2016-09-15 11:42:43 --> Config Class Initialized
INFO - 2016-09-15 11:42:43 --> Hooks Class Initialized
DEBUG - 2016-09-15 11:42:44 --> UTF-8 Support Enabled
INFO - 2016-09-15 11:42:44 --> Utf8 Class Initialized
INFO - 2016-09-15 11:42:44 --> URI Class Initialized
INFO - 2016-09-15 11:42:44 --> Router Class Initialized
INFO - 2016-09-15 11:42:44 --> Output Class Initialized
INFO - 2016-09-15 11:42:44 --> Security Class Initialized
DEBUG - 2016-09-15 11:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 11:42:44 --> Input Class Initialized
INFO - 2016-09-15 11:42:44 --> Language Class Initialized
INFO - 2016-09-15 11:42:44 --> Language Class Initialized
INFO - 2016-09-15 11:42:44 --> Config Class Initialized
INFO - 2016-09-15 11:42:44 --> Loader Class Initialized
INFO - 2016-09-15 11:42:44 --> Helper loaded: url_helper
INFO - 2016-09-15 11:42:44 --> Database Driver Class Initialized
INFO - 2016-09-15 11:42:44 --> Controller Class Initialized
DEBUG - 2016-09-15 11:42:44 --> Index MX_Controller Initialized
INFO - 2016-09-15 11:42:44 --> Model Class Initialized
INFO - 2016-09-15 11:42:44 --> Model Class Initialized
ERROR - 2016-09-15 11:42:44 --> Query error: Table 'koperasi.tm_peminjam' doesn't exist - Invalid query: SELECT * FROM tm_peminjam INNER JOIN tm_anggota ON tm_anggota.kd_anggota = tm_peminjam.kd_anggota
INFO - 2016-09-15 11:42:44 --> Language file loaded: language/english/db_lang.php
INFO - 2016-09-15 11:43:00 --> Config Class Initialized
INFO - 2016-09-15 11:43:00 --> Hooks Class Initialized
DEBUG - 2016-09-15 11:43:00 --> UTF-8 Support Enabled
INFO - 2016-09-15 11:43:00 --> Utf8 Class Initialized
INFO - 2016-09-15 11:43:00 --> URI Class Initialized
INFO - 2016-09-15 11:43:00 --> Router Class Initialized
INFO - 2016-09-15 11:43:00 --> Output Class Initialized
INFO - 2016-09-15 11:43:00 --> Security Class Initialized
DEBUG - 2016-09-15 11:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 11:43:00 --> Input Class Initialized
INFO - 2016-09-15 11:43:01 --> Language Class Initialized
INFO - 2016-09-15 11:43:01 --> Language Class Initialized
INFO - 2016-09-15 11:43:01 --> Config Class Initialized
INFO - 2016-09-15 11:43:01 --> Loader Class Initialized
INFO - 2016-09-15 11:43:01 --> Helper loaded: url_helper
INFO - 2016-09-15 11:43:01 --> Database Driver Class Initialized
INFO - 2016-09-15 11:43:01 --> Controller Class Initialized
DEBUG - 2016-09-15 11:43:01 --> Index MX_Controller Initialized
INFO - 2016-09-15 11:43:01 --> Model Class Initialized
INFO - 2016-09-15 11:43:01 --> Model Class Initialized
INFO - 2016-09-15 11:43:16 --> Config Class Initialized
INFO - 2016-09-15 11:43:16 --> Hooks Class Initialized
DEBUG - 2016-09-15 11:43:16 --> UTF-8 Support Enabled
INFO - 2016-09-15 11:43:16 --> Utf8 Class Initialized
INFO - 2016-09-15 11:43:16 --> URI Class Initialized
INFO - 2016-09-15 11:43:16 --> Router Class Initialized
INFO - 2016-09-15 11:43:16 --> Output Class Initialized
INFO - 2016-09-15 11:43:16 --> Security Class Initialized
DEBUG - 2016-09-15 11:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 11:43:16 --> Input Class Initialized
INFO - 2016-09-15 11:43:16 --> Language Class Initialized
INFO - 2016-09-15 11:43:16 --> Language Class Initialized
INFO - 2016-09-15 11:43:16 --> Config Class Initialized
INFO - 2016-09-15 11:43:16 --> Loader Class Initialized
INFO - 2016-09-15 11:43:16 --> Helper loaded: url_helper
INFO - 2016-09-15 11:43:16 --> Database Driver Class Initialized
INFO - 2016-09-15 11:43:16 --> Controller Class Initialized
DEBUG - 2016-09-15 11:43:16 --> Index MX_Controller Initialized
INFO - 2016-09-15 11:43:17 --> Model Class Initialized
INFO - 2016-09-15 11:43:17 --> Model Class Initialized
DEBUG - 2016-09-15 11:43:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 11:43:17 --> Final output sent to browser
DEBUG - 2016-09-15 11:43:17 --> Total execution time: 0.5282
INFO - 2016-09-15 11:43:32 --> Config Class Initialized
INFO - 2016-09-15 11:43:32 --> Hooks Class Initialized
DEBUG - 2016-09-15 11:43:32 --> UTF-8 Support Enabled
INFO - 2016-09-15 11:43:32 --> Utf8 Class Initialized
INFO - 2016-09-15 11:43:32 --> URI Class Initialized
INFO - 2016-09-15 11:43:32 --> Router Class Initialized
INFO - 2016-09-15 11:43:32 --> Output Class Initialized
INFO - 2016-09-15 11:43:32 --> Security Class Initialized
DEBUG - 2016-09-15 11:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 11:43:32 --> Input Class Initialized
INFO - 2016-09-15 11:43:32 --> Language Class Initialized
INFO - 2016-09-15 11:43:32 --> Language Class Initialized
INFO - 2016-09-15 11:43:32 --> Config Class Initialized
INFO - 2016-09-15 11:43:32 --> Loader Class Initialized
INFO - 2016-09-15 11:43:32 --> Helper loaded: url_helper
INFO - 2016-09-15 11:43:32 --> Database Driver Class Initialized
INFO - 2016-09-15 11:43:32 --> Controller Class Initialized
DEBUG - 2016-09-15 11:43:32 --> Index MX_Controller Initialized
INFO - 2016-09-15 11:43:32 --> Model Class Initialized
INFO - 2016-09-15 11:43:32 --> Model Class Initialized
DEBUG - 2016-09-15 11:43:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 11:43:32 --> Final output sent to browser
DEBUG - 2016-09-15 11:43:32 --> Total execution time: 0.5540
INFO - 2016-09-15 11:43:37 --> Config Class Initialized
INFO - 2016-09-15 11:43:37 --> Hooks Class Initialized
DEBUG - 2016-09-15 11:43:37 --> UTF-8 Support Enabled
INFO - 2016-09-15 11:43:37 --> Utf8 Class Initialized
INFO - 2016-09-15 11:43:37 --> URI Class Initialized
INFO - 2016-09-15 11:43:37 --> Router Class Initialized
INFO - 2016-09-15 11:43:37 --> Output Class Initialized
INFO - 2016-09-15 11:43:37 --> Security Class Initialized
DEBUG - 2016-09-15 11:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 11:43:37 --> Input Class Initialized
INFO - 2016-09-15 11:43:37 --> Language Class Initialized
INFO - 2016-09-15 11:43:37 --> Language Class Initialized
INFO - 2016-09-15 11:43:37 --> Config Class Initialized
INFO - 2016-09-15 11:43:37 --> Loader Class Initialized
INFO - 2016-09-15 11:43:37 --> Helper loaded: url_helper
INFO - 2016-09-15 11:43:37 --> Database Driver Class Initialized
INFO - 2016-09-15 11:43:37 --> Controller Class Initialized
DEBUG - 2016-09-15 11:43:37 --> Index MX_Controller Initialized
INFO - 2016-09-15 11:43:38 --> Model Class Initialized
INFO - 2016-09-15 11:43:38 --> Model Class Initialized
DEBUG - 2016-09-15 11:43:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 11:43:38 --> Final output sent to browser
DEBUG - 2016-09-15 11:43:38 --> Total execution time: 0.5279
INFO - 2016-09-15 11:44:46 --> Config Class Initialized
INFO - 2016-09-15 11:44:46 --> Hooks Class Initialized
DEBUG - 2016-09-15 11:44:46 --> UTF-8 Support Enabled
INFO - 2016-09-15 11:44:46 --> Utf8 Class Initialized
INFO - 2016-09-15 11:44:46 --> URI Class Initialized
INFO - 2016-09-15 11:44:46 --> Router Class Initialized
INFO - 2016-09-15 11:44:46 --> Output Class Initialized
INFO - 2016-09-15 11:44:46 --> Security Class Initialized
DEBUG - 2016-09-15 11:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 11:44:46 --> Input Class Initialized
INFO - 2016-09-15 11:44:46 --> Language Class Initialized
INFO - 2016-09-15 11:44:46 --> Language Class Initialized
INFO - 2016-09-15 11:44:46 --> Config Class Initialized
INFO - 2016-09-15 11:44:46 --> Loader Class Initialized
INFO - 2016-09-15 11:44:46 --> Helper loaded: url_helper
INFO - 2016-09-15 11:44:46 --> Database Driver Class Initialized
INFO - 2016-09-15 11:44:46 --> Controller Class Initialized
DEBUG - 2016-09-15 11:44:46 --> Index MX_Controller Initialized
INFO - 2016-09-15 11:44:47 --> Model Class Initialized
INFO - 2016-09-15 11:44:47 --> Model Class Initialized
DEBUG - 2016-09-15 11:44:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 11:44:47 --> Final output sent to browser
DEBUG - 2016-09-15 11:44:47 --> Total execution time: 0.5053
INFO - 2016-09-15 11:44:51 --> Config Class Initialized
INFO - 2016-09-15 11:44:51 --> Hooks Class Initialized
DEBUG - 2016-09-15 11:44:51 --> UTF-8 Support Enabled
INFO - 2016-09-15 11:44:51 --> Utf8 Class Initialized
INFO - 2016-09-15 11:44:51 --> URI Class Initialized
INFO - 2016-09-15 11:44:51 --> Router Class Initialized
INFO - 2016-09-15 11:44:51 --> Output Class Initialized
INFO - 2016-09-15 11:44:51 --> Security Class Initialized
DEBUG - 2016-09-15 11:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 11:44:51 --> Input Class Initialized
INFO - 2016-09-15 11:44:51 --> Language Class Initialized
INFO - 2016-09-15 11:44:51 --> Language Class Initialized
INFO - 2016-09-15 11:44:51 --> Config Class Initialized
INFO - 2016-09-15 11:44:51 --> Loader Class Initialized
INFO - 2016-09-15 11:44:51 --> Helper loaded: url_helper
INFO - 2016-09-15 11:44:51 --> Database Driver Class Initialized
INFO - 2016-09-15 11:44:51 --> Controller Class Initialized
DEBUG - 2016-09-15 11:44:51 --> Index MX_Controller Initialized
INFO - 2016-09-15 11:44:51 --> Model Class Initialized
INFO - 2016-09-15 11:44:51 --> Model Class Initialized
DEBUG - 2016-09-15 11:44:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 11:44:51 --> Final output sent to browser
DEBUG - 2016-09-15 11:44:51 --> Total execution time: 0.5408
INFO - 2016-09-15 11:45:20 --> Config Class Initialized
INFO - 2016-09-15 11:45:20 --> Hooks Class Initialized
DEBUG - 2016-09-15 11:45:20 --> UTF-8 Support Enabled
INFO - 2016-09-15 11:45:20 --> Utf8 Class Initialized
INFO - 2016-09-15 11:45:20 --> URI Class Initialized
INFO - 2016-09-15 11:45:20 --> Router Class Initialized
INFO - 2016-09-15 11:45:20 --> Output Class Initialized
INFO - 2016-09-15 11:45:20 --> Security Class Initialized
DEBUG - 2016-09-15 11:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 11:45:20 --> Input Class Initialized
INFO - 2016-09-15 11:45:20 --> Language Class Initialized
INFO - 2016-09-15 11:45:20 --> Language Class Initialized
INFO - 2016-09-15 11:45:20 --> Config Class Initialized
INFO - 2016-09-15 11:45:20 --> Loader Class Initialized
INFO - 2016-09-15 11:45:20 --> Helper loaded: url_helper
INFO - 2016-09-15 11:45:20 --> Database Driver Class Initialized
INFO - 2016-09-15 11:45:20 --> Controller Class Initialized
DEBUG - 2016-09-15 11:45:20 --> Index MX_Controller Initialized
INFO - 2016-09-15 11:45:20 --> Model Class Initialized
INFO - 2016-09-15 11:45:20 --> Model Class Initialized
DEBUG - 2016-09-15 11:45:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 11:45:20 --> Final output sent to browser
DEBUG - 2016-09-15 11:45:20 --> Total execution time: 0.5184
INFO - 2016-09-15 11:52:09 --> Config Class Initialized
INFO - 2016-09-15 11:52:09 --> Hooks Class Initialized
DEBUG - 2016-09-15 11:52:09 --> UTF-8 Support Enabled
INFO - 2016-09-15 11:52:09 --> Utf8 Class Initialized
INFO - 2016-09-15 11:52:09 --> URI Class Initialized
INFO - 2016-09-15 11:52:09 --> Router Class Initialized
INFO - 2016-09-15 11:52:09 --> Output Class Initialized
INFO - 2016-09-15 11:52:09 --> Security Class Initialized
DEBUG - 2016-09-15 11:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 11:52:09 --> Input Class Initialized
INFO - 2016-09-15 11:52:09 --> Language Class Initialized
INFO - 2016-09-15 11:52:09 --> Language Class Initialized
INFO - 2016-09-15 11:52:09 --> Config Class Initialized
INFO - 2016-09-15 11:52:09 --> Loader Class Initialized
INFO - 2016-09-15 11:52:10 --> Helper loaded: url_helper
INFO - 2016-09-15 11:52:10 --> Database Driver Class Initialized
INFO - 2016-09-15 11:52:10 --> Controller Class Initialized
DEBUG - 2016-09-15 11:52:10 --> Index MX_Controller Initialized
INFO - 2016-09-15 11:52:10 --> Model Class Initialized
INFO - 2016-09-15 11:52:10 --> Model Class Initialized
DEBUG - 2016-09-15 11:52:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 11:52:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 11:52:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 11:52:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_peminjam.php
DEBUG - 2016-09-15 11:52:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 11:52:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 11:52:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 11:52:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 11:52:10 --> Final output sent to browser
DEBUG - 2016-09-15 11:52:10 --> Total execution time: 0.8950
INFO - 2016-09-15 11:54:18 --> Config Class Initialized
INFO - 2016-09-15 11:54:19 --> Hooks Class Initialized
DEBUG - 2016-09-15 11:54:19 --> UTF-8 Support Enabled
INFO - 2016-09-15 11:54:19 --> Utf8 Class Initialized
INFO - 2016-09-15 11:54:19 --> URI Class Initialized
INFO - 2016-09-15 11:54:19 --> Router Class Initialized
INFO - 2016-09-15 11:54:19 --> Output Class Initialized
INFO - 2016-09-15 11:54:19 --> Security Class Initialized
DEBUG - 2016-09-15 11:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 11:54:19 --> Input Class Initialized
INFO - 2016-09-15 11:54:19 --> Language Class Initialized
INFO - 2016-09-15 11:54:19 --> Language Class Initialized
INFO - 2016-09-15 11:54:19 --> Config Class Initialized
INFO - 2016-09-15 11:54:19 --> Loader Class Initialized
INFO - 2016-09-15 11:54:19 --> Helper loaded: url_helper
INFO - 2016-09-15 11:54:19 --> Database Driver Class Initialized
INFO - 2016-09-15 11:54:19 --> Controller Class Initialized
DEBUG - 2016-09-15 11:54:19 --> Index MX_Controller Initialized
INFO - 2016-09-15 11:54:19 --> Model Class Initialized
INFO - 2016-09-15 11:54:19 --> Model Class Initialized
DEBUG - 2016-09-15 11:54:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 11:54:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 11:54:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 11:54:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_peminjam.php
DEBUG - 2016-09-15 11:54:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 11:54:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 11:54:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 11:54:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 11:54:19 --> Final output sent to browser
DEBUG - 2016-09-15 11:54:19 --> Total execution time: 0.8108
INFO - 2016-09-15 11:56:58 --> Config Class Initialized
INFO - 2016-09-15 11:56:58 --> Hooks Class Initialized
DEBUG - 2016-09-15 11:56:58 --> UTF-8 Support Enabled
INFO - 2016-09-15 11:56:58 --> Utf8 Class Initialized
INFO - 2016-09-15 11:56:58 --> URI Class Initialized
INFO - 2016-09-15 11:56:58 --> Router Class Initialized
INFO - 2016-09-15 11:56:58 --> Output Class Initialized
INFO - 2016-09-15 11:56:58 --> Security Class Initialized
DEBUG - 2016-09-15 11:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 11:56:58 --> Input Class Initialized
INFO - 2016-09-15 11:56:58 --> Language Class Initialized
INFO - 2016-09-15 11:56:58 --> Language Class Initialized
INFO - 2016-09-15 11:56:58 --> Config Class Initialized
INFO - 2016-09-15 11:56:58 --> Loader Class Initialized
INFO - 2016-09-15 11:56:58 --> Helper loaded: url_helper
INFO - 2016-09-15 11:56:59 --> Database Driver Class Initialized
INFO - 2016-09-15 11:56:59 --> Controller Class Initialized
DEBUG - 2016-09-15 11:56:59 --> Index MX_Controller Initialized
INFO - 2016-09-15 11:56:59 --> Model Class Initialized
INFO - 2016-09-15 11:56:59 --> Model Class Initialized
DEBUG - 2016-09-15 11:56:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 11:56:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 11:56:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 11:56:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_peminjam.php
DEBUG - 2016-09-15 11:56:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 11:56:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 11:56:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 11:56:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 11:56:59 --> Final output sent to browser
DEBUG - 2016-09-15 11:56:59 --> Total execution time: 0.6217
INFO - 2016-09-15 11:57:02 --> Config Class Initialized
INFO - 2016-09-15 11:57:02 --> Hooks Class Initialized
DEBUG - 2016-09-15 11:57:02 --> UTF-8 Support Enabled
INFO - 2016-09-15 11:57:02 --> Utf8 Class Initialized
INFO - 2016-09-15 11:57:02 --> URI Class Initialized
INFO - 2016-09-15 11:57:02 --> Router Class Initialized
INFO - 2016-09-15 11:57:02 --> Output Class Initialized
INFO - 2016-09-15 11:57:02 --> Security Class Initialized
DEBUG - 2016-09-15 11:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 11:57:02 --> Input Class Initialized
INFO - 2016-09-15 11:57:02 --> Language Class Initialized
INFO - 2016-09-15 11:57:02 --> Language Class Initialized
INFO - 2016-09-15 11:57:02 --> Config Class Initialized
INFO - 2016-09-15 11:57:02 --> Loader Class Initialized
INFO - 2016-09-15 11:57:02 --> Helper loaded: url_helper
INFO - 2016-09-15 11:57:02 --> Database Driver Class Initialized
INFO - 2016-09-15 11:57:02 --> Controller Class Initialized
DEBUG - 2016-09-15 11:57:02 --> Index MX_Controller Initialized
INFO - 2016-09-15 11:57:02 --> Model Class Initialized
INFO - 2016-09-15 11:57:02 --> Model Class Initialized
DEBUG - 2016-09-15 11:57:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 11:57:02 --> Final output sent to browser
DEBUG - 2016-09-15 11:57:02 --> Total execution time: 0.4585
INFO - 2016-09-15 11:57:04 --> Config Class Initialized
INFO - 2016-09-15 11:57:04 --> Hooks Class Initialized
DEBUG - 2016-09-15 11:57:04 --> UTF-8 Support Enabled
INFO - 2016-09-15 11:57:04 --> Utf8 Class Initialized
INFO - 2016-09-15 11:57:04 --> URI Class Initialized
INFO - 2016-09-15 11:57:04 --> Router Class Initialized
INFO - 2016-09-15 11:57:04 --> Output Class Initialized
INFO - 2016-09-15 11:57:04 --> Security Class Initialized
DEBUG - 2016-09-15 11:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 11:57:04 --> Input Class Initialized
INFO - 2016-09-15 11:57:04 --> Language Class Initialized
INFO - 2016-09-15 11:57:04 --> Language Class Initialized
INFO - 2016-09-15 11:57:04 --> Config Class Initialized
INFO - 2016-09-15 11:57:04 --> Loader Class Initialized
INFO - 2016-09-15 11:57:04 --> Helper loaded: url_helper
INFO - 2016-09-15 11:57:04 --> Database Driver Class Initialized
INFO - 2016-09-15 11:57:04 --> Controller Class Initialized
DEBUG - 2016-09-15 11:57:04 --> Index MX_Controller Initialized
INFO - 2016-09-15 11:57:04 --> Model Class Initialized
INFO - 2016-09-15 11:57:04 --> Model Class Initialized
DEBUG - 2016-09-15 11:57:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 11:57:04 --> Final output sent to browser
DEBUG - 2016-09-15 11:57:04 --> Total execution time: 0.4812
INFO - 2016-09-15 11:57:05 --> Config Class Initialized
INFO - 2016-09-15 11:57:05 --> Hooks Class Initialized
DEBUG - 2016-09-15 11:57:05 --> UTF-8 Support Enabled
INFO - 2016-09-15 11:57:05 --> Utf8 Class Initialized
INFO - 2016-09-15 11:57:05 --> URI Class Initialized
INFO - 2016-09-15 11:57:05 --> Router Class Initialized
INFO - 2016-09-15 11:57:05 --> Output Class Initialized
INFO - 2016-09-15 11:57:05 --> Security Class Initialized
DEBUG - 2016-09-15 11:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 11:57:05 --> Input Class Initialized
INFO - 2016-09-15 11:57:05 --> Language Class Initialized
INFO - 2016-09-15 11:57:05 --> Language Class Initialized
INFO - 2016-09-15 11:57:05 --> Config Class Initialized
INFO - 2016-09-15 11:57:05 --> Loader Class Initialized
INFO - 2016-09-15 11:57:05 --> Helper loaded: url_helper
INFO - 2016-09-15 11:57:05 --> Database Driver Class Initialized
INFO - 2016-09-15 11:57:05 --> Controller Class Initialized
DEBUG - 2016-09-15 11:57:05 --> Index MX_Controller Initialized
INFO - 2016-09-15 11:57:05 --> Model Class Initialized
INFO - 2016-09-15 11:57:05 --> Model Class Initialized
DEBUG - 2016-09-15 11:57:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 11:57:05 --> Final output sent to browser
DEBUG - 2016-09-15 11:57:05 --> Total execution time: 0.4988
INFO - 2016-09-15 11:57:21 --> Config Class Initialized
INFO - 2016-09-15 11:57:21 --> Hooks Class Initialized
DEBUG - 2016-09-15 11:57:21 --> UTF-8 Support Enabled
INFO - 2016-09-15 11:57:21 --> Utf8 Class Initialized
INFO - 2016-09-15 11:57:21 --> URI Class Initialized
INFO - 2016-09-15 11:57:21 --> Router Class Initialized
INFO - 2016-09-15 11:57:21 --> Output Class Initialized
INFO - 2016-09-15 11:57:21 --> Security Class Initialized
DEBUG - 2016-09-15 11:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 11:57:21 --> Input Class Initialized
INFO - 2016-09-15 11:57:21 --> Language Class Initialized
INFO - 2016-09-15 11:57:21 --> Language Class Initialized
INFO - 2016-09-15 11:57:21 --> Config Class Initialized
INFO - 2016-09-15 11:57:21 --> Loader Class Initialized
INFO - 2016-09-15 11:57:21 --> Helper loaded: url_helper
INFO - 2016-09-15 11:57:21 --> Database Driver Class Initialized
INFO - 2016-09-15 11:57:21 --> Controller Class Initialized
DEBUG - 2016-09-15 11:57:21 --> Index MX_Controller Initialized
INFO - 2016-09-15 11:57:21 --> Model Class Initialized
INFO - 2016-09-15 11:57:21 --> Model Class Initialized
DEBUG - 2016-09-15 11:57:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 11:57:21 --> Final output sent to browser
DEBUG - 2016-09-15 11:57:21 --> Total execution time: 0.5198
INFO - 2016-09-15 11:57:32 --> Config Class Initialized
INFO - 2016-09-15 11:57:32 --> Hooks Class Initialized
DEBUG - 2016-09-15 11:57:32 --> UTF-8 Support Enabled
INFO - 2016-09-15 11:57:32 --> Utf8 Class Initialized
INFO - 2016-09-15 11:57:32 --> URI Class Initialized
INFO - 2016-09-15 11:57:32 --> Router Class Initialized
INFO - 2016-09-15 11:57:32 --> Output Class Initialized
INFO - 2016-09-15 11:57:32 --> Security Class Initialized
DEBUG - 2016-09-15 11:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 11:57:32 --> Input Class Initialized
INFO - 2016-09-15 11:57:32 --> Language Class Initialized
INFO - 2016-09-15 11:57:32 --> Language Class Initialized
INFO - 2016-09-15 11:57:32 --> Config Class Initialized
INFO - 2016-09-15 11:57:32 --> Loader Class Initialized
INFO - 2016-09-15 11:57:32 --> Helper loaded: url_helper
INFO - 2016-09-15 11:57:32 --> Database Driver Class Initialized
INFO - 2016-09-15 11:57:32 --> Controller Class Initialized
DEBUG - 2016-09-15 11:57:32 --> Index MX_Controller Initialized
INFO - 2016-09-15 11:57:32 --> Model Class Initialized
INFO - 2016-09-15 11:57:33 --> Model Class Initialized
DEBUG - 2016-09-15 11:57:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 11:57:33 --> Final output sent to browser
DEBUG - 2016-09-15 11:57:33 --> Total execution time: 0.4956
INFO - 2016-09-15 11:57:33 --> Config Class Initialized
INFO - 2016-09-15 11:57:33 --> Hooks Class Initialized
DEBUG - 2016-09-15 11:57:33 --> UTF-8 Support Enabled
INFO - 2016-09-15 11:57:33 --> Utf8 Class Initialized
INFO - 2016-09-15 11:57:33 --> URI Class Initialized
INFO - 2016-09-15 11:57:33 --> Router Class Initialized
INFO - 2016-09-15 11:57:33 --> Output Class Initialized
INFO - 2016-09-15 11:57:33 --> Security Class Initialized
DEBUG - 2016-09-15 11:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 11:57:33 --> Input Class Initialized
INFO - 2016-09-15 11:57:33 --> Language Class Initialized
INFO - 2016-09-15 11:57:33 --> Language Class Initialized
INFO - 2016-09-15 11:57:33 --> Config Class Initialized
INFO - 2016-09-15 11:57:33 --> Loader Class Initialized
INFO - 2016-09-15 11:57:33 --> Helper loaded: url_helper
INFO - 2016-09-15 11:57:33 --> Database Driver Class Initialized
INFO - 2016-09-15 11:57:33 --> Controller Class Initialized
DEBUG - 2016-09-15 11:57:33 --> Index MX_Controller Initialized
INFO - 2016-09-15 11:57:33 --> Model Class Initialized
INFO - 2016-09-15 11:57:33 --> Model Class Initialized
DEBUG - 2016-09-15 11:57:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 11:57:33 --> Final output sent to browser
DEBUG - 2016-09-15 11:57:33 --> Total execution time: 0.4736
INFO - 2016-09-15 11:58:08 --> Config Class Initialized
INFO - 2016-09-15 11:58:08 --> Hooks Class Initialized
DEBUG - 2016-09-15 11:58:08 --> UTF-8 Support Enabled
INFO - 2016-09-15 11:58:08 --> Utf8 Class Initialized
INFO - 2016-09-15 11:58:08 --> URI Class Initialized
INFO - 2016-09-15 11:58:08 --> Router Class Initialized
INFO - 2016-09-15 11:58:08 --> Output Class Initialized
INFO - 2016-09-15 11:58:09 --> Security Class Initialized
DEBUG - 2016-09-15 11:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 11:58:09 --> Input Class Initialized
INFO - 2016-09-15 11:58:09 --> Language Class Initialized
INFO - 2016-09-15 11:58:09 --> Language Class Initialized
INFO - 2016-09-15 11:58:09 --> Config Class Initialized
INFO - 2016-09-15 11:58:09 --> Loader Class Initialized
INFO - 2016-09-15 11:58:09 --> Helper loaded: url_helper
INFO - 2016-09-15 11:58:09 --> Database Driver Class Initialized
INFO - 2016-09-15 11:58:09 --> Controller Class Initialized
DEBUG - 2016-09-15 11:58:09 --> Index MX_Controller Initialized
INFO - 2016-09-15 11:58:09 --> Model Class Initialized
INFO - 2016-09-15 11:58:09 --> Model Class Initialized
DEBUG - 2016-09-15 11:58:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 11:58:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 11:58:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 11:58:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_peminjam.php
DEBUG - 2016-09-15 11:58:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 11:58:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 11:58:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 11:58:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 11:58:09 --> Final output sent to browser
DEBUG - 2016-09-15 11:58:09 --> Total execution time: 0.6830
INFO - 2016-09-15 11:58:18 --> Config Class Initialized
INFO - 2016-09-15 11:58:18 --> Hooks Class Initialized
DEBUG - 2016-09-15 11:58:18 --> UTF-8 Support Enabled
INFO - 2016-09-15 11:58:18 --> Utf8 Class Initialized
INFO - 2016-09-15 11:58:18 --> URI Class Initialized
INFO - 2016-09-15 11:58:18 --> Router Class Initialized
INFO - 2016-09-15 11:58:18 --> Output Class Initialized
INFO - 2016-09-15 11:58:18 --> Security Class Initialized
DEBUG - 2016-09-15 11:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 11:58:18 --> Input Class Initialized
INFO - 2016-09-15 11:58:18 --> Language Class Initialized
INFO - 2016-09-15 11:58:18 --> Language Class Initialized
INFO - 2016-09-15 11:58:18 --> Config Class Initialized
INFO - 2016-09-15 11:58:18 --> Loader Class Initialized
INFO - 2016-09-15 11:58:18 --> Helper loaded: url_helper
INFO - 2016-09-15 11:58:18 --> Database Driver Class Initialized
INFO - 2016-09-15 11:58:18 --> Controller Class Initialized
DEBUG - 2016-09-15 11:58:18 --> Index MX_Controller Initialized
INFO - 2016-09-15 11:58:19 --> Model Class Initialized
INFO - 2016-09-15 11:58:19 --> Model Class Initialized
DEBUG - 2016-09-15 11:58:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 11:58:19 --> Final output sent to browser
DEBUG - 2016-09-15 11:58:19 --> Total execution time: 0.5466
INFO - 2016-09-15 11:58:19 --> Config Class Initialized
INFO - 2016-09-15 11:58:19 --> Hooks Class Initialized
DEBUG - 2016-09-15 11:58:19 --> UTF-8 Support Enabled
INFO - 2016-09-15 11:58:19 --> Utf8 Class Initialized
INFO - 2016-09-15 11:58:19 --> URI Class Initialized
INFO - 2016-09-15 11:58:19 --> Router Class Initialized
INFO - 2016-09-15 11:58:19 --> Output Class Initialized
INFO - 2016-09-15 11:58:19 --> Security Class Initialized
DEBUG - 2016-09-15 11:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 11:58:19 --> Input Class Initialized
INFO - 2016-09-15 11:58:19 --> Language Class Initialized
INFO - 2016-09-15 11:58:19 --> Language Class Initialized
INFO - 2016-09-15 11:58:19 --> Config Class Initialized
INFO - 2016-09-15 11:58:19 --> Loader Class Initialized
INFO - 2016-09-15 11:58:19 --> Helper loaded: url_helper
INFO - 2016-09-15 11:58:19 --> Database Driver Class Initialized
INFO - 2016-09-15 11:58:19 --> Controller Class Initialized
ERROR - 2016-09-15 11:58:19 --> 404 Page Not Found: ../modules/admin/controllers/Index/%3Cdiv
INFO - 2016-09-15 11:58:20 --> Config Class Initialized
INFO - 2016-09-15 11:58:20 --> Hooks Class Initialized
DEBUG - 2016-09-15 11:58:20 --> UTF-8 Support Enabled
INFO - 2016-09-15 11:58:20 --> Utf8 Class Initialized
INFO - 2016-09-15 11:58:20 --> URI Class Initialized
INFO - 2016-09-15 11:58:20 --> Router Class Initialized
INFO - 2016-09-15 11:58:20 --> Output Class Initialized
INFO - 2016-09-15 11:58:20 --> Security Class Initialized
DEBUG - 2016-09-15 11:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 11:58:20 --> Input Class Initialized
INFO - 2016-09-15 11:58:20 --> Language Class Initialized
INFO - 2016-09-15 11:58:20 --> Language Class Initialized
INFO - 2016-09-15 11:58:20 --> Config Class Initialized
INFO - 2016-09-15 11:58:20 --> Loader Class Initialized
INFO - 2016-09-15 11:58:20 --> Helper loaded: url_helper
INFO - 2016-09-15 11:58:20 --> Database Driver Class Initialized
INFO - 2016-09-15 11:58:20 --> Controller Class Initialized
DEBUG - 2016-09-15 11:58:20 --> Index MX_Controller Initialized
INFO - 2016-09-15 11:58:20 --> Model Class Initialized
INFO - 2016-09-15 11:58:20 --> Model Class Initialized
DEBUG - 2016-09-15 11:58:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 11:58:21 --> Final output sent to browser
DEBUG - 2016-09-15 11:58:21 --> Total execution time: 0.4646
INFO - 2016-09-15 11:58:21 --> Config Class Initialized
INFO - 2016-09-15 11:58:21 --> Hooks Class Initialized
DEBUG - 2016-09-15 11:58:21 --> UTF-8 Support Enabled
INFO - 2016-09-15 11:58:21 --> Utf8 Class Initialized
INFO - 2016-09-15 11:58:21 --> URI Class Initialized
INFO - 2016-09-15 11:58:21 --> Router Class Initialized
INFO - 2016-09-15 11:58:21 --> Output Class Initialized
INFO - 2016-09-15 11:58:21 --> Security Class Initialized
DEBUG - 2016-09-15 11:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 11:58:21 --> Input Class Initialized
INFO - 2016-09-15 11:58:21 --> Language Class Initialized
INFO - 2016-09-15 11:58:21 --> Language Class Initialized
INFO - 2016-09-15 11:58:21 --> Config Class Initialized
INFO - 2016-09-15 11:58:21 --> Loader Class Initialized
INFO - 2016-09-15 11:58:21 --> Helper loaded: url_helper
INFO - 2016-09-15 11:58:21 --> Database Driver Class Initialized
INFO - 2016-09-15 11:58:21 --> Controller Class Initialized
ERROR - 2016-09-15 11:58:21 --> 404 Page Not Found: ../modules/admin/controllers/Index/%3Cdiv
INFO - 2016-09-15 11:58:22 --> Config Class Initialized
INFO - 2016-09-15 11:58:22 --> Hooks Class Initialized
DEBUG - 2016-09-15 11:58:22 --> UTF-8 Support Enabled
INFO - 2016-09-15 11:58:22 --> Utf8 Class Initialized
INFO - 2016-09-15 11:58:22 --> URI Class Initialized
INFO - 2016-09-15 11:58:22 --> Router Class Initialized
INFO - 2016-09-15 11:58:22 --> Output Class Initialized
INFO - 2016-09-15 11:58:22 --> Security Class Initialized
DEBUG - 2016-09-15 11:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 11:58:22 --> Input Class Initialized
INFO - 2016-09-15 11:58:22 --> Language Class Initialized
INFO - 2016-09-15 11:58:22 --> Language Class Initialized
INFO - 2016-09-15 11:58:22 --> Config Class Initialized
INFO - 2016-09-15 11:58:22 --> Loader Class Initialized
INFO - 2016-09-15 11:58:22 --> Helper loaded: url_helper
INFO - 2016-09-15 11:58:22 --> Database Driver Class Initialized
INFO - 2016-09-15 11:58:22 --> Controller Class Initialized
DEBUG - 2016-09-15 11:58:22 --> Index MX_Controller Initialized
INFO - 2016-09-15 11:58:22 --> Model Class Initialized
INFO - 2016-09-15 11:58:22 --> Model Class Initialized
DEBUG - 2016-09-15 11:58:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 11:58:22 --> Final output sent to browser
DEBUG - 2016-09-15 11:58:22 --> Total execution time: 0.4749
INFO - 2016-09-15 11:58:22 --> Config Class Initialized
INFO - 2016-09-15 11:58:22 --> Hooks Class Initialized
DEBUG - 2016-09-15 11:58:22 --> UTF-8 Support Enabled
INFO - 2016-09-15 11:58:22 --> Utf8 Class Initialized
INFO - 2016-09-15 11:58:22 --> URI Class Initialized
INFO - 2016-09-15 11:58:22 --> Router Class Initialized
INFO - 2016-09-15 11:58:22 --> Output Class Initialized
INFO - 2016-09-15 11:58:22 --> Security Class Initialized
DEBUG - 2016-09-15 11:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 11:58:22 --> Input Class Initialized
INFO - 2016-09-15 11:58:22 --> Language Class Initialized
INFO - 2016-09-15 11:58:23 --> Language Class Initialized
INFO - 2016-09-15 11:58:23 --> Config Class Initialized
INFO - 2016-09-15 11:58:23 --> Config Class Initialized
INFO - 2016-09-15 11:58:23 --> Loader Class Initialized
INFO - 2016-09-15 11:58:23 --> Hooks Class Initialized
INFO - 2016-09-15 11:58:23 --> Helper loaded: url_helper
DEBUG - 2016-09-15 11:58:23 --> UTF-8 Support Enabled
INFO - 2016-09-15 11:58:23 --> Database Driver Class Initialized
INFO - 2016-09-15 11:58:23 --> Utf8 Class Initialized
INFO - 2016-09-15 11:58:23 --> Controller Class Initialized
ERROR - 2016-09-15 11:58:23 --> 404 Page Not Found: ../modules/admin/controllers/Index/%3Cdiv
INFO - 2016-09-15 11:58:23 --> URI Class Initialized
INFO - 2016-09-15 11:58:23 --> Router Class Initialized
INFO - 2016-09-15 11:58:23 --> Output Class Initialized
INFO - 2016-09-15 11:58:23 --> Security Class Initialized
DEBUG - 2016-09-15 11:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 11:58:23 --> Input Class Initialized
INFO - 2016-09-15 11:58:23 --> Language Class Initialized
INFO - 2016-09-15 11:58:23 --> Language Class Initialized
INFO - 2016-09-15 11:58:23 --> Config Class Initialized
INFO - 2016-09-15 11:58:23 --> Config Class Initialized
INFO - 2016-09-15 11:58:23 --> Hooks Class Initialized
INFO - 2016-09-15 11:58:23 --> Loader Class Initialized
INFO - 2016-09-15 11:58:23 --> Helper loaded: url_helper
DEBUG - 2016-09-15 11:58:23 --> UTF-8 Support Enabled
INFO - 2016-09-15 11:58:23 --> Utf8 Class Initialized
INFO - 2016-09-15 11:58:23 --> Database Driver Class Initialized
INFO - 2016-09-15 11:58:23 --> URI Class Initialized
INFO - 2016-09-15 11:58:23 --> Controller Class Initialized
DEBUG - 2016-09-15 11:58:23 --> Index MX_Controller Initialized
INFO - 2016-09-15 11:58:23 --> Router Class Initialized
INFO - 2016-09-15 11:58:23 --> Model Class Initialized
INFO - 2016-09-15 11:58:23 --> Output Class Initialized
INFO - 2016-09-15 11:58:23 --> Model Class Initialized
INFO - 2016-09-15 11:58:23 --> Security Class Initialized
DEBUG - 2016-09-15 11:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-15 11:58:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 11:58:23 --> Final output sent to browser
INFO - 2016-09-15 11:58:23 --> Input Class Initialized
DEBUG - 2016-09-15 11:58:23 --> Total execution time: 0.6189
INFO - 2016-09-15 11:58:23 --> Language Class Initialized
INFO - 2016-09-15 11:58:23 --> Language Class Initialized
INFO - 2016-09-15 11:58:23 --> Config Class Initialized
INFO - 2016-09-15 11:58:23 --> Hooks Class Initialized
INFO - 2016-09-15 11:58:23 --> Config Class Initialized
DEBUG - 2016-09-15 11:58:23 --> UTF-8 Support Enabled
INFO - 2016-09-15 11:58:23 --> Loader Class Initialized
INFO - 2016-09-15 11:58:23 --> Utf8 Class Initialized
INFO - 2016-09-15 11:58:23 --> Helper loaded: url_helper
INFO - 2016-09-15 11:58:23 --> URI Class Initialized
INFO - 2016-09-15 11:58:23 --> Database Driver Class Initialized
INFO - 2016-09-15 11:58:23 --> Router Class Initialized
INFO - 2016-09-15 11:58:23 --> Output Class Initialized
INFO - 2016-09-15 11:58:23 --> Controller Class Initialized
DEBUG - 2016-09-15 11:58:23 --> Index MX_Controller Initialized
INFO - 2016-09-15 11:58:23 --> Security Class Initialized
INFO - 2016-09-15 11:58:23 --> Model Class Initialized
DEBUG - 2016-09-15 11:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 11:58:23 --> Input Class Initialized
INFO - 2016-09-15 11:58:23 --> Model Class Initialized
INFO - 2016-09-15 11:58:23 --> Config Class Initialized
INFO - 2016-09-15 11:58:23 --> Hooks Class Initialized
INFO - 2016-09-15 11:58:23 --> Language Class Initialized
DEBUG - 2016-09-15 11:58:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 11:58:23 --> Final output sent to browser
DEBUG - 2016-09-15 11:58:23 --> UTF-8 Support Enabled
INFO - 2016-09-15 11:58:24 --> Language Class Initialized
DEBUG - 2016-09-15 11:58:24 --> Total execution time: 0.5742
INFO - 2016-09-15 11:58:24 --> Utf8 Class Initialized
INFO - 2016-09-15 11:58:24 --> Config Class Initialized
INFO - 2016-09-15 11:58:24 --> URI Class Initialized
INFO - 2016-09-15 11:58:24 --> Config Class Initialized
INFO - 2016-09-15 11:58:24 --> Loader Class Initialized
INFO - 2016-09-15 11:58:24 --> Hooks Class Initialized
INFO - 2016-09-15 11:58:24 --> Router Class Initialized
INFO - 2016-09-15 11:58:24 --> Helper loaded: url_helper
INFO - 2016-09-15 11:58:24 --> Output Class Initialized
DEBUG - 2016-09-15 11:58:24 --> UTF-8 Support Enabled
INFO - 2016-09-15 11:58:24 --> Database Driver Class Initialized
INFO - 2016-09-15 11:58:24 --> Utf8 Class Initialized
INFO - 2016-09-15 11:58:24 --> Security Class Initialized
INFO - 2016-09-15 11:58:24 --> Controller Class Initialized
ERROR - 2016-09-15 11:58:24 --> 404 Page Not Found: ../modules/admin/controllers/Index/%3Cdiv
INFO - 2016-09-15 11:58:24 --> URI Class Initialized
DEBUG - 2016-09-15 11:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 11:58:24 --> Input Class Initialized
INFO - 2016-09-15 11:58:24 --> Router Class Initialized
INFO - 2016-09-15 11:58:24 --> Language Class Initialized
INFO - 2016-09-15 11:58:24 --> Output Class Initialized
INFO - 2016-09-15 11:58:24 --> Language Class Initialized
INFO - 2016-09-15 11:58:24 --> Config Class Initialized
INFO - 2016-09-15 11:58:24 --> Security Class Initialized
DEBUG - 2016-09-15 11:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 11:58:24 --> Loader Class Initialized
INFO - 2016-09-15 11:58:24 --> Input Class Initialized
INFO - 2016-09-15 11:58:24 --> Helper loaded: url_helper
INFO - 2016-09-15 11:58:24 --> Language Class Initialized
INFO - 2016-09-15 11:58:24 --> Database Driver Class Initialized
INFO - 2016-09-15 11:58:24 --> Controller Class Initialized
INFO - 2016-09-15 11:58:24 --> Language Class Initialized
INFO - 2016-09-15 11:58:24 --> Config Class Initialized
DEBUG - 2016-09-15 11:58:24 --> Index MX_Controller Initialized
INFO - 2016-09-15 11:58:24 --> Model Class Initialized
INFO - 2016-09-15 11:58:24 --> Loader Class Initialized
INFO - 2016-09-15 11:58:24 --> Model Class Initialized
INFO - 2016-09-15 11:58:24 --> Helper loaded: url_helper
DEBUG - 2016-09-15 11:58:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 11:58:24 --> Database Driver Class Initialized
INFO - 2016-09-15 11:58:24 --> Final output sent to browser
INFO - 2016-09-15 11:58:24 --> Controller Class Initialized
DEBUG - 2016-09-15 11:58:24 --> Total execution time: 0.5241
ERROR - 2016-09-15 11:58:24 --> 404 Page Not Found: ../modules/admin/controllers/Index/%3Cdiv
INFO - 2016-09-15 11:58:24 --> Config Class Initialized
INFO - 2016-09-15 11:58:24 --> Hooks Class Initialized
DEBUG - 2016-09-15 11:58:24 --> UTF-8 Support Enabled
INFO - 2016-09-15 11:58:24 --> Utf8 Class Initialized
INFO - 2016-09-15 11:58:24 --> URI Class Initialized
INFO - 2016-09-15 11:58:24 --> Router Class Initialized
INFO - 2016-09-15 11:58:24 --> Output Class Initialized
INFO - 2016-09-15 11:58:24 --> Security Class Initialized
DEBUG - 2016-09-15 11:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 11:58:24 --> Input Class Initialized
INFO - 2016-09-15 11:58:24 --> Language Class Initialized
INFO - 2016-09-15 11:58:24 --> Language Class Initialized
INFO - 2016-09-15 11:58:24 --> Config Class Initialized
INFO - 2016-09-15 11:58:24 --> Loader Class Initialized
INFO - 2016-09-15 11:58:24 --> Helper loaded: url_helper
INFO - 2016-09-15 11:58:24 --> Database Driver Class Initialized
INFO - 2016-09-15 11:58:24 --> Controller Class Initialized
ERROR - 2016-09-15 11:58:24 --> 404 Page Not Found: ../modules/admin/controllers/Index/%3Cdiv
INFO - 2016-09-15 11:58:27 --> Config Class Initialized
INFO - 2016-09-15 11:58:27 --> Hooks Class Initialized
DEBUG - 2016-09-15 11:58:27 --> UTF-8 Support Enabled
INFO - 2016-09-15 11:58:27 --> Utf8 Class Initialized
INFO - 2016-09-15 11:58:27 --> URI Class Initialized
INFO - 2016-09-15 11:58:27 --> Router Class Initialized
INFO - 2016-09-15 11:58:27 --> Output Class Initialized
INFO - 2016-09-15 11:58:27 --> Security Class Initialized
DEBUG - 2016-09-15 11:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 11:58:27 --> Input Class Initialized
INFO - 2016-09-15 11:58:27 --> Language Class Initialized
INFO - 2016-09-15 11:58:28 --> Language Class Initialized
INFO - 2016-09-15 11:58:28 --> Config Class Initialized
INFO - 2016-09-15 11:58:28 --> Loader Class Initialized
INFO - 2016-09-15 11:58:28 --> Helper loaded: url_helper
INFO - 2016-09-15 11:58:28 --> Database Driver Class Initialized
INFO - 2016-09-15 11:58:28 --> Controller Class Initialized
DEBUG - 2016-09-15 11:58:28 --> Index MX_Controller Initialized
INFO - 2016-09-15 11:58:28 --> Model Class Initialized
INFO - 2016-09-15 11:58:28 --> Model Class Initialized
DEBUG - 2016-09-15 11:58:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 11:58:28 --> Final output sent to browser
DEBUG - 2016-09-15 11:58:28 --> Total execution time: 0.4866
INFO - 2016-09-15 11:58:28 --> Config Class Initialized
INFO - 2016-09-15 11:58:28 --> Hooks Class Initialized
DEBUG - 2016-09-15 11:58:28 --> UTF-8 Support Enabled
INFO - 2016-09-15 11:58:28 --> Utf8 Class Initialized
INFO - 2016-09-15 11:58:28 --> URI Class Initialized
INFO - 2016-09-15 11:58:28 --> Router Class Initialized
INFO - 2016-09-15 11:58:28 --> Output Class Initialized
INFO - 2016-09-15 11:58:28 --> Security Class Initialized
DEBUG - 2016-09-15 11:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 11:58:28 --> Input Class Initialized
INFO - 2016-09-15 11:58:28 --> Language Class Initialized
INFO - 2016-09-15 11:58:28 --> Language Class Initialized
INFO - 2016-09-15 11:58:28 --> Config Class Initialized
INFO - 2016-09-15 11:58:28 --> Loader Class Initialized
INFO - 2016-09-15 11:58:28 --> Helper loaded: url_helper
INFO - 2016-09-15 11:58:28 --> Database Driver Class Initialized
INFO - 2016-09-15 11:58:28 --> Controller Class Initialized
ERROR - 2016-09-15 11:58:28 --> 404 Page Not Found: ../modules/admin/controllers/Index/%3Cdiv
INFO - 2016-09-15 11:58:41 --> Config Class Initialized
INFO - 2016-09-15 11:58:41 --> Hooks Class Initialized
DEBUG - 2016-09-15 11:58:41 --> UTF-8 Support Enabled
INFO - 2016-09-15 11:58:41 --> Utf8 Class Initialized
INFO - 2016-09-15 11:58:41 --> URI Class Initialized
INFO - 2016-09-15 11:58:41 --> Router Class Initialized
INFO - 2016-09-15 11:58:41 --> Output Class Initialized
INFO - 2016-09-15 11:58:41 --> Security Class Initialized
DEBUG - 2016-09-15 11:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 11:58:41 --> Input Class Initialized
INFO - 2016-09-15 11:58:41 --> Language Class Initialized
INFO - 2016-09-15 11:58:41 --> Language Class Initialized
INFO - 2016-09-15 11:58:41 --> Config Class Initialized
INFO - 2016-09-15 11:58:41 --> Loader Class Initialized
INFO - 2016-09-15 11:58:41 --> Helper loaded: url_helper
INFO - 2016-09-15 11:58:41 --> Database Driver Class Initialized
INFO - 2016-09-15 11:58:41 --> Controller Class Initialized
DEBUG - 2016-09-15 11:58:41 --> Index MX_Controller Initialized
INFO - 2016-09-15 11:58:41 --> Model Class Initialized
INFO - 2016-09-15 11:58:41 --> Model Class Initialized
DEBUG - 2016-09-15 11:58:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 11:58:41 --> Final output sent to browser
DEBUG - 2016-09-15 11:58:41 --> Total execution time: 0.5328
INFO - 2016-09-15 11:58:41 --> Config Class Initialized
INFO - 2016-09-15 11:58:41 --> Hooks Class Initialized
DEBUG - 2016-09-15 11:58:42 --> UTF-8 Support Enabled
INFO - 2016-09-15 11:58:42 --> Utf8 Class Initialized
INFO - 2016-09-15 11:58:42 --> URI Class Initialized
INFO - 2016-09-15 11:58:42 --> Router Class Initialized
INFO - 2016-09-15 11:58:42 --> Output Class Initialized
INFO - 2016-09-15 11:58:42 --> Security Class Initialized
DEBUG - 2016-09-15 11:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 11:58:42 --> Input Class Initialized
INFO - 2016-09-15 11:58:42 --> Language Class Initialized
INFO - 2016-09-15 11:58:42 --> Language Class Initialized
INFO - 2016-09-15 11:58:42 --> Config Class Initialized
INFO - 2016-09-15 11:58:42 --> Loader Class Initialized
INFO - 2016-09-15 11:58:42 --> Helper loaded: url_helper
INFO - 2016-09-15 11:58:42 --> Database Driver Class Initialized
INFO - 2016-09-15 11:58:42 --> Controller Class Initialized
ERROR - 2016-09-15 11:58:42 --> 404 Page Not Found: ../modules/admin/controllers/Index/%3Cdiv
INFO - 2016-09-15 11:58:44 --> Config Class Initialized
INFO - 2016-09-15 11:58:44 --> Hooks Class Initialized
DEBUG - 2016-09-15 11:58:44 --> UTF-8 Support Enabled
INFO - 2016-09-15 11:58:44 --> Utf8 Class Initialized
INFO - 2016-09-15 11:58:44 --> URI Class Initialized
INFO - 2016-09-15 11:58:44 --> Router Class Initialized
INFO - 2016-09-15 11:58:44 --> Output Class Initialized
INFO - 2016-09-15 11:58:44 --> Security Class Initialized
DEBUG - 2016-09-15 11:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 11:58:44 --> Input Class Initialized
INFO - 2016-09-15 11:58:44 --> Language Class Initialized
INFO - 2016-09-15 11:58:44 --> Language Class Initialized
INFO - 2016-09-15 11:58:44 --> Config Class Initialized
INFO - 2016-09-15 11:58:44 --> Loader Class Initialized
INFO - 2016-09-15 11:58:44 --> Helper loaded: url_helper
INFO - 2016-09-15 11:58:45 --> Database Driver Class Initialized
INFO - 2016-09-15 11:58:45 --> Controller Class Initialized
DEBUG - 2016-09-15 11:58:45 --> Index MX_Controller Initialized
INFO - 2016-09-15 11:58:45 --> Model Class Initialized
INFO - 2016-09-15 11:58:45 --> Model Class Initialized
DEBUG - 2016-09-15 11:58:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 11:58:45 --> Final output sent to browser
DEBUG - 2016-09-15 11:58:45 --> Total execution time: 0.4997
INFO - 2016-09-15 11:58:45 --> Config Class Initialized
INFO - 2016-09-15 11:58:45 --> Hooks Class Initialized
DEBUG - 2016-09-15 11:58:45 --> UTF-8 Support Enabled
INFO - 2016-09-15 11:58:45 --> Utf8 Class Initialized
INFO - 2016-09-15 11:58:45 --> URI Class Initialized
INFO - 2016-09-15 11:58:45 --> Router Class Initialized
INFO - 2016-09-15 11:58:45 --> Output Class Initialized
INFO - 2016-09-15 11:58:45 --> Security Class Initialized
DEBUG - 2016-09-15 11:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 11:58:45 --> Input Class Initialized
INFO - 2016-09-15 11:58:45 --> Language Class Initialized
INFO - 2016-09-15 11:58:45 --> Language Class Initialized
INFO - 2016-09-15 11:58:45 --> Config Class Initialized
INFO - 2016-09-15 11:58:45 --> Loader Class Initialized
INFO - 2016-09-15 11:58:45 --> Helper loaded: url_helper
INFO - 2016-09-15 11:58:45 --> Database Driver Class Initialized
INFO - 2016-09-15 11:58:45 --> Controller Class Initialized
ERROR - 2016-09-15 11:58:45 --> 404 Page Not Found: ../modules/admin/controllers/Index/%3Cdiv
INFO - 2016-09-15 11:59:04 --> Config Class Initialized
INFO - 2016-09-15 11:59:04 --> Hooks Class Initialized
DEBUG - 2016-09-15 11:59:04 --> UTF-8 Support Enabled
INFO - 2016-09-15 11:59:04 --> Utf8 Class Initialized
INFO - 2016-09-15 11:59:04 --> URI Class Initialized
INFO - 2016-09-15 11:59:04 --> Router Class Initialized
INFO - 2016-09-15 11:59:05 --> Output Class Initialized
INFO - 2016-09-15 11:59:05 --> Security Class Initialized
DEBUG - 2016-09-15 11:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 11:59:05 --> Input Class Initialized
INFO - 2016-09-15 11:59:05 --> Language Class Initialized
INFO - 2016-09-15 11:59:05 --> Language Class Initialized
INFO - 2016-09-15 11:59:05 --> Config Class Initialized
INFO - 2016-09-15 11:59:05 --> Loader Class Initialized
INFO - 2016-09-15 11:59:05 --> Helper loaded: url_helper
INFO - 2016-09-15 11:59:05 --> Database Driver Class Initialized
INFO - 2016-09-15 11:59:05 --> Controller Class Initialized
DEBUG - 2016-09-15 11:59:05 --> Index MX_Controller Initialized
INFO - 2016-09-15 11:59:05 --> Model Class Initialized
INFO - 2016-09-15 11:59:05 --> Model Class Initialized
DEBUG - 2016-09-15 11:59:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 11:59:05 --> Final output sent to browser
DEBUG - 2016-09-15 11:59:05 --> Total execution time: 0.6001
INFO - 2016-09-15 11:59:05 --> Config Class Initialized
INFO - 2016-09-15 11:59:05 --> Hooks Class Initialized
DEBUG - 2016-09-15 11:59:05 --> UTF-8 Support Enabled
INFO - 2016-09-15 11:59:05 --> Utf8 Class Initialized
INFO - 2016-09-15 11:59:05 --> URI Class Initialized
INFO - 2016-09-15 11:59:05 --> Router Class Initialized
INFO - 2016-09-15 11:59:05 --> Output Class Initialized
INFO - 2016-09-15 11:59:05 --> Security Class Initialized
DEBUG - 2016-09-15 11:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 11:59:05 --> Input Class Initialized
INFO - 2016-09-15 11:59:05 --> Language Class Initialized
INFO - 2016-09-15 11:59:05 --> Language Class Initialized
INFO - 2016-09-15 11:59:05 --> Config Class Initialized
INFO - 2016-09-15 11:59:05 --> Loader Class Initialized
INFO - 2016-09-15 11:59:05 --> Helper loaded: url_helper
INFO - 2016-09-15 11:59:05 --> Database Driver Class Initialized
INFO - 2016-09-15 11:59:05 --> Controller Class Initialized
ERROR - 2016-09-15 11:59:05 --> 404 Page Not Found: ../modules/admin/controllers/Index/%3Cdiv
INFO - 2016-09-15 11:59:32 --> Config Class Initialized
INFO - 2016-09-15 11:59:32 --> Hooks Class Initialized
DEBUG - 2016-09-15 11:59:32 --> UTF-8 Support Enabled
INFO - 2016-09-15 11:59:32 --> Utf8 Class Initialized
INFO - 2016-09-15 11:59:32 --> URI Class Initialized
INFO - 2016-09-15 11:59:32 --> Router Class Initialized
INFO - 2016-09-15 11:59:32 --> Output Class Initialized
INFO - 2016-09-15 11:59:33 --> Security Class Initialized
DEBUG - 2016-09-15 11:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 11:59:33 --> Input Class Initialized
INFO - 2016-09-15 11:59:33 --> Language Class Initialized
INFO - 2016-09-15 11:59:33 --> Language Class Initialized
INFO - 2016-09-15 11:59:33 --> Config Class Initialized
INFO - 2016-09-15 11:59:33 --> Loader Class Initialized
INFO - 2016-09-15 11:59:33 --> Helper loaded: url_helper
INFO - 2016-09-15 11:59:33 --> Database Driver Class Initialized
INFO - 2016-09-15 11:59:33 --> Controller Class Initialized
DEBUG - 2016-09-15 11:59:33 --> Index MX_Controller Initialized
INFO - 2016-09-15 11:59:33 --> Model Class Initialized
INFO - 2016-09-15 11:59:33 --> Model Class Initialized
DEBUG - 2016-09-15 11:59:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 11:59:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 11:59:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 11:59:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_peminjam.php
DEBUG - 2016-09-15 11:59:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 11:59:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 11:59:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 11:59:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 11:59:33 --> Final output sent to browser
DEBUG - 2016-09-15 11:59:33 --> Total execution time: 0.7135
INFO - 2016-09-15 11:59:44 --> Config Class Initialized
INFO - 2016-09-15 11:59:44 --> Hooks Class Initialized
DEBUG - 2016-09-15 11:59:44 --> UTF-8 Support Enabled
INFO - 2016-09-15 11:59:44 --> Utf8 Class Initialized
INFO - 2016-09-15 11:59:44 --> URI Class Initialized
INFO - 2016-09-15 11:59:44 --> Router Class Initialized
INFO - 2016-09-15 11:59:44 --> Output Class Initialized
INFO - 2016-09-15 11:59:44 --> Security Class Initialized
DEBUG - 2016-09-15 11:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 11:59:44 --> Input Class Initialized
INFO - 2016-09-15 11:59:44 --> Language Class Initialized
INFO - 2016-09-15 11:59:44 --> Language Class Initialized
INFO - 2016-09-15 11:59:44 --> Config Class Initialized
INFO - 2016-09-15 11:59:44 --> Loader Class Initialized
INFO - 2016-09-15 11:59:44 --> Helper loaded: url_helper
INFO - 2016-09-15 11:59:44 --> Database Driver Class Initialized
INFO - 2016-09-15 11:59:44 --> Controller Class Initialized
DEBUG - 2016-09-15 11:59:44 --> Index MX_Controller Initialized
INFO - 2016-09-15 11:59:44 --> Model Class Initialized
INFO - 2016-09-15 11:59:44 --> Model Class Initialized
DEBUG - 2016-09-15 11:59:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 11:59:44 --> Final output sent to browser
DEBUG - 2016-09-15 11:59:45 --> Total execution time: 0.5824
INFO - 2016-09-15 11:59:49 --> Config Class Initialized
INFO - 2016-09-15 11:59:49 --> Hooks Class Initialized
DEBUG - 2016-09-15 11:59:49 --> UTF-8 Support Enabled
INFO - 2016-09-15 11:59:49 --> Utf8 Class Initialized
INFO - 2016-09-15 11:59:49 --> URI Class Initialized
INFO - 2016-09-15 11:59:49 --> Router Class Initialized
INFO - 2016-09-15 11:59:49 --> Output Class Initialized
INFO - 2016-09-15 11:59:49 --> Security Class Initialized
DEBUG - 2016-09-15 11:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 11:59:49 --> Input Class Initialized
INFO - 2016-09-15 11:59:49 --> Language Class Initialized
INFO - 2016-09-15 11:59:49 --> Language Class Initialized
INFO - 2016-09-15 11:59:49 --> Config Class Initialized
INFO - 2016-09-15 11:59:49 --> Loader Class Initialized
INFO - 2016-09-15 11:59:49 --> Helper loaded: url_helper
INFO - 2016-09-15 11:59:49 --> Database Driver Class Initialized
INFO - 2016-09-15 11:59:49 --> Controller Class Initialized
DEBUG - 2016-09-15 11:59:49 --> Index MX_Controller Initialized
INFO - 2016-09-15 11:59:49 --> Model Class Initialized
INFO - 2016-09-15 11:59:49 --> Model Class Initialized
DEBUG - 2016-09-15 11:59:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 11:59:49 --> Final output sent to browser
DEBUG - 2016-09-15 11:59:49 --> Total execution time: 0.5405
INFO - 2016-09-15 12:01:06 --> Config Class Initialized
INFO - 2016-09-15 12:01:06 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:01:06 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:01:06 --> Utf8 Class Initialized
INFO - 2016-09-15 12:01:06 --> URI Class Initialized
INFO - 2016-09-15 12:01:06 --> Router Class Initialized
INFO - 2016-09-15 12:01:06 --> Output Class Initialized
INFO - 2016-09-15 12:01:07 --> Security Class Initialized
DEBUG - 2016-09-15 12:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:01:07 --> Input Class Initialized
INFO - 2016-09-15 12:01:07 --> Language Class Initialized
INFO - 2016-09-15 12:01:07 --> Language Class Initialized
INFO - 2016-09-15 12:01:07 --> Config Class Initialized
INFO - 2016-09-15 12:01:07 --> Loader Class Initialized
INFO - 2016-09-15 12:01:07 --> Helper loaded: url_helper
INFO - 2016-09-15 12:01:07 --> Database Driver Class Initialized
INFO - 2016-09-15 12:01:07 --> Controller Class Initialized
DEBUG - 2016-09-15 12:01:07 --> Index MX_Controller Initialized
INFO - 2016-09-15 12:01:07 --> Model Class Initialized
INFO - 2016-09-15 12:01:07 --> Model Class Initialized
DEBUG - 2016-09-15 12:01:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 12:01:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 12:01:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 12:01:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_peminjam.php
DEBUG - 2016-09-15 12:01:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 12:01:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 12:01:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 12:01:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 12:01:07 --> Final output sent to browser
DEBUG - 2016-09-15 12:01:07 --> Total execution time: 0.7276
INFO - 2016-09-15 12:01:17 --> Config Class Initialized
INFO - 2016-09-15 12:01:17 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:01:17 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:01:17 --> Utf8 Class Initialized
INFO - 2016-09-15 12:01:17 --> URI Class Initialized
INFO - 2016-09-15 12:01:17 --> Router Class Initialized
INFO - 2016-09-15 12:01:17 --> Output Class Initialized
INFO - 2016-09-15 12:01:17 --> Security Class Initialized
DEBUG - 2016-09-15 12:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:01:17 --> Input Class Initialized
INFO - 2016-09-15 12:01:17 --> Language Class Initialized
INFO - 2016-09-15 12:01:17 --> Language Class Initialized
INFO - 2016-09-15 12:01:17 --> Config Class Initialized
INFO - 2016-09-15 12:01:17 --> Loader Class Initialized
INFO - 2016-09-15 12:01:17 --> Helper loaded: url_helper
INFO - 2016-09-15 12:01:17 --> Database Driver Class Initialized
INFO - 2016-09-15 12:01:17 --> Controller Class Initialized
DEBUG - 2016-09-15 12:01:17 --> Index MX_Controller Initialized
INFO - 2016-09-15 12:01:17 --> Model Class Initialized
INFO - 2016-09-15 12:01:17 --> Model Class Initialized
DEBUG - 2016-09-15 12:01:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 12:01:17 --> Final output sent to browser
DEBUG - 2016-09-15 12:01:17 --> Total execution time: 0.5489
INFO - 2016-09-15 12:01:20 --> Config Class Initialized
INFO - 2016-09-15 12:01:20 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:01:20 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:01:20 --> Utf8 Class Initialized
INFO - 2016-09-15 12:01:20 --> URI Class Initialized
INFO - 2016-09-15 12:01:20 --> Router Class Initialized
INFO - 2016-09-15 12:01:20 --> Output Class Initialized
INFO - 2016-09-15 12:01:20 --> Security Class Initialized
DEBUG - 2016-09-15 12:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:01:20 --> Input Class Initialized
INFO - 2016-09-15 12:01:20 --> Language Class Initialized
INFO - 2016-09-15 12:01:20 --> Language Class Initialized
INFO - 2016-09-15 12:01:20 --> Config Class Initialized
INFO - 2016-09-15 12:01:20 --> Loader Class Initialized
INFO - 2016-09-15 12:01:20 --> Helper loaded: url_helper
INFO - 2016-09-15 12:01:20 --> Database Driver Class Initialized
INFO - 2016-09-15 12:01:20 --> Controller Class Initialized
DEBUG - 2016-09-15 12:01:20 --> Index MX_Controller Initialized
INFO - 2016-09-15 12:01:20 --> Model Class Initialized
INFO - 2016-09-15 12:01:20 --> Model Class Initialized
DEBUG - 2016-09-15 12:01:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 12:01:20 --> Final output sent to browser
DEBUG - 2016-09-15 12:01:20 --> Total execution time: 0.5120
INFO - 2016-09-15 12:01:30 --> Config Class Initialized
INFO - 2016-09-15 12:01:30 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:01:30 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:01:30 --> Utf8 Class Initialized
INFO - 2016-09-15 12:01:30 --> URI Class Initialized
INFO - 2016-09-15 12:01:30 --> Router Class Initialized
INFO - 2016-09-15 12:01:30 --> Output Class Initialized
INFO - 2016-09-15 12:01:30 --> Security Class Initialized
DEBUG - 2016-09-15 12:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:01:30 --> Input Class Initialized
INFO - 2016-09-15 12:01:30 --> Language Class Initialized
INFO - 2016-09-15 12:01:30 --> Language Class Initialized
INFO - 2016-09-15 12:01:30 --> Config Class Initialized
INFO - 2016-09-15 12:01:30 --> Loader Class Initialized
INFO - 2016-09-15 12:01:30 --> Helper loaded: url_helper
INFO - 2016-09-15 12:01:30 --> Database Driver Class Initialized
INFO - 2016-09-15 12:01:30 --> Controller Class Initialized
DEBUG - 2016-09-15 12:01:30 --> Index MX_Controller Initialized
INFO - 2016-09-15 12:01:30 --> Model Class Initialized
INFO - 2016-09-15 12:01:30 --> Model Class Initialized
DEBUG - 2016-09-15 12:01:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 12:01:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 12:01:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 12:01:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_peminjam.php
DEBUG - 2016-09-15 12:01:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 12:01:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 12:01:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 12:01:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 12:01:31 --> Final output sent to browser
DEBUG - 2016-09-15 12:01:31 --> Total execution time: 0.7421
INFO - 2016-09-15 12:01:43 --> Config Class Initialized
INFO - 2016-09-15 12:01:43 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:01:43 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:01:43 --> Utf8 Class Initialized
INFO - 2016-09-15 12:01:43 --> URI Class Initialized
INFO - 2016-09-15 12:01:43 --> Router Class Initialized
INFO - 2016-09-15 12:01:43 --> Output Class Initialized
INFO - 2016-09-15 12:01:43 --> Security Class Initialized
DEBUG - 2016-09-15 12:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:01:43 --> Input Class Initialized
INFO - 2016-09-15 12:01:43 --> Language Class Initialized
INFO - 2016-09-15 12:01:43 --> Language Class Initialized
INFO - 2016-09-15 12:01:43 --> Config Class Initialized
INFO - 2016-09-15 12:01:43 --> Loader Class Initialized
INFO - 2016-09-15 12:01:43 --> Helper loaded: url_helper
INFO - 2016-09-15 12:01:43 --> Database Driver Class Initialized
INFO - 2016-09-15 12:01:43 --> Controller Class Initialized
DEBUG - 2016-09-15 12:01:43 --> Index MX_Controller Initialized
INFO - 2016-09-15 12:01:43 --> Model Class Initialized
INFO - 2016-09-15 12:01:43 --> Model Class Initialized
DEBUG - 2016-09-15 12:01:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 12:01:43 --> Final output sent to browser
DEBUG - 2016-09-15 12:01:43 --> Total execution time: 0.6560
INFO - 2016-09-15 12:01:45 --> Config Class Initialized
INFO - 2016-09-15 12:01:45 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:01:45 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:01:45 --> Utf8 Class Initialized
INFO - 2016-09-15 12:01:45 --> URI Class Initialized
INFO - 2016-09-15 12:01:45 --> Router Class Initialized
INFO - 2016-09-15 12:01:45 --> Output Class Initialized
INFO - 2016-09-15 12:01:45 --> Security Class Initialized
DEBUG - 2016-09-15 12:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:01:45 --> Input Class Initialized
INFO - 2016-09-15 12:01:45 --> Language Class Initialized
INFO - 2016-09-15 12:01:45 --> Language Class Initialized
INFO - 2016-09-15 12:01:45 --> Config Class Initialized
INFO - 2016-09-15 12:01:45 --> Loader Class Initialized
INFO - 2016-09-15 12:01:45 --> Helper loaded: url_helper
INFO - 2016-09-15 12:01:45 --> Database Driver Class Initialized
INFO - 2016-09-15 12:01:45 --> Controller Class Initialized
DEBUG - 2016-09-15 12:01:45 --> Index MX_Controller Initialized
INFO - 2016-09-15 12:01:45 --> Model Class Initialized
INFO - 2016-09-15 12:01:45 --> Model Class Initialized
DEBUG - 2016-09-15 12:01:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 12:01:45 --> Final output sent to browser
DEBUG - 2016-09-15 12:01:45 --> Total execution time: 0.5243
INFO - 2016-09-15 12:02:22 --> Config Class Initialized
INFO - 2016-09-15 12:02:22 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:02:22 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:02:22 --> Utf8 Class Initialized
INFO - 2016-09-15 12:02:22 --> URI Class Initialized
INFO - 2016-09-15 12:02:22 --> Router Class Initialized
INFO - 2016-09-15 12:02:22 --> Output Class Initialized
INFO - 2016-09-15 12:02:23 --> Security Class Initialized
DEBUG - 2016-09-15 12:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:02:23 --> Input Class Initialized
INFO - 2016-09-15 12:02:23 --> Language Class Initialized
INFO - 2016-09-15 12:02:23 --> Language Class Initialized
INFO - 2016-09-15 12:02:23 --> Config Class Initialized
INFO - 2016-09-15 12:02:23 --> Loader Class Initialized
INFO - 2016-09-15 12:02:23 --> Helper loaded: url_helper
INFO - 2016-09-15 12:02:23 --> Database Driver Class Initialized
INFO - 2016-09-15 12:02:23 --> Controller Class Initialized
DEBUG - 2016-09-15 12:02:23 --> Index MX_Controller Initialized
INFO - 2016-09-15 12:02:23 --> Model Class Initialized
INFO - 2016-09-15 12:02:23 --> Model Class Initialized
DEBUG - 2016-09-15 12:02:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 12:02:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 12:02:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 12:02:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_peminjam.php
DEBUG - 2016-09-15 12:02:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 12:02:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 12:02:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 12:02:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 12:02:23 --> Final output sent to browser
DEBUG - 2016-09-15 12:02:23 --> Total execution time: 0.7314
INFO - 2016-09-15 12:02:29 --> Config Class Initialized
INFO - 2016-09-15 12:02:29 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:02:29 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:02:29 --> Utf8 Class Initialized
INFO - 2016-09-15 12:02:29 --> URI Class Initialized
INFO - 2016-09-15 12:02:29 --> Router Class Initialized
INFO - 2016-09-15 12:02:30 --> Output Class Initialized
INFO - 2016-09-15 12:02:30 --> Security Class Initialized
DEBUG - 2016-09-15 12:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:02:30 --> Input Class Initialized
INFO - 2016-09-15 12:02:30 --> Language Class Initialized
INFO - 2016-09-15 12:02:30 --> Language Class Initialized
INFO - 2016-09-15 12:02:30 --> Config Class Initialized
INFO - 2016-09-15 12:02:30 --> Loader Class Initialized
INFO - 2016-09-15 12:02:30 --> Helper loaded: url_helper
INFO - 2016-09-15 12:02:30 --> Database Driver Class Initialized
INFO - 2016-09-15 12:02:30 --> Controller Class Initialized
DEBUG - 2016-09-15 12:02:30 --> Index MX_Controller Initialized
INFO - 2016-09-15 12:02:30 --> Model Class Initialized
INFO - 2016-09-15 12:02:30 --> Model Class Initialized
DEBUG - 2016-09-15 12:02:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 12:02:30 --> Final output sent to browser
DEBUG - 2016-09-15 12:02:30 --> Total execution time: 0.6602
INFO - 2016-09-15 12:02:33 --> Config Class Initialized
INFO - 2016-09-15 12:02:33 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:02:33 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:02:33 --> Utf8 Class Initialized
INFO - 2016-09-15 12:02:33 --> URI Class Initialized
INFO - 2016-09-15 12:02:33 --> Router Class Initialized
INFO - 2016-09-15 12:02:33 --> Output Class Initialized
INFO - 2016-09-15 12:02:33 --> Security Class Initialized
DEBUG - 2016-09-15 12:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:02:33 --> Input Class Initialized
INFO - 2016-09-15 12:02:33 --> Language Class Initialized
INFO - 2016-09-15 12:02:33 --> Language Class Initialized
INFO - 2016-09-15 12:02:33 --> Config Class Initialized
INFO - 2016-09-15 12:02:33 --> Loader Class Initialized
INFO - 2016-09-15 12:02:33 --> Helper loaded: url_helper
INFO - 2016-09-15 12:02:33 --> Database Driver Class Initialized
INFO - 2016-09-15 12:02:33 --> Controller Class Initialized
DEBUG - 2016-09-15 12:02:33 --> Index MX_Controller Initialized
INFO - 2016-09-15 12:02:33 --> Model Class Initialized
INFO - 2016-09-15 12:02:33 --> Model Class Initialized
DEBUG - 2016-09-15 12:02:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 12:02:33 --> Final output sent to browser
DEBUG - 2016-09-15 12:02:33 --> Total execution time: 0.5688
INFO - 2016-09-15 12:03:36 --> Config Class Initialized
INFO - 2016-09-15 12:03:36 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:03:36 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:03:36 --> Utf8 Class Initialized
INFO - 2016-09-15 12:03:36 --> URI Class Initialized
INFO - 2016-09-15 12:03:36 --> Router Class Initialized
INFO - 2016-09-15 12:03:36 --> Output Class Initialized
INFO - 2016-09-15 12:03:36 --> Security Class Initialized
DEBUG - 2016-09-15 12:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:03:37 --> Input Class Initialized
INFO - 2016-09-15 12:03:37 --> Language Class Initialized
INFO - 2016-09-15 12:03:37 --> Language Class Initialized
INFO - 2016-09-15 12:03:37 --> Config Class Initialized
INFO - 2016-09-15 12:03:37 --> Loader Class Initialized
INFO - 2016-09-15 12:03:37 --> Helper loaded: url_helper
INFO - 2016-09-15 12:03:37 --> Database Driver Class Initialized
INFO - 2016-09-15 12:03:37 --> Controller Class Initialized
DEBUG - 2016-09-15 12:03:37 --> Index MX_Controller Initialized
INFO - 2016-09-15 12:03:37 --> Model Class Initialized
INFO - 2016-09-15 12:03:37 --> Model Class Initialized
DEBUG - 2016-09-15 12:03:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 12:03:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 12:03:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 12:03:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_peminjam.php
DEBUG - 2016-09-15 12:03:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 12:03:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 12:03:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 12:03:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 12:03:37 --> Final output sent to browser
DEBUG - 2016-09-15 12:03:37 --> Total execution time: 0.7298
INFO - 2016-09-15 12:03:46 --> Config Class Initialized
INFO - 2016-09-15 12:03:46 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:03:46 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:03:46 --> Utf8 Class Initialized
INFO - 2016-09-15 12:03:46 --> URI Class Initialized
INFO - 2016-09-15 12:03:46 --> Router Class Initialized
INFO - 2016-09-15 12:03:46 --> Output Class Initialized
INFO - 2016-09-15 12:03:46 --> Security Class Initialized
DEBUG - 2016-09-15 12:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:03:46 --> Input Class Initialized
INFO - 2016-09-15 12:03:46 --> Language Class Initialized
INFO - 2016-09-15 12:03:46 --> Language Class Initialized
INFO - 2016-09-15 12:03:46 --> Config Class Initialized
INFO - 2016-09-15 12:03:46 --> Loader Class Initialized
INFO - 2016-09-15 12:03:46 --> Helper loaded: url_helper
INFO - 2016-09-15 12:03:46 --> Database Driver Class Initialized
INFO - 2016-09-15 12:03:46 --> Controller Class Initialized
DEBUG - 2016-09-15 12:03:46 --> Index MX_Controller Initialized
INFO - 2016-09-15 12:03:46 --> Model Class Initialized
INFO - 2016-09-15 12:03:46 --> Model Class Initialized
DEBUG - 2016-09-15 12:03:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 12:03:46 --> Final output sent to browser
DEBUG - 2016-09-15 12:03:46 --> Total execution time: 0.6048
INFO - 2016-09-15 12:03:50 --> Config Class Initialized
INFO - 2016-09-15 12:03:50 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:03:50 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:03:50 --> Utf8 Class Initialized
INFO - 2016-09-15 12:03:50 --> URI Class Initialized
INFO - 2016-09-15 12:03:50 --> Router Class Initialized
INFO - 2016-09-15 12:03:50 --> Output Class Initialized
INFO - 2016-09-15 12:03:50 --> Security Class Initialized
DEBUG - 2016-09-15 12:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:03:50 --> Input Class Initialized
INFO - 2016-09-15 12:03:50 --> Language Class Initialized
INFO - 2016-09-15 12:03:50 --> Language Class Initialized
INFO - 2016-09-15 12:03:50 --> Config Class Initialized
INFO - 2016-09-15 12:03:50 --> Loader Class Initialized
INFO - 2016-09-15 12:03:50 --> Helper loaded: url_helper
INFO - 2016-09-15 12:03:50 --> Database Driver Class Initialized
INFO - 2016-09-15 12:03:50 --> Controller Class Initialized
DEBUG - 2016-09-15 12:03:50 --> Index MX_Controller Initialized
INFO - 2016-09-15 12:03:50 --> Model Class Initialized
INFO - 2016-09-15 12:03:50 --> Model Class Initialized
DEBUG - 2016-09-15 12:03:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 12:03:50 --> Final output sent to browser
DEBUG - 2016-09-15 12:03:50 --> Total execution time: 0.5531
INFO - 2016-09-15 12:04:17 --> Config Class Initialized
INFO - 2016-09-15 12:04:17 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:04:17 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:04:17 --> Utf8 Class Initialized
INFO - 2016-09-15 12:04:17 --> URI Class Initialized
INFO - 2016-09-15 12:04:17 --> Router Class Initialized
INFO - 2016-09-15 12:04:17 --> Output Class Initialized
INFO - 2016-09-15 12:04:17 --> Security Class Initialized
DEBUG - 2016-09-15 12:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:04:17 --> Input Class Initialized
INFO - 2016-09-15 12:04:17 --> Language Class Initialized
INFO - 2016-09-15 12:04:17 --> Language Class Initialized
INFO - 2016-09-15 12:04:17 --> Config Class Initialized
INFO - 2016-09-15 12:04:18 --> Loader Class Initialized
INFO - 2016-09-15 12:04:18 --> Helper loaded: url_helper
INFO - 2016-09-15 12:04:18 --> Database Driver Class Initialized
INFO - 2016-09-15 12:04:18 --> Controller Class Initialized
DEBUG - 2016-09-15 12:04:18 --> Index MX_Controller Initialized
INFO - 2016-09-15 12:04:18 --> Model Class Initialized
INFO - 2016-09-15 12:04:18 --> Model Class Initialized
DEBUG - 2016-09-15 12:04:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 12:04:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 12:04:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 12:04:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_peminjam.php
DEBUG - 2016-09-15 12:04:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 12:04:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 12:04:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 12:04:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 12:04:18 --> Final output sent to browser
DEBUG - 2016-09-15 12:04:18 --> Total execution time: 0.6764
INFO - 2016-09-15 12:04:21 --> Config Class Initialized
INFO - 2016-09-15 12:04:21 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:04:21 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:04:21 --> Utf8 Class Initialized
INFO - 2016-09-15 12:04:21 --> URI Class Initialized
INFO - 2016-09-15 12:04:21 --> Router Class Initialized
INFO - 2016-09-15 12:04:21 --> Output Class Initialized
INFO - 2016-09-15 12:04:21 --> Security Class Initialized
DEBUG - 2016-09-15 12:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:04:21 --> Input Class Initialized
INFO - 2016-09-15 12:04:21 --> Language Class Initialized
INFO - 2016-09-15 12:04:21 --> Language Class Initialized
INFO - 2016-09-15 12:04:21 --> Config Class Initialized
INFO - 2016-09-15 12:04:21 --> Loader Class Initialized
INFO - 2016-09-15 12:04:22 --> Helper loaded: url_helper
INFO - 2016-09-15 12:04:22 --> Database Driver Class Initialized
INFO - 2016-09-15 12:04:22 --> Controller Class Initialized
DEBUG - 2016-09-15 12:04:22 --> Index MX_Controller Initialized
INFO - 2016-09-15 12:04:22 --> Model Class Initialized
INFO - 2016-09-15 12:04:22 --> Model Class Initialized
DEBUG - 2016-09-15 12:04:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 12:04:22 --> Final output sent to browser
DEBUG - 2016-09-15 12:04:22 --> Total execution time: 0.4996
INFO - 2016-09-15 12:04:23 --> Config Class Initialized
INFO - 2016-09-15 12:04:23 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:04:23 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:04:23 --> Utf8 Class Initialized
INFO - 2016-09-15 12:04:23 --> URI Class Initialized
INFO - 2016-09-15 12:04:23 --> Router Class Initialized
INFO - 2016-09-15 12:04:23 --> Output Class Initialized
INFO - 2016-09-15 12:04:23 --> Security Class Initialized
DEBUG - 2016-09-15 12:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:04:23 --> Input Class Initialized
INFO - 2016-09-15 12:04:23 --> Language Class Initialized
INFO - 2016-09-15 12:04:23 --> Language Class Initialized
INFO - 2016-09-15 12:04:23 --> Config Class Initialized
INFO - 2016-09-15 12:04:23 --> Loader Class Initialized
INFO - 2016-09-15 12:04:23 --> Helper loaded: url_helper
INFO - 2016-09-15 12:04:23 --> Database Driver Class Initialized
INFO - 2016-09-15 12:04:23 --> Controller Class Initialized
DEBUG - 2016-09-15 12:04:23 --> Index MX_Controller Initialized
INFO - 2016-09-15 12:04:23 --> Model Class Initialized
INFO - 2016-09-15 12:04:24 --> Model Class Initialized
DEBUG - 2016-09-15 12:04:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 12:04:24 --> Final output sent to browser
DEBUG - 2016-09-15 12:04:24 --> Total execution time: 0.5128
INFO - 2016-09-15 12:04:25 --> Config Class Initialized
INFO - 2016-09-15 12:04:25 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:04:25 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:04:25 --> Utf8 Class Initialized
INFO - 2016-09-15 12:04:25 --> URI Class Initialized
INFO - 2016-09-15 12:04:25 --> Router Class Initialized
INFO - 2016-09-15 12:04:25 --> Output Class Initialized
INFO - 2016-09-15 12:04:25 --> Security Class Initialized
DEBUG - 2016-09-15 12:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:04:25 --> Input Class Initialized
INFO - 2016-09-15 12:04:25 --> Language Class Initialized
INFO - 2016-09-15 12:04:25 --> Language Class Initialized
INFO - 2016-09-15 12:04:25 --> Config Class Initialized
INFO - 2016-09-15 12:04:25 --> Loader Class Initialized
INFO - 2016-09-15 12:04:25 --> Helper loaded: url_helper
INFO - 2016-09-15 12:04:25 --> Database Driver Class Initialized
INFO - 2016-09-15 12:04:25 --> Controller Class Initialized
DEBUG - 2016-09-15 12:04:25 --> Index MX_Controller Initialized
INFO - 2016-09-15 12:04:25 --> Model Class Initialized
INFO - 2016-09-15 12:04:25 --> Model Class Initialized
DEBUG - 2016-09-15 12:04:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 12:04:25 --> Final output sent to browser
DEBUG - 2016-09-15 12:04:25 --> Total execution time: 0.5203
INFO - 2016-09-15 12:04:26 --> Config Class Initialized
INFO - 2016-09-15 12:04:26 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:04:26 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:04:26 --> Utf8 Class Initialized
INFO - 2016-09-15 12:04:26 --> URI Class Initialized
INFO - 2016-09-15 12:04:27 --> Router Class Initialized
INFO - 2016-09-15 12:04:27 --> Output Class Initialized
INFO - 2016-09-15 12:04:27 --> Security Class Initialized
DEBUG - 2016-09-15 12:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:04:27 --> Input Class Initialized
INFO - 2016-09-15 12:04:27 --> Language Class Initialized
INFO - 2016-09-15 12:04:27 --> Language Class Initialized
INFO - 2016-09-15 12:04:27 --> Config Class Initialized
INFO - 2016-09-15 12:04:27 --> Loader Class Initialized
INFO - 2016-09-15 12:04:27 --> Helper loaded: url_helper
INFO - 2016-09-15 12:04:27 --> Database Driver Class Initialized
INFO - 2016-09-15 12:04:27 --> Controller Class Initialized
DEBUG - 2016-09-15 12:04:27 --> Index MX_Controller Initialized
INFO - 2016-09-15 12:04:27 --> Model Class Initialized
INFO - 2016-09-15 12:04:27 --> Model Class Initialized
DEBUG - 2016-09-15 12:04:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 12:04:27 --> Final output sent to browser
DEBUG - 2016-09-15 12:04:27 --> Total execution time: 0.5056
INFO - 2016-09-15 12:05:10 --> Config Class Initialized
INFO - 2016-09-15 12:05:10 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:05:10 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:05:10 --> Utf8 Class Initialized
INFO - 2016-09-15 12:05:10 --> URI Class Initialized
INFO - 2016-09-15 12:05:10 --> Router Class Initialized
INFO - 2016-09-15 12:05:10 --> Output Class Initialized
INFO - 2016-09-15 12:05:10 --> Security Class Initialized
DEBUG - 2016-09-15 12:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:05:10 --> Input Class Initialized
INFO - 2016-09-15 12:05:10 --> Language Class Initialized
INFO - 2016-09-15 12:05:10 --> Language Class Initialized
INFO - 2016-09-15 12:05:10 --> Config Class Initialized
INFO - 2016-09-15 12:05:10 --> Loader Class Initialized
INFO - 2016-09-15 12:05:10 --> Helper loaded: url_helper
INFO - 2016-09-15 12:05:10 --> Database Driver Class Initialized
INFO - 2016-09-15 12:05:11 --> Controller Class Initialized
DEBUG - 2016-09-15 12:05:11 --> Index MX_Controller Initialized
INFO - 2016-09-15 12:05:11 --> Model Class Initialized
INFO - 2016-09-15 12:05:11 --> Model Class Initialized
DEBUG - 2016-09-15 12:05:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 12:05:11 --> Final output sent to browser
DEBUG - 2016-09-15 12:05:11 --> Total execution time: 0.5306
INFO - 2016-09-15 12:05:15 --> Config Class Initialized
INFO - 2016-09-15 12:05:15 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:05:15 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:05:15 --> Utf8 Class Initialized
INFO - 2016-09-15 12:05:15 --> URI Class Initialized
INFO - 2016-09-15 12:05:15 --> Router Class Initialized
INFO - 2016-09-15 12:05:15 --> Output Class Initialized
INFO - 2016-09-15 12:05:15 --> Security Class Initialized
DEBUG - 2016-09-15 12:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:05:15 --> Input Class Initialized
INFO - 2016-09-15 12:05:15 --> Language Class Initialized
INFO - 2016-09-15 12:05:15 --> Language Class Initialized
INFO - 2016-09-15 12:05:15 --> Config Class Initialized
INFO - 2016-09-15 12:05:15 --> Loader Class Initialized
INFO - 2016-09-15 12:05:16 --> Helper loaded: url_helper
INFO - 2016-09-15 12:05:16 --> Database Driver Class Initialized
INFO - 2016-09-15 12:05:16 --> Controller Class Initialized
DEBUG - 2016-09-15 12:05:16 --> Index MX_Controller Initialized
INFO - 2016-09-15 12:05:16 --> Model Class Initialized
INFO - 2016-09-15 12:05:16 --> Model Class Initialized
DEBUG - 2016-09-15 12:05:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 12:05:16 --> Final output sent to browser
DEBUG - 2016-09-15 12:05:16 --> Total execution time: 0.5137
INFO - 2016-09-15 12:05:16 --> Config Class Initialized
INFO - 2016-09-15 12:05:16 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:05:16 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:05:16 --> Utf8 Class Initialized
INFO - 2016-09-15 12:05:16 --> URI Class Initialized
INFO - 2016-09-15 12:05:17 --> Router Class Initialized
INFO - 2016-09-15 12:05:17 --> Output Class Initialized
INFO - 2016-09-15 12:05:17 --> Security Class Initialized
DEBUG - 2016-09-15 12:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:05:17 --> Input Class Initialized
INFO - 2016-09-15 12:05:17 --> Language Class Initialized
INFO - 2016-09-15 12:05:17 --> Language Class Initialized
INFO - 2016-09-15 12:05:17 --> Config Class Initialized
INFO - 2016-09-15 12:05:17 --> Loader Class Initialized
INFO - 2016-09-15 12:05:17 --> Helper loaded: url_helper
INFO - 2016-09-15 12:05:17 --> Database Driver Class Initialized
INFO - 2016-09-15 12:05:17 --> Controller Class Initialized
DEBUG - 2016-09-15 12:05:17 --> Index MX_Controller Initialized
INFO - 2016-09-15 12:05:17 --> Model Class Initialized
INFO - 2016-09-15 12:05:17 --> Model Class Initialized
DEBUG - 2016-09-15 12:05:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 12:05:17 --> Final output sent to browser
DEBUG - 2016-09-15 12:05:17 --> Total execution time: 0.5044
INFO - 2016-09-15 12:05:17 --> Config Class Initialized
INFO - 2016-09-15 12:05:17 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:05:17 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:05:17 --> Utf8 Class Initialized
INFO - 2016-09-15 12:05:17 --> URI Class Initialized
INFO - 2016-09-15 12:05:17 --> Router Class Initialized
INFO - 2016-09-15 12:05:17 --> Output Class Initialized
INFO - 2016-09-15 12:05:18 --> Security Class Initialized
DEBUG - 2016-09-15 12:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:05:18 --> Input Class Initialized
INFO - 2016-09-15 12:05:18 --> Language Class Initialized
INFO - 2016-09-15 12:05:18 --> Language Class Initialized
INFO - 2016-09-15 12:05:18 --> Config Class Initialized
INFO - 2016-09-15 12:05:18 --> Loader Class Initialized
INFO - 2016-09-15 12:05:18 --> Helper loaded: url_helper
INFO - 2016-09-15 12:05:18 --> Database Driver Class Initialized
INFO - 2016-09-15 12:05:18 --> Controller Class Initialized
DEBUG - 2016-09-15 12:05:18 --> Index MX_Controller Initialized
INFO - 2016-09-15 12:05:18 --> Model Class Initialized
INFO - 2016-09-15 12:05:18 --> Model Class Initialized
DEBUG - 2016-09-15 12:05:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 12:05:18 --> Final output sent to browser
DEBUG - 2016-09-15 12:05:18 --> Total execution time: 0.5185
INFO - 2016-09-15 12:06:04 --> Config Class Initialized
INFO - 2016-09-15 12:06:04 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:06:04 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:06:04 --> Utf8 Class Initialized
INFO - 2016-09-15 12:06:04 --> URI Class Initialized
INFO - 2016-09-15 12:06:04 --> Router Class Initialized
INFO - 2016-09-15 12:06:04 --> Output Class Initialized
INFO - 2016-09-15 12:06:04 --> Security Class Initialized
DEBUG - 2016-09-15 12:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:06:04 --> Input Class Initialized
INFO - 2016-09-15 12:06:04 --> Language Class Initialized
INFO - 2016-09-15 12:06:04 --> Language Class Initialized
INFO - 2016-09-15 12:06:04 --> Config Class Initialized
INFO - 2016-09-15 12:06:04 --> Loader Class Initialized
INFO - 2016-09-15 12:06:04 --> Helper loaded: url_helper
INFO - 2016-09-15 12:06:04 --> Database Driver Class Initialized
INFO - 2016-09-15 12:06:04 --> Controller Class Initialized
DEBUG - 2016-09-15 12:06:04 --> Index MX_Controller Initialized
INFO - 2016-09-15 12:06:04 --> Model Class Initialized
INFO - 2016-09-15 12:06:04 --> Model Class Initialized
DEBUG - 2016-09-15 12:06:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 12:06:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 12:06:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 12:06:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_peminjam.php
DEBUG - 2016-09-15 12:06:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 12:06:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 12:06:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 12:06:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 12:06:04 --> Final output sent to browser
DEBUG - 2016-09-15 12:06:05 --> Total execution time: 0.6987
INFO - 2016-09-15 12:06:08 --> Config Class Initialized
INFO - 2016-09-15 12:06:08 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:06:08 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:06:08 --> Utf8 Class Initialized
INFO - 2016-09-15 12:06:08 --> URI Class Initialized
INFO - 2016-09-15 12:06:08 --> Router Class Initialized
INFO - 2016-09-15 12:06:08 --> Output Class Initialized
INFO - 2016-09-15 12:06:08 --> Security Class Initialized
DEBUG - 2016-09-15 12:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:06:08 --> Input Class Initialized
INFO - 2016-09-15 12:06:08 --> Language Class Initialized
INFO - 2016-09-15 12:06:08 --> Language Class Initialized
INFO - 2016-09-15 12:06:08 --> Config Class Initialized
INFO - 2016-09-15 12:06:08 --> Loader Class Initialized
INFO - 2016-09-15 12:06:08 --> Helper loaded: url_helper
INFO - 2016-09-15 12:06:08 --> Database Driver Class Initialized
INFO - 2016-09-15 12:06:08 --> Controller Class Initialized
DEBUG - 2016-09-15 12:06:08 --> Index MX_Controller Initialized
INFO - 2016-09-15 12:06:08 --> Model Class Initialized
INFO - 2016-09-15 12:06:08 --> Model Class Initialized
DEBUG - 2016-09-15 12:06:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 12:06:08 --> Final output sent to browser
DEBUG - 2016-09-15 12:06:08 --> Total execution time: 0.5057
INFO - 2016-09-15 12:06:11 --> Config Class Initialized
INFO - 2016-09-15 12:06:11 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:06:11 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:06:11 --> Utf8 Class Initialized
INFO - 2016-09-15 12:06:12 --> URI Class Initialized
INFO - 2016-09-15 12:06:12 --> Router Class Initialized
INFO - 2016-09-15 12:06:12 --> Output Class Initialized
INFO - 2016-09-15 12:06:12 --> Security Class Initialized
DEBUG - 2016-09-15 12:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:06:12 --> Input Class Initialized
INFO - 2016-09-15 12:06:12 --> Language Class Initialized
INFO - 2016-09-15 12:06:12 --> Language Class Initialized
INFO - 2016-09-15 12:06:12 --> Config Class Initialized
INFO - 2016-09-15 12:06:12 --> Loader Class Initialized
INFO - 2016-09-15 12:06:12 --> Helper loaded: url_helper
INFO - 2016-09-15 12:06:12 --> Database Driver Class Initialized
INFO - 2016-09-15 12:06:12 --> Controller Class Initialized
DEBUG - 2016-09-15 12:06:12 --> Index MX_Controller Initialized
INFO - 2016-09-15 12:06:12 --> Model Class Initialized
INFO - 2016-09-15 12:06:12 --> Model Class Initialized
DEBUG - 2016-09-15 12:06:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 12:06:12 --> Final output sent to browser
DEBUG - 2016-09-15 12:06:12 --> Total execution time: 0.4953
INFO - 2016-09-15 12:06:14 --> Config Class Initialized
INFO - 2016-09-15 12:06:14 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:06:14 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:06:14 --> Utf8 Class Initialized
INFO - 2016-09-15 12:06:14 --> URI Class Initialized
INFO - 2016-09-15 12:06:14 --> Router Class Initialized
INFO - 2016-09-15 12:06:14 --> Output Class Initialized
INFO - 2016-09-15 12:06:14 --> Security Class Initialized
DEBUG - 2016-09-15 12:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:06:14 --> Input Class Initialized
INFO - 2016-09-15 12:06:14 --> Language Class Initialized
INFO - 2016-09-15 12:06:14 --> Language Class Initialized
INFO - 2016-09-15 12:06:14 --> Config Class Initialized
INFO - 2016-09-15 12:06:14 --> Loader Class Initialized
INFO - 2016-09-15 12:06:14 --> Helper loaded: url_helper
INFO - 2016-09-15 12:06:15 --> Database Driver Class Initialized
INFO - 2016-09-15 12:06:15 --> Controller Class Initialized
DEBUG - 2016-09-15 12:06:15 --> Index MX_Controller Initialized
INFO - 2016-09-15 12:06:15 --> Model Class Initialized
INFO - 2016-09-15 12:06:15 --> Model Class Initialized
DEBUG - 2016-09-15 12:06:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 12:06:15 --> Final output sent to browser
DEBUG - 2016-09-15 12:06:15 --> Total execution time: 0.5050
INFO - 2016-09-15 12:06:16 --> Config Class Initialized
INFO - 2016-09-15 12:06:16 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:06:16 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:06:16 --> Utf8 Class Initialized
INFO - 2016-09-15 12:06:16 --> URI Class Initialized
INFO - 2016-09-15 12:06:16 --> Router Class Initialized
INFO - 2016-09-15 12:06:16 --> Output Class Initialized
INFO - 2016-09-15 12:06:16 --> Security Class Initialized
DEBUG - 2016-09-15 12:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:06:16 --> Input Class Initialized
INFO - 2016-09-15 12:06:16 --> Language Class Initialized
INFO - 2016-09-15 12:06:16 --> Language Class Initialized
INFO - 2016-09-15 12:06:16 --> Config Class Initialized
INFO - 2016-09-15 12:06:16 --> Loader Class Initialized
INFO - 2016-09-15 12:06:16 --> Helper loaded: url_helper
INFO - 2016-09-15 12:06:16 --> Database Driver Class Initialized
INFO - 2016-09-15 12:06:16 --> Controller Class Initialized
DEBUG - 2016-09-15 12:06:16 --> Index MX_Controller Initialized
INFO - 2016-09-15 12:06:16 --> Model Class Initialized
INFO - 2016-09-15 12:06:16 --> Model Class Initialized
DEBUG - 2016-09-15 12:06:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 12:06:16 --> Final output sent to browser
DEBUG - 2016-09-15 12:06:16 --> Total execution time: 0.5748
INFO - 2016-09-15 12:06:18 --> Config Class Initialized
INFO - 2016-09-15 12:06:18 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:06:18 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:06:18 --> Utf8 Class Initialized
INFO - 2016-09-15 12:06:18 --> URI Class Initialized
INFO - 2016-09-15 12:06:18 --> Router Class Initialized
INFO - 2016-09-15 12:06:18 --> Output Class Initialized
INFO - 2016-09-15 12:06:18 --> Security Class Initialized
DEBUG - 2016-09-15 12:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:06:18 --> Input Class Initialized
INFO - 2016-09-15 12:06:19 --> Language Class Initialized
INFO - 2016-09-15 12:06:19 --> Language Class Initialized
INFO - 2016-09-15 12:06:19 --> Config Class Initialized
INFO - 2016-09-15 12:06:19 --> Loader Class Initialized
INFO - 2016-09-15 12:06:19 --> Helper loaded: url_helper
INFO - 2016-09-15 12:06:19 --> Database Driver Class Initialized
INFO - 2016-09-15 12:06:19 --> Controller Class Initialized
DEBUG - 2016-09-15 12:06:19 --> Index MX_Controller Initialized
INFO - 2016-09-15 12:06:19 --> Model Class Initialized
INFO - 2016-09-15 12:06:19 --> Model Class Initialized
DEBUG - 2016-09-15 12:06:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 12:06:19 --> Final output sent to browser
DEBUG - 2016-09-15 12:06:19 --> Total execution time: 0.5010
INFO - 2016-09-15 12:06:20 --> Config Class Initialized
INFO - 2016-09-15 12:06:20 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:06:20 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:06:20 --> Utf8 Class Initialized
INFO - 2016-09-15 12:06:20 --> URI Class Initialized
INFO - 2016-09-15 12:06:20 --> Router Class Initialized
INFO - 2016-09-15 12:06:20 --> Output Class Initialized
INFO - 2016-09-15 12:06:20 --> Security Class Initialized
DEBUG - 2016-09-15 12:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:06:20 --> Input Class Initialized
INFO - 2016-09-15 12:06:20 --> Language Class Initialized
INFO - 2016-09-15 12:06:20 --> Language Class Initialized
INFO - 2016-09-15 12:06:20 --> Config Class Initialized
INFO - 2016-09-15 12:06:20 --> Loader Class Initialized
INFO - 2016-09-15 12:06:20 --> Helper loaded: url_helper
INFO - 2016-09-15 12:06:20 --> Database Driver Class Initialized
INFO - 2016-09-15 12:06:20 --> Controller Class Initialized
DEBUG - 2016-09-15 12:06:20 --> Index MX_Controller Initialized
INFO - 2016-09-15 12:06:20 --> Model Class Initialized
INFO - 2016-09-15 12:06:20 --> Model Class Initialized
DEBUG - 2016-09-15 12:06:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 12:06:20 --> Final output sent to browser
DEBUG - 2016-09-15 12:06:20 --> Total execution time: 0.4949
INFO - 2016-09-15 12:06:21 --> Config Class Initialized
INFO - 2016-09-15 12:06:21 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:06:21 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:06:21 --> Utf8 Class Initialized
INFO - 2016-09-15 12:06:21 --> URI Class Initialized
INFO - 2016-09-15 12:06:21 --> Router Class Initialized
INFO - 2016-09-15 12:06:21 --> Output Class Initialized
INFO - 2016-09-15 12:06:21 --> Security Class Initialized
DEBUG - 2016-09-15 12:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:06:21 --> Input Class Initialized
INFO - 2016-09-15 12:06:21 --> Language Class Initialized
INFO - 2016-09-15 12:06:21 --> Language Class Initialized
INFO - 2016-09-15 12:06:21 --> Config Class Initialized
INFO - 2016-09-15 12:06:21 --> Loader Class Initialized
INFO - 2016-09-15 12:06:21 --> Helper loaded: url_helper
INFO - 2016-09-15 12:06:21 --> Database Driver Class Initialized
INFO - 2016-09-15 12:06:21 --> Controller Class Initialized
DEBUG - 2016-09-15 12:06:21 --> Index MX_Controller Initialized
INFO - 2016-09-15 12:06:21 --> Model Class Initialized
INFO - 2016-09-15 12:06:21 --> Model Class Initialized
DEBUG - 2016-09-15 12:06:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 12:06:21 --> Final output sent to browser
DEBUG - 2016-09-15 12:06:21 --> Total execution time: 0.4940
INFO - 2016-09-15 12:06:35 --> Config Class Initialized
INFO - 2016-09-15 12:06:35 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:06:35 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:06:35 --> Utf8 Class Initialized
INFO - 2016-09-15 12:06:35 --> URI Class Initialized
INFO - 2016-09-15 12:06:35 --> Router Class Initialized
INFO - 2016-09-15 12:06:35 --> Output Class Initialized
INFO - 2016-09-15 12:06:35 --> Security Class Initialized
DEBUG - 2016-09-15 12:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:06:35 --> Input Class Initialized
INFO - 2016-09-15 12:06:35 --> Language Class Initialized
INFO - 2016-09-15 12:06:35 --> Language Class Initialized
INFO - 2016-09-15 12:06:35 --> Config Class Initialized
INFO - 2016-09-15 12:06:35 --> Loader Class Initialized
INFO - 2016-09-15 12:06:35 --> Helper loaded: url_helper
INFO - 2016-09-15 12:06:35 --> Database Driver Class Initialized
INFO - 2016-09-15 12:06:36 --> Controller Class Initialized
DEBUG - 2016-09-15 12:06:36 --> Index MX_Controller Initialized
INFO - 2016-09-15 12:06:36 --> Model Class Initialized
INFO - 2016-09-15 12:06:36 --> Model Class Initialized
DEBUG - 2016-09-15 12:06:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 12:06:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 12:06:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 12:06:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_peminjam.php
DEBUG - 2016-09-15 12:06:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 12:06:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 12:06:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 12:06:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 12:06:36 --> Final output sent to browser
DEBUG - 2016-09-15 12:06:36 --> Total execution time: 0.7198
INFO - 2016-09-15 12:06:41 --> Config Class Initialized
INFO - 2016-09-15 12:06:41 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:06:41 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:06:41 --> Utf8 Class Initialized
INFO - 2016-09-15 12:06:41 --> URI Class Initialized
INFO - 2016-09-15 12:06:41 --> Router Class Initialized
INFO - 2016-09-15 12:06:41 --> Output Class Initialized
INFO - 2016-09-15 12:06:41 --> Security Class Initialized
DEBUG - 2016-09-15 12:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:06:41 --> Input Class Initialized
INFO - 2016-09-15 12:06:41 --> Language Class Initialized
INFO - 2016-09-15 12:06:41 --> Language Class Initialized
INFO - 2016-09-15 12:06:41 --> Config Class Initialized
INFO - 2016-09-15 12:06:41 --> Loader Class Initialized
INFO - 2016-09-15 12:06:41 --> Helper loaded: url_helper
INFO - 2016-09-15 12:06:41 --> Database Driver Class Initialized
INFO - 2016-09-15 12:06:41 --> Controller Class Initialized
DEBUG - 2016-09-15 12:06:41 --> Index MX_Controller Initialized
INFO - 2016-09-15 12:06:41 --> Model Class Initialized
INFO - 2016-09-15 12:06:41 --> Model Class Initialized
DEBUG - 2016-09-15 12:06:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 12:06:41 --> Final output sent to browser
DEBUG - 2016-09-15 12:06:41 --> Total execution time: 0.5019
INFO - 2016-09-15 12:06:44 --> Config Class Initialized
INFO - 2016-09-15 12:06:44 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:06:44 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:06:44 --> Utf8 Class Initialized
INFO - 2016-09-15 12:06:44 --> URI Class Initialized
INFO - 2016-09-15 12:06:44 --> Router Class Initialized
INFO - 2016-09-15 12:06:44 --> Output Class Initialized
INFO - 2016-09-15 12:06:44 --> Security Class Initialized
DEBUG - 2016-09-15 12:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:06:44 --> Input Class Initialized
INFO - 2016-09-15 12:06:44 --> Language Class Initialized
INFO - 2016-09-15 12:06:44 --> Language Class Initialized
INFO - 2016-09-15 12:06:44 --> Config Class Initialized
INFO - 2016-09-15 12:06:44 --> Loader Class Initialized
INFO - 2016-09-15 12:06:44 --> Helper loaded: url_helper
INFO - 2016-09-15 12:06:44 --> Database Driver Class Initialized
INFO - 2016-09-15 12:06:44 --> Controller Class Initialized
DEBUG - 2016-09-15 12:06:44 --> Index MX_Controller Initialized
INFO - 2016-09-15 12:06:44 --> Model Class Initialized
INFO - 2016-09-15 12:06:44 --> Model Class Initialized
DEBUG - 2016-09-15 12:06:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 12:06:45 --> Final output sent to browser
DEBUG - 2016-09-15 12:06:45 --> Total execution time: 0.5670
INFO - 2016-09-15 12:13:05 --> Config Class Initialized
INFO - 2016-09-15 12:13:05 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:13:05 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:13:05 --> Utf8 Class Initialized
INFO - 2016-09-15 12:13:05 --> URI Class Initialized
INFO - 2016-09-15 12:13:05 --> Router Class Initialized
INFO - 2016-09-15 12:13:05 --> Output Class Initialized
INFO - 2016-09-15 12:13:05 --> Security Class Initialized
DEBUG - 2016-09-15 12:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:13:05 --> Input Class Initialized
INFO - 2016-09-15 12:13:05 --> Language Class Initialized
INFO - 2016-09-15 12:13:05 --> Language Class Initialized
INFO - 2016-09-15 12:13:05 --> Config Class Initialized
INFO - 2016-09-15 12:13:05 --> Loader Class Initialized
INFO - 2016-09-15 12:13:05 --> Helper loaded: url_helper
INFO - 2016-09-15 12:13:05 --> Database Driver Class Initialized
INFO - 2016-09-15 12:13:05 --> Controller Class Initialized
DEBUG - 2016-09-15 12:13:05 --> Index MX_Controller Initialized
INFO - 2016-09-15 12:13:05 --> Model Class Initialized
INFO - 2016-09-15 12:13:05 --> Model Class Initialized
DEBUG - 2016-09-15 12:13:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 12:13:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 12:13:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 12:13:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_peminjam.php
DEBUG - 2016-09-15 12:13:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 12:13:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 12:13:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 12:13:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 12:13:05 --> Final output sent to browser
DEBUG - 2016-09-15 12:13:05 --> Total execution time: 0.8402
INFO - 2016-09-15 12:13:07 --> Config Class Initialized
INFO - 2016-09-15 12:13:07 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:13:07 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:13:07 --> Utf8 Class Initialized
INFO - 2016-09-15 12:13:07 --> URI Class Initialized
INFO - 2016-09-15 12:13:07 --> Router Class Initialized
INFO - 2016-09-15 12:13:07 --> Output Class Initialized
INFO - 2016-09-15 12:13:07 --> Security Class Initialized
DEBUG - 2016-09-15 12:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:13:07 --> Input Class Initialized
INFO - 2016-09-15 12:13:08 --> Language Class Initialized
INFO - 2016-09-15 12:13:08 --> Language Class Initialized
INFO - 2016-09-15 12:13:08 --> Config Class Initialized
INFO - 2016-09-15 12:13:08 --> Loader Class Initialized
INFO - 2016-09-15 12:13:08 --> Helper loaded: url_helper
INFO - 2016-09-15 12:13:08 --> Database Driver Class Initialized
INFO - 2016-09-15 12:13:08 --> Controller Class Initialized
DEBUG - 2016-09-15 12:13:08 --> Index MX_Controller Initialized
INFO - 2016-09-15 12:13:08 --> Model Class Initialized
INFO - 2016-09-15 12:13:08 --> Model Class Initialized
DEBUG - 2016-09-15 12:13:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 12:13:08 --> Final output sent to browser
DEBUG - 2016-09-15 12:13:08 --> Total execution time: 0.7171
INFO - 2016-09-15 12:13:09 --> Config Class Initialized
INFO - 2016-09-15 12:13:09 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:13:09 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:13:09 --> Utf8 Class Initialized
INFO - 2016-09-15 12:13:09 --> URI Class Initialized
INFO - 2016-09-15 12:13:09 --> Router Class Initialized
INFO - 2016-09-15 12:13:09 --> Output Class Initialized
INFO - 2016-09-15 12:13:09 --> Security Class Initialized
DEBUG - 2016-09-15 12:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:13:09 --> Input Class Initialized
INFO - 2016-09-15 12:13:09 --> Language Class Initialized
INFO - 2016-09-15 12:13:09 --> Language Class Initialized
INFO - 2016-09-15 12:13:09 --> Config Class Initialized
INFO - 2016-09-15 12:13:09 --> Loader Class Initialized
INFO - 2016-09-15 12:13:09 --> Helper loaded: url_helper
INFO - 2016-09-15 12:13:10 --> Database Driver Class Initialized
INFO - 2016-09-15 12:13:10 --> Controller Class Initialized
DEBUG - 2016-09-15 12:13:10 --> Index MX_Controller Initialized
INFO - 2016-09-15 12:13:10 --> Model Class Initialized
INFO - 2016-09-15 12:13:10 --> Model Class Initialized
DEBUG - 2016-09-15 12:13:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 12:13:10 --> Final output sent to browser
DEBUG - 2016-09-15 12:13:10 --> Total execution time: 0.5691
INFO - 2016-09-15 12:13:11 --> Config Class Initialized
INFO - 2016-09-15 12:13:11 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:13:11 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:13:11 --> Utf8 Class Initialized
INFO - 2016-09-15 12:13:11 --> URI Class Initialized
INFO - 2016-09-15 12:13:11 --> Router Class Initialized
INFO - 2016-09-15 12:13:11 --> Output Class Initialized
INFO - 2016-09-15 12:13:11 --> Security Class Initialized
DEBUG - 2016-09-15 12:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:13:11 --> Input Class Initialized
INFO - 2016-09-15 12:13:11 --> Language Class Initialized
INFO - 2016-09-15 12:13:11 --> Language Class Initialized
INFO - 2016-09-15 12:13:11 --> Config Class Initialized
INFO - 2016-09-15 12:13:11 --> Loader Class Initialized
INFO - 2016-09-15 12:13:11 --> Helper loaded: url_helper
INFO - 2016-09-15 12:13:11 --> Database Driver Class Initialized
INFO - 2016-09-15 12:13:11 --> Controller Class Initialized
DEBUG - 2016-09-15 12:13:11 --> Index MX_Controller Initialized
INFO - 2016-09-15 12:13:11 --> Model Class Initialized
INFO - 2016-09-15 12:13:11 --> Model Class Initialized
DEBUG - 2016-09-15 12:13:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 12:13:11 --> Final output sent to browser
DEBUG - 2016-09-15 12:13:11 --> Total execution time: 0.5840
INFO - 2016-09-15 12:13:13 --> Config Class Initialized
INFO - 2016-09-15 12:13:13 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:13:13 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:13:13 --> Utf8 Class Initialized
INFO - 2016-09-15 12:13:13 --> URI Class Initialized
INFO - 2016-09-15 12:13:13 --> Router Class Initialized
INFO - 2016-09-15 12:13:13 --> Output Class Initialized
INFO - 2016-09-15 12:13:13 --> Security Class Initialized
DEBUG - 2016-09-15 12:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:13:13 --> Input Class Initialized
INFO - 2016-09-15 12:13:13 --> Language Class Initialized
INFO - 2016-09-15 12:13:13 --> Language Class Initialized
INFO - 2016-09-15 12:13:13 --> Config Class Initialized
INFO - 2016-09-15 12:13:13 --> Loader Class Initialized
INFO - 2016-09-15 12:13:13 --> Helper loaded: url_helper
INFO - 2016-09-15 12:13:13 --> Database Driver Class Initialized
INFO - 2016-09-15 12:13:13 --> Controller Class Initialized
DEBUG - 2016-09-15 12:13:13 --> Index MX_Controller Initialized
INFO - 2016-09-15 12:13:13 --> Model Class Initialized
INFO - 2016-09-15 12:13:13 --> Model Class Initialized
DEBUG - 2016-09-15 12:13:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 12:13:13 --> Final output sent to browser
DEBUG - 2016-09-15 12:13:13 --> Total execution time: 0.5372
INFO - 2016-09-15 12:13:16 --> Config Class Initialized
INFO - 2016-09-15 12:13:16 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:13:16 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:13:16 --> Utf8 Class Initialized
INFO - 2016-09-15 12:13:16 --> URI Class Initialized
INFO - 2016-09-15 12:13:16 --> Router Class Initialized
INFO - 2016-09-15 12:13:16 --> Output Class Initialized
INFO - 2016-09-15 12:13:16 --> Security Class Initialized
DEBUG - 2016-09-15 12:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:13:16 --> Input Class Initialized
INFO - 2016-09-15 12:13:16 --> Language Class Initialized
INFO - 2016-09-15 12:13:16 --> Language Class Initialized
INFO - 2016-09-15 12:13:16 --> Config Class Initialized
INFO - 2016-09-15 12:13:16 --> Loader Class Initialized
INFO - 2016-09-15 12:13:16 --> Helper loaded: url_helper
INFO - 2016-09-15 12:13:16 --> Database Driver Class Initialized
INFO - 2016-09-15 12:13:16 --> Controller Class Initialized
DEBUG - 2016-09-15 12:13:17 --> Index MX_Controller Initialized
INFO - 2016-09-15 12:13:17 --> Model Class Initialized
INFO - 2016-09-15 12:13:17 --> Model Class Initialized
DEBUG - 2016-09-15 12:13:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 12:13:17 --> Final output sent to browser
DEBUG - 2016-09-15 12:13:17 --> Total execution time: 0.5281
INFO - 2016-09-15 12:13:17 --> Config Class Initialized
INFO - 2016-09-15 12:13:17 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:13:17 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:13:17 --> Utf8 Class Initialized
INFO - 2016-09-15 12:13:17 --> URI Class Initialized
INFO - 2016-09-15 12:13:17 --> Router Class Initialized
INFO - 2016-09-15 12:13:17 --> Output Class Initialized
INFO - 2016-09-15 12:13:17 --> Security Class Initialized
DEBUG - 2016-09-15 12:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:13:17 --> Input Class Initialized
INFO - 2016-09-15 12:13:17 --> Language Class Initialized
INFO - 2016-09-15 12:13:17 --> Language Class Initialized
INFO - 2016-09-15 12:13:17 --> Config Class Initialized
INFO - 2016-09-15 12:13:18 --> Loader Class Initialized
INFO - 2016-09-15 12:13:18 --> Helper loaded: url_helper
INFO - 2016-09-15 12:13:18 --> Database Driver Class Initialized
INFO - 2016-09-15 12:13:18 --> Controller Class Initialized
DEBUG - 2016-09-15 12:13:18 --> Index MX_Controller Initialized
INFO - 2016-09-15 12:13:18 --> Model Class Initialized
INFO - 2016-09-15 12:13:18 --> Model Class Initialized
DEBUG - 2016-09-15 12:13:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 12:13:18 --> Final output sent to browser
DEBUG - 2016-09-15 12:13:18 --> Total execution time: 0.5235
INFO - 2016-09-15 13:10:21 --> Config Class Initialized
INFO - 2016-09-15 13:10:21 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:10:21 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:10:21 --> Utf8 Class Initialized
INFO - 2016-09-15 13:10:21 --> URI Class Initialized
INFO - 2016-09-15 13:10:21 --> Router Class Initialized
INFO - 2016-09-15 13:10:21 --> Output Class Initialized
INFO - 2016-09-15 13:10:22 --> Security Class Initialized
DEBUG - 2016-09-15 13:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:10:22 --> Input Class Initialized
INFO - 2016-09-15 13:10:22 --> Language Class Initialized
INFO - 2016-09-15 13:10:22 --> Language Class Initialized
INFO - 2016-09-15 13:10:22 --> Config Class Initialized
INFO - 2016-09-15 13:10:22 --> Loader Class Initialized
INFO - 2016-09-15 13:10:22 --> Helper loaded: url_helper
INFO - 2016-09-15 13:10:22 --> Database Driver Class Initialized
INFO - 2016-09-15 13:10:22 --> Controller Class Initialized
DEBUG - 2016-09-15 13:10:22 --> Index MX_Controller Initialized
INFO - 2016-09-15 13:10:22 --> Model Class Initialized
INFO - 2016-09-15 13:10:22 --> Model Class Initialized
DEBUG - 2016-09-15 13:10:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 13:10:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 13:10:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 13:10:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-15 13:10:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 13:10:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 13:10:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 13:10:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 13:10:22 --> Final output sent to browser
DEBUG - 2016-09-15 13:10:22 --> Total execution time: 0.7601
INFO - 2016-09-15 13:10:27 --> Config Class Initialized
INFO - 2016-09-15 13:10:27 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:10:27 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:10:27 --> Utf8 Class Initialized
INFO - 2016-09-15 13:10:27 --> URI Class Initialized
INFO - 2016-09-15 13:10:27 --> Router Class Initialized
INFO - 2016-09-15 13:10:27 --> Output Class Initialized
INFO - 2016-09-15 13:10:27 --> Security Class Initialized
DEBUG - 2016-09-15 13:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:10:27 --> Input Class Initialized
INFO - 2016-09-15 13:10:27 --> Language Class Initialized
INFO - 2016-09-15 13:10:27 --> Language Class Initialized
INFO - 2016-09-15 13:10:27 --> Config Class Initialized
INFO - 2016-09-15 13:10:27 --> Loader Class Initialized
INFO - 2016-09-15 13:10:27 --> Helper loaded: url_helper
INFO - 2016-09-15 13:10:27 --> Database Driver Class Initialized
INFO - 2016-09-15 13:10:27 --> Controller Class Initialized
DEBUG - 2016-09-15 13:10:27 --> Index MX_Controller Initialized
INFO - 2016-09-15 13:10:27 --> Model Class Initialized
INFO - 2016-09-15 13:10:27 --> Model Class Initialized
DEBUG - 2016-09-15 13:10:27 --> Anggota MX_Controller Initialized
INFO - 2016-09-15 13:10:27 --> Database Driver Class Initialized
INFO - 2016-09-15 13:10:27 --> Final output sent to browser
DEBUG - 2016-09-15 13:10:27 --> Total execution time: 0.5726
INFO - 2016-09-15 13:10:37 --> Config Class Initialized
INFO - 2016-09-15 13:10:37 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:10:37 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:10:37 --> Utf8 Class Initialized
INFO - 2016-09-15 13:10:37 --> URI Class Initialized
INFO - 2016-09-15 13:10:37 --> Router Class Initialized
INFO - 2016-09-15 13:10:37 --> Output Class Initialized
INFO - 2016-09-15 13:10:37 --> Security Class Initialized
DEBUG - 2016-09-15 13:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:10:37 --> Input Class Initialized
INFO - 2016-09-15 13:10:37 --> Language Class Initialized
INFO - 2016-09-15 13:10:37 --> Language Class Initialized
INFO - 2016-09-15 13:10:37 --> Config Class Initialized
INFO - 2016-09-15 13:10:37 --> Loader Class Initialized
INFO - 2016-09-15 13:10:37 --> Helper loaded: url_helper
INFO - 2016-09-15 13:10:37 --> Database Driver Class Initialized
INFO - 2016-09-15 13:10:37 --> Controller Class Initialized
DEBUG - 2016-09-15 13:10:37 --> Index MX_Controller Initialized
INFO - 2016-09-15 13:10:37 --> Model Class Initialized
INFO - 2016-09-15 13:10:38 --> Model Class Initialized
DEBUG - 2016-09-15 13:10:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 13:10:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 13:10:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 13:10:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-15 13:10:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 13:10:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 13:10:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 13:10:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 13:10:38 --> Final output sent to browser
DEBUG - 2016-09-15 13:10:38 --> Total execution time: 0.7343
INFO - 2016-09-15 13:10:46 --> Config Class Initialized
INFO - 2016-09-15 13:10:46 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:10:46 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:10:46 --> Utf8 Class Initialized
INFO - 2016-09-15 13:10:46 --> URI Class Initialized
INFO - 2016-09-15 13:10:46 --> Router Class Initialized
INFO - 2016-09-15 13:10:46 --> Output Class Initialized
INFO - 2016-09-15 13:10:46 --> Security Class Initialized
DEBUG - 2016-09-15 13:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:10:46 --> Input Class Initialized
INFO - 2016-09-15 13:10:46 --> Language Class Initialized
INFO - 2016-09-15 13:10:46 --> Language Class Initialized
INFO - 2016-09-15 13:10:46 --> Config Class Initialized
INFO - 2016-09-15 13:10:46 --> Loader Class Initialized
INFO - 2016-09-15 13:10:46 --> Helper loaded: url_helper
INFO - 2016-09-15 13:10:46 --> Database Driver Class Initialized
INFO - 2016-09-15 13:10:46 --> Controller Class Initialized
DEBUG - 2016-09-15 13:10:46 --> Index MX_Controller Initialized
INFO - 2016-09-15 13:10:46 --> Model Class Initialized
INFO - 2016-09-15 13:10:46 --> Model Class Initialized
DEBUG - 2016-09-15 13:10:46 --> Anggota MX_Controller Initialized
INFO - 2016-09-15 13:10:46 --> Database Driver Class Initialized
INFO - 2016-09-15 13:10:47 --> Final output sent to browser
DEBUG - 2016-09-15 13:10:47 --> Total execution time: 0.5980
INFO - 2016-09-15 13:10:59 --> Config Class Initialized
INFO - 2016-09-15 13:10:59 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:10:59 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:10:59 --> Utf8 Class Initialized
INFO - 2016-09-15 13:10:59 --> URI Class Initialized
INFO - 2016-09-15 13:10:59 --> Router Class Initialized
INFO - 2016-09-15 13:10:59 --> Output Class Initialized
INFO - 2016-09-15 13:10:59 --> Security Class Initialized
DEBUG - 2016-09-15 13:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:10:59 --> Input Class Initialized
INFO - 2016-09-15 13:10:59 --> Language Class Initialized
INFO - 2016-09-15 13:10:59 --> Language Class Initialized
INFO - 2016-09-15 13:10:59 --> Config Class Initialized
INFO - 2016-09-15 13:10:59 --> Loader Class Initialized
INFO - 2016-09-15 13:10:59 --> Helper loaded: url_helper
INFO - 2016-09-15 13:10:59 --> Database Driver Class Initialized
INFO - 2016-09-15 13:10:59 --> Controller Class Initialized
DEBUG - 2016-09-15 13:10:59 --> Index MX_Controller Initialized
INFO - 2016-09-15 13:10:59 --> Model Class Initialized
INFO - 2016-09-15 13:10:59 --> Model Class Initialized
DEBUG - 2016-09-15 13:10:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 13:10:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 13:10:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 13:11:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-09-15 13:11:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 13:11:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 13:11:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 13:11:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 13:11:00 --> Final output sent to browser
DEBUG - 2016-09-15 13:11:00 --> Total execution time: 0.8286
INFO - 2016-09-15 13:11:16 --> Config Class Initialized
INFO - 2016-09-15 13:11:16 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:11:16 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:11:16 --> Utf8 Class Initialized
INFO - 2016-09-15 13:11:16 --> URI Class Initialized
INFO - 2016-09-15 13:11:16 --> Router Class Initialized
INFO - 2016-09-15 13:11:16 --> Output Class Initialized
INFO - 2016-09-15 13:11:16 --> Security Class Initialized
DEBUG - 2016-09-15 13:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:11:17 --> Input Class Initialized
INFO - 2016-09-15 13:11:17 --> Language Class Initialized
INFO - 2016-09-15 13:11:17 --> Language Class Initialized
INFO - 2016-09-15 13:11:17 --> Config Class Initialized
INFO - 2016-09-15 13:11:17 --> Loader Class Initialized
INFO - 2016-09-15 13:11:17 --> Helper loaded: url_helper
INFO - 2016-09-15 13:11:17 --> Database Driver Class Initialized
INFO - 2016-09-15 13:11:17 --> Controller Class Initialized
DEBUG - 2016-09-15 13:11:17 --> Index MX_Controller Initialized
INFO - 2016-09-15 13:11:17 --> Model Class Initialized
INFO - 2016-09-15 13:11:17 --> Model Class Initialized
INFO - 2016-09-15 13:11:17 --> Database Driver Class Initialized
INFO - 2016-09-15 13:11:17 --> Final output sent to browser
DEBUG - 2016-09-15 13:11:17 --> Total execution time: 0.6879
INFO - 2016-09-15 13:12:17 --> Config Class Initialized
INFO - 2016-09-15 13:12:17 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:12:17 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:12:17 --> Utf8 Class Initialized
INFO - 2016-09-15 13:12:17 --> URI Class Initialized
INFO - 2016-09-15 13:12:17 --> Router Class Initialized
INFO - 2016-09-15 13:12:17 --> Output Class Initialized
INFO - 2016-09-15 13:12:17 --> Security Class Initialized
DEBUG - 2016-09-15 13:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:12:17 --> Input Class Initialized
INFO - 2016-09-15 13:12:17 --> Language Class Initialized
INFO - 2016-09-15 13:12:17 --> Language Class Initialized
INFO - 2016-09-15 13:12:17 --> Config Class Initialized
INFO - 2016-09-15 13:12:17 --> Loader Class Initialized
INFO - 2016-09-15 13:12:18 --> Helper loaded: url_helper
INFO - 2016-09-15 13:12:18 --> Database Driver Class Initialized
INFO - 2016-09-15 13:12:18 --> Controller Class Initialized
DEBUG - 2016-09-15 13:12:18 --> Index MX_Controller Initialized
INFO - 2016-09-15 13:12:18 --> Model Class Initialized
INFO - 2016-09-15 13:12:18 --> Model Class Initialized
INFO - 2016-09-15 13:12:18 --> Final output sent to browser
DEBUG - 2016-09-15 13:12:18 --> Total execution time: 0.5502
INFO - 2016-09-15 13:12:18 --> Config Class Initialized
INFO - 2016-09-15 13:12:18 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:12:18 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:12:18 --> Utf8 Class Initialized
INFO - 2016-09-15 13:12:18 --> URI Class Initialized
INFO - 2016-09-15 13:12:18 --> Router Class Initialized
INFO - 2016-09-15 13:12:18 --> Output Class Initialized
INFO - 2016-09-15 13:12:18 --> Security Class Initialized
DEBUG - 2016-09-15 13:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:12:18 --> Input Class Initialized
INFO - 2016-09-15 13:12:18 --> Language Class Initialized
INFO - 2016-09-15 13:12:18 --> Language Class Initialized
INFO - 2016-09-15 13:12:18 --> Config Class Initialized
INFO - 2016-09-15 13:12:18 --> Loader Class Initialized
INFO - 2016-09-15 13:12:18 --> Helper loaded: url_helper
INFO - 2016-09-15 13:12:18 --> Database Driver Class Initialized
INFO - 2016-09-15 13:12:18 --> Controller Class Initialized
DEBUG - 2016-09-15 13:12:18 --> Index MX_Controller Initialized
INFO - 2016-09-15 13:12:18 --> Model Class Initialized
INFO - 2016-09-15 13:12:18 --> Model Class Initialized
DEBUG - 2016-09-15 13:12:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 13:12:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 13:12:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 13:12:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-15 13:12:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 13:12:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 13:12:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 13:12:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 13:12:18 --> Final output sent to browser
DEBUG - 2016-09-15 13:12:19 --> Total execution time: 0.7351
INFO - 2016-09-15 13:12:24 --> Config Class Initialized
INFO - 2016-09-15 13:12:24 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:12:24 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:12:24 --> Utf8 Class Initialized
INFO - 2016-09-15 13:12:24 --> URI Class Initialized
INFO - 2016-09-15 13:12:24 --> Router Class Initialized
INFO - 2016-09-15 13:12:24 --> Output Class Initialized
INFO - 2016-09-15 13:12:24 --> Security Class Initialized
DEBUG - 2016-09-15 13:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:12:24 --> Input Class Initialized
INFO - 2016-09-15 13:12:24 --> Language Class Initialized
INFO - 2016-09-15 13:12:24 --> Language Class Initialized
INFO - 2016-09-15 13:12:25 --> Config Class Initialized
INFO - 2016-09-15 13:12:25 --> Loader Class Initialized
INFO - 2016-09-15 13:12:25 --> Helper loaded: url_helper
INFO - 2016-09-15 13:12:25 --> Database Driver Class Initialized
INFO - 2016-09-15 13:12:25 --> Controller Class Initialized
DEBUG - 2016-09-15 13:12:25 --> Index MX_Controller Initialized
INFO - 2016-09-15 13:12:25 --> Model Class Initialized
INFO - 2016-09-15 13:12:25 --> Model Class Initialized
DEBUG - 2016-09-15 13:12:25 --> Anggota MX_Controller Initialized
INFO - 2016-09-15 13:12:25 --> Database Driver Class Initialized
INFO - 2016-09-15 13:12:25 --> Final output sent to browser
DEBUG - 2016-09-15 13:12:25 --> Total execution time: 0.6422
INFO - 2016-09-15 13:12:26 --> Config Class Initialized
INFO - 2016-09-15 13:12:26 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:12:26 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:12:26 --> Utf8 Class Initialized
INFO - 2016-09-15 13:12:26 --> URI Class Initialized
INFO - 2016-09-15 13:12:26 --> Router Class Initialized
INFO - 2016-09-15 13:12:26 --> Output Class Initialized
INFO - 2016-09-15 13:12:26 --> Security Class Initialized
DEBUG - 2016-09-15 13:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:12:26 --> Input Class Initialized
INFO - 2016-09-15 13:12:26 --> Language Class Initialized
INFO - 2016-09-15 13:12:27 --> Language Class Initialized
INFO - 2016-09-15 13:12:27 --> Config Class Initialized
INFO - 2016-09-15 13:12:27 --> Loader Class Initialized
INFO - 2016-09-15 13:12:27 --> Helper loaded: url_helper
INFO - 2016-09-15 13:12:27 --> Database Driver Class Initialized
INFO - 2016-09-15 13:12:27 --> Controller Class Initialized
DEBUG - 2016-09-15 13:12:27 --> Index MX_Controller Initialized
INFO - 2016-09-15 13:12:27 --> Model Class Initialized
INFO - 2016-09-15 13:12:27 --> Model Class Initialized
DEBUG - 2016-09-15 13:12:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 13:12:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 13:12:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 13:12:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-09-15 13:12:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 13:12:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 13:12:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 13:12:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 13:12:27 --> Final output sent to browser
DEBUG - 2016-09-15 13:12:27 --> Total execution time: 0.7687
INFO - 2016-09-15 13:12:35 --> Config Class Initialized
INFO - 2016-09-15 13:12:35 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:12:35 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:12:35 --> Utf8 Class Initialized
INFO - 2016-09-15 13:12:35 --> URI Class Initialized
INFO - 2016-09-15 13:12:35 --> Router Class Initialized
INFO - 2016-09-15 13:12:36 --> Output Class Initialized
INFO - 2016-09-15 13:12:36 --> Security Class Initialized
DEBUG - 2016-09-15 13:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:12:36 --> Input Class Initialized
INFO - 2016-09-15 13:12:36 --> Language Class Initialized
INFO - 2016-09-15 13:12:36 --> Language Class Initialized
INFO - 2016-09-15 13:12:36 --> Config Class Initialized
INFO - 2016-09-15 13:12:36 --> Loader Class Initialized
INFO - 2016-09-15 13:12:36 --> Helper loaded: url_helper
INFO - 2016-09-15 13:12:36 --> Database Driver Class Initialized
INFO - 2016-09-15 13:12:36 --> Controller Class Initialized
DEBUG - 2016-09-15 13:12:36 --> Index MX_Controller Initialized
INFO - 2016-09-15 13:12:36 --> Model Class Initialized
INFO - 2016-09-15 13:12:36 --> Model Class Initialized
INFO - 2016-09-15 13:12:36 --> Database Driver Class Initialized
INFO - 2016-09-15 13:12:36 --> Final output sent to browser
DEBUG - 2016-09-15 13:12:36 --> Total execution time: 0.7123
INFO - 2016-09-15 13:13:22 --> Config Class Initialized
INFO - 2016-09-15 13:13:22 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:13:22 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:13:22 --> Utf8 Class Initialized
INFO - 2016-09-15 13:13:22 --> URI Class Initialized
INFO - 2016-09-15 13:13:22 --> Router Class Initialized
INFO - 2016-09-15 13:13:22 --> Output Class Initialized
INFO - 2016-09-15 13:13:22 --> Security Class Initialized
DEBUG - 2016-09-15 13:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:13:22 --> Input Class Initialized
INFO - 2016-09-15 13:13:22 --> Language Class Initialized
INFO - 2016-09-15 13:13:22 --> Language Class Initialized
INFO - 2016-09-15 13:13:22 --> Config Class Initialized
INFO - 2016-09-15 13:13:22 --> Loader Class Initialized
INFO - 2016-09-15 13:13:22 --> Helper loaded: url_helper
INFO - 2016-09-15 13:13:22 --> Database Driver Class Initialized
INFO - 2016-09-15 13:13:22 --> Controller Class Initialized
DEBUG - 2016-09-15 13:13:22 --> Index MX_Controller Initialized
INFO - 2016-09-15 13:13:22 --> Model Class Initialized
INFO - 2016-09-15 13:13:22 --> Model Class Initialized
DEBUG - 2016-09-15 13:13:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 13:13:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 13:13:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 13:13:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_bayar_angsuran.php
DEBUG - 2016-09-15 13:13:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 13:13:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 13:13:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 13:13:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 13:13:22 --> Final output sent to browser
DEBUG - 2016-09-15 13:13:22 --> Total execution time: 0.7113
INFO - 2016-09-15 13:13:26 --> Config Class Initialized
INFO - 2016-09-15 13:13:26 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:13:26 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:13:26 --> Utf8 Class Initialized
INFO - 2016-09-15 13:13:26 --> URI Class Initialized
INFO - 2016-09-15 13:13:26 --> Router Class Initialized
INFO - 2016-09-15 13:13:26 --> Output Class Initialized
INFO - 2016-09-15 13:13:26 --> Security Class Initialized
DEBUG - 2016-09-15 13:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:13:26 --> Input Class Initialized
INFO - 2016-09-15 13:13:26 --> Language Class Initialized
INFO - 2016-09-15 13:13:26 --> Language Class Initialized
INFO - 2016-09-15 13:13:26 --> Config Class Initialized
INFO - 2016-09-15 13:13:26 --> Loader Class Initialized
INFO - 2016-09-15 13:13:26 --> Helper loaded: url_helper
INFO - 2016-09-15 13:13:26 --> Database Driver Class Initialized
INFO - 2016-09-15 13:13:26 --> Controller Class Initialized
DEBUG - 2016-09-15 13:13:26 --> Index MX_Controller Initialized
INFO - 2016-09-15 13:13:26 --> Model Class Initialized
INFO - 2016-09-15 13:13:26 --> Model Class Initialized
INFO - 2016-09-15 13:13:26 --> Database Driver Class Initialized
INFO - 2016-09-15 13:13:26 --> Final output sent to browser
DEBUG - 2016-09-15 13:13:26 --> Total execution time: 0.5626
INFO - 2016-09-15 13:13:35 --> Config Class Initialized
INFO - 2016-09-15 13:13:35 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:13:35 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:13:35 --> Utf8 Class Initialized
INFO - 2016-09-15 13:13:35 --> URI Class Initialized
INFO - 2016-09-15 13:13:35 --> Router Class Initialized
INFO - 2016-09-15 13:13:35 --> Output Class Initialized
INFO - 2016-09-15 13:13:35 --> Security Class Initialized
DEBUG - 2016-09-15 13:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:13:35 --> Input Class Initialized
INFO - 2016-09-15 13:13:35 --> Language Class Initialized
INFO - 2016-09-15 13:13:35 --> Language Class Initialized
INFO - 2016-09-15 13:13:35 --> Config Class Initialized
INFO - 2016-09-15 13:13:35 --> Loader Class Initialized
INFO - 2016-09-15 13:13:35 --> Helper loaded: url_helper
INFO - 2016-09-15 13:13:35 --> Database Driver Class Initialized
INFO - 2016-09-15 13:13:35 --> Controller Class Initialized
DEBUG - 2016-09-15 13:13:35 --> Index MX_Controller Initialized
INFO - 2016-09-15 13:13:35 --> Model Class Initialized
INFO - 2016-09-15 13:13:35 --> Model Class Initialized
INFO - 2016-09-15 13:13:35 --> Database Driver Class Initialized
INFO - 2016-09-15 13:13:36 --> Final output sent to browser
DEBUG - 2016-09-15 13:13:36 --> Total execution time: 0.7561
INFO - 2016-09-15 13:13:38 --> Config Class Initialized
INFO - 2016-09-15 13:13:38 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:13:38 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:13:38 --> Utf8 Class Initialized
INFO - 2016-09-15 13:13:38 --> URI Class Initialized
INFO - 2016-09-15 13:13:38 --> Router Class Initialized
INFO - 2016-09-15 13:13:38 --> Output Class Initialized
INFO - 2016-09-15 13:13:38 --> Security Class Initialized
DEBUG - 2016-09-15 13:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:13:38 --> Input Class Initialized
INFO - 2016-09-15 13:13:38 --> Language Class Initialized
INFO - 2016-09-15 13:13:38 --> Language Class Initialized
INFO - 2016-09-15 13:13:38 --> Config Class Initialized
INFO - 2016-09-15 13:13:38 --> Loader Class Initialized
INFO - 2016-09-15 13:13:38 --> Helper loaded: url_helper
INFO - 2016-09-15 13:13:38 --> Database Driver Class Initialized
INFO - 2016-09-15 13:13:38 --> Controller Class Initialized
DEBUG - 2016-09-15 13:13:38 --> Index MX_Controller Initialized
INFO - 2016-09-15 13:13:38 --> Model Class Initialized
INFO - 2016-09-15 13:13:38 --> Model Class Initialized
INFO - 2016-09-15 13:13:38 --> Database Driver Class Initialized
INFO - 2016-09-15 13:13:38 --> Final output sent to browser
DEBUG - 2016-09-15 13:13:38 --> Total execution time: 0.6017
INFO - 2016-09-15 13:13:46 --> Config Class Initialized
INFO - 2016-09-15 13:13:46 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:13:46 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:13:47 --> Utf8 Class Initialized
INFO - 2016-09-15 13:13:47 --> URI Class Initialized
INFO - 2016-09-15 13:13:47 --> Router Class Initialized
INFO - 2016-09-15 13:13:47 --> Output Class Initialized
INFO - 2016-09-15 13:13:47 --> Security Class Initialized
DEBUG - 2016-09-15 13:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:13:47 --> Input Class Initialized
INFO - 2016-09-15 13:13:47 --> Language Class Initialized
INFO - 2016-09-15 13:13:47 --> Language Class Initialized
INFO - 2016-09-15 13:13:47 --> Config Class Initialized
INFO - 2016-09-15 13:13:47 --> Loader Class Initialized
INFO - 2016-09-15 13:13:47 --> Helper loaded: url_helper
INFO - 2016-09-15 13:13:47 --> Database Driver Class Initialized
INFO - 2016-09-15 13:13:47 --> Controller Class Initialized
DEBUG - 2016-09-15 13:13:47 --> Index MX_Controller Initialized
INFO - 2016-09-15 13:13:47 --> Model Class Initialized
INFO - 2016-09-15 13:13:47 --> Model Class Initialized
DEBUG - 2016-09-15 13:13:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 13:13:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 13:13:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 13:13:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tutup_angsuran.php
DEBUG - 2016-09-15 13:13:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 13:13:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 13:13:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 13:13:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 13:13:47 --> Final output sent to browser
DEBUG - 2016-09-15 13:13:47 --> Total execution time: 0.8273
INFO - 2016-09-15 13:13:51 --> Config Class Initialized
INFO - 2016-09-15 13:13:51 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:13:51 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:13:51 --> Utf8 Class Initialized
INFO - 2016-09-15 13:13:51 --> URI Class Initialized
INFO - 2016-09-15 13:13:51 --> Router Class Initialized
INFO - 2016-09-15 13:13:51 --> Output Class Initialized
INFO - 2016-09-15 13:13:51 --> Security Class Initialized
DEBUG - 2016-09-15 13:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:13:51 --> Input Class Initialized
INFO - 2016-09-15 13:13:51 --> Language Class Initialized
INFO - 2016-09-15 13:13:51 --> Language Class Initialized
INFO - 2016-09-15 13:13:51 --> Config Class Initialized
INFO - 2016-09-15 13:13:51 --> Loader Class Initialized
INFO - 2016-09-15 13:13:51 --> Helper loaded: url_helper
INFO - 2016-09-15 13:13:51 --> Database Driver Class Initialized
INFO - 2016-09-15 13:13:52 --> Controller Class Initialized
DEBUG - 2016-09-15 13:13:52 --> Index MX_Controller Initialized
INFO - 2016-09-15 13:13:52 --> Model Class Initialized
INFO - 2016-09-15 13:13:52 --> Model Class Initialized
INFO - 2016-09-15 13:13:52 --> Database Driver Class Initialized
INFO - 2016-09-15 13:13:52 --> Final output sent to browser
DEBUG - 2016-09-15 13:13:52 --> Total execution time: 0.6374
INFO - 2016-09-15 13:14:10 --> Config Class Initialized
INFO - 2016-09-15 13:14:10 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:14:10 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:14:10 --> Utf8 Class Initialized
INFO - 2016-09-15 13:14:10 --> URI Class Initialized
INFO - 2016-09-15 13:14:10 --> Router Class Initialized
INFO - 2016-09-15 13:14:10 --> Output Class Initialized
INFO - 2016-09-15 13:14:10 --> Security Class Initialized
DEBUG - 2016-09-15 13:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:14:10 --> Input Class Initialized
INFO - 2016-09-15 13:14:10 --> Language Class Initialized
INFO - 2016-09-15 13:14:10 --> Language Class Initialized
INFO - 2016-09-15 13:14:10 --> Config Class Initialized
INFO - 2016-09-15 13:14:10 --> Loader Class Initialized
INFO - 2016-09-15 13:14:10 --> Helper loaded: url_helper
INFO - 2016-09-15 13:14:10 --> Database Driver Class Initialized
INFO - 2016-09-15 13:14:10 --> Controller Class Initialized
DEBUG - 2016-09-15 13:14:10 --> Index MX_Controller Initialized
INFO - 2016-09-15 13:14:10 --> Model Class Initialized
INFO - 2016-09-15 13:14:10 --> Model Class Initialized
INFO - 2016-09-15 13:14:10 --> Database Driver Class Initialized
INFO - 2016-09-15 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-15 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-15 13:14:11 --> Final output sent to browser
DEBUG - 2016-09-15 13:14:11 --> Total execution time: 0.9120
INFO - 2016-09-15 13:14:15 --> Config Class Initialized
INFO - 2016-09-15 13:14:15 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:14:15 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:14:15 --> Utf8 Class Initialized
INFO - 2016-09-15 13:14:15 --> URI Class Initialized
INFO - 2016-09-15 13:14:15 --> Router Class Initialized
INFO - 2016-09-15 13:14:15 --> Output Class Initialized
INFO - 2016-09-15 13:14:15 --> Security Class Initialized
DEBUG - 2016-09-15 13:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:14:15 --> Input Class Initialized
INFO - 2016-09-15 13:14:15 --> Language Class Initialized
INFO - 2016-09-15 13:14:15 --> Language Class Initialized
INFO - 2016-09-15 13:14:15 --> Config Class Initialized
INFO - 2016-09-15 13:14:15 --> Loader Class Initialized
INFO - 2016-09-15 13:14:16 --> Helper loaded: url_helper
INFO - 2016-09-15 13:14:16 --> Database Driver Class Initialized
INFO - 2016-09-15 13:14:16 --> Controller Class Initialized
DEBUG - 2016-09-15 13:14:16 --> Index MX_Controller Initialized
INFO - 2016-09-15 13:14:16 --> Model Class Initialized
INFO - 2016-09-15 13:14:16 --> Model Class Initialized
INFO - 2016-09-15 13:14:16 --> Final output sent to browser
DEBUG - 2016-09-15 13:14:16 --> Total execution time: 0.5370
INFO - 2016-09-15 13:14:19 --> Config Class Initialized
INFO - 2016-09-15 13:14:19 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:14:19 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:14:19 --> Utf8 Class Initialized
INFO - 2016-09-15 13:14:19 --> URI Class Initialized
INFO - 2016-09-15 13:14:19 --> Router Class Initialized
INFO - 2016-09-15 13:14:20 --> Output Class Initialized
INFO - 2016-09-15 13:14:20 --> Security Class Initialized
DEBUG - 2016-09-15 13:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:14:20 --> Input Class Initialized
INFO - 2016-09-15 13:14:20 --> Language Class Initialized
INFO - 2016-09-15 13:14:20 --> Language Class Initialized
INFO - 2016-09-15 13:14:20 --> Config Class Initialized
INFO - 2016-09-15 13:14:20 --> Loader Class Initialized
INFO - 2016-09-15 13:14:20 --> Helper loaded: url_helper
INFO - 2016-09-15 13:14:20 --> Database Driver Class Initialized
INFO - 2016-09-15 13:14:20 --> Controller Class Initialized
DEBUG - 2016-09-15 13:14:20 --> Index MX_Controller Initialized
INFO - 2016-09-15 13:14:20 --> Model Class Initialized
INFO - 2016-09-15 13:14:20 --> Model Class Initialized
DEBUG - 2016-09-15 13:14:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 13:14:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 13:14:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 13:14:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-15 13:14:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 13:14:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 13:14:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 13:14:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 13:14:20 --> Final output sent to browser
DEBUG - 2016-09-15 13:14:20 --> Total execution time: 0.7336
INFO - 2016-09-15 13:16:19 --> Config Class Initialized
INFO - 2016-09-15 13:16:19 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:16:19 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:16:19 --> Utf8 Class Initialized
INFO - 2016-09-15 13:16:19 --> URI Class Initialized
INFO - 2016-09-15 13:16:19 --> Router Class Initialized
INFO - 2016-09-15 13:16:19 --> Output Class Initialized
INFO - 2016-09-15 13:16:20 --> Security Class Initialized
DEBUG - 2016-09-15 13:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:16:20 --> Input Class Initialized
INFO - 2016-09-15 13:16:20 --> Language Class Initialized
INFO - 2016-09-15 13:16:20 --> Language Class Initialized
INFO - 2016-09-15 13:16:20 --> Config Class Initialized
INFO - 2016-09-15 13:16:20 --> Loader Class Initialized
INFO - 2016-09-15 13:16:20 --> Helper loaded: url_helper
INFO - 2016-09-15 13:16:20 --> Database Driver Class Initialized
INFO - 2016-09-15 13:16:20 --> Controller Class Initialized
DEBUG - 2016-09-15 13:16:20 --> Index MX_Controller Initialized
INFO - 2016-09-15 13:16:20 --> Model Class Initialized
INFO - 2016-09-15 13:16:20 --> Model Class Initialized
DEBUG - 2016-09-15 13:16:20 --> Anggota MX_Controller Initialized
INFO - 2016-09-15 13:16:20 --> Database Driver Class Initialized
INFO - 2016-09-15 13:16:20 --> Final output sent to browser
DEBUG - 2016-09-15 13:16:20 --> Total execution time: 0.6520
INFO - 2016-09-15 13:16:21 --> Config Class Initialized
INFO - 2016-09-15 13:16:21 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:16:21 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:16:21 --> Utf8 Class Initialized
INFO - 2016-09-15 13:16:21 --> URI Class Initialized
INFO - 2016-09-15 13:16:21 --> Router Class Initialized
INFO - 2016-09-15 13:16:21 --> Output Class Initialized
INFO - 2016-09-15 13:16:21 --> Security Class Initialized
DEBUG - 2016-09-15 13:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:16:21 --> Input Class Initialized
INFO - 2016-09-15 13:16:21 --> Language Class Initialized
INFO - 2016-09-15 13:16:21 --> Language Class Initialized
INFO - 2016-09-15 13:16:21 --> Config Class Initialized
INFO - 2016-09-15 13:16:21 --> Loader Class Initialized
INFO - 2016-09-15 13:16:21 --> Helper loaded: url_helper
INFO - 2016-09-15 13:16:21 --> Database Driver Class Initialized
INFO - 2016-09-15 13:16:21 --> Controller Class Initialized
DEBUG - 2016-09-15 13:16:21 --> Index MX_Controller Initialized
INFO - 2016-09-15 13:16:22 --> Model Class Initialized
INFO - 2016-09-15 13:16:22 --> Model Class Initialized
DEBUG - 2016-09-15 13:16:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 13:16:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 13:16:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 13:16:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_umum.php
DEBUG - 2016-09-15 13:16:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 13:16:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 13:16:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 13:16:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 13:16:22 --> Final output sent to browser
DEBUG - 2016-09-15 13:16:22 --> Total execution time: 0.8305
INFO - 2016-09-15 13:17:17 --> Config Class Initialized
INFO - 2016-09-15 13:17:17 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:17:18 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:17:18 --> Utf8 Class Initialized
INFO - 2016-09-15 13:17:18 --> URI Class Initialized
INFO - 2016-09-15 13:17:18 --> Router Class Initialized
INFO - 2016-09-15 13:17:18 --> Output Class Initialized
INFO - 2016-09-15 13:17:18 --> Security Class Initialized
DEBUG - 2016-09-15 13:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:17:18 --> Input Class Initialized
INFO - 2016-09-15 13:17:18 --> Language Class Initialized
INFO - 2016-09-15 13:17:18 --> Language Class Initialized
INFO - 2016-09-15 13:17:18 --> Config Class Initialized
INFO - 2016-09-15 13:17:18 --> Loader Class Initialized
INFO - 2016-09-15 13:17:18 --> Helper loaded: url_helper
INFO - 2016-09-15 13:17:18 --> Database Driver Class Initialized
INFO - 2016-09-15 13:17:18 --> Controller Class Initialized
DEBUG - 2016-09-15 13:17:18 --> Index MX_Controller Initialized
INFO - 2016-09-15 13:17:18 --> Model Class Initialized
INFO - 2016-09-15 13:17:18 --> Model Class Initialized
INFO - 2016-09-15 13:17:18 --> Database Driver Class Initialized
INFO - 2016-09-15 13:17:18 --> Final output sent to browser
DEBUG - 2016-09-15 13:17:18 --> Total execution time: 0.6317
INFO - 2016-09-15 13:17:44 --> Config Class Initialized
INFO - 2016-09-15 13:17:44 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:17:44 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:17:44 --> Utf8 Class Initialized
INFO - 2016-09-15 13:17:44 --> URI Class Initialized
INFO - 2016-09-15 13:17:44 --> Router Class Initialized
INFO - 2016-09-15 13:17:44 --> Output Class Initialized
INFO - 2016-09-15 13:17:45 --> Security Class Initialized
DEBUG - 2016-09-15 13:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:17:45 --> Input Class Initialized
INFO - 2016-09-15 13:17:45 --> Language Class Initialized
INFO - 2016-09-15 13:17:45 --> Language Class Initialized
INFO - 2016-09-15 13:17:45 --> Config Class Initialized
INFO - 2016-09-15 13:17:45 --> Loader Class Initialized
INFO - 2016-09-15 13:17:45 --> Helper loaded: url_helper
INFO - 2016-09-15 13:17:45 --> Database Driver Class Initialized
INFO - 2016-09-15 13:17:45 --> Controller Class Initialized
DEBUG - 2016-09-15 13:17:45 --> Index MX_Controller Initialized
INFO - 2016-09-15 13:17:45 --> Model Class Initialized
INFO - 2016-09-15 13:17:45 --> Model Class Initialized
INFO - 2016-09-15 13:17:45 --> Database Driver Class Initialized
INFO - 2016-09-15 13:17:45 --> Final output sent to browser
DEBUG - 2016-09-15 13:17:45 --> Total execution time: 0.7195
INFO - 2016-09-15 13:20:13 --> Config Class Initialized
INFO - 2016-09-15 13:20:13 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:20:13 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:20:13 --> Utf8 Class Initialized
INFO - 2016-09-15 13:20:13 --> URI Class Initialized
INFO - 2016-09-15 13:20:13 --> Router Class Initialized
INFO - 2016-09-15 13:20:13 --> Output Class Initialized
INFO - 2016-09-15 13:20:13 --> Security Class Initialized
DEBUG - 2016-09-15 13:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:20:13 --> Input Class Initialized
INFO - 2016-09-15 13:20:13 --> Language Class Initialized
INFO - 2016-09-15 13:20:13 --> Language Class Initialized
INFO - 2016-09-15 13:20:13 --> Config Class Initialized
INFO - 2016-09-15 13:20:13 --> Loader Class Initialized
INFO - 2016-09-15 13:20:13 --> Helper loaded: url_helper
INFO - 2016-09-15 13:20:13 --> Database Driver Class Initialized
INFO - 2016-09-15 13:20:13 --> Controller Class Initialized
DEBUG - 2016-09-15 13:20:13 --> Index MX_Controller Initialized
INFO - 2016-09-15 13:20:13 --> Model Class Initialized
INFO - 2016-09-15 13:20:13 --> Model Class Initialized
DEBUG - 2016-09-15 13:20:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 13:20:13 --> Final output sent to browser
DEBUG - 2016-09-15 13:20:13 --> Total execution time: 0.5467
INFO - 2016-09-15 13:20:14 --> Config Class Initialized
INFO - 2016-09-15 13:20:14 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:20:14 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:20:14 --> Utf8 Class Initialized
INFO - 2016-09-15 13:20:14 --> URI Class Initialized
INFO - 2016-09-15 13:20:14 --> Router Class Initialized
INFO - 2016-09-15 13:20:14 --> Output Class Initialized
INFO - 2016-09-15 13:20:14 --> Security Class Initialized
DEBUG - 2016-09-15 13:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:20:14 --> Input Class Initialized
INFO - 2016-09-15 13:20:14 --> Language Class Initialized
INFO - 2016-09-15 13:20:15 --> Language Class Initialized
INFO - 2016-09-15 13:20:15 --> Config Class Initialized
INFO - 2016-09-15 13:20:15 --> Loader Class Initialized
INFO - 2016-09-15 13:20:15 --> Helper loaded: url_helper
INFO - 2016-09-15 13:20:15 --> Database Driver Class Initialized
INFO - 2016-09-15 13:20:15 --> Controller Class Initialized
DEBUG - 2016-09-15 13:20:15 --> Index MX_Controller Initialized
INFO - 2016-09-15 13:20:15 --> Model Class Initialized
INFO - 2016-09-15 13:20:15 --> Model Class Initialized
DEBUG - 2016-09-15 13:20:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 13:20:15 --> Final output sent to browser
DEBUG - 2016-09-15 13:20:15 --> Total execution time: 0.5367
INFO - 2016-09-15 13:20:15 --> Config Class Initialized
INFO - 2016-09-15 13:20:16 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:20:16 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:20:16 --> Utf8 Class Initialized
INFO - 2016-09-15 13:20:16 --> URI Class Initialized
INFO - 2016-09-15 13:20:16 --> Router Class Initialized
INFO - 2016-09-15 13:20:16 --> Output Class Initialized
INFO - 2016-09-15 13:20:16 --> Security Class Initialized
DEBUG - 2016-09-15 13:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:20:16 --> Input Class Initialized
INFO - 2016-09-15 13:20:16 --> Language Class Initialized
INFO - 2016-09-15 13:20:16 --> Language Class Initialized
INFO - 2016-09-15 13:20:16 --> Config Class Initialized
INFO - 2016-09-15 13:20:16 --> Loader Class Initialized
INFO - 2016-09-15 13:20:16 --> Helper loaded: url_helper
INFO - 2016-09-15 13:20:16 --> Database Driver Class Initialized
INFO - 2016-09-15 13:20:16 --> Controller Class Initialized
DEBUG - 2016-09-15 13:20:16 --> Index MX_Controller Initialized
INFO - 2016-09-15 13:20:16 --> Model Class Initialized
INFO - 2016-09-15 13:20:16 --> Model Class Initialized
DEBUG - 2016-09-15 13:20:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 13:20:16 --> Final output sent to browser
DEBUG - 2016-09-15 13:20:16 --> Total execution time: 0.5452
INFO - 2016-09-15 13:20:50 --> Config Class Initialized
INFO - 2016-09-15 13:20:50 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:20:50 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:20:50 --> Utf8 Class Initialized
INFO - 2016-09-15 13:20:50 --> URI Class Initialized
INFO - 2016-09-15 13:20:50 --> Router Class Initialized
INFO - 2016-09-15 13:20:50 --> Output Class Initialized
INFO - 2016-09-15 13:20:50 --> Security Class Initialized
DEBUG - 2016-09-15 13:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:20:50 --> Input Class Initialized
INFO - 2016-09-15 13:20:50 --> Language Class Initialized
INFO - 2016-09-15 13:20:50 --> Language Class Initialized
INFO - 2016-09-15 13:20:50 --> Config Class Initialized
INFO - 2016-09-15 13:20:50 --> Loader Class Initialized
INFO - 2016-09-15 13:20:50 --> Helper loaded: url_helper
INFO - 2016-09-15 13:20:50 --> Database Driver Class Initialized
INFO - 2016-09-15 13:20:50 --> Controller Class Initialized
DEBUG - 2016-09-15 13:20:50 --> Index MX_Controller Initialized
INFO - 2016-09-15 13:20:50 --> Model Class Initialized
INFO - 2016-09-15 13:20:50 --> Model Class Initialized
DEBUG - 2016-09-15 13:20:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 13:20:50 --> Final output sent to browser
DEBUG - 2016-09-15 13:20:50 --> Total execution time: 0.5758
INFO - 2016-09-15 13:20:50 --> Config Class Initialized
INFO - 2016-09-15 13:20:50 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:20:50 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:20:50 --> Utf8 Class Initialized
INFO - 2016-09-15 13:20:50 --> URI Class Initialized
INFO - 2016-09-15 13:20:50 --> Router Class Initialized
INFO - 2016-09-15 13:20:51 --> Output Class Initialized
INFO - 2016-09-15 13:20:51 --> Security Class Initialized
DEBUG - 2016-09-15 13:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:20:51 --> Input Class Initialized
INFO - 2016-09-15 13:20:51 --> Language Class Initialized
INFO - 2016-09-15 13:20:51 --> Language Class Initialized
INFO - 2016-09-15 13:20:51 --> Config Class Initialized
INFO - 2016-09-15 13:20:51 --> Loader Class Initialized
INFO - 2016-09-15 13:20:51 --> Helper loaded: url_helper
INFO - 2016-09-15 13:20:51 --> Database Driver Class Initialized
INFO - 2016-09-15 13:20:51 --> Controller Class Initialized
DEBUG - 2016-09-15 13:20:51 --> Index MX_Controller Initialized
INFO - 2016-09-15 13:20:51 --> Model Class Initialized
INFO - 2016-09-15 13:20:51 --> Model Class Initialized
DEBUG - 2016-09-15 13:20:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 13:20:51 --> Final output sent to browser
DEBUG - 2016-09-15 13:20:51 --> Total execution time: 0.5448
INFO - 2016-09-15 13:20:52 --> Config Class Initialized
INFO - 2016-09-15 13:20:52 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:20:52 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:20:52 --> Utf8 Class Initialized
INFO - 2016-09-15 13:20:52 --> URI Class Initialized
INFO - 2016-09-15 13:20:52 --> Router Class Initialized
INFO - 2016-09-15 13:20:52 --> Output Class Initialized
INFO - 2016-09-15 13:20:52 --> Security Class Initialized
DEBUG - 2016-09-15 13:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:20:52 --> Input Class Initialized
INFO - 2016-09-15 13:20:52 --> Language Class Initialized
INFO - 2016-09-15 13:20:52 --> Language Class Initialized
INFO - 2016-09-15 13:20:52 --> Config Class Initialized
INFO - 2016-09-15 13:20:52 --> Loader Class Initialized
INFO - 2016-09-15 13:20:52 --> Helper loaded: url_helper
INFO - 2016-09-15 13:20:52 --> Database Driver Class Initialized
INFO - 2016-09-15 13:20:52 --> Controller Class Initialized
DEBUG - 2016-09-15 13:20:52 --> Index MX_Controller Initialized
INFO - 2016-09-15 13:20:52 --> Model Class Initialized
INFO - 2016-09-15 13:20:52 --> Model Class Initialized
DEBUG - 2016-09-15 13:20:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 13:20:52 --> Final output sent to browser
DEBUG - 2016-09-15 13:20:52 --> Total execution time: 0.5380
INFO - 2016-09-15 13:20:53 --> Config Class Initialized
INFO - 2016-09-15 13:20:53 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:20:53 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:20:53 --> Utf8 Class Initialized
INFO - 2016-09-15 13:20:53 --> URI Class Initialized
INFO - 2016-09-15 13:20:53 --> Router Class Initialized
INFO - 2016-09-15 13:20:53 --> Output Class Initialized
INFO - 2016-09-15 13:20:53 --> Security Class Initialized
DEBUG - 2016-09-15 13:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:20:53 --> Input Class Initialized
INFO - 2016-09-15 13:20:53 --> Language Class Initialized
INFO - 2016-09-15 13:20:53 --> Language Class Initialized
INFO - 2016-09-15 13:20:53 --> Config Class Initialized
INFO - 2016-09-15 13:20:53 --> Loader Class Initialized
INFO - 2016-09-15 13:20:53 --> Helper loaded: url_helper
INFO - 2016-09-15 13:20:53 --> Database Driver Class Initialized
INFO - 2016-09-15 13:20:53 --> Controller Class Initialized
DEBUG - 2016-09-15 13:20:54 --> Index MX_Controller Initialized
INFO - 2016-09-15 13:20:54 --> Model Class Initialized
INFO - 2016-09-15 13:20:54 --> Model Class Initialized
DEBUG - 2016-09-15 13:20:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 13:20:54 --> Final output sent to browser
DEBUG - 2016-09-15 13:20:54 --> Total execution time: 0.5761
INFO - 2016-09-15 13:20:54 --> Config Class Initialized
INFO - 2016-09-15 13:20:54 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:20:54 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:20:54 --> Utf8 Class Initialized
INFO - 2016-09-15 13:20:54 --> URI Class Initialized
INFO - 2016-09-15 13:20:54 --> Router Class Initialized
INFO - 2016-09-15 13:20:54 --> Output Class Initialized
INFO - 2016-09-15 13:20:54 --> Security Class Initialized
DEBUG - 2016-09-15 13:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:20:55 --> Input Class Initialized
INFO - 2016-09-15 13:20:55 --> Language Class Initialized
INFO - 2016-09-15 13:20:55 --> Language Class Initialized
INFO - 2016-09-15 13:20:55 --> Config Class Initialized
INFO - 2016-09-15 13:20:55 --> Loader Class Initialized
INFO - 2016-09-15 13:20:55 --> Helper loaded: url_helper
INFO - 2016-09-15 13:20:55 --> Database Driver Class Initialized
INFO - 2016-09-15 13:20:55 --> Controller Class Initialized
DEBUG - 2016-09-15 13:20:55 --> Index MX_Controller Initialized
INFO - 2016-09-15 13:20:55 --> Model Class Initialized
INFO - 2016-09-15 13:20:55 --> Model Class Initialized
DEBUG - 2016-09-15 13:20:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 13:20:55 --> Final output sent to browser
DEBUG - 2016-09-15 13:20:55 --> Total execution time: 0.5500
INFO - 2016-09-15 13:21:00 --> Config Class Initialized
INFO - 2016-09-15 13:21:00 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:21:00 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:21:00 --> Utf8 Class Initialized
INFO - 2016-09-15 13:21:00 --> URI Class Initialized
INFO - 2016-09-15 13:21:00 --> Router Class Initialized
INFO - 2016-09-15 13:21:00 --> Output Class Initialized
INFO - 2016-09-15 13:21:00 --> Security Class Initialized
DEBUG - 2016-09-15 13:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:21:00 --> Input Class Initialized
INFO - 2016-09-15 13:21:00 --> Language Class Initialized
INFO - 2016-09-15 13:21:00 --> Language Class Initialized
INFO - 2016-09-15 13:21:01 --> Config Class Initialized
INFO - 2016-09-15 13:21:01 --> Loader Class Initialized
INFO - 2016-09-15 13:21:01 --> Helper loaded: url_helper
INFO - 2016-09-15 13:21:01 --> Database Driver Class Initialized
INFO - 2016-09-15 13:21:01 --> Controller Class Initialized
DEBUG - 2016-09-15 13:21:01 --> Index MX_Controller Initialized
INFO - 2016-09-15 13:21:01 --> Model Class Initialized
INFO - 2016-09-15 13:21:01 --> Model Class Initialized
DEBUG - 2016-09-15 13:21:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 13:21:01 --> Final output sent to browser
DEBUG - 2016-09-15 13:21:01 --> Total execution time: 0.5600
INFO - 2016-09-15 13:21:01 --> Config Class Initialized
INFO - 2016-09-15 13:21:01 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:21:01 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:21:02 --> Utf8 Class Initialized
INFO - 2016-09-15 13:21:02 --> URI Class Initialized
INFO - 2016-09-15 13:21:02 --> Router Class Initialized
INFO - 2016-09-15 13:21:02 --> Output Class Initialized
INFO - 2016-09-15 13:21:02 --> Security Class Initialized
DEBUG - 2016-09-15 13:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:21:02 --> Input Class Initialized
INFO - 2016-09-15 13:21:02 --> Language Class Initialized
INFO - 2016-09-15 13:21:02 --> Language Class Initialized
INFO - 2016-09-15 13:21:02 --> Config Class Initialized
INFO - 2016-09-15 13:21:02 --> Loader Class Initialized
INFO - 2016-09-15 13:21:02 --> Helper loaded: url_helper
INFO - 2016-09-15 13:21:02 --> Database Driver Class Initialized
INFO - 2016-09-15 13:21:02 --> Controller Class Initialized
DEBUG - 2016-09-15 13:21:02 --> Index MX_Controller Initialized
INFO - 2016-09-15 13:21:02 --> Model Class Initialized
INFO - 2016-09-15 13:21:02 --> Model Class Initialized
DEBUG - 2016-09-15 13:21:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 13:21:02 --> Final output sent to browser
DEBUG - 2016-09-15 13:21:02 --> Total execution time: 0.5398
INFO - 2016-09-15 13:21:03 --> Config Class Initialized
INFO - 2016-09-15 13:21:03 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:21:03 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:21:03 --> Utf8 Class Initialized
INFO - 2016-09-15 13:21:03 --> URI Class Initialized
INFO - 2016-09-15 13:21:03 --> Router Class Initialized
INFO - 2016-09-15 13:21:03 --> Output Class Initialized
INFO - 2016-09-15 13:21:03 --> Security Class Initialized
DEBUG - 2016-09-15 13:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:21:03 --> Input Class Initialized
INFO - 2016-09-15 13:21:03 --> Language Class Initialized
INFO - 2016-09-15 13:21:03 --> Language Class Initialized
INFO - 2016-09-15 13:21:03 --> Config Class Initialized
INFO - 2016-09-15 13:21:03 --> Loader Class Initialized
INFO - 2016-09-15 13:21:03 --> Helper loaded: url_helper
INFO - 2016-09-15 13:21:03 --> Database Driver Class Initialized
INFO - 2016-09-15 13:21:03 --> Controller Class Initialized
DEBUG - 2016-09-15 13:21:03 --> Index MX_Controller Initialized
INFO - 2016-09-15 13:21:03 --> Model Class Initialized
INFO - 2016-09-15 13:21:03 --> Model Class Initialized
DEBUG - 2016-09-15 13:21:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 13:21:03 --> Final output sent to browser
DEBUG - 2016-09-15 13:21:03 --> Total execution time: 0.5479
INFO - 2016-09-15 13:21:04 --> Config Class Initialized
INFO - 2016-09-15 13:21:04 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:21:04 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:21:04 --> Utf8 Class Initialized
INFO - 2016-09-15 13:21:04 --> URI Class Initialized
INFO - 2016-09-15 13:21:04 --> Router Class Initialized
INFO - 2016-09-15 13:21:04 --> Output Class Initialized
INFO - 2016-09-15 13:21:04 --> Security Class Initialized
DEBUG - 2016-09-15 13:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:21:04 --> Input Class Initialized
INFO - 2016-09-15 13:21:04 --> Language Class Initialized
INFO - 2016-09-15 13:21:04 --> Language Class Initialized
INFO - 2016-09-15 13:21:04 --> Config Class Initialized
INFO - 2016-09-15 13:21:04 --> Loader Class Initialized
INFO - 2016-09-15 13:21:04 --> Helper loaded: url_helper
INFO - 2016-09-15 13:21:04 --> Database Driver Class Initialized
INFO - 2016-09-15 13:21:04 --> Controller Class Initialized
DEBUG - 2016-09-15 13:21:04 --> Index MX_Controller Initialized
INFO - 2016-09-15 13:21:04 --> Model Class Initialized
INFO - 2016-09-15 13:21:04 --> Model Class Initialized
DEBUG - 2016-09-15 13:21:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 13:21:04 --> Final output sent to browser
DEBUG - 2016-09-15 13:21:04 --> Total execution time: 0.5826
INFO - 2016-09-15 15:05:11 --> Config Class Initialized
INFO - 2016-09-15 15:05:11 --> Hooks Class Initialized
DEBUG - 2016-09-15 15:05:11 --> UTF-8 Support Enabled
INFO - 2016-09-15 15:05:11 --> Utf8 Class Initialized
INFO - 2016-09-15 15:05:11 --> URI Class Initialized
INFO - 2016-09-15 15:05:11 --> Router Class Initialized
INFO - 2016-09-15 15:05:11 --> Output Class Initialized
INFO - 2016-09-15 15:05:12 --> Security Class Initialized
DEBUG - 2016-09-15 15:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 15:05:12 --> Input Class Initialized
INFO - 2016-09-15 15:05:12 --> Language Class Initialized
INFO - 2016-09-15 15:05:12 --> Language Class Initialized
INFO - 2016-09-15 15:05:12 --> Config Class Initialized
INFO - 2016-09-15 15:05:12 --> Loader Class Initialized
INFO - 2016-09-15 15:05:12 --> Helper loaded: url_helper
INFO - 2016-09-15 15:05:12 --> Database Driver Class Initialized
INFO - 2016-09-15 15:05:12 --> Controller Class Initialized
DEBUG - 2016-09-15 15:05:12 --> Index MX_Controller Initialized
INFO - 2016-09-15 15:05:12 --> Model Class Initialized
INFO - 2016-09-15 15:05:12 --> Model Class Initialized
DEBUG - 2016-09-15 15:05:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 15:05:12 --> Final output sent to browser
DEBUG - 2016-09-15 15:05:12 --> Total execution time: 0.5491
INFO - 2016-09-15 15:05:13 --> Config Class Initialized
INFO - 2016-09-15 15:05:13 --> Hooks Class Initialized
DEBUG - 2016-09-15 15:05:13 --> UTF-8 Support Enabled
INFO - 2016-09-15 15:05:13 --> Utf8 Class Initialized
INFO - 2016-09-15 15:05:13 --> URI Class Initialized
INFO - 2016-09-15 15:05:13 --> Router Class Initialized
INFO - 2016-09-15 15:05:13 --> Output Class Initialized
INFO - 2016-09-15 15:05:13 --> Security Class Initialized
DEBUG - 2016-09-15 15:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 15:05:13 --> Input Class Initialized
INFO - 2016-09-15 15:05:13 --> Language Class Initialized
INFO - 2016-09-15 15:05:13 --> Language Class Initialized
INFO - 2016-09-15 15:05:13 --> Config Class Initialized
INFO - 2016-09-15 15:05:13 --> Loader Class Initialized
INFO - 2016-09-15 15:05:13 --> Helper loaded: url_helper
INFO - 2016-09-15 15:05:13 --> Database Driver Class Initialized
INFO - 2016-09-15 15:05:13 --> Controller Class Initialized
DEBUG - 2016-09-15 15:05:13 --> Index MX_Controller Initialized
INFO - 2016-09-15 15:05:13 --> Model Class Initialized
INFO - 2016-09-15 15:05:13 --> Model Class Initialized
DEBUG - 2016-09-15 15:05:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 15:05:13 --> Final output sent to browser
DEBUG - 2016-09-15 15:05:13 --> Total execution time: 0.5599
INFO - 2016-09-15 15:05:14 --> Config Class Initialized
INFO - 2016-09-15 15:05:14 --> Hooks Class Initialized
DEBUG - 2016-09-15 15:05:14 --> UTF-8 Support Enabled
INFO - 2016-09-15 15:05:14 --> Utf8 Class Initialized
INFO - 2016-09-15 15:05:14 --> URI Class Initialized
INFO - 2016-09-15 15:05:14 --> Router Class Initialized
INFO - 2016-09-15 15:05:14 --> Output Class Initialized
INFO - 2016-09-15 15:05:14 --> Security Class Initialized
DEBUG - 2016-09-15 15:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 15:05:14 --> Input Class Initialized
INFO - 2016-09-15 15:05:14 --> Language Class Initialized
INFO - 2016-09-15 15:05:14 --> Language Class Initialized
INFO - 2016-09-15 15:05:14 --> Config Class Initialized
INFO - 2016-09-15 15:05:14 --> Loader Class Initialized
INFO - 2016-09-15 15:05:14 --> Helper loaded: url_helper
INFO - 2016-09-15 15:05:14 --> Database Driver Class Initialized
INFO - 2016-09-15 15:05:14 --> Controller Class Initialized
DEBUG - 2016-09-15 15:05:15 --> Index MX_Controller Initialized
INFO - 2016-09-15 15:05:15 --> Model Class Initialized
INFO - 2016-09-15 15:05:15 --> Model Class Initialized
DEBUG - 2016-09-15 15:05:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 15:05:15 --> Final output sent to browser
DEBUG - 2016-09-15 15:05:15 --> Total execution time: 0.5493
INFO - 2016-09-15 15:05:16 --> Config Class Initialized
INFO - 2016-09-15 15:05:16 --> Hooks Class Initialized
DEBUG - 2016-09-15 15:05:16 --> UTF-8 Support Enabled
INFO - 2016-09-15 15:05:16 --> Utf8 Class Initialized
INFO - 2016-09-15 15:05:16 --> URI Class Initialized
INFO - 2016-09-15 15:05:16 --> Router Class Initialized
INFO - 2016-09-15 15:05:16 --> Output Class Initialized
INFO - 2016-09-15 15:05:16 --> Security Class Initialized
DEBUG - 2016-09-15 15:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 15:05:16 --> Input Class Initialized
INFO - 2016-09-15 15:05:16 --> Language Class Initialized
INFO - 2016-09-15 15:05:16 --> Language Class Initialized
INFO - 2016-09-15 15:05:16 --> Config Class Initialized
INFO - 2016-09-15 15:05:16 --> Loader Class Initialized
INFO - 2016-09-15 15:05:16 --> Helper loaded: url_helper
INFO - 2016-09-15 15:05:16 --> Database Driver Class Initialized
INFO - 2016-09-15 15:05:16 --> Controller Class Initialized
DEBUG - 2016-09-15 15:05:16 --> Index MX_Controller Initialized
INFO - 2016-09-15 15:05:16 --> Model Class Initialized
INFO - 2016-09-15 15:05:16 --> Model Class Initialized
DEBUG - 2016-09-15 15:05:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 15:05:16 --> Final output sent to browser
DEBUG - 2016-09-15 15:05:16 --> Total execution time: 0.5566
INFO - 2016-09-15 15:07:08 --> Config Class Initialized
INFO - 2016-09-15 15:07:08 --> Hooks Class Initialized
DEBUG - 2016-09-15 15:07:08 --> UTF-8 Support Enabled
INFO - 2016-09-15 15:07:08 --> Utf8 Class Initialized
INFO - 2016-09-15 15:07:08 --> URI Class Initialized
INFO - 2016-09-15 15:07:08 --> Router Class Initialized
INFO - 2016-09-15 15:07:08 --> Output Class Initialized
INFO - 2016-09-15 15:07:09 --> Security Class Initialized
DEBUG - 2016-09-15 15:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 15:07:09 --> Input Class Initialized
INFO - 2016-09-15 15:07:09 --> Language Class Initialized
INFO - 2016-09-15 15:07:09 --> Language Class Initialized
INFO - 2016-09-15 15:07:09 --> Config Class Initialized
INFO - 2016-09-15 15:07:09 --> Loader Class Initialized
INFO - 2016-09-15 15:07:09 --> Helper loaded: url_helper
INFO - 2016-09-15 15:07:09 --> Database Driver Class Initialized
INFO - 2016-09-15 15:07:09 --> Controller Class Initialized
DEBUG - 2016-09-15 15:07:09 --> Index MX_Controller Initialized
INFO - 2016-09-15 15:07:09 --> Model Class Initialized
INFO - 2016-09-15 15:07:09 --> Model Class Initialized
DEBUG - 2016-09-15 15:07:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 15:07:09 --> Final output sent to browser
DEBUG - 2016-09-15 15:07:09 --> Total execution time: 0.5972
INFO - 2016-09-15 15:07:10 --> Config Class Initialized
INFO - 2016-09-15 15:07:10 --> Hooks Class Initialized
DEBUG - 2016-09-15 15:07:10 --> UTF-8 Support Enabled
INFO - 2016-09-15 15:07:10 --> Utf8 Class Initialized
INFO - 2016-09-15 15:07:10 --> URI Class Initialized
INFO - 2016-09-15 15:07:10 --> Router Class Initialized
INFO - 2016-09-15 15:07:10 --> Output Class Initialized
INFO - 2016-09-15 15:07:10 --> Security Class Initialized
DEBUG - 2016-09-15 15:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 15:07:10 --> Input Class Initialized
INFO - 2016-09-15 15:07:10 --> Language Class Initialized
INFO - 2016-09-15 15:07:10 --> Language Class Initialized
INFO - 2016-09-15 15:07:10 --> Config Class Initialized
INFO - 2016-09-15 15:07:10 --> Loader Class Initialized
INFO - 2016-09-15 15:07:10 --> Helper loaded: url_helper
INFO - 2016-09-15 15:07:10 --> Database Driver Class Initialized
INFO - 2016-09-15 15:07:10 --> Controller Class Initialized
DEBUG - 2016-09-15 15:07:10 --> Index MX_Controller Initialized
INFO - 2016-09-15 15:07:10 --> Model Class Initialized
INFO - 2016-09-15 15:07:10 --> Model Class Initialized
DEBUG - 2016-09-15 15:07:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 15:07:10 --> Final output sent to browser
DEBUG - 2016-09-15 15:07:10 --> Total execution time: 0.5901
INFO - 2016-09-15 15:07:11 --> Config Class Initialized
INFO - 2016-09-15 15:07:11 --> Hooks Class Initialized
DEBUG - 2016-09-15 15:07:11 --> UTF-8 Support Enabled
INFO - 2016-09-15 15:07:11 --> Utf8 Class Initialized
INFO - 2016-09-15 15:07:11 --> URI Class Initialized
INFO - 2016-09-15 15:07:11 --> Router Class Initialized
INFO - 2016-09-15 15:07:11 --> Output Class Initialized
INFO - 2016-09-15 15:07:11 --> Security Class Initialized
DEBUG - 2016-09-15 15:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 15:07:11 --> Input Class Initialized
INFO - 2016-09-15 15:07:11 --> Language Class Initialized
INFO - 2016-09-15 15:07:11 --> Language Class Initialized
INFO - 2016-09-15 15:07:11 --> Config Class Initialized
INFO - 2016-09-15 15:07:11 --> Loader Class Initialized
INFO - 2016-09-15 15:07:11 --> Helper loaded: url_helper
INFO - 2016-09-15 15:07:11 --> Database Driver Class Initialized
INFO - 2016-09-15 15:07:11 --> Controller Class Initialized
DEBUG - 2016-09-15 15:07:11 --> Index MX_Controller Initialized
INFO - 2016-09-15 15:07:11 --> Model Class Initialized
INFO - 2016-09-15 15:07:11 --> Model Class Initialized
DEBUG - 2016-09-15 15:07:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 15:07:11 --> Final output sent to browser
DEBUG - 2016-09-15 15:07:11 --> Total execution time: 0.5776
INFO - 2016-09-15 15:07:12 --> Config Class Initialized
INFO - 2016-09-15 15:07:12 --> Hooks Class Initialized
DEBUG - 2016-09-15 15:07:12 --> UTF-8 Support Enabled
INFO - 2016-09-15 15:07:12 --> Utf8 Class Initialized
INFO - 2016-09-15 15:07:12 --> URI Class Initialized
INFO - 2016-09-15 15:07:12 --> Router Class Initialized
INFO - 2016-09-15 15:07:12 --> Output Class Initialized
INFO - 2016-09-15 15:07:12 --> Security Class Initialized
DEBUG - 2016-09-15 15:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 15:07:12 --> Input Class Initialized
INFO - 2016-09-15 15:07:12 --> Language Class Initialized
INFO - 2016-09-15 15:07:12 --> Language Class Initialized
INFO - 2016-09-15 15:07:12 --> Config Class Initialized
INFO - 2016-09-15 15:07:12 --> Loader Class Initialized
INFO - 2016-09-15 15:07:12 --> Helper loaded: url_helper
INFO - 2016-09-15 15:07:12 --> Database Driver Class Initialized
INFO - 2016-09-15 15:07:12 --> Controller Class Initialized
DEBUG - 2016-09-15 15:07:12 --> Index MX_Controller Initialized
INFO - 2016-09-15 15:07:12 --> Model Class Initialized
INFO - 2016-09-15 15:07:12 --> Model Class Initialized
DEBUG - 2016-09-15 15:07:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 15:07:12 --> Final output sent to browser
DEBUG - 2016-09-15 15:07:12 --> Total execution time: 0.5564
INFO - 2016-09-15 15:34:25 --> Config Class Initialized
INFO - 2016-09-15 15:34:25 --> Hooks Class Initialized
DEBUG - 2016-09-15 15:34:25 --> UTF-8 Support Enabled
INFO - 2016-09-15 15:34:25 --> Utf8 Class Initialized
INFO - 2016-09-15 15:34:25 --> URI Class Initialized
INFO - 2016-09-15 15:34:25 --> Router Class Initialized
INFO - 2016-09-15 15:34:25 --> Output Class Initialized
INFO - 2016-09-15 15:34:25 --> Security Class Initialized
DEBUG - 2016-09-15 15:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 15:34:25 --> Input Class Initialized
INFO - 2016-09-15 15:34:25 --> Language Class Initialized
INFO - 2016-09-15 15:34:25 --> Language Class Initialized
INFO - 2016-09-15 15:34:25 --> Config Class Initialized
INFO - 2016-09-15 15:34:25 --> Loader Class Initialized
INFO - 2016-09-15 15:34:25 --> Helper loaded: url_helper
INFO - 2016-09-15 15:34:25 --> Database Driver Class Initialized
INFO - 2016-09-15 15:34:25 --> Controller Class Initialized
DEBUG - 2016-09-15 15:34:25 --> Index MX_Controller Initialized
INFO - 2016-09-15 15:34:25 --> Model Class Initialized
INFO - 2016-09-15 15:34:25 --> Model Class Initialized
DEBUG - 2016-09-15 15:34:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 15:34:25 --> Final output sent to browser
DEBUG - 2016-09-15 15:34:25 --> Total execution time: 0.7007
INFO - 2016-09-15 15:54:48 --> Config Class Initialized
INFO - 2016-09-15 15:54:48 --> Hooks Class Initialized
DEBUG - 2016-09-15 15:54:48 --> UTF-8 Support Enabled
INFO - 2016-09-15 15:54:49 --> Utf8 Class Initialized
INFO - 2016-09-15 15:54:49 --> URI Class Initialized
INFO - 2016-09-15 15:54:49 --> Router Class Initialized
INFO - 2016-09-15 15:54:49 --> Output Class Initialized
INFO - 2016-09-15 15:54:49 --> Security Class Initialized
DEBUG - 2016-09-15 15:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 15:54:49 --> Input Class Initialized
INFO - 2016-09-15 15:54:49 --> Language Class Initialized
INFO - 2016-09-15 15:54:49 --> Language Class Initialized
INFO - 2016-09-15 15:54:49 --> Config Class Initialized
INFO - 2016-09-15 15:54:49 --> Loader Class Initialized
INFO - 2016-09-15 15:54:49 --> Helper loaded: url_helper
INFO - 2016-09-15 15:54:49 --> Database Driver Class Initialized
INFO - 2016-09-15 15:54:49 --> Controller Class Initialized
DEBUG - 2016-09-15 15:54:49 --> Index MX_Controller Initialized
INFO - 2016-09-15 15:54:49 --> Model Class Initialized
INFO - 2016-09-15 15:54:49 --> Model Class Initialized
DEBUG - 2016-09-15 15:54:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 15:54:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 15:54:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 15:54:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_peminjam.php
DEBUG - 2016-09-15 15:54:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 15:54:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 15:54:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 15:54:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 15:54:50 --> Final output sent to browser
DEBUG - 2016-09-15 15:54:50 --> Total execution time: 1.1960
INFO - 2016-09-15 15:54:53 --> Config Class Initialized
INFO - 2016-09-15 15:54:53 --> Hooks Class Initialized
DEBUG - 2016-09-15 15:54:53 --> UTF-8 Support Enabled
INFO - 2016-09-15 15:54:53 --> Utf8 Class Initialized
INFO - 2016-09-15 15:54:53 --> URI Class Initialized
INFO - 2016-09-15 15:54:53 --> Router Class Initialized
INFO - 2016-09-15 15:54:54 --> Output Class Initialized
INFO - 2016-09-15 15:54:54 --> Security Class Initialized
DEBUG - 2016-09-15 15:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 15:54:54 --> Input Class Initialized
INFO - 2016-09-15 15:54:54 --> Language Class Initialized
INFO - 2016-09-15 15:54:54 --> Language Class Initialized
INFO - 2016-09-15 15:54:54 --> Config Class Initialized
INFO - 2016-09-15 15:54:54 --> Loader Class Initialized
INFO - 2016-09-15 15:54:54 --> Helper loaded: url_helper
INFO - 2016-09-15 15:54:54 --> Config Class Initialized
INFO - 2016-09-15 15:54:54 --> Hooks Class Initialized
INFO - 2016-09-15 15:54:54 --> Database Driver Class Initialized
DEBUG - 2016-09-15 15:54:54 --> UTF-8 Support Enabled
INFO - 2016-09-15 15:54:55 --> Utf8 Class Initialized
INFO - 2016-09-15 15:54:55 --> URI Class Initialized
INFO - 2016-09-15 15:54:55 --> Router Class Initialized
INFO - 2016-09-15 15:54:55 --> Output Class Initialized
INFO - 2016-09-15 15:54:55 --> Security Class Initialized
DEBUG - 2016-09-15 15:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 15:54:55 --> Input Class Initialized
INFO - 2016-09-15 15:54:55 --> Language Class Initialized
INFO - 2016-09-15 15:54:55 --> Language Class Initialized
INFO - 2016-09-15 15:54:55 --> Config Class Initialized
INFO - 2016-09-15 15:54:55 --> Loader Class Initialized
INFO - 2016-09-15 15:54:55 --> Helper loaded: url_helper
INFO - 2016-09-15 15:54:55 --> Database Driver Class Initialized
INFO - 2016-09-15 15:54:55 --> Controller Class Initialized
INFO - 2016-09-15 15:54:55 --> Controller Class Initialized
DEBUG - 2016-09-15 15:54:55 --> Index MX_Controller Initialized
DEBUG - 2016-09-15 15:54:55 --> Index MX_Controller Initialized
INFO - 2016-09-15 15:54:56 --> Model Class Initialized
INFO - 2016-09-15 15:54:56 --> Model Class Initialized
INFO - 2016-09-15 15:54:56 --> Model Class Initialized
DEBUG - 2016-09-15 15:54:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 15:54:56 --> Final output sent to browser
INFO - 2016-09-15 15:54:56 --> Model Class Initialized
DEBUG - 2016-09-15 15:54:56 --> Total execution time: 2.6657
DEBUG - 2016-09-15 15:54:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 15:54:56 --> Final output sent to browser
DEBUG - 2016-09-15 15:54:56 --> Total execution time: 1.4023
INFO - 2016-09-15 15:54:58 --> Config Class Initialized
INFO - 2016-09-15 15:54:58 --> Hooks Class Initialized
DEBUG - 2016-09-15 15:54:58 --> UTF-8 Support Enabled
INFO - 2016-09-15 15:54:58 --> Utf8 Class Initialized
INFO - 2016-09-15 15:54:58 --> URI Class Initialized
INFO - 2016-09-15 15:54:58 --> Router Class Initialized
INFO - 2016-09-15 15:54:58 --> Output Class Initialized
INFO - 2016-09-15 15:54:58 --> Security Class Initialized
DEBUG - 2016-09-15 15:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 15:54:58 --> Input Class Initialized
INFO - 2016-09-15 15:54:58 --> Language Class Initialized
INFO - 2016-09-15 15:54:58 --> Language Class Initialized
INFO - 2016-09-15 15:54:58 --> Config Class Initialized
INFO - 2016-09-15 15:54:58 --> Loader Class Initialized
INFO - 2016-09-15 15:54:58 --> Helper loaded: url_helper
INFO - 2016-09-15 15:54:58 --> Database Driver Class Initialized
INFO - 2016-09-15 15:54:58 --> Controller Class Initialized
DEBUG - 2016-09-15 15:54:59 --> Index MX_Controller Initialized
INFO - 2016-09-15 15:54:59 --> Model Class Initialized
INFO - 2016-09-15 15:54:59 --> Model Class Initialized
DEBUG - 2016-09-15 15:54:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 15:54:59 --> Final output sent to browser
DEBUG - 2016-09-15 15:54:59 --> Total execution time: 1.0718
INFO - 2016-09-15 15:57:08 --> Config Class Initialized
INFO - 2016-09-15 15:57:09 --> Hooks Class Initialized
DEBUG - 2016-09-15 15:57:09 --> UTF-8 Support Enabled
INFO - 2016-09-15 15:57:09 --> Utf8 Class Initialized
INFO - 2016-09-15 15:57:09 --> URI Class Initialized
INFO - 2016-09-15 15:57:09 --> Router Class Initialized
INFO - 2016-09-15 15:57:09 --> Output Class Initialized
INFO - 2016-09-15 15:57:09 --> Security Class Initialized
DEBUG - 2016-09-15 15:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 15:57:09 --> Input Class Initialized
INFO - 2016-09-15 15:57:09 --> Language Class Initialized
INFO - 2016-09-15 15:57:09 --> Language Class Initialized
INFO - 2016-09-15 15:57:09 --> Config Class Initialized
INFO - 2016-09-15 15:57:09 --> Loader Class Initialized
INFO - 2016-09-15 15:57:09 --> Helper loaded: url_helper
INFO - 2016-09-15 15:57:10 --> Database Driver Class Initialized
INFO - 2016-09-15 15:57:10 --> Controller Class Initialized
DEBUG - 2016-09-15 15:57:10 --> Index MX_Controller Initialized
INFO - 2016-09-15 15:57:10 --> Model Class Initialized
INFO - 2016-09-15 15:57:10 --> Model Class Initialized
DEBUG - 2016-09-15 15:57:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 15:57:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 15:57:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 15:57:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_peminjam.php
DEBUG - 2016-09-15 15:57:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 15:57:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 15:57:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 15:57:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 15:57:10 --> Final output sent to browser
DEBUG - 2016-09-15 15:57:10 --> Total execution time: 1.7601
INFO - 2016-09-15 15:57:23 --> Config Class Initialized
INFO - 2016-09-15 15:57:24 --> Hooks Class Initialized
DEBUG - 2016-09-15 15:57:24 --> UTF-8 Support Enabled
INFO - 2016-09-15 15:57:25 --> Utf8 Class Initialized
INFO - 2016-09-15 15:57:25 --> URI Class Initialized
INFO - 2016-09-15 15:57:25 --> Router Class Initialized
INFO - 2016-09-15 15:57:25 --> Output Class Initialized
INFO - 2016-09-15 15:57:25 --> Security Class Initialized
DEBUG - 2016-09-15 15:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 15:57:26 --> Input Class Initialized
INFO - 2016-09-15 15:57:26 --> Language Class Initialized
INFO - 2016-09-15 15:57:26 --> Language Class Initialized
INFO - 2016-09-15 15:57:26 --> Config Class Initialized
INFO - 2016-09-15 15:57:26 --> Loader Class Initialized
INFO - 2016-09-15 15:57:26 --> Helper loaded: url_helper
INFO - 2016-09-15 15:57:26 --> Database Driver Class Initialized
INFO - 2016-09-15 15:57:27 --> Controller Class Initialized
DEBUG - 2016-09-15 15:57:27 --> Index MX_Controller Initialized
INFO - 2016-09-15 15:57:27 --> Model Class Initialized
INFO - 2016-09-15 15:57:27 --> Model Class Initialized
DEBUG - 2016-09-15 15:57:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 15:57:27 --> Final output sent to browser
DEBUG - 2016-09-15 15:57:28 --> Total execution time: 3.7649
INFO - 2016-09-15 15:57:28 --> Config Class Initialized
INFO - 2016-09-15 15:57:28 --> Hooks Class Initialized
DEBUG - 2016-09-15 15:57:28 --> UTF-8 Support Enabled
INFO - 2016-09-15 15:57:29 --> Utf8 Class Initialized
INFO - 2016-09-15 15:57:29 --> URI Class Initialized
INFO - 2016-09-15 15:57:29 --> Router Class Initialized
INFO - 2016-09-15 15:57:29 --> Output Class Initialized
INFO - 2016-09-15 15:57:29 --> Security Class Initialized
DEBUG - 2016-09-15 15:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 15:57:29 --> Input Class Initialized
INFO - 2016-09-15 15:57:29 --> Language Class Initialized
INFO - 2016-09-15 15:57:29 --> Language Class Initialized
INFO - 2016-09-15 15:57:29 --> Config Class Initialized
INFO - 2016-09-15 15:57:29 --> Loader Class Initialized
INFO - 2016-09-15 15:57:29 --> Helper loaded: url_helper
INFO - 2016-09-15 15:57:29 --> Database Driver Class Initialized
INFO - 2016-09-15 15:57:30 --> Controller Class Initialized
DEBUG - 2016-09-15 15:57:30 --> Index MX_Controller Initialized
INFO - 2016-09-15 15:57:30 --> Model Class Initialized
INFO - 2016-09-15 15:57:30 --> Model Class Initialized
DEBUG - 2016-09-15 15:57:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 15:57:30 --> Final output sent to browser
DEBUG - 2016-09-15 15:57:30 --> Total execution time: 1.9779
INFO - 2016-09-15 15:59:32 --> Config Class Initialized
INFO - 2016-09-15 15:59:33 --> Hooks Class Initialized
DEBUG - 2016-09-15 15:59:33 --> UTF-8 Support Enabled
INFO - 2016-09-15 15:59:33 --> Utf8 Class Initialized
INFO - 2016-09-15 15:59:33 --> URI Class Initialized
INFO - 2016-09-15 15:59:34 --> Router Class Initialized
INFO - 2016-09-15 15:59:34 --> Output Class Initialized
INFO - 2016-09-15 15:59:34 --> Security Class Initialized
DEBUG - 2016-09-15 15:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 15:59:34 --> Input Class Initialized
INFO - 2016-09-15 15:59:34 --> Language Class Initialized
INFO - 2016-09-15 15:59:34 --> Language Class Initialized
INFO - 2016-09-15 15:59:34 --> Config Class Initialized
INFO - 2016-09-15 15:59:34 --> Loader Class Initialized
INFO - 2016-09-15 15:59:34 --> Helper loaded: url_helper
INFO - 2016-09-15 15:59:34 --> Database Driver Class Initialized
INFO - 2016-09-15 15:59:34 --> Controller Class Initialized
DEBUG - 2016-09-15 15:59:34 --> Index MX_Controller Initialized
INFO - 2016-09-15 15:59:34 --> Model Class Initialized
INFO - 2016-09-15 15:59:34 --> Model Class Initialized
DEBUG - 2016-09-15 15:59:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 15:59:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 15:59:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 15:59:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_peminjam.php
DEBUG - 2016-09-15 15:59:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 15:59:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 15:59:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 15:59:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 15:59:35 --> Final output sent to browser
DEBUG - 2016-09-15 15:59:35 --> Total execution time: 2.1308
INFO - 2016-09-15 15:59:53 --> Config Class Initialized
INFO - 2016-09-15 15:59:53 --> Hooks Class Initialized
DEBUG - 2016-09-15 15:59:53 --> UTF-8 Support Enabled
INFO - 2016-09-15 15:59:53 --> Utf8 Class Initialized
INFO - 2016-09-15 15:59:53 --> URI Class Initialized
INFO - 2016-09-15 15:59:53 --> Router Class Initialized
INFO - 2016-09-15 15:59:53 --> Output Class Initialized
INFO - 2016-09-15 15:59:53 --> Security Class Initialized
DEBUG - 2016-09-15 15:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 15:59:53 --> Input Class Initialized
INFO - 2016-09-15 15:59:53 --> Language Class Initialized
INFO - 2016-09-15 15:59:53 --> Language Class Initialized
INFO - 2016-09-15 15:59:53 --> Config Class Initialized
INFO - 2016-09-15 15:59:53 --> Loader Class Initialized
INFO - 2016-09-15 15:59:53 --> Helper loaded: url_helper
INFO - 2016-09-15 15:59:53 --> Database Driver Class Initialized
INFO - 2016-09-15 15:59:53 --> Controller Class Initialized
DEBUG - 2016-09-15 15:59:53 --> Index MX_Controller Initialized
INFO - 2016-09-15 15:59:53 --> Model Class Initialized
INFO - 2016-09-15 15:59:53 --> Model Class Initialized
DEBUG - 2016-09-15 15:59:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 15:59:53 --> Final output sent to browser
DEBUG - 2016-09-15 15:59:54 --> Total execution time: 0.8830
INFO - 2016-09-15 16:00:47 --> Config Class Initialized
INFO - 2016-09-15 16:00:48 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:00:48 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:00:48 --> Utf8 Class Initialized
INFO - 2016-09-15 16:00:48 --> URI Class Initialized
INFO - 2016-09-15 16:00:48 --> Router Class Initialized
INFO - 2016-09-15 16:00:48 --> Output Class Initialized
INFO - 2016-09-15 16:00:48 --> Security Class Initialized
DEBUG - 2016-09-15 16:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:00:48 --> Input Class Initialized
INFO - 2016-09-15 16:00:48 --> Language Class Initialized
INFO - 2016-09-15 16:00:48 --> Language Class Initialized
INFO - 2016-09-15 16:00:48 --> Config Class Initialized
INFO - 2016-09-15 16:00:48 --> Loader Class Initialized
INFO - 2016-09-15 16:00:48 --> Helper loaded: url_helper
INFO - 2016-09-15 16:00:48 --> Database Driver Class Initialized
INFO - 2016-09-15 16:00:48 --> Controller Class Initialized
DEBUG - 2016-09-15 16:00:49 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:00:49 --> Model Class Initialized
INFO - 2016-09-15 16:00:49 --> Model Class Initialized
DEBUG - 2016-09-15 16:00:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 16:00:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 16:00:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 16:00:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_peminjam.php
DEBUG - 2016-09-15 16:00:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 16:00:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 16:00:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 16:00:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 16:00:49 --> Final output sent to browser
DEBUG - 2016-09-15 16:00:49 --> Total execution time: 1.6147
INFO - 2016-09-15 16:01:02 --> Config Class Initialized
INFO - 2016-09-15 16:01:02 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:01:02 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:01:02 --> Utf8 Class Initialized
INFO - 2016-09-15 16:01:02 --> URI Class Initialized
INFO - 2016-09-15 16:01:02 --> Router Class Initialized
INFO - 2016-09-15 16:01:02 --> Output Class Initialized
INFO - 2016-09-15 16:01:02 --> Security Class Initialized
DEBUG - 2016-09-15 16:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:01:03 --> Input Class Initialized
INFO - 2016-09-15 16:01:03 --> Language Class Initialized
INFO - 2016-09-15 16:01:03 --> Language Class Initialized
INFO - 2016-09-15 16:01:03 --> Config Class Initialized
INFO - 2016-09-15 16:01:03 --> Loader Class Initialized
INFO - 2016-09-15 16:01:03 --> Helper loaded: url_helper
INFO - 2016-09-15 16:01:03 --> Database Driver Class Initialized
INFO - 2016-09-15 16:01:03 --> Controller Class Initialized
DEBUG - 2016-09-15 16:01:03 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:01:03 --> Model Class Initialized
INFO - 2016-09-15 16:01:03 --> Model Class Initialized
DEBUG - 2016-09-15 16:01:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 16:01:03 --> Final output sent to browser
DEBUG - 2016-09-15 16:01:03 --> Total execution time: 1.2704
INFO - 2016-09-15 16:02:33 --> Config Class Initialized
INFO - 2016-09-15 16:02:33 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:02:33 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:02:33 --> Utf8 Class Initialized
INFO - 2016-09-15 16:02:33 --> URI Class Initialized
INFO - 2016-09-15 16:02:33 --> Router Class Initialized
INFO - 2016-09-15 16:02:34 --> Output Class Initialized
INFO - 2016-09-15 16:02:34 --> Security Class Initialized
DEBUG - 2016-09-15 16:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:02:34 --> Input Class Initialized
INFO - 2016-09-15 16:02:34 --> Language Class Initialized
INFO - 2016-09-15 16:02:34 --> Language Class Initialized
INFO - 2016-09-15 16:02:34 --> Config Class Initialized
INFO - 2016-09-15 16:02:34 --> Loader Class Initialized
INFO - 2016-09-15 16:02:34 --> Helper loaded: url_helper
INFO - 2016-09-15 16:02:34 --> Database Driver Class Initialized
INFO - 2016-09-15 16:02:34 --> Controller Class Initialized
DEBUG - 2016-09-15 16:02:34 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:02:34 --> Model Class Initialized
INFO - 2016-09-15 16:02:34 --> Model Class Initialized
DEBUG - 2016-09-15 16:02:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 16:02:34 --> Final output sent to browser
DEBUG - 2016-09-15 16:02:34 --> Total execution time: 0.9088
INFO - 2016-09-15 16:02:35 --> Config Class Initialized
INFO - 2016-09-15 16:02:35 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:02:35 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:02:35 --> Utf8 Class Initialized
INFO - 2016-09-15 16:02:35 --> URI Class Initialized
INFO - 2016-09-15 16:02:35 --> Router Class Initialized
INFO - 2016-09-15 16:02:35 --> Output Class Initialized
INFO - 2016-09-15 16:02:35 --> Security Class Initialized
DEBUG - 2016-09-15 16:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:02:35 --> Input Class Initialized
INFO - 2016-09-15 16:02:35 --> Language Class Initialized
INFO - 2016-09-15 16:02:35 --> Language Class Initialized
INFO - 2016-09-15 16:02:35 --> Config Class Initialized
INFO - 2016-09-15 16:02:35 --> Loader Class Initialized
INFO - 2016-09-15 16:02:35 --> Helper loaded: url_helper
INFO - 2016-09-15 16:02:35 --> Database Driver Class Initialized
INFO - 2016-09-15 16:02:35 --> Controller Class Initialized
DEBUG - 2016-09-15 16:02:35 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:02:35 --> Model Class Initialized
INFO - 2016-09-15 16:02:35 --> Model Class Initialized
DEBUG - 2016-09-15 16:02:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 16:02:35 --> Final output sent to browser
DEBUG - 2016-09-15 16:02:35 --> Total execution time: 0.7942
INFO - 2016-09-15 16:03:12 --> Config Class Initialized
INFO - 2016-09-15 16:03:12 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:03:12 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:03:13 --> Utf8 Class Initialized
INFO - 2016-09-15 16:03:13 --> URI Class Initialized
INFO - 2016-09-15 16:03:13 --> Router Class Initialized
INFO - 2016-09-15 16:03:13 --> Output Class Initialized
INFO - 2016-09-15 16:03:13 --> Security Class Initialized
DEBUG - 2016-09-15 16:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:03:13 --> Input Class Initialized
INFO - 2016-09-15 16:03:13 --> Language Class Initialized
INFO - 2016-09-15 16:03:13 --> Language Class Initialized
INFO - 2016-09-15 16:03:13 --> Config Class Initialized
INFO - 2016-09-15 16:03:14 --> Loader Class Initialized
INFO - 2016-09-15 16:03:14 --> Helper loaded: url_helper
INFO - 2016-09-15 16:03:14 --> Database Driver Class Initialized
INFO - 2016-09-15 16:03:14 --> Controller Class Initialized
DEBUG - 2016-09-15 16:03:14 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:03:14 --> Model Class Initialized
INFO - 2016-09-15 16:03:14 --> Model Class Initialized
DEBUG - 2016-09-15 16:03:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 16:03:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 16:03:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 16:03:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_peminjam.php
DEBUG - 2016-09-15 16:03:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 16:03:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 16:03:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 16:03:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 16:03:14 --> Final output sent to browser
DEBUG - 2016-09-15 16:03:15 --> Total execution time: 2.2819
INFO - 2016-09-15 16:03:26 --> Config Class Initialized
INFO - 2016-09-15 16:03:26 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:03:27 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:03:27 --> Utf8 Class Initialized
INFO - 2016-09-15 16:03:27 --> URI Class Initialized
INFO - 2016-09-15 16:03:27 --> Router Class Initialized
INFO - 2016-09-15 16:03:27 --> Output Class Initialized
INFO - 2016-09-15 16:03:27 --> Security Class Initialized
DEBUG - 2016-09-15 16:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:03:27 --> Input Class Initialized
INFO - 2016-09-15 16:03:28 --> Language Class Initialized
INFO - 2016-09-15 16:03:28 --> Language Class Initialized
INFO - 2016-09-15 16:03:28 --> Config Class Initialized
INFO - 2016-09-15 16:03:28 --> Loader Class Initialized
INFO - 2016-09-15 16:03:28 --> Helper loaded: url_helper
INFO - 2016-09-15 16:03:28 --> Database Driver Class Initialized
INFO - 2016-09-15 16:03:28 --> Controller Class Initialized
DEBUG - 2016-09-15 16:03:28 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:03:28 --> Model Class Initialized
INFO - 2016-09-15 16:03:29 --> Model Class Initialized
DEBUG - 2016-09-15 16:03:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 16:03:29 --> Final output sent to browser
DEBUG - 2016-09-15 16:03:29 --> Total execution time: 2.8016
INFO - 2016-09-15 16:03:31 --> Config Class Initialized
INFO - 2016-09-15 16:03:31 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:03:31 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:03:31 --> Utf8 Class Initialized
INFO - 2016-09-15 16:03:31 --> URI Class Initialized
INFO - 2016-09-15 16:03:31 --> Router Class Initialized
INFO - 2016-09-15 16:03:31 --> Output Class Initialized
INFO - 2016-09-15 16:03:31 --> Security Class Initialized
DEBUG - 2016-09-15 16:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:03:31 --> Input Class Initialized
INFO - 2016-09-15 16:03:31 --> Language Class Initialized
INFO - 2016-09-15 16:03:31 --> Language Class Initialized
INFO - 2016-09-15 16:03:31 --> Config Class Initialized
INFO - 2016-09-15 16:03:31 --> Loader Class Initialized
INFO - 2016-09-15 16:03:31 --> Helper loaded: url_helper
INFO - 2016-09-15 16:03:32 --> Database Driver Class Initialized
INFO - 2016-09-15 16:03:32 --> Controller Class Initialized
DEBUG - 2016-09-15 16:03:32 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:03:32 --> Model Class Initialized
INFO - 2016-09-15 16:03:32 --> Model Class Initialized
DEBUG - 2016-09-15 16:03:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 16:03:32 --> Final output sent to browser
DEBUG - 2016-09-15 16:03:32 --> Total execution time: 1.0669
INFO - 2016-09-15 16:03:33 --> Config Class Initialized
INFO - 2016-09-15 16:03:33 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:03:33 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:03:33 --> Utf8 Class Initialized
INFO - 2016-09-15 16:03:33 --> URI Class Initialized
INFO - 2016-09-15 16:03:33 --> Router Class Initialized
INFO - 2016-09-15 16:03:33 --> Output Class Initialized
INFO - 2016-09-15 16:03:33 --> Security Class Initialized
DEBUG - 2016-09-15 16:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:03:33 --> Input Class Initialized
INFO - 2016-09-15 16:03:33 --> Language Class Initialized
INFO - 2016-09-15 16:03:33 --> Language Class Initialized
INFO - 2016-09-15 16:03:33 --> Config Class Initialized
INFO - 2016-09-15 16:03:33 --> Loader Class Initialized
INFO - 2016-09-15 16:03:33 --> Helper loaded: url_helper
INFO - 2016-09-15 16:03:33 --> Database Driver Class Initialized
INFO - 2016-09-15 16:03:33 --> Controller Class Initialized
DEBUG - 2016-09-15 16:03:33 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:03:33 --> Model Class Initialized
INFO - 2016-09-15 16:03:34 --> Model Class Initialized
DEBUG - 2016-09-15 16:03:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 16:03:34 --> Final output sent to browser
DEBUG - 2016-09-15 16:03:34 --> Total execution time: 1.1194
INFO - 2016-09-15 16:03:35 --> Config Class Initialized
INFO - 2016-09-15 16:03:35 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:03:35 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:03:35 --> Utf8 Class Initialized
INFO - 2016-09-15 16:03:35 --> URI Class Initialized
INFO - 2016-09-15 16:03:36 --> Router Class Initialized
INFO - 2016-09-15 16:03:36 --> Output Class Initialized
INFO - 2016-09-15 16:03:36 --> Security Class Initialized
DEBUG - 2016-09-15 16:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:03:36 --> Input Class Initialized
INFO - 2016-09-15 16:03:36 --> Language Class Initialized
INFO - 2016-09-15 16:03:36 --> Language Class Initialized
INFO - 2016-09-15 16:03:37 --> Config Class Initialized
INFO - 2016-09-15 16:03:37 --> Loader Class Initialized
INFO - 2016-09-15 16:03:37 --> Helper loaded: url_helper
INFO - 2016-09-15 16:03:37 --> Database Driver Class Initialized
INFO - 2016-09-15 16:03:38 --> Controller Class Initialized
DEBUG - 2016-09-15 16:03:38 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:03:38 --> Model Class Initialized
INFO - 2016-09-15 16:03:38 --> Model Class Initialized
ERROR - 2016-09-15 16:03:38 --> Query error: Unknown column 'f6e1126cedebf23e1463aee73f9df08783640400' in 'where clause' - Invalid query: SELECT * FROM tm_pinjaman 
                                                            LEFT JOIN tt_angsuran ON tt_angsuran.kd_pinjaman = tm_pinjaman.kd_pinjaman
                                                            WHERE sha1(tm_pinjaman.kd_pinjaman) = f6e1126cedebf23e1463aee73f9df08783640400
INFO - 2016-09-15 16:03:38 --> Language file loaded: language/english/db_lang.php
INFO - 2016-09-15 16:03:57 --> Config Class Initialized
INFO - 2016-09-15 16:03:57 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:03:57 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:03:57 --> Utf8 Class Initialized
INFO - 2016-09-15 16:03:57 --> URI Class Initialized
INFO - 2016-09-15 16:03:57 --> Router Class Initialized
INFO - 2016-09-15 16:03:57 --> Output Class Initialized
INFO - 2016-09-15 16:03:57 --> Security Class Initialized
DEBUG - 2016-09-15 16:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:03:58 --> Input Class Initialized
INFO - 2016-09-15 16:03:58 --> Language Class Initialized
INFO - 2016-09-15 16:03:58 --> Language Class Initialized
INFO - 2016-09-15 16:03:59 --> Config Class Initialized
INFO - 2016-09-15 16:03:59 --> Loader Class Initialized
INFO - 2016-09-15 16:03:59 --> Helper loaded: url_helper
INFO - 2016-09-15 16:03:59 --> Database Driver Class Initialized
INFO - 2016-09-15 16:04:00 --> Controller Class Initialized
DEBUG - 2016-09-15 16:04:00 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:04:00 --> Model Class Initialized
INFO - 2016-09-15 16:04:00 --> Model Class Initialized
ERROR - 2016-09-15 16:04:00 --> Query error: Unknown column 'f6e1126cedebf23e1463aee73f9df08783640400' in 'where clause' - Invalid query: SELECT * FROM tm_pinjaman 
                                                            LEFT JOIN tt_angsuran ON tt_angsuran.kd_pinjaman = tm_pinjaman.kd_pinjaman
                                                            WHERE sha1(tm_pinjaman.kd_pinjaman) = f6e1126cedebf23e1463aee73f9df08783640400
INFO - 2016-09-15 16:04:00 --> Language file loaded: language/english/db_lang.php
INFO - 2016-09-15 16:04:27 --> Config Class Initialized
INFO - 2016-09-15 16:04:27 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:04:27 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:04:27 --> Utf8 Class Initialized
INFO - 2016-09-15 16:04:27 --> URI Class Initialized
INFO - 2016-09-15 16:04:28 --> Router Class Initialized
INFO - 2016-09-15 16:04:28 --> Output Class Initialized
INFO - 2016-09-15 16:04:28 --> Security Class Initialized
DEBUG - 2016-09-15 16:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:04:28 --> Input Class Initialized
INFO - 2016-09-15 16:04:28 --> Language Class Initialized
INFO - 2016-09-15 16:04:28 --> Language Class Initialized
INFO - 2016-09-15 16:04:28 --> Config Class Initialized
INFO - 2016-09-15 16:04:28 --> Loader Class Initialized
INFO - 2016-09-15 16:04:28 --> Helper loaded: url_helper
INFO - 2016-09-15 16:04:28 --> Database Driver Class Initialized
INFO - 2016-09-15 16:04:29 --> Controller Class Initialized
DEBUG - 2016-09-15 16:04:29 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:04:29 --> Model Class Initialized
INFO - 2016-09-15 16:04:29 --> Model Class Initialized
DEBUG - 2016-09-15 16:04:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_transaksi.php
INFO - 2016-09-15 16:04:29 --> Final output sent to browser
DEBUG - 2016-09-15 16:04:30 --> Total execution time: 2.4766
INFO - 2016-09-15 16:04:42 --> Config Class Initialized
INFO - 2016-09-15 16:04:42 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:04:42 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:04:42 --> Utf8 Class Initialized
INFO - 2016-09-15 16:04:42 --> URI Class Initialized
INFO - 2016-09-15 16:04:42 --> Router Class Initialized
INFO - 2016-09-15 16:04:42 --> Output Class Initialized
INFO - 2016-09-15 16:04:43 --> Security Class Initialized
DEBUG - 2016-09-15 16:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:04:43 --> Input Class Initialized
INFO - 2016-09-15 16:04:43 --> Language Class Initialized
INFO - 2016-09-15 16:04:43 --> Language Class Initialized
INFO - 2016-09-15 16:04:43 --> Config Class Initialized
INFO - 2016-09-15 16:04:43 --> Loader Class Initialized
INFO - 2016-09-15 16:04:43 --> Helper loaded: url_helper
INFO - 2016-09-15 16:04:43 --> Database Driver Class Initialized
INFO - 2016-09-15 16:04:43 --> Controller Class Initialized
DEBUG - 2016-09-15 16:04:43 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:04:43 --> Model Class Initialized
INFO - 2016-09-15 16:04:43 --> Model Class Initialized
DEBUG - 2016-09-15 16:04:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_transaksi.php
INFO - 2016-09-15 16:04:44 --> Final output sent to browser
DEBUG - 2016-09-15 16:04:44 --> Total execution time: 1.4065
INFO - 2016-09-15 16:06:38 --> Config Class Initialized
INFO - 2016-09-15 16:06:38 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:06:38 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:06:38 --> Utf8 Class Initialized
INFO - 2016-09-15 16:06:38 --> URI Class Initialized
INFO - 2016-09-15 16:06:38 --> Router Class Initialized
INFO - 2016-09-15 16:06:38 --> Output Class Initialized
INFO - 2016-09-15 16:06:38 --> Security Class Initialized
DEBUG - 2016-09-15 16:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:06:38 --> Input Class Initialized
INFO - 2016-09-15 16:06:38 --> Language Class Initialized
INFO - 2016-09-15 16:06:38 --> Language Class Initialized
INFO - 2016-09-15 16:06:38 --> Config Class Initialized
INFO - 2016-09-15 16:06:38 --> Loader Class Initialized
INFO - 2016-09-15 16:06:38 --> Helper loaded: url_helper
INFO - 2016-09-15 16:06:38 --> Database Driver Class Initialized
INFO - 2016-09-15 16:06:39 --> Controller Class Initialized
DEBUG - 2016-09-15 16:06:39 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:06:39 --> Model Class Initialized
INFO - 2016-09-15 16:06:39 --> Model Class Initialized
DEBUG - 2016-09-15 16:06:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 16:06:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 16:06:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 16:06:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_peminjam.php
DEBUG - 2016-09-15 16:06:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 16:06:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 16:06:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 16:06:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 16:06:39 --> Final output sent to browser
DEBUG - 2016-09-15 16:06:39 --> Total execution time: 1.1735
INFO - 2016-09-15 16:06:47 --> Config Class Initialized
INFO - 2016-09-15 16:06:47 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:06:47 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:06:47 --> Utf8 Class Initialized
INFO - 2016-09-15 16:06:47 --> URI Class Initialized
INFO - 2016-09-15 16:06:47 --> Router Class Initialized
INFO - 2016-09-15 16:06:47 --> Output Class Initialized
INFO - 2016-09-15 16:06:47 --> Security Class Initialized
DEBUG - 2016-09-15 16:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:06:47 --> Input Class Initialized
INFO - 2016-09-15 16:06:47 --> Language Class Initialized
INFO - 2016-09-15 16:06:48 --> Language Class Initialized
INFO - 2016-09-15 16:06:48 --> Config Class Initialized
INFO - 2016-09-15 16:06:48 --> Loader Class Initialized
INFO - 2016-09-15 16:06:48 --> Helper loaded: url_helper
INFO - 2016-09-15 16:06:48 --> Database Driver Class Initialized
INFO - 2016-09-15 16:06:48 --> Controller Class Initialized
DEBUG - 2016-09-15 16:06:48 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:06:48 --> Model Class Initialized
INFO - 2016-09-15 16:06:48 --> Model Class Initialized
DEBUG - 2016-09-15 16:06:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 16:06:48 --> Final output sent to browser
DEBUG - 2016-09-15 16:06:48 --> Total execution time: 1.2199
INFO - 2016-09-15 16:06:48 --> Config Class Initialized
INFO - 2016-09-15 16:06:48 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:06:48 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:06:48 --> Utf8 Class Initialized
INFO - 2016-09-15 16:06:48 --> URI Class Initialized
INFO - 2016-09-15 16:06:48 --> Router Class Initialized
INFO - 2016-09-15 16:06:48 --> Output Class Initialized
INFO - 2016-09-15 16:06:48 --> Security Class Initialized
DEBUG - 2016-09-15 16:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:06:49 --> Input Class Initialized
INFO - 2016-09-15 16:06:49 --> Language Class Initialized
INFO - 2016-09-15 16:06:49 --> Language Class Initialized
INFO - 2016-09-15 16:06:49 --> Config Class Initialized
INFO - 2016-09-15 16:06:49 --> Loader Class Initialized
INFO - 2016-09-15 16:06:49 --> Helper loaded: url_helper
INFO - 2016-09-15 16:06:49 --> Database Driver Class Initialized
INFO - 2016-09-15 16:06:49 --> Controller Class Initialized
DEBUG - 2016-09-15 16:06:49 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:06:49 --> Model Class Initialized
INFO - 2016-09-15 16:06:49 --> Model Class Initialized
DEBUG - 2016-09-15 16:06:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 16:06:49 --> Final output sent to browser
DEBUG - 2016-09-15 16:06:49 --> Total execution time: 0.7425
INFO - 2016-09-15 16:06:50 --> Config Class Initialized
INFO - 2016-09-15 16:06:51 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:06:51 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:06:51 --> Utf8 Class Initialized
INFO - 2016-09-15 16:06:51 --> URI Class Initialized
INFO - 2016-09-15 16:06:51 --> Router Class Initialized
INFO - 2016-09-15 16:06:51 --> Output Class Initialized
INFO - 2016-09-15 16:06:51 --> Security Class Initialized
DEBUG - 2016-09-15 16:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:06:51 --> Input Class Initialized
INFO - 2016-09-15 16:06:51 --> Language Class Initialized
INFO - 2016-09-15 16:06:51 --> Language Class Initialized
INFO - 2016-09-15 16:06:51 --> Config Class Initialized
INFO - 2016-09-15 16:06:51 --> Loader Class Initialized
INFO - 2016-09-15 16:06:51 --> Helper loaded: url_helper
INFO - 2016-09-15 16:06:51 --> Database Driver Class Initialized
INFO - 2016-09-15 16:06:51 --> Controller Class Initialized
DEBUG - 2016-09-15 16:06:51 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:06:51 --> Model Class Initialized
INFO - 2016-09-15 16:06:51 --> Model Class Initialized
DEBUG - 2016-09-15 16:06:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_transaksi.php
INFO - 2016-09-15 16:06:52 --> Final output sent to browser
DEBUG - 2016-09-15 16:06:52 --> Total execution time: 1.2778
INFO - 2016-09-15 16:06:57 --> Config Class Initialized
INFO - 2016-09-15 16:06:58 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:06:58 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:06:58 --> Utf8 Class Initialized
INFO - 2016-09-15 16:06:58 --> URI Class Initialized
INFO - 2016-09-15 16:06:58 --> Router Class Initialized
INFO - 2016-09-15 16:06:58 --> Output Class Initialized
INFO - 2016-09-15 16:06:58 --> Security Class Initialized
DEBUG - 2016-09-15 16:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:06:58 --> Input Class Initialized
INFO - 2016-09-15 16:06:58 --> Language Class Initialized
INFO - 2016-09-15 16:06:58 --> Language Class Initialized
INFO - 2016-09-15 16:06:58 --> Config Class Initialized
INFO - 2016-09-15 16:06:58 --> Loader Class Initialized
INFO - 2016-09-15 16:06:58 --> Helper loaded: url_helper
INFO - 2016-09-15 16:06:58 --> Database Driver Class Initialized
INFO - 2016-09-15 16:06:59 --> Controller Class Initialized
DEBUG - 2016-09-15 16:06:59 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:06:59 --> Model Class Initialized
INFO - 2016-09-15 16:06:59 --> Model Class Initialized
DEBUG - 2016-09-15 16:06:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_transaksi.php
INFO - 2016-09-15 16:06:59 --> Final output sent to browser
DEBUG - 2016-09-15 16:06:59 --> Total execution time: 1.4184
INFO - 2016-09-15 16:10:10 --> Config Class Initialized
INFO - 2016-09-15 16:10:10 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:10:10 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:10:10 --> Utf8 Class Initialized
INFO - 2016-09-15 16:10:10 --> URI Class Initialized
INFO - 2016-09-15 16:10:10 --> Router Class Initialized
INFO - 2016-09-15 16:10:10 --> Output Class Initialized
INFO - 2016-09-15 16:10:10 --> Security Class Initialized
DEBUG - 2016-09-15 16:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:10:10 --> Input Class Initialized
INFO - 2016-09-15 16:10:10 --> Language Class Initialized
INFO - 2016-09-15 16:10:10 --> Language Class Initialized
INFO - 2016-09-15 16:10:10 --> Config Class Initialized
INFO - 2016-09-15 16:10:10 --> Loader Class Initialized
INFO - 2016-09-15 16:10:10 --> Helper loaded: url_helper
INFO - 2016-09-15 16:10:10 --> Database Driver Class Initialized
INFO - 2016-09-15 16:10:10 --> Controller Class Initialized
DEBUG - 2016-09-15 16:10:10 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:10:11 --> Model Class Initialized
INFO - 2016-09-15 16:10:11 --> Model Class Initialized
DEBUG - 2016-09-15 16:10:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_transaksi.php
INFO - 2016-09-15 16:10:11 --> Final output sent to browser
DEBUG - 2016-09-15 16:10:11 --> Total execution time: 1.0219
INFO - 2016-09-15 16:10:11 --> Config Class Initialized
INFO - 2016-09-15 16:10:11 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:10:11 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:10:11 --> Utf8 Class Initialized
INFO - 2016-09-15 16:10:11 --> URI Class Initialized
INFO - 2016-09-15 16:10:11 --> Router Class Initialized
INFO - 2016-09-15 16:10:11 --> Output Class Initialized
INFO - 2016-09-15 16:10:11 --> Security Class Initialized
DEBUG - 2016-09-15 16:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:10:11 --> Input Class Initialized
INFO - 2016-09-15 16:10:11 --> Language Class Initialized
INFO - 2016-09-15 16:10:11 --> Language Class Initialized
INFO - 2016-09-15 16:10:11 --> Config Class Initialized
INFO - 2016-09-15 16:10:11 --> Loader Class Initialized
INFO - 2016-09-15 16:10:11 --> Helper loaded: url_helper
INFO - 2016-09-15 16:10:11 --> Database Driver Class Initialized
INFO - 2016-09-15 16:10:11 --> Controller Class Initialized
ERROR - 2016-09-15 16:10:11 --> 404 Page Not Found: ../modules/admin/controllers/Index/images
INFO - 2016-09-15 16:10:18 --> Config Class Initialized
INFO - 2016-09-15 16:10:18 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:10:18 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:10:18 --> Utf8 Class Initialized
INFO - 2016-09-15 16:10:18 --> URI Class Initialized
INFO - 2016-09-15 16:10:18 --> Router Class Initialized
INFO - 2016-09-15 16:10:18 --> Output Class Initialized
INFO - 2016-09-15 16:10:18 --> Security Class Initialized
DEBUG - 2016-09-15 16:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:10:18 --> Input Class Initialized
INFO - 2016-09-15 16:10:19 --> Language Class Initialized
INFO - 2016-09-15 16:10:19 --> Language Class Initialized
INFO - 2016-09-15 16:10:19 --> Config Class Initialized
INFO - 2016-09-15 16:10:19 --> Loader Class Initialized
INFO - 2016-09-15 16:10:19 --> Helper loaded: url_helper
INFO - 2016-09-15 16:10:19 --> Database Driver Class Initialized
INFO - 2016-09-15 16:10:19 --> Controller Class Initialized
DEBUG - 2016-09-15 16:10:19 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:10:19 --> Model Class Initialized
INFO - 2016-09-15 16:10:19 --> Model Class Initialized
DEBUG - 2016-09-15 16:10:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_transaksi.php
INFO - 2016-09-15 16:10:19 --> Final output sent to browser
DEBUG - 2016-09-15 16:10:19 --> Total execution time: 1.2138
INFO - 2016-09-15 16:10:19 --> Config Class Initialized
INFO - 2016-09-15 16:10:19 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:10:19 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:10:19 --> Utf8 Class Initialized
INFO - 2016-09-15 16:10:19 --> URI Class Initialized
INFO - 2016-09-15 16:10:19 --> Router Class Initialized
INFO - 2016-09-15 16:10:20 --> Output Class Initialized
INFO - 2016-09-15 16:10:20 --> Security Class Initialized
DEBUG - 2016-09-15 16:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:10:20 --> Input Class Initialized
INFO - 2016-09-15 16:10:20 --> Language Class Initialized
INFO - 2016-09-15 16:10:20 --> Language Class Initialized
INFO - 2016-09-15 16:10:20 --> Config Class Initialized
INFO - 2016-09-15 16:10:20 --> Loader Class Initialized
INFO - 2016-09-15 16:10:20 --> Helper loaded: url_helper
INFO - 2016-09-15 16:10:20 --> Database Driver Class Initialized
INFO - 2016-09-15 16:10:20 --> Controller Class Initialized
ERROR - 2016-09-15 16:10:20 --> 404 Page Not Found: ../modules/admin/controllers/Index/images
INFO - 2016-09-15 16:10:46 --> Config Class Initialized
INFO - 2016-09-15 16:10:46 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:10:46 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:10:46 --> Utf8 Class Initialized
INFO - 2016-09-15 16:10:46 --> URI Class Initialized
INFO - 2016-09-15 16:10:46 --> Router Class Initialized
INFO - 2016-09-15 16:10:46 --> Output Class Initialized
INFO - 2016-09-15 16:10:46 --> Security Class Initialized
DEBUG - 2016-09-15 16:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:10:46 --> Input Class Initialized
INFO - 2016-09-15 16:10:46 --> Language Class Initialized
INFO - 2016-09-15 16:10:46 --> Language Class Initialized
INFO - 2016-09-15 16:10:46 --> Config Class Initialized
INFO - 2016-09-15 16:10:47 --> Loader Class Initialized
INFO - 2016-09-15 16:10:47 --> Helper loaded: url_helper
INFO - 2016-09-15 16:10:47 --> Database Driver Class Initialized
INFO - 2016-09-15 16:10:47 --> Controller Class Initialized
DEBUG - 2016-09-15 16:10:47 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:10:47 --> Model Class Initialized
INFO - 2016-09-15 16:10:47 --> Model Class Initialized
DEBUG - 2016-09-15 16:10:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_transaksi.php
INFO - 2016-09-15 16:10:47 --> Final output sent to browser
DEBUG - 2016-09-15 16:10:47 --> Total execution time: 1.1119
INFO - 2016-09-15 16:10:47 --> Config Class Initialized
INFO - 2016-09-15 16:10:47 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:10:47 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:10:47 --> Utf8 Class Initialized
INFO - 2016-09-15 16:10:47 --> URI Class Initialized
INFO - 2016-09-15 16:10:47 --> Router Class Initialized
INFO - 2016-09-15 16:10:47 --> Output Class Initialized
INFO - 2016-09-15 16:10:47 --> Security Class Initialized
DEBUG - 2016-09-15 16:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:10:47 --> Input Class Initialized
INFO - 2016-09-15 16:10:47 --> Language Class Initialized
INFO - 2016-09-15 16:10:47 --> Language Class Initialized
INFO - 2016-09-15 16:10:47 --> Config Class Initialized
INFO - 2016-09-15 16:10:47 --> Loader Class Initialized
INFO - 2016-09-15 16:10:47 --> Helper loaded: url_helper
INFO - 2016-09-15 16:10:47 --> Database Driver Class Initialized
INFO - 2016-09-15 16:10:47 --> Controller Class Initialized
ERROR - 2016-09-15 16:10:48 --> 404 Page Not Found: ../modules/admin/controllers/Index/images
INFO - 2016-09-15 16:11:11 --> Config Class Initialized
INFO - 2016-09-15 16:11:11 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:11:11 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:11:11 --> Utf8 Class Initialized
INFO - 2016-09-15 16:11:11 --> URI Class Initialized
INFO - 2016-09-15 16:11:11 --> Router Class Initialized
INFO - 2016-09-15 16:11:11 --> Output Class Initialized
INFO - 2016-09-15 16:11:11 --> Security Class Initialized
DEBUG - 2016-09-15 16:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:11:11 --> Input Class Initialized
INFO - 2016-09-15 16:11:11 --> Language Class Initialized
INFO - 2016-09-15 16:11:11 --> Language Class Initialized
INFO - 2016-09-15 16:11:11 --> Config Class Initialized
INFO - 2016-09-15 16:11:12 --> Loader Class Initialized
INFO - 2016-09-15 16:11:12 --> Helper loaded: url_helper
INFO - 2016-09-15 16:11:12 --> Database Driver Class Initialized
INFO - 2016-09-15 16:11:12 --> Controller Class Initialized
DEBUG - 2016-09-15 16:11:12 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:11:12 --> Model Class Initialized
INFO - 2016-09-15 16:11:12 --> Model Class Initialized
DEBUG - 2016-09-15 16:11:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_transaksi.php
INFO - 2016-09-15 16:11:12 --> Final output sent to browser
DEBUG - 2016-09-15 16:11:12 --> Total execution time: 0.9843
INFO - 2016-09-15 16:11:12 --> Config Class Initialized
INFO - 2016-09-15 16:11:12 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:11:12 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:11:12 --> Utf8 Class Initialized
INFO - 2016-09-15 16:11:12 --> URI Class Initialized
INFO - 2016-09-15 16:11:12 --> Router Class Initialized
INFO - 2016-09-15 16:11:12 --> Output Class Initialized
INFO - 2016-09-15 16:11:12 --> Security Class Initialized
DEBUG - 2016-09-15 16:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:11:12 --> Input Class Initialized
INFO - 2016-09-15 16:11:12 --> Language Class Initialized
INFO - 2016-09-15 16:11:12 --> Language Class Initialized
INFO - 2016-09-15 16:11:12 --> Config Class Initialized
INFO - 2016-09-15 16:11:12 --> Loader Class Initialized
INFO - 2016-09-15 16:11:12 --> Helper loaded: url_helper
INFO - 2016-09-15 16:11:12 --> Database Driver Class Initialized
INFO - 2016-09-15 16:11:12 --> Controller Class Initialized
ERROR - 2016-09-15 16:11:13 --> 404 Page Not Found: ../modules/admin/controllers/Index/images
INFO - 2016-09-15 16:14:44 --> Config Class Initialized
INFO - 2016-09-15 16:14:44 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:14:44 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:14:44 --> Utf8 Class Initialized
INFO - 2016-09-15 16:14:44 --> URI Class Initialized
INFO - 2016-09-15 16:14:44 --> Router Class Initialized
INFO - 2016-09-15 16:14:44 --> Output Class Initialized
INFO - 2016-09-15 16:14:45 --> Security Class Initialized
DEBUG - 2016-09-15 16:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:14:45 --> Input Class Initialized
INFO - 2016-09-15 16:14:45 --> Language Class Initialized
INFO - 2016-09-15 16:14:45 --> Language Class Initialized
INFO - 2016-09-15 16:14:45 --> Config Class Initialized
INFO - 2016-09-15 16:14:45 --> Loader Class Initialized
INFO - 2016-09-15 16:14:45 --> Helper loaded: url_helper
INFO - 2016-09-15 16:14:45 --> Database Driver Class Initialized
INFO - 2016-09-15 16:14:45 --> Controller Class Initialized
DEBUG - 2016-09-15 16:14:45 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:14:45 --> Model Class Initialized
INFO - 2016-09-15 16:14:45 --> Model Class Initialized
DEBUG - 2016-09-15 16:14:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_transaksi.php
INFO - 2016-09-15 16:14:45 --> Final output sent to browser
DEBUG - 2016-09-15 16:14:45 --> Total execution time: 0.7556
INFO - 2016-09-15 16:15:11 --> Config Class Initialized
INFO - 2016-09-15 16:15:11 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:15:11 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:15:11 --> Utf8 Class Initialized
INFO - 2016-09-15 16:15:11 --> URI Class Initialized
INFO - 2016-09-15 16:15:11 --> Router Class Initialized
INFO - 2016-09-15 16:15:11 --> Output Class Initialized
INFO - 2016-09-15 16:15:11 --> Security Class Initialized
DEBUG - 2016-09-15 16:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:15:12 --> Input Class Initialized
INFO - 2016-09-15 16:15:12 --> Language Class Initialized
INFO - 2016-09-15 16:15:12 --> Language Class Initialized
INFO - 2016-09-15 16:15:12 --> Config Class Initialized
INFO - 2016-09-15 16:15:12 --> Loader Class Initialized
INFO - 2016-09-15 16:15:12 --> Helper loaded: url_helper
INFO - 2016-09-15 16:15:12 --> Database Driver Class Initialized
INFO - 2016-09-15 16:15:12 --> Controller Class Initialized
DEBUG - 2016-09-15 16:15:12 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:15:12 --> Model Class Initialized
INFO - 2016-09-15 16:15:12 --> Model Class Initialized
DEBUG - 2016-09-15 16:15:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_transaksi.php
INFO - 2016-09-15 16:15:12 --> Final output sent to browser
DEBUG - 2016-09-15 16:15:12 --> Total execution time: 0.7737
INFO - 2016-09-15 16:15:34 --> Config Class Initialized
INFO - 2016-09-15 16:15:34 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:15:34 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:15:34 --> Utf8 Class Initialized
INFO - 2016-09-15 16:15:34 --> URI Class Initialized
INFO - 2016-09-15 16:15:35 --> Router Class Initialized
INFO - 2016-09-15 16:15:35 --> Output Class Initialized
INFO - 2016-09-15 16:15:35 --> Security Class Initialized
DEBUG - 2016-09-15 16:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:15:35 --> Input Class Initialized
INFO - 2016-09-15 16:15:35 --> Language Class Initialized
INFO - 2016-09-15 16:15:35 --> Language Class Initialized
INFO - 2016-09-15 16:15:35 --> Config Class Initialized
INFO - 2016-09-15 16:15:35 --> Loader Class Initialized
INFO - 2016-09-15 16:15:35 --> Helper loaded: url_helper
INFO - 2016-09-15 16:15:35 --> Database Driver Class Initialized
INFO - 2016-09-15 16:15:35 --> Controller Class Initialized
DEBUG - 2016-09-15 16:15:35 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:15:35 --> Model Class Initialized
INFO - 2016-09-15 16:15:35 --> Model Class Initialized
DEBUG - 2016-09-15 16:15:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_transaksi.php
INFO - 2016-09-15 16:15:35 --> Final output sent to browser
DEBUG - 2016-09-15 16:15:35 --> Total execution time: 0.7709
INFO - 2016-09-15 16:15:40 --> Config Class Initialized
INFO - 2016-09-15 16:15:40 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:15:40 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:15:40 --> Utf8 Class Initialized
INFO - 2016-09-15 16:15:40 --> URI Class Initialized
INFO - 2016-09-15 16:15:40 --> Router Class Initialized
INFO - 2016-09-15 16:15:40 --> Output Class Initialized
INFO - 2016-09-15 16:15:40 --> Security Class Initialized
DEBUG - 2016-09-15 16:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:15:40 --> Input Class Initialized
INFO - 2016-09-15 16:15:40 --> Language Class Initialized
INFO - 2016-09-15 16:15:40 --> Language Class Initialized
INFO - 2016-09-15 16:15:40 --> Config Class Initialized
INFO - 2016-09-15 16:15:40 --> Loader Class Initialized
INFO - 2016-09-15 16:15:40 --> Helper loaded: url_helper
INFO - 2016-09-15 16:15:40 --> Database Driver Class Initialized
INFO - 2016-09-15 16:15:40 --> Controller Class Initialized
DEBUG - 2016-09-15 16:15:40 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:15:40 --> Model Class Initialized
INFO - 2016-09-15 16:15:41 --> Model Class Initialized
DEBUG - 2016-09-15 16:15:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_transaksi.php
INFO - 2016-09-15 16:15:41 --> Final output sent to browser
DEBUG - 2016-09-15 16:15:41 --> Total execution time: 0.7862
INFO - 2016-09-15 16:15:58 --> Config Class Initialized
INFO - 2016-09-15 16:15:58 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:15:58 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:15:58 --> Utf8 Class Initialized
INFO - 2016-09-15 16:15:58 --> URI Class Initialized
INFO - 2016-09-15 16:15:58 --> Router Class Initialized
INFO - 2016-09-15 16:15:58 --> Output Class Initialized
INFO - 2016-09-15 16:15:58 --> Security Class Initialized
DEBUG - 2016-09-15 16:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:15:58 --> Input Class Initialized
INFO - 2016-09-15 16:15:59 --> Language Class Initialized
INFO - 2016-09-15 16:15:59 --> Language Class Initialized
INFO - 2016-09-15 16:15:59 --> Config Class Initialized
INFO - 2016-09-15 16:15:59 --> Loader Class Initialized
INFO - 2016-09-15 16:15:59 --> Helper loaded: url_helper
INFO - 2016-09-15 16:15:59 --> Database Driver Class Initialized
INFO - 2016-09-15 16:15:59 --> Controller Class Initialized
DEBUG - 2016-09-15 16:15:59 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:15:59 --> Model Class Initialized
INFO - 2016-09-15 16:15:59 --> Model Class Initialized
DEBUG - 2016-09-15 16:15:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_transaksi.php
INFO - 2016-09-15 16:15:59 --> Final output sent to browser
DEBUG - 2016-09-15 16:15:59 --> Total execution time: 0.7495
INFO - 2016-09-15 16:16:08 --> Config Class Initialized
INFO - 2016-09-15 16:16:08 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:16:08 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:16:08 --> Utf8 Class Initialized
INFO - 2016-09-15 16:16:08 --> URI Class Initialized
INFO - 2016-09-15 16:16:09 --> Router Class Initialized
INFO - 2016-09-15 16:16:09 --> Output Class Initialized
INFO - 2016-09-15 16:16:09 --> Security Class Initialized
DEBUG - 2016-09-15 16:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:16:09 --> Input Class Initialized
INFO - 2016-09-15 16:16:09 --> Language Class Initialized
INFO - 2016-09-15 16:16:09 --> Language Class Initialized
INFO - 2016-09-15 16:16:09 --> Config Class Initialized
INFO - 2016-09-15 16:16:09 --> Loader Class Initialized
INFO - 2016-09-15 16:16:09 --> Helper loaded: url_helper
INFO - 2016-09-15 16:16:09 --> Database Driver Class Initialized
INFO - 2016-09-15 16:16:09 --> Controller Class Initialized
DEBUG - 2016-09-15 16:16:09 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:16:09 --> Model Class Initialized
INFO - 2016-09-15 16:16:09 --> Model Class Initialized
DEBUG - 2016-09-15 16:16:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_transaksi.php
INFO - 2016-09-15 16:16:09 --> Final output sent to browser
DEBUG - 2016-09-15 16:16:09 --> Total execution time: 0.7633
INFO - 2016-09-15 16:16:13 --> Config Class Initialized
INFO - 2016-09-15 16:16:13 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:16:13 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:16:13 --> Utf8 Class Initialized
INFO - 2016-09-15 16:16:13 --> URI Class Initialized
INFO - 2016-09-15 16:16:13 --> Router Class Initialized
INFO - 2016-09-15 16:16:13 --> Output Class Initialized
INFO - 2016-09-15 16:16:13 --> Security Class Initialized
DEBUG - 2016-09-15 16:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:16:13 --> Input Class Initialized
INFO - 2016-09-15 16:16:13 --> Language Class Initialized
INFO - 2016-09-15 16:16:13 --> Language Class Initialized
INFO - 2016-09-15 16:16:13 --> Config Class Initialized
INFO - 2016-09-15 16:16:13 --> Loader Class Initialized
INFO - 2016-09-15 16:16:13 --> Helper loaded: url_helper
INFO - 2016-09-15 16:16:13 --> Database Driver Class Initialized
INFO - 2016-09-15 16:16:13 --> Controller Class Initialized
DEBUG - 2016-09-15 16:16:13 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:16:13 --> Model Class Initialized
INFO - 2016-09-15 16:16:13 --> Model Class Initialized
DEBUG - 2016-09-15 16:16:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_transaksi.php
INFO - 2016-09-15 16:16:14 --> Final output sent to browser
DEBUG - 2016-09-15 16:16:14 --> Total execution time: 0.7760
INFO - 2016-09-15 16:16:25 --> Config Class Initialized
INFO - 2016-09-15 16:16:25 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:16:25 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:16:25 --> Utf8 Class Initialized
INFO - 2016-09-15 16:16:25 --> URI Class Initialized
INFO - 2016-09-15 16:16:25 --> Router Class Initialized
INFO - 2016-09-15 16:16:25 --> Output Class Initialized
INFO - 2016-09-15 16:16:25 --> Security Class Initialized
DEBUG - 2016-09-15 16:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:16:25 --> Input Class Initialized
INFO - 2016-09-15 16:16:25 --> Language Class Initialized
INFO - 2016-09-15 16:16:25 --> Language Class Initialized
INFO - 2016-09-15 16:16:25 --> Config Class Initialized
INFO - 2016-09-15 16:16:25 --> Loader Class Initialized
INFO - 2016-09-15 16:16:25 --> Helper loaded: url_helper
INFO - 2016-09-15 16:16:25 --> Database Driver Class Initialized
INFO - 2016-09-15 16:16:25 --> Controller Class Initialized
DEBUG - 2016-09-15 16:16:25 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:16:25 --> Model Class Initialized
INFO - 2016-09-15 16:16:25 --> Model Class Initialized
DEBUG - 2016-09-15 16:16:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_transaksi.php
INFO - 2016-09-15 16:16:25 --> Final output sent to browser
DEBUG - 2016-09-15 16:16:25 --> Total execution time: 0.7554
INFO - 2016-09-15 16:16:28 --> Config Class Initialized
INFO - 2016-09-15 16:16:28 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:16:28 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:16:28 --> Utf8 Class Initialized
INFO - 2016-09-15 16:16:28 --> URI Class Initialized
INFO - 2016-09-15 16:16:28 --> Router Class Initialized
INFO - 2016-09-15 16:16:28 --> Output Class Initialized
INFO - 2016-09-15 16:16:28 --> Security Class Initialized
DEBUG - 2016-09-15 16:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:16:28 --> Input Class Initialized
INFO - 2016-09-15 16:16:28 --> Language Class Initialized
INFO - 2016-09-15 16:16:28 --> Language Class Initialized
INFO - 2016-09-15 16:16:29 --> Config Class Initialized
INFO - 2016-09-15 16:16:29 --> Loader Class Initialized
INFO - 2016-09-15 16:16:29 --> Helper loaded: url_helper
INFO - 2016-09-15 16:16:29 --> Database Driver Class Initialized
INFO - 2016-09-15 16:16:29 --> Controller Class Initialized
DEBUG - 2016-09-15 16:16:29 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:16:29 --> Model Class Initialized
INFO - 2016-09-15 16:16:29 --> Model Class Initialized
DEBUG - 2016-09-15 16:16:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_transaksi.php
INFO - 2016-09-15 16:16:29 --> Final output sent to browser
DEBUG - 2016-09-15 16:16:29 --> Total execution time: 0.8355
INFO - 2016-09-15 16:16:34 --> Config Class Initialized
INFO - 2016-09-15 16:16:34 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:16:34 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:16:34 --> Utf8 Class Initialized
INFO - 2016-09-15 16:16:34 --> URI Class Initialized
INFO - 2016-09-15 16:16:34 --> Router Class Initialized
INFO - 2016-09-15 16:16:34 --> Output Class Initialized
INFO - 2016-09-15 16:16:34 --> Security Class Initialized
DEBUG - 2016-09-15 16:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:16:34 --> Input Class Initialized
INFO - 2016-09-15 16:16:34 --> Language Class Initialized
INFO - 2016-09-15 16:16:35 --> Language Class Initialized
INFO - 2016-09-15 16:16:35 --> Config Class Initialized
INFO - 2016-09-15 16:16:35 --> Loader Class Initialized
INFO - 2016-09-15 16:16:35 --> Helper loaded: url_helper
INFO - 2016-09-15 16:16:35 --> Database Driver Class Initialized
INFO - 2016-09-15 16:16:35 --> Controller Class Initialized
DEBUG - 2016-09-15 16:16:35 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:16:35 --> Model Class Initialized
INFO - 2016-09-15 16:16:35 --> Model Class Initialized
DEBUG - 2016-09-15 16:16:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_transaksi.php
INFO - 2016-09-15 16:16:35 --> Final output sent to browser
DEBUG - 2016-09-15 16:16:35 --> Total execution time: 0.7826
INFO - 2016-09-15 16:16:59 --> Config Class Initialized
INFO - 2016-09-15 16:17:00 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:17:00 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:17:00 --> Utf8 Class Initialized
INFO - 2016-09-15 16:17:00 --> URI Class Initialized
INFO - 2016-09-15 16:17:00 --> Router Class Initialized
INFO - 2016-09-15 16:17:00 --> Output Class Initialized
INFO - 2016-09-15 16:17:00 --> Security Class Initialized
DEBUG - 2016-09-15 16:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:17:00 --> Input Class Initialized
INFO - 2016-09-15 16:17:00 --> Language Class Initialized
INFO - 2016-09-15 16:17:00 --> Language Class Initialized
INFO - 2016-09-15 16:17:00 --> Config Class Initialized
INFO - 2016-09-15 16:17:00 --> Loader Class Initialized
INFO - 2016-09-15 16:17:00 --> Helper loaded: url_helper
INFO - 2016-09-15 16:17:00 --> Database Driver Class Initialized
INFO - 2016-09-15 16:17:00 --> Controller Class Initialized
DEBUG - 2016-09-15 16:17:00 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:17:00 --> Model Class Initialized
INFO - 2016-09-15 16:17:00 --> Model Class Initialized
DEBUG - 2016-09-15 16:17:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_transaksi.php
INFO - 2016-09-15 16:17:00 --> Final output sent to browser
DEBUG - 2016-09-15 16:17:00 --> Total execution time: 0.8107
INFO - 2016-09-15 16:17:08 --> Config Class Initialized
INFO - 2016-09-15 16:17:08 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:17:08 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:17:08 --> Utf8 Class Initialized
INFO - 2016-09-15 16:17:08 --> URI Class Initialized
INFO - 2016-09-15 16:17:08 --> Router Class Initialized
INFO - 2016-09-15 16:17:08 --> Output Class Initialized
INFO - 2016-09-15 16:17:08 --> Security Class Initialized
DEBUG - 2016-09-15 16:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:17:08 --> Input Class Initialized
INFO - 2016-09-15 16:17:08 --> Language Class Initialized
INFO - 2016-09-15 16:17:08 --> Language Class Initialized
INFO - 2016-09-15 16:17:09 --> Config Class Initialized
INFO - 2016-09-15 16:17:09 --> Loader Class Initialized
INFO - 2016-09-15 16:17:09 --> Helper loaded: url_helper
INFO - 2016-09-15 16:17:09 --> Database Driver Class Initialized
INFO - 2016-09-15 16:17:09 --> Controller Class Initialized
DEBUG - 2016-09-15 16:17:09 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:17:09 --> Model Class Initialized
INFO - 2016-09-15 16:17:09 --> Model Class Initialized
DEBUG - 2016-09-15 16:17:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_transaksi.php
INFO - 2016-09-15 16:17:09 --> Final output sent to browser
DEBUG - 2016-09-15 16:17:09 --> Total execution time: 0.7621
INFO - 2016-09-15 16:17:24 --> Config Class Initialized
INFO - 2016-09-15 16:17:24 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:17:24 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:17:24 --> Utf8 Class Initialized
INFO - 2016-09-15 16:17:24 --> URI Class Initialized
INFO - 2016-09-15 16:17:24 --> Router Class Initialized
INFO - 2016-09-15 16:17:24 --> Output Class Initialized
INFO - 2016-09-15 16:17:24 --> Security Class Initialized
DEBUG - 2016-09-15 16:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:17:24 --> Input Class Initialized
INFO - 2016-09-15 16:17:24 --> Language Class Initialized
INFO - 2016-09-15 16:17:24 --> Language Class Initialized
INFO - 2016-09-15 16:17:24 --> Config Class Initialized
INFO - 2016-09-15 16:17:24 --> Loader Class Initialized
INFO - 2016-09-15 16:17:24 --> Helper loaded: url_helper
INFO - 2016-09-15 16:17:24 --> Database Driver Class Initialized
INFO - 2016-09-15 16:17:24 --> Controller Class Initialized
DEBUG - 2016-09-15 16:17:24 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:17:24 --> Model Class Initialized
INFO - 2016-09-15 16:17:24 --> Model Class Initialized
DEBUG - 2016-09-15 16:17:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_transaksi.php
INFO - 2016-09-15 16:17:24 --> Final output sent to browser
DEBUG - 2016-09-15 16:17:24 --> Total execution time: 0.7640
INFO - 2016-09-15 16:17:49 --> Config Class Initialized
INFO - 2016-09-15 16:17:49 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:17:49 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:17:49 --> Utf8 Class Initialized
INFO - 2016-09-15 16:17:49 --> URI Class Initialized
INFO - 2016-09-15 16:17:49 --> Router Class Initialized
INFO - 2016-09-15 16:17:49 --> Output Class Initialized
INFO - 2016-09-15 16:17:49 --> Security Class Initialized
DEBUG - 2016-09-15 16:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:17:49 --> Input Class Initialized
INFO - 2016-09-15 16:17:49 --> Language Class Initialized
INFO - 2016-09-15 16:17:49 --> Language Class Initialized
INFO - 2016-09-15 16:17:49 --> Config Class Initialized
INFO - 2016-09-15 16:17:49 --> Loader Class Initialized
INFO - 2016-09-15 16:17:49 --> Helper loaded: url_helper
INFO - 2016-09-15 16:17:49 --> Database Driver Class Initialized
INFO - 2016-09-15 16:17:50 --> Controller Class Initialized
DEBUG - 2016-09-15 16:17:50 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:17:50 --> Model Class Initialized
INFO - 2016-09-15 16:17:50 --> Model Class Initialized
DEBUG - 2016-09-15 16:17:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_transaksi.php
INFO - 2016-09-15 16:17:50 --> Final output sent to browser
DEBUG - 2016-09-15 16:17:50 --> Total execution time: 0.7640
INFO - 2016-09-15 16:20:14 --> Config Class Initialized
INFO - 2016-09-15 16:20:14 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:20:14 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:20:14 --> Utf8 Class Initialized
INFO - 2016-09-15 16:20:14 --> URI Class Initialized
INFO - 2016-09-15 16:20:14 --> Router Class Initialized
INFO - 2016-09-15 16:20:14 --> Output Class Initialized
INFO - 2016-09-15 16:20:14 --> Security Class Initialized
DEBUG - 2016-09-15 16:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:20:14 --> Input Class Initialized
INFO - 2016-09-15 16:20:14 --> Language Class Initialized
INFO - 2016-09-15 16:20:14 --> Language Class Initialized
INFO - 2016-09-15 16:20:14 --> Config Class Initialized
INFO - 2016-09-15 16:20:14 --> Loader Class Initialized
INFO - 2016-09-15 16:20:14 --> Helper loaded: url_helper
INFO - 2016-09-15 16:20:14 --> Database Driver Class Initialized
INFO - 2016-09-15 16:20:14 --> Controller Class Initialized
DEBUG - 2016-09-15 16:20:14 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:20:14 --> Model Class Initialized
INFO - 2016-09-15 16:20:14 --> Model Class Initialized
DEBUG - 2016-09-15 16:20:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 16:20:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 16:20:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 16:20:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_bayar_angsuran.php
DEBUG - 2016-09-15 16:20:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 16:20:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 16:20:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 16:20:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 16:20:15 --> Final output sent to browser
DEBUG - 2016-09-15 16:20:15 --> Total execution time: 0.8658
INFO - 2016-09-15 16:20:18 --> Config Class Initialized
INFO - 2016-09-15 16:20:18 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:20:18 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:20:18 --> Utf8 Class Initialized
INFO - 2016-09-15 16:20:18 --> URI Class Initialized
INFO - 2016-09-15 16:20:18 --> Router Class Initialized
INFO - 2016-09-15 16:20:18 --> Output Class Initialized
INFO - 2016-09-15 16:20:18 --> Security Class Initialized
DEBUG - 2016-09-15 16:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:20:18 --> Input Class Initialized
INFO - 2016-09-15 16:20:19 --> Language Class Initialized
INFO - 2016-09-15 16:20:19 --> Language Class Initialized
INFO - 2016-09-15 16:20:19 --> Config Class Initialized
INFO - 2016-09-15 16:20:19 --> Loader Class Initialized
INFO - 2016-09-15 16:20:19 --> Helper loaded: url_helper
INFO - 2016-09-15 16:20:19 --> Database Driver Class Initialized
INFO - 2016-09-15 16:20:19 --> Controller Class Initialized
DEBUG - 2016-09-15 16:20:19 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:20:19 --> Model Class Initialized
INFO - 2016-09-15 16:20:19 --> Model Class Initialized
INFO - 2016-09-15 16:20:19 --> Database Driver Class Initialized
INFO - 2016-09-15 16:20:19 --> Final output sent to browser
DEBUG - 2016-09-15 16:20:19 --> Total execution time: 0.7501
INFO - 2016-09-15 16:20:34 --> Config Class Initialized
INFO - 2016-09-15 16:20:34 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:20:34 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:20:34 --> Utf8 Class Initialized
INFO - 2016-09-15 16:20:34 --> URI Class Initialized
INFO - 2016-09-15 16:20:34 --> Router Class Initialized
INFO - 2016-09-15 16:20:34 --> Output Class Initialized
INFO - 2016-09-15 16:20:34 --> Security Class Initialized
DEBUG - 2016-09-15 16:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:20:34 --> Input Class Initialized
INFO - 2016-09-15 16:20:34 --> Language Class Initialized
INFO - 2016-09-15 16:20:35 --> Language Class Initialized
INFO - 2016-09-15 16:20:35 --> Config Class Initialized
INFO - 2016-09-15 16:20:35 --> Loader Class Initialized
INFO - 2016-09-15 16:20:35 --> Helper loaded: url_helper
INFO - 2016-09-15 16:20:35 --> Database Driver Class Initialized
INFO - 2016-09-15 16:20:35 --> Controller Class Initialized
DEBUG - 2016-09-15 16:20:35 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:20:35 --> Model Class Initialized
INFO - 2016-09-15 16:20:35 --> Model Class Initialized
INFO - 2016-09-15 16:20:35 --> Database Driver Class Initialized
INFO - 2016-09-15 16:20:35 --> Final output sent to browser
DEBUG - 2016-09-15 16:20:35 --> Total execution time: 0.7449
INFO - 2016-09-15 16:20:37 --> Config Class Initialized
INFO - 2016-09-15 16:20:37 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:20:37 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:20:37 --> Utf8 Class Initialized
INFO - 2016-09-15 16:20:37 --> URI Class Initialized
INFO - 2016-09-15 16:20:37 --> Router Class Initialized
INFO - 2016-09-15 16:20:37 --> Output Class Initialized
INFO - 2016-09-15 16:20:37 --> Security Class Initialized
DEBUG - 2016-09-15 16:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:20:38 --> Input Class Initialized
INFO - 2016-09-15 16:20:38 --> Language Class Initialized
INFO - 2016-09-15 16:20:38 --> Language Class Initialized
INFO - 2016-09-15 16:20:38 --> Config Class Initialized
INFO - 2016-09-15 16:20:38 --> Loader Class Initialized
INFO - 2016-09-15 16:20:38 --> Helper loaded: url_helper
INFO - 2016-09-15 16:20:38 --> Database Driver Class Initialized
INFO - 2016-09-15 16:20:38 --> Controller Class Initialized
DEBUG - 2016-09-15 16:20:38 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:20:38 --> Model Class Initialized
INFO - 2016-09-15 16:20:38 --> Model Class Initialized
INFO - 2016-09-15 16:20:38 --> Database Driver Class Initialized
INFO - 2016-09-15 16:20:38 --> Final output sent to browser
DEBUG - 2016-09-15 16:20:38 --> Total execution time: 0.6656
INFO - 2016-09-15 16:20:39 --> Config Class Initialized
INFO - 2016-09-15 16:20:39 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:20:39 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:20:39 --> Utf8 Class Initialized
INFO - 2016-09-15 16:20:39 --> URI Class Initialized
INFO - 2016-09-15 16:20:39 --> Router Class Initialized
INFO - 2016-09-15 16:20:39 --> Output Class Initialized
INFO - 2016-09-15 16:20:39 --> Security Class Initialized
DEBUG - 2016-09-15 16:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:20:39 --> Input Class Initialized
INFO - 2016-09-15 16:20:39 --> Language Class Initialized
INFO - 2016-09-15 16:20:39 --> Language Class Initialized
INFO - 2016-09-15 16:20:40 --> Config Class Initialized
INFO - 2016-09-15 16:20:40 --> Loader Class Initialized
INFO - 2016-09-15 16:20:40 --> Helper loaded: url_helper
INFO - 2016-09-15 16:20:40 --> Database Driver Class Initialized
INFO - 2016-09-15 16:20:40 --> Controller Class Initialized
DEBUG - 2016-09-15 16:20:40 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:20:40 --> Model Class Initialized
INFO - 2016-09-15 16:20:40 --> Model Class Initialized
INFO - 2016-09-15 16:20:40 --> Database Driver Class Initialized
INFO - 2016-09-15 16:20:40 --> Final output sent to browser
DEBUG - 2016-09-15 16:20:40 --> Total execution time: 0.8560
INFO - 2016-09-15 16:20:41 --> Config Class Initialized
INFO - 2016-09-15 16:20:41 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:20:41 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:20:41 --> Utf8 Class Initialized
INFO - 2016-09-15 16:20:41 --> URI Class Initialized
INFO - 2016-09-15 16:20:41 --> Router Class Initialized
INFO - 2016-09-15 16:20:41 --> Output Class Initialized
INFO - 2016-09-15 16:20:41 --> Security Class Initialized
DEBUG - 2016-09-15 16:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:20:42 --> Input Class Initialized
INFO - 2016-09-15 16:20:42 --> Language Class Initialized
INFO - 2016-09-15 16:20:42 --> Language Class Initialized
INFO - 2016-09-15 16:20:42 --> Config Class Initialized
INFO - 2016-09-15 16:20:42 --> Loader Class Initialized
INFO - 2016-09-15 16:20:42 --> Helper loaded: url_helper
INFO - 2016-09-15 16:20:42 --> Database Driver Class Initialized
INFO - 2016-09-15 16:20:42 --> Controller Class Initialized
DEBUG - 2016-09-15 16:20:42 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:20:42 --> Model Class Initialized
INFO - 2016-09-15 16:20:42 --> Model Class Initialized
INFO - 2016-09-15 16:20:42 --> Database Driver Class Initialized
INFO - 2016-09-15 16:20:42 --> Final output sent to browser
DEBUG - 2016-09-15 16:20:42 --> Total execution time: 0.7520
INFO - 2016-09-15 16:20:43 --> Config Class Initialized
INFO - 2016-09-15 16:20:43 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:20:43 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:20:43 --> Utf8 Class Initialized
INFO - 2016-09-15 16:20:43 --> URI Class Initialized
INFO - 2016-09-15 16:20:43 --> Router Class Initialized
INFO - 2016-09-15 16:20:43 --> Output Class Initialized
INFO - 2016-09-15 16:20:43 --> Security Class Initialized
DEBUG - 2016-09-15 16:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:20:43 --> Input Class Initialized
INFO - 2016-09-15 16:20:43 --> Language Class Initialized
INFO - 2016-09-15 16:20:43 --> Language Class Initialized
INFO - 2016-09-15 16:20:43 --> Config Class Initialized
INFO - 2016-09-15 16:20:43 --> Loader Class Initialized
INFO - 2016-09-15 16:20:43 --> Helper loaded: url_helper
INFO - 2016-09-15 16:20:44 --> Database Driver Class Initialized
INFO - 2016-09-15 16:20:44 --> Controller Class Initialized
DEBUG - 2016-09-15 16:20:44 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:20:44 --> Model Class Initialized
INFO - 2016-09-15 16:20:44 --> Model Class Initialized
INFO - 2016-09-15 16:20:44 --> Database Driver Class Initialized
INFO - 2016-09-15 16:20:44 --> Final output sent to browser
DEBUG - 2016-09-15 16:20:44 --> Total execution time: 0.9712
INFO - 2016-09-15 16:20:45 --> Config Class Initialized
INFO - 2016-09-15 16:20:45 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:20:45 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:20:45 --> Utf8 Class Initialized
INFO - 2016-09-15 16:20:45 --> URI Class Initialized
INFO - 2016-09-15 16:20:45 --> Router Class Initialized
INFO - 2016-09-15 16:20:45 --> Output Class Initialized
INFO - 2016-09-15 16:20:45 --> Security Class Initialized
DEBUG - 2016-09-15 16:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:20:45 --> Input Class Initialized
INFO - 2016-09-15 16:20:45 --> Language Class Initialized
INFO - 2016-09-15 16:20:45 --> Language Class Initialized
INFO - 2016-09-15 16:20:45 --> Config Class Initialized
INFO - 2016-09-15 16:20:45 --> Loader Class Initialized
INFO - 2016-09-15 16:20:45 --> Helper loaded: url_helper
INFO - 2016-09-15 16:20:45 --> Database Driver Class Initialized
INFO - 2016-09-15 16:20:45 --> Controller Class Initialized
DEBUG - 2016-09-15 16:20:45 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:20:45 --> Model Class Initialized
INFO - 2016-09-15 16:20:46 --> Model Class Initialized
INFO - 2016-09-15 16:20:46 --> Database Driver Class Initialized
INFO - 2016-09-15 16:20:46 --> Final output sent to browser
DEBUG - 2016-09-15 16:20:46 --> Total execution time: 0.7866
INFO - 2016-09-15 16:20:46 --> Config Class Initialized
INFO - 2016-09-15 16:20:46 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:20:46 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:20:46 --> Utf8 Class Initialized
INFO - 2016-09-15 16:20:46 --> URI Class Initialized
INFO - 2016-09-15 16:20:47 --> Router Class Initialized
INFO - 2016-09-15 16:20:47 --> Output Class Initialized
INFO - 2016-09-15 16:20:47 --> Security Class Initialized
DEBUG - 2016-09-15 16:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:20:47 --> Input Class Initialized
INFO - 2016-09-15 16:20:47 --> Language Class Initialized
INFO - 2016-09-15 16:20:47 --> Language Class Initialized
INFO - 2016-09-15 16:20:47 --> Config Class Initialized
INFO - 2016-09-15 16:20:47 --> Loader Class Initialized
INFO - 2016-09-15 16:20:47 --> Helper loaded: url_helper
INFO - 2016-09-15 16:20:47 --> Database Driver Class Initialized
INFO - 2016-09-15 16:20:47 --> Controller Class Initialized
DEBUG - 2016-09-15 16:20:47 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:20:47 --> Model Class Initialized
INFO - 2016-09-15 16:20:47 --> Model Class Initialized
INFO - 2016-09-15 16:20:47 --> Database Driver Class Initialized
INFO - 2016-09-15 16:20:47 --> Final output sent to browser
DEBUG - 2016-09-15 16:20:47 --> Total execution time: 0.7336
INFO - 2016-09-15 16:20:54 --> Config Class Initialized
INFO - 2016-09-15 16:20:54 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:20:54 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:20:54 --> Utf8 Class Initialized
INFO - 2016-09-15 16:20:54 --> URI Class Initialized
INFO - 2016-09-15 16:20:54 --> Router Class Initialized
INFO - 2016-09-15 16:20:54 --> Output Class Initialized
INFO - 2016-09-15 16:20:54 --> Security Class Initialized
DEBUG - 2016-09-15 16:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:20:54 --> Input Class Initialized
INFO - 2016-09-15 16:20:54 --> Language Class Initialized
INFO - 2016-09-15 16:20:54 --> Language Class Initialized
INFO - 2016-09-15 16:20:54 --> Config Class Initialized
INFO - 2016-09-15 16:20:54 --> Loader Class Initialized
INFO - 2016-09-15 16:20:54 --> Helper loaded: url_helper
INFO - 2016-09-15 16:20:55 --> Database Driver Class Initialized
INFO - 2016-09-15 16:20:55 --> Controller Class Initialized
DEBUG - 2016-09-15 16:20:55 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:20:55 --> Model Class Initialized
INFO - 2016-09-15 16:20:55 --> Model Class Initialized
DEBUG - 2016-09-15 16:20:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 16:20:55 --> Final output sent to browser
DEBUG - 2016-09-15 16:20:55 --> Total execution time: 0.6131
INFO - 2016-09-15 16:20:55 --> Config Class Initialized
INFO - 2016-09-15 16:20:55 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:20:55 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:20:55 --> Utf8 Class Initialized
INFO - 2016-09-15 16:20:55 --> URI Class Initialized
INFO - 2016-09-15 16:20:56 --> Router Class Initialized
INFO - 2016-09-15 16:20:56 --> Output Class Initialized
INFO - 2016-09-15 16:20:56 --> Security Class Initialized
DEBUG - 2016-09-15 16:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:20:56 --> Input Class Initialized
INFO - 2016-09-15 16:20:56 --> Language Class Initialized
INFO - 2016-09-15 16:20:56 --> Language Class Initialized
INFO - 2016-09-15 16:20:56 --> Config Class Initialized
INFO - 2016-09-15 16:20:56 --> Loader Class Initialized
INFO - 2016-09-15 16:20:56 --> Helper loaded: url_helper
INFO - 2016-09-15 16:20:56 --> Database Driver Class Initialized
INFO - 2016-09-15 16:20:56 --> Controller Class Initialized
DEBUG - 2016-09-15 16:20:56 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:20:56 --> Model Class Initialized
INFO - 2016-09-15 16:20:56 --> Model Class Initialized
DEBUG - 2016-09-15 16:20:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 16:20:56 --> Final output sent to browser
DEBUG - 2016-09-15 16:20:56 --> Total execution time: 0.6412
INFO - 2016-09-15 16:20:57 --> Config Class Initialized
INFO - 2016-09-15 16:20:57 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:20:57 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:20:57 --> Utf8 Class Initialized
INFO - 2016-09-15 16:20:57 --> URI Class Initialized
INFO - 2016-09-15 16:20:57 --> Router Class Initialized
INFO - 2016-09-15 16:20:57 --> Output Class Initialized
INFO - 2016-09-15 16:20:57 --> Security Class Initialized
DEBUG - 2016-09-15 16:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:20:58 --> Input Class Initialized
INFO - 2016-09-15 16:20:58 --> Language Class Initialized
INFO - 2016-09-15 16:20:58 --> Language Class Initialized
INFO - 2016-09-15 16:20:58 --> Config Class Initialized
INFO - 2016-09-15 16:20:58 --> Loader Class Initialized
INFO - 2016-09-15 16:20:58 --> Helper loaded: url_helper
INFO - 2016-09-15 16:20:58 --> Database Driver Class Initialized
INFO - 2016-09-15 16:20:58 --> Controller Class Initialized
DEBUG - 2016-09-15 16:20:58 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:20:58 --> Model Class Initialized
INFO - 2016-09-15 16:20:58 --> Model Class Initialized
DEBUG - 2016-09-15 16:20:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_transaksi.php
INFO - 2016-09-15 16:20:58 --> Final output sent to browser
DEBUG - 2016-09-15 16:20:58 --> Total execution time: 0.8027
INFO - 2016-09-15 16:21:08 --> Config Class Initialized
INFO - 2016-09-15 16:21:08 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:21:08 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:21:08 --> Utf8 Class Initialized
INFO - 2016-09-15 16:21:08 --> URI Class Initialized
INFO - 2016-09-15 16:21:09 --> Router Class Initialized
INFO - 2016-09-15 16:21:09 --> Output Class Initialized
INFO - 2016-09-15 16:21:09 --> Security Class Initialized
DEBUG - 2016-09-15 16:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:21:09 --> Input Class Initialized
INFO - 2016-09-15 16:21:09 --> Language Class Initialized
INFO - 2016-09-15 16:21:09 --> Language Class Initialized
INFO - 2016-09-15 16:21:09 --> Config Class Initialized
INFO - 2016-09-15 16:21:09 --> Loader Class Initialized
INFO - 2016-09-15 16:21:09 --> Helper loaded: url_helper
INFO - 2016-09-15 16:21:09 --> Database Driver Class Initialized
INFO - 2016-09-15 16:21:09 --> Controller Class Initialized
DEBUG - 2016-09-15 16:21:09 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:21:09 --> Model Class Initialized
INFO - 2016-09-15 16:21:09 --> Model Class Initialized
DEBUG - 2016-09-15 16:21:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 16:21:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 16:21:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 16:21:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tutup_angsuran.php
DEBUG - 2016-09-15 16:21:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 16:21:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 16:21:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 16:21:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 16:21:09 --> Final output sent to browser
DEBUG - 2016-09-15 16:21:09 --> Total execution time: 0.9546
INFO - 2016-09-15 16:21:13 --> Config Class Initialized
INFO - 2016-09-15 16:21:13 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:21:13 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:21:13 --> Utf8 Class Initialized
INFO - 2016-09-15 16:21:13 --> URI Class Initialized
INFO - 2016-09-15 16:21:13 --> Router Class Initialized
INFO - 2016-09-15 16:21:13 --> Output Class Initialized
INFO - 2016-09-15 16:21:13 --> Security Class Initialized
DEBUG - 2016-09-15 16:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:21:13 --> Input Class Initialized
INFO - 2016-09-15 16:21:13 --> Language Class Initialized
INFO - 2016-09-15 16:21:13 --> Language Class Initialized
INFO - 2016-09-15 16:21:13 --> Config Class Initialized
INFO - 2016-09-15 16:21:13 --> Loader Class Initialized
INFO - 2016-09-15 16:21:13 --> Helper loaded: url_helper
INFO - 2016-09-15 16:21:13 --> Database Driver Class Initialized
INFO - 2016-09-15 16:21:13 --> Controller Class Initialized
DEBUG - 2016-09-15 16:21:13 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:21:13 --> Model Class Initialized
INFO - 2016-09-15 16:21:13 --> Model Class Initialized
INFO - 2016-09-15 16:21:13 --> Database Driver Class Initialized
INFO - 2016-09-15 16:21:13 --> Final output sent to browser
DEBUG - 2016-09-15 16:21:13 --> Total execution time: 0.7540
INFO - 2016-09-15 16:21:20 --> Config Class Initialized
INFO - 2016-09-15 16:21:20 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:21:20 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:21:20 --> Utf8 Class Initialized
INFO - 2016-09-15 16:21:20 --> URI Class Initialized
INFO - 2016-09-15 16:21:20 --> Router Class Initialized
INFO - 2016-09-15 16:21:20 --> Output Class Initialized
INFO - 2016-09-15 16:21:20 --> Security Class Initialized
DEBUG - 2016-09-15 16:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:21:20 --> Input Class Initialized
INFO - 2016-09-15 16:21:20 --> Language Class Initialized
INFO - 2016-09-15 16:21:20 --> Language Class Initialized
INFO - 2016-09-15 16:21:20 --> Config Class Initialized
INFO - 2016-09-15 16:21:20 --> Loader Class Initialized
INFO - 2016-09-15 16:21:20 --> Helper loaded: url_helper
INFO - 2016-09-15 16:21:20 --> Database Driver Class Initialized
INFO - 2016-09-15 16:21:20 --> Controller Class Initialized
DEBUG - 2016-09-15 16:21:20 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:21:20 --> Model Class Initialized
INFO - 2016-09-15 16:21:20 --> Model Class Initialized
INFO - 2016-09-15 16:21:20 --> Database Driver Class Initialized
INFO - 2016-09-15 16:21:20 --> Database Driver Class Initialized
INFO - 2016-09-15 16:21:21 --> Database Driver Class Initialized
INFO - 2016-09-15 16:21:21 --> Database Driver Class Initialized
INFO - 2016-09-15 16:21:21 --> Database Driver Class Initialized
INFO - 2016-09-15 16:21:21 --> Database Driver Class Initialized
INFO - 2016-09-15 16:21:21 --> Database Driver Class Initialized
INFO - 2016-09-15 16:21:21 --> Database Driver Class Initialized
INFO - 2016-09-15 16:21:21 --> Database Driver Class Initialized
INFO - 2016-09-15 16:21:21 --> Final output sent to browser
DEBUG - 2016-09-15 16:21:21 --> Total execution time: 1.6082
INFO - 2016-09-15 16:21:26 --> Config Class Initialized
INFO - 2016-09-15 16:21:26 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:21:27 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:21:27 --> Utf8 Class Initialized
INFO - 2016-09-15 16:21:27 --> URI Class Initialized
INFO - 2016-09-15 16:21:27 --> Router Class Initialized
INFO - 2016-09-15 16:21:27 --> Output Class Initialized
INFO - 2016-09-15 16:21:27 --> Security Class Initialized
DEBUG - 2016-09-15 16:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:21:27 --> Input Class Initialized
INFO - 2016-09-15 16:21:27 --> Language Class Initialized
INFO - 2016-09-15 16:21:27 --> Language Class Initialized
INFO - 2016-09-15 16:21:27 --> Config Class Initialized
INFO - 2016-09-15 16:21:27 --> Loader Class Initialized
INFO - 2016-09-15 16:21:27 --> Helper loaded: url_helper
INFO - 2016-09-15 16:21:27 --> Database Driver Class Initialized
INFO - 2016-09-15 16:21:27 --> Controller Class Initialized
DEBUG - 2016-09-15 16:21:27 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:21:27 --> Model Class Initialized
INFO - 2016-09-15 16:21:27 --> Model Class Initialized
DEBUG - 2016-09-15 16:21:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_transaksi.php
INFO - 2016-09-15 16:21:27 --> Final output sent to browser
DEBUG - 2016-09-15 16:21:27 --> Total execution time: 0.8424
INFO - 2016-09-15 16:23:45 --> Config Class Initialized
INFO - 2016-09-15 16:23:45 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:23:46 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:23:46 --> Utf8 Class Initialized
INFO - 2016-09-15 16:23:46 --> URI Class Initialized
INFO - 2016-09-15 16:23:46 --> Router Class Initialized
INFO - 2016-09-15 16:23:46 --> Output Class Initialized
INFO - 2016-09-15 16:23:46 --> Security Class Initialized
DEBUG - 2016-09-15 16:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:23:46 --> Input Class Initialized
INFO - 2016-09-15 16:23:46 --> Language Class Initialized
INFO - 2016-09-15 16:23:46 --> Language Class Initialized
INFO - 2016-09-15 16:23:46 --> Config Class Initialized
INFO - 2016-09-15 16:23:46 --> Loader Class Initialized
INFO - 2016-09-15 16:23:46 --> Helper loaded: url_helper
INFO - 2016-09-15 16:23:46 --> Database Driver Class Initialized
INFO - 2016-09-15 16:23:46 --> Controller Class Initialized
DEBUG - 2016-09-15 16:23:46 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:23:46 --> Model Class Initialized
INFO - 2016-09-15 16:23:46 --> Model Class Initialized
DEBUG - 2016-09-15 16:23:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 16:23:46 --> Final output sent to browser
DEBUG - 2016-09-15 16:23:46 --> Total execution time: 0.6470
INFO - 2016-09-15 16:23:46 --> Config Class Initialized
INFO - 2016-09-15 16:23:46 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:23:46 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:23:46 --> Utf8 Class Initialized
INFO - 2016-09-15 16:23:46 --> URI Class Initialized
INFO - 2016-09-15 16:23:46 --> Router Class Initialized
INFO - 2016-09-15 16:23:47 --> Output Class Initialized
INFO - 2016-09-15 16:23:47 --> Security Class Initialized
DEBUG - 2016-09-15 16:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:23:47 --> Input Class Initialized
INFO - 2016-09-15 16:23:47 --> Language Class Initialized
INFO - 2016-09-15 16:23:47 --> Language Class Initialized
INFO - 2016-09-15 16:23:47 --> Config Class Initialized
INFO - 2016-09-15 16:23:47 --> Loader Class Initialized
INFO - 2016-09-15 16:23:47 --> Helper loaded: url_helper
INFO - 2016-09-15 16:23:47 --> Database Driver Class Initialized
INFO - 2016-09-15 16:23:47 --> Controller Class Initialized
DEBUG - 2016-09-15 16:23:47 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:23:47 --> Model Class Initialized
INFO - 2016-09-15 16:23:47 --> Model Class Initialized
DEBUG - 2016-09-15 16:23:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 16:23:47 --> Final output sent to browser
DEBUG - 2016-09-15 16:23:47 --> Total execution time: 0.6729
INFO - 2016-09-15 16:23:48 --> Config Class Initialized
INFO - 2016-09-15 16:23:48 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:23:48 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:23:48 --> Utf8 Class Initialized
INFO - 2016-09-15 16:23:48 --> URI Class Initialized
INFO - 2016-09-15 16:23:48 --> Router Class Initialized
INFO - 2016-09-15 16:23:48 --> Output Class Initialized
INFO - 2016-09-15 16:23:48 --> Security Class Initialized
DEBUG - 2016-09-15 16:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:23:48 --> Input Class Initialized
INFO - 2016-09-15 16:23:48 --> Language Class Initialized
INFO - 2016-09-15 16:23:48 --> Language Class Initialized
INFO - 2016-09-15 16:23:48 --> Config Class Initialized
INFO - 2016-09-15 16:23:48 --> Loader Class Initialized
INFO - 2016-09-15 16:23:48 --> Helper loaded: url_helper
INFO - 2016-09-15 16:23:48 --> Database Driver Class Initialized
INFO - 2016-09-15 16:23:48 --> Controller Class Initialized
DEBUG - 2016-09-15 16:23:48 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:23:48 --> Model Class Initialized
INFO - 2016-09-15 16:23:48 --> Model Class Initialized
DEBUG - 2016-09-15 16:23:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 16:23:48 --> Final output sent to browser
DEBUG - 2016-09-15 16:23:48 --> Total execution time: 0.6213
INFO - 2016-09-15 16:23:49 --> Config Class Initialized
INFO - 2016-09-15 16:23:49 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:23:49 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:23:49 --> Utf8 Class Initialized
INFO - 2016-09-15 16:23:49 --> URI Class Initialized
INFO - 2016-09-15 16:23:49 --> Router Class Initialized
INFO - 2016-09-15 16:23:49 --> Output Class Initialized
INFO - 2016-09-15 16:23:50 --> Security Class Initialized
DEBUG - 2016-09-15 16:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:23:50 --> Input Class Initialized
INFO - 2016-09-15 16:23:50 --> Language Class Initialized
INFO - 2016-09-15 16:23:50 --> Language Class Initialized
INFO - 2016-09-15 16:23:50 --> Config Class Initialized
INFO - 2016-09-15 16:23:50 --> Loader Class Initialized
INFO - 2016-09-15 16:23:50 --> Helper loaded: url_helper
INFO - 2016-09-15 16:23:50 --> Database Driver Class Initialized
INFO - 2016-09-15 16:23:50 --> Controller Class Initialized
DEBUG - 2016-09-15 16:23:50 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:23:50 --> Model Class Initialized
INFO - 2016-09-15 16:23:50 --> Model Class Initialized
DEBUG - 2016-09-15 16:23:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 16:23:50 --> Final output sent to browser
DEBUG - 2016-09-15 16:23:50 --> Total execution time: 0.6648
INFO - 2016-09-15 16:23:50 --> Config Class Initialized
INFO - 2016-09-15 16:23:50 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:23:50 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:23:50 --> Utf8 Class Initialized
INFO - 2016-09-15 16:23:50 --> URI Class Initialized
INFO - 2016-09-15 16:23:50 --> Router Class Initialized
INFO - 2016-09-15 16:23:50 --> Output Class Initialized
INFO - 2016-09-15 16:23:50 --> Security Class Initialized
DEBUG - 2016-09-15 16:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:23:50 --> Input Class Initialized
INFO - 2016-09-15 16:23:51 --> Language Class Initialized
INFO - 2016-09-15 16:23:51 --> Language Class Initialized
INFO - 2016-09-15 16:23:51 --> Config Class Initialized
INFO - 2016-09-15 16:23:51 --> Loader Class Initialized
INFO - 2016-09-15 16:23:51 --> Helper loaded: url_helper
INFO - 2016-09-15 16:23:51 --> Database Driver Class Initialized
INFO - 2016-09-15 16:23:51 --> Controller Class Initialized
DEBUG - 2016-09-15 16:23:51 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:23:51 --> Model Class Initialized
INFO - 2016-09-15 16:23:51 --> Model Class Initialized
DEBUG - 2016-09-15 16:23:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 16:23:51 --> Final output sent to browser
DEBUG - 2016-09-15 16:23:51 --> Total execution time: 0.6456
INFO - 2016-09-15 16:23:51 --> Config Class Initialized
INFO - 2016-09-15 16:23:51 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:23:51 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:23:51 --> Utf8 Class Initialized
INFO - 2016-09-15 16:23:51 --> URI Class Initialized
INFO - 2016-09-15 16:23:51 --> Router Class Initialized
INFO - 2016-09-15 16:23:51 --> Output Class Initialized
INFO - 2016-09-15 16:23:51 --> Security Class Initialized
DEBUG - 2016-09-15 16:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:23:51 --> Input Class Initialized
INFO - 2016-09-15 16:23:51 --> Language Class Initialized
INFO - 2016-09-15 16:23:51 --> Language Class Initialized
INFO - 2016-09-15 16:23:51 --> Config Class Initialized
INFO - 2016-09-15 16:23:51 --> Loader Class Initialized
INFO - 2016-09-15 16:23:51 --> Helper loaded: url_helper
INFO - 2016-09-15 16:23:51 --> Database Driver Class Initialized
INFO - 2016-09-15 16:23:51 --> Controller Class Initialized
DEBUG - 2016-09-15 16:23:51 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:23:52 --> Model Class Initialized
INFO - 2016-09-15 16:23:52 --> Model Class Initialized
DEBUG - 2016-09-15 16:23:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 16:23:52 --> Final output sent to browser
DEBUG - 2016-09-15 16:23:52 --> Total execution time: 0.6775
INFO - 2016-09-15 16:23:53 --> Config Class Initialized
INFO - 2016-09-15 16:23:53 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:23:53 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:23:53 --> Utf8 Class Initialized
INFO - 2016-09-15 16:23:53 --> URI Class Initialized
INFO - 2016-09-15 16:23:53 --> Router Class Initialized
INFO - 2016-09-15 16:23:53 --> Output Class Initialized
INFO - 2016-09-15 16:23:53 --> Security Class Initialized
DEBUG - 2016-09-15 16:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:23:53 --> Input Class Initialized
INFO - 2016-09-15 16:23:53 --> Language Class Initialized
INFO - 2016-09-15 16:23:53 --> Language Class Initialized
INFO - 2016-09-15 16:23:54 --> Config Class Initialized
INFO - 2016-09-15 16:23:54 --> Loader Class Initialized
INFO - 2016-09-15 16:23:54 --> Helper loaded: url_helper
INFO - 2016-09-15 16:23:54 --> Database Driver Class Initialized
INFO - 2016-09-15 16:23:54 --> Controller Class Initialized
DEBUG - 2016-09-15 16:23:54 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:23:54 --> Model Class Initialized
INFO - 2016-09-15 16:23:54 --> Model Class Initialized
DEBUG - 2016-09-15 16:23:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 16:23:54 --> Final output sent to browser
DEBUG - 2016-09-15 16:23:54 --> Total execution time: 0.7116
INFO - 2016-09-15 16:23:54 --> Config Class Initialized
INFO - 2016-09-15 16:23:54 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:23:55 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:23:55 --> Utf8 Class Initialized
INFO - 2016-09-15 16:23:55 --> URI Class Initialized
INFO - 2016-09-15 16:23:55 --> Router Class Initialized
INFO - 2016-09-15 16:23:55 --> Output Class Initialized
INFO - 2016-09-15 16:23:55 --> Security Class Initialized
DEBUG - 2016-09-15 16:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:23:55 --> Input Class Initialized
INFO - 2016-09-15 16:23:55 --> Language Class Initialized
INFO - 2016-09-15 16:23:55 --> Language Class Initialized
INFO - 2016-09-15 16:23:55 --> Config Class Initialized
INFO - 2016-09-15 16:23:55 --> Loader Class Initialized
INFO - 2016-09-15 16:23:55 --> Helper loaded: url_helper
INFO - 2016-09-15 16:23:55 --> Database Driver Class Initialized
INFO - 2016-09-15 16:23:55 --> Controller Class Initialized
DEBUG - 2016-09-15 16:23:55 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:23:55 --> Model Class Initialized
INFO - 2016-09-15 16:23:55 --> Model Class Initialized
DEBUG - 2016-09-15 16:23:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_transaksi.php
INFO - 2016-09-15 16:23:55 --> Final output sent to browser
DEBUG - 2016-09-15 16:23:55 --> Total execution time: 0.7779
INFO - 2016-09-15 16:26:36 --> Config Class Initialized
INFO - 2016-09-15 16:26:36 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:26:36 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:26:36 --> Utf8 Class Initialized
INFO - 2016-09-15 16:26:36 --> URI Class Initialized
INFO - 2016-09-15 16:26:36 --> Router Class Initialized
INFO - 2016-09-15 16:26:36 --> Output Class Initialized
INFO - 2016-09-15 16:26:36 --> Security Class Initialized
DEBUG - 2016-09-15 16:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:26:36 --> Input Class Initialized
INFO - 2016-09-15 16:26:36 --> Language Class Initialized
INFO - 2016-09-15 16:26:36 --> Language Class Initialized
INFO - 2016-09-15 16:26:36 --> Config Class Initialized
INFO - 2016-09-15 16:26:36 --> Loader Class Initialized
INFO - 2016-09-15 16:26:36 --> Helper loaded: url_helper
INFO - 2016-09-15 16:26:36 --> Database Driver Class Initialized
INFO - 2016-09-15 16:26:36 --> Controller Class Initialized
DEBUG - 2016-09-15 16:26:36 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:26:36 --> Model Class Initialized
INFO - 2016-09-15 16:26:36 --> Model Class Initialized
DEBUG - 2016-09-15 16:26:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 16:26:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 16:26:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 16:26:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-15 16:26:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 16:26:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 16:26:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 16:26:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 16:26:37 --> Final output sent to browser
DEBUG - 2016-09-15 16:26:37 --> Total execution time: 0.8902
INFO - 2016-09-15 16:26:39 --> Config Class Initialized
INFO - 2016-09-15 16:26:39 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:26:39 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:26:39 --> Utf8 Class Initialized
INFO - 2016-09-15 16:26:39 --> URI Class Initialized
INFO - 2016-09-15 16:26:40 --> Router Class Initialized
INFO - 2016-09-15 16:26:40 --> Output Class Initialized
INFO - 2016-09-15 16:26:40 --> Security Class Initialized
DEBUG - 2016-09-15 16:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:26:40 --> Input Class Initialized
INFO - 2016-09-15 16:26:40 --> Language Class Initialized
INFO - 2016-09-15 16:26:40 --> Language Class Initialized
INFO - 2016-09-15 16:26:40 --> Config Class Initialized
INFO - 2016-09-15 16:26:40 --> Loader Class Initialized
INFO - 2016-09-15 16:26:40 --> Helper loaded: url_helper
INFO - 2016-09-15 16:26:40 --> Database Driver Class Initialized
INFO - 2016-09-15 16:26:40 --> Controller Class Initialized
DEBUG - 2016-09-15 16:26:40 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:26:40 --> Model Class Initialized
INFO - 2016-09-15 16:26:40 --> Model Class Initialized
DEBUG - 2016-09-15 16:26:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 16:26:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 16:26:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 16:26:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_peminjam.php
DEBUG - 2016-09-15 16:26:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 16:26:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 16:26:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 16:26:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 16:26:40 --> Final output sent to browser
DEBUG - 2016-09-15 16:26:40 --> Total execution time: 1.0583
INFO - 2016-09-15 16:26:52 --> Config Class Initialized
INFO - 2016-09-15 16:26:52 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:26:52 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:26:52 --> Utf8 Class Initialized
INFO - 2016-09-15 16:26:52 --> URI Class Initialized
INFO - 2016-09-15 16:26:52 --> Router Class Initialized
INFO - 2016-09-15 16:26:52 --> Output Class Initialized
INFO - 2016-09-15 16:26:52 --> Security Class Initialized
DEBUG - 2016-09-15 16:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:26:52 --> Input Class Initialized
INFO - 2016-09-15 16:26:52 --> Language Class Initialized
INFO - 2016-09-15 16:26:52 --> Language Class Initialized
INFO - 2016-09-15 16:26:52 --> Config Class Initialized
INFO - 2016-09-15 16:26:52 --> Loader Class Initialized
INFO - 2016-09-15 16:26:52 --> Helper loaded: url_helper
INFO - 2016-09-15 16:26:52 --> Database Driver Class Initialized
INFO - 2016-09-15 16:26:52 --> Controller Class Initialized
DEBUG - 2016-09-15 16:26:52 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:26:52 --> Model Class Initialized
INFO - 2016-09-15 16:26:52 --> Model Class Initialized
DEBUG - 2016-09-15 16:26:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 16:26:52 --> Final output sent to browser
DEBUG - 2016-09-15 16:26:53 --> Total execution time: 0.6767
INFO - 2016-09-15 16:26:53 --> Config Class Initialized
INFO - 2016-09-15 16:26:53 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:26:53 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:26:53 --> Utf8 Class Initialized
INFO - 2016-09-15 16:26:53 --> URI Class Initialized
INFO - 2016-09-15 16:26:53 --> Router Class Initialized
INFO - 2016-09-15 16:26:53 --> Output Class Initialized
INFO - 2016-09-15 16:26:53 --> Security Class Initialized
DEBUG - 2016-09-15 16:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:26:53 --> Input Class Initialized
INFO - 2016-09-15 16:26:53 --> Language Class Initialized
INFO - 2016-09-15 16:26:53 --> Language Class Initialized
INFO - 2016-09-15 16:26:53 --> Config Class Initialized
INFO - 2016-09-15 16:26:54 --> Loader Class Initialized
INFO - 2016-09-15 16:26:54 --> Helper loaded: url_helper
INFO - 2016-09-15 16:26:54 --> Database Driver Class Initialized
INFO - 2016-09-15 16:26:54 --> Controller Class Initialized
DEBUG - 2016-09-15 16:26:54 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:26:54 --> Model Class Initialized
INFO - 2016-09-15 16:26:54 --> Model Class Initialized
DEBUG - 2016-09-15 16:26:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 16:26:54 --> Final output sent to browser
DEBUG - 2016-09-15 16:26:54 --> Total execution time: 0.6270
INFO - 2016-09-15 16:26:55 --> Config Class Initialized
INFO - 2016-09-15 16:26:55 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:26:55 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:26:55 --> Utf8 Class Initialized
INFO - 2016-09-15 16:26:55 --> URI Class Initialized
INFO - 2016-09-15 16:26:55 --> Router Class Initialized
INFO - 2016-09-15 16:26:55 --> Output Class Initialized
INFO - 2016-09-15 16:26:55 --> Security Class Initialized
DEBUG - 2016-09-15 16:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:26:56 --> Input Class Initialized
INFO - 2016-09-15 16:26:56 --> Language Class Initialized
INFO - 2016-09-15 16:26:56 --> Language Class Initialized
INFO - 2016-09-15 16:26:56 --> Config Class Initialized
INFO - 2016-09-15 16:26:56 --> Loader Class Initialized
INFO - 2016-09-15 16:26:56 --> Helper loaded: url_helper
INFO - 2016-09-15 16:26:56 --> Database Driver Class Initialized
INFO - 2016-09-15 16:26:56 --> Controller Class Initialized
DEBUG - 2016-09-15 16:26:56 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:26:56 --> Model Class Initialized
INFO - 2016-09-15 16:26:56 --> Model Class Initialized
DEBUG - 2016-09-15 16:26:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 16:26:56 --> Final output sent to browser
DEBUG - 2016-09-15 16:26:56 --> Total execution time: 0.7345
INFO - 2016-09-15 16:26:58 --> Config Class Initialized
INFO - 2016-09-15 16:26:58 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:26:58 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:26:58 --> Utf8 Class Initialized
INFO - 2016-09-15 16:26:58 --> URI Class Initialized
INFO - 2016-09-15 16:26:58 --> Router Class Initialized
INFO - 2016-09-15 16:26:58 --> Output Class Initialized
INFO - 2016-09-15 16:26:58 --> Security Class Initialized
DEBUG - 2016-09-15 16:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:26:58 --> Input Class Initialized
INFO - 2016-09-15 16:26:58 --> Language Class Initialized
INFO - 2016-09-15 16:26:58 --> Language Class Initialized
INFO - 2016-09-15 16:26:58 --> Config Class Initialized
INFO - 2016-09-15 16:26:59 --> Loader Class Initialized
INFO - 2016-09-15 16:26:59 --> Helper loaded: url_helper
INFO - 2016-09-15 16:26:59 --> Database Driver Class Initialized
INFO - 2016-09-15 16:26:59 --> Controller Class Initialized
DEBUG - 2016-09-15 16:26:59 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:26:59 --> Model Class Initialized
INFO - 2016-09-15 16:26:59 --> Model Class Initialized
DEBUG - 2016-09-15 16:26:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 16:26:59 --> Final output sent to browser
DEBUG - 2016-09-15 16:26:59 --> Total execution time: 0.6545
INFO - 2016-09-15 16:27:00 --> Config Class Initialized
INFO - 2016-09-15 16:27:00 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:27:00 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:27:00 --> Utf8 Class Initialized
INFO - 2016-09-15 16:27:00 --> URI Class Initialized
INFO - 2016-09-15 16:27:00 --> Router Class Initialized
INFO - 2016-09-15 16:27:00 --> Output Class Initialized
INFO - 2016-09-15 16:27:00 --> Security Class Initialized
DEBUG - 2016-09-15 16:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:27:00 --> Input Class Initialized
INFO - 2016-09-15 16:27:00 --> Language Class Initialized
INFO - 2016-09-15 16:27:00 --> Language Class Initialized
INFO - 2016-09-15 16:27:00 --> Config Class Initialized
INFO - 2016-09-15 16:27:00 --> Loader Class Initialized
INFO - 2016-09-15 16:27:00 --> Helper loaded: url_helper
INFO - 2016-09-15 16:27:00 --> Database Driver Class Initialized
INFO - 2016-09-15 16:27:00 --> Controller Class Initialized
DEBUG - 2016-09-15 16:27:00 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:27:00 --> Model Class Initialized
INFO - 2016-09-15 16:27:00 --> Model Class Initialized
DEBUG - 2016-09-15 16:27:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-15 16:27:00 --> Final output sent to browser
DEBUG - 2016-09-15 16:27:00 --> Total execution time: 0.6315
INFO - 2016-09-15 16:27:02 --> Config Class Initialized
INFO - 2016-09-15 16:27:02 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:27:02 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:27:02 --> Utf8 Class Initialized
INFO - 2016-09-15 16:27:02 --> URI Class Initialized
INFO - 2016-09-15 16:27:02 --> Router Class Initialized
INFO - 2016-09-15 16:27:02 --> Output Class Initialized
INFO - 2016-09-15 16:27:02 --> Security Class Initialized
DEBUG - 2016-09-15 16:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:27:02 --> Input Class Initialized
INFO - 2016-09-15 16:27:02 --> Language Class Initialized
INFO - 2016-09-15 16:27:02 --> Language Class Initialized
INFO - 2016-09-15 16:27:02 --> Config Class Initialized
INFO - 2016-09-15 16:27:02 --> Loader Class Initialized
INFO - 2016-09-15 16:27:02 --> Helper loaded: url_helper
INFO - 2016-09-15 16:27:03 --> Database Driver Class Initialized
INFO - 2016-09-15 16:27:03 --> Controller Class Initialized
DEBUG - 2016-09-15 16:27:03 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:27:03 --> Model Class Initialized
INFO - 2016-09-15 16:27:03 --> Model Class Initialized
DEBUG - 2016-09-15 16:27:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/subcontent/data_transaksi.php
INFO - 2016-09-15 16:27:03 --> Final output sent to browser
DEBUG - 2016-09-15 16:27:03 --> Total execution time: 0.8296
INFO - 2016-09-15 16:28:00 --> Config Class Initialized
INFO - 2016-09-15 16:28:00 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:28:00 --> UTF-8 Support Enabled
INFO - 2016-09-15 16:28:00 --> Utf8 Class Initialized
INFO - 2016-09-15 16:28:00 --> URI Class Initialized
INFO - 2016-09-15 16:28:00 --> Router Class Initialized
INFO - 2016-09-15 16:28:00 --> Output Class Initialized
INFO - 2016-09-15 16:28:00 --> Security Class Initialized
DEBUG - 2016-09-15 16:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 16:28:00 --> Input Class Initialized
INFO - 2016-09-15 16:28:00 --> Language Class Initialized
INFO - 2016-09-15 16:28:00 --> Language Class Initialized
INFO - 2016-09-15 16:28:00 --> Config Class Initialized
INFO - 2016-09-15 16:28:00 --> Loader Class Initialized
INFO - 2016-09-15 16:28:00 --> Helper loaded: url_helper
INFO - 2016-09-15 16:28:00 --> Database Driver Class Initialized
INFO - 2016-09-15 16:28:00 --> Controller Class Initialized
DEBUG - 2016-09-15 16:28:00 --> Index MX_Controller Initialized
INFO - 2016-09-15 16:28:00 --> Model Class Initialized
INFO - 2016-09-15 16:28:00 --> Model Class Initialized
DEBUG - 2016-09-15 16:28:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 16:28:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 16:28:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 16:28:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-15 16:28:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 16:28:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 16:28:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 16:28:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 16:28:00 --> Final output sent to browser
DEBUG - 2016-09-15 16:28:00 --> Total execution time: 0.8738
INFO - 2016-09-15 17:54:18 --> Config Class Initialized
INFO - 2016-09-15 17:54:18 --> Hooks Class Initialized
DEBUG - 2016-09-15 17:54:18 --> UTF-8 Support Enabled
INFO - 2016-09-15 17:54:18 --> Utf8 Class Initialized
INFO - 2016-09-15 17:54:18 --> URI Class Initialized
INFO - 2016-09-15 17:54:18 --> Router Class Initialized
INFO - 2016-09-15 17:54:18 --> Output Class Initialized
INFO - 2016-09-15 17:54:18 --> Security Class Initialized
DEBUG - 2016-09-15 17:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 17:54:18 --> Input Class Initialized
INFO - 2016-09-15 17:54:18 --> Language Class Initialized
INFO - 2016-09-15 17:54:18 --> Language Class Initialized
INFO - 2016-09-15 17:54:18 --> Config Class Initialized
INFO - 2016-09-15 17:54:18 --> Loader Class Initialized
INFO - 2016-09-15 17:54:18 --> Helper loaded: url_helper
INFO - 2016-09-15 17:54:18 --> Database Driver Class Initialized
INFO - 2016-09-15 17:54:18 --> Controller Class Initialized
DEBUG - 2016-09-15 17:54:18 --> Index MX_Controller Initialized
INFO - 2016-09-15 17:54:18 --> Model Class Initialized
INFO - 2016-09-15 17:54:18 --> Model Class Initialized
DEBUG - 2016-09-15 17:54:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 17:54:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 17:54:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 17:54:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/pinjaman.php
DEBUG - 2016-09-15 17:54:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 17:54:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 17:54:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 17:54:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 17:54:18 --> Final output sent to browser
DEBUG - 2016-09-15 17:54:19 --> Total execution time: 0.9760
INFO - 2016-09-15 17:54:43 --> Config Class Initialized
INFO - 2016-09-15 17:54:43 --> Hooks Class Initialized
DEBUG - 2016-09-15 17:54:43 --> UTF-8 Support Enabled
INFO - 2016-09-15 17:54:43 --> Utf8 Class Initialized
INFO - 2016-09-15 17:54:43 --> URI Class Initialized
INFO - 2016-09-15 17:54:43 --> Router Class Initialized
INFO - 2016-09-15 17:54:43 --> Output Class Initialized
INFO - 2016-09-15 17:54:43 --> Security Class Initialized
DEBUG - 2016-09-15 17:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 17:54:43 --> Input Class Initialized
INFO - 2016-09-15 17:54:43 --> Language Class Initialized
INFO - 2016-09-15 17:54:43 --> Language Class Initialized
INFO - 2016-09-15 17:54:43 --> Config Class Initialized
INFO - 2016-09-15 17:54:43 --> Loader Class Initialized
INFO - 2016-09-15 17:54:43 --> Helper loaded: url_helper
INFO - 2016-09-15 17:54:43 --> Database Driver Class Initialized
INFO - 2016-09-15 17:54:43 --> Controller Class Initialized
DEBUG - 2016-09-15 17:54:43 --> Index MX_Controller Initialized
INFO - 2016-09-15 17:54:43 --> Model Class Initialized
INFO - 2016-09-15 17:54:43 --> Model Class Initialized
DEBUG - 2016-09-15 17:54:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 17:54:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 17:54:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 17:54:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/pinjaman.php
DEBUG - 2016-09-15 17:54:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 17:54:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 17:54:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 17:54:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 17:54:44 --> Final output sent to browser
DEBUG - 2016-09-15 17:54:44 --> Total execution time: 1.1014
INFO - 2016-09-15 17:55:13 --> Config Class Initialized
INFO - 2016-09-15 17:55:13 --> Hooks Class Initialized
DEBUG - 2016-09-15 17:55:13 --> UTF-8 Support Enabled
INFO - 2016-09-15 17:55:13 --> Utf8 Class Initialized
INFO - 2016-09-15 17:55:13 --> URI Class Initialized
INFO - 2016-09-15 17:55:13 --> Router Class Initialized
INFO - 2016-09-15 17:55:13 --> Output Class Initialized
INFO - 2016-09-15 17:55:13 --> Security Class Initialized
DEBUG - 2016-09-15 17:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 17:55:13 --> Input Class Initialized
INFO - 2016-09-15 17:55:13 --> Language Class Initialized
INFO - 2016-09-15 17:55:13 --> Language Class Initialized
INFO - 2016-09-15 17:55:13 --> Config Class Initialized
INFO - 2016-09-15 17:55:13 --> Loader Class Initialized
INFO - 2016-09-15 17:55:13 --> Helper loaded: url_helper
INFO - 2016-09-15 17:55:13 --> Database Driver Class Initialized
INFO - 2016-09-15 17:55:13 --> Controller Class Initialized
DEBUG - 2016-09-15 17:55:13 --> Index MX_Controller Initialized
INFO - 2016-09-15 17:55:13 --> Model Class Initialized
INFO - 2016-09-15 17:55:14 --> Model Class Initialized
DEBUG - 2016-09-15 17:55:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 17:55:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 17:55:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 17:55:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/pinjaman.php
DEBUG - 2016-09-15 17:55:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 17:55:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 17:55:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 17:55:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 17:55:14 --> Final output sent to browser
DEBUG - 2016-09-15 17:55:14 --> Total execution time: 0.9470
INFO - 2016-09-15 17:55:29 --> Config Class Initialized
INFO - 2016-09-15 17:55:29 --> Hooks Class Initialized
DEBUG - 2016-09-15 17:55:29 --> UTF-8 Support Enabled
INFO - 2016-09-15 17:55:29 --> Utf8 Class Initialized
INFO - 2016-09-15 17:55:29 --> URI Class Initialized
INFO - 2016-09-15 17:55:29 --> Router Class Initialized
INFO - 2016-09-15 17:55:29 --> Output Class Initialized
INFO - 2016-09-15 17:55:29 --> Security Class Initialized
DEBUG - 2016-09-15 17:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 17:55:29 --> Input Class Initialized
INFO - 2016-09-15 17:55:29 --> Language Class Initialized
INFO - 2016-09-15 17:55:29 --> Language Class Initialized
INFO - 2016-09-15 17:55:29 --> Config Class Initialized
INFO - 2016-09-15 17:55:29 --> Loader Class Initialized
INFO - 2016-09-15 17:55:29 --> Helper loaded: url_helper
INFO - 2016-09-15 17:55:29 --> Database Driver Class Initialized
INFO - 2016-09-15 17:55:29 --> Controller Class Initialized
DEBUG - 2016-09-15 17:55:29 --> Index MX_Controller Initialized
INFO - 2016-09-15 17:55:29 --> Model Class Initialized
INFO - 2016-09-15 17:55:29 --> Model Class Initialized
DEBUG - 2016-09-15 17:55:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 17:55:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 17:55:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 17:55:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/pinjaman.php
DEBUG - 2016-09-15 17:55:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 17:55:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 17:55:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 17:55:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 17:55:30 --> Final output sent to browser
DEBUG - 2016-09-15 17:55:30 --> Total execution time: 0.9344
INFO - 2016-09-15 17:55:57 --> Config Class Initialized
INFO - 2016-09-15 17:55:57 --> Hooks Class Initialized
DEBUG - 2016-09-15 17:55:57 --> UTF-8 Support Enabled
INFO - 2016-09-15 17:55:57 --> Utf8 Class Initialized
INFO - 2016-09-15 17:55:57 --> URI Class Initialized
INFO - 2016-09-15 17:55:57 --> Router Class Initialized
INFO - 2016-09-15 17:55:57 --> Output Class Initialized
INFO - 2016-09-15 17:55:57 --> Security Class Initialized
DEBUG - 2016-09-15 17:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 17:55:57 --> Input Class Initialized
INFO - 2016-09-15 17:55:57 --> Language Class Initialized
INFO - 2016-09-15 17:55:57 --> Language Class Initialized
INFO - 2016-09-15 17:55:57 --> Config Class Initialized
INFO - 2016-09-15 17:55:57 --> Loader Class Initialized
INFO - 2016-09-15 17:55:57 --> Helper loaded: url_helper
INFO - 2016-09-15 17:55:57 --> Database Driver Class Initialized
INFO - 2016-09-15 17:55:57 --> Controller Class Initialized
DEBUG - 2016-09-15 17:55:57 --> Index MX_Controller Initialized
INFO - 2016-09-15 17:55:57 --> Model Class Initialized
INFO - 2016-09-15 17:55:58 --> Model Class Initialized
DEBUG - 2016-09-15 17:55:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 17:55:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 17:55:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 17:55:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/pinjaman.php
DEBUG - 2016-09-15 17:55:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 17:55:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 17:55:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 17:55:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 17:55:58 --> Final output sent to browser
DEBUG - 2016-09-15 17:55:58 --> Total execution time: 0.9667
INFO - 2016-09-15 17:56:10 --> Config Class Initialized
INFO - 2016-09-15 17:56:10 --> Hooks Class Initialized
DEBUG - 2016-09-15 17:56:10 --> UTF-8 Support Enabled
INFO - 2016-09-15 17:56:10 --> Utf8 Class Initialized
INFO - 2016-09-15 17:56:10 --> URI Class Initialized
INFO - 2016-09-15 17:56:11 --> Router Class Initialized
INFO - 2016-09-15 17:56:11 --> Output Class Initialized
INFO - 2016-09-15 17:56:11 --> Security Class Initialized
DEBUG - 2016-09-15 17:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 17:56:11 --> Input Class Initialized
INFO - 2016-09-15 17:56:11 --> Language Class Initialized
INFO - 2016-09-15 17:56:11 --> Language Class Initialized
INFO - 2016-09-15 17:56:11 --> Config Class Initialized
INFO - 2016-09-15 17:56:11 --> Loader Class Initialized
INFO - 2016-09-15 17:56:11 --> Helper loaded: url_helper
INFO - 2016-09-15 17:56:11 --> Database Driver Class Initialized
INFO - 2016-09-15 17:56:11 --> Controller Class Initialized
DEBUG - 2016-09-15 17:56:11 --> Index MX_Controller Initialized
INFO - 2016-09-15 17:56:11 --> Model Class Initialized
INFO - 2016-09-15 17:56:11 --> Model Class Initialized
DEBUG - 2016-09-15 17:56:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 17:56:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 17:56:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 17:56:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/pinjaman.php
DEBUG - 2016-09-15 17:56:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 17:56:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 17:56:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 17:56:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 17:56:11 --> Final output sent to browser
DEBUG - 2016-09-15 17:56:11 --> Total execution time: 0.9271
INFO - 2016-09-15 17:56:38 --> Config Class Initialized
INFO - 2016-09-15 17:56:38 --> Hooks Class Initialized
DEBUG - 2016-09-15 17:56:39 --> UTF-8 Support Enabled
INFO - 2016-09-15 17:56:39 --> Utf8 Class Initialized
INFO - 2016-09-15 17:56:39 --> URI Class Initialized
INFO - 2016-09-15 17:56:39 --> Router Class Initialized
INFO - 2016-09-15 17:56:39 --> Output Class Initialized
INFO - 2016-09-15 17:56:39 --> Security Class Initialized
DEBUG - 2016-09-15 17:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 17:56:39 --> Input Class Initialized
INFO - 2016-09-15 17:56:39 --> Language Class Initialized
INFO - 2016-09-15 17:56:39 --> Language Class Initialized
INFO - 2016-09-15 17:56:39 --> Config Class Initialized
INFO - 2016-09-15 17:56:39 --> Loader Class Initialized
INFO - 2016-09-15 17:56:39 --> Helper loaded: url_helper
INFO - 2016-09-15 17:56:39 --> Database Driver Class Initialized
INFO - 2016-09-15 17:56:39 --> Controller Class Initialized
DEBUG - 2016-09-15 17:56:39 --> Index MX_Controller Initialized
INFO - 2016-09-15 17:56:39 --> Model Class Initialized
INFO - 2016-09-15 17:56:39 --> Model Class Initialized
DEBUG - 2016-09-15 17:56:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 17:56:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 17:56:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 17:56:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/pinjaman.php
DEBUG - 2016-09-15 17:56:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 17:56:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 17:56:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 17:56:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 17:56:39 --> Final output sent to browser
DEBUG - 2016-09-15 17:56:39 --> Total execution time: 0.9685
INFO - 2016-09-15 17:58:10 --> Config Class Initialized
INFO - 2016-09-15 17:58:10 --> Hooks Class Initialized
DEBUG - 2016-09-15 17:58:11 --> UTF-8 Support Enabled
INFO - 2016-09-15 17:58:11 --> Utf8 Class Initialized
INFO - 2016-09-15 17:58:11 --> URI Class Initialized
INFO - 2016-09-15 17:58:11 --> Router Class Initialized
INFO - 2016-09-15 17:58:11 --> Output Class Initialized
INFO - 2016-09-15 17:58:11 --> Security Class Initialized
DEBUG - 2016-09-15 17:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 17:58:11 --> Input Class Initialized
INFO - 2016-09-15 17:58:11 --> Language Class Initialized
INFO - 2016-09-15 17:58:11 --> Language Class Initialized
INFO - 2016-09-15 17:58:11 --> Config Class Initialized
INFO - 2016-09-15 17:58:11 --> Loader Class Initialized
INFO - 2016-09-15 17:58:11 --> Helper loaded: url_helper
INFO - 2016-09-15 17:58:11 --> Database Driver Class Initialized
INFO - 2016-09-15 17:58:11 --> Controller Class Initialized
DEBUG - 2016-09-15 17:58:11 --> Index MX_Controller Initialized
INFO - 2016-09-15 17:58:11 --> Model Class Initialized
INFO - 2016-09-15 17:58:11 --> Model Class Initialized
DEBUG - 2016-09-15 17:58:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 17:58:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 17:58:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 17:58:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/pinjaman.php
DEBUG - 2016-09-15 17:58:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 17:58:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 17:58:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 17:58:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 17:58:11 --> Final output sent to browser
DEBUG - 2016-09-15 17:58:11 --> Total execution time: 0.9530
INFO - 2016-09-15 18:00:10 --> Config Class Initialized
INFO - 2016-09-15 18:00:10 --> Hooks Class Initialized
DEBUG - 2016-09-15 18:00:10 --> UTF-8 Support Enabled
INFO - 2016-09-15 18:00:10 --> Utf8 Class Initialized
INFO - 2016-09-15 18:00:11 --> URI Class Initialized
INFO - 2016-09-15 18:00:11 --> Router Class Initialized
INFO - 2016-09-15 18:00:11 --> Output Class Initialized
INFO - 2016-09-15 18:00:11 --> Security Class Initialized
DEBUG - 2016-09-15 18:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 18:00:11 --> Input Class Initialized
INFO - 2016-09-15 18:00:11 --> Language Class Initialized
INFO - 2016-09-15 18:00:11 --> Language Class Initialized
INFO - 2016-09-15 18:00:11 --> Config Class Initialized
INFO - 2016-09-15 18:00:11 --> Loader Class Initialized
INFO - 2016-09-15 18:00:11 --> Helper loaded: url_helper
INFO - 2016-09-15 18:00:11 --> Database Driver Class Initialized
INFO - 2016-09-15 18:00:11 --> Controller Class Initialized
DEBUG - 2016-09-15 18:00:11 --> Index MX_Controller Initialized
INFO - 2016-09-15 18:00:11 --> Model Class Initialized
INFO - 2016-09-15 18:00:11 --> Model Class Initialized
DEBUG - 2016-09-15 18:00:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 18:00:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 18:00:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 18:00:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/pinjaman.php
DEBUG - 2016-09-15 18:00:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 18:00:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 18:00:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 18:00:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 18:00:11 --> Final output sent to browser
DEBUG - 2016-09-15 18:00:11 --> Total execution time: 0.9460
INFO - 2016-09-15 18:00:16 --> Config Class Initialized
INFO - 2016-09-15 18:00:16 --> Hooks Class Initialized
DEBUG - 2016-09-15 18:00:16 --> UTF-8 Support Enabled
INFO - 2016-09-15 18:00:16 --> Utf8 Class Initialized
INFO - 2016-09-15 18:00:16 --> URI Class Initialized
INFO - 2016-09-15 18:00:16 --> Router Class Initialized
INFO - 2016-09-15 18:00:16 --> Output Class Initialized
INFO - 2016-09-15 18:00:16 --> Security Class Initialized
DEBUG - 2016-09-15 18:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 18:00:17 --> Input Class Initialized
INFO - 2016-09-15 18:00:17 --> Language Class Initialized
INFO - 2016-09-15 18:00:17 --> Language Class Initialized
INFO - 2016-09-15 18:00:17 --> Config Class Initialized
INFO - 2016-09-15 18:00:17 --> Loader Class Initialized
INFO - 2016-09-15 18:00:17 --> Helper loaded: url_helper
INFO - 2016-09-15 18:00:17 --> Database Driver Class Initialized
INFO - 2016-09-15 18:00:17 --> Controller Class Initialized
DEBUG - 2016-09-15 18:00:17 --> Index MX_Controller Initialized
INFO - 2016-09-15 18:00:17 --> Model Class Initialized
INFO - 2016-09-15 18:00:17 --> Model Class Initialized
INFO - 2016-09-15 18:00:17 --> Final output sent to browser
DEBUG - 2016-09-15 18:00:17 --> Total execution time: 0.6476
INFO - 2016-09-15 18:11:20 --> Config Class Initialized
INFO - 2016-09-15 18:11:20 --> Hooks Class Initialized
DEBUG - 2016-09-15 18:11:20 --> UTF-8 Support Enabled
INFO - 2016-09-15 18:11:20 --> Utf8 Class Initialized
INFO - 2016-09-15 18:11:20 --> URI Class Initialized
INFO - 2016-09-15 18:11:20 --> Router Class Initialized
INFO - 2016-09-15 18:11:20 --> Output Class Initialized
INFO - 2016-09-15 18:11:20 --> Security Class Initialized
DEBUG - 2016-09-15 18:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 18:11:20 --> Input Class Initialized
INFO - 2016-09-15 18:11:20 --> Language Class Initialized
INFO - 2016-09-15 18:11:20 --> Language Class Initialized
INFO - 2016-09-15 18:11:20 --> Config Class Initialized
INFO - 2016-09-15 18:11:20 --> Loader Class Initialized
INFO - 2016-09-15 18:11:20 --> Helper loaded: url_helper
INFO - 2016-09-15 18:11:20 --> Database Driver Class Initialized
INFO - 2016-09-15 18:11:20 --> Controller Class Initialized
DEBUG - 2016-09-15 18:11:20 --> Index MX_Controller Initialized
INFO - 2016-09-15 18:11:20 --> Model Class Initialized
INFO - 2016-09-15 18:11:20 --> Model Class Initialized
DEBUG - 2016-09-15 18:11:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 18:11:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 18:11:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 18:11:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/pinjaman.php
DEBUG - 2016-09-15 18:11:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 18:11:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 18:11:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 18:11:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 18:11:21 --> Final output sent to browser
DEBUG - 2016-09-15 18:11:21 --> Total execution time: 1.0875
INFO - 2016-09-15 18:11:35 --> Config Class Initialized
INFO - 2016-09-15 18:11:35 --> Hooks Class Initialized
DEBUG - 2016-09-15 18:11:35 --> UTF-8 Support Enabled
INFO - 2016-09-15 18:11:35 --> Utf8 Class Initialized
INFO - 2016-09-15 18:11:35 --> URI Class Initialized
INFO - 2016-09-15 18:11:36 --> Router Class Initialized
INFO - 2016-09-15 18:11:36 --> Output Class Initialized
INFO - 2016-09-15 18:11:36 --> Security Class Initialized
DEBUG - 2016-09-15 18:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 18:11:36 --> Input Class Initialized
INFO - 2016-09-15 18:11:36 --> Language Class Initialized
INFO - 2016-09-15 18:11:36 --> Language Class Initialized
INFO - 2016-09-15 18:11:36 --> Config Class Initialized
INFO - 2016-09-15 18:11:36 --> Loader Class Initialized
INFO - 2016-09-15 18:11:36 --> Helper loaded: url_helper
INFO - 2016-09-15 18:11:36 --> Database Driver Class Initialized
INFO - 2016-09-15 18:11:36 --> Controller Class Initialized
DEBUG - 2016-09-15 18:11:36 --> Index MX_Controller Initialized
INFO - 2016-09-15 18:11:36 --> Model Class Initialized
INFO - 2016-09-15 18:11:36 --> Model Class Initialized
DEBUG - 2016-09-15 18:11:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_pinjaman.php
INFO - 2016-09-15 18:11:36 --> Final output sent to browser
DEBUG - 2016-09-15 18:11:36 --> Total execution time: 0.7127
INFO - 2016-09-15 18:11:58 --> Config Class Initialized
INFO - 2016-09-15 18:11:58 --> Hooks Class Initialized
DEBUG - 2016-09-15 18:11:58 --> UTF-8 Support Enabled
INFO - 2016-09-15 18:11:58 --> Utf8 Class Initialized
INFO - 2016-09-15 18:11:58 --> URI Class Initialized
INFO - 2016-09-15 18:11:58 --> Router Class Initialized
INFO - 2016-09-15 18:11:58 --> Output Class Initialized
INFO - 2016-09-15 18:11:58 --> Security Class Initialized
DEBUG - 2016-09-15 18:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 18:11:58 --> Input Class Initialized
INFO - 2016-09-15 18:11:58 --> Language Class Initialized
INFO - 2016-09-15 18:11:58 --> Language Class Initialized
INFO - 2016-09-15 18:11:58 --> Config Class Initialized
INFO - 2016-09-15 18:11:58 --> Loader Class Initialized
INFO - 2016-09-15 18:11:58 --> Helper loaded: url_helper
INFO - 2016-09-15 18:11:58 --> Database Driver Class Initialized
INFO - 2016-09-15 18:11:58 --> Controller Class Initialized
DEBUG - 2016-09-15 18:11:58 --> Index MX_Controller Initialized
INFO - 2016-09-15 18:11:58 --> Model Class Initialized
INFO - 2016-09-15 18:11:58 --> Model Class Initialized
DEBUG - 2016-09-15 18:11:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_pinjaman.php
INFO - 2016-09-15 18:11:58 --> Final output sent to browser
DEBUG - 2016-09-15 18:11:58 --> Total execution time: 0.6749
INFO - 2016-09-15 18:12:13 --> Config Class Initialized
INFO - 2016-09-15 18:12:13 --> Hooks Class Initialized
DEBUG - 2016-09-15 18:12:13 --> UTF-8 Support Enabled
INFO - 2016-09-15 18:12:13 --> Utf8 Class Initialized
INFO - 2016-09-15 18:12:13 --> URI Class Initialized
INFO - 2016-09-15 18:12:13 --> Router Class Initialized
INFO - 2016-09-15 18:12:13 --> Output Class Initialized
INFO - 2016-09-15 18:12:13 --> Security Class Initialized
DEBUG - 2016-09-15 18:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 18:12:13 --> Input Class Initialized
INFO - 2016-09-15 18:12:14 --> Language Class Initialized
INFO - 2016-09-15 18:12:14 --> Language Class Initialized
INFO - 2016-09-15 18:12:14 --> Config Class Initialized
INFO - 2016-09-15 18:12:14 --> Loader Class Initialized
INFO - 2016-09-15 18:12:14 --> Helper loaded: url_helper
INFO - 2016-09-15 18:12:14 --> Database Driver Class Initialized
INFO - 2016-09-15 18:12:14 --> Controller Class Initialized
DEBUG - 2016-09-15 18:12:14 --> Index MX_Controller Initialized
INFO - 2016-09-15 18:12:14 --> Model Class Initialized
INFO - 2016-09-15 18:12:14 --> Model Class Initialized
DEBUG - 2016-09-15 18:12:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_pinjaman.php
INFO - 2016-09-15 18:12:14 --> Final output sent to browser
DEBUG - 2016-09-15 18:12:14 --> Total execution time: 0.6731
INFO - 2016-09-15 18:13:10 --> Config Class Initialized
INFO - 2016-09-15 18:13:10 --> Hooks Class Initialized
DEBUG - 2016-09-15 18:13:10 --> UTF-8 Support Enabled
INFO - 2016-09-15 18:13:10 --> Utf8 Class Initialized
INFO - 2016-09-15 18:13:10 --> URI Class Initialized
INFO - 2016-09-15 18:13:10 --> Router Class Initialized
INFO - 2016-09-15 18:13:10 --> Output Class Initialized
INFO - 2016-09-15 18:13:10 --> Security Class Initialized
DEBUG - 2016-09-15 18:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 18:13:10 --> Input Class Initialized
INFO - 2016-09-15 18:13:11 --> Language Class Initialized
INFO - 2016-09-15 18:13:11 --> Language Class Initialized
INFO - 2016-09-15 18:13:11 --> Config Class Initialized
INFO - 2016-09-15 18:13:11 --> Loader Class Initialized
INFO - 2016-09-15 18:13:11 --> Helper loaded: url_helper
INFO - 2016-09-15 18:13:11 --> Database Driver Class Initialized
INFO - 2016-09-15 18:13:11 --> Controller Class Initialized
DEBUG - 2016-09-15 18:13:11 --> Index MX_Controller Initialized
INFO - 2016-09-15 18:13:11 --> Model Class Initialized
INFO - 2016-09-15 18:13:11 --> Model Class Initialized
DEBUG - 2016-09-15 18:13:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_pinjaman.php
INFO - 2016-09-15 18:13:11 --> Final output sent to browser
DEBUG - 2016-09-15 18:13:11 --> Total execution time: 0.6704
INFO - 2016-09-15 18:14:08 --> Config Class Initialized
INFO - 2016-09-15 18:14:08 --> Hooks Class Initialized
DEBUG - 2016-09-15 18:14:08 --> UTF-8 Support Enabled
INFO - 2016-09-15 18:14:08 --> Utf8 Class Initialized
INFO - 2016-09-15 18:14:08 --> URI Class Initialized
INFO - 2016-09-15 18:14:08 --> Router Class Initialized
INFO - 2016-09-15 18:14:08 --> Output Class Initialized
INFO - 2016-09-15 18:14:08 --> Security Class Initialized
DEBUG - 2016-09-15 18:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 18:14:08 --> Input Class Initialized
INFO - 2016-09-15 18:14:08 --> Language Class Initialized
INFO - 2016-09-15 18:14:09 --> Language Class Initialized
INFO - 2016-09-15 18:14:09 --> Config Class Initialized
INFO - 2016-09-15 18:14:09 --> Loader Class Initialized
INFO - 2016-09-15 18:14:09 --> Helper loaded: url_helper
INFO - 2016-09-15 18:14:09 --> Database Driver Class Initialized
INFO - 2016-09-15 18:14:09 --> Controller Class Initialized
DEBUG - 2016-09-15 18:14:09 --> Index MX_Controller Initialized
INFO - 2016-09-15 18:14:09 --> Model Class Initialized
INFO - 2016-09-15 18:14:09 --> Model Class Initialized
DEBUG - 2016-09-15 18:14:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_pinjaman.php
INFO - 2016-09-15 18:14:09 --> Final output sent to browser
DEBUG - 2016-09-15 18:14:09 --> Total execution time: 0.6610
INFO - 2016-09-15 18:14:32 --> Config Class Initialized
INFO - 2016-09-15 18:14:32 --> Hooks Class Initialized
DEBUG - 2016-09-15 18:14:32 --> UTF-8 Support Enabled
INFO - 2016-09-15 18:14:32 --> Utf8 Class Initialized
INFO - 2016-09-15 18:14:32 --> URI Class Initialized
INFO - 2016-09-15 18:14:32 --> Router Class Initialized
INFO - 2016-09-15 18:14:32 --> Output Class Initialized
INFO - 2016-09-15 18:14:32 --> Security Class Initialized
DEBUG - 2016-09-15 18:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 18:14:32 --> Input Class Initialized
INFO - 2016-09-15 18:14:32 --> Language Class Initialized
INFO - 2016-09-15 18:14:33 --> Language Class Initialized
INFO - 2016-09-15 18:14:33 --> Config Class Initialized
INFO - 2016-09-15 18:14:33 --> Loader Class Initialized
INFO - 2016-09-15 18:14:33 --> Helper loaded: url_helper
INFO - 2016-09-15 18:14:33 --> Database Driver Class Initialized
INFO - 2016-09-15 18:14:33 --> Controller Class Initialized
DEBUG - 2016-09-15 18:14:33 --> Index MX_Controller Initialized
INFO - 2016-09-15 18:14:33 --> Model Class Initialized
INFO - 2016-09-15 18:14:33 --> Model Class Initialized
DEBUG - 2016-09-15 18:14:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_pinjaman.php
INFO - 2016-09-15 18:14:33 --> Final output sent to browser
DEBUG - 2016-09-15 18:14:33 --> Total execution time: 0.6819
INFO - 2016-09-15 18:16:45 --> Config Class Initialized
INFO - 2016-09-15 18:16:45 --> Hooks Class Initialized
DEBUG - 2016-09-15 18:16:45 --> UTF-8 Support Enabled
INFO - 2016-09-15 18:16:45 --> Utf8 Class Initialized
INFO - 2016-09-15 18:16:45 --> URI Class Initialized
INFO - 2016-09-15 18:16:45 --> Router Class Initialized
INFO - 2016-09-15 18:16:45 --> Output Class Initialized
INFO - 2016-09-15 18:16:45 --> Security Class Initialized
DEBUG - 2016-09-15 18:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 18:16:45 --> Input Class Initialized
INFO - 2016-09-15 18:16:45 --> Language Class Initialized
INFO - 2016-09-15 18:16:45 --> Language Class Initialized
INFO - 2016-09-15 18:16:45 --> Config Class Initialized
INFO - 2016-09-15 18:16:45 --> Loader Class Initialized
INFO - 2016-09-15 18:16:45 --> Helper loaded: url_helper
INFO - 2016-09-15 18:16:45 --> Database Driver Class Initialized
INFO - 2016-09-15 18:16:46 --> Controller Class Initialized
DEBUG - 2016-09-15 18:16:46 --> Index MX_Controller Initialized
INFO - 2016-09-15 18:16:46 --> Model Class Initialized
INFO - 2016-09-15 18:16:46 --> Model Class Initialized
DEBUG - 2016-09-15 18:16:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 18:16:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 18:16:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 18:16:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/pinjaman.php
DEBUG - 2016-09-15 18:16:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 18:16:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 18:16:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 18:16:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 18:16:46 --> Final output sent to browser
DEBUG - 2016-09-15 18:16:46 --> Total execution time: 0.9908
INFO - 2016-09-15 18:16:51 --> Config Class Initialized
INFO - 2016-09-15 18:16:51 --> Hooks Class Initialized
DEBUG - 2016-09-15 18:16:51 --> UTF-8 Support Enabled
INFO - 2016-09-15 18:16:51 --> Utf8 Class Initialized
INFO - 2016-09-15 18:16:51 --> URI Class Initialized
INFO - 2016-09-15 18:16:51 --> Router Class Initialized
INFO - 2016-09-15 18:16:51 --> Output Class Initialized
INFO - 2016-09-15 18:16:51 --> Security Class Initialized
DEBUG - 2016-09-15 18:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 18:16:51 --> Input Class Initialized
INFO - 2016-09-15 18:16:51 --> Language Class Initialized
INFO - 2016-09-15 18:16:51 --> Language Class Initialized
INFO - 2016-09-15 18:16:51 --> Config Class Initialized
INFO - 2016-09-15 18:16:51 --> Loader Class Initialized
INFO - 2016-09-15 18:16:51 --> Helper loaded: url_helper
INFO - 2016-09-15 18:16:51 --> Database Driver Class Initialized
INFO - 2016-09-15 18:16:51 --> Controller Class Initialized
DEBUG - 2016-09-15 18:16:51 --> Index MX_Controller Initialized
INFO - 2016-09-15 18:16:51 --> Model Class Initialized
INFO - 2016-09-15 18:16:51 --> Model Class Initialized
DEBUG - 2016-09-15 18:16:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_pinjaman.php
INFO - 2016-09-15 18:16:51 --> Final output sent to browser
DEBUG - 2016-09-15 18:16:51 --> Total execution time: 0.6944
INFO - 2016-09-15 18:17:07 --> Config Class Initialized
INFO - 2016-09-15 18:17:07 --> Hooks Class Initialized
DEBUG - 2016-09-15 18:17:07 --> UTF-8 Support Enabled
INFO - 2016-09-15 18:17:07 --> Utf8 Class Initialized
INFO - 2016-09-15 18:17:07 --> URI Class Initialized
INFO - 2016-09-15 18:17:07 --> Router Class Initialized
INFO - 2016-09-15 18:17:07 --> Output Class Initialized
INFO - 2016-09-15 18:17:07 --> Security Class Initialized
DEBUG - 2016-09-15 18:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 18:17:07 --> Input Class Initialized
INFO - 2016-09-15 18:17:07 --> Language Class Initialized
INFO - 2016-09-15 18:17:07 --> Language Class Initialized
INFO - 2016-09-15 18:17:07 --> Config Class Initialized
INFO - 2016-09-15 18:17:07 --> Loader Class Initialized
INFO - 2016-09-15 18:17:07 --> Helper loaded: url_helper
INFO - 2016-09-15 18:17:07 --> Database Driver Class Initialized
INFO - 2016-09-15 18:17:07 --> Controller Class Initialized
DEBUG - 2016-09-15 18:17:08 --> Index MX_Controller Initialized
INFO - 2016-09-15 18:17:08 --> Model Class Initialized
INFO - 2016-09-15 18:17:08 --> Model Class Initialized
DEBUG - 2016-09-15 18:17:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_pinjaman.php
INFO - 2016-09-15 18:17:08 --> Final output sent to browser
DEBUG - 2016-09-15 18:17:08 --> Total execution time: 0.6841
INFO - 2016-09-15 18:18:03 --> Config Class Initialized
INFO - 2016-09-15 18:18:03 --> Hooks Class Initialized
DEBUG - 2016-09-15 18:18:03 --> UTF-8 Support Enabled
INFO - 2016-09-15 18:18:03 --> Utf8 Class Initialized
INFO - 2016-09-15 18:18:03 --> URI Class Initialized
INFO - 2016-09-15 18:18:03 --> Router Class Initialized
INFO - 2016-09-15 18:18:03 --> Output Class Initialized
INFO - 2016-09-15 18:18:03 --> Security Class Initialized
DEBUG - 2016-09-15 18:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 18:18:03 --> Input Class Initialized
INFO - 2016-09-15 18:18:03 --> Language Class Initialized
INFO - 2016-09-15 18:18:03 --> Language Class Initialized
INFO - 2016-09-15 18:18:03 --> Config Class Initialized
INFO - 2016-09-15 18:18:03 --> Loader Class Initialized
INFO - 2016-09-15 18:18:03 --> Helper loaded: url_helper
INFO - 2016-09-15 18:18:03 --> Database Driver Class Initialized
INFO - 2016-09-15 18:18:03 --> Controller Class Initialized
DEBUG - 2016-09-15 18:18:03 --> Index MX_Controller Initialized
INFO - 2016-09-15 18:18:03 --> Model Class Initialized
INFO - 2016-09-15 18:18:04 --> Model Class Initialized
DEBUG - 2016-09-15 18:18:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_pinjaman.php
INFO - 2016-09-15 18:18:04 --> Final output sent to browser
DEBUG - 2016-09-15 18:18:04 --> Total execution time: 0.7289
INFO - 2016-09-15 18:18:15 --> Config Class Initialized
INFO - 2016-09-15 18:18:15 --> Hooks Class Initialized
DEBUG - 2016-09-15 18:18:15 --> UTF-8 Support Enabled
INFO - 2016-09-15 18:18:15 --> Utf8 Class Initialized
INFO - 2016-09-15 18:18:15 --> URI Class Initialized
INFO - 2016-09-15 18:18:15 --> Router Class Initialized
INFO - 2016-09-15 18:18:15 --> Output Class Initialized
INFO - 2016-09-15 18:18:15 --> Security Class Initialized
DEBUG - 2016-09-15 18:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 18:18:15 --> Input Class Initialized
INFO - 2016-09-15 18:18:15 --> Language Class Initialized
INFO - 2016-09-15 18:18:15 --> Language Class Initialized
INFO - 2016-09-15 18:18:15 --> Config Class Initialized
INFO - 2016-09-15 18:18:15 --> Loader Class Initialized
INFO - 2016-09-15 18:18:15 --> Helper loaded: url_helper
INFO - 2016-09-15 18:18:15 --> Database Driver Class Initialized
INFO - 2016-09-15 18:18:15 --> Controller Class Initialized
DEBUG - 2016-09-15 18:18:15 --> Index MX_Controller Initialized
INFO - 2016-09-15 18:18:15 --> Model Class Initialized
INFO - 2016-09-15 18:18:15 --> Model Class Initialized
DEBUG - 2016-09-15 18:18:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_pinjaman.php
INFO - 2016-09-15 18:18:16 --> Final output sent to browser
DEBUG - 2016-09-15 18:18:16 --> Total execution time: 0.7118
INFO - 2016-09-15 18:56:51 --> Config Class Initialized
INFO - 2016-09-15 18:56:51 --> Hooks Class Initialized
DEBUG - 2016-09-15 18:56:51 --> UTF-8 Support Enabled
INFO - 2016-09-15 18:56:51 --> Utf8 Class Initialized
INFO - 2016-09-15 18:56:51 --> URI Class Initialized
INFO - 2016-09-15 18:56:51 --> Router Class Initialized
INFO - 2016-09-15 18:56:51 --> Output Class Initialized
INFO - 2016-09-15 18:56:51 --> Security Class Initialized
DEBUG - 2016-09-15 18:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 18:56:51 --> Input Class Initialized
INFO - 2016-09-15 18:56:51 --> Language Class Initialized
INFO - 2016-09-15 18:56:51 --> Language Class Initialized
INFO - 2016-09-15 18:56:51 --> Config Class Initialized
INFO - 2016-09-15 18:56:51 --> Loader Class Initialized
INFO - 2016-09-15 18:56:51 --> Helper loaded: url_helper
INFO - 2016-09-15 18:56:51 --> Database Driver Class Initialized
INFO - 2016-09-15 18:56:51 --> Controller Class Initialized
DEBUG - 2016-09-15 18:56:51 --> Index MX_Controller Initialized
INFO - 2016-09-15 18:56:51 --> Model Class Initialized
INFO - 2016-09-15 18:56:51 --> Model Class Initialized
DEBUG - 2016-09-15 18:56:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 18:56:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 18:56:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 18:56:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/angsuran.php
DEBUG - 2016-09-15 18:56:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 18:56:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 18:56:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 18:56:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 18:56:52 --> Final output sent to browser
DEBUG - 2016-09-15 18:56:52 --> Total execution time: 0.9324
INFO - 2016-09-15 18:56:57 --> Config Class Initialized
INFO - 2016-09-15 18:56:57 --> Hooks Class Initialized
DEBUG - 2016-09-15 18:56:57 --> UTF-8 Support Enabled
INFO - 2016-09-15 18:56:57 --> Utf8 Class Initialized
INFO - 2016-09-15 18:56:57 --> URI Class Initialized
INFO - 2016-09-15 18:56:57 --> Router Class Initialized
INFO - 2016-09-15 18:56:57 --> Output Class Initialized
INFO - 2016-09-15 18:56:57 --> Security Class Initialized
DEBUG - 2016-09-15 18:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 18:56:57 --> Input Class Initialized
INFO - 2016-09-15 18:56:57 --> Language Class Initialized
INFO - 2016-09-15 18:56:57 --> Language Class Initialized
INFO - 2016-09-15 18:56:57 --> Config Class Initialized
INFO - 2016-09-15 18:56:57 --> Loader Class Initialized
INFO - 2016-09-15 18:56:57 --> Helper loaded: url_helper
INFO - 2016-09-15 18:56:57 --> Database Driver Class Initialized
INFO - 2016-09-15 18:56:57 --> Controller Class Initialized
DEBUG - 2016-09-15 18:56:57 --> Index MX_Controller Initialized
INFO - 2016-09-15 18:56:57 --> Model Class Initialized
INFO - 2016-09-15 18:56:57 --> Model Class Initialized
DEBUG - 2016-09-15 18:56:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_pinjaman.php
INFO - 2016-09-15 18:56:57 --> Final output sent to browser
DEBUG - 2016-09-15 18:56:57 --> Total execution time: 0.7020
INFO - 2016-09-15 18:57:10 --> Config Class Initialized
INFO - 2016-09-15 18:57:10 --> Hooks Class Initialized
DEBUG - 2016-09-15 18:57:10 --> UTF-8 Support Enabled
INFO - 2016-09-15 18:57:10 --> Utf8 Class Initialized
INFO - 2016-09-15 18:57:10 --> URI Class Initialized
INFO - 2016-09-15 18:57:10 --> Router Class Initialized
INFO - 2016-09-15 18:57:10 --> Output Class Initialized
INFO - 2016-09-15 18:57:10 --> Security Class Initialized
DEBUG - 2016-09-15 18:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 18:57:10 --> Input Class Initialized
INFO - 2016-09-15 18:57:10 --> Language Class Initialized
INFO - 2016-09-15 18:57:10 --> Language Class Initialized
INFO - 2016-09-15 18:57:10 --> Config Class Initialized
INFO - 2016-09-15 18:57:10 --> Loader Class Initialized
INFO - 2016-09-15 18:57:10 --> Helper loaded: url_helper
INFO - 2016-09-15 18:57:10 --> Database Driver Class Initialized
INFO - 2016-09-15 18:57:10 --> Controller Class Initialized
DEBUG - 2016-09-15 18:57:10 --> Index MX_Controller Initialized
INFO - 2016-09-15 18:57:10 --> Model Class Initialized
INFO - 2016-09-15 18:57:10 --> Model Class Initialized
ERROR - 2016-09-15 18:57:11 --> Severity: Notice --> Undefined variable: dataAngsuran E:\SERVER\htdocs\koperasiweda\application\views\main_html\content\laporan\data_angsuran.php 17
ERROR - 2016-09-15 18:57:11 --> Severity: Error --> Call to a member function num_rows() on null E:\SERVER\htdocs\koperasiweda\application\views\main_html\content\laporan\data_angsuran.php 17
INFO - 2016-09-15 18:57:21 --> Config Class Initialized
INFO - 2016-09-15 18:57:21 --> Hooks Class Initialized
DEBUG - 2016-09-15 18:57:21 --> UTF-8 Support Enabled
INFO - 2016-09-15 18:57:21 --> Utf8 Class Initialized
INFO - 2016-09-15 18:57:21 --> URI Class Initialized
INFO - 2016-09-15 18:57:21 --> Router Class Initialized
INFO - 2016-09-15 18:57:21 --> Output Class Initialized
INFO - 2016-09-15 18:57:21 --> Security Class Initialized
DEBUG - 2016-09-15 18:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 18:57:21 --> Input Class Initialized
INFO - 2016-09-15 18:57:21 --> Language Class Initialized
INFO - 2016-09-15 18:57:21 --> Language Class Initialized
INFO - 2016-09-15 18:57:21 --> Config Class Initialized
INFO - 2016-09-15 18:57:22 --> Loader Class Initialized
INFO - 2016-09-15 18:57:22 --> Helper loaded: url_helper
INFO - 2016-09-15 18:57:22 --> Database Driver Class Initialized
INFO - 2016-09-15 18:57:22 --> Controller Class Initialized
DEBUG - 2016-09-15 18:57:22 --> Index MX_Controller Initialized
INFO - 2016-09-15 18:57:22 --> Model Class Initialized
INFO - 2016-09-15 18:57:22 --> Model Class Initialized
ERROR - 2016-09-15 18:57:22 --> Severity: Notice --> Undefined variable: dataAngsuran E:\SERVER\htdocs\koperasiweda\application\views\main_html\content\laporan\data_angsuran.php 17
ERROR - 2016-09-15 18:57:22 --> Severity: Error --> Call to a member function num_rows() on null E:\SERVER\htdocs\koperasiweda\application\views\main_html\content\laporan\data_angsuran.php 17
INFO - 2016-09-15 18:57:52 --> Config Class Initialized
INFO - 2016-09-15 18:57:52 --> Hooks Class Initialized
DEBUG - 2016-09-15 18:57:52 --> UTF-8 Support Enabled
INFO - 2016-09-15 18:57:52 --> Utf8 Class Initialized
INFO - 2016-09-15 18:57:52 --> URI Class Initialized
INFO - 2016-09-15 18:57:52 --> Router Class Initialized
INFO - 2016-09-15 18:57:52 --> Output Class Initialized
INFO - 2016-09-15 18:57:52 --> Security Class Initialized
DEBUG - 2016-09-15 18:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 18:57:52 --> Input Class Initialized
INFO - 2016-09-15 18:57:52 --> Language Class Initialized
INFO - 2016-09-15 18:57:52 --> Language Class Initialized
INFO - 2016-09-15 18:57:52 --> Config Class Initialized
INFO - 2016-09-15 18:57:52 --> Loader Class Initialized
INFO - 2016-09-15 18:57:53 --> Helper loaded: url_helper
INFO - 2016-09-15 18:57:53 --> Database Driver Class Initialized
INFO - 2016-09-15 18:57:53 --> Controller Class Initialized
DEBUG - 2016-09-15 18:57:53 --> Index MX_Controller Initialized
INFO - 2016-09-15 18:57:53 --> Model Class Initialized
INFO - 2016-09-15 18:57:53 --> Model Class Initialized
DEBUG - 2016-09-15 18:57:53 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 18:57:53 --> Index MX_Controller Initialized
ERROR - 2016-09-15 18:57:53 --> Severity: Compile Error --> Cannot redeclare class Anggota E:\SERVER\htdocs\koperasiweda\application\modules\Anggota\controllers\Anggota.php 86
INFO - 2016-09-15 18:59:30 --> Config Class Initialized
INFO - 2016-09-15 18:59:30 --> Hooks Class Initialized
DEBUG - 2016-09-15 18:59:30 --> UTF-8 Support Enabled
INFO - 2016-09-15 18:59:30 --> Utf8 Class Initialized
INFO - 2016-09-15 18:59:30 --> URI Class Initialized
INFO - 2016-09-15 18:59:30 --> Router Class Initialized
INFO - 2016-09-15 18:59:30 --> Output Class Initialized
INFO - 2016-09-15 18:59:30 --> Security Class Initialized
DEBUG - 2016-09-15 18:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 18:59:31 --> Input Class Initialized
INFO - 2016-09-15 18:59:31 --> Language Class Initialized
INFO - 2016-09-15 18:59:31 --> Language Class Initialized
INFO - 2016-09-15 18:59:31 --> Config Class Initialized
INFO - 2016-09-15 18:59:31 --> Loader Class Initialized
INFO - 2016-09-15 18:59:31 --> Helper loaded: url_helper
INFO - 2016-09-15 18:59:31 --> Database Driver Class Initialized
INFO - 2016-09-15 18:59:31 --> Controller Class Initialized
DEBUG - 2016-09-15 18:59:31 --> Index MX_Controller Initialized
INFO - 2016-09-15 18:59:31 --> Model Class Initialized
INFO - 2016-09-15 18:59:31 --> Model Class Initialized
DEBUG - 2016-09-15 18:59:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 18:59:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 18:59:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 18:59:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/angsuran.php
DEBUG - 2016-09-15 18:59:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 18:59:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 18:59:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 18:59:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 18:59:31 --> Final output sent to browser
DEBUG - 2016-09-15 18:59:31 --> Total execution time: 1.0098
INFO - 2016-09-15 18:59:48 --> Config Class Initialized
INFO - 2016-09-15 18:59:48 --> Hooks Class Initialized
DEBUG - 2016-09-15 18:59:48 --> UTF-8 Support Enabled
INFO - 2016-09-15 18:59:48 --> Utf8 Class Initialized
INFO - 2016-09-15 18:59:48 --> URI Class Initialized
INFO - 2016-09-15 18:59:48 --> Router Class Initialized
INFO - 2016-09-15 18:59:48 --> Output Class Initialized
INFO - 2016-09-15 18:59:48 --> Security Class Initialized
DEBUG - 2016-09-15 18:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 18:59:48 --> Input Class Initialized
INFO - 2016-09-15 18:59:48 --> Language Class Initialized
INFO - 2016-09-15 18:59:48 --> Language Class Initialized
INFO - 2016-09-15 18:59:48 --> Config Class Initialized
INFO - 2016-09-15 18:59:48 --> Loader Class Initialized
INFO - 2016-09-15 18:59:48 --> Helper loaded: url_helper
INFO - 2016-09-15 18:59:48 --> Database Driver Class Initialized
INFO - 2016-09-15 18:59:48 --> Controller Class Initialized
DEBUG - 2016-09-15 18:59:48 --> Index MX_Controller Initialized
INFO - 2016-09-15 18:59:48 --> Model Class Initialized
INFO - 2016-09-15 18:59:48 --> Model Class Initialized
DEBUG - 2016-09-15 18:59:48 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 18:59:48 --> Index MX_Controller Initialized
ERROR - 2016-09-15 18:59:48 --> Severity: Compile Error --> Cannot redeclare class Anggota E:\SERVER\htdocs\koperasiweda\application\modules\Anggota\controllers\Anggota.php 86
INFO - 2016-09-15 19:01:51 --> Config Class Initialized
INFO - 2016-09-15 19:01:51 --> Hooks Class Initialized
DEBUG - 2016-09-15 19:01:51 --> UTF-8 Support Enabled
INFO - 2016-09-15 19:01:51 --> Utf8 Class Initialized
INFO - 2016-09-15 19:01:51 --> URI Class Initialized
INFO - 2016-09-15 19:01:51 --> Router Class Initialized
INFO - 2016-09-15 19:01:51 --> Output Class Initialized
INFO - 2016-09-15 19:01:51 --> Security Class Initialized
DEBUG - 2016-09-15 19:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 19:01:51 --> Input Class Initialized
INFO - 2016-09-15 19:01:51 --> Language Class Initialized
INFO - 2016-09-15 19:01:51 --> Language Class Initialized
INFO - 2016-09-15 19:01:51 --> Config Class Initialized
INFO - 2016-09-15 19:01:51 --> Loader Class Initialized
INFO - 2016-09-15 19:01:51 --> Helper loaded: url_helper
INFO - 2016-09-15 19:01:51 --> Database Driver Class Initialized
INFO - 2016-09-15 19:01:51 --> Controller Class Initialized
DEBUG - 2016-09-15 19:01:51 --> Index MX_Controller Initialized
INFO - 2016-09-15 19:01:51 --> Model Class Initialized
INFO - 2016-09-15 19:01:52 --> Model Class Initialized
DEBUG - 2016-09-15 19:01:52 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:01:52 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:01:52 --> Severity: Compile Error --> Cannot redeclare class Anggota E:\SERVER\htdocs\koperasiweda\application\modules\Anggota\controllers\Anggota.php 86
INFO - 2016-09-15 19:02:32 --> Config Class Initialized
INFO - 2016-09-15 19:02:32 --> Hooks Class Initialized
DEBUG - 2016-09-15 19:02:32 --> UTF-8 Support Enabled
INFO - 2016-09-15 19:02:32 --> Utf8 Class Initialized
INFO - 2016-09-15 19:02:32 --> URI Class Initialized
INFO - 2016-09-15 19:02:32 --> Router Class Initialized
INFO - 2016-09-15 19:02:32 --> Output Class Initialized
INFO - 2016-09-15 19:02:32 --> Security Class Initialized
DEBUG - 2016-09-15 19:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 19:02:32 --> Input Class Initialized
INFO - 2016-09-15 19:02:32 --> Language Class Initialized
INFO - 2016-09-15 19:02:32 --> Language Class Initialized
INFO - 2016-09-15 19:02:32 --> Config Class Initialized
INFO - 2016-09-15 19:02:32 --> Loader Class Initialized
INFO - 2016-09-15 19:02:32 --> Helper loaded: url_helper
INFO - 2016-09-15 19:02:32 --> Database Driver Class Initialized
INFO - 2016-09-15 19:02:32 --> Controller Class Initialized
DEBUG - 2016-09-15 19:02:33 --> Index MX_Controller Initialized
INFO - 2016-09-15 19:02:33 --> Model Class Initialized
INFO - 2016-09-15 19:02:33 --> Model Class Initialized
INFO - 2016-09-15 19:02:33 --> Final output sent to browser
DEBUG - 2016-09-15 19:02:33 --> Total execution time: 0.7353
INFO - 2016-09-15 19:02:47 --> Config Class Initialized
INFO - 2016-09-15 19:02:47 --> Hooks Class Initialized
DEBUG - 2016-09-15 19:02:48 --> UTF-8 Support Enabled
INFO - 2016-09-15 19:02:48 --> Utf8 Class Initialized
INFO - 2016-09-15 19:02:48 --> URI Class Initialized
INFO - 2016-09-15 19:02:48 --> Router Class Initialized
INFO - 2016-09-15 19:02:48 --> Output Class Initialized
INFO - 2016-09-15 19:02:48 --> Security Class Initialized
DEBUG - 2016-09-15 19:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 19:02:48 --> Input Class Initialized
INFO - 2016-09-15 19:02:48 --> Language Class Initialized
INFO - 2016-09-15 19:02:48 --> Language Class Initialized
INFO - 2016-09-15 19:02:48 --> Config Class Initialized
INFO - 2016-09-15 19:02:48 --> Loader Class Initialized
INFO - 2016-09-15 19:02:48 --> Helper loaded: url_helper
INFO - 2016-09-15 19:02:48 --> Database Driver Class Initialized
INFO - 2016-09-15 19:02:48 --> Controller Class Initialized
DEBUG - 2016-09-15 19:02:48 --> Index MX_Controller Initialized
INFO - 2016-09-15 19:02:48 --> Model Class Initialized
INFO - 2016-09-15 19:02:48 --> Model Class Initialized
INFO - 2016-09-15 19:02:48 --> Final output sent to browser
DEBUG - 2016-09-15 19:02:48 --> Total execution time: 0.7180
INFO - 2016-09-15 19:02:54 --> Config Class Initialized
INFO - 2016-09-15 19:02:55 --> Hooks Class Initialized
DEBUG - 2016-09-15 19:02:55 --> UTF-8 Support Enabled
INFO - 2016-09-15 19:02:55 --> Utf8 Class Initialized
INFO - 2016-09-15 19:02:55 --> URI Class Initialized
INFO - 2016-09-15 19:02:55 --> Router Class Initialized
INFO - 2016-09-15 19:02:55 --> Output Class Initialized
INFO - 2016-09-15 19:02:55 --> Security Class Initialized
DEBUG - 2016-09-15 19:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 19:02:55 --> Input Class Initialized
INFO - 2016-09-15 19:02:55 --> Language Class Initialized
INFO - 2016-09-15 19:02:55 --> Language Class Initialized
INFO - 2016-09-15 19:02:55 --> Config Class Initialized
INFO - 2016-09-15 19:02:55 --> Loader Class Initialized
INFO - 2016-09-15 19:02:55 --> Helper loaded: url_helper
INFO - 2016-09-15 19:02:55 --> Database Driver Class Initialized
INFO - 2016-09-15 19:02:55 --> Controller Class Initialized
DEBUG - 2016-09-15 19:02:55 --> Index MX_Controller Initialized
INFO - 2016-09-15 19:02:55 --> Model Class Initialized
INFO - 2016-09-15 19:02:55 --> Model Class Initialized
INFO - 2016-09-15 19:02:55 --> Final output sent to browser
DEBUG - 2016-09-15 19:02:55 --> Total execution time: 0.7443
INFO - 2016-09-15 19:02:59 --> Config Class Initialized
INFO - 2016-09-15 19:02:59 --> Hooks Class Initialized
DEBUG - 2016-09-15 19:03:00 --> UTF-8 Support Enabled
INFO - 2016-09-15 19:03:00 --> Utf8 Class Initialized
INFO - 2016-09-15 19:03:00 --> URI Class Initialized
INFO - 2016-09-15 19:03:00 --> Router Class Initialized
INFO - 2016-09-15 19:03:00 --> Output Class Initialized
INFO - 2016-09-15 19:03:00 --> Security Class Initialized
DEBUG - 2016-09-15 19:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 19:03:00 --> Input Class Initialized
INFO - 2016-09-15 19:03:00 --> Language Class Initialized
INFO - 2016-09-15 19:03:00 --> Language Class Initialized
INFO - 2016-09-15 19:03:00 --> Config Class Initialized
INFO - 2016-09-15 19:03:00 --> Loader Class Initialized
INFO - 2016-09-15 19:03:00 --> Helper loaded: url_helper
INFO - 2016-09-15 19:03:00 --> Database Driver Class Initialized
INFO - 2016-09-15 19:03:00 --> Controller Class Initialized
DEBUG - 2016-09-15 19:03:00 --> Index MX_Controller Initialized
INFO - 2016-09-15 19:03:00 --> Model Class Initialized
INFO - 2016-09-15 19:03:00 --> Model Class Initialized
INFO - 2016-09-15 19:03:00 --> Final output sent to browser
DEBUG - 2016-09-15 19:03:00 --> Total execution time: 0.8016
INFO - 2016-09-15 19:03:47 --> Config Class Initialized
INFO - 2016-09-15 19:03:47 --> Hooks Class Initialized
DEBUG - 2016-09-15 19:03:47 --> UTF-8 Support Enabled
INFO - 2016-09-15 19:03:47 --> Utf8 Class Initialized
INFO - 2016-09-15 19:03:47 --> URI Class Initialized
INFO - 2016-09-15 19:03:47 --> Router Class Initialized
INFO - 2016-09-15 19:03:47 --> Output Class Initialized
INFO - 2016-09-15 19:03:47 --> Security Class Initialized
DEBUG - 2016-09-15 19:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 19:03:47 --> Input Class Initialized
INFO - 2016-09-15 19:03:47 --> Language Class Initialized
INFO - 2016-09-15 19:03:47 --> Language Class Initialized
INFO - 2016-09-15 19:03:47 --> Config Class Initialized
INFO - 2016-09-15 19:03:47 --> Loader Class Initialized
INFO - 2016-09-15 19:03:47 --> Helper loaded: url_helper
INFO - 2016-09-15 19:03:47 --> Database Driver Class Initialized
INFO - 2016-09-15 19:03:47 --> Controller Class Initialized
DEBUG - 2016-09-15 19:03:47 --> Index MX_Controller Initialized
INFO - 2016-09-15 19:03:47 --> Model Class Initialized
INFO - 2016-09-15 19:03:47 --> Model Class Initialized
DEBUG - 2016-09-15 19:03:48 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:03:48 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:03:48 --> Severity: Compile Error --> Cannot redeclare class Anggota E:\SERVER\htdocs\koperasiweda\application\modules\Anggota\controllers\Anggota.php 86
INFO - 2016-09-15 19:03:54 --> Config Class Initialized
INFO - 2016-09-15 19:03:54 --> Hooks Class Initialized
DEBUG - 2016-09-15 19:03:54 --> UTF-8 Support Enabled
INFO - 2016-09-15 19:03:54 --> Utf8 Class Initialized
INFO - 2016-09-15 19:03:54 --> URI Class Initialized
INFO - 2016-09-15 19:03:54 --> Router Class Initialized
INFO - 2016-09-15 19:03:54 --> Output Class Initialized
INFO - 2016-09-15 19:03:54 --> Security Class Initialized
DEBUG - 2016-09-15 19:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 19:03:54 --> Input Class Initialized
INFO - 2016-09-15 19:03:54 --> Language Class Initialized
INFO - 2016-09-15 19:03:54 --> Language Class Initialized
INFO - 2016-09-15 19:03:54 --> Config Class Initialized
INFO - 2016-09-15 19:03:54 --> Loader Class Initialized
INFO - 2016-09-15 19:03:54 --> Helper loaded: url_helper
INFO - 2016-09-15 19:03:55 --> Database Driver Class Initialized
INFO - 2016-09-15 19:03:55 --> Controller Class Initialized
DEBUG - 2016-09-15 19:03:55 --> Index MX_Controller Initialized
INFO - 2016-09-15 19:03:55 --> Model Class Initialized
INFO - 2016-09-15 19:03:55 --> Model Class Initialized
DEBUG - 2016-09-15 19:03:55 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:03:55 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:03:55 --> Severity: Compile Error --> Cannot redeclare class Anggota E:\SERVER\htdocs\koperasiweda\application\modules\Anggota\controllers\Anggota.php 86
INFO - 2016-09-15 19:04:00 --> Config Class Initialized
INFO - 2016-09-15 19:04:00 --> Hooks Class Initialized
DEBUG - 2016-09-15 19:04:00 --> UTF-8 Support Enabled
INFO - 2016-09-15 19:04:00 --> Utf8 Class Initialized
INFO - 2016-09-15 19:04:00 --> URI Class Initialized
INFO - 2016-09-15 19:04:00 --> Router Class Initialized
INFO - 2016-09-15 19:04:00 --> Output Class Initialized
INFO - 2016-09-15 19:04:00 --> Security Class Initialized
DEBUG - 2016-09-15 19:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 19:04:00 --> Input Class Initialized
INFO - 2016-09-15 19:04:00 --> Language Class Initialized
INFO - 2016-09-15 19:04:00 --> Language Class Initialized
INFO - 2016-09-15 19:04:00 --> Config Class Initialized
INFO - 2016-09-15 19:04:00 --> Loader Class Initialized
INFO - 2016-09-15 19:04:00 --> Helper loaded: url_helper
INFO - 2016-09-15 19:04:00 --> Database Driver Class Initialized
INFO - 2016-09-15 19:04:00 --> Controller Class Initialized
DEBUG - 2016-09-15 19:04:00 --> Index MX_Controller Initialized
INFO - 2016-09-15 19:04:00 --> Model Class Initialized
INFO - 2016-09-15 19:04:00 --> Model Class Initialized
DEBUG - 2016-09-15 19:04:00 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:04:00 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:04:00 --> Severity: Compile Error --> Cannot redeclare class Anggota E:\SERVER\htdocs\koperasiweda\application\modules\Anggota\controllers\Anggota.php 86
INFO - 2016-09-15 19:05:10 --> Config Class Initialized
INFO - 2016-09-15 19:05:10 --> Hooks Class Initialized
DEBUG - 2016-09-15 19:05:10 --> UTF-8 Support Enabled
INFO - 2016-09-15 19:05:10 --> Utf8 Class Initialized
INFO - 2016-09-15 19:05:10 --> URI Class Initialized
INFO - 2016-09-15 19:05:10 --> Router Class Initialized
INFO - 2016-09-15 19:05:10 --> Output Class Initialized
INFO - 2016-09-15 19:05:10 --> Security Class Initialized
DEBUG - 2016-09-15 19:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 19:05:10 --> Input Class Initialized
INFO - 2016-09-15 19:05:10 --> Language Class Initialized
INFO - 2016-09-15 19:05:11 --> Language Class Initialized
INFO - 2016-09-15 19:05:11 --> Config Class Initialized
INFO - 2016-09-15 19:05:11 --> Loader Class Initialized
INFO - 2016-09-15 19:05:11 --> Helper loaded: url_helper
INFO - 2016-09-15 19:05:11 --> Database Driver Class Initialized
INFO - 2016-09-15 19:05:11 --> Controller Class Initialized
DEBUG - 2016-09-15 19:05:11 --> Index MX_Controller Initialized
INFO - 2016-09-15 19:05:11 --> Model Class Initialized
INFO - 2016-09-15 19:05:11 --> Model Class Initialized
ERROR - 2016-09-15 19:05:11 --> Severity: Warning --> require(E:\SERVER\htdocs\koperasiweda\application\\modules\anggota\controllers\Anggota.php): failed to open stream: No such file or directory E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 7
ERROR - 2016-09-15 19:05:11 --> Severity: Compile Error --> require(): Failed opening required 'E:\SERVER\htdocs\koperasiweda\application\\modules\anggota\controllers\Anggota.php' (include_path='E:\SERVER\php\PEAR') E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 7
INFO - 2016-09-15 19:05:39 --> Config Class Initialized
INFO - 2016-09-15 19:05:39 --> Hooks Class Initialized
DEBUG - 2016-09-15 19:05:40 --> UTF-8 Support Enabled
INFO - 2016-09-15 19:05:40 --> Utf8 Class Initialized
INFO - 2016-09-15 19:05:40 --> URI Class Initialized
INFO - 2016-09-15 19:05:40 --> Router Class Initialized
INFO - 2016-09-15 19:05:40 --> Output Class Initialized
INFO - 2016-09-15 19:05:40 --> Security Class Initialized
DEBUG - 2016-09-15 19:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 19:05:40 --> Input Class Initialized
INFO - 2016-09-15 19:05:40 --> Language Class Initialized
INFO - 2016-09-15 19:05:40 --> Language Class Initialized
INFO - 2016-09-15 19:05:40 --> Config Class Initialized
INFO - 2016-09-15 19:05:40 --> Loader Class Initialized
INFO - 2016-09-15 19:05:40 --> Helper loaded: url_helper
INFO - 2016-09-15 19:05:40 --> Database Driver Class Initialized
INFO - 2016-09-15 19:05:40 --> Controller Class Initialized
DEBUG - 2016-09-15 19:05:40 --> Index MX_Controller Initialized
INFO - 2016-09-15 19:05:40 --> Model Class Initialized
INFO - 2016-09-15 19:05:40 --> Model Class Initialized
ERROR - 2016-09-15 19:05:40 --> Severity: Warning --> require_once(E:\SERVER\htdocs\koperasiweda\application\\modules\anggota\controllers\Anggota.php): failed to open stream: No such file or directory E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 7
ERROR - 2016-09-15 19:05:40 --> Severity: Compile Error --> require_once(): Failed opening required 'E:\SERVER\htdocs\koperasiweda\application\\modules\anggota\controllers\Anggota.php' (include_path='E:\SERVER\php\PEAR') E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 7
INFO - 2016-09-15 19:06:05 --> Config Class Initialized
INFO - 2016-09-15 19:06:05 --> Hooks Class Initialized
DEBUG - 2016-09-15 19:06:05 --> UTF-8 Support Enabled
INFO - 2016-09-15 19:06:05 --> Utf8 Class Initialized
INFO - 2016-09-15 19:06:05 --> URI Class Initialized
INFO - 2016-09-15 19:06:05 --> Router Class Initialized
INFO - 2016-09-15 19:06:05 --> Output Class Initialized
INFO - 2016-09-15 19:06:05 --> Security Class Initialized
DEBUG - 2016-09-15 19:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 19:06:05 --> Input Class Initialized
INFO - 2016-09-15 19:06:05 --> Language Class Initialized
INFO - 2016-09-15 19:06:05 --> Language Class Initialized
INFO - 2016-09-15 19:06:05 --> Config Class Initialized
INFO - 2016-09-15 19:06:05 --> Loader Class Initialized
INFO - 2016-09-15 19:06:05 --> Helper loaded: url_helper
INFO - 2016-09-15 19:06:05 --> Database Driver Class Initialized
INFO - 2016-09-15 19:06:05 --> Controller Class Initialized
DEBUG - 2016-09-15 19:06:05 --> Index MX_Controller Initialized
INFO - 2016-09-15 19:06:05 --> Model Class Initialized
INFO - 2016-09-15 19:06:05 --> Model Class Initialized
DEBUG - 2016-09-15 19:06:05 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:06:06 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:06:06 --> Module controller failed to run: admin/index/detailAngsuran/1574bddb75c78a6fd2251d61e2993b5146201319/total_angsuran
ERROR - 2016-09-15 19:06:06 --> Module controller failed to run: admin/index/detailAngsuran/1574bddb75c78a6fd2251d61e2993b5146201319/angsuran
ERROR - 2016-09-15 19:06:06 --> Module controller failed to run: admin/index/detailAngsuran/1574bddb75c78a6fd2251d61e2993b5146201319/bunga
DEBUG - 2016-09-15 19:06:06 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:06:06 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:06:06 --> Module controller failed to run: admin/index/detailAngsuran/0716d9708d321ffb6a00818614779e779925365c/total_angsuran
ERROR - 2016-09-15 19:06:06 --> Module controller failed to run: admin/index/detailAngsuran/0716d9708d321ffb6a00818614779e779925365c/angsuran
ERROR - 2016-09-15 19:06:06 --> Module controller failed to run: admin/index/detailAngsuran/0716d9708d321ffb6a00818614779e779925365c/bunga
DEBUG - 2016-09-15 19:06:06 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:06:06 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:06:06 --> Module controller failed to run: admin/index/detailAngsuran/9e6a55b6b4563e652a23be9d623ca5055c356940/total_angsuran
ERROR - 2016-09-15 19:06:06 --> Module controller failed to run: admin/index/detailAngsuran/9e6a55b6b4563e652a23be9d623ca5055c356940/angsuran
ERROR - 2016-09-15 19:06:06 --> Module controller failed to run: admin/index/detailAngsuran/9e6a55b6b4563e652a23be9d623ca5055c356940/bunga
DEBUG - 2016-09-15 19:06:06 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:06:06 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:06:06 --> Module controller failed to run: admin/index/detailAngsuran/f6e1126cedebf23e1463aee73f9df08783640400/total_angsuran
ERROR - 2016-09-15 19:06:06 --> Module controller failed to run: admin/index/detailAngsuran/f6e1126cedebf23e1463aee73f9df08783640400/angsuran
ERROR - 2016-09-15 19:06:06 --> Module controller failed to run: admin/index/detailAngsuran/f6e1126cedebf23e1463aee73f9df08783640400/bunga
DEBUG - 2016-09-15 19:06:06 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:06:06 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:06:06 --> Module controller failed to run: admin/index/detailAngsuran/887309d048beef83ad3eabf2a79a64a389ab1c9f/total_angsuran
ERROR - 2016-09-15 19:06:06 --> Module controller failed to run: admin/index/detailAngsuran/887309d048beef83ad3eabf2a79a64a389ab1c9f/angsuran
ERROR - 2016-09-15 19:06:06 --> Module controller failed to run: admin/index/detailAngsuran/887309d048beef83ad3eabf2a79a64a389ab1c9f/bunga
DEBUG - 2016-09-15 19:06:06 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:06:06 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:06:06 --> Module controller failed to run: admin/index/detailAngsuran/0a57cb53ba59c46fc4b692527a38a87c78d84028/total_angsuran
ERROR - 2016-09-15 19:06:06 --> Module controller failed to run: admin/index/detailAngsuran/0a57cb53ba59c46fc4b692527a38a87c78d84028/angsuran
ERROR - 2016-09-15 19:06:06 --> Module controller failed to run: admin/index/detailAngsuran/0a57cb53ba59c46fc4b692527a38a87c78d84028/bunga
DEBUG - 2016-09-15 19:06:06 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:06:06 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:06:06 --> Module controller failed to run: admin/index/detailAngsuran/7719a1c782a1ba91c031a682a0a2f8658209adbf/total_angsuran
ERROR - 2016-09-15 19:06:06 --> Module controller failed to run: admin/index/detailAngsuran/7719a1c782a1ba91c031a682a0a2f8658209adbf/angsuran
ERROR - 2016-09-15 19:06:06 --> Module controller failed to run: admin/index/detailAngsuran/7719a1c782a1ba91c031a682a0a2f8658209adbf/bunga
DEBUG - 2016-09-15 19:06:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_angsuran.php
INFO - 2016-09-15 19:06:07 --> Final output sent to browser
DEBUG - 2016-09-15 19:06:07 --> Total execution time: 1.8758
INFO - 2016-09-15 19:06:55 --> Config Class Initialized
INFO - 2016-09-15 19:06:55 --> Hooks Class Initialized
DEBUG - 2016-09-15 19:06:55 --> UTF-8 Support Enabled
INFO - 2016-09-15 19:06:55 --> Utf8 Class Initialized
INFO - 2016-09-15 19:06:55 --> URI Class Initialized
INFO - 2016-09-15 19:06:55 --> Router Class Initialized
INFO - 2016-09-15 19:06:55 --> Output Class Initialized
INFO - 2016-09-15 19:06:55 --> Security Class Initialized
DEBUG - 2016-09-15 19:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 19:06:55 --> Input Class Initialized
INFO - 2016-09-15 19:06:55 --> Language Class Initialized
INFO - 2016-09-15 19:06:55 --> Language Class Initialized
INFO - 2016-09-15 19:06:55 --> Config Class Initialized
INFO - 2016-09-15 19:06:55 --> Loader Class Initialized
INFO - 2016-09-15 19:06:55 --> Helper loaded: url_helper
INFO - 2016-09-15 19:06:55 --> Database Driver Class Initialized
INFO - 2016-09-15 19:06:56 --> Controller Class Initialized
DEBUG - 2016-09-15 19:06:56 --> Index MX_Controller Initialized
INFO - 2016-09-15 19:06:56 --> Model Class Initialized
INFO - 2016-09-15 19:06:56 --> Model Class Initialized
DEBUG - 2016-09-15 19:06:56 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:06:56 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:06:56 --> Module controller failed to run: admin/index/detailAngsuran/1574bddb75c78a6fd2251d61e2993b5146201319/total_angsuran
ERROR - 2016-09-15 19:06:56 --> Module controller failed to run: admin/index/detailAngsuran/1574bddb75c78a6fd2251d61e2993b5146201319/angsuran
ERROR - 2016-09-15 19:06:56 --> Module controller failed to run: admin/index/detailAngsuran/1574bddb75c78a6fd2251d61e2993b5146201319/bunga
DEBUG - 2016-09-15 19:06:56 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:06:56 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:06:56 --> Module controller failed to run: admin/index/detailAngsuran/0716d9708d321ffb6a00818614779e779925365c/total_angsuran
ERROR - 2016-09-15 19:06:56 --> Module controller failed to run: admin/index/detailAngsuran/0716d9708d321ffb6a00818614779e779925365c/angsuran
ERROR - 2016-09-15 19:06:56 --> Module controller failed to run: admin/index/detailAngsuran/0716d9708d321ffb6a00818614779e779925365c/bunga
DEBUG - 2016-09-15 19:06:56 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:06:56 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:06:56 --> Module controller failed to run: admin/index/detailAngsuran/9e6a55b6b4563e652a23be9d623ca5055c356940/total_angsuran
ERROR - 2016-09-15 19:06:56 --> Module controller failed to run: admin/index/detailAngsuran/9e6a55b6b4563e652a23be9d623ca5055c356940/angsuran
ERROR - 2016-09-15 19:06:56 --> Module controller failed to run: admin/index/detailAngsuran/9e6a55b6b4563e652a23be9d623ca5055c356940/bunga
DEBUG - 2016-09-15 19:06:56 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:06:56 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:06:56 --> Module controller failed to run: admin/index/detailAngsuran/f6e1126cedebf23e1463aee73f9df08783640400/total_angsuran
ERROR - 2016-09-15 19:06:56 --> Module controller failed to run: admin/index/detailAngsuran/f6e1126cedebf23e1463aee73f9df08783640400/angsuran
ERROR - 2016-09-15 19:06:56 --> Module controller failed to run: admin/index/detailAngsuran/f6e1126cedebf23e1463aee73f9df08783640400/bunga
DEBUG - 2016-09-15 19:06:56 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:06:56 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:06:56 --> Module controller failed to run: admin/index/detailAngsuran/887309d048beef83ad3eabf2a79a64a389ab1c9f/total_angsuran
ERROR - 2016-09-15 19:06:56 --> Module controller failed to run: admin/index/detailAngsuran/887309d048beef83ad3eabf2a79a64a389ab1c9f/angsuran
ERROR - 2016-09-15 19:06:56 --> Module controller failed to run: admin/index/detailAngsuran/887309d048beef83ad3eabf2a79a64a389ab1c9f/bunga
DEBUG - 2016-09-15 19:06:56 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:06:56 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:06:56 --> Module controller failed to run: admin/index/detailAngsuran/0a57cb53ba59c46fc4b692527a38a87c78d84028/total_angsuran
ERROR - 2016-09-15 19:06:57 --> Module controller failed to run: admin/index/detailAngsuran/0a57cb53ba59c46fc4b692527a38a87c78d84028/angsuran
ERROR - 2016-09-15 19:06:57 --> Module controller failed to run: admin/index/detailAngsuran/0a57cb53ba59c46fc4b692527a38a87c78d84028/bunga
DEBUG - 2016-09-15 19:06:57 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:06:57 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:06:57 --> Module controller failed to run: admin/index/detailAngsuran/7719a1c782a1ba91c031a682a0a2f8658209adbf/total_angsuran
ERROR - 2016-09-15 19:06:57 --> Module controller failed to run: admin/index/detailAngsuran/7719a1c782a1ba91c031a682a0a2f8658209adbf/angsuran
ERROR - 2016-09-15 19:06:57 --> Module controller failed to run: admin/index/detailAngsuran/7719a1c782a1ba91c031a682a0a2f8658209adbf/bunga
DEBUG - 2016-09-15 19:06:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_angsuran.php
INFO - 2016-09-15 19:06:57 --> Final output sent to browser
DEBUG - 2016-09-15 19:06:57 --> Total execution time: 1.8591
INFO - 2016-09-15 19:08:02 --> Config Class Initialized
INFO - 2016-09-15 19:08:02 --> Hooks Class Initialized
DEBUG - 2016-09-15 19:08:02 --> UTF-8 Support Enabled
INFO - 2016-09-15 19:08:02 --> Utf8 Class Initialized
INFO - 2016-09-15 19:08:02 --> URI Class Initialized
INFO - 2016-09-15 19:08:02 --> Router Class Initialized
INFO - 2016-09-15 19:08:02 --> Output Class Initialized
INFO - 2016-09-15 19:08:02 --> Security Class Initialized
DEBUG - 2016-09-15 19:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 19:08:02 --> Input Class Initialized
INFO - 2016-09-15 19:08:02 --> Language Class Initialized
INFO - 2016-09-15 19:08:02 --> Language Class Initialized
INFO - 2016-09-15 19:08:02 --> Config Class Initialized
INFO - 2016-09-15 19:08:02 --> Loader Class Initialized
INFO - 2016-09-15 19:08:02 --> Helper loaded: url_helper
INFO - 2016-09-15 19:08:02 --> Database Driver Class Initialized
INFO - 2016-09-15 19:08:02 --> Controller Class Initialized
DEBUG - 2016-09-15 19:08:02 --> Index MX_Controller Initialized
INFO - 2016-09-15 19:08:02 --> Model Class Initialized
INFO - 2016-09-15 19:08:02 --> Model Class Initialized
DEBUG - 2016-09-15 19:08:02 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/Admin/controllers/Index.php
DEBUG - 2016-09-15 19:08:03 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:08:03 --> Module controller failed to run: Admin/index/detailAngsuran/1574bddb75c78a6fd2251d61e2993b5146201319/total_angsuran
ERROR - 2016-09-15 19:08:03 --> Module controller failed to run: admin/index/detailAngsuran/1574bddb75c78a6fd2251d61e2993b5146201319/angsuran
ERROR - 2016-09-15 19:08:03 --> Module controller failed to run: admin/index/detailAngsuran/1574bddb75c78a6fd2251d61e2993b5146201319/bunga
DEBUG - 2016-09-15 19:08:03 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/Admin/controllers/Index.php
DEBUG - 2016-09-15 19:08:03 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:08:03 --> Module controller failed to run: Admin/index/detailAngsuran/0716d9708d321ffb6a00818614779e779925365c/total_angsuran
ERROR - 2016-09-15 19:08:03 --> Module controller failed to run: admin/index/detailAngsuran/0716d9708d321ffb6a00818614779e779925365c/angsuran
ERROR - 2016-09-15 19:08:03 --> Module controller failed to run: admin/index/detailAngsuran/0716d9708d321ffb6a00818614779e779925365c/bunga
DEBUG - 2016-09-15 19:08:03 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/Admin/controllers/Index.php
DEBUG - 2016-09-15 19:08:03 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:08:03 --> Module controller failed to run: Admin/index/detailAngsuran/9e6a55b6b4563e652a23be9d623ca5055c356940/total_angsuran
ERROR - 2016-09-15 19:08:03 --> Module controller failed to run: admin/index/detailAngsuran/9e6a55b6b4563e652a23be9d623ca5055c356940/angsuran
ERROR - 2016-09-15 19:08:03 --> Module controller failed to run: admin/index/detailAngsuran/9e6a55b6b4563e652a23be9d623ca5055c356940/bunga
DEBUG - 2016-09-15 19:08:03 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/Admin/controllers/Index.php
DEBUG - 2016-09-15 19:08:03 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:08:03 --> Module controller failed to run: Admin/index/detailAngsuran/f6e1126cedebf23e1463aee73f9df08783640400/total_angsuran
ERROR - 2016-09-15 19:08:03 --> Module controller failed to run: admin/index/detailAngsuran/f6e1126cedebf23e1463aee73f9df08783640400/angsuran
ERROR - 2016-09-15 19:08:03 --> Module controller failed to run: admin/index/detailAngsuran/f6e1126cedebf23e1463aee73f9df08783640400/bunga
DEBUG - 2016-09-15 19:08:03 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/Admin/controllers/Index.php
DEBUG - 2016-09-15 19:08:03 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:08:03 --> Module controller failed to run: Admin/index/detailAngsuran/887309d048beef83ad3eabf2a79a64a389ab1c9f/total_angsuran
ERROR - 2016-09-15 19:08:03 --> Module controller failed to run: admin/index/detailAngsuran/887309d048beef83ad3eabf2a79a64a389ab1c9f/angsuran
ERROR - 2016-09-15 19:08:03 --> Module controller failed to run: admin/index/detailAngsuran/887309d048beef83ad3eabf2a79a64a389ab1c9f/bunga
DEBUG - 2016-09-15 19:08:03 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/Admin/controllers/Index.php
DEBUG - 2016-09-15 19:08:03 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:08:03 --> Module controller failed to run: Admin/index/detailAngsuran/0a57cb53ba59c46fc4b692527a38a87c78d84028/total_angsuran
ERROR - 2016-09-15 19:08:03 --> Module controller failed to run: admin/index/detailAngsuran/0a57cb53ba59c46fc4b692527a38a87c78d84028/angsuran
ERROR - 2016-09-15 19:08:03 --> Module controller failed to run: admin/index/detailAngsuran/0a57cb53ba59c46fc4b692527a38a87c78d84028/bunga
DEBUG - 2016-09-15 19:08:03 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/Admin/controllers/Index.php
DEBUG - 2016-09-15 19:08:03 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:08:03 --> Module controller failed to run: Admin/index/detailAngsuran/7719a1c782a1ba91c031a682a0a2f8658209adbf/total_angsuran
ERROR - 2016-09-15 19:08:03 --> Module controller failed to run: admin/index/detailAngsuran/7719a1c782a1ba91c031a682a0a2f8658209adbf/angsuran
ERROR - 2016-09-15 19:08:03 --> Module controller failed to run: admin/index/detailAngsuran/7719a1c782a1ba91c031a682a0a2f8658209adbf/bunga
DEBUG - 2016-09-15 19:08:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_angsuran.php
INFO - 2016-09-15 19:08:04 --> Final output sent to browser
DEBUG - 2016-09-15 19:08:04 --> Total execution time: 1.7941
INFO - 2016-09-15 19:08:26 --> Config Class Initialized
INFO - 2016-09-15 19:08:26 --> Hooks Class Initialized
DEBUG - 2016-09-15 19:08:26 --> UTF-8 Support Enabled
INFO - 2016-09-15 19:08:26 --> Utf8 Class Initialized
INFO - 2016-09-15 19:08:26 --> URI Class Initialized
INFO - 2016-09-15 19:08:26 --> Router Class Initialized
INFO - 2016-09-15 19:08:26 --> Output Class Initialized
INFO - 2016-09-15 19:08:26 --> Security Class Initialized
DEBUG - 2016-09-15 19:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 19:08:26 --> Input Class Initialized
INFO - 2016-09-15 19:08:26 --> Language Class Initialized
INFO - 2016-09-15 19:08:26 --> Language Class Initialized
INFO - 2016-09-15 19:08:26 --> Config Class Initialized
INFO - 2016-09-15 19:08:26 --> Loader Class Initialized
INFO - 2016-09-15 19:08:26 --> Helper loaded: url_helper
INFO - 2016-09-15 19:08:26 --> Database Driver Class Initialized
INFO - 2016-09-15 19:08:26 --> Controller Class Initialized
DEBUG - 2016-09-15 19:08:26 --> Index MX_Controller Initialized
INFO - 2016-09-15 19:08:26 --> Model Class Initialized
INFO - 2016-09-15 19:08:26 --> Model Class Initialized
DEBUG - 2016-09-15 19:08:26 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/Admin/controllers/Index.php
DEBUG - 2016-09-15 19:08:26 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:08:27 --> Module controller failed to run: Admin/Index/detailAngsuran/1574bddb75c78a6fd2251d61e2993b5146201319/total_angsuran
ERROR - 2016-09-15 19:08:27 --> Module controller failed to run: admin/index/detailAngsuran/1574bddb75c78a6fd2251d61e2993b5146201319/angsuran
ERROR - 2016-09-15 19:08:27 --> Module controller failed to run: admin/index/detailAngsuran/1574bddb75c78a6fd2251d61e2993b5146201319/bunga
DEBUG - 2016-09-15 19:08:27 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/Admin/controllers/Index.php
DEBUG - 2016-09-15 19:08:27 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:08:27 --> Module controller failed to run: Admin/Index/detailAngsuran/0716d9708d321ffb6a00818614779e779925365c/total_angsuran
ERROR - 2016-09-15 19:08:27 --> Module controller failed to run: admin/index/detailAngsuran/0716d9708d321ffb6a00818614779e779925365c/angsuran
ERROR - 2016-09-15 19:08:27 --> Module controller failed to run: admin/index/detailAngsuran/0716d9708d321ffb6a00818614779e779925365c/bunga
DEBUG - 2016-09-15 19:08:27 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/Admin/controllers/Index.php
DEBUG - 2016-09-15 19:08:27 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:08:27 --> Module controller failed to run: Admin/Index/detailAngsuran/9e6a55b6b4563e652a23be9d623ca5055c356940/total_angsuran
ERROR - 2016-09-15 19:08:27 --> Module controller failed to run: admin/index/detailAngsuran/9e6a55b6b4563e652a23be9d623ca5055c356940/angsuran
ERROR - 2016-09-15 19:08:27 --> Module controller failed to run: admin/index/detailAngsuran/9e6a55b6b4563e652a23be9d623ca5055c356940/bunga
DEBUG - 2016-09-15 19:08:27 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/Admin/controllers/Index.php
DEBUG - 2016-09-15 19:08:27 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:08:27 --> Module controller failed to run: Admin/Index/detailAngsuran/f6e1126cedebf23e1463aee73f9df08783640400/total_angsuran
ERROR - 2016-09-15 19:08:27 --> Module controller failed to run: admin/index/detailAngsuran/f6e1126cedebf23e1463aee73f9df08783640400/angsuran
ERROR - 2016-09-15 19:08:27 --> Module controller failed to run: admin/index/detailAngsuran/f6e1126cedebf23e1463aee73f9df08783640400/bunga
DEBUG - 2016-09-15 19:08:27 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/Admin/controllers/Index.php
DEBUG - 2016-09-15 19:08:27 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:08:27 --> Module controller failed to run: Admin/Index/detailAngsuran/887309d048beef83ad3eabf2a79a64a389ab1c9f/total_angsuran
ERROR - 2016-09-15 19:08:27 --> Module controller failed to run: admin/index/detailAngsuran/887309d048beef83ad3eabf2a79a64a389ab1c9f/angsuran
ERROR - 2016-09-15 19:08:27 --> Module controller failed to run: admin/index/detailAngsuran/887309d048beef83ad3eabf2a79a64a389ab1c9f/bunga
DEBUG - 2016-09-15 19:08:27 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/Admin/controllers/Index.php
DEBUG - 2016-09-15 19:08:27 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:08:27 --> Module controller failed to run: Admin/Index/detailAngsuran/0a57cb53ba59c46fc4b692527a38a87c78d84028/total_angsuran
ERROR - 2016-09-15 19:08:27 --> Module controller failed to run: admin/index/detailAngsuran/0a57cb53ba59c46fc4b692527a38a87c78d84028/angsuran
ERROR - 2016-09-15 19:08:27 --> Module controller failed to run: admin/index/detailAngsuran/0a57cb53ba59c46fc4b692527a38a87c78d84028/bunga
DEBUG - 2016-09-15 19:08:27 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/Admin/controllers/Index.php
DEBUG - 2016-09-15 19:08:27 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:08:27 --> Module controller failed to run: Admin/Index/detailAngsuran/7719a1c782a1ba91c031a682a0a2f8658209adbf/total_angsuran
ERROR - 2016-09-15 19:08:27 --> Module controller failed to run: admin/index/detailAngsuran/7719a1c782a1ba91c031a682a0a2f8658209adbf/angsuran
ERROR - 2016-09-15 19:08:27 --> Module controller failed to run: admin/index/detailAngsuran/7719a1c782a1ba91c031a682a0a2f8658209adbf/bunga
DEBUG - 2016-09-15 19:08:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_angsuran.php
INFO - 2016-09-15 19:08:28 --> Final output sent to browser
DEBUG - 2016-09-15 19:08:28 --> Total execution time: 1.7707
INFO - 2016-09-15 19:10:00 --> Config Class Initialized
INFO - 2016-09-15 19:10:00 --> Hooks Class Initialized
DEBUG - 2016-09-15 19:10:00 --> UTF-8 Support Enabled
INFO - 2016-09-15 19:10:00 --> Utf8 Class Initialized
INFO - 2016-09-15 19:10:00 --> URI Class Initialized
INFO - 2016-09-15 19:10:00 --> Router Class Initialized
INFO - 2016-09-15 19:10:00 --> Output Class Initialized
INFO - 2016-09-15 19:10:00 --> Security Class Initialized
DEBUG - 2016-09-15 19:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 19:10:00 --> Input Class Initialized
INFO - 2016-09-15 19:10:00 --> Language Class Initialized
INFO - 2016-09-15 19:10:00 --> Language Class Initialized
INFO - 2016-09-15 19:10:00 --> Config Class Initialized
INFO - 2016-09-15 19:10:00 --> Loader Class Initialized
INFO - 2016-09-15 19:10:00 --> Helper loaded: url_helper
INFO - 2016-09-15 19:10:00 --> Database Driver Class Initialized
INFO - 2016-09-15 19:10:00 --> Controller Class Initialized
DEBUG - 2016-09-15 19:10:00 --> Index MX_Controller Initialized
INFO - 2016-09-15 19:10:00 --> Model Class Initialized
INFO - 2016-09-15 19:10:00 --> Model Class Initialized
DEBUG - 2016-09-15 19:10:00 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/Admin/controllers/Index.php
DEBUG - 2016-09-15 19:10:00 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:10:00 --> Module controller failed to run: Admin/Index/detailAngsuran/
DEBUG - 2016-09-15 19:10:00 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:10:01 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:10:01 --> Module controller failed to run: admin/index/detailAngsuran/1574bddb75c78a6fd2251d61e2993b5146201319/angsuran
ERROR - 2016-09-15 19:10:01 --> Module controller failed to run: admin/index/detailAngsuran/1574bddb75c78a6fd2251d61e2993b5146201319/bunga
ERROR - 2016-09-15 19:10:01 --> Module controller failed to run: Admin/Index/detailAngsuran/
DEBUG - 2016-09-15 19:10:01 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:10:01 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:10:01 --> Module controller failed to run: admin/index/detailAngsuran/0716d9708d321ffb6a00818614779e779925365c/angsuran
ERROR - 2016-09-15 19:10:01 --> Module controller failed to run: admin/index/detailAngsuran/0716d9708d321ffb6a00818614779e779925365c/bunga
ERROR - 2016-09-15 19:10:01 --> Module controller failed to run: Admin/Index/detailAngsuran/
DEBUG - 2016-09-15 19:10:01 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:10:01 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:10:01 --> Module controller failed to run: admin/index/detailAngsuran/9e6a55b6b4563e652a23be9d623ca5055c356940/angsuran
ERROR - 2016-09-15 19:10:01 --> Module controller failed to run: admin/index/detailAngsuran/9e6a55b6b4563e652a23be9d623ca5055c356940/bunga
ERROR - 2016-09-15 19:10:01 --> Module controller failed to run: Admin/Index/detailAngsuran/
DEBUG - 2016-09-15 19:10:01 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:10:01 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:10:01 --> Module controller failed to run: admin/index/detailAngsuran/f6e1126cedebf23e1463aee73f9df08783640400/angsuran
ERROR - 2016-09-15 19:10:01 --> Module controller failed to run: admin/index/detailAngsuran/f6e1126cedebf23e1463aee73f9df08783640400/bunga
ERROR - 2016-09-15 19:10:01 --> Module controller failed to run: Admin/Index/detailAngsuran/
DEBUG - 2016-09-15 19:10:01 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:10:01 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:10:01 --> Module controller failed to run: admin/index/detailAngsuran/887309d048beef83ad3eabf2a79a64a389ab1c9f/angsuran
ERROR - 2016-09-15 19:10:01 --> Module controller failed to run: admin/index/detailAngsuran/887309d048beef83ad3eabf2a79a64a389ab1c9f/bunga
ERROR - 2016-09-15 19:10:01 --> Module controller failed to run: Admin/Index/detailAngsuran/
DEBUG - 2016-09-15 19:10:01 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:10:01 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:10:01 --> Module controller failed to run: admin/index/detailAngsuran/0a57cb53ba59c46fc4b692527a38a87c78d84028/angsuran
ERROR - 2016-09-15 19:10:01 --> Module controller failed to run: admin/index/detailAngsuran/0a57cb53ba59c46fc4b692527a38a87c78d84028/bunga
ERROR - 2016-09-15 19:10:01 --> Module controller failed to run: Admin/Index/detailAngsuran/
DEBUG - 2016-09-15 19:10:01 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:10:01 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:10:01 --> Module controller failed to run: admin/index/detailAngsuran/7719a1c782a1ba91c031a682a0a2f8658209adbf/angsuran
ERROR - 2016-09-15 19:10:01 --> Module controller failed to run: admin/index/detailAngsuran/7719a1c782a1ba91c031a682a0a2f8658209adbf/bunga
DEBUG - 2016-09-15 19:10:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_angsuran.php
INFO - 2016-09-15 19:10:02 --> Final output sent to browser
DEBUG - 2016-09-15 19:10:02 --> Total execution time: 1.8737
INFO - 2016-09-15 19:10:48 --> Config Class Initialized
INFO - 2016-09-15 19:10:48 --> Hooks Class Initialized
DEBUG - 2016-09-15 19:10:48 --> UTF-8 Support Enabled
INFO - 2016-09-15 19:10:48 --> Utf8 Class Initialized
INFO - 2016-09-15 19:10:48 --> URI Class Initialized
INFO - 2016-09-15 19:10:48 --> Router Class Initialized
INFO - 2016-09-15 19:10:48 --> Output Class Initialized
INFO - 2016-09-15 19:10:48 --> Security Class Initialized
DEBUG - 2016-09-15 19:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 19:10:48 --> Input Class Initialized
INFO - 2016-09-15 19:10:48 --> Language Class Initialized
INFO - 2016-09-15 19:10:48 --> Language Class Initialized
INFO - 2016-09-15 19:10:48 --> Config Class Initialized
INFO - 2016-09-15 19:10:48 --> Loader Class Initialized
INFO - 2016-09-15 19:10:48 --> Helper loaded: url_helper
INFO - 2016-09-15 19:10:48 --> Database Driver Class Initialized
INFO - 2016-09-15 19:10:48 --> Controller Class Initialized
DEBUG - 2016-09-15 19:10:48 --> Index MX_Controller Initialized
INFO - 2016-09-15 19:10:48 --> Model Class Initialized
INFO - 2016-09-15 19:10:48 --> Model Class Initialized
DEBUG - 2016-09-15 19:10:48 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:10:49 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:10:49 --> Module controller failed to run: admin/index/detailAngsuran/
DEBUG - 2016-09-15 19:10:49 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:10:49 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:10:49 --> Module controller failed to run: admin/index/detailAngsuran/1574bddb75c78a6fd2251d61e2993b5146201319/angsuran
ERROR - 2016-09-15 19:10:49 --> Module controller failed to run: admin/index/detailAngsuran/1574bddb75c78a6fd2251d61e2993b5146201319/bunga
ERROR - 2016-09-15 19:10:49 --> Module controller failed to run: admin/index/detailAngsuran/
DEBUG - 2016-09-15 19:10:49 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:10:49 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:10:49 --> Module controller failed to run: admin/index/detailAngsuran/0716d9708d321ffb6a00818614779e779925365c/angsuran
ERROR - 2016-09-15 19:10:49 --> Module controller failed to run: admin/index/detailAngsuran/0716d9708d321ffb6a00818614779e779925365c/bunga
ERROR - 2016-09-15 19:10:49 --> Module controller failed to run: admin/index/detailAngsuran/
DEBUG - 2016-09-15 19:10:49 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:10:49 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:10:49 --> Module controller failed to run: admin/index/detailAngsuran/9e6a55b6b4563e652a23be9d623ca5055c356940/angsuran
ERROR - 2016-09-15 19:10:49 --> Module controller failed to run: admin/index/detailAngsuran/9e6a55b6b4563e652a23be9d623ca5055c356940/bunga
ERROR - 2016-09-15 19:10:49 --> Module controller failed to run: admin/index/detailAngsuran/
DEBUG - 2016-09-15 19:10:49 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:10:49 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:10:49 --> Module controller failed to run: admin/index/detailAngsuran/f6e1126cedebf23e1463aee73f9df08783640400/angsuran
ERROR - 2016-09-15 19:10:49 --> Module controller failed to run: admin/index/detailAngsuran/f6e1126cedebf23e1463aee73f9df08783640400/bunga
ERROR - 2016-09-15 19:10:49 --> Module controller failed to run: admin/index/detailAngsuran/
DEBUG - 2016-09-15 19:10:49 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:10:49 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:10:49 --> Module controller failed to run: admin/index/detailAngsuran/887309d048beef83ad3eabf2a79a64a389ab1c9f/angsuran
ERROR - 2016-09-15 19:10:49 --> Module controller failed to run: admin/index/detailAngsuran/887309d048beef83ad3eabf2a79a64a389ab1c9f/bunga
ERROR - 2016-09-15 19:10:49 --> Module controller failed to run: admin/index/detailAngsuran/
DEBUG - 2016-09-15 19:10:49 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:10:49 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:10:49 --> Module controller failed to run: admin/index/detailAngsuran/0a57cb53ba59c46fc4b692527a38a87c78d84028/angsuran
ERROR - 2016-09-15 19:10:50 --> Module controller failed to run: admin/index/detailAngsuran/0a57cb53ba59c46fc4b692527a38a87c78d84028/bunga
ERROR - 2016-09-15 19:10:50 --> Module controller failed to run: admin/index/detailAngsuran/
DEBUG - 2016-09-15 19:10:50 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:10:50 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:10:50 --> Module controller failed to run: admin/index/detailAngsuran/7719a1c782a1ba91c031a682a0a2f8658209adbf/angsuran
ERROR - 2016-09-15 19:10:50 --> Module controller failed to run: admin/index/detailAngsuran/7719a1c782a1ba91c031a682a0a2f8658209adbf/bunga
DEBUG - 2016-09-15 19:10:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_angsuran.php
INFO - 2016-09-15 19:10:50 --> Final output sent to browser
DEBUG - 2016-09-15 19:10:50 --> Total execution time: 2.0258
INFO - 2016-09-15 19:11:11 --> Config Class Initialized
INFO - 2016-09-15 19:11:11 --> Hooks Class Initialized
DEBUG - 2016-09-15 19:11:11 --> UTF-8 Support Enabled
INFO - 2016-09-15 19:11:11 --> Utf8 Class Initialized
INFO - 2016-09-15 19:11:11 --> URI Class Initialized
INFO - 2016-09-15 19:11:11 --> Router Class Initialized
INFO - 2016-09-15 19:11:11 --> Output Class Initialized
INFO - 2016-09-15 19:11:11 --> Security Class Initialized
DEBUG - 2016-09-15 19:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 19:11:11 --> Input Class Initialized
INFO - 2016-09-15 19:11:11 --> Language Class Initialized
INFO - 2016-09-15 19:11:11 --> Language Class Initialized
INFO - 2016-09-15 19:11:11 --> Config Class Initialized
INFO - 2016-09-15 19:11:11 --> Loader Class Initialized
INFO - 2016-09-15 19:11:11 --> Helper loaded: url_helper
INFO - 2016-09-15 19:11:11 --> Database Driver Class Initialized
INFO - 2016-09-15 19:11:11 --> Controller Class Initialized
DEBUG - 2016-09-15 19:11:11 --> Index MX_Controller Initialized
INFO - 2016-09-15 19:11:12 --> Model Class Initialized
INFO - 2016-09-15 19:11:12 --> Model Class Initialized
DEBUG - 2016-09-15 19:11:12 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:11:12 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:11:12 --> Module controller failed to run: admin/index/detailAngsuran/
DEBUG - 2016-09-15 19:11:12 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:11:12 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:11:12 --> Module controller failed to run: admin/index/detailAngsuran/1574bddb75c78a6fd2251d61e2993b5146201319/angsuran
ERROR - 2016-09-15 19:11:12 --> Module controller failed to run: admin/index/detailAngsuran/1574bddb75c78a6fd2251d61e2993b5146201319/bunga
ERROR - 2016-09-15 19:11:12 --> Module controller failed to run: admin/index/detailAngsuran/
DEBUG - 2016-09-15 19:11:12 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:11:12 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:11:12 --> Module controller failed to run: admin/index/detailAngsuran/0716d9708d321ffb6a00818614779e779925365c/angsuran
ERROR - 2016-09-15 19:11:12 --> Module controller failed to run: admin/index/detailAngsuran/0716d9708d321ffb6a00818614779e779925365c/bunga
ERROR - 2016-09-15 19:11:12 --> Module controller failed to run: admin/index/detailAngsuran/
DEBUG - 2016-09-15 19:11:12 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:11:12 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:11:12 --> Module controller failed to run: admin/index/detailAngsuran/9e6a55b6b4563e652a23be9d623ca5055c356940/angsuran
ERROR - 2016-09-15 19:11:12 --> Module controller failed to run: admin/index/detailAngsuran/9e6a55b6b4563e652a23be9d623ca5055c356940/bunga
ERROR - 2016-09-15 19:11:12 --> Module controller failed to run: admin/index/detailAngsuran/
DEBUG - 2016-09-15 19:11:12 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:11:12 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:11:12 --> Module controller failed to run: admin/index/detailAngsuran/f6e1126cedebf23e1463aee73f9df08783640400/angsuran
ERROR - 2016-09-15 19:11:12 --> Module controller failed to run: admin/index/detailAngsuran/f6e1126cedebf23e1463aee73f9df08783640400/bunga
ERROR - 2016-09-15 19:11:12 --> Module controller failed to run: admin/index/detailAngsuran/
DEBUG - 2016-09-15 19:11:12 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:11:12 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:11:12 --> Module controller failed to run: admin/index/detailAngsuran/887309d048beef83ad3eabf2a79a64a389ab1c9f/angsuran
ERROR - 2016-09-15 19:11:12 --> Module controller failed to run: admin/index/detailAngsuran/887309d048beef83ad3eabf2a79a64a389ab1c9f/bunga
ERROR - 2016-09-15 19:11:12 --> Module controller failed to run: admin/index/detailAngsuran/
DEBUG - 2016-09-15 19:11:12 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:11:12 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:11:13 --> Module controller failed to run: admin/index/detailAngsuran/0a57cb53ba59c46fc4b692527a38a87c78d84028/angsuran
ERROR - 2016-09-15 19:11:13 --> Module controller failed to run: admin/index/detailAngsuran/0a57cb53ba59c46fc4b692527a38a87c78d84028/bunga
ERROR - 2016-09-15 19:11:13 --> Module controller failed to run: admin/index/detailAngsuran/
DEBUG - 2016-09-15 19:11:13 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:11:13 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:11:13 --> Module controller failed to run: admin/index/detailAngsuran/7719a1c782a1ba91c031a682a0a2f8658209adbf/angsuran
ERROR - 2016-09-15 19:11:13 --> Module controller failed to run: admin/index/detailAngsuran/7719a1c782a1ba91c031a682a0a2f8658209adbf/bunga
DEBUG - 2016-09-15 19:11:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_angsuran.php
INFO - 2016-09-15 19:11:13 --> Final output sent to browser
DEBUG - 2016-09-15 19:11:13 --> Total execution time: 2.0521
INFO - 2016-09-15 19:11:44 --> Config Class Initialized
INFO - 2016-09-15 19:11:44 --> Hooks Class Initialized
DEBUG - 2016-09-15 19:11:44 --> UTF-8 Support Enabled
INFO - 2016-09-15 19:11:45 --> Utf8 Class Initialized
INFO - 2016-09-15 19:11:45 --> URI Class Initialized
INFO - 2016-09-15 19:11:45 --> Router Class Initialized
INFO - 2016-09-15 19:11:45 --> Output Class Initialized
INFO - 2016-09-15 19:11:45 --> Security Class Initialized
DEBUG - 2016-09-15 19:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 19:11:45 --> Input Class Initialized
INFO - 2016-09-15 19:11:45 --> Language Class Initialized
INFO - 2016-09-15 19:11:45 --> Language Class Initialized
INFO - 2016-09-15 19:11:45 --> Config Class Initialized
INFO - 2016-09-15 19:11:45 --> Loader Class Initialized
INFO - 2016-09-15 19:11:45 --> Helper loaded: url_helper
INFO - 2016-09-15 19:11:45 --> Database Driver Class Initialized
INFO - 2016-09-15 19:11:45 --> Controller Class Initialized
DEBUG - 2016-09-15 19:11:45 --> Index MX_Controller Initialized
INFO - 2016-09-15 19:11:45 --> Model Class Initialized
INFO - 2016-09-15 19:11:45 --> Model Class Initialized
DEBUG - 2016-09-15 19:11:45 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:11:45 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:11:45 --> Module controller failed to run: admin/index/detailAngsuran/
DEBUG - 2016-09-15 19:11:45 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:11:45 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:11:45 --> Module controller failed to run: admin/index/detailAngsuran/1574bddb75c78a6fd2251d61e2993b5146201319/angsuran
ERROR - 2016-09-15 19:11:45 --> Module controller failed to run: admin/index/detailAngsuran/1574bddb75c78a6fd2251d61e2993b5146201319/bunga
ERROR - 2016-09-15 19:11:45 --> Module controller failed to run: admin/index/detailAngsuran/
DEBUG - 2016-09-15 19:11:45 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:11:45 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:11:45 --> Module controller failed to run: admin/index/detailAngsuran/0716d9708d321ffb6a00818614779e779925365c/angsuran
ERROR - 2016-09-15 19:11:45 --> Module controller failed to run: admin/index/detailAngsuran/0716d9708d321ffb6a00818614779e779925365c/bunga
ERROR - 2016-09-15 19:11:45 --> Module controller failed to run: admin/index/detailAngsuran/
DEBUG - 2016-09-15 19:11:46 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:11:46 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:11:46 --> Module controller failed to run: admin/index/detailAngsuran/9e6a55b6b4563e652a23be9d623ca5055c356940/angsuran
ERROR - 2016-09-15 19:11:46 --> Module controller failed to run: admin/index/detailAngsuran/9e6a55b6b4563e652a23be9d623ca5055c356940/bunga
ERROR - 2016-09-15 19:11:46 --> Module controller failed to run: admin/index/detailAngsuran/
DEBUG - 2016-09-15 19:11:46 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:11:46 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:11:46 --> Module controller failed to run: admin/index/detailAngsuran/f6e1126cedebf23e1463aee73f9df08783640400/angsuran
ERROR - 2016-09-15 19:11:46 --> Module controller failed to run: admin/index/detailAngsuran/f6e1126cedebf23e1463aee73f9df08783640400/bunga
ERROR - 2016-09-15 19:11:46 --> Module controller failed to run: admin/index/detailAngsuran/
DEBUG - 2016-09-15 19:11:46 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:11:46 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:11:46 --> Module controller failed to run: admin/index/detailAngsuran/887309d048beef83ad3eabf2a79a64a389ab1c9f/angsuran
ERROR - 2016-09-15 19:11:46 --> Module controller failed to run: admin/index/detailAngsuran/887309d048beef83ad3eabf2a79a64a389ab1c9f/bunga
ERROR - 2016-09-15 19:11:46 --> Module controller failed to run: admin/index/detailAngsuran/
DEBUG - 2016-09-15 19:11:46 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:11:46 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:11:46 --> Module controller failed to run: admin/index/detailAngsuran/0a57cb53ba59c46fc4b692527a38a87c78d84028/angsuran
ERROR - 2016-09-15 19:11:46 --> Module controller failed to run: admin/index/detailAngsuran/0a57cb53ba59c46fc4b692527a38a87c78d84028/bunga
ERROR - 2016-09-15 19:11:46 --> Module controller failed to run: admin/index/detailAngsuran/
DEBUG - 2016-09-15 19:11:46 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:11:46 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:11:46 --> Module controller failed to run: admin/index/detailAngsuran/7719a1c782a1ba91c031a682a0a2f8658209adbf/angsuran
ERROR - 2016-09-15 19:11:46 --> Module controller failed to run: admin/index/detailAngsuran/7719a1c782a1ba91c031a682a0a2f8658209adbf/bunga
DEBUG - 2016-09-15 19:11:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_angsuran.php
INFO - 2016-09-15 19:11:46 --> Final output sent to browser
DEBUG - 2016-09-15 19:11:46 --> Total execution time: 2.0214
INFO - 2016-09-15 19:12:14 --> Config Class Initialized
INFO - 2016-09-15 19:12:14 --> Hooks Class Initialized
DEBUG - 2016-09-15 19:12:14 --> UTF-8 Support Enabled
INFO - 2016-09-15 19:12:14 --> Utf8 Class Initialized
INFO - 2016-09-15 19:12:14 --> URI Class Initialized
INFO - 2016-09-15 19:12:14 --> Router Class Initialized
INFO - 2016-09-15 19:12:15 --> Output Class Initialized
INFO - 2016-09-15 19:12:15 --> Security Class Initialized
DEBUG - 2016-09-15 19:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 19:12:15 --> Input Class Initialized
INFO - 2016-09-15 19:12:15 --> Language Class Initialized
INFO - 2016-09-15 19:12:15 --> Language Class Initialized
INFO - 2016-09-15 19:12:15 --> Config Class Initialized
INFO - 2016-09-15 19:12:15 --> Loader Class Initialized
INFO - 2016-09-15 19:12:15 --> Helper loaded: url_helper
INFO - 2016-09-15 19:12:15 --> Database Driver Class Initialized
INFO - 2016-09-15 19:12:15 --> Controller Class Initialized
DEBUG - 2016-09-15 19:12:15 --> Index MX_Controller Initialized
INFO - 2016-09-15 19:12:15 --> Model Class Initialized
INFO - 2016-09-15 19:12:15 --> Model Class Initialized
DEBUG - 2016-09-15 19:12:15 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:12:15 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:12:15 --> Module controller failed to run: admin/index/detailAngsuran/1574bddb75c78a6fd2251d61e2993b5146201319/total_angsuran
ERROR - 2016-09-15 19:12:15 --> Module controller failed to run: admin/index/detailAngsuran/1574bddb75c78a6fd2251d61e2993b5146201319/angsuran
ERROR - 2016-09-15 19:12:15 --> Module controller failed to run: admin/index/detailAngsuran/1574bddb75c78a6fd2251d61e2993b5146201319/bunga
DEBUG - 2016-09-15 19:12:15 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:12:15 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:12:15 --> Module controller failed to run: admin/index/detailAngsuran/0716d9708d321ffb6a00818614779e779925365c/total_angsuran
ERROR - 2016-09-15 19:12:15 --> Module controller failed to run: admin/index/detailAngsuran/0716d9708d321ffb6a00818614779e779925365c/angsuran
ERROR - 2016-09-15 19:12:15 --> Module controller failed to run: admin/index/detailAngsuran/0716d9708d321ffb6a00818614779e779925365c/bunga
DEBUG - 2016-09-15 19:12:15 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:12:15 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:12:15 --> Module controller failed to run: admin/index/detailAngsuran/9e6a55b6b4563e652a23be9d623ca5055c356940/total_angsuran
ERROR - 2016-09-15 19:12:15 --> Module controller failed to run: admin/index/detailAngsuran/9e6a55b6b4563e652a23be9d623ca5055c356940/angsuran
ERROR - 2016-09-15 19:12:15 --> Module controller failed to run: admin/index/detailAngsuran/9e6a55b6b4563e652a23be9d623ca5055c356940/bunga
DEBUG - 2016-09-15 19:12:15 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:12:15 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:12:16 --> Module controller failed to run: admin/index/detailAngsuran/f6e1126cedebf23e1463aee73f9df08783640400/total_angsuran
ERROR - 2016-09-15 19:12:16 --> Module controller failed to run: admin/index/detailAngsuran/f6e1126cedebf23e1463aee73f9df08783640400/angsuran
ERROR - 2016-09-15 19:12:16 --> Module controller failed to run: admin/index/detailAngsuran/f6e1126cedebf23e1463aee73f9df08783640400/bunga
DEBUG - 2016-09-15 19:12:16 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:12:16 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:12:16 --> Module controller failed to run: admin/index/detailAngsuran/887309d048beef83ad3eabf2a79a64a389ab1c9f/total_angsuran
ERROR - 2016-09-15 19:12:16 --> Module controller failed to run: admin/index/detailAngsuran/887309d048beef83ad3eabf2a79a64a389ab1c9f/angsuran
ERROR - 2016-09-15 19:12:16 --> Module controller failed to run: admin/index/detailAngsuran/887309d048beef83ad3eabf2a79a64a389ab1c9f/bunga
DEBUG - 2016-09-15 19:12:16 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:12:16 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:12:16 --> Module controller failed to run: admin/index/detailAngsuran/0a57cb53ba59c46fc4b692527a38a87c78d84028/total_angsuran
ERROR - 2016-09-15 19:12:16 --> Module controller failed to run: admin/index/detailAngsuran/0a57cb53ba59c46fc4b692527a38a87c78d84028/angsuran
ERROR - 2016-09-15 19:12:16 --> Module controller failed to run: admin/index/detailAngsuran/0a57cb53ba59c46fc4b692527a38a87c78d84028/bunga
DEBUG - 2016-09-15 19:12:16 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:12:16 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:12:16 --> Module controller failed to run: admin/index/detailAngsuran/7719a1c782a1ba91c031a682a0a2f8658209adbf/total_angsuran
ERROR - 2016-09-15 19:12:16 --> Module controller failed to run: admin/index/detailAngsuran/7719a1c782a1ba91c031a682a0a2f8658209adbf/angsuran
ERROR - 2016-09-15 19:12:16 --> Module controller failed to run: admin/index/detailAngsuran/7719a1c782a1ba91c031a682a0a2f8658209adbf/bunga
DEBUG - 2016-09-15 19:12:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_angsuran.php
INFO - 2016-09-15 19:12:16 --> Final output sent to browser
DEBUG - 2016-09-15 19:12:16 --> Total execution time: 1.9109
INFO - 2016-09-15 19:12:23 --> Config Class Initialized
INFO - 2016-09-15 19:12:23 --> Hooks Class Initialized
DEBUG - 2016-09-15 19:12:23 --> UTF-8 Support Enabled
INFO - 2016-09-15 19:12:23 --> Utf8 Class Initialized
INFO - 2016-09-15 19:12:23 --> URI Class Initialized
INFO - 2016-09-15 19:12:23 --> Router Class Initialized
INFO - 2016-09-15 19:12:23 --> Output Class Initialized
INFO - 2016-09-15 19:12:23 --> Security Class Initialized
DEBUG - 2016-09-15 19:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 19:12:23 --> Input Class Initialized
INFO - 2016-09-15 19:12:23 --> Language Class Initialized
INFO - 2016-09-15 19:12:23 --> Language Class Initialized
INFO - 2016-09-15 19:12:23 --> Config Class Initialized
INFO - 2016-09-15 19:12:23 --> Loader Class Initialized
INFO - 2016-09-15 19:12:23 --> Helper loaded: url_helper
INFO - 2016-09-15 19:12:23 --> Database Driver Class Initialized
INFO - 2016-09-15 19:12:23 --> Controller Class Initialized
DEBUG - 2016-09-15 19:12:23 --> Index MX_Controller Initialized
INFO - 2016-09-15 19:12:23 --> Model Class Initialized
INFO - 2016-09-15 19:12:23 --> Model Class Initialized
DEBUG - 2016-09-15 19:12:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 19:12:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 19:12:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 19:12:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/angsuran.php
DEBUG - 2016-09-15 19:12:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 19:12:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 19:12:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 19:12:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 19:12:24 --> Final output sent to browser
DEBUG - 2016-09-15 19:12:24 --> Total execution time: 1.0984
INFO - 2016-09-15 19:12:35 --> Config Class Initialized
INFO - 2016-09-15 19:12:35 --> Hooks Class Initialized
DEBUG - 2016-09-15 19:12:35 --> UTF-8 Support Enabled
INFO - 2016-09-15 19:12:35 --> Utf8 Class Initialized
INFO - 2016-09-15 19:12:35 --> URI Class Initialized
INFO - 2016-09-15 19:12:35 --> Router Class Initialized
INFO - 2016-09-15 19:12:35 --> Output Class Initialized
INFO - 2016-09-15 19:12:35 --> Security Class Initialized
DEBUG - 2016-09-15 19:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 19:12:35 --> Input Class Initialized
INFO - 2016-09-15 19:12:35 --> Language Class Initialized
INFO - 2016-09-15 19:12:35 --> Language Class Initialized
INFO - 2016-09-15 19:12:35 --> Config Class Initialized
INFO - 2016-09-15 19:12:35 --> Loader Class Initialized
INFO - 2016-09-15 19:12:35 --> Helper loaded: url_helper
INFO - 2016-09-15 19:12:35 --> Database Driver Class Initialized
INFO - 2016-09-15 19:12:35 --> Controller Class Initialized
DEBUG - 2016-09-15 19:12:35 --> Index MX_Controller Initialized
INFO - 2016-09-15 19:12:36 --> Model Class Initialized
INFO - 2016-09-15 19:12:36 --> Model Class Initialized
DEBUG - 2016-09-15 19:12:36 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:12:36 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:12:36 --> Module controller failed to run: admin/index/detailAngsuran/1574bddb75c78a6fd2251d61e2993b5146201319/total_angsuran
ERROR - 2016-09-15 19:12:36 --> Module controller failed to run: admin/index/detailAngsuran/1574bddb75c78a6fd2251d61e2993b5146201319/angsuran
ERROR - 2016-09-15 19:12:36 --> Module controller failed to run: admin/index/detailAngsuran/1574bddb75c78a6fd2251d61e2993b5146201319/bunga
DEBUG - 2016-09-15 19:12:36 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:12:36 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:12:36 --> Module controller failed to run: admin/index/detailAngsuran/0716d9708d321ffb6a00818614779e779925365c/total_angsuran
ERROR - 2016-09-15 19:12:36 --> Module controller failed to run: admin/index/detailAngsuran/0716d9708d321ffb6a00818614779e779925365c/angsuran
ERROR - 2016-09-15 19:12:36 --> Module controller failed to run: admin/index/detailAngsuran/0716d9708d321ffb6a00818614779e779925365c/bunga
DEBUG - 2016-09-15 19:12:36 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:12:36 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:12:36 --> Module controller failed to run: admin/index/detailAngsuran/9e6a55b6b4563e652a23be9d623ca5055c356940/total_angsuran
ERROR - 2016-09-15 19:12:36 --> Module controller failed to run: admin/index/detailAngsuran/9e6a55b6b4563e652a23be9d623ca5055c356940/angsuran
ERROR - 2016-09-15 19:12:36 --> Module controller failed to run: admin/index/detailAngsuran/9e6a55b6b4563e652a23be9d623ca5055c356940/bunga
DEBUG - 2016-09-15 19:12:36 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:12:36 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:12:36 --> Module controller failed to run: admin/index/detailAngsuran/f6e1126cedebf23e1463aee73f9df08783640400/total_angsuran
ERROR - 2016-09-15 19:12:36 --> Module controller failed to run: admin/index/detailAngsuran/f6e1126cedebf23e1463aee73f9df08783640400/angsuran
ERROR - 2016-09-15 19:12:36 --> Module controller failed to run: admin/index/detailAngsuran/f6e1126cedebf23e1463aee73f9df08783640400/bunga
DEBUG - 2016-09-15 19:12:36 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:12:36 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:12:36 --> Module controller failed to run: admin/index/detailAngsuran/887309d048beef83ad3eabf2a79a64a389ab1c9f/total_angsuran
ERROR - 2016-09-15 19:12:36 --> Module controller failed to run: admin/index/detailAngsuran/887309d048beef83ad3eabf2a79a64a389ab1c9f/angsuran
ERROR - 2016-09-15 19:12:36 --> Module controller failed to run: admin/index/detailAngsuran/887309d048beef83ad3eabf2a79a64a389ab1c9f/bunga
DEBUG - 2016-09-15 19:12:36 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:12:37 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:12:37 --> Module controller failed to run: admin/index/detailAngsuran/0a57cb53ba59c46fc4b692527a38a87c78d84028/total_angsuran
ERROR - 2016-09-15 19:12:37 --> Module controller failed to run: admin/index/detailAngsuran/0a57cb53ba59c46fc4b692527a38a87c78d84028/angsuran
ERROR - 2016-09-15 19:12:37 --> Module controller failed to run: admin/index/detailAngsuran/0a57cb53ba59c46fc4b692527a38a87c78d84028/bunga
DEBUG - 2016-09-15 19:12:37 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:12:37 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:12:37 --> Module controller failed to run: admin/index/detailAngsuran/7719a1c782a1ba91c031a682a0a2f8658209adbf/total_angsuran
ERROR - 2016-09-15 19:12:37 --> Module controller failed to run: admin/index/detailAngsuran/7719a1c782a1ba91c031a682a0a2f8658209adbf/angsuran
ERROR - 2016-09-15 19:12:37 --> Module controller failed to run: admin/index/detailAngsuran/7719a1c782a1ba91c031a682a0a2f8658209adbf/bunga
DEBUG - 2016-09-15 19:12:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_angsuran.php
INFO - 2016-09-15 19:12:37 --> Final output sent to browser
DEBUG - 2016-09-15 19:12:37 --> Total execution time: 2.0908
INFO - 2016-09-15 19:13:24 --> Config Class Initialized
INFO - 2016-09-15 19:13:24 --> Hooks Class Initialized
DEBUG - 2016-09-15 19:13:24 --> UTF-8 Support Enabled
INFO - 2016-09-15 19:13:24 --> Utf8 Class Initialized
INFO - 2016-09-15 19:13:24 --> URI Class Initialized
INFO - 2016-09-15 19:13:24 --> Router Class Initialized
INFO - 2016-09-15 19:13:24 --> Output Class Initialized
INFO - 2016-09-15 19:13:24 --> Security Class Initialized
DEBUG - 2016-09-15 19:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 19:13:25 --> Input Class Initialized
INFO - 2016-09-15 19:13:25 --> Language Class Initialized
INFO - 2016-09-15 19:13:25 --> Language Class Initialized
INFO - 2016-09-15 19:13:25 --> Config Class Initialized
INFO - 2016-09-15 19:13:25 --> Loader Class Initialized
INFO - 2016-09-15 19:13:25 --> Helper loaded: url_helper
INFO - 2016-09-15 19:13:25 --> Database Driver Class Initialized
INFO - 2016-09-15 19:13:25 --> Controller Class Initialized
DEBUG - 2016-09-15 19:13:25 --> Index MX_Controller Initialized
INFO - 2016-09-15 19:13:25 --> Model Class Initialized
INFO - 2016-09-15 19:13:25 --> Model Class Initialized
DEBUG - 2016-09-15 19:13:25 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:13:25 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:13:25 --> Module controller failed to run: admin/Index/detailAngsuran/1574bddb75c78a6fd2251d61e2993b5146201319/total_angsuran
ERROR - 2016-09-15 19:13:25 --> Module controller failed to run: admin/index/detailAngsuran/1574bddb75c78a6fd2251d61e2993b5146201319/angsuran
ERROR - 2016-09-15 19:13:25 --> Module controller failed to run: admin/index/detailAngsuran/1574bddb75c78a6fd2251d61e2993b5146201319/bunga
DEBUG - 2016-09-15 19:13:25 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:13:25 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:13:25 --> Module controller failed to run: admin/Index/detailAngsuran/0716d9708d321ffb6a00818614779e779925365c/total_angsuran
ERROR - 2016-09-15 19:13:25 --> Module controller failed to run: admin/index/detailAngsuran/0716d9708d321ffb6a00818614779e779925365c/angsuran
ERROR - 2016-09-15 19:13:25 --> Module controller failed to run: admin/index/detailAngsuran/0716d9708d321ffb6a00818614779e779925365c/bunga
DEBUG - 2016-09-15 19:13:25 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:13:25 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:13:25 --> Module controller failed to run: admin/Index/detailAngsuran/9e6a55b6b4563e652a23be9d623ca5055c356940/total_angsuran
ERROR - 2016-09-15 19:13:25 --> Module controller failed to run: admin/index/detailAngsuran/9e6a55b6b4563e652a23be9d623ca5055c356940/angsuran
ERROR - 2016-09-15 19:13:25 --> Module controller failed to run: admin/index/detailAngsuran/9e6a55b6b4563e652a23be9d623ca5055c356940/bunga
DEBUG - 2016-09-15 19:13:25 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:13:25 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:13:25 --> Module controller failed to run: admin/Index/detailAngsuran/f6e1126cedebf23e1463aee73f9df08783640400/total_angsuran
ERROR - 2016-09-15 19:13:25 --> Module controller failed to run: admin/index/detailAngsuran/f6e1126cedebf23e1463aee73f9df08783640400/angsuran
ERROR - 2016-09-15 19:13:26 --> Module controller failed to run: admin/index/detailAngsuran/f6e1126cedebf23e1463aee73f9df08783640400/bunga
DEBUG - 2016-09-15 19:13:26 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:13:26 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:13:26 --> Module controller failed to run: admin/Index/detailAngsuran/887309d048beef83ad3eabf2a79a64a389ab1c9f/total_angsuran
ERROR - 2016-09-15 19:13:26 --> Module controller failed to run: admin/index/detailAngsuran/887309d048beef83ad3eabf2a79a64a389ab1c9f/angsuran
ERROR - 2016-09-15 19:13:26 --> Module controller failed to run: admin/index/detailAngsuran/887309d048beef83ad3eabf2a79a64a389ab1c9f/bunga
DEBUG - 2016-09-15 19:13:26 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:13:26 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:13:26 --> Module controller failed to run: admin/Index/detailAngsuran/0a57cb53ba59c46fc4b692527a38a87c78d84028/total_angsuran
ERROR - 2016-09-15 19:13:26 --> Module controller failed to run: admin/index/detailAngsuran/0a57cb53ba59c46fc4b692527a38a87c78d84028/angsuran
ERROR - 2016-09-15 19:13:26 --> Module controller failed to run: admin/index/detailAngsuran/0a57cb53ba59c46fc4b692527a38a87c78d84028/bunga
DEBUG - 2016-09-15 19:13:26 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:13:26 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:13:26 --> Module controller failed to run: admin/Index/detailAngsuran/7719a1c782a1ba91c031a682a0a2f8658209adbf/total_angsuran
ERROR - 2016-09-15 19:13:26 --> Module controller failed to run: admin/index/detailAngsuran/7719a1c782a1ba91c031a682a0a2f8658209adbf/angsuran
ERROR - 2016-09-15 19:13:26 --> Module controller failed to run: admin/index/detailAngsuran/7719a1c782a1ba91c031a682a0a2f8658209adbf/bunga
DEBUG - 2016-09-15 19:13:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_angsuran.php
INFO - 2016-09-15 19:13:26 --> Final output sent to browser
DEBUG - 2016-09-15 19:13:26 --> Total execution time: 1.8271
INFO - 2016-09-15 19:13:45 --> Config Class Initialized
INFO - 2016-09-15 19:13:45 --> Hooks Class Initialized
DEBUG - 2016-09-15 19:13:46 --> UTF-8 Support Enabled
INFO - 2016-09-15 19:13:46 --> Utf8 Class Initialized
INFO - 2016-09-15 19:13:46 --> URI Class Initialized
INFO - 2016-09-15 19:13:46 --> Router Class Initialized
INFO - 2016-09-15 19:13:46 --> Output Class Initialized
INFO - 2016-09-15 19:13:46 --> Security Class Initialized
DEBUG - 2016-09-15 19:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 19:13:46 --> Input Class Initialized
INFO - 2016-09-15 19:13:46 --> Language Class Initialized
INFO - 2016-09-15 19:13:46 --> Language Class Initialized
INFO - 2016-09-15 19:13:46 --> Config Class Initialized
INFO - 2016-09-15 19:13:46 --> Loader Class Initialized
INFO - 2016-09-15 19:13:46 --> Helper loaded: url_helper
INFO - 2016-09-15 19:13:46 --> Database Driver Class Initialized
INFO - 2016-09-15 19:13:46 --> Controller Class Initialized
DEBUG - 2016-09-15 19:13:46 --> Index MX_Controller Initialized
INFO - 2016-09-15 19:13:46 --> Model Class Initialized
INFO - 2016-09-15 19:13:46 --> Model Class Initialized
DEBUG - 2016-09-15 19:13:46 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:13:46 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:13:46 --> Module controller failed to run: admin/Index/detailAngsuran/
DEBUG - 2016-09-15 19:13:46 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:13:46 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:13:46 --> Module controller failed to run: admin/index/detailAngsuran/1574bddb75c78a6fd2251d61e2993b5146201319/angsuran
ERROR - 2016-09-15 19:13:46 --> Module controller failed to run: admin/index/detailAngsuran/1574bddb75c78a6fd2251d61e2993b5146201319/bunga
ERROR - 2016-09-15 19:13:46 --> Module controller failed to run: admin/Index/detailAngsuran/
DEBUG - 2016-09-15 19:13:46 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:13:46 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:13:47 --> Module controller failed to run: admin/index/detailAngsuran/0716d9708d321ffb6a00818614779e779925365c/angsuran
ERROR - 2016-09-15 19:13:47 --> Module controller failed to run: admin/index/detailAngsuran/0716d9708d321ffb6a00818614779e779925365c/bunga
ERROR - 2016-09-15 19:13:47 --> Module controller failed to run: admin/Index/detailAngsuran/
DEBUG - 2016-09-15 19:13:47 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:13:47 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:13:47 --> Module controller failed to run: admin/index/detailAngsuran/9e6a55b6b4563e652a23be9d623ca5055c356940/angsuran
ERROR - 2016-09-15 19:13:47 --> Module controller failed to run: admin/index/detailAngsuran/9e6a55b6b4563e652a23be9d623ca5055c356940/bunga
ERROR - 2016-09-15 19:13:47 --> Module controller failed to run: admin/Index/detailAngsuran/
DEBUG - 2016-09-15 19:13:47 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:13:47 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:13:47 --> Module controller failed to run: admin/index/detailAngsuran/f6e1126cedebf23e1463aee73f9df08783640400/angsuran
ERROR - 2016-09-15 19:13:47 --> Module controller failed to run: admin/index/detailAngsuran/f6e1126cedebf23e1463aee73f9df08783640400/bunga
ERROR - 2016-09-15 19:13:47 --> Module controller failed to run: admin/Index/detailAngsuran/
DEBUG - 2016-09-15 19:13:47 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:13:47 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:13:47 --> Module controller failed to run: admin/index/detailAngsuran/887309d048beef83ad3eabf2a79a64a389ab1c9f/angsuran
ERROR - 2016-09-15 19:13:47 --> Module controller failed to run: admin/index/detailAngsuran/887309d048beef83ad3eabf2a79a64a389ab1c9f/bunga
ERROR - 2016-09-15 19:13:47 --> Module controller failed to run: admin/Index/detailAngsuran/
DEBUG - 2016-09-15 19:13:47 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:13:47 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:13:47 --> Module controller failed to run: admin/index/detailAngsuran/0a57cb53ba59c46fc4b692527a38a87c78d84028/angsuran
ERROR - 2016-09-15 19:13:47 --> Module controller failed to run: admin/index/detailAngsuran/0a57cb53ba59c46fc4b692527a38a87c78d84028/bunga
ERROR - 2016-09-15 19:13:47 --> Module controller failed to run: admin/Index/detailAngsuran/
DEBUG - 2016-09-15 19:13:47 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:13:47 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:13:47 --> Module controller failed to run: admin/index/detailAngsuran/7719a1c782a1ba91c031a682a0a2f8658209adbf/angsuran
ERROR - 2016-09-15 19:13:47 --> Module controller failed to run: admin/index/detailAngsuran/7719a1c782a1ba91c031a682a0a2f8658209adbf/bunga
DEBUG - 2016-09-15 19:13:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_angsuran.php
INFO - 2016-09-15 19:13:47 --> Final output sent to browser
DEBUG - 2016-09-15 19:13:47 --> Total execution time: 1.9800
INFO - 2016-09-15 19:14:41 --> Config Class Initialized
INFO - 2016-09-15 19:14:41 --> Hooks Class Initialized
DEBUG - 2016-09-15 19:14:41 --> UTF-8 Support Enabled
INFO - 2016-09-15 19:14:41 --> Utf8 Class Initialized
INFO - 2016-09-15 19:14:41 --> URI Class Initialized
INFO - 2016-09-15 19:14:41 --> Router Class Initialized
INFO - 2016-09-15 19:14:41 --> Output Class Initialized
INFO - 2016-09-15 19:14:41 --> Security Class Initialized
DEBUG - 2016-09-15 19:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 19:14:41 --> Input Class Initialized
INFO - 2016-09-15 19:14:41 --> Language Class Initialized
INFO - 2016-09-15 19:14:41 --> Language Class Initialized
INFO - 2016-09-15 19:14:41 --> Config Class Initialized
INFO - 2016-09-15 19:14:41 --> Loader Class Initialized
INFO - 2016-09-15 19:14:41 --> Helper loaded: url_helper
INFO - 2016-09-15 19:14:41 --> Database Driver Class Initialized
INFO - 2016-09-15 19:14:41 --> Controller Class Initialized
DEBUG - 2016-09-15 19:14:41 --> Index MX_Controller Initialized
INFO - 2016-09-15 19:14:41 --> Model Class Initialized
INFO - 2016-09-15 19:14:41 --> Model Class Initialized
DEBUG - 2016-09-15 19:14:41 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:14:42 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:14:42 --> Module controller failed to run: admin/Index/detailAngsuran/
DEBUG - 2016-09-15 19:14:42 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:14:42 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:14:42 --> Module controller failed to run: admin/index/detailAngsuran/1574bddb75c78a6fd2251d61e2993b5146201319/bunga
ERROR - 2016-09-15 19:14:42 --> Module controller failed to run: admin/Index/detailAngsuran/
DEBUG - 2016-09-15 19:14:42 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:14:42 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:14:42 --> Module controller failed to run: admin/index/detailAngsuran/0716d9708d321ffb6a00818614779e779925365c/bunga
ERROR - 2016-09-15 19:14:42 --> Module controller failed to run: admin/Index/detailAngsuran/
DEBUG - 2016-09-15 19:14:42 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:14:42 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:14:42 --> Module controller failed to run: admin/index/detailAngsuran/9e6a55b6b4563e652a23be9d623ca5055c356940/bunga
ERROR - 2016-09-15 19:14:42 --> Module controller failed to run: admin/Index/detailAngsuran/
DEBUG - 2016-09-15 19:14:42 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:14:42 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:14:42 --> Module controller failed to run: admin/index/detailAngsuran/f6e1126cedebf23e1463aee73f9df08783640400/bunga
ERROR - 2016-09-15 19:14:42 --> Module controller failed to run: admin/Index/detailAngsuran/
DEBUG - 2016-09-15 19:14:42 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:14:42 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:14:42 --> Module controller failed to run: admin/index/detailAngsuran/887309d048beef83ad3eabf2a79a64a389ab1c9f/bunga
ERROR - 2016-09-15 19:14:42 --> Module controller failed to run: admin/Index/detailAngsuran/
DEBUG - 2016-09-15 19:14:42 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:14:42 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:14:42 --> Module controller failed to run: admin/index/detailAngsuran/0a57cb53ba59c46fc4b692527a38a87c78d84028/bunga
ERROR - 2016-09-15 19:14:42 --> Module controller failed to run: admin/Index/detailAngsuran/
DEBUG - 2016-09-15 19:14:42 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:14:42 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:14:42 --> Module controller failed to run: admin/index/detailAngsuran/7719a1c782a1ba91c031a682a0a2f8658209adbf/bunga
DEBUG - 2016-09-15 19:14:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_angsuran.php
INFO - 2016-09-15 19:14:42 --> Final output sent to browser
DEBUG - 2016-09-15 19:14:42 --> Total execution time: 1.7685
INFO - 2016-09-15 19:15:15 --> Config Class Initialized
INFO - 2016-09-15 19:15:15 --> Hooks Class Initialized
DEBUG - 2016-09-15 19:15:15 --> UTF-8 Support Enabled
INFO - 2016-09-15 19:15:15 --> Utf8 Class Initialized
INFO - 2016-09-15 19:15:15 --> URI Class Initialized
INFO - 2016-09-15 19:15:15 --> Router Class Initialized
INFO - 2016-09-15 19:15:15 --> Output Class Initialized
INFO - 2016-09-15 19:15:15 --> Security Class Initialized
DEBUG - 2016-09-15 19:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 19:15:16 --> Input Class Initialized
INFO - 2016-09-15 19:15:16 --> Language Class Initialized
INFO - 2016-09-15 19:15:16 --> Language Class Initialized
INFO - 2016-09-15 19:15:16 --> Config Class Initialized
INFO - 2016-09-15 19:15:16 --> Loader Class Initialized
INFO - 2016-09-15 19:15:16 --> Helper loaded: url_helper
INFO - 2016-09-15 19:15:16 --> Database Driver Class Initialized
INFO - 2016-09-15 19:15:16 --> Controller Class Initialized
DEBUG - 2016-09-15 19:15:16 --> Index MX_Controller Initialized
INFO - 2016-09-15 19:15:16 --> Model Class Initialized
INFO - 2016-09-15 19:15:16 --> Model Class Initialized
DEBUG - 2016-09-15 19:15:16 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:15:16 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:15:16 --> Module controller failed to run: admin/Index/detailAngsuran/
DEBUG - 2016-09-15 19:15:16 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:15:16 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:15:16 --> Module controller failed to run: admin/index/detailAngsuran/1574bddb75c78a6fd2251d61e2993b5146201319/bunga
ERROR - 2016-09-15 19:15:16 --> Module controller failed to run: admin/Index/detailAngsuran/
DEBUG - 2016-09-15 19:15:16 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:15:16 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:15:16 --> Module controller failed to run: admin/index/detailAngsuran/0716d9708d321ffb6a00818614779e779925365c/bunga
ERROR - 2016-09-15 19:15:16 --> Module controller failed to run: admin/Index/detailAngsuran/
DEBUG - 2016-09-15 19:15:16 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:15:16 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:15:16 --> Module controller failed to run: admin/index/detailAngsuran/9e6a55b6b4563e652a23be9d623ca5055c356940/bunga
ERROR - 2016-09-15 19:15:16 --> Module controller failed to run: admin/Index/detailAngsuran/
DEBUG - 2016-09-15 19:15:16 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:15:16 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:15:16 --> Module controller failed to run: admin/index/detailAngsuran/f6e1126cedebf23e1463aee73f9df08783640400/bunga
ERROR - 2016-09-15 19:15:16 --> Module controller failed to run: admin/Index/detailAngsuran/
DEBUG - 2016-09-15 19:15:16 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:15:17 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:15:17 --> Module controller failed to run: admin/index/detailAngsuran/887309d048beef83ad3eabf2a79a64a389ab1c9f/bunga
ERROR - 2016-09-15 19:15:17 --> Module controller failed to run: admin/Index/detailAngsuran/
DEBUG - 2016-09-15 19:15:17 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:15:17 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:15:17 --> Module controller failed to run: admin/index/detailAngsuran/0a57cb53ba59c46fc4b692527a38a87c78d84028/bunga
ERROR - 2016-09-15 19:15:17 --> Module controller failed to run: admin/Index/detailAngsuran/
DEBUG - 2016-09-15 19:15:17 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:15:17 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:15:17 --> Module controller failed to run: admin/index/detailAngsuran/7719a1c782a1ba91c031a682a0a2f8658209adbf/bunga
DEBUG - 2016-09-15 19:15:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_angsuran.php
INFO - 2016-09-15 19:15:17 --> Final output sent to browser
DEBUG - 2016-09-15 19:15:17 --> Total execution time: 1.7081
INFO - 2016-09-15 19:16:15 --> Config Class Initialized
INFO - 2016-09-15 19:16:15 --> Hooks Class Initialized
DEBUG - 2016-09-15 19:16:15 --> UTF-8 Support Enabled
INFO - 2016-09-15 19:16:15 --> Utf8 Class Initialized
INFO - 2016-09-15 19:16:15 --> URI Class Initialized
INFO - 2016-09-15 19:16:15 --> Router Class Initialized
INFO - 2016-09-15 19:16:15 --> Output Class Initialized
INFO - 2016-09-15 19:16:15 --> Security Class Initialized
DEBUG - 2016-09-15 19:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 19:16:16 --> Input Class Initialized
INFO - 2016-09-15 19:16:16 --> Language Class Initialized
INFO - 2016-09-15 19:16:16 --> Language Class Initialized
INFO - 2016-09-15 19:16:16 --> Config Class Initialized
INFO - 2016-09-15 19:16:16 --> Loader Class Initialized
INFO - 2016-09-15 19:16:16 --> Helper loaded: url_helper
INFO - 2016-09-15 19:16:16 --> Database Driver Class Initialized
INFO - 2016-09-15 19:16:16 --> Controller Class Initialized
DEBUG - 2016-09-15 19:16:16 --> Index MX_Controller Initialized
INFO - 2016-09-15 19:16:16 --> Model Class Initialized
INFO - 2016-09-15 19:16:16 --> Model Class Initialized
DEBUG - 2016-09-15 19:16:16 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:16:16 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:16:16 --> Module controller failed to run: admin/Index/detailAngsuran/
DEBUG - 2016-09-15 19:16:16 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:16:16 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:16:16 --> Module controller failed to run: admin/index/detailAngsuran/1574bddb75c78a6fd2251d61e2993b5146201319/bunga
ERROR - 2016-09-15 19:16:16 --> Module controller failed to run: admin/Index/detailAngsuran/
DEBUG - 2016-09-15 19:16:16 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:16:16 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:16:16 --> Module controller failed to run: admin/index/detailAngsuran/0716d9708d321ffb6a00818614779e779925365c/bunga
ERROR - 2016-09-15 19:16:16 --> Module controller failed to run: admin/Index/detailAngsuran/
DEBUG - 2016-09-15 19:16:16 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:16:16 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:16:16 --> Module controller failed to run: admin/index/detailAngsuran/9e6a55b6b4563e652a23be9d623ca5055c356940/bunga
ERROR - 2016-09-15 19:16:16 --> Module controller failed to run: admin/Index/detailAngsuran/
DEBUG - 2016-09-15 19:16:16 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:16:16 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:16:16 --> Module controller failed to run: admin/index/detailAngsuran/f6e1126cedebf23e1463aee73f9df08783640400/bunga
ERROR - 2016-09-15 19:16:16 --> Module controller failed to run: admin/Index/detailAngsuran/
DEBUG - 2016-09-15 19:16:16 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:16:16 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:16:17 --> Module controller failed to run: admin/index/detailAngsuran/887309d048beef83ad3eabf2a79a64a389ab1c9f/bunga
ERROR - 2016-09-15 19:16:17 --> Module controller failed to run: admin/Index/detailAngsuran/
DEBUG - 2016-09-15 19:16:17 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:16:17 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:16:17 --> Module controller failed to run: admin/index/detailAngsuran/0a57cb53ba59c46fc4b692527a38a87c78d84028/bunga
ERROR - 2016-09-15 19:16:17 --> Module controller failed to run: admin/Index/detailAngsuran/
DEBUG - 2016-09-15 19:16:17 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:16:17 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:16:17 --> Module controller failed to run: admin/index/detailAngsuran/7719a1c782a1ba91c031a682a0a2f8658209adbf/bunga
DEBUG - 2016-09-15 19:16:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_angsuran.php
INFO - 2016-09-15 19:16:17 --> Final output sent to browser
DEBUG - 2016-09-15 19:16:17 --> Total execution time: 1.6677
INFO - 2016-09-15 19:16:46 --> Config Class Initialized
INFO - 2016-09-15 19:16:46 --> Hooks Class Initialized
DEBUG - 2016-09-15 19:16:46 --> UTF-8 Support Enabled
INFO - 2016-09-15 19:16:46 --> Utf8 Class Initialized
INFO - 2016-09-15 19:16:46 --> URI Class Initialized
INFO - 2016-09-15 19:16:46 --> Router Class Initialized
INFO - 2016-09-15 19:16:46 --> Output Class Initialized
INFO - 2016-09-15 19:16:46 --> Security Class Initialized
DEBUG - 2016-09-15 19:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 19:16:46 --> Input Class Initialized
INFO - 2016-09-15 19:16:46 --> Language Class Initialized
INFO - 2016-09-15 19:16:46 --> Language Class Initialized
INFO - 2016-09-15 19:16:46 --> Config Class Initialized
INFO - 2016-09-15 19:16:46 --> Loader Class Initialized
INFO - 2016-09-15 19:16:46 --> Helper loaded: url_helper
INFO - 2016-09-15 19:16:46 --> Database Driver Class Initialized
INFO - 2016-09-15 19:16:46 --> Controller Class Initialized
DEBUG - 2016-09-15 19:16:46 --> Index MX_Controller Initialized
INFO - 2016-09-15 19:16:46 --> Model Class Initialized
INFO - 2016-09-15 19:16:46 --> Model Class Initialized
DEBUG - 2016-09-15 19:16:46 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:16:46 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:16:46 --> Module controller failed to run: admin/index/detailAngsuran/
DEBUG - 2016-09-15 19:16:46 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:16:46 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:16:46 --> Module controller failed to run: admin/index/detailAngsuran/1574bddb75c78a6fd2251d61e2993b5146201319/bunga
ERROR - 2016-09-15 19:16:47 --> Module controller failed to run: admin/index/detailAngsuran/
DEBUG - 2016-09-15 19:16:47 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:16:47 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:16:47 --> Module controller failed to run: admin/index/detailAngsuran/0716d9708d321ffb6a00818614779e779925365c/bunga
ERROR - 2016-09-15 19:16:47 --> Module controller failed to run: admin/index/detailAngsuran/
DEBUG - 2016-09-15 19:16:47 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:16:47 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:16:47 --> Module controller failed to run: admin/index/detailAngsuran/9e6a55b6b4563e652a23be9d623ca5055c356940/bunga
ERROR - 2016-09-15 19:16:47 --> Module controller failed to run: admin/index/detailAngsuran/
DEBUG - 2016-09-15 19:16:47 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:16:47 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:16:47 --> Module controller failed to run: admin/index/detailAngsuran/f6e1126cedebf23e1463aee73f9df08783640400/bunga
ERROR - 2016-09-15 19:16:47 --> Module controller failed to run: admin/index/detailAngsuran/
DEBUG - 2016-09-15 19:16:47 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:16:47 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:16:47 --> Module controller failed to run: admin/index/detailAngsuran/887309d048beef83ad3eabf2a79a64a389ab1c9f/bunga
ERROR - 2016-09-15 19:16:47 --> Module controller failed to run: admin/index/detailAngsuran/
DEBUG - 2016-09-15 19:16:47 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:16:47 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:16:47 --> Module controller failed to run: admin/index/detailAngsuran/0a57cb53ba59c46fc4b692527a38a87c78d84028/bunga
ERROR - 2016-09-15 19:16:47 --> Module controller failed to run: admin/index/detailAngsuran/
DEBUG - 2016-09-15 19:16:47 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:16:47 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:16:47 --> Module controller failed to run: admin/index/detailAngsuran/7719a1c782a1ba91c031a682a0a2f8658209adbf/bunga
DEBUG - 2016-09-15 19:16:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_angsuran.php
INFO - 2016-09-15 19:16:47 --> Final output sent to browser
DEBUG - 2016-09-15 19:16:47 --> Total execution time: 1.7357
INFO - 2016-09-15 19:17:06 --> Config Class Initialized
INFO - 2016-09-15 19:17:06 --> Hooks Class Initialized
DEBUG - 2016-09-15 19:17:06 --> UTF-8 Support Enabled
INFO - 2016-09-15 19:17:07 --> Utf8 Class Initialized
INFO - 2016-09-15 19:17:07 --> URI Class Initialized
INFO - 2016-09-15 19:17:07 --> Router Class Initialized
INFO - 2016-09-15 19:17:07 --> Output Class Initialized
INFO - 2016-09-15 19:17:07 --> Security Class Initialized
DEBUG - 2016-09-15 19:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 19:17:07 --> Input Class Initialized
INFO - 2016-09-15 19:17:07 --> Language Class Initialized
INFO - 2016-09-15 19:17:07 --> Language Class Initialized
INFO - 2016-09-15 19:17:07 --> Config Class Initialized
INFO - 2016-09-15 19:17:07 --> Loader Class Initialized
INFO - 2016-09-15 19:17:07 --> Helper loaded: url_helper
INFO - 2016-09-15 19:17:07 --> Database Driver Class Initialized
INFO - 2016-09-15 19:17:07 --> Controller Class Initialized
DEBUG - 2016-09-15 19:17:07 --> Index MX_Controller Initialized
INFO - 2016-09-15 19:17:07 --> Model Class Initialized
INFO - 2016-09-15 19:17:07 --> Model Class Initialized
DEBUG - 2016-09-15 19:17:07 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:17:07 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:17:07 --> Module controller failed to run: admin/index/detailAngsuran/
DEBUG - 2016-09-15 19:17:07 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:17:07 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:17:07 --> Module controller failed to run: admin/index/detailAngsuran/1574bddb75c78a6fd2251d61e2993b5146201319/bunga
ERROR - 2016-09-15 19:17:07 --> Module controller failed to run: admin/index/detailAngsuran/
DEBUG - 2016-09-15 19:17:07 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:17:07 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:17:07 --> Module controller failed to run: admin/index/detailAngsuran/0716d9708d321ffb6a00818614779e779925365c/bunga
ERROR - 2016-09-15 19:17:07 --> Module controller failed to run: admin/index/detailAngsuran/
DEBUG - 2016-09-15 19:17:07 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:17:07 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:17:07 --> Module controller failed to run: admin/index/detailAngsuran/9e6a55b6b4563e652a23be9d623ca5055c356940/bunga
ERROR - 2016-09-15 19:17:08 --> Module controller failed to run: admin/index/detailAngsuran/
DEBUG - 2016-09-15 19:17:08 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:17:08 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:17:08 --> Module controller failed to run: admin/index/detailAngsuran/f6e1126cedebf23e1463aee73f9df08783640400/bunga
ERROR - 2016-09-15 19:17:08 --> Module controller failed to run: admin/index/detailAngsuran/
DEBUG - 2016-09-15 19:17:08 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:17:08 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:17:08 --> Module controller failed to run: admin/index/detailAngsuran/887309d048beef83ad3eabf2a79a64a389ab1c9f/bunga
ERROR - 2016-09-15 19:17:08 --> Module controller failed to run: admin/index/detailAngsuran/
DEBUG - 2016-09-15 19:17:08 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:17:08 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:17:08 --> Module controller failed to run: admin/index/detailAngsuran/0a57cb53ba59c46fc4b692527a38a87c78d84028/bunga
ERROR - 2016-09-15 19:17:08 --> Module controller failed to run: admin/index/detailAngsuran/
DEBUG - 2016-09-15 19:17:08 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:17:08 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:17:08 --> Module controller failed to run: admin/index/detailAngsuran/7719a1c782a1ba91c031a682a0a2f8658209adbf/bunga
DEBUG - 2016-09-15 19:17:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_angsuran.php
INFO - 2016-09-15 19:17:08 --> Final output sent to browser
DEBUG - 2016-09-15 19:17:08 --> Total execution time: 1.6287
INFO - 2016-09-15 19:17:40 --> Config Class Initialized
INFO - 2016-09-15 19:17:41 --> Hooks Class Initialized
DEBUG - 2016-09-15 19:17:41 --> UTF-8 Support Enabled
INFO - 2016-09-15 19:17:41 --> Utf8 Class Initialized
INFO - 2016-09-15 19:17:41 --> URI Class Initialized
INFO - 2016-09-15 19:17:41 --> Router Class Initialized
INFO - 2016-09-15 19:17:41 --> Output Class Initialized
INFO - 2016-09-15 19:17:41 --> Security Class Initialized
DEBUG - 2016-09-15 19:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 19:17:41 --> Input Class Initialized
INFO - 2016-09-15 19:17:41 --> Language Class Initialized
INFO - 2016-09-15 19:17:41 --> Language Class Initialized
INFO - 2016-09-15 19:17:41 --> Config Class Initialized
INFO - 2016-09-15 19:17:41 --> Loader Class Initialized
INFO - 2016-09-15 19:17:41 --> Helper loaded: url_helper
INFO - 2016-09-15 19:17:41 --> Database Driver Class Initialized
INFO - 2016-09-15 19:17:41 --> Controller Class Initialized
DEBUG - 2016-09-15 19:17:41 --> Index MX_Controller Initialized
INFO - 2016-09-15 19:17:41 --> Model Class Initialized
INFO - 2016-09-15 19:17:41 --> Model Class Initialized
DEBUG - 2016-09-15 19:17:41 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:17:41 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:17:41 --> Module controller failed to run: admin/index/detailAngsuran/
DEBUG - 2016-09-15 19:17:41 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:17:41 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:17:41 --> Module controller failed to run: admin/index/detailAngsuran/1574bddb75c78a6fd2251d61e2993b5146201319/bunga
ERROR - 2016-09-15 19:17:41 --> Module controller failed to run: admin/index/detailAngsuran/
DEBUG - 2016-09-15 19:17:41 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:17:41 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:17:41 --> Module controller failed to run: admin/index/detailAngsuran/0716d9708d321ffb6a00818614779e779925365c/bunga
ERROR - 2016-09-15 19:17:42 --> Module controller failed to run: admin/index/detailAngsuran/
DEBUG - 2016-09-15 19:17:42 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:17:42 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:17:42 --> Module controller failed to run: admin/index/detailAngsuran/9e6a55b6b4563e652a23be9d623ca5055c356940/bunga
ERROR - 2016-09-15 19:17:42 --> Module controller failed to run: admin/index/detailAngsuran/
DEBUG - 2016-09-15 19:17:42 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:17:42 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:17:42 --> Module controller failed to run: admin/index/detailAngsuran/f6e1126cedebf23e1463aee73f9df08783640400/bunga
ERROR - 2016-09-15 19:17:42 --> Module controller failed to run: admin/index/detailAngsuran/
DEBUG - 2016-09-15 19:17:42 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:17:42 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:17:42 --> Module controller failed to run: admin/index/detailAngsuran/887309d048beef83ad3eabf2a79a64a389ab1c9f/bunga
ERROR - 2016-09-15 19:17:42 --> Module controller failed to run: admin/index/detailAngsuran/
DEBUG - 2016-09-15 19:17:42 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:17:42 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:17:42 --> Module controller failed to run: admin/index/detailAngsuran/0a57cb53ba59c46fc4b692527a38a87c78d84028/bunga
ERROR - 2016-09-15 19:17:42 --> Module controller failed to run: admin/index/detailAngsuran/
DEBUG - 2016-09-15 19:17:42 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:17:42 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:17:42 --> Module controller failed to run: admin/index/detailAngsuran/7719a1c782a1ba91c031a682a0a2f8658209adbf/bunga
DEBUG - 2016-09-15 19:17:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_angsuran.php
INFO - 2016-09-15 19:17:42 --> Final output sent to browser
DEBUG - 2016-09-15 19:17:42 --> Total execution time: 1.7683
INFO - 2016-09-15 19:18:21 --> Config Class Initialized
INFO - 2016-09-15 19:18:21 --> Hooks Class Initialized
DEBUG - 2016-09-15 19:18:21 --> UTF-8 Support Enabled
INFO - 2016-09-15 19:18:21 --> Utf8 Class Initialized
INFO - 2016-09-15 19:18:21 --> URI Class Initialized
INFO - 2016-09-15 19:18:21 --> Router Class Initialized
INFO - 2016-09-15 19:18:21 --> Output Class Initialized
INFO - 2016-09-15 19:18:21 --> Security Class Initialized
DEBUG - 2016-09-15 19:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 19:18:22 --> Input Class Initialized
INFO - 2016-09-15 19:18:22 --> Language Class Initialized
INFO - 2016-09-15 19:18:22 --> Language Class Initialized
INFO - 2016-09-15 19:18:22 --> Config Class Initialized
INFO - 2016-09-15 19:18:22 --> Loader Class Initialized
INFO - 2016-09-15 19:18:22 --> Helper loaded: url_helper
INFO - 2016-09-15 19:18:22 --> Database Driver Class Initialized
INFO - 2016-09-15 19:18:22 --> Controller Class Initialized
DEBUG - 2016-09-15 19:18:22 --> Index MX_Controller Initialized
INFO - 2016-09-15 19:18:22 --> Model Class Initialized
INFO - 2016-09-15 19:18:22 --> Model Class Initialized
DEBUG - 2016-09-15 19:18:22 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:18:22 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:18:22 --> Module controller failed to run: admin/index/detailAngsuran/
ERROR - 2016-09-15 19:18:22 --> Severity: Notice --> Undefined variable: kd_pinjaman E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 481
INFO - 2016-09-15 19:18:22 --> Database Driver Class Initialized
ERROR - 2016-09-15 19:18:22 --> Severity: Notice --> Undefined variable: output E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 483
ERROR - 2016-09-15 19:18:22 --> Severity: Notice --> Undefined variable: output E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 485
ERROR - 2016-09-15 19:18:22 --> Severity: Notice --> Undefined variable: output E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 491
DEBUG - 2016-09-15 19:18:22 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:18:22 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:18:22 --> Module controller failed to run: admin/index/detailAngsuran/1574bddb75c78a6fd2251d61e2993b5146201319/bunga
ERROR - 2016-09-15 19:18:22 --> Module controller failed to run: admin/index/detailAngsuran/
ERROR - 2016-09-15 19:18:22 --> Severity: Notice --> Undefined variable: kd_pinjaman E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 481
INFO - 2016-09-15 19:18:22 --> Database Driver Class Initialized
ERROR - 2016-09-15 19:18:22 --> Severity: Notice --> Undefined variable: output E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 483
ERROR - 2016-09-15 19:18:22 --> Severity: Notice --> Undefined variable: output E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 485
ERROR - 2016-09-15 19:18:22 --> Severity: Notice --> Undefined variable: output E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 491
DEBUG - 2016-09-15 19:18:22 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:18:22 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:18:23 --> Module controller failed to run: admin/index/detailAngsuran/0716d9708d321ffb6a00818614779e779925365c/bunga
ERROR - 2016-09-15 19:18:23 --> Module controller failed to run: admin/index/detailAngsuran/
ERROR - 2016-09-15 19:18:23 --> Severity: Notice --> Undefined variable: kd_pinjaman E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 481
INFO - 2016-09-15 19:18:23 --> Database Driver Class Initialized
ERROR - 2016-09-15 19:18:23 --> Severity: Notice --> Undefined variable: output E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 483
ERROR - 2016-09-15 19:18:23 --> Severity: Notice --> Undefined variable: output E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 485
ERROR - 2016-09-15 19:18:23 --> Severity: Notice --> Undefined variable: output E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 491
DEBUG - 2016-09-15 19:18:23 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:18:23 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:18:23 --> Module controller failed to run: admin/index/detailAngsuran/9e6a55b6b4563e652a23be9d623ca5055c356940/bunga
ERROR - 2016-09-15 19:18:23 --> Module controller failed to run: admin/index/detailAngsuran/
ERROR - 2016-09-15 19:18:23 --> Severity: Notice --> Undefined variable: kd_pinjaman E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 481
INFO - 2016-09-15 19:18:23 --> Database Driver Class Initialized
ERROR - 2016-09-15 19:18:23 --> Severity: Notice --> Undefined variable: output E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 483
ERROR - 2016-09-15 19:18:23 --> Severity: Notice --> Undefined variable: output E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 485
ERROR - 2016-09-15 19:18:23 --> Severity: Notice --> Undefined variable: output E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 491
DEBUG - 2016-09-15 19:18:23 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:18:23 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:18:23 --> Module controller failed to run: admin/index/detailAngsuran/f6e1126cedebf23e1463aee73f9df08783640400/bunga
ERROR - 2016-09-15 19:18:23 --> Module controller failed to run: admin/index/detailAngsuran/
ERROR - 2016-09-15 19:18:23 --> Severity: Notice --> Undefined variable: kd_pinjaman E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 481
INFO - 2016-09-15 19:18:23 --> Database Driver Class Initialized
ERROR - 2016-09-15 19:18:23 --> Severity: Notice --> Undefined variable: output E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 483
ERROR - 2016-09-15 19:18:23 --> Severity: Notice --> Undefined variable: output E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 485
ERROR - 2016-09-15 19:18:23 --> Severity: Notice --> Undefined variable: output E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 491
DEBUG - 2016-09-15 19:18:23 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:18:24 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:18:24 --> Module controller failed to run: admin/index/detailAngsuran/887309d048beef83ad3eabf2a79a64a389ab1c9f/bunga
ERROR - 2016-09-15 19:18:24 --> Module controller failed to run: admin/index/detailAngsuran/
ERROR - 2016-09-15 19:18:24 --> Severity: Notice --> Undefined variable: kd_pinjaman E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 481
INFO - 2016-09-15 19:18:24 --> Database Driver Class Initialized
ERROR - 2016-09-15 19:18:24 --> Severity: Notice --> Undefined variable: output E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 483
ERROR - 2016-09-15 19:18:24 --> Severity: Notice --> Undefined variable: output E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 485
ERROR - 2016-09-15 19:18:24 --> Severity: Notice --> Undefined variable: output E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 491
DEBUG - 2016-09-15 19:18:24 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:18:24 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:18:24 --> Module controller failed to run: admin/index/detailAngsuran/0a57cb53ba59c46fc4b692527a38a87c78d84028/bunga
ERROR - 2016-09-15 19:18:24 --> Module controller failed to run: admin/index/detailAngsuran/
ERROR - 2016-09-15 19:18:24 --> Severity: Notice --> Undefined variable: kd_pinjaman E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 481
INFO - 2016-09-15 19:18:24 --> Database Driver Class Initialized
ERROR - 2016-09-15 19:18:24 --> Severity: Notice --> Undefined variable: output E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 483
ERROR - 2016-09-15 19:18:24 --> Severity: Notice --> Undefined variable: output E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 485
ERROR - 2016-09-15 19:18:24 --> Severity: Notice --> Undefined variable: output E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 491
DEBUG - 2016-09-15 19:18:24 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:18:24 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:18:24 --> Module controller failed to run: admin/index/detailAngsuran/7719a1c782a1ba91c031a682a0a2f8658209adbf/bunga
DEBUG - 2016-09-15 19:18:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_angsuran.php
INFO - 2016-09-15 19:18:24 --> Final output sent to browser
DEBUG - 2016-09-15 19:18:24 --> Total execution time: 2.9925
INFO - 2016-09-15 19:18:59 --> Config Class Initialized
INFO - 2016-09-15 19:18:59 --> Hooks Class Initialized
DEBUG - 2016-09-15 19:18:59 --> UTF-8 Support Enabled
INFO - 2016-09-15 19:18:59 --> Utf8 Class Initialized
INFO - 2016-09-15 19:18:59 --> URI Class Initialized
INFO - 2016-09-15 19:18:59 --> Router Class Initialized
INFO - 2016-09-15 19:18:59 --> Output Class Initialized
INFO - 2016-09-15 19:18:59 --> Security Class Initialized
DEBUG - 2016-09-15 19:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 19:18:59 --> Input Class Initialized
INFO - 2016-09-15 19:18:59 --> Language Class Initialized
INFO - 2016-09-15 19:18:59 --> Language Class Initialized
INFO - 2016-09-15 19:18:59 --> Config Class Initialized
INFO - 2016-09-15 19:18:59 --> Loader Class Initialized
INFO - 2016-09-15 19:18:59 --> Helper loaded: url_helper
INFO - 2016-09-15 19:18:59 --> Database Driver Class Initialized
INFO - 2016-09-15 19:18:59 --> Controller Class Initialized
DEBUG - 2016-09-15 19:18:59 --> Index MX_Controller Initialized
INFO - 2016-09-15 19:18:59 --> Model Class Initialized
INFO - 2016-09-15 19:18:59 --> Model Class Initialized
DEBUG - 2016-09-15 19:18:59 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:18:59 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:18:59 --> Module controller failed to run: admin/index/detailAngsuran/
ERROR - 2016-09-15 19:19:00 --> Severity: Notice --> Undefined variable: kd_pinjaman E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 481
INFO - 2016-09-15 19:19:00 --> Database Driver Class Initialized
ERROR - 2016-09-15 19:19:00 --> Severity: Notice --> Undefined variable: output E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 483
ERROR - 2016-09-15 19:19:00 --> Severity: Notice --> Undefined variable: output E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 485
ERROR - 2016-09-15 19:19:00 --> Severity: Notice --> Undefined variable: output E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 491
DEBUG - 2016-09-15 19:19:00 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:19:00 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:19:00 --> Module controller failed to run: admin/index/detailAngsuran/1574bddb75c78a6fd2251d61e2993b5146201319/bunga
ERROR - 2016-09-15 19:19:00 --> Module controller failed to run: admin/index/detailAngsuran/
ERROR - 2016-09-15 19:19:00 --> Severity: Notice --> Undefined variable: kd_pinjaman E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 481
INFO - 2016-09-15 19:19:00 --> Database Driver Class Initialized
ERROR - 2016-09-15 19:19:00 --> Severity: Notice --> Undefined variable: output E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 483
ERROR - 2016-09-15 19:19:00 --> Severity: Notice --> Undefined variable: output E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 485
ERROR - 2016-09-15 19:19:00 --> Severity: Notice --> Undefined variable: output E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 491
DEBUG - 2016-09-15 19:19:00 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:19:00 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:19:00 --> Module controller failed to run: admin/index/detailAngsuran/0716d9708d321ffb6a00818614779e779925365c/bunga
ERROR - 2016-09-15 19:19:00 --> Module controller failed to run: admin/index/detailAngsuran/
ERROR - 2016-09-15 19:19:00 --> Severity: Notice --> Undefined variable: kd_pinjaman E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 481
INFO - 2016-09-15 19:19:00 --> Database Driver Class Initialized
ERROR - 2016-09-15 19:19:00 --> Severity: Notice --> Undefined variable: output E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 483
ERROR - 2016-09-15 19:19:00 --> Severity: Notice --> Undefined variable: output E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 485
ERROR - 2016-09-15 19:19:00 --> Severity: Notice --> Undefined variable: output E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 491
DEBUG - 2016-09-15 19:19:00 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:19:00 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:19:00 --> Module controller failed to run: admin/index/detailAngsuran/9e6a55b6b4563e652a23be9d623ca5055c356940/bunga
ERROR - 2016-09-15 19:19:00 --> Module controller failed to run: admin/index/detailAngsuran/
ERROR - 2016-09-15 19:19:00 --> Severity: Notice --> Undefined variable: kd_pinjaman E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 481
INFO - 2016-09-15 19:19:00 --> Database Driver Class Initialized
ERROR - 2016-09-15 19:19:00 --> Severity: Notice --> Undefined variable: output E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 483
ERROR - 2016-09-15 19:19:01 --> Severity: Notice --> Undefined variable: output E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 485
ERROR - 2016-09-15 19:19:01 --> Severity: Notice --> Undefined variable: output E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 491
DEBUG - 2016-09-15 19:19:01 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:19:01 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:19:01 --> Module controller failed to run: admin/index/detailAngsuran/f6e1126cedebf23e1463aee73f9df08783640400/bunga
ERROR - 2016-09-15 19:19:01 --> Module controller failed to run: admin/index/detailAngsuran/
ERROR - 2016-09-15 19:19:01 --> Severity: Notice --> Undefined variable: kd_pinjaman E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 481
INFO - 2016-09-15 19:19:01 --> Database Driver Class Initialized
ERROR - 2016-09-15 19:19:01 --> Severity: Notice --> Undefined variable: output E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 483
ERROR - 2016-09-15 19:19:01 --> Severity: Notice --> Undefined variable: output E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 485
ERROR - 2016-09-15 19:19:01 --> Severity: Notice --> Undefined variable: output E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 491
DEBUG - 2016-09-15 19:19:01 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:19:01 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:19:01 --> Module controller failed to run: admin/index/detailAngsuran/887309d048beef83ad3eabf2a79a64a389ab1c9f/bunga
ERROR - 2016-09-15 19:19:01 --> Module controller failed to run: admin/index/detailAngsuran/
ERROR - 2016-09-15 19:19:01 --> Severity: Notice --> Undefined variable: kd_pinjaman E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 481
INFO - 2016-09-15 19:19:01 --> Database Driver Class Initialized
ERROR - 2016-09-15 19:19:01 --> Severity: Notice --> Undefined variable: output E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 483
ERROR - 2016-09-15 19:19:01 --> Severity: Notice --> Undefined variable: output E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 485
ERROR - 2016-09-15 19:19:01 --> Severity: Notice --> Undefined variable: output E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 491
DEBUG - 2016-09-15 19:19:01 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:19:01 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:19:01 --> Module controller failed to run: admin/index/detailAngsuran/0a57cb53ba59c46fc4b692527a38a87c78d84028/bunga
ERROR - 2016-09-15 19:19:01 --> Module controller failed to run: admin/index/detailAngsuran/
ERROR - 2016-09-15 19:19:01 --> Severity: Notice --> Undefined variable: kd_pinjaman E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 481
INFO - 2016-09-15 19:19:01 --> Database Driver Class Initialized
ERROR - 2016-09-15 19:19:01 --> Severity: Notice --> Undefined variable: output E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 483
ERROR - 2016-09-15 19:19:01 --> Severity: Notice --> Undefined variable: output E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 485
ERROR - 2016-09-15 19:19:02 --> Severity: Notice --> Undefined variable: output E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 491
DEBUG - 2016-09-15 19:19:02 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:19:02 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:19:02 --> Module controller failed to run: admin/index/detailAngsuran/7719a1c782a1ba91c031a682a0a2f8658209adbf/bunga
DEBUG - 2016-09-15 19:19:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_angsuran.php
INFO - 2016-09-15 19:19:02 --> Final output sent to browser
DEBUG - 2016-09-15 19:19:02 --> Total execution time: 3.1817
INFO - 2016-09-15 19:19:24 --> Config Class Initialized
INFO - 2016-09-15 19:19:24 --> Hooks Class Initialized
DEBUG - 2016-09-15 19:19:24 --> UTF-8 Support Enabled
INFO - 2016-09-15 19:19:24 --> Utf8 Class Initialized
INFO - 2016-09-15 19:19:25 --> URI Class Initialized
INFO - 2016-09-15 19:19:25 --> Router Class Initialized
INFO - 2016-09-15 19:19:25 --> Output Class Initialized
INFO - 2016-09-15 19:19:25 --> Security Class Initialized
DEBUG - 2016-09-15 19:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 19:19:25 --> Input Class Initialized
INFO - 2016-09-15 19:19:25 --> Language Class Initialized
INFO - 2016-09-15 19:19:25 --> Language Class Initialized
INFO - 2016-09-15 19:19:25 --> Config Class Initialized
INFO - 2016-09-15 19:19:25 --> Loader Class Initialized
INFO - 2016-09-15 19:19:25 --> Helper loaded: url_helper
INFO - 2016-09-15 19:19:25 --> Database Driver Class Initialized
INFO - 2016-09-15 19:19:25 --> Controller Class Initialized
DEBUG - 2016-09-15 19:19:25 --> Index MX_Controller Initialized
INFO - 2016-09-15 19:19:25 --> Model Class Initialized
INFO - 2016-09-15 19:19:25 --> Model Class Initialized
DEBUG - 2016-09-15 19:19:25 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:19:25 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:19:25 --> Module controller failed to run: admin/index/detailAngsuran/
INFO - 2016-09-15 19:19:25 --> Database Driver Class Initialized
DEBUG - 2016-09-15 19:19:25 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:19:25 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:19:25 --> Module controller failed to run: admin/index/detailAngsuran/1574bddb75c78a6fd2251d61e2993b5146201319/bunga
ERROR - 2016-09-15 19:19:25 --> Module controller failed to run: admin/index/detailAngsuran/
INFO - 2016-09-15 19:19:25 --> Database Driver Class Initialized
DEBUG - 2016-09-15 19:19:25 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:19:25 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:19:25 --> Module controller failed to run: admin/index/detailAngsuran/0716d9708d321ffb6a00818614779e779925365c/bunga
ERROR - 2016-09-15 19:19:26 --> Module controller failed to run: admin/index/detailAngsuran/
INFO - 2016-09-15 19:19:26 --> Database Driver Class Initialized
DEBUG - 2016-09-15 19:19:26 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:19:26 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:19:26 --> Module controller failed to run: admin/index/detailAngsuran/9e6a55b6b4563e652a23be9d623ca5055c356940/bunga
ERROR - 2016-09-15 19:19:26 --> Module controller failed to run: admin/index/detailAngsuran/
INFO - 2016-09-15 19:19:26 --> Database Driver Class Initialized
DEBUG - 2016-09-15 19:19:26 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:19:26 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:19:26 --> Module controller failed to run: admin/index/detailAngsuran/f6e1126cedebf23e1463aee73f9df08783640400/bunga
ERROR - 2016-09-15 19:19:26 --> Module controller failed to run: admin/index/detailAngsuran/
INFO - 2016-09-15 19:19:26 --> Database Driver Class Initialized
DEBUG - 2016-09-15 19:19:26 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:19:26 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:19:26 --> Module controller failed to run: admin/index/detailAngsuran/887309d048beef83ad3eabf2a79a64a389ab1c9f/bunga
ERROR - 2016-09-15 19:19:26 --> Module controller failed to run: admin/index/detailAngsuran/
INFO - 2016-09-15 19:19:26 --> Database Driver Class Initialized
DEBUG - 2016-09-15 19:19:26 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:19:26 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:19:26 --> Module controller failed to run: admin/index/detailAngsuran/0a57cb53ba59c46fc4b692527a38a87c78d84028/bunga
ERROR - 2016-09-15 19:19:26 --> Module controller failed to run: admin/index/detailAngsuran/
INFO - 2016-09-15 19:19:26 --> Database Driver Class Initialized
DEBUG - 2016-09-15 19:19:26 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:19:26 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:19:26 --> Module controller failed to run: admin/index/detailAngsuran/7719a1c782a1ba91c031a682a0a2f8658209adbf/bunga
DEBUG - 2016-09-15 19:19:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_angsuran.php
INFO - 2016-09-15 19:19:26 --> Final output sent to browser
DEBUG - 2016-09-15 19:19:27 --> Total execution time: 2.1473
INFO - 2016-09-15 19:20:02 --> Config Class Initialized
INFO - 2016-09-15 19:20:02 --> Hooks Class Initialized
DEBUG - 2016-09-15 19:20:02 --> UTF-8 Support Enabled
INFO - 2016-09-15 19:20:02 --> Utf8 Class Initialized
INFO - 2016-09-15 19:20:02 --> URI Class Initialized
INFO - 2016-09-15 19:20:02 --> Router Class Initialized
INFO - 2016-09-15 19:20:02 --> Output Class Initialized
INFO - 2016-09-15 19:20:02 --> Security Class Initialized
DEBUG - 2016-09-15 19:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 19:20:03 --> Input Class Initialized
INFO - 2016-09-15 19:20:03 --> Language Class Initialized
INFO - 2016-09-15 19:20:03 --> Language Class Initialized
INFO - 2016-09-15 19:20:03 --> Config Class Initialized
INFO - 2016-09-15 19:20:03 --> Loader Class Initialized
INFO - 2016-09-15 19:20:03 --> Helper loaded: url_helper
INFO - 2016-09-15 19:20:03 --> Database Driver Class Initialized
INFO - 2016-09-15 19:20:03 --> Controller Class Initialized
DEBUG - 2016-09-15 19:20:03 --> Index MX_Controller Initialized
INFO - 2016-09-15 19:20:03 --> Model Class Initialized
INFO - 2016-09-15 19:20:03 --> Model Class Initialized
INFO - 2016-09-15 19:20:03 --> Database Driver Class Initialized
INFO - 2016-09-15 19:20:03 --> Database Driver Class Initialized
DEBUG - 2016-09-15 19:20:03 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:20:03 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:20:03 --> Module controller failed to run: admin/index/detailAngsuran/1574bddb75c78a6fd2251d61e2993b5146201319/bunga
INFO - 2016-09-15 19:20:03 --> Database Driver Class Initialized
INFO - 2016-09-15 19:20:03 --> Database Driver Class Initialized
DEBUG - 2016-09-15 19:20:03 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:20:03 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:20:03 --> Module controller failed to run: admin/index/detailAngsuran/0716d9708d321ffb6a00818614779e779925365c/bunga
INFO - 2016-09-15 19:20:03 --> Database Driver Class Initialized
INFO - 2016-09-15 19:20:03 --> Database Driver Class Initialized
DEBUG - 2016-09-15 19:20:03 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:20:03 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:20:03 --> Module controller failed to run: admin/index/detailAngsuran/9e6a55b6b4563e652a23be9d623ca5055c356940/bunga
INFO - 2016-09-15 19:20:03 --> Database Driver Class Initialized
INFO - 2016-09-15 19:20:04 --> Database Driver Class Initialized
DEBUG - 2016-09-15 19:20:04 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:20:04 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:20:04 --> Module controller failed to run: admin/index/detailAngsuran/f6e1126cedebf23e1463aee73f9df08783640400/bunga
INFO - 2016-09-15 19:20:04 --> Database Driver Class Initialized
INFO - 2016-09-15 19:20:04 --> Database Driver Class Initialized
DEBUG - 2016-09-15 19:20:04 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:20:04 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:20:04 --> Module controller failed to run: admin/index/detailAngsuran/887309d048beef83ad3eabf2a79a64a389ab1c9f/bunga
INFO - 2016-09-15 19:20:04 --> Database Driver Class Initialized
INFO - 2016-09-15 19:20:04 --> Database Driver Class Initialized
DEBUG - 2016-09-15 19:20:04 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:20:04 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:20:04 --> Module controller failed to run: admin/index/detailAngsuran/0a57cb53ba59c46fc4b692527a38a87c78d84028/bunga
INFO - 2016-09-15 19:20:04 --> Database Driver Class Initialized
INFO - 2016-09-15 19:20:04 --> Database Driver Class Initialized
DEBUG - 2016-09-15 19:20:04 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/admin/controllers/Index.php
DEBUG - 2016-09-15 19:20:04 --> Index MX_Controller Initialized
ERROR - 2016-09-15 19:20:04 --> Module controller failed to run: admin/index/detailAngsuran/7719a1c782a1ba91c031a682a0a2f8658209adbf/bunga
DEBUG - 2016-09-15 19:20:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_angsuran.php
INFO - 2016-09-15 19:20:04 --> Final output sent to browser
DEBUG - 2016-09-15 19:20:04 --> Total execution time: 1.9896
INFO - 2016-09-15 19:20:22 --> Config Class Initialized
INFO - 2016-09-15 19:20:22 --> Hooks Class Initialized
DEBUG - 2016-09-15 19:20:22 --> UTF-8 Support Enabled
INFO - 2016-09-15 19:20:22 --> Utf8 Class Initialized
INFO - 2016-09-15 19:20:22 --> URI Class Initialized
INFO - 2016-09-15 19:20:22 --> Router Class Initialized
INFO - 2016-09-15 19:20:22 --> Output Class Initialized
INFO - 2016-09-15 19:20:22 --> Security Class Initialized
DEBUG - 2016-09-15 19:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 19:20:22 --> Input Class Initialized
INFO - 2016-09-15 19:20:22 --> Language Class Initialized
INFO - 2016-09-15 19:20:22 --> Language Class Initialized
INFO - 2016-09-15 19:20:22 --> Config Class Initialized
INFO - 2016-09-15 19:20:22 --> Loader Class Initialized
INFO - 2016-09-15 19:20:22 --> Helper loaded: url_helper
INFO - 2016-09-15 19:20:23 --> Database Driver Class Initialized
INFO - 2016-09-15 19:20:23 --> Controller Class Initialized
DEBUG - 2016-09-15 19:20:23 --> Index MX_Controller Initialized
INFO - 2016-09-15 19:20:23 --> Model Class Initialized
INFO - 2016-09-15 19:20:23 --> Model Class Initialized
INFO - 2016-09-15 19:20:23 --> Database Driver Class Initialized
INFO - 2016-09-15 19:20:23 --> Database Driver Class Initialized
ERROR - 2016-09-15 19:20:23 --> Module controller failed to run: admin/index/detailAngsuran1574bddb75c78a6fd2251d61e2993b5146201319bunga
INFO - 2016-09-15 19:20:23 --> Database Driver Class Initialized
INFO - 2016-09-15 19:20:23 --> Database Driver Class Initialized
ERROR - 2016-09-15 19:20:23 --> Module controller failed to run: admin/index/detailAngsuran0716d9708d321ffb6a00818614779e779925365cbunga
INFO - 2016-09-15 19:20:23 --> Database Driver Class Initialized
INFO - 2016-09-15 19:20:23 --> Database Driver Class Initialized
ERROR - 2016-09-15 19:20:23 --> Module controller failed to run: admin/index/detailAngsuran9e6a55b6b4563e652a23be9d623ca5055c356940bunga
INFO - 2016-09-15 19:20:23 --> Database Driver Class Initialized
INFO - 2016-09-15 19:20:23 --> Database Driver Class Initialized
ERROR - 2016-09-15 19:20:23 --> Module controller failed to run: admin/index/detailAngsuranf6e1126cedebf23e1463aee73f9df08783640400bunga
INFO - 2016-09-15 19:20:23 --> Database Driver Class Initialized
INFO - 2016-09-15 19:20:23 --> Database Driver Class Initialized
ERROR - 2016-09-15 19:20:23 --> Module controller failed to run: admin/index/detailAngsuran887309d048beef83ad3eabf2a79a64a389ab1c9fbunga
INFO - 2016-09-15 19:20:23 --> Database Driver Class Initialized
INFO - 2016-09-15 19:20:23 --> Database Driver Class Initialized
ERROR - 2016-09-15 19:20:23 --> Module controller failed to run: admin/index/detailAngsuran0a57cb53ba59c46fc4b692527a38a87c78d84028bunga
INFO - 2016-09-15 19:20:23 --> Database Driver Class Initialized
INFO - 2016-09-15 19:20:23 --> Database Driver Class Initialized
ERROR - 2016-09-15 19:20:23 --> Module controller failed to run: admin/index/detailAngsuran7719a1c782a1ba91c031a682a0a2f8658209adbfbunga
DEBUG - 2016-09-15 19:20:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_angsuran.php
INFO - 2016-09-15 19:20:24 --> Final output sent to browser
DEBUG - 2016-09-15 19:20:24 --> Total execution time: 1.6187
INFO - 2016-09-15 19:21:26 --> Config Class Initialized
INFO - 2016-09-15 19:21:26 --> Hooks Class Initialized
DEBUG - 2016-09-15 19:21:27 --> UTF-8 Support Enabled
INFO - 2016-09-15 19:21:27 --> Utf8 Class Initialized
INFO - 2016-09-15 19:21:27 --> URI Class Initialized
INFO - 2016-09-15 19:21:27 --> Router Class Initialized
INFO - 2016-09-15 19:21:27 --> Output Class Initialized
INFO - 2016-09-15 19:21:27 --> Security Class Initialized
DEBUG - 2016-09-15 19:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 19:21:27 --> Input Class Initialized
INFO - 2016-09-15 19:21:27 --> Language Class Initialized
INFO - 2016-09-15 19:21:27 --> Language Class Initialized
INFO - 2016-09-15 19:21:27 --> Config Class Initialized
INFO - 2016-09-15 19:21:27 --> Loader Class Initialized
INFO - 2016-09-15 19:21:27 --> Helper loaded: url_helper
INFO - 2016-09-15 19:21:27 --> Database Driver Class Initialized
INFO - 2016-09-15 19:21:27 --> Controller Class Initialized
DEBUG - 2016-09-15 19:21:27 --> Index MX_Controller Initialized
INFO - 2016-09-15 19:21:27 --> Model Class Initialized
INFO - 2016-09-15 19:21:27 --> Model Class Initialized
INFO - 2016-09-15 19:21:27 --> Database Driver Class Initialized
INFO - 2016-09-15 19:21:27 --> Database Driver Class Initialized
INFO - 2016-09-15 19:21:27 --> Database Driver Class Initialized
INFO - 2016-09-15 19:21:27 --> Database Driver Class Initialized
INFO - 2016-09-15 19:21:27 --> Database Driver Class Initialized
INFO - 2016-09-15 19:21:27 --> Database Driver Class Initialized
INFO - 2016-09-15 19:21:27 --> Database Driver Class Initialized
INFO - 2016-09-15 19:21:27 --> Database Driver Class Initialized
INFO - 2016-09-15 19:21:28 --> Database Driver Class Initialized
INFO - 2016-09-15 19:21:28 --> Database Driver Class Initialized
INFO - 2016-09-15 19:21:28 --> Database Driver Class Initialized
INFO - 2016-09-15 19:21:28 --> Database Driver Class Initialized
INFO - 2016-09-15 19:21:28 --> Database Driver Class Initialized
INFO - 2016-09-15 19:21:28 --> Database Driver Class Initialized
INFO - 2016-09-15 19:21:28 --> Database Driver Class Initialized
INFO - 2016-09-15 19:21:28 --> Database Driver Class Initialized
INFO - 2016-09-15 19:21:28 --> Database Driver Class Initialized
INFO - 2016-09-15 19:21:28 --> Database Driver Class Initialized
INFO - 2016-09-15 19:21:28 --> Database Driver Class Initialized
INFO - 2016-09-15 19:21:28 --> Database Driver Class Initialized
INFO - 2016-09-15 19:21:28 --> Database Driver Class Initialized
DEBUG - 2016-09-15 19:21:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_angsuran.php
INFO - 2016-09-15 19:21:28 --> Final output sent to browser
DEBUG - 2016-09-15 19:21:28 --> Total execution time: 1.6234
INFO - 2016-09-15 19:22:50 --> Config Class Initialized
INFO - 2016-09-15 19:22:50 --> Hooks Class Initialized
DEBUG - 2016-09-15 19:22:50 --> UTF-8 Support Enabled
INFO - 2016-09-15 19:22:50 --> Utf8 Class Initialized
INFO - 2016-09-15 19:22:50 --> URI Class Initialized
INFO - 2016-09-15 19:22:50 --> Router Class Initialized
INFO - 2016-09-15 19:22:50 --> Output Class Initialized
INFO - 2016-09-15 19:22:50 --> Security Class Initialized
DEBUG - 2016-09-15 19:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 19:22:51 --> Input Class Initialized
INFO - 2016-09-15 19:22:51 --> Language Class Initialized
INFO - 2016-09-15 19:22:51 --> Language Class Initialized
INFO - 2016-09-15 19:22:51 --> Config Class Initialized
INFO - 2016-09-15 19:22:51 --> Loader Class Initialized
INFO - 2016-09-15 19:22:51 --> Helper loaded: url_helper
INFO - 2016-09-15 19:22:51 --> Database Driver Class Initialized
INFO - 2016-09-15 19:22:51 --> Controller Class Initialized
DEBUG - 2016-09-15 19:22:51 --> Index MX_Controller Initialized
INFO - 2016-09-15 19:22:51 --> Model Class Initialized
INFO - 2016-09-15 19:22:51 --> Model Class Initialized
DEBUG - 2016-09-15 19:22:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-15 19:22:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-15 19:22:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-15 19:22:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/angsuran.php
DEBUG - 2016-09-15 19:22:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-15 19:22:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-15 19:22:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-15 19:22:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-15 19:22:51 --> Final output sent to browser
DEBUG - 2016-09-15 19:22:51 --> Total execution time: 1.0386
INFO - 2016-09-15 19:23:00 --> Config Class Initialized
INFO - 2016-09-15 19:23:00 --> Hooks Class Initialized
DEBUG - 2016-09-15 19:23:00 --> UTF-8 Support Enabled
INFO - 2016-09-15 19:23:00 --> Utf8 Class Initialized
INFO - 2016-09-15 19:23:00 --> URI Class Initialized
INFO - 2016-09-15 19:23:00 --> Router Class Initialized
INFO - 2016-09-15 19:23:00 --> Output Class Initialized
INFO - 2016-09-15 19:23:00 --> Security Class Initialized
DEBUG - 2016-09-15 19:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 19:23:00 --> Input Class Initialized
INFO - 2016-09-15 19:23:00 --> Language Class Initialized
INFO - 2016-09-15 19:23:00 --> Language Class Initialized
INFO - 2016-09-15 19:23:00 --> Config Class Initialized
INFO - 2016-09-15 19:23:00 --> Loader Class Initialized
INFO - 2016-09-15 19:23:00 --> Helper loaded: url_helper
INFO - 2016-09-15 19:23:00 --> Database Driver Class Initialized
INFO - 2016-09-15 19:23:00 --> Controller Class Initialized
DEBUG - 2016-09-15 19:23:00 --> Index MX_Controller Initialized
INFO - 2016-09-15 19:23:00 --> Model Class Initialized
INFO - 2016-09-15 19:23:00 --> Model Class Initialized
INFO - 2016-09-15 19:23:00 --> Database Driver Class Initialized
INFO - 2016-09-15 19:23:00 --> Database Driver Class Initialized
INFO - 2016-09-15 19:23:00 --> Database Driver Class Initialized
INFO - 2016-09-15 19:23:00 --> Database Driver Class Initialized
INFO - 2016-09-15 19:23:00 --> Database Driver Class Initialized
INFO - 2016-09-15 19:23:01 --> Database Driver Class Initialized
INFO - 2016-09-15 19:23:01 --> Database Driver Class Initialized
INFO - 2016-09-15 19:23:01 --> Database Driver Class Initialized
INFO - 2016-09-15 19:23:01 --> Database Driver Class Initialized
INFO - 2016-09-15 19:23:01 --> Database Driver Class Initialized
INFO - 2016-09-15 19:23:01 --> Database Driver Class Initialized
INFO - 2016-09-15 19:23:01 --> Database Driver Class Initialized
INFO - 2016-09-15 19:23:01 --> Database Driver Class Initialized
INFO - 2016-09-15 19:23:01 --> Database Driver Class Initialized
INFO - 2016-09-15 19:23:01 --> Database Driver Class Initialized
INFO - 2016-09-15 19:23:01 --> Database Driver Class Initialized
INFO - 2016-09-15 19:23:01 --> Database Driver Class Initialized
INFO - 2016-09-15 19:23:01 --> Database Driver Class Initialized
INFO - 2016-09-15 19:23:01 --> Database Driver Class Initialized
INFO - 2016-09-15 19:23:01 --> Database Driver Class Initialized
INFO - 2016-09-15 19:23:01 --> Database Driver Class Initialized
DEBUG - 2016-09-15 19:23:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/laporan/data_angsuran.php
INFO - 2016-09-15 19:23:01 --> Final output sent to browser
DEBUG - 2016-09-15 19:23:01 --> Total execution time: 1.5929
