<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-11-01 15:21:47 --> Config Class Initialized
INFO - 2016-11-01 15:21:47 --> Hooks Class Initialized
DEBUG - 2016-11-01 15:21:47 --> UTF-8 Support Enabled
INFO - 2016-11-01 15:21:47 --> Utf8 Class Initialized
INFO - 2016-11-01 15:21:47 --> URI Class Initialized
DEBUG - 2016-11-01 15:21:47 --> No URI present. Default controller set.
INFO - 2016-11-01 15:21:47 --> Router Class Initialized
INFO - 2016-11-01 15:21:48 --> Output Class Initialized
INFO - 2016-11-01 15:21:48 --> Security Class Initialized
DEBUG - 2016-11-01 15:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-01 15:21:48 --> Input Class Initialized
INFO - 2016-11-01 15:21:48 --> Language Class Initialized
INFO - 2016-11-01 15:21:48 --> Language Class Initialized
INFO - 2016-11-01 15:21:48 --> Config Class Initialized
INFO - 2016-11-01 15:21:48 --> Loader Class Initialized
INFO - 2016-11-01 15:21:49 --> Helper loaded: url_helper
INFO - 2016-11-01 15:21:49 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-01 15:21:49 --> Controller Class Initialized
DEBUG - 2016-11-01 15:21:49 --> Index MX_Controller Initialized
INFO - 2016-11-01 15:21:49 --> Model Class Initialized
INFO - 2016-11-01 15:21:49 --> Model Class Initialized
ERROR - 2016-11-01 15:21:49 --> Unable to delete cache file for 
DEBUG - 2016-11-01 15:21:49 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-11-01 15:21:50 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-11-01 15:21:50 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-11-01 15:21:50 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/dashboard.php
DEBUG - 2016-11-01 15:21:50 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-11-01 15:21:50 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-11-01 15:21:50 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:50 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:50 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:50 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:50 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:50 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:50 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:50 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:50 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:50 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:50 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:50 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:50 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:50 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:50 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:50 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:50 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:50 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:50 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:50 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:50 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:50 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:50 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:50 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:50 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:51 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:51 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:51 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:51 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:51 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:51 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:51 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:51 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:51 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:51 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:51 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:51 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:51 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:51 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:51 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:51 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:51 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:51 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:51 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:51 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:51 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:51 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:51 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:51 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:51 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:51 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:51 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:51 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:51 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:51 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:51 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:51 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:51 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:51 --> Database Driver Class Initialized
DEBUG - 2016-11-01 15:21:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-11-01 15:21:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-11-01 15:21:51 --> Final output sent to browser
DEBUG - 2016-11-01 15:21:51 --> Total execution time: 4.7160
INFO - 2016-11-01 15:21:51 --> Config Class Initialized
INFO - 2016-11-01 15:21:51 --> Hooks Class Initialized
DEBUG - 2016-11-01 15:21:51 --> UTF-8 Support Enabled
INFO - 2016-11-01 15:21:51 --> Utf8 Class Initialized
INFO - 2016-11-01 15:21:51 --> URI Class Initialized
INFO - 2016-11-01 15:21:51 --> Router Class Initialized
INFO - 2016-11-01 15:21:51 --> Output Class Initialized
INFO - 2016-11-01 15:21:52 --> Security Class Initialized
DEBUG - 2016-11-01 15:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-01 15:21:52 --> Input Class Initialized
INFO - 2016-11-01 15:21:52 --> Language Class Initialized
INFO - 2016-11-01 15:21:52 --> Language Class Initialized
INFO - 2016-11-01 15:21:52 --> Config Class Initialized
INFO - 2016-11-01 15:21:52 --> Loader Class Initialized
INFO - 2016-11-01 15:21:52 --> Helper loaded: url_helper
INFO - 2016-11-01 15:21:52 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-01 15:21:52 --> Controller Class Initialized
DEBUG - 2016-11-01 15:21:52 --> login MX_Controller Initialized
INFO - 2016-11-01 15:21:52 --> Model Class Initialized
INFO - 2016-11-01 15:21:52 --> Model Class Initialized
DEBUG - 2016-11-01 15:21:52 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/login.php
INFO - 2016-11-01 15:21:52 --> Final output sent to browser
DEBUG - 2016-11-01 15:21:52 --> Total execution time: 0.5127
INFO - 2016-11-01 15:21:57 --> Config Class Initialized
INFO - 2016-11-01 15:21:57 --> Hooks Class Initialized
DEBUG - 2016-11-01 15:21:57 --> UTF-8 Support Enabled
INFO - 2016-11-01 15:21:57 --> Utf8 Class Initialized
INFO - 2016-11-01 15:21:57 --> URI Class Initialized
INFO - 2016-11-01 15:21:57 --> Router Class Initialized
INFO - 2016-11-01 15:21:57 --> Output Class Initialized
INFO - 2016-11-01 15:21:57 --> Security Class Initialized
DEBUG - 2016-11-01 15:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-01 15:21:57 --> Input Class Initialized
INFO - 2016-11-01 15:21:57 --> Language Class Initialized
INFO - 2016-11-01 15:21:57 --> Language Class Initialized
INFO - 2016-11-01 15:21:57 --> Config Class Initialized
INFO - 2016-11-01 15:21:57 --> Loader Class Initialized
INFO - 2016-11-01 15:21:57 --> Helper loaded: url_helper
INFO - 2016-11-01 15:21:57 --> Database Driver Class Initialized
INFO - 2016-11-01 15:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-01 15:21:57 --> Controller Class Initialized
DEBUG - 2016-11-01 15:21:57 --> login MX_Controller Initialized
INFO - 2016-11-01 15:21:57 --> Model Class Initialized
INFO - 2016-11-01 15:21:57 --> Model Class Initialized
INFO - 2016-11-01 15:21:57 --> Final output sent to browser
DEBUG - 2016-11-01 15:21:57 --> Total execution time: 0.3949
INFO - 2016-11-01 15:22:01 --> Config Class Initialized
INFO - 2016-11-01 15:22:01 --> Hooks Class Initialized
DEBUG - 2016-11-01 15:22:01 --> UTF-8 Support Enabled
INFO - 2016-11-01 15:22:01 --> Utf8 Class Initialized
INFO - 2016-11-01 15:22:01 --> URI Class Initialized
INFO - 2016-11-01 15:22:01 --> Router Class Initialized
INFO - 2016-11-01 15:22:01 --> Output Class Initialized
INFO - 2016-11-01 15:22:01 --> Security Class Initialized
DEBUG - 2016-11-01 15:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-01 15:22:01 --> Input Class Initialized
INFO - 2016-11-01 15:22:01 --> Language Class Initialized
INFO - 2016-11-01 15:22:01 --> Language Class Initialized
INFO - 2016-11-01 15:22:01 --> Config Class Initialized
INFO - 2016-11-01 15:22:01 --> Loader Class Initialized
INFO - 2016-11-01 15:22:01 --> Helper loaded: url_helper
INFO - 2016-11-01 15:22:01 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-01 15:22:01 --> Controller Class Initialized
DEBUG - 2016-11-01 15:22:01 --> login MX_Controller Initialized
INFO - 2016-11-01 15:22:01 --> Model Class Initialized
INFO - 2016-11-01 15:22:01 --> Model Class Initialized
INFO - 2016-11-01 15:22:02 --> Final output sent to browser
DEBUG - 2016-11-01 15:22:02 --> Total execution time: 0.3796
INFO - 2016-11-01 15:22:02 --> Config Class Initialized
INFO - 2016-11-01 15:22:02 --> Hooks Class Initialized
DEBUG - 2016-11-01 15:22:02 --> UTF-8 Support Enabled
INFO - 2016-11-01 15:22:02 --> Utf8 Class Initialized
INFO - 2016-11-01 15:22:02 --> URI Class Initialized
INFO - 2016-11-01 15:22:02 --> Router Class Initialized
INFO - 2016-11-01 15:22:02 --> Output Class Initialized
INFO - 2016-11-01 15:22:02 --> Security Class Initialized
DEBUG - 2016-11-01 15:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-01 15:22:02 --> Input Class Initialized
INFO - 2016-11-01 15:22:02 --> Language Class Initialized
INFO - 2016-11-01 15:22:02 --> Language Class Initialized
INFO - 2016-11-01 15:22:02 --> Config Class Initialized
INFO - 2016-11-01 15:22:02 --> Loader Class Initialized
INFO - 2016-11-01 15:22:02 --> Helper loaded: url_helper
INFO - 2016-11-01 15:22:02 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-01 15:22:02 --> Controller Class Initialized
DEBUG - 2016-11-01 15:22:02 --> Index MX_Controller Initialized
INFO - 2016-11-01 15:22:02 --> Model Class Initialized
INFO - 2016-11-01 15:22:02 --> Model Class Initialized
ERROR - 2016-11-01 15:22:02 --> Unable to delete cache file for admin/index
DEBUG - 2016-11-01 15:22:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-11-01 15:22:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-11-01 15:22:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-11-01 15:22:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/dashboard.php
DEBUG - 2016-11-01 15:22:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-11-01 15:22:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-11-01 15:22:02 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:02 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:02 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:02 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:02 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:03 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:03 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:03 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:03 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:03 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:03 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:03 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:03 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:03 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:03 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:03 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:03 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:03 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:03 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:03 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:03 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:03 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:03 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:03 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:03 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:03 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:03 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:03 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:03 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:03 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:03 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:03 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:03 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:03 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:03 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:03 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:03 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:03 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:03 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:03 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:03 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:03 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:03 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:03 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:03 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:03 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:03 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:03 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:03 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:03 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:03 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:04 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:04 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:04 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:04 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:04 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:04 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:04 --> Database Driver Class Initialized
INFO - 2016-11-01 15:22:04 --> Database Driver Class Initialized
DEBUG - 2016-11-01 15:22:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-11-01 15:22:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-11-01 15:22:04 --> Final output sent to browser
DEBUG - 2016-11-01 15:22:04 --> Total execution time: 2.1179
