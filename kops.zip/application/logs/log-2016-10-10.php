<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-10-10 09:27:23 --> Config Class Initialized
INFO - 2016-10-10 09:27:23 --> Hooks Class Initialized
DEBUG - 2016-10-10 09:27:23 --> UTF-8 Support Enabled
INFO - 2016-10-10 09:27:23 --> Utf8 Class Initialized
INFO - 2016-10-10 09:27:23 --> URI Class Initialized
DEBUG - 2016-10-10 09:27:24 --> No URI present. Default controller set.
INFO - 2016-10-10 09:27:24 --> Router Class Initialized
INFO - 2016-10-10 09:27:24 --> Output Class Initialized
INFO - 2016-10-10 09:27:24 --> Security Class Initialized
DEBUG - 2016-10-10 09:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 09:27:24 --> Input Class Initialized
INFO - 2016-10-10 09:27:24 --> Language Class Initialized
INFO - 2016-10-10 09:27:25 --> Language Class Initialized
INFO - 2016-10-10 09:27:25 --> Config Class Initialized
INFO - 2016-10-10 09:27:25 --> Loader Class Initialized
INFO - 2016-10-10 09:27:25 --> Helper loaded: url_helper
INFO - 2016-10-10 09:27:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 09:27:26 --> Controller Class Initialized
DEBUG - 2016-10-10 09:27:26 --> Index MX_Controller Initialized
INFO - 2016-10-10 09:27:26 --> Model Class Initialized
INFO - 2016-10-10 09:27:26 --> Model Class Initialized
ERROR - 2016-10-10 09:27:26 --> Unable to delete cache file for 
DEBUG - 2016-10-10 09:27:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 09:27:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 09:27:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 09:27:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/dashboard.php
DEBUG - 2016-10-10 09:27:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 09:27:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 09:27:27 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:27 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:27 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:27 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:27 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:27 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:27 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:27 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:27 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:27 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:27 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:27 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:27 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:27 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:27 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:27 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:27 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:27 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:27 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:27 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:27 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:27 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:27 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:27 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:27 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:27 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:27 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:27 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:27 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:27 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:28 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:28 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:28 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:28 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:28 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:28 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:28 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:28 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:28 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:28 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:28 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:28 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:28 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:28 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:28 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:28 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:28 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:28 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:28 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:28 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:28 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:28 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:28 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:28 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:28 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:28 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:28 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:28 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:29 --> Database Driver Class Initialized
DEBUG - 2016-10-10 09:27:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 09:27:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 09:27:29 --> Final output sent to browser
DEBUG - 2016-10-10 09:27:29 --> Total execution time: 6.0024
INFO - 2016-10-10 09:27:29 --> Config Class Initialized
INFO - 2016-10-10 09:27:29 --> Hooks Class Initialized
DEBUG - 2016-10-10 09:27:29 --> UTF-8 Support Enabled
INFO - 2016-10-10 09:27:29 --> Utf8 Class Initialized
INFO - 2016-10-10 09:27:29 --> URI Class Initialized
INFO - 2016-10-10 09:27:29 --> Router Class Initialized
INFO - 2016-10-10 09:27:29 --> Output Class Initialized
INFO - 2016-10-10 09:27:29 --> Security Class Initialized
DEBUG - 2016-10-10 09:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 09:27:29 --> Input Class Initialized
INFO - 2016-10-10 09:27:29 --> Language Class Initialized
INFO - 2016-10-10 09:27:29 --> Language Class Initialized
INFO - 2016-10-10 09:27:29 --> Config Class Initialized
INFO - 2016-10-10 09:27:29 --> Loader Class Initialized
INFO - 2016-10-10 09:27:29 --> Helper loaded: url_helper
INFO - 2016-10-10 09:27:29 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 09:27:29 --> Controller Class Initialized
DEBUG - 2016-10-10 09:27:29 --> login MX_Controller Initialized
INFO - 2016-10-10 09:27:29 --> Model Class Initialized
INFO - 2016-10-10 09:27:29 --> Model Class Initialized
DEBUG - 2016-10-10 09:27:30 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/login.php
INFO - 2016-10-10 09:27:30 --> Final output sent to browser
DEBUG - 2016-10-10 09:27:30 --> Total execution time: 0.8133
INFO - 2016-10-10 09:27:35 --> Config Class Initialized
INFO - 2016-10-10 09:27:35 --> Hooks Class Initialized
DEBUG - 2016-10-10 09:27:35 --> UTF-8 Support Enabled
INFO - 2016-10-10 09:27:35 --> Utf8 Class Initialized
INFO - 2016-10-10 09:27:35 --> URI Class Initialized
INFO - 2016-10-10 09:27:35 --> Router Class Initialized
INFO - 2016-10-10 09:27:35 --> Output Class Initialized
INFO - 2016-10-10 09:27:35 --> Security Class Initialized
DEBUG - 2016-10-10 09:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 09:27:35 --> Input Class Initialized
INFO - 2016-10-10 09:27:35 --> Language Class Initialized
INFO - 2016-10-10 09:27:35 --> Language Class Initialized
INFO - 2016-10-10 09:27:35 --> Config Class Initialized
INFO - 2016-10-10 09:27:35 --> Loader Class Initialized
INFO - 2016-10-10 09:27:35 --> Helper loaded: url_helper
INFO - 2016-10-10 09:27:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 09:27:35 --> Controller Class Initialized
DEBUG - 2016-10-10 09:27:35 --> login MX_Controller Initialized
INFO - 2016-10-10 09:27:35 --> Model Class Initialized
INFO - 2016-10-10 09:27:35 --> Model Class Initialized
INFO - 2016-10-10 09:27:35 --> Final output sent to browser
DEBUG - 2016-10-10 09:27:35 --> Total execution time: 0.5376
INFO - 2016-10-10 09:27:36 --> Config Class Initialized
INFO - 2016-10-10 09:27:36 --> Hooks Class Initialized
DEBUG - 2016-10-10 09:27:36 --> UTF-8 Support Enabled
INFO - 2016-10-10 09:27:36 --> Utf8 Class Initialized
INFO - 2016-10-10 09:27:36 --> URI Class Initialized
INFO - 2016-10-10 09:27:36 --> Router Class Initialized
INFO - 2016-10-10 09:27:36 --> Output Class Initialized
INFO - 2016-10-10 09:27:36 --> Security Class Initialized
DEBUG - 2016-10-10 09:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 09:27:36 --> Input Class Initialized
INFO - 2016-10-10 09:27:36 --> Language Class Initialized
INFO - 2016-10-10 09:27:36 --> Language Class Initialized
INFO - 2016-10-10 09:27:36 --> Config Class Initialized
INFO - 2016-10-10 09:27:36 --> Loader Class Initialized
INFO - 2016-10-10 09:27:36 --> Helper loaded: url_helper
INFO - 2016-10-10 09:27:36 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 09:27:36 --> Controller Class Initialized
DEBUG - 2016-10-10 09:27:36 --> Index MX_Controller Initialized
INFO - 2016-10-10 09:27:36 --> Model Class Initialized
INFO - 2016-10-10 09:27:36 --> Model Class Initialized
ERROR - 2016-10-10 09:27:36 --> Unable to delete cache file for admin/index
DEBUG - 2016-10-10 09:27:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 09:27:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 09:27:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 09:27:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/dashboard.php
DEBUG - 2016-10-10 09:27:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 09:27:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 09:27:36 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:36 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:37 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:37 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:37 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:37 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:37 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:37 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:37 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:37 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:37 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:37 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:37 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:37 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:37 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:37 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:37 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:37 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:37 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:37 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:37 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:37 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:37 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:37 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:37 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:37 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:37 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:37 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:37 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:37 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:37 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:37 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:37 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:37 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:38 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:38 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:38 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:38 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:38 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:38 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:38 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:38 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:38 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:38 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:38 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:38 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:38 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:38 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:38 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:38 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:38 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:38 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:38 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:38 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:38 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:38 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:38 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:38 --> Database Driver Class Initialized
INFO - 2016-10-10 09:27:38 --> Database Driver Class Initialized
DEBUG - 2016-10-10 09:27:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 09:27:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 09:27:39 --> Final output sent to browser
DEBUG - 2016-10-10 09:27:39 --> Total execution time: 2.8667
INFO - 2016-10-10 09:28:33 --> Config Class Initialized
INFO - 2016-10-10 09:28:33 --> Hooks Class Initialized
DEBUG - 2016-10-10 09:28:33 --> UTF-8 Support Enabled
INFO - 2016-10-10 09:28:33 --> Utf8 Class Initialized
INFO - 2016-10-10 09:28:33 --> URI Class Initialized
INFO - 2016-10-10 09:28:33 --> Router Class Initialized
INFO - 2016-10-10 09:28:33 --> Output Class Initialized
INFO - 2016-10-10 09:28:33 --> Security Class Initialized
DEBUG - 2016-10-10 09:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 09:28:33 --> Input Class Initialized
INFO - 2016-10-10 09:28:33 --> Language Class Initialized
INFO - 2016-10-10 09:28:33 --> Language Class Initialized
INFO - 2016-10-10 09:28:33 --> Config Class Initialized
INFO - 2016-10-10 09:28:33 --> Loader Class Initialized
INFO - 2016-10-10 09:28:33 --> Helper loaded: url_helper
INFO - 2016-10-10 09:28:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 09:28:34 --> Controller Class Initialized
DEBUG - 2016-10-10 09:28:34 --> Index MX_Controller Initialized
INFO - 2016-10-10 09:28:34 --> Model Class Initialized
INFO - 2016-10-10 09:28:34 --> Model Class Initialized
ERROR - 2016-10-10 09:28:34 --> Unable to delete cache file for admin/index/data_peminjam
DEBUG - 2016-10-10 09:28:34 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 09:28:34 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 09:28:34 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 09:28:34 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_peminjam.php
DEBUG - 2016-10-10 09:28:34 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 09:28:34 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 09:28:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:36 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:36 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:36 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:36 --> Database Driver Class Initialized
DEBUG - 2016-10-10 09:28:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 09:28:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 09:28:36 --> Final output sent to browser
DEBUG - 2016-10-10 09:28:36 --> Total execution time: 2.5170
INFO - 2016-10-10 09:28:41 --> Config Class Initialized
INFO - 2016-10-10 09:28:41 --> Hooks Class Initialized
DEBUG - 2016-10-10 09:28:41 --> UTF-8 Support Enabled
INFO - 2016-10-10 09:28:41 --> Utf8 Class Initialized
INFO - 2016-10-10 09:28:41 --> URI Class Initialized
INFO - 2016-10-10 09:28:41 --> Router Class Initialized
INFO - 2016-10-10 09:28:41 --> Output Class Initialized
INFO - 2016-10-10 09:28:41 --> Security Class Initialized
DEBUG - 2016-10-10 09:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 09:28:41 --> Input Class Initialized
INFO - 2016-10-10 09:28:41 --> Language Class Initialized
INFO - 2016-10-10 09:28:41 --> Language Class Initialized
INFO - 2016-10-10 09:28:41 --> Config Class Initialized
INFO - 2016-10-10 09:28:42 --> Loader Class Initialized
INFO - 2016-10-10 09:28:42 --> Helper loaded: url_helper
INFO - 2016-10-10 09:28:42 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 09:28:42 --> Controller Class Initialized
DEBUG - 2016-10-10 09:28:42 --> Index MX_Controller Initialized
INFO - 2016-10-10 09:28:42 --> Model Class Initialized
INFO - 2016-10-10 09:28:42 --> Model Class Initialized
ERROR - 2016-10-10 09:28:42 --> Unable to delete cache file for admin/index/getDataPeminjam
DEBUG - 2016-10-10 09:28:42 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-10-10 09:28:42 --> Final output sent to browser
DEBUG - 2016-10-10 09:28:42 --> Total execution time: 0.7686
INFO - 2016-10-10 09:28:49 --> Config Class Initialized
INFO - 2016-10-10 09:28:49 --> Hooks Class Initialized
DEBUG - 2016-10-10 09:28:49 --> UTF-8 Support Enabled
INFO - 2016-10-10 09:28:49 --> Utf8 Class Initialized
INFO - 2016-10-10 09:28:49 --> URI Class Initialized
INFO - 2016-10-10 09:28:49 --> Router Class Initialized
INFO - 2016-10-10 09:28:49 --> Output Class Initialized
INFO - 2016-10-10 09:28:49 --> Security Class Initialized
DEBUG - 2016-10-10 09:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 09:28:49 --> Input Class Initialized
INFO - 2016-10-10 09:28:49 --> Language Class Initialized
INFO - 2016-10-10 09:28:49 --> Language Class Initialized
INFO - 2016-10-10 09:28:49 --> Config Class Initialized
INFO - 2016-10-10 09:28:49 --> Loader Class Initialized
INFO - 2016-10-10 09:28:49 --> Helper loaded: url_helper
INFO - 2016-10-10 09:28:49 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 09:28:50 --> Controller Class Initialized
DEBUG - 2016-10-10 09:28:50 --> Index MX_Controller Initialized
INFO - 2016-10-10 09:28:50 --> Model Class Initialized
INFO - 2016-10-10 09:28:50 --> Model Class Initialized
ERROR - 2016-10-10 09:28:50 --> Unable to delete cache file for admin/index/detail_pinjaman/f1f836cb4ea6efb2a0b1b99f41ad8b103eff4b59
DEBUG - 2016-10-10 09:28:50 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/subcontent/data_transaksi.php
INFO - 2016-10-10 09:28:50 --> Final output sent to browser
DEBUG - 2016-10-10 09:28:50 --> Total execution time: 0.7995
INFO - 2016-10-10 09:28:55 --> Config Class Initialized
INFO - 2016-10-10 09:28:55 --> Hooks Class Initialized
DEBUG - 2016-10-10 09:28:55 --> UTF-8 Support Enabled
INFO - 2016-10-10 09:28:55 --> Utf8 Class Initialized
INFO - 2016-10-10 09:28:55 --> URI Class Initialized
INFO - 2016-10-10 09:28:55 --> Router Class Initialized
INFO - 2016-10-10 09:28:55 --> Output Class Initialized
INFO - 2016-10-10 09:28:55 --> Security Class Initialized
DEBUG - 2016-10-10 09:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 09:28:55 --> Input Class Initialized
INFO - 2016-10-10 09:28:55 --> Language Class Initialized
INFO - 2016-10-10 09:28:55 --> Language Class Initialized
INFO - 2016-10-10 09:28:55 --> Config Class Initialized
INFO - 2016-10-10 09:28:55 --> Loader Class Initialized
INFO - 2016-10-10 09:28:55 --> Helper loaded: url_helper
INFO - 2016-10-10 09:28:55 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 09:28:55 --> Controller Class Initialized
DEBUG - 2016-10-10 09:28:55 --> Index MX_Controller Initialized
INFO - 2016-10-10 09:28:55 --> Model Class Initialized
INFO - 2016-10-10 09:28:55 --> Model Class Initialized
ERROR - 2016-10-10 09:28:55 --> Unable to delete cache file for admin/index/data/anggota
DEBUG - 2016-10-10 09:28:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 09:28:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 09:28:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 09:28:56 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-10 09:28:56 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-10 09:28:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-10 09:28:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 09:28:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 09:28:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:58 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:58 --> Database Driver Class Initialized
INFO - 2016-10-10 09:28:58 --> Database Driver Class Initialized
DEBUG - 2016-10-10 09:28:58 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 09:28:58 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 09:28:58 --> Final output sent to browser
DEBUG - 2016-10-10 09:28:58 --> Total execution time: 2.9303
INFO - 2016-10-10 09:29:09 --> Config Class Initialized
INFO - 2016-10-10 09:29:09 --> Hooks Class Initialized
DEBUG - 2016-10-10 09:29:09 --> UTF-8 Support Enabled
INFO - 2016-10-10 09:29:09 --> Utf8 Class Initialized
INFO - 2016-10-10 09:29:09 --> URI Class Initialized
INFO - 2016-10-10 09:29:09 --> Router Class Initialized
INFO - 2016-10-10 09:29:09 --> Output Class Initialized
INFO - 2016-10-10 09:29:09 --> Security Class Initialized
DEBUG - 2016-10-10 09:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 09:29:09 --> Input Class Initialized
INFO - 2016-10-10 09:29:09 --> Language Class Initialized
INFO - 2016-10-10 09:29:09 --> Language Class Initialized
INFO - 2016-10-10 09:29:09 --> Config Class Initialized
INFO - 2016-10-10 09:29:09 --> Loader Class Initialized
INFO - 2016-10-10 09:29:09 --> Helper loaded: url_helper
INFO - 2016-10-10 09:29:09 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 09:29:09 --> Controller Class Initialized
DEBUG - 2016-10-10 09:29:09 --> Index MX_Controller Initialized
INFO - 2016-10-10 09:29:09 --> Model Class Initialized
INFO - 2016-10-10 09:29:09 --> Model Class Initialized
ERROR - 2016-10-10 09:29:09 --> Unable to delete cache file for admin/index/detail_anggota/356a192b7913b04c54574d18c28d46e6395428ab
DEBUG - 2016-10-10 09:29:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 09:29:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 09:29:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
INFO - 2016-10-10 09:29:09 --> Database Driver Class Initialized
DEBUG - 2016-10-10 09:29:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_pinjaman.php
INFO - 2016-10-10 09:29:09 --> Database Driver Class Initialized
DEBUG - 2016-10-10 09:29:10 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_tabungan.php
DEBUG - 2016-10-10 09:29:10 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/profile_anggota.php
DEBUG - 2016-10-10 09:29:10 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 09:29:10 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 09:29:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:11 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:11 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:11 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:11 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:11 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:11 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:11 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:11 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:11 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:11 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:11 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:11 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:11 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:11 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:11 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:11 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:11 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:11 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:11 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:11 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:11 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:11 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:11 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:11 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:11 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:11 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:11 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:11 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:11 --> Database Driver Class Initialized
DEBUG - 2016-10-10 09:29:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 09:29:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 09:29:11 --> Final output sent to browser
DEBUG - 2016-10-10 09:29:11 --> Total execution time: 2.7626
INFO - 2016-10-10 09:29:12 --> Config Class Initialized
INFO - 2016-10-10 09:29:12 --> Hooks Class Initialized
DEBUG - 2016-10-10 09:29:12 --> UTF-8 Support Enabled
INFO - 2016-10-10 09:29:12 --> Utf8 Class Initialized
INFO - 2016-10-10 09:29:12 --> URI Class Initialized
INFO - 2016-10-10 09:29:12 --> Router Class Initialized
INFO - 2016-10-10 09:29:12 --> Output Class Initialized
INFO - 2016-10-10 09:29:12 --> Security Class Initialized
DEBUG - 2016-10-10 09:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 09:29:12 --> Input Class Initialized
INFO - 2016-10-10 09:29:12 --> Language Class Initialized
INFO - 2016-10-10 09:29:12 --> Language Class Initialized
INFO - 2016-10-10 09:29:12 --> Config Class Initialized
INFO - 2016-10-10 09:29:12 --> Loader Class Initialized
INFO - 2016-10-10 09:29:12 --> Helper loaded: url_helper
INFO - 2016-10-10 09:29:12 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 09:29:12 --> Controller Class Initialized
DEBUG - 2016-10-10 09:29:12 --> Index MX_Controller Initialized
INFO - 2016-10-10 09:29:12 --> Model Class Initialized
INFO - 2016-10-10 09:29:12 --> Model Class Initialized
ERROR - 2016-10-10 09:29:12 --> Unable to delete cache file for admin/index/detail_anggota/images/picture.jpg
DEBUG - 2016-10-10 09:29:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 09:29:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 09:29:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
ERROR - 2016-10-10 09:29:13 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 16
ERROR - 2016-10-10 09:29:13 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 19
ERROR - 2016-10-10 09:29:13 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 22
ERROR - 2016-10-10 09:29:13 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 38
INFO - 2016-10-10 09:29:13 --> Database Driver Class Initialized
DEBUG - 2016-10-10 09:29:13 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_pinjaman.php
ERROR - 2016-10-10 09:29:13 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 41
INFO - 2016-10-10 09:29:13 --> Database Driver Class Initialized
DEBUG - 2016-10-10 09:29:13 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_tabungan.php
DEBUG - 2016-10-10 09:29:13 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/profile_anggota.php
DEBUG - 2016-10-10 09:29:13 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 09:29:13 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 09:29:13 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:14 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:14 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:14 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:14 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:14 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:14 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:14 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:14 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:14 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:14 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:14 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:15 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:15 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:15 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:15 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:15 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:15 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:15 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:15 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:15 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:15 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:15 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:15 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:15 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:15 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:17 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:17 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:17 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:17 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:17 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:17 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:17 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:17 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:17 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:17 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:17 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:18 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:18 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:18 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:18 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:18 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:18 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:18 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:18 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:18 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:18 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:18 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:18 --> Database Driver Class Initialized
DEBUG - 2016-10-10 09:29:18 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 09:29:18 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 09:29:18 --> Final output sent to browser
DEBUG - 2016-10-10 09:29:18 --> Total execution time: 6.6513
INFO - 2016-10-10 09:29:26 --> Config Class Initialized
INFO - 2016-10-10 09:29:26 --> Hooks Class Initialized
DEBUG - 2016-10-10 09:29:26 --> UTF-8 Support Enabled
INFO - 2016-10-10 09:29:26 --> Utf8 Class Initialized
INFO - 2016-10-10 09:29:26 --> URI Class Initialized
INFO - 2016-10-10 09:29:26 --> Router Class Initialized
INFO - 2016-10-10 09:29:26 --> Output Class Initialized
INFO - 2016-10-10 09:29:26 --> Security Class Initialized
DEBUG - 2016-10-10 09:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 09:29:26 --> Input Class Initialized
INFO - 2016-10-10 09:29:26 --> Language Class Initialized
INFO - 2016-10-10 09:29:26 --> Language Class Initialized
INFO - 2016-10-10 09:29:26 --> Config Class Initialized
INFO - 2016-10-10 09:29:26 --> Loader Class Initialized
INFO - 2016-10-10 09:29:26 --> Helper loaded: url_helper
INFO - 2016-10-10 09:29:26 --> Database Driver Class Initialized
INFO - 2016-10-10 09:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 09:29:26 --> Controller Class Initialized
DEBUG - 2016-10-10 09:29:26 --> Index MX_Controller Initialized
INFO - 2016-10-10 09:29:26 --> Model Class Initialized
INFO - 2016-10-10 09:29:26 --> Model Class Initialized
ERROR - 2016-10-10 09:29:26 --> Unable to delete cache file for admin/index/getRaportAngsuran/356a192b7913b04c54574d18c28d46e6395428ab
DEBUG - 2016-10-10 09:29:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/raport_angsuran.php
INFO - 2016-10-10 09:29:27 --> Final output sent to browser
DEBUG - 2016-10-10 09:29:27 --> Total execution time: 0.7108
INFO - 2016-10-10 09:36:45 --> Config Class Initialized
INFO - 2016-10-10 09:36:45 --> Hooks Class Initialized
DEBUG - 2016-10-10 09:36:45 --> UTF-8 Support Enabled
INFO - 2016-10-10 09:36:45 --> Utf8 Class Initialized
INFO - 2016-10-10 09:36:45 --> URI Class Initialized
INFO - 2016-10-10 09:36:45 --> Router Class Initialized
INFO - 2016-10-10 09:36:45 --> Output Class Initialized
INFO - 2016-10-10 09:36:45 --> Security Class Initialized
DEBUG - 2016-10-10 09:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 09:36:45 --> Input Class Initialized
INFO - 2016-10-10 09:36:45 --> Language Class Initialized
INFO - 2016-10-10 09:36:45 --> Language Class Initialized
INFO - 2016-10-10 09:36:45 --> Config Class Initialized
INFO - 2016-10-10 09:36:45 --> Loader Class Initialized
INFO - 2016-10-10 09:36:45 --> Helper loaded: url_helper
INFO - 2016-10-10 09:36:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 09:36:46 --> Controller Class Initialized
DEBUG - 2016-10-10 09:36:46 --> Index MX_Controller Initialized
INFO - 2016-10-10 09:36:46 --> Model Class Initialized
INFO - 2016-10-10 09:36:46 --> Model Class Initialized
ERROR - 2016-10-10 09:36:46 --> Unable to delete cache file for admin/index/getRaportAngsuran/356a192b7913b04c54574d18c28d46e6395428ab
DEBUG - 2016-10-10 09:36:46 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/raport_angsuran.php
INFO - 2016-10-10 09:36:46 --> Final output sent to browser
DEBUG - 2016-10-10 09:36:46 --> Total execution time: 0.8068
INFO - 2016-10-10 09:37:03 --> Config Class Initialized
INFO - 2016-10-10 09:37:03 --> Hooks Class Initialized
DEBUG - 2016-10-10 09:37:03 --> UTF-8 Support Enabled
INFO - 2016-10-10 09:37:03 --> Utf8 Class Initialized
INFO - 2016-10-10 09:37:03 --> URI Class Initialized
INFO - 2016-10-10 09:37:03 --> Router Class Initialized
INFO - 2016-10-10 09:37:03 --> Output Class Initialized
INFO - 2016-10-10 09:37:03 --> Security Class Initialized
DEBUG - 2016-10-10 09:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 09:37:03 --> Input Class Initialized
INFO - 2016-10-10 09:37:03 --> Language Class Initialized
INFO - 2016-10-10 09:37:03 --> Language Class Initialized
INFO - 2016-10-10 09:37:03 --> Config Class Initialized
INFO - 2016-10-10 09:37:03 --> Loader Class Initialized
INFO - 2016-10-10 09:37:03 --> Helper loaded: url_helper
INFO - 2016-10-10 09:37:03 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 09:37:03 --> Controller Class Initialized
DEBUG - 2016-10-10 09:37:03 --> Index MX_Controller Initialized
INFO - 2016-10-10 09:37:03 --> Model Class Initialized
INFO - 2016-10-10 09:37:03 --> Model Class Initialized
ERROR - 2016-10-10 09:37:03 --> Unable to delete cache file for admin/index/tutup_angsuran
DEBUG - 2016-10-10 09:37:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 09:37:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 09:37:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 09:37:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_tutup_angsuran.php
DEBUG - 2016-10-10 09:37:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 09:37:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 09:37:03 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:03 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:03 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:04 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:04 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:04 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:04 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:04 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:04 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:04 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:04 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:04 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:04 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:04 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:04 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:04 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:04 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:04 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:04 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:04 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:04 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:04 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:04 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:04 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:04 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:04 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:04 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:04 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:04 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:04 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:04 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:04 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:04 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:04 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:04 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:04 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:05 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:05 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:05 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:05 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:05 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:05 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:05 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:05 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:05 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:05 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:05 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:05 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:05 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:05 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:05 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:05 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:05 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:05 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:05 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:05 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:05 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:05 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:05 --> Database Driver Class Initialized
DEBUG - 2016-10-10 09:37:05 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 09:37:05 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 09:37:05 --> Final output sent to browser
DEBUG - 2016-10-10 09:37:05 --> Total execution time: 2.4711
INFO - 2016-10-10 09:37:10 --> Config Class Initialized
INFO - 2016-10-10 09:37:10 --> Hooks Class Initialized
DEBUG - 2016-10-10 09:37:10 --> UTF-8 Support Enabled
INFO - 2016-10-10 09:37:10 --> Utf8 Class Initialized
INFO - 2016-10-10 09:37:10 --> URI Class Initialized
INFO - 2016-10-10 09:37:10 --> Router Class Initialized
INFO - 2016-10-10 09:37:10 --> Output Class Initialized
INFO - 2016-10-10 09:37:10 --> Security Class Initialized
DEBUG - 2016-10-10 09:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 09:37:10 --> Input Class Initialized
INFO - 2016-10-10 09:37:10 --> Language Class Initialized
INFO - 2016-10-10 09:37:10 --> Language Class Initialized
INFO - 2016-10-10 09:37:10 --> Config Class Initialized
INFO - 2016-10-10 09:37:10 --> Loader Class Initialized
INFO - 2016-10-10 09:37:10 --> Helper loaded: url_helper
INFO - 2016-10-10 09:37:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 09:37:10 --> Controller Class Initialized
DEBUG - 2016-10-10 09:37:10 --> Index MX_Controller Initialized
INFO - 2016-10-10 09:37:10 --> Model Class Initialized
INFO - 2016-10-10 09:37:10 --> Model Class Initialized
ERROR - 2016-10-10 09:37:10 --> Unable to delete cache file for admin/index/getDetailLunas
INFO - 2016-10-10 09:37:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:10 --> Final output sent to browser
DEBUG - 2016-10-10 09:37:10 --> Total execution time: 0.7005
INFO - 2016-10-10 09:37:17 --> Config Class Initialized
INFO - 2016-10-10 09:37:17 --> Hooks Class Initialized
DEBUG - 2016-10-10 09:37:17 --> UTF-8 Support Enabled
INFO - 2016-10-10 09:37:17 --> Utf8 Class Initialized
INFO - 2016-10-10 09:37:17 --> URI Class Initialized
INFO - 2016-10-10 09:37:17 --> Router Class Initialized
INFO - 2016-10-10 09:37:17 --> Output Class Initialized
INFO - 2016-10-10 09:37:17 --> Security Class Initialized
DEBUG - 2016-10-10 09:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 09:37:17 --> Input Class Initialized
INFO - 2016-10-10 09:37:18 --> Language Class Initialized
INFO - 2016-10-10 09:37:18 --> Language Class Initialized
INFO - 2016-10-10 09:37:18 --> Config Class Initialized
INFO - 2016-10-10 09:37:18 --> Loader Class Initialized
INFO - 2016-10-10 09:37:18 --> Helper loaded: url_helper
INFO - 2016-10-10 09:37:18 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 09:37:18 --> Controller Class Initialized
DEBUG - 2016-10-10 09:37:18 --> Index MX_Controller Initialized
INFO - 2016-10-10 09:37:18 --> Model Class Initialized
INFO - 2016-10-10 09:37:18 --> Model Class Initialized
ERROR - 2016-10-10 09:37:18 --> Unable to delete cache file for admin/index/do_lunas
INFO - 2016-10-10 09:37:18 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:18 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:18 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:18 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:18 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:18 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:18 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:18 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:18 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:18 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:19 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:19 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:19 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:19 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:19 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:19 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:19 --> Final output sent to browser
DEBUG - 2016-10-10 09:37:19 --> Total execution time: 1.9416
INFO - 2016-10-10 09:37:22 --> Config Class Initialized
INFO - 2016-10-10 09:37:22 --> Hooks Class Initialized
DEBUG - 2016-10-10 09:37:22 --> UTF-8 Support Enabled
INFO - 2016-10-10 09:37:22 --> Utf8 Class Initialized
INFO - 2016-10-10 09:37:22 --> URI Class Initialized
INFO - 2016-10-10 09:37:23 --> Router Class Initialized
INFO - 2016-10-10 09:37:23 --> Output Class Initialized
INFO - 2016-10-10 09:37:23 --> Security Class Initialized
DEBUG - 2016-10-10 09:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 09:37:23 --> Input Class Initialized
INFO - 2016-10-10 09:37:23 --> Language Class Initialized
INFO - 2016-10-10 09:37:23 --> Language Class Initialized
INFO - 2016-10-10 09:37:23 --> Config Class Initialized
INFO - 2016-10-10 09:37:23 --> Loader Class Initialized
INFO - 2016-10-10 09:37:23 --> Helper loaded: url_helper
INFO - 2016-10-10 09:37:23 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 09:37:23 --> Controller Class Initialized
DEBUG - 2016-10-10 09:37:23 --> Index MX_Controller Initialized
INFO - 2016-10-10 09:37:23 --> Model Class Initialized
INFO - 2016-10-10 09:37:23 --> Model Class Initialized
ERROR - 2016-10-10 09:37:23 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-10-10 09:37:23 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 09:37:23 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 09:37:23 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 09:37:23 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-10-10 09:37:23 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 09:37:23 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 09:37:23 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:23 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:23 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:23 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:25 --> Database Driver Class Initialized
DEBUG - 2016-10-10 09:37:25 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 09:37:25 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 09:37:25 --> Final output sent to browser
DEBUG - 2016-10-10 09:37:25 --> Total execution time: 2.7816
INFO - 2016-10-10 09:37:31 --> Config Class Initialized
INFO - 2016-10-10 09:37:31 --> Hooks Class Initialized
DEBUG - 2016-10-10 09:37:31 --> UTF-8 Support Enabled
INFO - 2016-10-10 09:37:31 --> Utf8 Class Initialized
INFO - 2016-10-10 09:37:31 --> URI Class Initialized
INFO - 2016-10-10 09:37:31 --> Router Class Initialized
INFO - 2016-10-10 09:37:31 --> Output Class Initialized
INFO - 2016-10-10 09:37:31 --> Security Class Initialized
DEBUG - 2016-10-10 09:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 09:37:31 --> Input Class Initialized
INFO - 2016-10-10 09:37:31 --> Language Class Initialized
INFO - 2016-10-10 09:37:32 --> Language Class Initialized
INFO - 2016-10-10 09:37:32 --> Config Class Initialized
INFO - 2016-10-10 09:37:32 --> Loader Class Initialized
INFO - 2016-10-10 09:37:32 --> Helper loaded: url_helper
INFO - 2016-10-10 09:37:32 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 09:37:32 --> Controller Class Initialized
DEBUG - 2016-10-10 09:37:32 --> Index MX_Controller Initialized
INFO - 2016-10-10 09:37:32 --> Model Class Initialized
INFO - 2016-10-10 09:37:32 --> Model Class Initialized
ERROR - 2016-10-10 09:37:32 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-10 09:37:32 --> Anggota MX_Controller Initialized
INFO - 2016-10-10 09:37:32 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:32 --> Final output sent to browser
DEBUG - 2016-10-10 09:37:32 --> Total execution time: 0.7247
INFO - 2016-10-10 09:37:38 --> Config Class Initialized
INFO - 2016-10-10 09:37:38 --> Hooks Class Initialized
DEBUG - 2016-10-10 09:37:38 --> UTF-8 Support Enabled
INFO - 2016-10-10 09:37:38 --> Utf8 Class Initialized
INFO - 2016-10-10 09:37:38 --> URI Class Initialized
INFO - 2016-10-10 09:37:38 --> Router Class Initialized
INFO - 2016-10-10 09:37:38 --> Output Class Initialized
INFO - 2016-10-10 09:37:38 --> Security Class Initialized
DEBUG - 2016-10-10 09:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 09:37:38 --> Input Class Initialized
INFO - 2016-10-10 09:37:38 --> Language Class Initialized
INFO - 2016-10-10 09:37:38 --> Language Class Initialized
INFO - 2016-10-10 09:37:38 --> Config Class Initialized
INFO - 2016-10-10 09:37:38 --> Loader Class Initialized
INFO - 2016-10-10 09:37:38 --> Helper loaded: url_helper
INFO - 2016-10-10 09:37:38 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 09:37:38 --> Controller Class Initialized
DEBUG - 2016-10-10 09:37:38 --> Index MX_Controller Initialized
INFO - 2016-10-10 09:37:38 --> Model Class Initialized
INFO - 2016-10-10 09:37:38 --> Model Class Initialized
ERROR - 2016-10-10 09:37:38 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-10-10 09:37:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 09:37:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 09:37:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 09:37:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_umum.php
DEBUG - 2016-10-10 09:37:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 09:37:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 09:37:39 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:39 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:39 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:39 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:39 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:39 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:39 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:39 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:39 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:39 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:39 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:39 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:39 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:39 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:39 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:39 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:39 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:39 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:39 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:39 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:39 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:39 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:39 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:39 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:39 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:39 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:39 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:39 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:40 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:40 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:40 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:40 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:40 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:40 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:40 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:40 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:40 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:40 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:40 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:40 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:40 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:40 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:40 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:40 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:40 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:40 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:40 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:40 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:40 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:40 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:40 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:40 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:40 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:40 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:40 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:40 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:40 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:40 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:41 --> Database Driver Class Initialized
INFO - 2016-10-10 09:37:41 --> Database Driver Class Initialized
DEBUG - 2016-10-10 09:37:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 09:37:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 09:37:41 --> Final output sent to browser
DEBUG - 2016-10-10 09:37:41 --> Total execution time: 2.8310
INFO - 2016-10-10 09:38:29 --> Config Class Initialized
INFO - 2016-10-10 09:38:29 --> Hooks Class Initialized
DEBUG - 2016-10-10 09:38:29 --> UTF-8 Support Enabled
INFO - 2016-10-10 09:38:29 --> Utf8 Class Initialized
INFO - 2016-10-10 09:38:29 --> URI Class Initialized
INFO - 2016-10-10 09:38:29 --> Router Class Initialized
INFO - 2016-10-10 09:38:30 --> Output Class Initialized
INFO - 2016-10-10 09:38:30 --> Security Class Initialized
DEBUG - 2016-10-10 09:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 09:38:30 --> Input Class Initialized
INFO - 2016-10-10 09:38:30 --> Language Class Initialized
INFO - 2016-10-10 09:38:30 --> Language Class Initialized
INFO - 2016-10-10 09:38:30 --> Config Class Initialized
INFO - 2016-10-10 09:38:30 --> Loader Class Initialized
INFO - 2016-10-10 09:38:30 --> Helper loaded: url_helper
INFO - 2016-10-10 09:38:30 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 09:38:30 --> Controller Class Initialized
DEBUG - 2016-10-10 09:38:30 --> Index MX_Controller Initialized
INFO - 2016-10-10 09:38:30 --> Model Class Initialized
INFO - 2016-10-10 09:38:30 --> Model Class Initialized
ERROR - 2016-10-10 09:38:30 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-10-10 09:38:30 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 09:38:30 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 09:38:30 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 09:38:30 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_umum.php
DEBUG - 2016-10-10 09:38:30 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 09:38:30 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 09:38:30 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:30 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:30 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:30 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:30 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:30 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:30 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:30 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:30 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:30 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:30 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:30 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:31 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:31 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:31 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:31 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:31 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:31 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:31 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:31 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:31 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:31 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:31 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:31 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:31 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:31 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:31 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:31 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:31 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:31 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:31 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:31 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:31 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:31 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:31 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:31 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:31 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:31 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:31 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:31 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:31 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:31 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:31 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:31 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:31 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:31 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:32 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:32 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:32 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:32 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:32 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:32 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:32 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:32 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:32 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:32 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:32 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:32 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:32 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:32 --> Database Driver Class Initialized
DEBUG - 2016-10-10 09:38:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 09:38:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 09:38:32 --> Final output sent to browser
DEBUG - 2016-10-10 09:38:32 --> Total execution time: 2.6836
INFO - 2016-10-10 09:38:58 --> Config Class Initialized
INFO - 2016-10-10 09:38:58 --> Hooks Class Initialized
DEBUG - 2016-10-10 09:38:58 --> UTF-8 Support Enabled
INFO - 2016-10-10 09:38:58 --> Utf8 Class Initialized
INFO - 2016-10-10 09:38:58 --> URI Class Initialized
INFO - 2016-10-10 09:38:58 --> Router Class Initialized
INFO - 2016-10-10 09:38:58 --> Output Class Initialized
INFO - 2016-10-10 09:38:58 --> Security Class Initialized
DEBUG - 2016-10-10 09:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 09:38:59 --> Input Class Initialized
INFO - 2016-10-10 09:38:59 --> Language Class Initialized
INFO - 2016-10-10 09:38:59 --> Language Class Initialized
INFO - 2016-10-10 09:38:59 --> Config Class Initialized
INFO - 2016-10-10 09:38:59 --> Loader Class Initialized
INFO - 2016-10-10 09:38:59 --> Helper loaded: url_helper
INFO - 2016-10-10 09:38:59 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 09:38:59 --> Controller Class Initialized
DEBUG - 2016-10-10 09:38:59 --> Index MX_Controller Initialized
INFO - 2016-10-10 09:38:59 --> Model Class Initialized
INFO - 2016-10-10 09:38:59 --> Model Class Initialized
ERROR - 2016-10-10 09:38:59 --> Unable to delete cache file for admin/index/do_ajukan_pinjaman
INFO - 2016-10-10 09:38:59 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:59 --> Database Driver Class Initialized
INFO - 2016-10-10 09:38:59 --> Final output sent to browser
DEBUG - 2016-10-10 09:38:59 --> Total execution time: 0.7413
INFO - 2016-10-10 09:39:54 --> Config Class Initialized
INFO - 2016-10-10 09:39:54 --> Hooks Class Initialized
DEBUG - 2016-10-10 09:39:54 --> UTF-8 Support Enabled
INFO - 2016-10-10 09:39:54 --> Utf8 Class Initialized
INFO - 2016-10-10 09:39:54 --> URI Class Initialized
INFO - 2016-10-10 09:39:54 --> Router Class Initialized
INFO - 2016-10-10 09:39:54 --> Output Class Initialized
INFO - 2016-10-10 09:39:54 --> Security Class Initialized
DEBUG - 2016-10-10 09:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 09:39:54 --> Input Class Initialized
INFO - 2016-10-10 09:39:54 --> Language Class Initialized
INFO - 2016-10-10 09:39:54 --> Language Class Initialized
INFO - 2016-10-10 09:39:54 --> Config Class Initialized
INFO - 2016-10-10 09:39:54 --> Loader Class Initialized
INFO - 2016-10-10 09:39:54 --> Helper loaded: url_helper
INFO - 2016-10-10 09:39:54 --> Database Driver Class Initialized
INFO - 2016-10-10 09:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 09:39:54 --> Controller Class Initialized
DEBUG - 2016-10-10 09:39:54 --> Index MX_Controller Initialized
INFO - 2016-10-10 09:39:55 --> Model Class Initialized
INFO - 2016-10-10 09:39:55 --> Model Class Initialized
ERROR - 2016-10-10 09:39:55 --> Unable to delete cache file for admin/index/do_save_jaminan/sertifikat
INFO - 2016-10-10 09:39:55 --> Database Driver Class Initialized
INFO - 2016-10-10 09:39:55 --> Final output sent to browser
DEBUG - 2016-10-10 09:39:55 --> Total execution time: 0.7027
INFO - 2016-10-10 09:40:51 --> Config Class Initialized
INFO - 2016-10-10 09:40:51 --> Hooks Class Initialized
DEBUG - 2016-10-10 09:40:51 --> UTF-8 Support Enabled
INFO - 2016-10-10 09:40:51 --> Utf8 Class Initialized
INFO - 2016-10-10 09:40:51 --> URI Class Initialized
INFO - 2016-10-10 09:40:51 --> Router Class Initialized
INFO - 2016-10-10 09:40:51 --> Output Class Initialized
INFO - 2016-10-10 09:40:51 --> Security Class Initialized
DEBUG - 2016-10-10 09:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 09:40:51 --> Input Class Initialized
INFO - 2016-10-10 09:40:51 --> Language Class Initialized
INFO - 2016-10-10 09:40:51 --> Language Class Initialized
INFO - 2016-10-10 09:40:51 --> Config Class Initialized
INFO - 2016-10-10 09:40:51 --> Loader Class Initialized
INFO - 2016-10-10 09:40:51 --> Helper loaded: url_helper
INFO - 2016-10-10 09:40:51 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 09:40:51 --> Controller Class Initialized
DEBUG - 2016-10-10 09:40:51 --> Index MX_Controller Initialized
INFO - 2016-10-10 09:40:51 --> Model Class Initialized
INFO - 2016-10-10 09:40:51 --> Model Class Initialized
ERROR - 2016-10-10 09:40:51 --> Unable to delete cache file for admin/index/batal/972a67c48192728a34979d9a35164c1295401b71
INFO - 2016-10-10 09:40:52 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:52 --> Final output sent to browser
DEBUG - 2016-10-10 09:40:52 --> Total execution time: 1.0379
INFO - 2016-10-10 09:40:52 --> Config Class Initialized
INFO - 2016-10-10 09:40:52 --> Hooks Class Initialized
DEBUG - 2016-10-10 09:40:52 --> UTF-8 Support Enabled
INFO - 2016-10-10 09:40:52 --> Utf8 Class Initialized
INFO - 2016-10-10 09:40:52 --> URI Class Initialized
INFO - 2016-10-10 09:40:52 --> Router Class Initialized
INFO - 2016-10-10 09:40:52 --> Output Class Initialized
INFO - 2016-10-10 09:40:52 --> Security Class Initialized
DEBUG - 2016-10-10 09:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 09:40:52 --> Input Class Initialized
INFO - 2016-10-10 09:40:52 --> Language Class Initialized
INFO - 2016-10-10 09:40:52 --> Language Class Initialized
INFO - 2016-10-10 09:40:52 --> Config Class Initialized
INFO - 2016-10-10 09:40:52 --> Loader Class Initialized
INFO - 2016-10-10 09:40:52 --> Helper loaded: url_helper
INFO - 2016-10-10 09:40:52 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 09:40:52 --> Controller Class Initialized
DEBUG - 2016-10-10 09:40:52 --> Index MX_Controller Initialized
INFO - 2016-10-10 09:40:52 --> Model Class Initialized
INFO - 2016-10-10 09:40:52 --> Model Class Initialized
ERROR - 2016-10-10 09:40:52 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-10-10 09:40:53 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 09:40:53 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 09:40:53 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 09:40:53 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-10-10 09:40:53 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 09:40:53 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 09:40:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:54 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:54 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:54 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:54 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:54 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:54 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:54 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:54 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:54 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:54 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:54 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:54 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:54 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:54 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:54 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:54 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:54 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:54 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:54 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:54 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:54 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:54 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:54 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:54 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:54 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:54 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:54 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:54 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:54 --> Database Driver Class Initialized
INFO - 2016-10-10 09:40:54 --> Database Driver Class Initialized
DEBUG - 2016-10-10 09:40:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 09:40:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 09:40:54 --> Final output sent to browser
DEBUG - 2016-10-10 09:40:55 --> Total execution time: 2.5907
INFO - 2016-10-10 09:41:04 --> Config Class Initialized
INFO - 2016-10-10 09:41:04 --> Hooks Class Initialized
DEBUG - 2016-10-10 09:41:04 --> UTF-8 Support Enabled
INFO - 2016-10-10 09:41:04 --> Utf8 Class Initialized
INFO - 2016-10-10 09:41:04 --> URI Class Initialized
INFO - 2016-10-10 09:41:04 --> Router Class Initialized
INFO - 2016-10-10 09:41:04 --> Output Class Initialized
INFO - 2016-10-10 09:41:04 --> Security Class Initialized
DEBUG - 2016-10-10 09:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 09:41:04 --> Input Class Initialized
INFO - 2016-10-10 09:41:04 --> Language Class Initialized
INFO - 2016-10-10 09:41:04 --> Language Class Initialized
INFO - 2016-10-10 09:41:04 --> Config Class Initialized
INFO - 2016-10-10 09:41:04 --> Loader Class Initialized
INFO - 2016-10-10 09:41:04 --> Helper loaded: url_helper
INFO - 2016-10-10 09:41:04 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 09:41:04 --> Controller Class Initialized
DEBUG - 2016-10-10 09:41:04 --> Index MX_Controller Initialized
INFO - 2016-10-10 09:41:04 --> Model Class Initialized
INFO - 2016-10-10 09:41:04 --> Model Class Initialized
ERROR - 2016-10-10 09:41:04 --> Unable to delete cache file for admin/index/list_jaminan
DEBUG - 2016-10-10 09:41:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 09:41:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 09:41:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 09:41:05 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/jaminan.php
DEBUG - 2016-10-10 09:41:05 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 09:41:05 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 09:41:05 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:05 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:05 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:05 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:05 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:05 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:05 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:05 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:05 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:05 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:05 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:05 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:05 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:05 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:05 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:05 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:05 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:05 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:05 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:05 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:05 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:06 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:06 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:06 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:06 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:06 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:06 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:06 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:06 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:06 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:06 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:06 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:06 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:06 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:06 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:06 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:06 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:06 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:06 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:06 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:06 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:06 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:06 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:06 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:07 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:07 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:07 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:07 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:07 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:07 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:07 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:07 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:07 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:07 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:07 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:07 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:07 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:07 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:07 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:07 --> Database Driver Class Initialized
DEBUG - 2016-10-10 09:41:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 09:41:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 09:41:07 --> Final output sent to browser
DEBUG - 2016-10-10 09:41:07 --> Total execution time: 3.4301
INFO - 2016-10-10 09:41:35 --> Config Class Initialized
INFO - 2016-10-10 09:41:35 --> Hooks Class Initialized
DEBUG - 2016-10-10 09:41:35 --> UTF-8 Support Enabled
INFO - 2016-10-10 09:41:35 --> Utf8 Class Initialized
INFO - 2016-10-10 09:41:35 --> URI Class Initialized
INFO - 2016-10-10 09:41:35 --> Router Class Initialized
INFO - 2016-10-10 09:41:35 --> Output Class Initialized
INFO - 2016-10-10 09:41:35 --> Security Class Initialized
DEBUG - 2016-10-10 09:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 09:41:35 --> Input Class Initialized
INFO - 2016-10-10 09:41:35 --> Language Class Initialized
INFO - 2016-10-10 09:41:35 --> Language Class Initialized
INFO - 2016-10-10 09:41:35 --> Config Class Initialized
INFO - 2016-10-10 09:41:35 --> Loader Class Initialized
INFO - 2016-10-10 09:41:35 --> Helper loaded: url_helper
INFO - 2016-10-10 09:41:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 09:41:35 --> Controller Class Initialized
DEBUG - 2016-10-10 09:41:35 --> Index MX_Controller Initialized
INFO - 2016-10-10 09:41:35 --> Model Class Initialized
INFO - 2016-10-10 09:41:35 --> Model Class Initialized
ERROR - 2016-10-10 09:41:35 --> Unable to delete cache file for admin/index/data/anggota
DEBUG - 2016-10-10 09:41:35 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 09:41:35 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 09:41:35 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 09:41:35 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-10 09:41:35 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-10 09:41:35 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-10 09:41:35 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 09:41:35 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 09:41:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:36 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:36 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:36 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:36 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:36 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:36 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:36 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:36 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:36 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:36 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:36 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:36 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:36 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:36 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:36 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:36 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:36 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:36 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:36 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:36 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:36 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:36 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:36 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:36 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:36 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:36 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:36 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:36 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:36 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:36 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:36 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:36 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:36 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:37 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:37 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:37 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:37 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:37 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:37 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:37 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:37 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:37 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:37 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:37 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:37 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:37 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:37 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:37 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:37 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:37 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:37 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:37 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:37 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:37 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:37 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:37 --> Database Driver Class Initialized
DEBUG - 2016-10-10 09:41:37 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 09:41:37 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 09:41:37 --> Final output sent to browser
DEBUG - 2016-10-10 09:41:37 --> Total execution time: 2.6235
INFO - 2016-10-10 09:41:43 --> Config Class Initialized
INFO - 2016-10-10 09:41:43 --> Hooks Class Initialized
DEBUG - 2016-10-10 09:41:43 --> UTF-8 Support Enabled
INFO - 2016-10-10 09:41:43 --> Utf8 Class Initialized
INFO - 2016-10-10 09:41:43 --> URI Class Initialized
INFO - 2016-10-10 09:41:43 --> Router Class Initialized
INFO - 2016-10-10 09:41:43 --> Output Class Initialized
INFO - 2016-10-10 09:41:43 --> Security Class Initialized
DEBUG - 2016-10-10 09:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 09:41:43 --> Input Class Initialized
INFO - 2016-10-10 09:41:43 --> Language Class Initialized
INFO - 2016-10-10 09:41:43 --> Language Class Initialized
INFO - 2016-10-10 09:41:43 --> Config Class Initialized
INFO - 2016-10-10 09:41:43 --> Loader Class Initialized
INFO - 2016-10-10 09:41:43 --> Helper loaded: url_helper
INFO - 2016-10-10 09:41:43 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 09:41:43 --> Controller Class Initialized
DEBUG - 2016-10-10 09:41:43 --> Index MX_Controller Initialized
INFO - 2016-10-10 09:41:43 --> Model Class Initialized
INFO - 2016-10-10 09:41:43 --> Model Class Initialized
ERROR - 2016-10-10 09:41:43 --> Unable to delete cache file for admin/index/data/anggota/umum
DEBUG - 2016-10-10 09:41:43 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 09:41:43 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 09:41:43 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 09:41:43 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-10 09:41:43 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-10 09:41:43 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-10 09:41:43 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 09:41:43 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 09:41:43 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:43 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:45 --> Database Driver Class Initialized
DEBUG - 2016-10-10 09:41:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 09:41:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 09:41:45 --> Final output sent to browser
DEBUG - 2016-10-10 09:41:45 --> Total execution time: 2.6354
INFO - 2016-10-10 09:41:51 --> Config Class Initialized
INFO - 2016-10-10 09:41:51 --> Hooks Class Initialized
DEBUG - 2016-10-10 09:41:51 --> UTF-8 Support Enabled
INFO - 2016-10-10 09:41:51 --> Utf8 Class Initialized
INFO - 2016-10-10 09:41:51 --> URI Class Initialized
INFO - 2016-10-10 09:41:51 --> Router Class Initialized
INFO - 2016-10-10 09:41:51 --> Output Class Initialized
INFO - 2016-10-10 09:41:51 --> Security Class Initialized
DEBUG - 2016-10-10 09:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 09:41:51 --> Input Class Initialized
INFO - 2016-10-10 09:41:51 --> Language Class Initialized
INFO - 2016-10-10 09:41:51 --> Language Class Initialized
INFO - 2016-10-10 09:41:51 --> Config Class Initialized
INFO - 2016-10-10 09:41:51 --> Loader Class Initialized
INFO - 2016-10-10 09:41:51 --> Helper loaded: url_helper
INFO - 2016-10-10 09:41:51 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 09:41:51 --> Controller Class Initialized
DEBUG - 2016-10-10 09:41:51 --> Index MX_Controller Initialized
INFO - 2016-10-10 09:41:51 --> Model Class Initialized
INFO - 2016-10-10 09:41:51 --> Model Class Initialized
ERROR - 2016-10-10 09:41:51 --> Unable to delete cache file for admin/index/data/anggota/karyawan
DEBUG - 2016-10-10 09:41:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 09:41:52 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 09:41:52 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 09:41:52 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-10 09:41:52 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-10 09:41:52 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-10 09:41:52 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 09:41:52 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 09:41:52 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:52 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:52 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:52 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:52 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:52 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:52 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:52 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:52 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:52 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:52 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:52 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:52 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:52 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:52 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:52 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:52 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:52 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:52 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:53 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:54 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:54 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:54 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:54 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:54 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:54 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:54 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:54 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:54 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:54 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:54 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:54 --> Database Driver Class Initialized
INFO - 2016-10-10 09:41:54 --> Database Driver Class Initialized
DEBUG - 2016-10-10 09:41:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 09:41:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 09:41:54 --> Final output sent to browser
DEBUG - 2016-10-10 09:41:54 --> Total execution time: 3.2002
INFO - 2016-10-10 09:42:42 --> Config Class Initialized
INFO - 2016-10-10 09:42:42 --> Hooks Class Initialized
DEBUG - 2016-10-10 09:42:42 --> UTF-8 Support Enabled
INFO - 2016-10-10 09:42:42 --> Utf8 Class Initialized
INFO - 2016-10-10 09:42:42 --> URI Class Initialized
INFO - 2016-10-10 09:42:42 --> Router Class Initialized
INFO - 2016-10-10 09:42:42 --> Output Class Initialized
INFO - 2016-10-10 09:42:42 --> Security Class Initialized
DEBUG - 2016-10-10 09:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 09:42:42 --> Input Class Initialized
INFO - 2016-10-10 09:42:42 --> Language Class Initialized
INFO - 2016-10-10 09:42:42 --> Language Class Initialized
INFO - 2016-10-10 09:42:42 --> Config Class Initialized
INFO - 2016-10-10 09:42:42 --> Loader Class Initialized
INFO - 2016-10-10 09:42:42 --> Helper loaded: url_helper
INFO - 2016-10-10 09:42:42 --> Database Driver Class Initialized
INFO - 2016-10-10 09:42:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 09:42:43 --> Controller Class Initialized
DEBUG - 2016-10-10 09:42:43 --> Index MX_Controller Initialized
INFO - 2016-10-10 09:42:43 --> Model Class Initialized
INFO - 2016-10-10 09:42:43 --> Model Class Initialized
ERROR - 2016-10-10 09:42:43 --> Unable to delete cache file for admin/index/post_get/anggota/356a192b7913b04c54574d18c28d46e6395428ab
DEBUG - 2016-10-10 09:42:43 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-10 09:42:43 --> Users MX_Controller Initialized
INFO - 2016-10-10 09:42:43 --> Final output sent to browser
DEBUG - 2016-10-10 09:42:43 --> Total execution time: 0.9346
INFO - 2016-10-10 09:44:12 --> Config Class Initialized
INFO - 2016-10-10 09:44:12 --> Hooks Class Initialized
DEBUG - 2016-10-10 09:44:12 --> UTF-8 Support Enabled
INFO - 2016-10-10 09:44:12 --> Utf8 Class Initialized
INFO - 2016-10-10 09:44:12 --> URI Class Initialized
INFO - 2016-10-10 09:44:12 --> Router Class Initialized
INFO - 2016-10-10 09:44:12 --> Output Class Initialized
INFO - 2016-10-10 09:44:12 --> Security Class Initialized
DEBUG - 2016-10-10 09:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 09:44:12 --> Input Class Initialized
INFO - 2016-10-10 09:44:12 --> Language Class Initialized
INFO - 2016-10-10 09:44:12 --> Language Class Initialized
INFO - 2016-10-10 09:44:12 --> Config Class Initialized
INFO - 2016-10-10 09:44:12 --> Loader Class Initialized
INFO - 2016-10-10 09:44:12 --> Helper loaded: url_helper
INFO - 2016-10-10 09:44:12 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 09:44:12 --> Controller Class Initialized
DEBUG - 2016-10-10 09:44:12 --> Index MX_Controller Initialized
INFO - 2016-10-10 09:44:12 --> Model Class Initialized
INFO - 2016-10-10 09:44:12 --> Model Class Initialized
ERROR - 2016-10-10 09:44:12 --> Unable to delete cache file for admin/index/data/anggota/karyawan
DEBUG - 2016-10-10 09:44:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 09:44:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 09:44:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 09:44:12 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-10 09:44:12 --> Anggota MX_Controller Initialized
ERROR - 2016-10-10 09:44:12 --> Severity: Notice --> Undefined index: kd_pinjaman E:\SERVER\htdocs\kops\application\views\main_html\content\list_anggota.php 40
DEBUG - 2016-10-10 09:44:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-10 09:44:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 09:44:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 09:44:13 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:13 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:13 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:13 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:13 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:13 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:13 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:13 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:13 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:13 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:13 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:13 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:13 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:13 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:13 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:13 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:13 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:13 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:13 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:13 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:13 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:13 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:13 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:13 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:13 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:13 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:13 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:13 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:13 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:13 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:13 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:13 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:13 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:14 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:14 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:14 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:14 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:14 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:14 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:14 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:14 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:14 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:14 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:14 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:14 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:14 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:14 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:14 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:14 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:14 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:14 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:14 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:14 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:14 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:14 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:14 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:14 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:14 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:14 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:14 --> Database Driver Class Initialized
DEBUG - 2016-10-10 09:44:14 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 09:44:14 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 09:44:14 --> Final output sent to browser
DEBUG - 2016-10-10 09:44:14 --> Total execution time: 2.6279
INFO - 2016-10-10 09:44:23 --> Config Class Initialized
INFO - 2016-10-10 09:44:23 --> Hooks Class Initialized
DEBUG - 2016-10-10 09:44:24 --> UTF-8 Support Enabled
INFO - 2016-10-10 09:44:24 --> Utf8 Class Initialized
INFO - 2016-10-10 09:44:24 --> URI Class Initialized
INFO - 2016-10-10 09:44:24 --> Router Class Initialized
INFO - 2016-10-10 09:44:24 --> Output Class Initialized
INFO - 2016-10-10 09:44:24 --> Security Class Initialized
DEBUG - 2016-10-10 09:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 09:44:24 --> Input Class Initialized
INFO - 2016-10-10 09:44:24 --> Language Class Initialized
INFO - 2016-10-10 09:44:24 --> Language Class Initialized
INFO - 2016-10-10 09:44:24 --> Config Class Initialized
INFO - 2016-10-10 09:44:24 --> Loader Class Initialized
INFO - 2016-10-10 09:44:24 --> Helper loaded: url_helper
INFO - 2016-10-10 09:44:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 09:44:24 --> Controller Class Initialized
DEBUG - 2016-10-10 09:44:24 --> Index MX_Controller Initialized
INFO - 2016-10-10 09:44:24 --> Model Class Initialized
INFO - 2016-10-10 09:44:24 --> Model Class Initialized
ERROR - 2016-10-10 09:44:24 --> Unable to delete cache file for admin/index/data/anggota/karyawan
DEBUG - 2016-10-10 09:44:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 09:44:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 09:44:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 09:44:24 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-10 09:44:24 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-10 09:44:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-10 09:44:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 09:44:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 09:44:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:26 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:26 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:26 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:26 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:26 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:26 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:26 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:26 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:26 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:26 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:26 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:26 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:26 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:26 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:26 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:26 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:26 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:26 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:26 --> Database Driver Class Initialized
INFO - 2016-10-10 09:44:26 --> Database Driver Class Initialized
DEBUG - 2016-10-10 09:44:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 09:44:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 09:44:26 --> Final output sent to browser
DEBUG - 2016-10-10 09:44:26 --> Total execution time: 2.7586
INFO - 2016-10-10 09:45:32 --> Config Class Initialized
INFO - 2016-10-10 09:45:32 --> Hooks Class Initialized
DEBUG - 2016-10-10 09:45:32 --> UTF-8 Support Enabled
INFO - 2016-10-10 09:45:32 --> Utf8 Class Initialized
INFO - 2016-10-10 09:45:33 --> URI Class Initialized
INFO - 2016-10-10 09:45:33 --> Router Class Initialized
INFO - 2016-10-10 09:45:33 --> Output Class Initialized
INFO - 2016-10-10 09:45:33 --> Security Class Initialized
DEBUG - 2016-10-10 09:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 09:45:33 --> Input Class Initialized
INFO - 2016-10-10 09:45:33 --> Language Class Initialized
INFO - 2016-10-10 09:45:33 --> Language Class Initialized
INFO - 2016-10-10 09:45:33 --> Config Class Initialized
INFO - 2016-10-10 09:45:33 --> Loader Class Initialized
INFO - 2016-10-10 09:45:33 --> Helper loaded: url_helper
INFO - 2016-10-10 09:45:33 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 09:45:33 --> Controller Class Initialized
DEBUG - 2016-10-10 09:45:33 --> Index MX_Controller Initialized
INFO - 2016-10-10 09:45:33 --> Model Class Initialized
INFO - 2016-10-10 09:45:33 --> Model Class Initialized
ERROR - 2016-10-10 09:45:33 --> Unable to delete cache file for admin/index/detail_anggota/356a192b7913b04c54574d18c28d46e6395428ab
DEBUG - 2016-10-10 09:45:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 09:45:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 09:45:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
INFO - 2016-10-10 09:45:33 --> Database Driver Class Initialized
DEBUG - 2016-10-10 09:45:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_pinjaman.php
INFO - 2016-10-10 09:45:33 --> Database Driver Class Initialized
DEBUG - 2016-10-10 09:45:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_tabungan.php
DEBUG - 2016-10-10 09:45:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/profile_anggota.php
DEBUG - 2016-10-10 09:45:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 09:45:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 09:45:33 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:33 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:35 --> Database Driver Class Initialized
DEBUG - 2016-10-10 09:45:35 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 09:45:35 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 09:45:36 --> Final output sent to browser
DEBUG - 2016-10-10 09:45:36 --> Total execution time: 3.1223
INFO - 2016-10-10 09:45:36 --> Config Class Initialized
INFO - 2016-10-10 09:45:36 --> Hooks Class Initialized
DEBUG - 2016-10-10 09:45:36 --> UTF-8 Support Enabled
INFO - 2016-10-10 09:45:36 --> Utf8 Class Initialized
INFO - 2016-10-10 09:45:36 --> URI Class Initialized
INFO - 2016-10-10 09:45:36 --> Router Class Initialized
INFO - 2016-10-10 09:45:36 --> Output Class Initialized
INFO - 2016-10-10 09:45:36 --> Security Class Initialized
DEBUG - 2016-10-10 09:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 09:45:36 --> Input Class Initialized
INFO - 2016-10-10 09:45:36 --> Language Class Initialized
INFO - 2016-10-10 09:45:36 --> Language Class Initialized
INFO - 2016-10-10 09:45:36 --> Config Class Initialized
INFO - 2016-10-10 09:45:36 --> Loader Class Initialized
INFO - 2016-10-10 09:45:36 --> Helper loaded: url_helper
INFO - 2016-10-10 09:45:36 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 09:45:36 --> Controller Class Initialized
DEBUG - 2016-10-10 09:45:37 --> Index MX_Controller Initialized
INFO - 2016-10-10 09:45:37 --> Model Class Initialized
INFO - 2016-10-10 09:45:37 --> Model Class Initialized
ERROR - 2016-10-10 09:45:37 --> Unable to delete cache file for admin/index/detail_anggota/images/picture.jpg
DEBUG - 2016-10-10 09:45:37 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 09:45:37 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 09:45:37 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
ERROR - 2016-10-10 09:45:37 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 16
ERROR - 2016-10-10 09:45:37 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 19
ERROR - 2016-10-10 09:45:37 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 22
ERROR - 2016-10-10 09:45:37 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 38
INFO - 2016-10-10 09:45:37 --> Database Driver Class Initialized
DEBUG - 2016-10-10 09:45:37 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_pinjaman.php
ERROR - 2016-10-10 09:45:37 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 41
INFO - 2016-10-10 09:45:38 --> Database Driver Class Initialized
DEBUG - 2016-10-10 09:45:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_tabungan.php
DEBUG - 2016-10-10 09:45:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/profile_anggota.php
DEBUG - 2016-10-10 09:45:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 09:45:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 09:45:38 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:38 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:38 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:38 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:38 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:38 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:38 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:39 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:39 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:39 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:39 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:39 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:39 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:39 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:39 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:39 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:39 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:39 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:39 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:39 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:39 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:39 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:39 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:39 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:39 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:39 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:39 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:40 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:40 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:40 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:40 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:40 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:41 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:41 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:41 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:41 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:41 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:41 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:41 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:41 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:41 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:41 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:41 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:41 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:41 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:41 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:41 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:41 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:41 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:41 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:42 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:42 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:42 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:42 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:42 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:42 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:42 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:42 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:42 --> Config Class Initialized
INFO - 2016-10-10 09:45:42 --> Hooks Class Initialized
INFO - 2016-10-10 09:45:42 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:42 --> Database Driver Class Initialized
DEBUG - 2016-10-10 09:45:42 --> UTF-8 Support Enabled
DEBUG - 2016-10-10 09:45:42 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 09:45:42 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 09:45:42 --> Final output sent to browser
DEBUG - 2016-10-10 09:45:42 --> Total execution time: 6.5313
INFO - 2016-10-10 09:45:42 --> Utf8 Class Initialized
INFO - 2016-10-10 09:45:42 --> URI Class Initialized
INFO - 2016-10-10 09:45:42 --> Router Class Initialized
INFO - 2016-10-10 09:45:42 --> Output Class Initialized
INFO - 2016-10-10 09:45:42 --> Security Class Initialized
DEBUG - 2016-10-10 09:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 09:45:43 --> Input Class Initialized
INFO - 2016-10-10 09:45:43 --> Language Class Initialized
INFO - 2016-10-10 09:45:43 --> Language Class Initialized
INFO - 2016-10-10 09:45:43 --> Config Class Initialized
INFO - 2016-10-10 09:45:43 --> Loader Class Initialized
INFO - 2016-10-10 09:45:43 --> Helper loaded: url_helper
INFO - 2016-10-10 09:45:43 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 09:45:43 --> Controller Class Initialized
DEBUG - 2016-10-10 09:45:43 --> Index MX_Controller Initialized
INFO - 2016-10-10 09:45:43 --> Model Class Initialized
INFO - 2016-10-10 09:45:43 --> Model Class Initialized
ERROR - 2016-10-10 09:45:43 --> Unable to delete cache file for admin/index/getRaportAngsuran/356a192b7913b04c54574d18c28d46e6395428ab
DEBUG - 2016-10-10 09:45:43 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/raport_angsuran.php
INFO - 2016-10-10 09:45:43 --> Final output sent to browser
DEBUG - 2016-10-10 09:45:43 --> Total execution time: 1.1235
INFO - 2016-10-10 09:45:47 --> Config Class Initialized
INFO - 2016-10-10 09:45:47 --> Hooks Class Initialized
DEBUG - 2016-10-10 09:45:47 --> UTF-8 Support Enabled
INFO - 2016-10-10 09:45:47 --> Utf8 Class Initialized
INFO - 2016-10-10 09:45:47 --> URI Class Initialized
INFO - 2016-10-10 09:45:47 --> Router Class Initialized
INFO - 2016-10-10 09:45:47 --> Output Class Initialized
INFO - 2016-10-10 09:45:47 --> Security Class Initialized
DEBUG - 2016-10-10 09:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 09:45:47 --> Input Class Initialized
INFO - 2016-10-10 09:45:47 --> Language Class Initialized
INFO - 2016-10-10 09:45:47 --> Language Class Initialized
INFO - 2016-10-10 09:45:47 --> Config Class Initialized
INFO - 2016-10-10 09:45:47 --> Loader Class Initialized
INFO - 2016-10-10 09:45:47 --> Helper loaded: url_helper
INFO - 2016-10-10 09:45:47 --> Database Driver Class Initialized
INFO - 2016-10-10 09:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 09:45:47 --> Controller Class Initialized
DEBUG - 2016-10-10 09:45:47 --> Index MX_Controller Initialized
INFO - 2016-10-10 09:45:47 --> Model Class Initialized
INFO - 2016-10-10 09:45:47 --> Model Class Initialized
ERROR - 2016-10-10 09:45:47 --> Unable to delete cache file for admin/index/getRaportAngsuran/f1f836cb4ea6efb2a0b1b99f41ad8b103eff4b59
DEBUG - 2016-10-10 09:45:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/raport_angsuran.php
INFO - 2016-10-10 09:45:47 --> Final output sent to browser
DEBUG - 2016-10-10 09:45:47 --> Total execution time: 0.8300
INFO - 2016-10-10 09:47:08 --> Config Class Initialized
INFO - 2016-10-10 09:47:08 --> Hooks Class Initialized
DEBUG - 2016-10-10 09:47:08 --> UTF-8 Support Enabled
INFO - 2016-10-10 09:47:08 --> Utf8 Class Initialized
INFO - 2016-10-10 09:47:08 --> URI Class Initialized
INFO - 2016-10-10 09:47:08 --> Router Class Initialized
INFO - 2016-10-10 09:47:08 --> Output Class Initialized
INFO - 2016-10-10 09:47:08 --> Security Class Initialized
DEBUG - 2016-10-10 09:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 09:47:08 --> Input Class Initialized
INFO - 2016-10-10 09:47:08 --> Language Class Initialized
INFO - 2016-10-10 09:47:08 --> Language Class Initialized
INFO - 2016-10-10 09:47:08 --> Config Class Initialized
INFO - 2016-10-10 09:47:08 --> Loader Class Initialized
INFO - 2016-10-10 09:47:08 --> Helper loaded: url_helper
INFO - 2016-10-10 09:47:08 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 09:47:08 --> Controller Class Initialized
DEBUG - 2016-10-10 09:47:08 --> Index MX_Controller Initialized
INFO - 2016-10-10 09:47:08 --> Model Class Initialized
INFO - 2016-10-10 09:47:08 --> Model Class Initialized
ERROR - 2016-10-10 09:47:08 --> Unable to delete cache file for admin/index/add/anggota
DEBUG - 2016-10-10 09:47:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 09:47:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 09:47:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 09:47:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_anggota.php
DEBUG - 2016-10-10 09:47:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 09:47:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 09:47:09 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:09 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:09 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:09 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:09 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:09 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:09 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:09 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:09 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:09 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:09 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:09 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:09 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:09 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:09 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:09 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:09 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:09 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:09 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:09 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:09 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:09 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:09 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:09 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:09 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:10 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:11 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:11 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:11 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:11 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:11 --> Database Driver Class Initialized
DEBUG - 2016-10-10 09:47:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 09:47:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 09:47:11 --> Final output sent to browser
DEBUG - 2016-10-10 09:47:11 --> Total execution time: 2.9634
INFO - 2016-10-10 09:47:45 --> Config Class Initialized
INFO - 2016-10-10 09:47:45 --> Hooks Class Initialized
DEBUG - 2016-10-10 09:47:45 --> UTF-8 Support Enabled
INFO - 2016-10-10 09:47:45 --> Utf8 Class Initialized
INFO - 2016-10-10 09:47:45 --> URI Class Initialized
INFO - 2016-10-10 09:47:45 --> Router Class Initialized
INFO - 2016-10-10 09:47:45 --> Output Class Initialized
INFO - 2016-10-10 09:47:45 --> Security Class Initialized
DEBUG - 2016-10-10 09:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 09:47:45 --> Input Class Initialized
INFO - 2016-10-10 09:47:45 --> Language Class Initialized
INFO - 2016-10-10 09:47:45 --> Language Class Initialized
INFO - 2016-10-10 09:47:46 --> Config Class Initialized
INFO - 2016-10-10 09:47:46 --> Loader Class Initialized
INFO - 2016-10-10 09:47:46 --> Helper loaded: url_helper
INFO - 2016-10-10 09:47:46 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 09:47:46 --> Controller Class Initialized
DEBUG - 2016-10-10 09:47:46 --> Index MX_Controller Initialized
INFO - 2016-10-10 09:47:46 --> Model Class Initialized
INFO - 2016-10-10 09:47:46 --> Model Class Initialized
ERROR - 2016-10-10 09:47:46 --> Unable to delete cache file for admin/index/post_add
DEBUG - 2016-10-10 09:47:46 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-10 09:47:46 --> Users MX_Controller Initialized
DEBUG - 2016-10-10 09:47:46 --> Index MX_Controller Initialized
ERROR - 2016-10-10 09:47:46 --> Unable to delete cache file for admin/index/post_add
INFO - 2016-10-10 09:47:46 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:46 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:46 --> Final output sent to browser
DEBUG - 2016-10-10 09:47:46 --> Total execution time: 1.0138
INFO - 2016-10-10 09:47:46 --> Config Class Initialized
INFO - 2016-10-10 09:47:46 --> Hooks Class Initialized
DEBUG - 2016-10-10 09:47:46 --> UTF-8 Support Enabled
INFO - 2016-10-10 09:47:46 --> Utf8 Class Initialized
INFO - 2016-10-10 09:47:46 --> URI Class Initialized
INFO - 2016-10-10 09:47:47 --> Router Class Initialized
INFO - 2016-10-10 09:47:47 --> Output Class Initialized
INFO - 2016-10-10 09:47:47 --> Security Class Initialized
DEBUG - 2016-10-10 09:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 09:47:47 --> Input Class Initialized
INFO - 2016-10-10 09:47:47 --> Language Class Initialized
INFO - 2016-10-10 09:47:47 --> Language Class Initialized
INFO - 2016-10-10 09:47:47 --> Config Class Initialized
INFO - 2016-10-10 09:47:47 --> Loader Class Initialized
INFO - 2016-10-10 09:47:47 --> Helper loaded: url_helper
INFO - 2016-10-10 09:47:47 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 09:47:47 --> Controller Class Initialized
DEBUG - 2016-10-10 09:47:47 --> Index MX_Controller Initialized
INFO - 2016-10-10 09:47:47 --> Model Class Initialized
INFO - 2016-10-10 09:47:47 --> Model Class Initialized
ERROR - 2016-10-10 09:47:47 --> Unable to delete cache file for admin/index/data/anggota
DEBUG - 2016-10-10 09:47:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 09:47:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 09:47:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 09:47:47 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-10 09:47:47 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-10 09:47:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-10 09:47:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 09:47:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 09:47:47 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:47 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:47 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:47 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:47 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:48 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:48 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:48 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:48 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:48 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:48 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:48 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:48 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:48 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:48 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:48 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:48 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:48 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:48 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:48 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:48 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:48 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:48 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:48 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:48 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:48 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:48 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:48 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:48 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:48 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:48 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:48 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:48 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:48 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:48 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:49 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:49 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:49 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:49 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:49 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:49 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:49 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:49 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:49 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:49 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:49 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:49 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:49 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:49 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:49 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:49 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:49 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:49 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:49 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:49 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:49 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:49 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:49 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:49 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:49 --> Database Driver Class Initialized
DEBUG - 2016-10-10 09:47:49 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 09:47:49 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 09:47:49 --> Final output sent to browser
DEBUG - 2016-10-10 09:47:49 --> Total execution time: 3.0520
INFO - 2016-10-10 09:47:55 --> Config Class Initialized
INFO - 2016-10-10 09:47:55 --> Hooks Class Initialized
DEBUG - 2016-10-10 09:47:55 --> UTF-8 Support Enabled
INFO - 2016-10-10 09:47:55 --> Utf8 Class Initialized
INFO - 2016-10-10 09:47:55 --> URI Class Initialized
INFO - 2016-10-10 09:47:55 --> Router Class Initialized
INFO - 2016-10-10 09:47:55 --> Output Class Initialized
INFO - 2016-10-10 09:47:55 --> Security Class Initialized
DEBUG - 2016-10-10 09:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 09:47:55 --> Input Class Initialized
INFO - 2016-10-10 09:47:55 --> Language Class Initialized
INFO - 2016-10-10 09:47:55 --> Language Class Initialized
INFO - 2016-10-10 09:47:55 --> Config Class Initialized
INFO - 2016-10-10 09:47:55 --> Loader Class Initialized
INFO - 2016-10-10 09:47:55 --> Helper loaded: url_helper
INFO - 2016-10-10 09:47:55 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 09:47:55 --> Controller Class Initialized
DEBUG - 2016-10-10 09:47:55 --> Index MX_Controller Initialized
INFO - 2016-10-10 09:47:55 --> Model Class Initialized
INFO - 2016-10-10 09:47:55 --> Model Class Initialized
ERROR - 2016-10-10 09:47:56 --> Unable to delete cache file for admin/index/data/anggota/umum
DEBUG - 2016-10-10 09:47:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 09:47:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 09:47:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 09:47:56 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-10 09:47:56 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-10 09:47:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-10 09:47:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 09:47:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 09:47:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:57 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:58 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:58 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:58 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:58 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:58 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:58 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:58 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:58 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:58 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:58 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:58 --> Database Driver Class Initialized
INFO - 2016-10-10 09:47:58 --> Database Driver Class Initialized
DEBUG - 2016-10-10 09:47:58 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 09:47:58 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 09:47:58 --> Final output sent to browser
DEBUG - 2016-10-10 09:47:58 --> Total execution time: 3.1311
INFO - 2016-10-10 09:48:06 --> Config Class Initialized
INFO - 2016-10-10 09:48:06 --> Hooks Class Initialized
DEBUG - 2016-10-10 09:48:06 --> UTF-8 Support Enabled
INFO - 2016-10-10 09:48:06 --> Utf8 Class Initialized
INFO - 2016-10-10 09:48:06 --> URI Class Initialized
INFO - 2016-10-10 09:48:06 --> Router Class Initialized
INFO - 2016-10-10 09:48:06 --> Output Class Initialized
INFO - 2016-10-10 09:48:06 --> Security Class Initialized
DEBUG - 2016-10-10 09:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 09:48:07 --> Input Class Initialized
INFO - 2016-10-10 09:48:07 --> Language Class Initialized
INFO - 2016-10-10 09:48:07 --> Language Class Initialized
INFO - 2016-10-10 09:48:07 --> Config Class Initialized
INFO - 2016-10-10 09:48:07 --> Loader Class Initialized
INFO - 2016-10-10 09:48:07 --> Helper loaded: url_helper
INFO - 2016-10-10 09:48:07 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 09:48:07 --> Controller Class Initialized
DEBUG - 2016-10-10 09:48:07 --> Index MX_Controller Initialized
INFO - 2016-10-10 09:48:07 --> Model Class Initialized
INFO - 2016-10-10 09:48:07 --> Model Class Initialized
ERROR - 2016-10-10 09:48:07 --> Unable to delete cache file for admin/index/data/anggota/karyawan
DEBUG - 2016-10-10 09:48:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 09:48:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 09:48:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 09:48:07 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-10 09:48:07 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-10 09:48:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-10 09:48:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 09:48:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 09:48:07 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:07 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:07 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:07 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:07 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:07 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:07 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:07 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:07 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:07 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:08 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:08 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:08 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:08 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:08 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:08 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:08 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:08 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:08 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:08 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:08 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:08 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:08 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:08 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:08 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:08 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:08 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:08 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:08 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:08 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:08 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:08 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:08 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:08 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:08 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:08 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:08 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:08 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:08 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:08 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:09 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:09 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:09 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:09 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:09 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:09 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:09 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:09 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:09 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:09 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:09 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:09 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:09 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:09 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:09 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:09 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:09 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:09 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:09 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:09 --> Database Driver Class Initialized
DEBUG - 2016-10-10 09:48:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 09:48:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 09:48:09 --> Final output sent to browser
DEBUG - 2016-10-10 09:48:09 --> Total execution time: 3.1460
INFO - 2016-10-10 09:48:14 --> Config Class Initialized
INFO - 2016-10-10 09:48:14 --> Hooks Class Initialized
DEBUG - 2016-10-10 09:48:14 --> UTF-8 Support Enabled
INFO - 2016-10-10 09:48:15 --> Utf8 Class Initialized
INFO - 2016-10-10 09:48:15 --> URI Class Initialized
INFO - 2016-10-10 09:48:15 --> Router Class Initialized
INFO - 2016-10-10 09:48:15 --> Output Class Initialized
INFO - 2016-10-10 09:48:15 --> Security Class Initialized
DEBUG - 2016-10-10 09:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 09:48:15 --> Input Class Initialized
INFO - 2016-10-10 09:48:15 --> Language Class Initialized
INFO - 2016-10-10 09:48:15 --> Language Class Initialized
INFO - 2016-10-10 09:48:15 --> Config Class Initialized
INFO - 2016-10-10 09:48:15 --> Loader Class Initialized
INFO - 2016-10-10 09:48:15 --> Helper loaded: url_helper
INFO - 2016-10-10 09:48:15 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 09:48:15 --> Controller Class Initialized
DEBUG - 2016-10-10 09:48:15 --> Index MX_Controller Initialized
INFO - 2016-10-10 09:48:15 --> Model Class Initialized
INFO - 2016-10-10 09:48:15 --> Model Class Initialized
ERROR - 2016-10-10 09:48:15 --> Unable to delete cache file for admin/index/data/anggota
DEBUG - 2016-10-10 09:48:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 09:48:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 09:48:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 09:48:15 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-10 09:48:15 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-10 09:48:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-10 09:48:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 09:48:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 09:48:15 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:15 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:15 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:15 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:17 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:17 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:17 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:17 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:17 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:17 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:17 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:17 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:17 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:17 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:17 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:17 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:17 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:17 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:17 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:17 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:17 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:17 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:17 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:17 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:17 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:17 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:17 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:17 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:17 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:17 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:17 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:17 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:18 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:18 --> Database Driver Class Initialized
DEBUG - 2016-10-10 09:48:18 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 09:48:18 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 09:48:18 --> Final output sent to browser
DEBUG - 2016-10-10 09:48:18 --> Total execution time: 3.2610
INFO - 2016-10-10 09:48:32 --> Config Class Initialized
INFO - 2016-10-10 09:48:32 --> Hooks Class Initialized
DEBUG - 2016-10-10 09:48:32 --> UTF-8 Support Enabled
INFO - 2016-10-10 09:48:32 --> Utf8 Class Initialized
INFO - 2016-10-10 09:48:32 --> URI Class Initialized
INFO - 2016-10-10 09:48:32 --> Router Class Initialized
INFO - 2016-10-10 09:48:32 --> Output Class Initialized
INFO - 2016-10-10 09:48:32 --> Security Class Initialized
DEBUG - 2016-10-10 09:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 09:48:32 --> Input Class Initialized
INFO - 2016-10-10 09:48:32 --> Language Class Initialized
INFO - 2016-10-10 09:48:32 --> Language Class Initialized
INFO - 2016-10-10 09:48:32 --> Config Class Initialized
INFO - 2016-10-10 09:48:32 --> Loader Class Initialized
INFO - 2016-10-10 09:48:32 --> Helper loaded: url_helper
INFO - 2016-10-10 09:48:32 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 09:48:32 --> Controller Class Initialized
DEBUG - 2016-10-10 09:48:32 --> Index MX_Controller Initialized
INFO - 2016-10-10 09:48:32 --> Model Class Initialized
INFO - 2016-10-10 09:48:32 --> Model Class Initialized
ERROR - 2016-10-10 09:48:32 --> Unable to delete cache file for admin/index/data/anggota
DEBUG - 2016-10-10 09:48:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 09:48:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 09:48:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 09:48:32 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-10 09:48:32 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-10 09:48:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-10 09:48:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 09:48:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 09:48:33 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:33 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:33 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:33 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:33 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:33 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:33 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:33 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:33 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:33 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:33 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:33 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:33 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:33 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:33 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:33 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:33 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:33 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:33 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:33 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:33 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:33 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:33 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:33 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:34 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:35 --> Database Driver Class Initialized
INFO - 2016-10-10 09:48:35 --> Database Driver Class Initialized
DEBUG - 2016-10-10 09:48:35 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 09:48:35 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 09:48:35 --> Final output sent to browser
DEBUG - 2016-10-10 09:48:35 --> Total execution time: 3.4849
INFO - 2016-10-10 09:49:22 --> Config Class Initialized
INFO - 2016-10-10 09:49:22 --> Hooks Class Initialized
DEBUG - 2016-10-10 09:49:22 --> UTF-8 Support Enabled
INFO - 2016-10-10 09:49:22 --> Utf8 Class Initialized
INFO - 2016-10-10 09:49:22 --> URI Class Initialized
INFO - 2016-10-10 09:49:22 --> Router Class Initialized
INFO - 2016-10-10 09:49:23 --> Output Class Initialized
INFO - 2016-10-10 09:49:23 --> Security Class Initialized
DEBUG - 2016-10-10 09:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 09:49:23 --> Input Class Initialized
INFO - 2016-10-10 09:49:23 --> Language Class Initialized
INFO - 2016-10-10 09:49:23 --> Language Class Initialized
INFO - 2016-10-10 09:49:23 --> Config Class Initialized
INFO - 2016-10-10 09:49:23 --> Loader Class Initialized
INFO - 2016-10-10 09:49:23 --> Helper loaded: url_helper
INFO - 2016-10-10 09:49:23 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 09:49:23 --> Controller Class Initialized
DEBUG - 2016-10-10 09:49:23 --> Index MX_Controller Initialized
INFO - 2016-10-10 09:49:23 --> Model Class Initialized
INFO - 2016-10-10 09:49:23 --> Model Class Initialized
ERROR - 2016-10-10 09:49:23 --> Unable to delete cache file for admin/index/data/anggota/umum
DEBUG - 2016-10-10 09:49:23 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 09:49:23 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 09:49:23 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 09:49:23 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-10 09:49:23 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-10 09:49:23 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-10 09:49:23 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 09:49:23 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 09:49:23 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:23 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:23 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:23 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:23 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:23 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:23 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:23 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:23 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:24 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:25 --> Database Driver Class Initialized
INFO - 2016-10-10 09:49:25 --> Database Driver Class Initialized
DEBUG - 2016-10-10 09:49:25 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 09:49:25 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 09:49:25 --> Final output sent to browser
DEBUG - 2016-10-10 09:49:25 --> Total execution time: 2.9835
INFO - 2016-10-10 09:50:43 --> Config Class Initialized
INFO - 2016-10-10 09:50:43 --> Hooks Class Initialized
DEBUG - 2016-10-10 09:50:43 --> UTF-8 Support Enabled
INFO - 2016-10-10 09:50:43 --> Utf8 Class Initialized
INFO - 2016-10-10 09:50:43 --> URI Class Initialized
INFO - 2016-10-10 09:50:43 --> Router Class Initialized
INFO - 2016-10-10 09:50:43 --> Output Class Initialized
INFO - 2016-10-10 09:50:43 --> Security Class Initialized
DEBUG - 2016-10-10 09:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 09:50:43 --> Input Class Initialized
INFO - 2016-10-10 09:50:43 --> Language Class Initialized
INFO - 2016-10-10 09:50:43 --> Language Class Initialized
INFO - 2016-10-10 09:50:43 --> Config Class Initialized
INFO - 2016-10-10 09:50:43 --> Loader Class Initialized
INFO - 2016-10-10 09:50:43 --> Helper loaded: url_helper
INFO - 2016-10-10 09:50:43 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 09:50:43 --> Controller Class Initialized
DEBUG - 2016-10-10 09:50:43 --> Index MX_Controller Initialized
INFO - 2016-10-10 09:50:43 --> Model Class Initialized
INFO - 2016-10-10 09:50:43 --> Model Class Initialized
ERROR - 2016-10-10 09:50:43 --> Unable to delete cache file for admin/index/detail_anggota/da4b9237bacccdf19c0760cab7aec4a8359010b0
DEBUG - 2016-10-10 09:50:43 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 09:50:43 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 09:50:43 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
INFO - 2016-10-10 09:50:43 --> Database Driver Class Initialized
DEBUG - 2016-10-10 09:50:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_pinjaman.php
INFO - 2016-10-10 09:50:44 --> Database Driver Class Initialized
DEBUG - 2016-10-10 09:50:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_tabungan.php
DEBUG - 2016-10-10 09:50:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/profile_anggota.php
DEBUG - 2016-10-10 09:50:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 09:50:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 09:50:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:44 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:45 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:46 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:46 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:46 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:46 --> Database Driver Class Initialized
DEBUG - 2016-10-10 09:50:46 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 09:50:46 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 09:50:46 --> Final output sent to browser
DEBUG - 2016-10-10 09:50:46 --> Total execution time: 2.9492
INFO - 2016-10-10 09:50:46 --> Config Class Initialized
INFO - 2016-10-10 09:50:46 --> Hooks Class Initialized
DEBUG - 2016-10-10 09:50:46 --> UTF-8 Support Enabled
INFO - 2016-10-10 09:50:46 --> Utf8 Class Initialized
INFO - 2016-10-10 09:50:46 --> URI Class Initialized
INFO - 2016-10-10 09:50:46 --> Router Class Initialized
INFO - 2016-10-10 09:50:46 --> Output Class Initialized
INFO - 2016-10-10 09:50:46 --> Security Class Initialized
DEBUG - 2016-10-10 09:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 09:50:46 --> Input Class Initialized
INFO - 2016-10-10 09:50:46 --> Language Class Initialized
INFO - 2016-10-10 09:50:47 --> Language Class Initialized
INFO - 2016-10-10 09:50:47 --> Config Class Initialized
INFO - 2016-10-10 09:50:47 --> Loader Class Initialized
INFO - 2016-10-10 09:50:47 --> Helper loaded: url_helper
INFO - 2016-10-10 09:50:47 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 09:50:47 --> Controller Class Initialized
DEBUG - 2016-10-10 09:50:47 --> Index MX_Controller Initialized
INFO - 2016-10-10 09:50:47 --> Model Class Initialized
INFO - 2016-10-10 09:50:47 --> Model Class Initialized
ERROR - 2016-10-10 09:50:47 --> Unable to delete cache file for admin/index/detail_anggota/images/picture.jpg
DEBUG - 2016-10-10 09:50:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 09:50:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 09:50:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
ERROR - 2016-10-10 09:50:48 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 16
ERROR - 2016-10-10 09:50:48 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 19
ERROR - 2016-10-10 09:50:48 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 22
ERROR - 2016-10-10 09:50:48 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 38
INFO - 2016-10-10 09:50:48 --> Database Driver Class Initialized
DEBUG - 2016-10-10 09:50:48 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_pinjaman.php
ERROR - 2016-10-10 09:50:48 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 41
INFO - 2016-10-10 09:50:48 --> Database Driver Class Initialized
DEBUG - 2016-10-10 09:50:48 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_tabungan.php
DEBUG - 2016-10-10 09:50:48 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/profile_anggota.php
DEBUG - 2016-10-10 09:50:48 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 09:50:48 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 09:50:48 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:49 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:49 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:49 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:49 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:49 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:49 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:49 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:49 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:49 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:49 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:49 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:49 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:49 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:49 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:49 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:49 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:49 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:49 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:49 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:49 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:49 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:49 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:50 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:50 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:50 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:50 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:50 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:50 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:50 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:50 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:50 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:51 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:51 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:51 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:51 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:51 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:51 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:51 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:51 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:51 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:51 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:52 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:52 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:52 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:52 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:52 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:52 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:52 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:52 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:52 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:52 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:52 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:52 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:52 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:52 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:52 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:52 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:52 --> Database Driver Class Initialized
INFO - 2016-10-10 09:50:52 --> Database Driver Class Initialized
DEBUG - 2016-10-10 09:50:52 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 09:50:52 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 09:50:52 --> Final output sent to browser
DEBUG - 2016-10-10 09:50:52 --> Total execution time: 6.3563
INFO - 2016-10-10 09:51:14 --> Config Class Initialized
INFO - 2016-10-10 09:51:14 --> Hooks Class Initialized
DEBUG - 2016-10-10 09:51:14 --> UTF-8 Support Enabled
INFO - 2016-10-10 09:51:14 --> Utf8 Class Initialized
INFO - 2016-10-10 09:51:14 --> URI Class Initialized
INFO - 2016-10-10 09:51:14 --> Router Class Initialized
INFO - 2016-10-10 09:51:14 --> Output Class Initialized
INFO - 2016-10-10 09:51:14 --> Security Class Initialized
DEBUG - 2016-10-10 09:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 09:51:14 --> Input Class Initialized
INFO - 2016-10-10 09:51:14 --> Language Class Initialized
INFO - 2016-10-10 09:51:14 --> Language Class Initialized
INFO - 2016-10-10 09:51:14 --> Config Class Initialized
INFO - 2016-10-10 09:51:14 --> Loader Class Initialized
INFO - 2016-10-10 09:51:14 --> Helper loaded: url_helper
INFO - 2016-10-10 09:51:14 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 09:51:14 --> Controller Class Initialized
DEBUG - 2016-10-10 09:51:15 --> Index MX_Controller Initialized
INFO - 2016-10-10 09:51:15 --> Model Class Initialized
INFO - 2016-10-10 09:51:15 --> Model Class Initialized
ERROR - 2016-10-10 09:51:15 --> Unable to delete cache file for admin/index/data/anggota/umum
DEBUG - 2016-10-10 09:51:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 09:51:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 09:51:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 09:51:15 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-10 09:51:15 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-10 09:51:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-10 09:51:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 09:51:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 09:51:15 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:15 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:15 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:15 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:15 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:15 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:15 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:15 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:15 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:15 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:15 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:15 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:15 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:15 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:15 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:15 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:15 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:15 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:15 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:16 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:17 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:17 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:17 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:17 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:17 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:17 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:17 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:17 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:17 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:17 --> Database Driver Class Initialized
INFO - 2016-10-10 09:51:17 --> Database Driver Class Initialized
DEBUG - 2016-10-10 09:51:17 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 09:51:17 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 09:51:17 --> Final output sent to browser
DEBUG - 2016-10-10 09:51:17 --> Total execution time: 3.1159
INFO - 2016-10-10 09:58:53 --> Config Class Initialized
INFO - 2016-10-10 09:58:53 --> Hooks Class Initialized
DEBUG - 2016-10-10 09:58:53 --> UTF-8 Support Enabled
INFO - 2016-10-10 09:58:53 --> Utf8 Class Initialized
INFO - 2016-10-10 09:58:53 --> URI Class Initialized
INFO - 2016-10-10 09:58:54 --> Router Class Initialized
INFO - 2016-10-10 09:58:54 --> Output Class Initialized
INFO - 2016-10-10 09:58:54 --> Security Class Initialized
DEBUG - 2016-10-10 09:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 09:58:54 --> Input Class Initialized
INFO - 2016-10-10 09:58:54 --> Language Class Initialized
INFO - 2016-10-10 09:58:54 --> Language Class Initialized
INFO - 2016-10-10 09:58:54 --> Config Class Initialized
INFO - 2016-10-10 09:58:54 --> Loader Class Initialized
INFO - 2016-10-10 09:58:54 --> Helper loaded: url_helper
INFO - 2016-10-10 09:58:54 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 09:58:54 --> Controller Class Initialized
DEBUG - 2016-10-10 09:58:54 --> Index MX_Controller Initialized
INFO - 2016-10-10 09:58:54 --> Model Class Initialized
INFO - 2016-10-10 09:58:54 --> Model Class Initialized
ERROR - 2016-10-10 09:58:54 --> Unable to delete cache file for admin/index/data/anggota/umum
DEBUG - 2016-10-10 09:58:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 09:58:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 09:58:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 09:58:54 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-10 09:58:54 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-10 09:58:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-10 09:58:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 09:58:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 09:58:54 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:54 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:54 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:54 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:54 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:54 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:54 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:54 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:54 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:55 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:55 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:55 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:55 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:55 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:55 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:55 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:55 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:55 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:55 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:55 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:55 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:55 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:55 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:55 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:55 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:55 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:55 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:55 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:55 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:55 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:55 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:55 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:55 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:55 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:55 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:55 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:55 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:55 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:55 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:56 --> Database Driver Class Initialized
INFO - 2016-10-10 09:58:56 --> Database Driver Class Initialized
DEBUG - 2016-10-10 09:58:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 09:58:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 09:58:56 --> Final output sent to browser
DEBUG - 2016-10-10 09:58:56 --> Total execution time: 2.9609
INFO - 2016-10-10 09:59:17 --> Config Class Initialized
INFO - 2016-10-10 09:59:17 --> Hooks Class Initialized
DEBUG - 2016-10-10 09:59:17 --> UTF-8 Support Enabled
INFO - 2016-10-10 09:59:17 --> Utf8 Class Initialized
INFO - 2016-10-10 09:59:17 --> URI Class Initialized
INFO - 2016-10-10 09:59:17 --> Router Class Initialized
INFO - 2016-10-10 09:59:17 --> Output Class Initialized
INFO - 2016-10-10 09:59:17 --> Security Class Initialized
DEBUG - 2016-10-10 09:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 09:59:17 --> Input Class Initialized
INFO - 2016-10-10 09:59:17 --> Language Class Initialized
INFO - 2016-10-10 09:59:17 --> Language Class Initialized
INFO - 2016-10-10 09:59:17 --> Config Class Initialized
INFO - 2016-10-10 09:59:17 --> Loader Class Initialized
INFO - 2016-10-10 09:59:17 --> Helper loaded: url_helper
INFO - 2016-10-10 09:59:17 --> Database Driver Class Initialized
INFO - 2016-10-10 09:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 09:59:17 --> Controller Class Initialized
DEBUG - 2016-10-10 09:59:17 --> Index MX_Controller Initialized
INFO - 2016-10-10 09:59:18 --> Model Class Initialized
INFO - 2016-10-10 09:59:18 --> Model Class Initialized
ERROR - 2016-10-10 09:59:18 --> Unable to delete cache file for admin/index/post_get/anggota/da4b9237bacccdf19c0760cab7aec4a8359010b0
DEBUG - 2016-10-10 09:59:18 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-10 09:59:18 --> Users MX_Controller Initialized
INFO - 2016-10-10 09:59:18 --> Final output sent to browser
DEBUG - 2016-10-10 09:59:18 --> Total execution time: 1.0045
INFO - 2016-10-10 09:59:31 --> Config Class Initialized
INFO - 2016-10-10 09:59:31 --> Hooks Class Initialized
DEBUG - 2016-10-10 09:59:31 --> UTF-8 Support Enabled
INFO - 2016-10-10 09:59:31 --> Utf8 Class Initialized
INFO - 2016-10-10 09:59:31 --> URI Class Initialized
INFO - 2016-10-10 09:59:31 --> Router Class Initialized
INFO - 2016-10-10 09:59:31 --> Output Class Initialized
INFO - 2016-10-10 09:59:31 --> Security Class Initialized
DEBUG - 2016-10-10 09:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 09:59:31 --> Input Class Initialized
INFO - 2016-10-10 09:59:31 --> Language Class Initialized
INFO - 2016-10-10 09:59:31 --> Language Class Initialized
INFO - 2016-10-10 09:59:31 --> Config Class Initialized
INFO - 2016-10-10 09:59:31 --> Loader Class Initialized
INFO - 2016-10-10 09:59:31 --> Helper loaded: url_helper
INFO - 2016-10-10 09:59:32 --> Database Driver Class Initialized
INFO - 2016-10-10 09:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 09:59:32 --> Controller Class Initialized
DEBUG - 2016-10-10 09:59:32 --> Index MX_Controller Initialized
INFO - 2016-10-10 09:59:32 --> Model Class Initialized
INFO - 2016-10-10 09:59:32 --> Model Class Initialized
ERROR - 2016-10-10 09:59:32 --> Unable to delete cache file for admin/index/post_update/anggota
DEBUG - 2016-10-10 09:59:32 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-10 09:59:32 --> Users MX_Controller Initialized
INFO - 2016-10-10 09:59:32 --> Final output sent to browser
DEBUG - 2016-10-10 09:59:32 --> Total execution time: 0.8540
INFO - 2016-10-10 10:08:05 --> Config Class Initialized
INFO - 2016-10-10 10:08:05 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:08:05 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:08:05 --> Utf8 Class Initialized
INFO - 2016-10-10 10:08:05 --> URI Class Initialized
INFO - 2016-10-10 10:08:05 --> Router Class Initialized
INFO - 2016-10-10 10:08:05 --> Output Class Initialized
INFO - 2016-10-10 10:08:05 --> Security Class Initialized
DEBUG - 2016-10-10 10:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:08:05 --> Input Class Initialized
INFO - 2016-10-10 10:08:05 --> Language Class Initialized
INFO - 2016-10-10 10:08:05 --> Language Class Initialized
INFO - 2016-10-10 10:08:05 --> Config Class Initialized
INFO - 2016-10-10 10:08:05 --> Loader Class Initialized
INFO - 2016-10-10 10:08:05 --> Helper loaded: url_helper
INFO - 2016-10-10 10:08:05 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:08:05 --> Controller Class Initialized
DEBUG - 2016-10-10 10:08:05 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:08:06 --> Model Class Initialized
INFO - 2016-10-10 10:08:06 --> Model Class Initialized
ERROR - 2016-10-10 10:08:06 --> Unable to delete cache file for admin/index/detail_pinjaman/f1f836cb4ea6efb2a0b1b99f41ad8b103eff4b59
DEBUG - 2016-10-10 10:08:06 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/subcontent/data_transaksi.php
INFO - 2016-10-10 10:08:06 --> Final output sent to browser
DEBUG - 2016-10-10 10:08:06 --> Total execution time: 0.9791
INFO - 2016-10-10 10:08:21 --> Config Class Initialized
INFO - 2016-10-10 10:08:21 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:08:21 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:08:21 --> Utf8 Class Initialized
INFO - 2016-10-10 10:08:21 --> URI Class Initialized
INFO - 2016-10-10 10:08:21 --> Router Class Initialized
INFO - 2016-10-10 10:08:21 --> Output Class Initialized
INFO - 2016-10-10 10:08:21 --> Security Class Initialized
DEBUG - 2016-10-10 10:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:08:22 --> Input Class Initialized
INFO - 2016-10-10 10:08:22 --> Language Class Initialized
INFO - 2016-10-10 10:08:22 --> Language Class Initialized
INFO - 2016-10-10 10:08:22 --> Config Class Initialized
INFO - 2016-10-10 10:08:22 --> Loader Class Initialized
INFO - 2016-10-10 10:08:22 --> Helper loaded: url_helper
INFO - 2016-10-10 10:08:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:08:22 --> Controller Class Initialized
DEBUG - 2016-10-10 10:08:22 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:08:22 --> Model Class Initialized
INFO - 2016-10-10 10:08:22 --> Model Class Initialized
ERROR - 2016-10-10 10:08:22 --> Unable to delete cache file for admin/index/add/anggota
DEBUG - 2016-10-10 10:08:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 10:08:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 10:08:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 10:08:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_anggota.php
DEBUG - 2016-10-10 10:08:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 10:08:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 10:08:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:24 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:24 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:24 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:24 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:24 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:24 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:24 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:24 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:24 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:24 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:24 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:24 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:24 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:24 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:24 --> Database Driver Class Initialized
INFO - 2016-10-10 10:08:24 --> Database Driver Class Initialized
DEBUG - 2016-10-10 10:08:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 10:08:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 10:08:24 --> Final output sent to browser
DEBUG - 2016-10-10 10:08:24 --> Total execution time: 2.9091
INFO - 2016-10-10 10:09:09 --> Config Class Initialized
INFO - 2016-10-10 10:09:09 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:09:09 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:09:09 --> Utf8 Class Initialized
INFO - 2016-10-10 10:09:09 --> URI Class Initialized
INFO - 2016-10-10 10:09:09 --> Router Class Initialized
INFO - 2016-10-10 10:09:09 --> Output Class Initialized
INFO - 2016-10-10 10:09:09 --> Security Class Initialized
DEBUG - 2016-10-10 10:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:09:09 --> Input Class Initialized
INFO - 2016-10-10 10:09:09 --> Language Class Initialized
INFO - 2016-10-10 10:09:09 --> Language Class Initialized
INFO - 2016-10-10 10:09:09 --> Config Class Initialized
INFO - 2016-10-10 10:09:09 --> Loader Class Initialized
INFO - 2016-10-10 10:09:09 --> Helper loaded: url_helper
INFO - 2016-10-10 10:09:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:09:09 --> Controller Class Initialized
DEBUG - 2016-10-10 10:09:09 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:09:09 --> Model Class Initialized
INFO - 2016-10-10 10:09:09 --> Model Class Initialized
ERROR - 2016-10-10 10:09:09 --> Unable to delete cache file for admin/index/add/anggota
DEBUG - 2016-10-10 10:09:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 10:09:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 10:09:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 10:09:10 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_anggota.php
DEBUG - 2016-10-10 10:09:10 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 10:09:10 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 10:09:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:11 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:11 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:11 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:11 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:11 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:11 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:11 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:11 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:11 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:11 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:11 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:11 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:11 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:11 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:11 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:11 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:11 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:11 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:11 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:11 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:11 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:11 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:11 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:11 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:11 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:11 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:11 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:11 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:12 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:12 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:12 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:12 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:12 --> Database Driver Class Initialized
DEBUG - 2016-10-10 10:09:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 10:09:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 10:09:12 --> Final output sent to browser
DEBUG - 2016-10-10 10:09:12 --> Total execution time: 2.9803
INFO - 2016-10-10 10:09:35 --> Config Class Initialized
INFO - 2016-10-10 10:09:35 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:09:35 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:09:35 --> Utf8 Class Initialized
INFO - 2016-10-10 10:09:35 --> URI Class Initialized
INFO - 2016-10-10 10:09:36 --> Router Class Initialized
INFO - 2016-10-10 10:09:36 --> Output Class Initialized
INFO - 2016-10-10 10:09:36 --> Security Class Initialized
DEBUG - 2016-10-10 10:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:09:36 --> Input Class Initialized
INFO - 2016-10-10 10:09:36 --> Language Class Initialized
INFO - 2016-10-10 10:09:36 --> Language Class Initialized
INFO - 2016-10-10 10:09:36 --> Config Class Initialized
INFO - 2016-10-10 10:09:36 --> Loader Class Initialized
INFO - 2016-10-10 10:09:36 --> Helper loaded: url_helper
INFO - 2016-10-10 10:09:36 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:09:36 --> Controller Class Initialized
DEBUG - 2016-10-10 10:09:36 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:09:36 --> Model Class Initialized
INFO - 2016-10-10 10:09:36 --> Model Class Initialized
ERROR - 2016-10-10 10:09:36 --> Unable to delete cache file for admin/index/post_add
DEBUG - 2016-10-10 10:09:36 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-10 10:09:36 --> Users MX_Controller Initialized
DEBUG - 2016-10-10 10:09:36 --> Index MX_Controller Initialized
ERROR - 2016-10-10 10:09:36 --> Unable to delete cache file for admin/index/post_add
INFO - 2016-10-10 10:09:36 --> Database Driver Class Initialized
ERROR - 2016-10-10 10:09:36 --> Severity: Notice --> Object of class CI_DB_mysqli_result could not be converted to int E:\SERVER\htdocs\kops\application\modules\anggota\controllers\Anggota.php 43
INFO - 2016-10-10 10:09:36 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:36 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:36 --> Final output sent to browser
DEBUG - 2016-10-10 10:09:36 --> Total execution time: 1.0849
INFO - 2016-10-10 10:09:52 --> Config Class Initialized
INFO - 2016-10-10 10:09:52 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:09:52 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:09:53 --> Utf8 Class Initialized
INFO - 2016-10-10 10:09:53 --> URI Class Initialized
INFO - 2016-10-10 10:09:53 --> Router Class Initialized
INFO - 2016-10-10 10:09:53 --> Output Class Initialized
INFO - 2016-10-10 10:09:53 --> Security Class Initialized
DEBUG - 2016-10-10 10:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:09:53 --> Input Class Initialized
INFO - 2016-10-10 10:09:53 --> Language Class Initialized
INFO - 2016-10-10 10:09:53 --> Language Class Initialized
INFO - 2016-10-10 10:09:53 --> Config Class Initialized
INFO - 2016-10-10 10:09:53 --> Loader Class Initialized
INFO - 2016-10-10 10:09:53 --> Helper loaded: url_helper
INFO - 2016-10-10 10:09:53 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:09:53 --> Controller Class Initialized
DEBUG - 2016-10-10 10:09:53 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:09:53 --> Model Class Initialized
INFO - 2016-10-10 10:09:53 --> Model Class Initialized
ERROR - 2016-10-10 10:09:53 --> Unable to delete cache file for admin/index/post_add
DEBUG - 2016-10-10 10:09:53 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-10 10:09:53 --> Users MX_Controller Initialized
DEBUG - 2016-10-10 10:09:53 --> Index MX_Controller Initialized
ERROR - 2016-10-10 10:09:53 --> Unable to delete cache file for admin/index/post_add
INFO - 2016-10-10 10:09:53 --> Database Driver Class Initialized
INFO - 2016-10-10 10:09:53 --> Final output sent to browser
DEBUG - 2016-10-10 10:09:53 --> Total execution time: 0.8162
INFO - 2016-10-10 10:10:17 --> Config Class Initialized
INFO - 2016-10-10 10:10:18 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:10:18 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:10:18 --> Utf8 Class Initialized
INFO - 2016-10-10 10:10:18 --> URI Class Initialized
INFO - 2016-10-10 10:10:18 --> Router Class Initialized
INFO - 2016-10-10 10:10:18 --> Output Class Initialized
INFO - 2016-10-10 10:10:18 --> Security Class Initialized
DEBUG - 2016-10-10 10:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:10:18 --> Input Class Initialized
INFO - 2016-10-10 10:10:18 --> Language Class Initialized
INFO - 2016-10-10 10:10:18 --> Language Class Initialized
INFO - 2016-10-10 10:10:18 --> Config Class Initialized
INFO - 2016-10-10 10:10:18 --> Loader Class Initialized
INFO - 2016-10-10 10:10:18 --> Helper loaded: url_helper
INFO - 2016-10-10 10:10:18 --> Database Driver Class Initialized
INFO - 2016-10-10 10:10:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:10:18 --> Controller Class Initialized
DEBUG - 2016-10-10 10:10:18 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:10:18 --> Model Class Initialized
INFO - 2016-10-10 10:10:18 --> Model Class Initialized
ERROR - 2016-10-10 10:10:18 --> Unable to delete cache file for admin/index/post_add
DEBUG - 2016-10-10 10:10:18 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-10 10:10:18 --> Users MX_Controller Initialized
DEBUG - 2016-10-10 10:10:18 --> Index MX_Controller Initialized
ERROR - 2016-10-10 10:10:18 --> Unable to delete cache file for admin/index/post_add
INFO - 2016-10-10 10:10:18 --> Database Driver Class Initialized
ERROR - 2016-10-10 10:10:18 --> Query error: Table 'koperasi.tm_anggotas' doesn't exist - Invalid query: SELECT *
FROM `tm_anggotas`
WHERE `no_identitas` = '123'
INFO - 2016-10-10 10:10:18 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-10 10:10:42 --> Config Class Initialized
INFO - 2016-10-10 10:10:42 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:10:42 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:10:42 --> Utf8 Class Initialized
INFO - 2016-10-10 10:10:42 --> URI Class Initialized
INFO - 2016-10-10 10:10:42 --> Router Class Initialized
INFO - 2016-10-10 10:10:42 --> Output Class Initialized
INFO - 2016-10-10 10:10:42 --> Security Class Initialized
DEBUG - 2016-10-10 10:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:10:42 --> Input Class Initialized
INFO - 2016-10-10 10:10:42 --> Language Class Initialized
INFO - 2016-10-10 10:10:42 --> Language Class Initialized
INFO - 2016-10-10 10:10:42 --> Config Class Initialized
INFO - 2016-10-10 10:10:42 --> Loader Class Initialized
INFO - 2016-10-10 10:10:42 --> Helper loaded: url_helper
INFO - 2016-10-10 10:10:42 --> Database Driver Class Initialized
INFO - 2016-10-10 10:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:10:42 --> Controller Class Initialized
DEBUG - 2016-10-10 10:10:42 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:10:42 --> Model Class Initialized
INFO - 2016-10-10 10:10:43 --> Model Class Initialized
ERROR - 2016-10-10 10:10:43 --> Unable to delete cache file for admin/index/post_add
DEBUG - 2016-10-10 10:10:43 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-10 10:10:43 --> Users MX_Controller Initialized
DEBUG - 2016-10-10 10:10:43 --> Index MX_Controller Initialized
ERROR - 2016-10-10 10:10:43 --> Unable to delete cache file for admin/index/post_add
INFO - 2016-10-10 10:10:43 --> Database Driver Class Initialized
ERROR - 2016-10-10 10:10:43 --> Query error: Table 'koperasi.tm_anggotas' doesn't exist - Invalid query: SELECT *
FROM `tm_anggotas`
WHERE `no_identitas` = '123'
INFO - 2016-10-10 10:10:43 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-10 10:11:09 --> Config Class Initialized
INFO - 2016-10-10 10:11:09 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:11:09 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:11:09 --> Utf8 Class Initialized
INFO - 2016-10-10 10:11:09 --> URI Class Initialized
INFO - 2016-10-10 10:11:09 --> Router Class Initialized
INFO - 2016-10-10 10:11:09 --> Output Class Initialized
INFO - 2016-10-10 10:11:09 --> Security Class Initialized
DEBUG - 2016-10-10 10:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:11:09 --> Input Class Initialized
INFO - 2016-10-10 10:11:09 --> Language Class Initialized
INFO - 2016-10-10 10:11:09 --> Language Class Initialized
INFO - 2016-10-10 10:11:09 --> Config Class Initialized
INFO - 2016-10-10 10:11:09 --> Loader Class Initialized
INFO - 2016-10-10 10:11:09 --> Helper loaded: url_helper
INFO - 2016-10-10 10:11:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:11:09 --> Controller Class Initialized
DEBUG - 2016-10-10 10:11:09 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:11:09 --> Model Class Initialized
INFO - 2016-10-10 10:11:09 --> Model Class Initialized
ERROR - 2016-10-10 10:11:09 --> Unable to delete cache file for admin/index/post_add
DEBUG - 2016-10-10 10:11:09 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-10 10:11:09 --> Users MX_Controller Initialized
DEBUG - 2016-10-10 10:11:09 --> Index MX_Controller Initialized
ERROR - 2016-10-10 10:11:09 --> Unable to delete cache file for admin/index/post_add
INFO - 2016-10-10 10:11:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:11:09 --> Final output sent to browser
DEBUG - 2016-10-10 10:11:09 --> Total execution time: 0.8945
INFO - 2016-10-10 10:11:59 --> Config Class Initialized
INFO - 2016-10-10 10:11:59 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:11:59 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:11:59 --> Utf8 Class Initialized
INFO - 2016-10-10 10:11:59 --> URI Class Initialized
INFO - 2016-10-10 10:11:59 --> Router Class Initialized
INFO - 2016-10-10 10:11:59 --> Output Class Initialized
INFO - 2016-10-10 10:11:59 --> Security Class Initialized
DEBUG - 2016-10-10 10:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:11:59 --> Input Class Initialized
INFO - 2016-10-10 10:11:59 --> Language Class Initialized
INFO - 2016-10-10 10:12:00 --> Language Class Initialized
INFO - 2016-10-10 10:12:00 --> Config Class Initialized
INFO - 2016-10-10 10:12:00 --> Loader Class Initialized
INFO - 2016-10-10 10:12:00 --> Helper loaded: url_helper
INFO - 2016-10-10 10:12:00 --> Database Driver Class Initialized
INFO - 2016-10-10 10:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:12:00 --> Controller Class Initialized
DEBUG - 2016-10-10 10:12:00 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:12:00 --> Model Class Initialized
INFO - 2016-10-10 10:12:00 --> Model Class Initialized
ERROR - 2016-10-10 10:12:00 --> Unable to delete cache file for admin/index/post_add
DEBUG - 2016-10-10 10:12:00 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-10 10:12:00 --> Users MX_Controller Initialized
DEBUG - 2016-10-10 10:12:00 --> Index MX_Controller Initialized
ERROR - 2016-10-10 10:12:00 --> Unable to delete cache file for admin/index/post_add
INFO - 2016-10-10 10:12:00 --> Database Driver Class Initialized
INFO - 2016-10-10 10:12:00 --> Final output sent to browser
DEBUG - 2016-10-10 10:12:00 --> Total execution time: 0.8384
INFO - 2016-10-10 10:12:59 --> Config Class Initialized
INFO - 2016-10-10 10:12:59 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:12:59 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:12:59 --> Utf8 Class Initialized
INFO - 2016-10-10 10:12:59 --> URI Class Initialized
INFO - 2016-10-10 10:12:59 --> Router Class Initialized
INFO - 2016-10-10 10:12:59 --> Output Class Initialized
INFO - 2016-10-10 10:12:59 --> Security Class Initialized
DEBUG - 2016-10-10 10:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:13:00 --> Input Class Initialized
INFO - 2016-10-10 10:13:00 --> Language Class Initialized
INFO - 2016-10-10 10:13:00 --> Language Class Initialized
INFO - 2016-10-10 10:13:00 --> Config Class Initialized
INFO - 2016-10-10 10:13:00 --> Loader Class Initialized
INFO - 2016-10-10 10:13:00 --> Helper loaded: url_helper
INFO - 2016-10-10 10:13:00 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:13:00 --> Controller Class Initialized
DEBUG - 2016-10-10 10:13:00 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:13:00 --> Model Class Initialized
INFO - 2016-10-10 10:13:00 --> Model Class Initialized
ERROR - 2016-10-10 10:13:00 --> Unable to delete cache file for admin/index/post_add
DEBUG - 2016-10-10 10:13:00 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-10 10:13:00 --> Users MX_Controller Initialized
DEBUG - 2016-10-10 10:13:00 --> Index MX_Controller Initialized
ERROR - 2016-10-10 10:13:00 --> Unable to delete cache file for admin/index/post_add
INFO - 2016-10-10 10:13:00 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:00 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:00 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:00 --> Final output sent to browser
DEBUG - 2016-10-10 10:13:00 --> Total execution time: 1.1140
INFO - 2016-10-10 10:13:01 --> Config Class Initialized
INFO - 2016-10-10 10:13:01 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:13:01 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:13:01 --> Utf8 Class Initialized
INFO - 2016-10-10 10:13:01 --> URI Class Initialized
INFO - 2016-10-10 10:13:01 --> Router Class Initialized
INFO - 2016-10-10 10:13:01 --> Output Class Initialized
INFO - 2016-10-10 10:13:01 --> Security Class Initialized
DEBUG - 2016-10-10 10:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:13:01 --> Input Class Initialized
INFO - 2016-10-10 10:13:01 --> Language Class Initialized
INFO - 2016-10-10 10:13:01 --> Language Class Initialized
INFO - 2016-10-10 10:13:01 --> Config Class Initialized
INFO - 2016-10-10 10:13:01 --> Loader Class Initialized
INFO - 2016-10-10 10:13:01 --> Helper loaded: url_helper
INFO - 2016-10-10 10:13:01 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:13:01 --> Controller Class Initialized
DEBUG - 2016-10-10 10:13:01 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:13:01 --> Model Class Initialized
INFO - 2016-10-10 10:13:01 --> Model Class Initialized
ERROR - 2016-10-10 10:13:01 --> Unable to delete cache file for admin/index/data/anggota
DEBUG - 2016-10-10 10:13:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 10:13:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 10:13:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 10:13:02 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-10 10:13:02 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-10 10:13:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-10 10:13:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 10:13:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 10:13:02 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:02 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:02 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:02 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:02 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:02 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:02 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:02 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:02 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:02 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:02 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:02 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:02 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:02 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:02 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:02 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:02 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:02 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:02 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:03 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:03 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:03 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:03 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:03 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:03 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:03 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:03 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:03 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:03 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:03 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:03 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:03 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:03 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:03 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:03 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:03 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:03 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:03 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:03 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:03 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:03 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:03 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:03 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:03 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:04 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:04 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:04 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:04 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:04 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:04 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:04 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:04 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:04 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:04 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:04 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:04 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:04 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:04 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:04 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:04 --> Database Driver Class Initialized
DEBUG - 2016-10-10 10:13:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 10:13:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 10:13:04 --> Final output sent to browser
DEBUG - 2016-10-10 10:13:04 --> Total execution time: 3.7839
INFO - 2016-10-10 10:13:32 --> Config Class Initialized
INFO - 2016-10-10 10:13:32 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:13:32 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:13:32 --> Utf8 Class Initialized
INFO - 2016-10-10 10:13:32 --> URI Class Initialized
INFO - 2016-10-10 10:13:32 --> Router Class Initialized
INFO - 2016-10-10 10:13:32 --> Output Class Initialized
INFO - 2016-10-10 10:13:32 --> Security Class Initialized
DEBUG - 2016-10-10 10:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:13:32 --> Input Class Initialized
INFO - 2016-10-10 10:13:32 --> Language Class Initialized
INFO - 2016-10-10 10:13:32 --> Language Class Initialized
INFO - 2016-10-10 10:13:32 --> Config Class Initialized
INFO - 2016-10-10 10:13:32 --> Loader Class Initialized
INFO - 2016-10-10 10:13:32 --> Helper loaded: url_helper
INFO - 2016-10-10 10:13:32 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:13:32 --> Controller Class Initialized
DEBUG - 2016-10-10 10:13:32 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:13:32 --> Model Class Initialized
INFO - 2016-10-10 10:13:32 --> Model Class Initialized
ERROR - 2016-10-10 10:13:32 --> Unable to delete cache file for admin/index/data/anggota/umum
DEBUG - 2016-10-10 10:13:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 10:13:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 10:13:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 10:13:32 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-10 10:13:32 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-10 10:13:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-10 10:13:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 10:13:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 10:13:33 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:33 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:33 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:33 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:33 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:33 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:33 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:33 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:33 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:33 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:33 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:33 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:33 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:33 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:33 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:33 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:33 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:33 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:33 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:33 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:33 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:33 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:33 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:33 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:34 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:34 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:34 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:34 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:34 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:34 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:34 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:34 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:34 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:34 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:34 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:34 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:34 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:34 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:34 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:34 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:34 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:34 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:34 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:34 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:34 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:34 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:34 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:34 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:34 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:35 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:35 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:35 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:35 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:35 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:35 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:35 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:35 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:35 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:35 --> Database Driver Class Initialized
INFO - 2016-10-10 10:13:35 --> Database Driver Class Initialized
DEBUG - 2016-10-10 10:13:35 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 10:13:35 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 10:13:35 --> Final output sent to browser
DEBUG - 2016-10-10 10:13:35 --> Total execution time: 3.5120
INFO - 2016-10-10 10:14:09 --> Config Class Initialized
INFO - 2016-10-10 10:14:09 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:14:09 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:14:09 --> Utf8 Class Initialized
INFO - 2016-10-10 10:14:09 --> URI Class Initialized
INFO - 2016-10-10 10:14:09 --> Router Class Initialized
INFO - 2016-10-10 10:14:09 --> Output Class Initialized
INFO - 2016-10-10 10:14:09 --> Security Class Initialized
DEBUG - 2016-10-10 10:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:14:09 --> Input Class Initialized
INFO - 2016-10-10 10:14:09 --> Language Class Initialized
INFO - 2016-10-10 10:14:10 --> Language Class Initialized
INFO - 2016-10-10 10:14:10 --> Config Class Initialized
INFO - 2016-10-10 10:14:10 --> Loader Class Initialized
INFO - 2016-10-10 10:14:10 --> Helper loaded: url_helper
INFO - 2016-10-10 10:14:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:14:10 --> Controller Class Initialized
DEBUG - 2016-10-10 10:14:10 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:14:10 --> Model Class Initialized
INFO - 2016-10-10 10:14:10 --> Model Class Initialized
ERROR - 2016-10-10 10:14:10 --> Unable to delete cache file for admin/index/post_add
DEBUG - 2016-10-10 10:14:10 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-10 10:14:10 --> Users MX_Controller Initialized
DEBUG - 2016-10-10 10:14:10 --> Index MX_Controller Initialized
ERROR - 2016-10-10 10:14:10 --> Unable to delete cache file for admin/index/post_add
INFO - 2016-10-10 10:14:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:14:10 --> Final output sent to browser
DEBUG - 2016-10-10 10:14:10 --> Total execution time: 0.9383
INFO - 2016-10-10 10:14:34 --> Config Class Initialized
INFO - 2016-10-10 10:14:34 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:14:34 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:14:34 --> Utf8 Class Initialized
INFO - 2016-10-10 10:14:34 --> URI Class Initialized
INFO - 2016-10-10 10:14:34 --> Router Class Initialized
INFO - 2016-10-10 10:14:34 --> Output Class Initialized
INFO - 2016-10-10 10:14:34 --> Security Class Initialized
DEBUG - 2016-10-10 10:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:14:34 --> Input Class Initialized
INFO - 2016-10-10 10:14:34 --> Language Class Initialized
INFO - 2016-10-10 10:14:34 --> Language Class Initialized
INFO - 2016-10-10 10:14:34 --> Config Class Initialized
INFO - 2016-10-10 10:14:34 --> Loader Class Initialized
INFO - 2016-10-10 10:14:34 --> Helper loaded: url_helper
INFO - 2016-10-10 10:14:34 --> Database Driver Class Initialized
INFO - 2016-10-10 10:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:14:34 --> Controller Class Initialized
DEBUG - 2016-10-10 10:14:34 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:14:34 --> Model Class Initialized
INFO - 2016-10-10 10:14:34 --> Model Class Initialized
ERROR - 2016-10-10 10:14:34 --> Unable to delete cache file for admin/index/post_add
DEBUG - 2016-10-10 10:14:34 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-10 10:14:34 --> Users MX_Controller Initialized
DEBUG - 2016-10-10 10:14:35 --> Index MX_Controller Initialized
ERROR - 2016-10-10 10:14:35 --> Unable to delete cache file for admin/index/post_add
INFO - 2016-10-10 10:14:35 --> Database Driver Class Initialized
INFO - 2016-10-10 10:14:35 --> Final output sent to browser
DEBUG - 2016-10-10 10:14:35 --> Total execution time: 0.8557
INFO - 2016-10-10 10:15:13 --> Config Class Initialized
INFO - 2016-10-10 10:15:13 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:15:13 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:15:13 --> Utf8 Class Initialized
INFO - 2016-10-10 10:15:13 --> URI Class Initialized
INFO - 2016-10-10 10:15:13 --> Router Class Initialized
INFO - 2016-10-10 10:15:13 --> Output Class Initialized
INFO - 2016-10-10 10:15:13 --> Security Class Initialized
DEBUG - 2016-10-10 10:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:15:13 --> Input Class Initialized
INFO - 2016-10-10 10:15:13 --> Language Class Initialized
INFO - 2016-10-10 10:15:13 --> Language Class Initialized
INFO - 2016-10-10 10:15:13 --> Config Class Initialized
INFO - 2016-10-10 10:15:13 --> Loader Class Initialized
INFO - 2016-10-10 10:15:13 --> Helper loaded: url_helper
INFO - 2016-10-10 10:15:14 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:15:14 --> Controller Class Initialized
DEBUG - 2016-10-10 10:15:14 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:15:14 --> Model Class Initialized
INFO - 2016-10-10 10:15:14 --> Model Class Initialized
ERROR - 2016-10-10 10:15:14 --> Unable to delete cache file for admin/index/post_add
DEBUG - 2016-10-10 10:15:14 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-10 10:15:14 --> Users MX_Controller Initialized
DEBUG - 2016-10-10 10:15:14 --> Index MX_Controller Initialized
ERROR - 2016-10-10 10:15:14 --> Unable to delete cache file for admin/index/post_add
INFO - 2016-10-10 10:15:14 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:14 --> Final output sent to browser
DEBUG - 2016-10-10 10:15:14 --> Total execution time: 0.8831
INFO - 2016-10-10 10:15:23 --> Config Class Initialized
INFO - 2016-10-10 10:15:23 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:15:23 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:15:23 --> Utf8 Class Initialized
INFO - 2016-10-10 10:15:23 --> URI Class Initialized
INFO - 2016-10-10 10:15:23 --> Router Class Initialized
INFO - 2016-10-10 10:15:23 --> Output Class Initialized
INFO - 2016-10-10 10:15:23 --> Security Class Initialized
DEBUG - 2016-10-10 10:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:15:23 --> Input Class Initialized
INFO - 2016-10-10 10:15:23 --> Language Class Initialized
INFO - 2016-10-10 10:15:23 --> Language Class Initialized
INFO - 2016-10-10 10:15:23 --> Config Class Initialized
INFO - 2016-10-10 10:15:23 --> Loader Class Initialized
INFO - 2016-10-10 10:15:23 --> Helper loaded: url_helper
INFO - 2016-10-10 10:15:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:15:23 --> Controller Class Initialized
DEBUG - 2016-10-10 10:15:23 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:15:23 --> Model Class Initialized
INFO - 2016-10-10 10:15:23 --> Model Class Initialized
ERROR - 2016-10-10 10:15:23 --> Unable to delete cache file for admin/index/post_add
DEBUG - 2016-10-10 10:15:23 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-10 10:15:23 --> Users MX_Controller Initialized
DEBUG - 2016-10-10 10:15:24 --> Index MX_Controller Initialized
ERROR - 2016-10-10 10:15:24 --> Unable to delete cache file for admin/index/post_add
INFO - 2016-10-10 10:15:24 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:24 --> Final output sent to browser
DEBUG - 2016-10-10 10:15:24 --> Total execution time: 1.0106
INFO - 2016-10-10 10:15:29 --> Config Class Initialized
INFO - 2016-10-10 10:15:30 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:15:30 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:15:30 --> Utf8 Class Initialized
INFO - 2016-10-10 10:15:30 --> URI Class Initialized
INFO - 2016-10-10 10:15:30 --> Router Class Initialized
INFO - 2016-10-10 10:15:30 --> Output Class Initialized
INFO - 2016-10-10 10:15:30 --> Security Class Initialized
DEBUG - 2016-10-10 10:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:15:30 --> Input Class Initialized
INFO - 2016-10-10 10:15:30 --> Language Class Initialized
INFO - 2016-10-10 10:15:30 --> Language Class Initialized
INFO - 2016-10-10 10:15:30 --> Config Class Initialized
INFO - 2016-10-10 10:15:30 --> Loader Class Initialized
INFO - 2016-10-10 10:15:30 --> Helper loaded: url_helper
INFO - 2016-10-10 10:15:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:15:30 --> Controller Class Initialized
DEBUG - 2016-10-10 10:15:30 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:15:30 --> Model Class Initialized
INFO - 2016-10-10 10:15:30 --> Model Class Initialized
ERROR - 2016-10-10 10:15:30 --> Unable to delete cache file for admin/index/post_add
DEBUG - 2016-10-10 10:15:30 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-10 10:15:30 --> Users MX_Controller Initialized
DEBUG - 2016-10-10 10:15:30 --> Index MX_Controller Initialized
ERROR - 2016-10-10 10:15:30 --> Unable to delete cache file for admin/index/post_add
INFO - 2016-10-10 10:15:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:30 --> Final output sent to browser
DEBUG - 2016-10-10 10:15:30 --> Total execution time: 0.8273
INFO - 2016-10-10 10:15:30 --> Config Class Initialized
INFO - 2016-10-10 10:15:31 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:15:31 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:15:31 --> Utf8 Class Initialized
INFO - 2016-10-10 10:15:31 --> URI Class Initialized
INFO - 2016-10-10 10:15:31 --> Router Class Initialized
INFO - 2016-10-10 10:15:31 --> Output Class Initialized
INFO - 2016-10-10 10:15:31 --> Security Class Initialized
DEBUG - 2016-10-10 10:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:15:31 --> Input Class Initialized
INFO - 2016-10-10 10:15:31 --> Language Class Initialized
INFO - 2016-10-10 10:15:31 --> Language Class Initialized
INFO - 2016-10-10 10:15:31 --> Config Class Initialized
INFO - 2016-10-10 10:15:31 --> Loader Class Initialized
INFO - 2016-10-10 10:15:31 --> Helper loaded: url_helper
INFO - 2016-10-10 10:15:31 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:15:31 --> Controller Class Initialized
DEBUG - 2016-10-10 10:15:31 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:15:31 --> Model Class Initialized
INFO - 2016-10-10 10:15:31 --> Model Class Initialized
ERROR - 2016-10-10 10:15:31 --> Unable to delete cache file for admin/index/data/anggota
DEBUG - 2016-10-10 10:15:31 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 10:15:31 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 10:15:31 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 10:15:31 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-10 10:15:31 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-10 10:15:31 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-10 10:15:31 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 10:15:31 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 10:15:31 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:32 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:32 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:32 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:32 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:32 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:32 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:32 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:32 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:32 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:32 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:32 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:32 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:32 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:32 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:32 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:32 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:32 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:32 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:32 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:32 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:32 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:32 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:32 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:32 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:32 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:32 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:33 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:33 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:33 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:33 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:33 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:33 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:33 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:33 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:33 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:33 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:33 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:33 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:33 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:33 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:33 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:33 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:33 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:33 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:33 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:34 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:34 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:34 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:34 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:34 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:34 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:34 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:34 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:34 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:34 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:34 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:34 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:34 --> Database Driver Class Initialized
INFO - 2016-10-10 10:15:34 --> Database Driver Class Initialized
DEBUG - 2016-10-10 10:15:34 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 10:15:34 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 10:15:34 --> Final output sent to browser
DEBUG - 2016-10-10 10:15:34 --> Total execution time: 3.8594
INFO - 2016-10-10 10:16:24 --> Config Class Initialized
INFO - 2016-10-10 10:16:24 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:16:24 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:16:24 --> Utf8 Class Initialized
INFO - 2016-10-10 10:16:24 --> URI Class Initialized
INFO - 2016-10-10 10:16:24 --> Router Class Initialized
INFO - 2016-10-10 10:16:24 --> Output Class Initialized
INFO - 2016-10-10 10:16:24 --> Security Class Initialized
DEBUG - 2016-10-10 10:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:16:24 --> Input Class Initialized
INFO - 2016-10-10 10:16:24 --> Language Class Initialized
INFO - 2016-10-10 10:16:24 --> Language Class Initialized
INFO - 2016-10-10 10:16:25 --> Config Class Initialized
INFO - 2016-10-10 10:16:25 --> Loader Class Initialized
INFO - 2016-10-10 10:16:25 --> Helper loaded: url_helper
INFO - 2016-10-10 10:16:25 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:16:25 --> Controller Class Initialized
DEBUG - 2016-10-10 10:16:25 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:16:25 --> Model Class Initialized
INFO - 2016-10-10 10:16:25 --> Model Class Initialized
ERROR - 2016-10-10 10:16:25 --> Unable to delete cache file for admin/index/data/user
DEBUG - 2016-10-10 10:16:25 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 10:16:25 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 10:16:25 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 10:16:25 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/user/controllers/Users.php
DEBUG - 2016-10-10 10:16:25 --> Users MX_Controller Initialized
DEBUG - 2016-10-10 10:16:25 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_user.php
DEBUG - 2016-10-10 10:16:25 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 10:16:25 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 10:16:25 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:25 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:25 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:25 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:25 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:25 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:25 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:25 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:25 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:25 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:28 --> Config Class Initialized
INFO - 2016-10-10 10:16:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:28 --> Hooks Class Initialized
INFO - 2016-10-10 10:16:28 --> Database Driver Class Initialized
DEBUG - 2016-10-10 10:16:28 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:16:28 --> Utf8 Class Initialized
INFO - 2016-10-10 10:16:28 --> URI Class Initialized
INFO - 2016-10-10 10:16:28 --> Router Class Initialized
DEBUG - 2016-10-10 10:16:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 10:16:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 10:16:28 --> Output Class Initialized
INFO - 2016-10-10 10:16:28 --> Final output sent to browser
DEBUG - 2016-10-10 10:16:28 --> Total execution time: 3.9724
INFO - 2016-10-10 10:16:28 --> Security Class Initialized
DEBUG - 2016-10-10 10:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:16:28 --> Input Class Initialized
INFO - 2016-10-10 10:16:28 --> Language Class Initialized
INFO - 2016-10-10 10:16:28 --> Language Class Initialized
INFO - 2016-10-10 10:16:28 --> Config Class Initialized
INFO - 2016-10-10 10:16:28 --> Loader Class Initialized
INFO - 2016-10-10 10:16:28 --> Helper loaded: url_helper
INFO - 2016-10-10 10:16:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:16:28 --> Controller Class Initialized
DEBUG - 2016-10-10 10:16:28 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:16:28 --> Model Class Initialized
INFO - 2016-10-10 10:16:28 --> Model Class Initialized
ERROR - 2016-10-10 10:16:29 --> Unable to delete cache file for admin/index/add/anggota
DEBUG - 2016-10-10 10:16:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 10:16:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 10:16:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 10:16:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_anggota.php
DEBUG - 2016-10-10 10:16:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 10:16:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 10:16:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:31 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:31 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:31 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:31 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:31 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:31 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:31 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:31 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:31 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:31 --> Database Driver Class Initialized
INFO - 2016-10-10 10:16:31 --> Database Driver Class Initialized
DEBUG - 2016-10-10 10:16:31 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 10:16:31 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 10:16:31 --> Final output sent to browser
DEBUG - 2016-10-10 10:16:31 --> Total execution time: 3.1630
INFO - 2016-10-10 10:16:59 --> Config Class Initialized
INFO - 2016-10-10 10:16:59 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:16:59 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:16:59 --> Utf8 Class Initialized
INFO - 2016-10-10 10:16:59 --> URI Class Initialized
INFO - 2016-10-10 10:16:59 --> Router Class Initialized
INFO - 2016-10-10 10:16:59 --> Output Class Initialized
INFO - 2016-10-10 10:17:00 --> Security Class Initialized
DEBUG - 2016-10-10 10:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:17:00 --> Input Class Initialized
INFO - 2016-10-10 10:17:00 --> Language Class Initialized
INFO - 2016-10-10 10:17:00 --> Language Class Initialized
INFO - 2016-10-10 10:17:00 --> Config Class Initialized
INFO - 2016-10-10 10:17:00 --> Loader Class Initialized
INFO - 2016-10-10 10:17:00 --> Helper loaded: url_helper
INFO - 2016-10-10 10:17:00 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:17:00 --> Controller Class Initialized
DEBUG - 2016-10-10 10:17:00 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:17:00 --> Model Class Initialized
INFO - 2016-10-10 10:17:00 --> Model Class Initialized
ERROR - 2016-10-10 10:17:00 --> Unable to delete cache file for admin/index/post_add
DEBUG - 2016-10-10 10:17:00 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-10 10:17:00 --> Users MX_Controller Initialized
DEBUG - 2016-10-10 10:17:00 --> Index MX_Controller Initialized
ERROR - 2016-10-10 10:17:00 --> Unable to delete cache file for admin/index/post_add
INFO - 2016-10-10 10:17:00 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:00 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:00 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:00 --> Final output sent to browser
DEBUG - 2016-10-10 10:17:00 --> Total execution time: 1.1246
INFO - 2016-10-10 10:17:00 --> Config Class Initialized
INFO - 2016-10-10 10:17:01 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:17:01 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:17:01 --> Utf8 Class Initialized
INFO - 2016-10-10 10:17:01 --> URI Class Initialized
INFO - 2016-10-10 10:17:01 --> Router Class Initialized
INFO - 2016-10-10 10:17:01 --> Output Class Initialized
INFO - 2016-10-10 10:17:01 --> Security Class Initialized
DEBUG - 2016-10-10 10:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:17:01 --> Input Class Initialized
INFO - 2016-10-10 10:17:01 --> Language Class Initialized
INFO - 2016-10-10 10:17:01 --> Language Class Initialized
INFO - 2016-10-10 10:17:01 --> Config Class Initialized
INFO - 2016-10-10 10:17:01 --> Loader Class Initialized
INFO - 2016-10-10 10:17:01 --> Helper loaded: url_helper
INFO - 2016-10-10 10:17:01 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:17:01 --> Controller Class Initialized
DEBUG - 2016-10-10 10:17:01 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:17:01 --> Model Class Initialized
INFO - 2016-10-10 10:17:01 --> Model Class Initialized
ERROR - 2016-10-10 10:17:01 --> Unable to delete cache file for admin/index/data/anggota
DEBUG - 2016-10-10 10:17:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 10:17:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 10:17:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 10:17:01 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-10 10:17:01 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-10 10:17:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-10 10:17:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 10:17:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 10:17:02 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:02 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:02 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:02 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:02 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:02 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:02 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:02 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:02 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:02 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:02 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:02 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:02 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:02 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:02 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:02 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:02 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:02 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:02 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:02 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:02 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:02 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:02 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:03 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:03 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:03 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:03 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:03 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:03 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:03 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:03 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:03 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:03 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:03 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:03 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:03 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:03 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:03 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:03 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:03 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:03 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:03 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:03 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:04 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:04 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:04 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:04 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:04 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:04 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:04 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:04 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:04 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:04 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:04 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:04 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:04 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:04 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:04 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:04 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:04 --> Database Driver Class Initialized
DEBUG - 2016-10-10 10:17:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 10:17:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 10:17:04 --> Final output sent to browser
DEBUG - 2016-10-10 10:17:04 --> Total execution time: 3.8829
INFO - 2016-10-10 10:17:15 --> Config Class Initialized
INFO - 2016-10-10 10:17:15 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:17:16 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:17:16 --> Utf8 Class Initialized
INFO - 2016-10-10 10:17:16 --> URI Class Initialized
INFO - 2016-10-10 10:17:16 --> Router Class Initialized
INFO - 2016-10-10 10:17:16 --> Output Class Initialized
INFO - 2016-10-10 10:17:16 --> Security Class Initialized
DEBUG - 2016-10-10 10:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:17:16 --> Input Class Initialized
INFO - 2016-10-10 10:17:16 --> Language Class Initialized
INFO - 2016-10-10 10:17:16 --> Language Class Initialized
INFO - 2016-10-10 10:17:16 --> Config Class Initialized
INFO - 2016-10-10 10:17:16 --> Loader Class Initialized
INFO - 2016-10-10 10:17:16 --> Helper loaded: url_helper
INFO - 2016-10-10 10:17:16 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:17:16 --> Controller Class Initialized
DEBUG - 2016-10-10 10:17:16 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:17:16 --> Model Class Initialized
INFO - 2016-10-10 10:17:16 --> Model Class Initialized
ERROR - 2016-10-10 10:17:16 --> Unable to delete cache file for admin/index/data/anggota/umum
DEBUG - 2016-10-10 10:17:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 10:17:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 10:17:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 10:17:16 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-10 10:17:16 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-10 10:17:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-10 10:17:17 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 10:17:17 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 10:17:17 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:17 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:17 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:17 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:17 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:17 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:17 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:17 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:17 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:17 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:17 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:17 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:17 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:17 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:17 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:17 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:17 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:17 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:17 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:17 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:18 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:18 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:18 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:18 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:18 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:18 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:18 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:18 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:18 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:18 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:18 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:18 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:18 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:18 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:18 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:18 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:18 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:18 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:18 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:18 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:18 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:18 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:18 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:19 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:19 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:19 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:19 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:19 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:19 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:19 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:19 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:19 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:19 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:19 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:19 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:19 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:19 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:19 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:19 --> Database Driver Class Initialized
INFO - 2016-10-10 10:17:19 --> Database Driver Class Initialized
DEBUG - 2016-10-10 10:17:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 10:17:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 10:17:19 --> Final output sent to browser
DEBUG - 2016-10-10 10:17:19 --> Total execution time: 3.8612
INFO - 2016-10-10 10:18:02 --> Config Class Initialized
INFO - 2016-10-10 10:18:02 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:18:02 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:18:02 --> Utf8 Class Initialized
INFO - 2016-10-10 10:18:02 --> URI Class Initialized
INFO - 2016-10-10 10:18:02 --> Router Class Initialized
INFO - 2016-10-10 10:18:02 --> Output Class Initialized
INFO - 2016-10-10 10:18:02 --> Security Class Initialized
DEBUG - 2016-10-10 10:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:18:02 --> Input Class Initialized
INFO - 2016-10-10 10:18:02 --> Language Class Initialized
INFO - 2016-10-10 10:18:02 --> Language Class Initialized
INFO - 2016-10-10 10:18:02 --> Config Class Initialized
INFO - 2016-10-10 10:18:02 --> Loader Class Initialized
INFO - 2016-10-10 10:18:02 --> Helper loaded: url_helper
INFO - 2016-10-10 10:18:02 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:18:02 --> Controller Class Initialized
DEBUG - 2016-10-10 10:18:02 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:18:02 --> Model Class Initialized
INFO - 2016-10-10 10:18:02 --> Model Class Initialized
ERROR - 2016-10-10 10:18:02 --> Unable to delete cache file for admin/index/post_del/anggota/da4b9237bacccdf19c0760cab7aec4a8359010b0
DEBUG - 2016-10-10 10:18:02 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-10 10:18:02 --> Users MX_Controller Initialized
INFO - 2016-10-10 10:18:02 --> Final output sent to browser
DEBUG - 2016-10-10 10:18:02 --> Total execution time: 0.8829
INFO - 2016-10-10 10:18:06 --> Config Class Initialized
INFO - 2016-10-10 10:18:06 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:18:06 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:18:06 --> Utf8 Class Initialized
INFO - 2016-10-10 10:18:06 --> URI Class Initialized
INFO - 2016-10-10 10:18:06 --> Router Class Initialized
INFO - 2016-10-10 10:18:06 --> Output Class Initialized
INFO - 2016-10-10 10:18:06 --> Security Class Initialized
DEBUG - 2016-10-10 10:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:18:06 --> Input Class Initialized
INFO - 2016-10-10 10:18:06 --> Language Class Initialized
INFO - 2016-10-10 10:18:06 --> Language Class Initialized
INFO - 2016-10-10 10:18:06 --> Config Class Initialized
INFO - 2016-10-10 10:18:06 --> Loader Class Initialized
INFO - 2016-10-10 10:18:06 --> Helper loaded: url_helper
INFO - 2016-10-10 10:18:06 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:18:07 --> Controller Class Initialized
DEBUG - 2016-10-10 10:18:07 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:18:07 --> Model Class Initialized
INFO - 2016-10-10 10:18:07 --> Model Class Initialized
ERROR - 2016-10-10 10:18:07 --> Unable to delete cache file for admin/index/post_del/anggota/1b6453892473a467d07372d45eb05abc2031647a
DEBUG - 2016-10-10 10:18:07 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-10 10:18:07 --> Users MX_Controller Initialized
INFO - 2016-10-10 10:18:07 --> Final output sent to browser
DEBUG - 2016-10-10 10:18:07 --> Total execution time: 0.8695
INFO - 2016-10-10 10:18:10 --> Config Class Initialized
INFO - 2016-10-10 10:18:11 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:18:11 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:18:11 --> Utf8 Class Initialized
INFO - 2016-10-10 10:18:11 --> URI Class Initialized
INFO - 2016-10-10 10:18:11 --> Router Class Initialized
INFO - 2016-10-10 10:18:11 --> Output Class Initialized
INFO - 2016-10-10 10:18:11 --> Security Class Initialized
DEBUG - 2016-10-10 10:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:18:11 --> Input Class Initialized
INFO - 2016-10-10 10:18:11 --> Language Class Initialized
INFO - 2016-10-10 10:18:11 --> Language Class Initialized
INFO - 2016-10-10 10:18:11 --> Config Class Initialized
INFO - 2016-10-10 10:18:11 --> Loader Class Initialized
INFO - 2016-10-10 10:18:11 --> Helper loaded: url_helper
INFO - 2016-10-10 10:18:11 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:18:11 --> Controller Class Initialized
DEBUG - 2016-10-10 10:18:11 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:18:11 --> Model Class Initialized
INFO - 2016-10-10 10:18:11 --> Model Class Initialized
ERROR - 2016-10-10 10:18:11 --> Unable to delete cache file for admin/index/data/anggota
DEBUG - 2016-10-10 10:18:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 10:18:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 10:18:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 10:18:11 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-10 10:18:11 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-10 10:18:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-10 10:18:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 10:18:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 10:18:11 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:12 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:12 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:12 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:12 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:12 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:12 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:12 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:12 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:12 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:12 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:12 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:12 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:12 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:12 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:12 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:12 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:12 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:12 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:12 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:12 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:13 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:13 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:13 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:13 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:13 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:13 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:13 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:13 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:13 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:13 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:13 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:13 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:13 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:13 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:13 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:13 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:13 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:13 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:13 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:13 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:13 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:13 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:13 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:13 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:13 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:14 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:14 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:14 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:14 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:14 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:14 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:14 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:14 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:14 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:14 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:14 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:14 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:14 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:14 --> Database Driver Class Initialized
DEBUG - 2016-10-10 10:18:14 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 10:18:14 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 10:18:14 --> Final output sent to browser
DEBUG - 2016-10-10 10:18:14 --> Total execution time: 3.6891
INFO - 2016-10-10 10:18:25 --> Config Class Initialized
INFO - 2016-10-10 10:18:25 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:18:25 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:18:26 --> Utf8 Class Initialized
INFO - 2016-10-10 10:18:26 --> URI Class Initialized
INFO - 2016-10-10 10:18:26 --> Router Class Initialized
INFO - 2016-10-10 10:18:26 --> Output Class Initialized
INFO - 2016-10-10 10:18:26 --> Security Class Initialized
DEBUG - 2016-10-10 10:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:18:26 --> Input Class Initialized
INFO - 2016-10-10 10:18:26 --> Language Class Initialized
INFO - 2016-10-10 10:18:26 --> Language Class Initialized
INFO - 2016-10-10 10:18:26 --> Config Class Initialized
INFO - 2016-10-10 10:18:26 --> Loader Class Initialized
INFO - 2016-10-10 10:18:26 --> Helper loaded: url_helper
INFO - 2016-10-10 10:18:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:18:26 --> Controller Class Initialized
DEBUG - 2016-10-10 10:18:26 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:18:26 --> Model Class Initialized
INFO - 2016-10-10 10:18:26 --> Model Class Initialized
ERROR - 2016-10-10 10:18:26 --> Unable to delete cache file for admin/index/add/anggota
DEBUG - 2016-10-10 10:18:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 10:18:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 10:18:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 10:18:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_anggota.php
DEBUG - 2016-10-10 10:18:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 10:18:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 10:18:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:18:29 --> Database Driver Class Initialized
DEBUG - 2016-10-10 10:18:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 10:18:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 10:18:29 --> Final output sent to browser
DEBUG - 2016-10-10 10:18:29 --> Total execution time: 3.8707
INFO - 2016-10-10 10:19:10 --> Config Class Initialized
INFO - 2016-10-10 10:19:10 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:19:10 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:19:10 --> Utf8 Class Initialized
INFO - 2016-10-10 10:19:10 --> URI Class Initialized
INFO - 2016-10-10 10:19:10 --> Router Class Initialized
INFO - 2016-10-10 10:19:10 --> Output Class Initialized
INFO - 2016-10-10 10:19:10 --> Security Class Initialized
DEBUG - 2016-10-10 10:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:19:10 --> Input Class Initialized
INFO - 2016-10-10 10:19:10 --> Language Class Initialized
INFO - 2016-10-10 10:19:10 --> Language Class Initialized
INFO - 2016-10-10 10:19:11 --> Config Class Initialized
INFO - 2016-10-10 10:19:11 --> Loader Class Initialized
INFO - 2016-10-10 10:19:11 --> Helper loaded: url_helper
INFO - 2016-10-10 10:19:11 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:19:11 --> Controller Class Initialized
DEBUG - 2016-10-10 10:19:11 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:19:11 --> Model Class Initialized
INFO - 2016-10-10 10:19:11 --> Model Class Initialized
ERROR - 2016-10-10 10:19:11 --> Unable to delete cache file for admin/index/post_add
DEBUG - 2016-10-10 10:19:11 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-10 10:19:11 --> Users MX_Controller Initialized
DEBUG - 2016-10-10 10:19:11 --> Index MX_Controller Initialized
ERROR - 2016-10-10 10:19:11 --> Unable to delete cache file for admin/index/post_add
INFO - 2016-10-10 10:19:11 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:11 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:11 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:11 --> Final output sent to browser
DEBUG - 2016-10-10 10:19:11 --> Total execution time: 1.1677
INFO - 2016-10-10 10:19:11 --> Config Class Initialized
INFO - 2016-10-10 10:19:11 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:19:11 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:19:11 --> Utf8 Class Initialized
INFO - 2016-10-10 10:19:12 --> URI Class Initialized
INFO - 2016-10-10 10:19:12 --> Router Class Initialized
INFO - 2016-10-10 10:19:12 --> Output Class Initialized
INFO - 2016-10-10 10:19:12 --> Security Class Initialized
DEBUG - 2016-10-10 10:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:19:12 --> Input Class Initialized
INFO - 2016-10-10 10:19:12 --> Language Class Initialized
INFO - 2016-10-10 10:19:12 --> Language Class Initialized
INFO - 2016-10-10 10:19:12 --> Config Class Initialized
INFO - 2016-10-10 10:19:12 --> Loader Class Initialized
INFO - 2016-10-10 10:19:12 --> Helper loaded: url_helper
INFO - 2016-10-10 10:19:12 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:19:12 --> Controller Class Initialized
DEBUG - 2016-10-10 10:19:12 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:19:12 --> Model Class Initialized
INFO - 2016-10-10 10:19:12 --> Model Class Initialized
ERROR - 2016-10-10 10:19:12 --> Unable to delete cache file for admin/index/data/anggota
DEBUG - 2016-10-10 10:19:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 10:19:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 10:19:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 10:19:12 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-10 10:19:12 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-10 10:19:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-10 10:19:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 10:19:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 10:19:13 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:13 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:13 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:13 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:13 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:13 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:13 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:13 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:13 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:13 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:13 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:13 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:13 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:13 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:13 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:13 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:13 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:13 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:13 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:13 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:13 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:13 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:13 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:13 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:13 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:13 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:13 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:14 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:14 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:14 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:14 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:14 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:14 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:14 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:14 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:14 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:14 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:14 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:14 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:14 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:14 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:14 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:14 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:14 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:14 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:14 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:14 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:14 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:14 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:14 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:15 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:15 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:15 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:15 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:15 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:15 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:15 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:15 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:15 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:15 --> Database Driver Class Initialized
DEBUG - 2016-10-10 10:19:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 10:19:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 10:19:15 --> Final output sent to browser
DEBUG - 2016-10-10 10:19:15 --> Total execution time: 3.6347
INFO - 2016-10-10 10:19:20 --> Config Class Initialized
INFO - 2016-10-10 10:19:20 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:19:20 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:19:20 --> Utf8 Class Initialized
INFO - 2016-10-10 10:19:20 --> URI Class Initialized
INFO - 2016-10-10 10:19:20 --> Router Class Initialized
INFO - 2016-10-10 10:19:20 --> Output Class Initialized
INFO - 2016-10-10 10:19:20 --> Security Class Initialized
DEBUG - 2016-10-10 10:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:19:20 --> Input Class Initialized
INFO - 2016-10-10 10:19:20 --> Language Class Initialized
INFO - 2016-10-10 10:19:20 --> Language Class Initialized
INFO - 2016-10-10 10:19:20 --> Config Class Initialized
INFO - 2016-10-10 10:19:20 --> Loader Class Initialized
INFO - 2016-10-10 10:19:20 --> Helper loaded: url_helper
INFO - 2016-10-10 10:19:20 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:19:21 --> Controller Class Initialized
DEBUG - 2016-10-10 10:19:21 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:19:21 --> Model Class Initialized
INFO - 2016-10-10 10:19:21 --> Model Class Initialized
ERROR - 2016-10-10 10:19:21 --> Unable to delete cache file for admin/index/data/anggota/umum
DEBUG - 2016-10-10 10:19:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 10:19:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 10:19:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 10:19:21 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-10 10:19:21 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-10 10:19:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-10 10:19:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 10:19:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 10:19:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:23 --> Database Driver Class Initialized
DEBUG - 2016-10-10 10:19:23 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 10:19:23 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 10:19:23 --> Final output sent to browser
DEBUG - 2016-10-10 10:19:23 --> Total execution time: 3.7748
INFO - 2016-10-10 10:19:44 --> Config Class Initialized
INFO - 2016-10-10 10:19:44 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:19:44 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:19:44 --> Utf8 Class Initialized
INFO - 2016-10-10 10:19:44 --> URI Class Initialized
INFO - 2016-10-10 10:19:44 --> Router Class Initialized
INFO - 2016-10-10 10:19:44 --> Output Class Initialized
INFO - 2016-10-10 10:19:44 --> Security Class Initialized
DEBUG - 2016-10-10 10:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:19:44 --> Input Class Initialized
INFO - 2016-10-10 10:19:44 --> Language Class Initialized
INFO - 2016-10-10 10:19:44 --> Language Class Initialized
INFO - 2016-10-10 10:19:44 --> Config Class Initialized
INFO - 2016-10-10 10:19:44 --> Loader Class Initialized
INFO - 2016-10-10 10:19:44 --> Helper loaded: url_helper
INFO - 2016-10-10 10:19:44 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:19:44 --> Controller Class Initialized
DEBUG - 2016-10-10 10:19:45 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:19:45 --> Model Class Initialized
INFO - 2016-10-10 10:19:45 --> Model Class Initialized
ERROR - 2016-10-10 10:19:45 --> Unable to delete cache file for admin/index/add/anggota
DEBUG - 2016-10-10 10:19:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 10:19:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 10:19:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 10:19:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_anggota.php
DEBUG - 2016-10-10 10:19:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 10:19:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 10:19:45 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:45 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:45 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:45 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:45 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:45 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:45 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:45 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:45 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:45 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:45 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:45 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:45 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:45 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:45 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:45 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:19:47 --> Database Driver Class Initialized
DEBUG - 2016-10-10 10:19:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 10:19:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 10:19:47 --> Final output sent to browser
DEBUG - 2016-10-10 10:19:48 --> Total execution time: 3.5577
INFO - 2016-10-10 10:20:17 --> Config Class Initialized
INFO - 2016-10-10 10:20:17 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:20:17 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:20:17 --> Utf8 Class Initialized
INFO - 2016-10-10 10:20:17 --> URI Class Initialized
INFO - 2016-10-10 10:20:17 --> Router Class Initialized
INFO - 2016-10-10 10:20:17 --> Output Class Initialized
INFO - 2016-10-10 10:20:17 --> Security Class Initialized
DEBUG - 2016-10-10 10:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:20:17 --> Input Class Initialized
INFO - 2016-10-10 10:20:17 --> Language Class Initialized
INFO - 2016-10-10 10:20:17 --> Language Class Initialized
INFO - 2016-10-10 10:20:18 --> Config Class Initialized
INFO - 2016-10-10 10:20:18 --> Loader Class Initialized
INFO - 2016-10-10 10:20:18 --> Helper loaded: url_helper
INFO - 2016-10-10 10:20:18 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:20:18 --> Controller Class Initialized
DEBUG - 2016-10-10 10:20:18 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:20:18 --> Model Class Initialized
INFO - 2016-10-10 10:20:18 --> Model Class Initialized
ERROR - 2016-10-10 10:20:18 --> Unable to delete cache file for admin/index/post_add
DEBUG - 2016-10-10 10:20:18 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-10 10:20:18 --> Users MX_Controller Initialized
DEBUG - 2016-10-10 10:20:18 --> Index MX_Controller Initialized
ERROR - 2016-10-10 10:20:18 --> Unable to delete cache file for admin/index/post_add
INFO - 2016-10-10 10:20:18 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:18 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:18 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:18 --> Final output sent to browser
DEBUG - 2016-10-10 10:20:18 --> Total execution time: 1.1827
INFO - 2016-10-10 10:20:18 --> Config Class Initialized
INFO - 2016-10-10 10:20:18 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:20:18 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:20:19 --> Utf8 Class Initialized
INFO - 2016-10-10 10:20:19 --> URI Class Initialized
INFO - 2016-10-10 10:20:19 --> Router Class Initialized
INFO - 2016-10-10 10:20:19 --> Output Class Initialized
INFO - 2016-10-10 10:20:19 --> Security Class Initialized
DEBUG - 2016-10-10 10:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:20:19 --> Input Class Initialized
INFO - 2016-10-10 10:20:19 --> Language Class Initialized
INFO - 2016-10-10 10:20:19 --> Language Class Initialized
INFO - 2016-10-10 10:20:19 --> Config Class Initialized
INFO - 2016-10-10 10:20:19 --> Loader Class Initialized
INFO - 2016-10-10 10:20:19 --> Helper loaded: url_helper
INFO - 2016-10-10 10:20:19 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:20:19 --> Controller Class Initialized
DEBUG - 2016-10-10 10:20:19 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:20:19 --> Model Class Initialized
INFO - 2016-10-10 10:20:19 --> Model Class Initialized
ERROR - 2016-10-10 10:20:19 --> Unable to delete cache file for admin/index/data/anggota
DEBUG - 2016-10-10 10:20:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 10:20:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 10:20:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 10:20:19 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-10 10:20:19 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-10 10:20:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-10 10:20:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 10:20:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 10:20:20 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:20 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:20 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:20 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:20 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:20 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:20 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:20 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:20 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:20 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:20 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:20 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:20 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:20 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:20 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:20 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:20 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:20 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:20 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:20 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:20 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:20 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:20 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:20 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:20 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:20 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:22 --> Database Driver Class Initialized
DEBUG - 2016-10-10 10:20:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 10:20:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 10:20:22 --> Final output sent to browser
DEBUG - 2016-10-10 10:20:22 --> Total execution time: 3.5765
INFO - 2016-10-10 10:20:28 --> Config Class Initialized
INFO - 2016-10-10 10:20:28 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:20:28 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:20:28 --> Utf8 Class Initialized
INFO - 2016-10-10 10:20:28 --> URI Class Initialized
INFO - 2016-10-10 10:20:28 --> Router Class Initialized
INFO - 2016-10-10 10:20:28 --> Output Class Initialized
INFO - 2016-10-10 10:20:28 --> Security Class Initialized
DEBUG - 2016-10-10 10:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:20:28 --> Input Class Initialized
INFO - 2016-10-10 10:20:28 --> Language Class Initialized
INFO - 2016-10-10 10:20:28 --> Language Class Initialized
INFO - 2016-10-10 10:20:28 --> Config Class Initialized
INFO - 2016-10-10 10:20:28 --> Loader Class Initialized
INFO - 2016-10-10 10:20:28 --> Helper loaded: url_helper
INFO - 2016-10-10 10:20:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:20:28 --> Controller Class Initialized
DEBUG - 2016-10-10 10:20:28 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:20:28 --> Model Class Initialized
INFO - 2016-10-10 10:20:28 --> Model Class Initialized
ERROR - 2016-10-10 10:20:29 --> Unable to delete cache file for admin/index/data/anggota/umum
DEBUG - 2016-10-10 10:20:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 10:20:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 10:20:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 10:20:29 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-10 10:20:29 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-10 10:20:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-10 10:20:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 10:20:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 10:20:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:31 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:31 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:31 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:31 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:31 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:31 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:31 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:31 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:31 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:31 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:31 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:31 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:31 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:31 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:31 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:31 --> Database Driver Class Initialized
DEBUG - 2016-10-10 10:20:31 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 10:20:31 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 10:20:31 --> Final output sent to browser
DEBUG - 2016-10-10 10:20:31 --> Total execution time: 3.3966
INFO - 2016-10-10 10:20:43 --> Config Class Initialized
INFO - 2016-10-10 10:20:43 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:20:43 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:20:43 --> Utf8 Class Initialized
INFO - 2016-10-10 10:20:43 --> URI Class Initialized
INFO - 2016-10-10 10:20:43 --> Router Class Initialized
INFO - 2016-10-10 10:20:43 --> Output Class Initialized
INFO - 2016-10-10 10:20:43 --> Security Class Initialized
DEBUG - 2016-10-10 10:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:20:43 --> Input Class Initialized
INFO - 2016-10-10 10:20:43 --> Language Class Initialized
INFO - 2016-10-10 10:20:43 --> Language Class Initialized
INFO - 2016-10-10 10:20:43 --> Config Class Initialized
INFO - 2016-10-10 10:20:43 --> Loader Class Initialized
INFO - 2016-10-10 10:20:43 --> Helper loaded: url_helper
INFO - 2016-10-10 10:20:43 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:20:43 --> Controller Class Initialized
DEBUG - 2016-10-10 10:20:44 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:20:44 --> Model Class Initialized
INFO - 2016-10-10 10:20:44 --> Model Class Initialized
ERROR - 2016-10-10 10:20:44 --> Unable to delete cache file for admin/index/add/anggota
DEBUG - 2016-10-10 10:20:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 10:20:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 10:20:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 10:20:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_anggota.php
DEBUG - 2016-10-10 10:20:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 10:20:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 10:20:44 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:44 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:44 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:44 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:44 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:44 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:44 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:44 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:44 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:44 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:44 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:44 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:44 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:44 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:44 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:45 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:45 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:45 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:45 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:45 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:45 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:45 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:45 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:45 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:45 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:45 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:45 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:45 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:45 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:45 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:45 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:45 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:45 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:45 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:45 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:45 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:45 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:45 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:20:46 --> Database Driver Class Initialized
DEBUG - 2016-10-10 10:20:46 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 10:20:46 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 10:20:47 --> Final output sent to browser
DEBUG - 2016-10-10 10:20:47 --> Total execution time: 3.6771
INFO - 2016-10-10 10:21:17 --> Config Class Initialized
INFO - 2016-10-10 10:21:17 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:21:17 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:21:17 --> Utf8 Class Initialized
INFO - 2016-10-10 10:21:17 --> URI Class Initialized
INFO - 2016-10-10 10:21:17 --> Router Class Initialized
INFO - 2016-10-10 10:21:17 --> Output Class Initialized
INFO - 2016-10-10 10:21:18 --> Security Class Initialized
DEBUG - 2016-10-10 10:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:21:18 --> Input Class Initialized
INFO - 2016-10-10 10:21:18 --> Language Class Initialized
INFO - 2016-10-10 10:21:18 --> Language Class Initialized
INFO - 2016-10-10 10:21:18 --> Config Class Initialized
INFO - 2016-10-10 10:21:18 --> Loader Class Initialized
INFO - 2016-10-10 10:21:18 --> Helper loaded: url_helper
INFO - 2016-10-10 10:21:18 --> Database Driver Class Initialized
INFO - 2016-10-10 10:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:21:18 --> Controller Class Initialized
DEBUG - 2016-10-10 10:21:18 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:21:18 --> Model Class Initialized
INFO - 2016-10-10 10:21:18 --> Model Class Initialized
ERROR - 2016-10-10 10:21:18 --> Unable to delete cache file for admin/index/post_add
DEBUG - 2016-10-10 10:21:18 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-10 10:21:18 --> Users MX_Controller Initialized
DEBUG - 2016-10-10 10:21:18 --> Index MX_Controller Initialized
ERROR - 2016-10-10 10:21:18 --> Unable to delete cache file for admin/index/post_add
INFO - 2016-10-10 10:21:18 --> Database Driver Class Initialized
INFO - 2016-10-10 10:21:18 --> Final output sent to browser
DEBUG - 2016-10-10 10:21:18 --> Total execution time: 0.9777
INFO - 2016-10-10 10:21:56 --> Config Class Initialized
INFO - 2016-10-10 10:21:57 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:21:57 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:21:57 --> Utf8 Class Initialized
INFO - 2016-10-10 10:21:57 --> URI Class Initialized
INFO - 2016-10-10 10:21:57 --> Router Class Initialized
INFO - 2016-10-10 10:21:57 --> Output Class Initialized
INFO - 2016-10-10 10:21:57 --> Security Class Initialized
DEBUG - 2016-10-10 10:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:21:57 --> Input Class Initialized
INFO - 2016-10-10 10:21:57 --> Language Class Initialized
INFO - 2016-10-10 10:21:57 --> Language Class Initialized
INFO - 2016-10-10 10:21:57 --> Config Class Initialized
INFO - 2016-10-10 10:21:57 --> Loader Class Initialized
INFO - 2016-10-10 10:21:57 --> Helper loaded: url_helper
INFO - 2016-10-10 10:21:57 --> Database Driver Class Initialized
INFO - 2016-10-10 10:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:21:57 --> Controller Class Initialized
DEBUG - 2016-10-10 10:21:57 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:21:57 --> Model Class Initialized
INFO - 2016-10-10 10:21:57 --> Model Class Initialized
ERROR - 2016-10-10 10:21:57 --> Unable to delete cache file for admin/index/post_add
DEBUG - 2016-10-10 10:21:57 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-10 10:21:57 --> Users MX_Controller Initialized
DEBUG - 2016-10-10 10:21:57 --> Index MX_Controller Initialized
ERROR - 2016-10-10 10:21:57 --> Unable to delete cache file for admin/index/post_add
INFO - 2016-10-10 10:21:57 --> Database Driver Class Initialized
INFO - 2016-10-10 10:21:57 --> Final output sent to browser
DEBUG - 2016-10-10 10:21:57 --> Total execution time: 0.9697
INFO - 2016-10-10 10:22:08 --> Config Class Initialized
INFO - 2016-10-10 10:22:08 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:22:08 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:22:08 --> Utf8 Class Initialized
INFO - 2016-10-10 10:22:08 --> URI Class Initialized
INFO - 2016-10-10 10:22:08 --> Router Class Initialized
INFO - 2016-10-10 10:22:08 --> Output Class Initialized
INFO - 2016-10-10 10:22:08 --> Security Class Initialized
DEBUG - 2016-10-10 10:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:22:08 --> Input Class Initialized
INFO - 2016-10-10 10:22:08 --> Language Class Initialized
INFO - 2016-10-10 10:22:08 --> Language Class Initialized
INFO - 2016-10-10 10:22:08 --> Config Class Initialized
INFO - 2016-10-10 10:22:08 --> Loader Class Initialized
INFO - 2016-10-10 10:22:08 --> Helper loaded: url_helper
INFO - 2016-10-10 10:22:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:22:08 --> Controller Class Initialized
DEBUG - 2016-10-10 10:22:08 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:22:08 --> Model Class Initialized
INFO - 2016-10-10 10:22:08 --> Model Class Initialized
ERROR - 2016-10-10 10:22:08 --> Unable to delete cache file for admin/index/data/anggota/umum
DEBUG - 2016-10-10 10:22:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 10:22:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 10:22:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 10:22:08 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-10 10:22:09 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-10 10:22:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-10 10:22:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 10:22:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 10:22:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:11 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:11 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:11 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:11 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:11 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:11 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:11 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:11 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:11 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:11 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:11 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:11 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:11 --> Database Driver Class Initialized
DEBUG - 2016-10-10 10:22:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 10:22:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 10:22:11 --> Final output sent to browser
DEBUG - 2016-10-10 10:22:11 --> Total execution time: 3.6355
INFO - 2016-10-10 10:22:15 --> Config Class Initialized
INFO - 2016-10-10 10:22:15 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:22:15 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:22:15 --> Utf8 Class Initialized
INFO - 2016-10-10 10:22:15 --> URI Class Initialized
INFO - 2016-10-10 10:22:15 --> Router Class Initialized
INFO - 2016-10-10 10:22:15 --> Output Class Initialized
INFO - 2016-10-10 10:22:15 --> Security Class Initialized
DEBUG - 2016-10-10 10:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:22:15 --> Input Class Initialized
INFO - 2016-10-10 10:22:15 --> Language Class Initialized
INFO - 2016-10-10 10:22:15 --> Language Class Initialized
INFO - 2016-10-10 10:22:15 --> Config Class Initialized
INFO - 2016-10-10 10:22:15 --> Loader Class Initialized
INFO - 2016-10-10 10:22:16 --> Helper loaded: url_helper
INFO - 2016-10-10 10:22:16 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:22:16 --> Controller Class Initialized
DEBUG - 2016-10-10 10:22:16 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:22:16 --> Model Class Initialized
INFO - 2016-10-10 10:22:16 --> Model Class Initialized
ERROR - 2016-10-10 10:22:16 --> Unable to delete cache file for admin/index/data/anggota/karyawan
DEBUG - 2016-10-10 10:22:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 10:22:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 10:22:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 10:22:16 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-10 10:22:16 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-10 10:22:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-10 10:22:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 10:22:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 10:22:16 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:16 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:16 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:16 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:16 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:17 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:17 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:17 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:17 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:17 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:17 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:17 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:17 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:17 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:17 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:17 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:17 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:17 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:17 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:17 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:17 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:17 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:17 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:17 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:17 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:17 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:18 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:18 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:18 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:18 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:18 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:18 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:18 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:18 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:18 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:18 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:18 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:18 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:18 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:18 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:18 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:18 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:18 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:18 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:18 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:18 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:19 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:19 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:19 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:19 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:19 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:19 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:19 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:19 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:19 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:19 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:19 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:19 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:19 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:19 --> Database Driver Class Initialized
DEBUG - 2016-10-10 10:22:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 10:22:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 10:22:19 --> Final output sent to browser
DEBUG - 2016-10-10 10:22:19 --> Total execution time: 4.4243
INFO - 2016-10-10 10:22:26 --> Config Class Initialized
INFO - 2016-10-10 10:22:26 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:22:26 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:22:26 --> Utf8 Class Initialized
INFO - 2016-10-10 10:22:26 --> URI Class Initialized
INFO - 2016-10-10 10:22:26 --> Router Class Initialized
INFO - 2016-10-10 10:22:26 --> Output Class Initialized
INFO - 2016-10-10 10:22:26 --> Security Class Initialized
DEBUG - 2016-10-10 10:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:22:27 --> Input Class Initialized
INFO - 2016-10-10 10:22:27 --> Language Class Initialized
INFO - 2016-10-10 10:22:27 --> Language Class Initialized
INFO - 2016-10-10 10:22:27 --> Config Class Initialized
INFO - 2016-10-10 10:22:27 --> Loader Class Initialized
INFO - 2016-10-10 10:22:27 --> Helper loaded: url_helper
INFO - 2016-10-10 10:22:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:22:27 --> Controller Class Initialized
DEBUG - 2016-10-10 10:22:27 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:22:27 --> Model Class Initialized
INFO - 2016-10-10 10:22:27 --> Model Class Initialized
ERROR - 2016-10-10 10:22:27 --> Unable to delete cache file for admin/index/detail_anggota/356a192b7913b04c54574d18c28d46e6395428ab
DEBUG - 2016-10-10 10:22:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 10:22:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 10:22:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
INFO - 2016-10-10 10:22:27 --> Database Driver Class Initialized
DEBUG - 2016-10-10 10:22:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_pinjaman.php
INFO - 2016-10-10 10:22:27 --> Database Driver Class Initialized
DEBUG - 2016-10-10 10:22:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_tabungan.php
DEBUG - 2016-10-10 10:22:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/profile_anggota.php
DEBUG - 2016-10-10 10:22:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 10:22:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 10:22:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:30 --> Database Driver Class Initialized
DEBUG - 2016-10-10 10:22:30 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 10:22:30 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 10:22:30 --> Final output sent to browser
DEBUG - 2016-10-10 10:22:30 --> Total execution time: 3.9695
INFO - 2016-10-10 10:22:30 --> Config Class Initialized
INFO - 2016-10-10 10:22:30 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:22:30 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:22:30 --> Utf8 Class Initialized
INFO - 2016-10-10 10:22:31 --> URI Class Initialized
INFO - 2016-10-10 10:22:31 --> Router Class Initialized
INFO - 2016-10-10 10:22:31 --> Output Class Initialized
INFO - 2016-10-10 10:22:31 --> Security Class Initialized
DEBUG - 2016-10-10 10:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:22:31 --> Input Class Initialized
INFO - 2016-10-10 10:22:31 --> Language Class Initialized
INFO - 2016-10-10 10:22:31 --> Language Class Initialized
INFO - 2016-10-10 10:22:31 --> Config Class Initialized
INFO - 2016-10-10 10:22:31 --> Loader Class Initialized
INFO - 2016-10-10 10:22:31 --> Helper loaded: url_helper
INFO - 2016-10-10 10:22:31 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:22:31 --> Controller Class Initialized
DEBUG - 2016-10-10 10:22:32 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:22:32 --> Model Class Initialized
INFO - 2016-10-10 10:22:32 --> Model Class Initialized
ERROR - 2016-10-10 10:22:32 --> Unable to delete cache file for admin/index/detail_anggota/images/picture.jpg
DEBUG - 2016-10-10 10:22:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 10:22:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 10:22:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
ERROR - 2016-10-10 10:22:32 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 16
ERROR - 2016-10-10 10:22:32 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 19
ERROR - 2016-10-10 10:22:32 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 22
ERROR - 2016-10-10 10:22:32 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 38
INFO - 2016-10-10 10:22:32 --> Database Driver Class Initialized
DEBUG - 2016-10-10 10:22:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_pinjaman.php
ERROR - 2016-10-10 10:22:33 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 41
INFO - 2016-10-10 10:22:33 --> Database Driver Class Initialized
DEBUG - 2016-10-10 10:22:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_tabungan.php
DEBUG - 2016-10-10 10:22:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/profile_anggota.php
DEBUG - 2016-10-10 10:22:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 10:22:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 10:22:33 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:34 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:34 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:34 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:34 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:34 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:34 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:34 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:34 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:34 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:34 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:34 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:34 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:34 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:34 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:35 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:35 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:35 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:35 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:35 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:35 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:35 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:35 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:35 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:35 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:35 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:36 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:36 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:36 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:36 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:36 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:36 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:36 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:36 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:37 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:37 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:37 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:37 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:37 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:37 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:37 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:37 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:37 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:38 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:38 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:38 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:38 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:38 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:38 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:38 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:38 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:38 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:38 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:38 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:38 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:38 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:38 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:38 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:38 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:38 --> Database Driver Class Initialized
DEBUG - 2016-10-10 10:22:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 10:22:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 10:22:39 --> Final output sent to browser
DEBUG - 2016-10-10 10:22:39 --> Total execution time: 8.3186
INFO - 2016-10-10 10:22:48 --> Config Class Initialized
INFO - 2016-10-10 10:22:48 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:22:48 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:22:48 --> Utf8 Class Initialized
INFO - 2016-10-10 10:22:48 --> URI Class Initialized
INFO - 2016-10-10 10:22:48 --> Router Class Initialized
INFO - 2016-10-10 10:22:48 --> Output Class Initialized
INFO - 2016-10-10 10:22:48 --> Security Class Initialized
DEBUG - 2016-10-10 10:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:22:48 --> Input Class Initialized
INFO - 2016-10-10 10:22:48 --> Language Class Initialized
INFO - 2016-10-10 10:22:48 --> Language Class Initialized
INFO - 2016-10-10 10:22:48 --> Config Class Initialized
INFO - 2016-10-10 10:22:48 --> Loader Class Initialized
INFO - 2016-10-10 10:22:48 --> Helper loaded: url_helper
INFO - 2016-10-10 10:22:48 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:22:49 --> Controller Class Initialized
DEBUG - 2016-10-10 10:22:49 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:22:49 --> Model Class Initialized
INFO - 2016-10-10 10:22:49 --> Model Class Initialized
ERROR - 2016-10-10 10:22:49 --> Unable to delete cache file for admin/index/getRaportAngsuran/356a192b7913b04c54574d18c28d46e6395428ab
DEBUG - 2016-10-10 10:22:49 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/raport_angsuran.php
INFO - 2016-10-10 10:22:49 --> Final output sent to browser
DEBUG - 2016-10-10 10:22:49 --> Total execution time: 1.1583
INFO - 2016-10-10 10:22:57 --> Config Class Initialized
INFO - 2016-10-10 10:22:57 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:22:57 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:22:57 --> Utf8 Class Initialized
INFO - 2016-10-10 10:22:57 --> URI Class Initialized
INFO - 2016-10-10 10:22:57 --> Router Class Initialized
INFO - 2016-10-10 10:22:57 --> Output Class Initialized
INFO - 2016-10-10 10:22:57 --> Security Class Initialized
DEBUG - 2016-10-10 10:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:22:57 --> Input Class Initialized
INFO - 2016-10-10 10:22:57 --> Language Class Initialized
INFO - 2016-10-10 10:22:57 --> Language Class Initialized
INFO - 2016-10-10 10:22:57 --> Config Class Initialized
INFO - 2016-10-10 10:22:57 --> Loader Class Initialized
INFO - 2016-10-10 10:22:57 --> Helper loaded: url_helper
INFO - 2016-10-10 10:22:57 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:22:58 --> Controller Class Initialized
DEBUG - 2016-10-10 10:22:58 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:22:58 --> Model Class Initialized
INFO - 2016-10-10 10:22:58 --> Model Class Initialized
ERROR - 2016-10-10 10:22:58 --> Unable to delete cache file for admin/index/data/anggota
DEBUG - 2016-10-10 10:22:58 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 10:22:58 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 10:22:58 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 10:22:58 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-10 10:22:58 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-10 10:22:58 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-10 10:22:58 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 10:22:58 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 10:22:58 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:58 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:58 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:58 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:58 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:58 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:58 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:58 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:58 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:58 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:58 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:58 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:58 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:59 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:59 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:59 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:59 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:59 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:59 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:59 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:59 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:59 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:59 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:59 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:59 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:59 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:59 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:59 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:59 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:59 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:59 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:59 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:59 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:59 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:59 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:59 --> Database Driver Class Initialized
INFO - 2016-10-10 10:22:59 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:00 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:00 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:00 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:00 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:00 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:00 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:00 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:00 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:00 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:00 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:00 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:00 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:00 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:00 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:00 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:00 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:00 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:00 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:00 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:00 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:00 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:01 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:01 --> Database Driver Class Initialized
DEBUG - 2016-10-10 10:23:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 10:23:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 10:23:01 --> Final output sent to browser
DEBUG - 2016-10-10 10:23:01 --> Total execution time: 3.8625
INFO - 2016-10-10 10:23:07 --> Config Class Initialized
INFO - 2016-10-10 10:23:07 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:23:07 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:23:07 --> Utf8 Class Initialized
INFO - 2016-10-10 10:23:07 --> URI Class Initialized
INFO - 2016-10-10 10:23:07 --> Router Class Initialized
INFO - 2016-10-10 10:23:07 --> Output Class Initialized
INFO - 2016-10-10 10:23:07 --> Security Class Initialized
DEBUG - 2016-10-10 10:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:23:07 --> Input Class Initialized
INFO - 2016-10-10 10:23:07 --> Language Class Initialized
INFO - 2016-10-10 10:23:08 --> Language Class Initialized
INFO - 2016-10-10 10:23:08 --> Config Class Initialized
INFO - 2016-10-10 10:23:08 --> Loader Class Initialized
INFO - 2016-10-10 10:23:08 --> Helper loaded: url_helper
INFO - 2016-10-10 10:23:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:23:08 --> Controller Class Initialized
DEBUG - 2016-10-10 10:23:08 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:23:08 --> Model Class Initialized
INFO - 2016-10-10 10:23:08 --> Model Class Initialized
ERROR - 2016-10-10 10:23:08 --> Unable to delete cache file for admin/index/data/anggota/umum
DEBUG - 2016-10-10 10:23:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 10:23:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 10:23:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 10:23:08 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-10 10:23:08 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-10 10:23:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-10 10:23:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 10:23:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 10:23:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:11 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:11 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:11 --> Database Driver Class Initialized
DEBUG - 2016-10-10 10:23:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 10:23:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 10:23:11 --> Final output sent to browser
DEBUG - 2016-10-10 10:23:11 --> Total execution time: 3.6897
INFO - 2016-10-10 10:23:51 --> Config Class Initialized
INFO - 2016-10-10 10:23:51 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:23:51 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:23:51 --> Utf8 Class Initialized
INFO - 2016-10-10 10:23:51 --> URI Class Initialized
INFO - 2016-10-10 10:23:51 --> Router Class Initialized
INFO - 2016-10-10 10:23:51 --> Output Class Initialized
INFO - 2016-10-10 10:23:51 --> Security Class Initialized
DEBUG - 2016-10-10 10:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:23:52 --> Input Class Initialized
INFO - 2016-10-10 10:23:52 --> Language Class Initialized
INFO - 2016-10-10 10:23:52 --> Language Class Initialized
INFO - 2016-10-10 10:23:52 --> Config Class Initialized
INFO - 2016-10-10 10:23:52 --> Loader Class Initialized
INFO - 2016-10-10 10:23:52 --> Helper loaded: url_helper
INFO - 2016-10-10 10:23:52 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:23:52 --> Controller Class Initialized
DEBUG - 2016-10-10 10:23:52 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:23:52 --> Model Class Initialized
INFO - 2016-10-10 10:23:52 --> Model Class Initialized
ERROR - 2016-10-10 10:23:52 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-10-10 10:23:52 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 10:23:52 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 10:23:52 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 10:23:52 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-10-10 10:23:52 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 10:23:52 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 10:23:52 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:52 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:52 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:52 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:52 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:52 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:53 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:53 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:53 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:53 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:53 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:53 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:53 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:53 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:53 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:53 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:53 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:53 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:53 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:53 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:53 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:53 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:53 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:53 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:53 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:53 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:53 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:53 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:53 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:53 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:54 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:54 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:54 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:54 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:54 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:54 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:54 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:54 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:54 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:54 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:54 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:54 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:54 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:54 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:54 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:54 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:54 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:54 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:54 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:54 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:54 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:54 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:54 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:55 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:55 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:55 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:55 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:55 --> Database Driver Class Initialized
INFO - 2016-10-10 10:23:55 --> Database Driver Class Initialized
DEBUG - 2016-10-10 10:23:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 10:23:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 10:23:55 --> Final output sent to browser
DEBUG - 2016-10-10 10:23:55 --> Total execution time: 3.6880
INFO - 2016-10-10 10:24:06 --> Config Class Initialized
INFO - 2016-10-10 10:24:06 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:24:06 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:24:06 --> Utf8 Class Initialized
INFO - 2016-10-10 10:24:06 --> URI Class Initialized
INFO - 2016-10-10 10:24:06 --> Router Class Initialized
INFO - 2016-10-10 10:24:06 --> Output Class Initialized
INFO - 2016-10-10 10:24:06 --> Security Class Initialized
DEBUG - 2016-10-10 10:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:24:07 --> Input Class Initialized
INFO - 2016-10-10 10:24:07 --> Language Class Initialized
INFO - 2016-10-10 10:24:07 --> Language Class Initialized
INFO - 2016-10-10 10:24:07 --> Config Class Initialized
INFO - 2016-10-10 10:24:07 --> Loader Class Initialized
INFO - 2016-10-10 10:24:07 --> Helper loaded: url_helper
INFO - 2016-10-10 10:24:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:24:07 --> Controller Class Initialized
DEBUG - 2016-10-10 10:24:07 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:24:07 --> Model Class Initialized
INFO - 2016-10-10 10:24:07 --> Model Class Initialized
ERROR - 2016-10-10 10:24:07 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-10 10:24:07 --> Anggota MX_Controller Initialized
INFO - 2016-10-10 10:24:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:07 --> Final output sent to browser
DEBUG - 2016-10-10 10:24:07 --> Total execution time: 0.9824
INFO - 2016-10-10 10:24:19 --> Config Class Initialized
INFO - 2016-10-10 10:24:19 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:24:19 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:24:19 --> Utf8 Class Initialized
INFO - 2016-10-10 10:24:19 --> URI Class Initialized
INFO - 2016-10-10 10:24:19 --> Router Class Initialized
INFO - 2016-10-10 10:24:19 --> Output Class Initialized
INFO - 2016-10-10 10:24:19 --> Security Class Initialized
DEBUG - 2016-10-10 10:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:24:20 --> Input Class Initialized
INFO - 2016-10-10 10:24:20 --> Language Class Initialized
INFO - 2016-10-10 10:24:20 --> Language Class Initialized
INFO - 2016-10-10 10:24:20 --> Config Class Initialized
INFO - 2016-10-10 10:24:20 --> Loader Class Initialized
INFO - 2016-10-10 10:24:20 --> Helper loaded: url_helper
INFO - 2016-10-10 10:24:20 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:24:20 --> Controller Class Initialized
DEBUG - 2016-10-10 10:24:20 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:24:20 --> Model Class Initialized
INFO - 2016-10-10 10:24:20 --> Model Class Initialized
ERROR - 2016-10-10 10:24:20 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-10-10 10:24:20 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 10:24:20 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 10:24:20 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 10:24:20 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_umum.php
DEBUG - 2016-10-10 10:24:20 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 10:24:20 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 10:24:20 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:20 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:20 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:20 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:20 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:20 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:20 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:23 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:23 --> Database Driver Class Initialized
DEBUG - 2016-10-10 10:24:23 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 10:24:23 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 10:24:23 --> Final output sent to browser
DEBUG - 2016-10-10 10:24:23 --> Total execution time: 3.6020
INFO - 2016-10-10 10:24:47 --> Config Class Initialized
INFO - 2016-10-10 10:24:47 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:24:47 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:24:47 --> Utf8 Class Initialized
INFO - 2016-10-10 10:24:47 --> URI Class Initialized
INFO - 2016-10-10 10:24:47 --> Router Class Initialized
INFO - 2016-10-10 10:24:47 --> Output Class Initialized
INFO - 2016-10-10 10:24:47 --> Security Class Initialized
DEBUG - 2016-10-10 10:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:24:47 --> Input Class Initialized
INFO - 2016-10-10 10:24:48 --> Language Class Initialized
INFO - 2016-10-10 10:24:48 --> Language Class Initialized
INFO - 2016-10-10 10:24:48 --> Config Class Initialized
INFO - 2016-10-10 10:24:48 --> Loader Class Initialized
INFO - 2016-10-10 10:24:48 --> Helper loaded: url_helper
INFO - 2016-10-10 10:24:48 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:24:48 --> Controller Class Initialized
DEBUG - 2016-10-10 10:24:48 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:24:48 --> Model Class Initialized
INFO - 2016-10-10 10:24:48 --> Model Class Initialized
ERROR - 2016-10-10 10:24:48 --> Unable to delete cache file for admin/index/do_ajukan_pinjaman
INFO - 2016-10-10 10:24:48 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:48 --> Database Driver Class Initialized
INFO - 2016-10-10 10:24:48 --> Final output sent to browser
DEBUG - 2016-10-10 10:24:48 --> Total execution time: 1.0179
INFO - 2016-10-10 10:25:06 --> Config Class Initialized
INFO - 2016-10-10 10:25:06 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:25:06 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:25:06 --> Utf8 Class Initialized
INFO - 2016-10-10 10:25:06 --> URI Class Initialized
INFO - 2016-10-10 10:25:06 --> Router Class Initialized
INFO - 2016-10-10 10:25:06 --> Output Class Initialized
INFO - 2016-10-10 10:25:06 --> Security Class Initialized
DEBUG - 2016-10-10 10:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:25:06 --> Input Class Initialized
INFO - 2016-10-10 10:25:06 --> Language Class Initialized
INFO - 2016-10-10 10:25:06 --> Language Class Initialized
INFO - 2016-10-10 10:25:06 --> Config Class Initialized
INFO - 2016-10-10 10:25:06 --> Loader Class Initialized
INFO - 2016-10-10 10:25:06 --> Helper loaded: url_helper
INFO - 2016-10-10 10:25:06 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:25:06 --> Controller Class Initialized
DEBUG - 2016-10-10 10:25:06 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:25:06 --> Model Class Initialized
INFO - 2016-10-10 10:25:07 --> Model Class Initialized
ERROR - 2016-10-10 10:25:07 --> Unable to delete cache file for admin/index/do_save_jaminan/sertifikat
INFO - 2016-10-10 10:25:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:07 --> Final output sent to browser
DEBUG - 2016-10-10 10:25:07 --> Total execution time: 1.0785
INFO - 2016-10-10 10:25:53 --> Config Class Initialized
INFO - 2016-10-10 10:25:53 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:25:53 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:25:53 --> Utf8 Class Initialized
INFO - 2016-10-10 10:25:54 --> URI Class Initialized
INFO - 2016-10-10 10:25:54 --> Router Class Initialized
INFO - 2016-10-10 10:25:54 --> Output Class Initialized
INFO - 2016-10-10 10:25:54 --> Security Class Initialized
DEBUG - 2016-10-10 10:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:25:54 --> Input Class Initialized
INFO - 2016-10-10 10:25:54 --> Language Class Initialized
INFO - 2016-10-10 10:25:54 --> Language Class Initialized
INFO - 2016-10-10 10:25:54 --> Config Class Initialized
INFO - 2016-10-10 10:25:54 --> Loader Class Initialized
INFO - 2016-10-10 10:25:54 --> Helper loaded: url_helper
INFO - 2016-10-10 10:25:54 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:25:54 --> Controller Class Initialized
DEBUG - 2016-10-10 10:25:54 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:25:54 --> Model Class Initialized
INFO - 2016-10-10 10:25:54 --> Model Class Initialized
ERROR - 2016-10-10 10:25:54 --> Unable to delete cache file for admin/index/finish_pinjaman/fc074d501302eb2b93e2554793fcaf50b3bf7291
INFO - 2016-10-10 10:25:54 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:54 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:54 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:54 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:54 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:55 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:55 --> Final output sent to browser
DEBUG - 2016-10-10 10:25:55 --> Total execution time: 1.2423
INFO - 2016-10-10 10:25:55 --> Config Class Initialized
INFO - 2016-10-10 10:25:55 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:25:55 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:25:55 --> Utf8 Class Initialized
INFO - 2016-10-10 10:25:55 --> URI Class Initialized
INFO - 2016-10-10 10:25:55 --> Router Class Initialized
INFO - 2016-10-10 10:25:55 --> Output Class Initialized
INFO - 2016-10-10 10:25:55 --> Security Class Initialized
DEBUG - 2016-10-10 10:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:25:55 --> Input Class Initialized
INFO - 2016-10-10 10:25:55 --> Language Class Initialized
INFO - 2016-10-10 10:25:55 --> Language Class Initialized
INFO - 2016-10-10 10:25:55 --> Config Class Initialized
INFO - 2016-10-10 10:25:55 --> Loader Class Initialized
INFO - 2016-10-10 10:25:55 --> Helper loaded: url_helper
INFO - 2016-10-10 10:25:55 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:25:55 --> Controller Class Initialized
DEBUG - 2016-10-10 10:25:55 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:25:56 --> Model Class Initialized
INFO - 2016-10-10 10:25:56 --> Model Class Initialized
ERROR - 2016-10-10 10:25:56 --> Unable to delete cache file for admin/index/data_peminjam
DEBUG - 2016-10-10 10:25:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 10:25:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 10:25:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 10:25:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_peminjam.php
DEBUG - 2016-10-10 10:25:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 10:25:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 10:25:56 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:56 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:56 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:56 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:56 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:56 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:56 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:56 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:56 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:56 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:56 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:56 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:56 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:56 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:56 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:57 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:57 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:57 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:57 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:57 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:57 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:57 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:57 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:57 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:57 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:57 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:57 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:57 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:57 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:57 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:57 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:57 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:57 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:57 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:57 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:57 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:58 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:58 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:58 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:58 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:58 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:58 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:58 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:58 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:58 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:58 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:58 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:58 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:58 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:58 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:58 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:58 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:58 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:58 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:58 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:58 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:58 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:58 --> Database Driver Class Initialized
INFO - 2016-10-10 10:25:59 --> Database Driver Class Initialized
DEBUG - 2016-10-10 10:25:59 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 10:25:59 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 10:25:59 --> Final output sent to browser
DEBUG - 2016-10-10 10:25:59 --> Total execution time: 3.9015
INFO - 2016-10-10 10:26:03 --> Config Class Initialized
INFO - 2016-10-10 10:26:03 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:26:03 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:26:03 --> Utf8 Class Initialized
INFO - 2016-10-10 10:26:03 --> URI Class Initialized
INFO - 2016-10-10 10:26:03 --> Router Class Initialized
INFO - 2016-10-10 10:26:03 --> Output Class Initialized
INFO - 2016-10-10 10:26:03 --> Security Class Initialized
DEBUG - 2016-10-10 10:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:26:03 --> Input Class Initialized
INFO - 2016-10-10 10:26:03 --> Language Class Initialized
INFO - 2016-10-10 10:26:03 --> Language Class Initialized
INFO - 2016-10-10 10:26:03 --> Config Class Initialized
INFO - 2016-10-10 10:26:03 --> Loader Class Initialized
INFO - 2016-10-10 10:26:03 --> Helper loaded: url_helper
INFO - 2016-10-10 10:26:03 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:26:03 --> Controller Class Initialized
DEBUG - 2016-10-10 10:26:03 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:26:03 --> Model Class Initialized
INFO - 2016-10-10 10:26:03 --> Model Class Initialized
ERROR - 2016-10-10 10:26:03 --> Unable to delete cache file for admin/index/getDataPeminjam/umum
DEBUG - 2016-10-10 10:26:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-10-10 10:26:04 --> Final output sent to browser
DEBUG - 2016-10-10 10:26:04 --> Total execution time: 0.8873
INFO - 2016-10-10 10:26:25 --> Config Class Initialized
INFO - 2016-10-10 10:26:25 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:26:25 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:26:25 --> Utf8 Class Initialized
INFO - 2016-10-10 10:26:25 --> URI Class Initialized
INFO - 2016-10-10 10:26:25 --> Router Class Initialized
INFO - 2016-10-10 10:26:25 --> Output Class Initialized
INFO - 2016-10-10 10:26:25 --> Security Class Initialized
DEBUG - 2016-10-10 10:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:26:25 --> Input Class Initialized
INFO - 2016-10-10 10:26:26 --> Language Class Initialized
INFO - 2016-10-10 10:26:26 --> Language Class Initialized
INFO - 2016-10-10 10:26:26 --> Config Class Initialized
INFO - 2016-10-10 10:26:26 --> Loader Class Initialized
INFO - 2016-10-10 10:26:26 --> Helper loaded: url_helper
INFO - 2016-10-10 10:26:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:26:26 --> Controller Class Initialized
DEBUG - 2016-10-10 10:26:26 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:26:26 --> Model Class Initialized
INFO - 2016-10-10 10:26:26 --> Model Class Initialized
ERROR - 2016-10-10 10:26:26 --> Unable to delete cache file for admin/index/add/anggota
DEBUG - 2016-10-10 10:26:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 10:26:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 10:26:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 10:26:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_anggota.php
DEBUG - 2016-10-10 10:26:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 10:26:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 10:26:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:28 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:26:29 --> Database Driver Class Initialized
DEBUG - 2016-10-10 10:26:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 10:26:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 10:26:29 --> Final output sent to browser
DEBUG - 2016-10-10 10:26:29 --> Total execution time: 3.7299
INFO - 2016-10-10 10:27:07 --> Config Class Initialized
INFO - 2016-10-10 10:27:07 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:27:07 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:27:07 --> Utf8 Class Initialized
INFO - 2016-10-10 10:27:07 --> URI Class Initialized
INFO - 2016-10-10 10:27:07 --> Router Class Initialized
INFO - 2016-10-10 10:27:07 --> Output Class Initialized
INFO - 2016-10-10 10:27:07 --> Security Class Initialized
DEBUG - 2016-10-10 10:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:27:07 --> Input Class Initialized
INFO - 2016-10-10 10:27:07 --> Language Class Initialized
INFO - 2016-10-10 10:27:07 --> Language Class Initialized
INFO - 2016-10-10 10:27:07 --> Config Class Initialized
INFO - 2016-10-10 10:27:07 --> Loader Class Initialized
INFO - 2016-10-10 10:27:07 --> Helper loaded: url_helper
INFO - 2016-10-10 10:27:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:27:08 --> Controller Class Initialized
DEBUG - 2016-10-10 10:27:08 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:27:08 --> Model Class Initialized
INFO - 2016-10-10 10:27:08 --> Model Class Initialized
ERROR - 2016-10-10 10:27:08 --> Unable to delete cache file for admin/index/laporan_pinjaman
DEBUG - 2016-10-10 10:27:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 10:27:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 10:27:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 10:27:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/pinjaman.php
DEBUG - 2016-10-10 10:27:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 10:27:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 10:27:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:10 --> Database Driver Class Initialized
DEBUG - 2016-10-10 10:27:10 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 10:27:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 10:27:11 --> Final output sent to browser
DEBUG - 2016-10-10 10:27:11 --> Total execution time: 3.7222
INFO - 2016-10-10 10:27:20 --> Config Class Initialized
INFO - 2016-10-10 10:27:20 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:27:20 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:27:20 --> Utf8 Class Initialized
INFO - 2016-10-10 10:27:20 --> URI Class Initialized
INFO - 2016-10-10 10:27:21 --> Router Class Initialized
INFO - 2016-10-10 10:27:21 --> Output Class Initialized
INFO - 2016-10-10 10:27:21 --> Security Class Initialized
DEBUG - 2016-10-10 10:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:27:21 --> Input Class Initialized
INFO - 2016-10-10 10:27:21 --> Language Class Initialized
INFO - 2016-10-10 10:27:21 --> Language Class Initialized
INFO - 2016-10-10 10:27:21 --> Config Class Initialized
INFO - 2016-10-10 10:27:21 --> Loader Class Initialized
INFO - 2016-10-10 10:27:21 --> Helper loaded: url_helper
INFO - 2016-10-10 10:27:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:27:21 --> Controller Class Initialized
DEBUG - 2016-10-10 10:27:21 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:27:21 --> Model Class Initialized
INFO - 2016-10-10 10:27:21 --> Model Class Initialized
ERROR - 2016-10-10 10:27:21 --> Unable to delete cache file for admin/index/do_laporan_pinjaman
DEBUG - 2016-10-10 10:27:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_pinjaman.php
INFO - 2016-10-10 10:27:21 --> Final output sent to browser
DEBUG - 2016-10-10 10:27:21 --> Total execution time: 0.8753
INFO - 2016-10-10 10:27:30 --> Config Class Initialized
INFO - 2016-10-10 10:27:30 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:27:30 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:27:30 --> Utf8 Class Initialized
INFO - 2016-10-10 10:27:30 --> URI Class Initialized
INFO - 2016-10-10 10:27:30 --> Router Class Initialized
INFO - 2016-10-10 10:27:30 --> Output Class Initialized
INFO - 2016-10-10 10:27:30 --> Security Class Initialized
DEBUG - 2016-10-10 10:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:27:30 --> Input Class Initialized
INFO - 2016-10-10 10:27:30 --> Language Class Initialized
INFO - 2016-10-10 10:27:30 --> Language Class Initialized
INFO - 2016-10-10 10:27:30 --> Config Class Initialized
INFO - 2016-10-10 10:27:31 --> Loader Class Initialized
INFO - 2016-10-10 10:27:31 --> Helper loaded: url_helper
INFO - 2016-10-10 10:27:31 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:27:31 --> Controller Class Initialized
DEBUG - 2016-10-10 10:27:31 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:27:31 --> Model Class Initialized
INFO - 2016-10-10 10:27:31 --> Model Class Initialized
ERROR - 2016-10-10 10:27:31 --> Unable to delete cache file for admin/index/do_laporan_pinjaman
DEBUG - 2016-10-10 10:27:31 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_pinjaman.php
INFO - 2016-10-10 10:27:31 --> Final output sent to browser
DEBUG - 2016-10-10 10:27:31 --> Total execution time: 0.8750
INFO - 2016-10-10 10:27:57 --> Config Class Initialized
INFO - 2016-10-10 10:27:57 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:27:57 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:27:57 --> Utf8 Class Initialized
INFO - 2016-10-10 10:27:57 --> URI Class Initialized
INFO - 2016-10-10 10:27:57 --> Router Class Initialized
INFO - 2016-10-10 10:27:57 --> Output Class Initialized
INFO - 2016-10-10 10:27:57 --> Security Class Initialized
DEBUG - 2016-10-10 10:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:27:57 --> Input Class Initialized
INFO - 2016-10-10 10:27:57 --> Language Class Initialized
INFO - 2016-10-10 10:27:58 --> Language Class Initialized
INFO - 2016-10-10 10:27:58 --> Config Class Initialized
INFO - 2016-10-10 10:27:58 --> Loader Class Initialized
INFO - 2016-10-10 10:27:58 --> Helper loaded: url_helper
INFO - 2016-10-10 10:27:58 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:27:58 --> Controller Class Initialized
DEBUG - 2016-10-10 10:27:58 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:27:58 --> Model Class Initialized
INFO - 2016-10-10 10:27:58 --> Model Class Initialized
ERROR - 2016-10-10 10:27:58 --> Unable to delete cache file for admin/index/buku_besar
DEBUG - 2016-10-10 10:27:58 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 10:27:58 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 10:27:58 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 10:27:58 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/buku_besar.php
DEBUG - 2016-10-10 10:27:58 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 10:27:58 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 10:27:58 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:58 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:58 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:58 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:58 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:58 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:59 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:59 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:59 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:59 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:59 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:59 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:59 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:59 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:59 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:59 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:59 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:59 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:59 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:59 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:59 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:59 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:59 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:59 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:59 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:59 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:59 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:59 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:59 --> Database Driver Class Initialized
INFO - 2016-10-10 10:28:00 --> Database Driver Class Initialized
INFO - 2016-10-10 10:28:00 --> Database Driver Class Initialized
INFO - 2016-10-10 10:28:00 --> Database Driver Class Initialized
INFO - 2016-10-10 10:28:00 --> Database Driver Class Initialized
INFO - 2016-10-10 10:28:00 --> Database Driver Class Initialized
INFO - 2016-10-10 10:28:00 --> Database Driver Class Initialized
INFO - 2016-10-10 10:28:00 --> Database Driver Class Initialized
INFO - 2016-10-10 10:28:00 --> Database Driver Class Initialized
INFO - 2016-10-10 10:28:00 --> Database Driver Class Initialized
INFO - 2016-10-10 10:28:00 --> Database Driver Class Initialized
INFO - 2016-10-10 10:28:00 --> Database Driver Class Initialized
INFO - 2016-10-10 10:28:00 --> Database Driver Class Initialized
INFO - 2016-10-10 10:28:00 --> Database Driver Class Initialized
INFO - 2016-10-10 10:28:00 --> Database Driver Class Initialized
INFO - 2016-10-10 10:28:00 --> Database Driver Class Initialized
INFO - 2016-10-10 10:28:00 --> Database Driver Class Initialized
INFO - 2016-10-10 10:28:00 --> Database Driver Class Initialized
INFO - 2016-10-10 10:28:00 --> Database Driver Class Initialized
INFO - 2016-10-10 10:28:00 --> Database Driver Class Initialized
INFO - 2016-10-10 10:28:00 --> Database Driver Class Initialized
INFO - 2016-10-10 10:28:00 --> Database Driver Class Initialized
INFO - 2016-10-10 10:28:01 --> Database Driver Class Initialized
INFO - 2016-10-10 10:28:01 --> Database Driver Class Initialized
INFO - 2016-10-10 10:28:01 --> Database Driver Class Initialized
INFO - 2016-10-10 10:28:01 --> Database Driver Class Initialized
INFO - 2016-10-10 10:28:01 --> Database Driver Class Initialized
INFO - 2016-10-10 10:28:01 --> Database Driver Class Initialized
INFO - 2016-10-10 10:28:01 --> Database Driver Class Initialized
INFO - 2016-10-10 10:28:01 --> Database Driver Class Initialized
INFO - 2016-10-10 10:28:01 --> Database Driver Class Initialized
INFO - 2016-10-10 10:28:01 --> Database Driver Class Initialized
DEBUG - 2016-10-10 10:28:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 10:28:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 10:28:01 --> Final output sent to browser
DEBUG - 2016-10-10 10:28:01 --> Total execution time: 3.9046
INFO - 2016-10-10 10:28:19 --> Config Class Initialized
INFO - 2016-10-10 10:28:19 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:28:19 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:28:19 --> Utf8 Class Initialized
INFO - 2016-10-10 10:28:19 --> URI Class Initialized
INFO - 2016-10-10 10:28:19 --> Router Class Initialized
INFO - 2016-10-10 10:28:19 --> Output Class Initialized
INFO - 2016-10-10 10:28:19 --> Security Class Initialized
DEBUG - 2016-10-10 10:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:28:20 --> Input Class Initialized
INFO - 2016-10-10 10:28:20 --> Language Class Initialized
INFO - 2016-10-10 10:28:20 --> Language Class Initialized
INFO - 2016-10-10 10:28:20 --> Config Class Initialized
INFO - 2016-10-10 10:28:20 --> Loader Class Initialized
INFO - 2016-10-10 10:28:20 --> Helper loaded: url_helper
INFO - 2016-10-10 10:28:20 --> Database Driver Class Initialized
INFO - 2016-10-10 10:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:28:20 --> Controller Class Initialized
DEBUG - 2016-10-10 10:28:20 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:28:20 --> Model Class Initialized
INFO - 2016-10-10 10:28:20 --> Model Class Initialized
ERROR - 2016-10-10 10:28:20 --> Unable to delete cache file for admin/index/do_laporan_buku_besar
DEBUG - 2016-10-10 10:28:20 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_buku_besar.php
INFO - 2016-10-10 10:28:20 --> Final output sent to browser
DEBUG - 2016-10-10 10:28:20 --> Total execution time: 0.9064
INFO - 2016-10-10 10:29:00 --> Config Class Initialized
INFO - 2016-10-10 10:29:00 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:29:00 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:29:01 --> Utf8 Class Initialized
INFO - 2016-10-10 10:29:01 --> URI Class Initialized
INFO - 2016-10-10 10:29:01 --> Router Class Initialized
INFO - 2016-10-10 10:29:01 --> Output Class Initialized
INFO - 2016-10-10 10:29:01 --> Security Class Initialized
DEBUG - 2016-10-10 10:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:29:01 --> Input Class Initialized
INFO - 2016-10-10 10:29:01 --> Language Class Initialized
INFO - 2016-10-10 10:29:01 --> Language Class Initialized
INFO - 2016-10-10 10:29:01 --> Config Class Initialized
INFO - 2016-10-10 10:29:01 --> Loader Class Initialized
INFO - 2016-10-10 10:29:01 --> Helper loaded: url_helper
INFO - 2016-10-10 10:29:01 --> Database Driver Class Initialized
INFO - 2016-10-10 10:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:29:01 --> Controller Class Initialized
DEBUG - 2016-10-10 10:29:01 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:29:01 --> Model Class Initialized
INFO - 2016-10-10 10:29:01 --> Model Class Initialized
ERROR - 2016-10-10 10:29:01 --> Unable to delete cache file for admin/index/do_laporan_buku_besar
DEBUG - 2016-10-10 10:29:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_buku_besar.php
INFO - 2016-10-10 10:29:01 --> Final output sent to browser
DEBUG - 2016-10-10 10:29:01 --> Total execution time: 0.8474
INFO - 2016-10-10 10:29:10 --> Config Class Initialized
INFO - 2016-10-10 10:29:10 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:29:10 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:29:10 --> Utf8 Class Initialized
INFO - 2016-10-10 10:29:10 --> URI Class Initialized
INFO - 2016-10-10 10:29:10 --> Router Class Initialized
INFO - 2016-10-10 10:29:10 --> Output Class Initialized
INFO - 2016-10-10 10:29:10 --> Security Class Initialized
DEBUG - 2016-10-10 10:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:29:10 --> Input Class Initialized
INFO - 2016-10-10 10:29:10 --> Language Class Initialized
INFO - 2016-10-10 10:29:10 --> Language Class Initialized
INFO - 2016-10-10 10:29:10 --> Config Class Initialized
INFO - 2016-10-10 10:29:10 --> Loader Class Initialized
INFO - 2016-10-10 10:29:10 --> Helper loaded: url_helper
INFO - 2016-10-10 10:29:10 --> Database Driver Class Initialized
INFO - 2016-10-10 10:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:29:10 --> Controller Class Initialized
DEBUG - 2016-10-10 10:29:10 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:29:10 --> Model Class Initialized
INFO - 2016-10-10 10:29:10 --> Model Class Initialized
ERROR - 2016-10-10 10:29:10 --> Unable to delete cache file for admin/index/do_laporan_buku_besar
DEBUG - 2016-10-10 10:29:10 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_buku_besar.php
INFO - 2016-10-10 10:29:10 --> Final output sent to browser
DEBUG - 2016-10-10 10:29:10 --> Total execution time: 0.8020
INFO - 2016-10-10 10:33:03 --> Config Class Initialized
INFO - 2016-10-10 10:33:04 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:33:04 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:33:04 --> Utf8 Class Initialized
INFO - 2016-10-10 10:33:04 --> URI Class Initialized
INFO - 2016-10-10 10:33:04 --> Router Class Initialized
INFO - 2016-10-10 10:33:04 --> Output Class Initialized
INFO - 2016-10-10 10:33:04 --> Security Class Initialized
DEBUG - 2016-10-10 10:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:33:04 --> Input Class Initialized
INFO - 2016-10-10 10:33:04 --> Language Class Initialized
INFO - 2016-10-10 10:33:04 --> Language Class Initialized
INFO - 2016-10-10 10:33:04 --> Config Class Initialized
INFO - 2016-10-10 10:33:04 --> Loader Class Initialized
INFO - 2016-10-10 10:33:04 --> Helper loaded: url_helper
INFO - 2016-10-10 10:33:04 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:33:04 --> Controller Class Initialized
DEBUG - 2016-10-10 10:33:04 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:33:04 --> Model Class Initialized
INFO - 2016-10-10 10:33:04 --> Model Class Initialized
ERROR - 2016-10-10 10:33:04 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-10-10 10:33:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 10:33:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 10:33:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 10:33:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-10-10 10:33:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 10:33:05 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 10:33:05 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:05 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:05 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:05 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:05 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:05 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:05 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:05 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:05 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:05 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:05 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:05 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:05 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:05 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:05 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:05 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:05 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:05 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:05 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:05 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:05 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:05 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:05 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:06 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:06 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:06 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:06 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:06 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:06 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:06 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:06 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:06 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:06 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:06 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:06 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:06 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:06 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:06 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:06 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:06 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:06 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:06 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:06 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:06 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:06 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:06 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:07 --> Database Driver Class Initialized
DEBUG - 2016-10-10 10:33:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 10:33:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 10:33:07 --> Final output sent to browser
DEBUG - 2016-10-10 10:33:07 --> Total execution time: 3.6899
INFO - 2016-10-10 10:33:18 --> Config Class Initialized
INFO - 2016-10-10 10:33:18 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:33:18 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:33:18 --> Utf8 Class Initialized
INFO - 2016-10-10 10:33:18 --> URI Class Initialized
INFO - 2016-10-10 10:33:18 --> Router Class Initialized
INFO - 2016-10-10 10:33:18 --> Output Class Initialized
INFO - 2016-10-10 10:33:18 --> Security Class Initialized
DEBUG - 2016-10-10 10:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:33:19 --> Input Class Initialized
INFO - 2016-10-10 10:33:19 --> Language Class Initialized
INFO - 2016-10-10 10:33:19 --> Language Class Initialized
INFO - 2016-10-10 10:33:19 --> Config Class Initialized
INFO - 2016-10-10 10:33:19 --> Loader Class Initialized
INFO - 2016-10-10 10:33:19 --> Helper loaded: url_helper
INFO - 2016-10-10 10:33:19 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:33:19 --> Controller Class Initialized
DEBUG - 2016-10-10 10:33:19 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:33:19 --> Model Class Initialized
INFO - 2016-10-10 10:33:19 --> Model Class Initialized
ERROR - 2016-10-10 10:33:19 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-10 10:33:19 --> Anggota MX_Controller Initialized
INFO - 2016-10-10 10:33:19 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:19 --> Final output sent to browser
DEBUG - 2016-10-10 10:33:19 --> Total execution time: 0.9922
INFO - 2016-10-10 10:33:23 --> Config Class Initialized
INFO - 2016-10-10 10:33:23 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:33:23 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:33:23 --> Utf8 Class Initialized
INFO - 2016-10-10 10:33:23 --> URI Class Initialized
INFO - 2016-10-10 10:33:24 --> Router Class Initialized
INFO - 2016-10-10 10:33:24 --> Output Class Initialized
INFO - 2016-10-10 10:33:24 --> Security Class Initialized
DEBUG - 2016-10-10 10:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:33:24 --> Input Class Initialized
INFO - 2016-10-10 10:33:24 --> Language Class Initialized
INFO - 2016-10-10 10:33:24 --> Language Class Initialized
INFO - 2016-10-10 10:33:24 --> Config Class Initialized
INFO - 2016-10-10 10:33:24 --> Loader Class Initialized
INFO - 2016-10-10 10:33:24 --> Helper loaded: url_helper
INFO - 2016-10-10 10:33:24 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:33:24 --> Controller Class Initialized
DEBUG - 2016-10-10 10:33:24 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:33:24 --> Model Class Initialized
INFO - 2016-10-10 10:33:24 --> Model Class Initialized
ERROR - 2016-10-10 10:33:24 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-10-10 10:33:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 10:33:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 10:33:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 10:33:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_umum.php
DEBUG - 2016-10-10 10:33:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 10:33:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 10:33:24 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:25 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:25 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:25 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:25 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:25 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:25 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:25 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:25 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:25 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:25 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:25 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:25 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:25 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:25 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:25 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:25 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:25 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:25 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:25 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:25 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:25 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:25 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:25 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:27 --> Database Driver Class Initialized
DEBUG - 2016-10-10 10:33:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 10:33:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 10:33:27 --> Final output sent to browser
DEBUG - 2016-10-10 10:33:27 --> Total execution time: 3.9565
INFO - 2016-10-10 10:33:45 --> Config Class Initialized
INFO - 2016-10-10 10:33:45 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:33:45 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:33:46 --> Utf8 Class Initialized
INFO - 2016-10-10 10:33:46 --> URI Class Initialized
INFO - 2016-10-10 10:33:46 --> Router Class Initialized
INFO - 2016-10-10 10:33:46 --> Output Class Initialized
INFO - 2016-10-10 10:33:46 --> Security Class Initialized
DEBUG - 2016-10-10 10:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:33:46 --> Input Class Initialized
INFO - 2016-10-10 10:33:46 --> Language Class Initialized
INFO - 2016-10-10 10:33:46 --> Language Class Initialized
INFO - 2016-10-10 10:33:46 --> Config Class Initialized
INFO - 2016-10-10 10:33:46 --> Loader Class Initialized
INFO - 2016-10-10 10:33:46 --> Helper loaded: url_helper
INFO - 2016-10-10 10:33:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:33:46 --> Controller Class Initialized
DEBUG - 2016-10-10 10:33:46 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:33:46 --> Model Class Initialized
INFO - 2016-10-10 10:33:46 --> Model Class Initialized
ERROR - 2016-10-10 10:33:46 --> Unable to delete cache file for admin/index/do_ajukan_pinjaman
INFO - 2016-10-10 10:33:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:33:46 --> Final output sent to browser
DEBUG - 2016-10-10 10:33:46 --> Total execution time: 1.0619
INFO - 2016-10-10 10:37:03 --> Config Class Initialized
INFO - 2016-10-10 10:37:03 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:37:03 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:37:03 --> Utf8 Class Initialized
INFO - 2016-10-10 10:37:03 --> URI Class Initialized
INFO - 2016-10-10 10:37:03 --> Router Class Initialized
INFO - 2016-10-10 10:37:03 --> Output Class Initialized
INFO - 2016-10-10 10:37:03 --> Security Class Initialized
DEBUG - 2016-10-10 10:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:37:04 --> Input Class Initialized
INFO - 2016-10-10 10:37:04 --> Language Class Initialized
INFO - 2016-10-10 10:37:04 --> Language Class Initialized
INFO - 2016-10-10 10:37:04 --> Config Class Initialized
INFO - 2016-10-10 10:37:04 --> Loader Class Initialized
INFO - 2016-10-10 10:37:04 --> Helper loaded: url_helper
INFO - 2016-10-10 10:37:04 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:37:04 --> Controller Class Initialized
DEBUG - 2016-10-10 10:37:04 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:37:04 --> Model Class Initialized
INFO - 2016-10-10 10:37:04 --> Model Class Initialized
ERROR - 2016-10-10 10:37:04 --> Unable to delete cache file for admin/index/batal/cb7a1d775e800fd1ee4049f7dca9e041eb9ba083
INFO - 2016-10-10 10:37:04 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:04 --> Final output sent to browser
DEBUG - 2016-10-10 10:37:04 --> Total execution time: 0.9934
INFO - 2016-10-10 10:37:04 --> Config Class Initialized
INFO - 2016-10-10 10:37:04 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:37:04 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:37:05 --> Utf8 Class Initialized
INFO - 2016-10-10 10:37:05 --> URI Class Initialized
INFO - 2016-10-10 10:37:05 --> Router Class Initialized
INFO - 2016-10-10 10:37:05 --> Output Class Initialized
INFO - 2016-10-10 10:37:05 --> Security Class Initialized
DEBUG - 2016-10-10 10:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:37:05 --> Input Class Initialized
INFO - 2016-10-10 10:37:05 --> Language Class Initialized
INFO - 2016-10-10 10:37:05 --> Language Class Initialized
INFO - 2016-10-10 10:37:05 --> Config Class Initialized
INFO - 2016-10-10 10:37:05 --> Loader Class Initialized
INFO - 2016-10-10 10:37:05 --> Helper loaded: url_helper
INFO - 2016-10-10 10:37:05 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:37:05 --> Controller Class Initialized
DEBUG - 2016-10-10 10:37:05 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:37:05 --> Model Class Initialized
INFO - 2016-10-10 10:37:05 --> Model Class Initialized
ERROR - 2016-10-10 10:37:05 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-10-10 10:37:05 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 10:37:05 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 10:37:05 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 10:37:05 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-10-10 10:37:05 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 10:37:05 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 10:37:06 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:06 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:06 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:06 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:06 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:06 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:06 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:06 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:06 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:06 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:06 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:06 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:06 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:06 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:06 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:06 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:06 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:06 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:06 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:06 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:06 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:08 --> Database Driver Class Initialized
DEBUG - 2016-10-10 10:37:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 10:37:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 10:37:08 --> Final output sent to browser
DEBUG - 2016-10-10 10:37:08 --> Total execution time: 3.8725
INFO - 2016-10-10 10:37:26 --> Config Class Initialized
INFO - 2016-10-10 10:37:26 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:37:26 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:37:26 --> Utf8 Class Initialized
INFO - 2016-10-10 10:37:26 --> URI Class Initialized
INFO - 2016-10-10 10:37:26 --> Router Class Initialized
INFO - 2016-10-10 10:37:26 --> Output Class Initialized
INFO - 2016-10-10 10:37:26 --> Security Class Initialized
DEBUG - 2016-10-10 10:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:37:26 --> Input Class Initialized
INFO - 2016-10-10 10:37:26 --> Language Class Initialized
INFO - 2016-10-10 10:37:26 --> Language Class Initialized
INFO - 2016-10-10 10:37:26 --> Config Class Initialized
INFO - 2016-10-10 10:37:26 --> Loader Class Initialized
INFO - 2016-10-10 10:37:26 --> Helper loaded: url_helper
INFO - 2016-10-10 10:37:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:37:26 --> Controller Class Initialized
DEBUG - 2016-10-10 10:37:27 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:37:27 --> Model Class Initialized
INFO - 2016-10-10 10:37:27 --> Model Class Initialized
ERROR - 2016-10-10 10:37:27 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-10 10:37:27 --> Anggota MX_Controller Initialized
INFO - 2016-10-10 10:37:27 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:27 --> Final output sent to browser
DEBUG - 2016-10-10 10:37:27 --> Total execution time: 0.9779
INFO - 2016-10-10 10:37:28 --> Config Class Initialized
INFO - 2016-10-10 10:37:28 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:37:28 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:37:28 --> Utf8 Class Initialized
INFO - 2016-10-10 10:37:28 --> URI Class Initialized
INFO - 2016-10-10 10:37:28 --> Router Class Initialized
INFO - 2016-10-10 10:37:29 --> Output Class Initialized
INFO - 2016-10-10 10:37:29 --> Security Class Initialized
DEBUG - 2016-10-10 10:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:37:29 --> Input Class Initialized
INFO - 2016-10-10 10:37:29 --> Language Class Initialized
INFO - 2016-10-10 10:37:29 --> Language Class Initialized
INFO - 2016-10-10 10:37:29 --> Config Class Initialized
INFO - 2016-10-10 10:37:29 --> Loader Class Initialized
INFO - 2016-10-10 10:37:29 --> Helper loaded: url_helper
INFO - 2016-10-10 10:37:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:37:29 --> Controller Class Initialized
DEBUG - 2016-10-10 10:37:29 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:37:29 --> Model Class Initialized
INFO - 2016-10-10 10:37:29 --> Model Class Initialized
ERROR - 2016-10-10 10:37:29 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-10-10 10:37:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 10:37:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 10:37:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 10:37:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_umum.php
DEBUG - 2016-10-10 10:37:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 10:37:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 10:37:29 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:30 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:31 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:31 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:31 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:31 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:31 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:31 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:31 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:31 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:31 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:31 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:31 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:31 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:31 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:31 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:31 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:31 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:31 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:31 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:31 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:31 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:31 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:32 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:32 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:32 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:32 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:32 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:32 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:32 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:32 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:32 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:32 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:32 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:32 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:32 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:32 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:32 --> Database Driver Class Initialized
DEBUG - 2016-10-10 10:37:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 10:37:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 10:37:32 --> Final output sent to browser
DEBUG - 2016-10-10 10:37:32 --> Total execution time: 4.0570
INFO - 2016-10-10 10:37:48 --> Config Class Initialized
INFO - 2016-10-10 10:37:48 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:37:48 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:37:48 --> Utf8 Class Initialized
INFO - 2016-10-10 10:37:48 --> URI Class Initialized
INFO - 2016-10-10 10:37:49 --> Router Class Initialized
INFO - 2016-10-10 10:37:49 --> Output Class Initialized
INFO - 2016-10-10 10:37:49 --> Security Class Initialized
DEBUG - 2016-10-10 10:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:37:49 --> Input Class Initialized
INFO - 2016-10-10 10:37:49 --> Language Class Initialized
INFO - 2016-10-10 10:37:49 --> Language Class Initialized
INFO - 2016-10-10 10:37:49 --> Config Class Initialized
INFO - 2016-10-10 10:37:49 --> Loader Class Initialized
INFO - 2016-10-10 10:37:49 --> Helper loaded: url_helper
INFO - 2016-10-10 10:37:49 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:37:49 --> Controller Class Initialized
DEBUG - 2016-10-10 10:37:49 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:37:49 --> Model Class Initialized
INFO - 2016-10-10 10:37:49 --> Model Class Initialized
ERROR - 2016-10-10 10:37:49 --> Unable to delete cache file for admin/index/do_ajukan_pinjaman
INFO - 2016-10-10 10:37:49 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:49 --> Database Driver Class Initialized
INFO - 2016-10-10 10:37:49 --> Final output sent to browser
DEBUG - 2016-10-10 10:37:49 --> Total execution time: 1.0796
INFO - 2016-10-10 10:38:48 --> Config Class Initialized
INFO - 2016-10-10 10:38:48 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:38:48 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:38:48 --> Utf8 Class Initialized
INFO - 2016-10-10 10:38:48 --> URI Class Initialized
INFO - 2016-10-10 10:38:48 --> Router Class Initialized
INFO - 2016-10-10 10:38:48 --> Output Class Initialized
INFO - 2016-10-10 10:38:48 --> Security Class Initialized
DEBUG - 2016-10-10 10:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:38:49 --> Input Class Initialized
INFO - 2016-10-10 10:38:49 --> Language Class Initialized
INFO - 2016-10-10 10:38:49 --> Language Class Initialized
INFO - 2016-10-10 10:38:49 --> Config Class Initialized
INFO - 2016-10-10 10:38:49 --> Loader Class Initialized
INFO - 2016-10-10 10:38:49 --> Helper loaded: url_helper
INFO - 2016-10-10 10:38:49 --> Database Driver Class Initialized
INFO - 2016-10-10 10:38:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:38:49 --> Controller Class Initialized
DEBUG - 2016-10-10 10:38:49 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:38:49 --> Model Class Initialized
INFO - 2016-10-10 10:38:49 --> Model Class Initialized
ERROR - 2016-10-10 10:38:49 --> Unable to delete cache file for admin/index/do_save_jaminan/sertifikat
INFO - 2016-10-10 10:38:49 --> Database Driver Class Initialized
INFO - 2016-10-10 10:38:49 --> Final output sent to browser
DEBUG - 2016-10-10 10:38:49 --> Total execution time: 0.9551
INFO - 2016-10-10 10:39:43 --> Config Class Initialized
INFO - 2016-10-10 10:39:43 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:39:43 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:39:43 --> Utf8 Class Initialized
INFO - 2016-10-10 10:39:43 --> URI Class Initialized
INFO - 2016-10-10 10:39:43 --> Router Class Initialized
INFO - 2016-10-10 10:39:43 --> Output Class Initialized
INFO - 2016-10-10 10:39:43 --> Security Class Initialized
DEBUG - 2016-10-10 10:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:39:43 --> Input Class Initialized
INFO - 2016-10-10 10:39:43 --> Language Class Initialized
INFO - 2016-10-10 10:39:43 --> Language Class Initialized
INFO - 2016-10-10 10:39:43 --> Config Class Initialized
INFO - 2016-10-10 10:39:43 --> Loader Class Initialized
INFO - 2016-10-10 10:39:43 --> Helper loaded: url_helper
INFO - 2016-10-10 10:39:44 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:39:44 --> Controller Class Initialized
DEBUG - 2016-10-10 10:39:44 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:39:44 --> Model Class Initialized
INFO - 2016-10-10 10:39:44 --> Model Class Initialized
ERROR - 2016-10-10 10:39:44 --> Unable to delete cache file for admin/index/finish_pinjaman/5b384ce32d8cdef02bc3a139d4cac0a22bb029e8
INFO - 2016-10-10 10:39:44 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:44 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:44 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:44 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:44 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:44 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:44 --> Final output sent to browser
DEBUG - 2016-10-10 10:39:44 --> Total execution time: 1.2939
INFO - 2016-10-10 10:39:44 --> Config Class Initialized
INFO - 2016-10-10 10:39:44 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:39:45 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:39:45 --> Utf8 Class Initialized
INFO - 2016-10-10 10:39:45 --> URI Class Initialized
INFO - 2016-10-10 10:39:45 --> Router Class Initialized
INFO - 2016-10-10 10:39:45 --> Output Class Initialized
INFO - 2016-10-10 10:39:45 --> Security Class Initialized
DEBUG - 2016-10-10 10:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:39:45 --> Input Class Initialized
INFO - 2016-10-10 10:39:45 --> Language Class Initialized
INFO - 2016-10-10 10:39:45 --> Language Class Initialized
INFO - 2016-10-10 10:39:45 --> Config Class Initialized
INFO - 2016-10-10 10:39:45 --> Loader Class Initialized
INFO - 2016-10-10 10:39:45 --> Helper loaded: url_helper
INFO - 2016-10-10 10:39:45 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:39:45 --> Controller Class Initialized
DEBUG - 2016-10-10 10:39:45 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:39:45 --> Model Class Initialized
INFO - 2016-10-10 10:39:45 --> Model Class Initialized
ERROR - 2016-10-10 10:39:45 --> Unable to delete cache file for admin/index/data_peminjam
DEBUG - 2016-10-10 10:39:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 10:39:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 10:39:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 10:39:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_peminjam.php
DEBUG - 2016-10-10 10:39:46 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 10:39:46 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 10:39:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:48 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:48 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:48 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:48 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:48 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:48 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:48 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:48 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:48 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:48 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:48 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:48 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:48 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:48 --> Database Driver Class Initialized
DEBUG - 2016-10-10 10:39:48 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 10:39:48 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 10:39:48 --> Final output sent to browser
DEBUG - 2016-10-10 10:39:48 --> Total execution time: 3.8111
INFO - 2016-10-10 10:39:55 --> Config Class Initialized
INFO - 2016-10-10 10:39:55 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:39:55 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:39:55 --> Utf8 Class Initialized
INFO - 2016-10-10 10:39:55 --> URI Class Initialized
INFO - 2016-10-10 10:39:55 --> Router Class Initialized
INFO - 2016-10-10 10:39:55 --> Output Class Initialized
INFO - 2016-10-10 10:39:55 --> Security Class Initialized
DEBUG - 2016-10-10 10:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:39:55 --> Input Class Initialized
INFO - 2016-10-10 10:39:55 --> Language Class Initialized
INFO - 2016-10-10 10:39:55 --> Language Class Initialized
INFO - 2016-10-10 10:39:55 --> Config Class Initialized
INFO - 2016-10-10 10:39:55 --> Loader Class Initialized
INFO - 2016-10-10 10:39:55 --> Helper loaded: url_helper
INFO - 2016-10-10 10:39:55 --> Database Driver Class Initialized
INFO - 2016-10-10 10:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:39:55 --> Controller Class Initialized
DEBUG - 2016-10-10 10:39:55 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:39:55 --> Model Class Initialized
INFO - 2016-10-10 10:39:55 --> Model Class Initialized
ERROR - 2016-10-10 10:39:55 --> Unable to delete cache file for admin/index/getDataPeminjam/umum
DEBUG - 2016-10-10 10:39:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-10-10 10:39:55 --> Final output sent to browser
DEBUG - 2016-10-10 10:39:55 --> Total execution time: 0.8603
INFO - 2016-10-10 10:40:00 --> Config Class Initialized
INFO - 2016-10-10 10:40:00 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:40:00 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:40:00 --> Utf8 Class Initialized
INFO - 2016-10-10 10:40:00 --> URI Class Initialized
INFO - 2016-10-10 10:40:00 --> Router Class Initialized
INFO - 2016-10-10 10:40:00 --> Output Class Initialized
INFO - 2016-10-10 10:40:00 --> Security Class Initialized
DEBUG - 2016-10-10 10:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:40:00 --> Input Class Initialized
INFO - 2016-10-10 10:40:00 --> Language Class Initialized
INFO - 2016-10-10 10:40:00 --> Language Class Initialized
INFO - 2016-10-10 10:40:00 --> Config Class Initialized
INFO - 2016-10-10 10:40:00 --> Loader Class Initialized
INFO - 2016-10-10 10:40:00 --> Helper loaded: url_helper
INFO - 2016-10-10 10:40:01 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:40:01 --> Controller Class Initialized
DEBUG - 2016-10-10 10:40:01 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:40:01 --> Model Class Initialized
INFO - 2016-10-10 10:40:01 --> Model Class Initialized
ERROR - 2016-10-10 10:40:01 --> Unable to delete cache file for admin/index/detail_pinjaman/5b384ce32d8cdef02bc3a139d4cac0a22bb029e8
DEBUG - 2016-10-10 10:40:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/subcontent/data_transaksi.php
INFO - 2016-10-10 10:40:01 --> Final output sent to browser
DEBUG - 2016-10-10 10:40:01 --> Total execution time: 1.2224
INFO - 2016-10-10 10:40:06 --> Config Class Initialized
INFO - 2016-10-10 10:40:06 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:40:06 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:40:06 --> Utf8 Class Initialized
INFO - 2016-10-10 10:40:06 --> URI Class Initialized
INFO - 2016-10-10 10:40:06 --> Router Class Initialized
INFO - 2016-10-10 10:40:06 --> Output Class Initialized
INFO - 2016-10-10 10:40:06 --> Security Class Initialized
DEBUG - 2016-10-10 10:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:40:06 --> Input Class Initialized
INFO - 2016-10-10 10:40:06 --> Language Class Initialized
INFO - 2016-10-10 10:40:06 --> Language Class Initialized
INFO - 2016-10-10 10:40:06 --> Config Class Initialized
INFO - 2016-10-10 10:40:06 --> Loader Class Initialized
INFO - 2016-10-10 10:40:06 --> Helper loaded: url_helper
INFO - 2016-10-10 10:40:06 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:40:06 --> Controller Class Initialized
DEBUG - 2016-10-10 10:40:06 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:40:06 --> Model Class Initialized
INFO - 2016-10-10 10:40:06 --> Model Class Initialized
ERROR - 2016-10-10 10:40:07 --> Unable to delete cache file for admin/index/perpanjang_angsuran
DEBUG - 2016-10-10 10:40:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 10:40:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 10:40:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 10:40:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_perpanjangan.php
DEBUG - 2016-10-10 10:40:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 10:40:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 10:40:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:08 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:40:09 --> Database Driver Class Initialized
DEBUG - 2016-10-10 10:40:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 10:40:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 10:40:10 --> Final output sent to browser
DEBUG - 2016-10-10 10:40:10 --> Total execution time: 3.8770
INFO - 2016-10-10 10:41:46 --> Config Class Initialized
INFO - 2016-10-10 10:41:46 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:41:46 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:41:46 --> Utf8 Class Initialized
INFO - 2016-10-10 10:41:46 --> URI Class Initialized
INFO - 2016-10-10 10:41:46 --> Router Class Initialized
INFO - 2016-10-10 10:41:46 --> Output Class Initialized
INFO - 2016-10-10 10:41:46 --> Security Class Initialized
DEBUG - 2016-10-10 10:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:41:47 --> Input Class Initialized
INFO - 2016-10-10 10:41:47 --> Language Class Initialized
INFO - 2016-10-10 10:41:47 --> Language Class Initialized
INFO - 2016-10-10 10:41:47 --> Config Class Initialized
INFO - 2016-10-10 10:41:47 --> Loader Class Initialized
INFO - 2016-10-10 10:41:47 --> Helper loaded: url_helper
INFO - 2016-10-10 10:41:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:41:47 --> Controller Class Initialized
DEBUG - 2016-10-10 10:41:47 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:41:47 --> Model Class Initialized
INFO - 2016-10-10 10:41:47 --> Model Class Initialized
ERROR - 2016-10-10 10:41:47 --> Unable to delete cache file for admin/index/list_jaminan
DEBUG - 2016-10-10 10:41:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 10:41:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 10:41:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 10:41:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/jaminan.php
DEBUG - 2016-10-10 10:41:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 10:41:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 10:41:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:48 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:48 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:48 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:48 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:48 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:48 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:48 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:48 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:48 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:48 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:48 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:48 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:48 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:48 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:48 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:48 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:48 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:48 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:48 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:48 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:48 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:48 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:48 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:49 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:49 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:49 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:49 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:49 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:49 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:49 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:49 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:49 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:49 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:49 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:49 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:49 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:49 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:49 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:49 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:49 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:49 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:49 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:49 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:49 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:50 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:50 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:50 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:50 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:50 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:50 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:50 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:50 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:50 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:50 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:50 --> Database Driver Class Initialized
INFO - 2016-10-10 10:41:50 --> Database Driver Class Initialized
DEBUG - 2016-10-10 10:41:50 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 10:41:50 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 10:41:50 --> Final output sent to browser
DEBUG - 2016-10-10 10:41:50 --> Total execution time: 4.0536
INFO - 2016-10-10 10:42:37 --> Config Class Initialized
INFO - 2016-10-10 10:42:37 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:42:37 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:42:37 --> Utf8 Class Initialized
INFO - 2016-10-10 10:42:37 --> URI Class Initialized
INFO - 2016-10-10 10:42:37 --> Router Class Initialized
INFO - 2016-10-10 10:42:37 --> Output Class Initialized
INFO - 2016-10-10 10:42:37 --> Security Class Initialized
DEBUG - 2016-10-10 10:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:42:37 --> Input Class Initialized
INFO - 2016-10-10 10:42:37 --> Language Class Initialized
INFO - 2016-10-10 10:42:37 --> Language Class Initialized
INFO - 2016-10-10 10:42:37 --> Config Class Initialized
INFO - 2016-10-10 10:42:37 --> Loader Class Initialized
INFO - 2016-10-10 10:42:37 --> Helper loaded: url_helper
INFO - 2016-10-10 10:42:37 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:42:37 --> Controller Class Initialized
DEBUG - 2016-10-10 10:42:37 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:42:37 --> Model Class Initialized
INFO - 2016-10-10 10:42:37 --> Model Class Initialized
ERROR - 2016-10-10 10:42:37 --> Unable to delete cache file for admin/index/data_biaya
DEBUG - 2016-10-10 10:42:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 10:42:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 10:42:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 10:42:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_biaya.php
DEBUG - 2016-10-10 10:42:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 10:42:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 10:42:38 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:38 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:38 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:38 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:38 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:38 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:38 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:38 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:38 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:38 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:38 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:38 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:38 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:38 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:38 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:39 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:39 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:39 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:39 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:39 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:39 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:39 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:39 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:39 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:39 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:39 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:39 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:39 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:39 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:39 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:39 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:39 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:39 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:39 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:39 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:39 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:39 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:39 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:40 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:40 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:40 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:40 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:40 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:40 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:40 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:40 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:40 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:40 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:40 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:40 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:40 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:40 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:40 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:40 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:40 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:40 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:40 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:40 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:40 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:41 --> Database Driver Class Initialized
DEBUG - 2016-10-10 10:42:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 10:42:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 10:42:41 --> Final output sent to browser
DEBUG - 2016-10-10 10:42:41 --> Total execution time: 4.0300
INFO - 2016-10-10 10:42:44 --> Config Class Initialized
INFO - 2016-10-10 10:42:44 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:42:44 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:42:44 --> Utf8 Class Initialized
INFO - 2016-10-10 10:42:44 --> URI Class Initialized
INFO - 2016-10-10 10:42:45 --> Router Class Initialized
INFO - 2016-10-10 10:42:45 --> Output Class Initialized
INFO - 2016-10-10 10:42:45 --> Security Class Initialized
DEBUG - 2016-10-10 10:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:42:45 --> Input Class Initialized
INFO - 2016-10-10 10:42:45 --> Language Class Initialized
INFO - 2016-10-10 10:42:45 --> Language Class Initialized
INFO - 2016-10-10 10:42:45 --> Config Class Initialized
INFO - 2016-10-10 10:42:45 --> Loader Class Initialized
INFO - 2016-10-10 10:42:45 --> Helper loaded: url_helper
INFO - 2016-10-10 10:42:45 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:42:45 --> Controller Class Initialized
DEBUG - 2016-10-10 10:42:45 --> Index MX_Controller Initialized
INFO - 2016-10-10 10:42:45 --> Model Class Initialized
INFO - 2016-10-10 10:42:45 --> Model Class Initialized
ERROR - 2016-10-10 10:42:46 --> Unable to delete cache file for admin/index/list_jaminan
DEBUG - 2016-10-10 10:42:46 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-10 10:42:46 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-10 10:42:46 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-10 10:42:46 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/jaminan.php
DEBUG - 2016-10-10 10:42:46 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-10 10:42:46 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-10 10:42:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:46 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:47 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:48 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:48 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:48 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:48 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:48 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:48 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:48 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:48 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:48 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:48 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:48 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:48 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:48 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:48 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:49 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:49 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:49 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:49 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:49 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:49 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:49 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:49 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:49 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:49 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:49 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:49 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:49 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:49 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:49 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:49 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:49 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:50 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:50 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:50 --> Database Driver Class Initialized
DEBUG - 2016-10-10 10:42:50 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-10 10:42:50 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-10 10:42:50 --> Final output sent to browser
DEBUG - 2016-10-10 10:42:50 --> Total execution time: 5.8372
