<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-10-02 01:17:04 --> Config Class Initialized
INFO - 2016-10-02 01:17:04 --> Hooks Class Initialized
DEBUG - 2016-10-02 01:17:04 --> UTF-8 Support Enabled
INFO - 2016-10-02 01:17:04 --> Utf8 Class Initialized
INFO - 2016-10-02 01:17:04 --> URI Class Initialized
DEBUG - 2016-10-02 01:17:04 --> No URI present. Default controller set.
INFO - 2016-10-02 01:17:04 --> Router Class Initialized
INFO - 2016-10-02 01:17:04 --> Output Class Initialized
INFO - 2016-10-02 01:17:04 --> Security Class Initialized
DEBUG - 2016-10-02 01:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 01:17:04 --> Input Class Initialized
INFO - 2016-10-02 01:17:04 --> Language Class Initialized
INFO - 2016-10-02 01:17:04 --> Language Class Initialized
INFO - 2016-10-02 01:17:04 --> Config Class Initialized
INFO - 2016-10-02 01:17:04 --> Loader Class Initialized
INFO - 2016-10-02 01:17:04 --> Helper loaded: url_helper
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-02 01:17:04 --> Controller Class Initialized
DEBUG - 2016-10-02 01:17:04 --> Index MX_Controller Initialized
INFO - 2016-10-02 01:17:04 --> Model Class Initialized
INFO - 2016-10-02 01:17:04 --> Model Class Initialized
ERROR - 2016-10-02 01:17:04 --> Unable to delete cache file for 
DEBUG - 2016-10-02 01:17:04 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-10-02 01:17:04 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-10-02 01:17:04 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-10-02 01:17:04 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-10-02 01:17:04 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-10-02 01:17:04 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
INFO - 2016-10-02 01:17:04 --> Database Driver Class Initialized
DEBUG - 2016-10-02 01:17:04 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-10-02 01:17:04 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-10-02 01:17:04 --> Final output sent to browser
DEBUG - 2016-10-02 01:17:04 --> Total execution time: 0.1864
INFO - 2016-10-02 01:17:04 --> Config Class Initialized
INFO - 2016-10-02 01:17:04 --> Hooks Class Initialized
DEBUG - 2016-10-02 01:17:04 --> UTF-8 Support Enabled
INFO - 2016-10-02 01:17:04 --> Utf8 Class Initialized
INFO - 2016-10-02 01:17:04 --> URI Class Initialized
INFO - 2016-10-02 01:17:04 --> Router Class Initialized
INFO - 2016-10-02 01:17:04 --> Output Class Initialized
INFO - 2016-10-02 01:17:04 --> Security Class Initialized
DEBUG - 2016-10-02 01:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 01:17:04 --> Input Class Initialized
INFO - 2016-10-02 01:17:04 --> Language Class Initialized
ERROR - 2016-10-02 01:17:04 --> 404 Page Not Found: /index
INFO - 2016-10-02 01:17:04 --> Config Class Initialized
INFO - 2016-10-02 01:17:04 --> Hooks Class Initialized
DEBUG - 2016-10-02 01:17:04 --> UTF-8 Support Enabled
INFO - 2016-10-02 01:17:04 --> Utf8 Class Initialized
INFO - 2016-10-02 01:17:04 --> URI Class Initialized
INFO - 2016-10-02 01:17:04 --> Router Class Initialized
INFO - 2016-10-02 01:17:04 --> Output Class Initialized
INFO - 2016-10-02 01:17:04 --> Security Class Initialized
DEBUG - 2016-10-02 01:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 01:17:04 --> Input Class Initialized
INFO - 2016-10-02 01:17:04 --> Language Class Initialized
ERROR - 2016-10-02 01:17:04 --> 404 Page Not Found: /index
INFO - 2016-10-02 01:17:04 --> Config Class Initialized
INFO - 2016-10-02 01:17:04 --> Hooks Class Initialized
DEBUG - 2016-10-02 01:17:04 --> UTF-8 Support Enabled
INFO - 2016-10-02 01:17:04 --> Utf8 Class Initialized
INFO - 2016-10-02 01:17:04 --> URI Class Initialized
INFO - 2016-10-02 01:17:04 --> Router Class Initialized
INFO - 2016-10-02 01:17:04 --> Output Class Initialized
INFO - 2016-10-02 01:17:04 --> Security Class Initialized
DEBUG - 2016-10-02 01:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 01:17:04 --> Input Class Initialized
INFO - 2016-10-02 01:17:04 --> Language Class Initialized
ERROR - 2016-10-02 01:17:04 --> 404 Page Not Found: /index
INFO - 2016-10-02 01:17:04 --> Config Class Initialized
INFO - 2016-10-02 01:17:04 --> Hooks Class Initialized
DEBUG - 2016-10-02 01:17:04 --> UTF-8 Support Enabled
INFO - 2016-10-02 01:17:04 --> Utf8 Class Initialized
INFO - 2016-10-02 01:17:04 --> URI Class Initialized
INFO - 2016-10-02 01:17:04 --> Router Class Initialized
INFO - 2016-10-02 01:17:04 --> Output Class Initialized
INFO - 2016-10-02 01:17:04 --> Security Class Initialized
DEBUG - 2016-10-02 01:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 01:17:04 --> Input Class Initialized
INFO - 2016-10-02 01:17:04 --> Language Class Initialized
ERROR - 2016-10-02 01:17:04 --> 404 Page Not Found: /index
INFO - 2016-10-02 01:17:04 --> Config Class Initialized
INFO - 2016-10-02 01:17:04 --> Hooks Class Initialized
DEBUG - 2016-10-02 01:17:04 --> UTF-8 Support Enabled
INFO - 2016-10-02 01:17:04 --> Utf8 Class Initialized
INFO - 2016-10-02 01:17:04 --> URI Class Initialized
INFO - 2016-10-02 01:17:04 --> Router Class Initialized
INFO - 2016-10-02 01:17:04 --> Output Class Initialized
INFO - 2016-10-02 01:17:04 --> Security Class Initialized
DEBUG - 2016-10-02 01:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 01:17:04 --> Input Class Initialized
INFO - 2016-10-02 01:17:04 --> Language Class Initialized
ERROR - 2016-10-02 01:17:04 --> 404 Page Not Found: /index
INFO - 2016-10-02 01:17:04 --> Config Class Initialized
INFO - 2016-10-02 01:17:04 --> Hooks Class Initialized
DEBUG - 2016-10-02 01:17:04 --> UTF-8 Support Enabled
INFO - 2016-10-02 01:17:04 --> Utf8 Class Initialized
INFO - 2016-10-02 01:17:04 --> URI Class Initialized
INFO - 2016-10-02 01:17:04 --> Router Class Initialized
INFO - 2016-10-02 01:17:04 --> Output Class Initialized
INFO - 2016-10-02 01:17:04 --> Security Class Initialized
DEBUG - 2016-10-02 01:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 01:17:04 --> Input Class Initialized
INFO - 2016-10-02 01:17:04 --> Language Class Initialized
ERROR - 2016-10-02 01:17:04 --> 404 Page Not Found: /index
INFO - 2016-10-02 01:17:04 --> Config Class Initialized
INFO - 2016-10-02 01:17:04 --> Hooks Class Initialized
DEBUG - 2016-10-02 01:17:04 --> UTF-8 Support Enabled
INFO - 2016-10-02 01:17:04 --> Utf8 Class Initialized
INFO - 2016-10-02 01:17:04 --> URI Class Initialized
INFO - 2016-10-02 01:17:04 --> Router Class Initialized
INFO - 2016-10-02 01:17:04 --> Output Class Initialized
INFO - 2016-10-02 01:17:04 --> Security Class Initialized
DEBUG - 2016-10-02 01:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 01:17:04 --> Input Class Initialized
INFO - 2016-10-02 01:17:04 --> Language Class Initialized
ERROR - 2016-10-02 01:17:04 --> 404 Page Not Found: /index
INFO - 2016-10-02 01:17:04 --> Config Class Initialized
INFO - 2016-10-02 01:17:04 --> Hooks Class Initialized
DEBUG - 2016-10-02 01:17:04 --> UTF-8 Support Enabled
INFO - 2016-10-02 01:17:04 --> Utf8 Class Initialized
INFO - 2016-10-02 01:17:04 --> URI Class Initialized
INFO - 2016-10-02 01:17:04 --> Router Class Initialized
INFO - 2016-10-02 01:17:04 --> Output Class Initialized
INFO - 2016-10-02 01:17:04 --> Security Class Initialized
DEBUG - 2016-10-02 01:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 01:17:04 --> Input Class Initialized
INFO - 2016-10-02 01:17:04 --> Language Class Initialized
ERROR - 2016-10-02 01:17:04 --> 404 Page Not Found: /index
INFO - 2016-10-02 01:17:05 --> Config Class Initialized
INFO - 2016-10-02 01:17:05 --> Hooks Class Initialized
DEBUG - 2016-10-02 01:17:05 --> UTF-8 Support Enabled
INFO - 2016-10-02 01:17:05 --> Utf8 Class Initialized
INFO - 2016-10-02 01:17:05 --> URI Class Initialized
INFO - 2016-10-02 01:17:05 --> Router Class Initialized
INFO - 2016-10-02 01:17:05 --> Output Class Initialized
INFO - 2016-10-02 01:17:05 --> Security Class Initialized
DEBUG - 2016-10-02 01:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 01:17:05 --> Input Class Initialized
INFO - 2016-10-02 01:17:05 --> Language Class Initialized
ERROR - 2016-10-02 01:17:05 --> 404 Page Not Found: /index
INFO - 2016-10-02 01:17:05 --> Config Class Initialized
INFO - 2016-10-02 01:17:05 --> Hooks Class Initialized
DEBUG - 2016-10-02 01:17:05 --> UTF-8 Support Enabled
INFO - 2016-10-02 01:17:05 --> Utf8 Class Initialized
INFO - 2016-10-02 01:17:05 --> URI Class Initialized
INFO - 2016-10-02 01:17:05 --> Router Class Initialized
INFO - 2016-10-02 01:17:05 --> Output Class Initialized
INFO - 2016-10-02 01:17:05 --> Security Class Initialized
DEBUG - 2016-10-02 01:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 01:17:05 --> Input Class Initialized
INFO - 2016-10-02 01:17:05 --> Language Class Initialized
ERROR - 2016-10-02 01:17:05 --> 404 Page Not Found: /index
INFO - 2016-10-02 01:17:05 --> Config Class Initialized
INFO - 2016-10-02 01:17:05 --> Hooks Class Initialized
DEBUG - 2016-10-02 01:17:05 --> UTF-8 Support Enabled
INFO - 2016-10-02 01:17:05 --> Utf8 Class Initialized
INFO - 2016-10-02 01:17:05 --> URI Class Initialized
INFO - 2016-10-02 01:17:05 --> Router Class Initialized
INFO - 2016-10-02 01:17:05 --> Output Class Initialized
INFO - 2016-10-02 01:17:05 --> Security Class Initialized
DEBUG - 2016-10-02 01:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 01:17:05 --> Input Class Initialized
INFO - 2016-10-02 01:17:05 --> Language Class Initialized
ERROR - 2016-10-02 01:17:05 --> 404 Page Not Found: /index
INFO - 2016-10-02 01:17:05 --> Config Class Initialized
INFO - 2016-10-02 01:17:05 --> Hooks Class Initialized
DEBUG - 2016-10-02 01:17:05 --> UTF-8 Support Enabled
INFO - 2016-10-02 01:17:05 --> Utf8 Class Initialized
INFO - 2016-10-02 01:17:05 --> URI Class Initialized
INFO - 2016-10-02 01:17:05 --> Router Class Initialized
INFO - 2016-10-02 01:17:05 --> Output Class Initialized
INFO - 2016-10-02 01:17:05 --> Security Class Initialized
DEBUG - 2016-10-02 01:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 01:17:05 --> Input Class Initialized
INFO - 2016-10-02 01:17:05 --> Language Class Initialized
ERROR - 2016-10-02 01:17:05 --> 404 Page Not Found: /index
INFO - 2016-10-02 01:17:05 --> Config Class Initialized
INFO - 2016-10-02 01:17:05 --> Hooks Class Initialized
DEBUG - 2016-10-02 01:17:05 --> UTF-8 Support Enabled
INFO - 2016-10-02 01:17:05 --> Utf8 Class Initialized
INFO - 2016-10-02 01:17:05 --> URI Class Initialized
INFO - 2016-10-02 01:17:05 --> Router Class Initialized
INFO - 2016-10-02 01:17:05 --> Output Class Initialized
INFO - 2016-10-02 01:17:05 --> Security Class Initialized
DEBUG - 2016-10-02 01:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 01:17:05 --> Input Class Initialized
INFO - 2016-10-02 01:17:05 --> Language Class Initialized
ERROR - 2016-10-02 01:17:05 --> 404 Page Not Found: /index
INFO - 2016-10-02 01:17:05 --> Config Class Initialized
INFO - 2016-10-02 01:17:05 --> Hooks Class Initialized
DEBUG - 2016-10-02 01:17:05 --> UTF-8 Support Enabled
INFO - 2016-10-02 01:17:05 --> Utf8 Class Initialized
INFO - 2016-10-02 01:17:05 --> URI Class Initialized
INFO - 2016-10-02 01:17:05 --> Router Class Initialized
INFO - 2016-10-02 01:17:05 --> Output Class Initialized
INFO - 2016-10-02 01:17:05 --> Security Class Initialized
DEBUG - 2016-10-02 01:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 01:17:05 --> Input Class Initialized
INFO - 2016-10-02 01:17:05 --> Language Class Initialized
ERROR - 2016-10-02 01:17:05 --> 404 Page Not Found: /index
INFO - 2016-10-02 02:17:59 --> Config Class Initialized
INFO - 2016-10-02 02:17:59 --> Hooks Class Initialized
DEBUG - 2016-10-02 02:17:59 --> UTF-8 Support Enabled
INFO - 2016-10-02 02:17:59 --> Utf8 Class Initialized
INFO - 2016-10-02 02:17:59 --> URI Class Initialized
INFO - 2016-10-02 02:17:59 --> Router Class Initialized
INFO - 2016-10-02 02:17:59 --> Output Class Initialized
INFO - 2016-10-02 02:17:59 --> Security Class Initialized
DEBUG - 2016-10-02 02:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 02:17:59 --> Input Class Initialized
INFO - 2016-10-02 02:17:59 --> Language Class Initialized
ERROR - 2016-10-02 02:17:59 --> 404 Page Not Found: /index
INFO - 2016-10-02 02:18:10 --> Config Class Initialized
INFO - 2016-10-02 02:18:10 --> Hooks Class Initialized
DEBUG - 2016-10-02 02:18:10 --> UTF-8 Support Enabled
INFO - 2016-10-02 02:18:10 --> Utf8 Class Initialized
INFO - 2016-10-02 02:18:10 --> URI Class Initialized
INFO - 2016-10-02 02:18:10 --> Router Class Initialized
INFO - 2016-10-02 02:18:10 --> Output Class Initialized
INFO - 2016-10-02 02:18:10 --> Security Class Initialized
DEBUG - 2016-10-02 02:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 02:18:10 --> Input Class Initialized
INFO - 2016-10-02 02:18:10 --> Language Class Initialized
ERROR - 2016-10-02 02:18:10 --> 404 Page Not Found: /index
INFO - 2016-10-02 03:01:52 --> Config Class Initialized
INFO - 2016-10-02 03:01:52 --> Hooks Class Initialized
DEBUG - 2016-10-02 03:01:52 --> UTF-8 Support Enabled
INFO - 2016-10-02 03:01:52 --> Utf8 Class Initialized
INFO - 2016-10-02 03:01:52 --> URI Class Initialized
INFO - 2016-10-02 03:01:52 --> Router Class Initialized
INFO - 2016-10-02 03:01:52 --> Output Class Initialized
INFO - 2016-10-02 03:01:52 --> Security Class Initialized
DEBUG - 2016-10-02 03:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 03:01:52 --> Input Class Initialized
INFO - 2016-10-02 03:01:52 --> Language Class Initialized
ERROR - 2016-10-02 03:01:52 --> 404 Page Not Found: /index
INFO - 2016-10-02 12:59:36 --> Config Class Initialized
INFO - 2016-10-02 12:59:36 --> Hooks Class Initialized
DEBUG - 2016-10-02 12:59:36 --> UTF-8 Support Enabled
INFO - 2016-10-02 12:59:36 --> Utf8 Class Initialized
INFO - 2016-10-02 12:59:36 --> URI Class Initialized
DEBUG - 2016-10-02 12:59:36 --> No URI present. Default controller set.
INFO - 2016-10-02 12:59:36 --> Router Class Initialized
INFO - 2016-10-02 12:59:36 --> Output Class Initialized
INFO - 2016-10-02 12:59:36 --> Security Class Initialized
DEBUG - 2016-10-02 12:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 12:59:36 --> Input Class Initialized
INFO - 2016-10-02 12:59:36 --> Language Class Initialized
INFO - 2016-10-02 12:59:36 --> Language Class Initialized
INFO - 2016-10-02 12:59:36 --> Config Class Initialized
INFO - 2016-10-02 12:59:36 --> Loader Class Initialized
INFO - 2016-10-02 12:59:36 --> Helper loaded: url_helper
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-02 12:59:36 --> Controller Class Initialized
DEBUG - 2016-10-02 12:59:36 --> Index MX_Controller Initialized
INFO - 2016-10-02 12:59:36 --> Model Class Initialized
INFO - 2016-10-02 12:59:36 --> Model Class Initialized
ERROR - 2016-10-02 12:59:36 --> Unable to delete cache file for 
DEBUG - 2016-10-02 12:59:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-10-02 12:59:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-10-02 12:59:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-10-02 12:59:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-10-02 12:59:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-10-02 12:59:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
INFO - 2016-10-02 12:59:36 --> Database Driver Class Initialized
DEBUG - 2016-10-02 12:59:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-10-02 12:59:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-10-02 12:59:36 --> Final output sent to browser
DEBUG - 2016-10-02 12:59:36 --> Total execution time: 0.2130
INFO - 2016-10-02 12:59:36 --> Config Class Initialized
INFO - 2016-10-02 12:59:36 --> Hooks Class Initialized
DEBUG - 2016-10-02 12:59:36 --> UTF-8 Support Enabled
INFO - 2016-10-02 12:59:36 --> Utf8 Class Initialized
INFO - 2016-10-02 12:59:36 --> URI Class Initialized
INFO - 2016-10-02 12:59:36 --> Router Class Initialized
INFO - 2016-10-02 12:59:36 --> Output Class Initialized
INFO - 2016-10-02 12:59:36 --> Security Class Initialized
DEBUG - 2016-10-02 12:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 12:59:36 --> Input Class Initialized
INFO - 2016-10-02 12:59:36 --> Language Class Initialized
ERROR - 2016-10-02 12:59:36 --> 404 Page Not Found: /index
INFO - 2016-10-02 12:59:36 --> Config Class Initialized
INFO - 2016-10-02 12:59:36 --> Hooks Class Initialized
DEBUG - 2016-10-02 12:59:36 --> UTF-8 Support Enabled
INFO - 2016-10-02 12:59:36 --> Utf8 Class Initialized
INFO - 2016-10-02 12:59:37 --> URI Class Initialized
INFO - 2016-10-02 12:59:37 --> Router Class Initialized
INFO - 2016-10-02 12:59:37 --> Output Class Initialized
INFO - 2016-10-02 12:59:37 --> Security Class Initialized
DEBUG - 2016-10-02 12:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 12:59:37 --> Input Class Initialized
INFO - 2016-10-02 12:59:37 --> Language Class Initialized
ERROR - 2016-10-02 12:59:37 --> 404 Page Not Found: /index
INFO - 2016-10-02 12:59:37 --> Config Class Initialized
INFO - 2016-10-02 12:59:37 --> Hooks Class Initialized
DEBUG - 2016-10-02 12:59:37 --> UTF-8 Support Enabled
INFO - 2016-10-02 12:59:37 --> Utf8 Class Initialized
INFO - 2016-10-02 12:59:37 --> URI Class Initialized
INFO - 2016-10-02 12:59:37 --> Router Class Initialized
INFO - 2016-10-02 12:59:37 --> Output Class Initialized
INFO - 2016-10-02 12:59:37 --> Security Class Initialized
DEBUG - 2016-10-02 12:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 12:59:37 --> Input Class Initialized
INFO - 2016-10-02 12:59:37 --> Language Class Initialized
ERROR - 2016-10-02 12:59:37 --> 404 Page Not Found: /index
INFO - 2016-10-02 12:59:37 --> Config Class Initialized
INFO - 2016-10-02 12:59:37 --> Hooks Class Initialized
DEBUG - 2016-10-02 12:59:37 --> UTF-8 Support Enabled
INFO - 2016-10-02 12:59:37 --> Utf8 Class Initialized
INFO - 2016-10-02 12:59:37 --> URI Class Initialized
INFO - 2016-10-02 12:59:37 --> Router Class Initialized
INFO - 2016-10-02 12:59:37 --> Output Class Initialized
INFO - 2016-10-02 12:59:37 --> Security Class Initialized
DEBUG - 2016-10-02 12:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 12:59:37 --> Input Class Initialized
INFO - 2016-10-02 12:59:37 --> Language Class Initialized
ERROR - 2016-10-02 12:59:37 --> 404 Page Not Found: /index
INFO - 2016-10-02 12:59:37 --> Config Class Initialized
INFO - 2016-10-02 12:59:37 --> Hooks Class Initialized
DEBUG - 2016-10-02 12:59:37 --> UTF-8 Support Enabled
INFO - 2016-10-02 12:59:37 --> Utf8 Class Initialized
INFO - 2016-10-02 12:59:37 --> URI Class Initialized
INFO - 2016-10-02 12:59:37 --> Router Class Initialized
INFO - 2016-10-02 12:59:37 --> Output Class Initialized
INFO - 2016-10-02 12:59:37 --> Security Class Initialized
DEBUG - 2016-10-02 12:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 12:59:37 --> Input Class Initialized
INFO - 2016-10-02 12:59:37 --> Language Class Initialized
ERROR - 2016-10-02 12:59:37 --> 404 Page Not Found: /index
INFO - 2016-10-02 12:59:37 --> Config Class Initialized
INFO - 2016-10-02 12:59:37 --> Hooks Class Initialized
DEBUG - 2016-10-02 12:59:37 --> UTF-8 Support Enabled
INFO - 2016-10-02 12:59:37 --> Utf8 Class Initialized
INFO - 2016-10-02 12:59:37 --> URI Class Initialized
INFO - 2016-10-02 12:59:37 --> Router Class Initialized
INFO - 2016-10-02 12:59:37 --> Output Class Initialized
INFO - 2016-10-02 12:59:37 --> Security Class Initialized
DEBUG - 2016-10-02 12:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 12:59:37 --> Input Class Initialized
INFO - 2016-10-02 12:59:37 --> Language Class Initialized
ERROR - 2016-10-02 12:59:37 --> 404 Page Not Found: /index
INFO - 2016-10-02 12:59:38 --> Config Class Initialized
INFO - 2016-10-02 12:59:38 --> Hooks Class Initialized
DEBUG - 2016-10-02 12:59:38 --> UTF-8 Support Enabled
INFO - 2016-10-02 12:59:38 --> Utf8 Class Initialized
INFO - 2016-10-02 12:59:38 --> URI Class Initialized
INFO - 2016-10-02 12:59:38 --> Router Class Initialized
INFO - 2016-10-02 12:59:38 --> Output Class Initialized
INFO - 2016-10-02 12:59:38 --> Security Class Initialized
DEBUG - 2016-10-02 12:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 12:59:38 --> Input Class Initialized
INFO - 2016-10-02 12:59:38 --> Language Class Initialized
ERROR - 2016-10-02 12:59:38 --> 404 Page Not Found: /index
INFO - 2016-10-02 12:59:38 --> Config Class Initialized
INFO - 2016-10-02 12:59:38 --> Hooks Class Initialized
DEBUG - 2016-10-02 12:59:38 --> UTF-8 Support Enabled
INFO - 2016-10-02 12:59:38 --> Utf8 Class Initialized
INFO - 2016-10-02 12:59:38 --> URI Class Initialized
INFO - 2016-10-02 12:59:38 --> Router Class Initialized
INFO - 2016-10-02 12:59:38 --> Output Class Initialized
INFO - 2016-10-02 12:59:38 --> Security Class Initialized
DEBUG - 2016-10-02 12:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 12:59:38 --> Input Class Initialized
INFO - 2016-10-02 12:59:38 --> Language Class Initialized
ERROR - 2016-10-02 12:59:38 --> 404 Page Not Found: /index
INFO - 2016-10-02 12:59:38 --> Config Class Initialized
INFO - 2016-10-02 12:59:38 --> Hooks Class Initialized
DEBUG - 2016-10-02 12:59:38 --> UTF-8 Support Enabled
INFO - 2016-10-02 12:59:38 --> Utf8 Class Initialized
INFO - 2016-10-02 12:59:38 --> URI Class Initialized
INFO - 2016-10-02 12:59:38 --> Router Class Initialized
INFO - 2016-10-02 12:59:38 --> Output Class Initialized
INFO - 2016-10-02 12:59:38 --> Security Class Initialized
DEBUG - 2016-10-02 12:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 12:59:38 --> Input Class Initialized
INFO - 2016-10-02 12:59:38 --> Language Class Initialized
ERROR - 2016-10-02 12:59:38 --> 404 Page Not Found: /index
INFO - 2016-10-02 12:59:38 --> Config Class Initialized
INFO - 2016-10-02 12:59:38 --> Hooks Class Initialized
DEBUG - 2016-10-02 12:59:38 --> UTF-8 Support Enabled
INFO - 2016-10-02 12:59:38 --> Utf8 Class Initialized
INFO - 2016-10-02 12:59:38 --> URI Class Initialized
INFO - 2016-10-02 12:59:38 --> Router Class Initialized
INFO - 2016-10-02 12:59:38 --> Output Class Initialized
INFO - 2016-10-02 12:59:38 --> Security Class Initialized
DEBUG - 2016-10-02 12:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 12:59:38 --> Input Class Initialized
INFO - 2016-10-02 12:59:38 --> Language Class Initialized
ERROR - 2016-10-02 12:59:38 --> 404 Page Not Found: /index
INFO - 2016-10-02 12:59:39 --> Config Class Initialized
INFO - 2016-10-02 12:59:39 --> Hooks Class Initialized
DEBUG - 2016-10-02 12:59:39 --> UTF-8 Support Enabled
INFO - 2016-10-02 12:59:39 --> Utf8 Class Initialized
INFO - 2016-10-02 12:59:39 --> URI Class Initialized
INFO - 2016-10-02 12:59:39 --> Router Class Initialized
INFO - 2016-10-02 12:59:39 --> Output Class Initialized
INFO - 2016-10-02 12:59:39 --> Security Class Initialized
DEBUG - 2016-10-02 12:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 12:59:39 --> Input Class Initialized
INFO - 2016-10-02 12:59:39 --> Language Class Initialized
ERROR - 2016-10-02 12:59:39 --> 404 Page Not Found: /index
INFO - 2016-10-02 12:59:39 --> Config Class Initialized
INFO - 2016-10-02 12:59:39 --> Hooks Class Initialized
DEBUG - 2016-10-02 12:59:39 --> UTF-8 Support Enabled
INFO - 2016-10-02 12:59:39 --> Utf8 Class Initialized
INFO - 2016-10-02 12:59:39 --> URI Class Initialized
INFO - 2016-10-02 12:59:39 --> Router Class Initialized
INFO - 2016-10-02 12:59:39 --> Output Class Initialized
INFO - 2016-10-02 12:59:39 --> Security Class Initialized
DEBUG - 2016-10-02 12:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 12:59:39 --> Input Class Initialized
INFO - 2016-10-02 12:59:39 --> Language Class Initialized
ERROR - 2016-10-02 12:59:39 --> 404 Page Not Found: /index
INFO - 2016-10-02 12:59:39 --> Config Class Initialized
INFO - 2016-10-02 12:59:39 --> Hooks Class Initialized
DEBUG - 2016-10-02 12:59:39 --> UTF-8 Support Enabled
INFO - 2016-10-02 12:59:39 --> Utf8 Class Initialized
INFO - 2016-10-02 12:59:39 --> URI Class Initialized
INFO - 2016-10-02 12:59:39 --> Router Class Initialized
INFO - 2016-10-02 12:59:39 --> Output Class Initialized
INFO - 2016-10-02 12:59:39 --> Security Class Initialized
DEBUG - 2016-10-02 12:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 12:59:39 --> Input Class Initialized
INFO - 2016-10-02 12:59:39 --> Language Class Initialized
ERROR - 2016-10-02 12:59:39 --> 404 Page Not Found: /index
INFO - 2016-10-02 12:59:39 --> Config Class Initialized
INFO - 2016-10-02 12:59:39 --> Hooks Class Initialized
DEBUG - 2016-10-02 12:59:39 --> UTF-8 Support Enabled
INFO - 2016-10-02 12:59:39 --> Utf8 Class Initialized
INFO - 2016-10-02 12:59:39 --> URI Class Initialized
INFO - 2016-10-02 12:59:39 --> Router Class Initialized
INFO - 2016-10-02 12:59:39 --> Output Class Initialized
INFO - 2016-10-02 12:59:39 --> Security Class Initialized
DEBUG - 2016-10-02 12:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 12:59:39 --> Input Class Initialized
INFO - 2016-10-02 12:59:39 --> Language Class Initialized
ERROR - 2016-10-02 12:59:39 --> 404 Page Not Found: /index
INFO - 2016-10-02 13:11:40 --> Config Class Initialized
INFO - 2016-10-02 13:11:40 --> Hooks Class Initialized
DEBUG - 2016-10-02 13:11:40 --> UTF-8 Support Enabled
INFO - 2016-10-02 13:11:40 --> Utf8 Class Initialized
INFO - 2016-10-02 13:11:40 --> URI Class Initialized
DEBUG - 2016-10-02 13:11:41 --> No URI present. Default controller set.
INFO - 2016-10-02 13:11:41 --> Router Class Initialized
INFO - 2016-10-02 13:11:41 --> Output Class Initialized
INFO - 2016-10-02 13:11:41 --> Security Class Initialized
DEBUG - 2016-10-02 13:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 13:11:41 --> Input Class Initialized
INFO - 2016-10-02 13:11:41 --> Language Class Initialized
INFO - 2016-10-02 13:11:41 --> Language Class Initialized
INFO - 2016-10-02 13:11:41 --> Config Class Initialized
INFO - 2016-10-02 13:11:41 --> Loader Class Initialized
INFO - 2016-10-02 13:11:41 --> Helper loaded: url_helper
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-02 13:11:41 --> Controller Class Initialized
DEBUG - 2016-10-02 13:11:41 --> Index MX_Controller Initialized
INFO - 2016-10-02 13:11:41 --> Model Class Initialized
INFO - 2016-10-02 13:11:41 --> Model Class Initialized
ERROR - 2016-10-02 13:11:41 --> Unable to delete cache file for 
DEBUG - 2016-10-02 13:11:41 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-10-02 13:11:41 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-10-02 13:11:41 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-10-02 13:11:41 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-10-02 13:11:41 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-10-02 13:11:41 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
INFO - 2016-10-02 13:11:41 --> Database Driver Class Initialized
DEBUG - 2016-10-02 13:11:41 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-10-02 13:11:41 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-10-02 13:11:41 --> Final output sent to browser
DEBUG - 2016-10-02 13:11:41 --> Total execution time: 0.1669
INFO - 2016-10-02 13:11:41 --> Config Class Initialized
INFO - 2016-10-02 13:11:41 --> Hooks Class Initialized
DEBUG - 2016-10-02 13:11:41 --> UTF-8 Support Enabled
INFO - 2016-10-02 13:11:41 --> Utf8 Class Initialized
INFO - 2016-10-02 13:11:41 --> URI Class Initialized
INFO - 2016-10-02 13:11:41 --> Router Class Initialized
INFO - 2016-10-02 13:11:41 --> Output Class Initialized
INFO - 2016-10-02 13:11:41 --> Security Class Initialized
DEBUG - 2016-10-02 13:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 13:11:41 --> Input Class Initialized
INFO - 2016-10-02 13:11:41 --> Language Class Initialized
ERROR - 2016-10-02 13:11:41 --> 404 Page Not Found: /index
INFO - 2016-10-02 13:11:41 --> Config Class Initialized
INFO - 2016-10-02 13:11:41 --> Hooks Class Initialized
DEBUG - 2016-10-02 13:11:41 --> UTF-8 Support Enabled
INFO - 2016-10-02 13:11:41 --> Utf8 Class Initialized
INFO - 2016-10-02 13:11:41 --> URI Class Initialized
INFO - 2016-10-02 13:11:41 --> Router Class Initialized
INFO - 2016-10-02 13:11:41 --> Output Class Initialized
INFO - 2016-10-02 13:11:41 --> Security Class Initialized
DEBUG - 2016-10-02 13:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 13:11:41 --> Input Class Initialized
INFO - 2016-10-02 13:11:41 --> Language Class Initialized
ERROR - 2016-10-02 13:11:41 --> 404 Page Not Found: /index
INFO - 2016-10-02 13:11:41 --> Config Class Initialized
INFO - 2016-10-02 13:11:41 --> Hooks Class Initialized
DEBUG - 2016-10-02 13:11:41 --> UTF-8 Support Enabled
INFO - 2016-10-02 13:11:41 --> Utf8 Class Initialized
INFO - 2016-10-02 13:11:41 --> URI Class Initialized
INFO - 2016-10-02 13:11:41 --> Router Class Initialized
INFO - 2016-10-02 13:11:41 --> Output Class Initialized
INFO - 2016-10-02 13:11:41 --> Security Class Initialized
DEBUG - 2016-10-02 13:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 13:11:41 --> Input Class Initialized
INFO - 2016-10-02 13:11:41 --> Language Class Initialized
ERROR - 2016-10-02 13:11:41 --> 404 Page Not Found: /index
INFO - 2016-10-02 13:11:42 --> Config Class Initialized
INFO - 2016-10-02 13:11:42 --> Hooks Class Initialized
DEBUG - 2016-10-02 13:11:42 --> UTF-8 Support Enabled
INFO - 2016-10-02 13:11:42 --> Utf8 Class Initialized
INFO - 2016-10-02 13:11:42 --> URI Class Initialized
INFO - 2016-10-02 13:11:42 --> Router Class Initialized
INFO - 2016-10-02 13:11:42 --> Output Class Initialized
INFO - 2016-10-02 13:11:42 --> Security Class Initialized
DEBUG - 2016-10-02 13:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 13:11:42 --> Input Class Initialized
INFO - 2016-10-02 13:11:42 --> Language Class Initialized
ERROR - 2016-10-02 13:11:42 --> 404 Page Not Found: /index
INFO - 2016-10-02 13:11:42 --> Config Class Initialized
INFO - 2016-10-02 13:11:42 --> Hooks Class Initialized
DEBUG - 2016-10-02 13:11:42 --> UTF-8 Support Enabled
INFO - 2016-10-02 13:11:42 --> Utf8 Class Initialized
INFO - 2016-10-02 13:11:42 --> URI Class Initialized
INFO - 2016-10-02 13:11:42 --> Router Class Initialized
INFO - 2016-10-02 13:11:42 --> Output Class Initialized
INFO - 2016-10-02 13:11:42 --> Security Class Initialized
DEBUG - 2016-10-02 13:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 13:11:42 --> Input Class Initialized
INFO - 2016-10-02 13:11:42 --> Language Class Initialized
ERROR - 2016-10-02 13:11:42 --> 404 Page Not Found: /index
INFO - 2016-10-02 13:11:42 --> Config Class Initialized
INFO - 2016-10-02 13:11:42 --> Hooks Class Initialized
DEBUG - 2016-10-02 13:11:42 --> UTF-8 Support Enabled
INFO - 2016-10-02 13:11:42 --> Utf8 Class Initialized
INFO - 2016-10-02 13:11:42 --> URI Class Initialized
INFO - 2016-10-02 13:11:42 --> Router Class Initialized
INFO - 2016-10-02 13:11:42 --> Output Class Initialized
INFO - 2016-10-02 13:11:42 --> Security Class Initialized
DEBUG - 2016-10-02 13:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 13:11:42 --> Input Class Initialized
INFO - 2016-10-02 13:11:42 --> Language Class Initialized
ERROR - 2016-10-02 13:11:42 --> 404 Page Not Found: /index
INFO - 2016-10-02 13:11:42 --> Config Class Initialized
INFO - 2016-10-02 13:11:42 --> Hooks Class Initialized
DEBUG - 2016-10-02 13:11:42 --> UTF-8 Support Enabled
INFO - 2016-10-02 13:11:42 --> Utf8 Class Initialized
INFO - 2016-10-02 13:11:42 --> URI Class Initialized
INFO - 2016-10-02 13:11:42 --> Router Class Initialized
INFO - 2016-10-02 13:11:42 --> Output Class Initialized
INFO - 2016-10-02 13:11:42 --> Security Class Initialized
DEBUG - 2016-10-02 13:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 13:11:42 --> Input Class Initialized
INFO - 2016-10-02 13:11:42 --> Language Class Initialized
ERROR - 2016-10-02 13:11:42 --> 404 Page Not Found: /index
INFO - 2016-10-02 13:11:43 --> Config Class Initialized
INFO - 2016-10-02 13:11:43 --> Hooks Class Initialized
DEBUG - 2016-10-02 13:11:43 --> UTF-8 Support Enabled
INFO - 2016-10-02 13:11:43 --> Utf8 Class Initialized
INFO - 2016-10-02 13:11:43 --> URI Class Initialized
INFO - 2016-10-02 13:11:43 --> Router Class Initialized
INFO - 2016-10-02 13:11:43 --> Output Class Initialized
INFO - 2016-10-02 13:11:43 --> Security Class Initialized
DEBUG - 2016-10-02 13:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 13:11:43 --> Input Class Initialized
INFO - 2016-10-02 13:11:43 --> Language Class Initialized
ERROR - 2016-10-02 13:11:43 --> 404 Page Not Found: /index
INFO - 2016-10-02 13:11:43 --> Config Class Initialized
INFO - 2016-10-02 13:11:43 --> Hooks Class Initialized
DEBUG - 2016-10-02 13:11:43 --> UTF-8 Support Enabled
INFO - 2016-10-02 13:11:43 --> Utf8 Class Initialized
INFO - 2016-10-02 13:11:43 --> URI Class Initialized
INFO - 2016-10-02 13:11:43 --> Router Class Initialized
INFO - 2016-10-02 13:11:43 --> Output Class Initialized
INFO - 2016-10-02 13:11:43 --> Security Class Initialized
DEBUG - 2016-10-02 13:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 13:11:43 --> Input Class Initialized
INFO - 2016-10-02 13:11:43 --> Language Class Initialized
ERROR - 2016-10-02 13:11:43 --> 404 Page Not Found: /index
INFO - 2016-10-02 13:11:43 --> Config Class Initialized
INFO - 2016-10-02 13:11:43 --> Hooks Class Initialized
DEBUG - 2016-10-02 13:11:43 --> UTF-8 Support Enabled
INFO - 2016-10-02 13:11:43 --> Utf8 Class Initialized
INFO - 2016-10-02 13:11:43 --> URI Class Initialized
INFO - 2016-10-02 13:11:43 --> Router Class Initialized
INFO - 2016-10-02 13:11:43 --> Output Class Initialized
INFO - 2016-10-02 13:11:43 --> Security Class Initialized
DEBUG - 2016-10-02 13:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 13:11:43 --> Input Class Initialized
INFO - 2016-10-02 13:11:43 --> Language Class Initialized
ERROR - 2016-10-02 13:11:43 --> 404 Page Not Found: /index
INFO - 2016-10-02 13:11:43 --> Config Class Initialized
INFO - 2016-10-02 13:11:43 --> Hooks Class Initialized
DEBUG - 2016-10-02 13:11:43 --> UTF-8 Support Enabled
INFO - 2016-10-02 13:11:43 --> Utf8 Class Initialized
INFO - 2016-10-02 13:11:43 --> URI Class Initialized
INFO - 2016-10-02 13:11:43 --> Router Class Initialized
INFO - 2016-10-02 13:11:43 --> Output Class Initialized
INFO - 2016-10-02 13:11:43 --> Security Class Initialized
DEBUG - 2016-10-02 13:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 13:11:43 --> Input Class Initialized
INFO - 2016-10-02 13:11:43 --> Language Class Initialized
ERROR - 2016-10-02 13:11:43 --> 404 Page Not Found: /index
INFO - 2016-10-02 13:11:44 --> Config Class Initialized
INFO - 2016-10-02 13:11:44 --> Hooks Class Initialized
DEBUG - 2016-10-02 13:11:44 --> UTF-8 Support Enabled
INFO - 2016-10-02 13:11:44 --> Utf8 Class Initialized
INFO - 2016-10-02 13:11:44 --> URI Class Initialized
INFO - 2016-10-02 13:11:44 --> Router Class Initialized
INFO - 2016-10-02 13:11:44 --> Output Class Initialized
INFO - 2016-10-02 13:11:44 --> Security Class Initialized
DEBUG - 2016-10-02 13:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 13:11:44 --> Input Class Initialized
INFO - 2016-10-02 13:11:44 --> Language Class Initialized
ERROR - 2016-10-02 13:11:44 --> 404 Page Not Found: /index
INFO - 2016-10-02 13:11:44 --> Config Class Initialized
INFO - 2016-10-02 13:11:44 --> Hooks Class Initialized
DEBUG - 2016-10-02 13:11:44 --> UTF-8 Support Enabled
INFO - 2016-10-02 13:11:44 --> Utf8 Class Initialized
INFO - 2016-10-02 13:11:44 --> URI Class Initialized
INFO - 2016-10-02 13:11:44 --> Router Class Initialized
INFO - 2016-10-02 13:11:44 --> Output Class Initialized
INFO - 2016-10-02 13:11:44 --> Security Class Initialized
DEBUG - 2016-10-02 13:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 13:11:44 --> Input Class Initialized
INFO - 2016-10-02 13:11:44 --> Language Class Initialized
ERROR - 2016-10-02 13:11:44 --> 404 Page Not Found: /index
INFO - 2016-10-02 13:11:44 --> Config Class Initialized
INFO - 2016-10-02 13:11:44 --> Hooks Class Initialized
DEBUG - 2016-10-02 13:11:44 --> UTF-8 Support Enabled
INFO - 2016-10-02 13:11:44 --> Utf8 Class Initialized
INFO - 2016-10-02 13:11:44 --> URI Class Initialized
INFO - 2016-10-02 13:11:44 --> Router Class Initialized
INFO - 2016-10-02 13:11:44 --> Output Class Initialized
INFO - 2016-10-02 13:11:44 --> Security Class Initialized
DEBUG - 2016-10-02 13:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 13:11:44 --> Input Class Initialized
INFO - 2016-10-02 13:11:44 --> Language Class Initialized
ERROR - 2016-10-02 13:11:44 --> 404 Page Not Found: /index
INFO - 2016-10-02 13:24:36 --> Config Class Initialized
INFO - 2016-10-02 13:24:36 --> Hooks Class Initialized
DEBUG - 2016-10-02 13:24:36 --> UTF-8 Support Enabled
INFO - 2016-10-02 13:24:36 --> Utf8 Class Initialized
INFO - 2016-10-02 13:24:36 --> URI Class Initialized
INFO - 2016-10-02 13:24:36 --> Router Class Initialized
INFO - 2016-10-02 13:24:36 --> Output Class Initialized
INFO - 2016-10-02 13:24:36 --> Security Class Initialized
DEBUG - 2016-10-02 13:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 13:24:36 --> Input Class Initialized
INFO - 2016-10-02 13:24:36 --> Language Class Initialized
ERROR - 2016-10-02 13:24:36 --> 404 Page Not Found: /index
INFO - 2016-10-02 13:28:09 --> Config Class Initialized
INFO - 2016-10-02 13:28:09 --> Hooks Class Initialized
DEBUG - 2016-10-02 13:28:09 --> UTF-8 Support Enabled
INFO - 2016-10-02 13:28:09 --> Utf8 Class Initialized
INFO - 2016-10-02 13:28:09 --> URI Class Initialized
DEBUG - 2016-10-02 13:28:09 --> No URI present. Default controller set.
INFO - 2016-10-02 13:28:09 --> Router Class Initialized
INFO - 2016-10-02 13:28:09 --> Output Class Initialized
INFO - 2016-10-02 13:28:09 --> Security Class Initialized
DEBUG - 2016-10-02 13:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 13:28:09 --> Input Class Initialized
INFO - 2016-10-02 13:28:09 --> Language Class Initialized
INFO - 2016-10-02 13:28:09 --> Language Class Initialized
INFO - 2016-10-02 13:28:09 --> Config Class Initialized
INFO - 2016-10-02 13:28:09 --> Loader Class Initialized
INFO - 2016-10-02 13:28:09 --> Helper loaded: url_helper
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-02 13:28:09 --> Controller Class Initialized
DEBUG - 2016-10-02 13:28:09 --> Index MX_Controller Initialized
INFO - 2016-10-02 13:28:09 --> Model Class Initialized
INFO - 2016-10-02 13:28:09 --> Model Class Initialized
ERROR - 2016-10-02 13:28:09 --> Unable to delete cache file for 
DEBUG - 2016-10-02 13:28:09 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-10-02 13:28:09 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-10-02 13:28:09 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-10-02 13:28:09 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-10-02 13:28:09 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-10-02 13:28:09 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:09 --> Database Driver Class Initialized
DEBUG - 2016-10-02 13:28:09 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-10-02 13:28:09 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-10-02 13:28:09 --> Final output sent to browser
DEBUG - 2016-10-02 13:28:09 --> Total execution time: 0.2288
INFO - 2016-10-02 13:28:10 --> Config Class Initialized
INFO - 2016-10-02 13:28:10 --> Hooks Class Initialized
DEBUG - 2016-10-02 13:28:10 --> UTF-8 Support Enabled
INFO - 2016-10-02 13:28:10 --> Utf8 Class Initialized
INFO - 2016-10-02 13:28:10 --> URI Class Initialized
INFO - 2016-10-02 13:28:10 --> Router Class Initialized
INFO - 2016-10-02 13:28:10 --> Output Class Initialized
INFO - 2016-10-02 13:28:10 --> Security Class Initialized
DEBUG - 2016-10-02 13:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 13:28:10 --> Input Class Initialized
INFO - 2016-10-02 13:28:10 --> Language Class Initialized
INFO - 2016-10-02 13:28:10 --> Language Class Initialized
INFO - 2016-10-02 13:28:10 --> Config Class Initialized
INFO - 2016-10-02 13:28:10 --> Loader Class Initialized
INFO - 2016-10-02 13:28:10 --> Helper loaded: url_helper
INFO - 2016-10-02 13:28:10 --> Database Driver Class Initialized
INFO - 2016-10-02 13:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-02 13:28:10 --> Controller Class Initialized
DEBUG - 2016-10-02 13:28:10 --> login MX_Controller Initialized
INFO - 2016-10-02 13:28:10 --> Model Class Initialized
INFO - 2016-10-02 13:28:10 --> Model Class Initialized
DEBUG - 2016-10-02 13:28:10 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-10-02 13:28:10 --> Final output sent to browser
DEBUG - 2016-10-02 13:28:10 --> Total execution time: 0.0837
INFO - 2016-10-02 13:40:46 --> Config Class Initialized
INFO - 2016-10-02 13:40:46 --> Hooks Class Initialized
DEBUG - 2016-10-02 13:40:46 --> UTF-8 Support Enabled
INFO - 2016-10-02 13:40:46 --> Utf8 Class Initialized
INFO - 2016-10-02 13:40:46 --> URI Class Initialized
DEBUG - 2016-10-02 13:40:46 --> No URI present. Default controller set.
INFO - 2016-10-02 13:40:46 --> Router Class Initialized
INFO - 2016-10-02 13:40:46 --> Output Class Initialized
INFO - 2016-10-02 13:40:46 --> Security Class Initialized
DEBUG - 2016-10-02 13:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 13:40:46 --> Input Class Initialized
INFO - 2016-10-02 13:40:46 --> Language Class Initialized
INFO - 2016-10-02 13:40:46 --> Language Class Initialized
INFO - 2016-10-02 13:40:46 --> Config Class Initialized
INFO - 2016-10-02 13:40:46 --> Loader Class Initialized
INFO - 2016-10-02 13:40:46 --> Helper loaded: url_helper
INFO - 2016-10-02 13:40:46 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-02 13:40:46 --> Controller Class Initialized
DEBUG - 2016-10-02 13:40:46 --> Index MX_Controller Initialized
INFO - 2016-10-02 13:40:46 --> Model Class Initialized
INFO - 2016-10-02 13:40:46 --> Model Class Initialized
ERROR - 2016-10-02 13:40:46 --> Unable to delete cache file for 
DEBUG - 2016-10-02 13:40:46 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-10-02 13:40:46 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-10-02 13:40:46 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-10-02 13:40:46 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-10-02 13:40:46 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-10-02 13:40:46 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-10-02 13:40:46 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:46 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:46 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:46 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:46 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:46 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:46 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:46 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:46 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:46 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:46 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:46 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:46 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:46 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:46 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:46 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:46 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:46 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:46 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:46 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:46 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:46 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:46 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:46 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:46 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:46 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:46 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:46 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:46 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:46 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:46 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:46 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:46 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:46 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:46 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:46 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:46 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:46 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:46 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:46 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:46 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:47 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:47 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:47 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:47 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:47 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:47 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:47 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:47 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:47 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:47 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:47 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:47 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:47 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:47 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:47 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:47 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:47 --> Database Driver Class Initialized
INFO - 2016-10-02 13:40:47 --> Database Driver Class Initialized
DEBUG - 2016-10-02 13:40:47 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-10-02 13:40:47 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-10-02 13:40:47 --> Final output sent to browser
DEBUG - 2016-10-02 13:40:47 --> Total execution time: 0.1922
INFO - 2016-10-02 13:40:47 --> Config Class Initialized
INFO - 2016-10-02 13:40:47 --> Hooks Class Initialized
DEBUG - 2016-10-02 13:40:47 --> UTF-8 Support Enabled
INFO - 2016-10-02 13:40:47 --> Utf8 Class Initialized
INFO - 2016-10-02 13:40:47 --> URI Class Initialized
INFO - 2016-10-02 13:40:47 --> Router Class Initialized
INFO - 2016-10-02 13:40:47 --> Output Class Initialized
INFO - 2016-10-02 13:40:47 --> Security Class Initialized
DEBUG - 2016-10-02 13:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 13:40:47 --> Input Class Initialized
INFO - 2016-10-02 13:40:47 --> Language Class Initialized
ERROR - 2016-10-02 13:40:47 --> 404 Page Not Found: /index
INFO - 2016-10-02 13:40:47 --> Config Class Initialized
INFO - 2016-10-02 13:40:47 --> Hooks Class Initialized
DEBUG - 2016-10-02 13:40:47 --> UTF-8 Support Enabled
INFO - 2016-10-02 13:40:47 --> Utf8 Class Initialized
INFO - 2016-10-02 13:40:47 --> URI Class Initialized
INFO - 2016-10-02 13:40:47 --> Router Class Initialized
INFO - 2016-10-02 13:40:47 --> Output Class Initialized
INFO - 2016-10-02 13:40:47 --> Security Class Initialized
DEBUG - 2016-10-02 13:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 13:40:47 --> Input Class Initialized
INFO - 2016-10-02 13:40:47 --> Language Class Initialized
ERROR - 2016-10-02 13:40:47 --> 404 Page Not Found: /index
INFO - 2016-10-02 13:40:47 --> Config Class Initialized
INFO - 2016-10-02 13:40:47 --> Hooks Class Initialized
DEBUG - 2016-10-02 13:40:47 --> UTF-8 Support Enabled
INFO - 2016-10-02 13:40:47 --> Utf8 Class Initialized
INFO - 2016-10-02 13:40:47 --> URI Class Initialized
INFO - 2016-10-02 13:40:47 --> Router Class Initialized
INFO - 2016-10-02 13:40:47 --> Output Class Initialized
INFO - 2016-10-02 13:40:47 --> Security Class Initialized
DEBUG - 2016-10-02 13:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 13:40:47 --> Input Class Initialized
INFO - 2016-10-02 13:40:47 --> Language Class Initialized
ERROR - 2016-10-02 13:40:47 --> 404 Page Not Found: /index
INFO - 2016-10-02 13:40:47 --> Config Class Initialized
INFO - 2016-10-02 13:40:47 --> Hooks Class Initialized
DEBUG - 2016-10-02 13:40:47 --> UTF-8 Support Enabled
INFO - 2016-10-02 13:40:47 --> Utf8 Class Initialized
INFO - 2016-10-02 13:40:47 --> URI Class Initialized
INFO - 2016-10-02 13:40:47 --> Router Class Initialized
INFO - 2016-10-02 13:40:47 --> Output Class Initialized
INFO - 2016-10-02 13:40:47 --> Security Class Initialized
DEBUG - 2016-10-02 13:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 13:40:47 --> Input Class Initialized
INFO - 2016-10-02 13:40:47 --> Language Class Initialized
ERROR - 2016-10-02 13:40:47 --> 404 Page Not Found: /index
INFO - 2016-10-02 13:40:47 --> Config Class Initialized
INFO - 2016-10-02 13:40:47 --> Hooks Class Initialized
DEBUG - 2016-10-02 13:40:47 --> UTF-8 Support Enabled
INFO - 2016-10-02 13:40:47 --> Utf8 Class Initialized
INFO - 2016-10-02 13:40:47 --> URI Class Initialized
INFO - 2016-10-02 13:40:47 --> Router Class Initialized
INFO - 2016-10-02 13:40:47 --> Output Class Initialized
INFO - 2016-10-02 13:40:47 --> Security Class Initialized
DEBUG - 2016-10-02 13:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 13:40:47 --> Input Class Initialized
INFO - 2016-10-02 13:40:47 --> Language Class Initialized
ERROR - 2016-10-02 13:40:47 --> 404 Page Not Found: /index
INFO - 2016-10-02 13:40:47 --> Config Class Initialized
INFO - 2016-10-02 13:40:47 --> Hooks Class Initialized
DEBUG - 2016-10-02 13:40:47 --> UTF-8 Support Enabled
INFO - 2016-10-02 13:40:47 --> Utf8 Class Initialized
INFO - 2016-10-02 13:40:47 --> URI Class Initialized
INFO - 2016-10-02 13:40:47 --> Router Class Initialized
INFO - 2016-10-02 13:40:47 --> Output Class Initialized
INFO - 2016-10-02 13:40:47 --> Security Class Initialized
DEBUG - 2016-10-02 13:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 13:40:47 --> Input Class Initialized
INFO - 2016-10-02 13:40:47 --> Language Class Initialized
ERROR - 2016-10-02 13:40:47 --> 404 Page Not Found: /index
INFO - 2016-10-02 13:40:47 --> Config Class Initialized
INFO - 2016-10-02 13:40:47 --> Hooks Class Initialized
DEBUG - 2016-10-02 13:40:47 --> UTF-8 Support Enabled
INFO - 2016-10-02 13:40:47 --> Utf8 Class Initialized
INFO - 2016-10-02 13:40:47 --> URI Class Initialized
INFO - 2016-10-02 13:40:47 --> Router Class Initialized
INFO - 2016-10-02 13:40:47 --> Output Class Initialized
INFO - 2016-10-02 13:40:47 --> Security Class Initialized
DEBUG - 2016-10-02 13:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 13:40:47 --> Input Class Initialized
INFO - 2016-10-02 13:40:47 --> Language Class Initialized
ERROR - 2016-10-02 13:40:47 --> 404 Page Not Found: /index
INFO - 2016-10-02 13:40:47 --> Config Class Initialized
INFO - 2016-10-02 13:40:47 --> Hooks Class Initialized
DEBUG - 2016-10-02 13:40:47 --> UTF-8 Support Enabled
INFO - 2016-10-02 13:40:47 --> Utf8 Class Initialized
INFO - 2016-10-02 13:40:47 --> URI Class Initialized
INFO - 2016-10-02 13:40:47 --> Router Class Initialized
INFO - 2016-10-02 13:40:47 --> Output Class Initialized
INFO - 2016-10-02 13:40:47 --> Security Class Initialized
DEBUG - 2016-10-02 13:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 13:40:47 --> Input Class Initialized
INFO - 2016-10-02 13:40:47 --> Language Class Initialized
ERROR - 2016-10-02 13:40:47 --> 404 Page Not Found: /index
INFO - 2016-10-02 13:40:47 --> Config Class Initialized
INFO - 2016-10-02 13:40:47 --> Hooks Class Initialized
DEBUG - 2016-10-02 13:40:47 --> UTF-8 Support Enabled
INFO - 2016-10-02 13:40:47 --> Utf8 Class Initialized
INFO - 2016-10-02 13:40:47 --> URI Class Initialized
INFO - 2016-10-02 13:40:47 --> Router Class Initialized
INFO - 2016-10-02 13:40:47 --> Output Class Initialized
INFO - 2016-10-02 13:40:47 --> Security Class Initialized
DEBUG - 2016-10-02 13:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 13:40:47 --> Input Class Initialized
INFO - 2016-10-02 13:40:47 --> Language Class Initialized
ERROR - 2016-10-02 13:40:47 --> 404 Page Not Found: /index
INFO - 2016-10-02 13:40:47 --> Config Class Initialized
INFO - 2016-10-02 13:40:47 --> Hooks Class Initialized
DEBUG - 2016-10-02 13:40:47 --> UTF-8 Support Enabled
INFO - 2016-10-02 13:40:47 --> Utf8 Class Initialized
INFO - 2016-10-02 13:40:47 --> URI Class Initialized
INFO - 2016-10-02 13:40:47 --> Router Class Initialized
INFO - 2016-10-02 13:40:47 --> Output Class Initialized
INFO - 2016-10-02 13:40:47 --> Security Class Initialized
DEBUG - 2016-10-02 13:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 13:40:47 --> Input Class Initialized
INFO - 2016-10-02 13:40:47 --> Language Class Initialized
ERROR - 2016-10-02 13:40:47 --> 404 Page Not Found: /index
INFO - 2016-10-02 13:40:47 --> Config Class Initialized
INFO - 2016-10-02 13:40:47 --> Hooks Class Initialized
DEBUG - 2016-10-02 13:40:47 --> UTF-8 Support Enabled
INFO - 2016-10-02 13:40:47 --> Utf8 Class Initialized
INFO - 2016-10-02 13:40:47 --> URI Class Initialized
INFO - 2016-10-02 13:40:47 --> Router Class Initialized
INFO - 2016-10-02 13:40:47 --> Output Class Initialized
INFO - 2016-10-02 13:40:47 --> Security Class Initialized
DEBUG - 2016-10-02 13:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 13:40:47 --> Input Class Initialized
INFO - 2016-10-02 13:40:47 --> Language Class Initialized
ERROR - 2016-10-02 13:40:47 --> 404 Page Not Found: /index
INFO - 2016-10-02 13:40:48 --> Config Class Initialized
INFO - 2016-10-02 13:40:48 --> Hooks Class Initialized
DEBUG - 2016-10-02 13:40:48 --> UTF-8 Support Enabled
INFO - 2016-10-02 13:40:48 --> Utf8 Class Initialized
INFO - 2016-10-02 13:40:48 --> URI Class Initialized
INFO - 2016-10-02 13:40:48 --> Router Class Initialized
INFO - 2016-10-02 13:40:48 --> Output Class Initialized
INFO - 2016-10-02 13:40:48 --> Security Class Initialized
DEBUG - 2016-10-02 13:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 13:40:48 --> Input Class Initialized
INFO - 2016-10-02 13:40:48 --> Language Class Initialized
ERROR - 2016-10-02 13:40:48 --> 404 Page Not Found: /index
INFO - 2016-10-02 13:40:48 --> Config Class Initialized
INFO - 2016-10-02 13:40:48 --> Hooks Class Initialized
DEBUG - 2016-10-02 13:40:48 --> UTF-8 Support Enabled
INFO - 2016-10-02 13:40:48 --> Utf8 Class Initialized
INFO - 2016-10-02 13:40:48 --> URI Class Initialized
INFO - 2016-10-02 13:40:48 --> Router Class Initialized
INFO - 2016-10-02 13:40:48 --> Output Class Initialized
INFO - 2016-10-02 13:40:48 --> Security Class Initialized
DEBUG - 2016-10-02 13:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 13:40:48 --> Input Class Initialized
INFO - 2016-10-02 13:40:48 --> Language Class Initialized
ERROR - 2016-10-02 13:40:48 --> 404 Page Not Found: /index
INFO - 2016-10-02 13:40:48 --> Config Class Initialized
INFO - 2016-10-02 13:40:48 --> Hooks Class Initialized
DEBUG - 2016-10-02 13:40:48 --> UTF-8 Support Enabled
INFO - 2016-10-02 13:40:48 --> Utf8 Class Initialized
INFO - 2016-10-02 13:40:48 --> URI Class Initialized
INFO - 2016-10-02 13:40:48 --> Router Class Initialized
INFO - 2016-10-02 13:40:48 --> Output Class Initialized
INFO - 2016-10-02 13:40:48 --> Security Class Initialized
DEBUG - 2016-10-02 13:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 13:40:48 --> Input Class Initialized
INFO - 2016-10-02 13:40:48 --> Language Class Initialized
ERROR - 2016-10-02 13:40:48 --> 404 Page Not Found: /index
INFO - 2016-10-02 14:33:42 --> Config Class Initialized
INFO - 2016-10-02 14:33:42 --> Hooks Class Initialized
DEBUG - 2016-10-02 14:33:42 --> UTF-8 Support Enabled
INFO - 2016-10-02 14:33:42 --> Utf8 Class Initialized
INFO - 2016-10-02 14:33:42 --> URI Class Initialized
DEBUG - 2016-10-02 14:33:42 --> No URI present. Default controller set.
INFO - 2016-10-02 14:33:42 --> Router Class Initialized
INFO - 2016-10-02 14:33:42 --> Output Class Initialized
INFO - 2016-10-02 14:33:42 --> Security Class Initialized
DEBUG - 2016-10-02 14:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 14:33:42 --> Input Class Initialized
INFO - 2016-10-02 14:33:42 --> Language Class Initialized
INFO - 2016-10-02 14:33:42 --> Language Class Initialized
INFO - 2016-10-02 14:33:42 --> Config Class Initialized
INFO - 2016-10-02 14:33:42 --> Loader Class Initialized
INFO - 2016-10-02 14:33:42 --> Helper loaded: url_helper
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-02 14:33:42 --> Controller Class Initialized
DEBUG - 2016-10-02 14:33:42 --> Index MX_Controller Initialized
INFO - 2016-10-02 14:33:42 --> Model Class Initialized
INFO - 2016-10-02 14:33:42 --> Model Class Initialized
ERROR - 2016-10-02 14:33:42 --> Unable to delete cache file for 
DEBUG - 2016-10-02 14:33:42 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-10-02 14:33:42 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-10-02 14:33:42 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-10-02 14:33:42 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-10-02 14:33:42 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-10-02 14:33:42 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:42 --> Database Driver Class Initialized
DEBUG - 2016-10-02 14:33:42 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-10-02 14:33:42 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-10-02 14:33:42 --> Final output sent to browser
DEBUG - 2016-10-02 14:33:42 --> Total execution time: 0.2040
INFO - 2016-10-02 14:33:43 --> Config Class Initialized
INFO - 2016-10-02 14:33:43 --> Hooks Class Initialized
DEBUG - 2016-10-02 14:33:43 --> UTF-8 Support Enabled
INFO - 2016-10-02 14:33:43 --> Utf8 Class Initialized
INFO - 2016-10-02 14:33:43 --> URI Class Initialized
DEBUG - 2016-10-02 14:33:43 --> No URI present. Default controller set.
INFO - 2016-10-02 14:33:43 --> Router Class Initialized
INFO - 2016-10-02 14:33:43 --> Output Class Initialized
INFO - 2016-10-02 14:33:43 --> Security Class Initialized
DEBUG - 2016-10-02 14:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 14:33:43 --> Input Class Initialized
INFO - 2016-10-02 14:33:43 --> Language Class Initialized
INFO - 2016-10-02 14:33:43 --> Language Class Initialized
INFO - 2016-10-02 14:33:43 --> Config Class Initialized
INFO - 2016-10-02 14:33:43 --> Loader Class Initialized
INFO - 2016-10-02 14:33:43 --> Helper loaded: url_helper
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-02 14:33:43 --> Controller Class Initialized
DEBUG - 2016-10-02 14:33:43 --> Index MX_Controller Initialized
INFO - 2016-10-02 14:33:43 --> Model Class Initialized
INFO - 2016-10-02 14:33:43 --> Model Class Initialized
ERROR - 2016-10-02 14:33:43 --> Unable to delete cache file for 
DEBUG - 2016-10-02 14:33:43 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-10-02 14:33:43 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-10-02 14:33:43 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-10-02 14:33:43 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-10-02 14:33:43 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-10-02 14:33:43 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:43 --> Database Driver Class Initialized
DEBUG - 2016-10-02 14:33:43 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-10-02 14:33:43 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-10-02 14:33:43 --> Final output sent to browser
DEBUG - 2016-10-02 14:33:43 --> Total execution time: 0.1420
INFO - 2016-10-02 14:33:44 --> Config Class Initialized
INFO - 2016-10-02 14:33:44 --> Hooks Class Initialized
DEBUG - 2016-10-02 14:33:44 --> UTF-8 Support Enabled
INFO - 2016-10-02 14:33:44 --> Utf8 Class Initialized
INFO - 2016-10-02 14:33:44 --> URI Class Initialized
INFO - 2016-10-02 14:33:44 --> Router Class Initialized
INFO - 2016-10-02 14:33:44 --> Output Class Initialized
INFO - 2016-10-02 14:33:44 --> Security Class Initialized
DEBUG - 2016-10-02 14:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 14:33:44 --> Input Class Initialized
INFO - 2016-10-02 14:33:44 --> Language Class Initialized
INFO - 2016-10-02 14:33:44 --> Language Class Initialized
INFO - 2016-10-02 14:33:44 --> Config Class Initialized
INFO - 2016-10-02 14:33:44 --> Loader Class Initialized
INFO - 2016-10-02 14:33:44 --> Helper loaded: url_helper
INFO - 2016-10-02 14:33:44 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-02 14:33:44 --> Controller Class Initialized
DEBUG - 2016-10-02 14:33:44 --> login MX_Controller Initialized
INFO - 2016-10-02 14:33:44 --> Model Class Initialized
INFO - 2016-10-02 14:33:44 --> Model Class Initialized
DEBUG - 2016-10-02 14:33:44 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-10-02 14:33:44 --> Final output sent to browser
DEBUG - 2016-10-02 14:33:44 --> Total execution time: 0.0338
INFO - 2016-10-02 14:33:46 --> Config Class Initialized
INFO - 2016-10-02 14:33:46 --> Hooks Class Initialized
DEBUG - 2016-10-02 14:33:46 --> UTF-8 Support Enabled
INFO - 2016-10-02 14:33:46 --> Utf8 Class Initialized
INFO - 2016-10-02 14:33:46 --> URI Class Initialized
INFO - 2016-10-02 14:33:46 --> Router Class Initialized
INFO - 2016-10-02 14:33:46 --> Output Class Initialized
INFO - 2016-10-02 14:33:46 --> Security Class Initialized
DEBUG - 2016-10-02 14:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 14:33:46 --> Input Class Initialized
INFO - 2016-10-02 14:33:46 --> Language Class Initialized
INFO - 2016-10-02 14:33:46 --> Language Class Initialized
INFO - 2016-10-02 14:33:46 --> Config Class Initialized
INFO - 2016-10-02 14:33:46 --> Loader Class Initialized
INFO - 2016-10-02 14:33:46 --> Helper loaded: url_helper
INFO - 2016-10-02 14:33:46 --> Database Driver Class Initialized
INFO - 2016-10-02 14:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-02 14:33:46 --> Controller Class Initialized
DEBUG - 2016-10-02 14:33:46 --> login MX_Controller Initialized
INFO - 2016-10-02 14:33:46 --> Model Class Initialized
INFO - 2016-10-02 14:33:46 --> Model Class Initialized
DEBUG - 2016-10-02 14:33:46 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-10-02 14:33:46 --> Final output sent to browser
DEBUG - 2016-10-02 14:33:46 --> Total execution time: 0.0437
INFO - 2016-10-02 17:41:49 --> Config Class Initialized
INFO - 2016-10-02 17:41:49 --> Hooks Class Initialized
DEBUG - 2016-10-02 17:41:49 --> UTF-8 Support Enabled
INFO - 2016-10-02 17:41:49 --> Utf8 Class Initialized
INFO - 2016-10-02 17:41:49 --> URI Class Initialized
INFO - 2016-10-02 17:41:49 --> Router Class Initialized
INFO - 2016-10-02 17:41:49 --> Output Class Initialized
INFO - 2016-10-02 17:41:49 --> Security Class Initialized
DEBUG - 2016-10-02 17:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 17:41:49 --> Input Class Initialized
INFO - 2016-10-02 17:41:49 --> Language Class Initialized
ERROR - 2016-10-02 17:41:49 --> 404 Page Not Found: /index
INFO - 2016-10-02 17:41:54 --> Config Class Initialized
INFO - 2016-10-02 17:41:54 --> Hooks Class Initialized
DEBUG - 2016-10-02 17:41:54 --> UTF-8 Support Enabled
INFO - 2016-10-02 17:41:54 --> Utf8 Class Initialized
INFO - 2016-10-02 17:41:54 --> URI Class Initialized
INFO - 2016-10-02 17:41:54 --> Router Class Initialized
INFO - 2016-10-02 17:41:54 --> Output Class Initialized
INFO - 2016-10-02 17:41:54 --> Security Class Initialized
DEBUG - 2016-10-02 17:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 17:41:54 --> Input Class Initialized
INFO - 2016-10-02 17:41:54 --> Language Class Initialized
ERROR - 2016-10-02 17:41:54 --> 404 Page Not Found: /index
INFO - 2016-10-02 17:48:18 --> Config Class Initialized
INFO - 2016-10-02 17:48:18 --> Hooks Class Initialized
DEBUG - 2016-10-02 17:48:18 --> UTF-8 Support Enabled
INFO - 2016-10-02 17:48:18 --> Utf8 Class Initialized
INFO - 2016-10-02 17:48:18 --> URI Class Initialized
DEBUG - 2016-10-02 17:48:18 --> No URI present. Default controller set.
INFO - 2016-10-02 17:48:18 --> Router Class Initialized
INFO - 2016-10-02 17:48:18 --> Output Class Initialized
INFO - 2016-10-02 17:48:18 --> Security Class Initialized
DEBUG - 2016-10-02 17:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 17:48:18 --> Input Class Initialized
INFO - 2016-10-02 17:48:18 --> Language Class Initialized
INFO - 2016-10-02 17:48:18 --> Language Class Initialized
INFO - 2016-10-02 17:48:18 --> Config Class Initialized
INFO - 2016-10-02 17:48:18 --> Loader Class Initialized
INFO - 2016-10-02 17:48:18 --> Helper loaded: url_helper
INFO - 2016-10-02 17:48:18 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-02 17:48:18 --> Controller Class Initialized
DEBUG - 2016-10-02 17:48:18 --> Index MX_Controller Initialized
INFO - 2016-10-02 17:48:18 --> Model Class Initialized
INFO - 2016-10-02 17:48:18 --> Model Class Initialized
ERROR - 2016-10-02 17:48:18 --> Unable to delete cache file for 
DEBUG - 2016-10-02 17:48:18 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-10-02 17:48:18 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-10-02 17:48:18 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-10-02 17:48:18 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-10-02 17:48:18 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-10-02 17:48:18 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-10-02 17:48:18 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:18 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
INFO - 2016-10-02 17:48:19 --> Database Driver Class Initialized
DEBUG - 2016-10-02 17:48:19 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-10-02 17:48:19 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-10-02 17:48:19 --> Final output sent to browser
DEBUG - 2016-10-02 17:48:19 --> Total execution time: 0.5280
INFO - 2016-10-02 20:24:14 --> Config Class Initialized
INFO - 2016-10-02 20:24:14 --> Hooks Class Initialized
DEBUG - 2016-10-02 20:24:14 --> UTF-8 Support Enabled
INFO - 2016-10-02 20:24:14 --> Utf8 Class Initialized
INFO - 2016-10-02 20:24:14 --> URI Class Initialized
INFO - 2016-10-02 20:24:14 --> Router Class Initialized
INFO - 2016-10-02 20:24:14 --> Output Class Initialized
INFO - 2016-10-02 20:24:14 --> Security Class Initialized
DEBUG - 2016-10-02 20:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 20:24:14 --> Input Class Initialized
INFO - 2016-10-02 20:24:14 --> Language Class Initialized
ERROR - 2016-10-02 20:24:14 --> 404 Page Not Found: /index
INFO - 2016-10-02 20:38:45 --> Config Class Initialized
INFO - 2016-10-02 20:38:45 --> Hooks Class Initialized
DEBUG - 2016-10-02 20:38:45 --> UTF-8 Support Enabled
INFO - 2016-10-02 20:38:45 --> Utf8 Class Initialized
INFO - 2016-10-02 20:38:45 --> URI Class Initialized
DEBUG - 2016-10-02 20:38:45 --> No URI present. Default controller set.
INFO - 2016-10-02 20:38:45 --> Router Class Initialized
INFO - 2016-10-02 20:38:45 --> Output Class Initialized
INFO - 2016-10-02 20:38:45 --> Security Class Initialized
DEBUG - 2016-10-02 20:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 20:38:45 --> Input Class Initialized
INFO - 2016-10-02 20:38:45 --> Language Class Initialized
INFO - 2016-10-02 20:38:45 --> Language Class Initialized
INFO - 2016-10-02 20:38:45 --> Config Class Initialized
INFO - 2016-10-02 20:38:45 --> Loader Class Initialized
INFO - 2016-10-02 20:38:45 --> Helper loaded: url_helper
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-02 20:38:45 --> Controller Class Initialized
DEBUG - 2016-10-02 20:38:45 --> Index MX_Controller Initialized
INFO - 2016-10-02 20:38:45 --> Model Class Initialized
INFO - 2016-10-02 20:38:45 --> Model Class Initialized
ERROR - 2016-10-02 20:38:45 --> Unable to delete cache file for 
DEBUG - 2016-10-02 20:38:45 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-10-02 20:38:45 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-10-02 20:38:45 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-10-02 20:38:45 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-10-02 20:38:45 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-10-02 20:38:45 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:45 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:46 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:46 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:46 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:46 --> Database Driver Class Initialized
INFO - 2016-10-02 20:38:46 --> Database Driver Class Initialized
DEBUG - 2016-10-02 20:38:46 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-10-02 20:38:46 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-10-02 20:38:46 --> Final output sent to browser
DEBUG - 2016-10-02 20:38:46 --> Total execution time: 0.2326
INFO - 2016-10-02 20:38:46 --> Config Class Initialized
INFO - 2016-10-02 20:38:46 --> Hooks Class Initialized
DEBUG - 2016-10-02 20:38:46 --> UTF-8 Support Enabled
INFO - 2016-10-02 20:38:46 --> Utf8 Class Initialized
INFO - 2016-10-02 20:38:46 --> URI Class Initialized
INFO - 2016-10-02 20:38:46 --> Router Class Initialized
INFO - 2016-10-02 20:38:46 --> Output Class Initialized
INFO - 2016-10-02 20:38:46 --> Security Class Initialized
DEBUG - 2016-10-02 20:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 20:38:46 --> Input Class Initialized
INFO - 2016-10-02 20:38:46 --> Language Class Initialized
ERROR - 2016-10-02 20:38:46 --> 404 Page Not Found: /index
INFO - 2016-10-02 20:38:46 --> Config Class Initialized
INFO - 2016-10-02 20:38:46 --> Hooks Class Initialized
DEBUG - 2016-10-02 20:38:46 --> UTF-8 Support Enabled
INFO - 2016-10-02 20:38:46 --> Utf8 Class Initialized
INFO - 2016-10-02 20:38:46 --> URI Class Initialized
INFO - 2016-10-02 20:38:46 --> Router Class Initialized
INFO - 2016-10-02 20:38:46 --> Output Class Initialized
INFO - 2016-10-02 20:38:46 --> Security Class Initialized
DEBUG - 2016-10-02 20:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 20:38:46 --> Input Class Initialized
INFO - 2016-10-02 20:38:46 --> Language Class Initialized
ERROR - 2016-10-02 20:38:46 --> 404 Page Not Found: /index
INFO - 2016-10-02 20:38:46 --> Config Class Initialized
INFO - 2016-10-02 20:38:46 --> Hooks Class Initialized
DEBUG - 2016-10-02 20:38:46 --> UTF-8 Support Enabled
INFO - 2016-10-02 20:38:46 --> Utf8 Class Initialized
INFO - 2016-10-02 20:38:46 --> URI Class Initialized
INFO - 2016-10-02 20:38:46 --> Router Class Initialized
INFO - 2016-10-02 20:38:46 --> Output Class Initialized
INFO - 2016-10-02 20:38:46 --> Security Class Initialized
DEBUG - 2016-10-02 20:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 20:38:46 --> Input Class Initialized
INFO - 2016-10-02 20:38:46 --> Language Class Initialized
ERROR - 2016-10-02 20:38:46 --> 404 Page Not Found: /index
INFO - 2016-10-02 20:38:47 --> Config Class Initialized
INFO - 2016-10-02 20:38:47 --> Hooks Class Initialized
DEBUG - 2016-10-02 20:38:47 --> UTF-8 Support Enabled
INFO - 2016-10-02 20:38:47 --> Utf8 Class Initialized
INFO - 2016-10-02 20:38:47 --> URI Class Initialized
INFO - 2016-10-02 20:38:47 --> Router Class Initialized
INFO - 2016-10-02 20:38:47 --> Output Class Initialized
INFO - 2016-10-02 20:38:47 --> Security Class Initialized
DEBUG - 2016-10-02 20:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 20:38:47 --> Input Class Initialized
INFO - 2016-10-02 20:38:47 --> Language Class Initialized
ERROR - 2016-10-02 20:38:47 --> 404 Page Not Found: /index
INFO - 2016-10-02 20:38:47 --> Config Class Initialized
INFO - 2016-10-02 20:38:47 --> Hooks Class Initialized
DEBUG - 2016-10-02 20:38:47 --> UTF-8 Support Enabled
INFO - 2016-10-02 20:38:47 --> Utf8 Class Initialized
INFO - 2016-10-02 20:38:47 --> URI Class Initialized
INFO - 2016-10-02 20:38:47 --> Router Class Initialized
INFO - 2016-10-02 20:38:47 --> Output Class Initialized
INFO - 2016-10-02 20:38:47 --> Security Class Initialized
DEBUG - 2016-10-02 20:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 20:38:47 --> Input Class Initialized
INFO - 2016-10-02 20:38:47 --> Language Class Initialized
ERROR - 2016-10-02 20:38:47 --> 404 Page Not Found: /index
INFO - 2016-10-02 20:38:47 --> Config Class Initialized
INFO - 2016-10-02 20:38:47 --> Hooks Class Initialized
DEBUG - 2016-10-02 20:38:47 --> UTF-8 Support Enabled
INFO - 2016-10-02 20:38:47 --> Utf8 Class Initialized
INFO - 2016-10-02 20:38:47 --> URI Class Initialized
INFO - 2016-10-02 20:38:47 --> Router Class Initialized
INFO - 2016-10-02 20:38:47 --> Output Class Initialized
INFO - 2016-10-02 20:38:47 --> Security Class Initialized
DEBUG - 2016-10-02 20:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 20:38:47 --> Input Class Initialized
INFO - 2016-10-02 20:38:47 --> Language Class Initialized
ERROR - 2016-10-02 20:38:47 --> 404 Page Not Found: /index
INFO - 2016-10-02 20:38:48 --> Config Class Initialized
INFO - 2016-10-02 20:38:48 --> Hooks Class Initialized
DEBUG - 2016-10-02 20:38:48 --> UTF-8 Support Enabled
INFO - 2016-10-02 20:38:48 --> Utf8 Class Initialized
INFO - 2016-10-02 20:38:48 --> URI Class Initialized
INFO - 2016-10-02 20:38:48 --> Router Class Initialized
INFO - 2016-10-02 20:38:48 --> Output Class Initialized
INFO - 2016-10-02 20:38:48 --> Security Class Initialized
DEBUG - 2016-10-02 20:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 20:38:48 --> Input Class Initialized
INFO - 2016-10-02 20:38:48 --> Language Class Initialized
ERROR - 2016-10-02 20:38:48 --> 404 Page Not Found: /index
INFO - 2016-10-02 20:38:48 --> Config Class Initialized
INFO - 2016-10-02 20:38:48 --> Hooks Class Initialized
DEBUG - 2016-10-02 20:38:48 --> UTF-8 Support Enabled
INFO - 2016-10-02 20:38:48 --> Utf8 Class Initialized
INFO - 2016-10-02 20:38:48 --> URI Class Initialized
INFO - 2016-10-02 20:38:48 --> Router Class Initialized
INFO - 2016-10-02 20:38:48 --> Output Class Initialized
INFO - 2016-10-02 20:38:48 --> Security Class Initialized
DEBUG - 2016-10-02 20:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 20:38:48 --> Input Class Initialized
INFO - 2016-10-02 20:38:48 --> Language Class Initialized
ERROR - 2016-10-02 20:38:48 --> 404 Page Not Found: /index
INFO - 2016-10-02 20:38:48 --> Config Class Initialized
INFO - 2016-10-02 20:38:48 --> Hooks Class Initialized
DEBUG - 2016-10-02 20:38:48 --> UTF-8 Support Enabled
INFO - 2016-10-02 20:38:48 --> Utf8 Class Initialized
INFO - 2016-10-02 20:38:48 --> URI Class Initialized
INFO - 2016-10-02 20:38:48 --> Router Class Initialized
INFO - 2016-10-02 20:38:48 --> Output Class Initialized
INFO - 2016-10-02 20:38:48 --> Security Class Initialized
DEBUG - 2016-10-02 20:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 20:38:48 --> Input Class Initialized
INFO - 2016-10-02 20:38:48 --> Language Class Initialized
ERROR - 2016-10-02 20:38:48 --> 404 Page Not Found: /index
INFO - 2016-10-02 20:38:48 --> Config Class Initialized
INFO - 2016-10-02 20:38:48 --> Hooks Class Initialized
DEBUG - 2016-10-02 20:38:48 --> UTF-8 Support Enabled
INFO - 2016-10-02 20:38:48 --> Utf8 Class Initialized
INFO - 2016-10-02 20:38:48 --> URI Class Initialized
INFO - 2016-10-02 20:38:48 --> Router Class Initialized
INFO - 2016-10-02 20:38:48 --> Output Class Initialized
INFO - 2016-10-02 20:38:48 --> Security Class Initialized
DEBUG - 2016-10-02 20:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 20:38:48 --> Input Class Initialized
INFO - 2016-10-02 20:38:48 --> Language Class Initialized
ERROR - 2016-10-02 20:38:48 --> 404 Page Not Found: /index
INFO - 2016-10-02 20:38:49 --> Config Class Initialized
INFO - 2016-10-02 20:38:49 --> Hooks Class Initialized
DEBUG - 2016-10-02 20:38:49 --> UTF-8 Support Enabled
INFO - 2016-10-02 20:38:49 --> Utf8 Class Initialized
INFO - 2016-10-02 20:38:49 --> URI Class Initialized
INFO - 2016-10-02 20:38:49 --> Router Class Initialized
INFO - 2016-10-02 20:38:49 --> Output Class Initialized
INFO - 2016-10-02 20:38:49 --> Security Class Initialized
DEBUG - 2016-10-02 20:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 20:38:49 --> Input Class Initialized
INFO - 2016-10-02 20:38:49 --> Language Class Initialized
ERROR - 2016-10-02 20:38:49 --> 404 Page Not Found: /index
INFO - 2016-10-02 20:38:49 --> Config Class Initialized
INFO - 2016-10-02 20:38:49 --> Hooks Class Initialized
DEBUG - 2016-10-02 20:38:49 --> UTF-8 Support Enabled
INFO - 2016-10-02 20:38:49 --> Utf8 Class Initialized
INFO - 2016-10-02 20:38:49 --> URI Class Initialized
INFO - 2016-10-02 20:38:49 --> Router Class Initialized
INFO - 2016-10-02 20:38:49 --> Output Class Initialized
INFO - 2016-10-02 20:38:49 --> Security Class Initialized
DEBUG - 2016-10-02 20:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 20:38:49 --> Input Class Initialized
INFO - 2016-10-02 20:38:49 --> Language Class Initialized
ERROR - 2016-10-02 20:38:49 --> 404 Page Not Found: /index
INFO - 2016-10-02 20:38:49 --> Config Class Initialized
INFO - 2016-10-02 20:38:49 --> Hooks Class Initialized
DEBUG - 2016-10-02 20:38:49 --> UTF-8 Support Enabled
INFO - 2016-10-02 20:38:49 --> Utf8 Class Initialized
INFO - 2016-10-02 20:38:49 --> URI Class Initialized
INFO - 2016-10-02 20:38:49 --> Router Class Initialized
INFO - 2016-10-02 20:38:49 --> Output Class Initialized
INFO - 2016-10-02 20:38:49 --> Security Class Initialized
DEBUG - 2016-10-02 20:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 20:38:49 --> Input Class Initialized
INFO - 2016-10-02 20:38:49 --> Language Class Initialized
ERROR - 2016-10-02 20:38:49 --> 404 Page Not Found: /index
INFO - 2016-10-02 20:38:50 --> Config Class Initialized
INFO - 2016-10-02 20:38:50 --> Hooks Class Initialized
DEBUG - 2016-10-02 20:38:50 --> UTF-8 Support Enabled
INFO - 2016-10-02 20:38:50 --> Utf8 Class Initialized
INFO - 2016-10-02 20:38:50 --> URI Class Initialized
INFO - 2016-10-02 20:38:50 --> Router Class Initialized
INFO - 2016-10-02 20:38:50 --> Output Class Initialized
INFO - 2016-10-02 20:38:50 --> Security Class Initialized
DEBUG - 2016-10-02 20:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-02 20:38:50 --> Input Class Initialized
INFO - 2016-10-02 20:38:50 --> Language Class Initialized
ERROR - 2016-10-02 20:38:50 --> 404 Page Not Found: /index
