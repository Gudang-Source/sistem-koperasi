<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-10-08 04:46:35 --> Config Class Initialized
INFO - 2016-10-08 04:46:35 --> Hooks Class Initialized
DEBUG - 2016-10-08 04:46:36 --> UTF-8 Support Enabled
INFO - 2016-10-08 04:46:36 --> Utf8 Class Initialized
INFO - 2016-10-08 04:46:36 --> URI Class Initialized
DEBUG - 2016-10-08 04:46:36 --> No URI present. Default controller set.
INFO - 2016-10-08 04:46:36 --> Router Class Initialized
INFO - 2016-10-08 04:46:37 --> Output Class Initialized
INFO - 2016-10-08 04:46:37 --> Security Class Initialized
DEBUG - 2016-10-08 04:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 04:46:37 --> Input Class Initialized
INFO - 2016-10-08 04:46:37 --> Language Class Initialized
INFO - 2016-10-08 04:46:38 --> Language Class Initialized
INFO - 2016-10-08 04:46:38 --> Config Class Initialized
INFO - 2016-10-08 04:46:38 --> Loader Class Initialized
INFO - 2016-10-08 04:46:38 --> Helper loaded: url_helper
INFO - 2016-10-08 04:46:39 --> Database Driver Class Initialized
ERROR - 2016-10-08 04:46:40 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'koperasi' E:\SERVER\htdocs\kops\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-08 04:46:40 --> Unable to connect to the database
INFO - 2016-10-08 04:46:40 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-08 04:48:08 --> Config Class Initialized
INFO - 2016-10-08 04:48:08 --> Hooks Class Initialized
DEBUG - 2016-10-08 04:48:08 --> UTF-8 Support Enabled
INFO - 2016-10-08 04:48:08 --> Utf8 Class Initialized
INFO - 2016-10-08 04:48:08 --> URI Class Initialized
DEBUG - 2016-10-08 04:48:08 --> No URI present. Default controller set.
INFO - 2016-10-08 04:48:08 --> Router Class Initialized
INFO - 2016-10-08 04:48:08 --> Output Class Initialized
INFO - 2016-10-08 04:48:08 --> Security Class Initialized
DEBUG - 2016-10-08 04:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 04:48:09 --> Input Class Initialized
INFO - 2016-10-08 04:48:09 --> Language Class Initialized
INFO - 2016-10-08 04:48:09 --> Language Class Initialized
INFO - 2016-10-08 04:48:09 --> Config Class Initialized
INFO - 2016-10-08 04:48:09 --> Loader Class Initialized
INFO - 2016-10-08 04:48:09 --> Helper loaded: url_helper
INFO - 2016-10-08 04:48:09 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 04:48:09 --> Controller Class Initialized
DEBUG - 2016-10-08 04:48:09 --> Index MX_Controller Initialized
INFO - 2016-10-08 04:48:09 --> Model Class Initialized
INFO - 2016-10-08 04:48:09 --> Model Class Initialized
ERROR - 2016-10-08 04:48:09 --> Unable to delete cache file for 
DEBUG - 2016-10-08 04:48:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 04:48:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 04:48:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 04:48:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/dashboard.php
DEBUG - 2016-10-08 04:48:10 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 04:48:10 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 04:48:10 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:10 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:10 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:10 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:10 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:10 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:10 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:10 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:10 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:10 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:10 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:10 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:10 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:10 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:10 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:10 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:10 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:10 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:10 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:10 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:10 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:10 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:10 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:10 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:10 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:10 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:10 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:10 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:11 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:11 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:11 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:11 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:11 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:11 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:11 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:11 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:11 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:11 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:11 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:11 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:11 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:11 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:11 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:11 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:11 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:11 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:11 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:11 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:11 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:11 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:11 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:11 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:11 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:11 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:11 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:11 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:11 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:11 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:11 --> Database Driver Class Initialized
DEBUG - 2016-10-08 04:48:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 04:48:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 04:48:11 --> Config Class Initialized
INFO - 2016-10-08 04:48:11 --> Final output sent to browser
INFO - 2016-10-08 04:48:11 --> Hooks Class Initialized
DEBUG - 2016-10-08 04:48:11 --> Total execution time: 3.0678
DEBUG - 2016-10-08 04:48:11 --> UTF-8 Support Enabled
INFO - 2016-10-08 04:48:11 --> Utf8 Class Initialized
INFO - 2016-10-08 04:48:12 --> URI Class Initialized
INFO - 2016-10-08 04:48:12 --> Router Class Initialized
INFO - 2016-10-08 04:48:12 --> Output Class Initialized
INFO - 2016-10-08 04:48:12 --> Security Class Initialized
DEBUG - 2016-10-08 04:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 04:48:12 --> Input Class Initialized
INFO - 2016-10-08 04:48:12 --> Language Class Initialized
INFO - 2016-10-08 04:48:12 --> Language Class Initialized
INFO - 2016-10-08 04:48:12 --> Config Class Initialized
INFO - 2016-10-08 04:48:12 --> Loader Class Initialized
INFO - 2016-10-08 04:48:12 --> Helper loaded: url_helper
INFO - 2016-10-08 04:48:12 --> Database Driver Class Initialized
INFO - 2016-10-08 04:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 04:48:12 --> Controller Class Initialized
DEBUG - 2016-10-08 04:48:12 --> login MX_Controller Initialized
INFO - 2016-10-08 04:48:12 --> Model Class Initialized
INFO - 2016-10-08 04:48:12 --> Model Class Initialized
DEBUG - 2016-10-08 04:48:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/login.php
INFO - 2016-10-08 04:48:12 --> Final output sent to browser
DEBUG - 2016-10-08 04:48:12 --> Total execution time: 0.5898
INFO - 2016-10-08 04:49:33 --> Config Class Initialized
INFO - 2016-10-08 04:49:33 --> Hooks Class Initialized
DEBUG - 2016-10-08 04:49:33 --> UTF-8 Support Enabled
INFO - 2016-10-08 04:49:33 --> Utf8 Class Initialized
INFO - 2016-10-08 04:49:33 --> URI Class Initialized
INFO - 2016-10-08 04:49:33 --> Router Class Initialized
INFO - 2016-10-08 04:49:33 --> Output Class Initialized
INFO - 2016-10-08 04:49:33 --> Security Class Initialized
DEBUG - 2016-10-08 04:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 04:49:33 --> Input Class Initialized
INFO - 2016-10-08 04:49:33 --> Language Class Initialized
INFO - 2016-10-08 04:49:33 --> Language Class Initialized
INFO - 2016-10-08 04:49:33 --> Config Class Initialized
INFO - 2016-10-08 04:49:33 --> Loader Class Initialized
INFO - 2016-10-08 04:49:33 --> Helper loaded: url_helper
INFO - 2016-10-08 04:49:34 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 04:49:34 --> Controller Class Initialized
DEBUG - 2016-10-08 04:49:34 --> login MX_Controller Initialized
INFO - 2016-10-08 04:49:34 --> Model Class Initialized
INFO - 2016-10-08 04:49:34 --> Model Class Initialized
INFO - 2016-10-08 04:49:34 --> Final output sent to browser
DEBUG - 2016-10-08 04:49:34 --> Total execution time: 0.5715
INFO - 2016-10-08 04:49:34 --> Config Class Initialized
INFO - 2016-10-08 04:49:34 --> Hooks Class Initialized
DEBUG - 2016-10-08 04:49:34 --> UTF-8 Support Enabled
INFO - 2016-10-08 04:49:34 --> Utf8 Class Initialized
INFO - 2016-10-08 04:49:34 --> URI Class Initialized
INFO - 2016-10-08 04:49:34 --> Router Class Initialized
INFO - 2016-10-08 04:49:34 --> Output Class Initialized
INFO - 2016-10-08 04:49:34 --> Security Class Initialized
DEBUG - 2016-10-08 04:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 04:49:34 --> Input Class Initialized
INFO - 2016-10-08 04:49:34 --> Language Class Initialized
INFO - 2016-10-08 04:49:34 --> Language Class Initialized
INFO - 2016-10-08 04:49:34 --> Config Class Initialized
INFO - 2016-10-08 04:49:34 --> Loader Class Initialized
INFO - 2016-10-08 04:49:34 --> Helper loaded: url_helper
INFO - 2016-10-08 04:49:34 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 04:49:35 --> Controller Class Initialized
DEBUG - 2016-10-08 04:49:35 --> Index MX_Controller Initialized
INFO - 2016-10-08 04:49:35 --> Model Class Initialized
INFO - 2016-10-08 04:49:35 --> Model Class Initialized
ERROR - 2016-10-08 04:49:35 --> Unable to delete cache file for admin/index
DEBUG - 2016-10-08 04:49:35 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 04:49:35 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 04:49:35 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 04:49:35 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/dashboard.php
DEBUG - 2016-10-08 04:49:35 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 04:49:35 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 04:49:35 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:35 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:35 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:35 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:35 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:35 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:35 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:35 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:35 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:35 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:35 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:35 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:35 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:35 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:35 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:35 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:35 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:35 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:35 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:35 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:35 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:35 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:35 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:35 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:35 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:35 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:36 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:36 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:36 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:36 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:36 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:36 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:36 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:36 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:36 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:36 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:36 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:36 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:36 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:36 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:36 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:36 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:36 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:36 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:36 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:36 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:36 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:36 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:36 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:36 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:36 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:36 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:36 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:36 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:36 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:36 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:36 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:36 --> Database Driver Class Initialized
INFO - 2016-10-08 04:49:36 --> Database Driver Class Initialized
DEBUG - 2016-10-08 04:49:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 04:49:37 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 04:49:37 --> Final output sent to browser
DEBUG - 2016-10-08 04:49:37 --> Total execution time: 2.5744
INFO - 2016-10-08 04:50:16 --> Config Class Initialized
INFO - 2016-10-08 04:50:16 --> Hooks Class Initialized
DEBUG - 2016-10-08 04:50:16 --> UTF-8 Support Enabled
INFO - 2016-10-08 04:50:16 --> Utf8 Class Initialized
INFO - 2016-10-08 04:50:16 --> URI Class Initialized
INFO - 2016-10-08 04:50:16 --> Router Class Initialized
INFO - 2016-10-08 04:50:16 --> Output Class Initialized
INFO - 2016-10-08 04:50:16 --> Security Class Initialized
DEBUG - 2016-10-08 04:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 04:50:16 --> Input Class Initialized
INFO - 2016-10-08 04:50:16 --> Language Class Initialized
INFO - 2016-10-08 04:50:16 --> Language Class Initialized
INFO - 2016-10-08 04:50:16 --> Config Class Initialized
INFO - 2016-10-08 04:50:16 --> Loader Class Initialized
INFO - 2016-10-08 04:50:16 --> Helper loaded: url_helper
INFO - 2016-10-08 04:50:16 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 04:50:16 --> Controller Class Initialized
DEBUG - 2016-10-08 04:50:16 --> Index MX_Controller Initialized
INFO - 2016-10-08 04:50:16 --> Model Class Initialized
INFO - 2016-10-08 04:50:16 --> Model Class Initialized
ERROR - 2016-10-08 04:50:16 --> Unable to delete cache file for admin/index/data/anggota
DEBUG - 2016-10-08 04:50:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 04:50:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 04:50:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 04:50:16 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-08 04:50:16 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-08 04:50:17 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-08 04:50:17 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 04:50:17 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 04:50:17 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:17 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:17 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:17 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:17 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:17 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:17 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:17 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:17 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:17 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:17 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:17 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:17 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:17 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:17 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:17 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:17 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:17 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:17 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:17 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:17 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:17 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:17 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:17 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:17 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:17 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:17 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:17 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:18 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:18 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:18 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:18 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:18 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:18 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:18 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:18 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:18 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:18 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:18 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:18 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:18 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:18 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:18 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:18 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:18 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:18 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:18 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:18 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:18 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:18 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:18 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:18 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:18 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:18 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:18 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:19 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:19 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:19 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:19 --> Database Driver Class Initialized
INFO - 2016-10-08 04:50:19 --> Database Driver Class Initialized
DEBUG - 2016-10-08 04:50:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 04:50:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 04:50:19 --> Final output sent to browser
DEBUG - 2016-10-08 04:50:19 --> Total execution time: 3.1420
INFO - 2016-10-08 04:58:37 --> Config Class Initialized
INFO - 2016-10-08 04:58:38 --> Hooks Class Initialized
DEBUG - 2016-10-08 04:58:38 --> UTF-8 Support Enabled
INFO - 2016-10-08 04:58:38 --> Utf8 Class Initialized
INFO - 2016-10-08 04:58:38 --> URI Class Initialized
INFO - 2016-10-08 04:58:38 --> Router Class Initialized
INFO - 2016-10-08 04:58:38 --> Output Class Initialized
INFO - 2016-10-08 04:58:38 --> Security Class Initialized
DEBUG - 2016-10-08 04:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 04:58:38 --> Input Class Initialized
INFO - 2016-10-08 04:58:38 --> Language Class Initialized
INFO - 2016-10-08 04:58:38 --> Language Class Initialized
INFO - 2016-10-08 04:58:38 --> Config Class Initialized
INFO - 2016-10-08 04:58:38 --> Loader Class Initialized
INFO - 2016-10-08 04:58:38 --> Helper loaded: url_helper
INFO - 2016-10-08 04:58:38 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 04:58:38 --> Controller Class Initialized
DEBUG - 2016-10-08 04:58:38 --> Index MX_Controller Initialized
INFO - 2016-10-08 04:58:38 --> Model Class Initialized
INFO - 2016-10-08 04:58:38 --> Model Class Initialized
ERROR - 2016-10-08 04:58:38 --> Unable to delete cache file for admin/index/data/anggota
DEBUG - 2016-10-08 04:58:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 04:58:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 04:58:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 04:58:38 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-08 04:58:38 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-08 04:58:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-08 04:58:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 04:58:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 04:58:38 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:38 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:38 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:39 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:39 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:39 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:39 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:39 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:39 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:39 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:39 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:39 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:39 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:39 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:39 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:39 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:39 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:39 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:39 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:39 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:39 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:39 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:39 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:39 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:39 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:39 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:39 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:39 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:39 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:39 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:39 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:39 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:39 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:39 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:39 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:39 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:39 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:39 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:40 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:40 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:40 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:40 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:40 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:40 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:40 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:40 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:40 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:40 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:40 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:40 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:40 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:40 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:40 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:40 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:40 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:40 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:40 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:40 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:40 --> Database Driver Class Initialized
INFO - 2016-10-08 04:58:40 --> Database Driver Class Initialized
DEBUG - 2016-10-08 04:58:40 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 04:58:40 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 04:58:40 --> Final output sent to browser
DEBUG - 2016-10-08 04:58:40 --> Total execution time: 2.7555
INFO - 2016-10-08 04:59:28 --> Config Class Initialized
INFO - 2016-10-08 04:59:28 --> Hooks Class Initialized
DEBUG - 2016-10-08 04:59:28 --> UTF-8 Support Enabled
INFO - 2016-10-08 04:59:28 --> Utf8 Class Initialized
INFO - 2016-10-08 04:59:28 --> URI Class Initialized
INFO - 2016-10-08 04:59:28 --> Router Class Initialized
INFO - 2016-10-08 04:59:28 --> Output Class Initialized
INFO - 2016-10-08 04:59:28 --> Security Class Initialized
DEBUG - 2016-10-08 04:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 04:59:28 --> Input Class Initialized
INFO - 2016-10-08 04:59:28 --> Language Class Initialized
INFO - 2016-10-08 04:59:28 --> Language Class Initialized
INFO - 2016-10-08 04:59:28 --> Config Class Initialized
INFO - 2016-10-08 04:59:28 --> Loader Class Initialized
INFO - 2016-10-08 04:59:28 --> Helper loaded: url_helper
INFO - 2016-10-08 04:59:28 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 04:59:28 --> Controller Class Initialized
DEBUG - 2016-10-08 04:59:28 --> Index MX_Controller Initialized
INFO - 2016-10-08 04:59:28 --> Model Class Initialized
INFO - 2016-10-08 04:59:28 --> Model Class Initialized
ERROR - 2016-10-08 04:59:28 --> Unable to delete cache file for admin/index/data/anggota
DEBUG - 2016-10-08 04:59:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 04:59:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 04:59:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 04:59:29 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-08 04:59:29 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-08 04:59:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-08 04:59:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 04:59:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 04:59:29 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:29 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:29 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:29 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:29 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:29 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:29 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:29 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:29 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:29 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:29 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:29 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:29 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:29 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:29 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:29 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:29 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:29 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:29 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:29 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:29 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:29 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:29 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:29 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:30 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:30 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:30 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:30 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:30 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:30 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:30 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:30 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:30 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:30 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:30 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:30 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:30 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:30 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:30 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:30 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:30 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:30 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:30 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:30 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:30 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:30 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:30 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:30 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:30 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:30 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:30 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:30 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:30 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:30 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:30 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:30 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:30 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:31 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:31 --> Database Driver Class Initialized
INFO - 2016-10-08 04:59:31 --> Database Driver Class Initialized
DEBUG - 2016-10-08 04:59:31 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 04:59:31 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 04:59:31 --> Final output sent to browser
DEBUG - 2016-10-08 04:59:31 --> Total execution time: 2.9174
INFO - 2016-10-08 05:00:30 --> Config Class Initialized
INFO - 2016-10-08 05:00:30 --> Hooks Class Initialized
DEBUG - 2016-10-08 05:00:30 --> UTF-8 Support Enabled
INFO - 2016-10-08 05:00:30 --> Utf8 Class Initialized
INFO - 2016-10-08 05:00:30 --> URI Class Initialized
INFO - 2016-10-08 05:00:30 --> Router Class Initialized
INFO - 2016-10-08 05:00:30 --> Output Class Initialized
INFO - 2016-10-08 05:00:30 --> Security Class Initialized
DEBUG - 2016-10-08 05:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 05:00:30 --> Input Class Initialized
INFO - 2016-10-08 05:00:30 --> Language Class Initialized
INFO - 2016-10-08 05:00:30 --> Language Class Initialized
INFO - 2016-10-08 05:00:30 --> Config Class Initialized
INFO - 2016-10-08 05:00:30 --> Loader Class Initialized
INFO - 2016-10-08 05:00:30 --> Helper loaded: url_helper
INFO - 2016-10-08 05:00:30 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 05:00:30 --> Controller Class Initialized
DEBUG - 2016-10-08 05:00:30 --> Index MX_Controller Initialized
INFO - 2016-10-08 05:00:30 --> Model Class Initialized
INFO - 2016-10-08 05:00:30 --> Model Class Initialized
ERROR - 2016-10-08 05:00:30 --> Unable to delete cache file for admin/index/data/anggota
DEBUG - 2016-10-08 05:00:30 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 05:00:30 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 05:00:30 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 05:00:30 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-08 05:00:30 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-08 05:00:30 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-08 05:00:30 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 05:00:30 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 05:00:30 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:30 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:30 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:30 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:30 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:31 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:31 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:31 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:31 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:31 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:31 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:31 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:31 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:31 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:31 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:31 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:31 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:31 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:31 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:31 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:31 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:31 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:31 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:31 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:31 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:31 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:31 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:31 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:31 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:31 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:31 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:31 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:31 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:31 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:31 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:31 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:31 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:31 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:32 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:32 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:32 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:32 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:32 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:32 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:32 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:32 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:32 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:32 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:32 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:32 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:32 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:32 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:32 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:32 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:32 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:32 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:32 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:32 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:32 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:32 --> Database Driver Class Initialized
DEBUG - 2016-10-08 05:00:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 05:00:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 05:00:32 --> Final output sent to browser
DEBUG - 2016-10-08 05:00:32 --> Total execution time: 2.6286
INFO - 2016-10-08 05:00:47 --> Config Class Initialized
INFO - 2016-10-08 05:00:47 --> Hooks Class Initialized
DEBUG - 2016-10-08 05:00:47 --> UTF-8 Support Enabled
INFO - 2016-10-08 05:00:47 --> Utf8 Class Initialized
INFO - 2016-10-08 05:00:47 --> URI Class Initialized
INFO - 2016-10-08 05:00:47 --> Router Class Initialized
INFO - 2016-10-08 05:00:47 --> Output Class Initialized
INFO - 2016-10-08 05:00:47 --> Security Class Initialized
DEBUG - 2016-10-08 05:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 05:00:47 --> Input Class Initialized
INFO - 2016-10-08 05:00:47 --> Language Class Initialized
INFO - 2016-10-08 05:00:47 --> Language Class Initialized
INFO - 2016-10-08 05:00:47 --> Config Class Initialized
INFO - 2016-10-08 05:00:47 --> Loader Class Initialized
INFO - 2016-10-08 05:00:47 --> Helper loaded: url_helper
INFO - 2016-10-08 05:00:47 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 05:00:47 --> Controller Class Initialized
DEBUG - 2016-10-08 05:00:47 --> Index MX_Controller Initialized
INFO - 2016-10-08 05:00:47 --> Model Class Initialized
INFO - 2016-10-08 05:00:47 --> Model Class Initialized
ERROR - 2016-10-08 05:00:47 --> Unable to delete cache file for admin/index/data/anggota/umum
DEBUG - 2016-10-08 05:00:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 05:00:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 05:00:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 05:00:47 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-08 05:00:47 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-08 05:00:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-08 05:00:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 05:00:48 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 05:00:48 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:48 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:48 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:48 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:48 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:48 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:48 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:48 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:48 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:48 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:48 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:48 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:48 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:48 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:48 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:48 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:48 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:48 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:48 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:48 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:48 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:48 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:48 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:48 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:48 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:48 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:49 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:49 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:49 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:49 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:49 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:49 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:49 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:49 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:49 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:49 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:49 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:49 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:49 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:49 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:49 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:49 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:49 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:49 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:49 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:49 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:49 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:49 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:49 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:49 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:49 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:49 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:49 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:49 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:49 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:49 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:50 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:50 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:50 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:50 --> Database Driver Class Initialized
DEBUG - 2016-10-08 05:00:50 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 05:00:50 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 05:00:50 --> Final output sent to browser
DEBUG - 2016-10-08 05:00:50 --> Total execution time: 2.9847
INFO - 2016-10-08 05:00:54 --> Config Class Initialized
INFO - 2016-10-08 05:00:54 --> Hooks Class Initialized
DEBUG - 2016-10-08 05:00:54 --> UTF-8 Support Enabled
INFO - 2016-10-08 05:00:54 --> Utf8 Class Initialized
INFO - 2016-10-08 05:00:54 --> URI Class Initialized
INFO - 2016-10-08 05:00:55 --> Router Class Initialized
INFO - 2016-10-08 05:00:55 --> Output Class Initialized
INFO - 2016-10-08 05:00:55 --> Security Class Initialized
DEBUG - 2016-10-08 05:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 05:00:55 --> Input Class Initialized
INFO - 2016-10-08 05:00:55 --> Language Class Initialized
INFO - 2016-10-08 05:00:55 --> Language Class Initialized
INFO - 2016-10-08 05:00:55 --> Config Class Initialized
INFO - 2016-10-08 05:00:55 --> Loader Class Initialized
INFO - 2016-10-08 05:00:55 --> Helper loaded: url_helper
INFO - 2016-10-08 05:00:55 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 05:00:55 --> Controller Class Initialized
DEBUG - 2016-10-08 05:00:55 --> Index MX_Controller Initialized
INFO - 2016-10-08 05:00:55 --> Model Class Initialized
INFO - 2016-10-08 05:00:55 --> Model Class Initialized
ERROR - 2016-10-08 05:00:55 --> Unable to delete cache file for admin/index/data/anggota/karyawan
DEBUG - 2016-10-08 05:00:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 05:00:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 05:00:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 05:00:55 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-08 05:00:55 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-08 05:00:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-08 05:00:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 05:00:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 05:00:56 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:56 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:56 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:56 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:56 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:56 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:56 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:56 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:56 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:56 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:56 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:56 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:56 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:56 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:56 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:56 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:56 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:57 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:57 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:57 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:57 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:57 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:57 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:57 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:57 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:57 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:57 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:57 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:57 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:57 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:58 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:58 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:58 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:58 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:58 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:58 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:58 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:58 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:58 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:58 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:58 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:58 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:58 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:58 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:58 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:58 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:58 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:58 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:58 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:58 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:58 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:58 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:58 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:58 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:58 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:58 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:58 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:58 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:58 --> Database Driver Class Initialized
INFO - 2016-10-08 05:00:58 --> Database Driver Class Initialized
DEBUG - 2016-10-08 05:00:59 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 05:00:59 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 05:00:59 --> Final output sent to browser
DEBUG - 2016-10-08 05:00:59 --> Total execution time: 4.2988
INFO - 2016-10-08 05:01:30 --> Config Class Initialized
INFO - 2016-10-08 05:01:30 --> Hooks Class Initialized
DEBUG - 2016-10-08 05:01:30 --> UTF-8 Support Enabled
INFO - 2016-10-08 05:01:30 --> Utf8 Class Initialized
INFO - 2016-10-08 05:01:30 --> URI Class Initialized
INFO - 2016-10-08 05:01:30 --> Router Class Initialized
INFO - 2016-10-08 05:01:30 --> Output Class Initialized
INFO - 2016-10-08 05:01:30 --> Security Class Initialized
DEBUG - 2016-10-08 05:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 05:01:31 --> Input Class Initialized
INFO - 2016-10-08 05:01:31 --> Language Class Initialized
INFO - 2016-10-08 05:01:31 --> Language Class Initialized
INFO - 2016-10-08 05:01:31 --> Config Class Initialized
INFO - 2016-10-08 05:01:31 --> Loader Class Initialized
INFO - 2016-10-08 05:01:31 --> Helper loaded: url_helper
INFO - 2016-10-08 05:01:31 --> Database Driver Class Initialized
INFO - 2016-10-08 05:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 05:01:31 --> Controller Class Initialized
DEBUG - 2016-10-08 05:01:31 --> Index MX_Controller Initialized
INFO - 2016-10-08 05:01:31 --> Model Class Initialized
INFO - 2016-10-08 05:01:31 --> Model Class Initialized
ERROR - 2016-10-08 05:01:31 --> Unable to delete cache file for admin/index/data/anggota
DEBUG - 2016-10-08 05:01:31 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 05:01:31 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 05:01:31 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 05:01:31 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-08 05:01:31 --> Anggota MX_Controller Initialized
ERROR - 2016-10-08 05:01:31 --> Module controller failed to run: anggota/Anggota/data/All
ERROR - 2016-10-08 05:01:31 --> Severity: Error --> Call to a member function num_rows() on null E:\SERVER\htdocs\kops\application\views\main_html\content\list_anggota.php 36
INFO - 2016-10-08 05:01:37 --> Config Class Initialized
INFO - 2016-10-08 05:01:37 --> Hooks Class Initialized
DEBUG - 2016-10-08 05:01:37 --> UTF-8 Support Enabled
INFO - 2016-10-08 05:01:37 --> Utf8 Class Initialized
INFO - 2016-10-08 05:01:37 --> URI Class Initialized
INFO - 2016-10-08 05:01:37 --> Router Class Initialized
INFO - 2016-10-08 05:01:37 --> Output Class Initialized
INFO - 2016-10-08 05:01:37 --> Security Class Initialized
DEBUG - 2016-10-08 05:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 05:01:38 --> Input Class Initialized
INFO - 2016-10-08 05:01:38 --> Language Class Initialized
INFO - 2016-10-08 05:01:38 --> Language Class Initialized
INFO - 2016-10-08 05:01:38 --> Config Class Initialized
INFO - 2016-10-08 05:01:38 --> Loader Class Initialized
INFO - 2016-10-08 05:01:38 --> Helper loaded: url_helper
INFO - 2016-10-08 05:01:38 --> Database Driver Class Initialized
INFO - 2016-10-08 05:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 05:01:38 --> Controller Class Initialized
DEBUG - 2016-10-08 05:01:38 --> Index MX_Controller Initialized
INFO - 2016-10-08 05:01:38 --> Model Class Initialized
INFO - 2016-10-08 05:01:38 --> Model Class Initialized
ERROR - 2016-10-08 05:01:38 --> Unable to delete cache file for admin/index/data/anggota/umum
DEBUG - 2016-10-08 05:01:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 05:01:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 05:01:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 05:01:38 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-08 05:01:38 --> Anggota MX_Controller Initialized
ERROR - 2016-10-08 05:01:38 --> Module controller failed to run: anggota/Anggota/data/umum
ERROR - 2016-10-08 05:01:38 --> Severity: Error --> Call to a member function num_rows() on null E:\SERVER\htdocs\kops\application\views\main_html\content\list_anggota.php 36
INFO - 2016-10-08 05:01:41 --> Config Class Initialized
INFO - 2016-10-08 05:01:41 --> Hooks Class Initialized
DEBUG - 2016-10-08 05:01:41 --> UTF-8 Support Enabled
INFO - 2016-10-08 05:01:41 --> Utf8 Class Initialized
INFO - 2016-10-08 05:01:41 --> URI Class Initialized
INFO - 2016-10-08 05:01:41 --> Router Class Initialized
INFO - 2016-10-08 05:01:41 --> Output Class Initialized
INFO - 2016-10-08 05:01:41 --> Security Class Initialized
DEBUG - 2016-10-08 05:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 05:01:41 --> Input Class Initialized
INFO - 2016-10-08 05:01:41 --> Language Class Initialized
INFO - 2016-10-08 05:01:42 --> Language Class Initialized
INFO - 2016-10-08 05:01:42 --> Config Class Initialized
INFO - 2016-10-08 05:01:42 --> Loader Class Initialized
INFO - 2016-10-08 05:01:42 --> Helper loaded: url_helper
INFO - 2016-10-08 05:01:42 --> Database Driver Class Initialized
INFO - 2016-10-08 05:01:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 05:01:42 --> Controller Class Initialized
DEBUG - 2016-10-08 05:01:42 --> Index MX_Controller Initialized
INFO - 2016-10-08 05:01:42 --> Model Class Initialized
INFO - 2016-10-08 05:01:42 --> Model Class Initialized
ERROR - 2016-10-08 05:01:42 --> Unable to delete cache file for admin/index/data/anggota/karyawan
DEBUG - 2016-10-08 05:01:42 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 05:01:42 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 05:01:42 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 05:01:42 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-08 05:01:42 --> Anggota MX_Controller Initialized
ERROR - 2016-10-08 05:01:42 --> Module controller failed to run: anggota/Anggota/data/karyawan
ERROR - 2016-10-08 05:01:42 --> Severity: Error --> Call to a member function num_rows() on null E:\SERVER\htdocs\kops\application\views\main_html\content\list_anggota.php 36
INFO - 2016-10-08 05:01:44 --> Config Class Initialized
INFO - 2016-10-08 05:01:44 --> Hooks Class Initialized
DEBUG - 2016-10-08 05:01:44 --> UTF-8 Support Enabled
INFO - 2016-10-08 05:01:44 --> Utf8 Class Initialized
INFO - 2016-10-08 05:01:44 --> URI Class Initialized
INFO - 2016-10-08 05:01:44 --> Router Class Initialized
INFO - 2016-10-08 05:01:44 --> Output Class Initialized
INFO - 2016-10-08 05:01:44 --> Security Class Initialized
DEBUG - 2016-10-08 05:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 05:01:44 --> Input Class Initialized
INFO - 2016-10-08 05:01:44 --> Language Class Initialized
INFO - 2016-10-08 05:01:44 --> Language Class Initialized
INFO - 2016-10-08 05:01:44 --> Config Class Initialized
INFO - 2016-10-08 05:01:44 --> Loader Class Initialized
INFO - 2016-10-08 05:01:44 --> Helper loaded: url_helper
INFO - 2016-10-08 05:01:44 --> Database Driver Class Initialized
INFO - 2016-10-08 05:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 05:01:44 --> Controller Class Initialized
DEBUG - 2016-10-08 05:01:44 --> Index MX_Controller Initialized
INFO - 2016-10-08 05:01:44 --> Model Class Initialized
INFO - 2016-10-08 05:01:44 --> Model Class Initialized
ERROR - 2016-10-08 05:01:44 --> Unable to delete cache file for admin/index/data/anggota
DEBUG - 2016-10-08 05:01:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 05:01:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 05:01:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 05:01:44 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-08 05:01:44 --> Anggota MX_Controller Initialized
ERROR - 2016-10-08 05:01:44 --> Module controller failed to run: anggota/Anggota/data/All
ERROR - 2016-10-08 05:01:44 --> Severity: Error --> Call to a member function num_rows() on null E:\SERVER\htdocs\kops\application\views\main_html\content\list_anggota.php 36
INFO - 2016-10-08 05:01:45 --> Config Class Initialized
INFO - 2016-10-08 05:01:45 --> Hooks Class Initialized
DEBUG - 2016-10-08 05:01:45 --> UTF-8 Support Enabled
INFO - 2016-10-08 05:01:45 --> Utf8 Class Initialized
INFO - 2016-10-08 05:01:46 --> URI Class Initialized
INFO - 2016-10-08 05:01:46 --> Router Class Initialized
INFO - 2016-10-08 05:01:46 --> Output Class Initialized
INFO - 2016-10-08 05:01:46 --> Security Class Initialized
DEBUG - 2016-10-08 05:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 05:01:46 --> Input Class Initialized
INFO - 2016-10-08 05:01:46 --> Language Class Initialized
INFO - 2016-10-08 05:01:46 --> Language Class Initialized
INFO - 2016-10-08 05:01:46 --> Config Class Initialized
INFO - 2016-10-08 05:01:46 --> Loader Class Initialized
INFO - 2016-10-08 05:01:46 --> Helper loaded: url_helper
INFO - 2016-10-08 05:01:46 --> Database Driver Class Initialized
INFO - 2016-10-08 05:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 05:01:46 --> Controller Class Initialized
DEBUG - 2016-10-08 05:01:46 --> Index MX_Controller Initialized
INFO - 2016-10-08 05:01:46 --> Model Class Initialized
INFO - 2016-10-08 05:01:46 --> Model Class Initialized
ERROR - 2016-10-08 05:01:46 --> Unable to delete cache file for admin/index/data/anggota/umum
DEBUG - 2016-10-08 05:01:46 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 05:01:46 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 05:01:46 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 05:01:46 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-08 05:01:46 --> Anggota MX_Controller Initialized
ERROR - 2016-10-08 05:01:46 --> Module controller failed to run: anggota/Anggota/data/umum
ERROR - 2016-10-08 05:01:46 --> Severity: Error --> Call to a member function num_rows() on null E:\SERVER\htdocs\kops\application\views\main_html\content\list_anggota.php 36
INFO - 2016-10-08 05:02:00 --> Config Class Initialized
INFO - 2016-10-08 05:02:00 --> Hooks Class Initialized
DEBUG - 2016-10-08 05:02:00 --> UTF-8 Support Enabled
INFO - 2016-10-08 05:02:00 --> Utf8 Class Initialized
INFO - 2016-10-08 05:02:00 --> URI Class Initialized
INFO - 2016-10-08 05:02:00 --> Router Class Initialized
INFO - 2016-10-08 05:02:00 --> Output Class Initialized
INFO - 2016-10-08 05:02:00 --> Security Class Initialized
DEBUG - 2016-10-08 05:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 05:02:00 --> Input Class Initialized
INFO - 2016-10-08 05:02:00 --> Language Class Initialized
INFO - 2016-10-08 05:02:00 --> Language Class Initialized
INFO - 2016-10-08 05:02:01 --> Config Class Initialized
INFO - 2016-10-08 05:02:01 --> Loader Class Initialized
INFO - 2016-10-08 05:02:01 --> Helper loaded: url_helper
INFO - 2016-10-08 05:02:01 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 05:02:01 --> Controller Class Initialized
DEBUG - 2016-10-08 05:02:01 --> Index MX_Controller Initialized
INFO - 2016-10-08 05:02:01 --> Model Class Initialized
INFO - 2016-10-08 05:02:01 --> Model Class Initialized
ERROR - 2016-10-08 05:02:01 --> Unable to delete cache file for admin/index/data/anggota/umum
DEBUG - 2016-10-08 05:02:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 05:02:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 05:02:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 05:02:01 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-08 05:02:01 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-08 05:02:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-08 05:02:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 05:02:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 05:02:01 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:01 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:01 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:01 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:01 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:01 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:01 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:01 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:01 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:01 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:01 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:01 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:01 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:01 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:01 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:01 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:01 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:01 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:02 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:02 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:02 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:02 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:02 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:02 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:02 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:02 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:02 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:02 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:02 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:02 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:02 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:02 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:02 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:02 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:02 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:02 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:02 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:02 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:02 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:02 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:02 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:02 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:02 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:02 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:02 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:02 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:02 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:03 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:03 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:03 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:03 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:03 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:03 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:03 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:03 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:03 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:03 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:03 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:03 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:03 --> Database Driver Class Initialized
DEBUG - 2016-10-08 05:02:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 05:02:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 05:02:03 --> Final output sent to browser
DEBUG - 2016-10-08 05:02:03 --> Total execution time: 2.8267
INFO - 2016-10-08 05:02:08 --> Config Class Initialized
INFO - 2016-10-08 05:02:08 --> Hooks Class Initialized
DEBUG - 2016-10-08 05:02:08 --> UTF-8 Support Enabled
INFO - 2016-10-08 05:02:08 --> Utf8 Class Initialized
INFO - 2016-10-08 05:02:08 --> URI Class Initialized
INFO - 2016-10-08 05:02:08 --> Router Class Initialized
INFO - 2016-10-08 05:02:08 --> Output Class Initialized
INFO - 2016-10-08 05:02:08 --> Security Class Initialized
DEBUG - 2016-10-08 05:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 05:02:08 --> Input Class Initialized
INFO - 2016-10-08 05:02:08 --> Language Class Initialized
INFO - 2016-10-08 05:02:08 --> Language Class Initialized
INFO - 2016-10-08 05:02:08 --> Config Class Initialized
INFO - 2016-10-08 05:02:08 --> Loader Class Initialized
INFO - 2016-10-08 05:02:08 --> Helper loaded: url_helper
INFO - 2016-10-08 05:02:08 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 05:02:08 --> Controller Class Initialized
DEBUG - 2016-10-08 05:02:08 --> Index MX_Controller Initialized
INFO - 2016-10-08 05:02:08 --> Model Class Initialized
INFO - 2016-10-08 05:02:08 --> Model Class Initialized
ERROR - 2016-10-08 05:02:08 --> Unable to delete cache file for admin/index/data/anggota/karyawan
DEBUG - 2016-10-08 05:02:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 05:02:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 05:02:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 05:02:08 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-08 05:02:08 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-08 05:02:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-08 05:02:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 05:02:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 05:02:08 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:08 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:08 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:08 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:08 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:09 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:09 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:09 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:09 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:09 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:09 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:09 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:09 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:09 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:09 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:09 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:09 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:09 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:09 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:09 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:09 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:09 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:09 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:09 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:09 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:09 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:09 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:09 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:09 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:09 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:09 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:09 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:09 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:09 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:09 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:09 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:09 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:10 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:10 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:10 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:10 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:10 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:10 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:10 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:10 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:10 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:10 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:10 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:10 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:10 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:10 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:10 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:10 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:10 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:10 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:10 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:10 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:10 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:10 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:10 --> Database Driver Class Initialized
DEBUG - 2016-10-08 05:02:10 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 05:02:10 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 05:02:10 --> Final output sent to browser
DEBUG - 2016-10-08 05:02:10 --> Total execution time: 2.8209
INFO - 2016-10-08 05:02:30 --> Config Class Initialized
INFO - 2016-10-08 05:02:30 --> Hooks Class Initialized
DEBUG - 2016-10-08 05:02:30 --> UTF-8 Support Enabled
INFO - 2016-10-08 05:02:30 --> Utf8 Class Initialized
INFO - 2016-10-08 05:02:30 --> URI Class Initialized
INFO - 2016-10-08 05:02:30 --> Router Class Initialized
INFO - 2016-10-08 05:02:30 --> Output Class Initialized
INFO - 2016-10-08 05:02:31 --> Security Class Initialized
DEBUG - 2016-10-08 05:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 05:02:31 --> Input Class Initialized
INFO - 2016-10-08 05:02:31 --> Language Class Initialized
INFO - 2016-10-08 05:02:31 --> Language Class Initialized
INFO - 2016-10-08 05:02:31 --> Config Class Initialized
INFO - 2016-10-08 05:02:31 --> Loader Class Initialized
INFO - 2016-10-08 05:02:31 --> Helper loaded: url_helper
INFO - 2016-10-08 05:02:31 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 05:02:31 --> Controller Class Initialized
DEBUG - 2016-10-08 05:02:31 --> Index MX_Controller Initialized
INFO - 2016-10-08 05:02:31 --> Model Class Initialized
INFO - 2016-10-08 05:02:31 --> Model Class Initialized
ERROR - 2016-10-08 05:02:31 --> Unable to delete cache file for admin/index/data/anggota/umum
DEBUG - 2016-10-08 05:02:31 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 05:02:31 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 05:02:31 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 05:02:31 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-08 05:02:31 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-08 05:02:31 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-08 05:02:31 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 05:02:31 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 05:02:31 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:31 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:31 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:31 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:31 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:31 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:31 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:31 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:31 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:31 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:31 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:31 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:32 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:32 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:32 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:32 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:32 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:32 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:32 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:32 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:32 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:32 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:32 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:32 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:32 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:32 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:32 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:32 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:32 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:32 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:32 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:32 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:32 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:32 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:32 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:32 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:32 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:32 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:32 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:32 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:32 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:32 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:32 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:33 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:33 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:33 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:33 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:33 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:33 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:33 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:33 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:33 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:33 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:33 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:33 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:33 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:33 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:33 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:33 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:33 --> Database Driver Class Initialized
DEBUG - 2016-10-08 05:02:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 05:02:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 05:02:33 --> Final output sent to browser
DEBUG - 2016-10-08 05:02:33 --> Total execution time: 2.7882
INFO - 2016-10-08 05:02:38 --> Config Class Initialized
INFO - 2016-10-08 05:02:38 --> Hooks Class Initialized
DEBUG - 2016-10-08 05:02:38 --> UTF-8 Support Enabled
INFO - 2016-10-08 05:02:38 --> Utf8 Class Initialized
INFO - 2016-10-08 05:02:38 --> URI Class Initialized
INFO - 2016-10-08 05:02:38 --> Router Class Initialized
INFO - 2016-10-08 05:02:38 --> Output Class Initialized
INFO - 2016-10-08 05:02:38 --> Security Class Initialized
DEBUG - 2016-10-08 05:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 05:02:38 --> Input Class Initialized
INFO - 2016-10-08 05:02:38 --> Language Class Initialized
INFO - 2016-10-08 05:02:38 --> Language Class Initialized
INFO - 2016-10-08 05:02:38 --> Config Class Initialized
INFO - 2016-10-08 05:02:38 --> Loader Class Initialized
INFO - 2016-10-08 05:02:38 --> Helper loaded: url_helper
INFO - 2016-10-08 05:02:38 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 05:02:38 --> Controller Class Initialized
DEBUG - 2016-10-08 05:02:38 --> Index MX_Controller Initialized
INFO - 2016-10-08 05:02:38 --> Model Class Initialized
INFO - 2016-10-08 05:02:38 --> Model Class Initialized
ERROR - 2016-10-08 05:02:38 --> Unable to delete cache file for admin/index/data/anggota/karyawan
DEBUG - 2016-10-08 05:02:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 05:02:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 05:02:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 05:02:38 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-08 05:02:39 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-08 05:02:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-08 05:02:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 05:02:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 05:02:39 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:39 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:39 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:39 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:39 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:39 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:39 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:39 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:39 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:39 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:39 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:39 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:39 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:39 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:39 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:39 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:39 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:39 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:39 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:39 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:39 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:39 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:39 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:39 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:39 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:39 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:39 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:39 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:40 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:40 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:40 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:40 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:40 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:40 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:40 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:40 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:40 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:40 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:40 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:40 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:40 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:40 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:40 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:40 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:40 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:40 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:40 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:40 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:40 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:40 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:40 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:40 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:40 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:40 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:40 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:40 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:40 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:40 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:40 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:40 --> Database Driver Class Initialized
DEBUG - 2016-10-08 05:02:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 05:02:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 05:02:41 --> Final output sent to browser
DEBUG - 2016-10-08 05:02:41 --> Total execution time: 2.7782
INFO - 2016-10-08 05:02:45 --> Config Class Initialized
INFO - 2016-10-08 05:02:46 --> Hooks Class Initialized
DEBUG - 2016-10-08 05:02:46 --> UTF-8 Support Enabled
INFO - 2016-10-08 05:02:46 --> Utf8 Class Initialized
INFO - 2016-10-08 05:02:46 --> URI Class Initialized
INFO - 2016-10-08 05:02:46 --> Router Class Initialized
INFO - 2016-10-08 05:02:46 --> Output Class Initialized
INFO - 2016-10-08 05:02:46 --> Security Class Initialized
DEBUG - 2016-10-08 05:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 05:02:46 --> Input Class Initialized
INFO - 2016-10-08 05:02:46 --> Language Class Initialized
INFO - 2016-10-08 05:02:46 --> Language Class Initialized
INFO - 2016-10-08 05:02:46 --> Config Class Initialized
INFO - 2016-10-08 05:02:46 --> Loader Class Initialized
INFO - 2016-10-08 05:02:46 --> Helper loaded: url_helper
INFO - 2016-10-08 05:02:46 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 05:02:46 --> Controller Class Initialized
DEBUG - 2016-10-08 05:02:46 --> Index MX_Controller Initialized
INFO - 2016-10-08 05:02:46 --> Model Class Initialized
INFO - 2016-10-08 05:02:46 --> Model Class Initialized
ERROR - 2016-10-08 05:02:46 --> Unable to delete cache file for admin/index/data/anggota
DEBUG - 2016-10-08 05:02:46 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 05:02:46 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 05:02:46 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 05:02:46 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-08 05:02:46 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-08 05:02:46 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-08 05:02:46 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 05:02:46 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 05:02:46 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:46 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:46 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:46 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:47 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:47 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:47 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:47 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:47 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:47 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:47 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:47 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:47 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:47 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:47 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:47 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:47 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:47 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:47 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:47 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:47 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:47 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:47 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:47 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:47 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:47 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:47 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:47 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:48 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:48 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:48 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:48 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:48 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:48 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:48 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:48 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:48 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:48 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:48 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:48 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:48 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:48 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:48 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:48 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:48 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:48 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:48 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:48 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:48 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:48 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:48 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:48 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:49 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:49 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:49 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:49 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:49 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:49 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:49 --> Database Driver Class Initialized
INFO - 2016-10-08 05:02:49 --> Database Driver Class Initialized
DEBUG - 2016-10-08 05:02:49 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 05:02:49 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 05:02:49 --> Final output sent to browser
DEBUG - 2016-10-08 05:02:49 --> Total execution time: 3.3546
INFO - 2016-10-08 05:03:10 --> Config Class Initialized
INFO - 2016-10-08 05:03:10 --> Hooks Class Initialized
DEBUG - 2016-10-08 05:03:10 --> UTF-8 Support Enabled
INFO - 2016-10-08 05:03:10 --> Utf8 Class Initialized
INFO - 2016-10-08 05:03:10 --> URI Class Initialized
INFO - 2016-10-08 05:03:10 --> Router Class Initialized
INFO - 2016-10-08 05:03:10 --> Output Class Initialized
INFO - 2016-10-08 05:03:10 --> Security Class Initialized
DEBUG - 2016-10-08 05:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 05:03:11 --> Input Class Initialized
INFO - 2016-10-08 05:03:11 --> Language Class Initialized
INFO - 2016-10-08 05:03:11 --> Language Class Initialized
INFO - 2016-10-08 05:03:11 --> Config Class Initialized
INFO - 2016-10-08 05:03:11 --> Loader Class Initialized
INFO - 2016-10-08 05:03:11 --> Helper loaded: url_helper
INFO - 2016-10-08 05:03:11 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 05:03:11 --> Controller Class Initialized
DEBUG - 2016-10-08 05:03:11 --> Index MX_Controller Initialized
INFO - 2016-10-08 05:03:11 --> Model Class Initialized
INFO - 2016-10-08 05:03:11 --> Model Class Initialized
ERROR - 2016-10-08 05:03:11 --> Unable to delete cache file for admin/index/detail_anggota/356a192b7913b04c54574d18c28d46e6395428ab
DEBUG - 2016-10-08 05:03:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 05:03:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 05:03:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
INFO - 2016-10-08 05:03:11 --> Database Driver Class Initialized
DEBUG - 2016-10-08 05:03:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_pinjaman.php
INFO - 2016-10-08 05:03:11 --> Database Driver Class Initialized
DEBUG - 2016-10-08 05:03:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_tabungan.php
DEBUG - 2016-10-08 05:03:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/profile_anggota.php
DEBUG - 2016-10-08 05:03:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 05:03:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 05:03:11 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:11 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:11 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:11 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:12 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:12 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:12 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:12 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:12 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:12 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:12 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:12 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:12 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:12 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:12 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:12 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:12 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:12 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:12 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:12 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:12 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:12 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:12 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:12 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:12 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:12 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:12 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:12 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:12 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:12 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:12 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:12 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:12 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:12 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:12 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:12 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:13 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:13 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:13 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:13 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:13 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:13 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:13 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:13 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:13 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:13 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:13 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:13 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:13 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:13 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:13 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:13 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:13 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:13 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:13 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:13 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:13 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:13 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:13 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:13 --> Database Driver Class Initialized
DEBUG - 2016-10-08 05:03:13 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 05:03:13 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 05:03:13 --> Final output sent to browser
DEBUG - 2016-10-08 05:03:13 --> Total execution time: 3.0210
INFO - 2016-10-08 05:03:13 --> Config Class Initialized
INFO - 2016-10-08 05:03:14 --> Hooks Class Initialized
DEBUG - 2016-10-08 05:03:14 --> UTF-8 Support Enabled
INFO - 2016-10-08 05:03:14 --> Utf8 Class Initialized
INFO - 2016-10-08 05:03:14 --> URI Class Initialized
INFO - 2016-10-08 05:03:14 --> Router Class Initialized
INFO - 2016-10-08 05:03:14 --> Output Class Initialized
INFO - 2016-10-08 05:03:14 --> Security Class Initialized
DEBUG - 2016-10-08 05:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 05:03:14 --> Input Class Initialized
INFO - 2016-10-08 05:03:14 --> Language Class Initialized
INFO - 2016-10-08 05:03:14 --> Language Class Initialized
INFO - 2016-10-08 05:03:14 --> Config Class Initialized
INFO - 2016-10-08 05:03:14 --> Loader Class Initialized
INFO - 2016-10-08 05:03:14 --> Helper loaded: url_helper
INFO - 2016-10-08 05:03:14 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 05:03:14 --> Controller Class Initialized
DEBUG - 2016-10-08 05:03:14 --> Index MX_Controller Initialized
INFO - 2016-10-08 05:03:15 --> Model Class Initialized
INFO - 2016-10-08 05:03:15 --> Model Class Initialized
ERROR - 2016-10-08 05:03:15 --> Unable to delete cache file for admin/index/detail_anggota/images/picture.jpg
DEBUG - 2016-10-08 05:03:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 05:03:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 05:03:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
ERROR - 2016-10-08 05:03:15 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 16
ERROR - 2016-10-08 05:03:15 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 19
ERROR - 2016-10-08 05:03:15 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 22
ERROR - 2016-10-08 05:03:15 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 38
INFO - 2016-10-08 05:03:15 --> Database Driver Class Initialized
DEBUG - 2016-10-08 05:03:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_pinjaman.php
ERROR - 2016-10-08 05:03:15 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 41
INFO - 2016-10-08 05:03:16 --> Database Driver Class Initialized
DEBUG - 2016-10-08 05:03:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_tabungan.php
DEBUG - 2016-10-08 05:03:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/profile_anggota.php
DEBUG - 2016-10-08 05:03:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 05:03:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 05:03:16 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:16 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:16 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:16 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:16 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:17 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:17 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:17 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:17 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:17 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:17 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:17 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:17 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:17 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:17 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:17 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:18 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:18 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:18 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:18 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:18 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:18 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:18 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:18 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:18 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:18 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:18 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:18 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:18 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:19 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:19 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:19 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:19 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:19 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:19 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:19 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:19 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:19 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:19 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:19 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:19 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:19 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:19 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:19 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:19 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:20 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:20 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:20 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:20 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:20 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:20 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:20 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:20 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:20 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:20 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:20 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:20 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:21 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:21 --> Database Driver Class Initialized
INFO - 2016-10-08 05:03:21 --> Database Driver Class Initialized
DEBUG - 2016-10-08 05:03:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 05:03:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 05:03:21 --> Final output sent to browser
DEBUG - 2016-10-08 05:03:21 --> Total execution time: 7.3940
INFO - 2016-10-08 05:05:11 --> Config Class Initialized
INFO - 2016-10-08 05:05:11 --> Hooks Class Initialized
DEBUG - 2016-10-08 05:05:11 --> UTF-8 Support Enabled
INFO - 2016-10-08 05:05:11 --> Utf8 Class Initialized
INFO - 2016-10-08 05:05:12 --> URI Class Initialized
INFO - 2016-10-08 05:05:12 --> Router Class Initialized
INFO - 2016-10-08 05:05:12 --> Output Class Initialized
INFO - 2016-10-08 05:05:12 --> Security Class Initialized
DEBUG - 2016-10-08 05:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 05:05:12 --> Input Class Initialized
INFO - 2016-10-08 05:05:12 --> Language Class Initialized
INFO - 2016-10-08 05:05:12 --> Language Class Initialized
INFO - 2016-10-08 05:05:12 --> Config Class Initialized
INFO - 2016-10-08 05:05:12 --> Loader Class Initialized
INFO - 2016-10-08 05:05:12 --> Helper loaded: url_helper
INFO - 2016-10-08 05:05:12 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 05:05:12 --> Controller Class Initialized
DEBUG - 2016-10-08 05:05:12 --> Index MX_Controller Initialized
INFO - 2016-10-08 05:05:12 --> Model Class Initialized
INFO - 2016-10-08 05:05:12 --> Model Class Initialized
ERROR - 2016-10-08 05:05:12 --> Unable to delete cache file for admin/index/detail_anggota/356a192b7913b04c54574d18c28d46e6395428ab
DEBUG - 2016-10-08 05:05:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 05:05:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 05:05:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
INFO - 2016-10-08 05:05:12 --> Database Driver Class Initialized
DEBUG - 2016-10-08 05:05:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_pinjaman.php
INFO - 2016-10-08 05:05:12 --> Database Driver Class Initialized
DEBUG - 2016-10-08 05:05:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_tabungan.php
DEBUG - 2016-10-08 05:05:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/profile_anggota.php
DEBUG - 2016-10-08 05:05:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 05:05:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 05:05:12 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:12 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:12 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:12 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:12 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:12 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:12 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:13 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:13 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:13 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:13 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:13 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:13 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:13 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:13 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:13 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:13 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:13 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:13 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:13 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:13 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:13 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:13 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:13 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:13 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:13 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:13 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:13 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:13 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:13 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:13 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:13 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:13 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:13 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:13 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:13 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:13 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:14 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:14 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:14 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:14 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:14 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:14 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:14 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:14 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:14 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:14 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:14 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:14 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:14 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:14 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:14 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:14 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:14 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:14 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:14 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:14 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:14 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:14 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:14 --> Database Driver Class Initialized
DEBUG - 2016-10-08 05:05:14 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 05:05:14 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 05:05:14 --> Final output sent to browser
DEBUG - 2016-10-08 05:05:14 --> Total execution time: 2.9642
INFO - 2016-10-08 05:05:15 --> Config Class Initialized
INFO - 2016-10-08 05:05:15 --> Hooks Class Initialized
DEBUG - 2016-10-08 05:05:15 --> UTF-8 Support Enabled
INFO - 2016-10-08 05:05:15 --> Utf8 Class Initialized
INFO - 2016-10-08 05:05:15 --> URI Class Initialized
INFO - 2016-10-08 05:05:15 --> Router Class Initialized
INFO - 2016-10-08 05:05:15 --> Output Class Initialized
INFO - 2016-10-08 05:05:15 --> Security Class Initialized
DEBUG - 2016-10-08 05:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 05:05:15 --> Input Class Initialized
INFO - 2016-10-08 05:05:15 --> Language Class Initialized
INFO - 2016-10-08 05:05:15 --> Language Class Initialized
INFO - 2016-10-08 05:05:15 --> Config Class Initialized
INFO - 2016-10-08 05:05:15 --> Loader Class Initialized
INFO - 2016-10-08 05:05:15 --> Helper loaded: url_helper
INFO - 2016-10-08 05:05:16 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 05:05:16 --> Controller Class Initialized
DEBUG - 2016-10-08 05:05:16 --> Index MX_Controller Initialized
INFO - 2016-10-08 05:05:16 --> Model Class Initialized
INFO - 2016-10-08 05:05:16 --> Model Class Initialized
ERROR - 2016-10-08 05:05:16 --> Unable to delete cache file for admin/index/detail_anggota/images/picture.jpg
DEBUG - 2016-10-08 05:05:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 05:05:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 05:05:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
ERROR - 2016-10-08 05:05:16 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 16
ERROR - 2016-10-08 05:05:16 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 19
ERROR - 2016-10-08 05:05:17 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 22
ERROR - 2016-10-08 05:05:17 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 38
INFO - 2016-10-08 05:05:17 --> Database Driver Class Initialized
DEBUG - 2016-10-08 05:05:17 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_pinjaman.php
ERROR - 2016-10-08 05:05:17 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 41
INFO - 2016-10-08 05:05:17 --> Database Driver Class Initialized
DEBUG - 2016-10-08 05:05:17 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_tabungan.php
DEBUG - 2016-10-08 05:05:17 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/profile_anggota.php
DEBUG - 2016-10-08 05:05:17 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 05:05:17 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 05:05:17 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:17 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:18 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:18 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:18 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:18 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:18 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:18 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:18 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:18 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:19 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:19 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:19 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:19 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:19 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:19 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:19 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:19 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:19 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:19 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:19 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:19 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:19 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:20 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:20 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:20 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:20 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:20 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:20 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:20 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:20 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:20 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:20 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:20 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:21 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:21 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:21 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:21 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:21 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:21 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:21 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:21 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:21 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:21 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:21 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:21 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:22 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:22 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:22 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:22 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:22 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:22 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:22 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:22 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:22 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:22 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:22 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:22 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:22 --> Database Driver Class Initialized
INFO - 2016-10-08 05:05:22 --> Database Driver Class Initialized
DEBUG - 2016-10-08 05:05:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 05:05:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 05:05:22 --> Final output sent to browser
DEBUG - 2016-10-08 05:05:22 --> Total execution time: 7.8781
INFO - 2016-10-08 05:06:54 --> Config Class Initialized
INFO - 2016-10-08 05:06:54 --> Hooks Class Initialized
DEBUG - 2016-10-08 05:06:55 --> UTF-8 Support Enabled
INFO - 2016-10-08 05:06:55 --> Utf8 Class Initialized
INFO - 2016-10-08 05:06:55 --> URI Class Initialized
INFO - 2016-10-08 05:06:55 --> Router Class Initialized
INFO - 2016-10-08 05:06:55 --> Output Class Initialized
INFO - 2016-10-08 05:06:55 --> Security Class Initialized
DEBUG - 2016-10-08 05:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 05:06:55 --> Input Class Initialized
INFO - 2016-10-08 05:06:55 --> Language Class Initialized
INFO - 2016-10-08 05:06:55 --> Language Class Initialized
INFO - 2016-10-08 05:06:55 --> Config Class Initialized
INFO - 2016-10-08 05:06:55 --> Loader Class Initialized
INFO - 2016-10-08 05:06:55 --> Helper loaded: url_helper
INFO - 2016-10-08 05:06:55 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 05:06:55 --> Controller Class Initialized
DEBUG - 2016-10-08 05:06:55 --> Index MX_Controller Initialized
INFO - 2016-10-08 05:06:55 --> Model Class Initialized
INFO - 2016-10-08 05:06:55 --> Model Class Initialized
ERROR - 2016-10-08 05:06:55 --> Unable to delete cache file for admin/index/detail_anggota/356a192b7913b04c54574d18c28d46e6395428ab
DEBUG - 2016-10-08 05:06:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 05:06:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 05:06:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
INFO - 2016-10-08 05:06:55 --> Database Driver Class Initialized
DEBUG - 2016-10-08 05:06:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_pinjaman.php
INFO - 2016-10-08 05:06:55 --> Database Driver Class Initialized
DEBUG - 2016-10-08 05:06:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_tabungan.php
DEBUG - 2016-10-08 05:06:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/profile_anggota.php
DEBUG - 2016-10-08 05:06:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 05:06:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 05:06:55 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:55 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:56 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:56 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:56 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:56 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:56 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:56 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:56 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:56 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:56 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:56 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:56 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:56 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:56 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:56 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:56 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:56 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:56 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:56 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:56 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:56 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:56 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:57 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:57 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:57 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:57 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:57 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:57 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:57 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:57 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:57 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:57 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:57 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:57 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:57 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:57 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:57 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:57 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:57 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:57 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:57 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:57 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:57 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:57 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:57 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:57 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:57 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:57 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:57 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:58 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:58 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:58 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:58 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:58 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:58 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:58 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:58 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:58 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:58 --> Database Driver Class Initialized
DEBUG - 2016-10-08 05:06:58 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 05:06:58 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 05:06:58 --> Final output sent to browser
DEBUG - 2016-10-08 05:06:58 --> Total execution time: 3.5395
INFO - 2016-10-08 05:06:58 --> Config Class Initialized
INFO - 2016-10-08 05:06:58 --> Hooks Class Initialized
DEBUG - 2016-10-08 05:06:58 --> UTF-8 Support Enabled
INFO - 2016-10-08 05:06:58 --> Utf8 Class Initialized
INFO - 2016-10-08 05:06:58 --> URI Class Initialized
INFO - 2016-10-08 05:06:59 --> Router Class Initialized
INFO - 2016-10-08 05:06:59 --> Output Class Initialized
INFO - 2016-10-08 05:06:59 --> Security Class Initialized
DEBUG - 2016-10-08 05:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 05:06:59 --> Input Class Initialized
INFO - 2016-10-08 05:06:59 --> Language Class Initialized
INFO - 2016-10-08 05:06:59 --> Language Class Initialized
INFO - 2016-10-08 05:06:59 --> Config Class Initialized
INFO - 2016-10-08 05:06:59 --> Loader Class Initialized
INFO - 2016-10-08 05:06:59 --> Helper loaded: url_helper
INFO - 2016-10-08 05:06:59 --> Database Driver Class Initialized
INFO - 2016-10-08 05:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 05:06:59 --> Controller Class Initialized
DEBUG - 2016-10-08 05:06:59 --> Index MX_Controller Initialized
INFO - 2016-10-08 05:07:00 --> Model Class Initialized
INFO - 2016-10-08 05:07:00 --> Model Class Initialized
ERROR - 2016-10-08 05:07:00 --> Unable to delete cache file for admin/index/detail_anggota/images/picture.jpg
DEBUG - 2016-10-08 05:07:00 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 05:07:00 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 05:07:00 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
ERROR - 2016-10-08 05:07:00 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 16
ERROR - 2016-10-08 05:07:00 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 19
ERROR - 2016-10-08 05:07:00 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 22
ERROR - 2016-10-08 05:07:01 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 38
INFO - 2016-10-08 05:07:01 --> Database Driver Class Initialized
DEBUG - 2016-10-08 05:07:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_pinjaman.php
ERROR - 2016-10-08 05:07:01 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 41
INFO - 2016-10-08 05:07:01 --> Database Driver Class Initialized
DEBUG - 2016-10-08 05:07:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_tabungan.php
DEBUG - 2016-10-08 05:07:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/profile_anggota.php
DEBUG - 2016-10-08 05:07:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 05:07:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 05:07:02 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:02 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:02 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:02 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:02 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:02 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:02 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:02 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:02 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:02 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:02 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:02 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:02 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:02 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:02 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:02 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:02 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:03 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:03 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:03 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:03 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:03 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:04 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:04 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:04 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:04 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:04 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:04 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:04 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:05 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:05 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:05 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:05 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:05 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:05 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:05 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:05 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:05 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:05 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:05 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:05 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:05 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:05 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:05 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:06 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:06 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:06 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:06 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:06 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:06 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:06 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:06 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:06 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:06 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:06 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:06 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:06 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:06 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:06 --> Database Driver Class Initialized
INFO - 2016-10-08 05:07:06 --> Database Driver Class Initialized
DEBUG - 2016-10-08 05:07:06 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 05:07:06 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 05:07:06 --> Final output sent to browser
DEBUG - 2016-10-08 05:07:06 --> Total execution time: 8.1514
INFO - 2016-10-08 06:33:05 --> Config Class Initialized
INFO - 2016-10-08 06:33:05 --> Hooks Class Initialized
DEBUG - 2016-10-08 06:33:05 --> UTF-8 Support Enabled
INFO - 2016-10-08 06:33:05 --> Utf8 Class Initialized
INFO - 2016-10-08 06:33:05 --> URI Class Initialized
INFO - 2016-10-08 06:33:06 --> Router Class Initialized
INFO - 2016-10-08 06:33:06 --> Output Class Initialized
INFO - 2016-10-08 06:33:06 --> Security Class Initialized
DEBUG - 2016-10-08 06:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 06:33:06 --> Input Class Initialized
INFO - 2016-10-08 06:33:06 --> Language Class Initialized
ERROR - 2016-10-08 06:33:06 --> Severity: Compile Error --> Cannot redeclare Index::getDetailAngsuran() E:\SERVER\htdocs\kops\application\modules\admin\controllers\Index.php 1154
INFO - 2016-10-08 06:33:32 --> Config Class Initialized
INFO - 2016-10-08 06:33:32 --> Hooks Class Initialized
DEBUG - 2016-10-08 06:33:32 --> UTF-8 Support Enabled
INFO - 2016-10-08 06:33:33 --> Utf8 Class Initialized
INFO - 2016-10-08 06:33:33 --> URI Class Initialized
INFO - 2016-10-08 06:33:33 --> Router Class Initialized
INFO - 2016-10-08 06:33:33 --> Output Class Initialized
INFO - 2016-10-08 06:33:33 --> Security Class Initialized
DEBUG - 2016-10-08 06:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 06:33:33 --> Input Class Initialized
INFO - 2016-10-08 06:33:33 --> Language Class Initialized
INFO - 2016-10-08 06:33:33 --> Language Class Initialized
INFO - 2016-10-08 06:33:33 --> Config Class Initialized
INFO - 2016-10-08 06:33:33 --> Loader Class Initialized
INFO - 2016-10-08 06:33:33 --> Helper loaded: url_helper
INFO - 2016-10-08 06:33:33 --> Database Driver Class Initialized
INFO - 2016-10-08 06:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 06:33:34 --> Controller Class Initialized
DEBUG - 2016-10-08 06:33:34 --> Index MX_Controller Initialized
INFO - 2016-10-08 06:33:34 --> Model Class Initialized
INFO - 2016-10-08 06:33:34 --> Model Class Initialized
ERROR - 2016-10-08 06:33:34 --> Unable to delete cache file for admin/index/getRaportAngsuran/123123123
DEBUG - 2016-10-08 06:33:34 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/raport_angsuran.php
INFO - 2016-10-08 06:33:34 --> Final output sent to browser
DEBUG - 2016-10-08 06:33:34 --> Total execution time: 1.6435
INFO - 2016-10-08 06:39:09 --> Config Class Initialized
INFO - 2016-10-08 06:39:09 --> Hooks Class Initialized
DEBUG - 2016-10-08 06:39:09 --> UTF-8 Support Enabled
INFO - 2016-10-08 06:39:09 --> Utf8 Class Initialized
INFO - 2016-10-08 06:39:10 --> URI Class Initialized
INFO - 2016-10-08 06:39:10 --> Router Class Initialized
INFO - 2016-10-08 06:39:10 --> Output Class Initialized
INFO - 2016-10-08 06:39:10 --> Security Class Initialized
DEBUG - 2016-10-08 06:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 06:39:10 --> Input Class Initialized
INFO - 2016-10-08 06:39:10 --> Language Class Initialized
INFO - 2016-10-08 06:39:10 --> Language Class Initialized
INFO - 2016-10-08 06:39:10 --> Config Class Initialized
INFO - 2016-10-08 06:39:10 --> Loader Class Initialized
INFO - 2016-10-08 06:39:10 --> Helper loaded: url_helper
INFO - 2016-10-08 06:39:10 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 06:39:10 --> Controller Class Initialized
DEBUG - 2016-10-08 06:39:10 --> Index MX_Controller Initialized
INFO - 2016-10-08 06:39:10 --> Model Class Initialized
INFO - 2016-10-08 06:39:10 --> Model Class Initialized
ERROR - 2016-10-08 06:39:10 --> Unable to delete cache file for admin/index
DEBUG - 2016-10-08 06:39:10 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 06:39:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 06:39:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 06:39:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/dashboard.php
DEBUG - 2016-10-08 06:39:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 06:39:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 06:39:11 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:11 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:11 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:11 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:11 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:11 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:11 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:11 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:11 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:11 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:11 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:11 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:11 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:11 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:11 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:11 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:11 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:11 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:11 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:11 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:11 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:11 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:11 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:11 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:13 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:13 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:13 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:13 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:13 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:13 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:13 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:13 --> Database Driver Class Initialized
DEBUG - 2016-10-08 06:39:13 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 06:39:13 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 06:39:13 --> Final output sent to browser
DEBUG - 2016-10-08 06:39:13 --> Total execution time: 3.5019
INFO - 2016-10-08 06:39:25 --> Config Class Initialized
INFO - 2016-10-08 06:39:25 --> Hooks Class Initialized
DEBUG - 2016-10-08 06:39:25 --> UTF-8 Support Enabled
INFO - 2016-10-08 06:39:25 --> Utf8 Class Initialized
INFO - 2016-10-08 06:39:25 --> URI Class Initialized
INFO - 2016-10-08 06:39:26 --> Router Class Initialized
INFO - 2016-10-08 06:39:26 --> Output Class Initialized
INFO - 2016-10-08 06:39:26 --> Security Class Initialized
DEBUG - 2016-10-08 06:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 06:39:26 --> Input Class Initialized
INFO - 2016-10-08 06:39:26 --> Language Class Initialized
INFO - 2016-10-08 06:39:26 --> Language Class Initialized
INFO - 2016-10-08 06:39:26 --> Config Class Initialized
INFO - 2016-10-08 06:39:26 --> Loader Class Initialized
INFO - 2016-10-08 06:39:26 --> Helper loaded: url_helper
INFO - 2016-10-08 06:39:26 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 06:39:26 --> Controller Class Initialized
DEBUG - 2016-10-08 06:39:26 --> Index MX_Controller Initialized
INFO - 2016-10-08 06:39:26 --> Model Class Initialized
INFO - 2016-10-08 06:39:26 --> Model Class Initialized
ERROR - 2016-10-08 06:39:26 --> Unable to delete cache file for admin/index/data/anggota
DEBUG - 2016-10-08 06:39:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 06:39:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 06:39:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 06:39:26 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-08 06:39:26 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-08 06:39:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-08 06:39:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 06:39:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 06:39:26 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:27 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:27 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:27 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:27 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:27 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:27 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:27 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:27 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:27 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:27 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:27 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:27 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:27 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:27 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:27 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:27 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:27 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:27 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:27 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:27 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:27 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:27 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:27 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:28 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:28 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:28 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:28 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:28 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:28 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:28 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:28 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:28 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:28 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:28 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:28 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:28 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:28 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:28 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:28 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:28 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:28 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:28 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:28 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:28 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:28 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:28 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:28 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:29 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:29 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:29 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:29 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:29 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:29 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:29 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:29 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:29 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:29 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:29 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:29 --> Database Driver Class Initialized
DEBUG - 2016-10-08 06:39:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 06:39:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 06:39:29 --> Final output sent to browser
DEBUG - 2016-10-08 06:39:29 --> Total execution time: 3.8195
INFO - 2016-10-08 06:39:35 --> Config Class Initialized
INFO - 2016-10-08 06:39:35 --> Hooks Class Initialized
DEBUG - 2016-10-08 06:39:35 --> UTF-8 Support Enabled
INFO - 2016-10-08 06:39:35 --> Utf8 Class Initialized
INFO - 2016-10-08 06:39:35 --> URI Class Initialized
INFO - 2016-10-08 06:39:35 --> Router Class Initialized
INFO - 2016-10-08 06:39:35 --> Output Class Initialized
INFO - 2016-10-08 06:39:35 --> Security Class Initialized
DEBUG - 2016-10-08 06:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 06:39:35 --> Input Class Initialized
INFO - 2016-10-08 06:39:35 --> Language Class Initialized
INFO - 2016-10-08 06:39:36 --> Language Class Initialized
INFO - 2016-10-08 06:39:36 --> Config Class Initialized
INFO - 2016-10-08 06:39:36 --> Loader Class Initialized
INFO - 2016-10-08 06:39:36 --> Helper loaded: url_helper
INFO - 2016-10-08 06:39:36 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 06:39:36 --> Controller Class Initialized
DEBUG - 2016-10-08 06:39:36 --> Index MX_Controller Initialized
INFO - 2016-10-08 06:39:36 --> Model Class Initialized
INFO - 2016-10-08 06:39:36 --> Model Class Initialized
ERROR - 2016-10-08 06:39:36 --> Unable to delete cache file for admin/index/detail_anggota/356a192b7913b04c54574d18c28d46e6395428ab
DEBUG - 2016-10-08 06:39:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 06:39:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 06:39:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
INFO - 2016-10-08 06:39:36 --> Database Driver Class Initialized
DEBUG - 2016-10-08 06:39:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_pinjaman.php
INFO - 2016-10-08 06:39:36 --> Database Driver Class Initialized
DEBUG - 2016-10-08 06:39:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_tabungan.php
DEBUG - 2016-10-08 06:39:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/profile_anggota.php
DEBUG - 2016-10-08 06:39:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 06:39:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 06:39:36 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:36 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:37 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:37 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:37 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:37 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:37 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:37 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:37 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:37 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:37 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:37 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:37 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:37 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:37 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:37 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:37 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:37 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:37 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:37 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:37 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:37 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:37 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:37 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:37 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:37 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:37 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:37 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:37 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:37 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:37 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:37 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:37 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:37 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:37 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:37 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:38 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:38 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:38 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:38 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:38 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:38 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:38 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:38 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:38 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:38 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:38 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:38 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:38 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:38 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:38 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:38 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:38 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:38 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:38 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:38 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:38 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:38 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:38 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:38 --> Database Driver Class Initialized
DEBUG - 2016-10-08 06:39:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 06:39:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 06:39:38 --> Final output sent to browser
INFO - 2016-10-08 06:39:39 --> Config Class Initialized
INFO - 2016-10-08 06:39:39 --> Hooks Class Initialized
DEBUG - 2016-10-08 06:39:39 --> Total execution time: 3.7110
DEBUG - 2016-10-08 06:39:39 --> UTF-8 Support Enabled
INFO - 2016-10-08 06:39:39 --> Utf8 Class Initialized
INFO - 2016-10-08 06:39:39 --> URI Class Initialized
INFO - 2016-10-08 06:39:39 --> Router Class Initialized
INFO - 2016-10-08 06:39:39 --> Output Class Initialized
INFO - 2016-10-08 06:39:39 --> Security Class Initialized
DEBUG - 2016-10-08 06:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 06:39:39 --> Input Class Initialized
INFO - 2016-10-08 06:39:39 --> Language Class Initialized
INFO - 2016-10-08 06:39:39 --> Language Class Initialized
INFO - 2016-10-08 06:39:39 --> Config Class Initialized
INFO - 2016-10-08 06:39:39 --> Loader Class Initialized
INFO - 2016-10-08 06:39:39 --> Helper loaded: url_helper
INFO - 2016-10-08 06:39:40 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 06:39:40 --> Controller Class Initialized
DEBUG - 2016-10-08 06:39:40 --> Index MX_Controller Initialized
INFO - 2016-10-08 06:39:40 --> Model Class Initialized
INFO - 2016-10-08 06:39:40 --> Model Class Initialized
ERROR - 2016-10-08 06:39:40 --> Unable to delete cache file for admin/index/detail_anggota/images/picture.jpg
DEBUG - 2016-10-08 06:39:40 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 06:39:40 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 06:39:40 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
ERROR - 2016-10-08 06:39:40 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 16
ERROR - 2016-10-08 06:39:40 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 19
ERROR - 2016-10-08 06:39:41 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 22
ERROR - 2016-10-08 06:39:41 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 38
INFO - 2016-10-08 06:39:41 --> Database Driver Class Initialized
DEBUG - 2016-10-08 06:39:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_pinjaman.php
ERROR - 2016-10-08 06:39:41 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 41
INFO - 2016-10-08 06:39:41 --> Database Driver Class Initialized
DEBUG - 2016-10-08 06:39:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_tabungan.php
DEBUG - 2016-10-08 06:39:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/profile_anggota.php
DEBUG - 2016-10-08 06:39:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 06:39:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 06:39:42 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:42 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:42 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:42 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:42 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:42 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:42 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:43 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:43 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:43 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:43 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:43 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:43 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:43 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:44 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:44 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:44 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:44 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:44 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:44 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:44 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:44 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:44 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:44 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:45 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:45 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:45 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:45 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:45 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:45 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:45 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:45 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:45 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:45 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:45 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:45 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:45 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:46 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:46 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:46 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:46 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:46 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:46 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:46 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:46 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:46 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:47 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:47 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:47 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:47 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:47 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:47 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:47 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:47 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:47 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:47 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:47 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:47 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:48 --> Database Driver Class Initialized
INFO - 2016-10-08 06:39:48 --> Database Driver Class Initialized
DEBUG - 2016-10-08 06:39:48 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 06:39:48 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 06:39:48 --> Final output sent to browser
DEBUG - 2016-10-08 06:39:48 --> Total execution time: 9.0864
INFO - 2016-10-08 06:41:40 --> Config Class Initialized
INFO - 2016-10-08 06:41:40 --> Hooks Class Initialized
DEBUG - 2016-10-08 06:41:40 --> UTF-8 Support Enabled
INFO - 2016-10-08 06:41:40 --> Utf8 Class Initialized
INFO - 2016-10-08 06:41:40 --> URI Class Initialized
INFO - 2016-10-08 06:41:40 --> Router Class Initialized
INFO - 2016-10-08 06:41:40 --> Output Class Initialized
INFO - 2016-10-08 06:41:40 --> Security Class Initialized
DEBUG - 2016-10-08 06:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 06:41:40 --> Input Class Initialized
INFO - 2016-10-08 06:41:40 --> Language Class Initialized
INFO - 2016-10-08 06:41:40 --> Language Class Initialized
INFO - 2016-10-08 06:41:41 --> Config Class Initialized
INFO - 2016-10-08 06:41:41 --> Loader Class Initialized
INFO - 2016-10-08 06:41:41 --> Helper loaded: url_helper
INFO - 2016-10-08 06:41:41 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 06:41:41 --> Controller Class Initialized
DEBUG - 2016-10-08 06:41:41 --> Index MX_Controller Initialized
INFO - 2016-10-08 06:41:41 --> Model Class Initialized
INFO - 2016-10-08 06:41:41 --> Model Class Initialized
ERROR - 2016-10-08 06:41:41 --> Unable to delete cache file for admin/index/detail_anggota/356a192b7913b04c54574d18c28d46e6395428ab
DEBUG - 2016-10-08 06:41:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 06:41:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 06:41:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
INFO - 2016-10-08 06:41:41 --> Database Driver Class Initialized
DEBUG - 2016-10-08 06:41:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_pinjaman.php
INFO - 2016-10-08 06:41:41 --> Database Driver Class Initialized
DEBUG - 2016-10-08 06:41:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_tabungan.php
DEBUG - 2016-10-08 06:41:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/profile_anggota.php
DEBUG - 2016-10-08 06:41:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 06:41:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 06:41:41 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:41 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:41 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:41 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:41 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:41 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:41 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:41 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:41 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:41 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:41 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:41 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:41 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:41 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:41 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:42 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:42 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:42 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:42 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:42 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:42 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:42 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:42 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:42 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:42 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:42 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:42 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:42 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:42 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:42 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:42 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:42 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:42 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:42 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:42 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:42 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:42 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:42 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:42 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:42 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:42 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:42 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:42 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:42 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:42 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:42 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:42 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:42 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:42 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:42 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:43 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:43 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:43 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:43 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:43 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:43 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:43 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:43 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:43 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:43 --> Database Driver Class Initialized
DEBUG - 2016-10-08 06:41:43 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 06:41:43 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 06:41:43 --> Final output sent to browser
DEBUG - 2016-10-08 06:41:43 --> Total execution time: 2.7130
INFO - 2016-10-08 06:41:43 --> Config Class Initialized
INFO - 2016-10-08 06:41:43 --> Hooks Class Initialized
DEBUG - 2016-10-08 06:41:43 --> UTF-8 Support Enabled
INFO - 2016-10-08 06:41:43 --> Utf8 Class Initialized
INFO - 2016-10-08 06:41:43 --> URI Class Initialized
INFO - 2016-10-08 06:41:43 --> Router Class Initialized
INFO - 2016-10-08 06:41:43 --> Output Class Initialized
INFO - 2016-10-08 06:41:43 --> Security Class Initialized
DEBUG - 2016-10-08 06:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 06:41:43 --> Input Class Initialized
INFO - 2016-10-08 06:41:43 --> Language Class Initialized
INFO - 2016-10-08 06:41:44 --> Language Class Initialized
INFO - 2016-10-08 06:41:44 --> Config Class Initialized
INFO - 2016-10-08 06:41:44 --> Loader Class Initialized
INFO - 2016-10-08 06:41:44 --> Helper loaded: url_helper
INFO - 2016-10-08 06:41:44 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 06:41:44 --> Controller Class Initialized
DEBUG - 2016-10-08 06:41:44 --> Index MX_Controller Initialized
INFO - 2016-10-08 06:41:44 --> Model Class Initialized
INFO - 2016-10-08 06:41:44 --> Model Class Initialized
ERROR - 2016-10-08 06:41:44 --> Unable to delete cache file for admin/index/detail_anggota/images/picture.jpg
DEBUG - 2016-10-08 06:41:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 06:41:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 06:41:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
ERROR - 2016-10-08 06:41:44 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 16
ERROR - 2016-10-08 06:41:44 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 19
ERROR - 2016-10-08 06:41:44 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 22
ERROR - 2016-10-08 06:41:44 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 38
INFO - 2016-10-08 06:41:44 --> Database Driver Class Initialized
DEBUG - 2016-10-08 06:41:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_pinjaman.php
ERROR - 2016-10-08 06:41:44 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 41
INFO - 2016-10-08 06:41:44 --> Database Driver Class Initialized
DEBUG - 2016-10-08 06:41:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_tabungan.php
DEBUG - 2016-10-08 06:41:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/profile_anggota.php
DEBUG - 2016-10-08 06:41:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 06:41:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 06:41:45 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:45 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:45 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:45 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:45 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:45 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:45 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:45 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:45 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:45 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:45 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:45 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:45 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:45 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:45 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:45 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:45 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:45 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:45 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:45 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:47 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:47 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:47 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:47 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:47 --> Database Driver Class Initialized
INFO - 2016-10-08 06:41:47 --> Database Driver Class Initialized
DEBUG - 2016-10-08 06:41:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 06:41:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 06:41:47 --> Final output sent to browser
DEBUG - 2016-10-08 06:41:47 --> Total execution time: 3.6378
INFO - 2016-10-08 06:43:00 --> Config Class Initialized
INFO - 2016-10-08 06:43:00 --> Hooks Class Initialized
DEBUG - 2016-10-08 06:43:00 --> UTF-8 Support Enabled
INFO - 2016-10-08 06:43:00 --> Utf8 Class Initialized
INFO - 2016-10-08 06:43:00 --> URI Class Initialized
INFO - 2016-10-08 06:43:00 --> Router Class Initialized
INFO - 2016-10-08 06:43:00 --> Output Class Initialized
INFO - 2016-10-08 06:43:00 --> Security Class Initialized
DEBUG - 2016-10-08 06:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 06:43:00 --> Input Class Initialized
INFO - 2016-10-08 06:43:00 --> Language Class Initialized
INFO - 2016-10-08 06:43:00 --> Language Class Initialized
INFO - 2016-10-08 06:43:00 --> Config Class Initialized
INFO - 2016-10-08 06:43:00 --> Loader Class Initialized
INFO - 2016-10-08 06:43:00 --> Helper loaded: url_helper
INFO - 2016-10-08 06:43:00 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 06:43:01 --> Controller Class Initialized
DEBUG - 2016-10-08 06:43:01 --> Index MX_Controller Initialized
INFO - 2016-10-08 06:43:01 --> Model Class Initialized
INFO - 2016-10-08 06:43:01 --> Model Class Initialized
ERROR - 2016-10-08 06:43:01 --> Unable to delete cache file for admin/index/detail_anggota/356a192b7913b04c54574d18c28d46e6395428ab
DEBUG - 2016-10-08 06:43:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 06:43:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 06:43:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
INFO - 2016-10-08 06:43:01 --> Database Driver Class Initialized
DEBUG - 2016-10-08 06:43:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_pinjaman.php
INFO - 2016-10-08 06:43:01 --> Database Driver Class Initialized
DEBUG - 2016-10-08 06:43:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_tabungan.php
DEBUG - 2016-10-08 06:43:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/profile_anggota.php
DEBUG - 2016-10-08 06:43:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 06:43:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 06:43:01 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:01 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:01 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:01 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:01 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:01 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:01 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:01 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:01 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:01 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:01 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:01 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:01 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:01 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:01 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:01 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:01 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:02 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:02 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:02 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:02 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:02 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:02 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:02 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:02 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:02 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:02 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:02 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:02 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:02 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:02 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:02 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:02 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:02 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:02 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:02 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:02 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:02 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:02 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:02 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:02 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:02 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:02 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:02 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:02 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:02 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:02 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:02 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:02 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:02 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:02 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:02 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:03 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:03 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:03 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:03 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:03 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:03 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:03 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:03 --> Database Driver Class Initialized
DEBUG - 2016-10-08 06:43:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 06:43:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 06:43:03 --> Final output sent to browser
DEBUG - 2016-10-08 06:43:03 --> Total execution time: 2.7848
INFO - 2016-10-08 06:43:03 --> Config Class Initialized
INFO - 2016-10-08 06:43:03 --> Hooks Class Initialized
DEBUG - 2016-10-08 06:43:03 --> UTF-8 Support Enabled
INFO - 2016-10-08 06:43:03 --> Utf8 Class Initialized
INFO - 2016-10-08 06:43:03 --> URI Class Initialized
INFO - 2016-10-08 06:43:03 --> Router Class Initialized
INFO - 2016-10-08 06:43:03 --> Output Class Initialized
INFO - 2016-10-08 06:43:03 --> Security Class Initialized
DEBUG - 2016-10-08 06:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 06:43:03 --> Input Class Initialized
INFO - 2016-10-08 06:43:03 --> Language Class Initialized
INFO - 2016-10-08 06:43:04 --> Language Class Initialized
INFO - 2016-10-08 06:43:04 --> Config Class Initialized
INFO - 2016-10-08 06:43:04 --> Loader Class Initialized
INFO - 2016-10-08 06:43:04 --> Helper loaded: url_helper
INFO - 2016-10-08 06:43:04 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 06:43:04 --> Controller Class Initialized
DEBUG - 2016-10-08 06:43:04 --> Index MX_Controller Initialized
INFO - 2016-10-08 06:43:04 --> Model Class Initialized
INFO - 2016-10-08 06:43:04 --> Model Class Initialized
ERROR - 2016-10-08 06:43:04 --> Unable to delete cache file for admin/index/detail_anggota/images/picture.jpg
DEBUG - 2016-10-08 06:43:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 06:43:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 06:43:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
ERROR - 2016-10-08 06:43:04 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 16
ERROR - 2016-10-08 06:43:04 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 19
ERROR - 2016-10-08 06:43:04 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 22
ERROR - 2016-10-08 06:43:04 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 38
INFO - 2016-10-08 06:43:04 --> Database Driver Class Initialized
DEBUG - 2016-10-08 06:43:05 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_pinjaman.php
ERROR - 2016-10-08 06:43:05 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 41
INFO - 2016-10-08 06:43:05 --> Database Driver Class Initialized
DEBUG - 2016-10-08 06:43:05 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_tabungan.php
DEBUG - 2016-10-08 06:43:05 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/profile_anggota.php
DEBUG - 2016-10-08 06:43:05 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 06:43:05 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 06:43:05 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:05 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:05 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:05 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:05 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:05 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:05 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:05 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:05 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:05 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:05 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:05 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:05 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:05 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:05 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:05 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:06 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:06 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:06 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:06 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:06 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:06 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:06 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:06 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:06 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:06 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:06 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:06 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:06 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:06 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:06 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:06 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:06 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:06 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:06 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:07 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:07 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:07 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:07 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:07 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:07 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:07 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:07 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:07 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:07 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:07 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:07 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:07 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:07 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:07 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:07 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:07 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:07 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:07 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:07 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:07 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:07 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:07 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:07 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:07 --> Database Driver Class Initialized
DEBUG - 2016-10-08 06:43:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 06:43:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 06:43:08 --> Final output sent to browser
DEBUG - 2016-10-08 06:43:08 --> Total execution time: 4.5703
INFO - 2016-10-08 06:43:10 --> Config Class Initialized
INFO - 2016-10-08 06:43:10 --> Hooks Class Initialized
DEBUG - 2016-10-08 06:43:10 --> UTF-8 Support Enabled
INFO - 2016-10-08 06:43:10 --> Utf8 Class Initialized
INFO - 2016-10-08 06:43:10 --> URI Class Initialized
INFO - 2016-10-08 06:43:10 --> Router Class Initialized
INFO - 2016-10-08 06:43:10 --> Output Class Initialized
INFO - 2016-10-08 06:43:10 --> Security Class Initialized
DEBUG - 2016-10-08 06:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 06:43:10 --> Input Class Initialized
INFO - 2016-10-08 06:43:10 --> Language Class Initialized
INFO - 2016-10-08 06:43:10 --> Language Class Initialized
INFO - 2016-10-08 06:43:10 --> Config Class Initialized
INFO - 2016-10-08 06:43:10 --> Loader Class Initialized
INFO - 2016-10-08 06:43:10 --> Helper loaded: url_helper
INFO - 2016-10-08 06:43:10 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 06:43:10 --> Controller Class Initialized
DEBUG - 2016-10-08 06:43:10 --> Index MX_Controller Initialized
INFO - 2016-10-08 06:43:10 --> Model Class Initialized
INFO - 2016-10-08 06:43:10 --> Model Class Initialized
ERROR - 2016-10-08 06:43:10 --> Unable to delete cache file for admin/index/getRaportAngsuran/356a192b7913b04c54574d18c28d46e6395428ab
DEBUG - 2016-10-08 06:43:10 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/raport_angsuran.php
INFO - 2016-10-08 06:43:10 --> Final output sent to browser
DEBUG - 2016-10-08 06:43:10 --> Total execution time: 0.7566
INFO - 2016-10-08 06:43:23 --> Config Class Initialized
INFO - 2016-10-08 06:43:23 --> Hooks Class Initialized
DEBUG - 2016-10-08 06:43:23 --> UTF-8 Support Enabled
INFO - 2016-10-08 06:43:23 --> Utf8 Class Initialized
INFO - 2016-10-08 06:43:23 --> URI Class Initialized
INFO - 2016-10-08 06:43:24 --> Router Class Initialized
INFO - 2016-10-08 06:43:24 --> Output Class Initialized
INFO - 2016-10-08 06:43:24 --> Security Class Initialized
DEBUG - 2016-10-08 06:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 06:43:24 --> Input Class Initialized
INFO - 2016-10-08 06:43:24 --> Language Class Initialized
INFO - 2016-10-08 06:43:24 --> Language Class Initialized
INFO - 2016-10-08 06:43:24 --> Config Class Initialized
INFO - 2016-10-08 06:43:24 --> Loader Class Initialized
INFO - 2016-10-08 06:43:24 --> Helper loaded: url_helper
INFO - 2016-10-08 06:43:24 --> Database Driver Class Initialized
INFO - 2016-10-08 06:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 06:43:24 --> Controller Class Initialized
DEBUG - 2016-10-08 06:43:24 --> Index MX_Controller Initialized
INFO - 2016-10-08 06:43:24 --> Model Class Initialized
INFO - 2016-10-08 06:43:24 --> Model Class Initialized
ERROR - 2016-10-08 06:43:24 --> Unable to delete cache file for admin/index/getRaportAngsuran/356a192b7913b04c54574d18c28d46e6395428ab
DEBUG - 2016-10-08 06:43:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/raport_angsuran.php
INFO - 2016-10-08 06:43:24 --> Final output sent to browser
DEBUG - 2016-10-08 06:43:24 --> Total execution time: 0.8607
INFO - 2016-10-08 06:44:20 --> Config Class Initialized
INFO - 2016-10-08 06:44:20 --> Hooks Class Initialized
DEBUG - 2016-10-08 06:44:20 --> UTF-8 Support Enabled
INFO - 2016-10-08 06:44:20 --> Utf8 Class Initialized
INFO - 2016-10-08 06:44:20 --> URI Class Initialized
INFO - 2016-10-08 06:44:20 --> Router Class Initialized
INFO - 2016-10-08 06:44:20 --> Output Class Initialized
INFO - 2016-10-08 06:44:20 --> Security Class Initialized
DEBUG - 2016-10-08 06:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 06:44:20 --> Input Class Initialized
INFO - 2016-10-08 06:44:20 --> Language Class Initialized
INFO - 2016-10-08 06:44:20 --> Language Class Initialized
INFO - 2016-10-08 06:44:20 --> Config Class Initialized
INFO - 2016-10-08 06:44:20 --> Loader Class Initialized
INFO - 2016-10-08 06:44:20 --> Helper loaded: url_helper
INFO - 2016-10-08 06:44:20 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 06:44:20 --> Controller Class Initialized
DEBUG - 2016-10-08 06:44:21 --> Index MX_Controller Initialized
INFO - 2016-10-08 06:44:21 --> Model Class Initialized
INFO - 2016-10-08 06:44:21 --> Model Class Initialized
ERROR - 2016-10-08 06:44:21 --> Unable to delete cache file for admin/index/bayar_angsuran
DEBUG - 2016-10-08 06:44:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 06:44:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 06:44:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 06:44:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_bayar_angsuran.php
DEBUG - 2016-10-08 06:44:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 06:44:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 06:44:21 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:21 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:21 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:21 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:21 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:21 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:21 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:21 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:21 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:21 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:21 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:21 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:21 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:21 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:21 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:21 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:21 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:22 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:22 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:22 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:22 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:22 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:22 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:22 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:22 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:22 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:22 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:22 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:22 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:22 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:22 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:22 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:22 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:22 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:22 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:22 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:22 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:22 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:22 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:22 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:22 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:22 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:22 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:22 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:22 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:22 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:22 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:22 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:22 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:22 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:23 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:23 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:23 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:23 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:23 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:23 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:23 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:23 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:23 --> Database Driver Class Initialized
DEBUG - 2016-10-08 06:44:23 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 06:44:23 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 06:44:23 --> Final output sent to browser
DEBUG - 2016-10-08 06:44:23 --> Total execution time: 2.9302
INFO - 2016-10-08 06:44:27 --> Config Class Initialized
INFO - 2016-10-08 06:44:27 --> Hooks Class Initialized
DEBUG - 2016-10-08 06:44:27 --> UTF-8 Support Enabled
INFO - 2016-10-08 06:44:27 --> Utf8 Class Initialized
INFO - 2016-10-08 06:44:27 --> URI Class Initialized
INFO - 2016-10-08 06:44:27 --> Router Class Initialized
INFO - 2016-10-08 06:44:27 --> Output Class Initialized
INFO - 2016-10-08 06:44:28 --> Security Class Initialized
DEBUG - 2016-10-08 06:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 06:44:28 --> Input Class Initialized
INFO - 2016-10-08 06:44:28 --> Language Class Initialized
INFO - 2016-10-08 06:44:28 --> Language Class Initialized
INFO - 2016-10-08 06:44:28 --> Config Class Initialized
INFO - 2016-10-08 06:44:28 --> Loader Class Initialized
INFO - 2016-10-08 06:44:28 --> Helper loaded: url_helper
INFO - 2016-10-08 06:44:28 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 06:44:28 --> Controller Class Initialized
DEBUG - 2016-10-08 06:44:28 --> Index MX_Controller Initialized
INFO - 2016-10-08 06:44:28 --> Model Class Initialized
INFO - 2016-10-08 06:44:28 --> Model Class Initialized
ERROR - 2016-10-08 06:44:28 --> Unable to delete cache file for admin/index/getDetailAngsuran
INFO - 2016-10-08 06:44:28 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:28 --> Final output sent to browser
DEBUG - 2016-10-08 06:44:28 --> Total execution time: 0.7348
INFO - 2016-10-08 06:44:36 --> Config Class Initialized
INFO - 2016-10-08 06:44:36 --> Hooks Class Initialized
DEBUG - 2016-10-08 06:44:36 --> UTF-8 Support Enabled
INFO - 2016-10-08 06:44:36 --> Utf8 Class Initialized
INFO - 2016-10-08 06:44:36 --> URI Class Initialized
INFO - 2016-10-08 06:44:36 --> Router Class Initialized
INFO - 2016-10-08 06:44:36 --> Output Class Initialized
INFO - 2016-10-08 06:44:36 --> Security Class Initialized
DEBUG - 2016-10-08 06:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 06:44:36 --> Input Class Initialized
INFO - 2016-10-08 06:44:36 --> Language Class Initialized
INFO - 2016-10-08 06:44:36 --> Language Class Initialized
INFO - 2016-10-08 06:44:36 --> Config Class Initialized
INFO - 2016-10-08 06:44:36 --> Loader Class Initialized
INFO - 2016-10-08 06:44:36 --> Helper loaded: url_helper
INFO - 2016-10-08 06:44:36 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 06:44:36 --> Controller Class Initialized
DEBUG - 2016-10-08 06:44:36 --> Index MX_Controller Initialized
INFO - 2016-10-08 06:44:36 --> Model Class Initialized
INFO - 2016-10-08 06:44:36 --> Model Class Initialized
ERROR - 2016-10-08 06:44:36 --> Unable to delete cache file for admin/index/do_bayar
INFO - 2016-10-08 06:44:37 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:37 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:37 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:37 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:37 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:37 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:37 --> Final output sent to browser
DEBUG - 2016-10-08 06:44:37 --> Total execution time: 1.2595
INFO - 2016-10-08 06:44:40 --> Config Class Initialized
INFO - 2016-10-08 06:44:40 --> Hooks Class Initialized
DEBUG - 2016-10-08 06:44:40 --> UTF-8 Support Enabled
INFO - 2016-10-08 06:44:40 --> Utf8 Class Initialized
INFO - 2016-10-08 06:44:40 --> URI Class Initialized
INFO - 2016-10-08 06:44:40 --> Router Class Initialized
INFO - 2016-10-08 06:44:40 --> Output Class Initialized
INFO - 2016-10-08 06:44:40 --> Security Class Initialized
DEBUG - 2016-10-08 06:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 06:44:40 --> Input Class Initialized
INFO - 2016-10-08 06:44:40 --> Language Class Initialized
INFO - 2016-10-08 06:44:40 --> Language Class Initialized
INFO - 2016-10-08 06:44:40 --> Config Class Initialized
INFO - 2016-10-08 06:44:40 --> Loader Class Initialized
INFO - 2016-10-08 06:44:40 --> Helper loaded: url_helper
INFO - 2016-10-08 06:44:40 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 06:44:40 --> Controller Class Initialized
DEBUG - 2016-10-08 06:44:40 --> Index MX_Controller Initialized
INFO - 2016-10-08 06:44:40 --> Model Class Initialized
INFO - 2016-10-08 06:44:40 --> Model Class Initialized
ERROR - 2016-10-08 06:44:40 --> Unable to delete cache file for admin/index/getDetailAngsuran
INFO - 2016-10-08 06:44:40 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:40 --> Final output sent to browser
DEBUG - 2016-10-08 06:44:40 --> Total execution time: 0.7310
INFO - 2016-10-08 06:44:42 --> Config Class Initialized
INFO - 2016-10-08 06:44:42 --> Hooks Class Initialized
DEBUG - 2016-10-08 06:44:42 --> UTF-8 Support Enabled
INFO - 2016-10-08 06:44:42 --> Utf8 Class Initialized
INFO - 2016-10-08 06:44:42 --> URI Class Initialized
INFO - 2016-10-08 06:44:42 --> Router Class Initialized
INFO - 2016-10-08 06:44:42 --> Output Class Initialized
INFO - 2016-10-08 06:44:42 --> Security Class Initialized
DEBUG - 2016-10-08 06:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 06:44:42 --> Input Class Initialized
INFO - 2016-10-08 06:44:42 --> Language Class Initialized
INFO - 2016-10-08 06:44:42 --> Language Class Initialized
INFO - 2016-10-08 06:44:42 --> Config Class Initialized
INFO - 2016-10-08 06:44:42 --> Loader Class Initialized
INFO - 2016-10-08 06:44:42 --> Helper loaded: url_helper
INFO - 2016-10-08 06:44:42 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 06:44:42 --> Controller Class Initialized
DEBUG - 2016-10-08 06:44:42 --> Index MX_Controller Initialized
INFO - 2016-10-08 06:44:42 --> Model Class Initialized
INFO - 2016-10-08 06:44:42 --> Model Class Initialized
ERROR - 2016-10-08 06:44:42 --> Unable to delete cache file for admin/index/do_bayar
INFO - 2016-10-08 06:44:42 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:42 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:42 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:42 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:43 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:43 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:43 --> Final output sent to browser
DEBUG - 2016-10-08 06:44:43 --> Total execution time: 1.1116
INFO - 2016-10-08 06:44:43 --> Config Class Initialized
INFO - 2016-10-08 06:44:43 --> Hooks Class Initialized
DEBUG - 2016-10-08 06:44:44 --> UTF-8 Support Enabled
INFO - 2016-10-08 06:44:44 --> Utf8 Class Initialized
INFO - 2016-10-08 06:44:44 --> URI Class Initialized
INFO - 2016-10-08 06:44:44 --> Router Class Initialized
INFO - 2016-10-08 06:44:44 --> Output Class Initialized
INFO - 2016-10-08 06:44:44 --> Security Class Initialized
DEBUG - 2016-10-08 06:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 06:44:44 --> Input Class Initialized
INFO - 2016-10-08 06:44:44 --> Language Class Initialized
INFO - 2016-10-08 06:44:44 --> Language Class Initialized
INFO - 2016-10-08 06:44:44 --> Config Class Initialized
INFO - 2016-10-08 06:44:44 --> Loader Class Initialized
INFO - 2016-10-08 06:44:44 --> Helper loaded: url_helper
INFO - 2016-10-08 06:44:44 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 06:44:44 --> Controller Class Initialized
DEBUG - 2016-10-08 06:44:44 --> Index MX_Controller Initialized
INFO - 2016-10-08 06:44:44 --> Model Class Initialized
INFO - 2016-10-08 06:44:44 --> Model Class Initialized
ERROR - 2016-10-08 06:44:44 --> Unable to delete cache file for admin/index/getDetailAngsuran
INFO - 2016-10-08 06:44:44 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:44 --> Final output sent to browser
DEBUG - 2016-10-08 06:44:44 --> Total execution time: 0.7627
INFO - 2016-10-08 06:44:45 --> Config Class Initialized
INFO - 2016-10-08 06:44:45 --> Hooks Class Initialized
DEBUG - 2016-10-08 06:44:45 --> UTF-8 Support Enabled
INFO - 2016-10-08 06:44:45 --> Utf8 Class Initialized
INFO - 2016-10-08 06:44:45 --> URI Class Initialized
INFO - 2016-10-08 06:44:45 --> Router Class Initialized
INFO - 2016-10-08 06:44:45 --> Output Class Initialized
INFO - 2016-10-08 06:44:45 --> Security Class Initialized
DEBUG - 2016-10-08 06:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 06:44:45 --> Input Class Initialized
INFO - 2016-10-08 06:44:45 --> Language Class Initialized
INFO - 2016-10-08 06:44:45 --> Language Class Initialized
INFO - 2016-10-08 06:44:45 --> Config Class Initialized
INFO - 2016-10-08 06:44:45 --> Loader Class Initialized
INFO - 2016-10-08 06:44:45 --> Helper loaded: url_helper
INFO - 2016-10-08 06:44:45 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 06:44:45 --> Controller Class Initialized
DEBUG - 2016-10-08 06:44:45 --> Index MX_Controller Initialized
INFO - 2016-10-08 06:44:45 --> Model Class Initialized
INFO - 2016-10-08 06:44:45 --> Model Class Initialized
ERROR - 2016-10-08 06:44:45 --> Unable to delete cache file for admin/index/do_bayar
INFO - 2016-10-08 06:44:46 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:46 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:46 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:46 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:46 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:46 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:46 --> Final output sent to browser
DEBUG - 2016-10-08 06:44:46 --> Total execution time: 0.9803
INFO - 2016-10-08 06:44:47 --> Config Class Initialized
INFO - 2016-10-08 06:44:47 --> Hooks Class Initialized
DEBUG - 2016-10-08 06:44:47 --> UTF-8 Support Enabled
INFO - 2016-10-08 06:44:47 --> Utf8 Class Initialized
INFO - 2016-10-08 06:44:47 --> URI Class Initialized
INFO - 2016-10-08 06:44:47 --> Router Class Initialized
INFO - 2016-10-08 06:44:47 --> Output Class Initialized
INFO - 2016-10-08 06:44:47 --> Security Class Initialized
DEBUG - 2016-10-08 06:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 06:44:47 --> Input Class Initialized
INFO - 2016-10-08 06:44:47 --> Language Class Initialized
INFO - 2016-10-08 06:44:47 --> Language Class Initialized
INFO - 2016-10-08 06:44:47 --> Config Class Initialized
INFO - 2016-10-08 06:44:47 --> Loader Class Initialized
INFO - 2016-10-08 06:44:47 --> Helper loaded: url_helper
INFO - 2016-10-08 06:44:47 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 06:44:47 --> Controller Class Initialized
DEBUG - 2016-10-08 06:44:47 --> Index MX_Controller Initialized
INFO - 2016-10-08 06:44:47 --> Model Class Initialized
INFO - 2016-10-08 06:44:47 --> Model Class Initialized
ERROR - 2016-10-08 06:44:47 --> Unable to delete cache file for admin/index/getDetailAngsuran
INFO - 2016-10-08 06:44:47 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:47 --> Final output sent to browser
DEBUG - 2016-10-08 06:44:47 --> Total execution time: 0.7127
INFO - 2016-10-08 06:44:48 --> Config Class Initialized
INFO - 2016-10-08 06:44:48 --> Hooks Class Initialized
DEBUG - 2016-10-08 06:44:48 --> UTF-8 Support Enabled
INFO - 2016-10-08 06:44:48 --> Utf8 Class Initialized
INFO - 2016-10-08 06:44:48 --> URI Class Initialized
INFO - 2016-10-08 06:44:48 --> Router Class Initialized
INFO - 2016-10-08 06:44:48 --> Output Class Initialized
INFO - 2016-10-08 06:44:48 --> Security Class Initialized
DEBUG - 2016-10-08 06:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 06:44:49 --> Input Class Initialized
INFO - 2016-10-08 06:44:49 --> Language Class Initialized
INFO - 2016-10-08 06:44:49 --> Language Class Initialized
INFO - 2016-10-08 06:44:49 --> Config Class Initialized
INFO - 2016-10-08 06:44:49 --> Loader Class Initialized
INFO - 2016-10-08 06:44:49 --> Helper loaded: url_helper
INFO - 2016-10-08 06:44:49 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 06:44:49 --> Controller Class Initialized
DEBUG - 2016-10-08 06:44:49 --> Index MX_Controller Initialized
INFO - 2016-10-08 06:44:49 --> Model Class Initialized
INFO - 2016-10-08 06:44:49 --> Model Class Initialized
ERROR - 2016-10-08 06:44:49 --> Unable to delete cache file for admin/index/do_bayar
INFO - 2016-10-08 06:44:49 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:49 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:49 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:49 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:49 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:49 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:49 --> Final output sent to browser
DEBUG - 2016-10-08 06:44:49 --> Total execution time: 0.9947
INFO - 2016-10-08 06:44:50 --> Config Class Initialized
INFO - 2016-10-08 06:44:50 --> Hooks Class Initialized
DEBUG - 2016-10-08 06:44:50 --> UTF-8 Support Enabled
INFO - 2016-10-08 06:44:50 --> Utf8 Class Initialized
INFO - 2016-10-08 06:44:50 --> URI Class Initialized
INFO - 2016-10-08 06:44:50 --> Router Class Initialized
INFO - 2016-10-08 06:44:50 --> Output Class Initialized
INFO - 2016-10-08 06:44:50 --> Security Class Initialized
DEBUG - 2016-10-08 06:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 06:44:50 --> Input Class Initialized
INFO - 2016-10-08 06:44:50 --> Language Class Initialized
INFO - 2016-10-08 06:44:50 --> Language Class Initialized
INFO - 2016-10-08 06:44:50 --> Config Class Initialized
INFO - 2016-10-08 06:44:50 --> Loader Class Initialized
INFO - 2016-10-08 06:44:50 --> Helper loaded: url_helper
INFO - 2016-10-08 06:44:50 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 06:44:50 --> Controller Class Initialized
DEBUG - 2016-10-08 06:44:50 --> Index MX_Controller Initialized
INFO - 2016-10-08 06:44:50 --> Model Class Initialized
INFO - 2016-10-08 06:44:51 --> Model Class Initialized
ERROR - 2016-10-08 06:44:51 --> Unable to delete cache file for admin/index/getDetailAngsuran
INFO - 2016-10-08 06:44:51 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:51 --> Final output sent to browser
DEBUG - 2016-10-08 06:44:51 --> Total execution time: 0.6615
INFO - 2016-10-08 06:44:51 --> Config Class Initialized
INFO - 2016-10-08 06:44:52 --> Hooks Class Initialized
DEBUG - 2016-10-08 06:44:52 --> UTF-8 Support Enabled
INFO - 2016-10-08 06:44:52 --> Utf8 Class Initialized
INFO - 2016-10-08 06:44:52 --> URI Class Initialized
INFO - 2016-10-08 06:44:52 --> Router Class Initialized
INFO - 2016-10-08 06:44:52 --> Output Class Initialized
INFO - 2016-10-08 06:44:52 --> Security Class Initialized
DEBUG - 2016-10-08 06:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 06:44:52 --> Input Class Initialized
INFO - 2016-10-08 06:44:52 --> Language Class Initialized
INFO - 2016-10-08 06:44:52 --> Language Class Initialized
INFO - 2016-10-08 06:44:52 --> Config Class Initialized
INFO - 2016-10-08 06:44:52 --> Loader Class Initialized
INFO - 2016-10-08 06:44:52 --> Helper loaded: url_helper
INFO - 2016-10-08 06:44:52 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 06:44:52 --> Controller Class Initialized
DEBUG - 2016-10-08 06:44:52 --> Index MX_Controller Initialized
INFO - 2016-10-08 06:44:52 --> Model Class Initialized
INFO - 2016-10-08 06:44:52 --> Model Class Initialized
ERROR - 2016-10-08 06:44:52 --> Unable to delete cache file for admin/index/do_bayar
INFO - 2016-10-08 06:44:52 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:52 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:53 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:53 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:53 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:53 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:53 --> Final output sent to browser
DEBUG - 2016-10-08 06:44:53 --> Total execution time: 1.2551
INFO - 2016-10-08 06:44:53 --> Config Class Initialized
INFO - 2016-10-08 06:44:53 --> Hooks Class Initialized
DEBUG - 2016-10-08 06:44:53 --> UTF-8 Support Enabled
INFO - 2016-10-08 06:44:54 --> Utf8 Class Initialized
INFO - 2016-10-08 06:44:54 --> URI Class Initialized
INFO - 2016-10-08 06:44:54 --> Router Class Initialized
INFO - 2016-10-08 06:44:54 --> Output Class Initialized
INFO - 2016-10-08 06:44:54 --> Security Class Initialized
DEBUG - 2016-10-08 06:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 06:44:54 --> Input Class Initialized
INFO - 2016-10-08 06:44:54 --> Language Class Initialized
INFO - 2016-10-08 06:44:54 --> Language Class Initialized
INFO - 2016-10-08 06:44:54 --> Config Class Initialized
INFO - 2016-10-08 06:44:54 --> Loader Class Initialized
INFO - 2016-10-08 06:44:54 --> Helper loaded: url_helper
INFO - 2016-10-08 06:44:54 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 06:44:54 --> Controller Class Initialized
DEBUG - 2016-10-08 06:44:54 --> Index MX_Controller Initialized
INFO - 2016-10-08 06:44:54 --> Model Class Initialized
INFO - 2016-10-08 06:44:54 --> Model Class Initialized
ERROR - 2016-10-08 06:44:54 --> Unable to delete cache file for admin/index/getDetailAngsuran
INFO - 2016-10-08 06:44:54 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:54 --> Final output sent to browser
DEBUG - 2016-10-08 06:44:54 --> Total execution time: 0.6802
INFO - 2016-10-08 06:44:55 --> Config Class Initialized
INFO - 2016-10-08 06:44:55 --> Hooks Class Initialized
DEBUG - 2016-10-08 06:44:55 --> UTF-8 Support Enabled
INFO - 2016-10-08 06:44:55 --> Utf8 Class Initialized
INFO - 2016-10-08 06:44:55 --> URI Class Initialized
INFO - 2016-10-08 06:44:55 --> Router Class Initialized
INFO - 2016-10-08 06:44:55 --> Output Class Initialized
INFO - 2016-10-08 06:44:55 --> Security Class Initialized
DEBUG - 2016-10-08 06:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 06:44:55 --> Input Class Initialized
INFO - 2016-10-08 06:44:56 --> Language Class Initialized
INFO - 2016-10-08 06:44:56 --> Language Class Initialized
INFO - 2016-10-08 06:44:56 --> Config Class Initialized
INFO - 2016-10-08 06:44:56 --> Loader Class Initialized
INFO - 2016-10-08 06:44:56 --> Helper loaded: url_helper
INFO - 2016-10-08 06:44:56 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 06:44:56 --> Controller Class Initialized
DEBUG - 2016-10-08 06:44:56 --> Index MX_Controller Initialized
INFO - 2016-10-08 06:44:56 --> Model Class Initialized
INFO - 2016-10-08 06:44:56 --> Model Class Initialized
ERROR - 2016-10-08 06:44:56 --> Unable to delete cache file for admin/index/do_bayar
INFO - 2016-10-08 06:44:56 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:56 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:56 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:56 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:56 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:56 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:56 --> Final output sent to browser
DEBUG - 2016-10-08 06:44:56 --> Total execution time: 1.0794
INFO - 2016-10-08 06:44:57 --> Config Class Initialized
INFO - 2016-10-08 06:44:57 --> Hooks Class Initialized
DEBUG - 2016-10-08 06:44:57 --> UTF-8 Support Enabled
INFO - 2016-10-08 06:44:57 --> Utf8 Class Initialized
INFO - 2016-10-08 06:44:57 --> URI Class Initialized
INFO - 2016-10-08 06:44:57 --> Router Class Initialized
INFO - 2016-10-08 06:44:57 --> Output Class Initialized
INFO - 2016-10-08 06:44:57 --> Security Class Initialized
DEBUG - 2016-10-08 06:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 06:44:57 --> Input Class Initialized
INFO - 2016-10-08 06:44:57 --> Language Class Initialized
INFO - 2016-10-08 06:44:57 --> Language Class Initialized
INFO - 2016-10-08 06:44:58 --> Config Class Initialized
INFO - 2016-10-08 06:44:58 --> Loader Class Initialized
INFO - 2016-10-08 06:44:58 --> Helper loaded: url_helper
INFO - 2016-10-08 06:44:58 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 06:44:58 --> Controller Class Initialized
DEBUG - 2016-10-08 06:44:58 --> Index MX_Controller Initialized
INFO - 2016-10-08 06:44:58 --> Model Class Initialized
INFO - 2016-10-08 06:44:58 --> Model Class Initialized
ERROR - 2016-10-08 06:44:58 --> Unable to delete cache file for admin/index/getDetailAngsuran
INFO - 2016-10-08 06:44:58 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:58 --> Final output sent to browser
DEBUG - 2016-10-08 06:44:58 --> Total execution time: 0.6263
INFO - 2016-10-08 06:44:59 --> Config Class Initialized
INFO - 2016-10-08 06:44:59 --> Hooks Class Initialized
DEBUG - 2016-10-08 06:44:59 --> UTF-8 Support Enabled
INFO - 2016-10-08 06:44:59 --> Utf8 Class Initialized
INFO - 2016-10-08 06:44:59 --> URI Class Initialized
INFO - 2016-10-08 06:44:59 --> Router Class Initialized
INFO - 2016-10-08 06:44:59 --> Output Class Initialized
INFO - 2016-10-08 06:44:59 --> Security Class Initialized
DEBUG - 2016-10-08 06:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 06:44:59 --> Input Class Initialized
INFO - 2016-10-08 06:44:59 --> Language Class Initialized
INFO - 2016-10-08 06:44:59 --> Language Class Initialized
INFO - 2016-10-08 06:44:59 --> Config Class Initialized
INFO - 2016-10-08 06:44:59 --> Loader Class Initialized
INFO - 2016-10-08 06:44:59 --> Helper loaded: url_helper
INFO - 2016-10-08 06:44:59 --> Database Driver Class Initialized
INFO - 2016-10-08 06:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 06:44:59 --> Controller Class Initialized
DEBUG - 2016-10-08 06:44:59 --> Index MX_Controller Initialized
INFO - 2016-10-08 06:44:59 --> Model Class Initialized
INFO - 2016-10-08 06:44:59 --> Model Class Initialized
ERROR - 2016-10-08 06:44:59 --> Unable to delete cache file for admin/index/do_bayar
INFO - 2016-10-08 06:45:00 --> Database Driver Class Initialized
INFO - 2016-10-08 06:45:00 --> Database Driver Class Initialized
INFO - 2016-10-08 06:45:00 --> Database Driver Class Initialized
INFO - 2016-10-08 06:45:00 --> Database Driver Class Initialized
INFO - 2016-10-08 06:45:00 --> Database Driver Class Initialized
INFO - 2016-10-08 06:45:00 --> Database Driver Class Initialized
INFO - 2016-10-08 06:45:00 --> Final output sent to browser
DEBUG - 2016-10-08 06:45:00 --> Total execution time: 1.2174
INFO - 2016-10-08 06:45:01 --> Config Class Initialized
INFO - 2016-10-08 06:45:01 --> Hooks Class Initialized
DEBUG - 2016-10-08 06:45:01 --> UTF-8 Support Enabled
INFO - 2016-10-08 06:45:01 --> Utf8 Class Initialized
INFO - 2016-10-08 06:45:01 --> URI Class Initialized
INFO - 2016-10-08 06:45:01 --> Router Class Initialized
INFO - 2016-10-08 06:45:01 --> Output Class Initialized
INFO - 2016-10-08 06:45:01 --> Security Class Initialized
DEBUG - 2016-10-08 06:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 06:45:01 --> Input Class Initialized
INFO - 2016-10-08 06:45:01 --> Language Class Initialized
INFO - 2016-10-08 06:45:01 --> Language Class Initialized
INFO - 2016-10-08 06:45:01 --> Config Class Initialized
INFO - 2016-10-08 06:45:01 --> Loader Class Initialized
INFO - 2016-10-08 06:45:01 --> Helper loaded: url_helper
INFO - 2016-10-08 06:45:01 --> Database Driver Class Initialized
INFO - 2016-10-08 06:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 06:45:01 --> Controller Class Initialized
DEBUG - 2016-10-08 06:45:02 --> Index MX_Controller Initialized
INFO - 2016-10-08 06:45:02 --> Model Class Initialized
INFO - 2016-10-08 06:45:02 --> Model Class Initialized
ERROR - 2016-10-08 06:45:02 --> Unable to delete cache file for admin/index/getDetailAngsuran
INFO - 2016-10-08 06:45:02 --> Database Driver Class Initialized
INFO - 2016-10-08 06:45:02 --> Final output sent to browser
DEBUG - 2016-10-08 06:45:02 --> Total execution time: 0.6929
INFO - 2016-10-08 06:45:06 --> Config Class Initialized
INFO - 2016-10-08 06:45:06 --> Hooks Class Initialized
DEBUG - 2016-10-08 06:45:06 --> UTF-8 Support Enabled
INFO - 2016-10-08 06:45:06 --> Utf8 Class Initialized
INFO - 2016-10-08 06:45:06 --> URI Class Initialized
INFO - 2016-10-08 06:45:06 --> Router Class Initialized
INFO - 2016-10-08 06:45:06 --> Output Class Initialized
INFO - 2016-10-08 06:45:06 --> Security Class Initialized
DEBUG - 2016-10-08 06:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 06:45:06 --> Input Class Initialized
INFO - 2016-10-08 06:45:06 --> Language Class Initialized
INFO - 2016-10-08 06:45:06 --> Language Class Initialized
INFO - 2016-10-08 06:45:06 --> Config Class Initialized
INFO - 2016-10-08 06:45:06 --> Loader Class Initialized
INFO - 2016-10-08 06:45:07 --> Helper loaded: url_helper
INFO - 2016-10-08 06:45:07 --> Database Driver Class Initialized
INFO - 2016-10-08 06:45:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 06:45:07 --> Controller Class Initialized
DEBUG - 2016-10-08 06:45:07 --> Index MX_Controller Initialized
INFO - 2016-10-08 06:45:07 --> Model Class Initialized
INFO - 2016-10-08 06:45:07 --> Model Class Initialized
ERROR - 2016-10-08 06:45:07 --> Unable to delete cache file for admin/index/do_bayar
INFO - 2016-10-08 06:45:07 --> Database Driver Class Initialized
INFO - 2016-10-08 06:45:07 --> Database Driver Class Initialized
INFO - 2016-10-08 06:45:07 --> Database Driver Class Initialized
INFO - 2016-10-08 06:45:07 --> Database Driver Class Initialized
INFO - 2016-10-08 06:45:07 --> Database Driver Class Initialized
INFO - 2016-10-08 06:45:07 --> Database Driver Class Initialized
INFO - 2016-10-08 06:45:07 --> Final output sent to browser
DEBUG - 2016-10-08 06:45:07 --> Total execution time: 1.0311
INFO - 2016-10-08 06:45:08 --> Config Class Initialized
INFO - 2016-10-08 06:45:08 --> Hooks Class Initialized
DEBUG - 2016-10-08 06:45:08 --> UTF-8 Support Enabled
INFO - 2016-10-08 06:45:08 --> Utf8 Class Initialized
INFO - 2016-10-08 06:45:08 --> URI Class Initialized
INFO - 2016-10-08 06:45:08 --> Router Class Initialized
INFO - 2016-10-08 06:45:08 --> Output Class Initialized
INFO - 2016-10-08 06:45:08 --> Security Class Initialized
DEBUG - 2016-10-08 06:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 06:45:08 --> Input Class Initialized
INFO - 2016-10-08 06:45:08 --> Language Class Initialized
INFO - 2016-10-08 06:45:08 --> Language Class Initialized
INFO - 2016-10-08 06:45:08 --> Config Class Initialized
INFO - 2016-10-08 06:45:08 --> Loader Class Initialized
INFO - 2016-10-08 06:45:08 --> Helper loaded: url_helper
INFO - 2016-10-08 06:45:08 --> Database Driver Class Initialized
INFO - 2016-10-08 06:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 06:45:08 --> Controller Class Initialized
DEBUG - 2016-10-08 06:45:08 --> Index MX_Controller Initialized
INFO - 2016-10-08 06:45:08 --> Model Class Initialized
INFO - 2016-10-08 06:45:08 --> Model Class Initialized
ERROR - 2016-10-08 06:45:08 --> Unable to delete cache file for admin/index/getDetailAngsuran
INFO - 2016-10-08 06:45:08 --> Database Driver Class Initialized
INFO - 2016-10-08 06:45:09 --> Final output sent to browser
DEBUG - 2016-10-08 06:45:09 --> Total execution time: 0.6698
INFO - 2016-10-08 06:45:10 --> Config Class Initialized
INFO - 2016-10-08 06:45:10 --> Hooks Class Initialized
DEBUG - 2016-10-08 06:45:10 --> UTF-8 Support Enabled
INFO - 2016-10-08 06:45:10 --> Utf8 Class Initialized
INFO - 2016-10-08 06:45:10 --> URI Class Initialized
INFO - 2016-10-08 06:45:10 --> Router Class Initialized
INFO - 2016-10-08 06:45:10 --> Output Class Initialized
INFO - 2016-10-08 06:45:10 --> Security Class Initialized
DEBUG - 2016-10-08 06:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 06:45:10 --> Input Class Initialized
INFO - 2016-10-08 06:45:10 --> Language Class Initialized
INFO - 2016-10-08 06:45:10 --> Language Class Initialized
INFO - 2016-10-08 06:45:10 --> Config Class Initialized
INFO - 2016-10-08 06:45:10 --> Loader Class Initialized
INFO - 2016-10-08 06:45:10 --> Helper loaded: url_helper
INFO - 2016-10-08 06:45:10 --> Database Driver Class Initialized
INFO - 2016-10-08 06:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 06:45:10 --> Controller Class Initialized
DEBUG - 2016-10-08 06:45:10 --> Index MX_Controller Initialized
INFO - 2016-10-08 06:45:10 --> Model Class Initialized
INFO - 2016-10-08 06:45:10 --> Model Class Initialized
ERROR - 2016-10-08 06:45:10 --> Unable to delete cache file for admin/index/do_bayar
INFO - 2016-10-08 06:45:10 --> Database Driver Class Initialized
INFO - 2016-10-08 06:45:10 --> Database Driver Class Initialized
INFO - 2016-10-08 06:45:10 --> Database Driver Class Initialized
INFO - 2016-10-08 06:45:10 --> Database Driver Class Initialized
INFO - 2016-10-08 06:45:10 --> Database Driver Class Initialized
INFO - 2016-10-08 06:45:10 --> Database Driver Class Initialized
INFO - 2016-10-08 06:45:11 --> Final output sent to browser
DEBUG - 2016-10-08 06:45:11 --> Total execution time: 0.9538
INFO - 2016-10-08 06:45:12 --> Config Class Initialized
INFO - 2016-10-08 06:45:12 --> Hooks Class Initialized
DEBUG - 2016-10-08 06:45:12 --> UTF-8 Support Enabled
INFO - 2016-10-08 06:45:12 --> Utf8 Class Initialized
INFO - 2016-10-08 06:45:12 --> URI Class Initialized
INFO - 2016-10-08 06:45:12 --> Router Class Initialized
INFO - 2016-10-08 06:45:12 --> Output Class Initialized
INFO - 2016-10-08 06:45:12 --> Security Class Initialized
DEBUG - 2016-10-08 06:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 06:45:12 --> Input Class Initialized
INFO - 2016-10-08 06:45:12 --> Language Class Initialized
INFO - 2016-10-08 06:45:12 --> Language Class Initialized
INFO - 2016-10-08 06:45:12 --> Config Class Initialized
INFO - 2016-10-08 06:45:12 --> Loader Class Initialized
INFO - 2016-10-08 06:45:12 --> Helper loaded: url_helper
INFO - 2016-10-08 06:45:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 06:45:12 --> Controller Class Initialized
DEBUG - 2016-10-08 06:45:12 --> Index MX_Controller Initialized
INFO - 2016-10-08 06:45:12 --> Model Class Initialized
INFO - 2016-10-08 06:45:12 --> Model Class Initialized
ERROR - 2016-10-08 06:45:12 --> Unable to delete cache file for admin/index/getDetailAngsuran
INFO - 2016-10-08 06:45:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:45:12 --> Final output sent to browser
DEBUG - 2016-10-08 06:45:12 --> Total execution time: 0.6348
INFO - 2016-10-08 06:45:13 --> Config Class Initialized
INFO - 2016-10-08 06:45:13 --> Hooks Class Initialized
DEBUG - 2016-10-08 06:45:13 --> UTF-8 Support Enabled
INFO - 2016-10-08 06:45:13 --> Utf8 Class Initialized
INFO - 2016-10-08 06:45:13 --> URI Class Initialized
INFO - 2016-10-08 06:45:13 --> Router Class Initialized
INFO - 2016-10-08 06:45:13 --> Output Class Initialized
INFO - 2016-10-08 06:45:13 --> Security Class Initialized
DEBUG - 2016-10-08 06:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 06:45:14 --> Input Class Initialized
INFO - 2016-10-08 06:45:14 --> Language Class Initialized
INFO - 2016-10-08 06:45:14 --> Language Class Initialized
INFO - 2016-10-08 06:45:14 --> Config Class Initialized
INFO - 2016-10-08 06:45:14 --> Loader Class Initialized
INFO - 2016-10-08 06:45:14 --> Helper loaded: url_helper
INFO - 2016-10-08 06:45:14 --> Database Driver Class Initialized
INFO - 2016-10-08 06:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 06:45:14 --> Controller Class Initialized
DEBUG - 2016-10-08 06:45:14 --> Index MX_Controller Initialized
INFO - 2016-10-08 06:45:14 --> Model Class Initialized
INFO - 2016-10-08 06:45:14 --> Model Class Initialized
ERROR - 2016-10-08 06:45:14 --> Unable to delete cache file for admin/index/do_bayar
INFO - 2016-10-08 06:45:14 --> Database Driver Class Initialized
INFO - 2016-10-08 06:45:14 --> Database Driver Class Initialized
INFO - 2016-10-08 06:45:14 --> Database Driver Class Initialized
INFO - 2016-10-08 06:45:14 --> Database Driver Class Initialized
INFO - 2016-10-08 06:45:14 --> Database Driver Class Initialized
INFO - 2016-10-08 06:45:14 --> Database Driver Class Initialized
INFO - 2016-10-08 06:45:14 --> Final output sent to browser
DEBUG - 2016-10-08 06:45:14 --> Total execution time: 1.1129
INFO - 2016-10-08 06:45:15 --> Config Class Initialized
INFO - 2016-10-08 06:45:16 --> Hooks Class Initialized
DEBUG - 2016-10-08 06:45:16 --> UTF-8 Support Enabled
INFO - 2016-10-08 06:45:16 --> Utf8 Class Initialized
INFO - 2016-10-08 06:45:16 --> URI Class Initialized
INFO - 2016-10-08 06:45:16 --> Router Class Initialized
INFO - 2016-10-08 06:45:16 --> Output Class Initialized
INFO - 2016-10-08 06:45:16 --> Security Class Initialized
DEBUG - 2016-10-08 06:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 06:45:16 --> Input Class Initialized
INFO - 2016-10-08 06:45:16 --> Language Class Initialized
INFO - 2016-10-08 06:45:16 --> Language Class Initialized
INFO - 2016-10-08 06:45:16 --> Config Class Initialized
INFO - 2016-10-08 06:45:16 --> Loader Class Initialized
INFO - 2016-10-08 06:45:16 --> Helper loaded: url_helper
INFO - 2016-10-08 06:45:16 --> Database Driver Class Initialized
INFO - 2016-10-08 06:45:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 06:45:16 --> Controller Class Initialized
DEBUG - 2016-10-08 06:45:16 --> Index MX_Controller Initialized
INFO - 2016-10-08 06:45:16 --> Model Class Initialized
INFO - 2016-10-08 06:45:16 --> Model Class Initialized
ERROR - 2016-10-08 06:45:16 --> Unable to delete cache file for admin/index/getDetailAngsuran
INFO - 2016-10-08 06:45:16 --> Database Driver Class Initialized
INFO - 2016-10-08 06:45:16 --> Final output sent to browser
DEBUG - 2016-10-08 06:45:16 --> Total execution time: 0.7517
INFO - 2016-10-08 06:45:24 --> Config Class Initialized
INFO - 2016-10-08 06:45:25 --> Hooks Class Initialized
DEBUG - 2016-10-08 06:45:25 --> UTF-8 Support Enabled
INFO - 2016-10-08 06:45:25 --> Utf8 Class Initialized
INFO - 2016-10-08 06:45:25 --> URI Class Initialized
INFO - 2016-10-08 06:45:25 --> Router Class Initialized
INFO - 2016-10-08 06:45:25 --> Output Class Initialized
INFO - 2016-10-08 06:45:25 --> Security Class Initialized
DEBUG - 2016-10-08 06:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 06:45:25 --> Input Class Initialized
INFO - 2016-10-08 06:45:25 --> Language Class Initialized
INFO - 2016-10-08 06:45:25 --> Language Class Initialized
INFO - 2016-10-08 06:45:25 --> Config Class Initialized
INFO - 2016-10-08 06:45:25 --> Loader Class Initialized
INFO - 2016-10-08 06:45:25 --> Helper loaded: url_helper
INFO - 2016-10-08 06:45:25 --> Database Driver Class Initialized
INFO - 2016-10-08 06:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 06:45:25 --> Controller Class Initialized
DEBUG - 2016-10-08 06:45:25 --> Index MX_Controller Initialized
INFO - 2016-10-08 06:45:25 --> Model Class Initialized
INFO - 2016-10-08 06:45:25 --> Model Class Initialized
ERROR - 2016-10-08 06:45:25 --> Unable to delete cache file for admin/index/do_bayar
INFO - 2016-10-08 06:45:25 --> Database Driver Class Initialized
INFO - 2016-10-08 06:45:25 --> Database Driver Class Initialized
INFO - 2016-10-08 06:45:25 --> Database Driver Class Initialized
INFO - 2016-10-08 06:45:25 --> Database Driver Class Initialized
INFO - 2016-10-08 06:45:25 --> Database Driver Class Initialized
INFO - 2016-10-08 06:45:25 --> Database Driver Class Initialized
INFO - 2016-10-08 06:45:25 --> Final output sent to browser
DEBUG - 2016-10-08 06:45:26 --> Total execution time: 1.0006
INFO - 2016-10-08 06:45:31 --> Config Class Initialized
INFO - 2016-10-08 06:45:31 --> Hooks Class Initialized
DEBUG - 2016-10-08 06:45:31 --> UTF-8 Support Enabled
INFO - 2016-10-08 06:45:31 --> Utf8 Class Initialized
INFO - 2016-10-08 06:45:31 --> URI Class Initialized
INFO - 2016-10-08 06:45:31 --> Router Class Initialized
INFO - 2016-10-08 06:45:31 --> Output Class Initialized
INFO - 2016-10-08 06:45:31 --> Security Class Initialized
DEBUG - 2016-10-08 06:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 06:45:31 --> Input Class Initialized
INFO - 2016-10-08 06:45:31 --> Language Class Initialized
INFO - 2016-10-08 06:45:32 --> Language Class Initialized
INFO - 2016-10-08 06:45:32 --> Config Class Initialized
INFO - 2016-10-08 06:45:32 --> Loader Class Initialized
INFO - 2016-10-08 06:45:32 --> Helper loaded: url_helper
INFO - 2016-10-08 06:45:32 --> Database Driver Class Initialized
INFO - 2016-10-08 06:45:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 06:45:32 --> Controller Class Initialized
DEBUG - 2016-10-08 06:45:32 --> Index MX_Controller Initialized
INFO - 2016-10-08 06:45:32 --> Model Class Initialized
INFO - 2016-10-08 06:45:32 --> Model Class Initialized
ERROR - 2016-10-08 06:45:32 --> Unable to delete cache file for admin/index/getRaportAngsuran/356a192b7913b04c54574d18c28d46e6395428ab
DEBUG - 2016-10-08 06:45:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/raport_angsuran.php
INFO - 2016-10-08 06:45:32 --> Final output sent to browser
DEBUG - 2016-10-08 06:45:32 --> Total execution time: 0.9728
INFO - 2016-10-08 06:48:03 --> Config Class Initialized
INFO - 2016-10-08 06:48:03 --> Hooks Class Initialized
DEBUG - 2016-10-08 06:48:03 --> UTF-8 Support Enabled
INFO - 2016-10-08 06:48:03 --> Utf8 Class Initialized
INFO - 2016-10-08 06:48:03 --> URI Class Initialized
INFO - 2016-10-08 06:48:03 --> Router Class Initialized
INFO - 2016-10-08 06:48:03 --> Output Class Initialized
INFO - 2016-10-08 06:48:04 --> Security Class Initialized
DEBUG - 2016-10-08 06:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 06:48:04 --> Input Class Initialized
INFO - 2016-10-08 06:48:04 --> Language Class Initialized
INFO - 2016-10-08 06:48:04 --> Language Class Initialized
INFO - 2016-10-08 06:48:04 --> Config Class Initialized
INFO - 2016-10-08 06:48:04 --> Loader Class Initialized
INFO - 2016-10-08 06:48:04 --> Helper loaded: url_helper
INFO - 2016-10-08 06:48:04 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 06:48:04 --> Controller Class Initialized
DEBUG - 2016-10-08 06:48:04 --> Index MX_Controller Initialized
INFO - 2016-10-08 06:48:04 --> Model Class Initialized
INFO - 2016-10-08 06:48:04 --> Model Class Initialized
ERROR - 2016-10-08 06:48:04 --> Unable to delete cache file for admin/index/getRaportAngsuran/356a192b7913b04c54574d18c28d46e6395428ab
DEBUG - 2016-10-08 06:48:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/raport_angsuran.php
INFO - 2016-10-08 06:48:04 --> Final output sent to browser
DEBUG - 2016-10-08 06:48:04 --> Total execution time: 0.8395
INFO - 2016-10-08 06:48:10 --> Config Class Initialized
INFO - 2016-10-08 06:48:10 --> Hooks Class Initialized
DEBUG - 2016-10-08 06:48:10 --> UTF-8 Support Enabled
INFO - 2016-10-08 06:48:10 --> Utf8 Class Initialized
INFO - 2016-10-08 06:48:10 --> URI Class Initialized
INFO - 2016-10-08 06:48:10 --> Router Class Initialized
INFO - 2016-10-08 06:48:10 --> Output Class Initialized
INFO - 2016-10-08 06:48:10 --> Security Class Initialized
DEBUG - 2016-10-08 06:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 06:48:11 --> Input Class Initialized
INFO - 2016-10-08 06:48:11 --> Language Class Initialized
INFO - 2016-10-08 06:48:11 --> Language Class Initialized
INFO - 2016-10-08 06:48:11 --> Config Class Initialized
INFO - 2016-10-08 06:48:11 --> Loader Class Initialized
INFO - 2016-10-08 06:48:11 --> Helper loaded: url_helper
INFO - 2016-10-08 06:48:11 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 06:48:11 --> Controller Class Initialized
DEBUG - 2016-10-08 06:48:11 --> Index MX_Controller Initialized
INFO - 2016-10-08 06:48:11 --> Model Class Initialized
INFO - 2016-10-08 06:48:11 --> Model Class Initialized
ERROR - 2016-10-08 06:48:11 --> Unable to delete cache file for admin/index/detail_anggota/356a192b7913b04c54574d18c28d46e6395428ab
DEBUG - 2016-10-08 06:48:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 06:48:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 06:48:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
INFO - 2016-10-08 06:48:11 --> Database Driver Class Initialized
DEBUG - 2016-10-08 06:48:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_pinjaman.php
INFO - 2016-10-08 06:48:11 --> Database Driver Class Initialized
DEBUG - 2016-10-08 06:48:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_tabungan.php
DEBUG - 2016-10-08 06:48:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/profile_anggota.php
DEBUG - 2016-10-08 06:48:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 06:48:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 06:48:11 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:11 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:11 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:11 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:11 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:11 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:11 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:11 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:11 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:11 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:11 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:11 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:12 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:13 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:13 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:13 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:13 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:13 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:13 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:13 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:13 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:13 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:13 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:13 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:13 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:13 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:13 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:13 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:13 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:13 --> Database Driver Class Initialized
DEBUG - 2016-10-08 06:48:13 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 06:48:13 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 06:48:13 --> Final output sent to browser
DEBUG - 2016-10-08 06:48:13 --> Total execution time: 2.8828
INFO - 2016-10-08 06:48:13 --> Config Class Initialized
INFO - 2016-10-08 06:48:13 --> Hooks Class Initialized
DEBUG - 2016-10-08 06:48:13 --> UTF-8 Support Enabled
INFO - 2016-10-08 06:48:14 --> Utf8 Class Initialized
INFO - 2016-10-08 06:48:14 --> URI Class Initialized
INFO - 2016-10-08 06:48:14 --> Router Class Initialized
INFO - 2016-10-08 06:48:14 --> Output Class Initialized
INFO - 2016-10-08 06:48:14 --> Security Class Initialized
DEBUG - 2016-10-08 06:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 06:48:14 --> Input Class Initialized
INFO - 2016-10-08 06:48:14 --> Language Class Initialized
INFO - 2016-10-08 06:48:14 --> Language Class Initialized
INFO - 2016-10-08 06:48:14 --> Config Class Initialized
INFO - 2016-10-08 06:48:14 --> Loader Class Initialized
INFO - 2016-10-08 06:48:14 --> Helper loaded: url_helper
INFO - 2016-10-08 06:48:14 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 06:48:14 --> Controller Class Initialized
DEBUG - 2016-10-08 06:48:14 --> Index MX_Controller Initialized
INFO - 2016-10-08 06:48:14 --> Model Class Initialized
INFO - 2016-10-08 06:48:14 --> Model Class Initialized
ERROR - 2016-10-08 06:48:14 --> Unable to delete cache file for admin/index/detail_anggota/images/picture.jpg
DEBUG - 2016-10-08 06:48:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 06:48:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 06:48:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
ERROR - 2016-10-08 06:48:15 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 16
ERROR - 2016-10-08 06:48:15 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 19
ERROR - 2016-10-08 06:48:15 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 22
ERROR - 2016-10-08 06:48:15 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 38
INFO - 2016-10-08 06:48:15 --> Database Driver Class Initialized
DEBUG - 2016-10-08 06:48:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_pinjaman.php
ERROR - 2016-10-08 06:48:15 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\profile_anggota.php 41
INFO - 2016-10-08 06:48:15 --> Database Driver Class Initialized
DEBUG - 2016-10-08 06:48:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_tabungan.php
DEBUG - 2016-10-08 06:48:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/profile_anggota.php
DEBUG - 2016-10-08 06:48:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 06:48:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 06:48:15 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:16 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:16 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:16 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:16 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:16 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:16 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:16 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:16 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:16 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:16 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:16 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:16 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:16 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:16 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:16 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:16 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:16 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:16 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:16 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:16 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:16 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:17 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:17 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:17 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:17 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:17 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:17 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:17 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:17 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:18 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:18 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:18 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:18 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:18 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:18 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:18 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:18 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:18 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:18 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:18 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:18 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:19 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:19 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:19 --> Config Class Initialized
INFO - 2016-10-08 06:48:19 --> Hooks Class Initialized
INFO - 2016-10-08 06:48:19 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:19 --> Database Driver Class Initialized
DEBUG - 2016-10-08 06:48:19 --> UTF-8 Support Enabled
INFO - 2016-10-08 06:48:19 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:19 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:19 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:19 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:19 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:19 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:19 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:19 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:19 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:19 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:19 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:19 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:20 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:20 --> Database Driver Class Initialized
DEBUG - 2016-10-08 06:48:20 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 06:48:20 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 06:48:20 --> Utf8 Class Initialized
INFO - 2016-10-08 06:48:20 --> Final output sent to browser
DEBUG - 2016-10-08 06:48:20 --> Total execution time: 6.3442
INFO - 2016-10-08 06:48:20 --> URI Class Initialized
INFO - 2016-10-08 06:48:20 --> Router Class Initialized
INFO - 2016-10-08 06:48:20 --> Output Class Initialized
INFO - 2016-10-08 06:48:20 --> Security Class Initialized
DEBUG - 2016-10-08 06:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 06:48:20 --> Input Class Initialized
INFO - 2016-10-08 06:48:20 --> Language Class Initialized
INFO - 2016-10-08 06:48:20 --> Language Class Initialized
INFO - 2016-10-08 06:48:20 --> Config Class Initialized
INFO - 2016-10-08 06:48:20 --> Loader Class Initialized
INFO - 2016-10-08 06:48:20 --> Helper loaded: url_helper
INFO - 2016-10-08 06:48:20 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 06:48:20 --> Controller Class Initialized
DEBUG - 2016-10-08 06:48:20 --> Index MX_Controller Initialized
INFO - 2016-10-08 06:48:20 --> Model Class Initialized
INFO - 2016-10-08 06:48:20 --> Model Class Initialized
ERROR - 2016-10-08 06:48:20 --> Unable to delete cache file for admin/index/getRaportAngsuran/356a192b7913b04c54574d18c28d46e6395428ab
DEBUG - 2016-10-08 06:48:20 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/raport_angsuran.php
INFO - 2016-10-08 06:48:20 --> Final output sent to browser
DEBUG - 2016-10-08 06:48:21 --> Total execution time: 1.5904
INFO - 2016-10-08 06:48:55 --> Config Class Initialized
INFO - 2016-10-08 06:48:55 --> Hooks Class Initialized
DEBUG - 2016-10-08 06:48:55 --> UTF-8 Support Enabled
INFO - 2016-10-08 06:48:56 --> Utf8 Class Initialized
INFO - 2016-10-08 06:48:56 --> URI Class Initialized
INFO - 2016-10-08 06:48:56 --> Router Class Initialized
INFO - 2016-10-08 06:48:56 --> Output Class Initialized
INFO - 2016-10-08 06:48:56 --> Security Class Initialized
DEBUG - 2016-10-08 06:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 06:48:56 --> Input Class Initialized
INFO - 2016-10-08 06:48:56 --> Language Class Initialized
INFO - 2016-10-08 06:48:56 --> Language Class Initialized
INFO - 2016-10-08 06:48:56 --> Config Class Initialized
INFO - 2016-10-08 06:48:56 --> Loader Class Initialized
INFO - 2016-10-08 06:48:56 --> Helper loaded: url_helper
INFO - 2016-10-08 06:48:56 --> Database Driver Class Initialized
INFO - 2016-10-08 06:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 06:48:56 --> Controller Class Initialized
DEBUG - 2016-10-08 06:48:56 --> Index MX_Controller Initialized
INFO - 2016-10-08 06:48:56 --> Model Class Initialized
INFO - 2016-10-08 06:48:56 --> Model Class Initialized
ERROR - 2016-10-08 06:48:56 --> Unable to delete cache file for admin/index/getRaportAngsuran/356a192b7913b04c54574d18c28d46e6395428ab
DEBUG - 2016-10-08 06:48:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/raport_angsuran.php
INFO - 2016-10-08 06:48:56 --> Final output sent to browser
DEBUG - 2016-10-08 06:48:56 --> Total execution time: 0.8725
INFO - 2016-10-08 07:29:54 --> Config Class Initialized
INFO - 2016-10-08 07:29:55 --> Hooks Class Initialized
DEBUG - 2016-10-08 07:29:55 --> UTF-8 Support Enabled
INFO - 2016-10-08 07:29:55 --> Utf8 Class Initialized
INFO - 2016-10-08 07:29:55 --> URI Class Initialized
INFO - 2016-10-08 07:29:55 --> Router Class Initialized
INFO - 2016-10-08 07:29:55 --> Output Class Initialized
INFO - 2016-10-08 07:29:55 --> Security Class Initialized
DEBUG - 2016-10-08 07:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 07:29:55 --> Input Class Initialized
INFO - 2016-10-08 07:29:55 --> Language Class Initialized
INFO - 2016-10-08 07:29:55 --> Language Class Initialized
INFO - 2016-10-08 07:29:55 --> Config Class Initialized
INFO - 2016-10-08 07:29:55 --> Loader Class Initialized
INFO - 2016-10-08 07:29:55 --> Helper loaded: url_helper
INFO - 2016-10-08 07:29:55 --> Database Driver Class Initialized
INFO - 2016-10-08 07:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 07:29:55 --> Controller Class Initialized
DEBUG - 2016-10-08 07:29:55 --> Index MX_Controller Initialized
INFO - 2016-10-08 07:29:55 --> Model Class Initialized
INFO - 2016-10-08 07:29:55 --> Model Class Initialized
ERROR - 2016-10-08 07:29:55 --> Unable to delete cache file for admin/index/getRaportAngsuran/356a192b7913b04c54574d18c28d46e6395428ab
DEBUG - 2016-10-08 07:29:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/raport_angsuran.php
INFO - 2016-10-08 07:29:55 --> Final output sent to browser
DEBUG - 2016-10-08 07:29:55 --> Total execution time: 0.9013
INFO - 2016-10-08 07:30:19 --> Config Class Initialized
INFO - 2016-10-08 07:30:19 --> Hooks Class Initialized
DEBUG - 2016-10-08 07:30:19 --> UTF-8 Support Enabled
INFO - 2016-10-08 07:30:19 --> Utf8 Class Initialized
INFO - 2016-10-08 07:30:19 --> URI Class Initialized
INFO - 2016-10-08 07:30:20 --> Router Class Initialized
INFO - 2016-10-08 07:30:20 --> Output Class Initialized
INFO - 2016-10-08 07:30:20 --> Security Class Initialized
DEBUG - 2016-10-08 07:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 07:30:20 --> Input Class Initialized
INFO - 2016-10-08 07:30:20 --> Language Class Initialized
INFO - 2016-10-08 07:30:20 --> Language Class Initialized
INFO - 2016-10-08 07:30:20 --> Config Class Initialized
INFO - 2016-10-08 07:30:20 --> Loader Class Initialized
INFO - 2016-10-08 07:30:20 --> Helper loaded: url_helper
INFO - 2016-10-08 07:30:20 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 07:30:20 --> Controller Class Initialized
DEBUG - 2016-10-08 07:30:20 --> Index MX_Controller Initialized
INFO - 2016-10-08 07:30:20 --> Model Class Initialized
INFO - 2016-10-08 07:30:20 --> Model Class Initialized
ERROR - 2016-10-08 07:30:20 --> Unable to delete cache file for admin/index/upload_foto
DEBUG - 2016-10-08 07:30:20 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 07:30:20 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 07:30:20 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 07:30:20 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/upload_foto.php
DEBUG - 2016-10-08 07:30:20 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 07:30:20 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 07:30:20 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:20 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:20 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:20 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:20 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:20 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:20 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:20 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:20 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:21 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:21 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:21 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:21 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:21 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:21 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:21 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:21 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:21 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:21 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:21 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:21 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:21 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:21 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:21 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:21 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:21 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:21 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:21 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:21 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:21 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:21 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:21 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:21 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:21 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:21 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:21 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:21 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:21 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:22 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:22 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:22 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:22 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:22 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:22 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:22 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:22 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:22 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:22 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:22 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:22 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:22 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:22 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:22 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:22 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:22 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:22 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:22 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:22 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:22 --> Database Driver Class Initialized
DEBUG - 2016-10-08 07:30:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 07:30:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 07:30:22 --> Final output sent to browser
DEBUG - 2016-10-08 07:30:22 --> Total execution time: 2.8538
INFO - 2016-10-08 07:30:40 --> Config Class Initialized
INFO - 2016-10-08 07:30:40 --> Hooks Class Initialized
DEBUG - 2016-10-08 07:30:40 --> UTF-8 Support Enabled
INFO - 2016-10-08 07:30:40 --> Utf8 Class Initialized
INFO - 2016-10-08 07:30:40 --> URI Class Initialized
INFO - 2016-10-08 07:30:40 --> Router Class Initialized
INFO - 2016-10-08 07:30:40 --> Output Class Initialized
INFO - 2016-10-08 07:30:40 --> Security Class Initialized
DEBUG - 2016-10-08 07:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 07:30:40 --> Input Class Initialized
INFO - 2016-10-08 07:30:40 --> Language Class Initialized
INFO - 2016-10-08 07:30:40 --> Language Class Initialized
INFO - 2016-10-08 07:30:40 --> Config Class Initialized
INFO - 2016-10-08 07:30:40 --> Loader Class Initialized
INFO - 2016-10-08 07:30:40 --> Helper loaded: url_helper
INFO - 2016-10-08 07:30:40 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 07:30:40 --> Controller Class Initialized
DEBUG - 2016-10-08 07:30:41 --> Index MX_Controller Initialized
INFO - 2016-10-08 07:30:41 --> Model Class Initialized
INFO - 2016-10-08 07:30:41 --> Model Class Initialized
ERROR - 2016-10-08 07:30:41 --> Unable to delete cache file for admin/index/do_upload_foto
INFO - 2016-10-08 07:30:41 --> Upload Class Initialized
INFO - 2016-10-08 07:30:41 --> Final output sent to browser
DEBUG - 2016-10-08 07:30:41 --> Total execution time: 1.0104
INFO - 2016-10-08 07:30:52 --> Config Class Initialized
INFO - 2016-10-08 07:30:52 --> Hooks Class Initialized
DEBUG - 2016-10-08 07:30:52 --> UTF-8 Support Enabled
INFO - 2016-10-08 07:30:52 --> Utf8 Class Initialized
INFO - 2016-10-08 07:30:52 --> URI Class Initialized
INFO - 2016-10-08 07:30:52 --> Router Class Initialized
INFO - 2016-10-08 07:30:52 --> Output Class Initialized
INFO - 2016-10-08 07:30:52 --> Security Class Initialized
DEBUG - 2016-10-08 07:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 07:30:53 --> Input Class Initialized
INFO - 2016-10-08 07:30:53 --> Language Class Initialized
INFO - 2016-10-08 07:30:53 --> Language Class Initialized
INFO - 2016-10-08 07:30:53 --> Config Class Initialized
INFO - 2016-10-08 07:30:53 --> Loader Class Initialized
INFO - 2016-10-08 07:30:53 --> Helper loaded: url_helper
INFO - 2016-10-08 07:30:53 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 07:30:53 --> Controller Class Initialized
DEBUG - 2016-10-08 07:30:53 --> Index MX_Controller Initialized
INFO - 2016-10-08 07:30:53 --> Model Class Initialized
INFO - 2016-10-08 07:30:53 --> Model Class Initialized
ERROR - 2016-10-08 07:30:53 --> Unable to delete cache file for admin/index/upload_foto
DEBUG - 2016-10-08 07:30:53 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 07:30:53 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 07:30:53 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 07:30:53 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/upload_foto.php
DEBUG - 2016-10-08 07:30:53 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 07:30:53 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 07:30:53 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:53 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:53 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:53 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:53 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:53 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:53 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:53 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:53 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:53 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:53 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:53 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:53 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:53 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:54 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:54 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:54 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:54 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:54 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:54 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:54 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:54 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:54 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:54 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:54 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:54 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:54 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:54 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:54 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:54 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:54 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:54 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:54 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:54 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:54 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:54 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:54 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:54 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:54 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:54 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:54 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:54 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:54 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:54 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:54 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:55 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:55 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:55 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:55 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:55 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:55 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:55 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:55 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:55 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:55 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:55 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:55 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:55 --> Database Driver Class Initialized
INFO - 2016-10-08 07:30:55 --> Database Driver Class Initialized
DEBUG - 2016-10-08 07:30:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 07:30:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 07:30:55 --> Final output sent to browser
DEBUG - 2016-10-08 07:30:55 --> Total execution time: 2.7410
INFO - 2016-10-08 07:31:01 --> Config Class Initialized
INFO - 2016-10-08 07:31:01 --> Hooks Class Initialized
DEBUG - 2016-10-08 07:31:01 --> UTF-8 Support Enabled
INFO - 2016-10-08 07:31:01 --> Utf8 Class Initialized
INFO - 2016-10-08 07:31:01 --> URI Class Initialized
INFO - 2016-10-08 07:31:01 --> Router Class Initialized
INFO - 2016-10-08 07:31:01 --> Output Class Initialized
INFO - 2016-10-08 07:31:01 --> Security Class Initialized
DEBUG - 2016-10-08 07:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 07:31:01 --> Input Class Initialized
INFO - 2016-10-08 07:31:01 --> Language Class Initialized
INFO - 2016-10-08 07:31:01 --> Language Class Initialized
INFO - 2016-10-08 07:31:01 --> Config Class Initialized
INFO - 2016-10-08 07:31:01 --> Loader Class Initialized
INFO - 2016-10-08 07:31:01 --> Helper loaded: url_helper
INFO - 2016-10-08 07:31:01 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 07:31:01 --> Controller Class Initialized
DEBUG - 2016-10-08 07:31:01 --> Index MX_Controller Initialized
INFO - 2016-10-08 07:31:01 --> Model Class Initialized
INFO - 2016-10-08 07:31:01 --> Model Class Initialized
ERROR - 2016-10-08 07:31:02 --> Unable to delete cache file for admin/index/logout
INFO - 2016-10-08 07:31:02 --> Final output sent to browser
DEBUG - 2016-10-08 07:31:02 --> Total execution time: 0.6383
INFO - 2016-10-08 07:31:02 --> Config Class Initialized
INFO - 2016-10-08 07:31:02 --> Hooks Class Initialized
DEBUG - 2016-10-08 07:31:02 --> UTF-8 Support Enabled
INFO - 2016-10-08 07:31:02 --> Utf8 Class Initialized
INFO - 2016-10-08 07:31:02 --> URI Class Initialized
INFO - 2016-10-08 07:31:02 --> Router Class Initialized
INFO - 2016-10-08 07:31:02 --> Output Class Initialized
INFO - 2016-10-08 07:31:02 --> Security Class Initialized
DEBUG - 2016-10-08 07:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 07:31:02 --> Input Class Initialized
INFO - 2016-10-08 07:31:02 --> Language Class Initialized
INFO - 2016-10-08 07:31:02 --> Language Class Initialized
INFO - 2016-10-08 07:31:02 --> Config Class Initialized
INFO - 2016-10-08 07:31:02 --> Loader Class Initialized
INFO - 2016-10-08 07:31:02 --> Helper loaded: url_helper
INFO - 2016-10-08 07:31:02 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 07:31:02 --> Controller Class Initialized
DEBUG - 2016-10-08 07:31:02 --> login MX_Controller Initialized
INFO - 2016-10-08 07:31:02 --> Model Class Initialized
INFO - 2016-10-08 07:31:02 --> Model Class Initialized
DEBUG - 2016-10-08 07:31:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/login.php
INFO - 2016-10-08 07:31:03 --> Final output sent to browser
DEBUG - 2016-10-08 07:31:03 --> Total execution time: 0.8989
INFO - 2016-10-08 07:31:08 --> Config Class Initialized
INFO - 2016-10-08 07:31:08 --> Hooks Class Initialized
DEBUG - 2016-10-08 07:31:08 --> UTF-8 Support Enabled
INFO - 2016-10-08 07:31:08 --> Utf8 Class Initialized
INFO - 2016-10-08 07:31:08 --> URI Class Initialized
INFO - 2016-10-08 07:31:08 --> Router Class Initialized
INFO - 2016-10-08 07:31:08 --> Output Class Initialized
INFO - 2016-10-08 07:31:08 --> Security Class Initialized
DEBUG - 2016-10-08 07:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 07:31:08 --> Input Class Initialized
INFO - 2016-10-08 07:31:08 --> Language Class Initialized
INFO - 2016-10-08 07:31:08 --> Language Class Initialized
INFO - 2016-10-08 07:31:08 --> Config Class Initialized
INFO - 2016-10-08 07:31:08 --> Loader Class Initialized
INFO - 2016-10-08 07:31:08 --> Helper loaded: url_helper
INFO - 2016-10-08 07:31:08 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 07:31:08 --> Controller Class Initialized
DEBUG - 2016-10-08 07:31:08 --> login MX_Controller Initialized
INFO - 2016-10-08 07:31:08 --> Model Class Initialized
INFO - 2016-10-08 07:31:08 --> Model Class Initialized
INFO - 2016-10-08 07:31:08 --> Final output sent to browser
DEBUG - 2016-10-08 07:31:08 --> Total execution time: 0.5824
INFO - 2016-10-08 07:31:08 --> Config Class Initialized
INFO - 2016-10-08 07:31:08 --> Hooks Class Initialized
DEBUG - 2016-10-08 07:31:08 --> UTF-8 Support Enabled
INFO - 2016-10-08 07:31:08 --> Utf8 Class Initialized
INFO - 2016-10-08 07:31:08 --> URI Class Initialized
INFO - 2016-10-08 07:31:08 --> Router Class Initialized
INFO - 2016-10-08 07:31:08 --> Output Class Initialized
INFO - 2016-10-08 07:31:09 --> Security Class Initialized
DEBUG - 2016-10-08 07:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 07:31:09 --> Input Class Initialized
INFO - 2016-10-08 07:31:09 --> Language Class Initialized
INFO - 2016-10-08 07:31:09 --> Language Class Initialized
INFO - 2016-10-08 07:31:09 --> Config Class Initialized
INFO - 2016-10-08 07:31:09 --> Loader Class Initialized
INFO - 2016-10-08 07:31:09 --> Helper loaded: url_helper
INFO - 2016-10-08 07:31:09 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 07:31:09 --> Controller Class Initialized
DEBUG - 2016-10-08 07:31:09 --> Index MX_Controller Initialized
INFO - 2016-10-08 07:31:09 --> Model Class Initialized
INFO - 2016-10-08 07:31:09 --> Model Class Initialized
ERROR - 2016-10-08 07:31:09 --> Unable to delete cache file for admin/index
DEBUG - 2016-10-08 07:31:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 07:31:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 07:31:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 07:31:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/dashboard.php
DEBUG - 2016-10-08 07:31:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 07:31:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 07:31:09 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:09 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:09 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:09 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:09 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:09 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:09 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:09 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:09 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:10 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:10 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:10 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:10 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:10 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:10 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:10 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:10 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:10 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:10 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:10 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:10 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:10 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:10 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:10 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:10 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:10 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:10 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:10 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:10 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:10 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:10 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:10 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:10 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:10 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:10 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:10 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:10 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:11 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:11 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:11 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:11 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:11 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:11 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:11 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:11 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:11 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:11 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:11 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:11 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:11 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:11 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:11 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:11 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:11 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:11 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:11 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:11 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:11 --> Database Driver Class Initialized
INFO - 2016-10-08 07:31:11 --> Database Driver Class Initialized
DEBUG - 2016-10-08 07:31:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 07:31:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 07:31:11 --> Final output sent to browser
DEBUG - 2016-10-08 07:31:11 --> Total execution time: 3.1279
INFO - 2016-10-08 07:38:50 --> Config Class Initialized
INFO - 2016-10-08 07:38:50 --> Hooks Class Initialized
DEBUG - 2016-10-08 07:38:51 --> UTF-8 Support Enabled
INFO - 2016-10-08 07:38:51 --> Utf8 Class Initialized
INFO - 2016-10-08 07:38:51 --> URI Class Initialized
INFO - 2016-10-08 07:38:51 --> Router Class Initialized
INFO - 2016-10-08 07:38:51 --> Output Class Initialized
INFO - 2016-10-08 07:38:51 --> Security Class Initialized
DEBUG - 2016-10-08 07:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 07:38:51 --> Input Class Initialized
INFO - 2016-10-08 07:38:51 --> Language Class Initialized
INFO - 2016-10-08 07:38:52 --> Language Class Initialized
INFO - 2016-10-08 07:38:52 --> Config Class Initialized
INFO - 2016-10-08 07:38:52 --> Loader Class Initialized
INFO - 2016-10-08 07:38:52 --> Helper loaded: url_helper
INFO - 2016-10-08 07:38:52 --> Database Driver Class Initialized
INFO - 2016-10-08 07:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 07:38:53 --> Controller Class Initialized
DEBUG - 2016-10-08 07:38:53 --> Index MX_Controller Initialized
INFO - 2016-10-08 07:38:53 --> Model Class Initialized
INFO - 2016-10-08 07:38:53 --> Model Class Initialized
ERROR - 2016-10-08 07:38:53 --> Unable to delete cache file for admin/index/getRaportAngsuran/356a192b7913b04c54574d18c28d46e6395428ab
DEBUG - 2016-10-08 07:38:53 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/raport_angsuran.php
INFO - 2016-10-08 07:38:53 --> Final output sent to browser
DEBUG - 2016-10-08 07:38:53 --> Total execution time: 2.8219
INFO - 2016-10-08 17:32:04 --> Config Class Initialized
INFO - 2016-10-08 17:32:04 --> Hooks Class Initialized
DEBUG - 2016-10-08 17:32:04 --> UTF-8 Support Enabled
INFO - 2016-10-08 17:32:04 --> Utf8 Class Initialized
INFO - 2016-10-08 17:32:04 --> URI Class Initialized
INFO - 2016-10-08 17:32:04 --> Router Class Initialized
INFO - 2016-10-08 17:32:04 --> Output Class Initialized
INFO - 2016-10-08 17:32:04 --> Security Class Initialized
DEBUG - 2016-10-08 17:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 17:32:05 --> Input Class Initialized
INFO - 2016-10-08 17:32:05 --> Language Class Initialized
INFO - 2016-10-08 17:32:05 --> Language Class Initialized
INFO - 2016-10-08 17:32:05 --> Config Class Initialized
INFO - 2016-10-08 17:32:05 --> Loader Class Initialized
INFO - 2016-10-08 17:32:05 --> Helper loaded: url_helper
INFO - 2016-10-08 17:32:05 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 17:32:05 --> Controller Class Initialized
DEBUG - 2016-10-08 17:32:05 --> Index MX_Controller Initialized
INFO - 2016-10-08 17:32:05 --> Model Class Initialized
INFO - 2016-10-08 17:32:05 --> Model Class Initialized
ERROR - 2016-10-08 17:32:05 --> Unable to delete cache file for admin/index
DEBUG - 2016-10-08 17:32:05 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 17:32:05 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 17:32:05 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 17:32:05 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/dashboard.php
DEBUG - 2016-10-08 17:32:06 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 17:32:06 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 17:32:06 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:06 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:06 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:06 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:06 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:06 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:06 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:06 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:06 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:06 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:06 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:06 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:06 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:06 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:07 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:07 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:07 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:07 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:07 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:07 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:07 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:07 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:07 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:07 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:07 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:07 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:07 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:07 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:07 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:07 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:07 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:07 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:07 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:07 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:08 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:08 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:08 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:08 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:08 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:08 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:08 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:08 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:08 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:08 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:08 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:08 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:08 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:08 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:08 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:08 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:08 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:08 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:08 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:09 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:09 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:09 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:09 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:09 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:09 --> Database Driver Class Initialized
DEBUG - 2016-10-08 17:32:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 17:32:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 17:32:09 --> Final output sent to browser
INFO - 2016-10-08 17:32:09 --> Config Class Initialized
DEBUG - 2016-10-08 17:32:09 --> Total execution time: 5.2087
INFO - 2016-10-08 17:32:09 --> Hooks Class Initialized
DEBUG - 2016-10-08 17:32:09 --> UTF-8 Support Enabled
INFO - 2016-10-08 17:32:09 --> Utf8 Class Initialized
INFO - 2016-10-08 17:32:09 --> URI Class Initialized
INFO - 2016-10-08 17:32:09 --> Router Class Initialized
INFO - 2016-10-08 17:32:09 --> Output Class Initialized
INFO - 2016-10-08 17:32:09 --> Security Class Initialized
DEBUG - 2016-10-08 17:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 17:32:09 --> Input Class Initialized
INFO - 2016-10-08 17:32:09 --> Language Class Initialized
INFO - 2016-10-08 17:32:09 --> Language Class Initialized
INFO - 2016-10-08 17:32:10 --> Config Class Initialized
INFO - 2016-10-08 17:32:10 --> Loader Class Initialized
INFO - 2016-10-08 17:32:10 --> Helper loaded: url_helper
INFO - 2016-10-08 17:32:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 17:32:10 --> Controller Class Initialized
DEBUG - 2016-10-08 17:32:10 --> login MX_Controller Initialized
INFO - 2016-10-08 17:32:10 --> Model Class Initialized
INFO - 2016-10-08 17:32:10 --> Model Class Initialized
DEBUG - 2016-10-08 17:32:10 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/login.php
INFO - 2016-10-08 17:32:10 --> Final output sent to browser
DEBUG - 2016-10-08 17:32:10 --> Total execution time: 1.1511
INFO - 2016-10-08 17:32:15 --> Config Class Initialized
INFO - 2016-10-08 17:32:15 --> Hooks Class Initialized
DEBUG - 2016-10-08 17:32:15 --> UTF-8 Support Enabled
INFO - 2016-10-08 17:32:15 --> Utf8 Class Initialized
INFO - 2016-10-08 17:32:15 --> URI Class Initialized
INFO - 2016-10-08 17:32:15 --> Router Class Initialized
INFO - 2016-10-08 17:32:15 --> Output Class Initialized
INFO - 2016-10-08 17:32:15 --> Security Class Initialized
DEBUG - 2016-10-08 17:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 17:32:15 --> Input Class Initialized
INFO - 2016-10-08 17:32:15 --> Language Class Initialized
INFO - 2016-10-08 17:32:15 --> Language Class Initialized
INFO - 2016-10-08 17:32:15 --> Config Class Initialized
INFO - 2016-10-08 17:32:15 --> Loader Class Initialized
INFO - 2016-10-08 17:32:16 --> Helper loaded: url_helper
INFO - 2016-10-08 17:32:16 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 17:32:16 --> Controller Class Initialized
DEBUG - 2016-10-08 17:32:16 --> login MX_Controller Initialized
INFO - 2016-10-08 17:32:16 --> Model Class Initialized
INFO - 2016-10-08 17:32:16 --> Model Class Initialized
INFO - 2016-10-08 17:32:16 --> Final output sent to browser
DEBUG - 2016-10-08 17:32:16 --> Total execution time: 0.8250
INFO - 2016-10-08 17:32:16 --> Config Class Initialized
INFO - 2016-10-08 17:32:16 --> Hooks Class Initialized
DEBUG - 2016-10-08 17:32:16 --> UTF-8 Support Enabled
INFO - 2016-10-08 17:32:16 --> Utf8 Class Initialized
INFO - 2016-10-08 17:32:16 --> URI Class Initialized
INFO - 2016-10-08 17:32:16 --> Router Class Initialized
INFO - 2016-10-08 17:32:16 --> Output Class Initialized
INFO - 2016-10-08 17:32:16 --> Security Class Initialized
DEBUG - 2016-10-08 17:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 17:32:16 --> Input Class Initialized
INFO - 2016-10-08 17:32:16 --> Language Class Initialized
INFO - 2016-10-08 17:32:16 --> Language Class Initialized
INFO - 2016-10-08 17:32:16 --> Config Class Initialized
INFO - 2016-10-08 17:32:17 --> Loader Class Initialized
INFO - 2016-10-08 17:32:17 --> Helper loaded: url_helper
INFO - 2016-10-08 17:32:17 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 17:32:17 --> Controller Class Initialized
DEBUG - 2016-10-08 17:32:17 --> Index MX_Controller Initialized
INFO - 2016-10-08 17:32:17 --> Model Class Initialized
INFO - 2016-10-08 17:32:17 --> Model Class Initialized
ERROR - 2016-10-08 17:32:17 --> Unable to delete cache file for admin/index
DEBUG - 2016-10-08 17:32:17 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 17:32:17 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 17:32:17 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 17:32:17 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/dashboard.php
DEBUG - 2016-10-08 17:32:17 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 17:32:17 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 17:32:17 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:17 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:17 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:17 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:17 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:17 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:17 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:17 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:17 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:19 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:19 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:19 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:19 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:19 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:19 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:19 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:19 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:19 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:19 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:19 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:19 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:19 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:19 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:19 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:19 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:19 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:19 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:19 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:20 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:20 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:20 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:20 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:20 --> Database Driver Class Initialized
INFO - 2016-10-08 17:32:20 --> Database Driver Class Initialized
DEBUG - 2016-10-08 17:32:20 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 17:32:20 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 17:32:20 --> Final output sent to browser
DEBUG - 2016-10-08 17:32:20 --> Total execution time: 3.9545
INFO - 2016-10-08 17:44:08 --> Config Class Initialized
INFO - 2016-10-08 17:44:08 --> Hooks Class Initialized
DEBUG - 2016-10-08 17:44:08 --> UTF-8 Support Enabled
INFO - 2016-10-08 17:44:08 --> Utf8 Class Initialized
INFO - 2016-10-08 17:44:09 --> URI Class Initialized
INFO - 2016-10-08 17:44:09 --> Router Class Initialized
INFO - 2016-10-08 17:44:09 --> Output Class Initialized
INFO - 2016-10-08 17:44:09 --> Security Class Initialized
DEBUG - 2016-10-08 17:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 17:44:09 --> Input Class Initialized
INFO - 2016-10-08 17:44:09 --> Language Class Initialized
INFO - 2016-10-08 17:44:09 --> Language Class Initialized
INFO - 2016-10-08 17:44:09 --> Config Class Initialized
INFO - 2016-10-08 17:44:09 --> Loader Class Initialized
INFO - 2016-10-08 17:44:09 --> Helper loaded: url_helper
INFO - 2016-10-08 17:44:09 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 17:44:09 --> Controller Class Initialized
DEBUG - 2016-10-08 17:44:09 --> Index MX_Controller Initialized
INFO - 2016-10-08 17:44:09 --> Model Class Initialized
INFO - 2016-10-08 17:44:09 --> Model Class Initialized
ERROR - 2016-10-08 17:44:09 --> Unable to delete cache file for admin/index/tutup_angsuran
DEBUG - 2016-10-08 17:44:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 17:44:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 17:44:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 17:44:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_tutup_angsuran.php
DEBUG - 2016-10-08 17:44:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 17:44:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 17:44:09 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:11 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:11 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:11 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:11 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:11 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:11 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:11 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:11 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:11 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:11 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:11 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:11 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:11 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:11 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:11 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:11 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:11 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:11 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:11 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:11 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:12 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:12 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:12 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:12 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:12 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:12 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:12 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:12 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:12 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:12 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:12 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:12 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:12 --> Database Driver Class Initialized
DEBUG - 2016-10-08 17:44:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 17:44:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 17:44:12 --> Final output sent to browser
DEBUG - 2016-10-08 17:44:12 --> Total execution time: 4.0834
INFO - 2016-10-08 17:44:18 --> Config Class Initialized
INFO - 2016-10-08 17:44:18 --> Hooks Class Initialized
DEBUG - 2016-10-08 17:44:18 --> UTF-8 Support Enabled
INFO - 2016-10-08 17:44:18 --> Utf8 Class Initialized
INFO - 2016-10-08 17:44:18 --> URI Class Initialized
INFO - 2016-10-08 17:44:18 --> Router Class Initialized
INFO - 2016-10-08 17:44:18 --> Output Class Initialized
INFO - 2016-10-08 17:44:18 --> Security Class Initialized
DEBUG - 2016-10-08 17:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 17:44:18 --> Input Class Initialized
INFO - 2016-10-08 17:44:18 --> Language Class Initialized
INFO - 2016-10-08 17:44:18 --> Language Class Initialized
INFO - 2016-10-08 17:44:18 --> Config Class Initialized
INFO - 2016-10-08 17:44:18 --> Loader Class Initialized
INFO - 2016-10-08 17:44:18 --> Helper loaded: url_helper
INFO - 2016-10-08 17:44:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 17:44:19 --> Controller Class Initialized
DEBUG - 2016-10-08 17:44:19 --> Index MX_Controller Initialized
INFO - 2016-10-08 17:44:19 --> Model Class Initialized
INFO - 2016-10-08 17:44:19 --> Model Class Initialized
ERROR - 2016-10-08 17:44:19 --> Unable to delete cache file for admin/index/getDetailLunas
INFO - 2016-10-08 17:44:19 --> Final output sent to browser
DEBUG - 2016-10-08 17:44:19 --> Total execution time: 0.8770
INFO - 2016-10-08 17:44:24 --> Config Class Initialized
INFO - 2016-10-08 17:44:24 --> Hooks Class Initialized
DEBUG - 2016-10-08 17:44:24 --> UTF-8 Support Enabled
INFO - 2016-10-08 17:44:24 --> Utf8 Class Initialized
INFO - 2016-10-08 17:44:24 --> URI Class Initialized
INFO - 2016-10-08 17:44:24 --> Router Class Initialized
INFO - 2016-10-08 17:44:24 --> Output Class Initialized
INFO - 2016-10-08 17:44:24 --> Security Class Initialized
DEBUG - 2016-10-08 17:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 17:44:24 --> Input Class Initialized
INFO - 2016-10-08 17:44:24 --> Language Class Initialized
INFO - 2016-10-08 17:44:24 --> Language Class Initialized
INFO - 2016-10-08 17:44:24 --> Config Class Initialized
INFO - 2016-10-08 17:44:24 --> Loader Class Initialized
INFO - 2016-10-08 17:44:24 --> Helper loaded: url_helper
INFO - 2016-10-08 17:44:24 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 17:44:24 --> Controller Class Initialized
DEBUG - 2016-10-08 17:44:24 --> Index MX_Controller Initialized
INFO - 2016-10-08 17:44:24 --> Model Class Initialized
INFO - 2016-10-08 17:44:24 --> Model Class Initialized
ERROR - 2016-10-08 17:44:24 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-10-08 17:44:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 17:44:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 17:44:25 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 17:44:25 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-10-08 17:44:25 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 17:44:25 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 17:44:25 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:25 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:25 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:25 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:25 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:25 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:25 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:25 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:25 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:25 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:25 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:25 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:25 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:25 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:25 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:25 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:26 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:26 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:26 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:26 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:26 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:26 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:26 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:26 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:26 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:26 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:26 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:26 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:26 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:26 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:26 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:26 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:26 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:26 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:27 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:27 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:27 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:27 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:27 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:27 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:27 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:27 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:27 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:27 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:27 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:27 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:27 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:27 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:27 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:27 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:27 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:27 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:27 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:27 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:27 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:28 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:28 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:28 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:28 --> Database Driver Class Initialized
DEBUG - 2016-10-08 17:44:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 17:44:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 17:44:28 --> Final output sent to browser
DEBUG - 2016-10-08 17:44:28 --> Total execution time: 4.3553
INFO - 2016-10-08 17:44:34 --> Config Class Initialized
INFO - 2016-10-08 17:44:34 --> Hooks Class Initialized
DEBUG - 2016-10-08 17:44:34 --> UTF-8 Support Enabled
INFO - 2016-10-08 17:44:34 --> Utf8 Class Initialized
INFO - 2016-10-08 17:44:34 --> URI Class Initialized
INFO - 2016-10-08 17:44:34 --> Router Class Initialized
INFO - 2016-10-08 17:44:34 --> Output Class Initialized
INFO - 2016-10-08 17:44:34 --> Security Class Initialized
DEBUG - 2016-10-08 17:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 17:44:34 --> Input Class Initialized
INFO - 2016-10-08 17:44:34 --> Language Class Initialized
INFO - 2016-10-08 17:44:34 --> Language Class Initialized
INFO - 2016-10-08 17:44:34 --> Config Class Initialized
INFO - 2016-10-08 17:44:34 --> Loader Class Initialized
INFO - 2016-10-08 17:44:34 --> Helper loaded: url_helper
INFO - 2016-10-08 17:44:34 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 17:44:35 --> Controller Class Initialized
DEBUG - 2016-10-08 17:44:35 --> Index MX_Controller Initialized
INFO - 2016-10-08 17:44:35 --> Model Class Initialized
INFO - 2016-10-08 17:44:35 --> Model Class Initialized
ERROR - 2016-10-08 17:44:35 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-08 17:44:35 --> Anggota MX_Controller Initialized
INFO - 2016-10-08 17:44:35 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:35 --> Final output sent to browser
DEBUG - 2016-10-08 17:44:35 --> Total execution time: 1.1794
INFO - 2016-10-08 17:44:43 --> Config Class Initialized
INFO - 2016-10-08 17:44:43 --> Hooks Class Initialized
DEBUG - 2016-10-08 17:44:43 --> UTF-8 Support Enabled
INFO - 2016-10-08 17:44:43 --> Utf8 Class Initialized
INFO - 2016-10-08 17:44:43 --> URI Class Initialized
INFO - 2016-10-08 17:44:43 --> Router Class Initialized
INFO - 2016-10-08 17:44:43 --> Output Class Initialized
INFO - 2016-10-08 17:44:43 --> Security Class Initialized
DEBUG - 2016-10-08 17:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 17:44:43 --> Input Class Initialized
INFO - 2016-10-08 17:44:44 --> Language Class Initialized
INFO - 2016-10-08 17:44:44 --> Language Class Initialized
INFO - 2016-10-08 17:44:44 --> Config Class Initialized
INFO - 2016-10-08 17:44:44 --> Loader Class Initialized
INFO - 2016-10-08 17:44:44 --> Helper loaded: url_helper
INFO - 2016-10-08 17:44:44 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 17:44:44 --> Controller Class Initialized
DEBUG - 2016-10-08 17:44:44 --> Index MX_Controller Initialized
INFO - 2016-10-08 17:44:44 --> Model Class Initialized
INFO - 2016-10-08 17:44:44 --> Model Class Initialized
ERROR - 2016-10-08 17:44:44 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-10-08 17:44:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 17:44:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 17:44:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 17:44:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_umum.php
DEBUG - 2016-10-08 17:44:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 17:44:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 17:44:44 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:44 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:44 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:44 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:44 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:45 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:45 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:45 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:45 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:45 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:45 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:45 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:45 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:45 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:45 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:45 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:45 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:45 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:45 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:45 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:45 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:45 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:45 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:46 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:46 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:46 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:46 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:46 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:46 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:46 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:46 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:46 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:46 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:46 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:46 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:46 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:46 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:46 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:46 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:46 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:46 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:46 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:46 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:47 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:47 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:47 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:47 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:47 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:47 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:47 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:47 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:47 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:47 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:47 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:47 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:47 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:47 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:47 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:47 --> Database Driver Class Initialized
INFO - 2016-10-08 17:44:47 --> Database Driver Class Initialized
DEBUG - 2016-10-08 17:44:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 17:44:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 17:44:47 --> Final output sent to browser
DEBUG - 2016-10-08 17:44:48 --> Total execution time: 4.3623
INFO - 2016-10-08 17:45:17 --> Config Class Initialized
INFO - 2016-10-08 17:45:17 --> Hooks Class Initialized
DEBUG - 2016-10-08 17:45:17 --> UTF-8 Support Enabled
INFO - 2016-10-08 17:45:17 --> Utf8 Class Initialized
INFO - 2016-10-08 17:45:17 --> URI Class Initialized
INFO - 2016-10-08 17:45:17 --> Router Class Initialized
INFO - 2016-10-08 17:45:17 --> Output Class Initialized
INFO - 2016-10-08 17:45:17 --> Security Class Initialized
DEBUG - 2016-10-08 17:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 17:45:17 --> Input Class Initialized
INFO - 2016-10-08 17:45:17 --> Language Class Initialized
INFO - 2016-10-08 17:45:17 --> Language Class Initialized
INFO - 2016-10-08 17:45:17 --> Config Class Initialized
INFO - 2016-10-08 17:45:17 --> Loader Class Initialized
INFO - 2016-10-08 17:45:17 --> Helper loaded: url_helper
INFO - 2016-10-08 17:45:17 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 17:45:17 --> Controller Class Initialized
DEBUG - 2016-10-08 17:45:17 --> Index MX_Controller Initialized
INFO - 2016-10-08 17:45:17 --> Model Class Initialized
INFO - 2016-10-08 17:45:18 --> Model Class Initialized
ERROR - 2016-10-08 17:45:18 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-10-08 17:45:18 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 17:45:18 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 17:45:18 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 17:45:18 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_umum.php
DEBUG - 2016-10-08 17:45:18 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 17:45:18 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 17:45:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:19 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:19 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:19 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:19 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:19 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:19 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:19 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:19 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:19 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:19 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:19 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:19 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:19 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:19 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:19 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:19 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:19 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:19 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:19 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:19 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:19 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:19 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:20 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:20 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:20 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:20 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:20 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:20 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:20 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:20 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:20 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:20 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:20 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:20 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:20 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:20 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:20 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:20 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:20 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:20 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:20 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:21 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:21 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:21 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:21 --> Database Driver Class Initialized
DEBUG - 2016-10-08 17:45:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 17:45:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 17:45:21 --> Final output sent to browser
DEBUG - 2016-10-08 17:45:21 --> Total execution time: 4.1630
INFO - 2016-10-08 17:45:43 --> Config Class Initialized
INFO - 2016-10-08 17:45:43 --> Hooks Class Initialized
DEBUG - 2016-10-08 17:45:43 --> UTF-8 Support Enabled
INFO - 2016-10-08 17:45:43 --> Utf8 Class Initialized
INFO - 2016-10-08 17:45:43 --> URI Class Initialized
INFO - 2016-10-08 17:45:43 --> Router Class Initialized
INFO - 2016-10-08 17:45:43 --> Output Class Initialized
INFO - 2016-10-08 17:45:43 --> Security Class Initialized
DEBUG - 2016-10-08 17:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 17:45:43 --> Input Class Initialized
INFO - 2016-10-08 17:45:43 --> Language Class Initialized
INFO - 2016-10-08 17:45:43 --> Language Class Initialized
INFO - 2016-10-08 17:45:43 --> Config Class Initialized
INFO - 2016-10-08 17:45:43 --> Loader Class Initialized
INFO - 2016-10-08 17:45:43 --> Helper loaded: url_helper
INFO - 2016-10-08 17:45:43 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 17:45:43 --> Controller Class Initialized
DEBUG - 2016-10-08 17:45:43 --> Index MX_Controller Initialized
INFO - 2016-10-08 17:45:44 --> Model Class Initialized
INFO - 2016-10-08 17:45:44 --> Model Class Initialized
ERROR - 2016-10-08 17:45:44 --> Unable to delete cache file for admin/index/proses_peminjaman
INFO - 2016-10-08 17:45:44 --> Final output sent to browser
DEBUG - 2016-10-08 17:45:44 --> Total execution time: 0.9933
INFO - 2016-10-08 17:45:44 --> Config Class Initialized
INFO - 2016-10-08 17:45:44 --> Hooks Class Initialized
DEBUG - 2016-10-08 17:45:44 --> UTF-8 Support Enabled
INFO - 2016-10-08 17:45:44 --> Utf8 Class Initialized
INFO - 2016-10-08 17:45:44 --> URI Class Initialized
INFO - 2016-10-08 17:45:44 --> Router Class Initialized
INFO - 2016-10-08 17:45:44 --> Output Class Initialized
INFO - 2016-10-08 17:45:44 --> Security Class Initialized
DEBUG - 2016-10-08 17:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 17:45:44 --> Input Class Initialized
INFO - 2016-10-08 17:45:44 --> Language Class Initialized
INFO - 2016-10-08 17:45:44 --> Language Class Initialized
INFO - 2016-10-08 17:45:44 --> Config Class Initialized
INFO - 2016-10-08 17:45:44 --> Loader Class Initialized
INFO - 2016-10-08 17:45:44 --> Helper loaded: url_helper
INFO - 2016-10-08 17:45:45 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 17:45:45 --> Controller Class Initialized
DEBUG - 2016-10-08 17:45:45 --> Index MX_Controller Initialized
INFO - 2016-10-08 17:45:45 --> Model Class Initialized
INFO - 2016-10-08 17:45:45 --> Model Class Initialized
ERROR - 2016-10-08 17:45:45 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-10-08 17:45:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 17:45:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 17:45:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 17:45:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-10-08 17:45:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 17:45:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 17:45:45 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:45 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:45 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:45 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:45 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:45 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:45 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:45 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:46 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:46 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:46 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:46 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:46 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:46 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:46 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:46 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:46 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:46 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:46 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:46 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:46 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:46 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:46 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:46 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:46 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:46 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:47 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:47 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:47 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:47 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:47 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:47 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:47 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:47 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:47 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:47 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:47 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:47 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:47 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:47 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:47 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:47 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:47 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:47 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:47 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:47 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:48 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:48 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:48 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:48 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:48 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:48 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:48 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:48 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:48 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:48 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:48 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:48 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:48 --> Database Driver Class Initialized
DEBUG - 2016-10-08 17:45:48 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 17:45:48 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 17:45:48 --> Final output sent to browser
DEBUG - 2016-10-08 17:45:48 --> Total execution time: 4.4215
INFO - 2016-10-08 17:45:56 --> Config Class Initialized
INFO - 2016-10-08 17:45:56 --> Hooks Class Initialized
DEBUG - 2016-10-08 17:45:56 --> UTF-8 Support Enabled
INFO - 2016-10-08 17:45:56 --> Utf8 Class Initialized
INFO - 2016-10-08 17:45:56 --> URI Class Initialized
INFO - 2016-10-08 17:45:56 --> Router Class Initialized
INFO - 2016-10-08 17:45:56 --> Output Class Initialized
INFO - 2016-10-08 17:45:57 --> Security Class Initialized
DEBUG - 2016-10-08 17:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 17:45:57 --> Input Class Initialized
INFO - 2016-10-08 17:45:57 --> Language Class Initialized
INFO - 2016-10-08 17:45:57 --> Language Class Initialized
INFO - 2016-10-08 17:45:57 --> Config Class Initialized
INFO - 2016-10-08 17:45:57 --> Loader Class Initialized
INFO - 2016-10-08 17:45:57 --> Helper loaded: url_helper
INFO - 2016-10-08 17:45:57 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 17:45:57 --> Controller Class Initialized
DEBUG - 2016-10-08 17:45:57 --> Index MX_Controller Initialized
INFO - 2016-10-08 17:45:57 --> Model Class Initialized
INFO - 2016-10-08 17:45:57 --> Model Class Initialized
ERROR - 2016-10-08 17:45:57 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-08 17:45:57 --> Anggota MX_Controller Initialized
INFO - 2016-10-08 17:45:57 --> Database Driver Class Initialized
INFO - 2016-10-08 17:45:57 --> Final output sent to browser
DEBUG - 2016-10-08 17:45:57 --> Total execution time: 1.0612
INFO - 2016-10-08 17:46:07 --> Config Class Initialized
INFO - 2016-10-08 17:46:07 --> Hooks Class Initialized
DEBUG - 2016-10-08 17:46:07 --> UTF-8 Support Enabled
INFO - 2016-10-08 17:46:07 --> Utf8 Class Initialized
INFO - 2016-10-08 17:46:07 --> URI Class Initialized
INFO - 2016-10-08 17:46:07 --> Router Class Initialized
INFO - 2016-10-08 17:46:07 --> Output Class Initialized
INFO - 2016-10-08 17:46:07 --> Security Class Initialized
DEBUG - 2016-10-08 17:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 17:46:07 --> Input Class Initialized
INFO - 2016-10-08 17:46:07 --> Language Class Initialized
INFO - 2016-10-08 17:46:07 --> Language Class Initialized
INFO - 2016-10-08 17:46:07 --> Config Class Initialized
INFO - 2016-10-08 17:46:08 --> Loader Class Initialized
INFO - 2016-10-08 17:46:08 --> Helper loaded: url_helper
INFO - 2016-10-08 17:46:08 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 17:46:08 --> Controller Class Initialized
DEBUG - 2016-10-08 17:46:08 --> Index MX_Controller Initialized
INFO - 2016-10-08 17:46:08 --> Model Class Initialized
INFO - 2016-10-08 17:46:08 --> Model Class Initialized
ERROR - 2016-10-08 17:46:08 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-10-08 17:46:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 17:46:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 17:46:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 17:46:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_umum.php
DEBUG - 2016-10-08 17:46:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 17:46:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 17:46:08 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:09 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:09 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:09 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:09 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:09 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:09 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:09 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:09 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:09 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:09 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:09 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:09 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:09 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:09 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:09 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:09 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:09 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:09 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:09 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:09 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:09 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:11 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:11 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:11 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:11 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:11 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:11 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:11 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:11 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:11 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:11 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:11 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:11 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:11 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:11 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:11 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:11 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:11 --> Database Driver Class Initialized
DEBUG - 2016-10-08 17:46:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 17:46:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 17:46:11 --> Final output sent to browser
DEBUG - 2016-10-08 17:46:11 --> Total execution time: 4.5565
INFO - 2016-10-08 17:46:30 --> Config Class Initialized
INFO - 2016-10-08 17:46:30 --> Hooks Class Initialized
DEBUG - 2016-10-08 17:46:30 --> UTF-8 Support Enabled
INFO - 2016-10-08 17:46:30 --> Utf8 Class Initialized
INFO - 2016-10-08 17:46:30 --> URI Class Initialized
INFO - 2016-10-08 17:46:30 --> Router Class Initialized
INFO - 2016-10-08 17:46:30 --> Output Class Initialized
INFO - 2016-10-08 17:46:30 --> Security Class Initialized
DEBUG - 2016-10-08 17:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 17:46:30 --> Input Class Initialized
INFO - 2016-10-08 17:46:30 --> Language Class Initialized
INFO - 2016-10-08 17:46:30 --> Language Class Initialized
INFO - 2016-10-08 17:46:30 --> Config Class Initialized
INFO - 2016-10-08 17:46:30 --> Loader Class Initialized
INFO - 2016-10-08 17:46:30 --> Helper loaded: url_helper
INFO - 2016-10-08 17:46:30 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 17:46:31 --> Controller Class Initialized
DEBUG - 2016-10-08 17:46:31 --> Index MX_Controller Initialized
INFO - 2016-10-08 17:46:31 --> Model Class Initialized
INFO - 2016-10-08 17:46:31 --> Model Class Initialized
ERROR - 2016-10-08 17:46:31 --> Unable to delete cache file for admin/index/proses_peminjaman
INFO - 2016-10-08 17:46:31 --> Final output sent to browser
DEBUG - 2016-10-08 17:46:31 --> Total execution time: 1.0629
INFO - 2016-10-08 17:46:31 --> Config Class Initialized
INFO - 2016-10-08 17:46:31 --> Hooks Class Initialized
DEBUG - 2016-10-08 17:46:31 --> UTF-8 Support Enabled
INFO - 2016-10-08 17:46:31 --> Utf8 Class Initialized
INFO - 2016-10-08 17:46:31 --> URI Class Initialized
INFO - 2016-10-08 17:46:31 --> Router Class Initialized
INFO - 2016-10-08 17:46:31 --> Output Class Initialized
INFO - 2016-10-08 17:46:31 --> Security Class Initialized
DEBUG - 2016-10-08 17:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 17:46:31 --> Input Class Initialized
INFO - 2016-10-08 17:46:31 --> Language Class Initialized
INFO - 2016-10-08 17:46:32 --> Language Class Initialized
INFO - 2016-10-08 17:46:32 --> Config Class Initialized
INFO - 2016-10-08 17:46:32 --> Loader Class Initialized
INFO - 2016-10-08 17:46:32 --> Helper loaded: url_helper
INFO - 2016-10-08 17:46:32 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 17:46:32 --> Controller Class Initialized
DEBUG - 2016-10-08 17:46:32 --> Index MX_Controller Initialized
INFO - 2016-10-08 17:46:32 --> Model Class Initialized
INFO - 2016-10-08 17:46:32 --> Model Class Initialized
ERROR - 2016-10-08 17:46:32 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-10-08 17:46:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 17:46:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 17:46:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 17:46:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-10-08 17:46:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 17:46:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 17:46:32 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:32 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:33 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:33 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:33 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:33 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:33 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:33 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:33 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:33 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:33 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:33 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:33 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:33 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:33 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:33 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:33 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:33 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:33 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:33 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:33 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:33 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:34 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:34 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:34 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:34 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:34 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:34 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:34 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:34 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:34 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:34 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:34 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:34 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:34 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:34 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:34 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:35 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:35 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:35 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:35 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:35 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:35 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:35 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:35 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:35 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:35 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:35 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:35 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:35 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:35 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:35 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:36 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:36 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:36 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:36 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:36 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:36 --> Database Driver Class Initialized
INFO - 2016-10-08 17:46:36 --> Database Driver Class Initialized
DEBUG - 2016-10-08 17:46:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 17:46:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 17:46:36 --> Final output sent to browser
DEBUG - 2016-10-08 17:46:36 --> Total execution time: 5.0633
INFO - 2016-10-08 17:47:02 --> Config Class Initialized
INFO - 2016-10-08 17:47:02 --> Hooks Class Initialized
DEBUG - 2016-10-08 17:47:02 --> UTF-8 Support Enabled
INFO - 2016-10-08 17:47:02 --> Utf8 Class Initialized
INFO - 2016-10-08 17:47:02 --> URI Class Initialized
INFO - 2016-10-08 17:47:02 --> Router Class Initialized
INFO - 2016-10-08 17:47:03 --> Output Class Initialized
INFO - 2016-10-08 17:47:03 --> Security Class Initialized
DEBUG - 2016-10-08 17:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 17:47:03 --> Input Class Initialized
INFO - 2016-10-08 17:47:03 --> Language Class Initialized
INFO - 2016-10-08 17:47:03 --> Language Class Initialized
INFO - 2016-10-08 17:47:03 --> Config Class Initialized
INFO - 2016-10-08 17:47:03 --> Loader Class Initialized
INFO - 2016-10-08 17:47:03 --> Helper loaded: url_helper
INFO - 2016-10-08 17:47:03 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 17:47:03 --> Controller Class Initialized
DEBUG - 2016-10-08 17:47:03 --> Index MX_Controller Initialized
INFO - 2016-10-08 17:47:03 --> Model Class Initialized
INFO - 2016-10-08 17:47:03 --> Model Class Initialized
ERROR - 2016-10-08 17:47:03 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-08 17:47:03 --> Anggota MX_Controller Initialized
INFO - 2016-10-08 17:47:03 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:03 --> Final output sent to browser
DEBUG - 2016-10-08 17:47:03 --> Total execution time: 1.0147
INFO - 2016-10-08 17:47:14 --> Config Class Initialized
INFO - 2016-10-08 17:47:14 --> Hooks Class Initialized
DEBUG - 2016-10-08 17:47:14 --> UTF-8 Support Enabled
INFO - 2016-10-08 17:47:14 --> Utf8 Class Initialized
INFO - 2016-10-08 17:47:14 --> URI Class Initialized
INFO - 2016-10-08 17:47:14 --> Router Class Initialized
INFO - 2016-10-08 17:47:14 --> Output Class Initialized
INFO - 2016-10-08 17:47:14 --> Security Class Initialized
DEBUG - 2016-10-08 17:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 17:47:14 --> Input Class Initialized
INFO - 2016-10-08 17:47:14 --> Language Class Initialized
INFO - 2016-10-08 17:47:14 --> Language Class Initialized
INFO - 2016-10-08 17:47:14 --> Config Class Initialized
INFO - 2016-10-08 17:47:14 --> Loader Class Initialized
INFO - 2016-10-08 17:47:14 --> Helper loaded: url_helper
INFO - 2016-10-08 17:47:14 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 17:47:14 --> Controller Class Initialized
DEBUG - 2016-10-08 17:47:14 --> Index MX_Controller Initialized
INFO - 2016-10-08 17:47:15 --> Model Class Initialized
INFO - 2016-10-08 17:47:15 --> Model Class Initialized
ERROR - 2016-10-08 17:47:15 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-10-08 17:47:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 17:47:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 17:47:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 17:47:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_umum.php
DEBUG - 2016-10-08 17:47:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 17:47:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 17:47:15 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:15 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:15 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:15 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:15 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:15 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:15 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:15 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:15 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:15 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:16 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:16 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:16 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:16 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:16 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:16 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:16 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:16 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:16 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:16 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:16 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:16 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:16 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:17 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:17 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:17 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:17 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:17 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:17 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:17 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:17 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:17 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:17 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:17 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:17 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:17 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:17 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:17 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:18 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:19 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:19 --> Database Driver Class Initialized
INFO - 2016-10-08 17:47:19 --> Database Driver Class Initialized
DEBUG - 2016-10-08 17:47:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 17:47:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 17:47:19 --> Final output sent to browser
DEBUG - 2016-10-08 17:47:19 --> Total execution time: 5.2190
INFO - 2016-10-08 17:48:28 --> Config Class Initialized
INFO - 2016-10-08 17:48:28 --> Hooks Class Initialized
DEBUG - 2016-10-08 17:48:28 --> UTF-8 Support Enabled
INFO - 2016-10-08 17:48:28 --> Utf8 Class Initialized
INFO - 2016-10-08 17:48:28 --> URI Class Initialized
INFO - 2016-10-08 17:48:28 --> Router Class Initialized
INFO - 2016-10-08 17:48:28 --> Output Class Initialized
INFO - 2016-10-08 17:48:28 --> Security Class Initialized
DEBUG - 2016-10-08 17:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 17:48:28 --> Input Class Initialized
INFO - 2016-10-08 17:48:28 --> Language Class Initialized
INFO - 2016-10-08 17:48:28 --> Language Class Initialized
INFO - 2016-10-08 17:48:28 --> Config Class Initialized
INFO - 2016-10-08 17:48:28 --> Loader Class Initialized
INFO - 2016-10-08 17:48:28 --> Helper loaded: url_helper
INFO - 2016-10-08 17:48:28 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 17:48:28 --> Controller Class Initialized
DEBUG - 2016-10-08 17:48:28 --> Index MX_Controller Initialized
INFO - 2016-10-08 17:48:28 --> Model Class Initialized
INFO - 2016-10-08 17:48:29 --> Model Class Initialized
ERROR - 2016-10-08 17:48:29 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-10-08 17:48:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 17:48:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 17:48:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 17:48:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-10-08 17:48:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 17:48:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 17:48:29 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:29 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:29 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:29 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:29 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:29 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:29 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:29 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:29 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:29 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:29 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:29 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:30 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:30 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:30 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:30 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:30 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:30 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:30 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:30 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:30 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:30 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:30 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:30 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:30 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:30 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:30 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:30 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:30 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:30 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:30 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:30 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:30 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:30 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:31 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:31 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:31 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:31 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:31 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:31 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:31 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:31 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:31 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:31 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:31 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:31 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:31 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:31 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:31 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:31 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:31 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:31 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:31 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:31 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:31 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:32 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:32 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:32 --> Database Driver Class Initialized
INFO - 2016-10-08 17:48:32 --> Database Driver Class Initialized
DEBUG - 2016-10-08 17:48:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 17:48:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 17:48:32 --> Final output sent to browser
DEBUG - 2016-10-08 17:48:32 --> Total execution time: 4.2364
INFO - 2016-10-08 17:49:01 --> Config Class Initialized
INFO - 2016-10-08 17:49:01 --> Hooks Class Initialized
DEBUG - 2016-10-08 17:49:01 --> UTF-8 Support Enabled
INFO - 2016-10-08 17:49:01 --> Utf8 Class Initialized
INFO - 2016-10-08 17:49:01 --> URI Class Initialized
INFO - 2016-10-08 17:49:02 --> Router Class Initialized
INFO - 2016-10-08 17:49:02 --> Output Class Initialized
INFO - 2016-10-08 17:49:02 --> Security Class Initialized
DEBUG - 2016-10-08 17:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 17:49:02 --> Input Class Initialized
INFO - 2016-10-08 17:49:02 --> Language Class Initialized
INFO - 2016-10-08 17:49:02 --> Language Class Initialized
INFO - 2016-10-08 17:49:02 --> Config Class Initialized
INFO - 2016-10-08 17:49:02 --> Loader Class Initialized
INFO - 2016-10-08 17:49:02 --> Helper loaded: url_helper
INFO - 2016-10-08 17:49:02 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 17:49:02 --> Controller Class Initialized
DEBUG - 2016-10-08 17:49:02 --> Index MX_Controller Initialized
INFO - 2016-10-08 17:49:02 --> Model Class Initialized
INFO - 2016-10-08 17:49:02 --> Model Class Initialized
ERROR - 2016-10-08 17:49:02 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-08 17:49:02 --> Anggota MX_Controller Initialized
INFO - 2016-10-08 17:49:02 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:02 --> Final output sent to browser
DEBUG - 2016-10-08 17:49:03 --> Total execution time: 1.2755
INFO - 2016-10-08 17:49:06 --> Config Class Initialized
INFO - 2016-10-08 17:49:06 --> Hooks Class Initialized
DEBUG - 2016-10-08 17:49:06 --> UTF-8 Support Enabled
INFO - 2016-10-08 17:49:06 --> Utf8 Class Initialized
INFO - 2016-10-08 17:49:07 --> URI Class Initialized
INFO - 2016-10-08 17:49:07 --> Router Class Initialized
INFO - 2016-10-08 17:49:07 --> Output Class Initialized
INFO - 2016-10-08 17:49:07 --> Security Class Initialized
DEBUG - 2016-10-08 17:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 17:49:07 --> Input Class Initialized
INFO - 2016-10-08 17:49:07 --> Language Class Initialized
INFO - 2016-10-08 17:49:07 --> Language Class Initialized
INFO - 2016-10-08 17:49:07 --> Config Class Initialized
INFO - 2016-10-08 17:49:07 --> Loader Class Initialized
INFO - 2016-10-08 17:49:07 --> Helper loaded: url_helper
INFO - 2016-10-08 17:49:07 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 17:49:07 --> Controller Class Initialized
DEBUG - 2016-10-08 17:49:07 --> Index MX_Controller Initialized
INFO - 2016-10-08 17:49:07 --> Model Class Initialized
INFO - 2016-10-08 17:49:07 --> Model Class Initialized
ERROR - 2016-10-08 17:49:07 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-10-08 17:49:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 17:49:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 17:49:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 17:49:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_umum.php
DEBUG - 2016-10-08 17:49:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 17:49:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 17:49:08 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:08 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:08 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:08 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:08 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:08 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:08 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:08 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:08 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:08 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:08 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:08 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:08 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:08 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:08 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:08 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:08 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:09 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:09 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:09 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:09 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:09 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:09 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:09 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:09 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:09 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:09 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:09 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:09 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:09 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:09 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:09 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:09 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:09 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:09 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:09 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:09 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:09 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:10 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:11 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:11 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:11 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:11 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:11 --> Database Driver Class Initialized
DEBUG - 2016-10-08 17:49:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 17:49:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 17:49:11 --> Final output sent to browser
DEBUG - 2016-10-08 17:49:11 --> Total execution time: 4.6202
INFO - 2016-10-08 17:49:52 --> Config Class Initialized
INFO - 2016-10-08 17:49:52 --> Hooks Class Initialized
DEBUG - 2016-10-08 17:49:52 --> UTF-8 Support Enabled
INFO - 2016-10-08 17:49:52 --> Utf8 Class Initialized
INFO - 2016-10-08 17:49:53 --> URI Class Initialized
INFO - 2016-10-08 17:49:53 --> Router Class Initialized
INFO - 2016-10-08 17:49:53 --> Output Class Initialized
INFO - 2016-10-08 17:49:53 --> Security Class Initialized
DEBUG - 2016-10-08 17:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 17:49:53 --> Input Class Initialized
INFO - 2016-10-08 17:49:53 --> Language Class Initialized
INFO - 2016-10-08 17:49:53 --> Language Class Initialized
INFO - 2016-10-08 17:49:53 --> Config Class Initialized
INFO - 2016-10-08 17:49:53 --> Loader Class Initialized
INFO - 2016-10-08 17:49:53 --> Helper loaded: url_helper
INFO - 2016-10-08 17:49:53 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 17:49:53 --> Controller Class Initialized
DEBUG - 2016-10-08 17:49:53 --> Index MX_Controller Initialized
INFO - 2016-10-08 17:49:53 --> Model Class Initialized
INFO - 2016-10-08 17:49:53 --> Model Class Initialized
ERROR - 2016-10-08 17:49:53 --> Unable to delete cache file for admin/index/do_ajukan_pinjaman
INFO - 2016-10-08 17:49:53 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:54 --> Database Driver Class Initialized
INFO - 2016-10-08 17:49:54 --> Final output sent to browser
DEBUG - 2016-10-08 17:49:54 --> Total execution time: 1.1886
INFO - 2016-10-08 18:00:25 --> Config Class Initialized
INFO - 2016-10-08 18:00:25 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:00:25 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:00:25 --> Utf8 Class Initialized
INFO - 2016-10-08 18:00:25 --> URI Class Initialized
INFO - 2016-10-08 18:00:25 --> Router Class Initialized
INFO - 2016-10-08 18:00:25 --> Output Class Initialized
INFO - 2016-10-08 18:00:25 --> Security Class Initialized
DEBUG - 2016-10-08 18:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:00:25 --> Input Class Initialized
INFO - 2016-10-08 18:00:25 --> Language Class Initialized
INFO - 2016-10-08 18:00:26 --> Language Class Initialized
INFO - 2016-10-08 18:00:26 --> Config Class Initialized
INFO - 2016-10-08 18:00:26 --> Loader Class Initialized
INFO - 2016-10-08 18:00:26 --> Helper loaded: url_helper
INFO - 2016-10-08 18:00:26 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 18:00:26 --> Controller Class Initialized
DEBUG - 2016-10-08 18:00:26 --> Index MX_Controller Initialized
INFO - 2016-10-08 18:00:26 --> Model Class Initialized
INFO - 2016-10-08 18:00:26 --> Model Class Initialized
ERROR - 2016-10-08 18:00:26 --> Unable to delete cache file for admin/index/batal/da4b9237bacccdf19c0760cab7aec4a8359010b0
INFO - 2016-10-08 18:00:26 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:26 --> Final output sent to browser
DEBUG - 2016-10-08 18:00:26 --> Total execution time: 1.1767
INFO - 2016-10-08 18:00:35 --> Config Class Initialized
INFO - 2016-10-08 18:00:35 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:00:35 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:00:35 --> Utf8 Class Initialized
INFO - 2016-10-08 18:00:35 --> URI Class Initialized
INFO - 2016-10-08 18:00:35 --> Router Class Initialized
INFO - 2016-10-08 18:00:35 --> Output Class Initialized
INFO - 2016-10-08 18:00:35 --> Security Class Initialized
DEBUG - 2016-10-08 18:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:00:35 --> Input Class Initialized
INFO - 2016-10-08 18:00:35 --> Language Class Initialized
INFO - 2016-10-08 18:00:36 --> Language Class Initialized
INFO - 2016-10-08 18:00:36 --> Config Class Initialized
INFO - 2016-10-08 18:00:36 --> Loader Class Initialized
INFO - 2016-10-08 18:00:36 --> Helper loaded: url_helper
INFO - 2016-10-08 18:00:36 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 18:00:36 --> Controller Class Initialized
DEBUG - 2016-10-08 18:00:36 --> Index MX_Controller Initialized
INFO - 2016-10-08 18:00:36 --> Model Class Initialized
INFO - 2016-10-08 18:00:36 --> Model Class Initialized
ERROR - 2016-10-08 18:00:36 --> Unable to delete cache file for admin/index
DEBUG - 2016-10-08 18:00:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 18:00:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 18:00:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 18:00:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/dashboard.php
DEBUG - 2016-10-08 18:00:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 18:00:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 18:00:36 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:36 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:36 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:36 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:36 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:36 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:36 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:36 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:37 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:37 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:37 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:37 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:37 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:37 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:37 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:37 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:37 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:37 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:37 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:37 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:37 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:37 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:37 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:37 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:37 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:37 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:37 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:37 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:37 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:37 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:38 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:38 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:38 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:38 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:38 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:38 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:38 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:38 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:38 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:38 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:38 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:38 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:38 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:38 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:38 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:38 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:38 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:38 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:38 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:39 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:39 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:39 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:39 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:39 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:39 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:39 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:39 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:39 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:39 --> Database Driver Class Initialized
DEBUG - 2016-10-08 18:00:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 18:00:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 18:00:39 --> Final output sent to browser
DEBUG - 2016-10-08 18:00:40 --> Total execution time: 4.3642
INFO - 2016-10-08 18:00:50 --> Config Class Initialized
INFO - 2016-10-08 18:00:50 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:00:50 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:00:50 --> Utf8 Class Initialized
INFO - 2016-10-08 18:00:50 --> URI Class Initialized
INFO - 2016-10-08 18:00:50 --> Router Class Initialized
INFO - 2016-10-08 18:00:50 --> Output Class Initialized
INFO - 2016-10-08 18:00:50 --> Security Class Initialized
DEBUG - 2016-10-08 18:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:00:50 --> Input Class Initialized
INFO - 2016-10-08 18:00:50 --> Language Class Initialized
INFO - 2016-10-08 18:00:50 --> Language Class Initialized
INFO - 2016-10-08 18:00:50 --> Config Class Initialized
INFO - 2016-10-08 18:00:50 --> Loader Class Initialized
INFO - 2016-10-08 18:00:50 --> Helper loaded: url_helper
INFO - 2016-10-08 18:00:50 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 18:00:51 --> Controller Class Initialized
DEBUG - 2016-10-08 18:00:51 --> Index MX_Controller Initialized
INFO - 2016-10-08 18:00:51 --> Model Class Initialized
INFO - 2016-10-08 18:00:51 --> Model Class Initialized
ERROR - 2016-10-08 18:00:51 --> Unable to delete cache file for admin/index/data_peminjam
DEBUG - 2016-10-08 18:00:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 18:00:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 18:00:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 18:00:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_peminjam.php
DEBUG - 2016-10-08 18:00:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 18:00:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 18:00:51 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:51 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:51 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:51 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:51 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:51 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:51 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:51 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:51 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:51 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:52 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:52 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:52 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:52 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:52 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:52 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:52 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:52 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:52 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:52 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:52 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:52 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:52 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:52 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:52 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:52 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:52 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:52 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:52 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:52 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:52 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:53 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:53 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:53 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:53 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:53 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:53 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:53 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:53 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:53 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:53 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:53 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:53 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:53 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:53 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:53 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:53 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:53 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:53 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:53 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:53 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:54 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:54 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:54 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:54 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:54 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:54 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:54 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:54 --> Database Driver Class Initialized
DEBUG - 2016-10-08 18:00:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 18:00:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 18:00:54 --> Final output sent to browser
DEBUG - 2016-10-08 18:00:54 --> Total execution time: 4.5134
INFO - 2016-10-08 18:00:57 --> Config Class Initialized
INFO - 2016-10-08 18:00:57 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:00:57 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:00:57 --> Utf8 Class Initialized
INFO - 2016-10-08 18:00:57 --> URI Class Initialized
INFO - 2016-10-08 18:00:57 --> Router Class Initialized
INFO - 2016-10-08 18:00:57 --> Output Class Initialized
INFO - 2016-10-08 18:00:57 --> Security Class Initialized
DEBUG - 2016-10-08 18:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:00:57 --> Input Class Initialized
INFO - 2016-10-08 18:00:58 --> Language Class Initialized
INFO - 2016-10-08 18:00:58 --> Language Class Initialized
INFO - 2016-10-08 18:00:58 --> Config Class Initialized
INFO - 2016-10-08 18:00:58 --> Loader Class Initialized
INFO - 2016-10-08 18:00:58 --> Helper loaded: url_helper
INFO - 2016-10-08 18:00:58 --> Database Driver Class Initialized
INFO - 2016-10-08 18:00:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 18:00:58 --> Controller Class Initialized
DEBUG - 2016-10-08 18:00:58 --> Index MX_Controller Initialized
INFO - 2016-10-08 18:00:58 --> Config Class Initialized
INFO - 2016-10-08 18:00:58 --> Hooks Class Initialized
INFO - 2016-10-08 18:00:58 --> Model Class Initialized
DEBUG - 2016-10-08 18:00:58 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:00:58 --> Utf8 Class Initialized
INFO - 2016-10-08 18:00:59 --> Model Class Initialized
INFO - 2016-10-08 18:00:59 --> URI Class Initialized
ERROR - 2016-10-08 18:00:59 --> Unable to delete cache file for admin/index/getDataPeminjam
INFO - 2016-10-08 18:00:59 --> Router Class Initialized
INFO - 2016-10-08 18:00:59 --> Config Class Initialized
INFO - 2016-10-08 18:00:59 --> Hooks Class Initialized
INFO - 2016-10-08 18:00:59 --> Output Class Initialized
DEBUG - 2016-10-08 18:00:59 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-10-08 18:00:59 --> Final output sent to browser
DEBUG - 2016-10-08 18:00:59 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:00:59 --> Security Class Initialized
DEBUG - 2016-10-08 18:00:59 --> Total execution time: 2.6292
INFO - 2016-10-08 18:00:59 --> Utf8 Class Initialized
DEBUG - 2016-10-08 18:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:00:59 --> URI Class Initialized
INFO - 2016-10-08 18:01:00 --> Router Class Initialized
INFO - 2016-10-08 18:01:00 --> Output Class Initialized
INFO - 2016-10-08 18:01:00 --> Security Class Initialized
DEBUG - 2016-10-08 18:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:01:00 --> Input Class Initialized
INFO - 2016-10-08 18:01:00 --> Config Class Initialized
INFO - 2016-10-08 18:01:00 --> Hooks Class Initialized
INFO - 2016-10-08 18:01:00 --> Language Class Initialized
INFO - 2016-10-08 18:01:00 --> Input Class Initialized
INFO - 2016-10-08 18:01:00 --> Language Class Initialized
DEBUG - 2016-10-08 18:01:00 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:01:00 --> Language Class Initialized
INFO - 2016-10-08 18:01:00 --> Language Class Initialized
INFO - 2016-10-08 18:01:00 --> Utf8 Class Initialized
INFO - 2016-10-08 18:01:00 --> Config Class Initialized
INFO - 2016-10-08 18:01:00 --> Loader Class Initialized
INFO - 2016-10-08 18:01:00 --> URI Class Initialized
INFO - 2016-10-08 18:01:00 --> Helper loaded: url_helper
INFO - 2016-10-08 18:01:00 --> Router Class Initialized
INFO - 2016-10-08 18:01:00 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:00 --> Config Class Initialized
INFO - 2016-10-08 18:01:00 --> Output Class Initialized
INFO - 2016-10-08 18:01:01 --> Loader Class Initialized
INFO - 2016-10-08 18:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 18:01:01 --> Controller Class Initialized
INFO - 2016-10-08 18:01:01 --> Security Class Initialized
DEBUG - 2016-10-08 18:01:01 --> Index MX_Controller Initialized
INFO - 2016-10-08 18:01:01 --> Helper loaded: url_helper
DEBUG - 2016-10-08 18:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:01:01 --> Model Class Initialized
INFO - 2016-10-08 18:01:01 --> Input Class Initialized
INFO - 2016-10-08 18:01:01 --> Model Class Initialized
INFO - 2016-10-08 18:01:01 --> Database Driver Class Initialized
ERROR - 2016-10-08 18:01:01 --> Unable to delete cache file for admin/index/getDataPeminjam
INFO - 2016-10-08 18:01:01 --> Language Class Initialized
DEBUG - 2016-10-08 18:01:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-10-08 18:01:01 --> Language Class Initialized
INFO - 2016-10-08 18:01:01 --> Final output sent to browser
INFO - 2016-10-08 18:01:01 --> Config Class Initialized
DEBUG - 2016-10-08 18:01:01 --> Total execution time: 1.8290
INFO - 2016-10-08 18:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 18:01:01 --> Loader Class Initialized
INFO - 2016-10-08 18:01:01 --> Controller Class Initialized
DEBUG - 2016-10-08 18:01:01 --> Index MX_Controller Initialized
INFO - 2016-10-08 18:01:01 --> Model Class Initialized
INFO - 2016-10-08 18:01:01 --> Helper loaded: url_helper
INFO - 2016-10-08 18:01:01 --> Model Class Initialized
INFO - 2016-10-08 18:01:01 --> Database Driver Class Initialized
ERROR - 2016-10-08 18:01:01 --> Unable to delete cache file for admin/index/getDataPeminjam/umum
DEBUG - 2016-10-08 18:01:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-10-08 18:01:01 --> Final output sent to browser
DEBUG - 2016-10-08 18:01:01 --> Total execution time: 3.1830
INFO - 2016-10-08 18:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 18:01:02 --> Controller Class Initialized
DEBUG - 2016-10-08 18:01:02 --> Index MX_Controller Initialized
INFO - 2016-10-08 18:01:02 --> Model Class Initialized
INFO - 2016-10-08 18:01:02 --> Model Class Initialized
ERROR - 2016-10-08 18:01:02 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-10-08 18:01:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 18:01:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 18:01:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 18:01:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-10-08 18:01:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 18:01:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 18:01:02 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:02 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:02 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:02 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:02 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:02 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:02 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:03 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:03 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:03 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:03 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:03 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:03 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:03 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:03 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:03 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:03 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:03 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:03 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:03 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:03 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:03 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:03 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:03 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:04 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:04 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:04 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:04 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:04 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:04 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:04 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:04 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:04 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:04 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:04 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:04 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:04 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:04 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:04 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:05 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:05 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:05 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:05 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:05 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:05 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:05 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:05 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:05 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:05 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:05 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:05 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:05 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:06 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:06 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:06 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:06 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:06 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:06 --> Database Driver Class Initialized
INFO - 2016-10-08 18:01:06 --> Database Driver Class Initialized
DEBUG - 2016-10-08 18:01:06 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 18:01:06 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 18:01:06 --> Final output sent to browser
DEBUG - 2016-10-08 18:01:06 --> Total execution time: 6.3207
INFO - 2016-10-08 18:08:55 --> Config Class Initialized
INFO - 2016-10-08 18:08:55 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:08:55 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:08:55 --> Utf8 Class Initialized
INFO - 2016-10-08 18:08:55 --> URI Class Initialized
INFO - 2016-10-08 18:08:55 --> Router Class Initialized
INFO - 2016-10-08 18:08:55 --> Output Class Initialized
INFO - 2016-10-08 18:08:55 --> Security Class Initialized
DEBUG - 2016-10-08 18:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:08:55 --> Input Class Initialized
INFO - 2016-10-08 18:08:55 --> Language Class Initialized
INFO - 2016-10-08 18:08:55 --> Language Class Initialized
INFO - 2016-10-08 18:08:55 --> Config Class Initialized
INFO - 2016-10-08 18:08:55 --> Loader Class Initialized
INFO - 2016-10-08 18:08:55 --> Helper loaded: url_helper
INFO - 2016-10-08 18:08:55 --> Database Driver Class Initialized
INFO - 2016-10-08 18:08:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 18:08:55 --> Controller Class Initialized
DEBUG - 2016-10-08 18:08:55 --> Index MX_Controller Initialized
INFO - 2016-10-08 18:08:56 --> Model Class Initialized
INFO - 2016-10-08 18:08:56 --> Model Class Initialized
ERROR - 2016-10-08 18:08:56 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-08 18:08:56 --> Anggota MX_Controller Initialized
INFO - 2016-10-08 18:08:56 --> Database Driver Class Initialized
INFO - 2016-10-08 18:08:56 --> Final output sent to browser
DEBUG - 2016-10-08 18:08:56 --> Total execution time: 1.2079
INFO - 2016-10-08 18:08:59 --> Config Class Initialized
INFO - 2016-10-08 18:08:59 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:08:59 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:08:59 --> Utf8 Class Initialized
INFO - 2016-10-08 18:09:00 --> URI Class Initialized
INFO - 2016-10-08 18:09:00 --> Router Class Initialized
INFO - 2016-10-08 18:09:00 --> Output Class Initialized
INFO - 2016-10-08 18:09:00 --> Security Class Initialized
DEBUG - 2016-10-08 18:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:09:00 --> Input Class Initialized
INFO - 2016-10-08 18:09:00 --> Language Class Initialized
INFO - 2016-10-08 18:09:00 --> Language Class Initialized
INFO - 2016-10-08 18:09:00 --> Config Class Initialized
INFO - 2016-10-08 18:09:00 --> Loader Class Initialized
INFO - 2016-10-08 18:09:00 --> Helper loaded: url_helper
INFO - 2016-10-08 18:09:00 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 18:09:00 --> Controller Class Initialized
DEBUG - 2016-10-08 18:09:00 --> Index MX_Controller Initialized
INFO - 2016-10-08 18:09:00 --> Model Class Initialized
INFO - 2016-10-08 18:09:00 --> Model Class Initialized
ERROR - 2016-10-08 18:09:00 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-10-08 18:09:00 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 18:09:00 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 18:09:00 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 18:09:00 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_umum.php
DEBUG - 2016-10-08 18:09:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 18:09:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 18:09:01 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:01 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:01 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:01 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:01 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:01 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:01 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:01 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:01 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:01 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:01 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:01 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:01 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:01 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:01 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:01 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:01 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:01 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:01 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:01 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:02 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:02 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:02 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:02 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:02 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:02 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:02 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:02 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:02 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:02 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:02 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:02 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:02 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:02 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:02 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:02 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:02 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:02 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:02 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:02 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:02 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:02 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:03 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:03 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:03 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:03 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:03 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:03 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:03 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:03 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:03 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:03 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:03 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:03 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:03 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:03 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:03 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:03 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:03 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:03 --> Database Driver Class Initialized
DEBUG - 2016-10-08 18:09:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 18:09:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 18:09:03 --> Final output sent to browser
DEBUG - 2016-10-08 18:09:04 --> Total execution time: 4.1451
INFO - 2016-10-08 18:09:29 --> Config Class Initialized
INFO - 2016-10-08 18:09:29 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:09:29 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:09:29 --> Utf8 Class Initialized
INFO - 2016-10-08 18:09:29 --> URI Class Initialized
INFO - 2016-10-08 18:09:29 --> Router Class Initialized
INFO - 2016-10-08 18:09:29 --> Output Class Initialized
INFO - 2016-10-08 18:09:29 --> Security Class Initialized
DEBUG - 2016-10-08 18:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:09:29 --> Input Class Initialized
INFO - 2016-10-08 18:09:29 --> Language Class Initialized
INFO - 2016-10-08 18:09:29 --> Language Class Initialized
INFO - 2016-10-08 18:09:29 --> Config Class Initialized
INFO - 2016-10-08 18:09:29 --> Loader Class Initialized
INFO - 2016-10-08 18:09:29 --> Helper loaded: url_helper
INFO - 2016-10-08 18:09:29 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 18:09:29 --> Controller Class Initialized
DEBUG - 2016-10-08 18:09:29 --> Index MX_Controller Initialized
INFO - 2016-10-08 18:09:29 --> Model Class Initialized
INFO - 2016-10-08 18:09:29 --> Model Class Initialized
ERROR - 2016-10-08 18:09:29 --> Unable to delete cache file for admin/index/do_ajukan_pinjaman
INFO - 2016-10-08 18:09:29 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:30 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:30 --> Final output sent to browser
DEBUG - 2016-10-08 18:09:30 --> Total execution time: 1.1523
INFO - 2016-10-08 18:09:40 --> Config Class Initialized
INFO - 2016-10-08 18:09:40 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:09:40 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:09:40 --> Utf8 Class Initialized
INFO - 2016-10-08 18:09:40 --> URI Class Initialized
INFO - 2016-10-08 18:09:40 --> Router Class Initialized
INFO - 2016-10-08 18:09:40 --> Output Class Initialized
INFO - 2016-10-08 18:09:40 --> Security Class Initialized
DEBUG - 2016-10-08 18:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:09:40 --> Input Class Initialized
INFO - 2016-10-08 18:09:40 --> Language Class Initialized
INFO - 2016-10-08 18:09:40 --> Language Class Initialized
INFO - 2016-10-08 18:09:40 --> Config Class Initialized
INFO - 2016-10-08 18:09:40 --> Loader Class Initialized
INFO - 2016-10-08 18:09:40 --> Helper loaded: url_helper
INFO - 2016-10-08 18:09:40 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 18:09:40 --> Controller Class Initialized
DEBUG - 2016-10-08 18:09:40 --> Index MX_Controller Initialized
INFO - 2016-10-08 18:09:40 --> Model Class Initialized
INFO - 2016-10-08 18:09:40 --> Model Class Initialized
ERROR - 2016-10-08 18:09:40 --> Unable to delete cache file for admin/index/do_save_jaminan
INFO - 2016-10-08 18:09:41 --> Database Driver Class Initialized
INFO - 2016-10-08 18:09:41 --> Final output sent to browser
DEBUG - 2016-10-08 18:09:41 --> Total execution time: 1.0249
INFO - 2016-10-08 18:09:52 --> Config Class Initialized
INFO - 2016-10-08 18:09:52 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:09:52 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:09:52 --> Utf8 Class Initialized
INFO - 2016-10-08 18:10:17 --> Config Class Initialized
INFO - 2016-10-08 18:10:17 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:10:17 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:10:17 --> Utf8 Class Initialized
INFO - 2016-10-08 18:11:17 --> Config Class Initialized
INFO - 2016-10-08 18:11:17 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:11:17 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:11:17 --> Utf8 Class Initialized
INFO - 2016-10-08 18:11:17 --> URI Class Initialized
INFO - 2016-10-08 18:11:17 --> Router Class Initialized
INFO - 2016-10-08 18:11:17 --> Output Class Initialized
INFO - 2016-10-08 18:11:17 --> Security Class Initialized
DEBUG - 2016-10-08 18:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:11:17 --> Input Class Initialized
INFO - 2016-10-08 18:11:17 --> Language Class Initialized
INFO - 2016-10-08 18:11:17 --> Language Class Initialized
INFO - 2016-10-08 18:11:17 --> Config Class Initialized
INFO - 2016-10-08 18:11:17 --> Loader Class Initialized
INFO - 2016-10-08 18:11:17 --> Helper loaded: url_helper
INFO - 2016-10-08 18:11:18 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 18:11:18 --> Controller Class Initialized
DEBUG - 2016-10-08 18:11:18 --> Index MX_Controller Initialized
INFO - 2016-10-08 18:11:18 --> Model Class Initialized
INFO - 2016-10-08 18:11:18 --> Model Class Initialized
ERROR - 2016-10-08 18:11:18 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-10-08 18:11:18 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 18:11:18 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 18:11:18 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 18:11:18 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_umum.php
DEBUG - 2016-10-08 18:11:18 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 18:11:18 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 18:11:18 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:18 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:18 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:18 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:18 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:18 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:19 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:19 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:19 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:19 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:19 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:19 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:19 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:19 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:19 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:19 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:19 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:19 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:19 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:19 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:19 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:19 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:19 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:19 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:19 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:19 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:19 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:19 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:20 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:20 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:20 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:20 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:20 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:20 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:20 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:20 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:20 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:20 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:20 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:20 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:20 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:20 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:20 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:20 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:20 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:20 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:20 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:20 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:20 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:21 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:21 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:21 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:21 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:21 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:21 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:21 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:21 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:21 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:21 --> Database Driver Class Initialized
INFO - 2016-10-08 18:11:21 --> Database Driver Class Initialized
DEBUG - 2016-10-08 18:11:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 18:11:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 18:11:21 --> Final output sent to browser
DEBUG - 2016-10-08 18:11:21 --> Total execution time: 4.3371
INFO - 2016-10-08 18:12:05 --> Config Class Initialized
INFO - 2016-10-08 18:12:05 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:12:05 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:12:05 --> Utf8 Class Initialized
INFO - 2016-10-08 18:12:05 --> URI Class Initialized
INFO - 2016-10-08 18:12:05 --> Router Class Initialized
INFO - 2016-10-08 18:12:05 --> Output Class Initialized
INFO - 2016-10-08 18:12:05 --> Security Class Initialized
DEBUG - 2016-10-08 18:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:12:06 --> Input Class Initialized
INFO - 2016-10-08 18:12:06 --> Language Class Initialized
INFO - 2016-10-08 18:12:06 --> Language Class Initialized
INFO - 2016-10-08 18:12:06 --> Config Class Initialized
INFO - 2016-10-08 18:12:06 --> Loader Class Initialized
INFO - 2016-10-08 18:12:06 --> Helper loaded: url_helper
INFO - 2016-10-08 18:12:06 --> Database Driver Class Initialized
INFO - 2016-10-08 18:12:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 18:12:06 --> Controller Class Initialized
DEBUG - 2016-10-08 18:12:06 --> Index MX_Controller Initialized
INFO - 2016-10-08 18:12:06 --> Model Class Initialized
INFO - 2016-10-08 18:12:06 --> Model Class Initialized
ERROR - 2016-10-08 18:12:06 --> Unable to delete cache file for admin/index/do_ajukan_pinjaman
INFO - 2016-10-08 18:12:06 --> Database Driver Class Initialized
INFO - 2016-10-08 18:12:06 --> Database Driver Class Initialized
INFO - 2016-10-08 18:12:06 --> Final output sent to browser
DEBUG - 2016-10-08 18:12:06 --> Total execution time: 1.4425
INFO - 2016-10-08 18:12:14 --> Config Class Initialized
INFO - 2016-10-08 18:12:14 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:12:14 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:12:14 --> Utf8 Class Initialized
INFO - 2016-10-08 18:12:14 --> URI Class Initialized
INFO - 2016-10-08 18:12:15 --> Router Class Initialized
INFO - 2016-10-08 18:12:15 --> Output Class Initialized
INFO - 2016-10-08 18:12:15 --> Security Class Initialized
DEBUG - 2016-10-08 18:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:12:15 --> Input Class Initialized
INFO - 2016-10-08 18:12:15 --> Language Class Initialized
INFO - 2016-10-08 18:12:15 --> Language Class Initialized
INFO - 2016-10-08 18:12:15 --> Config Class Initialized
INFO - 2016-10-08 18:12:15 --> Loader Class Initialized
INFO - 2016-10-08 18:12:15 --> Helper loaded: url_helper
INFO - 2016-10-08 18:12:15 --> Database Driver Class Initialized
INFO - 2016-10-08 18:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 18:12:15 --> Controller Class Initialized
DEBUG - 2016-10-08 18:12:15 --> Index MX_Controller Initialized
INFO - 2016-10-08 18:12:15 --> Model Class Initialized
INFO - 2016-10-08 18:12:15 --> Model Class Initialized
ERROR - 2016-10-08 18:12:15 --> Unable to delete cache file for admin/index/do_save_jaminan
INFO - 2016-10-08 18:12:15 --> Database Driver Class Initialized
INFO - 2016-10-08 18:12:15 --> Final output sent to browser
DEBUG - 2016-10-08 18:12:15 --> Total execution time: 1.1765
INFO - 2016-10-08 18:12:23 --> Config Class Initialized
INFO - 2016-10-08 18:12:23 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:12:23 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:12:23 --> Utf8 Class Initialized
INFO - 2016-10-08 18:13:32 --> Config Class Initialized
INFO - 2016-10-08 18:13:32 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:13:32 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:13:32 --> Utf8 Class Initialized
INFO - 2016-10-08 18:13:32 --> URI Class Initialized
INFO - 2016-10-08 18:13:32 --> Router Class Initialized
INFO - 2016-10-08 18:13:32 --> Output Class Initialized
INFO - 2016-10-08 18:13:32 --> Security Class Initialized
DEBUG - 2016-10-08 18:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:13:32 --> Input Class Initialized
INFO - 2016-10-08 18:13:32 --> Language Class Initialized
INFO - 2016-10-08 18:13:32 --> Language Class Initialized
INFO - 2016-10-08 18:13:32 --> Config Class Initialized
INFO - 2016-10-08 18:13:33 --> Loader Class Initialized
INFO - 2016-10-08 18:13:33 --> Helper loaded: url_helper
INFO - 2016-10-08 18:13:33 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 18:13:33 --> Controller Class Initialized
DEBUG - 2016-10-08 18:13:33 --> Index MX_Controller Initialized
INFO - 2016-10-08 18:13:33 --> Model Class Initialized
INFO - 2016-10-08 18:13:33 --> Model Class Initialized
ERROR - 2016-10-08 18:13:33 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-10-08 18:13:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 18:13:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 18:13:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 18:13:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_umum.php
DEBUG - 2016-10-08 18:13:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 18:13:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 18:13:33 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:33 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:33 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:34 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:34 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:34 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:34 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:34 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:34 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:34 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:34 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:34 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:34 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:34 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:34 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:34 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:34 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:34 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:34 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:35 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:35 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:35 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:35 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:35 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:35 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:35 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:35 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:35 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:35 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:35 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:35 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:35 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:35 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:35 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:35 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:35 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:36 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:36 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:36 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:36 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:36 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:36 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:36 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:36 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:36 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:36 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:36 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:36 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:36 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:36 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:36 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:36 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:36 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:37 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:37 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:37 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:37 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:37 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:37 --> Database Driver Class Initialized
INFO - 2016-10-08 18:13:37 --> Database Driver Class Initialized
DEBUG - 2016-10-08 18:13:37 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 18:13:37 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 18:13:37 --> Final output sent to browser
DEBUG - 2016-10-08 18:13:37 --> Total execution time: 5.1507
INFO - 2016-10-08 18:14:04 --> Config Class Initialized
INFO - 2016-10-08 18:14:04 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:14:04 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:14:04 --> Utf8 Class Initialized
INFO - 2016-10-08 18:14:05 --> URI Class Initialized
INFO - 2016-10-08 18:14:05 --> Router Class Initialized
INFO - 2016-10-08 18:14:05 --> Output Class Initialized
INFO - 2016-10-08 18:14:05 --> Security Class Initialized
DEBUG - 2016-10-08 18:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:14:05 --> Input Class Initialized
INFO - 2016-10-08 18:14:05 --> Language Class Initialized
INFO - 2016-10-08 18:14:05 --> Language Class Initialized
INFO - 2016-10-08 18:14:05 --> Config Class Initialized
INFO - 2016-10-08 18:14:05 --> Loader Class Initialized
INFO - 2016-10-08 18:14:05 --> Helper loaded: url_helper
INFO - 2016-10-08 18:14:05 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 18:14:05 --> Controller Class Initialized
DEBUG - 2016-10-08 18:14:05 --> Index MX_Controller Initialized
INFO - 2016-10-08 18:14:05 --> Model Class Initialized
INFO - 2016-10-08 18:14:05 --> Model Class Initialized
ERROR - 2016-10-08 18:14:05 --> Unable to delete cache file for admin/index/do_ajukan_pinjaman
INFO - 2016-10-08 18:14:05 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:06 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:06 --> Final output sent to browser
DEBUG - 2016-10-08 18:14:06 --> Total execution time: 1.2608
INFO - 2016-10-08 18:14:15 --> Config Class Initialized
INFO - 2016-10-08 18:14:15 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:14:15 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:14:15 --> Utf8 Class Initialized
INFO - 2016-10-08 18:14:15 --> URI Class Initialized
INFO - 2016-10-08 18:14:15 --> Router Class Initialized
INFO - 2016-10-08 18:14:15 --> Output Class Initialized
INFO - 2016-10-08 18:14:15 --> Security Class Initialized
DEBUG - 2016-10-08 18:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:14:15 --> Input Class Initialized
INFO - 2016-10-08 18:14:15 --> Language Class Initialized
INFO - 2016-10-08 18:14:16 --> Language Class Initialized
INFO - 2016-10-08 18:14:16 --> Config Class Initialized
INFO - 2016-10-08 18:14:16 --> Loader Class Initialized
INFO - 2016-10-08 18:14:16 --> Helper loaded: url_helper
INFO - 2016-10-08 18:14:16 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 18:14:16 --> Controller Class Initialized
DEBUG - 2016-10-08 18:14:16 --> Index MX_Controller Initialized
INFO - 2016-10-08 18:14:16 --> Model Class Initialized
INFO - 2016-10-08 18:14:16 --> Model Class Initialized
ERROR - 2016-10-08 18:14:16 --> Unable to delete cache file for admin/index/do_save_jaminan
INFO - 2016-10-08 18:14:16 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:16 --> Final output sent to browser
DEBUG - 2016-10-08 18:14:16 --> Total execution time: 1.4082
INFO - 2016-10-08 18:14:21 --> Config Class Initialized
INFO - 2016-10-08 18:14:21 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:14:21 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:14:21 --> Utf8 Class Initialized
INFO - 2016-10-08 18:14:21 --> URI Class Initialized
INFO - 2016-10-08 18:14:21 --> Router Class Initialized
INFO - 2016-10-08 18:14:21 --> Output Class Initialized
INFO - 2016-10-08 18:14:21 --> Security Class Initialized
DEBUG - 2016-10-08 18:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:14:21 --> Input Class Initialized
INFO - 2016-10-08 18:14:21 --> Language Class Initialized
INFO - 2016-10-08 18:14:21 --> Language Class Initialized
INFO - 2016-10-08 18:14:22 --> Config Class Initialized
INFO - 2016-10-08 18:14:22 --> Loader Class Initialized
INFO - 2016-10-08 18:14:22 --> Helper loaded: url_helper
INFO - 2016-10-08 18:14:22 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 18:14:22 --> Controller Class Initialized
DEBUG - 2016-10-08 18:14:22 --> Index MX_Controller Initialized
INFO - 2016-10-08 18:14:22 --> Model Class Initialized
INFO - 2016-10-08 18:14:22 --> Model Class Initialized
ERROR - 2016-10-08 18:14:22 --> Unable to delete cache file for admin/index/batal/ac3478d69a3c81fa62e60f5c3696165a4e5e6ac4
INFO - 2016-10-08 18:14:22 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:22 --> Final output sent to browser
DEBUG - 2016-10-08 18:14:22 --> Total execution time: 1.4998
INFO - 2016-10-08 18:14:23 --> Config Class Initialized
INFO - 2016-10-08 18:14:23 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:14:23 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:14:23 --> Utf8 Class Initialized
INFO - 2016-10-08 18:14:23 --> URI Class Initialized
INFO - 2016-10-08 18:14:23 --> Router Class Initialized
INFO - 2016-10-08 18:14:23 --> Output Class Initialized
INFO - 2016-10-08 18:14:23 --> Security Class Initialized
DEBUG - 2016-10-08 18:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:14:23 --> Input Class Initialized
INFO - 2016-10-08 18:14:23 --> Language Class Initialized
INFO - 2016-10-08 18:14:23 --> Language Class Initialized
INFO - 2016-10-08 18:14:23 --> Config Class Initialized
INFO - 2016-10-08 18:14:24 --> Loader Class Initialized
INFO - 2016-10-08 18:14:24 --> Helper loaded: url_helper
INFO - 2016-10-08 18:14:24 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 18:14:24 --> Controller Class Initialized
DEBUG - 2016-10-08 18:14:24 --> Index MX_Controller Initialized
INFO - 2016-10-08 18:14:24 --> Model Class Initialized
INFO - 2016-10-08 18:14:24 --> Model Class Initialized
ERROR - 2016-10-08 18:14:24 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-10-08 18:14:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 18:14:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 18:14:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 18:14:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-10-08 18:14:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 18:14:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 18:14:24 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:24 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:25 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:25 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:25 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:25 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:25 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:25 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:25 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:25 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:25 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:25 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:25 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:25 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:25 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:25 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:25 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:25 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:25 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:26 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:26 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:26 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:26 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:26 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:26 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:26 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:26 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:26 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:26 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:26 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:26 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:26 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:26 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:27 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:27 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:27 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:27 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:27 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:27 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:27 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:27 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:27 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:27 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:27 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:27 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:27 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:27 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:27 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:28 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:28 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:28 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:28 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:28 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:28 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:28 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:28 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:28 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:28 --> Database Driver Class Initialized
INFO - 2016-10-08 18:14:28 --> Database Driver Class Initialized
DEBUG - 2016-10-08 18:14:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 18:14:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 18:14:28 --> Final output sent to browser
DEBUG - 2016-10-08 18:14:28 --> Total execution time: 5.5018
INFO - 2016-10-08 18:43:42 --> Config Class Initialized
INFO - 2016-10-08 18:43:42 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:43:42 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:43:42 --> Utf8 Class Initialized
INFO - 2016-10-08 18:43:42 --> URI Class Initialized
INFO - 2016-10-08 18:43:42 --> Router Class Initialized
INFO - 2016-10-08 18:43:42 --> Output Class Initialized
INFO - 2016-10-08 18:43:43 --> Security Class Initialized
DEBUG - 2016-10-08 18:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:43:43 --> Input Class Initialized
INFO - 2016-10-08 18:43:43 --> Language Class Initialized
INFO - 2016-10-08 18:43:43 --> Language Class Initialized
INFO - 2016-10-08 18:43:43 --> Config Class Initialized
INFO - 2016-10-08 18:43:43 --> Loader Class Initialized
INFO - 2016-10-08 18:43:43 --> Helper loaded: url_helper
INFO - 2016-10-08 18:43:43 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 18:43:43 --> Controller Class Initialized
DEBUG - 2016-10-08 18:43:43 --> Index MX_Controller Initialized
INFO - 2016-10-08 18:43:43 --> Model Class Initialized
INFO - 2016-10-08 18:43:43 --> Model Class Initialized
ERROR - 2016-10-08 18:43:43 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-08 18:43:43 --> Anggota MX_Controller Initialized
INFO - 2016-10-08 18:43:43 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:43 --> Final output sent to browser
DEBUG - 2016-10-08 18:43:43 --> Total execution time: 1.3767
INFO - 2016-10-08 18:43:46 --> Config Class Initialized
INFO - 2016-10-08 18:43:46 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:43:46 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:43:46 --> Utf8 Class Initialized
INFO - 2016-10-08 18:43:46 --> URI Class Initialized
INFO - 2016-10-08 18:43:46 --> Router Class Initialized
INFO - 2016-10-08 18:43:46 --> Output Class Initialized
INFO - 2016-10-08 18:43:46 --> Security Class Initialized
DEBUG - 2016-10-08 18:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:43:47 --> Input Class Initialized
INFO - 2016-10-08 18:43:47 --> Language Class Initialized
INFO - 2016-10-08 18:43:47 --> Language Class Initialized
INFO - 2016-10-08 18:43:47 --> Config Class Initialized
INFO - 2016-10-08 18:43:47 --> Loader Class Initialized
INFO - 2016-10-08 18:43:47 --> Helper loaded: url_helper
INFO - 2016-10-08 18:43:47 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 18:43:47 --> Controller Class Initialized
DEBUG - 2016-10-08 18:43:48 --> Index MX_Controller Initialized
INFO - 2016-10-08 18:43:48 --> Model Class Initialized
INFO - 2016-10-08 18:43:48 --> Model Class Initialized
ERROR - 2016-10-08 18:43:48 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-10-08 18:43:48 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 18:43:48 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 18:43:48 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 18:43:48 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_umum.php
DEBUG - 2016-10-08 18:43:48 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 18:43:48 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 18:43:48 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:48 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:48 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:48 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:48 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:48 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:48 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:48 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:48 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:48 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:49 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:49 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:49 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:49 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:49 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:49 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:49 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:49 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:49 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:49 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:49 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:49 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:49 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:49 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:49 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:50 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:50 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:50 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:50 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:50 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:50 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:50 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:50 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:50 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:50 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:50 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:50 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:50 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:50 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:50 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:50 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:51 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:51 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:51 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:51 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:51 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:51 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:51 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:51 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:51 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:51 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:51 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:51 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:51 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:52 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:52 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:52 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:52 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:52 --> Database Driver Class Initialized
INFO - 2016-10-08 18:43:52 --> Database Driver Class Initialized
DEBUG - 2016-10-08 18:43:52 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 18:43:52 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 18:43:52 --> Final output sent to browser
DEBUG - 2016-10-08 18:43:52 --> Total execution time: 6.1724
INFO - 2016-10-08 18:44:04 --> Config Class Initialized
INFO - 2016-10-08 18:44:04 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:44:04 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:44:04 --> Utf8 Class Initialized
INFO - 2016-10-08 18:44:04 --> URI Class Initialized
INFO - 2016-10-08 18:44:04 --> Router Class Initialized
INFO - 2016-10-08 18:44:04 --> Output Class Initialized
INFO - 2016-10-08 18:44:04 --> Security Class Initialized
DEBUG - 2016-10-08 18:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:44:04 --> Input Class Initialized
INFO - 2016-10-08 18:44:04 --> Language Class Initialized
INFO - 2016-10-08 18:44:05 --> Language Class Initialized
INFO - 2016-10-08 18:44:05 --> Config Class Initialized
INFO - 2016-10-08 18:44:05 --> Loader Class Initialized
INFO - 2016-10-08 18:44:05 --> Helper loaded: url_helper
INFO - 2016-10-08 18:44:05 --> Database Driver Class Initialized
INFO - 2016-10-08 18:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 18:44:05 --> Controller Class Initialized
DEBUG - 2016-10-08 18:44:05 --> Index MX_Controller Initialized
INFO - 2016-10-08 18:44:05 --> Model Class Initialized
INFO - 2016-10-08 18:44:05 --> Model Class Initialized
ERROR - 2016-10-08 18:44:05 --> Unable to delete cache file for admin/index/do_ajukan_pinjaman
INFO - 2016-10-08 18:44:05 --> Database Driver Class Initialized
INFO - 2016-10-08 18:44:05 --> Database Driver Class Initialized
INFO - 2016-10-08 18:44:05 --> Final output sent to browser
DEBUG - 2016-10-08 18:44:05 --> Total execution time: 1.1882
INFO - 2016-10-08 18:45:05 --> Config Class Initialized
INFO - 2016-10-08 18:45:05 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:45:05 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:45:05 --> Utf8 Class Initialized
INFO - 2016-10-08 18:45:05 --> URI Class Initialized
INFO - 2016-10-08 18:45:05 --> Router Class Initialized
INFO - 2016-10-08 18:45:05 --> Output Class Initialized
INFO - 2016-10-08 18:45:05 --> Security Class Initialized
DEBUG - 2016-10-08 18:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:45:05 --> Input Class Initialized
INFO - 2016-10-08 18:45:05 --> Language Class Initialized
INFO - 2016-10-08 18:45:05 --> Language Class Initialized
INFO - 2016-10-08 18:45:05 --> Config Class Initialized
INFO - 2016-10-08 18:45:05 --> Loader Class Initialized
INFO - 2016-10-08 18:45:05 --> Helper loaded: url_helper
INFO - 2016-10-08 18:45:06 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 18:45:06 --> Controller Class Initialized
DEBUG - 2016-10-08 18:45:06 --> Index MX_Controller Initialized
INFO - 2016-10-08 18:45:06 --> Model Class Initialized
INFO - 2016-10-08 18:45:06 --> Model Class Initialized
ERROR - 2016-10-08 18:45:06 --> Unable to delete cache file for admin/index/batal/c1dfd96eea8cc2b62785275bca38ac261256e278
INFO - 2016-10-08 18:45:06 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:06 --> Final output sent to browser
DEBUG - 2016-10-08 18:45:06 --> Total execution time: 1.1800
INFO - 2016-10-08 18:45:06 --> Config Class Initialized
INFO - 2016-10-08 18:45:06 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:45:06 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:45:06 --> Utf8 Class Initialized
INFO - 2016-10-08 18:45:06 --> URI Class Initialized
INFO - 2016-10-08 18:45:06 --> Router Class Initialized
INFO - 2016-10-08 18:45:07 --> Output Class Initialized
INFO - 2016-10-08 18:45:07 --> Security Class Initialized
DEBUG - 2016-10-08 18:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:45:07 --> Input Class Initialized
INFO - 2016-10-08 18:45:07 --> Language Class Initialized
INFO - 2016-10-08 18:45:07 --> Language Class Initialized
INFO - 2016-10-08 18:45:07 --> Config Class Initialized
INFO - 2016-10-08 18:45:07 --> Loader Class Initialized
INFO - 2016-10-08 18:45:07 --> Helper loaded: url_helper
INFO - 2016-10-08 18:45:07 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 18:45:07 --> Controller Class Initialized
DEBUG - 2016-10-08 18:45:07 --> Index MX_Controller Initialized
INFO - 2016-10-08 18:45:07 --> Model Class Initialized
INFO - 2016-10-08 18:45:07 --> Model Class Initialized
ERROR - 2016-10-08 18:45:07 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-10-08 18:45:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 18:45:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 18:45:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 18:45:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-10-08 18:45:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 18:45:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 18:45:08 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:08 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:08 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:08 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:08 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:08 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:08 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:08 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:08 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:08 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:08 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:09 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:09 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:09 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:09 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:09 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:09 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:09 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:09 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:09 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:09 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:09 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:09 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:09 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:09 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:09 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:10 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:10 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:10 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:10 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:10 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:10 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:10 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:10 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:10 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:10 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:10 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:10 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:10 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:10 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:10 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:11 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:11 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:11 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:11 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:11 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:11 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:11 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:11 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:11 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:11 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:11 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:11 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:11 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:12 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:12 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:12 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:12 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:12 --> Database Driver Class Initialized
DEBUG - 2016-10-08 18:45:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 18:45:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 18:45:12 --> Final output sent to browser
DEBUG - 2016-10-08 18:45:12 --> Total execution time: 5.7619
INFO - 2016-10-08 18:45:22 --> Config Class Initialized
INFO - 2016-10-08 18:45:23 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:45:23 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:45:23 --> Utf8 Class Initialized
INFO - 2016-10-08 18:45:23 --> URI Class Initialized
INFO - 2016-10-08 18:45:23 --> Router Class Initialized
INFO - 2016-10-08 18:45:23 --> Output Class Initialized
INFO - 2016-10-08 18:45:23 --> Security Class Initialized
DEBUG - 2016-10-08 18:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:45:23 --> Input Class Initialized
INFO - 2016-10-08 18:45:23 --> Language Class Initialized
INFO - 2016-10-08 18:45:23 --> Language Class Initialized
INFO - 2016-10-08 18:45:23 --> Config Class Initialized
INFO - 2016-10-08 18:45:23 --> Loader Class Initialized
INFO - 2016-10-08 18:45:23 --> Helper loaded: url_helper
INFO - 2016-10-08 18:45:23 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 18:45:23 --> Controller Class Initialized
DEBUG - 2016-10-08 18:45:23 --> Index MX_Controller Initialized
INFO - 2016-10-08 18:45:23 --> Model Class Initialized
INFO - 2016-10-08 18:45:24 --> Model Class Initialized
ERROR - 2016-10-08 18:45:24 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-08 18:45:24 --> Anggota MX_Controller Initialized
INFO - 2016-10-08 18:45:24 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:24 --> Final output sent to browser
DEBUG - 2016-10-08 18:45:24 --> Total execution time: 1.3485
INFO - 2016-10-08 18:45:27 --> Config Class Initialized
INFO - 2016-10-08 18:45:27 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:45:27 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:45:27 --> Utf8 Class Initialized
INFO - 2016-10-08 18:45:27 --> URI Class Initialized
INFO - 2016-10-08 18:45:27 --> Router Class Initialized
INFO - 2016-10-08 18:45:28 --> Output Class Initialized
INFO - 2016-10-08 18:45:28 --> Security Class Initialized
DEBUG - 2016-10-08 18:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:45:28 --> Input Class Initialized
INFO - 2016-10-08 18:45:28 --> Language Class Initialized
INFO - 2016-10-08 18:45:28 --> Language Class Initialized
INFO - 2016-10-08 18:45:28 --> Config Class Initialized
INFO - 2016-10-08 18:45:28 --> Loader Class Initialized
INFO - 2016-10-08 18:45:28 --> Helper loaded: url_helper
INFO - 2016-10-08 18:45:28 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 18:45:28 --> Controller Class Initialized
DEBUG - 2016-10-08 18:45:28 --> Index MX_Controller Initialized
INFO - 2016-10-08 18:45:28 --> Model Class Initialized
INFO - 2016-10-08 18:45:28 --> Model Class Initialized
ERROR - 2016-10-08 18:45:28 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-10-08 18:45:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 18:45:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 18:45:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 18:45:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_umum.php
DEBUG - 2016-10-08 18:45:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 18:45:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 18:45:29 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:29 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:29 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:29 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:29 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:29 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:29 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:29 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:29 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:29 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:29 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:29 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:29 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:29 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:29 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:29 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:29 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:30 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:30 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:30 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:30 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:30 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:30 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:30 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:30 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:30 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:30 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:30 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:30 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:30 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:30 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:30 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:30 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:30 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:31 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:31 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:31 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:31 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:31 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:31 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:31 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:31 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:31 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:31 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:31 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:31 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:31 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:31 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:31 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:31 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:32 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:32 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:32 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:32 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:32 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:32 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:32 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:32 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:32 --> Database Driver Class Initialized
INFO - 2016-10-08 18:45:32 --> Database Driver Class Initialized
DEBUG - 2016-10-08 18:45:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 18:45:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 18:45:32 --> Final output sent to browser
DEBUG - 2016-10-08 18:45:32 --> Total execution time: 4.9639
INFO - 2016-10-08 18:50:37 --> Config Class Initialized
INFO - 2016-10-08 18:50:37 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:50:37 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:50:37 --> Utf8 Class Initialized
INFO - 2016-10-08 18:50:37 --> URI Class Initialized
INFO - 2016-10-08 18:50:37 --> Router Class Initialized
INFO - 2016-10-08 18:50:37 --> Output Class Initialized
INFO - 2016-10-08 18:50:37 --> Security Class Initialized
DEBUG - 2016-10-08 18:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:50:37 --> Input Class Initialized
INFO - 2016-10-08 18:50:37 --> Language Class Initialized
INFO - 2016-10-08 18:50:38 --> Language Class Initialized
INFO - 2016-10-08 18:50:38 --> Config Class Initialized
INFO - 2016-10-08 18:50:38 --> Loader Class Initialized
INFO - 2016-10-08 18:50:38 --> Helper loaded: url_helper
INFO - 2016-10-08 18:50:38 --> Database Driver Class Initialized
INFO - 2016-10-08 18:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 18:50:38 --> Controller Class Initialized
DEBUG - 2016-10-08 18:50:38 --> Index MX_Controller Initialized
INFO - 2016-10-08 18:50:38 --> Model Class Initialized
INFO - 2016-10-08 18:50:38 --> Model Class Initialized
ERROR - 2016-10-08 18:50:38 --> Unable to delete cache file for admin/index/do_ajukan_pinjaman
INFO - 2016-10-08 18:50:38 --> Database Driver Class Initialized
INFO - 2016-10-08 18:50:38 --> Database Driver Class Initialized
INFO - 2016-10-08 18:50:38 --> Final output sent to browser
DEBUG - 2016-10-08 18:50:38 --> Total execution time: 1.2438
INFO - 2016-10-08 18:54:53 --> Config Class Initialized
INFO - 2016-10-08 18:54:53 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:54:53 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:54:53 --> Utf8 Class Initialized
INFO - 2016-10-08 18:54:53 --> URI Class Initialized
INFO - 2016-10-08 18:54:53 --> Router Class Initialized
INFO - 2016-10-08 18:54:53 --> Output Class Initialized
INFO - 2016-10-08 18:54:53 --> Security Class Initialized
DEBUG - 2016-10-08 18:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:54:53 --> Input Class Initialized
INFO - 2016-10-08 18:54:53 --> Language Class Initialized
INFO - 2016-10-08 18:54:53 --> Language Class Initialized
INFO - 2016-10-08 18:54:53 --> Config Class Initialized
INFO - 2016-10-08 18:54:53 --> Loader Class Initialized
INFO - 2016-10-08 18:54:53 --> Helper loaded: url_helper
INFO - 2016-10-08 18:54:53 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 18:54:53 --> Controller Class Initialized
DEBUG - 2016-10-08 18:54:54 --> Index MX_Controller Initialized
INFO - 2016-10-08 18:54:54 --> Model Class Initialized
INFO - 2016-10-08 18:54:54 --> Model Class Initialized
ERROR - 2016-10-08 18:54:54 --> Unable to delete cache file for admin/index/batal/902ba3cda1883801594b6e1b452790cc53948fda
INFO - 2016-10-08 18:54:54 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:54 --> Final output sent to browser
DEBUG - 2016-10-08 18:54:54 --> Total execution time: 1.1511
INFO - 2016-10-08 18:54:54 --> Config Class Initialized
INFO - 2016-10-08 18:54:54 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:54:54 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:54:54 --> Utf8 Class Initialized
INFO - 2016-10-08 18:54:54 --> URI Class Initialized
INFO - 2016-10-08 18:54:54 --> Router Class Initialized
INFO - 2016-10-08 18:54:54 --> Output Class Initialized
INFO - 2016-10-08 18:54:54 --> Security Class Initialized
DEBUG - 2016-10-08 18:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:54:55 --> Input Class Initialized
INFO - 2016-10-08 18:54:55 --> Language Class Initialized
INFO - 2016-10-08 18:54:55 --> Language Class Initialized
INFO - 2016-10-08 18:54:55 --> Config Class Initialized
INFO - 2016-10-08 18:54:55 --> Loader Class Initialized
INFO - 2016-10-08 18:54:55 --> Helper loaded: url_helper
INFO - 2016-10-08 18:54:55 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 18:54:55 --> Controller Class Initialized
DEBUG - 2016-10-08 18:54:55 --> Index MX_Controller Initialized
INFO - 2016-10-08 18:54:55 --> Model Class Initialized
INFO - 2016-10-08 18:54:55 --> Model Class Initialized
ERROR - 2016-10-08 18:54:55 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-10-08 18:54:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 18:54:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 18:54:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 18:54:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-10-08 18:54:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 18:54:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 18:54:55 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:55 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:56 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:56 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:56 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:56 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:56 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:56 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:56 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:56 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:56 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:56 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:56 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:56 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:56 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:56 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:56 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:56 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:56 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:56 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:56 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:56 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:57 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:57 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:57 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:57 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:57 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:57 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:57 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:57 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:57 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:57 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:57 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:57 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:57 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:57 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:57 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:57 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:57 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:57 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:57 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:58 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:58 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:58 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:58 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:58 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:58 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:58 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:58 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:58 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:58 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:58 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:58 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:58 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:58 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:58 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:58 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:58 --> Database Driver Class Initialized
INFO - 2016-10-08 18:54:58 --> Database Driver Class Initialized
DEBUG - 2016-10-08 18:54:59 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 18:54:59 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 18:54:59 --> Final output sent to browser
DEBUG - 2016-10-08 18:54:59 --> Total execution time: 4.7646
INFO - 2016-10-08 18:55:06 --> Config Class Initialized
INFO - 2016-10-08 18:55:06 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:55:06 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:55:06 --> Utf8 Class Initialized
INFO - 2016-10-08 18:55:06 --> URI Class Initialized
INFO - 2016-10-08 18:55:06 --> Router Class Initialized
INFO - 2016-10-08 18:55:06 --> Output Class Initialized
INFO - 2016-10-08 18:55:07 --> Security Class Initialized
DEBUG - 2016-10-08 18:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:55:07 --> Input Class Initialized
INFO - 2016-10-08 18:55:07 --> Language Class Initialized
INFO - 2016-10-08 18:55:07 --> Language Class Initialized
INFO - 2016-10-08 18:55:07 --> Config Class Initialized
INFO - 2016-10-08 18:55:07 --> Loader Class Initialized
INFO - 2016-10-08 18:55:07 --> Helper loaded: url_helper
INFO - 2016-10-08 18:55:07 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 18:55:07 --> Controller Class Initialized
DEBUG - 2016-10-08 18:55:07 --> Index MX_Controller Initialized
INFO - 2016-10-08 18:55:07 --> Model Class Initialized
INFO - 2016-10-08 18:55:07 --> Model Class Initialized
ERROR - 2016-10-08 18:55:07 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-08 18:55:07 --> Anggota MX_Controller Initialized
INFO - 2016-10-08 18:55:07 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:08 --> Final output sent to browser
DEBUG - 2016-10-08 18:55:08 --> Total execution time: 1.4815
INFO - 2016-10-08 18:55:10 --> Config Class Initialized
INFO - 2016-10-08 18:55:10 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:55:10 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:55:10 --> Utf8 Class Initialized
INFO - 2016-10-08 18:55:10 --> URI Class Initialized
INFO - 2016-10-08 18:55:10 --> Router Class Initialized
INFO - 2016-10-08 18:55:10 --> Output Class Initialized
INFO - 2016-10-08 18:55:10 --> Security Class Initialized
DEBUG - 2016-10-08 18:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:55:10 --> Input Class Initialized
INFO - 2016-10-08 18:55:10 --> Language Class Initialized
INFO - 2016-10-08 18:55:10 --> Language Class Initialized
INFO - 2016-10-08 18:55:10 --> Config Class Initialized
INFO - 2016-10-08 18:55:10 --> Loader Class Initialized
INFO - 2016-10-08 18:55:10 --> Helper loaded: url_helper
INFO - 2016-10-08 18:55:11 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 18:55:11 --> Controller Class Initialized
DEBUG - 2016-10-08 18:55:11 --> Index MX_Controller Initialized
INFO - 2016-10-08 18:55:11 --> Model Class Initialized
INFO - 2016-10-08 18:55:11 --> Model Class Initialized
ERROR - 2016-10-08 18:55:11 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-10-08 18:55:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 18:55:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 18:55:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 18:55:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_umum.php
DEBUG - 2016-10-08 18:55:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 18:55:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 18:55:11 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:11 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:11 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:11 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:11 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:11 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:11 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:12 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:12 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:12 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:12 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:12 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:12 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:12 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:12 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:12 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:12 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:12 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:12 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:12 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:12 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:12 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:12 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:12 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:12 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:13 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:13 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:13 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:13 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:13 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:13 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:13 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:13 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:13 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:13 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:13 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:13 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:13 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:13 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:13 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:13 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:13 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:13 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:14 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:14 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:14 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:14 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:14 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:14 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:14 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:14 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:14 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:14 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:14 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:14 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:14 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:14 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:14 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:14 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:15 --> Database Driver Class Initialized
DEBUG - 2016-10-08 18:55:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 18:55:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 18:55:15 --> Final output sent to browser
DEBUG - 2016-10-08 18:55:15 --> Total execution time: 5.0655
INFO - 2016-10-08 18:55:26 --> Config Class Initialized
INFO - 2016-10-08 18:55:26 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:55:26 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:55:26 --> Utf8 Class Initialized
INFO - 2016-10-08 18:55:26 --> URI Class Initialized
INFO - 2016-10-08 18:55:26 --> Router Class Initialized
INFO - 2016-10-08 18:55:26 --> Output Class Initialized
INFO - 2016-10-08 18:55:26 --> Security Class Initialized
DEBUG - 2016-10-08 18:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:55:26 --> Input Class Initialized
INFO - 2016-10-08 18:55:26 --> Language Class Initialized
INFO - 2016-10-08 18:55:26 --> Language Class Initialized
INFO - 2016-10-08 18:55:26 --> Config Class Initialized
INFO - 2016-10-08 18:55:27 --> Loader Class Initialized
INFO - 2016-10-08 18:55:27 --> Helper loaded: url_helper
INFO - 2016-10-08 18:55:27 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 18:55:27 --> Controller Class Initialized
DEBUG - 2016-10-08 18:55:27 --> Index MX_Controller Initialized
INFO - 2016-10-08 18:55:27 --> Model Class Initialized
INFO - 2016-10-08 18:55:27 --> Model Class Initialized
ERROR - 2016-10-08 18:55:27 --> Unable to delete cache file for admin/index/do_ajukan_pinjaman
INFO - 2016-10-08 18:55:27 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:27 --> Database Driver Class Initialized
INFO - 2016-10-08 18:55:27 --> Final output sent to browser
DEBUG - 2016-10-08 18:55:27 --> Total execution time: 1.1061
INFO - 2016-10-08 18:56:22 --> Config Class Initialized
INFO - 2016-10-08 18:56:22 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:56:22 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:56:22 --> Utf8 Class Initialized
INFO - 2016-10-08 18:56:23 --> URI Class Initialized
INFO - 2016-10-08 18:56:23 --> Router Class Initialized
INFO - 2016-10-08 18:56:23 --> Output Class Initialized
INFO - 2016-10-08 18:56:23 --> Security Class Initialized
DEBUG - 2016-10-08 18:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:56:23 --> Input Class Initialized
INFO - 2016-10-08 18:56:23 --> Language Class Initialized
INFO - 2016-10-08 18:56:23 --> Language Class Initialized
INFO - 2016-10-08 18:56:23 --> Config Class Initialized
INFO - 2016-10-08 18:56:23 --> Loader Class Initialized
INFO - 2016-10-08 18:56:23 --> Helper loaded: url_helper
INFO - 2016-10-08 18:56:23 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 18:56:23 --> Controller Class Initialized
DEBUG - 2016-10-08 18:56:23 --> Index MX_Controller Initialized
INFO - 2016-10-08 18:56:23 --> Model Class Initialized
INFO - 2016-10-08 18:56:23 --> Model Class Initialized
ERROR - 2016-10-08 18:56:23 --> Unable to delete cache file for admin/index/batal/fe5dbbcea5ce7e2988b8c69bcfdfde8904aabc1f
INFO - 2016-10-08 18:56:23 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:23 --> Final output sent to browser
DEBUG - 2016-10-08 18:56:23 --> Total execution time: 1.1351
INFO - 2016-10-08 18:56:24 --> Config Class Initialized
INFO - 2016-10-08 18:56:24 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:56:24 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:56:24 --> Utf8 Class Initialized
INFO - 2016-10-08 18:56:24 --> URI Class Initialized
INFO - 2016-10-08 18:56:24 --> Router Class Initialized
INFO - 2016-10-08 18:56:24 --> Output Class Initialized
INFO - 2016-10-08 18:56:24 --> Security Class Initialized
DEBUG - 2016-10-08 18:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:56:24 --> Input Class Initialized
INFO - 2016-10-08 18:56:24 --> Language Class Initialized
INFO - 2016-10-08 18:56:24 --> Language Class Initialized
INFO - 2016-10-08 18:56:24 --> Config Class Initialized
INFO - 2016-10-08 18:56:24 --> Loader Class Initialized
INFO - 2016-10-08 18:56:24 --> Helper loaded: url_helper
INFO - 2016-10-08 18:56:24 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 18:56:25 --> Controller Class Initialized
DEBUG - 2016-10-08 18:56:25 --> Index MX_Controller Initialized
INFO - 2016-10-08 18:56:25 --> Model Class Initialized
INFO - 2016-10-08 18:56:25 --> Model Class Initialized
ERROR - 2016-10-08 18:56:25 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-10-08 18:56:25 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 18:56:25 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 18:56:25 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 18:56:25 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-10-08 18:56:25 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 18:56:25 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 18:56:25 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:25 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:25 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:25 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:25 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:25 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:25 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:25 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:25 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:25 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:26 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:26 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:26 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:26 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:26 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:26 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:26 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:26 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:26 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:26 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:26 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:26 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:26 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:26 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:26 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:26 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:26 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:26 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:26 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:27 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:27 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:27 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:27 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:27 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:27 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:27 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:27 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:27 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:27 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:27 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:27 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:27 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:27 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:27 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:27 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:27 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:27 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:28 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:28 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:28 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:28 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:28 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:28 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:28 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:28 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:28 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:28 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:28 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:28 --> Database Driver Class Initialized
DEBUG - 2016-10-08 18:56:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 18:56:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 18:56:28 --> Final output sent to browser
DEBUG - 2016-10-08 18:56:29 --> Total execution time: 4.8756
INFO - 2016-10-08 18:56:34 --> Config Class Initialized
INFO - 2016-10-08 18:56:34 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:56:34 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:56:34 --> Utf8 Class Initialized
INFO - 2016-10-08 18:56:34 --> URI Class Initialized
INFO - 2016-10-08 18:56:34 --> Router Class Initialized
INFO - 2016-10-08 18:56:34 --> Output Class Initialized
INFO - 2016-10-08 18:56:34 --> Security Class Initialized
DEBUG - 2016-10-08 18:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:56:34 --> Input Class Initialized
INFO - 2016-10-08 18:56:34 --> Language Class Initialized
INFO - 2016-10-08 18:56:34 --> Language Class Initialized
INFO - 2016-10-08 18:56:35 --> Config Class Initialized
INFO - 2016-10-08 18:56:35 --> Loader Class Initialized
INFO - 2016-10-08 18:56:35 --> Helper loaded: url_helper
INFO - 2016-10-08 18:56:35 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 18:56:35 --> Controller Class Initialized
DEBUG - 2016-10-08 18:56:35 --> Index MX_Controller Initialized
INFO - 2016-10-08 18:56:35 --> Model Class Initialized
INFO - 2016-10-08 18:56:35 --> Model Class Initialized
ERROR - 2016-10-08 18:56:35 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-08 18:56:35 --> Anggota MX_Controller Initialized
INFO - 2016-10-08 18:56:35 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:35 --> Final output sent to browser
DEBUG - 2016-10-08 18:56:35 --> Total execution time: 1.4132
INFO - 2016-10-08 18:56:37 --> Config Class Initialized
INFO - 2016-10-08 18:56:37 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:56:38 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:56:38 --> Utf8 Class Initialized
INFO - 2016-10-08 18:56:38 --> URI Class Initialized
INFO - 2016-10-08 18:56:38 --> Router Class Initialized
INFO - 2016-10-08 18:56:38 --> Output Class Initialized
INFO - 2016-10-08 18:56:38 --> Security Class Initialized
DEBUG - 2016-10-08 18:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:56:38 --> Input Class Initialized
INFO - 2016-10-08 18:56:38 --> Language Class Initialized
INFO - 2016-10-08 18:56:38 --> Language Class Initialized
INFO - 2016-10-08 18:56:38 --> Config Class Initialized
INFO - 2016-10-08 18:56:38 --> Loader Class Initialized
INFO - 2016-10-08 18:56:38 --> Helper loaded: url_helper
INFO - 2016-10-08 18:56:38 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 18:56:38 --> Controller Class Initialized
DEBUG - 2016-10-08 18:56:38 --> Index MX_Controller Initialized
INFO - 2016-10-08 18:56:39 --> Model Class Initialized
INFO - 2016-10-08 18:56:39 --> Model Class Initialized
ERROR - 2016-10-08 18:56:39 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-10-08 18:56:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 18:56:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 18:56:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 18:56:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_umum.php
DEBUG - 2016-10-08 18:56:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 18:56:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 18:56:39 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:39 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:39 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:39 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:39 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:39 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:39 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:40 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:40 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:40 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:40 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:40 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:40 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:40 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:40 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:40 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:40 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:40 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:40 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:40 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:41 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:41 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:41 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:41 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:41 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:41 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:41 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:41 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:41 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:41 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:41 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:41 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:41 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:41 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:41 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:41 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:41 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:42 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:42 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:42 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:42 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:42 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:42 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:42 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:42 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:42 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:42 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:42 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:42 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:42 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:42 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:42 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:42 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:42 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:43 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:43 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:43 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:43 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:43 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:43 --> Database Driver Class Initialized
DEBUG - 2016-10-08 18:56:43 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 18:56:43 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 18:56:43 --> Final output sent to browser
DEBUG - 2016-10-08 18:56:43 --> Total execution time: 5.4756
INFO - 2016-10-08 18:56:53 --> Config Class Initialized
INFO - 2016-10-08 18:56:53 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:56:53 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:56:53 --> Utf8 Class Initialized
INFO - 2016-10-08 18:56:53 --> URI Class Initialized
INFO - 2016-10-08 18:56:53 --> Router Class Initialized
INFO - 2016-10-08 18:56:53 --> Output Class Initialized
INFO - 2016-10-08 18:56:53 --> Security Class Initialized
DEBUG - 2016-10-08 18:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:56:53 --> Input Class Initialized
INFO - 2016-10-08 18:56:53 --> Language Class Initialized
INFO - 2016-10-08 18:56:53 --> Language Class Initialized
INFO - 2016-10-08 18:56:53 --> Config Class Initialized
INFO - 2016-10-08 18:56:54 --> Loader Class Initialized
INFO - 2016-10-08 18:56:54 --> Helper loaded: url_helper
INFO - 2016-10-08 18:56:54 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 18:56:54 --> Controller Class Initialized
DEBUG - 2016-10-08 18:56:54 --> Index MX_Controller Initialized
INFO - 2016-10-08 18:56:54 --> Model Class Initialized
INFO - 2016-10-08 18:56:54 --> Model Class Initialized
ERROR - 2016-10-08 18:56:54 --> Unable to delete cache file for admin/index/do_ajukan_pinjaman
INFO - 2016-10-08 18:56:54 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:54 --> Database Driver Class Initialized
INFO - 2016-10-08 18:56:54 --> Final output sent to browser
DEBUG - 2016-10-08 18:56:54 --> Total execution time: 1.3489
INFO - 2016-10-08 18:57:17 --> Config Class Initialized
INFO - 2016-10-08 18:57:17 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:57:18 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:57:18 --> Utf8 Class Initialized
INFO - 2016-10-08 18:57:18 --> URI Class Initialized
INFO - 2016-10-08 18:57:18 --> Router Class Initialized
INFO - 2016-10-08 18:57:18 --> Output Class Initialized
INFO - 2016-10-08 18:57:18 --> Security Class Initialized
DEBUG - 2016-10-08 18:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:57:18 --> Input Class Initialized
INFO - 2016-10-08 18:57:18 --> Language Class Initialized
INFO - 2016-10-08 18:57:18 --> Language Class Initialized
INFO - 2016-10-08 18:57:18 --> Config Class Initialized
INFO - 2016-10-08 18:57:18 --> Loader Class Initialized
INFO - 2016-10-08 18:57:18 --> Helper loaded: url_helper
INFO - 2016-10-08 18:57:18 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 18:57:19 --> Controller Class Initialized
DEBUG - 2016-10-08 18:57:19 --> Index MX_Controller Initialized
INFO - 2016-10-08 18:57:19 --> Model Class Initialized
INFO - 2016-10-08 18:57:19 --> Model Class Initialized
ERROR - 2016-10-08 18:57:19 --> Unable to delete cache file for admin/index/batal/0ade7c2cf97f75d009975f4d720d1fa6c19f4897
INFO - 2016-10-08 18:57:19 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:19 --> Final output sent to browser
DEBUG - 2016-10-08 18:57:19 --> Total execution time: 1.4560
INFO - 2016-10-08 18:57:19 --> Config Class Initialized
INFO - 2016-10-08 18:57:19 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:57:19 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:57:19 --> Utf8 Class Initialized
INFO - 2016-10-08 18:57:19 --> URI Class Initialized
INFO - 2016-10-08 18:57:19 --> Router Class Initialized
INFO - 2016-10-08 18:57:19 --> Output Class Initialized
INFO - 2016-10-08 18:57:19 --> Security Class Initialized
DEBUG - 2016-10-08 18:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:57:20 --> Input Class Initialized
INFO - 2016-10-08 18:57:20 --> Language Class Initialized
INFO - 2016-10-08 18:57:20 --> Language Class Initialized
INFO - 2016-10-08 18:57:20 --> Config Class Initialized
INFO - 2016-10-08 18:57:20 --> Loader Class Initialized
INFO - 2016-10-08 18:57:20 --> Helper loaded: url_helper
INFO - 2016-10-08 18:57:20 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 18:57:20 --> Controller Class Initialized
DEBUG - 2016-10-08 18:57:20 --> Index MX_Controller Initialized
INFO - 2016-10-08 18:57:20 --> Model Class Initialized
INFO - 2016-10-08 18:57:20 --> Model Class Initialized
ERROR - 2016-10-08 18:57:20 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-10-08 18:57:20 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 18:57:20 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 18:57:20 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 18:57:20 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-10-08 18:57:20 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 18:57:20 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 18:57:20 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:20 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:21 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:21 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:21 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:21 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:21 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:21 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:21 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:21 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:21 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:21 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:21 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:21 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:21 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:21 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:21 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:21 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:21 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:21 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:21 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:21 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:22 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:22 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:22 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:22 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:22 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:22 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:22 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:22 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:22 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:23 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:23 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:23 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:23 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:23 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:23 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:23 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:23 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:23 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:23 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:23 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:23 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:23 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:23 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:24 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:24 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:24 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:24 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:24 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:24 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:24 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:24 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:24 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:24 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:24 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:24 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:24 --> Database Driver Class Initialized
INFO - 2016-10-08 18:57:24 --> Database Driver Class Initialized
DEBUG - 2016-10-08 18:57:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 18:57:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 18:57:24 --> Final output sent to browser
DEBUG - 2016-10-08 18:57:24 --> Total execution time: 5.4127
INFO - 2016-10-08 18:59:25 --> Config Class Initialized
INFO - 2016-10-08 18:59:25 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:59:25 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:59:25 --> Utf8 Class Initialized
INFO - 2016-10-08 18:59:25 --> URI Class Initialized
INFO - 2016-10-08 18:59:25 --> Router Class Initialized
INFO - 2016-10-08 18:59:25 --> Output Class Initialized
INFO - 2016-10-08 18:59:25 --> Security Class Initialized
DEBUG - 2016-10-08 18:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:59:25 --> Input Class Initialized
INFO - 2016-10-08 18:59:25 --> Language Class Initialized
INFO - 2016-10-08 18:59:25 --> Language Class Initialized
INFO - 2016-10-08 18:59:25 --> Config Class Initialized
INFO - 2016-10-08 18:59:25 --> Loader Class Initialized
INFO - 2016-10-08 18:59:25 --> Helper loaded: url_helper
INFO - 2016-10-08 18:59:25 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 18:59:25 --> Controller Class Initialized
DEBUG - 2016-10-08 18:59:25 --> Index MX_Controller Initialized
INFO - 2016-10-08 18:59:26 --> Model Class Initialized
INFO - 2016-10-08 18:59:26 --> Model Class Initialized
ERROR - 2016-10-08 18:59:26 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-08 18:59:26 --> Anggota MX_Controller Initialized
INFO - 2016-10-08 18:59:26 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:26 --> Final output sent to browser
DEBUG - 2016-10-08 18:59:26 --> Total execution time: 1.0983
INFO - 2016-10-08 18:59:27 --> Config Class Initialized
INFO - 2016-10-08 18:59:27 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:59:27 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:59:27 --> Utf8 Class Initialized
INFO - 2016-10-08 18:59:27 --> URI Class Initialized
INFO - 2016-10-08 18:59:28 --> Router Class Initialized
INFO - 2016-10-08 18:59:28 --> Output Class Initialized
INFO - 2016-10-08 18:59:28 --> Security Class Initialized
DEBUG - 2016-10-08 18:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:59:28 --> Input Class Initialized
INFO - 2016-10-08 18:59:28 --> Language Class Initialized
INFO - 2016-10-08 18:59:28 --> Language Class Initialized
INFO - 2016-10-08 18:59:28 --> Config Class Initialized
INFO - 2016-10-08 18:59:28 --> Loader Class Initialized
INFO - 2016-10-08 18:59:28 --> Helper loaded: url_helper
INFO - 2016-10-08 18:59:28 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 18:59:28 --> Controller Class Initialized
DEBUG - 2016-10-08 18:59:28 --> Index MX_Controller Initialized
INFO - 2016-10-08 18:59:28 --> Model Class Initialized
INFO - 2016-10-08 18:59:28 --> Model Class Initialized
ERROR - 2016-10-08 18:59:28 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-10-08 18:59:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 18:59:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 18:59:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 18:59:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_umum.php
DEBUG - 2016-10-08 18:59:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 18:59:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 18:59:29 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:29 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:29 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:29 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:29 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:29 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:29 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:29 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:29 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:29 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:29 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:29 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:29 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:29 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:29 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:29 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:29 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:29 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:30 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:30 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:30 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:30 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:30 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:30 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:30 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:30 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:30 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:30 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:30 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:30 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:30 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:30 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:30 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:30 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:30 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:30 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:30 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:30 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:31 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:31 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:31 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:31 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:31 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:31 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:31 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:31 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:31 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:31 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:31 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:31 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:31 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:31 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:31 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:31 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:31 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:31 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:31 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:31 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:32 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:32 --> Database Driver Class Initialized
DEBUG - 2016-10-08 18:59:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 18:59:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 18:59:32 --> Final output sent to browser
DEBUG - 2016-10-08 18:59:32 --> Total execution time: 4.5546
INFO - 2016-10-08 18:59:45 --> Config Class Initialized
INFO - 2016-10-08 18:59:45 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:59:45 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:59:45 --> Utf8 Class Initialized
INFO - 2016-10-08 18:59:45 --> URI Class Initialized
INFO - 2016-10-08 18:59:45 --> Router Class Initialized
INFO - 2016-10-08 18:59:45 --> Output Class Initialized
INFO - 2016-10-08 18:59:45 --> Security Class Initialized
DEBUG - 2016-10-08 18:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:59:45 --> Input Class Initialized
INFO - 2016-10-08 18:59:45 --> Language Class Initialized
INFO - 2016-10-08 18:59:46 --> Language Class Initialized
INFO - 2016-10-08 18:59:46 --> Config Class Initialized
INFO - 2016-10-08 18:59:46 --> Loader Class Initialized
INFO - 2016-10-08 18:59:46 --> Helper loaded: url_helper
INFO - 2016-10-08 18:59:46 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 18:59:46 --> Controller Class Initialized
DEBUG - 2016-10-08 18:59:46 --> Index MX_Controller Initialized
INFO - 2016-10-08 18:59:46 --> Model Class Initialized
INFO - 2016-10-08 18:59:46 --> Model Class Initialized
ERROR - 2016-10-08 18:59:46 --> Unable to delete cache file for admin/index/do_ajukan_pinjaman
INFO - 2016-10-08 18:59:46 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:46 --> Database Driver Class Initialized
INFO - 2016-10-08 18:59:46 --> Final output sent to browser
DEBUG - 2016-10-08 18:59:46 --> Total execution time: 1.4225
INFO - 2016-10-08 19:03:04 --> Config Class Initialized
INFO - 2016-10-08 19:03:04 --> Hooks Class Initialized
DEBUG - 2016-10-08 19:03:04 --> UTF-8 Support Enabled
INFO - 2016-10-08 19:03:04 --> Utf8 Class Initialized
INFO - 2016-10-08 19:03:04 --> URI Class Initialized
INFO - 2016-10-08 19:03:04 --> Router Class Initialized
INFO - 2016-10-08 19:03:04 --> Output Class Initialized
INFO - 2016-10-08 19:03:04 --> Security Class Initialized
DEBUG - 2016-10-08 19:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 19:03:04 --> Input Class Initialized
INFO - 2016-10-08 19:03:04 --> Language Class Initialized
INFO - 2016-10-08 19:03:04 --> Language Class Initialized
INFO - 2016-10-08 19:03:04 --> Config Class Initialized
INFO - 2016-10-08 19:03:04 --> Loader Class Initialized
INFO - 2016-10-08 19:03:04 --> Helper loaded: url_helper
INFO - 2016-10-08 19:03:04 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 19:03:04 --> Controller Class Initialized
DEBUG - 2016-10-08 19:03:05 --> Index MX_Controller Initialized
INFO - 2016-10-08 19:03:05 --> Model Class Initialized
INFO - 2016-10-08 19:03:05 --> Model Class Initialized
ERROR - 2016-10-08 19:03:05 --> Unable to delete cache file for admin/index/batal/b1d5781111d84f7b3fe45a0852e59758cd7a87e5
INFO - 2016-10-08 19:03:05 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:05 --> Final output sent to browser
DEBUG - 2016-10-08 19:03:05 --> Total execution time: 1.2927
INFO - 2016-10-08 19:03:05 --> Config Class Initialized
INFO - 2016-10-08 19:03:05 --> Hooks Class Initialized
DEBUG - 2016-10-08 19:03:05 --> UTF-8 Support Enabled
INFO - 2016-10-08 19:03:05 --> Utf8 Class Initialized
INFO - 2016-10-08 19:03:05 --> URI Class Initialized
INFO - 2016-10-08 19:03:05 --> Router Class Initialized
INFO - 2016-10-08 19:03:05 --> Output Class Initialized
INFO - 2016-10-08 19:03:05 --> Security Class Initialized
DEBUG - 2016-10-08 19:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 19:03:06 --> Input Class Initialized
INFO - 2016-10-08 19:03:06 --> Language Class Initialized
INFO - 2016-10-08 19:03:06 --> Language Class Initialized
INFO - 2016-10-08 19:03:06 --> Config Class Initialized
INFO - 2016-10-08 19:03:06 --> Loader Class Initialized
INFO - 2016-10-08 19:03:06 --> Helper loaded: url_helper
INFO - 2016-10-08 19:03:06 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 19:03:06 --> Controller Class Initialized
DEBUG - 2016-10-08 19:03:06 --> Index MX_Controller Initialized
INFO - 2016-10-08 19:03:06 --> Model Class Initialized
INFO - 2016-10-08 19:03:06 --> Model Class Initialized
ERROR - 2016-10-08 19:03:06 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-10-08 19:03:06 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 19:03:06 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 19:03:06 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 19:03:06 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-10-08 19:03:06 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 19:03:06 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 19:03:06 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:07 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:07 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:07 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:07 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:07 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:07 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:07 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:07 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:07 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:07 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:07 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:07 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:07 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:07 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:07 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:08 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:08 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:08 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:08 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:08 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:08 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:08 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:08 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:08 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:08 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:08 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:08 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:08 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:08 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:08 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:08 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:08 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:09 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:09 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:09 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:09 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:09 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:09 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:09 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:09 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:09 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:09 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:09 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:09 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:09 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:09 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:09 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:09 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:09 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:09 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:09 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:10 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:10 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:10 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:10 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:10 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:10 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:10 --> Database Driver Class Initialized
DEBUG - 2016-10-08 19:03:10 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 19:03:10 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 19:03:10 --> Final output sent to browser
DEBUG - 2016-10-08 19:03:10 --> Total execution time: 4.8877
INFO - 2016-10-08 19:03:17 --> Config Class Initialized
INFO - 2016-10-08 19:03:17 --> Hooks Class Initialized
DEBUG - 2016-10-08 19:03:17 --> UTF-8 Support Enabled
INFO - 2016-10-08 19:03:17 --> Utf8 Class Initialized
INFO - 2016-10-08 19:03:17 --> URI Class Initialized
INFO - 2016-10-08 19:03:17 --> Router Class Initialized
INFO - 2016-10-08 19:03:17 --> Output Class Initialized
INFO - 2016-10-08 19:03:18 --> Security Class Initialized
DEBUG - 2016-10-08 19:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 19:03:18 --> Input Class Initialized
INFO - 2016-10-08 19:03:18 --> Language Class Initialized
INFO - 2016-10-08 19:03:18 --> Language Class Initialized
INFO - 2016-10-08 19:03:18 --> Config Class Initialized
INFO - 2016-10-08 19:03:18 --> Loader Class Initialized
INFO - 2016-10-08 19:03:18 --> Helper loaded: url_helper
INFO - 2016-10-08 19:03:18 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 19:03:18 --> Controller Class Initialized
DEBUG - 2016-10-08 19:03:18 --> Index MX_Controller Initialized
INFO - 2016-10-08 19:03:18 --> Model Class Initialized
INFO - 2016-10-08 19:03:18 --> Model Class Initialized
ERROR - 2016-10-08 19:03:18 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-08 19:03:18 --> Anggota MX_Controller Initialized
INFO - 2016-10-08 19:03:18 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:18 --> Final output sent to browser
DEBUG - 2016-10-08 19:03:18 --> Total execution time: 1.0824
INFO - 2016-10-08 19:03:20 --> Config Class Initialized
INFO - 2016-10-08 19:03:20 --> Hooks Class Initialized
DEBUG - 2016-10-08 19:03:20 --> UTF-8 Support Enabled
INFO - 2016-10-08 19:03:20 --> Utf8 Class Initialized
INFO - 2016-10-08 19:03:20 --> URI Class Initialized
INFO - 2016-10-08 19:03:20 --> Router Class Initialized
INFO - 2016-10-08 19:03:20 --> Output Class Initialized
INFO - 2016-10-08 19:03:20 --> Security Class Initialized
DEBUG - 2016-10-08 19:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 19:03:20 --> Input Class Initialized
INFO - 2016-10-08 19:03:20 --> Language Class Initialized
INFO - 2016-10-08 19:03:20 --> Language Class Initialized
INFO - 2016-10-08 19:03:20 --> Config Class Initialized
INFO - 2016-10-08 19:03:20 --> Loader Class Initialized
INFO - 2016-10-08 19:03:20 --> Helper loaded: url_helper
INFO - 2016-10-08 19:03:21 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 19:03:21 --> Controller Class Initialized
DEBUG - 2016-10-08 19:03:21 --> Index MX_Controller Initialized
INFO - 2016-10-08 19:03:21 --> Model Class Initialized
INFO - 2016-10-08 19:03:21 --> Model Class Initialized
ERROR - 2016-10-08 19:03:21 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-10-08 19:03:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 19:03:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 19:03:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 19:03:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_umum.php
DEBUG - 2016-10-08 19:03:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 19:03:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 19:03:21 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:21 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:21 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:21 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:21 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:21 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:21 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:21 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:21 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:21 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:21 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:21 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:22 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:22 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:22 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:22 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:22 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:22 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:22 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:22 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:22 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:22 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:22 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:22 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:22 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:22 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:22 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:22 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:22 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:22 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:22 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:22 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:22 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:22 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:22 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:23 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:23 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:23 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:23 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:23 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:23 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:23 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:23 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:23 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:23 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:23 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:23 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:23 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:23 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:23 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:23 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:23 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:23 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:23 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:23 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:23 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:23 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:24 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:24 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:24 --> Database Driver Class Initialized
DEBUG - 2016-10-08 19:03:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 19:03:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 19:03:24 --> Final output sent to browser
DEBUG - 2016-10-08 19:03:24 --> Total execution time: 3.9296
INFO - 2016-10-08 19:03:33 --> Config Class Initialized
INFO - 2016-10-08 19:03:33 --> Hooks Class Initialized
DEBUG - 2016-10-08 19:03:33 --> UTF-8 Support Enabled
INFO - 2016-10-08 19:03:33 --> Utf8 Class Initialized
INFO - 2016-10-08 19:03:33 --> URI Class Initialized
INFO - 2016-10-08 19:03:33 --> Router Class Initialized
INFO - 2016-10-08 19:03:33 --> Output Class Initialized
INFO - 2016-10-08 19:03:34 --> Security Class Initialized
DEBUG - 2016-10-08 19:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 19:03:34 --> Input Class Initialized
INFO - 2016-10-08 19:03:34 --> Language Class Initialized
INFO - 2016-10-08 19:03:34 --> Language Class Initialized
INFO - 2016-10-08 19:03:34 --> Config Class Initialized
INFO - 2016-10-08 19:03:34 --> Loader Class Initialized
INFO - 2016-10-08 19:03:34 --> Helper loaded: url_helper
INFO - 2016-10-08 19:03:34 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 19:03:34 --> Controller Class Initialized
DEBUG - 2016-10-08 19:03:34 --> Index MX_Controller Initialized
INFO - 2016-10-08 19:03:34 --> Model Class Initialized
INFO - 2016-10-08 19:03:34 --> Model Class Initialized
ERROR - 2016-10-08 19:03:34 --> Unable to delete cache file for admin/index/do_ajukan_pinjaman
INFO - 2016-10-08 19:03:34 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:34 --> Database Driver Class Initialized
INFO - 2016-10-08 19:03:34 --> Final output sent to browser
DEBUG - 2016-10-08 19:03:35 --> Total execution time: 1.3012
INFO - 2016-10-08 19:05:14 --> Config Class Initialized
INFO - 2016-10-08 19:05:14 --> Hooks Class Initialized
DEBUG - 2016-10-08 19:05:14 --> UTF-8 Support Enabled
INFO - 2016-10-08 19:05:14 --> Utf8 Class Initialized
INFO - 2016-10-08 19:05:14 --> URI Class Initialized
INFO - 2016-10-08 19:05:14 --> Router Class Initialized
INFO - 2016-10-08 19:05:14 --> Output Class Initialized
INFO - 2016-10-08 19:05:14 --> Security Class Initialized
DEBUG - 2016-10-08 19:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 19:05:14 --> Input Class Initialized
INFO - 2016-10-08 19:05:15 --> Language Class Initialized
INFO - 2016-10-08 19:05:15 --> Language Class Initialized
INFO - 2016-10-08 19:05:15 --> Config Class Initialized
INFO - 2016-10-08 19:05:15 --> Loader Class Initialized
INFO - 2016-10-08 19:05:15 --> Helper loaded: url_helper
INFO - 2016-10-08 19:05:15 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 19:05:15 --> Controller Class Initialized
DEBUG - 2016-10-08 19:05:15 --> Index MX_Controller Initialized
INFO - 2016-10-08 19:05:15 --> Model Class Initialized
INFO - 2016-10-08 19:05:15 --> Model Class Initialized
ERROR - 2016-10-08 19:05:15 --> Unable to delete cache file for admin/index/batal/17ba0791499db908433b80f37c5fbc89b870084b
INFO - 2016-10-08 19:05:15 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:15 --> Final output sent to browser
DEBUG - 2016-10-08 19:05:15 --> Total execution time: 1.0573
INFO - 2016-10-08 19:05:15 --> Config Class Initialized
INFO - 2016-10-08 19:05:15 --> Hooks Class Initialized
DEBUG - 2016-10-08 19:05:15 --> UTF-8 Support Enabled
INFO - 2016-10-08 19:05:15 --> Utf8 Class Initialized
INFO - 2016-10-08 19:05:15 --> URI Class Initialized
INFO - 2016-10-08 19:05:16 --> Router Class Initialized
INFO - 2016-10-08 19:05:16 --> Output Class Initialized
INFO - 2016-10-08 19:05:16 --> Security Class Initialized
DEBUG - 2016-10-08 19:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 19:05:16 --> Input Class Initialized
INFO - 2016-10-08 19:05:16 --> Language Class Initialized
INFO - 2016-10-08 19:05:16 --> Language Class Initialized
INFO - 2016-10-08 19:05:16 --> Config Class Initialized
INFO - 2016-10-08 19:05:16 --> Loader Class Initialized
INFO - 2016-10-08 19:05:16 --> Helper loaded: url_helper
INFO - 2016-10-08 19:05:16 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 19:05:16 --> Controller Class Initialized
DEBUG - 2016-10-08 19:05:16 --> Index MX_Controller Initialized
INFO - 2016-10-08 19:05:16 --> Model Class Initialized
INFO - 2016-10-08 19:05:16 --> Model Class Initialized
ERROR - 2016-10-08 19:05:16 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-10-08 19:05:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 19:05:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 19:05:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 19:05:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-10-08 19:05:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 19:05:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 19:05:17 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:17 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:17 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:17 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:17 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:17 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:17 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:17 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:17 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:17 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:17 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:17 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:17 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:17 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:17 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:17 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:17 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:17 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:17 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:17 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:17 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:17 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:17 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:18 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:18 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:18 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:18 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:18 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:18 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:18 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:18 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:18 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:18 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:18 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:18 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:18 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:18 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:18 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:18 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:18 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:18 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:18 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:18 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:18 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:18 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:18 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:19 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:19 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:19 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:19 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:19 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:19 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:19 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:19 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:19 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:19 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:19 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:19 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:19 --> Database Driver Class Initialized
DEBUG - 2016-10-08 19:05:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 19:05:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 19:05:19 --> Final output sent to browser
DEBUG - 2016-10-08 19:05:19 --> Total execution time: 3.8784
INFO - 2016-10-08 19:05:26 --> Config Class Initialized
INFO - 2016-10-08 19:05:26 --> Hooks Class Initialized
DEBUG - 2016-10-08 19:05:26 --> UTF-8 Support Enabled
INFO - 2016-10-08 19:05:26 --> Utf8 Class Initialized
INFO - 2016-10-08 19:05:26 --> URI Class Initialized
INFO - 2016-10-08 19:05:26 --> Router Class Initialized
INFO - 2016-10-08 19:05:26 --> Output Class Initialized
INFO - 2016-10-08 19:05:26 --> Security Class Initialized
DEBUG - 2016-10-08 19:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 19:05:26 --> Input Class Initialized
INFO - 2016-10-08 19:05:26 --> Language Class Initialized
INFO - 2016-10-08 19:05:26 --> Language Class Initialized
INFO - 2016-10-08 19:05:26 --> Config Class Initialized
INFO - 2016-10-08 19:05:27 --> Loader Class Initialized
INFO - 2016-10-08 19:05:27 --> Helper loaded: url_helper
INFO - 2016-10-08 19:05:27 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 19:05:27 --> Controller Class Initialized
DEBUG - 2016-10-08 19:05:27 --> Index MX_Controller Initialized
INFO - 2016-10-08 19:05:27 --> Model Class Initialized
INFO - 2016-10-08 19:05:27 --> Model Class Initialized
ERROR - 2016-10-08 19:05:27 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-08 19:05:27 --> Anggota MX_Controller Initialized
INFO - 2016-10-08 19:05:27 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:27 --> Final output sent to browser
DEBUG - 2016-10-08 19:05:27 --> Total execution time: 0.9683
INFO - 2016-10-08 19:05:28 --> Config Class Initialized
INFO - 2016-10-08 19:05:28 --> Hooks Class Initialized
DEBUG - 2016-10-08 19:05:29 --> UTF-8 Support Enabled
INFO - 2016-10-08 19:05:29 --> Utf8 Class Initialized
INFO - 2016-10-08 19:05:29 --> URI Class Initialized
INFO - 2016-10-08 19:05:29 --> Router Class Initialized
INFO - 2016-10-08 19:05:29 --> Output Class Initialized
INFO - 2016-10-08 19:05:29 --> Security Class Initialized
DEBUG - 2016-10-08 19:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 19:05:29 --> Input Class Initialized
INFO - 2016-10-08 19:05:29 --> Language Class Initialized
INFO - 2016-10-08 19:05:29 --> Language Class Initialized
INFO - 2016-10-08 19:05:29 --> Config Class Initialized
INFO - 2016-10-08 19:05:29 --> Loader Class Initialized
INFO - 2016-10-08 19:05:29 --> Helper loaded: url_helper
INFO - 2016-10-08 19:05:29 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 19:05:29 --> Controller Class Initialized
DEBUG - 2016-10-08 19:05:29 --> Index MX_Controller Initialized
INFO - 2016-10-08 19:05:29 --> Model Class Initialized
INFO - 2016-10-08 19:05:29 --> Model Class Initialized
ERROR - 2016-10-08 19:05:29 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-10-08 19:05:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 19:05:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 19:05:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 19:05:30 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_umum.php
DEBUG - 2016-10-08 19:05:30 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 19:05:30 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 19:05:30 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:30 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:30 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:30 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:30 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:30 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:30 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:30 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:30 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:30 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:30 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:30 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:30 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:30 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:30 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:30 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:30 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:30 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:30 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:31 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:31 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:31 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:31 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:31 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:31 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:31 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:31 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:31 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:31 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:31 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:31 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:31 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:31 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:31 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:31 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:31 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:31 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:31 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:31 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:32 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:32 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:32 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:32 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:32 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:32 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:32 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:32 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:32 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:32 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:32 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:32 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:32 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:32 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:32 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:32 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:32 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:33 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:33 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:33 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:33 --> Database Driver Class Initialized
DEBUG - 2016-10-08 19:05:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 19:05:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 19:05:33 --> Final output sent to browser
DEBUG - 2016-10-08 19:05:33 --> Total execution time: 4.3935
INFO - 2016-10-08 19:05:40 --> Config Class Initialized
INFO - 2016-10-08 19:05:40 --> Hooks Class Initialized
DEBUG - 2016-10-08 19:05:40 --> UTF-8 Support Enabled
INFO - 2016-10-08 19:05:40 --> Utf8 Class Initialized
INFO - 2016-10-08 19:05:40 --> URI Class Initialized
INFO - 2016-10-08 19:05:40 --> Router Class Initialized
INFO - 2016-10-08 19:05:40 --> Output Class Initialized
INFO - 2016-10-08 19:05:41 --> Security Class Initialized
DEBUG - 2016-10-08 19:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 19:05:41 --> Input Class Initialized
INFO - 2016-10-08 19:05:41 --> Language Class Initialized
INFO - 2016-10-08 19:05:41 --> Language Class Initialized
INFO - 2016-10-08 19:05:41 --> Config Class Initialized
INFO - 2016-10-08 19:05:41 --> Loader Class Initialized
INFO - 2016-10-08 19:05:41 --> Helper loaded: url_helper
INFO - 2016-10-08 19:05:41 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 19:05:41 --> Controller Class Initialized
DEBUG - 2016-10-08 19:05:41 --> Index MX_Controller Initialized
INFO - 2016-10-08 19:05:41 --> Model Class Initialized
INFO - 2016-10-08 19:05:41 --> Model Class Initialized
ERROR - 2016-10-08 19:05:41 --> Unable to delete cache file for admin/index/do_ajukan_pinjaman
INFO - 2016-10-08 19:05:41 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:42 --> Database Driver Class Initialized
INFO - 2016-10-08 19:05:42 --> Final output sent to browser
DEBUG - 2016-10-08 19:05:42 --> Total execution time: 1.6930
INFO - 2016-10-08 19:06:12 --> Config Class Initialized
INFO - 2016-10-08 19:06:12 --> Hooks Class Initialized
DEBUG - 2016-10-08 19:06:12 --> UTF-8 Support Enabled
INFO - 2016-10-08 19:06:12 --> Utf8 Class Initialized
INFO - 2016-10-08 19:06:12 --> URI Class Initialized
INFO - 2016-10-08 19:06:12 --> Router Class Initialized
INFO - 2016-10-08 19:06:12 --> Output Class Initialized
INFO - 2016-10-08 19:06:12 --> Security Class Initialized
DEBUG - 2016-10-08 19:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 19:06:13 --> Input Class Initialized
INFO - 2016-10-08 19:06:13 --> Language Class Initialized
INFO - 2016-10-08 19:06:13 --> Language Class Initialized
INFO - 2016-10-08 19:06:13 --> Config Class Initialized
INFO - 2016-10-08 19:06:13 --> Loader Class Initialized
INFO - 2016-10-08 19:06:13 --> Helper loaded: url_helper
INFO - 2016-10-08 19:06:13 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 19:06:13 --> Controller Class Initialized
DEBUG - 2016-10-08 19:06:13 --> Index MX_Controller Initialized
INFO - 2016-10-08 19:06:13 --> Model Class Initialized
INFO - 2016-10-08 19:06:13 --> Model Class Initialized
ERROR - 2016-10-08 19:06:13 --> Unable to delete cache file for admin/index/batal/7b52009b64fd0a2a49e6d8a939753077792b0554
INFO - 2016-10-08 19:06:13 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:13 --> Final output sent to browser
DEBUG - 2016-10-08 19:06:13 --> Total execution time: 1.0608
INFO - 2016-10-08 19:06:13 --> Config Class Initialized
INFO - 2016-10-08 19:06:13 --> Hooks Class Initialized
DEBUG - 2016-10-08 19:06:13 --> UTF-8 Support Enabled
INFO - 2016-10-08 19:06:13 --> Utf8 Class Initialized
INFO - 2016-10-08 19:06:14 --> URI Class Initialized
INFO - 2016-10-08 19:06:14 --> Router Class Initialized
INFO - 2016-10-08 19:06:14 --> Output Class Initialized
INFO - 2016-10-08 19:06:14 --> Security Class Initialized
DEBUG - 2016-10-08 19:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 19:06:14 --> Input Class Initialized
INFO - 2016-10-08 19:06:14 --> Language Class Initialized
INFO - 2016-10-08 19:06:14 --> Language Class Initialized
INFO - 2016-10-08 19:06:14 --> Config Class Initialized
INFO - 2016-10-08 19:06:14 --> Loader Class Initialized
INFO - 2016-10-08 19:06:14 --> Helper loaded: url_helper
INFO - 2016-10-08 19:06:14 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 19:06:14 --> Controller Class Initialized
DEBUG - 2016-10-08 19:06:14 --> Index MX_Controller Initialized
INFO - 2016-10-08 19:06:14 --> Model Class Initialized
INFO - 2016-10-08 19:06:14 --> Model Class Initialized
ERROR - 2016-10-08 19:06:14 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-10-08 19:06:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 19:06:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 19:06:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 19:06:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-10-08 19:06:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 19:06:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 19:06:15 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:15 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:15 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:15 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:15 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:15 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:15 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:15 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:15 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:15 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:15 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:15 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:15 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:16 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:16 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:16 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:16 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:16 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:16 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:16 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:16 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:16 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:16 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:16 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:16 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:16 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:16 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:16 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:16 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:16 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:16 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:16 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:16 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:16 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:16 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:17 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:17 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:17 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:17 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:17 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:17 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:17 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:17 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:17 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:17 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:17 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:17 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:17 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:17 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:17 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:17 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:17 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:17 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:17 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:17 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:17 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:18 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:18 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:18 --> Database Driver Class Initialized
DEBUG - 2016-10-08 19:06:18 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 19:06:18 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 19:06:18 --> Final output sent to browser
DEBUG - 2016-10-08 19:06:18 --> Total execution time: 4.4136
INFO - 2016-10-08 19:06:24 --> Config Class Initialized
INFO - 2016-10-08 19:06:24 --> Hooks Class Initialized
DEBUG - 2016-10-08 19:06:24 --> UTF-8 Support Enabled
INFO - 2016-10-08 19:06:24 --> Utf8 Class Initialized
INFO - 2016-10-08 19:06:24 --> URI Class Initialized
INFO - 2016-10-08 19:06:24 --> Router Class Initialized
INFO - 2016-10-08 19:06:24 --> Output Class Initialized
INFO - 2016-10-08 19:06:24 --> Security Class Initialized
DEBUG - 2016-10-08 19:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 19:06:24 --> Input Class Initialized
INFO - 2016-10-08 19:06:24 --> Language Class Initialized
INFO - 2016-10-08 19:06:24 --> Language Class Initialized
INFO - 2016-10-08 19:06:25 --> Config Class Initialized
INFO - 2016-10-08 19:06:25 --> Loader Class Initialized
INFO - 2016-10-08 19:06:25 --> Helper loaded: url_helper
INFO - 2016-10-08 19:06:25 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 19:06:25 --> Controller Class Initialized
DEBUG - 2016-10-08 19:06:25 --> Index MX_Controller Initialized
INFO - 2016-10-08 19:06:25 --> Model Class Initialized
INFO - 2016-10-08 19:06:25 --> Model Class Initialized
ERROR - 2016-10-08 19:06:25 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-08 19:06:25 --> Anggota MX_Controller Initialized
INFO - 2016-10-08 19:06:25 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:25 --> Final output sent to browser
DEBUG - 2016-10-08 19:06:25 --> Total execution time: 1.0309
INFO - 2016-10-08 19:06:26 --> Config Class Initialized
INFO - 2016-10-08 19:06:27 --> Hooks Class Initialized
DEBUG - 2016-10-08 19:06:27 --> UTF-8 Support Enabled
INFO - 2016-10-08 19:06:27 --> Utf8 Class Initialized
INFO - 2016-10-08 19:06:27 --> URI Class Initialized
INFO - 2016-10-08 19:06:27 --> Router Class Initialized
INFO - 2016-10-08 19:06:27 --> Output Class Initialized
INFO - 2016-10-08 19:06:27 --> Security Class Initialized
DEBUG - 2016-10-08 19:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 19:06:27 --> Input Class Initialized
INFO - 2016-10-08 19:06:27 --> Language Class Initialized
INFO - 2016-10-08 19:06:27 --> Language Class Initialized
INFO - 2016-10-08 19:06:27 --> Config Class Initialized
INFO - 2016-10-08 19:06:27 --> Loader Class Initialized
INFO - 2016-10-08 19:06:27 --> Helper loaded: url_helper
INFO - 2016-10-08 19:06:27 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 19:06:27 --> Controller Class Initialized
DEBUG - 2016-10-08 19:06:27 --> Index MX_Controller Initialized
INFO - 2016-10-08 19:06:27 --> Model Class Initialized
INFO - 2016-10-08 19:06:27 --> Model Class Initialized
ERROR - 2016-10-08 19:06:27 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-10-08 19:06:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 19:06:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 19:06:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 19:06:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_umum.php
DEBUG - 2016-10-08 19:06:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 19:06:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 19:06:28 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:28 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:28 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:28 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:28 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:28 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:28 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:28 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:28 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:28 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:28 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:28 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:28 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:28 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:28 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:28 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:28 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:28 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:28 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:28 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:29 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:29 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:29 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:29 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:29 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:29 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:29 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:29 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:29 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:29 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:29 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:29 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:29 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:29 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:29 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:29 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:29 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:29 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:29 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:29 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:29 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:29 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:30 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:30 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:30 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:30 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:30 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:30 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:30 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:30 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:30 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:30 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:30 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:30 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:30 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:30 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:30 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:30 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:30 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:30 --> Database Driver Class Initialized
DEBUG - 2016-10-08 19:06:30 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 19:06:30 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 19:06:30 --> Final output sent to browser
DEBUG - 2016-10-08 19:06:30 --> Total execution time: 3.9812
INFO - 2016-10-08 19:06:37 --> Config Class Initialized
INFO - 2016-10-08 19:06:37 --> Hooks Class Initialized
DEBUG - 2016-10-08 19:06:37 --> UTF-8 Support Enabled
INFO - 2016-10-08 19:06:37 --> Utf8 Class Initialized
INFO - 2016-10-08 19:06:37 --> URI Class Initialized
INFO - 2016-10-08 19:06:37 --> Router Class Initialized
INFO - 2016-10-08 19:06:37 --> Output Class Initialized
INFO - 2016-10-08 19:06:37 --> Security Class Initialized
DEBUG - 2016-10-08 19:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 19:06:37 --> Input Class Initialized
INFO - 2016-10-08 19:06:37 --> Language Class Initialized
INFO - 2016-10-08 19:06:37 --> Language Class Initialized
INFO - 2016-10-08 19:06:37 --> Config Class Initialized
INFO - 2016-10-08 19:06:38 --> Loader Class Initialized
INFO - 2016-10-08 19:06:38 --> Helper loaded: url_helper
INFO - 2016-10-08 19:06:38 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 19:06:38 --> Controller Class Initialized
DEBUG - 2016-10-08 19:06:38 --> Index MX_Controller Initialized
INFO - 2016-10-08 19:06:38 --> Model Class Initialized
INFO - 2016-10-08 19:06:38 --> Model Class Initialized
ERROR - 2016-10-08 19:06:38 --> Unable to delete cache file for admin/index/do_ajukan_pinjaman
INFO - 2016-10-08 19:06:38 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:38 --> Database Driver Class Initialized
INFO - 2016-10-08 19:06:38 --> Final output sent to browser
DEBUG - 2016-10-08 19:06:38 --> Total execution time: 1.2490
INFO - 2016-10-08 19:09:17 --> Config Class Initialized
INFO - 2016-10-08 19:09:17 --> Hooks Class Initialized
DEBUG - 2016-10-08 19:09:17 --> UTF-8 Support Enabled
INFO - 2016-10-08 19:09:17 --> Utf8 Class Initialized
INFO - 2016-10-08 19:09:17 --> URI Class Initialized
INFO - 2016-10-08 19:09:17 --> Router Class Initialized
INFO - 2016-10-08 19:09:17 --> Output Class Initialized
INFO - 2016-10-08 19:09:17 --> Security Class Initialized
DEBUG - 2016-10-08 19:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 19:09:17 --> Input Class Initialized
INFO - 2016-10-08 19:09:17 --> Language Class Initialized
INFO - 2016-10-08 19:09:17 --> Language Class Initialized
INFO - 2016-10-08 19:09:17 --> Config Class Initialized
INFO - 2016-10-08 19:09:17 --> Loader Class Initialized
INFO - 2016-10-08 19:09:17 --> Helper loaded: url_helper
INFO - 2016-10-08 19:09:18 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 19:09:18 --> Controller Class Initialized
DEBUG - 2016-10-08 19:09:18 --> Index MX_Controller Initialized
INFO - 2016-10-08 19:09:18 --> Model Class Initialized
INFO - 2016-10-08 19:09:18 --> Model Class Initialized
ERROR - 2016-10-08 19:09:18 --> Unable to delete cache file for admin/index/batal/bd307a3ec329e10a2cff8fb87480823da114f8f4
INFO - 2016-10-08 19:09:18 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:18 --> Final output sent to browser
DEBUG - 2016-10-08 19:09:18 --> Total execution time: 0.9931
INFO - 2016-10-08 19:09:18 --> Config Class Initialized
INFO - 2016-10-08 19:09:18 --> Hooks Class Initialized
DEBUG - 2016-10-08 19:09:18 --> UTF-8 Support Enabled
INFO - 2016-10-08 19:09:18 --> Utf8 Class Initialized
INFO - 2016-10-08 19:09:18 --> URI Class Initialized
INFO - 2016-10-08 19:09:18 --> Router Class Initialized
INFO - 2016-10-08 19:09:18 --> Output Class Initialized
INFO - 2016-10-08 19:09:18 --> Security Class Initialized
DEBUG - 2016-10-08 19:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 19:09:19 --> Input Class Initialized
INFO - 2016-10-08 19:09:19 --> Language Class Initialized
INFO - 2016-10-08 19:09:19 --> Language Class Initialized
INFO - 2016-10-08 19:09:19 --> Config Class Initialized
INFO - 2016-10-08 19:09:19 --> Loader Class Initialized
INFO - 2016-10-08 19:09:19 --> Helper loaded: url_helper
INFO - 2016-10-08 19:09:19 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 19:09:19 --> Controller Class Initialized
DEBUG - 2016-10-08 19:09:19 --> Index MX_Controller Initialized
INFO - 2016-10-08 19:09:19 --> Model Class Initialized
INFO - 2016-10-08 19:09:19 --> Model Class Initialized
ERROR - 2016-10-08 19:09:19 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-10-08 19:09:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 19:09:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 19:09:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 19:09:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-10-08 19:09:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 19:09:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 19:09:19 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:19 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:19 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:19 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:20 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:20 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:20 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:20 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:20 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:20 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:20 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:20 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:20 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:20 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:20 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:20 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:20 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:20 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:20 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:20 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:20 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:20 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:20 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:20 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:20 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:20 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:20 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:21 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:21 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:21 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:21 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:21 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:21 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:21 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:21 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:21 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:21 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:21 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:21 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:21 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:21 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:21 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:21 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:21 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:21 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:21 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:21 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:21 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:21 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:22 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:22 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:22 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:22 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:22 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:22 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:22 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:22 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:22 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:22 --> Database Driver Class Initialized
DEBUG - 2016-10-08 19:09:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 19:09:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 19:09:22 --> Final output sent to browser
DEBUG - 2016-10-08 19:09:22 --> Total execution time: 4.0329
INFO - 2016-10-08 19:09:38 --> Config Class Initialized
INFO - 2016-10-08 19:09:38 --> Hooks Class Initialized
DEBUG - 2016-10-08 19:09:38 --> UTF-8 Support Enabled
INFO - 2016-10-08 19:09:38 --> Utf8 Class Initialized
INFO - 2016-10-08 19:09:38 --> URI Class Initialized
INFO - 2016-10-08 19:09:38 --> Router Class Initialized
INFO - 2016-10-08 19:09:38 --> Output Class Initialized
INFO - 2016-10-08 19:09:38 --> Security Class Initialized
DEBUG - 2016-10-08 19:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 19:09:38 --> Input Class Initialized
INFO - 2016-10-08 19:09:38 --> Language Class Initialized
INFO - 2016-10-08 19:09:38 --> Language Class Initialized
INFO - 2016-10-08 19:09:38 --> Config Class Initialized
INFO - 2016-10-08 19:09:38 --> Loader Class Initialized
INFO - 2016-10-08 19:09:38 --> Helper loaded: url_helper
INFO - 2016-10-08 19:09:38 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 19:09:38 --> Controller Class Initialized
DEBUG - 2016-10-08 19:09:38 --> Index MX_Controller Initialized
INFO - 2016-10-08 19:09:38 --> Model Class Initialized
INFO - 2016-10-08 19:09:38 --> Model Class Initialized
ERROR - 2016-10-08 19:09:39 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-08 19:09:39 --> Anggota MX_Controller Initialized
INFO - 2016-10-08 19:09:39 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:39 --> Final output sent to browser
DEBUG - 2016-10-08 19:09:39 --> Total execution time: 0.9954
INFO - 2016-10-08 19:09:40 --> Config Class Initialized
INFO - 2016-10-08 19:09:40 --> Hooks Class Initialized
DEBUG - 2016-10-08 19:09:40 --> UTF-8 Support Enabled
INFO - 2016-10-08 19:09:41 --> Utf8 Class Initialized
INFO - 2016-10-08 19:09:41 --> URI Class Initialized
INFO - 2016-10-08 19:09:41 --> Router Class Initialized
INFO - 2016-10-08 19:09:41 --> Output Class Initialized
INFO - 2016-10-08 19:09:41 --> Security Class Initialized
DEBUG - 2016-10-08 19:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 19:09:41 --> Input Class Initialized
INFO - 2016-10-08 19:09:41 --> Language Class Initialized
INFO - 2016-10-08 19:09:41 --> Language Class Initialized
INFO - 2016-10-08 19:09:41 --> Config Class Initialized
INFO - 2016-10-08 19:09:41 --> Loader Class Initialized
INFO - 2016-10-08 19:09:41 --> Helper loaded: url_helper
INFO - 2016-10-08 19:09:41 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 19:09:41 --> Controller Class Initialized
DEBUG - 2016-10-08 19:09:41 --> Index MX_Controller Initialized
INFO - 2016-10-08 19:09:41 --> Model Class Initialized
INFO - 2016-10-08 19:09:41 --> Model Class Initialized
ERROR - 2016-10-08 19:09:41 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-10-08 19:09:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 19:09:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 19:09:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 19:09:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_umum.php
DEBUG - 2016-10-08 19:09:42 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 19:09:42 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 19:09:42 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:42 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:42 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:42 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:42 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:42 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:42 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:42 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:42 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:42 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:42 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:42 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:42 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:42 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:42 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:42 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:42 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:42 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:42 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:42 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:43 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:43 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:43 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:43 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:43 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:43 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:43 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:43 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:43 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:43 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:43 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:43 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:43 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:43 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:43 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:43 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:43 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:43 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:43 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:43 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:43 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:44 --> Database Driver Class Initialized
DEBUG - 2016-10-08 19:09:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 19:09:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 19:09:45 --> Final output sent to browser
DEBUG - 2016-10-08 19:09:45 --> Total execution time: 4.2219
INFO - 2016-10-08 19:09:55 --> Config Class Initialized
INFO - 2016-10-08 19:09:55 --> Hooks Class Initialized
DEBUG - 2016-10-08 19:09:55 --> UTF-8 Support Enabled
INFO - 2016-10-08 19:09:56 --> Utf8 Class Initialized
INFO - 2016-10-08 19:09:56 --> URI Class Initialized
INFO - 2016-10-08 19:09:56 --> Router Class Initialized
INFO - 2016-10-08 19:09:56 --> Output Class Initialized
INFO - 2016-10-08 19:09:56 --> Security Class Initialized
DEBUG - 2016-10-08 19:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 19:09:56 --> Input Class Initialized
INFO - 2016-10-08 19:09:56 --> Language Class Initialized
INFO - 2016-10-08 19:09:56 --> Language Class Initialized
INFO - 2016-10-08 19:09:56 --> Config Class Initialized
INFO - 2016-10-08 19:09:56 --> Loader Class Initialized
INFO - 2016-10-08 19:09:56 --> Helper loaded: url_helper
INFO - 2016-10-08 19:09:56 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 19:09:56 --> Controller Class Initialized
DEBUG - 2016-10-08 19:09:56 --> Index MX_Controller Initialized
INFO - 2016-10-08 19:09:56 --> Model Class Initialized
INFO - 2016-10-08 19:09:56 --> Model Class Initialized
ERROR - 2016-10-08 19:09:56 --> Unable to delete cache file for admin/index/do_ajukan_pinjaman
INFO - 2016-10-08 19:09:56 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:57 --> Database Driver Class Initialized
INFO - 2016-10-08 19:09:57 --> Final output sent to browser
DEBUG - 2016-10-08 19:09:57 --> Total execution time: 1.2952
INFO - 2016-10-08 19:15:32 --> Config Class Initialized
INFO - 2016-10-08 19:15:32 --> Hooks Class Initialized
DEBUG - 2016-10-08 19:15:32 --> UTF-8 Support Enabled
INFO - 2016-10-08 19:15:32 --> Utf8 Class Initialized
INFO - 2016-10-08 19:15:32 --> URI Class Initialized
INFO - 2016-10-08 19:15:32 --> Router Class Initialized
INFO - 2016-10-08 19:15:32 --> Output Class Initialized
INFO - 2016-10-08 19:15:33 --> Security Class Initialized
DEBUG - 2016-10-08 19:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 19:15:33 --> Input Class Initialized
INFO - 2016-10-08 19:15:33 --> Language Class Initialized
INFO - 2016-10-08 19:15:33 --> Language Class Initialized
INFO - 2016-10-08 19:15:33 --> Config Class Initialized
INFO - 2016-10-08 19:15:33 --> Loader Class Initialized
INFO - 2016-10-08 19:15:33 --> Helper loaded: url_helper
INFO - 2016-10-08 19:15:33 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 19:15:33 --> Controller Class Initialized
DEBUG - 2016-10-08 19:15:33 --> Index MX_Controller Initialized
INFO - 2016-10-08 19:15:33 --> Model Class Initialized
INFO - 2016-10-08 19:15:33 --> Model Class Initialized
ERROR - 2016-10-08 19:15:33 --> Unable to delete cache file for admin/index/batal/fa35e192121eabf3dabf9f5ea6abdbcbc107ac3b
INFO - 2016-10-08 19:15:33 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:33 --> Final output sent to browser
DEBUG - 2016-10-08 19:15:33 --> Total execution time: 1.0137
INFO - 2016-10-08 19:15:34 --> Config Class Initialized
INFO - 2016-10-08 19:15:34 --> Hooks Class Initialized
DEBUG - 2016-10-08 19:15:34 --> UTF-8 Support Enabled
INFO - 2016-10-08 19:15:34 --> Utf8 Class Initialized
INFO - 2016-10-08 19:15:34 --> URI Class Initialized
INFO - 2016-10-08 19:15:34 --> Router Class Initialized
INFO - 2016-10-08 19:15:34 --> Output Class Initialized
INFO - 2016-10-08 19:15:34 --> Security Class Initialized
DEBUG - 2016-10-08 19:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 19:15:34 --> Input Class Initialized
INFO - 2016-10-08 19:15:34 --> Language Class Initialized
INFO - 2016-10-08 19:15:34 --> Language Class Initialized
INFO - 2016-10-08 19:15:34 --> Config Class Initialized
INFO - 2016-10-08 19:15:34 --> Loader Class Initialized
INFO - 2016-10-08 19:15:34 --> Helper loaded: url_helper
INFO - 2016-10-08 19:15:34 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 19:15:34 --> Controller Class Initialized
DEBUG - 2016-10-08 19:15:34 --> Index MX_Controller Initialized
INFO - 2016-10-08 19:15:35 --> Model Class Initialized
INFO - 2016-10-08 19:15:35 --> Model Class Initialized
ERROR - 2016-10-08 19:15:35 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-10-08 19:15:35 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 19:15:35 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 19:15:35 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 19:15:35 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-10-08 19:15:35 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 19:15:35 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 19:15:35 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:35 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:35 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:35 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:35 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:35 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:35 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:35 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:35 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:35 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:35 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:35 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:35 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:35 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:35 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:36 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:36 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:36 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:36 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:36 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:36 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:36 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:36 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:36 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:36 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:36 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:36 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:36 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:36 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:36 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:36 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:36 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:36 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:36 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:36 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:36 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:37 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:37 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:37 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:37 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:37 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:37 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:37 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:37 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:37 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:37 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:37 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:37 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:37 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:37 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:37 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:37 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:37 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:37 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:37 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:37 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:37 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:37 --> Database Driver Class Initialized
INFO - 2016-10-08 19:15:37 --> Database Driver Class Initialized
DEBUG - 2016-10-08 19:15:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 19:15:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 19:15:38 --> Final output sent to browser
DEBUG - 2016-10-08 19:15:38 --> Total execution time: 3.9879
INFO - 2016-10-08 19:16:30 --> Config Class Initialized
INFO - 2016-10-08 19:16:30 --> Hooks Class Initialized
DEBUG - 2016-10-08 19:16:30 --> UTF-8 Support Enabled
INFO - 2016-10-08 19:16:30 --> Utf8 Class Initialized
INFO - 2016-10-08 19:16:30 --> URI Class Initialized
INFO - 2016-10-08 19:16:30 --> Router Class Initialized
INFO - 2016-10-08 19:16:30 --> Output Class Initialized
INFO - 2016-10-08 19:16:30 --> Security Class Initialized
DEBUG - 2016-10-08 19:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 19:16:30 --> Input Class Initialized
INFO - 2016-10-08 19:16:30 --> Language Class Initialized
INFO - 2016-10-08 19:16:30 --> Language Class Initialized
INFO - 2016-10-08 19:16:30 --> Config Class Initialized
INFO - 2016-10-08 19:16:30 --> Loader Class Initialized
INFO - 2016-10-08 19:16:30 --> Helper loaded: url_helper
INFO - 2016-10-08 19:16:30 --> Database Driver Class Initialized
INFO - 2016-10-08 19:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 19:16:30 --> Controller Class Initialized
DEBUG - 2016-10-08 19:16:30 --> Index MX_Controller Initialized
INFO - 2016-10-08 19:16:31 --> Model Class Initialized
INFO - 2016-10-08 19:16:31 --> Model Class Initialized
ERROR - 2016-10-08 19:16:31 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-08 19:16:31 --> Anggota MX_Controller Initialized
INFO - 2016-10-08 19:16:31 --> Database Driver Class Initialized
INFO - 2016-10-08 19:16:31 --> Final output sent to browser
DEBUG - 2016-10-08 19:16:31 --> Total execution time: 0.9807
INFO - 2016-10-08 19:37:05 --> Config Class Initialized
INFO - 2016-10-08 19:37:05 --> Hooks Class Initialized
DEBUG - 2016-10-08 19:37:05 --> UTF-8 Support Enabled
INFO - 2016-10-08 19:37:05 --> Utf8 Class Initialized
INFO - 2016-10-08 19:37:06 --> URI Class Initialized
INFO - 2016-10-08 19:37:06 --> Router Class Initialized
INFO - 2016-10-08 19:37:06 --> Output Class Initialized
INFO - 2016-10-08 19:37:06 --> Security Class Initialized
DEBUG - 2016-10-08 19:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 19:37:06 --> Input Class Initialized
INFO - 2016-10-08 19:37:06 --> Language Class Initialized
INFO - 2016-10-08 19:37:06 --> Language Class Initialized
INFO - 2016-10-08 19:37:06 --> Config Class Initialized
INFO - 2016-10-08 19:37:06 --> Loader Class Initialized
INFO - 2016-10-08 19:37:06 --> Helper loaded: url_helper
INFO - 2016-10-08 19:37:06 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 19:37:06 --> Controller Class Initialized
DEBUG - 2016-10-08 19:37:06 --> Index MX_Controller Initialized
INFO - 2016-10-08 19:37:06 --> Model Class Initialized
INFO - 2016-10-08 19:37:06 --> Model Class Initialized
ERROR - 2016-10-08 19:37:07 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-10-08 19:37:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 19:37:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 19:37:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 19:37:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_umum.php
DEBUG - 2016-10-08 19:37:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 19:37:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 19:37:07 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:07 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:07 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:07 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:07 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:07 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:07 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:07 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:07 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:07 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:07 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:07 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:07 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:07 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:07 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:08 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:08 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:08 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:08 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:08 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:08 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:08 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:08 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:08 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:08 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:08 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:08 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:08 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:08 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:08 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:08 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:08 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:08 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:08 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:08 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:09 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:09 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:09 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:09 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:09 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:09 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:09 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:09 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:09 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:09 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:09 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:09 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:09 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:09 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:09 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:09 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:09 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:09 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:09 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:09 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:09 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:10 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:10 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:10 --> Database Driver Class Initialized
INFO - 2016-10-08 19:37:10 --> Database Driver Class Initialized
DEBUG - 2016-10-08 19:37:10 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 19:37:10 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 19:37:10 --> Final output sent to browser
DEBUG - 2016-10-08 19:37:10 --> Total execution time: 4.6689
INFO - 2016-10-08 19:40:19 --> Config Class Initialized
INFO - 2016-10-08 19:40:19 --> Hooks Class Initialized
DEBUG - 2016-10-08 19:40:19 --> UTF-8 Support Enabled
INFO - 2016-10-08 19:40:19 --> Utf8 Class Initialized
INFO - 2016-10-08 19:40:19 --> URI Class Initialized
INFO - 2016-10-08 19:40:19 --> Router Class Initialized
INFO - 2016-10-08 19:40:19 --> Output Class Initialized
INFO - 2016-10-08 19:40:19 --> Security Class Initialized
DEBUG - 2016-10-08 19:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 19:40:19 --> Input Class Initialized
INFO - 2016-10-08 19:40:19 --> Language Class Initialized
INFO - 2016-10-08 19:40:19 --> Language Class Initialized
INFO - 2016-10-08 19:40:19 --> Config Class Initialized
INFO - 2016-10-08 19:40:19 --> Loader Class Initialized
INFO - 2016-10-08 19:40:19 --> Helper loaded: url_helper
INFO - 2016-10-08 19:40:19 --> Database Driver Class Initialized
INFO - 2016-10-08 19:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 19:40:20 --> Controller Class Initialized
DEBUG - 2016-10-08 19:40:20 --> Index MX_Controller Initialized
INFO - 2016-10-08 19:40:20 --> Model Class Initialized
INFO - 2016-10-08 19:40:20 --> Model Class Initialized
ERROR - 2016-10-08 19:40:20 --> Unable to delete cache file for admin/index/do_ajukan_pinjaman
INFO - 2016-10-08 19:40:20 --> Database Driver Class Initialized
INFO - 2016-10-08 19:40:20 --> Database Driver Class Initialized
INFO - 2016-10-08 19:40:20 --> Final output sent to browser
DEBUG - 2016-10-08 19:40:20 --> Total execution time: 1.1870
INFO - 2016-10-08 19:41:23 --> Config Class Initialized
INFO - 2016-10-08 19:41:23 --> Hooks Class Initialized
DEBUG - 2016-10-08 19:41:23 --> UTF-8 Support Enabled
INFO - 2016-10-08 19:41:23 --> Utf8 Class Initialized
INFO - 2016-10-08 19:41:23 --> URI Class Initialized
INFO - 2016-10-08 19:41:23 --> Router Class Initialized
INFO - 2016-10-08 19:41:23 --> Output Class Initialized
INFO - 2016-10-08 19:41:23 --> Security Class Initialized
DEBUG - 2016-10-08 19:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 19:41:23 --> Input Class Initialized
INFO - 2016-10-08 19:41:23 --> Language Class Initialized
INFO - 2016-10-08 19:41:23 --> Language Class Initialized
INFO - 2016-10-08 19:41:23 --> Config Class Initialized
INFO - 2016-10-08 19:41:23 --> Loader Class Initialized
INFO - 2016-10-08 19:41:23 --> Helper loaded: url_helper
INFO - 2016-10-08 19:41:23 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 19:41:24 --> Controller Class Initialized
DEBUG - 2016-10-08 19:41:24 --> Index MX_Controller Initialized
INFO - 2016-10-08 19:41:24 --> Model Class Initialized
INFO - 2016-10-08 19:41:24 --> Model Class Initialized
ERROR - 2016-10-08 19:41:24 --> Unable to delete cache file for admin/index/batal/f1abd670358e036c31296e66b3b66c382ac00812
INFO - 2016-10-08 19:41:24 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:24 --> Final output sent to browser
DEBUG - 2016-10-08 19:41:24 --> Total execution time: 1.1004
INFO - 2016-10-08 19:41:24 --> Config Class Initialized
INFO - 2016-10-08 19:41:24 --> Hooks Class Initialized
DEBUG - 2016-10-08 19:41:24 --> UTF-8 Support Enabled
INFO - 2016-10-08 19:41:25 --> Utf8 Class Initialized
INFO - 2016-10-08 19:41:25 --> URI Class Initialized
INFO - 2016-10-08 19:41:25 --> Router Class Initialized
INFO - 2016-10-08 19:41:25 --> Output Class Initialized
INFO - 2016-10-08 19:41:25 --> Security Class Initialized
DEBUG - 2016-10-08 19:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 19:41:25 --> Input Class Initialized
INFO - 2016-10-08 19:41:25 --> Language Class Initialized
INFO - 2016-10-08 19:41:25 --> Language Class Initialized
INFO - 2016-10-08 19:41:25 --> Config Class Initialized
INFO - 2016-10-08 19:41:25 --> Loader Class Initialized
INFO - 2016-10-08 19:41:25 --> Helper loaded: url_helper
INFO - 2016-10-08 19:41:25 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 19:41:25 --> Controller Class Initialized
DEBUG - 2016-10-08 19:41:25 --> Index MX_Controller Initialized
INFO - 2016-10-08 19:41:25 --> Model Class Initialized
INFO - 2016-10-08 19:41:25 --> Model Class Initialized
ERROR - 2016-10-08 19:41:25 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-10-08 19:41:25 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 19:41:25 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 19:41:25 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 19:41:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-10-08 19:41:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 19:41:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 19:41:26 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:26 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:26 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:26 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:26 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:26 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:26 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:26 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:26 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:26 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:26 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:26 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:26 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:26 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:27 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:27 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:27 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:27 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:27 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:27 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:27 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:27 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:27 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:27 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:27 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:27 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:27 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:27 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:27 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:27 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:27 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:27 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:27 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:27 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:28 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:28 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:28 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:28 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:28 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:28 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:28 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:28 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:28 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:28 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:28 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:28 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:28 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:28 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:28 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:28 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:28 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:28 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:28 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:28 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:29 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:29 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:29 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:29 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:29 --> Database Driver Class Initialized
DEBUG - 2016-10-08 19:41:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 19:41:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 19:41:29 --> Final output sent to browser
DEBUG - 2016-10-08 19:41:29 --> Total execution time: 4.4534
INFO - 2016-10-08 19:41:38 --> Config Class Initialized
INFO - 2016-10-08 19:41:38 --> Hooks Class Initialized
DEBUG - 2016-10-08 19:41:38 --> UTF-8 Support Enabled
INFO - 2016-10-08 19:41:38 --> Utf8 Class Initialized
INFO - 2016-10-08 19:41:38 --> URI Class Initialized
INFO - 2016-10-08 19:41:38 --> Router Class Initialized
INFO - 2016-10-08 19:41:38 --> Output Class Initialized
INFO - 2016-10-08 19:41:38 --> Security Class Initialized
DEBUG - 2016-10-08 19:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 19:41:39 --> Input Class Initialized
INFO - 2016-10-08 19:41:39 --> Language Class Initialized
INFO - 2016-10-08 19:41:39 --> Language Class Initialized
INFO - 2016-10-08 19:41:39 --> Config Class Initialized
INFO - 2016-10-08 19:41:39 --> Loader Class Initialized
INFO - 2016-10-08 19:41:39 --> Helper loaded: url_helper
INFO - 2016-10-08 19:41:39 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 19:41:39 --> Controller Class Initialized
DEBUG - 2016-10-08 19:41:39 --> Index MX_Controller Initialized
INFO - 2016-10-08 19:41:39 --> Model Class Initialized
INFO - 2016-10-08 19:41:39 --> Model Class Initialized
ERROR - 2016-10-08 19:41:39 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-08 19:41:39 --> Anggota MX_Controller Initialized
INFO - 2016-10-08 19:41:39 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:39 --> Final output sent to browser
DEBUG - 2016-10-08 19:41:39 --> Total execution time: 1.0564
INFO - 2016-10-08 19:41:42 --> Config Class Initialized
INFO - 2016-10-08 19:41:42 --> Hooks Class Initialized
DEBUG - 2016-10-08 19:41:42 --> UTF-8 Support Enabled
INFO - 2016-10-08 19:41:42 --> Utf8 Class Initialized
INFO - 2016-10-08 19:41:43 --> URI Class Initialized
INFO - 2016-10-08 19:41:43 --> Router Class Initialized
INFO - 2016-10-08 19:41:43 --> Output Class Initialized
INFO - 2016-10-08 19:41:43 --> Security Class Initialized
DEBUG - 2016-10-08 19:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 19:41:43 --> Input Class Initialized
INFO - 2016-10-08 19:41:43 --> Language Class Initialized
INFO - 2016-10-08 19:41:43 --> Language Class Initialized
INFO - 2016-10-08 19:41:43 --> Config Class Initialized
INFO - 2016-10-08 19:41:43 --> Loader Class Initialized
INFO - 2016-10-08 19:41:43 --> Helper loaded: url_helper
INFO - 2016-10-08 19:41:43 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 19:41:43 --> Controller Class Initialized
DEBUG - 2016-10-08 19:41:43 --> Index MX_Controller Initialized
INFO - 2016-10-08 19:41:43 --> Model Class Initialized
INFO - 2016-10-08 19:41:43 --> Model Class Initialized
ERROR - 2016-10-08 19:41:43 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-10-08 19:41:43 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 19:41:43 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 19:41:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 19:41:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_umum.php
DEBUG - 2016-10-08 19:41:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 19:41:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 19:41:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:45 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:45 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:45 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:45 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:45 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:45 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:45 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:45 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:45 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:45 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:45 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:45 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:45 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:45 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:45 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:45 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:45 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:45 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:45 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:45 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:46 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:47 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:47 --> Database Driver Class Initialized
DEBUG - 2016-10-08 19:41:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 19:41:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 19:41:47 --> Final output sent to browser
DEBUG - 2016-10-08 19:41:47 --> Total execution time: 4.3716
INFO - 2016-10-08 19:41:54 --> Config Class Initialized
INFO - 2016-10-08 19:41:54 --> Hooks Class Initialized
DEBUG - 2016-10-08 19:41:54 --> UTF-8 Support Enabled
INFO - 2016-10-08 19:41:54 --> Utf8 Class Initialized
INFO - 2016-10-08 19:41:54 --> URI Class Initialized
INFO - 2016-10-08 19:41:54 --> Router Class Initialized
INFO - 2016-10-08 19:41:54 --> Output Class Initialized
INFO - 2016-10-08 19:41:54 --> Security Class Initialized
DEBUG - 2016-10-08 19:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 19:41:54 --> Input Class Initialized
INFO - 2016-10-08 19:41:54 --> Language Class Initialized
INFO - 2016-10-08 19:41:54 --> Language Class Initialized
INFO - 2016-10-08 19:41:54 --> Config Class Initialized
INFO - 2016-10-08 19:41:54 --> Loader Class Initialized
INFO - 2016-10-08 19:41:54 --> Helper loaded: url_helper
INFO - 2016-10-08 19:41:54 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 19:41:54 --> Controller Class Initialized
DEBUG - 2016-10-08 19:41:54 --> Index MX_Controller Initialized
INFO - 2016-10-08 19:41:55 --> Model Class Initialized
INFO - 2016-10-08 19:41:55 --> Model Class Initialized
ERROR - 2016-10-08 19:41:55 --> Unable to delete cache file for admin/index/do_ajukan_pinjaman
INFO - 2016-10-08 19:41:55 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:55 --> Database Driver Class Initialized
INFO - 2016-10-08 19:41:55 --> Final output sent to browser
DEBUG - 2016-10-08 19:41:55 --> Total execution time: 1.2022
INFO - 2016-10-08 19:45:54 --> Config Class Initialized
INFO - 2016-10-08 19:45:54 --> Hooks Class Initialized
DEBUG - 2016-10-08 19:45:54 --> UTF-8 Support Enabled
INFO - 2016-10-08 19:45:54 --> Utf8 Class Initialized
INFO - 2016-10-08 19:45:54 --> URI Class Initialized
INFO - 2016-10-08 19:45:54 --> Router Class Initialized
INFO - 2016-10-08 19:45:54 --> Output Class Initialized
INFO - 2016-10-08 19:45:54 --> Security Class Initialized
DEBUG - 2016-10-08 19:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 19:45:54 --> Input Class Initialized
INFO - 2016-10-08 19:45:54 --> Language Class Initialized
INFO - 2016-10-08 19:45:54 --> Language Class Initialized
INFO - 2016-10-08 19:45:54 --> Config Class Initialized
INFO - 2016-10-08 19:45:54 --> Loader Class Initialized
INFO - 2016-10-08 19:45:54 --> Helper loaded: url_helper
INFO - 2016-10-08 19:45:55 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 19:45:55 --> Controller Class Initialized
DEBUG - 2016-10-08 19:45:55 --> Index MX_Controller Initialized
INFO - 2016-10-08 19:45:55 --> Model Class Initialized
INFO - 2016-10-08 19:45:55 --> Model Class Initialized
ERROR - 2016-10-08 19:45:55 --> Unable to delete cache file for admin/index/batal/1574bddb75c78a6fd2251d61e2993b5146201319
INFO - 2016-10-08 19:45:55 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:55 --> Final output sent to browser
DEBUG - 2016-10-08 19:45:55 --> Total execution time: 1.1431
INFO - 2016-10-08 19:45:55 --> Config Class Initialized
INFO - 2016-10-08 19:45:55 --> Hooks Class Initialized
DEBUG - 2016-10-08 19:45:55 --> UTF-8 Support Enabled
INFO - 2016-10-08 19:45:55 --> Utf8 Class Initialized
INFO - 2016-10-08 19:45:55 --> URI Class Initialized
INFO - 2016-10-08 19:45:55 --> Router Class Initialized
INFO - 2016-10-08 19:45:55 --> Output Class Initialized
INFO - 2016-10-08 19:45:56 --> Security Class Initialized
DEBUG - 2016-10-08 19:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 19:45:56 --> Input Class Initialized
INFO - 2016-10-08 19:45:56 --> Language Class Initialized
INFO - 2016-10-08 19:45:56 --> Language Class Initialized
INFO - 2016-10-08 19:45:56 --> Config Class Initialized
INFO - 2016-10-08 19:45:56 --> Loader Class Initialized
INFO - 2016-10-08 19:45:56 --> Helper loaded: url_helper
INFO - 2016-10-08 19:45:56 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 19:45:56 --> Controller Class Initialized
DEBUG - 2016-10-08 19:45:56 --> Index MX_Controller Initialized
INFO - 2016-10-08 19:45:56 --> Model Class Initialized
INFO - 2016-10-08 19:45:56 --> Model Class Initialized
ERROR - 2016-10-08 19:45:56 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-10-08 19:45:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 19:45:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 19:45:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 19:45:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-10-08 19:45:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 19:45:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 19:45:56 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:56 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:57 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:57 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:57 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:57 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:57 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:57 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:57 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:57 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:57 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:57 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:57 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:57 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:57 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:57 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:57 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:57 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:57 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:57 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:57 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:57 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:57 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:58 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:58 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:58 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:58 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:58 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:58 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:58 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:58 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:58 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:58 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:58 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:58 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:58 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:58 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:58 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:58 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:58 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:59 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:59 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:59 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:59 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:59 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:59 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:59 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:59 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:59 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:59 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:59 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:59 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:59 --> Database Driver Class Initialized
INFO - 2016-10-08 19:45:59 --> Database Driver Class Initialized
INFO - 2016-10-08 19:46:00 --> Database Driver Class Initialized
INFO - 2016-10-08 19:46:00 --> Database Driver Class Initialized
INFO - 2016-10-08 19:46:00 --> Database Driver Class Initialized
INFO - 2016-10-08 19:46:00 --> Database Driver Class Initialized
INFO - 2016-10-08 19:46:00 --> Database Driver Class Initialized
DEBUG - 2016-10-08 19:46:00 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 19:46:00 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 19:46:00 --> Final output sent to browser
DEBUG - 2016-10-08 19:46:00 --> Total execution time: 4.7050
INFO - 2016-10-08 19:47:07 --> Config Class Initialized
INFO - 2016-10-08 19:47:07 --> Hooks Class Initialized
DEBUG - 2016-10-08 19:47:07 --> UTF-8 Support Enabled
INFO - 2016-10-08 19:47:07 --> Utf8 Class Initialized
INFO - 2016-10-08 19:47:07 --> URI Class Initialized
INFO - 2016-10-08 19:47:07 --> Router Class Initialized
INFO - 2016-10-08 19:47:07 --> Output Class Initialized
INFO - 2016-10-08 19:47:07 --> Security Class Initialized
DEBUG - 2016-10-08 19:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 19:47:08 --> Input Class Initialized
INFO - 2016-10-08 19:47:08 --> Language Class Initialized
INFO - 2016-10-08 19:47:08 --> Language Class Initialized
INFO - 2016-10-08 19:47:08 --> Config Class Initialized
INFO - 2016-10-08 19:47:08 --> Loader Class Initialized
INFO - 2016-10-08 19:47:08 --> Helper loaded: url_helper
INFO - 2016-10-08 19:47:08 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 19:47:08 --> Controller Class Initialized
DEBUG - 2016-10-08 19:47:08 --> Index MX_Controller Initialized
INFO - 2016-10-08 19:47:08 --> Model Class Initialized
INFO - 2016-10-08 19:47:08 --> Model Class Initialized
ERROR - 2016-10-08 19:47:08 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-08 19:47:08 --> Anggota MX_Controller Initialized
INFO - 2016-10-08 19:47:08 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:08 --> Final output sent to browser
DEBUG - 2016-10-08 19:47:08 --> Total execution time: 1.1882
INFO - 2016-10-08 19:47:10 --> Config Class Initialized
INFO - 2016-10-08 19:47:10 --> Hooks Class Initialized
DEBUG - 2016-10-08 19:47:10 --> UTF-8 Support Enabled
INFO - 2016-10-08 19:47:10 --> Utf8 Class Initialized
INFO - 2016-10-08 19:47:10 --> URI Class Initialized
INFO - 2016-10-08 19:47:10 --> Router Class Initialized
INFO - 2016-10-08 19:47:10 --> Output Class Initialized
INFO - 2016-10-08 19:47:10 --> Security Class Initialized
DEBUG - 2016-10-08 19:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 19:47:10 --> Input Class Initialized
INFO - 2016-10-08 19:47:10 --> Language Class Initialized
INFO - 2016-10-08 19:47:10 --> Language Class Initialized
INFO - 2016-10-08 19:47:10 --> Config Class Initialized
INFO - 2016-10-08 19:47:10 --> Loader Class Initialized
INFO - 2016-10-08 19:47:10 --> Helper loaded: url_helper
INFO - 2016-10-08 19:47:11 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 19:47:11 --> Controller Class Initialized
DEBUG - 2016-10-08 19:47:11 --> Index MX_Controller Initialized
INFO - 2016-10-08 19:47:11 --> Model Class Initialized
INFO - 2016-10-08 19:47:11 --> Model Class Initialized
ERROR - 2016-10-08 19:47:11 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-10-08 19:47:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 19:47:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 19:47:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 19:47:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_umum.php
DEBUG - 2016-10-08 19:47:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 19:47:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 19:47:11 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:11 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:11 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:11 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:11 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:11 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:11 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:11 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:11 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:11 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:12 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:12 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:12 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:12 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:12 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:12 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:12 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:12 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:12 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:12 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:12 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:12 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:12 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:12 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:12 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:12 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:12 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:12 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:12 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:12 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:13 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:13 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:13 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:13 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:13 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:13 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:13 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:13 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:13 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:13 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:13 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:13 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:13 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:13 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:13 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:13 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:13 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:13 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:13 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:13 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:13 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:14 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:14 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:14 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:14 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:14 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:14 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:14 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:14 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:14 --> Database Driver Class Initialized
DEBUG - 2016-10-08 19:47:14 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 19:47:14 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 19:47:14 --> Final output sent to browser
DEBUG - 2016-10-08 19:47:14 --> Total execution time: 4.1988
INFO - 2016-10-08 19:47:21 --> Config Class Initialized
INFO - 2016-10-08 19:47:21 --> Hooks Class Initialized
DEBUG - 2016-10-08 19:47:21 --> UTF-8 Support Enabled
INFO - 2016-10-08 19:47:21 --> Utf8 Class Initialized
INFO - 2016-10-08 19:47:21 --> URI Class Initialized
INFO - 2016-10-08 19:47:21 --> Router Class Initialized
INFO - 2016-10-08 19:47:21 --> Output Class Initialized
INFO - 2016-10-08 19:47:21 --> Security Class Initialized
DEBUG - 2016-10-08 19:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 19:47:21 --> Input Class Initialized
INFO - 2016-10-08 19:47:21 --> Language Class Initialized
INFO - 2016-10-08 19:47:22 --> Language Class Initialized
INFO - 2016-10-08 19:47:22 --> Config Class Initialized
INFO - 2016-10-08 19:47:22 --> Loader Class Initialized
INFO - 2016-10-08 19:47:22 --> Helper loaded: url_helper
INFO - 2016-10-08 19:47:22 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 19:47:22 --> Controller Class Initialized
DEBUG - 2016-10-08 19:47:22 --> Index MX_Controller Initialized
INFO - 2016-10-08 19:47:22 --> Model Class Initialized
INFO - 2016-10-08 19:47:22 --> Model Class Initialized
ERROR - 2016-10-08 19:47:22 --> Unable to delete cache file for admin/index/do_ajukan_pinjaman
INFO - 2016-10-08 19:47:22 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:22 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:22 --> Final output sent to browser
DEBUG - 2016-10-08 19:47:22 --> Total execution time: 1.2441
INFO - 2016-10-08 19:47:39 --> Config Class Initialized
INFO - 2016-10-08 19:47:39 --> Hooks Class Initialized
DEBUG - 2016-10-08 19:47:39 --> UTF-8 Support Enabled
INFO - 2016-10-08 19:47:39 --> Utf8 Class Initialized
INFO - 2016-10-08 19:47:39 --> URI Class Initialized
INFO - 2016-10-08 19:47:39 --> Router Class Initialized
INFO - 2016-10-08 19:47:39 --> Output Class Initialized
INFO - 2016-10-08 19:47:39 --> Security Class Initialized
DEBUG - 2016-10-08 19:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 19:47:40 --> Input Class Initialized
INFO - 2016-10-08 19:47:40 --> Language Class Initialized
INFO - 2016-10-08 19:47:40 --> Language Class Initialized
INFO - 2016-10-08 19:47:40 --> Config Class Initialized
INFO - 2016-10-08 19:47:40 --> Loader Class Initialized
INFO - 2016-10-08 19:47:40 --> Helper loaded: url_helper
INFO - 2016-10-08 19:47:40 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 19:47:40 --> Controller Class Initialized
DEBUG - 2016-10-08 19:47:40 --> Index MX_Controller Initialized
INFO - 2016-10-08 19:47:40 --> Model Class Initialized
INFO - 2016-10-08 19:47:40 --> Model Class Initialized
ERROR - 2016-10-08 19:47:40 --> Unable to delete cache file for admin/index/batal/0716d9708d321ffb6a00818614779e779925365c
INFO - 2016-10-08 19:47:40 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:40 --> Final output sent to browser
DEBUG - 2016-10-08 19:47:40 --> Total execution time: 1.3011
INFO - 2016-10-08 19:47:41 --> Config Class Initialized
INFO - 2016-10-08 19:47:41 --> Hooks Class Initialized
DEBUG - 2016-10-08 19:47:41 --> UTF-8 Support Enabled
INFO - 2016-10-08 19:47:41 --> Utf8 Class Initialized
INFO - 2016-10-08 19:47:41 --> URI Class Initialized
INFO - 2016-10-08 19:47:41 --> Router Class Initialized
INFO - 2016-10-08 19:47:41 --> Output Class Initialized
INFO - 2016-10-08 19:47:41 --> Security Class Initialized
DEBUG - 2016-10-08 19:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 19:47:41 --> Input Class Initialized
INFO - 2016-10-08 19:47:41 --> Language Class Initialized
INFO - 2016-10-08 19:47:41 --> Language Class Initialized
INFO - 2016-10-08 19:47:41 --> Config Class Initialized
INFO - 2016-10-08 19:47:41 --> Loader Class Initialized
INFO - 2016-10-08 19:47:41 --> Helper loaded: url_helper
INFO - 2016-10-08 19:47:41 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 19:47:42 --> Controller Class Initialized
DEBUG - 2016-10-08 19:47:42 --> Index MX_Controller Initialized
INFO - 2016-10-08 19:47:42 --> Model Class Initialized
INFO - 2016-10-08 19:47:42 --> Model Class Initialized
ERROR - 2016-10-08 19:47:42 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-10-08 19:47:42 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-08 19:47:42 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-08 19:47:42 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-08 19:47:42 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-10-08 19:47:42 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-08 19:47:42 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-08 19:47:42 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:42 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:42 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:42 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:42 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:42 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:42 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:42 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:42 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:43 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:43 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:43 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:43 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:43 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:43 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:43 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:43 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:43 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:43 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:43 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:43 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:43 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:43 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:43 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:43 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:43 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:43 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:43 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:43 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:43 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:44 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:45 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:45 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:45 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:45 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:45 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:45 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:45 --> Database Driver Class Initialized
INFO - 2016-10-08 19:47:45 --> Database Driver Class Initialized
DEBUG - 2016-10-08 19:47:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-08 19:47:45 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-08 19:47:45 --> Final output sent to browser
DEBUG - 2016-10-08 19:47:45 --> Total execution time: 4.4559
