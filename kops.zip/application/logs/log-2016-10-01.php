<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-10-01 05:31:01 --> Config Class Initialized
INFO - 2016-10-01 05:31:01 --> Hooks Class Initialized
DEBUG - 2016-10-01 05:31:01 --> UTF-8 Support Enabled
INFO - 2016-10-01 05:31:01 --> Utf8 Class Initialized
INFO - 2016-10-01 05:31:01 --> URI Class Initialized
INFO - 2016-10-01 05:31:01 --> Router Class Initialized
INFO - 2016-10-01 05:31:01 --> Output Class Initialized
INFO - 2016-10-01 05:31:01 --> Security Class Initialized
DEBUG - 2016-10-01 05:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-01 05:31:01 --> Input Class Initialized
INFO - 2016-10-01 05:31:01 --> Language Class Initialized
ERROR - 2016-10-01 05:31:01 --> 404 Page Not Found: /index
INFO - 2016-10-01 05:35:35 --> Config Class Initialized
INFO - 2016-10-01 05:35:35 --> Hooks Class Initialized
DEBUG - 2016-10-01 05:35:35 --> UTF-8 Support Enabled
INFO - 2016-10-01 05:35:35 --> Utf8 Class Initialized
INFO - 2016-10-01 05:35:35 --> URI Class Initialized
DEBUG - 2016-10-01 05:35:35 --> No URI present. Default controller set.
INFO - 2016-10-01 05:35:35 --> Router Class Initialized
INFO - 2016-10-01 05:35:35 --> Output Class Initialized
INFO - 2016-10-01 05:35:35 --> Security Class Initialized
DEBUG - 2016-10-01 05:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-01 05:35:35 --> Input Class Initialized
INFO - 2016-10-01 05:35:35 --> Language Class Initialized
INFO - 2016-10-01 05:35:35 --> Language Class Initialized
INFO - 2016-10-01 05:35:35 --> Config Class Initialized
INFO - 2016-10-01 05:35:35 --> Loader Class Initialized
INFO - 2016-10-01 05:35:35 --> Helper loaded: url_helper
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-01 05:35:35 --> Controller Class Initialized
DEBUG - 2016-10-01 05:35:35 --> Index MX_Controller Initialized
INFO - 2016-10-01 05:35:35 --> Model Class Initialized
INFO - 2016-10-01 05:35:35 --> Model Class Initialized
ERROR - 2016-10-01 05:35:35 --> Unable to delete cache file for 
DEBUG - 2016-10-01 05:35:35 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-10-01 05:35:35 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-10-01 05:35:35 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-10-01 05:35:35 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-10-01 05:35:35 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-10-01 05:35:35 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:35 --> Database Driver Class Initialized
DEBUG - 2016-10-01 05:35:35 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-10-01 05:35:35 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-10-01 05:35:35 --> Final output sent to browser
DEBUG - 2016-10-01 05:35:35 --> Total execution time: 0.1637
INFO - 2016-10-01 05:35:36 --> Config Class Initialized
INFO - 2016-10-01 05:35:36 --> Hooks Class Initialized
DEBUG - 2016-10-01 05:35:36 --> UTF-8 Support Enabled
INFO - 2016-10-01 05:35:36 --> Utf8 Class Initialized
INFO - 2016-10-01 05:35:36 --> URI Class Initialized
INFO - 2016-10-01 05:35:36 --> Router Class Initialized
INFO - 2016-10-01 05:35:36 --> Output Class Initialized
INFO - 2016-10-01 05:35:36 --> Security Class Initialized
DEBUG - 2016-10-01 05:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-01 05:35:36 --> Input Class Initialized
INFO - 2016-10-01 05:35:36 --> Language Class Initialized
INFO - 2016-10-01 05:35:36 --> Language Class Initialized
INFO - 2016-10-01 05:35:36 --> Config Class Initialized
INFO - 2016-10-01 05:35:36 --> Loader Class Initialized
INFO - 2016-10-01 05:35:36 --> Helper loaded: url_helper
INFO - 2016-10-01 05:35:36 --> Database Driver Class Initialized
INFO - 2016-10-01 05:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-01 05:35:36 --> Controller Class Initialized
DEBUG - 2016-10-01 05:35:36 --> login MX_Controller Initialized
INFO - 2016-10-01 05:35:36 --> Model Class Initialized
INFO - 2016-10-01 05:35:36 --> Model Class Initialized
DEBUG - 2016-10-01 05:35:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-10-01 05:35:36 --> Final output sent to browser
DEBUG - 2016-10-01 05:35:36 --> Total execution time: 0.0433
INFO - 2016-10-01 07:55:00 --> Config Class Initialized
INFO - 2016-10-01 07:55:00 --> Hooks Class Initialized
DEBUG - 2016-10-01 07:55:00 --> UTF-8 Support Enabled
INFO - 2016-10-01 07:55:00 --> Utf8 Class Initialized
INFO - 2016-10-01 07:55:00 --> URI Class Initialized
INFO - 2016-10-01 07:55:00 --> Router Class Initialized
INFO - 2016-10-01 07:55:00 --> Output Class Initialized
INFO - 2016-10-01 07:55:00 --> Security Class Initialized
DEBUG - 2016-10-01 07:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-01 07:55:00 --> Input Class Initialized
INFO - 2016-10-01 07:55:00 --> Language Class Initialized
ERROR - 2016-10-01 07:55:00 --> 404 Page Not Found: /index
INFO - 2016-10-01 07:55:07 --> Config Class Initialized
INFO - 2016-10-01 07:55:07 --> Hooks Class Initialized
DEBUG - 2016-10-01 07:55:07 --> UTF-8 Support Enabled
INFO - 2016-10-01 07:55:07 --> Utf8 Class Initialized
INFO - 2016-10-01 07:55:07 --> URI Class Initialized
INFO - 2016-10-01 07:55:07 --> Router Class Initialized
INFO - 2016-10-01 07:55:07 --> Output Class Initialized
INFO - 2016-10-01 07:55:07 --> Security Class Initialized
DEBUG - 2016-10-01 07:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-01 07:55:07 --> Input Class Initialized
INFO - 2016-10-01 07:55:07 --> Language Class Initialized
ERROR - 2016-10-01 07:55:07 --> 404 Page Not Found: /index
INFO - 2016-10-01 10:25:23 --> Config Class Initialized
INFO - 2016-10-01 10:25:23 --> Hooks Class Initialized
DEBUG - 2016-10-01 10:25:23 --> UTF-8 Support Enabled
INFO - 2016-10-01 10:25:23 --> Utf8 Class Initialized
INFO - 2016-10-01 10:25:23 --> URI Class Initialized
INFO - 2016-10-01 10:25:23 --> Router Class Initialized
INFO - 2016-10-01 10:25:23 --> Output Class Initialized
INFO - 2016-10-01 10:25:23 --> Security Class Initialized
DEBUG - 2016-10-01 10:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-01 10:25:23 --> Input Class Initialized
INFO - 2016-10-01 10:25:23 --> Language Class Initialized
ERROR - 2016-10-01 10:25:23 --> 404 Page Not Found: /index
INFO - 2016-10-01 11:44:10 --> Config Class Initialized
INFO - 2016-10-01 11:44:10 --> Hooks Class Initialized
DEBUG - 2016-10-01 11:44:10 --> UTF-8 Support Enabled
INFO - 2016-10-01 11:44:10 --> Utf8 Class Initialized
INFO - 2016-10-01 11:44:10 --> URI Class Initialized
DEBUG - 2016-10-01 11:44:10 --> No URI present. Default controller set.
INFO - 2016-10-01 11:44:10 --> Router Class Initialized
INFO - 2016-10-01 11:44:10 --> Output Class Initialized
INFO - 2016-10-01 11:44:10 --> Security Class Initialized
DEBUG - 2016-10-01 11:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-01 11:44:10 --> Input Class Initialized
INFO - 2016-10-01 11:44:10 --> Language Class Initialized
INFO - 2016-10-01 11:44:10 --> Language Class Initialized
INFO - 2016-10-01 11:44:10 --> Config Class Initialized
INFO - 2016-10-01 11:44:10 --> Loader Class Initialized
INFO - 2016-10-01 11:44:10 --> Helper loaded: url_helper
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-01 11:44:10 --> Controller Class Initialized
DEBUG - 2016-10-01 11:44:10 --> Index MX_Controller Initialized
INFO - 2016-10-01 11:44:10 --> Model Class Initialized
INFO - 2016-10-01 11:44:10 --> Model Class Initialized
ERROR - 2016-10-01 11:44:10 --> Unable to delete cache file for 
DEBUG - 2016-10-01 11:44:10 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-10-01 11:44:10 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-10-01 11:44:10 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-10-01 11:44:10 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-10-01 11:44:10 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-10-01 11:44:10 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
DEBUG - 2016-10-01 11:44:10 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-10-01 11:44:10 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-10-01 11:44:10 --> Final output sent to browser
DEBUG - 2016-10-01 11:44:10 --> Total execution time: 0.1321
INFO - 2016-10-01 11:44:10 --> Config Class Initialized
INFO - 2016-10-01 11:44:10 --> Hooks Class Initialized
DEBUG - 2016-10-01 11:44:10 --> UTF-8 Support Enabled
INFO - 2016-10-01 11:44:10 --> Utf8 Class Initialized
INFO - 2016-10-01 11:44:10 --> URI Class Initialized
INFO - 2016-10-01 11:44:10 --> Router Class Initialized
INFO - 2016-10-01 11:44:10 --> Output Class Initialized
INFO - 2016-10-01 11:44:10 --> Security Class Initialized
DEBUG - 2016-10-01 11:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-01 11:44:10 --> Input Class Initialized
INFO - 2016-10-01 11:44:10 --> Language Class Initialized
INFO - 2016-10-01 11:44:10 --> Language Class Initialized
INFO - 2016-10-01 11:44:10 --> Config Class Initialized
INFO - 2016-10-01 11:44:10 --> Loader Class Initialized
INFO - 2016-10-01 11:44:10 --> Helper loaded: url_helper
INFO - 2016-10-01 11:44:10 --> Database Driver Class Initialized
INFO - 2016-10-01 11:44:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-01 11:44:10 --> Controller Class Initialized
DEBUG - 2016-10-01 11:44:10 --> login MX_Controller Initialized
INFO - 2016-10-01 11:44:10 --> Model Class Initialized
INFO - 2016-10-01 11:44:10 --> Model Class Initialized
DEBUG - 2016-10-01 11:44:10 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-10-01 11:44:10 --> Final output sent to browser
DEBUG - 2016-10-01 11:44:10 --> Total execution time: 0.0351
INFO - 2016-10-01 13:25:43 --> Config Class Initialized
INFO - 2016-10-01 13:25:43 --> Hooks Class Initialized
DEBUG - 2016-10-01 13:25:43 --> UTF-8 Support Enabled
INFO - 2016-10-01 13:25:43 --> Utf8 Class Initialized
INFO - 2016-10-01 13:25:43 --> URI Class Initialized
DEBUG - 2016-10-01 13:25:43 --> No URI present. Default controller set.
INFO - 2016-10-01 13:25:43 --> Router Class Initialized
INFO - 2016-10-01 13:25:43 --> Output Class Initialized
INFO - 2016-10-01 13:25:43 --> Security Class Initialized
DEBUG - 2016-10-01 13:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-01 13:25:43 --> Input Class Initialized
INFO - 2016-10-01 13:25:43 --> Language Class Initialized
INFO - 2016-10-01 13:25:43 --> Language Class Initialized
INFO - 2016-10-01 13:25:43 --> Config Class Initialized
INFO - 2016-10-01 13:25:43 --> Loader Class Initialized
INFO - 2016-10-01 13:25:43 --> Helper loaded: url_helper
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-01 13:25:43 --> Controller Class Initialized
DEBUG - 2016-10-01 13:25:43 --> Index MX_Controller Initialized
INFO - 2016-10-01 13:25:43 --> Model Class Initialized
INFO - 2016-10-01 13:25:43 --> Model Class Initialized
ERROR - 2016-10-01 13:25:43 --> Unable to delete cache file for 
DEBUG - 2016-10-01 13:25:43 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-10-01 13:25:43 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-10-01 13:25:43 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-10-01 13:25:43 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-10-01 13:25:43 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-10-01 13:25:43 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-01 13:25:43 --> Database Driver Class Initialized
DEBUG - 2016-10-01 13:25:43 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-10-01 13:25:43 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-10-01 13:25:43 --> Final output sent to browser
DEBUG - 2016-10-01 13:25:43 --> Total execution time: 0.1432
INFO - 2016-10-01 13:25:43 --> Config Class Initialized
INFO - 2016-10-01 13:25:43 --> Hooks Class Initialized
DEBUG - 2016-10-01 13:25:43 --> UTF-8 Support Enabled
INFO - 2016-10-01 13:25:43 --> Utf8 Class Initialized
INFO - 2016-10-01 13:25:43 --> URI Class Initialized
INFO - 2016-10-01 13:25:43 --> Router Class Initialized
INFO - 2016-10-01 13:25:43 --> Output Class Initialized
INFO - 2016-10-01 13:25:43 --> Security Class Initialized
DEBUG - 2016-10-01 13:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-01 13:25:43 --> Input Class Initialized
INFO - 2016-10-01 13:25:43 --> Language Class Initialized
ERROR - 2016-10-01 13:25:43 --> 404 Page Not Found: /index
INFO - 2016-10-01 13:25:43 --> Config Class Initialized
INFO - 2016-10-01 13:25:43 --> Hooks Class Initialized
DEBUG - 2016-10-01 13:25:43 --> UTF-8 Support Enabled
INFO - 2016-10-01 13:25:43 --> Utf8 Class Initialized
INFO - 2016-10-01 13:25:43 --> URI Class Initialized
INFO - 2016-10-01 13:25:43 --> Router Class Initialized
INFO - 2016-10-01 13:25:43 --> Output Class Initialized
INFO - 2016-10-01 13:25:43 --> Security Class Initialized
DEBUG - 2016-10-01 13:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-01 13:25:43 --> Input Class Initialized
INFO - 2016-10-01 13:25:43 --> Language Class Initialized
ERROR - 2016-10-01 13:25:43 --> 404 Page Not Found: /index
INFO - 2016-10-01 13:25:43 --> Config Class Initialized
INFO - 2016-10-01 13:25:43 --> Hooks Class Initialized
DEBUG - 2016-10-01 13:25:43 --> UTF-8 Support Enabled
INFO - 2016-10-01 13:25:43 --> Utf8 Class Initialized
INFO - 2016-10-01 13:25:43 --> URI Class Initialized
INFO - 2016-10-01 13:25:43 --> Router Class Initialized
INFO - 2016-10-01 13:25:43 --> Output Class Initialized
INFO - 2016-10-01 13:25:43 --> Security Class Initialized
DEBUG - 2016-10-01 13:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-01 13:25:43 --> Input Class Initialized
INFO - 2016-10-01 13:25:43 --> Language Class Initialized
ERROR - 2016-10-01 13:25:43 --> 404 Page Not Found: /index
INFO - 2016-10-01 13:25:43 --> Config Class Initialized
INFO - 2016-10-01 13:25:43 --> Hooks Class Initialized
DEBUG - 2016-10-01 13:25:43 --> UTF-8 Support Enabled
INFO - 2016-10-01 13:25:43 --> Utf8 Class Initialized
INFO - 2016-10-01 13:25:43 --> URI Class Initialized
INFO - 2016-10-01 13:25:43 --> Router Class Initialized
INFO - 2016-10-01 13:25:43 --> Output Class Initialized
INFO - 2016-10-01 13:25:43 --> Security Class Initialized
DEBUG - 2016-10-01 13:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-01 13:25:43 --> Input Class Initialized
INFO - 2016-10-01 13:25:43 --> Language Class Initialized
ERROR - 2016-10-01 13:25:43 --> 404 Page Not Found: /index
INFO - 2016-10-01 13:25:43 --> Config Class Initialized
INFO - 2016-10-01 13:25:43 --> Hooks Class Initialized
DEBUG - 2016-10-01 13:25:43 --> UTF-8 Support Enabled
INFO - 2016-10-01 13:25:43 --> Utf8 Class Initialized
INFO - 2016-10-01 13:25:43 --> URI Class Initialized
INFO - 2016-10-01 13:25:43 --> Router Class Initialized
INFO - 2016-10-01 13:25:43 --> Output Class Initialized
INFO - 2016-10-01 13:25:43 --> Security Class Initialized
DEBUG - 2016-10-01 13:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-01 13:25:43 --> Input Class Initialized
INFO - 2016-10-01 13:25:43 --> Language Class Initialized
ERROR - 2016-10-01 13:25:43 --> 404 Page Not Found: /index
INFO - 2016-10-01 13:25:43 --> Config Class Initialized
INFO - 2016-10-01 13:25:43 --> Hooks Class Initialized
DEBUG - 2016-10-01 13:25:43 --> UTF-8 Support Enabled
INFO - 2016-10-01 13:25:43 --> Utf8 Class Initialized
INFO - 2016-10-01 13:25:43 --> URI Class Initialized
INFO - 2016-10-01 13:25:43 --> Router Class Initialized
INFO - 2016-10-01 13:25:43 --> Output Class Initialized
INFO - 2016-10-01 13:25:43 --> Security Class Initialized
DEBUG - 2016-10-01 13:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-01 13:25:43 --> Input Class Initialized
INFO - 2016-10-01 13:25:43 --> Language Class Initialized
ERROR - 2016-10-01 13:25:43 --> 404 Page Not Found: /index
INFO - 2016-10-01 13:25:43 --> Config Class Initialized
INFO - 2016-10-01 13:25:43 --> Hooks Class Initialized
DEBUG - 2016-10-01 13:25:44 --> UTF-8 Support Enabled
INFO - 2016-10-01 13:25:44 --> Utf8 Class Initialized
INFO - 2016-10-01 13:25:44 --> URI Class Initialized
INFO - 2016-10-01 13:25:44 --> Router Class Initialized
INFO - 2016-10-01 13:25:44 --> Output Class Initialized
INFO - 2016-10-01 13:25:44 --> Security Class Initialized
DEBUG - 2016-10-01 13:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-01 13:25:44 --> Input Class Initialized
INFO - 2016-10-01 13:25:44 --> Language Class Initialized
ERROR - 2016-10-01 13:25:44 --> 404 Page Not Found: /index
INFO - 2016-10-01 13:25:44 --> Config Class Initialized
INFO - 2016-10-01 13:25:44 --> Hooks Class Initialized
DEBUG - 2016-10-01 13:25:44 --> UTF-8 Support Enabled
INFO - 2016-10-01 13:25:44 --> Utf8 Class Initialized
INFO - 2016-10-01 13:25:44 --> URI Class Initialized
INFO - 2016-10-01 13:25:44 --> Router Class Initialized
INFO - 2016-10-01 13:25:44 --> Output Class Initialized
INFO - 2016-10-01 13:25:44 --> Security Class Initialized
DEBUG - 2016-10-01 13:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-01 13:25:44 --> Input Class Initialized
INFO - 2016-10-01 13:25:44 --> Language Class Initialized
ERROR - 2016-10-01 13:25:44 --> 404 Page Not Found: /index
INFO - 2016-10-01 13:25:44 --> Config Class Initialized
INFO - 2016-10-01 13:25:44 --> Hooks Class Initialized
DEBUG - 2016-10-01 13:25:44 --> UTF-8 Support Enabled
INFO - 2016-10-01 13:25:44 --> Utf8 Class Initialized
INFO - 2016-10-01 13:25:44 --> URI Class Initialized
INFO - 2016-10-01 13:25:44 --> Router Class Initialized
INFO - 2016-10-01 13:25:44 --> Output Class Initialized
INFO - 2016-10-01 13:25:44 --> Security Class Initialized
DEBUG - 2016-10-01 13:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-01 13:25:44 --> Input Class Initialized
INFO - 2016-10-01 13:25:44 --> Language Class Initialized
ERROR - 2016-10-01 13:25:44 --> 404 Page Not Found: /index
INFO - 2016-10-01 13:25:44 --> Config Class Initialized
INFO - 2016-10-01 13:25:44 --> Hooks Class Initialized
DEBUG - 2016-10-01 13:25:44 --> UTF-8 Support Enabled
INFO - 2016-10-01 13:25:44 --> Utf8 Class Initialized
INFO - 2016-10-01 13:25:44 --> URI Class Initialized
INFO - 2016-10-01 13:25:44 --> Router Class Initialized
INFO - 2016-10-01 13:25:44 --> Output Class Initialized
INFO - 2016-10-01 13:25:44 --> Security Class Initialized
DEBUG - 2016-10-01 13:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-01 13:25:44 --> Input Class Initialized
INFO - 2016-10-01 13:25:44 --> Language Class Initialized
ERROR - 2016-10-01 13:25:44 --> 404 Page Not Found: /index
INFO - 2016-10-01 13:25:44 --> Config Class Initialized
INFO - 2016-10-01 13:25:44 --> Hooks Class Initialized
DEBUG - 2016-10-01 13:25:44 --> UTF-8 Support Enabled
INFO - 2016-10-01 13:25:44 --> Utf8 Class Initialized
INFO - 2016-10-01 13:25:44 --> URI Class Initialized
INFO - 2016-10-01 13:25:44 --> Router Class Initialized
INFO - 2016-10-01 13:25:44 --> Output Class Initialized
INFO - 2016-10-01 13:25:44 --> Security Class Initialized
DEBUG - 2016-10-01 13:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-01 13:25:44 --> Input Class Initialized
INFO - 2016-10-01 13:25:44 --> Language Class Initialized
ERROR - 2016-10-01 13:25:44 --> 404 Page Not Found: /index
INFO - 2016-10-01 13:25:44 --> Config Class Initialized
INFO - 2016-10-01 13:25:44 --> Hooks Class Initialized
DEBUG - 2016-10-01 13:25:44 --> UTF-8 Support Enabled
INFO - 2016-10-01 13:25:44 --> Utf8 Class Initialized
INFO - 2016-10-01 13:25:44 --> URI Class Initialized
INFO - 2016-10-01 13:25:44 --> Router Class Initialized
INFO - 2016-10-01 13:25:44 --> Output Class Initialized
INFO - 2016-10-01 13:25:44 --> Security Class Initialized
DEBUG - 2016-10-01 13:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-01 13:25:44 --> Input Class Initialized
INFO - 2016-10-01 13:25:44 --> Language Class Initialized
ERROR - 2016-10-01 13:25:44 --> 404 Page Not Found: /index
INFO - 2016-10-01 13:25:44 --> Config Class Initialized
INFO - 2016-10-01 13:25:44 --> Hooks Class Initialized
DEBUG - 2016-10-01 13:25:44 --> UTF-8 Support Enabled
INFO - 2016-10-01 13:25:44 --> Utf8 Class Initialized
INFO - 2016-10-01 13:25:44 --> URI Class Initialized
INFO - 2016-10-01 13:25:44 --> Router Class Initialized
INFO - 2016-10-01 13:25:44 --> Output Class Initialized
INFO - 2016-10-01 13:25:44 --> Security Class Initialized
DEBUG - 2016-10-01 13:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-01 13:25:44 --> Input Class Initialized
INFO - 2016-10-01 13:25:44 --> Language Class Initialized
ERROR - 2016-10-01 13:25:44 --> 404 Page Not Found: /index
INFO - 2016-10-01 13:25:44 --> Config Class Initialized
INFO - 2016-10-01 13:25:44 --> Hooks Class Initialized
DEBUG - 2016-10-01 13:25:44 --> UTF-8 Support Enabled
INFO - 2016-10-01 13:25:44 --> Utf8 Class Initialized
INFO - 2016-10-01 13:25:44 --> URI Class Initialized
INFO - 2016-10-01 13:25:44 --> Router Class Initialized
INFO - 2016-10-01 13:25:44 --> Output Class Initialized
INFO - 2016-10-01 13:25:44 --> Security Class Initialized
DEBUG - 2016-10-01 13:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-01 13:25:44 --> Input Class Initialized
INFO - 2016-10-01 13:25:44 --> Language Class Initialized
ERROR - 2016-10-01 13:25:44 --> 404 Page Not Found: /index
INFO - 2016-10-01 13:44:55 --> Config Class Initialized
INFO - 2016-10-01 13:44:55 --> Hooks Class Initialized
DEBUG - 2016-10-01 13:44:55 --> UTF-8 Support Enabled
INFO - 2016-10-01 13:44:55 --> Utf8 Class Initialized
INFO - 2016-10-01 13:44:55 --> URI Class Initialized
DEBUG - 2016-10-01 13:44:55 --> No URI present. Default controller set.
INFO - 2016-10-01 13:44:55 --> Router Class Initialized
INFO - 2016-10-01 13:44:55 --> Output Class Initialized
INFO - 2016-10-01 13:44:55 --> Security Class Initialized
DEBUG - 2016-10-01 13:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-01 13:44:55 --> Input Class Initialized
INFO - 2016-10-01 13:44:55 --> Language Class Initialized
INFO - 2016-10-01 13:44:55 --> Language Class Initialized
INFO - 2016-10-01 13:44:55 --> Config Class Initialized
INFO - 2016-10-01 13:44:55 --> Loader Class Initialized
INFO - 2016-10-01 13:44:55 --> Helper loaded: url_helper
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-01 13:44:55 --> Controller Class Initialized
DEBUG - 2016-10-01 13:44:55 --> Index MX_Controller Initialized
INFO - 2016-10-01 13:44:55 --> Model Class Initialized
INFO - 2016-10-01 13:44:55 --> Model Class Initialized
ERROR - 2016-10-01 13:44:55 --> Unable to delete cache file for 
DEBUG - 2016-10-01 13:44:55 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-10-01 13:44:55 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-10-01 13:44:55 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-10-01 13:44:55 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-10-01 13:44:55 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-10-01 13:44:55 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:55 --> Database Driver Class Initialized
DEBUG - 2016-10-01 13:44:55 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-10-01 13:44:55 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-10-01 13:44:55 --> Final output sent to browser
DEBUG - 2016-10-01 13:44:55 --> Total execution time: 0.1396
INFO - 2016-10-01 13:44:56 --> Config Class Initialized
INFO - 2016-10-01 13:44:56 --> Hooks Class Initialized
DEBUG - 2016-10-01 13:44:56 --> UTF-8 Support Enabled
INFO - 2016-10-01 13:44:56 --> Utf8 Class Initialized
INFO - 2016-10-01 13:44:56 --> URI Class Initialized
INFO - 2016-10-01 13:44:56 --> Router Class Initialized
INFO - 2016-10-01 13:44:56 --> Output Class Initialized
INFO - 2016-10-01 13:44:56 --> Security Class Initialized
DEBUG - 2016-10-01 13:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-01 13:44:56 --> Input Class Initialized
INFO - 2016-10-01 13:44:56 --> Language Class Initialized
INFO - 2016-10-01 13:44:56 --> Language Class Initialized
INFO - 2016-10-01 13:44:56 --> Config Class Initialized
INFO - 2016-10-01 13:44:56 --> Loader Class Initialized
INFO - 2016-10-01 13:44:56 --> Helper loaded: url_helper
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-01 13:44:56 --> Controller Class Initialized
DEBUG - 2016-10-01 13:44:56 --> login MX_Controller Initialized
INFO - 2016-10-01 13:44:56 --> Model Class Initialized
INFO - 2016-10-01 13:44:56 --> Model Class Initialized
DEBUG - 2016-10-01 13:44:56 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-10-01 13:44:56 --> Final output sent to browser
DEBUG - 2016-10-01 13:44:56 --> Total execution time: 0.0547
INFO - 2016-10-01 13:44:56 --> Config Class Initialized
INFO - 2016-10-01 13:44:56 --> Hooks Class Initialized
DEBUG - 2016-10-01 13:44:56 --> UTF-8 Support Enabled
INFO - 2016-10-01 13:44:56 --> Utf8 Class Initialized
INFO - 2016-10-01 13:44:56 --> URI Class Initialized
DEBUG - 2016-10-01 13:44:56 --> No URI present. Default controller set.
INFO - 2016-10-01 13:44:56 --> Router Class Initialized
INFO - 2016-10-01 13:44:56 --> Output Class Initialized
INFO - 2016-10-01 13:44:56 --> Security Class Initialized
DEBUG - 2016-10-01 13:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-01 13:44:56 --> Input Class Initialized
INFO - 2016-10-01 13:44:56 --> Language Class Initialized
INFO - 2016-10-01 13:44:56 --> Language Class Initialized
INFO - 2016-10-01 13:44:56 --> Config Class Initialized
INFO - 2016-10-01 13:44:56 --> Loader Class Initialized
INFO - 2016-10-01 13:44:56 --> Helper loaded: url_helper
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-01 13:44:56 --> Controller Class Initialized
DEBUG - 2016-10-01 13:44:56 --> Index MX_Controller Initialized
INFO - 2016-10-01 13:44:56 --> Model Class Initialized
INFO - 2016-10-01 13:44:56 --> Model Class Initialized
ERROR - 2016-10-01 13:44:56 --> Unable to delete cache file for 
DEBUG - 2016-10-01 13:44:56 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-10-01 13:44:56 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-10-01 13:44:56 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-10-01 13:44:56 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-10-01 13:44:56 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-10-01 13:44:56 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:56 --> Database Driver Class Initialized
DEBUG - 2016-10-01 13:44:56 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-10-01 13:44:56 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-10-01 13:44:56 --> Final output sent to browser
DEBUG - 2016-10-01 13:44:56 --> Total execution time: 0.1786
INFO - 2016-10-01 13:44:57 --> Config Class Initialized
INFO - 2016-10-01 13:44:57 --> Hooks Class Initialized
DEBUG - 2016-10-01 13:44:57 --> UTF-8 Support Enabled
INFO - 2016-10-01 13:44:57 --> Utf8 Class Initialized
INFO - 2016-10-01 13:44:57 --> URI Class Initialized
INFO - 2016-10-01 13:44:57 --> Router Class Initialized
INFO - 2016-10-01 13:44:57 --> Output Class Initialized
INFO - 2016-10-01 13:44:57 --> Security Class Initialized
DEBUG - 2016-10-01 13:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-01 13:44:57 --> Input Class Initialized
INFO - 2016-10-01 13:44:57 --> Language Class Initialized
INFO - 2016-10-01 13:44:57 --> Language Class Initialized
INFO - 2016-10-01 13:44:57 --> Config Class Initialized
INFO - 2016-10-01 13:44:57 --> Loader Class Initialized
INFO - 2016-10-01 13:44:57 --> Helper loaded: url_helper
INFO - 2016-10-01 13:44:57 --> Database Driver Class Initialized
INFO - 2016-10-01 13:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-01 13:44:57 --> Controller Class Initialized
DEBUG - 2016-10-01 13:44:57 --> login MX_Controller Initialized
INFO - 2016-10-01 13:44:57 --> Model Class Initialized
INFO - 2016-10-01 13:44:57 --> Model Class Initialized
DEBUG - 2016-10-01 13:44:57 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-10-01 13:44:57 --> Final output sent to browser
DEBUG - 2016-10-01 13:44:57 --> Total execution time: 0.0304
INFO - 2016-10-01 16:28:36 --> Config Class Initialized
INFO - 2016-10-01 16:28:36 --> Hooks Class Initialized
DEBUG - 2016-10-01 16:28:36 --> UTF-8 Support Enabled
INFO - 2016-10-01 16:28:36 --> Utf8 Class Initialized
INFO - 2016-10-01 16:28:36 --> URI Class Initialized
DEBUG - 2016-10-01 16:28:36 --> No URI present. Default controller set.
INFO - 2016-10-01 16:28:36 --> Router Class Initialized
INFO - 2016-10-01 16:28:36 --> Output Class Initialized
INFO - 2016-10-01 16:28:36 --> Security Class Initialized
DEBUG - 2016-10-01 16:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-01 16:28:36 --> Input Class Initialized
INFO - 2016-10-01 16:28:36 --> Language Class Initialized
INFO - 2016-10-01 16:28:36 --> Language Class Initialized
INFO - 2016-10-01 16:28:36 --> Config Class Initialized
INFO - 2016-10-01 16:28:36 --> Loader Class Initialized
INFO - 2016-10-01 16:28:36 --> Helper loaded: url_helper
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-01 16:28:36 --> Controller Class Initialized
DEBUG - 2016-10-01 16:28:36 --> Index MX_Controller Initialized
INFO - 2016-10-01 16:28:36 --> Model Class Initialized
INFO - 2016-10-01 16:28:36 --> Model Class Initialized
ERROR - 2016-10-01 16:28:36 --> Unable to delete cache file for 
DEBUG - 2016-10-01 16:28:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-10-01 16:28:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-10-01 16:28:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-10-01 16:28:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-10-01 16:28:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-10-01 16:28:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:36 --> Database Driver Class Initialized
DEBUG - 2016-10-01 16:28:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-10-01 16:28:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-10-01 16:28:36 --> Final output sent to browser
DEBUG - 2016-10-01 16:28:36 --> Total execution time: 0.2955
INFO - 2016-10-01 16:28:37 --> Config Class Initialized
INFO - 2016-10-01 16:28:37 --> Hooks Class Initialized
DEBUG - 2016-10-01 16:28:37 --> UTF-8 Support Enabled
INFO - 2016-10-01 16:28:37 --> Utf8 Class Initialized
INFO - 2016-10-01 16:28:37 --> URI Class Initialized
INFO - 2016-10-01 16:28:37 --> Router Class Initialized
INFO - 2016-10-01 16:28:37 --> Output Class Initialized
INFO - 2016-10-01 16:28:37 --> Security Class Initialized
DEBUG - 2016-10-01 16:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-01 16:28:37 --> Input Class Initialized
INFO - 2016-10-01 16:28:37 --> Language Class Initialized
INFO - 2016-10-01 16:28:37 --> Language Class Initialized
INFO - 2016-10-01 16:28:37 --> Config Class Initialized
INFO - 2016-10-01 16:28:37 --> Loader Class Initialized
INFO - 2016-10-01 16:28:37 --> Helper loaded: url_helper
INFO - 2016-10-01 16:28:37 --> Database Driver Class Initialized
INFO - 2016-10-01 16:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-01 16:28:37 --> Controller Class Initialized
DEBUG - 2016-10-01 16:28:37 --> login MX_Controller Initialized
INFO - 2016-10-01 16:28:37 --> Model Class Initialized
INFO - 2016-10-01 16:28:37 --> Model Class Initialized
DEBUG - 2016-10-01 16:28:37 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-10-01 16:28:37 --> Final output sent to browser
DEBUG - 2016-10-01 16:28:37 --> Total execution time: 0.0435
INFO - 2016-10-01 17:32:18 --> Config Class Initialized
INFO - 2016-10-01 17:32:18 --> Hooks Class Initialized
DEBUG - 2016-10-01 17:32:18 --> UTF-8 Support Enabled
INFO - 2016-10-01 17:32:18 --> Utf8 Class Initialized
INFO - 2016-10-01 17:32:18 --> URI Class Initialized
DEBUG - 2016-10-01 17:32:18 --> No URI present. Default controller set.
INFO - 2016-10-01 17:32:18 --> Router Class Initialized
INFO - 2016-10-01 17:32:18 --> Output Class Initialized
INFO - 2016-10-01 17:32:18 --> Security Class Initialized
DEBUG - 2016-10-01 17:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-01 17:32:18 --> Input Class Initialized
INFO - 2016-10-01 17:32:18 --> Language Class Initialized
INFO - 2016-10-01 17:32:18 --> Language Class Initialized
INFO - 2016-10-01 17:32:18 --> Config Class Initialized
INFO - 2016-10-01 17:32:18 --> Loader Class Initialized
INFO - 2016-10-01 17:32:18 --> Helper loaded: url_helper
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-01 17:32:18 --> Controller Class Initialized
DEBUG - 2016-10-01 17:32:18 --> Index MX_Controller Initialized
INFO - 2016-10-01 17:32:18 --> Model Class Initialized
INFO - 2016-10-01 17:32:18 --> Model Class Initialized
ERROR - 2016-10-01 17:32:18 --> Unable to delete cache file for 
DEBUG - 2016-10-01 17:32:18 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-10-01 17:32:18 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-10-01 17:32:18 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-10-01 17:32:18 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-10-01 17:32:18 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-10-01 17:32:18 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
INFO - 2016-10-01 17:32:18 --> Database Driver Class Initialized
DEBUG - 2016-10-01 17:32:18 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-10-01 17:32:18 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-10-01 17:32:18 --> Final output sent to browser
DEBUG - 2016-10-01 17:32:18 --> Total execution time: 0.2411
INFO - 2016-10-01 17:32:19 --> Config Class Initialized
INFO - 2016-10-01 17:32:19 --> Hooks Class Initialized
DEBUG - 2016-10-01 17:32:19 --> UTF-8 Support Enabled
INFO - 2016-10-01 17:32:19 --> Utf8 Class Initialized
INFO - 2016-10-01 17:32:19 --> URI Class Initialized
INFO - 2016-10-01 17:32:19 --> Router Class Initialized
INFO - 2016-10-01 17:32:19 --> Output Class Initialized
INFO - 2016-10-01 17:32:19 --> Security Class Initialized
DEBUG - 2016-10-01 17:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-01 17:32:19 --> Input Class Initialized
INFO - 2016-10-01 17:32:19 --> Language Class Initialized
ERROR - 2016-10-01 17:32:19 --> 404 Page Not Found: /index
INFO - 2016-10-01 17:32:19 --> Config Class Initialized
INFO - 2016-10-01 17:32:19 --> Hooks Class Initialized
DEBUG - 2016-10-01 17:32:19 --> UTF-8 Support Enabled
INFO - 2016-10-01 17:32:19 --> Utf8 Class Initialized
INFO - 2016-10-01 17:32:19 --> URI Class Initialized
INFO - 2016-10-01 17:32:19 --> Router Class Initialized
INFO - 2016-10-01 17:32:19 --> Output Class Initialized
INFO - 2016-10-01 17:32:19 --> Security Class Initialized
DEBUG - 2016-10-01 17:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-01 17:32:19 --> Input Class Initialized
INFO - 2016-10-01 17:32:19 --> Language Class Initialized
ERROR - 2016-10-01 17:32:19 --> 404 Page Not Found: /index
INFO - 2016-10-01 17:32:20 --> Config Class Initialized
INFO - 2016-10-01 17:32:20 --> Hooks Class Initialized
DEBUG - 2016-10-01 17:32:20 --> UTF-8 Support Enabled
INFO - 2016-10-01 17:32:20 --> Utf8 Class Initialized
INFO - 2016-10-01 17:32:20 --> URI Class Initialized
INFO - 2016-10-01 17:32:20 --> Router Class Initialized
INFO - 2016-10-01 17:32:20 --> Output Class Initialized
INFO - 2016-10-01 17:32:20 --> Security Class Initialized
DEBUG - 2016-10-01 17:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-01 17:32:20 --> Input Class Initialized
INFO - 2016-10-01 17:32:20 --> Language Class Initialized
ERROR - 2016-10-01 17:32:20 --> 404 Page Not Found: /index
INFO - 2016-10-01 17:32:21 --> Config Class Initialized
INFO - 2016-10-01 17:32:21 --> Hooks Class Initialized
DEBUG - 2016-10-01 17:32:21 --> UTF-8 Support Enabled
INFO - 2016-10-01 17:32:21 --> Utf8 Class Initialized
INFO - 2016-10-01 17:32:21 --> URI Class Initialized
INFO - 2016-10-01 17:32:21 --> Router Class Initialized
INFO - 2016-10-01 17:32:21 --> Output Class Initialized
INFO - 2016-10-01 17:32:21 --> Security Class Initialized
DEBUG - 2016-10-01 17:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-01 17:32:21 --> Input Class Initialized
INFO - 2016-10-01 17:32:21 --> Language Class Initialized
ERROR - 2016-10-01 17:32:21 --> 404 Page Not Found: /index
INFO - 2016-10-01 17:32:21 --> Config Class Initialized
INFO - 2016-10-01 17:32:21 --> Hooks Class Initialized
DEBUG - 2016-10-01 17:32:21 --> UTF-8 Support Enabled
INFO - 2016-10-01 17:32:21 --> Utf8 Class Initialized
INFO - 2016-10-01 17:32:21 --> URI Class Initialized
INFO - 2016-10-01 17:32:21 --> Router Class Initialized
INFO - 2016-10-01 17:32:21 --> Output Class Initialized
INFO - 2016-10-01 17:32:21 --> Security Class Initialized
DEBUG - 2016-10-01 17:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-01 17:32:21 --> Input Class Initialized
INFO - 2016-10-01 17:32:21 --> Language Class Initialized
ERROR - 2016-10-01 17:32:21 --> 404 Page Not Found: /index
INFO - 2016-10-01 17:32:22 --> Config Class Initialized
INFO - 2016-10-01 17:32:22 --> Hooks Class Initialized
DEBUG - 2016-10-01 17:32:22 --> UTF-8 Support Enabled
INFO - 2016-10-01 17:32:22 --> Utf8 Class Initialized
INFO - 2016-10-01 17:32:22 --> URI Class Initialized
INFO - 2016-10-01 17:32:22 --> Router Class Initialized
INFO - 2016-10-01 17:32:22 --> Output Class Initialized
INFO - 2016-10-01 17:32:22 --> Security Class Initialized
DEBUG - 2016-10-01 17:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-01 17:32:22 --> Input Class Initialized
INFO - 2016-10-01 17:32:22 --> Language Class Initialized
ERROR - 2016-10-01 17:32:22 --> 404 Page Not Found: /index
INFO - 2016-10-01 17:32:22 --> Config Class Initialized
INFO - 2016-10-01 17:32:22 --> Hooks Class Initialized
DEBUG - 2016-10-01 17:32:22 --> UTF-8 Support Enabled
INFO - 2016-10-01 17:32:22 --> Utf8 Class Initialized
INFO - 2016-10-01 17:32:22 --> URI Class Initialized
INFO - 2016-10-01 17:32:22 --> Router Class Initialized
INFO - 2016-10-01 17:32:22 --> Output Class Initialized
INFO - 2016-10-01 17:32:22 --> Security Class Initialized
DEBUG - 2016-10-01 17:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-01 17:32:22 --> Input Class Initialized
INFO - 2016-10-01 17:32:22 --> Language Class Initialized
ERROR - 2016-10-01 17:32:22 --> 404 Page Not Found: /index
INFO - 2016-10-01 17:32:23 --> Config Class Initialized
INFO - 2016-10-01 17:32:23 --> Hooks Class Initialized
DEBUG - 2016-10-01 17:32:23 --> UTF-8 Support Enabled
INFO - 2016-10-01 17:32:23 --> Utf8 Class Initialized
INFO - 2016-10-01 17:32:23 --> URI Class Initialized
INFO - 2016-10-01 17:32:23 --> Router Class Initialized
INFO - 2016-10-01 17:32:23 --> Output Class Initialized
INFO - 2016-10-01 17:32:23 --> Security Class Initialized
DEBUG - 2016-10-01 17:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-01 17:32:23 --> Input Class Initialized
INFO - 2016-10-01 17:32:23 --> Language Class Initialized
ERROR - 2016-10-01 17:32:23 --> 404 Page Not Found: /index
INFO - 2016-10-01 17:32:24 --> Config Class Initialized
INFO - 2016-10-01 17:32:24 --> Hooks Class Initialized
DEBUG - 2016-10-01 17:32:24 --> UTF-8 Support Enabled
INFO - 2016-10-01 17:32:24 --> Utf8 Class Initialized
INFO - 2016-10-01 17:32:24 --> URI Class Initialized
INFO - 2016-10-01 17:32:24 --> Router Class Initialized
INFO - 2016-10-01 17:32:24 --> Output Class Initialized
INFO - 2016-10-01 17:32:24 --> Security Class Initialized
DEBUG - 2016-10-01 17:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-01 17:32:24 --> Input Class Initialized
INFO - 2016-10-01 17:32:24 --> Language Class Initialized
ERROR - 2016-10-01 17:32:24 --> 404 Page Not Found: /index
INFO - 2016-10-01 17:32:24 --> Config Class Initialized
INFO - 2016-10-01 17:32:24 --> Hooks Class Initialized
DEBUG - 2016-10-01 17:32:24 --> UTF-8 Support Enabled
INFO - 2016-10-01 17:32:24 --> Utf8 Class Initialized
INFO - 2016-10-01 17:32:24 --> URI Class Initialized
INFO - 2016-10-01 17:32:24 --> Router Class Initialized
INFO - 2016-10-01 17:32:24 --> Output Class Initialized
INFO - 2016-10-01 17:32:24 --> Security Class Initialized
DEBUG - 2016-10-01 17:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-01 17:32:24 --> Input Class Initialized
INFO - 2016-10-01 17:32:24 --> Language Class Initialized
ERROR - 2016-10-01 17:32:24 --> 404 Page Not Found: /index
INFO - 2016-10-01 17:32:25 --> Config Class Initialized
INFO - 2016-10-01 17:32:25 --> Hooks Class Initialized
DEBUG - 2016-10-01 17:32:25 --> UTF-8 Support Enabled
INFO - 2016-10-01 17:32:25 --> Utf8 Class Initialized
INFO - 2016-10-01 17:32:25 --> URI Class Initialized
INFO - 2016-10-01 17:32:25 --> Router Class Initialized
INFO - 2016-10-01 17:32:25 --> Output Class Initialized
INFO - 2016-10-01 17:32:25 --> Security Class Initialized
DEBUG - 2016-10-01 17:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-01 17:32:25 --> Input Class Initialized
INFO - 2016-10-01 17:32:25 --> Language Class Initialized
ERROR - 2016-10-01 17:32:25 --> 404 Page Not Found: /index
INFO - 2016-10-01 17:32:25 --> Config Class Initialized
INFO - 2016-10-01 17:32:25 --> Hooks Class Initialized
DEBUG - 2016-10-01 17:32:25 --> UTF-8 Support Enabled
INFO - 2016-10-01 17:32:25 --> Utf8 Class Initialized
INFO - 2016-10-01 17:32:25 --> URI Class Initialized
INFO - 2016-10-01 17:32:25 --> Router Class Initialized
INFO - 2016-10-01 17:32:25 --> Output Class Initialized
INFO - 2016-10-01 17:32:25 --> Security Class Initialized
DEBUG - 2016-10-01 17:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-01 17:32:25 --> Input Class Initialized
INFO - 2016-10-01 17:32:25 --> Language Class Initialized
ERROR - 2016-10-01 17:32:25 --> 404 Page Not Found: /index
INFO - 2016-10-01 17:32:26 --> Config Class Initialized
INFO - 2016-10-01 17:32:26 --> Hooks Class Initialized
DEBUG - 2016-10-01 17:32:26 --> UTF-8 Support Enabled
INFO - 2016-10-01 17:32:26 --> Utf8 Class Initialized
INFO - 2016-10-01 17:32:26 --> URI Class Initialized
INFO - 2016-10-01 17:32:26 --> Router Class Initialized
INFO - 2016-10-01 17:32:26 --> Output Class Initialized
INFO - 2016-10-01 17:32:26 --> Security Class Initialized
DEBUG - 2016-10-01 17:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-01 17:32:26 --> Input Class Initialized
INFO - 2016-10-01 17:32:26 --> Language Class Initialized
ERROR - 2016-10-01 17:32:26 --> 404 Page Not Found: /index
INFO - 2016-10-01 17:32:27 --> Config Class Initialized
INFO - 2016-10-01 17:32:27 --> Hooks Class Initialized
DEBUG - 2016-10-01 17:32:27 --> UTF-8 Support Enabled
INFO - 2016-10-01 17:32:27 --> Utf8 Class Initialized
INFO - 2016-10-01 17:32:27 --> URI Class Initialized
INFO - 2016-10-01 17:32:27 --> Router Class Initialized
INFO - 2016-10-01 17:32:27 --> Output Class Initialized
INFO - 2016-10-01 17:32:27 --> Security Class Initialized
DEBUG - 2016-10-01 17:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-01 17:32:27 --> Input Class Initialized
INFO - 2016-10-01 17:32:27 --> Language Class Initialized
ERROR - 2016-10-01 17:32:27 --> 404 Page Not Found: /index
INFO - 2016-10-01 20:05:10 --> Config Class Initialized
INFO - 2016-10-01 20:05:10 --> Hooks Class Initialized
DEBUG - 2016-10-01 20:05:10 --> UTF-8 Support Enabled
INFO - 2016-10-01 20:05:10 --> Utf8 Class Initialized
INFO - 2016-10-01 20:05:10 --> URI Class Initialized
INFO - 2016-10-01 20:05:10 --> Router Class Initialized
INFO - 2016-10-01 20:05:10 --> Output Class Initialized
INFO - 2016-10-01 20:05:10 --> Security Class Initialized
DEBUG - 2016-10-01 20:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-01 20:05:10 --> Input Class Initialized
INFO - 2016-10-01 20:05:10 --> Language Class Initialized
ERROR - 2016-10-01 20:05:10 --> 404 Page Not Found: /index
INFO - 2016-10-01 20:05:14 --> Config Class Initialized
INFO - 2016-10-01 20:05:14 --> Hooks Class Initialized
DEBUG - 2016-10-01 20:05:14 --> UTF-8 Support Enabled
INFO - 2016-10-01 20:05:14 --> Utf8 Class Initialized
INFO - 2016-10-01 20:05:14 --> URI Class Initialized
INFO - 2016-10-01 20:05:14 --> Router Class Initialized
INFO - 2016-10-01 20:05:14 --> Output Class Initialized
INFO - 2016-10-01 20:05:14 --> Security Class Initialized
DEBUG - 2016-10-01 20:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-01 20:05:14 --> Input Class Initialized
INFO - 2016-10-01 20:05:14 --> Language Class Initialized
ERROR - 2016-10-01 20:05:14 --> 404 Page Not Found: /index
