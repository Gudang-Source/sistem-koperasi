<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-09-10 05:00:49 --> Config Class Initialized
INFO - 2016-09-10 05:00:49 --> Hooks Class Initialized
DEBUG - 2016-09-10 05:00:49 --> UTF-8 Support Enabled
INFO - 2016-09-10 05:00:49 --> Utf8 Class Initialized
INFO - 2016-09-10 05:00:49 --> URI Class Initialized
INFO - 2016-09-10 05:00:49 --> Router Class Initialized
INFO - 2016-09-10 05:00:49 --> Output Class Initialized
INFO - 2016-09-10 05:00:49 --> Security Class Initialized
DEBUG - 2016-09-10 05:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 05:00:49 --> Input Class Initialized
INFO - 2016-09-10 05:00:49 --> Language Class Initialized
INFO - 2016-09-10 05:00:50 --> Language Class Initialized
INFO - 2016-09-10 05:00:50 --> Config Class Initialized
INFO - 2016-09-10 05:00:50 --> Loader Class Initialized
INFO - 2016-09-10 05:00:50 --> Helper loaded: url_helper
INFO - 2016-09-10 05:00:50 --> Database Driver Class Initialized
INFO - 2016-09-10 05:00:50 --> Controller Class Initialized
DEBUG - 2016-09-10 05:00:50 --> Index MX_Controller Initialized
INFO - 2016-09-10 05:00:50 --> Model Class Initialized
INFO - 2016-09-10 05:00:50 --> Model Class Initialized
DEBUG - 2016-09-10 05:00:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-10 05:00:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-10 05:00:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-10 05:00:50 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-10 05:00:50 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-10 05:00:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-10 05:00:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-10 05:00:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-10 05:00:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-10 05:00:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-10 05:00:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-10 05:00:51 --> Final output sent to browser
DEBUG - 2016-09-10 05:00:51 --> Total execution time: 2.3650
INFO - 2016-09-10 05:01:08 --> Config Class Initialized
INFO - 2016-09-10 05:01:08 --> Hooks Class Initialized
DEBUG - 2016-09-10 05:01:08 --> UTF-8 Support Enabled
INFO - 2016-09-10 05:01:08 --> Utf8 Class Initialized
INFO - 2016-09-10 05:01:08 --> URI Class Initialized
INFO - 2016-09-10 05:01:08 --> Router Class Initialized
INFO - 2016-09-10 05:01:08 --> Output Class Initialized
INFO - 2016-09-10 05:01:08 --> Security Class Initialized
DEBUG - 2016-09-10 05:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 05:01:08 --> Input Class Initialized
INFO - 2016-09-10 05:01:08 --> Language Class Initialized
INFO - 2016-09-10 05:01:08 --> Language Class Initialized
INFO - 2016-09-10 05:01:08 --> Config Class Initialized
INFO - 2016-09-10 05:01:08 --> Loader Class Initialized
INFO - 2016-09-10 05:01:08 --> Helper loaded: url_helper
INFO - 2016-09-10 05:01:08 --> Database Driver Class Initialized
INFO - 2016-09-10 05:01:08 --> Controller Class Initialized
DEBUG - 2016-09-10 05:01:08 --> Index MX_Controller Initialized
INFO - 2016-09-10 05:01:08 --> Model Class Initialized
INFO - 2016-09-10 05:01:08 --> Model Class Initialized
DEBUG - 2016-09-10 05:01:08 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 05:01:09 --> Final output sent to browser
DEBUG - 2016-09-10 05:01:09 --> Total execution time: 0.5624
INFO - 2016-09-10 05:02:17 --> Config Class Initialized
INFO - 2016-09-10 05:02:17 --> Hooks Class Initialized
DEBUG - 2016-09-10 05:02:17 --> UTF-8 Support Enabled
INFO - 2016-09-10 05:02:17 --> Utf8 Class Initialized
INFO - 2016-09-10 05:02:17 --> URI Class Initialized
INFO - 2016-09-10 05:02:17 --> Router Class Initialized
INFO - 2016-09-10 05:02:17 --> Output Class Initialized
INFO - 2016-09-10 05:02:17 --> Security Class Initialized
DEBUG - 2016-09-10 05:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 05:02:17 --> Input Class Initialized
INFO - 2016-09-10 05:02:17 --> Language Class Initialized
INFO - 2016-09-10 05:02:17 --> Language Class Initialized
INFO - 2016-09-10 05:02:17 --> Config Class Initialized
INFO - 2016-09-10 05:02:17 --> Loader Class Initialized
INFO - 2016-09-10 05:02:17 --> Helper loaded: url_helper
INFO - 2016-09-10 05:02:17 --> Database Driver Class Initialized
INFO - 2016-09-10 05:02:17 --> Controller Class Initialized
DEBUG - 2016-09-10 05:02:17 --> Index MX_Controller Initialized
INFO - 2016-09-10 05:02:17 --> Model Class Initialized
INFO - 2016-09-10 05:02:17 --> Model Class Initialized
DEBUG - 2016-09-10 05:02:17 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 05:02:17 --> Final output sent to browser
DEBUG - 2016-09-10 05:02:17 --> Total execution time: 0.4486
INFO - 2016-09-10 05:03:38 --> Config Class Initialized
INFO - 2016-09-10 05:03:38 --> Hooks Class Initialized
DEBUG - 2016-09-10 05:03:38 --> UTF-8 Support Enabled
INFO - 2016-09-10 05:03:38 --> Utf8 Class Initialized
INFO - 2016-09-10 05:03:38 --> URI Class Initialized
INFO - 2016-09-10 05:03:38 --> Router Class Initialized
INFO - 2016-09-10 05:03:38 --> Output Class Initialized
INFO - 2016-09-10 05:03:38 --> Security Class Initialized
DEBUG - 2016-09-10 05:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 05:03:38 --> Input Class Initialized
INFO - 2016-09-10 05:03:38 --> Language Class Initialized
INFO - 2016-09-10 05:03:38 --> Language Class Initialized
INFO - 2016-09-10 05:03:38 --> Config Class Initialized
INFO - 2016-09-10 05:03:38 --> Loader Class Initialized
INFO - 2016-09-10 05:03:38 --> Helper loaded: url_helper
INFO - 2016-09-10 05:03:38 --> Database Driver Class Initialized
INFO - 2016-09-10 05:03:38 --> Controller Class Initialized
DEBUG - 2016-09-10 05:03:38 --> Index MX_Controller Initialized
INFO - 2016-09-10 05:03:38 --> Model Class Initialized
INFO - 2016-09-10 05:03:38 --> Model Class Initialized
DEBUG - 2016-09-10 05:03:38 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 05:03:38 --> Final output sent to browser
DEBUG - 2016-09-10 05:03:38 --> Total execution time: 0.4237
INFO - 2016-09-10 05:03:53 --> Config Class Initialized
INFO - 2016-09-10 05:03:53 --> Hooks Class Initialized
DEBUG - 2016-09-10 05:03:53 --> UTF-8 Support Enabled
INFO - 2016-09-10 05:03:53 --> Utf8 Class Initialized
INFO - 2016-09-10 05:03:53 --> URI Class Initialized
INFO - 2016-09-10 05:03:53 --> Router Class Initialized
INFO - 2016-09-10 05:03:53 --> Output Class Initialized
INFO - 2016-09-10 05:03:53 --> Security Class Initialized
DEBUG - 2016-09-10 05:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 05:03:53 --> Input Class Initialized
INFO - 2016-09-10 05:03:53 --> Language Class Initialized
INFO - 2016-09-10 05:03:53 --> Language Class Initialized
INFO - 2016-09-10 05:03:53 --> Config Class Initialized
INFO - 2016-09-10 05:03:53 --> Loader Class Initialized
INFO - 2016-09-10 05:03:53 --> Helper loaded: url_helper
INFO - 2016-09-10 05:03:53 --> Database Driver Class Initialized
INFO - 2016-09-10 05:03:53 --> Controller Class Initialized
DEBUG - 2016-09-10 05:03:53 --> Index MX_Controller Initialized
INFO - 2016-09-10 05:03:53 --> Model Class Initialized
INFO - 2016-09-10 05:03:53 --> Model Class Initialized
DEBUG - 2016-09-10 05:03:53 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 05:03:53 --> Final output sent to browser
DEBUG - 2016-09-10 05:03:53 --> Total execution time: 0.4649
INFO - 2016-09-10 05:04:25 --> Config Class Initialized
INFO - 2016-09-10 05:04:25 --> Hooks Class Initialized
DEBUG - 2016-09-10 05:04:25 --> UTF-8 Support Enabled
INFO - 2016-09-10 05:04:25 --> Utf8 Class Initialized
INFO - 2016-09-10 05:04:25 --> URI Class Initialized
INFO - 2016-09-10 05:04:25 --> Router Class Initialized
INFO - 2016-09-10 05:04:25 --> Output Class Initialized
INFO - 2016-09-10 05:04:25 --> Security Class Initialized
DEBUG - 2016-09-10 05:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 05:04:26 --> Input Class Initialized
INFO - 2016-09-10 05:04:26 --> Language Class Initialized
INFO - 2016-09-10 05:04:26 --> Language Class Initialized
INFO - 2016-09-10 05:04:26 --> Config Class Initialized
INFO - 2016-09-10 05:04:26 --> Loader Class Initialized
INFO - 2016-09-10 05:04:26 --> Helper loaded: url_helper
INFO - 2016-09-10 05:04:26 --> Database Driver Class Initialized
INFO - 2016-09-10 05:04:26 --> Controller Class Initialized
DEBUG - 2016-09-10 05:04:26 --> Index MX_Controller Initialized
INFO - 2016-09-10 05:04:26 --> Model Class Initialized
INFO - 2016-09-10 05:04:26 --> Model Class Initialized
DEBUG - 2016-09-10 05:04:26 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 05:04:26 --> Final output sent to browser
DEBUG - 2016-09-10 05:04:26 --> Total execution time: 0.4266
INFO - 2016-09-10 05:13:35 --> Config Class Initialized
INFO - 2016-09-10 05:13:35 --> Hooks Class Initialized
DEBUG - 2016-09-10 05:13:35 --> UTF-8 Support Enabled
INFO - 2016-09-10 05:13:35 --> Utf8 Class Initialized
INFO - 2016-09-10 05:13:35 --> URI Class Initialized
INFO - 2016-09-10 05:13:35 --> Router Class Initialized
INFO - 2016-09-10 05:13:35 --> Output Class Initialized
INFO - 2016-09-10 05:13:36 --> Security Class Initialized
DEBUG - 2016-09-10 05:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 05:13:36 --> Input Class Initialized
INFO - 2016-09-10 05:13:36 --> Language Class Initialized
INFO - 2016-09-10 05:13:36 --> Language Class Initialized
INFO - 2016-09-10 05:13:36 --> Config Class Initialized
INFO - 2016-09-10 05:13:36 --> Loader Class Initialized
INFO - 2016-09-10 05:13:36 --> Helper loaded: url_helper
INFO - 2016-09-10 05:13:36 --> Database Driver Class Initialized
INFO - 2016-09-10 05:13:36 --> Controller Class Initialized
DEBUG - 2016-09-10 05:13:36 --> Index MX_Controller Initialized
INFO - 2016-09-10 05:13:36 --> Model Class Initialized
INFO - 2016-09-10 05:13:36 --> Model Class Initialized
DEBUG - 2016-09-10 05:13:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-10 05:13:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-10 05:13:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-10 05:13:36 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-10 05:13:36 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-10 05:13:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-10 05:13:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-10 05:13:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-10 05:13:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-10 05:13:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-10 05:13:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-10 05:13:36 --> Final output sent to browser
DEBUG - 2016-09-10 05:13:36 --> Total execution time: 1.0307
INFO - 2016-09-10 05:16:44 --> Config Class Initialized
INFO - 2016-09-10 05:16:44 --> Hooks Class Initialized
DEBUG - 2016-09-10 05:16:44 --> UTF-8 Support Enabled
INFO - 2016-09-10 05:16:44 --> Utf8 Class Initialized
INFO - 2016-09-10 05:16:44 --> URI Class Initialized
INFO - 2016-09-10 05:16:44 --> Router Class Initialized
INFO - 2016-09-10 05:16:44 --> Output Class Initialized
INFO - 2016-09-10 05:16:44 --> Security Class Initialized
DEBUG - 2016-09-10 05:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 05:16:44 --> Input Class Initialized
INFO - 2016-09-10 05:16:44 --> Language Class Initialized
INFO - 2016-09-10 05:16:45 --> Language Class Initialized
INFO - 2016-09-10 05:16:45 --> Config Class Initialized
INFO - 2016-09-10 05:16:45 --> Loader Class Initialized
INFO - 2016-09-10 05:16:45 --> Helper loaded: url_helper
INFO - 2016-09-10 05:16:45 --> Database Driver Class Initialized
INFO - 2016-09-10 05:16:45 --> Controller Class Initialized
DEBUG - 2016-09-10 05:16:45 --> Index MX_Controller Initialized
INFO - 2016-09-10 05:16:45 --> Model Class Initialized
INFO - 2016-09-10 05:16:45 --> Model Class Initialized
DEBUG - 2016-09-10 05:16:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-10 05:16:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-10 05:16:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-10 05:16:45 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-10 05:16:45 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-10 05:16:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-10 05:16:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-10 05:16:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-10 05:16:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-10 05:16:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-10 05:16:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-10 05:16:45 --> Final output sent to browser
DEBUG - 2016-09-10 05:16:45 --> Total execution time: 0.6210
INFO - 2016-09-10 05:17:38 --> Config Class Initialized
INFO - 2016-09-10 05:17:38 --> Hooks Class Initialized
DEBUG - 2016-09-10 05:17:38 --> UTF-8 Support Enabled
INFO - 2016-09-10 05:17:38 --> Utf8 Class Initialized
INFO - 2016-09-10 05:17:38 --> URI Class Initialized
INFO - 2016-09-10 05:17:38 --> Router Class Initialized
INFO - 2016-09-10 05:17:38 --> Output Class Initialized
INFO - 2016-09-10 05:17:38 --> Security Class Initialized
DEBUG - 2016-09-10 05:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 05:17:38 --> Input Class Initialized
INFO - 2016-09-10 05:17:38 --> Language Class Initialized
INFO - 2016-09-10 05:17:38 --> Language Class Initialized
INFO - 2016-09-10 05:17:38 --> Config Class Initialized
INFO - 2016-09-10 05:17:38 --> Loader Class Initialized
INFO - 2016-09-10 05:17:38 --> Helper loaded: url_helper
INFO - 2016-09-10 05:17:38 --> Database Driver Class Initialized
INFO - 2016-09-10 05:17:38 --> Controller Class Initialized
DEBUG - 2016-09-10 05:17:38 --> Index MX_Controller Initialized
INFO - 2016-09-10 05:17:38 --> Model Class Initialized
INFO - 2016-09-10 05:17:38 --> Model Class Initialized
DEBUG - 2016-09-10 05:17:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-10 05:17:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-10 05:17:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-10 05:17:38 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-10 05:17:39 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-10 05:17:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-10 05:17:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-10 05:17:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-10 05:17:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-10 05:17:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-10 05:17:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-10 05:17:39 --> Final output sent to browser
DEBUG - 2016-09-10 05:17:39 --> Total execution time: 0.6028
INFO - 2016-09-10 05:17:54 --> Config Class Initialized
INFO - 2016-09-10 05:17:54 --> Hooks Class Initialized
DEBUG - 2016-09-10 05:17:54 --> UTF-8 Support Enabled
INFO - 2016-09-10 05:17:54 --> Utf8 Class Initialized
INFO - 2016-09-10 05:17:54 --> URI Class Initialized
INFO - 2016-09-10 05:17:54 --> Router Class Initialized
INFO - 2016-09-10 05:17:54 --> Output Class Initialized
INFO - 2016-09-10 05:17:55 --> Security Class Initialized
DEBUG - 2016-09-10 05:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 05:17:55 --> Input Class Initialized
INFO - 2016-09-10 05:17:55 --> Language Class Initialized
INFO - 2016-09-10 05:17:55 --> Language Class Initialized
INFO - 2016-09-10 05:17:55 --> Config Class Initialized
INFO - 2016-09-10 05:17:55 --> Loader Class Initialized
INFO - 2016-09-10 05:17:55 --> Helper loaded: url_helper
INFO - 2016-09-10 05:17:55 --> Database Driver Class Initialized
INFO - 2016-09-10 05:17:55 --> Controller Class Initialized
DEBUG - 2016-09-10 05:17:55 --> Index MX_Controller Initialized
INFO - 2016-09-10 05:17:55 --> Model Class Initialized
INFO - 2016-09-10 05:17:55 --> Model Class Initialized
DEBUG - 2016-09-10 05:17:55 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 05:17:55 --> Final output sent to browser
DEBUG - 2016-09-10 05:17:55 --> Total execution time: 0.4501
INFO - 2016-09-10 05:18:19 --> Config Class Initialized
INFO - 2016-09-10 05:18:19 --> Hooks Class Initialized
DEBUG - 2016-09-10 05:18:19 --> UTF-8 Support Enabled
INFO - 2016-09-10 05:18:19 --> Utf8 Class Initialized
INFO - 2016-09-10 05:18:19 --> URI Class Initialized
INFO - 2016-09-10 05:18:19 --> Router Class Initialized
INFO - 2016-09-10 05:18:19 --> Output Class Initialized
INFO - 2016-09-10 05:18:19 --> Security Class Initialized
DEBUG - 2016-09-10 05:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 05:18:19 --> Input Class Initialized
INFO - 2016-09-10 05:18:19 --> Language Class Initialized
INFO - 2016-09-10 05:18:19 --> Language Class Initialized
INFO - 2016-09-10 05:18:19 --> Config Class Initialized
INFO - 2016-09-10 05:18:19 --> Loader Class Initialized
INFO - 2016-09-10 05:18:19 --> Helper loaded: url_helper
INFO - 2016-09-10 05:18:19 --> Database Driver Class Initialized
INFO - 2016-09-10 05:18:19 --> Controller Class Initialized
DEBUG - 2016-09-10 05:18:19 --> Index MX_Controller Initialized
INFO - 2016-09-10 05:18:19 --> Model Class Initialized
INFO - 2016-09-10 05:18:19 --> Model Class Initialized
DEBUG - 2016-09-10 05:18:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-10 05:18:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-10 05:18:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-10 05:18:19 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-10 05:18:19 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-10 05:18:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-10 05:18:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-10 05:18:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-10 05:18:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-10 05:18:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-10 05:18:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-10 05:18:19 --> Final output sent to browser
DEBUG - 2016-09-10 05:18:19 --> Total execution time: 0.6413
INFO - 2016-09-10 05:18:36 --> Config Class Initialized
INFO - 2016-09-10 05:18:36 --> Hooks Class Initialized
DEBUG - 2016-09-10 05:18:36 --> UTF-8 Support Enabled
INFO - 2016-09-10 05:18:37 --> Utf8 Class Initialized
INFO - 2016-09-10 05:18:37 --> URI Class Initialized
INFO - 2016-09-10 05:18:37 --> Router Class Initialized
INFO - 2016-09-10 05:18:37 --> Output Class Initialized
INFO - 2016-09-10 05:18:37 --> Security Class Initialized
DEBUG - 2016-09-10 05:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 05:18:37 --> Input Class Initialized
INFO - 2016-09-10 05:18:37 --> Language Class Initialized
INFO - 2016-09-10 05:18:37 --> Language Class Initialized
INFO - 2016-09-10 05:18:37 --> Config Class Initialized
INFO - 2016-09-10 05:18:37 --> Loader Class Initialized
INFO - 2016-09-10 05:18:37 --> Helper loaded: url_helper
INFO - 2016-09-10 05:18:37 --> Database Driver Class Initialized
INFO - 2016-09-10 05:18:37 --> Controller Class Initialized
DEBUG - 2016-09-10 05:18:37 --> Index MX_Controller Initialized
INFO - 2016-09-10 05:18:37 --> Model Class Initialized
INFO - 2016-09-10 05:18:37 --> Model Class Initialized
DEBUG - 2016-09-10 05:18:37 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 05:18:37 --> Final output sent to browser
DEBUG - 2016-09-10 05:18:37 --> Total execution time: 0.5038
INFO - 2016-09-10 05:19:04 --> Config Class Initialized
INFO - 2016-09-10 05:19:04 --> Hooks Class Initialized
DEBUG - 2016-09-10 05:19:04 --> UTF-8 Support Enabled
INFO - 2016-09-10 05:19:04 --> Utf8 Class Initialized
INFO - 2016-09-10 05:19:04 --> URI Class Initialized
INFO - 2016-09-10 05:19:04 --> Router Class Initialized
INFO - 2016-09-10 05:19:04 --> Output Class Initialized
INFO - 2016-09-10 05:19:04 --> Security Class Initialized
DEBUG - 2016-09-10 05:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 05:19:04 --> Input Class Initialized
INFO - 2016-09-10 05:19:04 --> Language Class Initialized
INFO - 2016-09-10 05:19:05 --> Language Class Initialized
INFO - 2016-09-10 05:19:05 --> Config Class Initialized
INFO - 2016-09-10 05:19:05 --> Loader Class Initialized
INFO - 2016-09-10 05:19:05 --> Helper loaded: url_helper
INFO - 2016-09-10 05:19:05 --> Database Driver Class Initialized
INFO - 2016-09-10 05:19:05 --> Controller Class Initialized
DEBUG - 2016-09-10 05:19:05 --> Index MX_Controller Initialized
INFO - 2016-09-10 05:19:05 --> Model Class Initialized
INFO - 2016-09-10 05:19:05 --> Model Class Initialized
DEBUG - 2016-09-10 05:19:05 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 05:19:05 --> Final output sent to browser
DEBUG - 2016-09-10 05:19:05 --> Total execution time: 0.5095
INFO - 2016-09-10 17:33:54 --> Config Class Initialized
INFO - 2016-09-10 17:33:54 --> Hooks Class Initialized
DEBUG - 2016-09-10 17:33:54 --> UTF-8 Support Enabled
INFO - 2016-09-10 17:33:54 --> Utf8 Class Initialized
INFO - 2016-09-10 17:33:54 --> URI Class Initialized
INFO - 2016-09-10 17:33:54 --> Router Class Initialized
INFO - 2016-09-10 17:33:54 --> Output Class Initialized
INFO - 2016-09-10 17:33:54 --> Security Class Initialized
DEBUG - 2016-09-10 17:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 17:33:54 --> Input Class Initialized
INFO - 2016-09-10 17:33:54 --> Language Class Initialized
INFO - 2016-09-10 17:33:55 --> Language Class Initialized
INFO - 2016-09-10 17:33:55 --> Config Class Initialized
INFO - 2016-09-10 17:33:55 --> Loader Class Initialized
INFO - 2016-09-10 17:33:55 --> Helper loaded: url_helper
INFO - 2016-09-10 17:33:55 --> Database Driver Class Initialized
INFO - 2016-09-10 17:33:55 --> Controller Class Initialized
DEBUG - 2016-09-10 17:33:55 --> Index MX_Controller Initialized
INFO - 2016-09-10 17:33:55 --> Model Class Initialized
INFO - 2016-09-10 17:33:55 --> Model Class Initialized
DEBUG - 2016-09-10 17:33:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-10 17:33:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-10 17:33:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-10 17:33:55 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-10 17:33:55 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-10 17:33:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-10 17:33:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-10 17:33:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-10 17:33:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-10 17:33:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-10 17:33:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-10 17:33:55 --> Final output sent to browser
DEBUG - 2016-09-10 17:33:56 --> Total execution time: 1.3376
INFO - 2016-09-10 17:37:02 --> Config Class Initialized
INFO - 2016-09-10 17:37:02 --> Hooks Class Initialized
DEBUG - 2016-09-10 17:37:02 --> UTF-8 Support Enabled
INFO - 2016-09-10 17:37:02 --> Utf8 Class Initialized
INFO - 2016-09-10 17:37:02 --> URI Class Initialized
INFO - 2016-09-10 17:37:02 --> Router Class Initialized
INFO - 2016-09-10 17:37:02 --> Output Class Initialized
INFO - 2016-09-10 17:37:02 --> Security Class Initialized
DEBUG - 2016-09-10 17:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 17:37:02 --> Input Class Initialized
INFO - 2016-09-10 17:37:02 --> Language Class Initialized
INFO - 2016-09-10 17:37:02 --> Language Class Initialized
INFO - 2016-09-10 17:37:02 --> Config Class Initialized
INFO - 2016-09-10 17:37:02 --> Loader Class Initialized
INFO - 2016-09-10 17:37:02 --> Helper loaded: url_helper
INFO - 2016-09-10 17:37:02 --> Database Driver Class Initialized
INFO - 2016-09-10 17:37:02 --> Controller Class Initialized
DEBUG - 2016-09-10 17:37:02 --> Index MX_Controller Initialized
INFO - 2016-09-10 17:37:02 --> Model Class Initialized
INFO - 2016-09-10 17:37:02 --> Model Class Initialized
DEBUG - 2016-09-10 17:37:02 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 17:37:02 --> Final output sent to browser
DEBUG - 2016-09-10 17:37:02 --> Total execution time: 0.5349
INFO - 2016-09-10 17:37:36 --> Config Class Initialized
INFO - 2016-09-10 17:37:36 --> Hooks Class Initialized
DEBUG - 2016-09-10 17:37:36 --> UTF-8 Support Enabled
INFO - 2016-09-10 17:37:36 --> Utf8 Class Initialized
INFO - 2016-09-10 17:37:36 --> URI Class Initialized
INFO - 2016-09-10 17:37:36 --> Router Class Initialized
INFO - 2016-09-10 17:37:36 --> Output Class Initialized
INFO - 2016-09-10 17:37:36 --> Security Class Initialized
DEBUG - 2016-09-10 17:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 17:37:36 --> Input Class Initialized
INFO - 2016-09-10 17:37:36 --> Language Class Initialized
INFO - 2016-09-10 17:37:36 --> Language Class Initialized
INFO - 2016-09-10 17:37:36 --> Config Class Initialized
INFO - 2016-09-10 17:37:36 --> Loader Class Initialized
INFO - 2016-09-10 17:37:37 --> Helper loaded: url_helper
INFO - 2016-09-10 17:37:37 --> Database Driver Class Initialized
INFO - 2016-09-10 17:37:37 --> Controller Class Initialized
DEBUG - 2016-09-10 17:37:37 --> Index MX_Controller Initialized
INFO - 2016-09-10 17:37:37 --> Model Class Initialized
INFO - 2016-09-10 17:37:37 --> Model Class Initialized
DEBUG - 2016-09-10 17:37:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-10 17:37:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-10 17:37:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-10 17:37:37 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-10 17:37:37 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-10 17:37:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-10 17:37:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-10 17:37:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-10 17:37:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-10 17:37:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-10 17:37:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-10 17:37:37 --> Final output sent to browser
DEBUG - 2016-09-10 17:37:37 --> Total execution time: 0.6801
INFO - 2016-09-10 17:37:48 --> Config Class Initialized
INFO - 2016-09-10 17:37:48 --> Hooks Class Initialized
DEBUG - 2016-09-10 17:37:48 --> UTF-8 Support Enabled
INFO - 2016-09-10 17:37:48 --> Utf8 Class Initialized
INFO - 2016-09-10 17:37:48 --> URI Class Initialized
INFO - 2016-09-10 17:37:48 --> Router Class Initialized
INFO - 2016-09-10 17:37:48 --> Output Class Initialized
INFO - 2016-09-10 17:37:48 --> Security Class Initialized
DEBUG - 2016-09-10 17:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 17:37:48 --> Input Class Initialized
INFO - 2016-09-10 17:37:48 --> Language Class Initialized
INFO - 2016-09-10 17:37:48 --> Language Class Initialized
INFO - 2016-09-10 17:37:48 --> Config Class Initialized
INFO - 2016-09-10 17:37:48 --> Loader Class Initialized
INFO - 2016-09-10 17:37:48 --> Helper loaded: url_helper
INFO - 2016-09-10 17:37:48 --> Database Driver Class Initialized
INFO - 2016-09-10 17:37:48 --> Controller Class Initialized
DEBUG - 2016-09-10 17:37:48 --> Index MX_Controller Initialized
INFO - 2016-09-10 17:37:48 --> Model Class Initialized
INFO - 2016-09-10 17:37:48 --> Model Class Initialized
DEBUG - 2016-09-10 17:37:48 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 17:37:48 --> Final output sent to browser
DEBUG - 2016-09-10 17:37:48 --> Total execution time: 0.4456
INFO - 2016-09-10 17:44:40 --> Config Class Initialized
INFO - 2016-09-10 17:44:41 --> Hooks Class Initialized
DEBUG - 2016-09-10 17:44:41 --> UTF-8 Support Enabled
INFO - 2016-09-10 17:44:41 --> Utf8 Class Initialized
INFO - 2016-09-10 17:44:41 --> URI Class Initialized
INFO - 2016-09-10 17:44:41 --> Router Class Initialized
INFO - 2016-09-10 17:44:41 --> Output Class Initialized
INFO - 2016-09-10 17:44:41 --> Security Class Initialized
DEBUG - 2016-09-10 17:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 17:44:41 --> Input Class Initialized
INFO - 2016-09-10 17:44:41 --> Language Class Initialized
INFO - 2016-09-10 17:44:41 --> Language Class Initialized
INFO - 2016-09-10 17:44:41 --> Config Class Initialized
INFO - 2016-09-10 17:44:41 --> Loader Class Initialized
INFO - 2016-09-10 17:44:41 --> Helper loaded: url_helper
INFO - 2016-09-10 17:44:42 --> Database Driver Class Initialized
INFO - 2016-09-10 17:44:42 --> Controller Class Initialized
DEBUG - 2016-09-10 17:44:42 --> Index MX_Controller Initialized
INFO - 2016-09-10 17:44:42 --> Model Class Initialized
INFO - 2016-09-10 17:44:42 --> Model Class Initialized
DEBUG - 2016-09-10 17:44:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-10 17:44:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-10 17:44:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-10 17:44:42 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-10 17:44:42 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-10 17:44:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-10 17:44:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-10 17:44:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-10 17:44:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-10 17:44:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-10 17:44:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-10 17:44:42 --> Final output sent to browser
DEBUG - 2016-09-10 17:44:42 --> Total execution time: 1.8388
INFO - 2016-09-10 17:49:11 --> Config Class Initialized
INFO - 2016-09-10 17:49:11 --> Hooks Class Initialized
DEBUG - 2016-09-10 17:49:11 --> UTF-8 Support Enabled
INFO - 2016-09-10 17:49:11 --> Utf8 Class Initialized
INFO - 2016-09-10 17:49:11 --> URI Class Initialized
INFO - 2016-09-10 17:49:11 --> Router Class Initialized
INFO - 2016-09-10 17:49:11 --> Output Class Initialized
INFO - 2016-09-10 17:49:11 --> Security Class Initialized
DEBUG - 2016-09-10 17:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 17:49:11 --> Input Class Initialized
INFO - 2016-09-10 17:49:11 --> Language Class Initialized
INFO - 2016-09-10 17:49:11 --> Language Class Initialized
INFO - 2016-09-10 17:49:11 --> Config Class Initialized
INFO - 2016-09-10 17:49:11 --> Loader Class Initialized
INFO - 2016-09-10 17:49:11 --> Helper loaded: url_helper
INFO - 2016-09-10 17:49:11 --> Database Driver Class Initialized
INFO - 2016-09-10 17:49:11 --> Controller Class Initialized
DEBUG - 2016-09-10 17:49:11 --> Index MX_Controller Initialized
INFO - 2016-09-10 17:49:11 --> Model Class Initialized
INFO - 2016-09-10 17:49:11 --> Model Class Initialized
DEBUG - 2016-09-10 17:49:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-10 17:49:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-10 17:49:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-10 17:49:11 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-10 17:49:11 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-10 17:49:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-10 17:49:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-10 17:49:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-10 17:49:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-10 17:49:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-10 17:49:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-10 17:49:11 --> Final output sent to browser
DEBUG - 2016-09-10 17:49:11 --> Total execution time: 0.6785
INFO - 2016-09-10 17:49:15 --> Config Class Initialized
INFO - 2016-09-10 17:49:15 --> Hooks Class Initialized
DEBUG - 2016-09-10 17:49:15 --> UTF-8 Support Enabled
INFO - 2016-09-10 17:49:15 --> Utf8 Class Initialized
INFO - 2016-09-10 17:49:15 --> URI Class Initialized
INFO - 2016-09-10 17:49:15 --> Router Class Initialized
INFO - 2016-09-10 17:49:16 --> Output Class Initialized
INFO - 2016-09-10 17:49:16 --> Security Class Initialized
DEBUG - 2016-09-10 17:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 17:49:16 --> Input Class Initialized
INFO - 2016-09-10 17:49:16 --> Language Class Initialized
INFO - 2016-09-10 17:49:16 --> Language Class Initialized
INFO - 2016-09-10 17:49:16 --> Config Class Initialized
INFO - 2016-09-10 17:49:16 --> Loader Class Initialized
INFO - 2016-09-10 17:49:16 --> Helper loaded: url_helper
INFO - 2016-09-10 17:49:16 --> Database Driver Class Initialized
INFO - 2016-09-10 17:49:16 --> Controller Class Initialized
DEBUG - 2016-09-10 17:49:16 --> Index MX_Controller Initialized
INFO - 2016-09-10 17:49:16 --> Model Class Initialized
INFO - 2016-09-10 17:49:16 --> Model Class Initialized
DEBUG - 2016-09-10 17:49:16 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 17:49:17 --> Final output sent to browser
DEBUG - 2016-09-10 17:49:17 --> Total execution time: 1.1652
INFO - 2016-09-10 17:50:03 --> Config Class Initialized
INFO - 2016-09-10 17:50:03 --> Hooks Class Initialized
DEBUG - 2016-09-10 17:50:03 --> UTF-8 Support Enabled
INFO - 2016-09-10 17:50:03 --> Utf8 Class Initialized
INFO - 2016-09-10 17:50:03 --> URI Class Initialized
INFO - 2016-09-10 17:50:03 --> Router Class Initialized
INFO - 2016-09-10 17:50:03 --> Output Class Initialized
INFO - 2016-09-10 17:50:03 --> Security Class Initialized
DEBUG - 2016-09-10 17:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 17:50:03 --> Input Class Initialized
INFO - 2016-09-10 17:50:03 --> Language Class Initialized
INFO - 2016-09-10 17:50:03 --> Language Class Initialized
INFO - 2016-09-10 17:50:03 --> Config Class Initialized
INFO - 2016-09-10 17:50:03 --> Loader Class Initialized
INFO - 2016-09-10 17:50:03 --> Helper loaded: url_helper
INFO - 2016-09-10 17:50:03 --> Database Driver Class Initialized
INFO - 2016-09-10 17:50:03 --> Controller Class Initialized
DEBUG - 2016-09-10 17:50:03 --> Index MX_Controller Initialized
INFO - 2016-09-10 17:50:03 --> Model Class Initialized
INFO - 2016-09-10 17:50:03 --> Model Class Initialized
DEBUG - 2016-09-10 17:50:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-10 17:50:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-10 17:50:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-10 17:50:03 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-10 17:50:03 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-10 17:50:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-10 17:50:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-10 17:50:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-10 17:50:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-10 17:50:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-10 17:50:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-10 17:50:04 --> Final output sent to browser
DEBUG - 2016-09-10 17:50:04 --> Total execution time: 0.6509
INFO - 2016-09-10 17:50:38 --> Config Class Initialized
INFO - 2016-09-10 17:50:38 --> Hooks Class Initialized
DEBUG - 2016-09-10 17:50:38 --> UTF-8 Support Enabled
INFO - 2016-09-10 17:50:38 --> Utf8 Class Initialized
INFO - 2016-09-10 17:50:38 --> URI Class Initialized
INFO - 2016-09-10 17:50:38 --> Router Class Initialized
INFO - 2016-09-10 17:50:38 --> Output Class Initialized
INFO - 2016-09-10 17:50:38 --> Security Class Initialized
DEBUG - 2016-09-10 17:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 17:50:38 --> Input Class Initialized
INFO - 2016-09-10 17:50:38 --> Language Class Initialized
INFO - 2016-09-10 17:50:38 --> Language Class Initialized
INFO - 2016-09-10 17:50:38 --> Config Class Initialized
INFO - 2016-09-10 17:50:38 --> Loader Class Initialized
INFO - 2016-09-10 17:50:38 --> Helper loaded: url_helper
INFO - 2016-09-10 17:50:38 --> Database Driver Class Initialized
INFO - 2016-09-10 17:50:38 --> Controller Class Initialized
DEBUG - 2016-09-10 17:50:38 --> Index MX_Controller Initialized
INFO - 2016-09-10 17:50:38 --> Model Class Initialized
INFO - 2016-09-10 17:50:38 --> Model Class Initialized
DEBUG - 2016-09-10 17:50:38 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 17:50:38 --> Final output sent to browser
DEBUG - 2016-09-10 17:50:38 --> Total execution time: 0.6267
INFO - 2016-09-10 17:51:47 --> Config Class Initialized
INFO - 2016-09-10 17:51:47 --> Hooks Class Initialized
DEBUG - 2016-09-10 17:51:47 --> UTF-8 Support Enabled
INFO - 2016-09-10 17:51:47 --> Utf8 Class Initialized
INFO - 2016-09-10 17:51:47 --> URI Class Initialized
INFO - 2016-09-10 17:51:47 --> Router Class Initialized
INFO - 2016-09-10 17:51:47 --> Output Class Initialized
INFO - 2016-09-10 17:51:47 --> Security Class Initialized
DEBUG - 2016-09-10 17:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 17:51:47 --> Input Class Initialized
INFO - 2016-09-10 17:51:47 --> Language Class Initialized
INFO - 2016-09-10 17:51:47 --> Language Class Initialized
INFO - 2016-09-10 17:51:47 --> Config Class Initialized
INFO - 2016-09-10 17:51:47 --> Loader Class Initialized
INFO - 2016-09-10 17:51:47 --> Helper loaded: url_helper
INFO - 2016-09-10 17:51:47 --> Database Driver Class Initialized
INFO - 2016-09-10 17:51:47 --> Controller Class Initialized
DEBUG - 2016-09-10 17:51:47 --> Index MX_Controller Initialized
INFO - 2016-09-10 17:51:48 --> Model Class Initialized
INFO - 2016-09-10 17:51:48 --> Model Class Initialized
DEBUG - 2016-09-10 17:51:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-10 17:51:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-10 17:51:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-10 17:51:48 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-10 17:51:48 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-10 17:51:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-10 17:51:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-10 17:51:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-10 17:51:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-10 17:51:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-10 17:51:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-10 17:51:48 --> Final output sent to browser
DEBUG - 2016-09-10 17:51:48 --> Total execution time: 0.6894
INFO - 2016-09-10 17:52:08 --> Config Class Initialized
INFO - 2016-09-10 17:52:08 --> Hooks Class Initialized
DEBUG - 2016-09-10 17:52:08 --> UTF-8 Support Enabled
INFO - 2016-09-10 17:52:08 --> Utf8 Class Initialized
INFO - 2016-09-10 17:52:08 --> URI Class Initialized
INFO - 2016-09-10 17:52:08 --> Router Class Initialized
INFO - 2016-09-10 17:52:08 --> Output Class Initialized
INFO - 2016-09-10 17:52:08 --> Security Class Initialized
DEBUG - 2016-09-10 17:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 17:52:09 --> Input Class Initialized
INFO - 2016-09-10 17:52:09 --> Language Class Initialized
INFO - 2016-09-10 17:52:09 --> Language Class Initialized
INFO - 2016-09-10 17:52:09 --> Config Class Initialized
INFO - 2016-09-10 17:52:09 --> Loader Class Initialized
INFO - 2016-09-10 17:52:09 --> Helper loaded: url_helper
INFO - 2016-09-10 17:52:09 --> Database Driver Class Initialized
INFO - 2016-09-10 17:52:09 --> Controller Class Initialized
DEBUG - 2016-09-10 17:52:09 --> Index MX_Controller Initialized
INFO - 2016-09-10 17:52:09 --> Model Class Initialized
INFO - 2016-09-10 17:52:09 --> Model Class Initialized
DEBUG - 2016-09-10 17:52:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-10 17:52:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-10 17:52:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-10 17:52:09 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-10 17:52:09 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-10 17:52:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-10 17:52:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-10 17:52:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-10 17:52:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-10 17:52:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-10 17:52:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-10 17:52:09 --> Final output sent to browser
DEBUG - 2016-09-10 17:52:09 --> Total execution time: 0.6779
INFO - 2016-09-10 17:52:14 --> Config Class Initialized
INFO - 2016-09-10 17:52:14 --> Hooks Class Initialized
DEBUG - 2016-09-10 17:52:14 --> UTF-8 Support Enabled
INFO - 2016-09-10 17:52:14 --> Utf8 Class Initialized
INFO - 2016-09-10 17:52:14 --> URI Class Initialized
INFO - 2016-09-10 17:52:14 --> Router Class Initialized
INFO - 2016-09-10 17:52:14 --> Output Class Initialized
INFO - 2016-09-10 17:52:14 --> Security Class Initialized
DEBUG - 2016-09-10 17:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 17:52:14 --> Input Class Initialized
INFO - 2016-09-10 17:52:14 --> Language Class Initialized
INFO - 2016-09-10 17:52:14 --> Language Class Initialized
INFO - 2016-09-10 17:52:14 --> Config Class Initialized
INFO - 2016-09-10 17:52:14 --> Loader Class Initialized
INFO - 2016-09-10 17:52:14 --> Helper loaded: url_helper
INFO - 2016-09-10 17:52:15 --> Database Driver Class Initialized
INFO - 2016-09-10 17:52:15 --> Controller Class Initialized
DEBUG - 2016-09-10 17:52:15 --> Index MX_Controller Initialized
INFO - 2016-09-10 17:52:15 --> Model Class Initialized
INFO - 2016-09-10 17:52:15 --> Model Class Initialized
DEBUG - 2016-09-10 17:52:15 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 17:52:15 --> Final output sent to browser
DEBUG - 2016-09-10 17:52:15 --> Total execution time: 0.6204
INFO - 2016-09-10 17:54:45 --> Config Class Initialized
INFO - 2016-09-10 17:54:45 --> Hooks Class Initialized
DEBUG - 2016-09-10 17:54:45 --> UTF-8 Support Enabled
INFO - 2016-09-10 17:54:45 --> Utf8 Class Initialized
INFO - 2016-09-10 17:54:45 --> URI Class Initialized
INFO - 2016-09-10 17:54:45 --> Router Class Initialized
INFO - 2016-09-10 17:54:45 --> Output Class Initialized
INFO - 2016-09-10 17:54:45 --> Security Class Initialized
DEBUG - 2016-09-10 17:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 17:54:45 --> Input Class Initialized
INFO - 2016-09-10 17:54:45 --> Language Class Initialized
INFO - 2016-09-10 17:54:45 --> Language Class Initialized
INFO - 2016-09-10 17:54:45 --> Config Class Initialized
INFO - 2016-09-10 17:54:45 --> Loader Class Initialized
INFO - 2016-09-10 17:54:45 --> Helper loaded: url_helper
INFO - 2016-09-10 17:54:45 --> Database Driver Class Initialized
INFO - 2016-09-10 17:54:46 --> Controller Class Initialized
DEBUG - 2016-09-10 17:54:46 --> Index MX_Controller Initialized
INFO - 2016-09-10 17:54:46 --> Model Class Initialized
INFO - 2016-09-10 17:54:46 --> Model Class Initialized
DEBUG - 2016-09-10 17:54:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-10 17:54:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-10 17:54:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-10 17:54:46 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-10 17:54:46 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-10 17:54:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-10 17:54:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-10 17:54:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-10 17:54:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-10 17:54:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-10 17:54:46 --> Final output sent to browser
DEBUG - 2016-09-10 17:54:46 --> Total execution time: 0.6426
INFO - 2016-09-10 17:54:52 --> Config Class Initialized
INFO - 2016-09-10 17:54:52 --> Hooks Class Initialized
DEBUG - 2016-09-10 17:54:52 --> UTF-8 Support Enabled
INFO - 2016-09-10 17:54:52 --> Utf8 Class Initialized
INFO - 2016-09-10 17:54:52 --> URI Class Initialized
INFO - 2016-09-10 17:54:52 --> Router Class Initialized
INFO - 2016-09-10 17:54:52 --> Output Class Initialized
INFO - 2016-09-10 17:54:52 --> Security Class Initialized
DEBUG - 2016-09-10 17:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 17:54:52 --> Input Class Initialized
INFO - 2016-09-10 17:54:52 --> Language Class Initialized
INFO - 2016-09-10 17:54:52 --> Language Class Initialized
INFO - 2016-09-10 17:54:52 --> Config Class Initialized
INFO - 2016-09-10 17:54:52 --> Loader Class Initialized
INFO - 2016-09-10 17:54:52 --> Helper loaded: url_helper
INFO - 2016-09-10 17:54:52 --> Database Driver Class Initialized
INFO - 2016-09-10 17:54:52 --> Controller Class Initialized
DEBUG - 2016-09-10 17:54:52 --> Index MX_Controller Initialized
INFO - 2016-09-10 17:54:52 --> Model Class Initialized
INFO - 2016-09-10 17:54:52 --> Model Class Initialized
DEBUG - 2016-09-10 17:54:52 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 17:54:52 --> Final output sent to browser
DEBUG - 2016-09-10 17:54:52 --> Total execution time: 0.6139
INFO - 2016-09-10 17:55:17 --> Config Class Initialized
INFO - 2016-09-10 17:55:17 --> Hooks Class Initialized
DEBUG - 2016-09-10 17:55:17 --> UTF-8 Support Enabled
INFO - 2016-09-10 17:55:17 --> Utf8 Class Initialized
INFO - 2016-09-10 17:55:17 --> URI Class Initialized
INFO - 2016-09-10 17:55:17 --> Router Class Initialized
INFO - 2016-09-10 17:55:17 --> Output Class Initialized
INFO - 2016-09-10 17:55:17 --> Security Class Initialized
DEBUG - 2016-09-10 17:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 17:55:17 --> Input Class Initialized
INFO - 2016-09-10 17:55:17 --> Language Class Initialized
INFO - 2016-09-10 17:55:17 --> Language Class Initialized
INFO - 2016-09-10 17:55:17 --> Config Class Initialized
INFO - 2016-09-10 17:55:17 --> Loader Class Initialized
INFO - 2016-09-10 17:55:17 --> Helper loaded: url_helper
INFO - 2016-09-10 17:55:17 --> Database Driver Class Initialized
INFO - 2016-09-10 17:55:17 --> Controller Class Initialized
DEBUG - 2016-09-10 17:55:17 --> Index MX_Controller Initialized
INFO - 2016-09-10 17:55:17 --> Model Class Initialized
INFO - 2016-09-10 17:55:17 --> Model Class Initialized
DEBUG - 2016-09-10 17:55:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-10 17:55:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-10 17:55:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-10 17:55:17 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-10 17:55:17 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-10 17:55:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-10 17:55:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-10 17:55:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-10 17:55:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-10 17:55:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-10 17:55:18 --> Final output sent to browser
DEBUG - 2016-09-10 17:55:18 --> Total execution time: 0.6755
INFO - 2016-09-10 17:55:22 --> Config Class Initialized
INFO - 2016-09-10 17:55:22 --> Hooks Class Initialized
DEBUG - 2016-09-10 17:55:22 --> UTF-8 Support Enabled
INFO - 2016-09-10 17:55:22 --> Utf8 Class Initialized
INFO - 2016-09-10 17:55:22 --> URI Class Initialized
INFO - 2016-09-10 17:55:22 --> Router Class Initialized
INFO - 2016-09-10 17:55:22 --> Output Class Initialized
INFO - 2016-09-10 17:55:22 --> Security Class Initialized
DEBUG - 2016-09-10 17:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 17:55:23 --> Input Class Initialized
INFO - 2016-09-10 17:55:23 --> Language Class Initialized
INFO - 2016-09-10 17:55:23 --> Language Class Initialized
INFO - 2016-09-10 17:55:23 --> Config Class Initialized
INFO - 2016-09-10 17:55:23 --> Loader Class Initialized
INFO - 2016-09-10 17:55:23 --> Helper loaded: url_helper
INFO - 2016-09-10 17:55:23 --> Database Driver Class Initialized
INFO - 2016-09-10 17:55:23 --> Controller Class Initialized
DEBUG - 2016-09-10 17:55:23 --> Index MX_Controller Initialized
INFO - 2016-09-10 17:55:23 --> Model Class Initialized
INFO - 2016-09-10 17:55:23 --> Model Class Initialized
DEBUG - 2016-09-10 17:55:23 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 17:55:23 --> Final output sent to browser
DEBUG - 2016-09-10 17:55:23 --> Total execution time: 0.8117
INFO - 2016-09-10 17:56:49 --> Config Class Initialized
INFO - 2016-09-10 17:56:49 --> Hooks Class Initialized
DEBUG - 2016-09-10 17:56:49 --> UTF-8 Support Enabled
INFO - 2016-09-10 17:56:49 --> Utf8 Class Initialized
INFO - 2016-09-10 17:56:49 --> URI Class Initialized
INFO - 2016-09-10 17:56:49 --> Router Class Initialized
INFO - 2016-09-10 17:56:49 --> Output Class Initialized
INFO - 2016-09-10 17:56:49 --> Security Class Initialized
DEBUG - 2016-09-10 17:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 17:56:49 --> Input Class Initialized
INFO - 2016-09-10 17:56:49 --> Language Class Initialized
INFO - 2016-09-10 17:56:49 --> Language Class Initialized
INFO - 2016-09-10 17:56:49 --> Config Class Initialized
INFO - 2016-09-10 17:56:49 --> Loader Class Initialized
INFO - 2016-09-10 17:56:49 --> Helper loaded: url_helper
INFO - 2016-09-10 17:56:49 --> Database Driver Class Initialized
INFO - 2016-09-10 17:56:49 --> Controller Class Initialized
DEBUG - 2016-09-10 17:56:49 --> Index MX_Controller Initialized
INFO - 2016-09-10 17:56:49 --> Model Class Initialized
INFO - 2016-09-10 17:56:49 --> Model Class Initialized
DEBUG - 2016-09-10 17:56:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-10 17:56:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-10 17:56:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-10 17:56:49 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-10 17:56:49 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-10 17:56:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-10 17:56:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-10 17:56:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-10 17:56:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-10 17:56:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-10 17:56:50 --> Final output sent to browser
DEBUG - 2016-09-10 17:56:50 --> Total execution time: 0.6382
INFO - 2016-09-10 17:56:55 --> Config Class Initialized
INFO - 2016-09-10 17:56:55 --> Hooks Class Initialized
DEBUG - 2016-09-10 17:56:55 --> UTF-8 Support Enabled
INFO - 2016-09-10 17:56:55 --> Utf8 Class Initialized
INFO - 2016-09-10 17:56:55 --> URI Class Initialized
INFO - 2016-09-10 17:56:55 --> Router Class Initialized
INFO - 2016-09-10 17:56:55 --> Output Class Initialized
INFO - 2016-09-10 17:56:55 --> Security Class Initialized
DEBUG - 2016-09-10 17:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 17:56:55 --> Input Class Initialized
INFO - 2016-09-10 17:56:55 --> Language Class Initialized
INFO - 2016-09-10 17:56:55 --> Language Class Initialized
INFO - 2016-09-10 17:56:55 --> Config Class Initialized
INFO - 2016-09-10 17:56:55 --> Loader Class Initialized
INFO - 2016-09-10 17:56:55 --> Helper loaded: url_helper
INFO - 2016-09-10 17:56:55 --> Database Driver Class Initialized
INFO - 2016-09-10 17:56:56 --> Controller Class Initialized
DEBUG - 2016-09-10 17:56:56 --> Index MX_Controller Initialized
INFO - 2016-09-10 17:56:56 --> Model Class Initialized
INFO - 2016-09-10 17:56:56 --> Model Class Initialized
DEBUG - 2016-09-10 17:56:56 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 17:56:56 --> Final output sent to browser
DEBUG - 2016-09-10 17:56:56 --> Total execution time: 0.6473
INFO - 2016-09-10 17:57:29 --> Config Class Initialized
INFO - 2016-09-10 17:57:29 --> Hooks Class Initialized
DEBUG - 2016-09-10 17:57:29 --> UTF-8 Support Enabled
INFO - 2016-09-10 17:57:29 --> Utf8 Class Initialized
INFO - 2016-09-10 17:57:29 --> URI Class Initialized
INFO - 2016-09-10 17:57:29 --> Router Class Initialized
INFO - 2016-09-10 17:57:29 --> Output Class Initialized
INFO - 2016-09-10 17:57:29 --> Security Class Initialized
DEBUG - 2016-09-10 17:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 17:57:29 --> Input Class Initialized
INFO - 2016-09-10 17:57:29 --> Language Class Initialized
INFO - 2016-09-10 17:57:29 --> Language Class Initialized
INFO - 2016-09-10 17:57:29 --> Config Class Initialized
INFO - 2016-09-10 17:57:29 --> Loader Class Initialized
INFO - 2016-09-10 17:57:29 --> Helper loaded: url_helper
INFO - 2016-09-10 17:57:29 --> Database Driver Class Initialized
INFO - 2016-09-10 17:57:29 --> Controller Class Initialized
DEBUG - 2016-09-10 17:57:29 --> Index MX_Controller Initialized
INFO - 2016-09-10 17:57:29 --> Model Class Initialized
INFO - 2016-09-10 17:57:29 --> Model Class Initialized
DEBUG - 2016-09-10 17:57:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-10 17:57:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-10 17:57:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-10 17:57:29 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-10 17:57:29 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-10 17:57:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-10 17:57:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-10 17:57:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-10 17:57:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-10 17:57:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-10 17:57:29 --> Final output sent to browser
DEBUG - 2016-09-10 17:57:29 --> Total execution time: 0.6599
INFO - 2016-09-10 17:57:33 --> Config Class Initialized
INFO - 2016-09-10 17:57:34 --> Hooks Class Initialized
DEBUG - 2016-09-10 17:57:34 --> UTF-8 Support Enabled
INFO - 2016-09-10 17:57:34 --> Utf8 Class Initialized
INFO - 2016-09-10 17:57:34 --> URI Class Initialized
INFO - 2016-09-10 17:57:34 --> Router Class Initialized
INFO - 2016-09-10 17:57:34 --> Output Class Initialized
INFO - 2016-09-10 17:57:34 --> Security Class Initialized
DEBUG - 2016-09-10 17:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 17:57:34 --> Input Class Initialized
INFO - 2016-09-10 17:57:34 --> Language Class Initialized
INFO - 2016-09-10 17:57:34 --> Language Class Initialized
INFO - 2016-09-10 17:57:34 --> Config Class Initialized
INFO - 2016-09-10 17:57:34 --> Loader Class Initialized
INFO - 2016-09-10 17:57:34 --> Helper loaded: url_helper
INFO - 2016-09-10 17:57:34 --> Database Driver Class Initialized
INFO - 2016-09-10 17:57:34 --> Controller Class Initialized
DEBUG - 2016-09-10 17:57:34 --> Index MX_Controller Initialized
INFO - 2016-09-10 17:57:34 --> Model Class Initialized
INFO - 2016-09-10 17:57:34 --> Model Class Initialized
DEBUG - 2016-09-10 17:57:34 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 17:57:34 --> Final output sent to browser
DEBUG - 2016-09-10 17:57:34 --> Total execution time: 0.6369
INFO - 2016-09-10 18:00:05 --> Config Class Initialized
INFO - 2016-09-10 18:00:05 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:00:06 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:00:06 --> Utf8 Class Initialized
INFO - 2016-09-10 18:00:06 --> URI Class Initialized
INFO - 2016-09-10 18:00:06 --> Router Class Initialized
INFO - 2016-09-10 18:00:06 --> Output Class Initialized
INFO - 2016-09-10 18:00:06 --> Security Class Initialized
DEBUG - 2016-09-10 18:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:00:06 --> Input Class Initialized
INFO - 2016-09-10 18:00:06 --> Language Class Initialized
INFO - 2016-09-10 18:00:06 --> Language Class Initialized
INFO - 2016-09-10 18:00:06 --> Config Class Initialized
INFO - 2016-09-10 18:00:06 --> Loader Class Initialized
INFO - 2016-09-10 18:00:06 --> Helper loaded: url_helper
INFO - 2016-09-10 18:00:06 --> Database Driver Class Initialized
INFO - 2016-09-10 18:00:06 --> Controller Class Initialized
DEBUG - 2016-09-10 18:00:06 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:00:06 --> Model Class Initialized
INFO - 2016-09-10 18:00:06 --> Model Class Initialized
DEBUG - 2016-09-10 18:00:06 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 18:00:06 --> Final output sent to browser
DEBUG - 2016-09-10 18:00:06 --> Total execution time: 0.4842
INFO - 2016-09-10 18:00:19 --> Config Class Initialized
INFO - 2016-09-10 18:00:19 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:00:19 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:00:19 --> Utf8 Class Initialized
INFO - 2016-09-10 18:00:19 --> URI Class Initialized
INFO - 2016-09-10 18:00:19 --> Router Class Initialized
INFO - 2016-09-10 18:00:19 --> Output Class Initialized
INFO - 2016-09-10 18:00:19 --> Security Class Initialized
DEBUG - 2016-09-10 18:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:00:19 --> Input Class Initialized
INFO - 2016-09-10 18:00:19 --> Language Class Initialized
INFO - 2016-09-10 18:00:19 --> Language Class Initialized
INFO - 2016-09-10 18:00:19 --> Config Class Initialized
INFO - 2016-09-10 18:00:19 --> Loader Class Initialized
INFO - 2016-09-10 18:00:19 --> Helper loaded: url_helper
INFO - 2016-09-10 18:00:19 --> Database Driver Class Initialized
INFO - 2016-09-10 18:00:19 --> Controller Class Initialized
DEBUG - 2016-09-10 18:00:19 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:00:19 --> Model Class Initialized
INFO - 2016-09-10 18:00:19 --> Model Class Initialized
DEBUG - 2016-09-10 18:00:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-10 18:00:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-10 18:00:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-10 18:00:19 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-10 18:00:19 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-10 18:00:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-10 18:00:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-10 18:00:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-10 18:00:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-10 18:00:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-10 18:00:19 --> Final output sent to browser
DEBUG - 2016-09-10 18:00:19 --> Total execution time: 0.7665
INFO - 2016-09-10 18:00:24 --> Config Class Initialized
INFO - 2016-09-10 18:00:24 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:00:24 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:00:24 --> Utf8 Class Initialized
INFO - 2016-09-10 18:00:24 --> URI Class Initialized
INFO - 2016-09-10 18:00:24 --> Router Class Initialized
INFO - 2016-09-10 18:00:24 --> Output Class Initialized
INFO - 2016-09-10 18:00:24 --> Security Class Initialized
DEBUG - 2016-09-10 18:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:00:24 --> Input Class Initialized
INFO - 2016-09-10 18:00:24 --> Language Class Initialized
INFO - 2016-09-10 18:00:24 --> Language Class Initialized
INFO - 2016-09-10 18:00:24 --> Config Class Initialized
INFO - 2016-09-10 18:00:24 --> Loader Class Initialized
INFO - 2016-09-10 18:00:24 --> Helper loaded: url_helper
INFO - 2016-09-10 18:00:24 --> Database Driver Class Initialized
INFO - 2016-09-10 18:00:24 --> Controller Class Initialized
DEBUG - 2016-09-10 18:00:24 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:00:24 --> Model Class Initialized
INFO - 2016-09-10 18:00:24 --> Model Class Initialized
DEBUG - 2016-09-10 18:00:24 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 18:00:24 --> Final output sent to browser
DEBUG - 2016-09-10 18:00:24 --> Total execution time: 0.6645
INFO - 2016-09-10 18:00:28 --> Config Class Initialized
INFO - 2016-09-10 18:00:28 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:00:28 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:00:28 --> Utf8 Class Initialized
INFO - 2016-09-10 18:00:28 --> URI Class Initialized
INFO - 2016-09-10 18:00:28 --> Router Class Initialized
INFO - 2016-09-10 18:00:28 --> Output Class Initialized
INFO - 2016-09-10 18:00:28 --> Security Class Initialized
DEBUG - 2016-09-10 18:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:00:28 --> Input Class Initialized
INFO - 2016-09-10 18:00:28 --> Language Class Initialized
INFO - 2016-09-10 18:00:28 --> Language Class Initialized
INFO - 2016-09-10 18:00:28 --> Config Class Initialized
INFO - 2016-09-10 18:00:28 --> Loader Class Initialized
INFO - 2016-09-10 18:00:28 --> Helper loaded: url_helper
INFO - 2016-09-10 18:00:28 --> Database Driver Class Initialized
INFO - 2016-09-10 18:00:28 --> Controller Class Initialized
DEBUG - 2016-09-10 18:00:28 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:00:28 --> Model Class Initialized
INFO - 2016-09-10 18:00:28 --> Model Class Initialized
DEBUG - 2016-09-10 18:00:28 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 18:00:28 --> Final output sent to browser
DEBUG - 2016-09-10 18:00:29 --> Total execution time: 0.6908
INFO - 2016-09-10 18:01:40 --> Config Class Initialized
INFO - 2016-09-10 18:01:40 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:01:40 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:01:40 --> Utf8 Class Initialized
INFO - 2016-09-10 18:01:40 --> URI Class Initialized
INFO - 2016-09-10 18:01:40 --> Router Class Initialized
INFO - 2016-09-10 18:01:40 --> Output Class Initialized
INFO - 2016-09-10 18:01:40 --> Security Class Initialized
DEBUG - 2016-09-10 18:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:01:40 --> Input Class Initialized
INFO - 2016-09-10 18:01:40 --> Language Class Initialized
INFO - 2016-09-10 18:01:40 --> Language Class Initialized
INFO - 2016-09-10 18:01:40 --> Config Class Initialized
INFO - 2016-09-10 18:01:40 --> Loader Class Initialized
INFO - 2016-09-10 18:01:40 --> Helper loaded: url_helper
INFO - 2016-09-10 18:01:40 --> Database Driver Class Initialized
INFO - 2016-09-10 18:01:40 --> Controller Class Initialized
DEBUG - 2016-09-10 18:01:40 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:01:40 --> Model Class Initialized
INFO - 2016-09-10 18:01:40 --> Model Class Initialized
DEBUG - 2016-09-10 18:01:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-10 18:01:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-10 18:01:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-10 18:01:41 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-10 18:01:41 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-10 18:01:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-10 18:01:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-10 18:01:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-10 18:01:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-10 18:01:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-10 18:01:41 --> Final output sent to browser
DEBUG - 2016-09-10 18:01:41 --> Total execution time: 0.7705
INFO - 2016-09-10 18:01:45 --> Config Class Initialized
INFO - 2016-09-10 18:01:45 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:01:45 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:01:45 --> Utf8 Class Initialized
INFO - 2016-09-10 18:01:45 --> URI Class Initialized
INFO - 2016-09-10 18:01:45 --> Router Class Initialized
INFO - 2016-09-10 18:01:45 --> Output Class Initialized
INFO - 2016-09-10 18:01:45 --> Security Class Initialized
DEBUG - 2016-09-10 18:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:01:46 --> Input Class Initialized
INFO - 2016-09-10 18:01:46 --> Language Class Initialized
INFO - 2016-09-10 18:01:46 --> Language Class Initialized
INFO - 2016-09-10 18:01:46 --> Config Class Initialized
INFO - 2016-09-10 18:01:46 --> Loader Class Initialized
INFO - 2016-09-10 18:01:46 --> Helper loaded: url_helper
INFO - 2016-09-10 18:01:46 --> Database Driver Class Initialized
INFO - 2016-09-10 18:01:46 --> Controller Class Initialized
DEBUG - 2016-09-10 18:01:46 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:01:46 --> Model Class Initialized
INFO - 2016-09-10 18:01:46 --> Model Class Initialized
DEBUG - 2016-09-10 18:01:46 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 18:01:46 --> Final output sent to browser
DEBUG - 2016-09-10 18:01:46 --> Total execution time: 0.8593
INFO - 2016-09-10 18:02:06 --> Config Class Initialized
INFO - 2016-09-10 18:02:06 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:02:06 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:02:06 --> Utf8 Class Initialized
INFO - 2016-09-10 18:02:06 --> URI Class Initialized
INFO - 2016-09-10 18:02:06 --> Router Class Initialized
INFO - 2016-09-10 18:02:06 --> Output Class Initialized
INFO - 2016-09-10 18:02:06 --> Security Class Initialized
DEBUG - 2016-09-10 18:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:02:06 --> Input Class Initialized
INFO - 2016-09-10 18:02:06 --> Language Class Initialized
INFO - 2016-09-10 18:02:06 --> Language Class Initialized
INFO - 2016-09-10 18:02:07 --> Config Class Initialized
INFO - 2016-09-10 18:02:07 --> Loader Class Initialized
INFO - 2016-09-10 18:02:07 --> Helper loaded: url_helper
INFO - 2016-09-10 18:02:07 --> Database Driver Class Initialized
INFO - 2016-09-10 18:02:07 --> Controller Class Initialized
DEBUG - 2016-09-10 18:02:07 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:02:07 --> Model Class Initialized
INFO - 2016-09-10 18:02:07 --> Model Class Initialized
DEBUG - 2016-09-10 18:02:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-10 18:02:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-10 18:02:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-10 18:02:07 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-10 18:02:07 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-10 18:02:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-10 18:02:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-10 18:02:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-10 18:02:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-10 18:02:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-10 18:02:07 --> Final output sent to browser
DEBUG - 2016-09-10 18:02:07 --> Total execution time: 0.7327
INFO - 2016-09-10 18:02:12 --> Config Class Initialized
INFO - 2016-09-10 18:02:12 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:02:12 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:02:12 --> Utf8 Class Initialized
INFO - 2016-09-10 18:02:12 --> URI Class Initialized
INFO - 2016-09-10 18:02:12 --> Router Class Initialized
INFO - 2016-09-10 18:02:12 --> Output Class Initialized
INFO - 2016-09-10 18:02:12 --> Security Class Initialized
DEBUG - 2016-09-10 18:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:02:13 --> Input Class Initialized
INFO - 2016-09-10 18:02:13 --> Language Class Initialized
INFO - 2016-09-10 18:02:13 --> Language Class Initialized
INFO - 2016-09-10 18:02:13 --> Config Class Initialized
INFO - 2016-09-10 18:02:13 --> Loader Class Initialized
INFO - 2016-09-10 18:02:13 --> Helper loaded: url_helper
INFO - 2016-09-10 18:02:13 --> Database Driver Class Initialized
INFO - 2016-09-10 18:02:13 --> Controller Class Initialized
DEBUG - 2016-09-10 18:02:13 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:02:13 --> Model Class Initialized
INFO - 2016-09-10 18:02:13 --> Model Class Initialized
DEBUG - 2016-09-10 18:02:13 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 18:02:13 --> Final output sent to browser
DEBUG - 2016-09-10 18:02:13 --> Total execution time: 0.6808
INFO - 2016-09-10 18:05:38 --> Config Class Initialized
INFO - 2016-09-10 18:05:38 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:05:38 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:05:38 --> Utf8 Class Initialized
INFO - 2016-09-10 18:05:38 --> URI Class Initialized
INFO - 2016-09-10 18:05:38 --> Router Class Initialized
INFO - 2016-09-10 18:05:38 --> Output Class Initialized
INFO - 2016-09-10 18:05:38 --> Security Class Initialized
DEBUG - 2016-09-10 18:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:05:38 --> Input Class Initialized
INFO - 2016-09-10 18:05:38 --> Language Class Initialized
INFO - 2016-09-10 18:05:38 --> Language Class Initialized
INFO - 2016-09-10 18:05:38 --> Config Class Initialized
INFO - 2016-09-10 18:05:38 --> Loader Class Initialized
INFO - 2016-09-10 18:05:38 --> Helper loaded: url_helper
INFO - 2016-09-10 18:05:38 --> Database Driver Class Initialized
INFO - 2016-09-10 18:05:38 --> Controller Class Initialized
DEBUG - 2016-09-10 18:05:38 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:05:38 --> Model Class Initialized
INFO - 2016-09-10 18:05:39 --> Model Class Initialized
DEBUG - 2016-09-10 18:05:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-10 18:05:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-10 18:05:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-10 18:05:39 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-10 18:05:39 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-10 18:05:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-10 18:05:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-10 18:05:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-10 18:05:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-10 18:05:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-10 18:05:39 --> Final output sent to browser
DEBUG - 2016-09-10 18:05:39 --> Total execution time: 0.6524
INFO - 2016-09-10 18:05:43 --> Config Class Initialized
INFO - 2016-09-10 18:05:43 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:05:43 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:05:43 --> Utf8 Class Initialized
INFO - 2016-09-10 18:05:43 --> URI Class Initialized
INFO - 2016-09-10 18:05:43 --> Router Class Initialized
INFO - 2016-09-10 18:05:43 --> Output Class Initialized
INFO - 2016-09-10 18:05:43 --> Security Class Initialized
DEBUG - 2016-09-10 18:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:05:43 --> Input Class Initialized
INFO - 2016-09-10 18:05:43 --> Language Class Initialized
INFO - 2016-09-10 18:05:43 --> Language Class Initialized
INFO - 2016-09-10 18:05:43 --> Config Class Initialized
INFO - 2016-09-10 18:05:43 --> Loader Class Initialized
INFO - 2016-09-10 18:05:43 --> Helper loaded: url_helper
INFO - 2016-09-10 18:05:43 --> Database Driver Class Initialized
INFO - 2016-09-10 18:05:43 --> Controller Class Initialized
DEBUG - 2016-09-10 18:05:43 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:05:43 --> Model Class Initialized
INFO - 2016-09-10 18:05:43 --> Model Class Initialized
DEBUG - 2016-09-10 18:05:43 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 18:05:43 --> Final output sent to browser
DEBUG - 2016-09-10 18:05:44 --> Total execution time: 0.8084
INFO - 2016-09-10 18:14:09 --> Config Class Initialized
INFO - 2016-09-10 18:14:09 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:14:09 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:14:09 --> Utf8 Class Initialized
INFO - 2016-09-10 18:14:09 --> URI Class Initialized
INFO - 2016-09-10 18:14:09 --> Router Class Initialized
INFO - 2016-09-10 18:14:09 --> Output Class Initialized
INFO - 2016-09-10 18:14:09 --> Security Class Initialized
DEBUG - 2016-09-10 18:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:14:09 --> Input Class Initialized
INFO - 2016-09-10 18:14:09 --> Language Class Initialized
INFO - 2016-09-10 18:14:09 --> Language Class Initialized
INFO - 2016-09-10 18:14:09 --> Config Class Initialized
INFO - 2016-09-10 18:14:10 --> Loader Class Initialized
INFO - 2016-09-10 18:14:10 --> Helper loaded: url_helper
INFO - 2016-09-10 18:14:10 --> Database Driver Class Initialized
INFO - 2016-09-10 18:14:10 --> Controller Class Initialized
DEBUG - 2016-09-10 18:14:10 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:14:10 --> Model Class Initialized
INFO - 2016-09-10 18:14:10 --> Model Class Initialized
DEBUG - 2016-09-10 18:14:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-10 18:14:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-10 18:14:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-10 18:14:10 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-10 18:14:10 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-10 18:14:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-10 18:14:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-10 18:14:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-10 18:14:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-10 18:14:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-10 18:14:10 --> Final output sent to browser
DEBUG - 2016-09-10 18:14:10 --> Total execution time: 0.8432
INFO - 2016-09-10 18:14:15 --> Config Class Initialized
INFO - 2016-09-10 18:14:15 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:14:15 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:14:15 --> Utf8 Class Initialized
INFO - 2016-09-10 18:14:15 --> URI Class Initialized
INFO - 2016-09-10 18:14:15 --> Router Class Initialized
INFO - 2016-09-10 18:14:15 --> Output Class Initialized
INFO - 2016-09-10 18:14:15 --> Security Class Initialized
DEBUG - 2016-09-10 18:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:14:15 --> Input Class Initialized
INFO - 2016-09-10 18:14:15 --> Language Class Initialized
INFO - 2016-09-10 18:14:15 --> Language Class Initialized
INFO - 2016-09-10 18:14:15 --> Config Class Initialized
INFO - 2016-09-10 18:14:15 --> Loader Class Initialized
INFO - 2016-09-10 18:14:15 --> Helper loaded: url_helper
INFO - 2016-09-10 18:14:15 --> Database Driver Class Initialized
INFO - 2016-09-10 18:14:16 --> Controller Class Initialized
DEBUG - 2016-09-10 18:14:16 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:14:16 --> Model Class Initialized
INFO - 2016-09-10 18:14:16 --> Model Class Initialized
DEBUG - 2016-09-10 18:14:16 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 18:14:16 --> Final output sent to browser
DEBUG - 2016-09-10 18:14:16 --> Total execution time: 0.7077
INFO - 2016-09-10 18:14:19 --> Config Class Initialized
INFO - 2016-09-10 18:14:19 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:14:19 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:14:19 --> Utf8 Class Initialized
INFO - 2016-09-10 18:14:19 --> URI Class Initialized
INFO - 2016-09-10 18:14:19 --> Router Class Initialized
INFO - 2016-09-10 18:14:19 --> Output Class Initialized
INFO - 2016-09-10 18:14:19 --> Security Class Initialized
DEBUG - 2016-09-10 18:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:14:19 --> Input Class Initialized
INFO - 2016-09-10 18:14:19 --> Language Class Initialized
INFO - 2016-09-10 18:14:19 --> Language Class Initialized
INFO - 2016-09-10 18:14:19 --> Config Class Initialized
INFO - 2016-09-10 18:14:19 --> Loader Class Initialized
INFO - 2016-09-10 18:14:19 --> Helper loaded: url_helper
INFO - 2016-09-10 18:14:19 --> Database Driver Class Initialized
INFO - 2016-09-10 18:14:19 --> Controller Class Initialized
DEBUG - 2016-09-10 18:14:19 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:14:19 --> Model Class Initialized
INFO - 2016-09-10 18:14:19 --> Model Class Initialized
DEBUG - 2016-09-10 18:14:19 --> Anggota MX_Controller Initialized
ERROR - 2016-09-10 18:14:19 --> Severity: Notice --> Array to string conversion E:\SERVER\htdocs\koperasiweda\application\models\GLobalModel.php 25
ERROR - 2016-09-10 18:14:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '(kd_anggota)) VALUES ('12c6fc06c99a462375eeb3f43dfd832b08ca9e17')' at line 1 - Invalid query: INSERT INTO `Array` (sha1(kd_anggota)) VALUES ('12c6fc06c99a462375eeb3f43dfd832b08ca9e17')
INFO - 2016-09-10 18:14:19 --> Language file loaded: language/english/db_lang.php
INFO - 2016-09-10 18:14:35 --> Config Class Initialized
INFO - 2016-09-10 18:14:35 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:14:35 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:14:35 --> Utf8 Class Initialized
INFO - 2016-09-10 18:14:35 --> URI Class Initialized
INFO - 2016-09-10 18:14:35 --> Router Class Initialized
INFO - 2016-09-10 18:14:35 --> Output Class Initialized
INFO - 2016-09-10 18:14:35 --> Security Class Initialized
DEBUG - 2016-09-10 18:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:14:35 --> Input Class Initialized
INFO - 2016-09-10 18:14:35 --> Language Class Initialized
INFO - 2016-09-10 18:14:35 --> Language Class Initialized
INFO - 2016-09-10 18:14:35 --> Config Class Initialized
INFO - 2016-09-10 18:14:35 --> Loader Class Initialized
INFO - 2016-09-10 18:14:35 --> Helper loaded: url_helper
INFO - 2016-09-10 18:14:35 --> Database Driver Class Initialized
INFO - 2016-09-10 18:14:35 --> Controller Class Initialized
DEBUG - 2016-09-10 18:14:35 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:14:35 --> Model Class Initialized
INFO - 2016-09-10 18:14:35 --> Model Class Initialized
DEBUG - 2016-09-10 18:14:35 --> Anggota MX_Controller Initialized
ERROR - 2016-09-10 18:14:35 --> Severity: Notice --> Array to string conversion E:\SERVER\htdocs\koperasiweda\application\models\GLobalModel.php 25
ERROR - 2016-09-10 18:14:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '(kd_anggota)) VALUES ('12c6fc06c99a462375eeb3f43dfd832b08ca9e17')' at line 1 - Invalid query: INSERT INTO `Array` (sha1(kd_anggota)) VALUES ('12c6fc06c99a462375eeb3f43dfd832b08ca9e17')
INFO - 2016-09-10 18:14:35 --> Language file loaded: language/english/db_lang.php
INFO - 2016-09-10 18:15:40 --> Config Class Initialized
INFO - 2016-09-10 18:15:40 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:15:40 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:15:40 --> Utf8 Class Initialized
INFO - 2016-09-10 18:15:40 --> URI Class Initialized
INFO - 2016-09-10 18:15:40 --> Router Class Initialized
INFO - 2016-09-10 18:15:40 --> Output Class Initialized
INFO - 2016-09-10 18:15:40 --> Security Class Initialized
DEBUG - 2016-09-10 18:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:15:40 --> Input Class Initialized
INFO - 2016-09-10 18:15:40 --> Language Class Initialized
INFO - 2016-09-10 18:15:40 --> Language Class Initialized
INFO - 2016-09-10 18:15:40 --> Config Class Initialized
INFO - 2016-09-10 18:15:40 --> Loader Class Initialized
INFO - 2016-09-10 18:15:40 --> Helper loaded: url_helper
INFO - 2016-09-10 18:15:40 --> Database Driver Class Initialized
INFO - 2016-09-10 18:15:40 --> Controller Class Initialized
DEBUG - 2016-09-10 18:15:41 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:15:41 --> Model Class Initialized
INFO - 2016-09-10 18:15:41 --> Model Class Initialized
DEBUG - 2016-09-10 18:15:41 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 18:15:41 --> Final output sent to browser
DEBUG - 2016-09-10 18:15:41 --> Total execution time: 0.6213
INFO - 2016-09-10 18:15:57 --> Config Class Initialized
INFO - 2016-09-10 18:15:57 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:15:58 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:15:58 --> Utf8 Class Initialized
INFO - 2016-09-10 18:15:58 --> URI Class Initialized
INFO - 2016-09-10 18:15:58 --> Router Class Initialized
INFO - 2016-09-10 18:15:58 --> Output Class Initialized
INFO - 2016-09-10 18:15:58 --> Security Class Initialized
DEBUG - 2016-09-10 18:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:15:58 --> Input Class Initialized
INFO - 2016-09-10 18:15:58 --> Language Class Initialized
INFO - 2016-09-10 18:15:58 --> Language Class Initialized
INFO - 2016-09-10 18:15:58 --> Config Class Initialized
INFO - 2016-09-10 18:15:58 --> Loader Class Initialized
INFO - 2016-09-10 18:15:58 --> Helper loaded: url_helper
INFO - 2016-09-10 18:15:58 --> Database Driver Class Initialized
INFO - 2016-09-10 18:15:58 --> Controller Class Initialized
DEBUG - 2016-09-10 18:15:58 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:15:58 --> Model Class Initialized
INFO - 2016-09-10 18:15:58 --> Model Class Initialized
DEBUG - 2016-09-10 18:15:58 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 18:15:58 --> Final output sent to browser
DEBUG - 2016-09-10 18:15:58 --> Total execution time: 0.6133
INFO - 2016-09-10 18:16:11 --> Config Class Initialized
INFO - 2016-09-10 18:16:11 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:16:11 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:16:11 --> Utf8 Class Initialized
INFO - 2016-09-10 18:16:11 --> URI Class Initialized
INFO - 2016-09-10 18:16:11 --> Router Class Initialized
INFO - 2016-09-10 18:16:11 --> Output Class Initialized
INFO - 2016-09-10 18:16:11 --> Security Class Initialized
DEBUG - 2016-09-10 18:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:16:11 --> Input Class Initialized
INFO - 2016-09-10 18:16:11 --> Language Class Initialized
INFO - 2016-09-10 18:16:11 --> Language Class Initialized
INFO - 2016-09-10 18:16:11 --> Config Class Initialized
INFO - 2016-09-10 18:16:11 --> Loader Class Initialized
INFO - 2016-09-10 18:16:11 --> Helper loaded: url_helper
INFO - 2016-09-10 18:16:11 --> Database Driver Class Initialized
INFO - 2016-09-10 18:16:11 --> Controller Class Initialized
DEBUG - 2016-09-10 18:16:11 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:16:11 --> Model Class Initialized
INFO - 2016-09-10 18:16:12 --> Model Class Initialized
DEBUG - 2016-09-10 18:16:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-10 18:16:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-10 18:16:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-10 18:16:12 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-10 18:16:12 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-10 18:16:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-10 18:16:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-10 18:16:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-10 18:16:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-10 18:16:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-10 18:16:12 --> Final output sent to browser
DEBUG - 2016-09-10 18:16:12 --> Total execution time: 0.7955
INFO - 2016-09-10 18:16:19 --> Config Class Initialized
INFO - 2016-09-10 18:16:19 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:16:19 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:16:19 --> Utf8 Class Initialized
INFO - 2016-09-10 18:16:19 --> URI Class Initialized
INFO - 2016-09-10 18:16:19 --> Router Class Initialized
INFO - 2016-09-10 18:16:19 --> Output Class Initialized
INFO - 2016-09-10 18:16:19 --> Security Class Initialized
DEBUG - 2016-09-10 18:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:16:19 --> Input Class Initialized
INFO - 2016-09-10 18:16:19 --> Language Class Initialized
INFO - 2016-09-10 18:16:19 --> Language Class Initialized
INFO - 2016-09-10 18:16:19 --> Config Class Initialized
INFO - 2016-09-10 18:16:19 --> Loader Class Initialized
INFO - 2016-09-10 18:16:19 --> Helper loaded: url_helper
INFO - 2016-09-10 18:16:19 --> Database Driver Class Initialized
INFO - 2016-09-10 18:16:19 --> Controller Class Initialized
DEBUG - 2016-09-10 18:16:19 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:16:19 --> Model Class Initialized
INFO - 2016-09-10 18:16:19 --> Model Class Initialized
DEBUG - 2016-09-10 18:16:19 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 18:16:19 --> Final output sent to browser
DEBUG - 2016-09-10 18:16:19 --> Total execution time: 0.6358
INFO - 2016-09-10 18:16:22 --> Config Class Initialized
INFO - 2016-09-10 18:16:22 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:16:22 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:16:22 --> Utf8 Class Initialized
INFO - 2016-09-10 18:16:22 --> URI Class Initialized
INFO - 2016-09-10 18:16:22 --> Router Class Initialized
INFO - 2016-09-10 18:16:22 --> Output Class Initialized
INFO - 2016-09-10 18:16:22 --> Security Class Initialized
DEBUG - 2016-09-10 18:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:16:22 --> Input Class Initialized
INFO - 2016-09-10 18:16:22 --> Language Class Initialized
INFO - 2016-09-10 18:16:23 --> Language Class Initialized
INFO - 2016-09-10 18:16:23 --> Config Class Initialized
INFO - 2016-09-10 18:16:23 --> Loader Class Initialized
INFO - 2016-09-10 18:16:23 --> Helper loaded: url_helper
INFO - 2016-09-10 18:16:23 --> Database Driver Class Initialized
INFO - 2016-09-10 18:16:23 --> Controller Class Initialized
DEBUG - 2016-09-10 18:16:23 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:16:23 --> Model Class Initialized
INFO - 2016-09-10 18:16:23 --> Model Class Initialized
DEBUG - 2016-09-10 18:16:23 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 18:16:23 --> Final output sent to browser
DEBUG - 2016-09-10 18:16:23 --> Total execution time: 0.5398
INFO - 2016-09-10 18:26:01 --> Config Class Initialized
INFO - 2016-09-10 18:26:01 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:26:01 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:26:01 --> Utf8 Class Initialized
INFO - 2016-09-10 18:26:01 --> URI Class Initialized
INFO - 2016-09-10 18:26:01 --> Router Class Initialized
INFO - 2016-09-10 18:26:01 --> Output Class Initialized
INFO - 2016-09-10 18:26:01 --> Security Class Initialized
DEBUG - 2016-09-10 18:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:26:02 --> Input Class Initialized
INFO - 2016-09-10 18:26:02 --> Language Class Initialized
INFO - 2016-09-10 18:26:02 --> Language Class Initialized
INFO - 2016-09-10 18:26:02 --> Config Class Initialized
INFO - 2016-09-10 18:26:02 --> Loader Class Initialized
INFO - 2016-09-10 18:26:02 --> Helper loaded: url_helper
INFO - 2016-09-10 18:26:02 --> Database Driver Class Initialized
INFO - 2016-09-10 18:26:02 --> Controller Class Initialized
DEBUG - 2016-09-10 18:26:02 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:26:02 --> Model Class Initialized
INFO - 2016-09-10 18:26:02 --> Model Class Initialized
DEBUG - 2016-09-10 18:26:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-10 18:26:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-10 18:26:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-10 18:26:02 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-10 18:26:02 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-10 18:26:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-10 18:26:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-10 18:26:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-10 18:26:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-10 18:26:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-10 18:26:02 --> Final output sent to browser
DEBUG - 2016-09-10 18:26:02 --> Total execution time: 0.9793
INFO - 2016-09-10 18:26:06 --> Config Class Initialized
INFO - 2016-09-10 18:26:06 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:26:06 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:26:06 --> Utf8 Class Initialized
INFO - 2016-09-10 18:26:07 --> URI Class Initialized
INFO - 2016-09-10 18:26:07 --> Router Class Initialized
INFO - 2016-09-10 18:26:07 --> Output Class Initialized
INFO - 2016-09-10 18:26:07 --> Security Class Initialized
DEBUG - 2016-09-10 18:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:26:07 --> Input Class Initialized
INFO - 2016-09-10 18:26:07 --> Language Class Initialized
INFO - 2016-09-10 18:26:07 --> Language Class Initialized
INFO - 2016-09-10 18:26:07 --> Config Class Initialized
INFO - 2016-09-10 18:26:07 --> Loader Class Initialized
INFO - 2016-09-10 18:26:07 --> Helper loaded: url_helper
INFO - 2016-09-10 18:26:07 --> Database Driver Class Initialized
INFO - 2016-09-10 18:26:07 --> Controller Class Initialized
DEBUG - 2016-09-10 18:26:07 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:26:07 --> Model Class Initialized
INFO - 2016-09-10 18:26:07 --> Model Class Initialized
DEBUG - 2016-09-10 18:26:07 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 18:26:07 --> Final output sent to browser
DEBUG - 2016-09-10 18:26:07 --> Total execution time: 0.6208
INFO - 2016-09-10 18:26:22 --> Config Class Initialized
INFO - 2016-09-10 18:26:22 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:26:22 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:26:22 --> Utf8 Class Initialized
INFO - 2016-09-10 18:26:22 --> URI Class Initialized
INFO - 2016-09-10 18:26:22 --> Router Class Initialized
INFO - 2016-09-10 18:26:22 --> Output Class Initialized
INFO - 2016-09-10 18:26:22 --> Security Class Initialized
DEBUG - 2016-09-10 18:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:26:22 --> Input Class Initialized
INFO - 2016-09-10 18:26:22 --> Language Class Initialized
INFO - 2016-09-10 18:26:23 --> Language Class Initialized
INFO - 2016-09-10 18:26:23 --> Config Class Initialized
INFO - 2016-09-10 18:26:23 --> Loader Class Initialized
INFO - 2016-09-10 18:26:23 --> Helper loaded: url_helper
INFO - 2016-09-10 18:26:23 --> Database Driver Class Initialized
INFO - 2016-09-10 18:26:23 --> Controller Class Initialized
DEBUG - 2016-09-10 18:26:23 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:26:23 --> Model Class Initialized
INFO - 2016-09-10 18:26:23 --> Model Class Initialized
DEBUG - 2016-09-10 18:26:23 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 18:26:23 --> Final output sent to browser
DEBUG - 2016-09-10 18:26:23 --> Total execution time: 0.6499
INFO - 2016-09-10 18:30:38 --> Config Class Initialized
INFO - 2016-09-10 18:30:38 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:30:38 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:30:38 --> Utf8 Class Initialized
INFO - 2016-09-10 18:30:38 --> URI Class Initialized
INFO - 2016-09-10 18:30:38 --> Router Class Initialized
INFO - 2016-09-10 18:30:38 --> Output Class Initialized
INFO - 2016-09-10 18:30:38 --> Security Class Initialized
DEBUG - 2016-09-10 18:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:30:39 --> Input Class Initialized
INFO - 2016-09-10 18:30:39 --> Language Class Initialized
INFO - 2016-09-10 18:30:39 --> Language Class Initialized
INFO - 2016-09-10 18:30:39 --> Config Class Initialized
INFO - 2016-09-10 18:30:39 --> Loader Class Initialized
INFO - 2016-09-10 18:30:39 --> Helper loaded: url_helper
INFO - 2016-09-10 18:30:39 --> Database Driver Class Initialized
INFO - 2016-09-10 18:30:39 --> Controller Class Initialized
DEBUG - 2016-09-10 18:30:39 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:30:39 --> Model Class Initialized
INFO - 2016-09-10 18:30:39 --> Model Class Initialized
DEBUG - 2016-09-10 18:30:39 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 18:30:39 --> Final output sent to browser
DEBUG - 2016-09-10 18:30:39 --> Total execution time: 0.6776
INFO - 2016-09-10 18:30:44 --> Config Class Initialized
INFO - 2016-09-10 18:30:45 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:30:45 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:30:45 --> Utf8 Class Initialized
INFO - 2016-09-10 18:30:45 --> URI Class Initialized
INFO - 2016-09-10 18:30:45 --> Router Class Initialized
INFO - 2016-09-10 18:30:45 --> Output Class Initialized
INFO - 2016-09-10 18:30:45 --> Security Class Initialized
DEBUG - 2016-09-10 18:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:30:45 --> Input Class Initialized
INFO - 2016-09-10 18:30:45 --> Language Class Initialized
INFO - 2016-09-10 18:30:45 --> Language Class Initialized
INFO - 2016-09-10 18:30:45 --> Config Class Initialized
INFO - 2016-09-10 18:30:45 --> Loader Class Initialized
INFO - 2016-09-10 18:30:45 --> Helper loaded: url_helper
INFO - 2016-09-10 18:30:45 --> Database Driver Class Initialized
INFO - 2016-09-10 18:30:45 --> Controller Class Initialized
DEBUG - 2016-09-10 18:30:45 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:30:45 --> Model Class Initialized
INFO - 2016-09-10 18:30:45 --> Model Class Initialized
DEBUG - 2016-09-10 18:30:45 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 18:30:45 --> Final output sent to browser
DEBUG - 2016-09-10 18:30:45 --> Total execution time: 0.5752
INFO - 2016-09-10 18:36:18 --> Config Class Initialized
INFO - 2016-09-10 18:36:18 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:36:18 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:36:18 --> Utf8 Class Initialized
INFO - 2016-09-10 18:36:18 --> URI Class Initialized
INFO - 2016-09-10 18:36:18 --> Router Class Initialized
INFO - 2016-09-10 18:36:18 --> Output Class Initialized
INFO - 2016-09-10 18:36:18 --> Security Class Initialized
DEBUG - 2016-09-10 18:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:36:18 --> Input Class Initialized
INFO - 2016-09-10 18:36:18 --> Language Class Initialized
INFO - 2016-09-10 18:36:18 --> Language Class Initialized
INFO - 2016-09-10 18:36:18 --> Config Class Initialized
INFO - 2016-09-10 18:36:18 --> Loader Class Initialized
INFO - 2016-09-10 18:36:18 --> Helper loaded: url_helper
INFO - 2016-09-10 18:36:18 --> Database Driver Class Initialized
INFO - 2016-09-10 18:36:18 --> Controller Class Initialized
DEBUG - 2016-09-10 18:36:18 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:36:18 --> Model Class Initialized
INFO - 2016-09-10 18:36:18 --> Model Class Initialized
DEBUG - 2016-09-10 18:36:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-10 18:36:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-10 18:36:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-10 18:36:18 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-10 18:36:18 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-10 18:36:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-10 18:36:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-10 18:36:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-10 18:36:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-10 18:36:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-10 18:36:19 --> Final output sent to browser
DEBUG - 2016-09-10 18:36:19 --> Total execution time: 0.7749
INFO - 2016-09-10 18:36:23 --> Config Class Initialized
INFO - 2016-09-10 18:36:23 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:36:23 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:36:23 --> Utf8 Class Initialized
INFO - 2016-09-10 18:36:23 --> URI Class Initialized
INFO - 2016-09-10 18:36:23 --> Router Class Initialized
INFO - 2016-09-10 18:36:23 --> Output Class Initialized
INFO - 2016-09-10 18:36:23 --> Security Class Initialized
DEBUG - 2016-09-10 18:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:36:23 --> Input Class Initialized
INFO - 2016-09-10 18:36:23 --> Language Class Initialized
INFO - 2016-09-10 18:36:23 --> Language Class Initialized
INFO - 2016-09-10 18:36:23 --> Config Class Initialized
INFO - 2016-09-10 18:36:23 --> Loader Class Initialized
INFO - 2016-09-10 18:36:23 --> Helper loaded: url_helper
INFO - 2016-09-10 18:36:23 --> Database Driver Class Initialized
INFO - 2016-09-10 18:36:23 --> Controller Class Initialized
DEBUG - 2016-09-10 18:36:23 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:36:23 --> Model Class Initialized
INFO - 2016-09-10 18:36:23 --> Model Class Initialized
DEBUG - 2016-09-10 18:36:23 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 18:36:23 --> Final output sent to browser
DEBUG - 2016-09-10 18:36:23 --> Total execution time: 0.7202
INFO - 2016-09-10 18:36:26 --> Config Class Initialized
INFO - 2016-09-10 18:36:26 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:36:26 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:36:26 --> Utf8 Class Initialized
INFO - 2016-09-10 18:36:26 --> URI Class Initialized
INFO - 2016-09-10 18:36:26 --> Router Class Initialized
INFO - 2016-09-10 18:36:26 --> Output Class Initialized
INFO - 2016-09-10 18:36:26 --> Security Class Initialized
DEBUG - 2016-09-10 18:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:36:26 --> Input Class Initialized
INFO - 2016-09-10 18:36:26 --> Language Class Initialized
INFO - 2016-09-10 18:36:26 --> Language Class Initialized
INFO - 2016-09-10 18:36:26 --> Config Class Initialized
INFO - 2016-09-10 18:36:26 --> Loader Class Initialized
INFO - 2016-09-10 18:36:26 --> Helper loaded: url_helper
INFO - 2016-09-10 18:36:26 --> Database Driver Class Initialized
INFO - 2016-09-10 18:36:26 --> Controller Class Initialized
DEBUG - 2016-09-10 18:36:26 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:36:26 --> Model Class Initialized
INFO - 2016-09-10 18:36:26 --> Model Class Initialized
DEBUG - 2016-09-10 18:36:26 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 18:36:26 --> Final output sent to browser
DEBUG - 2016-09-10 18:36:26 --> Total execution time: 0.5306
INFO - 2016-09-10 18:36:38 --> Config Class Initialized
INFO - 2016-09-10 18:36:38 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:36:38 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:36:38 --> Utf8 Class Initialized
INFO - 2016-09-10 18:36:38 --> URI Class Initialized
INFO - 2016-09-10 18:36:38 --> Router Class Initialized
INFO - 2016-09-10 18:36:38 --> Output Class Initialized
INFO - 2016-09-10 18:36:38 --> Security Class Initialized
DEBUG - 2016-09-10 18:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:36:38 --> Input Class Initialized
INFO - 2016-09-10 18:36:38 --> Language Class Initialized
INFO - 2016-09-10 18:36:39 --> Language Class Initialized
INFO - 2016-09-10 18:36:39 --> Config Class Initialized
INFO - 2016-09-10 18:36:39 --> Loader Class Initialized
INFO - 2016-09-10 18:36:39 --> Helper loaded: url_helper
INFO - 2016-09-10 18:36:39 --> Database Driver Class Initialized
INFO - 2016-09-10 18:36:39 --> Controller Class Initialized
DEBUG - 2016-09-10 18:36:39 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:36:39 --> Model Class Initialized
INFO - 2016-09-10 18:36:39 --> Model Class Initialized
DEBUG - 2016-09-10 18:36:39 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 18:36:39 --> Final output sent to browser
DEBUG - 2016-09-10 18:36:39 --> Total execution time: 0.6587
INFO - 2016-09-10 18:36:48 --> Config Class Initialized
INFO - 2016-09-10 18:36:48 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:36:48 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:36:48 --> Utf8 Class Initialized
INFO - 2016-09-10 18:36:48 --> URI Class Initialized
INFO - 2016-09-10 18:36:48 --> Router Class Initialized
INFO - 2016-09-10 18:36:48 --> Output Class Initialized
INFO - 2016-09-10 18:36:48 --> Security Class Initialized
DEBUG - 2016-09-10 18:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:36:48 --> Input Class Initialized
INFO - 2016-09-10 18:36:48 --> Language Class Initialized
INFO - 2016-09-10 18:36:48 --> Language Class Initialized
INFO - 2016-09-10 18:36:48 --> Config Class Initialized
INFO - 2016-09-10 18:36:48 --> Loader Class Initialized
INFO - 2016-09-10 18:36:48 --> Helper loaded: url_helper
INFO - 2016-09-10 18:36:48 --> Database Driver Class Initialized
INFO - 2016-09-10 18:36:48 --> Controller Class Initialized
DEBUG - 2016-09-10 18:36:48 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:36:48 --> Model Class Initialized
INFO - 2016-09-10 18:36:48 --> Model Class Initialized
DEBUG - 2016-09-10 18:36:48 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 18:36:48 --> Final output sent to browser
DEBUG - 2016-09-10 18:36:48 --> Total execution time: 0.5411
INFO - 2016-09-10 18:39:31 --> Config Class Initialized
INFO - 2016-09-10 18:39:31 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:39:31 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:39:31 --> Utf8 Class Initialized
INFO - 2016-09-10 18:39:31 --> URI Class Initialized
INFO - 2016-09-10 18:39:31 --> Router Class Initialized
INFO - 2016-09-10 18:39:31 --> Output Class Initialized
INFO - 2016-09-10 18:39:31 --> Security Class Initialized
DEBUG - 2016-09-10 18:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:39:31 --> Input Class Initialized
INFO - 2016-09-10 18:39:31 --> Language Class Initialized
INFO - 2016-09-10 18:39:31 --> Language Class Initialized
INFO - 2016-09-10 18:39:31 --> Config Class Initialized
INFO - 2016-09-10 18:39:31 --> Loader Class Initialized
INFO - 2016-09-10 18:39:31 --> Helper loaded: url_helper
INFO - 2016-09-10 18:39:31 --> Database Driver Class Initialized
INFO - 2016-09-10 18:39:31 --> Controller Class Initialized
DEBUG - 2016-09-10 18:39:31 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:39:31 --> Model Class Initialized
INFO - 2016-09-10 18:39:31 --> Model Class Initialized
DEBUG - 2016-09-10 18:39:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-10 18:39:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-10 18:39:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-10 18:39:31 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-10 18:39:31 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-10 18:39:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-10 18:39:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-10 18:39:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-10 18:39:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-10 18:39:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-10 18:39:31 --> Final output sent to browser
DEBUG - 2016-09-10 18:39:31 --> Total execution time: 0.7507
INFO - 2016-09-10 18:39:40 --> Config Class Initialized
INFO - 2016-09-10 18:39:40 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:39:40 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:39:40 --> Utf8 Class Initialized
INFO - 2016-09-10 18:39:40 --> URI Class Initialized
INFO - 2016-09-10 18:39:40 --> Router Class Initialized
INFO - 2016-09-10 18:39:40 --> Output Class Initialized
INFO - 2016-09-10 18:39:40 --> Security Class Initialized
DEBUG - 2016-09-10 18:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:39:40 --> Input Class Initialized
INFO - 2016-09-10 18:39:40 --> Language Class Initialized
INFO - 2016-09-10 18:39:41 --> Language Class Initialized
INFO - 2016-09-10 18:39:41 --> Config Class Initialized
INFO - 2016-09-10 18:39:41 --> Loader Class Initialized
INFO - 2016-09-10 18:39:41 --> Helper loaded: url_helper
INFO - 2016-09-10 18:39:41 --> Database Driver Class Initialized
INFO - 2016-09-10 18:39:41 --> Controller Class Initialized
DEBUG - 2016-09-10 18:39:41 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:39:41 --> Model Class Initialized
INFO - 2016-09-10 18:39:41 --> Model Class Initialized
DEBUG - 2016-09-10 18:39:41 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 18:39:41 --> Final output sent to browser
DEBUG - 2016-09-10 18:39:41 --> Total execution time: 0.5816
INFO - 2016-09-10 18:39:48 --> Config Class Initialized
INFO - 2016-09-10 18:39:48 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:39:48 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:39:48 --> Utf8 Class Initialized
INFO - 2016-09-10 18:39:48 --> URI Class Initialized
INFO - 2016-09-10 18:39:48 --> Router Class Initialized
INFO - 2016-09-10 18:39:48 --> Output Class Initialized
INFO - 2016-09-10 18:39:48 --> Security Class Initialized
DEBUG - 2016-09-10 18:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:39:48 --> Input Class Initialized
INFO - 2016-09-10 18:39:48 --> Language Class Initialized
INFO - 2016-09-10 18:39:48 --> Language Class Initialized
INFO - 2016-09-10 18:39:48 --> Config Class Initialized
INFO - 2016-09-10 18:39:48 --> Loader Class Initialized
INFO - 2016-09-10 18:39:48 --> Helper loaded: url_helper
INFO - 2016-09-10 18:39:48 --> Database Driver Class Initialized
INFO - 2016-09-10 18:39:48 --> Controller Class Initialized
DEBUG - 2016-09-10 18:39:48 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:39:48 --> Model Class Initialized
INFO - 2016-09-10 18:39:48 --> Model Class Initialized
DEBUG - 2016-09-10 18:39:48 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 18:39:48 --> Final output sent to browser
DEBUG - 2016-09-10 18:39:48 --> Total execution time: 0.5838
INFO - 2016-09-10 18:40:56 --> Config Class Initialized
INFO - 2016-09-10 18:40:56 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:40:56 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:40:56 --> Utf8 Class Initialized
INFO - 2016-09-10 18:40:56 --> URI Class Initialized
INFO - 2016-09-10 18:40:57 --> Router Class Initialized
INFO - 2016-09-10 18:40:57 --> Output Class Initialized
INFO - 2016-09-10 18:40:57 --> Security Class Initialized
DEBUG - 2016-09-10 18:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:40:57 --> Input Class Initialized
INFO - 2016-09-10 18:40:57 --> Language Class Initialized
INFO - 2016-09-10 18:40:57 --> Language Class Initialized
INFO - 2016-09-10 18:40:57 --> Config Class Initialized
INFO - 2016-09-10 18:40:57 --> Loader Class Initialized
INFO - 2016-09-10 18:40:57 --> Helper loaded: url_helper
INFO - 2016-09-10 18:40:57 --> Database Driver Class Initialized
INFO - 2016-09-10 18:40:57 --> Controller Class Initialized
DEBUG - 2016-09-10 18:40:57 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:40:57 --> Model Class Initialized
INFO - 2016-09-10 18:40:57 --> Model Class Initialized
DEBUG - 2016-09-10 18:40:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-10 18:40:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-10 18:40:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-10 18:40:57 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-10 18:40:57 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-10 18:40:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-10 18:40:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-10 18:40:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-10 18:40:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-10 18:40:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-10 18:40:57 --> Final output sent to browser
DEBUG - 2016-09-10 18:40:57 --> Total execution time: 0.7591
INFO - 2016-09-10 18:41:01 --> Config Class Initialized
INFO - 2016-09-10 18:41:01 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:41:02 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:41:02 --> Utf8 Class Initialized
INFO - 2016-09-10 18:41:02 --> URI Class Initialized
INFO - 2016-09-10 18:41:02 --> Router Class Initialized
INFO - 2016-09-10 18:41:02 --> Output Class Initialized
INFO - 2016-09-10 18:41:02 --> Security Class Initialized
DEBUG - 2016-09-10 18:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:41:02 --> Input Class Initialized
INFO - 2016-09-10 18:41:02 --> Language Class Initialized
INFO - 2016-09-10 18:41:02 --> Language Class Initialized
INFO - 2016-09-10 18:41:02 --> Config Class Initialized
INFO - 2016-09-10 18:41:02 --> Loader Class Initialized
INFO - 2016-09-10 18:41:02 --> Helper loaded: url_helper
INFO - 2016-09-10 18:41:02 --> Database Driver Class Initialized
INFO - 2016-09-10 18:41:02 --> Controller Class Initialized
DEBUG - 2016-09-10 18:41:02 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:41:02 --> Model Class Initialized
INFO - 2016-09-10 18:41:02 --> Model Class Initialized
DEBUG - 2016-09-10 18:41:02 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 18:41:02 --> Final output sent to browser
DEBUG - 2016-09-10 18:41:02 --> Total execution time: 0.9101
INFO - 2016-09-10 18:41:43 --> Config Class Initialized
INFO - 2016-09-10 18:41:43 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:41:43 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:41:43 --> Utf8 Class Initialized
INFO - 2016-09-10 18:41:43 --> URI Class Initialized
INFO - 2016-09-10 18:41:43 --> Router Class Initialized
INFO - 2016-09-10 18:41:43 --> Output Class Initialized
INFO - 2016-09-10 18:41:43 --> Security Class Initialized
DEBUG - 2016-09-10 18:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:41:43 --> Input Class Initialized
INFO - 2016-09-10 18:41:43 --> Language Class Initialized
INFO - 2016-09-10 18:41:43 --> Language Class Initialized
INFO - 2016-09-10 18:41:43 --> Config Class Initialized
INFO - 2016-09-10 18:41:43 --> Loader Class Initialized
INFO - 2016-09-10 18:41:43 --> Helper loaded: url_helper
INFO - 2016-09-10 18:41:43 --> Database Driver Class Initialized
INFO - 2016-09-10 18:41:43 --> Controller Class Initialized
DEBUG - 2016-09-10 18:41:43 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:41:43 --> Model Class Initialized
INFO - 2016-09-10 18:41:43 --> Model Class Initialized
DEBUG - 2016-09-10 18:41:43 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 18:41:44 --> Final output sent to browser
DEBUG - 2016-09-10 18:41:44 --> Total execution time: 0.6228
INFO - 2016-09-10 18:41:51 --> Config Class Initialized
INFO - 2016-09-10 18:41:51 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:41:51 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:41:51 --> Utf8 Class Initialized
INFO - 2016-09-10 18:41:51 --> URI Class Initialized
INFO - 2016-09-10 18:41:51 --> Router Class Initialized
INFO - 2016-09-10 18:41:51 --> Output Class Initialized
INFO - 2016-09-10 18:41:51 --> Security Class Initialized
DEBUG - 2016-09-10 18:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:41:51 --> Input Class Initialized
INFO - 2016-09-10 18:41:51 --> Language Class Initialized
INFO - 2016-09-10 18:41:51 --> Language Class Initialized
INFO - 2016-09-10 18:41:51 --> Config Class Initialized
INFO - 2016-09-10 18:41:51 --> Loader Class Initialized
INFO - 2016-09-10 18:41:51 --> Helper loaded: url_helper
INFO - 2016-09-10 18:41:51 --> Database Driver Class Initialized
INFO - 2016-09-10 18:41:51 --> Controller Class Initialized
DEBUG - 2016-09-10 18:41:51 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:41:51 --> Model Class Initialized
INFO - 2016-09-10 18:41:51 --> Model Class Initialized
DEBUG - 2016-09-10 18:41:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-10 18:41:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-10 18:41:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-10 18:41:51 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-10 18:41:51 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-10 18:41:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-10 18:41:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-10 18:41:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-10 18:41:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-10 18:41:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-10 18:41:51 --> Final output sent to browser
DEBUG - 2016-09-10 18:41:52 --> Total execution time: 0.7587
INFO - 2016-09-10 18:41:57 --> Config Class Initialized
INFO - 2016-09-10 18:41:57 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:41:57 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:41:57 --> Utf8 Class Initialized
INFO - 2016-09-10 18:41:57 --> URI Class Initialized
INFO - 2016-09-10 18:41:57 --> Router Class Initialized
INFO - 2016-09-10 18:41:57 --> Output Class Initialized
INFO - 2016-09-10 18:41:57 --> Security Class Initialized
DEBUG - 2016-09-10 18:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:41:57 --> Input Class Initialized
INFO - 2016-09-10 18:41:57 --> Language Class Initialized
INFO - 2016-09-10 18:41:57 --> Language Class Initialized
INFO - 2016-09-10 18:41:57 --> Config Class Initialized
INFO - 2016-09-10 18:41:57 --> Loader Class Initialized
INFO - 2016-09-10 18:41:57 --> Helper loaded: url_helper
INFO - 2016-09-10 18:41:57 --> Database Driver Class Initialized
INFO - 2016-09-10 18:41:57 --> Controller Class Initialized
DEBUG - 2016-09-10 18:41:57 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:41:58 --> Model Class Initialized
INFO - 2016-09-10 18:41:58 --> Model Class Initialized
DEBUG - 2016-09-10 18:41:58 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 18:41:58 --> Final output sent to browser
DEBUG - 2016-09-10 18:41:58 --> Total execution time: 1.0176
INFO - 2016-09-10 18:42:14 --> Config Class Initialized
INFO - 2016-09-10 18:42:14 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:42:14 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:42:14 --> Utf8 Class Initialized
INFO - 2016-09-10 18:42:14 --> URI Class Initialized
INFO - 2016-09-10 18:42:14 --> Router Class Initialized
INFO - 2016-09-10 18:42:14 --> Output Class Initialized
INFO - 2016-09-10 18:42:14 --> Security Class Initialized
DEBUG - 2016-09-10 18:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:42:14 --> Input Class Initialized
INFO - 2016-09-10 18:42:14 --> Language Class Initialized
INFO - 2016-09-10 18:42:14 --> Language Class Initialized
INFO - 2016-09-10 18:42:14 --> Config Class Initialized
INFO - 2016-09-10 18:42:14 --> Loader Class Initialized
INFO - 2016-09-10 18:42:14 --> Helper loaded: url_helper
INFO - 2016-09-10 18:42:14 --> Database Driver Class Initialized
INFO - 2016-09-10 18:42:14 --> Controller Class Initialized
DEBUG - 2016-09-10 18:42:14 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:42:14 --> Model Class Initialized
INFO - 2016-09-10 18:42:14 --> Model Class Initialized
DEBUG - 2016-09-10 18:42:14 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 18:42:14 --> Final output sent to browser
DEBUG - 2016-09-10 18:42:14 --> Total execution time: 0.5242
INFO - 2016-09-10 18:42:17 --> Config Class Initialized
INFO - 2016-09-10 18:42:17 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:42:17 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:42:18 --> Utf8 Class Initialized
INFO - 2016-09-10 18:42:18 --> URI Class Initialized
INFO - 2016-09-10 18:42:18 --> Router Class Initialized
INFO - 2016-09-10 18:42:18 --> Output Class Initialized
INFO - 2016-09-10 18:42:18 --> Security Class Initialized
DEBUG - 2016-09-10 18:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:42:18 --> Input Class Initialized
INFO - 2016-09-10 18:42:18 --> Language Class Initialized
INFO - 2016-09-10 18:42:18 --> Language Class Initialized
INFO - 2016-09-10 18:42:18 --> Config Class Initialized
INFO - 2016-09-10 18:42:18 --> Loader Class Initialized
INFO - 2016-09-10 18:42:18 --> Helper loaded: url_helper
INFO - 2016-09-10 18:42:18 --> Database Driver Class Initialized
INFO - 2016-09-10 18:42:18 --> Controller Class Initialized
DEBUG - 2016-09-10 18:42:18 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:42:18 --> Model Class Initialized
INFO - 2016-09-10 18:42:18 --> Model Class Initialized
DEBUG - 2016-09-10 18:42:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-10 18:42:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-10 18:42:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-10 18:42:18 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-10 18:42:18 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-10 18:42:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-10 18:42:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-10 18:42:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-10 18:42:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-10 18:42:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-10 18:42:18 --> Final output sent to browser
DEBUG - 2016-09-10 18:42:18 --> Total execution time: 0.8388
INFO - 2016-09-10 18:42:32 --> Config Class Initialized
INFO - 2016-09-10 18:42:32 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:42:32 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:42:32 --> Utf8 Class Initialized
INFO - 2016-09-10 18:42:32 --> URI Class Initialized
INFO - 2016-09-10 18:42:32 --> Router Class Initialized
INFO - 2016-09-10 18:42:32 --> Output Class Initialized
INFO - 2016-09-10 18:42:32 --> Security Class Initialized
DEBUG - 2016-09-10 18:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:42:32 --> Input Class Initialized
INFO - 2016-09-10 18:42:33 --> Language Class Initialized
INFO - 2016-09-10 18:42:33 --> Language Class Initialized
INFO - 2016-09-10 18:42:33 --> Config Class Initialized
INFO - 2016-09-10 18:42:33 --> Loader Class Initialized
INFO - 2016-09-10 18:42:33 --> Helper loaded: url_helper
INFO - 2016-09-10 18:42:33 --> Database Driver Class Initialized
INFO - 2016-09-10 18:42:33 --> Controller Class Initialized
DEBUG - 2016-09-10 18:42:33 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:42:33 --> Model Class Initialized
INFO - 2016-09-10 18:42:33 --> Model Class Initialized
DEBUG - 2016-09-10 18:42:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-10 18:42:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-10 18:42:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-10 18:42:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-10 18:42:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-10 18:42:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-10 18:42:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-10 18:42:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-10 18:42:33 --> Final output sent to browser
DEBUG - 2016-09-10 18:42:33 --> Total execution time: 0.6434
INFO - 2016-09-10 18:43:38 --> Config Class Initialized
INFO - 2016-09-10 18:43:38 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:43:38 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:43:38 --> Utf8 Class Initialized
INFO - 2016-09-10 18:43:38 --> URI Class Initialized
INFO - 2016-09-10 18:43:38 --> Router Class Initialized
INFO - 2016-09-10 18:43:38 --> Output Class Initialized
INFO - 2016-09-10 18:43:38 --> Security Class Initialized
DEBUG - 2016-09-10 18:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:43:38 --> Input Class Initialized
INFO - 2016-09-10 18:43:38 --> Language Class Initialized
INFO - 2016-09-10 18:43:38 --> Language Class Initialized
INFO - 2016-09-10 18:43:38 --> Config Class Initialized
INFO - 2016-09-10 18:43:38 --> Loader Class Initialized
INFO - 2016-09-10 18:43:38 --> Helper loaded: url_helper
INFO - 2016-09-10 18:43:38 --> Database Driver Class Initialized
INFO - 2016-09-10 18:43:38 --> Controller Class Initialized
DEBUG - 2016-09-10 18:43:38 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:43:38 --> Model Class Initialized
INFO - 2016-09-10 18:43:38 --> Model Class Initialized
DEBUG - 2016-09-10 18:43:38 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 18:43:38 --> Final output sent to browser
DEBUG - 2016-09-10 18:43:39 --> Total execution time: 0.6422
INFO - 2016-09-10 18:43:42 --> Config Class Initialized
INFO - 2016-09-10 18:43:42 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:43:42 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:43:42 --> Utf8 Class Initialized
INFO - 2016-09-10 18:43:42 --> URI Class Initialized
INFO - 2016-09-10 18:43:42 --> Router Class Initialized
INFO - 2016-09-10 18:43:42 --> Output Class Initialized
INFO - 2016-09-10 18:43:42 --> Security Class Initialized
DEBUG - 2016-09-10 18:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:43:42 --> Input Class Initialized
INFO - 2016-09-10 18:43:42 --> Language Class Initialized
INFO - 2016-09-10 18:43:42 --> Language Class Initialized
INFO - 2016-09-10 18:43:42 --> Config Class Initialized
INFO - 2016-09-10 18:43:42 --> Loader Class Initialized
INFO - 2016-09-10 18:43:42 --> Helper loaded: url_helper
INFO - 2016-09-10 18:43:42 --> Database Driver Class Initialized
INFO - 2016-09-10 18:43:42 --> Controller Class Initialized
DEBUG - 2016-09-10 18:43:42 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:43:42 --> Model Class Initialized
INFO - 2016-09-10 18:43:42 --> Model Class Initialized
DEBUG - 2016-09-10 18:43:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-10 18:43:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-10 18:43:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-10 18:43:43 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-10 18:43:43 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-10 18:43:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-10 18:43:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-10 18:43:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-10 18:43:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-10 18:43:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-10 18:43:43 --> Final output sent to browser
DEBUG - 2016-09-10 18:43:43 --> Total execution time: 0.7133
INFO - 2016-09-10 18:43:51 --> Config Class Initialized
INFO - 2016-09-10 18:43:51 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:43:51 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:43:51 --> Utf8 Class Initialized
INFO - 2016-09-10 18:43:51 --> URI Class Initialized
INFO - 2016-09-10 18:43:51 --> Router Class Initialized
INFO - 2016-09-10 18:43:51 --> Output Class Initialized
INFO - 2016-09-10 18:43:51 --> Security Class Initialized
DEBUG - 2016-09-10 18:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:43:51 --> Input Class Initialized
INFO - 2016-09-10 18:43:51 --> Language Class Initialized
INFO - 2016-09-10 18:43:52 --> Language Class Initialized
INFO - 2016-09-10 18:43:52 --> Config Class Initialized
INFO - 2016-09-10 18:43:52 --> Loader Class Initialized
INFO - 2016-09-10 18:43:52 --> Helper loaded: url_helper
INFO - 2016-09-10 18:43:52 --> Database Driver Class Initialized
INFO - 2016-09-10 18:43:52 --> Controller Class Initialized
DEBUG - 2016-09-10 18:43:52 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:43:52 --> Model Class Initialized
INFO - 2016-09-10 18:43:52 --> Model Class Initialized
DEBUG - 2016-09-10 18:43:52 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 18:43:52 --> Final output sent to browser
DEBUG - 2016-09-10 18:43:52 --> Total execution time: 0.7063
INFO - 2016-09-10 18:43:57 --> Config Class Initialized
INFO - 2016-09-10 18:43:57 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:43:57 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:43:57 --> Utf8 Class Initialized
INFO - 2016-09-10 18:43:58 --> URI Class Initialized
INFO - 2016-09-10 18:43:58 --> Router Class Initialized
INFO - 2016-09-10 18:43:58 --> Output Class Initialized
INFO - 2016-09-10 18:43:58 --> Security Class Initialized
DEBUG - 2016-09-10 18:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:43:58 --> Input Class Initialized
INFO - 2016-09-10 18:43:58 --> Language Class Initialized
INFO - 2016-09-10 18:43:58 --> Language Class Initialized
INFO - 2016-09-10 18:43:58 --> Config Class Initialized
INFO - 2016-09-10 18:43:58 --> Loader Class Initialized
INFO - 2016-09-10 18:43:58 --> Helper loaded: url_helper
INFO - 2016-09-10 18:43:58 --> Database Driver Class Initialized
INFO - 2016-09-10 18:43:58 --> Controller Class Initialized
DEBUG - 2016-09-10 18:43:58 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:43:58 --> Model Class Initialized
INFO - 2016-09-10 18:43:58 --> Model Class Initialized
DEBUG - 2016-09-10 18:43:58 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 18:43:58 --> Final output sent to browser
DEBUG - 2016-09-10 18:43:58 --> Total execution time: 0.5823
INFO - 2016-09-10 18:44:02 --> Config Class Initialized
INFO - 2016-09-10 18:44:03 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:44:03 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:44:03 --> Utf8 Class Initialized
INFO - 2016-09-10 18:44:03 --> URI Class Initialized
INFO - 2016-09-10 18:44:03 --> Router Class Initialized
INFO - 2016-09-10 18:44:03 --> Output Class Initialized
INFO - 2016-09-10 18:44:03 --> Security Class Initialized
DEBUG - 2016-09-10 18:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:44:03 --> Input Class Initialized
INFO - 2016-09-10 18:44:03 --> Language Class Initialized
INFO - 2016-09-10 18:44:03 --> Language Class Initialized
INFO - 2016-09-10 18:44:03 --> Config Class Initialized
INFO - 2016-09-10 18:44:03 --> Loader Class Initialized
INFO - 2016-09-10 18:44:03 --> Helper loaded: url_helper
INFO - 2016-09-10 18:44:03 --> Database Driver Class Initialized
INFO - 2016-09-10 18:44:03 --> Controller Class Initialized
DEBUG - 2016-09-10 18:44:03 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:44:03 --> Model Class Initialized
INFO - 2016-09-10 18:44:03 --> Model Class Initialized
DEBUG - 2016-09-10 18:44:03 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 18:44:03 --> Final output sent to browser
DEBUG - 2016-09-10 18:44:03 --> Total execution time: 0.7417
INFO - 2016-09-10 18:44:06 --> Config Class Initialized
INFO - 2016-09-10 18:44:06 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:44:06 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:44:06 --> Utf8 Class Initialized
INFO - 2016-09-10 18:44:06 --> URI Class Initialized
INFO - 2016-09-10 18:44:06 --> Router Class Initialized
INFO - 2016-09-10 18:44:06 --> Output Class Initialized
INFO - 2016-09-10 18:44:06 --> Security Class Initialized
DEBUG - 2016-09-10 18:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:44:06 --> Input Class Initialized
INFO - 2016-09-10 18:44:06 --> Language Class Initialized
INFO - 2016-09-10 18:44:06 --> Language Class Initialized
INFO - 2016-09-10 18:44:06 --> Config Class Initialized
INFO - 2016-09-10 18:44:06 --> Loader Class Initialized
INFO - 2016-09-10 18:44:06 --> Helper loaded: url_helper
INFO - 2016-09-10 18:44:06 --> Database Driver Class Initialized
INFO - 2016-09-10 18:44:06 --> Controller Class Initialized
DEBUG - 2016-09-10 18:44:06 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:44:06 --> Model Class Initialized
INFO - 2016-09-10 18:44:06 --> Model Class Initialized
DEBUG - 2016-09-10 18:44:06 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 18:44:06 --> Final output sent to browser
DEBUG - 2016-09-10 18:44:06 --> Total execution time: 0.5687
INFO - 2016-09-10 18:44:09 --> Config Class Initialized
INFO - 2016-09-10 18:44:09 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:44:09 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:44:09 --> Utf8 Class Initialized
INFO - 2016-09-10 18:44:09 --> URI Class Initialized
INFO - 2016-09-10 18:44:09 --> Router Class Initialized
INFO - 2016-09-10 18:44:09 --> Output Class Initialized
INFO - 2016-09-10 18:44:09 --> Security Class Initialized
DEBUG - 2016-09-10 18:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:44:09 --> Input Class Initialized
INFO - 2016-09-10 18:44:09 --> Language Class Initialized
INFO - 2016-09-10 18:44:09 --> Language Class Initialized
INFO - 2016-09-10 18:44:09 --> Config Class Initialized
INFO - 2016-09-10 18:44:09 --> Loader Class Initialized
INFO - 2016-09-10 18:44:09 --> Helper loaded: url_helper
INFO - 2016-09-10 18:44:09 --> Database Driver Class Initialized
INFO - 2016-09-10 18:44:09 --> Controller Class Initialized
DEBUG - 2016-09-10 18:44:09 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:44:09 --> Model Class Initialized
INFO - 2016-09-10 18:44:09 --> Model Class Initialized
DEBUG - 2016-09-10 18:44:09 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 18:44:09 --> Final output sent to browser
DEBUG - 2016-09-10 18:44:09 --> Total execution time: 0.7257
INFO - 2016-09-10 18:44:12 --> Config Class Initialized
INFO - 2016-09-10 18:44:12 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:44:12 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:44:12 --> Utf8 Class Initialized
INFO - 2016-09-10 18:44:12 --> URI Class Initialized
INFO - 2016-09-10 18:44:12 --> Router Class Initialized
INFO - 2016-09-10 18:44:12 --> Output Class Initialized
INFO - 2016-09-10 18:44:12 --> Security Class Initialized
DEBUG - 2016-09-10 18:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:44:12 --> Input Class Initialized
INFO - 2016-09-10 18:44:12 --> Language Class Initialized
INFO - 2016-09-10 18:44:12 --> Language Class Initialized
INFO - 2016-09-10 18:44:12 --> Config Class Initialized
INFO - 2016-09-10 18:44:12 --> Loader Class Initialized
INFO - 2016-09-10 18:44:12 --> Helper loaded: url_helper
INFO - 2016-09-10 18:44:13 --> Database Driver Class Initialized
INFO - 2016-09-10 18:44:13 --> Controller Class Initialized
DEBUG - 2016-09-10 18:44:13 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:44:13 --> Model Class Initialized
INFO - 2016-09-10 18:44:13 --> Model Class Initialized
DEBUG - 2016-09-10 18:44:13 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 18:44:13 --> Final output sent to browser
DEBUG - 2016-09-10 18:44:13 --> Total execution time: 0.6108
INFO - 2016-09-10 18:47:17 --> Config Class Initialized
INFO - 2016-09-10 18:47:17 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:47:17 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:47:17 --> Utf8 Class Initialized
INFO - 2016-09-10 18:47:17 --> URI Class Initialized
INFO - 2016-09-10 18:47:17 --> Router Class Initialized
INFO - 2016-09-10 18:47:17 --> Output Class Initialized
INFO - 2016-09-10 18:47:17 --> Security Class Initialized
DEBUG - 2016-09-10 18:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:47:17 --> Input Class Initialized
INFO - 2016-09-10 18:47:17 --> Language Class Initialized
INFO - 2016-09-10 18:47:17 --> Language Class Initialized
INFO - 2016-09-10 18:47:17 --> Config Class Initialized
INFO - 2016-09-10 18:47:17 --> Loader Class Initialized
INFO - 2016-09-10 18:47:17 --> Helper loaded: url_helper
INFO - 2016-09-10 18:47:17 --> Database Driver Class Initialized
INFO - 2016-09-10 18:47:17 --> Controller Class Initialized
DEBUG - 2016-09-10 18:47:17 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:47:17 --> Model Class Initialized
INFO - 2016-09-10 18:47:17 --> Model Class Initialized
DEBUG - 2016-09-10 18:47:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-10 18:47:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-10 18:47:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-10 18:47:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-10 18:47:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-10 18:47:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-10 18:47:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-10 18:47:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-10 18:47:17 --> Final output sent to browser
DEBUG - 2016-09-10 18:47:18 --> Total execution time: 0.6566
INFO - 2016-09-10 18:47:34 --> Config Class Initialized
INFO - 2016-09-10 18:47:34 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:47:34 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:47:34 --> Utf8 Class Initialized
INFO - 2016-09-10 18:47:34 --> URI Class Initialized
INFO - 2016-09-10 18:47:34 --> Router Class Initialized
INFO - 2016-09-10 18:47:34 --> Output Class Initialized
INFO - 2016-09-10 18:47:34 --> Security Class Initialized
DEBUG - 2016-09-10 18:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:47:34 --> Input Class Initialized
INFO - 2016-09-10 18:47:34 --> Language Class Initialized
INFO - 2016-09-10 18:47:34 --> Language Class Initialized
INFO - 2016-09-10 18:47:34 --> Config Class Initialized
INFO - 2016-09-10 18:47:34 --> Loader Class Initialized
INFO - 2016-09-10 18:47:34 --> Helper loaded: url_helper
INFO - 2016-09-10 18:47:34 --> Database Driver Class Initialized
INFO - 2016-09-10 18:47:35 --> Controller Class Initialized
DEBUG - 2016-09-10 18:47:35 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:47:35 --> Model Class Initialized
INFO - 2016-09-10 18:47:35 --> Model Class Initialized
DEBUG - 2016-09-10 18:47:35 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 18:47:35 --> Final output sent to browser
DEBUG - 2016-09-10 18:47:35 --> Total execution time: 0.5768
INFO - 2016-09-10 18:48:07 --> Config Class Initialized
INFO - 2016-09-10 18:48:07 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:48:07 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:48:07 --> Utf8 Class Initialized
INFO - 2016-09-10 18:48:07 --> URI Class Initialized
INFO - 2016-09-10 18:48:07 --> Router Class Initialized
INFO - 2016-09-10 18:48:07 --> Output Class Initialized
INFO - 2016-09-10 18:48:08 --> Security Class Initialized
DEBUG - 2016-09-10 18:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:48:08 --> Input Class Initialized
INFO - 2016-09-10 18:48:08 --> Language Class Initialized
INFO - 2016-09-10 18:48:08 --> Language Class Initialized
INFO - 2016-09-10 18:48:08 --> Config Class Initialized
INFO - 2016-09-10 18:48:08 --> Loader Class Initialized
INFO - 2016-09-10 18:48:08 --> Helper loaded: url_helper
INFO - 2016-09-10 18:48:08 --> Database Driver Class Initialized
INFO - 2016-09-10 18:48:08 --> Controller Class Initialized
DEBUG - 2016-09-10 18:48:08 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:48:08 --> Model Class Initialized
INFO - 2016-09-10 18:48:08 --> Model Class Initialized
DEBUG - 2016-09-10 18:48:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-10 18:48:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-10 18:48:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-10 18:48:08 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-10 18:48:08 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-10 18:48:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-10 18:48:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-10 18:48:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-10 18:48:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-10 18:48:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-10 18:48:08 --> Final output sent to browser
DEBUG - 2016-09-10 18:48:08 --> Total execution time: 0.7472
INFO - 2016-09-10 18:48:15 --> Config Class Initialized
INFO - 2016-09-10 18:48:15 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:48:15 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:48:15 --> Utf8 Class Initialized
INFO - 2016-09-10 18:48:15 --> URI Class Initialized
INFO - 2016-09-10 18:48:15 --> Router Class Initialized
INFO - 2016-09-10 18:48:15 --> Output Class Initialized
INFO - 2016-09-10 18:48:15 --> Security Class Initialized
DEBUG - 2016-09-10 18:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:48:15 --> Input Class Initialized
INFO - 2016-09-10 18:48:15 --> Language Class Initialized
INFO - 2016-09-10 18:48:15 --> Language Class Initialized
INFO - 2016-09-10 18:48:15 --> Config Class Initialized
INFO - 2016-09-10 18:48:16 --> Loader Class Initialized
INFO - 2016-09-10 18:48:16 --> Helper loaded: url_helper
INFO - 2016-09-10 18:48:16 --> Database Driver Class Initialized
INFO - 2016-09-10 18:48:16 --> Controller Class Initialized
DEBUG - 2016-09-10 18:48:16 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:48:16 --> Model Class Initialized
INFO - 2016-09-10 18:48:16 --> Model Class Initialized
DEBUG - 2016-09-10 18:48:16 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 18:48:16 --> Final output sent to browser
DEBUG - 2016-09-10 18:48:16 --> Total execution time: 0.5880
INFO - 2016-09-10 18:48:21 --> Config Class Initialized
INFO - 2016-09-10 18:48:21 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:48:21 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:48:21 --> Utf8 Class Initialized
INFO - 2016-09-10 18:48:21 --> URI Class Initialized
INFO - 2016-09-10 18:48:21 --> Router Class Initialized
INFO - 2016-09-10 18:48:21 --> Output Class Initialized
INFO - 2016-09-10 18:48:21 --> Security Class Initialized
DEBUG - 2016-09-10 18:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:48:21 --> Input Class Initialized
INFO - 2016-09-10 18:48:21 --> Language Class Initialized
INFO - 2016-09-10 18:48:21 --> Language Class Initialized
INFO - 2016-09-10 18:48:21 --> Config Class Initialized
INFO - 2016-09-10 18:48:21 --> Loader Class Initialized
INFO - 2016-09-10 18:48:21 --> Helper loaded: url_helper
INFO - 2016-09-10 18:48:21 --> Database Driver Class Initialized
INFO - 2016-09-10 18:48:21 --> Controller Class Initialized
DEBUG - 2016-09-10 18:48:21 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:48:21 --> Model Class Initialized
INFO - 2016-09-10 18:48:21 --> Model Class Initialized
DEBUG - 2016-09-10 18:48:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-10 18:48:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-10 18:48:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-10 18:48:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-10 18:48:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-10 18:48:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-10 18:48:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-10 18:48:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-10 18:48:21 --> Final output sent to browser
DEBUG - 2016-09-10 18:48:21 --> Total execution time: 0.6494
INFO - 2016-09-10 18:48:37 --> Config Class Initialized
INFO - 2016-09-10 18:48:37 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:48:38 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:48:38 --> Utf8 Class Initialized
INFO - 2016-09-10 18:48:38 --> URI Class Initialized
INFO - 2016-09-10 18:48:38 --> Router Class Initialized
INFO - 2016-09-10 18:48:38 --> Output Class Initialized
INFO - 2016-09-10 18:48:38 --> Security Class Initialized
DEBUG - 2016-09-10 18:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:48:38 --> Input Class Initialized
INFO - 2016-09-10 18:48:38 --> Language Class Initialized
INFO - 2016-09-10 18:48:38 --> Language Class Initialized
INFO - 2016-09-10 18:48:38 --> Config Class Initialized
INFO - 2016-09-10 18:48:38 --> Loader Class Initialized
INFO - 2016-09-10 18:48:38 --> Helper loaded: url_helper
INFO - 2016-09-10 18:48:38 --> Database Driver Class Initialized
INFO - 2016-09-10 18:48:38 --> Controller Class Initialized
DEBUG - 2016-09-10 18:48:38 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:48:38 --> Model Class Initialized
INFO - 2016-09-10 18:48:38 --> Model Class Initialized
DEBUG - 2016-09-10 18:48:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-10 18:48:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-10 18:48:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-10 18:48:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-10 18:48:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-10 18:48:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-10 18:48:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-10 18:48:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-10 18:48:38 --> Final output sent to browser
DEBUG - 2016-09-10 18:48:38 --> Total execution time: 0.6754
INFO - 2016-09-10 18:50:06 --> Config Class Initialized
INFO - 2016-09-10 18:50:06 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:50:06 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:50:06 --> Utf8 Class Initialized
INFO - 2016-09-10 18:50:06 --> URI Class Initialized
INFO - 2016-09-10 18:50:06 --> Router Class Initialized
INFO - 2016-09-10 18:50:06 --> Output Class Initialized
INFO - 2016-09-10 18:50:06 --> Security Class Initialized
DEBUG - 2016-09-10 18:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:50:06 --> Input Class Initialized
INFO - 2016-09-10 18:50:06 --> Language Class Initialized
INFO - 2016-09-10 18:50:06 --> Language Class Initialized
INFO - 2016-09-10 18:50:06 --> Config Class Initialized
INFO - 2016-09-10 18:50:06 --> Loader Class Initialized
INFO - 2016-09-10 18:50:06 --> Helper loaded: url_helper
INFO - 2016-09-10 18:50:06 --> Database Driver Class Initialized
INFO - 2016-09-10 18:50:06 --> Controller Class Initialized
DEBUG - 2016-09-10 18:50:06 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:50:06 --> Model Class Initialized
INFO - 2016-09-10 18:50:06 --> Model Class Initialized
DEBUG - 2016-09-10 18:50:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-10 18:50:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-10 18:50:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-10 18:50:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-10 18:50:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-10 18:50:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-10 18:50:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-10 18:50:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-10 18:50:06 --> Final output sent to browser
DEBUG - 2016-09-10 18:50:06 --> Total execution time: 0.7814
INFO - 2016-09-10 18:50:15 --> Config Class Initialized
INFO - 2016-09-10 18:50:15 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:50:15 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:50:15 --> Utf8 Class Initialized
INFO - 2016-09-10 18:50:15 --> URI Class Initialized
INFO - 2016-09-10 18:50:15 --> Router Class Initialized
INFO - 2016-09-10 18:50:15 --> Output Class Initialized
INFO - 2016-09-10 18:50:16 --> Security Class Initialized
DEBUG - 2016-09-10 18:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:50:16 --> Input Class Initialized
INFO - 2016-09-10 18:50:16 --> Language Class Initialized
INFO - 2016-09-10 18:50:16 --> Language Class Initialized
INFO - 2016-09-10 18:50:16 --> Config Class Initialized
INFO - 2016-09-10 18:50:16 --> Loader Class Initialized
INFO - 2016-09-10 18:50:16 --> Helper loaded: url_helper
INFO - 2016-09-10 18:50:16 --> Database Driver Class Initialized
INFO - 2016-09-10 18:50:16 --> Controller Class Initialized
DEBUG - 2016-09-10 18:50:16 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:50:16 --> Model Class Initialized
INFO - 2016-09-10 18:50:16 --> Model Class Initialized
DEBUG - 2016-09-10 18:50:16 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 18:50:16 --> Final output sent to browser
DEBUG - 2016-09-10 18:50:16 --> Total execution time: 0.7526
INFO - 2016-09-10 18:50:22 --> Config Class Initialized
INFO - 2016-09-10 18:50:22 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:50:22 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:50:22 --> Utf8 Class Initialized
INFO - 2016-09-10 18:50:22 --> URI Class Initialized
INFO - 2016-09-10 18:50:22 --> Router Class Initialized
INFO - 2016-09-10 18:50:22 --> Output Class Initialized
INFO - 2016-09-10 18:50:22 --> Security Class Initialized
DEBUG - 2016-09-10 18:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:50:22 --> Input Class Initialized
INFO - 2016-09-10 18:50:22 --> Language Class Initialized
INFO - 2016-09-10 18:50:23 --> Language Class Initialized
INFO - 2016-09-10 18:50:23 --> Config Class Initialized
INFO - 2016-09-10 18:50:23 --> Loader Class Initialized
INFO - 2016-09-10 18:50:23 --> Helper loaded: url_helper
INFO - 2016-09-10 18:50:23 --> Database Driver Class Initialized
INFO - 2016-09-10 18:50:23 --> Controller Class Initialized
DEBUG - 2016-09-10 18:50:23 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:50:23 --> Model Class Initialized
INFO - 2016-09-10 18:50:23 --> Model Class Initialized
DEBUG - 2016-09-10 18:50:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-10 18:50:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-10 18:50:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-10 18:50:23 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-10 18:50:23 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-10 18:50:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-10 18:50:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-10 18:50:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-10 18:50:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-10 18:50:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-10 18:50:23 --> Final output sent to browser
DEBUG - 2016-09-10 18:50:23 --> Total execution time: 0.8748
INFO - 2016-09-10 18:50:30 --> Config Class Initialized
INFO - 2016-09-10 18:50:30 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:50:30 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:50:30 --> Utf8 Class Initialized
INFO - 2016-09-10 18:50:30 --> URI Class Initialized
INFO - 2016-09-10 18:50:30 --> Router Class Initialized
INFO - 2016-09-10 18:50:30 --> Output Class Initialized
INFO - 2016-09-10 18:50:30 --> Security Class Initialized
DEBUG - 2016-09-10 18:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:50:30 --> Input Class Initialized
INFO - 2016-09-10 18:50:30 --> Language Class Initialized
INFO - 2016-09-10 18:50:30 --> Language Class Initialized
INFO - 2016-09-10 18:50:30 --> Config Class Initialized
INFO - 2016-09-10 18:50:30 --> Loader Class Initialized
INFO - 2016-09-10 18:50:30 --> Helper loaded: url_helper
INFO - 2016-09-10 18:50:30 --> Database Driver Class Initialized
INFO - 2016-09-10 18:50:30 --> Controller Class Initialized
DEBUG - 2016-09-10 18:50:30 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:50:30 --> Model Class Initialized
INFO - 2016-09-10 18:50:30 --> Model Class Initialized
DEBUG - 2016-09-10 18:50:30 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 18:50:31 --> Final output sent to browser
DEBUG - 2016-09-10 18:50:31 --> Total execution time: 0.5893
INFO - 2016-09-10 18:50:34 --> Config Class Initialized
INFO - 2016-09-10 18:50:34 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:50:34 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:50:34 --> Utf8 Class Initialized
INFO - 2016-09-10 18:50:34 --> URI Class Initialized
INFO - 2016-09-10 18:50:34 --> Router Class Initialized
INFO - 2016-09-10 18:50:34 --> Output Class Initialized
INFO - 2016-09-10 18:50:34 --> Security Class Initialized
DEBUG - 2016-09-10 18:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:50:34 --> Input Class Initialized
INFO - 2016-09-10 18:50:34 --> Language Class Initialized
INFO - 2016-09-10 18:50:34 --> Language Class Initialized
INFO - 2016-09-10 18:50:34 --> Config Class Initialized
INFO - 2016-09-10 18:50:34 --> Loader Class Initialized
INFO - 2016-09-10 18:50:34 --> Helper loaded: url_helper
INFO - 2016-09-10 18:50:34 --> Database Driver Class Initialized
INFO - 2016-09-10 18:50:34 --> Controller Class Initialized
DEBUG - 2016-09-10 18:50:34 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:50:34 --> Model Class Initialized
INFO - 2016-09-10 18:50:34 --> Model Class Initialized
DEBUG - 2016-09-10 18:50:34 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 18:50:35 --> Final output sent to browser
DEBUG - 2016-09-10 18:50:35 --> Total execution time: 0.8113
INFO - 2016-09-10 18:50:39 --> Config Class Initialized
INFO - 2016-09-10 18:50:39 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:50:39 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:50:39 --> Utf8 Class Initialized
INFO - 2016-09-10 18:50:39 --> URI Class Initialized
INFO - 2016-09-10 18:50:39 --> Router Class Initialized
INFO - 2016-09-10 18:50:39 --> Output Class Initialized
INFO - 2016-09-10 18:50:39 --> Security Class Initialized
DEBUG - 2016-09-10 18:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:50:39 --> Input Class Initialized
INFO - 2016-09-10 18:50:39 --> Language Class Initialized
INFO - 2016-09-10 18:50:39 --> Language Class Initialized
INFO - 2016-09-10 18:50:39 --> Config Class Initialized
INFO - 2016-09-10 18:50:39 --> Loader Class Initialized
INFO - 2016-09-10 18:50:39 --> Helper loaded: url_helper
INFO - 2016-09-10 18:50:39 --> Database Driver Class Initialized
INFO - 2016-09-10 18:50:39 --> Controller Class Initialized
DEBUG - 2016-09-10 18:50:39 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:50:39 --> Model Class Initialized
INFO - 2016-09-10 18:50:39 --> Model Class Initialized
DEBUG - 2016-09-10 18:50:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-10 18:50:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-10 18:50:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-10 18:50:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-10 18:50:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-10 18:50:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-10 18:50:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-10 18:50:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-10 18:50:39 --> Final output sent to browser
DEBUG - 2016-09-10 18:50:39 --> Total execution time: 0.6816
INFO - 2016-09-10 18:51:01 --> Config Class Initialized
INFO - 2016-09-10 18:51:01 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:51:01 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:51:01 --> Utf8 Class Initialized
INFO - 2016-09-10 18:51:01 --> URI Class Initialized
INFO - 2016-09-10 18:51:01 --> Router Class Initialized
INFO - 2016-09-10 18:51:01 --> Output Class Initialized
INFO - 2016-09-10 18:51:01 --> Security Class Initialized
DEBUG - 2016-09-10 18:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:51:01 --> Input Class Initialized
INFO - 2016-09-10 18:51:01 --> Language Class Initialized
INFO - 2016-09-10 18:51:01 --> Language Class Initialized
INFO - 2016-09-10 18:51:01 --> Config Class Initialized
INFO - 2016-09-10 18:51:01 --> Loader Class Initialized
INFO - 2016-09-10 18:51:01 --> Helper loaded: url_helper
INFO - 2016-09-10 18:51:01 --> Database Driver Class Initialized
INFO - 2016-09-10 18:51:01 --> Controller Class Initialized
DEBUG - 2016-09-10 18:51:01 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:51:01 --> Model Class Initialized
INFO - 2016-09-10 18:51:01 --> Model Class Initialized
DEBUG - 2016-09-10 18:51:01 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 18:51:01 --> Final output sent to browser
DEBUG - 2016-09-10 18:51:01 --> Total execution time: 0.6769
INFO - 2016-09-10 18:51:05 --> Config Class Initialized
INFO - 2016-09-10 18:51:05 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:51:05 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:51:05 --> Utf8 Class Initialized
INFO - 2016-09-10 18:51:05 --> URI Class Initialized
INFO - 2016-09-10 18:51:05 --> Router Class Initialized
INFO - 2016-09-10 18:51:05 --> Output Class Initialized
INFO - 2016-09-10 18:51:05 --> Security Class Initialized
DEBUG - 2016-09-10 18:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:51:05 --> Input Class Initialized
INFO - 2016-09-10 18:51:05 --> Language Class Initialized
INFO - 2016-09-10 18:51:05 --> Language Class Initialized
INFO - 2016-09-10 18:51:05 --> Config Class Initialized
INFO - 2016-09-10 18:51:05 --> Loader Class Initialized
INFO - 2016-09-10 18:51:05 --> Helper loaded: url_helper
INFO - 2016-09-10 18:51:05 --> Database Driver Class Initialized
INFO - 2016-09-10 18:51:05 --> Controller Class Initialized
DEBUG - 2016-09-10 18:51:05 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:51:05 --> Model Class Initialized
INFO - 2016-09-10 18:51:06 --> Model Class Initialized
DEBUG - 2016-09-10 18:51:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-10 18:51:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-10 18:51:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-10 18:51:06 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-10 18:51:06 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-10 18:51:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-10 18:51:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-10 18:51:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-10 18:51:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-10 18:51:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-10 18:51:06 --> Final output sent to browser
DEBUG - 2016-09-10 18:51:06 --> Total execution time: 0.8861
INFO - 2016-09-10 18:51:23 --> Config Class Initialized
INFO - 2016-09-10 18:51:23 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:51:23 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:51:23 --> Utf8 Class Initialized
INFO - 2016-09-10 18:51:23 --> URI Class Initialized
INFO - 2016-09-10 18:51:23 --> Router Class Initialized
INFO - 2016-09-10 18:51:23 --> Output Class Initialized
INFO - 2016-09-10 18:51:23 --> Security Class Initialized
DEBUG - 2016-09-10 18:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:51:23 --> Input Class Initialized
INFO - 2016-09-10 18:51:23 --> Language Class Initialized
INFO - 2016-09-10 18:51:23 --> Language Class Initialized
INFO - 2016-09-10 18:51:23 --> Config Class Initialized
INFO - 2016-09-10 18:51:23 --> Loader Class Initialized
INFO - 2016-09-10 18:51:23 --> Helper loaded: url_helper
INFO - 2016-09-10 18:51:23 --> Database Driver Class Initialized
INFO - 2016-09-10 18:51:23 --> Controller Class Initialized
DEBUG - 2016-09-10 18:51:23 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:51:23 --> Model Class Initialized
INFO - 2016-09-10 18:51:23 --> Model Class Initialized
DEBUG - 2016-09-10 18:51:23 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 18:51:23 --> Final output sent to browser
DEBUG - 2016-09-10 18:51:23 --> Total execution time: 0.6882
INFO - 2016-09-10 18:54:14 --> Config Class Initialized
INFO - 2016-09-10 18:54:14 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:54:14 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:54:15 --> Utf8 Class Initialized
INFO - 2016-09-10 18:54:15 --> URI Class Initialized
INFO - 2016-09-10 18:54:15 --> Router Class Initialized
INFO - 2016-09-10 18:54:15 --> Output Class Initialized
INFO - 2016-09-10 18:54:15 --> Security Class Initialized
DEBUG - 2016-09-10 18:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:54:15 --> Input Class Initialized
INFO - 2016-09-10 18:54:15 --> Language Class Initialized
INFO - 2016-09-10 18:54:15 --> Language Class Initialized
INFO - 2016-09-10 18:54:15 --> Config Class Initialized
INFO - 2016-09-10 18:54:15 --> Loader Class Initialized
INFO - 2016-09-10 18:54:15 --> Helper loaded: url_helper
INFO - 2016-09-10 18:54:15 --> Database Driver Class Initialized
INFO - 2016-09-10 18:54:15 --> Controller Class Initialized
DEBUG - 2016-09-10 18:54:15 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:54:15 --> Model Class Initialized
INFO - 2016-09-10 18:54:15 --> Model Class Initialized
DEBUG - 2016-09-10 18:54:15 --> Anggota MX_Controller Initialized
ERROR - 2016-09-10 18:54:15 --> Query error: Unknown column 'noidentitas' in 'where clause' - Invalid query: SELECT *
FROM `tm_anggota`
WHERE `noidentitas` = '3573032002930011'
INFO - 2016-09-10 18:54:15 --> Language file loaded: language/english/db_lang.php
INFO - 2016-09-10 18:54:20 --> Config Class Initialized
INFO - 2016-09-10 18:54:20 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:54:20 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:54:20 --> Utf8 Class Initialized
INFO - 2016-09-10 18:54:20 --> URI Class Initialized
INFO - 2016-09-10 18:54:20 --> Router Class Initialized
INFO - 2016-09-10 18:54:20 --> Output Class Initialized
INFO - 2016-09-10 18:54:20 --> Security Class Initialized
DEBUG - 2016-09-10 18:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:54:20 --> Input Class Initialized
INFO - 2016-09-10 18:54:20 --> Language Class Initialized
INFO - 2016-09-10 18:54:20 --> Language Class Initialized
INFO - 2016-09-10 18:54:20 --> Config Class Initialized
INFO - 2016-09-10 18:54:20 --> Loader Class Initialized
INFO - 2016-09-10 18:54:20 --> Helper loaded: url_helper
INFO - 2016-09-10 18:54:20 --> Database Driver Class Initialized
INFO - 2016-09-10 18:54:20 --> Controller Class Initialized
DEBUG - 2016-09-10 18:54:20 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:54:20 --> Model Class Initialized
INFO - 2016-09-10 18:54:20 --> Model Class Initialized
DEBUG - 2016-09-10 18:54:20 --> Anggota MX_Controller Initialized
ERROR - 2016-09-10 18:54:20 --> Query error: Unknown column 'noidentitas' in 'where clause' - Invalid query: SELECT *
FROM `tm_anggota`
WHERE `noidentitas` = '3573032002930011'
INFO - 2016-09-10 18:54:21 --> Language file loaded: language/english/db_lang.php
INFO - 2016-09-10 18:54:31 --> Config Class Initialized
INFO - 2016-09-10 18:54:31 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:54:31 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:54:31 --> Utf8 Class Initialized
INFO - 2016-09-10 18:54:31 --> URI Class Initialized
INFO - 2016-09-10 18:54:31 --> Router Class Initialized
INFO - 2016-09-10 18:54:31 --> Output Class Initialized
INFO - 2016-09-10 18:54:31 --> Security Class Initialized
DEBUG - 2016-09-10 18:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:54:31 --> Input Class Initialized
INFO - 2016-09-10 18:54:31 --> Language Class Initialized
INFO - 2016-09-10 18:54:31 --> Language Class Initialized
INFO - 2016-09-10 18:54:31 --> Config Class Initialized
INFO - 2016-09-10 18:54:31 --> Loader Class Initialized
INFO - 2016-09-10 18:54:31 --> Helper loaded: url_helper
INFO - 2016-09-10 18:54:31 --> Database Driver Class Initialized
INFO - 2016-09-10 18:54:31 --> Controller Class Initialized
DEBUG - 2016-09-10 18:54:31 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:54:31 --> Model Class Initialized
INFO - 2016-09-10 18:54:31 --> Model Class Initialized
DEBUG - 2016-09-10 18:54:31 --> Anggota MX_Controller Initialized
ERROR - 2016-09-10 18:54:31 --> Query error: Unknown column 'noidentitas' in 'where clause' - Invalid query: SELECT *
FROM `tm_anggota`
WHERE `noidentitas` = '3573032002930011'
INFO - 2016-09-10 18:54:31 --> Language file loaded: language/english/db_lang.php
INFO - 2016-09-10 18:54:50 --> Config Class Initialized
INFO - 2016-09-10 18:54:50 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:54:50 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:54:50 --> Utf8 Class Initialized
INFO - 2016-09-10 18:54:50 --> URI Class Initialized
INFO - 2016-09-10 18:54:50 --> Router Class Initialized
INFO - 2016-09-10 18:54:50 --> Output Class Initialized
INFO - 2016-09-10 18:54:50 --> Security Class Initialized
DEBUG - 2016-09-10 18:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:54:50 --> Input Class Initialized
INFO - 2016-09-10 18:54:50 --> Language Class Initialized
INFO - 2016-09-10 18:54:50 --> Language Class Initialized
INFO - 2016-09-10 18:54:50 --> Config Class Initialized
INFO - 2016-09-10 18:54:50 --> Loader Class Initialized
INFO - 2016-09-10 18:54:50 --> Helper loaded: url_helper
INFO - 2016-09-10 18:54:50 --> Database Driver Class Initialized
INFO - 2016-09-10 18:54:50 --> Controller Class Initialized
DEBUG - 2016-09-10 18:54:50 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:54:50 --> Model Class Initialized
INFO - 2016-09-10 18:54:50 --> Model Class Initialized
DEBUG - 2016-09-10 18:54:50 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 18:54:50 --> Final output sent to browser
DEBUG - 2016-09-10 18:54:50 --> Total execution time: 0.5992
INFO - 2016-09-10 18:55:06 --> Config Class Initialized
INFO - 2016-09-10 18:55:06 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:55:06 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:55:06 --> Utf8 Class Initialized
INFO - 2016-09-10 18:55:06 --> URI Class Initialized
INFO - 2016-09-10 18:55:06 --> Router Class Initialized
INFO - 2016-09-10 18:55:06 --> Output Class Initialized
INFO - 2016-09-10 18:55:06 --> Security Class Initialized
DEBUG - 2016-09-10 18:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:55:06 --> Input Class Initialized
INFO - 2016-09-10 18:55:06 --> Language Class Initialized
INFO - 2016-09-10 18:55:06 --> Language Class Initialized
INFO - 2016-09-10 18:55:06 --> Config Class Initialized
INFO - 2016-09-10 18:55:06 --> Loader Class Initialized
INFO - 2016-09-10 18:55:06 --> Helper loaded: url_helper
INFO - 2016-09-10 18:55:06 --> Database Driver Class Initialized
INFO - 2016-09-10 18:55:06 --> Controller Class Initialized
DEBUG - 2016-09-10 18:55:06 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:55:06 --> Model Class Initialized
INFO - 2016-09-10 18:55:06 --> Model Class Initialized
DEBUG - 2016-09-10 18:55:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-10 18:55:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-10 18:55:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-10 18:55:06 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-10 18:55:06 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-10 18:55:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-10 18:55:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-10 18:55:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-10 18:55:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-10 18:55:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-10 18:55:06 --> Final output sent to browser
DEBUG - 2016-09-10 18:55:06 --> Total execution time: 0.7677
INFO - 2016-09-10 18:55:29 --> Config Class Initialized
INFO - 2016-09-10 18:55:29 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:55:30 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:55:30 --> Utf8 Class Initialized
INFO - 2016-09-10 18:55:30 --> URI Class Initialized
INFO - 2016-09-10 18:55:30 --> Router Class Initialized
INFO - 2016-09-10 18:55:30 --> Output Class Initialized
INFO - 2016-09-10 18:55:30 --> Security Class Initialized
DEBUG - 2016-09-10 18:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:55:30 --> Input Class Initialized
INFO - 2016-09-10 18:55:30 --> Language Class Initialized
INFO - 2016-09-10 18:55:30 --> Language Class Initialized
INFO - 2016-09-10 18:55:30 --> Config Class Initialized
INFO - 2016-09-10 18:55:30 --> Loader Class Initialized
INFO - 2016-09-10 18:55:30 --> Helper loaded: url_helper
INFO - 2016-09-10 18:55:30 --> Database Driver Class Initialized
INFO - 2016-09-10 18:55:30 --> Controller Class Initialized
DEBUG - 2016-09-10 18:55:30 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:55:30 --> Model Class Initialized
INFO - 2016-09-10 18:55:30 --> Model Class Initialized
DEBUG - 2016-09-10 18:55:30 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 18:55:30 --> Final output sent to browser
DEBUG - 2016-09-10 18:55:30 --> Total execution time: 0.5305
INFO - 2016-09-10 18:55:31 --> Config Class Initialized
INFO - 2016-09-10 18:55:31 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:55:31 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:55:31 --> Utf8 Class Initialized
INFO - 2016-09-10 18:55:31 --> URI Class Initialized
INFO - 2016-09-10 18:55:31 --> Router Class Initialized
INFO - 2016-09-10 18:55:31 --> Output Class Initialized
INFO - 2016-09-10 18:55:31 --> Security Class Initialized
DEBUG - 2016-09-10 18:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:55:31 --> Input Class Initialized
INFO - 2016-09-10 18:55:31 --> Language Class Initialized
INFO - 2016-09-10 18:55:31 --> Language Class Initialized
INFO - 2016-09-10 18:55:31 --> Config Class Initialized
INFO - 2016-09-10 18:55:31 --> Loader Class Initialized
INFO - 2016-09-10 18:55:31 --> Helper loaded: url_helper
INFO - 2016-09-10 18:55:31 --> Database Driver Class Initialized
INFO - 2016-09-10 18:55:31 --> Controller Class Initialized
DEBUG - 2016-09-10 18:55:31 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:55:31 --> Model Class Initialized
INFO - 2016-09-10 18:55:31 --> Model Class Initialized
DEBUG - 2016-09-10 18:55:31 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 18:55:31 --> Final output sent to browser
DEBUG - 2016-09-10 18:55:31 --> Total execution time: 0.5653
INFO - 2016-09-10 18:55:32 --> Config Class Initialized
INFO - 2016-09-10 18:55:32 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:55:32 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:55:32 --> Utf8 Class Initialized
INFO - 2016-09-10 18:55:32 --> URI Class Initialized
INFO - 2016-09-10 18:55:32 --> Router Class Initialized
INFO - 2016-09-10 18:55:32 --> Output Class Initialized
INFO - 2016-09-10 18:55:32 --> Security Class Initialized
DEBUG - 2016-09-10 18:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:55:32 --> Input Class Initialized
INFO - 2016-09-10 18:55:32 --> Language Class Initialized
INFO - 2016-09-10 18:55:32 --> Language Class Initialized
INFO - 2016-09-10 18:55:32 --> Config Class Initialized
INFO - 2016-09-10 18:55:32 --> Loader Class Initialized
INFO - 2016-09-10 18:55:32 --> Helper loaded: url_helper
INFO - 2016-09-10 18:55:32 --> Database Driver Class Initialized
INFO - 2016-09-10 18:55:33 --> Controller Class Initialized
DEBUG - 2016-09-10 18:55:33 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:55:33 --> Model Class Initialized
INFO - 2016-09-10 18:55:33 --> Model Class Initialized
DEBUG - 2016-09-10 18:55:33 --> Anggota MX_Controller Initialized
INFO - 2016-09-10 18:55:33 --> Final output sent to browser
DEBUG - 2016-09-10 18:55:33 --> Total execution time: 0.5416
INFO - 2016-09-10 18:55:53 --> Config Class Initialized
INFO - 2016-09-10 18:55:53 --> Hooks Class Initialized
DEBUG - 2016-09-10 18:55:53 --> UTF-8 Support Enabled
INFO - 2016-09-10 18:55:53 --> Utf8 Class Initialized
INFO - 2016-09-10 18:55:53 --> URI Class Initialized
INFO - 2016-09-10 18:55:53 --> Router Class Initialized
INFO - 2016-09-10 18:55:53 --> Output Class Initialized
INFO - 2016-09-10 18:55:53 --> Security Class Initialized
DEBUG - 2016-09-10 18:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-10 18:55:53 --> Input Class Initialized
INFO - 2016-09-10 18:55:53 --> Language Class Initialized
INFO - 2016-09-10 18:55:53 --> Language Class Initialized
INFO - 2016-09-10 18:55:53 --> Config Class Initialized
INFO - 2016-09-10 18:55:53 --> Loader Class Initialized
INFO - 2016-09-10 18:55:53 --> Helper loaded: url_helper
INFO - 2016-09-10 18:55:53 --> Database Driver Class Initialized
INFO - 2016-09-10 18:55:54 --> Controller Class Initialized
DEBUG - 2016-09-10 18:55:54 --> Index MX_Controller Initialized
INFO - 2016-09-10 18:55:54 --> Model Class Initialized
INFO - 2016-09-10 18:55:54 --> Model Class Initialized
DEBUG - 2016-09-10 18:55:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-10 18:55:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-10 18:55:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-10 18:55:54 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-10 18:55:54 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-10 18:55:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-10 18:55:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-10 18:55:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-10 18:55:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-10 18:55:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-10 18:55:54 --> Final output sent to browser
DEBUG - 2016-09-10 18:55:54 --> Total execution time: 0.7965
