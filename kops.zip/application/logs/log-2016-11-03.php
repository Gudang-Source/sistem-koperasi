<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-11-03 04:21:50 --> Config Class Initialized
INFO - 2016-11-03 04:21:50 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:21:51 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:21:51 --> Utf8 Class Initialized
INFO - 2016-11-03 04:21:51 --> URI Class Initialized
DEBUG - 2016-11-03 04:21:51 --> No URI present. Default controller set.
INFO - 2016-11-03 04:21:51 --> Router Class Initialized
INFO - 2016-11-03 04:21:51 --> Output Class Initialized
INFO - 2016-11-03 04:21:51 --> Security Class Initialized
DEBUG - 2016-11-03 04:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:21:51 --> Input Class Initialized
INFO - 2016-11-03 04:21:52 --> Language Class Initialized
INFO - 2016-11-03 04:21:52 --> Language Class Initialized
INFO - 2016-11-03 04:21:52 --> Config Class Initialized
INFO - 2016-11-03 04:21:52 --> Loader Class Initialized
INFO - 2016-11-03 04:21:52 --> Helper loaded: url_helper
INFO - 2016-11-03 04:21:53 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:21:53 --> Controller Class Initialized
DEBUG - 2016-11-03 04:21:53 --> Index MX_Controller Initialized
INFO - 2016-11-03 04:21:53 --> Model Class Initialized
INFO - 2016-11-03 04:21:53 --> Model Class Initialized
ERROR - 2016-11-03 04:21:53 --> Unable to delete cache file for 
DEBUG - 2016-11-03 04:21:53 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-11-03 04:21:53 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-11-03 04:21:53 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-11-03 04:21:53 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/dashboard.php
DEBUG - 2016-11-03 04:21:53 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-11-03 04:21:53 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-11-03 04:21:54 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:54 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:54 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:54 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:54 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:54 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:54 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:54 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:54 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:54 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:54 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:54 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:54 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:54 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:54 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:54 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:54 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:54 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:54 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:54 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:54 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:55 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:55 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:55 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:55 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:55 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:55 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:55 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:55 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:55 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:55 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:55 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:55 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:55 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:55 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:55 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:55 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:55 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:55 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:55 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:55 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:55 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:55 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:55 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:55 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:55 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:55 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:56 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:56 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:56 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:56 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:56 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:56 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:56 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:56 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:56 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:56 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:56 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:56 --> Database Driver Class Initialized
DEBUG - 2016-11-03 04:21:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-11-03 04:21:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-11-03 04:21:56 --> Final output sent to browser
INFO - 2016-11-03 04:21:56 --> Config Class Initialized
INFO - 2016-11-03 04:21:56 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:21:56 --> Total execution time: 5.9342
DEBUG - 2016-11-03 04:21:56 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:21:56 --> Utf8 Class Initialized
INFO - 2016-11-03 04:21:56 --> URI Class Initialized
INFO - 2016-11-03 04:21:56 --> Router Class Initialized
INFO - 2016-11-03 04:21:56 --> Output Class Initialized
INFO - 2016-11-03 04:21:56 --> Security Class Initialized
DEBUG - 2016-11-03 04:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:21:56 --> Input Class Initialized
INFO - 2016-11-03 04:21:56 --> Language Class Initialized
INFO - 2016-11-03 04:21:56 --> Language Class Initialized
INFO - 2016-11-03 04:21:56 --> Config Class Initialized
INFO - 2016-11-03 04:21:56 --> Loader Class Initialized
INFO - 2016-11-03 04:21:56 --> Helper loaded: url_helper
INFO - 2016-11-03 04:21:56 --> Database Driver Class Initialized
INFO - 2016-11-03 04:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:21:56 --> Controller Class Initialized
DEBUG - 2016-11-03 04:21:57 --> login MX_Controller Initialized
INFO - 2016-11-03 04:21:57 --> Model Class Initialized
INFO - 2016-11-03 04:21:57 --> Model Class Initialized
DEBUG - 2016-11-03 04:21:57 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/login.php
INFO - 2016-11-03 04:21:57 --> Final output sent to browser
DEBUG - 2016-11-03 04:21:57 --> Total execution time: 0.6128
INFO - 2016-11-03 04:26:14 --> Config Class Initialized
INFO - 2016-11-03 04:26:14 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:26:14 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:26:14 --> Utf8 Class Initialized
INFO - 2016-11-03 04:26:14 --> URI Class Initialized
INFO - 2016-11-03 04:26:14 --> Router Class Initialized
INFO - 2016-11-03 04:26:14 --> Output Class Initialized
INFO - 2016-11-03 04:26:14 --> Security Class Initialized
DEBUG - 2016-11-03 04:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:26:14 --> Input Class Initialized
INFO - 2016-11-03 04:26:14 --> Language Class Initialized
INFO - 2016-11-03 04:26:14 --> Language Class Initialized
INFO - 2016-11-03 04:26:14 --> Config Class Initialized
INFO - 2016-11-03 04:26:14 --> Loader Class Initialized
INFO - 2016-11-03 04:26:14 --> Helper loaded: url_helper
INFO - 2016-11-03 04:26:14 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:26:14 --> Controller Class Initialized
DEBUG - 2016-11-03 04:26:14 --> login MX_Controller Initialized
INFO - 2016-11-03 04:26:14 --> Model Class Initialized
INFO - 2016-11-03 04:26:14 --> Model Class Initialized
INFO - 2016-11-03 04:26:14 --> Final output sent to browser
DEBUG - 2016-11-03 04:26:14 --> Total execution time: 0.4487
INFO - 2016-11-03 04:26:20 --> Config Class Initialized
INFO - 2016-11-03 04:26:20 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:26:20 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:26:20 --> Utf8 Class Initialized
INFO - 2016-11-03 04:26:20 --> URI Class Initialized
INFO - 2016-11-03 04:26:20 --> Router Class Initialized
INFO - 2016-11-03 04:26:20 --> Output Class Initialized
INFO - 2016-11-03 04:26:20 --> Security Class Initialized
DEBUG - 2016-11-03 04:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:26:20 --> Input Class Initialized
INFO - 2016-11-03 04:26:20 --> Language Class Initialized
INFO - 2016-11-03 04:26:20 --> Language Class Initialized
INFO - 2016-11-03 04:26:20 --> Config Class Initialized
INFO - 2016-11-03 04:26:20 --> Loader Class Initialized
INFO - 2016-11-03 04:26:20 --> Helper loaded: url_helper
INFO - 2016-11-03 04:26:20 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:26:20 --> Controller Class Initialized
DEBUG - 2016-11-03 04:26:20 --> login MX_Controller Initialized
INFO - 2016-11-03 04:26:20 --> Model Class Initialized
INFO - 2016-11-03 04:26:20 --> Model Class Initialized
INFO - 2016-11-03 04:26:21 --> Final output sent to browser
DEBUG - 2016-11-03 04:26:21 --> Total execution time: 0.4070
INFO - 2016-11-03 04:26:21 --> Config Class Initialized
INFO - 2016-11-03 04:26:21 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:26:21 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:26:21 --> Utf8 Class Initialized
INFO - 2016-11-03 04:26:21 --> URI Class Initialized
INFO - 2016-11-03 04:26:21 --> Router Class Initialized
INFO - 2016-11-03 04:26:21 --> Output Class Initialized
INFO - 2016-11-03 04:26:21 --> Security Class Initialized
DEBUG - 2016-11-03 04:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:26:21 --> Input Class Initialized
INFO - 2016-11-03 04:26:21 --> Language Class Initialized
INFO - 2016-11-03 04:26:21 --> Language Class Initialized
INFO - 2016-11-03 04:26:21 --> Config Class Initialized
INFO - 2016-11-03 04:26:21 --> Loader Class Initialized
INFO - 2016-11-03 04:26:21 --> Helper loaded: url_helper
INFO - 2016-11-03 04:26:21 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:26:21 --> Controller Class Initialized
DEBUG - 2016-11-03 04:26:21 --> Index MX_Controller Initialized
INFO - 2016-11-03 04:26:21 --> Model Class Initialized
INFO - 2016-11-03 04:26:21 --> Model Class Initialized
ERROR - 2016-11-03 04:26:21 --> Unable to delete cache file for admin/index
DEBUG - 2016-11-03 04:26:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-11-03 04:26:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-11-03 04:26:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-11-03 04:26:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/dashboard.php
DEBUG - 2016-11-03 04:26:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-11-03 04:26:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-11-03 04:26:21 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:21 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:21 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:21 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:21 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:21 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:21 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:21 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:22 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:22 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:22 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:22 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:22 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:22 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:22 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:22 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:22 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:22 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:22 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:22 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:22 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:22 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:22 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:22 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:22 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:22 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:22 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:22 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:22 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:22 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:22 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:22 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:22 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:22 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:22 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:22 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:22 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:22 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:22 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:22 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:22 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:22 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:22 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:22 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:22 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:22 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:22 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:22 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:22 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:23 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:23 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:23 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:23 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:23 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:23 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:23 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:23 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:23 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:23 --> Database Driver Class Initialized
DEBUG - 2016-11-03 04:26:23 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-11-03 04:26:23 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-11-03 04:26:23 --> Final output sent to browser
DEBUG - 2016-11-03 04:26:23 --> Total execution time: 2.2195
INFO - 2016-11-03 04:26:38 --> Config Class Initialized
INFO - 2016-11-03 04:26:38 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:26:38 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:26:38 --> Utf8 Class Initialized
INFO - 2016-11-03 04:26:38 --> URI Class Initialized
INFO - 2016-11-03 04:26:38 --> Router Class Initialized
INFO - 2016-11-03 04:26:38 --> Output Class Initialized
INFO - 2016-11-03 04:26:39 --> Security Class Initialized
DEBUG - 2016-11-03 04:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:26:39 --> Input Class Initialized
INFO - 2016-11-03 04:26:39 --> Language Class Initialized
INFO - 2016-11-03 04:26:39 --> Language Class Initialized
INFO - 2016-11-03 04:26:39 --> Config Class Initialized
INFO - 2016-11-03 04:26:39 --> Loader Class Initialized
INFO - 2016-11-03 04:26:39 --> Helper loaded: url_helper
INFO - 2016-11-03 04:26:39 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:26:39 --> Controller Class Initialized
DEBUG - 2016-11-03 04:26:39 --> Index MX_Controller Initialized
INFO - 2016-11-03 04:26:39 --> Model Class Initialized
INFO - 2016-11-03 04:26:39 --> Model Class Initialized
ERROR - 2016-11-03 04:26:39 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-11-03 04:26:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-11-03 04:26:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-11-03 04:26:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-11-03 04:26:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-11-03 04:26:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-11-03 04:26:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-11-03 04:26:39 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:39 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:39 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:39 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:39 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:39 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:39 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:39 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:39 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:39 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:39 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:39 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:39 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:39 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:39 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:39 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:39 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:39 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:39 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:40 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:40 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:40 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:40 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:40 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:40 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:40 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:40 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:40 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:40 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:40 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:40 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:40 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:40 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:40 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:40 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:40 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:40 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:40 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:40 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:40 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:40 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:40 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:40 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:40 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:40 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:40 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:40 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:41 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:41 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:41 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:41 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:41 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:41 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:41 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:41 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:41 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:41 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:41 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:41 --> Database Driver Class Initialized
DEBUG - 2016-11-03 04:26:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-11-03 04:26:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-11-03 04:26:41 --> Final output sent to browser
DEBUG - 2016-11-03 04:26:41 --> Total execution time: 2.5280
INFO - 2016-11-03 04:26:45 --> Config Class Initialized
INFO - 2016-11-03 04:26:45 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:26:45 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:26:45 --> Utf8 Class Initialized
INFO - 2016-11-03 04:26:45 --> URI Class Initialized
INFO - 2016-11-03 04:26:45 --> Router Class Initialized
INFO - 2016-11-03 04:26:45 --> Output Class Initialized
INFO - 2016-11-03 04:26:45 --> Security Class Initialized
DEBUG - 2016-11-03 04:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:26:45 --> Input Class Initialized
INFO - 2016-11-03 04:26:45 --> Language Class Initialized
INFO - 2016-11-03 04:26:45 --> Language Class Initialized
INFO - 2016-11-03 04:26:45 --> Config Class Initialized
INFO - 2016-11-03 04:26:45 --> Loader Class Initialized
INFO - 2016-11-03 04:26:45 --> Helper loaded: url_helper
INFO - 2016-11-03 04:26:45 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:26:45 --> Controller Class Initialized
DEBUG - 2016-11-03 04:26:45 --> Index MX_Controller Initialized
INFO - 2016-11-03 04:26:45 --> Model Class Initialized
INFO - 2016-11-03 04:26:45 --> Model Class Initialized
ERROR - 2016-11-03 04:26:45 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-11-03 04:26:45 --> Anggota MX_Controller Initialized
INFO - 2016-11-03 04:26:45 --> Final output sent to browser
DEBUG - 2016-11-03 04:26:45 --> Total execution time: 0.5553
INFO - 2016-11-03 04:26:49 --> Config Class Initialized
INFO - 2016-11-03 04:26:49 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:26:49 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:26:49 --> Utf8 Class Initialized
INFO - 2016-11-03 04:26:49 --> URI Class Initialized
INFO - 2016-11-03 04:26:49 --> Router Class Initialized
INFO - 2016-11-03 04:26:49 --> Output Class Initialized
INFO - 2016-11-03 04:26:49 --> Security Class Initialized
DEBUG - 2016-11-03 04:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:26:49 --> Input Class Initialized
INFO - 2016-11-03 04:26:49 --> Language Class Initialized
INFO - 2016-11-03 04:26:49 --> Language Class Initialized
INFO - 2016-11-03 04:26:49 --> Config Class Initialized
INFO - 2016-11-03 04:26:49 --> Loader Class Initialized
INFO - 2016-11-03 04:26:49 --> Helper loaded: url_helper
INFO - 2016-11-03 04:26:49 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:26:49 --> Controller Class Initialized
DEBUG - 2016-11-03 04:26:49 --> Index MX_Controller Initialized
INFO - 2016-11-03 04:26:49 --> Model Class Initialized
INFO - 2016-11-03 04:26:49 --> Model Class Initialized
ERROR - 2016-11-03 04:26:49 --> Unable to delete cache file for admin/index/data/anggota
DEBUG - 2016-11-03 04:26:49 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-11-03 04:26:49 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-11-03 04:26:49 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-11-03 04:26:49 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-11-03 04:26:49 --> Anggota MX_Controller Initialized
DEBUG - 2016-11-03 04:26:49 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-11-03 04:26:49 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-11-03 04:26:49 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-11-03 04:26:50 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:50 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:50 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:50 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:50 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:50 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:50 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:50 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:50 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:50 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:50 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:50 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:50 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:50 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:50 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:50 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:50 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:50 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:50 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:50 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:50 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:50 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:50 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:50 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:50 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:50 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:50 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:50 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:50 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:50 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:50 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:50 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:50 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:50 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:50 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:50 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:50 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:50 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:50 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:50 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:50 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:51 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:51 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:51 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:51 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:51 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:51 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:51 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:51 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:51 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:51 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:51 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:51 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:51 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:51 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:51 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:51 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:51 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:51 --> Database Driver Class Initialized
INFO - 2016-11-03 04:26:51 --> Database Driver Class Initialized
DEBUG - 2016-11-03 04:26:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-11-03 04:26:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-11-03 04:26:52 --> Final output sent to browser
DEBUG - 2016-11-03 04:26:52 --> Total execution time: 2.7745
INFO - 2016-11-03 04:27:00 --> Config Class Initialized
INFO - 2016-11-03 04:27:00 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:27:00 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:27:00 --> Utf8 Class Initialized
INFO - 2016-11-03 04:27:00 --> URI Class Initialized
INFO - 2016-11-03 04:27:00 --> Router Class Initialized
INFO - 2016-11-03 04:27:00 --> Output Class Initialized
INFO - 2016-11-03 04:27:00 --> Security Class Initialized
DEBUG - 2016-11-03 04:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:27:00 --> Input Class Initialized
INFO - 2016-11-03 04:27:00 --> Language Class Initialized
INFO - 2016-11-03 04:27:00 --> Language Class Initialized
INFO - 2016-11-03 04:27:00 --> Config Class Initialized
INFO - 2016-11-03 04:27:00 --> Loader Class Initialized
INFO - 2016-11-03 04:27:00 --> Helper loaded: url_helper
INFO - 2016-11-03 04:27:00 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:27:00 --> Controller Class Initialized
DEBUG - 2016-11-03 04:27:00 --> Index MX_Controller Initialized
INFO - 2016-11-03 04:27:00 --> Model Class Initialized
INFO - 2016-11-03 04:27:00 --> Model Class Initialized
ERROR - 2016-11-03 04:27:00 --> Unable to delete cache file for admin/index/data_peminjam
DEBUG - 2016-11-03 04:27:00 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-11-03 04:27:00 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-11-03 04:27:00 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-11-03 04:27:00 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_peminjam.php
DEBUG - 2016-11-03 04:27:00 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-11-03 04:27:00 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-11-03 04:27:00 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:00 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:00 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:01 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:01 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:01 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:01 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:01 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:01 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:01 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:01 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:01 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:01 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:01 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:01 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:01 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:01 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:01 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:01 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:01 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:01 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:01 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:01 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:01 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:01 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:01 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:01 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:01 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:01 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:01 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:01 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:01 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:01 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:01 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:01 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:01 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:01 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:01 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:01 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:02 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:02 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:02 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:02 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:02 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:02 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:02 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:02 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:02 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:02 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:02 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:02 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:02 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:02 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:02 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:02 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:02 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:02 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:02 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:02 --> Database Driver Class Initialized
DEBUG - 2016-11-03 04:27:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-11-03 04:27:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-11-03 04:27:02 --> Final output sent to browser
DEBUG - 2016-11-03 04:27:02 --> Total execution time: 2.4666
INFO - 2016-11-03 04:27:06 --> Config Class Initialized
INFO - 2016-11-03 04:27:07 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:27:07 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:27:07 --> Utf8 Class Initialized
INFO - 2016-11-03 04:27:07 --> URI Class Initialized
INFO - 2016-11-03 04:27:07 --> Router Class Initialized
INFO - 2016-11-03 04:27:07 --> Output Class Initialized
INFO - 2016-11-03 04:27:07 --> Security Class Initialized
DEBUG - 2016-11-03 04:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:27:07 --> Input Class Initialized
INFO - 2016-11-03 04:27:07 --> Language Class Initialized
INFO - 2016-11-03 04:27:07 --> Language Class Initialized
INFO - 2016-11-03 04:27:07 --> Config Class Initialized
INFO - 2016-11-03 04:27:07 --> Loader Class Initialized
INFO - 2016-11-03 04:27:07 --> Helper loaded: url_helper
INFO - 2016-11-03 04:27:07 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:27:07 --> Controller Class Initialized
DEBUG - 2016-11-03 04:27:07 --> Index MX_Controller Initialized
INFO - 2016-11-03 04:27:07 --> Model Class Initialized
INFO - 2016-11-03 04:27:07 --> Model Class Initialized
ERROR - 2016-11-03 04:27:07 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-11-03 04:27:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-11-03 04:27:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-11-03 04:27:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-11-03 04:27:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-11-03 04:27:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-11-03 04:27:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-11-03 04:27:07 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:07 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:07 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:07 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:07 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:07 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:07 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:07 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:07 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:08 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:08 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:08 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:08 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:08 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:08 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:08 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:08 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:08 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:08 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:08 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:08 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:08 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:08 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:08 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:08 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:08 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:08 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:08 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:08 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:08 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:08 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:08 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:08 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:08 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:08 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:08 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:08 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:08 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:08 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:08 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:08 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:08 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:08 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:08 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:08 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:08 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:08 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:08 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:08 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:09 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:09 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:09 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:09 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:09 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:09 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:09 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:09 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:09 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:09 --> Database Driver Class Initialized
DEBUG - 2016-11-03 04:27:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-11-03 04:27:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-11-03 04:27:09 --> Final output sent to browser
DEBUG - 2016-11-03 04:27:09 --> Total execution time: 2.3288
INFO - 2016-11-03 04:27:13 --> Config Class Initialized
INFO - 2016-11-03 04:27:13 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:27:13 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:27:13 --> Utf8 Class Initialized
INFO - 2016-11-03 04:27:13 --> URI Class Initialized
INFO - 2016-11-03 04:27:13 --> Router Class Initialized
INFO - 2016-11-03 04:27:13 --> Output Class Initialized
INFO - 2016-11-03 04:27:13 --> Security Class Initialized
DEBUG - 2016-11-03 04:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:27:13 --> Input Class Initialized
INFO - 2016-11-03 04:27:13 --> Language Class Initialized
INFO - 2016-11-03 04:27:13 --> Language Class Initialized
INFO - 2016-11-03 04:27:13 --> Config Class Initialized
INFO - 2016-11-03 04:27:13 --> Loader Class Initialized
INFO - 2016-11-03 04:27:13 --> Helper loaded: url_helper
INFO - 2016-11-03 04:27:13 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:27:13 --> Controller Class Initialized
DEBUG - 2016-11-03 04:27:13 --> Index MX_Controller Initialized
INFO - 2016-11-03 04:27:13 --> Model Class Initialized
INFO - 2016-11-03 04:27:13 --> Model Class Initialized
ERROR - 2016-11-03 04:27:13 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-11-03 04:27:13 --> Anggota MX_Controller Initialized
INFO - 2016-11-03 04:27:13 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:13 --> Final output sent to browser
DEBUG - 2016-11-03 04:27:13 --> Total execution time: 0.5359
INFO - 2016-11-03 04:27:15 --> Config Class Initialized
INFO - 2016-11-03 04:27:15 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:27:15 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:27:15 --> Utf8 Class Initialized
INFO - 2016-11-03 04:27:15 --> URI Class Initialized
INFO - 2016-11-03 04:27:15 --> Router Class Initialized
INFO - 2016-11-03 04:27:16 --> Output Class Initialized
INFO - 2016-11-03 04:27:16 --> Security Class Initialized
DEBUG - 2016-11-03 04:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:27:16 --> Input Class Initialized
INFO - 2016-11-03 04:27:16 --> Language Class Initialized
INFO - 2016-11-03 04:27:16 --> Language Class Initialized
INFO - 2016-11-03 04:27:16 --> Config Class Initialized
INFO - 2016-11-03 04:27:16 --> Loader Class Initialized
INFO - 2016-11-03 04:27:16 --> Helper loaded: url_helper
INFO - 2016-11-03 04:27:16 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:27:16 --> Controller Class Initialized
DEBUG - 2016-11-03 04:27:16 --> Index MX_Controller Initialized
INFO - 2016-11-03 04:27:16 --> Model Class Initialized
INFO - 2016-11-03 04:27:16 --> Model Class Initialized
ERROR - 2016-11-03 04:27:16 --> Unable to delete cache file for admin/index/tutup_angsuran
DEBUG - 2016-11-03 04:27:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-11-03 04:27:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-11-03 04:27:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-11-03 04:27:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_tutup_angsuran.php
DEBUG - 2016-11-03 04:27:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-11-03 04:27:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-11-03 04:27:16 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:16 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:16 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:16 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:16 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:16 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:17 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:17 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:17 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:17 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:17 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:17 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:17 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:17 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:17 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:17 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:17 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:17 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:17 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:17 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:17 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:17 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:17 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:17 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:17 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:17 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:17 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:17 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:17 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:17 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:17 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:17 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:17 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:17 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:17 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:17 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:17 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:17 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:17 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:17 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:17 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:17 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:17 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:17 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:17 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:18 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:18 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:18 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:18 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:18 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:18 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:18 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:18 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:18 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:18 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:18 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:18 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:18 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:18 --> Database Driver Class Initialized
DEBUG - 2016-11-03 04:27:18 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-11-03 04:27:18 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-11-03 04:27:18 --> Final output sent to browser
DEBUG - 2016-11-03 04:27:18 --> Total execution time: 2.6013
INFO - 2016-11-03 04:27:20 --> Config Class Initialized
INFO - 2016-11-03 04:27:20 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:27:20 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:27:20 --> Utf8 Class Initialized
INFO - 2016-11-03 04:27:20 --> URI Class Initialized
INFO - 2016-11-03 04:27:20 --> Router Class Initialized
INFO - 2016-11-03 04:27:20 --> Output Class Initialized
INFO - 2016-11-03 04:27:20 --> Security Class Initialized
DEBUG - 2016-11-03 04:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:27:21 --> Input Class Initialized
INFO - 2016-11-03 04:27:21 --> Language Class Initialized
INFO - 2016-11-03 04:27:21 --> Language Class Initialized
INFO - 2016-11-03 04:27:21 --> Config Class Initialized
INFO - 2016-11-03 04:27:21 --> Loader Class Initialized
INFO - 2016-11-03 04:27:21 --> Helper loaded: url_helper
INFO - 2016-11-03 04:27:21 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:27:21 --> Controller Class Initialized
DEBUG - 2016-11-03 04:27:21 --> Index MX_Controller Initialized
INFO - 2016-11-03 04:27:21 --> Model Class Initialized
INFO - 2016-11-03 04:27:21 --> Model Class Initialized
ERROR - 2016-11-03 04:27:21 --> Unable to delete cache file for admin/index/getDetailLunas
INFO - 2016-11-03 04:27:21 --> Database Driver Class Initialized
INFO - 2016-11-03 04:27:21 --> Final output sent to browser
DEBUG - 2016-11-03 04:27:21 --> Total execution time: 0.6196
INFO - 2016-11-03 04:44:47 --> Config Class Initialized
INFO - 2016-11-03 04:44:47 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:44:47 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:44:47 --> Utf8 Class Initialized
INFO - 2016-11-03 04:44:47 --> URI Class Initialized
INFO - 2016-11-03 04:44:47 --> Router Class Initialized
INFO - 2016-11-03 04:44:47 --> Output Class Initialized
INFO - 2016-11-03 04:44:47 --> Security Class Initialized
DEBUG - 2016-11-03 04:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:44:47 --> Input Class Initialized
INFO - 2016-11-03 04:44:47 --> Language Class Initialized
INFO - 2016-11-03 04:44:48 --> Language Class Initialized
INFO - 2016-11-03 04:44:48 --> Config Class Initialized
INFO - 2016-11-03 04:44:48 --> Loader Class Initialized
INFO - 2016-11-03 04:44:48 --> Helper loaded: url_helper
INFO - 2016-11-03 04:44:48 --> Database Driver Class Initialized
INFO - 2016-11-03 04:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:44:48 --> Controller Class Initialized
DEBUG - 2016-11-03 04:44:48 --> Index MX_Controller Initialized
INFO - 2016-11-03 04:44:48 --> Model Class Initialized
INFO - 2016-11-03 04:44:48 --> Model Class Initialized
ERROR - 2016-11-03 04:44:48 --> Unable to delete cache file for admin/index/getDetailLunas
INFO - 2016-11-03 04:44:48 --> Database Driver Class Initialized
INFO - 2016-11-03 04:44:48 --> Final output sent to browser
DEBUG - 2016-11-03 04:44:48 --> Total execution time: 0.4658
INFO - 2016-11-03 04:45:11 --> Config Class Initialized
INFO - 2016-11-03 04:45:11 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:45:11 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:45:11 --> Utf8 Class Initialized
INFO - 2016-11-03 04:45:11 --> URI Class Initialized
INFO - 2016-11-03 04:45:11 --> Router Class Initialized
INFO - 2016-11-03 04:45:11 --> Output Class Initialized
INFO - 2016-11-03 04:45:11 --> Security Class Initialized
DEBUG - 2016-11-03 04:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:45:11 --> Input Class Initialized
INFO - 2016-11-03 04:45:11 --> Language Class Initialized
INFO - 2016-11-03 04:45:11 --> Language Class Initialized
INFO - 2016-11-03 04:45:11 --> Config Class Initialized
INFO - 2016-11-03 04:45:11 --> Loader Class Initialized
INFO - 2016-11-03 04:45:11 --> Helper loaded: url_helper
INFO - 2016-11-03 04:45:12 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:45:12 --> Controller Class Initialized
DEBUG - 2016-11-03 04:45:12 --> Index MX_Controller Initialized
INFO - 2016-11-03 04:45:12 --> Model Class Initialized
INFO - 2016-11-03 04:45:12 --> Model Class Initialized
ERROR - 2016-11-03 04:45:12 --> Unable to delete cache file for admin/index/getDetailLunas
INFO - 2016-11-03 04:45:12 --> Final output sent to browser
DEBUG - 2016-11-03 04:45:12 --> Total execution time: 0.4583
INFO - 2016-11-03 04:45:13 --> Config Class Initialized
INFO - 2016-11-03 04:45:13 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:45:13 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:45:13 --> Utf8 Class Initialized
INFO - 2016-11-03 04:45:13 --> URI Class Initialized
INFO - 2016-11-03 04:45:13 --> Router Class Initialized
INFO - 2016-11-03 04:45:13 --> Output Class Initialized
INFO - 2016-11-03 04:45:13 --> Security Class Initialized
DEBUG - 2016-11-03 04:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:45:13 --> Input Class Initialized
INFO - 2016-11-03 04:45:13 --> Language Class Initialized
INFO - 2016-11-03 04:45:13 --> Language Class Initialized
INFO - 2016-11-03 04:45:14 --> Config Class Initialized
INFO - 2016-11-03 04:45:14 --> Loader Class Initialized
INFO - 2016-11-03 04:45:14 --> Helper loaded: url_helper
INFO - 2016-11-03 04:45:14 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:45:14 --> Controller Class Initialized
DEBUG - 2016-11-03 04:45:14 --> Index MX_Controller Initialized
INFO - 2016-11-03 04:45:14 --> Model Class Initialized
INFO - 2016-11-03 04:45:14 --> Model Class Initialized
ERROR - 2016-11-03 04:45:14 --> Unable to delete cache file for admin/index/getDetailLunas
INFO - 2016-11-03 04:45:14 --> Final output sent to browser
DEBUG - 2016-11-03 04:45:14 --> Total execution time: 0.4596
INFO - 2016-11-03 04:45:17 --> Config Class Initialized
INFO - 2016-11-03 04:45:17 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:45:17 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:45:17 --> Utf8 Class Initialized
INFO - 2016-11-03 04:45:17 --> URI Class Initialized
INFO - 2016-11-03 04:45:17 --> Router Class Initialized
INFO - 2016-11-03 04:45:17 --> Output Class Initialized
INFO - 2016-11-03 04:45:17 --> Security Class Initialized
DEBUG - 2016-11-03 04:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:45:17 --> Input Class Initialized
INFO - 2016-11-03 04:45:17 --> Language Class Initialized
INFO - 2016-11-03 04:45:17 --> Language Class Initialized
INFO - 2016-11-03 04:45:17 --> Config Class Initialized
INFO - 2016-11-03 04:45:17 --> Loader Class Initialized
INFO - 2016-11-03 04:45:17 --> Helper loaded: url_helper
INFO - 2016-11-03 04:45:17 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:45:17 --> Controller Class Initialized
DEBUG - 2016-11-03 04:45:17 --> Index MX_Controller Initialized
INFO - 2016-11-03 04:45:17 --> Model Class Initialized
INFO - 2016-11-03 04:45:17 --> Model Class Initialized
ERROR - 2016-11-03 04:45:17 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-11-03 04:45:17 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-11-03 04:45:17 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-11-03 04:45:17 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-11-03 04:45:17 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-11-03 04:45:17 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-11-03 04:45:17 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-11-03 04:45:17 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:17 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:17 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:17 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:17 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:17 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:17 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:18 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:18 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:18 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:18 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:18 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:18 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:18 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:18 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:18 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:18 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:18 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:18 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:18 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:18 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:18 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:18 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:18 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:18 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:18 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:18 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:18 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:18 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:18 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:18 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:18 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:18 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:18 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:18 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:18 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:18 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:18 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:18 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:18 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:18 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:18 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:18 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:18 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:18 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:19 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:19 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:19 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:19 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:19 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:19 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:19 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:19 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:19 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:19 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:19 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:19 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:19 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:19 --> Database Driver Class Initialized
DEBUG - 2016-11-03 04:45:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-11-03 04:45:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-11-03 04:45:19 --> Final output sent to browser
DEBUG - 2016-11-03 04:45:19 --> Total execution time: 2.3535
INFO - 2016-11-03 04:45:24 --> Config Class Initialized
INFO - 2016-11-03 04:45:24 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:45:24 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:45:24 --> Utf8 Class Initialized
INFO - 2016-11-03 04:45:24 --> URI Class Initialized
INFO - 2016-11-03 04:45:24 --> Router Class Initialized
INFO - 2016-11-03 04:45:24 --> Output Class Initialized
INFO - 2016-11-03 04:45:24 --> Security Class Initialized
DEBUG - 2016-11-03 04:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:45:24 --> Input Class Initialized
INFO - 2016-11-03 04:45:24 --> Language Class Initialized
INFO - 2016-11-03 04:45:24 --> Language Class Initialized
INFO - 2016-11-03 04:45:24 --> Config Class Initialized
INFO - 2016-11-03 04:45:24 --> Loader Class Initialized
INFO - 2016-11-03 04:45:24 --> Helper loaded: url_helper
INFO - 2016-11-03 04:45:24 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:45:25 --> Controller Class Initialized
DEBUG - 2016-11-03 04:45:25 --> Index MX_Controller Initialized
INFO - 2016-11-03 04:45:25 --> Model Class Initialized
INFO - 2016-11-03 04:45:25 --> Model Class Initialized
ERROR - 2016-11-03 04:45:25 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-11-03 04:45:25 --> Anggota MX_Controller Initialized
INFO - 2016-11-03 04:45:25 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:25 --> Final output sent to browser
DEBUG - 2016-11-03 04:45:25 --> Total execution time: 0.4902
INFO - 2016-11-03 04:45:27 --> Config Class Initialized
INFO - 2016-11-03 04:45:27 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:45:27 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:45:27 --> Utf8 Class Initialized
INFO - 2016-11-03 04:45:27 --> URI Class Initialized
INFO - 2016-11-03 04:45:27 --> Router Class Initialized
INFO - 2016-11-03 04:45:27 --> Output Class Initialized
INFO - 2016-11-03 04:45:27 --> Security Class Initialized
DEBUG - 2016-11-03 04:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:45:27 --> Input Class Initialized
INFO - 2016-11-03 04:45:27 --> Language Class Initialized
INFO - 2016-11-03 04:45:27 --> Language Class Initialized
INFO - 2016-11-03 04:45:27 --> Config Class Initialized
INFO - 2016-11-03 04:45:27 --> Loader Class Initialized
INFO - 2016-11-03 04:45:27 --> Helper loaded: url_helper
INFO - 2016-11-03 04:45:27 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:45:27 --> Controller Class Initialized
DEBUG - 2016-11-03 04:45:27 --> Index MX_Controller Initialized
INFO - 2016-11-03 04:45:27 --> Model Class Initialized
INFO - 2016-11-03 04:45:27 --> Model Class Initialized
ERROR - 2016-11-03 04:45:27 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-11-03 04:45:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-11-03 04:45:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-11-03 04:45:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-11-03 04:45:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-11-03 04:45:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-11-03 04:45:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-11-03 04:45:27 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:27 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:27 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:27 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:27 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:29 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:29 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:29 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:29 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:29 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:29 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:29 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:29 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:29 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:29 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:29 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:29 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:29 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:29 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:29 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:29 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:29 --> Database Driver Class Initialized
DEBUG - 2016-11-03 04:45:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-11-03 04:45:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-11-03 04:45:29 --> Final output sent to browser
DEBUG - 2016-11-03 04:45:29 --> Total execution time: 2.3409
INFO - 2016-11-03 04:45:34 --> Config Class Initialized
INFO - 2016-11-03 04:45:34 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:45:34 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:45:34 --> Utf8 Class Initialized
INFO - 2016-11-03 04:45:34 --> URI Class Initialized
INFO - 2016-11-03 04:45:34 --> Router Class Initialized
INFO - 2016-11-03 04:45:34 --> Output Class Initialized
INFO - 2016-11-03 04:45:34 --> Security Class Initialized
DEBUG - 2016-11-03 04:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:45:34 --> Input Class Initialized
INFO - 2016-11-03 04:45:34 --> Language Class Initialized
INFO - 2016-11-03 04:45:34 --> Language Class Initialized
INFO - 2016-11-03 04:45:34 --> Config Class Initialized
INFO - 2016-11-03 04:45:34 --> Loader Class Initialized
INFO - 2016-11-03 04:45:34 --> Helper loaded: url_helper
INFO - 2016-11-03 04:45:34 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:45:34 --> Controller Class Initialized
DEBUG - 2016-11-03 04:45:34 --> Index MX_Controller Initialized
INFO - 2016-11-03 04:45:34 --> Model Class Initialized
INFO - 2016-11-03 04:45:34 --> Model Class Initialized
ERROR - 2016-11-03 04:45:34 --> Unable to delete cache file for admin/index/do_ajukan_pinjaman
INFO - 2016-11-03 04:45:34 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:34 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:34 --> Final output sent to browser
DEBUG - 2016-11-03 04:45:34 --> Total execution time: 0.7464
INFO - 2016-11-03 04:45:40 --> Config Class Initialized
INFO - 2016-11-03 04:45:40 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:45:40 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:45:40 --> Utf8 Class Initialized
INFO - 2016-11-03 04:45:40 --> URI Class Initialized
INFO - 2016-11-03 04:45:40 --> Router Class Initialized
INFO - 2016-11-03 04:45:40 --> Output Class Initialized
INFO - 2016-11-03 04:45:40 --> Security Class Initialized
DEBUG - 2016-11-03 04:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:45:40 --> Input Class Initialized
INFO - 2016-11-03 04:45:40 --> Language Class Initialized
INFO - 2016-11-03 04:45:40 --> Language Class Initialized
INFO - 2016-11-03 04:45:40 --> Config Class Initialized
INFO - 2016-11-03 04:45:40 --> Loader Class Initialized
INFO - 2016-11-03 04:45:40 --> Helper loaded: url_helper
INFO - 2016-11-03 04:45:40 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:45:40 --> Controller Class Initialized
DEBUG - 2016-11-03 04:45:40 --> Index MX_Controller Initialized
INFO - 2016-11-03 04:45:40 --> Model Class Initialized
INFO - 2016-11-03 04:45:40 --> Model Class Initialized
ERROR - 2016-11-03 04:45:40 --> Unable to delete cache file for admin/index/batal/92cfceb39d57d914ed8b14d0e37643de0797ae56
INFO - 2016-11-03 04:45:40 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:40 --> Final output sent to browser
DEBUG - 2016-11-03 04:45:40 --> Total execution time: 0.5976
INFO - 2016-11-03 04:45:41 --> Config Class Initialized
INFO - 2016-11-03 04:45:41 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:45:41 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:45:41 --> Utf8 Class Initialized
INFO - 2016-11-03 04:45:41 --> URI Class Initialized
INFO - 2016-11-03 04:45:41 --> Router Class Initialized
INFO - 2016-11-03 04:45:41 --> Output Class Initialized
INFO - 2016-11-03 04:45:41 --> Security Class Initialized
DEBUG - 2016-11-03 04:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:45:41 --> Input Class Initialized
INFO - 2016-11-03 04:45:41 --> Language Class Initialized
INFO - 2016-11-03 04:45:41 --> Language Class Initialized
INFO - 2016-11-03 04:45:41 --> Config Class Initialized
INFO - 2016-11-03 04:45:41 --> Loader Class Initialized
INFO - 2016-11-03 04:45:41 --> Helper loaded: url_helper
INFO - 2016-11-03 04:45:41 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:45:41 --> Controller Class Initialized
DEBUG - 2016-11-03 04:45:41 --> Index MX_Controller Initialized
INFO - 2016-11-03 04:45:41 --> Model Class Initialized
INFO - 2016-11-03 04:45:41 --> Model Class Initialized
ERROR - 2016-11-03 04:45:41 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-11-03 04:45:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-11-03 04:45:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-11-03 04:45:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-11-03 04:45:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-11-03 04:45:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-11-03 04:45:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-11-03 04:45:41 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:41 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:41 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:41 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:42 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:42 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:42 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:42 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:42 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:42 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:42 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:42 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:42 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:42 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:42 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:42 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:42 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:42 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:42 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:42 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:42 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:42 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:42 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:42 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:42 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:42 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:42 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:42 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:42 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:42 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:42 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:42 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:42 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:42 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:42 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:42 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:42 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:42 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:42 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:42 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:42 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:43 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:43 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:43 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:43 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:43 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:43 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:43 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:43 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:43 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:43 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:43 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:43 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:43 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:43 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:43 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:43 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:43 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:43 --> Database Driver Class Initialized
DEBUG - 2016-11-03 04:45:43 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-11-03 04:45:43 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-11-03 04:45:43 --> Final output sent to browser
DEBUG - 2016-11-03 04:45:43 --> Total execution time: 2.5582
INFO - 2016-11-03 04:45:48 --> Config Class Initialized
INFO - 2016-11-03 04:45:48 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:45:48 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:45:48 --> Utf8 Class Initialized
INFO - 2016-11-03 04:45:48 --> URI Class Initialized
INFO - 2016-11-03 04:45:48 --> Router Class Initialized
INFO - 2016-11-03 04:45:48 --> Output Class Initialized
INFO - 2016-11-03 04:45:48 --> Security Class Initialized
DEBUG - 2016-11-03 04:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:45:48 --> Input Class Initialized
INFO - 2016-11-03 04:45:48 --> Language Class Initialized
INFO - 2016-11-03 04:45:48 --> Language Class Initialized
INFO - 2016-11-03 04:45:48 --> Config Class Initialized
INFO - 2016-11-03 04:45:48 --> Loader Class Initialized
INFO - 2016-11-03 04:45:48 --> Helper loaded: url_helper
INFO - 2016-11-03 04:45:48 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:45:48 --> Controller Class Initialized
DEBUG - 2016-11-03 04:45:48 --> Index MX_Controller Initialized
INFO - 2016-11-03 04:45:48 --> Model Class Initialized
INFO - 2016-11-03 04:45:48 --> Model Class Initialized
ERROR - 2016-11-03 04:45:48 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-11-03 04:45:48 --> Anggota MX_Controller Initialized
INFO - 2016-11-03 04:45:48 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:48 --> Final output sent to browser
DEBUG - 2016-11-03 04:45:48 --> Total execution time: 0.5342
INFO - 2016-11-03 04:45:50 --> Config Class Initialized
INFO - 2016-11-03 04:45:50 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:45:50 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:45:50 --> Utf8 Class Initialized
INFO - 2016-11-03 04:45:50 --> URI Class Initialized
INFO - 2016-11-03 04:45:50 --> Router Class Initialized
INFO - 2016-11-03 04:45:50 --> Output Class Initialized
INFO - 2016-11-03 04:45:50 --> Security Class Initialized
DEBUG - 2016-11-03 04:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:45:50 --> Input Class Initialized
INFO - 2016-11-03 04:45:50 --> Language Class Initialized
INFO - 2016-11-03 04:45:50 --> Language Class Initialized
INFO - 2016-11-03 04:45:50 --> Config Class Initialized
INFO - 2016-11-03 04:45:51 --> Loader Class Initialized
INFO - 2016-11-03 04:45:51 --> Helper loaded: url_helper
INFO - 2016-11-03 04:45:51 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:45:51 --> Controller Class Initialized
DEBUG - 2016-11-03 04:45:51 --> Index MX_Controller Initialized
INFO - 2016-11-03 04:45:51 --> Model Class Initialized
INFO - 2016-11-03 04:45:51 --> Model Class Initialized
ERROR - 2016-11-03 04:45:51 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-11-03 04:45:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-11-03 04:45:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-11-03 04:45:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-11-03 04:45:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_umum.php
DEBUG - 2016-11-03 04:45:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-11-03 04:45:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-11-03 04:45:51 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:51 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:51 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:51 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:51 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:51 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:51 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:51 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:51 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:51 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:51 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:51 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:51 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:51 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:51 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:51 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:51 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:51 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:51 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:51 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:51 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:51 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:51 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:51 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:52 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:52 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:52 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:52 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:52 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:52 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:52 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:52 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:52 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:52 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:52 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:52 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:52 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:52 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:52 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:52 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:52 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:52 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:52 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:52 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:52 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:52 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:52 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:52 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:52 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:52 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:52 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:52 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:52 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:52 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:52 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:52 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:52 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:52 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:52 --> Database Driver Class Initialized
INFO - 2016-11-03 04:45:52 --> Database Driver Class Initialized
DEBUG - 2016-11-03 04:45:53 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-11-03 04:45:53 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-11-03 04:45:53 --> Final output sent to browser
DEBUG - 2016-11-03 04:45:53 --> Total execution time: 2.4728
INFO - 2016-11-03 04:46:01 --> Config Class Initialized
INFO - 2016-11-03 04:46:01 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:46:01 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:46:01 --> Utf8 Class Initialized
INFO - 2016-11-03 04:46:01 --> URI Class Initialized
INFO - 2016-11-03 04:46:01 --> Router Class Initialized
INFO - 2016-11-03 04:46:01 --> Output Class Initialized
INFO - 2016-11-03 04:46:02 --> Security Class Initialized
DEBUG - 2016-11-03 04:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:46:02 --> Input Class Initialized
INFO - 2016-11-03 04:46:02 --> Language Class Initialized
INFO - 2016-11-03 04:46:02 --> Language Class Initialized
INFO - 2016-11-03 04:46:02 --> Config Class Initialized
INFO - 2016-11-03 04:46:02 --> Loader Class Initialized
INFO - 2016-11-03 04:46:02 --> Helper loaded: url_helper
INFO - 2016-11-03 04:46:02 --> Database Driver Class Initialized
INFO - 2016-11-03 04:46:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:46:02 --> Controller Class Initialized
DEBUG - 2016-11-03 04:46:02 --> Index MX_Controller Initialized
INFO - 2016-11-03 04:46:02 --> Model Class Initialized
INFO - 2016-11-03 04:46:02 --> Model Class Initialized
ERROR - 2016-11-03 04:46:02 --> Unable to delete cache file for admin/index/do_ajukan_pinjaman
INFO - 2016-11-03 04:46:02 --> Database Driver Class Initialized
INFO - 2016-11-03 04:46:02 --> Database Driver Class Initialized
INFO - 2016-11-03 04:46:02 --> Final output sent to browser
DEBUG - 2016-11-03 04:46:02 --> Total execution time: 0.6487
INFO - 2016-11-03 04:46:27 --> Config Class Initialized
INFO - 2016-11-03 04:46:27 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:46:27 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:46:27 --> Utf8 Class Initialized
INFO - 2016-11-03 04:46:27 --> URI Class Initialized
INFO - 2016-11-03 04:46:27 --> Router Class Initialized
INFO - 2016-11-03 04:46:27 --> Output Class Initialized
INFO - 2016-11-03 04:46:27 --> Security Class Initialized
DEBUG - 2016-11-03 04:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:46:27 --> Input Class Initialized
INFO - 2016-11-03 04:46:27 --> Language Class Initialized
INFO - 2016-11-03 04:46:27 --> Language Class Initialized
INFO - 2016-11-03 04:46:27 --> Config Class Initialized
INFO - 2016-11-03 04:46:27 --> Loader Class Initialized
INFO - 2016-11-03 04:46:27 --> Helper loaded: url_helper
INFO - 2016-11-03 04:46:27 --> Database Driver Class Initialized
INFO - 2016-11-03 04:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:46:27 --> Controller Class Initialized
DEBUG - 2016-11-03 04:46:27 --> Index MX_Controller Initialized
INFO - 2016-11-03 04:46:27 --> Model Class Initialized
INFO - 2016-11-03 04:46:27 --> Model Class Initialized
ERROR - 2016-11-03 04:46:27 --> Unable to delete cache file for admin/index/do_save_jaminan/sertifikat
INFO - 2016-11-03 04:46:27 --> Database Driver Class Initialized
INFO - 2016-11-03 04:46:27 --> Final output sent to browser
DEBUG - 2016-11-03 04:46:27 --> Total execution time: 0.6539
INFO - 2016-11-03 04:46:38 --> Config Class Initialized
INFO - 2016-11-03 04:46:38 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:46:38 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:46:38 --> Utf8 Class Initialized
INFO - 2016-11-03 04:46:38 --> URI Class Initialized
INFO - 2016-11-03 04:46:38 --> Router Class Initialized
INFO - 2016-11-03 04:46:38 --> Output Class Initialized
INFO - 2016-11-03 04:46:38 --> Security Class Initialized
DEBUG - 2016-11-03 04:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:46:38 --> Input Class Initialized
INFO - 2016-11-03 04:46:39 --> Language Class Initialized
INFO - 2016-11-03 04:46:39 --> Language Class Initialized
INFO - 2016-11-03 04:46:39 --> Config Class Initialized
INFO - 2016-11-03 04:46:39 --> Loader Class Initialized
INFO - 2016-11-03 04:46:39 --> Helper loaded: url_helper
INFO - 2016-11-03 04:46:39 --> Database Driver Class Initialized
INFO - 2016-11-03 04:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:46:39 --> Controller Class Initialized
DEBUG - 2016-11-03 04:46:39 --> Index MX_Controller Initialized
INFO - 2016-11-03 04:46:39 --> Model Class Initialized
INFO - 2016-11-03 04:46:39 --> Model Class Initialized
ERROR - 2016-11-03 04:46:39 --> Unable to delete cache file for admin/index/cetak/0286dd552c9bea9a69ecb3759e7b94777635514b
INFO - 2016-11-03 04:46:39 --> Database Driver Class Initialized
INFO - 2016-11-03 04:46:39 --> Database Driver Class Initialized
DEBUG - 2016-11-03 04:46:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/perjanijan.php
INFO - 2016-11-03 04:46:39 --> Final output sent to browser
DEBUG - 2016-11-03 04:46:39 --> Total execution time: 0.6904
INFO - 2016-11-03 04:48:52 --> Config Class Initialized
INFO - 2016-11-03 04:48:52 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:48:52 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:48:52 --> Utf8 Class Initialized
INFO - 2016-11-03 04:48:52 --> URI Class Initialized
INFO - 2016-11-03 04:48:52 --> Router Class Initialized
INFO - 2016-11-03 04:48:52 --> Output Class Initialized
INFO - 2016-11-03 04:48:52 --> Security Class Initialized
DEBUG - 2016-11-03 04:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:48:52 --> Input Class Initialized
INFO - 2016-11-03 04:48:52 --> Language Class Initialized
INFO - 2016-11-03 04:48:53 --> Language Class Initialized
INFO - 2016-11-03 04:48:53 --> Config Class Initialized
INFO - 2016-11-03 04:48:53 --> Loader Class Initialized
INFO - 2016-11-03 04:48:53 --> Helper loaded: url_helper
INFO - 2016-11-03 04:48:53 --> Database Driver Class Initialized
INFO - 2016-11-03 04:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:48:53 --> Controller Class Initialized
DEBUG - 2016-11-03 04:48:53 --> Index MX_Controller Initialized
INFO - 2016-11-03 04:48:53 --> Model Class Initialized
INFO - 2016-11-03 04:48:53 --> Model Class Initialized
ERROR - 2016-11-03 04:48:53 --> Unable to delete cache file for admin/index/Terbilang/2500000
INFO - 2016-11-03 04:48:53 --> Final output sent to browser
DEBUG - 2016-11-03 04:48:53 --> Total execution time: 0.6758
INFO - 2016-11-03 04:49:27 --> Config Class Initialized
INFO - 2016-11-03 04:49:27 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:49:27 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:49:27 --> Utf8 Class Initialized
INFO - 2016-11-03 04:49:27 --> URI Class Initialized
INFO - 2016-11-03 04:49:27 --> Router Class Initialized
INFO - 2016-11-03 04:49:27 --> Output Class Initialized
INFO - 2016-11-03 04:49:27 --> Security Class Initialized
DEBUG - 2016-11-03 04:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:49:27 --> Input Class Initialized
INFO - 2016-11-03 04:49:27 --> Language Class Initialized
INFO - 2016-11-03 04:49:27 --> Language Class Initialized
INFO - 2016-11-03 04:49:27 --> Config Class Initialized
INFO - 2016-11-03 04:49:27 --> Loader Class Initialized
INFO - 2016-11-03 04:49:27 --> Helper loaded: url_helper
INFO - 2016-11-03 04:49:27 --> Database Driver Class Initialized
INFO - 2016-11-03 04:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:49:27 --> Controller Class Initialized
DEBUG - 2016-11-03 04:49:27 --> Index MX_Controller Initialized
INFO - 2016-11-03 04:49:27 --> Model Class Initialized
INFO - 2016-11-03 04:49:27 --> Model Class Initialized
ERROR - 2016-11-03 04:49:27 --> Unable to delete cache file for admin/index/testTerbilang/2500000
INFO - 2016-11-03 04:49:27 --> Final output sent to browser
DEBUG - 2016-11-03 04:49:27 --> Total execution time: 0.7075
INFO - 2016-11-03 04:49:34 --> Config Class Initialized
INFO - 2016-11-03 04:49:34 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:49:34 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:49:34 --> Utf8 Class Initialized
INFO - 2016-11-03 04:49:34 --> URI Class Initialized
INFO - 2016-11-03 04:49:34 --> Router Class Initialized
INFO - 2016-11-03 04:49:34 --> Output Class Initialized
INFO - 2016-11-03 04:49:34 --> Security Class Initialized
DEBUG - 2016-11-03 04:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:49:34 --> Input Class Initialized
INFO - 2016-11-03 04:49:34 --> Language Class Initialized
INFO - 2016-11-03 04:49:34 --> Language Class Initialized
INFO - 2016-11-03 04:49:34 --> Config Class Initialized
INFO - 2016-11-03 04:49:34 --> Loader Class Initialized
INFO - 2016-11-03 04:49:34 --> Helper loaded: url_helper
INFO - 2016-11-03 04:49:34 --> Database Driver Class Initialized
INFO - 2016-11-03 04:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:49:34 --> Controller Class Initialized
DEBUG - 2016-11-03 04:49:34 --> Index MX_Controller Initialized
INFO - 2016-11-03 04:49:34 --> Model Class Initialized
INFO - 2016-11-03 04:49:34 --> Model Class Initialized
ERROR - 2016-11-03 04:49:34 --> Unable to delete cache file for admin/index/testTerbilang/2500001
INFO - 2016-11-03 04:49:34 --> Final output sent to browser
DEBUG - 2016-11-03 04:49:34 --> Total execution time: 0.6166
INFO - 2016-11-03 04:49:39 --> Config Class Initialized
INFO - 2016-11-03 04:49:39 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:49:39 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:49:39 --> Utf8 Class Initialized
INFO - 2016-11-03 04:49:39 --> URI Class Initialized
INFO - 2016-11-03 04:49:39 --> Router Class Initialized
INFO - 2016-11-03 04:49:39 --> Output Class Initialized
INFO - 2016-11-03 04:49:39 --> Security Class Initialized
DEBUG - 2016-11-03 04:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:49:39 --> Input Class Initialized
INFO - 2016-11-03 04:49:39 --> Language Class Initialized
INFO - 2016-11-03 04:49:39 --> Language Class Initialized
INFO - 2016-11-03 04:49:39 --> Config Class Initialized
INFO - 2016-11-03 04:49:39 --> Loader Class Initialized
INFO - 2016-11-03 04:49:39 --> Helper loaded: url_helper
INFO - 2016-11-03 04:49:39 --> Database Driver Class Initialized
INFO - 2016-11-03 04:49:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:49:39 --> Controller Class Initialized
DEBUG - 2016-11-03 04:49:40 --> Index MX_Controller Initialized
INFO - 2016-11-03 04:49:40 --> Model Class Initialized
INFO - 2016-11-03 04:49:40 --> Model Class Initialized
ERROR - 2016-11-03 04:49:40 --> Unable to delete cache file for admin/index/testTerbilang/2500451
INFO - 2016-11-03 04:49:40 --> Final output sent to browser
DEBUG - 2016-11-03 04:49:40 --> Total execution time: 0.6464
INFO - 2016-11-03 04:49:47 --> Config Class Initialized
INFO - 2016-11-03 04:49:47 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:49:47 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:49:47 --> Utf8 Class Initialized
INFO - 2016-11-03 04:49:47 --> URI Class Initialized
INFO - 2016-11-03 04:49:47 --> Router Class Initialized
INFO - 2016-11-03 04:49:47 --> Output Class Initialized
INFO - 2016-11-03 04:49:47 --> Security Class Initialized
DEBUG - 2016-11-03 04:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:49:47 --> Input Class Initialized
INFO - 2016-11-03 04:49:47 --> Language Class Initialized
INFO - 2016-11-03 04:49:47 --> Language Class Initialized
INFO - 2016-11-03 04:49:47 --> Config Class Initialized
INFO - 2016-11-03 04:49:47 --> Loader Class Initialized
INFO - 2016-11-03 04:49:47 --> Helper loaded: url_helper
INFO - 2016-11-03 04:49:47 --> Database Driver Class Initialized
INFO - 2016-11-03 04:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:49:47 --> Controller Class Initialized
DEBUG - 2016-11-03 04:49:47 --> Index MX_Controller Initialized
INFO - 2016-11-03 04:49:47 --> Model Class Initialized
INFO - 2016-11-03 04:49:47 --> Model Class Initialized
ERROR - 2016-11-03 04:49:47 --> Unable to delete cache file for admin/index/testTerbilang/2501451
INFO - 2016-11-03 04:49:47 --> Final output sent to browser
DEBUG - 2016-11-03 04:49:47 --> Total execution time: 0.6404
INFO - 2016-11-03 04:49:57 --> Config Class Initialized
INFO - 2016-11-03 04:49:57 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:49:57 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:49:57 --> Utf8 Class Initialized
INFO - 2016-11-03 04:49:57 --> URI Class Initialized
INFO - 2016-11-03 04:49:57 --> Router Class Initialized
INFO - 2016-11-03 04:49:57 --> Output Class Initialized
INFO - 2016-11-03 04:49:57 --> Security Class Initialized
DEBUG - 2016-11-03 04:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:49:57 --> Input Class Initialized
INFO - 2016-11-03 04:49:57 --> Language Class Initialized
INFO - 2016-11-03 04:49:57 --> Language Class Initialized
INFO - 2016-11-03 04:49:57 --> Config Class Initialized
INFO - 2016-11-03 04:49:57 --> Loader Class Initialized
INFO - 2016-11-03 04:49:57 --> Helper loaded: url_helper
INFO - 2016-11-03 04:49:57 --> Database Driver Class Initialized
INFO - 2016-11-03 04:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:49:57 --> Controller Class Initialized
DEBUG - 2016-11-03 04:49:57 --> Index MX_Controller Initialized
INFO - 2016-11-03 04:49:57 --> Model Class Initialized
INFO - 2016-11-03 04:49:57 --> Model Class Initialized
ERROR - 2016-11-03 04:49:57 --> Unable to delete cache file for admin/index/testTerbilang/25231451
INFO - 2016-11-03 04:49:57 --> Final output sent to browser
DEBUG - 2016-11-03 04:49:57 --> Total execution time: 0.6733
INFO - 2016-11-03 04:50:08 --> Config Class Initialized
INFO - 2016-11-03 04:50:08 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:50:08 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:50:08 --> Utf8 Class Initialized
INFO - 2016-11-03 04:50:08 --> URI Class Initialized
INFO - 2016-11-03 04:50:08 --> Router Class Initialized
INFO - 2016-11-03 04:50:08 --> Output Class Initialized
INFO - 2016-11-03 04:50:08 --> Security Class Initialized
DEBUG - 2016-11-03 04:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:50:08 --> Input Class Initialized
INFO - 2016-11-03 04:50:08 --> Language Class Initialized
INFO - 2016-11-03 04:50:08 --> Language Class Initialized
INFO - 2016-11-03 04:50:08 --> Config Class Initialized
INFO - 2016-11-03 04:50:08 --> Loader Class Initialized
INFO - 2016-11-03 04:50:08 --> Helper loaded: url_helper
INFO - 2016-11-03 04:50:08 --> Database Driver Class Initialized
INFO - 2016-11-03 04:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:50:08 --> Controller Class Initialized
DEBUG - 2016-11-03 04:50:08 --> Index MX_Controller Initialized
INFO - 2016-11-03 04:50:08 --> Model Class Initialized
INFO - 2016-11-03 04:50:08 --> Model Class Initialized
ERROR - 2016-11-03 04:50:08 --> Unable to delete cache file for admin/index/testTerbilang/2501451
INFO - 2016-11-03 04:50:08 --> Final output sent to browser
DEBUG - 2016-11-03 04:50:08 --> Total execution time: 0.5662
INFO - 2016-11-03 04:50:10 --> Config Class Initialized
INFO - 2016-11-03 04:50:10 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:50:10 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:50:10 --> Utf8 Class Initialized
INFO - 2016-11-03 04:50:10 --> URI Class Initialized
INFO - 2016-11-03 04:50:10 --> Router Class Initialized
INFO - 2016-11-03 04:50:10 --> Output Class Initialized
INFO - 2016-11-03 04:50:10 --> Security Class Initialized
DEBUG - 2016-11-03 04:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:50:10 --> Input Class Initialized
INFO - 2016-11-03 04:50:10 --> Language Class Initialized
INFO - 2016-11-03 04:50:10 --> Language Class Initialized
INFO - 2016-11-03 04:50:10 --> Config Class Initialized
INFO - 2016-11-03 04:50:11 --> Loader Class Initialized
INFO - 2016-11-03 04:50:11 --> Helper loaded: url_helper
INFO - 2016-11-03 04:50:11 --> Database Driver Class Initialized
INFO - 2016-11-03 04:50:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:50:11 --> Controller Class Initialized
DEBUG - 2016-11-03 04:50:11 --> Index MX_Controller Initialized
INFO - 2016-11-03 04:50:11 --> Model Class Initialized
INFO - 2016-11-03 04:50:11 --> Model Class Initialized
ERROR - 2016-11-03 04:50:11 --> Unable to delete cache file for admin/index/testTerbilang/2500451
INFO - 2016-11-03 04:50:11 --> Final output sent to browser
DEBUG - 2016-11-03 04:50:11 --> Total execution time: 0.5919
INFO - 2016-11-03 04:50:11 --> Config Class Initialized
INFO - 2016-11-03 04:50:11 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:50:11 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:50:11 --> Utf8 Class Initialized
INFO - 2016-11-03 04:50:11 --> URI Class Initialized
INFO - 2016-11-03 04:50:11 --> Router Class Initialized
INFO - 2016-11-03 04:50:11 --> Output Class Initialized
INFO - 2016-11-03 04:50:12 --> Security Class Initialized
DEBUG - 2016-11-03 04:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:50:12 --> Input Class Initialized
INFO - 2016-11-03 04:50:12 --> Language Class Initialized
INFO - 2016-11-03 04:50:12 --> Language Class Initialized
INFO - 2016-11-03 04:50:12 --> Config Class Initialized
INFO - 2016-11-03 04:50:12 --> Loader Class Initialized
INFO - 2016-11-03 04:50:12 --> Helper loaded: url_helper
INFO - 2016-11-03 04:50:12 --> Database Driver Class Initialized
INFO - 2016-11-03 04:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:50:12 --> Controller Class Initialized
DEBUG - 2016-11-03 04:50:12 --> Index MX_Controller Initialized
INFO - 2016-11-03 04:50:12 --> Model Class Initialized
INFO - 2016-11-03 04:50:12 --> Model Class Initialized
ERROR - 2016-11-03 04:50:12 --> Unable to delete cache file for admin/index/testTerbilang/2500001
INFO - 2016-11-03 04:50:12 --> Final output sent to browser
DEBUG - 2016-11-03 04:50:12 --> Total execution time: 0.5642
INFO - 2016-11-03 04:50:12 --> Config Class Initialized
INFO - 2016-11-03 04:50:12 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:50:12 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:50:12 --> Utf8 Class Initialized
INFO - 2016-11-03 04:50:12 --> URI Class Initialized
INFO - 2016-11-03 04:50:13 --> Router Class Initialized
INFO - 2016-11-03 04:50:13 --> Output Class Initialized
INFO - 2016-11-03 04:50:13 --> Security Class Initialized
DEBUG - 2016-11-03 04:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:50:13 --> Input Class Initialized
INFO - 2016-11-03 04:50:13 --> Language Class Initialized
INFO - 2016-11-03 04:50:13 --> Language Class Initialized
INFO - 2016-11-03 04:50:13 --> Config Class Initialized
INFO - 2016-11-03 04:50:13 --> Loader Class Initialized
INFO - 2016-11-03 04:50:13 --> Helper loaded: url_helper
INFO - 2016-11-03 04:50:13 --> Database Driver Class Initialized
INFO - 2016-11-03 04:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:50:13 --> Controller Class Initialized
DEBUG - 2016-11-03 04:50:13 --> Index MX_Controller Initialized
INFO - 2016-11-03 04:50:13 --> Model Class Initialized
INFO - 2016-11-03 04:50:13 --> Model Class Initialized
ERROR - 2016-11-03 04:50:13 --> Unable to delete cache file for admin/index/testTerbilang/2500000
INFO - 2016-11-03 04:50:13 --> Final output sent to browser
DEBUG - 2016-11-03 04:50:13 --> Total execution time: 0.5611
INFO - 2016-11-03 04:50:13 --> Config Class Initialized
INFO - 2016-11-03 04:50:13 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:50:13 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:50:14 --> Utf8 Class Initialized
INFO - 2016-11-03 04:50:14 --> URI Class Initialized
INFO - 2016-11-03 04:50:14 --> Router Class Initialized
INFO - 2016-11-03 04:50:14 --> Output Class Initialized
INFO - 2016-11-03 04:50:14 --> Security Class Initialized
DEBUG - 2016-11-03 04:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:50:14 --> Input Class Initialized
INFO - 2016-11-03 04:50:14 --> Language Class Initialized
INFO - 2016-11-03 04:50:14 --> Language Class Initialized
INFO - 2016-11-03 04:50:14 --> Config Class Initialized
INFO - 2016-11-03 04:50:14 --> Loader Class Initialized
INFO - 2016-11-03 04:50:14 --> Helper loaded: url_helper
INFO - 2016-11-03 04:50:14 --> Database Driver Class Initialized
INFO - 2016-11-03 04:50:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:50:14 --> Controller Class Initialized
DEBUG - 2016-11-03 04:50:14 --> Index MX_Controller Initialized
INFO - 2016-11-03 04:50:14 --> Model Class Initialized
INFO - 2016-11-03 04:50:14 --> Model Class Initialized
ERROR - 2016-11-03 04:50:14 --> Unable to delete cache file for admin/index/Terbilang/2500000
INFO - 2016-11-03 04:50:14 --> Final output sent to browser
DEBUG - 2016-11-03 04:50:14 --> Total execution time: 0.5570
INFO - 2016-11-03 04:50:15 --> Config Class Initialized
INFO - 2016-11-03 04:50:15 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:50:15 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:50:15 --> Utf8 Class Initialized
INFO - 2016-11-03 04:50:15 --> URI Class Initialized
INFO - 2016-11-03 04:50:15 --> Router Class Initialized
INFO - 2016-11-03 04:50:15 --> Output Class Initialized
INFO - 2016-11-03 04:50:15 --> Security Class Initialized
DEBUG - 2016-11-03 04:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:50:15 --> Input Class Initialized
INFO - 2016-11-03 04:50:15 --> Language Class Initialized
INFO - 2016-11-03 04:50:15 --> Language Class Initialized
INFO - 2016-11-03 04:50:15 --> Config Class Initialized
INFO - 2016-11-03 04:50:15 --> Loader Class Initialized
INFO - 2016-11-03 04:50:15 --> Helper loaded: url_helper
INFO - 2016-11-03 04:50:15 --> Database Driver Class Initialized
INFO - 2016-11-03 04:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:50:15 --> Controller Class Initialized
DEBUG - 2016-11-03 04:50:15 --> Index MX_Controller Initialized
INFO - 2016-11-03 04:50:15 --> Model Class Initialized
INFO - 2016-11-03 04:50:15 --> Model Class Initialized
ERROR - 2016-11-03 04:50:15 --> Unable to delete cache file for admin/index/cetak/0286dd552c9bea9a69ecb3759e7b94777635514b
INFO - 2016-11-03 04:50:15 --> Database Driver Class Initialized
INFO - 2016-11-03 04:50:15 --> Database Driver Class Initialized
DEBUG - 2016-11-03 04:50:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/perjanijan.php
INFO - 2016-11-03 04:50:15 --> Final output sent to browser
DEBUG - 2016-11-03 04:50:15 --> Total execution time: 0.6488
INFO - 2016-11-03 04:52:15 --> Config Class Initialized
INFO - 2016-11-03 04:52:15 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:52:15 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:52:15 --> Utf8 Class Initialized
INFO - 2016-11-03 04:52:15 --> URI Class Initialized
INFO - 2016-11-03 04:52:15 --> Router Class Initialized
INFO - 2016-11-03 04:52:15 --> Output Class Initialized
INFO - 2016-11-03 04:52:15 --> Security Class Initialized
DEBUG - 2016-11-03 04:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:52:15 --> Input Class Initialized
INFO - 2016-11-03 04:52:15 --> Language Class Initialized
INFO - 2016-11-03 04:52:15 --> Language Class Initialized
INFO - 2016-11-03 04:52:16 --> Config Class Initialized
INFO - 2016-11-03 04:52:16 --> Loader Class Initialized
INFO - 2016-11-03 04:52:16 --> Helper loaded: url_helper
INFO - 2016-11-03 04:52:16 --> Database Driver Class Initialized
INFO - 2016-11-03 04:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:52:16 --> Controller Class Initialized
DEBUG - 2016-11-03 04:52:16 --> Index MX_Controller Initialized
INFO - 2016-11-03 04:52:16 --> Model Class Initialized
INFO - 2016-11-03 04:52:16 --> Model Class Initialized
ERROR - 2016-11-03 04:52:16 --> Unable to delete cache file for admin/index/cetak/0286dd552c9bea9a69ecb3759e7b94777635514b
INFO - 2016-11-03 04:52:16 --> Database Driver Class Initialized
INFO - 2016-11-03 04:52:16 --> Database Driver Class Initialized
DEBUG - 2016-11-03 04:52:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/perjanijan.php
INFO - 2016-11-03 04:52:16 --> Final output sent to browser
DEBUG - 2016-11-03 04:52:16 --> Total execution time: 0.6553
INFO - 2016-11-03 04:53:09 --> Config Class Initialized
INFO - 2016-11-03 04:53:09 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:53:09 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:53:09 --> Utf8 Class Initialized
INFO - 2016-11-03 04:53:09 --> URI Class Initialized
INFO - 2016-11-03 04:53:09 --> Router Class Initialized
INFO - 2016-11-03 04:53:09 --> Output Class Initialized
INFO - 2016-11-03 04:53:09 --> Security Class Initialized
DEBUG - 2016-11-03 04:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:53:09 --> Input Class Initialized
INFO - 2016-11-03 04:53:09 --> Language Class Initialized
INFO - 2016-11-03 04:53:09 --> Language Class Initialized
INFO - 2016-11-03 04:53:10 --> Config Class Initialized
INFO - 2016-11-03 04:53:10 --> Loader Class Initialized
INFO - 2016-11-03 04:53:10 --> Helper loaded: url_helper
INFO - 2016-11-03 04:53:10 --> Database Driver Class Initialized
INFO - 2016-11-03 04:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:53:10 --> Controller Class Initialized
DEBUG - 2016-11-03 04:53:10 --> Index MX_Controller Initialized
INFO - 2016-11-03 04:53:10 --> Model Class Initialized
INFO - 2016-11-03 04:53:10 --> Model Class Initialized
ERROR - 2016-11-03 04:53:10 --> Unable to delete cache file for admin/index/cetak/0286dd552c9bea9a69ecb3759e7b94777635514b
INFO - 2016-11-03 04:53:10 --> Database Driver Class Initialized
INFO - 2016-11-03 04:53:10 --> Database Driver Class Initialized
DEBUG - 2016-11-03 04:53:10 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/perjanijan.php
INFO - 2016-11-03 04:53:10 --> Final output sent to browser
DEBUG - 2016-11-03 04:53:10 --> Total execution time: 0.7478
INFO - 2016-11-03 04:53:43 --> Config Class Initialized
INFO - 2016-11-03 04:53:43 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:53:43 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:53:43 --> Utf8 Class Initialized
INFO - 2016-11-03 04:53:43 --> URI Class Initialized
INFO - 2016-11-03 04:53:43 --> Router Class Initialized
INFO - 2016-11-03 04:53:43 --> Output Class Initialized
INFO - 2016-11-03 04:53:43 --> Security Class Initialized
DEBUG - 2016-11-03 04:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:53:43 --> Input Class Initialized
INFO - 2016-11-03 04:53:43 --> Language Class Initialized
INFO - 2016-11-03 04:53:43 --> Language Class Initialized
INFO - 2016-11-03 04:53:43 --> Config Class Initialized
INFO - 2016-11-03 04:53:43 --> Loader Class Initialized
INFO - 2016-11-03 04:53:43 --> Helper loaded: url_helper
INFO - 2016-11-03 04:53:43 --> Database Driver Class Initialized
INFO - 2016-11-03 04:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:53:43 --> Controller Class Initialized
DEBUG - 2016-11-03 04:53:43 --> Index MX_Controller Initialized
INFO - 2016-11-03 04:53:43 --> Model Class Initialized
INFO - 2016-11-03 04:53:43 --> Model Class Initialized
ERROR - 2016-11-03 04:53:43 --> Unable to delete cache file for admin/index/cetak/0286dd552c9bea9a69ecb3759e7b94777635514b
INFO - 2016-11-03 04:53:43 --> Database Driver Class Initialized
INFO - 2016-11-03 04:53:43 --> Database Driver Class Initialized
DEBUG - 2016-11-03 04:53:43 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/perjanijan.php
INFO - 2016-11-03 04:53:43 --> Final output sent to browser
DEBUG - 2016-11-03 04:53:43 --> Total execution time: 0.6565
INFO - 2016-11-03 04:55:36 --> Config Class Initialized
INFO - 2016-11-03 04:55:36 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:55:36 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:55:36 --> Utf8 Class Initialized
INFO - 2016-11-03 04:55:36 --> URI Class Initialized
INFO - 2016-11-03 04:55:36 --> Router Class Initialized
INFO - 2016-11-03 04:55:36 --> Output Class Initialized
INFO - 2016-11-03 04:55:36 --> Security Class Initialized
DEBUG - 2016-11-03 04:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:55:36 --> Input Class Initialized
INFO - 2016-11-03 04:55:36 --> Language Class Initialized
INFO - 2016-11-03 04:55:36 --> Language Class Initialized
INFO - 2016-11-03 04:55:36 --> Config Class Initialized
INFO - 2016-11-03 04:55:36 --> Loader Class Initialized
INFO - 2016-11-03 04:55:36 --> Helper loaded: url_helper
INFO - 2016-11-03 04:55:36 --> Database Driver Class Initialized
INFO - 2016-11-03 04:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:55:36 --> Controller Class Initialized
DEBUG - 2016-11-03 04:55:36 --> Index MX_Controller Initialized
INFO - 2016-11-03 04:55:36 --> Model Class Initialized
INFO - 2016-11-03 04:55:36 --> Model Class Initialized
ERROR - 2016-11-03 04:55:36 --> Unable to delete cache file for admin/index/cetak/0286dd552c9bea9a69ecb3759e7b94777635514b
INFO - 2016-11-03 04:55:36 --> Database Driver Class Initialized
INFO - 2016-11-03 04:55:36 --> Database Driver Class Initialized
DEBUG - 2016-11-03 04:55:37 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/perjanijan.php
INFO - 2016-11-03 04:55:37 --> Final output sent to browser
DEBUG - 2016-11-03 04:55:37 --> Total execution time: 0.6732
INFO - 2016-11-03 04:55:48 --> Config Class Initialized
INFO - 2016-11-03 04:55:48 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:55:48 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:55:48 --> Utf8 Class Initialized
INFO - 2016-11-03 04:55:48 --> URI Class Initialized
INFO - 2016-11-03 04:55:48 --> Router Class Initialized
INFO - 2016-11-03 04:55:48 --> Output Class Initialized
INFO - 2016-11-03 04:55:48 --> Security Class Initialized
DEBUG - 2016-11-03 04:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:55:48 --> Input Class Initialized
INFO - 2016-11-03 04:55:48 --> Language Class Initialized
INFO - 2016-11-03 04:55:48 --> Language Class Initialized
INFO - 2016-11-03 04:55:48 --> Config Class Initialized
INFO - 2016-11-03 04:55:48 --> Loader Class Initialized
INFO - 2016-11-03 04:55:48 --> Helper loaded: url_helper
INFO - 2016-11-03 04:55:48 --> Database Driver Class Initialized
INFO - 2016-11-03 04:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:55:48 --> Controller Class Initialized
DEBUG - 2016-11-03 04:55:48 --> Index MX_Controller Initialized
INFO - 2016-11-03 04:55:48 --> Model Class Initialized
INFO - 2016-11-03 04:55:48 --> Model Class Initialized
ERROR - 2016-11-03 04:55:49 --> Unable to delete cache file for admin/index/cetak/0286dd552c9bea9a69ecb3759e7b94777635514b
INFO - 2016-11-03 04:55:49 --> Database Driver Class Initialized
INFO - 2016-11-03 04:55:49 --> Database Driver Class Initialized
DEBUG - 2016-11-03 04:55:49 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/perjanijan.php
INFO - 2016-11-03 04:55:49 --> Final output sent to browser
DEBUG - 2016-11-03 04:55:49 --> Total execution time: 0.6665
INFO - 2016-11-03 04:55:51 --> Config Class Initialized
INFO - 2016-11-03 04:55:51 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:55:51 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:55:51 --> Utf8 Class Initialized
INFO - 2016-11-03 04:55:51 --> URI Class Initialized
INFO - 2016-11-03 04:55:51 --> Router Class Initialized
INFO - 2016-11-03 04:55:51 --> Output Class Initialized
INFO - 2016-11-03 04:55:51 --> Security Class Initialized
DEBUG - 2016-11-03 04:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:55:51 --> Input Class Initialized
INFO - 2016-11-03 04:55:51 --> Language Class Initialized
INFO - 2016-11-03 04:55:51 --> Language Class Initialized
INFO - 2016-11-03 04:55:51 --> Config Class Initialized
INFO - 2016-11-03 04:55:51 --> Loader Class Initialized
INFO - 2016-11-03 04:55:51 --> Helper loaded: url_helper
INFO - 2016-11-03 04:55:51 --> Database Driver Class Initialized
INFO - 2016-11-03 04:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:55:51 --> Controller Class Initialized
DEBUG - 2016-11-03 04:55:51 --> Index MX_Controller Initialized
INFO - 2016-11-03 04:55:51 --> Model Class Initialized
INFO - 2016-11-03 04:55:51 --> Model Class Initialized
ERROR - 2016-11-03 04:55:51 --> Unable to delete cache file for admin/index/cetak/0286dd552c9bea9a69ecb3759e7b94777635514b
INFO - 2016-11-03 04:55:51 --> Database Driver Class Initialized
INFO - 2016-11-03 04:55:51 --> Database Driver Class Initialized
DEBUG - 2016-11-03 04:55:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/perjanijan.php
INFO - 2016-11-03 04:55:51 --> Final output sent to browser
DEBUG - 2016-11-03 04:55:51 --> Total execution time: 0.6626
INFO - 2016-11-03 04:56:22 --> Config Class Initialized
INFO - 2016-11-03 04:56:22 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:56:22 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:56:22 --> Utf8 Class Initialized
INFO - 2016-11-03 04:56:22 --> URI Class Initialized
INFO - 2016-11-03 04:56:22 --> Router Class Initialized
INFO - 2016-11-03 04:56:22 --> Output Class Initialized
INFO - 2016-11-03 04:56:22 --> Security Class Initialized
DEBUG - 2016-11-03 04:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:56:22 --> Input Class Initialized
INFO - 2016-11-03 04:56:22 --> Language Class Initialized
INFO - 2016-11-03 04:56:22 --> Language Class Initialized
INFO - 2016-11-03 04:56:22 --> Config Class Initialized
INFO - 2016-11-03 04:56:22 --> Loader Class Initialized
INFO - 2016-11-03 04:56:22 --> Helper loaded: url_helper
INFO - 2016-11-03 04:56:22 --> Database Driver Class Initialized
INFO - 2016-11-03 04:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:56:22 --> Controller Class Initialized
DEBUG - 2016-11-03 04:56:22 --> Index MX_Controller Initialized
INFO - 2016-11-03 04:56:22 --> Model Class Initialized
INFO - 2016-11-03 04:56:22 --> Model Class Initialized
ERROR - 2016-11-03 04:56:22 --> Unable to delete cache file for admin/index/cetak/0286dd552c9bea9a69ecb3759e7b94777635514b
INFO - 2016-11-03 04:56:22 --> Database Driver Class Initialized
INFO - 2016-11-03 04:56:22 --> Database Driver Class Initialized
DEBUG - 2016-11-03 04:56:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/perjanijan.php
INFO - 2016-11-03 04:56:22 --> Final output sent to browser
DEBUG - 2016-11-03 04:56:22 --> Total execution time: 0.6589
INFO - 2016-11-03 04:56:41 --> Config Class Initialized
INFO - 2016-11-03 04:56:41 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:56:41 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:56:41 --> Utf8 Class Initialized
INFO - 2016-11-03 04:56:41 --> URI Class Initialized
INFO - 2016-11-03 04:56:41 --> Router Class Initialized
INFO - 2016-11-03 04:56:41 --> Output Class Initialized
INFO - 2016-11-03 04:56:41 --> Security Class Initialized
DEBUG - 2016-11-03 04:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:56:41 --> Input Class Initialized
INFO - 2016-11-03 04:56:41 --> Language Class Initialized
INFO - 2016-11-03 04:56:41 --> Language Class Initialized
INFO - 2016-11-03 04:56:41 --> Config Class Initialized
INFO - 2016-11-03 04:56:41 --> Loader Class Initialized
INFO - 2016-11-03 04:56:41 --> Helper loaded: url_helper
INFO - 2016-11-03 04:56:41 --> Database Driver Class Initialized
INFO - 2016-11-03 04:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:56:41 --> Controller Class Initialized
DEBUG - 2016-11-03 04:56:41 --> Index MX_Controller Initialized
INFO - 2016-11-03 04:56:41 --> Model Class Initialized
INFO - 2016-11-03 04:56:41 --> Model Class Initialized
ERROR - 2016-11-03 04:56:41 --> Unable to delete cache file for admin/index/cetak/0286dd552c9bea9a69ecb3759e7b94777635514b
INFO - 2016-11-03 04:56:41 --> Database Driver Class Initialized
INFO - 2016-11-03 04:56:41 --> Database Driver Class Initialized
DEBUG - 2016-11-03 04:56:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/perjanijan.php
INFO - 2016-11-03 04:56:41 --> Final output sent to browser
DEBUG - 2016-11-03 04:56:41 --> Total execution time: 0.6634
INFO - 2016-11-03 04:57:15 --> Config Class Initialized
INFO - 2016-11-03 04:57:15 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:57:15 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:57:15 --> Utf8 Class Initialized
INFO - 2016-11-03 04:57:15 --> URI Class Initialized
INFO - 2016-11-03 04:57:15 --> Router Class Initialized
INFO - 2016-11-03 04:57:15 --> Output Class Initialized
INFO - 2016-11-03 04:57:15 --> Security Class Initialized
DEBUG - 2016-11-03 04:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:57:15 --> Input Class Initialized
INFO - 2016-11-03 04:57:15 --> Language Class Initialized
INFO - 2016-11-03 04:57:16 --> Language Class Initialized
INFO - 2016-11-03 04:57:16 --> Config Class Initialized
INFO - 2016-11-03 04:57:16 --> Loader Class Initialized
INFO - 2016-11-03 04:57:16 --> Helper loaded: url_helper
INFO - 2016-11-03 04:57:16 --> Database Driver Class Initialized
INFO - 2016-11-03 04:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:57:16 --> Controller Class Initialized
DEBUG - 2016-11-03 04:57:16 --> Index MX_Controller Initialized
INFO - 2016-11-03 04:57:16 --> Model Class Initialized
INFO - 2016-11-03 04:57:16 --> Model Class Initialized
ERROR - 2016-11-03 04:57:16 --> Unable to delete cache file for admin/index/cetak/0286dd552c9bea9a69ecb3759e7b94777635514b
INFO - 2016-11-03 04:57:16 --> Database Driver Class Initialized
INFO - 2016-11-03 04:57:16 --> Database Driver Class Initialized
DEBUG - 2016-11-03 04:57:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/perjanijan.php
INFO - 2016-11-03 04:57:16 --> Final output sent to browser
DEBUG - 2016-11-03 04:57:16 --> Total execution time: 0.6851
INFO - 2016-11-03 04:57:43 --> Config Class Initialized
INFO - 2016-11-03 04:57:43 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:57:43 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:57:43 --> Utf8 Class Initialized
INFO - 2016-11-03 04:57:43 --> URI Class Initialized
INFO - 2016-11-03 04:57:43 --> Router Class Initialized
INFO - 2016-11-03 04:57:43 --> Output Class Initialized
INFO - 2016-11-03 04:57:43 --> Security Class Initialized
DEBUG - 2016-11-03 04:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:57:43 --> Input Class Initialized
INFO - 2016-11-03 04:57:43 --> Language Class Initialized
INFO - 2016-11-03 04:57:43 --> Language Class Initialized
INFO - 2016-11-03 04:57:43 --> Config Class Initialized
INFO - 2016-11-03 04:57:43 --> Loader Class Initialized
INFO - 2016-11-03 04:57:43 --> Helper loaded: url_helper
INFO - 2016-11-03 04:57:43 --> Database Driver Class Initialized
INFO - 2016-11-03 04:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:57:43 --> Controller Class Initialized
DEBUG - 2016-11-03 04:57:43 --> Index MX_Controller Initialized
INFO - 2016-11-03 04:57:43 --> Model Class Initialized
INFO - 2016-11-03 04:57:43 --> Model Class Initialized
ERROR - 2016-11-03 04:57:43 --> Unable to delete cache file for admin/index/cetak/0286dd552c9bea9a69ecb3759e7b94777635514b
INFO - 2016-11-03 04:57:43 --> Database Driver Class Initialized
INFO - 2016-11-03 04:57:43 --> Database Driver Class Initialized
DEBUG - 2016-11-03 04:57:43 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/perjanijan.php
INFO - 2016-11-03 04:57:43 --> Final output sent to browser
DEBUG - 2016-11-03 04:57:43 --> Total execution time: 0.7230
INFO - 2016-11-03 04:58:13 --> Config Class Initialized
INFO - 2016-11-03 04:58:13 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:58:13 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:58:13 --> Utf8 Class Initialized
INFO - 2016-11-03 04:58:13 --> URI Class Initialized
INFO - 2016-11-03 04:58:14 --> Router Class Initialized
INFO - 2016-11-03 04:58:14 --> Output Class Initialized
INFO - 2016-11-03 04:58:14 --> Security Class Initialized
DEBUG - 2016-11-03 04:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:58:14 --> Input Class Initialized
INFO - 2016-11-03 04:58:14 --> Language Class Initialized
INFO - 2016-11-03 04:58:14 --> Language Class Initialized
INFO - 2016-11-03 04:58:14 --> Config Class Initialized
INFO - 2016-11-03 04:58:14 --> Loader Class Initialized
INFO - 2016-11-03 04:58:14 --> Helper loaded: url_helper
INFO - 2016-11-03 04:58:14 --> Database Driver Class Initialized
INFO - 2016-11-03 04:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:58:14 --> Controller Class Initialized
DEBUG - 2016-11-03 04:58:14 --> Index MX_Controller Initialized
INFO - 2016-11-03 04:58:14 --> Model Class Initialized
INFO - 2016-11-03 04:58:14 --> Model Class Initialized
ERROR - 2016-11-03 04:58:14 --> Unable to delete cache file for admin/index/cetak/0286dd552c9bea9a69ecb3759e7b94777635514b
INFO - 2016-11-03 04:58:14 --> Database Driver Class Initialized
INFO - 2016-11-03 04:58:14 --> Database Driver Class Initialized
DEBUG - 2016-11-03 04:58:14 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/perjanijan.php
INFO - 2016-11-03 04:58:14 --> Final output sent to browser
DEBUG - 2016-11-03 04:58:14 --> Total execution time: 0.6735
INFO - 2016-11-03 04:59:26 --> Config Class Initialized
INFO - 2016-11-03 04:59:26 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:59:26 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:59:26 --> Utf8 Class Initialized
INFO - 2016-11-03 04:59:26 --> URI Class Initialized
INFO - 2016-11-03 04:59:26 --> Router Class Initialized
INFO - 2016-11-03 04:59:26 --> Output Class Initialized
INFO - 2016-11-03 04:59:26 --> Security Class Initialized
DEBUG - 2016-11-03 04:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:59:26 --> Input Class Initialized
INFO - 2016-11-03 04:59:26 --> Language Class Initialized
INFO - 2016-11-03 04:59:26 --> Language Class Initialized
INFO - 2016-11-03 04:59:26 --> Config Class Initialized
INFO - 2016-11-03 04:59:26 --> Loader Class Initialized
INFO - 2016-11-03 04:59:26 --> Helper loaded: url_helper
INFO - 2016-11-03 04:59:26 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:59:26 --> Controller Class Initialized
DEBUG - 2016-11-03 04:59:26 --> Index MX_Controller Initialized
INFO - 2016-11-03 04:59:26 --> Model Class Initialized
INFO - 2016-11-03 04:59:26 --> Model Class Initialized
ERROR - 2016-11-03 04:59:26 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-11-03 04:59:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-11-03 04:59:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-11-03 04:59:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-11-03 04:59:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-11-03 04:59:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-11-03 04:59:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-11-03 04:59:27 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:27 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:27 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:27 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:27 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:27 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:27 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:27 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:27 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:27 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:27 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:27 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:27 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:27 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:27 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:27 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:27 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:27 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:27 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:27 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:27 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:27 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:27 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:27 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:27 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:27 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:27 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:27 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:27 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:28 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:28 --> Database Driver Class Initialized
DEBUG - 2016-11-03 04:59:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-11-03 04:59:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-11-03 04:59:28 --> Final output sent to browser
DEBUG - 2016-11-03 04:59:29 --> Total execution time: 2.7754
INFO - 2016-11-03 04:59:32 --> Config Class Initialized
INFO - 2016-11-03 04:59:32 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:59:32 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:59:32 --> Utf8 Class Initialized
INFO - 2016-11-03 04:59:32 --> URI Class Initialized
INFO - 2016-11-03 04:59:32 --> Router Class Initialized
INFO - 2016-11-03 04:59:32 --> Output Class Initialized
INFO - 2016-11-03 04:59:32 --> Security Class Initialized
DEBUG - 2016-11-03 04:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:59:32 --> Input Class Initialized
INFO - 2016-11-03 04:59:32 --> Language Class Initialized
INFO - 2016-11-03 04:59:32 --> Language Class Initialized
INFO - 2016-11-03 04:59:32 --> Config Class Initialized
INFO - 2016-11-03 04:59:32 --> Loader Class Initialized
INFO - 2016-11-03 04:59:32 --> Helper loaded: url_helper
INFO - 2016-11-03 04:59:32 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:59:32 --> Controller Class Initialized
DEBUG - 2016-11-03 04:59:32 --> Index MX_Controller Initialized
INFO - 2016-11-03 04:59:32 --> Model Class Initialized
INFO - 2016-11-03 04:59:32 --> Model Class Initialized
ERROR - 2016-11-03 04:59:32 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-11-03 04:59:32 --> Anggota MX_Controller Initialized
INFO - 2016-11-03 04:59:32 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:32 --> Final output sent to browser
DEBUG - 2016-11-03 04:59:32 --> Total execution time: 0.5525
INFO - 2016-11-03 04:59:39 --> Config Class Initialized
INFO - 2016-11-03 04:59:39 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:59:39 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:59:39 --> Utf8 Class Initialized
INFO - 2016-11-03 04:59:39 --> URI Class Initialized
INFO - 2016-11-03 04:59:39 --> Router Class Initialized
INFO - 2016-11-03 04:59:39 --> Output Class Initialized
INFO - 2016-11-03 04:59:39 --> Security Class Initialized
DEBUG - 2016-11-03 04:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:59:39 --> Input Class Initialized
INFO - 2016-11-03 04:59:39 --> Language Class Initialized
INFO - 2016-11-03 04:59:39 --> Language Class Initialized
INFO - 2016-11-03 04:59:39 --> Config Class Initialized
INFO - 2016-11-03 04:59:39 --> Loader Class Initialized
INFO - 2016-11-03 04:59:39 --> Helper loaded: url_helper
INFO - 2016-11-03 04:59:40 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:59:40 --> Controller Class Initialized
DEBUG - 2016-11-03 04:59:40 --> Index MX_Controller Initialized
INFO - 2016-11-03 04:59:40 --> Model Class Initialized
INFO - 2016-11-03 04:59:40 --> Model Class Initialized
ERROR - 2016-11-03 04:59:40 --> Unable to delete cache file for admin/index/bayar_angsuran
DEBUG - 2016-11-03 04:59:40 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-11-03 04:59:40 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-11-03 04:59:40 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-11-03 04:59:40 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_bayar_angsuran.php
DEBUG - 2016-11-03 04:59:40 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-11-03 04:59:40 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-11-03 04:59:40 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:40 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:40 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:40 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:40 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:40 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:40 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:40 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:40 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:41 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:41 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:41 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:41 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:41 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:41 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:41 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:41 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:41 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:41 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:41 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:41 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:41 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:41 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:41 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:41 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:41 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:41 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:41 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:41 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:41 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:41 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:41 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:41 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:41 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:41 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:41 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:41 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:41 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:41 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:41 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:41 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:41 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:42 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:42 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:42 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:42 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:42 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:42 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:42 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:42 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:42 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:42 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:42 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:42 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:42 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:42 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:42 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:42 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:42 --> Database Driver Class Initialized
DEBUG - 2016-11-03 04:59:42 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-11-03 04:59:42 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-11-03 04:59:42 --> Final output sent to browser
DEBUG - 2016-11-03 04:59:42 --> Total execution time: 3.0224
INFO - 2016-11-03 04:59:47 --> Config Class Initialized
INFO - 2016-11-03 04:59:47 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:59:47 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:59:47 --> Utf8 Class Initialized
INFO - 2016-11-03 04:59:47 --> URI Class Initialized
INFO - 2016-11-03 04:59:47 --> Router Class Initialized
INFO - 2016-11-03 04:59:47 --> Output Class Initialized
INFO - 2016-11-03 04:59:47 --> Security Class Initialized
DEBUG - 2016-11-03 04:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:59:47 --> Input Class Initialized
INFO - 2016-11-03 04:59:47 --> Language Class Initialized
INFO - 2016-11-03 04:59:47 --> Language Class Initialized
INFO - 2016-11-03 04:59:47 --> Config Class Initialized
INFO - 2016-11-03 04:59:47 --> Loader Class Initialized
INFO - 2016-11-03 04:59:47 --> Helper loaded: url_helper
INFO - 2016-11-03 04:59:47 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:59:47 --> Controller Class Initialized
DEBUG - 2016-11-03 04:59:47 --> Index MX_Controller Initialized
INFO - 2016-11-03 04:59:47 --> Model Class Initialized
INFO - 2016-11-03 04:59:47 --> Model Class Initialized
ERROR - 2016-11-03 04:59:47 --> Unable to delete cache file for admin/index/getDetailAngsuran
INFO - 2016-11-03 04:59:47 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:47 --> Final output sent to browser
DEBUG - 2016-11-03 04:59:47 --> Total execution time: 0.5229
INFO - 2016-11-03 04:59:56 --> Config Class Initialized
INFO - 2016-11-03 04:59:56 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:59:56 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:59:56 --> Utf8 Class Initialized
INFO - 2016-11-03 04:59:56 --> URI Class Initialized
INFO - 2016-11-03 04:59:56 --> Router Class Initialized
INFO - 2016-11-03 04:59:56 --> Output Class Initialized
INFO - 2016-11-03 04:59:56 --> Security Class Initialized
DEBUG - 2016-11-03 04:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:59:56 --> Input Class Initialized
INFO - 2016-11-03 04:59:56 --> Language Class Initialized
INFO - 2016-11-03 04:59:56 --> Language Class Initialized
INFO - 2016-11-03 04:59:56 --> Config Class Initialized
INFO - 2016-11-03 04:59:56 --> Loader Class Initialized
INFO - 2016-11-03 04:59:56 --> Helper loaded: url_helper
INFO - 2016-11-03 04:59:56 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:59:56 --> Controller Class Initialized
DEBUG - 2016-11-03 04:59:56 --> Index MX_Controller Initialized
INFO - 2016-11-03 04:59:56 --> Model Class Initialized
INFO - 2016-11-03 04:59:56 --> Model Class Initialized
ERROR - 2016-11-03 04:59:56 --> Unable to delete cache file for admin/index/do_bayar
INFO - 2016-11-03 04:59:56 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:56 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:56 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:56 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:56 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:56 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:56 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:56 --> Final output sent to browser
DEBUG - 2016-11-03 04:59:56 --> Total execution time: 0.9658
INFO - 2016-11-03 04:59:58 --> Config Class Initialized
INFO - 2016-11-03 04:59:58 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:59:58 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:59:58 --> Utf8 Class Initialized
INFO - 2016-11-03 04:59:58 --> URI Class Initialized
INFO - 2016-11-03 04:59:58 --> Router Class Initialized
INFO - 2016-11-03 04:59:58 --> Output Class Initialized
INFO - 2016-11-03 04:59:58 --> Security Class Initialized
DEBUG - 2016-11-03 04:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:59:58 --> Input Class Initialized
INFO - 2016-11-03 04:59:58 --> Language Class Initialized
INFO - 2016-11-03 04:59:58 --> Language Class Initialized
INFO - 2016-11-03 04:59:58 --> Config Class Initialized
INFO - 2016-11-03 04:59:58 --> Loader Class Initialized
INFO - 2016-11-03 04:59:58 --> Helper loaded: url_helper
INFO - 2016-11-03 04:59:58 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:59:58 --> Controller Class Initialized
DEBUG - 2016-11-03 04:59:58 --> Index MX_Controller Initialized
INFO - 2016-11-03 04:59:58 --> Model Class Initialized
INFO - 2016-11-03 04:59:58 --> Model Class Initialized
ERROR - 2016-11-03 04:59:58 --> Unable to delete cache file for admin/index/getDetailAngsuran
INFO - 2016-11-03 04:59:58 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:58 --> Final output sent to browser
DEBUG - 2016-11-03 04:59:58 --> Total execution time: 0.5998
INFO - 2016-11-03 04:59:59 --> Config Class Initialized
INFO - 2016-11-03 04:59:59 --> Hooks Class Initialized
DEBUG - 2016-11-03 04:59:59 --> UTF-8 Support Enabled
INFO - 2016-11-03 04:59:59 --> Utf8 Class Initialized
INFO - 2016-11-03 04:59:59 --> URI Class Initialized
INFO - 2016-11-03 04:59:59 --> Router Class Initialized
INFO - 2016-11-03 04:59:59 --> Output Class Initialized
INFO - 2016-11-03 04:59:59 --> Security Class Initialized
DEBUG - 2016-11-03 04:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 04:59:59 --> Input Class Initialized
INFO - 2016-11-03 04:59:59 --> Language Class Initialized
INFO - 2016-11-03 04:59:59 --> Language Class Initialized
INFO - 2016-11-03 04:59:59 --> Config Class Initialized
INFO - 2016-11-03 04:59:59 --> Loader Class Initialized
INFO - 2016-11-03 04:59:59 --> Helper loaded: url_helper
INFO - 2016-11-03 04:59:59 --> Database Driver Class Initialized
INFO - 2016-11-03 04:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 04:59:59 --> Controller Class Initialized
DEBUG - 2016-11-03 05:00:00 --> Index MX_Controller Initialized
INFO - 2016-11-03 05:00:00 --> Model Class Initialized
INFO - 2016-11-03 05:00:00 --> Model Class Initialized
ERROR - 2016-11-03 05:00:00 --> Unable to delete cache file for admin/index/do_bayar
INFO - 2016-11-03 05:00:00 --> Database Driver Class Initialized
INFO - 2016-11-03 05:00:00 --> Database Driver Class Initialized
INFO - 2016-11-03 05:00:00 --> Database Driver Class Initialized
INFO - 2016-11-03 05:00:00 --> Database Driver Class Initialized
INFO - 2016-11-03 05:00:00 --> Database Driver Class Initialized
INFO - 2016-11-03 05:00:00 --> Database Driver Class Initialized
INFO - 2016-11-03 05:00:00 --> Database Driver Class Initialized
INFO - 2016-11-03 05:00:00 --> Final output sent to browser
DEBUG - 2016-11-03 05:00:00 --> Total execution time: 1.3630
INFO - 2016-11-03 05:00:01 --> Config Class Initialized
INFO - 2016-11-03 05:00:01 --> Hooks Class Initialized
DEBUG - 2016-11-03 05:00:01 --> UTF-8 Support Enabled
INFO - 2016-11-03 05:00:01 --> Utf8 Class Initialized
INFO - 2016-11-03 05:00:01 --> URI Class Initialized
INFO - 2016-11-03 05:00:01 --> Router Class Initialized
INFO - 2016-11-03 05:00:01 --> Output Class Initialized
INFO - 2016-11-03 05:00:01 --> Security Class Initialized
DEBUG - 2016-11-03 05:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 05:00:01 --> Input Class Initialized
INFO - 2016-11-03 05:00:01 --> Language Class Initialized
INFO - 2016-11-03 05:00:01 --> Language Class Initialized
INFO - 2016-11-03 05:00:01 --> Config Class Initialized
INFO - 2016-11-03 05:00:01 --> Loader Class Initialized
INFO - 2016-11-03 05:00:01 --> Helper loaded: url_helper
INFO - 2016-11-03 05:00:01 --> Database Driver Class Initialized
INFO - 2016-11-03 05:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 05:00:02 --> Controller Class Initialized
DEBUG - 2016-11-03 05:00:02 --> Index MX_Controller Initialized
INFO - 2016-11-03 05:00:02 --> Model Class Initialized
INFO - 2016-11-03 05:00:02 --> Model Class Initialized
ERROR - 2016-11-03 05:00:02 --> Unable to delete cache file for admin/index/getDetailAngsuran
INFO - 2016-11-03 05:00:02 --> Database Driver Class Initialized
INFO - 2016-11-03 05:00:02 --> Final output sent to browser
DEBUG - 2016-11-03 05:00:02 --> Total execution time: 0.5774
INFO - 2016-11-03 05:00:03 --> Config Class Initialized
INFO - 2016-11-03 05:00:03 --> Hooks Class Initialized
DEBUG - 2016-11-03 05:00:03 --> UTF-8 Support Enabled
INFO - 2016-11-03 05:00:03 --> Utf8 Class Initialized
INFO - 2016-11-03 05:00:03 --> URI Class Initialized
INFO - 2016-11-03 05:00:03 --> Router Class Initialized
INFO - 2016-11-03 05:00:03 --> Output Class Initialized
INFO - 2016-11-03 05:00:03 --> Security Class Initialized
DEBUG - 2016-11-03 05:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 05:00:03 --> Input Class Initialized
INFO - 2016-11-03 05:00:03 --> Language Class Initialized
INFO - 2016-11-03 05:00:03 --> Language Class Initialized
INFO - 2016-11-03 05:00:03 --> Config Class Initialized
INFO - 2016-11-03 05:00:03 --> Loader Class Initialized
INFO - 2016-11-03 05:00:03 --> Helper loaded: url_helper
INFO - 2016-11-03 05:00:03 --> Database Driver Class Initialized
INFO - 2016-11-03 05:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 05:00:03 --> Controller Class Initialized
DEBUG - 2016-11-03 05:00:03 --> Index MX_Controller Initialized
INFO - 2016-11-03 05:00:03 --> Model Class Initialized
INFO - 2016-11-03 05:00:03 --> Model Class Initialized
ERROR - 2016-11-03 05:00:03 --> Unable to delete cache file for admin/index/do_bayar
INFO - 2016-11-03 05:00:03 --> Database Driver Class Initialized
INFO - 2016-11-03 05:00:03 --> Database Driver Class Initialized
INFO - 2016-11-03 05:00:03 --> Database Driver Class Initialized
INFO - 2016-11-03 05:00:03 --> Database Driver Class Initialized
INFO - 2016-11-03 05:00:03 --> Database Driver Class Initialized
INFO - 2016-11-03 05:00:03 --> Database Driver Class Initialized
INFO - 2016-11-03 05:00:03 --> Database Driver Class Initialized
INFO - 2016-11-03 05:00:03 --> Final output sent to browser
DEBUG - 2016-11-03 05:00:04 --> Total execution time: 0.9346
INFO - 2016-11-03 05:00:05 --> Config Class Initialized
INFO - 2016-11-03 05:00:05 --> Hooks Class Initialized
DEBUG - 2016-11-03 05:00:05 --> UTF-8 Support Enabled
INFO - 2016-11-03 05:00:05 --> Utf8 Class Initialized
INFO - 2016-11-03 05:00:05 --> URI Class Initialized
INFO - 2016-11-03 05:00:05 --> Router Class Initialized
INFO - 2016-11-03 05:00:05 --> Output Class Initialized
INFO - 2016-11-03 05:00:05 --> Security Class Initialized
DEBUG - 2016-11-03 05:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 05:00:05 --> Input Class Initialized
INFO - 2016-11-03 05:00:05 --> Language Class Initialized
INFO - 2016-11-03 05:00:05 --> Language Class Initialized
INFO - 2016-11-03 05:00:06 --> Config Class Initialized
INFO - 2016-11-03 05:00:06 --> Loader Class Initialized
INFO - 2016-11-03 05:00:06 --> Helper loaded: url_helper
INFO - 2016-11-03 05:00:06 --> Database Driver Class Initialized
INFO - 2016-11-03 05:00:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 05:00:06 --> Controller Class Initialized
DEBUG - 2016-11-03 05:00:06 --> Index MX_Controller Initialized
INFO - 2016-11-03 05:00:06 --> Model Class Initialized
INFO - 2016-11-03 05:00:06 --> Model Class Initialized
ERROR - 2016-11-03 05:00:06 --> Unable to delete cache file for admin/index/getDetailAngsuran
INFO - 2016-11-03 05:00:06 --> Database Driver Class Initialized
INFO - 2016-11-03 05:00:06 --> Final output sent to browser
DEBUG - 2016-11-03 05:00:06 --> Total execution time: 0.9127
INFO - 2016-11-03 05:06:23 --> Config Class Initialized
INFO - 2016-11-03 05:06:24 --> Hooks Class Initialized
DEBUG - 2016-11-03 05:06:24 --> UTF-8 Support Enabled
INFO - 2016-11-03 05:06:24 --> Utf8 Class Initialized
INFO - 2016-11-03 05:06:24 --> URI Class Initialized
INFO - 2016-11-03 05:06:24 --> Router Class Initialized
INFO - 2016-11-03 05:06:24 --> Output Class Initialized
INFO - 2016-11-03 05:06:24 --> Security Class Initialized
DEBUG - 2016-11-03 05:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 05:06:24 --> Input Class Initialized
INFO - 2016-11-03 05:06:24 --> Language Class Initialized
INFO - 2016-11-03 05:06:24 --> Language Class Initialized
INFO - 2016-11-03 05:06:24 --> Config Class Initialized
INFO - 2016-11-03 05:06:24 --> Loader Class Initialized
INFO - 2016-11-03 05:06:24 --> Helper loaded: url_helper
INFO - 2016-11-03 05:06:24 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 05:06:24 --> Controller Class Initialized
DEBUG - 2016-11-03 05:06:24 --> Index MX_Controller Initialized
INFO - 2016-11-03 05:06:24 --> Model Class Initialized
INFO - 2016-11-03 05:06:24 --> Model Class Initialized
ERROR - 2016-11-03 05:06:24 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-11-03 05:06:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-11-03 05:06:25 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-11-03 05:06:25 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-11-03 05:06:25 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-11-03 05:06:25 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-11-03 05:06:25 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-11-03 05:06:25 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:25 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:25 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:25 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:25 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:25 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:25 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:25 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:25 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:25 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:25 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:25 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:25 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:25 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:25 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:25 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:25 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:25 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:25 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:25 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:25 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:25 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:25 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:25 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:25 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:25 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:25 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:25 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:26 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:26 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:26 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:26 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:26 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:26 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:26 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:26 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:26 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:26 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:26 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:26 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:26 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:26 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:26 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:26 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:26 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:26 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:26 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:26 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:26 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:26 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:26 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:26 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:26 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:26 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:26 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:26 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:26 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:26 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:26 --> Database Driver Class Initialized
DEBUG - 2016-11-03 05:06:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-11-03 05:06:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-11-03 05:06:26 --> Final output sent to browser
DEBUG - 2016-11-03 05:06:27 --> Total execution time: 3.0151
INFO - 2016-11-03 05:06:31 --> Config Class Initialized
INFO - 2016-11-03 05:06:31 --> Hooks Class Initialized
DEBUG - 2016-11-03 05:06:31 --> UTF-8 Support Enabled
INFO - 2016-11-03 05:06:31 --> Utf8 Class Initialized
INFO - 2016-11-03 05:06:31 --> URI Class Initialized
INFO - 2016-11-03 05:06:31 --> Router Class Initialized
INFO - 2016-11-03 05:06:31 --> Output Class Initialized
INFO - 2016-11-03 05:06:31 --> Security Class Initialized
DEBUG - 2016-11-03 05:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 05:06:31 --> Input Class Initialized
INFO - 2016-11-03 05:06:31 --> Language Class Initialized
INFO - 2016-11-03 05:06:31 --> Language Class Initialized
INFO - 2016-11-03 05:06:31 --> Config Class Initialized
INFO - 2016-11-03 05:06:31 --> Loader Class Initialized
INFO - 2016-11-03 05:06:31 --> Helper loaded: url_helper
INFO - 2016-11-03 05:06:31 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 05:06:31 --> Controller Class Initialized
DEBUG - 2016-11-03 05:06:31 --> Index MX_Controller Initialized
INFO - 2016-11-03 05:06:31 --> Model Class Initialized
INFO - 2016-11-03 05:06:31 --> Model Class Initialized
ERROR - 2016-11-03 05:06:31 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-11-03 05:06:31 --> Anggota MX_Controller Initialized
INFO - 2016-11-03 05:06:31 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:31 --> Final output sent to browser
DEBUG - 2016-11-03 05:06:31 --> Total execution time: 0.5845
INFO - 2016-11-03 05:06:43 --> Config Class Initialized
INFO - 2016-11-03 05:06:43 --> Hooks Class Initialized
DEBUG - 2016-11-03 05:06:43 --> UTF-8 Support Enabled
INFO - 2016-11-03 05:06:43 --> Utf8 Class Initialized
INFO - 2016-11-03 05:06:43 --> URI Class Initialized
INFO - 2016-11-03 05:06:43 --> Router Class Initialized
INFO - 2016-11-03 05:06:43 --> Output Class Initialized
INFO - 2016-11-03 05:06:43 --> Security Class Initialized
DEBUG - 2016-11-03 05:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 05:06:43 --> Input Class Initialized
INFO - 2016-11-03 05:06:43 --> Language Class Initialized
INFO - 2016-11-03 05:06:43 --> Language Class Initialized
INFO - 2016-11-03 05:06:43 --> Config Class Initialized
INFO - 2016-11-03 05:06:43 --> Loader Class Initialized
INFO - 2016-11-03 05:06:43 --> Helper loaded: url_helper
INFO - 2016-11-03 05:06:44 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 05:06:44 --> Controller Class Initialized
DEBUG - 2016-11-03 05:06:44 --> Index MX_Controller Initialized
INFO - 2016-11-03 05:06:44 --> Model Class Initialized
INFO - 2016-11-03 05:06:44 --> Model Class Initialized
ERROR - 2016-11-03 05:06:44 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-11-03 05:06:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-11-03 05:06:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-11-03 05:06:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-11-03 05:06:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_umum.php
DEBUG - 2016-11-03 05:06:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-11-03 05:06:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-11-03 05:06:44 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:44 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:44 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:44 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:44 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:44 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:44 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:44 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:44 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:44 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:44 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:44 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:44 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:44 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:44 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:44 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:44 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:44 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:44 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:44 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:44 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:44 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:44 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:45 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:45 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:45 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:45 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:45 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:45 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:45 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:45 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:45 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:45 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:45 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:45 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:45 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:45 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:45 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:45 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:45 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:45 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:45 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:45 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:45 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:45 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:45 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:45 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:45 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:45 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:45 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:45 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:45 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:45 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:45 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:45 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:45 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:45 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:46 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:46 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:46 --> Database Driver Class Initialized
DEBUG - 2016-11-03 05:06:46 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-11-03 05:06:46 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-11-03 05:06:46 --> Final output sent to browser
DEBUG - 2016-11-03 05:06:46 --> Total execution time: 2.6231
INFO - 2016-11-03 05:06:57 --> Config Class Initialized
INFO - 2016-11-03 05:06:57 --> Hooks Class Initialized
DEBUG - 2016-11-03 05:06:58 --> UTF-8 Support Enabled
INFO - 2016-11-03 05:06:58 --> Utf8 Class Initialized
INFO - 2016-11-03 05:06:58 --> URI Class Initialized
INFO - 2016-11-03 05:06:58 --> Router Class Initialized
INFO - 2016-11-03 05:06:58 --> Output Class Initialized
INFO - 2016-11-03 05:06:58 --> Security Class Initialized
DEBUG - 2016-11-03 05:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 05:06:58 --> Input Class Initialized
INFO - 2016-11-03 05:06:58 --> Language Class Initialized
INFO - 2016-11-03 05:06:58 --> Language Class Initialized
INFO - 2016-11-03 05:06:58 --> Config Class Initialized
INFO - 2016-11-03 05:06:58 --> Loader Class Initialized
INFO - 2016-11-03 05:06:58 --> Helper loaded: url_helper
INFO - 2016-11-03 05:06:58 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 05:06:58 --> Controller Class Initialized
DEBUG - 2016-11-03 05:06:58 --> Index MX_Controller Initialized
INFO - 2016-11-03 05:06:58 --> Model Class Initialized
INFO - 2016-11-03 05:06:58 --> Model Class Initialized
ERROR - 2016-11-03 05:06:58 --> Unable to delete cache file for admin/index/do_ajukan_pinjaman
INFO - 2016-11-03 05:06:58 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:58 --> Database Driver Class Initialized
INFO - 2016-11-03 05:06:58 --> Final output sent to browser
DEBUG - 2016-11-03 05:06:58 --> Total execution time: 0.6483
INFO - 2016-11-03 05:07:07 --> Config Class Initialized
INFO - 2016-11-03 05:07:07 --> Hooks Class Initialized
DEBUG - 2016-11-03 05:07:07 --> UTF-8 Support Enabled
INFO - 2016-11-03 05:07:07 --> Utf8 Class Initialized
INFO - 2016-11-03 05:07:07 --> URI Class Initialized
INFO - 2016-11-03 05:07:07 --> Router Class Initialized
INFO - 2016-11-03 05:07:07 --> Output Class Initialized
INFO - 2016-11-03 05:07:07 --> Security Class Initialized
DEBUG - 2016-11-03 05:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 05:07:07 --> Input Class Initialized
INFO - 2016-11-03 05:07:07 --> Language Class Initialized
INFO - 2016-11-03 05:07:07 --> Language Class Initialized
INFO - 2016-11-03 05:07:08 --> Config Class Initialized
INFO - 2016-11-03 05:07:08 --> Loader Class Initialized
INFO - 2016-11-03 05:07:08 --> Helper loaded: url_helper
INFO - 2016-11-03 05:07:08 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 05:07:08 --> Controller Class Initialized
DEBUG - 2016-11-03 05:07:08 --> Index MX_Controller Initialized
INFO - 2016-11-03 05:07:08 --> Model Class Initialized
INFO - 2016-11-03 05:07:08 --> Model Class Initialized
ERROR - 2016-11-03 05:07:08 --> Unable to delete cache file for admin/index/do_save_jaminan/sertifikat
INFO - 2016-11-03 05:07:08 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:08 --> Final output sent to browser
DEBUG - 2016-11-03 05:07:08 --> Total execution time: 0.7146
INFO - 2016-11-03 05:07:16 --> Config Class Initialized
INFO - 2016-11-03 05:07:16 --> Hooks Class Initialized
DEBUG - 2016-11-03 05:07:16 --> UTF-8 Support Enabled
INFO - 2016-11-03 05:07:16 --> Utf8 Class Initialized
INFO - 2016-11-03 05:07:16 --> URI Class Initialized
INFO - 2016-11-03 05:07:16 --> Router Class Initialized
INFO - 2016-11-03 05:07:16 --> Output Class Initialized
INFO - 2016-11-03 05:07:16 --> Security Class Initialized
DEBUG - 2016-11-03 05:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 05:07:16 --> Input Class Initialized
INFO - 2016-11-03 05:07:16 --> Language Class Initialized
INFO - 2016-11-03 05:07:16 --> Language Class Initialized
INFO - 2016-11-03 05:07:16 --> Config Class Initialized
INFO - 2016-11-03 05:07:17 --> Loader Class Initialized
INFO - 2016-11-03 05:07:17 --> Helper loaded: url_helper
INFO - 2016-11-03 05:07:17 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 05:07:17 --> Controller Class Initialized
DEBUG - 2016-11-03 05:07:17 --> Index MX_Controller Initialized
INFO - 2016-11-03 05:07:17 --> Model Class Initialized
INFO - 2016-11-03 05:07:17 --> Model Class Initialized
ERROR - 2016-11-03 05:07:17 --> Unable to delete cache file for admin/index/cetak/0286dd552c9bea9a69ecb3759e7b94777635514b
INFO - 2016-11-03 05:07:17 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:17 --> Database Driver Class Initialized
DEBUG - 2016-11-03 05:07:17 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/perjanijan.php
INFO - 2016-11-03 05:07:17 --> Final output sent to browser
DEBUG - 2016-11-03 05:07:17 --> Total execution time: 1.2410
INFO - 2016-11-03 05:07:29 --> Config Class Initialized
INFO - 2016-11-03 05:07:29 --> Hooks Class Initialized
DEBUG - 2016-11-03 05:07:29 --> UTF-8 Support Enabled
INFO - 2016-11-03 05:07:29 --> Utf8 Class Initialized
INFO - 2016-11-03 05:07:29 --> URI Class Initialized
INFO - 2016-11-03 05:07:29 --> Router Class Initialized
INFO - 2016-11-03 05:07:29 --> Output Class Initialized
INFO - 2016-11-03 05:07:30 --> Security Class Initialized
DEBUG - 2016-11-03 05:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 05:07:30 --> Input Class Initialized
INFO - 2016-11-03 05:07:30 --> Language Class Initialized
INFO - 2016-11-03 05:07:30 --> Language Class Initialized
INFO - 2016-11-03 05:07:30 --> Config Class Initialized
INFO - 2016-11-03 05:07:30 --> Loader Class Initialized
INFO - 2016-11-03 05:07:30 --> Helper loaded: url_helper
INFO - 2016-11-03 05:07:30 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 05:07:30 --> Controller Class Initialized
DEBUG - 2016-11-03 05:07:30 --> Index MX_Controller Initialized
INFO - 2016-11-03 05:07:30 --> Model Class Initialized
INFO - 2016-11-03 05:07:30 --> Model Class Initialized
ERROR - 2016-11-03 05:07:30 --> Unable to delete cache file for admin/index/finish_pinjaman/0286dd552c9bea9a69ecb3759e7b94777635514b
INFO - 2016-11-03 05:07:30 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:30 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:30 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:30 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:30 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:30 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:30 --> Final output sent to browser
DEBUG - 2016-11-03 05:07:31 --> Total execution time: 1.1491
INFO - 2016-11-03 05:07:31 --> Config Class Initialized
INFO - 2016-11-03 05:07:31 --> Hooks Class Initialized
DEBUG - 2016-11-03 05:07:31 --> UTF-8 Support Enabled
INFO - 2016-11-03 05:07:31 --> Utf8 Class Initialized
INFO - 2016-11-03 05:07:31 --> URI Class Initialized
INFO - 2016-11-03 05:07:31 --> Router Class Initialized
INFO - 2016-11-03 05:07:31 --> Output Class Initialized
INFO - 2016-11-03 05:07:31 --> Security Class Initialized
DEBUG - 2016-11-03 05:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 05:07:31 --> Input Class Initialized
INFO - 2016-11-03 05:07:31 --> Language Class Initialized
INFO - 2016-11-03 05:07:31 --> Language Class Initialized
INFO - 2016-11-03 05:07:31 --> Config Class Initialized
INFO - 2016-11-03 05:07:31 --> Loader Class Initialized
INFO - 2016-11-03 05:07:31 --> Helper loaded: url_helper
INFO - 2016-11-03 05:07:31 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 05:07:31 --> Controller Class Initialized
DEBUG - 2016-11-03 05:07:31 --> Index MX_Controller Initialized
INFO - 2016-11-03 05:07:31 --> Model Class Initialized
INFO - 2016-11-03 05:07:31 --> Model Class Initialized
ERROR - 2016-11-03 05:07:31 --> Unable to delete cache file for admin/index/data_peminjam
DEBUG - 2016-11-03 05:07:31 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-11-03 05:07:31 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-11-03 05:07:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-11-03 05:07:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_peminjam.php
DEBUG - 2016-11-03 05:07:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-11-03 05:07:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-11-03 05:07:32 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:32 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:32 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:32 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:32 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:32 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:32 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:32 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:32 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:32 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:32 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:32 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:32 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:33 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:33 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:33 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:33 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:33 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:33 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:33 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:33 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:33 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:33 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:33 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:33 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:33 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:33 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:33 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:33 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:33 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:33 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:33 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:33 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:33 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:33 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:33 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:33 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:34 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:34 --> Config Class Initialized
INFO - 2016-11-03 05:07:34 --> Hooks Class Initialized
INFO - 2016-11-03 05:07:34 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:34 --> Database Driver Class Initialized
DEBUG - 2016-11-03 05:07:34 --> UTF-8 Support Enabled
INFO - 2016-11-03 05:07:34 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:34 --> Utf8 Class Initialized
INFO - 2016-11-03 05:07:34 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:34 --> URI Class Initialized
INFO - 2016-11-03 05:07:34 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:34 --> Router Class Initialized
INFO - 2016-11-03 05:07:34 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:34 --> Output Class Initialized
INFO - 2016-11-03 05:07:34 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:34 --> Security Class Initialized
INFO - 2016-11-03 05:07:34 --> Database Driver Class Initialized
DEBUG - 2016-11-03 05:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 05:07:34 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:34 --> Input Class Initialized
INFO - 2016-11-03 05:07:34 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:34 --> Language Class Initialized
INFO - 2016-11-03 05:07:34 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:34 --> Language Class Initialized
INFO - 2016-11-03 05:07:34 --> Config Class Initialized
INFO - 2016-11-03 05:07:34 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:34 --> Loader Class Initialized
INFO - 2016-11-03 05:07:34 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:34 --> Helper loaded: url_helper
INFO - 2016-11-03 05:07:34 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:34 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:34 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:34 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:34 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:35 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:35 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:35 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:35 --> Database Driver Class Initialized
DEBUG - 2016-11-03 05:07:35 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-11-03 05:07:35 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-11-03 05:07:35 --> Final output sent to browser
DEBUG - 2016-11-03 05:07:35 --> Total execution time: 4.4629
INFO - 2016-11-03 05:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 05:07:35 --> Controller Class Initialized
DEBUG - 2016-11-03 05:07:35 --> Index MX_Controller Initialized
INFO - 2016-11-03 05:07:35 --> Model Class Initialized
INFO - 2016-11-03 05:07:35 --> Model Class Initialized
ERROR - 2016-11-03 05:07:36 --> Unable to delete cache file for admin/index/bayar_angsuran
DEBUG - 2016-11-03 05:07:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-11-03 05:07:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-11-03 05:07:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-11-03 05:07:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_bayar_angsuran.php
DEBUG - 2016-11-03 05:07:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-11-03 05:07:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-11-03 05:07:36 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:36 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:36 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:36 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:36 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:36 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:36 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:36 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:36 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:36 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:36 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:37 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:37 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:37 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:37 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:37 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:37 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:37 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:37 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:37 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:37 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:37 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:37 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:37 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:37 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:37 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:37 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:37 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:37 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:38 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:38 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:38 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:38 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:38 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:38 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:38 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:38 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:38 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:38 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:38 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:38 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:38 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:38 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:38 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:38 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:38 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:38 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:38 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:38 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:38 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:38 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:38 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:38 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:38 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:38 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:38 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:38 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:38 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:38 --> Database Driver Class Initialized
DEBUG - 2016-11-03 05:07:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-11-03 05:07:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-11-03 05:07:39 --> Final output sent to browser
DEBUG - 2016-11-03 05:07:39 --> Total execution time: 4.9687
INFO - 2016-11-03 05:07:43 --> Config Class Initialized
INFO - 2016-11-03 05:07:43 --> Hooks Class Initialized
DEBUG - 2016-11-03 05:07:43 --> UTF-8 Support Enabled
INFO - 2016-11-03 05:07:43 --> Utf8 Class Initialized
INFO - 2016-11-03 05:07:43 --> URI Class Initialized
INFO - 2016-11-03 05:07:43 --> Router Class Initialized
INFO - 2016-11-03 05:07:43 --> Output Class Initialized
INFO - 2016-11-03 05:07:43 --> Security Class Initialized
DEBUG - 2016-11-03 05:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 05:07:43 --> Input Class Initialized
INFO - 2016-11-03 05:07:43 --> Language Class Initialized
INFO - 2016-11-03 05:07:43 --> Language Class Initialized
INFO - 2016-11-03 05:07:43 --> Config Class Initialized
INFO - 2016-11-03 05:07:43 --> Loader Class Initialized
INFO - 2016-11-03 05:07:43 --> Helper loaded: url_helper
INFO - 2016-11-03 05:07:43 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 05:07:43 --> Controller Class Initialized
DEBUG - 2016-11-03 05:07:43 --> Index MX_Controller Initialized
INFO - 2016-11-03 05:07:43 --> Model Class Initialized
INFO - 2016-11-03 05:07:43 --> Model Class Initialized
ERROR - 2016-11-03 05:07:43 --> Unable to delete cache file for admin/index/getDetailAngsuran
INFO - 2016-11-03 05:07:43 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:43 --> Final output sent to browser
DEBUG - 2016-11-03 05:07:43 --> Total execution time: 0.6131
INFO - 2016-11-03 05:07:47 --> Config Class Initialized
INFO - 2016-11-03 05:07:47 --> Hooks Class Initialized
DEBUG - 2016-11-03 05:07:47 --> UTF-8 Support Enabled
INFO - 2016-11-03 05:07:47 --> Utf8 Class Initialized
INFO - 2016-11-03 05:07:47 --> URI Class Initialized
INFO - 2016-11-03 05:07:47 --> Router Class Initialized
INFO - 2016-11-03 05:07:47 --> Output Class Initialized
INFO - 2016-11-03 05:07:47 --> Security Class Initialized
DEBUG - 2016-11-03 05:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 05:07:47 --> Input Class Initialized
INFO - 2016-11-03 05:07:47 --> Language Class Initialized
INFO - 2016-11-03 05:07:47 --> Language Class Initialized
INFO - 2016-11-03 05:07:47 --> Config Class Initialized
INFO - 2016-11-03 05:07:47 --> Loader Class Initialized
INFO - 2016-11-03 05:07:47 --> Helper loaded: url_helper
INFO - 2016-11-03 05:07:47 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 05:07:47 --> Controller Class Initialized
DEBUG - 2016-11-03 05:07:47 --> Index MX_Controller Initialized
INFO - 2016-11-03 05:07:47 --> Model Class Initialized
INFO - 2016-11-03 05:07:47 --> Model Class Initialized
ERROR - 2016-11-03 05:07:47 --> Unable to delete cache file for admin/index/do_bayar
INFO - 2016-11-03 05:07:47 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:47 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:47 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:47 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:48 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:48 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:48 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:48 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:48 --> Final output sent to browser
DEBUG - 2016-11-03 05:07:48 --> Total execution time: 1.3110
INFO - 2016-11-03 05:07:49 --> Config Class Initialized
INFO - 2016-11-03 05:07:49 --> Hooks Class Initialized
DEBUG - 2016-11-03 05:07:49 --> UTF-8 Support Enabled
INFO - 2016-11-03 05:07:49 --> Utf8 Class Initialized
INFO - 2016-11-03 05:07:49 --> URI Class Initialized
INFO - 2016-11-03 05:07:49 --> Router Class Initialized
INFO - 2016-11-03 05:07:49 --> Output Class Initialized
INFO - 2016-11-03 05:07:49 --> Security Class Initialized
DEBUG - 2016-11-03 05:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 05:07:49 --> Input Class Initialized
INFO - 2016-11-03 05:07:49 --> Language Class Initialized
INFO - 2016-11-03 05:07:49 --> Language Class Initialized
INFO - 2016-11-03 05:07:49 --> Config Class Initialized
INFO - 2016-11-03 05:07:49 --> Loader Class Initialized
INFO - 2016-11-03 05:07:49 --> Helper loaded: url_helper
INFO - 2016-11-03 05:07:49 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 05:07:49 --> Controller Class Initialized
DEBUG - 2016-11-03 05:07:49 --> Index MX_Controller Initialized
INFO - 2016-11-03 05:07:49 --> Model Class Initialized
INFO - 2016-11-03 05:07:49 --> Model Class Initialized
ERROR - 2016-11-03 05:07:49 --> Unable to delete cache file for admin/index/getDetailAngsuran
INFO - 2016-11-03 05:07:49 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:49 --> Final output sent to browser
DEBUG - 2016-11-03 05:07:49 --> Total execution time: 0.6149
INFO - 2016-11-03 05:07:51 --> Config Class Initialized
INFO - 2016-11-03 05:07:51 --> Hooks Class Initialized
DEBUG - 2016-11-03 05:07:51 --> UTF-8 Support Enabled
INFO - 2016-11-03 05:07:51 --> Utf8 Class Initialized
INFO - 2016-11-03 05:07:51 --> URI Class Initialized
INFO - 2016-11-03 05:07:51 --> Router Class Initialized
INFO - 2016-11-03 05:07:51 --> Output Class Initialized
INFO - 2016-11-03 05:07:51 --> Security Class Initialized
DEBUG - 2016-11-03 05:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 05:07:51 --> Input Class Initialized
INFO - 2016-11-03 05:07:51 --> Language Class Initialized
INFO - 2016-11-03 05:07:51 --> Language Class Initialized
INFO - 2016-11-03 05:07:51 --> Config Class Initialized
INFO - 2016-11-03 05:07:51 --> Loader Class Initialized
INFO - 2016-11-03 05:07:52 --> Helper loaded: url_helper
INFO - 2016-11-03 05:07:52 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 05:07:52 --> Controller Class Initialized
DEBUG - 2016-11-03 05:07:52 --> Index MX_Controller Initialized
INFO - 2016-11-03 05:07:52 --> Model Class Initialized
INFO - 2016-11-03 05:07:52 --> Model Class Initialized
ERROR - 2016-11-03 05:07:52 --> Unable to delete cache file for admin/index/do_bayar
INFO - 2016-11-03 05:07:52 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:52 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:52 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:52 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:52 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:52 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:52 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:52 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:52 --> Final output sent to browser
DEBUG - 2016-11-03 05:07:52 --> Total execution time: 1.0831
INFO - 2016-11-03 05:07:53 --> Config Class Initialized
INFO - 2016-11-03 05:07:53 --> Hooks Class Initialized
DEBUG - 2016-11-03 05:07:53 --> UTF-8 Support Enabled
INFO - 2016-11-03 05:07:53 --> Utf8 Class Initialized
INFO - 2016-11-03 05:07:53 --> URI Class Initialized
INFO - 2016-11-03 05:07:53 --> Router Class Initialized
INFO - 2016-11-03 05:07:53 --> Output Class Initialized
INFO - 2016-11-03 05:07:53 --> Security Class Initialized
DEBUG - 2016-11-03 05:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 05:07:53 --> Input Class Initialized
INFO - 2016-11-03 05:07:53 --> Language Class Initialized
INFO - 2016-11-03 05:07:53 --> Language Class Initialized
INFO - 2016-11-03 05:07:53 --> Config Class Initialized
INFO - 2016-11-03 05:07:53 --> Loader Class Initialized
INFO - 2016-11-03 05:07:53 --> Helper loaded: url_helper
INFO - 2016-11-03 05:07:53 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 05:07:53 --> Controller Class Initialized
DEBUG - 2016-11-03 05:07:54 --> Index MX_Controller Initialized
INFO - 2016-11-03 05:07:54 --> Model Class Initialized
INFO - 2016-11-03 05:07:54 --> Model Class Initialized
ERROR - 2016-11-03 05:07:54 --> Unable to delete cache file for admin/index/getDetailAngsuran
INFO - 2016-11-03 05:07:54 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:54 --> Final output sent to browser
DEBUG - 2016-11-03 05:07:54 --> Total execution time: 0.6144
INFO - 2016-11-03 05:07:55 --> Config Class Initialized
INFO - 2016-11-03 05:07:55 --> Hooks Class Initialized
DEBUG - 2016-11-03 05:07:55 --> UTF-8 Support Enabled
INFO - 2016-11-03 05:07:55 --> Utf8 Class Initialized
INFO - 2016-11-03 05:07:55 --> URI Class Initialized
INFO - 2016-11-03 05:07:55 --> Router Class Initialized
INFO - 2016-11-03 05:07:55 --> Output Class Initialized
INFO - 2016-11-03 05:07:55 --> Security Class Initialized
DEBUG - 2016-11-03 05:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 05:07:55 --> Input Class Initialized
INFO - 2016-11-03 05:07:55 --> Language Class Initialized
INFO - 2016-11-03 05:07:55 --> Language Class Initialized
INFO - 2016-11-03 05:07:55 --> Config Class Initialized
INFO - 2016-11-03 05:07:55 --> Loader Class Initialized
INFO - 2016-11-03 05:07:55 --> Helper loaded: url_helper
INFO - 2016-11-03 05:07:55 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 05:07:55 --> Controller Class Initialized
DEBUG - 2016-11-03 05:07:55 --> Index MX_Controller Initialized
INFO - 2016-11-03 05:07:55 --> Model Class Initialized
INFO - 2016-11-03 05:07:55 --> Model Class Initialized
ERROR - 2016-11-03 05:07:55 --> Unable to delete cache file for admin/index/do_bayar
INFO - 2016-11-03 05:07:55 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:55 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:55 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:55 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:55 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:55 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:55 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:55 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:56 --> Final output sent to browser
DEBUG - 2016-11-03 05:07:56 --> Total execution time: 1.0254
INFO - 2016-11-03 05:07:57 --> Config Class Initialized
INFO - 2016-11-03 05:07:57 --> Hooks Class Initialized
DEBUG - 2016-11-03 05:07:57 --> UTF-8 Support Enabled
INFO - 2016-11-03 05:07:57 --> Utf8 Class Initialized
INFO - 2016-11-03 05:07:57 --> URI Class Initialized
INFO - 2016-11-03 05:07:57 --> Router Class Initialized
INFO - 2016-11-03 05:07:57 --> Output Class Initialized
INFO - 2016-11-03 05:07:57 --> Security Class Initialized
DEBUG - 2016-11-03 05:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 05:07:57 --> Input Class Initialized
INFO - 2016-11-03 05:07:57 --> Language Class Initialized
INFO - 2016-11-03 05:07:57 --> Language Class Initialized
INFO - 2016-11-03 05:07:57 --> Config Class Initialized
INFO - 2016-11-03 05:07:57 --> Loader Class Initialized
INFO - 2016-11-03 05:07:58 --> Helper loaded: url_helper
INFO - 2016-11-03 05:07:58 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 05:07:58 --> Controller Class Initialized
DEBUG - 2016-11-03 05:07:58 --> Index MX_Controller Initialized
INFO - 2016-11-03 05:07:58 --> Model Class Initialized
INFO - 2016-11-03 05:07:58 --> Model Class Initialized
ERROR - 2016-11-03 05:07:58 --> Unable to delete cache file for admin/index/getDetailAngsuran
INFO - 2016-11-03 05:07:58 --> Database Driver Class Initialized
INFO - 2016-11-03 05:07:58 --> Final output sent to browser
DEBUG - 2016-11-03 05:07:58 --> Total execution time: 0.8893
INFO - 2016-11-03 05:08:06 --> Config Class Initialized
INFO - 2016-11-03 05:08:06 --> Hooks Class Initialized
DEBUG - 2016-11-03 05:08:06 --> UTF-8 Support Enabled
INFO - 2016-11-03 05:08:06 --> Utf8 Class Initialized
INFO - 2016-11-03 05:08:06 --> URI Class Initialized
INFO - 2016-11-03 05:08:07 --> Router Class Initialized
INFO - 2016-11-03 05:08:07 --> Output Class Initialized
INFO - 2016-11-03 05:08:07 --> Security Class Initialized
DEBUG - 2016-11-03 05:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 05:08:07 --> Input Class Initialized
INFO - 2016-11-03 05:08:07 --> Language Class Initialized
INFO - 2016-11-03 05:08:07 --> Language Class Initialized
INFO - 2016-11-03 05:08:07 --> Config Class Initialized
INFO - 2016-11-03 05:08:07 --> Loader Class Initialized
INFO - 2016-11-03 05:08:07 --> Helper loaded: url_helper
INFO - 2016-11-03 05:08:07 --> Database Driver Class Initialized
INFO - 2016-11-03 05:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 05:08:07 --> Controller Class Initialized
DEBUG - 2016-11-03 05:08:07 --> Index MX_Controller Initialized
INFO - 2016-11-03 05:08:07 --> Model Class Initialized
INFO - 2016-11-03 05:08:07 --> Model Class Initialized
ERROR - 2016-11-03 05:08:07 --> Unable to delete cache file for admin/index/getDetailAngsuran
INFO - 2016-11-03 05:08:07 --> Database Driver Class Initialized
INFO - 2016-11-03 05:08:07 --> Final output sent to browser
DEBUG - 2016-11-03 05:08:07 --> Total execution time: 0.6469
INFO - 2016-11-03 05:08:46 --> Config Class Initialized
INFO - 2016-11-03 05:08:46 --> Hooks Class Initialized
DEBUG - 2016-11-03 05:08:46 --> UTF-8 Support Enabled
INFO - 2016-11-03 05:08:46 --> Utf8 Class Initialized
INFO - 2016-11-03 05:08:46 --> URI Class Initialized
INFO - 2016-11-03 05:08:46 --> Router Class Initialized
INFO - 2016-11-03 05:08:46 --> Output Class Initialized
INFO - 2016-11-03 05:08:46 --> Security Class Initialized
DEBUG - 2016-11-03 05:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 05:08:46 --> Input Class Initialized
INFO - 2016-11-03 05:08:46 --> Language Class Initialized
INFO - 2016-11-03 05:08:46 --> Language Class Initialized
INFO - 2016-11-03 05:08:46 --> Config Class Initialized
INFO - 2016-11-03 05:08:46 --> Loader Class Initialized
INFO - 2016-11-03 05:08:46 --> Helper loaded: url_helper
INFO - 2016-11-03 05:08:46 --> Database Driver Class Initialized
INFO - 2016-11-03 05:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 05:08:46 --> Controller Class Initialized
DEBUG - 2016-11-03 05:08:46 --> Index MX_Controller Initialized
INFO - 2016-11-03 05:08:46 --> Model Class Initialized
INFO - 2016-11-03 05:08:46 --> Model Class Initialized
ERROR - 2016-11-03 05:08:46 --> Unable to delete cache file for admin/index/getDetailAngsuran
INFO - 2016-11-03 05:08:46 --> Database Driver Class Initialized
INFO - 2016-11-03 05:08:46 --> Final output sent to browser
DEBUG - 2016-11-03 05:08:46 --> Total execution time: 0.5683
INFO - 2016-11-03 05:09:01 --> Config Class Initialized
INFO - 2016-11-03 05:09:01 --> Hooks Class Initialized
DEBUG - 2016-11-03 05:09:01 --> UTF-8 Support Enabled
INFO - 2016-11-03 05:09:01 --> Utf8 Class Initialized
INFO - 2016-11-03 05:09:01 --> URI Class Initialized
INFO - 2016-11-03 05:09:01 --> Router Class Initialized
INFO - 2016-11-03 05:09:01 --> Output Class Initialized
INFO - 2016-11-03 05:09:01 --> Security Class Initialized
DEBUG - 2016-11-03 05:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 05:09:01 --> Input Class Initialized
INFO - 2016-11-03 05:09:01 --> Language Class Initialized
INFO - 2016-11-03 05:09:01 --> Language Class Initialized
INFO - 2016-11-03 05:09:01 --> Config Class Initialized
INFO - 2016-11-03 05:09:01 --> Loader Class Initialized
INFO - 2016-11-03 05:09:01 --> Helper loaded: url_helper
INFO - 2016-11-03 05:09:01 --> Database Driver Class Initialized
INFO - 2016-11-03 05:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 05:09:02 --> Controller Class Initialized
DEBUG - 2016-11-03 05:09:02 --> Index MX_Controller Initialized
INFO - 2016-11-03 05:09:02 --> Model Class Initialized
INFO - 2016-11-03 05:09:02 --> Model Class Initialized
ERROR - 2016-11-03 05:09:02 --> Unable to delete cache file for admin/index/getDetailAngsuran
INFO - 2016-11-03 05:09:02 --> Database Driver Class Initialized
INFO - 2016-11-03 05:09:02 --> Final output sent to browser
DEBUG - 2016-11-03 05:09:02 --> Total execution time: 0.5737
INFO - 2016-11-03 05:09:04 --> Config Class Initialized
INFO - 2016-11-03 05:09:04 --> Hooks Class Initialized
DEBUG - 2016-11-03 05:09:04 --> UTF-8 Support Enabled
INFO - 2016-11-03 05:09:04 --> Utf8 Class Initialized
INFO - 2016-11-03 05:09:04 --> URI Class Initialized
INFO - 2016-11-03 05:09:04 --> Router Class Initialized
INFO - 2016-11-03 05:09:04 --> Output Class Initialized
INFO - 2016-11-03 05:09:04 --> Security Class Initialized
DEBUG - 2016-11-03 05:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 05:09:04 --> Input Class Initialized
INFO - 2016-11-03 05:09:04 --> Language Class Initialized
INFO - 2016-11-03 05:09:04 --> Language Class Initialized
INFO - 2016-11-03 05:09:04 --> Config Class Initialized
INFO - 2016-11-03 05:09:04 --> Loader Class Initialized
INFO - 2016-11-03 05:09:04 --> Helper loaded: url_helper
INFO - 2016-11-03 05:09:04 --> Database Driver Class Initialized
INFO - 2016-11-03 05:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 05:09:04 --> Controller Class Initialized
DEBUG - 2016-11-03 05:09:04 --> Index MX_Controller Initialized
INFO - 2016-11-03 05:09:04 --> Model Class Initialized
INFO - 2016-11-03 05:09:04 --> Model Class Initialized
ERROR - 2016-11-03 05:09:04 --> Unable to delete cache file for admin/index/do_bayar
INFO - 2016-11-03 05:09:04 --> Database Driver Class Initialized
INFO - 2016-11-03 05:09:04 --> Database Driver Class Initialized
INFO - 2016-11-03 05:09:04 --> Database Driver Class Initialized
INFO - 2016-11-03 05:09:04 --> Database Driver Class Initialized
INFO - 2016-11-03 05:09:05 --> Database Driver Class Initialized
INFO - 2016-11-03 05:09:05 --> Database Driver Class Initialized
INFO - 2016-11-03 05:09:05 --> Database Driver Class Initialized
INFO - 2016-11-03 05:09:05 --> Database Driver Class Initialized
INFO - 2016-11-03 05:09:05 --> Final output sent to browser
DEBUG - 2016-11-03 05:09:05 --> Total execution time: 1.1109
INFO - 2016-11-03 05:09:06 --> Config Class Initialized
INFO - 2016-11-03 05:09:06 --> Hooks Class Initialized
DEBUG - 2016-11-03 05:09:06 --> UTF-8 Support Enabled
INFO - 2016-11-03 05:09:06 --> Utf8 Class Initialized
INFO - 2016-11-03 05:09:06 --> URI Class Initialized
INFO - 2016-11-03 05:09:06 --> Router Class Initialized
INFO - 2016-11-03 05:09:06 --> Output Class Initialized
INFO - 2016-11-03 05:09:06 --> Security Class Initialized
DEBUG - 2016-11-03 05:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 05:09:06 --> Input Class Initialized
INFO - 2016-11-03 05:09:06 --> Language Class Initialized
INFO - 2016-11-03 05:09:06 --> Language Class Initialized
INFO - 2016-11-03 05:09:07 --> Config Class Initialized
INFO - 2016-11-03 05:09:07 --> Loader Class Initialized
INFO - 2016-11-03 05:09:07 --> Helper loaded: url_helper
INFO - 2016-11-03 05:09:07 --> Database Driver Class Initialized
INFO - 2016-11-03 05:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 05:09:07 --> Controller Class Initialized
DEBUG - 2016-11-03 05:09:07 --> Index MX_Controller Initialized
INFO - 2016-11-03 05:09:07 --> Model Class Initialized
INFO - 2016-11-03 05:09:07 --> Model Class Initialized
ERROR - 2016-11-03 05:09:07 --> Unable to delete cache file for admin/index/getDetailAngsuran
INFO - 2016-11-03 05:09:07 --> Database Driver Class Initialized
INFO - 2016-11-03 05:09:07 --> Final output sent to browser
DEBUG - 2016-11-03 05:09:07 --> Total execution time: 0.6191
INFO - 2016-11-03 05:09:08 --> Config Class Initialized
INFO - 2016-11-03 05:09:08 --> Hooks Class Initialized
DEBUG - 2016-11-03 05:09:08 --> UTF-8 Support Enabled
INFO - 2016-11-03 05:09:08 --> Utf8 Class Initialized
INFO - 2016-11-03 05:09:08 --> URI Class Initialized
INFO - 2016-11-03 05:09:08 --> Router Class Initialized
INFO - 2016-11-03 05:09:08 --> Output Class Initialized
INFO - 2016-11-03 05:09:08 --> Security Class Initialized
DEBUG - 2016-11-03 05:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 05:09:08 --> Input Class Initialized
INFO - 2016-11-03 05:09:08 --> Language Class Initialized
INFO - 2016-11-03 05:09:08 --> Language Class Initialized
INFO - 2016-11-03 05:09:08 --> Config Class Initialized
INFO - 2016-11-03 05:09:08 --> Loader Class Initialized
INFO - 2016-11-03 05:09:08 --> Helper loaded: url_helper
INFO - 2016-11-03 05:09:08 --> Database Driver Class Initialized
INFO - 2016-11-03 05:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 05:09:08 --> Controller Class Initialized
DEBUG - 2016-11-03 05:09:08 --> Index MX_Controller Initialized
INFO - 2016-11-03 05:09:08 --> Model Class Initialized
INFO - 2016-11-03 05:09:08 --> Model Class Initialized
ERROR - 2016-11-03 05:09:08 --> Unable to delete cache file for admin/index/do_bayar
INFO - 2016-11-03 05:09:08 --> Database Driver Class Initialized
INFO - 2016-11-03 05:09:08 --> Database Driver Class Initialized
INFO - 2016-11-03 05:09:08 --> Database Driver Class Initialized
INFO - 2016-11-03 05:09:09 --> Database Driver Class Initialized
INFO - 2016-11-03 05:09:09 --> Database Driver Class Initialized
INFO - 2016-11-03 05:09:09 --> Database Driver Class Initialized
INFO - 2016-11-03 05:09:09 --> Database Driver Class Initialized
INFO - 2016-11-03 05:09:09 --> Database Driver Class Initialized
INFO - 2016-11-03 05:09:09 --> Final output sent to browser
DEBUG - 2016-11-03 05:09:09 --> Total execution time: 1.0891
INFO - 2016-11-03 05:09:10 --> Config Class Initialized
INFO - 2016-11-03 05:09:10 --> Hooks Class Initialized
DEBUG - 2016-11-03 05:09:10 --> UTF-8 Support Enabled
INFO - 2016-11-03 05:09:10 --> Utf8 Class Initialized
INFO - 2016-11-03 05:09:10 --> URI Class Initialized
INFO - 2016-11-03 05:09:10 --> Router Class Initialized
INFO - 2016-11-03 05:09:10 --> Output Class Initialized
INFO - 2016-11-03 05:09:10 --> Security Class Initialized
DEBUG - 2016-11-03 05:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 05:09:10 --> Input Class Initialized
INFO - 2016-11-03 05:09:10 --> Language Class Initialized
INFO - 2016-11-03 05:09:10 --> Language Class Initialized
INFO - 2016-11-03 05:09:10 --> Config Class Initialized
INFO - 2016-11-03 05:09:10 --> Loader Class Initialized
INFO - 2016-11-03 05:09:10 --> Helper loaded: url_helper
INFO - 2016-11-03 05:09:10 --> Database Driver Class Initialized
INFO - 2016-11-03 05:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 05:09:11 --> Controller Class Initialized
DEBUG - 2016-11-03 05:09:11 --> Index MX_Controller Initialized
INFO - 2016-11-03 05:09:11 --> Model Class Initialized
INFO - 2016-11-03 05:09:11 --> Model Class Initialized
ERROR - 2016-11-03 05:09:11 --> Unable to delete cache file for admin/index/getDetailAngsuran
INFO - 2016-11-03 05:09:11 --> Database Driver Class Initialized
INFO - 2016-11-03 05:09:11 --> Final output sent to browser
DEBUG - 2016-11-03 05:09:11 --> Total execution time: 0.6358
INFO - 2016-11-03 05:09:59 --> Config Class Initialized
INFO - 2016-11-03 05:09:59 --> Hooks Class Initialized
DEBUG - 2016-11-03 05:09:59 --> UTF-8 Support Enabled
INFO - 2016-11-03 05:09:59 --> Utf8 Class Initialized
INFO - 2016-11-03 05:09:59 --> URI Class Initialized
INFO - 2016-11-03 05:09:59 --> Router Class Initialized
INFO - 2016-11-03 05:09:59 --> Output Class Initialized
INFO - 2016-11-03 05:09:59 --> Security Class Initialized
DEBUG - 2016-11-03 05:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 05:09:59 --> Input Class Initialized
INFO - 2016-11-03 05:09:59 --> Language Class Initialized
INFO - 2016-11-03 05:09:59 --> Language Class Initialized
INFO - 2016-11-03 05:09:59 --> Config Class Initialized
INFO - 2016-11-03 05:09:59 --> Loader Class Initialized
INFO - 2016-11-03 05:09:59 --> Helper loaded: url_helper
INFO - 2016-11-03 05:09:59 --> Database Driver Class Initialized
INFO - 2016-11-03 05:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 05:09:59 --> Controller Class Initialized
DEBUG - 2016-11-03 05:09:59 --> Index MX_Controller Initialized
INFO - 2016-11-03 05:09:59 --> Model Class Initialized
INFO - 2016-11-03 05:09:59 --> Model Class Initialized
ERROR - 2016-11-03 05:09:59 --> Unable to delete cache file for admin/index/getDetailAngsuran
INFO - 2016-11-03 05:09:59 --> Database Driver Class Initialized
INFO - 2016-11-03 05:09:59 --> Final output sent to browser
DEBUG - 2016-11-03 05:09:59 --> Total execution time: 0.5800
INFO - 2016-11-03 05:10:21 --> Config Class Initialized
INFO - 2016-11-03 05:10:21 --> Hooks Class Initialized
DEBUG - 2016-11-03 05:10:21 --> UTF-8 Support Enabled
INFO - 2016-11-03 05:10:21 --> Utf8 Class Initialized
INFO - 2016-11-03 05:10:21 --> URI Class Initialized
INFO - 2016-11-03 05:10:21 --> Router Class Initialized
INFO - 2016-11-03 05:10:21 --> Output Class Initialized
INFO - 2016-11-03 05:10:21 --> Security Class Initialized
DEBUG - 2016-11-03 05:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 05:10:21 --> Input Class Initialized
INFO - 2016-11-03 05:10:21 --> Language Class Initialized
INFO - 2016-11-03 05:10:21 --> Language Class Initialized
INFO - 2016-11-03 05:10:21 --> Config Class Initialized
INFO - 2016-11-03 05:10:21 --> Loader Class Initialized
INFO - 2016-11-03 05:10:21 --> Helper loaded: url_helper
INFO - 2016-11-03 05:10:21 --> Database Driver Class Initialized
INFO - 2016-11-03 05:10:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 05:10:21 --> Controller Class Initialized
DEBUG - 2016-11-03 05:10:21 --> Index MX_Controller Initialized
INFO - 2016-11-03 05:10:21 --> Model Class Initialized
INFO - 2016-11-03 05:10:21 --> Model Class Initialized
ERROR - 2016-11-03 05:10:21 --> Unable to delete cache file for admin/index/do_bayar
INFO - 2016-11-03 05:10:21 --> Database Driver Class Initialized
INFO - 2016-11-03 05:10:21 --> Database Driver Class Initialized
INFO - 2016-11-03 05:10:22 --> Database Driver Class Initialized
INFO - 2016-11-03 05:10:22 --> Database Driver Class Initialized
INFO - 2016-11-03 05:10:22 --> Database Driver Class Initialized
INFO - 2016-11-03 05:10:22 --> Database Driver Class Initialized
INFO - 2016-11-03 05:10:22 --> Database Driver Class Initialized
INFO - 2016-11-03 05:10:22 --> Database Driver Class Initialized
INFO - 2016-11-03 05:10:22 --> Final output sent to browser
DEBUG - 2016-11-03 05:10:22 --> Total execution time: 1.2264
INFO - 2016-11-03 05:10:24 --> Config Class Initialized
INFO - 2016-11-03 05:10:24 --> Hooks Class Initialized
DEBUG - 2016-11-03 05:10:24 --> UTF-8 Support Enabled
INFO - 2016-11-03 05:10:24 --> Utf8 Class Initialized
INFO - 2016-11-03 05:10:24 --> URI Class Initialized
INFO - 2016-11-03 05:10:24 --> Router Class Initialized
INFO - 2016-11-03 05:10:24 --> Output Class Initialized
INFO - 2016-11-03 05:10:24 --> Security Class Initialized
DEBUG - 2016-11-03 05:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 05:10:24 --> Input Class Initialized
INFO - 2016-11-03 05:10:24 --> Language Class Initialized
INFO - 2016-11-03 05:10:24 --> Language Class Initialized
INFO - 2016-11-03 05:10:24 --> Config Class Initialized
INFO - 2016-11-03 05:10:24 --> Loader Class Initialized
INFO - 2016-11-03 05:10:24 --> Helper loaded: url_helper
INFO - 2016-11-03 05:10:24 --> Database Driver Class Initialized
INFO - 2016-11-03 05:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 05:10:24 --> Controller Class Initialized
DEBUG - 2016-11-03 05:10:24 --> Index MX_Controller Initialized
INFO - 2016-11-03 05:10:24 --> Model Class Initialized
INFO - 2016-11-03 05:10:24 --> Model Class Initialized
ERROR - 2016-11-03 05:10:24 --> Unable to delete cache file for admin/index/getDetailAngsuran
INFO - 2016-11-03 05:10:24 --> Database Driver Class Initialized
INFO - 2016-11-03 05:10:24 --> Final output sent to browser
DEBUG - 2016-11-03 05:10:24 --> Total execution time: 0.5759
INFO - 2016-11-03 05:10:25 --> Config Class Initialized
INFO - 2016-11-03 05:10:25 --> Hooks Class Initialized
DEBUG - 2016-11-03 05:10:25 --> UTF-8 Support Enabled
INFO - 2016-11-03 05:10:25 --> Utf8 Class Initialized
INFO - 2016-11-03 05:10:25 --> URI Class Initialized
INFO - 2016-11-03 05:10:25 --> Router Class Initialized
INFO - 2016-11-03 05:10:25 --> Output Class Initialized
INFO - 2016-11-03 05:10:25 --> Security Class Initialized
DEBUG - 2016-11-03 05:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 05:10:25 --> Input Class Initialized
INFO - 2016-11-03 05:10:25 --> Language Class Initialized
INFO - 2016-11-03 05:10:25 --> Language Class Initialized
INFO - 2016-11-03 05:10:25 --> Config Class Initialized
INFO - 2016-11-03 05:10:25 --> Loader Class Initialized
INFO - 2016-11-03 05:10:25 --> Helper loaded: url_helper
INFO - 2016-11-03 05:10:25 --> Database Driver Class Initialized
INFO - 2016-11-03 05:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 05:10:25 --> Controller Class Initialized
DEBUG - 2016-11-03 05:10:25 --> Index MX_Controller Initialized
INFO - 2016-11-03 05:10:26 --> Model Class Initialized
INFO - 2016-11-03 05:10:26 --> Model Class Initialized
ERROR - 2016-11-03 05:10:26 --> Unable to delete cache file for admin/index/do_bayar
INFO - 2016-11-03 05:10:26 --> Database Driver Class Initialized
INFO - 2016-11-03 05:10:26 --> Database Driver Class Initialized
INFO - 2016-11-03 05:10:26 --> Database Driver Class Initialized
INFO - 2016-11-03 05:10:26 --> Database Driver Class Initialized
INFO - 2016-11-03 05:10:26 --> Database Driver Class Initialized
INFO - 2016-11-03 05:10:26 --> Database Driver Class Initialized
INFO - 2016-11-03 05:10:26 --> Database Driver Class Initialized
INFO - 2016-11-03 05:10:26 --> Database Driver Class Initialized
INFO - 2016-11-03 05:10:26 --> Final output sent to browser
DEBUG - 2016-11-03 05:10:26 --> Total execution time: 1.1939
INFO - 2016-11-03 05:38:14 --> Config Class Initialized
INFO - 2016-11-03 05:38:14 --> Hooks Class Initialized
DEBUG - 2016-11-03 05:38:14 --> UTF-8 Support Enabled
INFO - 2016-11-03 05:38:14 --> Utf8 Class Initialized
INFO - 2016-11-03 05:38:14 --> URI Class Initialized
INFO - 2016-11-03 05:38:14 --> Router Class Initialized
INFO - 2016-11-03 05:38:14 --> Output Class Initialized
INFO - 2016-11-03 05:38:14 --> Security Class Initialized
DEBUG - 2016-11-03 05:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 05:38:14 --> Input Class Initialized
INFO - 2016-11-03 05:38:14 --> Language Class Initialized
INFO - 2016-11-03 05:38:14 --> Language Class Initialized
INFO - 2016-11-03 05:38:14 --> Config Class Initialized
INFO - 2016-11-03 05:38:14 --> Loader Class Initialized
INFO - 2016-11-03 05:38:14 --> Helper loaded: url_helper
INFO - 2016-11-03 05:38:14 --> Database Driver Class Initialized
INFO - 2016-11-03 05:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 05:38:14 --> Controller Class Initialized
DEBUG - 2016-11-03 05:38:14 --> Index MX_Controller Initialized
INFO - 2016-11-03 05:38:14 --> Model Class Initialized
INFO - 2016-11-03 05:38:14 --> Model Class Initialized
ERROR - 2016-11-03 05:38:14 --> Unable to delete cache file for admin/index/cetakJaminan/0286dd552c9bea9a69ecb3759e7b94777635514b
DEBUG - 2016-11-03 05:38:14 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/stjaminan.php
INFO - 2016-11-03 05:38:14 --> Final output sent to browser
DEBUG - 2016-11-03 05:38:14 --> Total execution time: 0.6973
INFO - 2016-11-03 05:40:24 --> Config Class Initialized
INFO - 2016-11-03 05:40:24 --> Hooks Class Initialized
DEBUG - 2016-11-03 05:40:24 --> UTF-8 Support Enabled
INFO - 2016-11-03 05:40:24 --> Utf8 Class Initialized
INFO - 2016-11-03 05:40:24 --> URI Class Initialized
INFO - 2016-11-03 05:40:24 --> Router Class Initialized
INFO - 2016-11-03 05:40:24 --> Output Class Initialized
INFO - 2016-11-03 05:40:24 --> Security Class Initialized
DEBUG - 2016-11-03 05:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 05:40:24 --> Input Class Initialized
INFO - 2016-11-03 05:40:25 --> Language Class Initialized
INFO - 2016-11-03 05:40:25 --> Language Class Initialized
INFO - 2016-11-03 05:40:25 --> Config Class Initialized
INFO - 2016-11-03 05:40:25 --> Loader Class Initialized
INFO - 2016-11-03 05:40:25 --> Helper loaded: url_helper
INFO - 2016-11-03 05:40:25 --> Database Driver Class Initialized
INFO - 2016-11-03 05:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 05:40:25 --> Controller Class Initialized
DEBUG - 2016-11-03 05:40:25 --> Index MX_Controller Initialized
INFO - 2016-11-03 05:40:25 --> Model Class Initialized
INFO - 2016-11-03 05:40:25 --> Model Class Initialized
ERROR - 2016-11-03 05:40:25 --> Unable to delete cache file for admin/index/cetakJaminan/0286dd552c9bea9a69ecb3759e7b94777635514b
DEBUG - 2016-11-03 05:40:25 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/stjaminan.php
INFO - 2016-11-03 05:40:25 --> Final output sent to browser
DEBUG - 2016-11-03 05:40:25 --> Total execution time: 0.7238
INFO - 2016-11-03 05:40:35 --> Config Class Initialized
INFO - 2016-11-03 05:40:35 --> Hooks Class Initialized
DEBUG - 2016-11-03 05:40:35 --> UTF-8 Support Enabled
INFO - 2016-11-03 05:40:35 --> Utf8 Class Initialized
INFO - 2016-11-03 05:40:35 --> URI Class Initialized
INFO - 2016-11-03 05:40:35 --> Router Class Initialized
INFO - 2016-11-03 05:40:35 --> Output Class Initialized
INFO - 2016-11-03 05:40:35 --> Security Class Initialized
DEBUG - 2016-11-03 05:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 05:40:35 --> Input Class Initialized
INFO - 2016-11-03 05:40:35 --> Language Class Initialized
INFO - 2016-11-03 05:40:35 --> Language Class Initialized
INFO - 2016-11-03 05:40:35 --> Config Class Initialized
INFO - 2016-11-03 05:40:35 --> Loader Class Initialized
INFO - 2016-11-03 05:40:35 --> Helper loaded: url_helper
INFO - 2016-11-03 05:40:35 --> Database Driver Class Initialized
INFO - 2016-11-03 05:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 05:40:36 --> Controller Class Initialized
DEBUG - 2016-11-03 05:40:36 --> Index MX_Controller Initialized
INFO - 2016-11-03 05:40:36 --> Model Class Initialized
INFO - 2016-11-03 05:40:36 --> Model Class Initialized
ERROR - 2016-11-03 05:40:36 --> Unable to delete cache file for admin/index/cetakJaminan/0286dd552c9bea9a69ecb3759e7b94777635514b
DEBUG - 2016-11-03 05:40:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/stjaminan.php
INFO - 2016-11-03 05:40:36 --> Final output sent to browser
DEBUG - 2016-11-03 05:40:36 --> Total execution time: 0.6841
INFO - 2016-11-03 05:41:03 --> Config Class Initialized
INFO - 2016-11-03 05:41:03 --> Hooks Class Initialized
DEBUG - 2016-11-03 05:41:03 --> UTF-8 Support Enabled
INFO - 2016-11-03 05:41:03 --> Utf8 Class Initialized
INFO - 2016-11-03 05:41:03 --> URI Class Initialized
INFO - 2016-11-03 05:41:03 --> Router Class Initialized
INFO - 2016-11-03 05:41:03 --> Output Class Initialized
INFO - 2016-11-03 05:41:03 --> Security Class Initialized
DEBUG - 2016-11-03 05:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 05:41:03 --> Input Class Initialized
INFO - 2016-11-03 05:41:03 --> Language Class Initialized
INFO - 2016-11-03 05:41:03 --> Language Class Initialized
INFO - 2016-11-03 05:41:03 --> Config Class Initialized
INFO - 2016-11-03 05:41:03 --> Loader Class Initialized
INFO - 2016-11-03 05:41:03 --> Helper loaded: url_helper
INFO - 2016-11-03 05:41:03 --> Database Driver Class Initialized
INFO - 2016-11-03 05:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 05:41:03 --> Controller Class Initialized
DEBUG - 2016-11-03 05:41:03 --> Index MX_Controller Initialized
INFO - 2016-11-03 05:41:03 --> Model Class Initialized
INFO - 2016-11-03 05:41:03 --> Model Class Initialized
ERROR - 2016-11-03 05:41:03 --> Unable to delete cache file for admin/index/cetakJaminan/0286dd552c9bea9a69ecb3759e7b94777635514b
DEBUG - 2016-11-03 05:41:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/stjaminan.php
INFO - 2016-11-03 05:41:03 --> Final output sent to browser
DEBUG - 2016-11-03 05:41:03 --> Total execution time: 0.6708
INFO - 2016-11-03 05:41:21 --> Config Class Initialized
INFO - 2016-11-03 05:41:21 --> Hooks Class Initialized
DEBUG - 2016-11-03 05:41:21 --> UTF-8 Support Enabled
INFO - 2016-11-03 05:41:21 --> Utf8 Class Initialized
INFO - 2016-11-03 05:41:21 --> URI Class Initialized
INFO - 2016-11-03 05:41:21 --> Router Class Initialized
INFO - 2016-11-03 05:41:21 --> Output Class Initialized
INFO - 2016-11-03 05:41:21 --> Security Class Initialized
DEBUG - 2016-11-03 05:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 05:41:21 --> Input Class Initialized
INFO - 2016-11-03 05:41:21 --> Language Class Initialized
INFO - 2016-11-03 05:41:21 --> Language Class Initialized
INFO - 2016-11-03 05:41:21 --> Config Class Initialized
INFO - 2016-11-03 05:41:21 --> Loader Class Initialized
INFO - 2016-11-03 05:41:21 --> Helper loaded: url_helper
INFO - 2016-11-03 05:41:21 --> Database Driver Class Initialized
INFO - 2016-11-03 05:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 05:41:21 --> Controller Class Initialized
DEBUG - 2016-11-03 05:41:21 --> Index MX_Controller Initialized
INFO - 2016-11-03 05:41:21 --> Model Class Initialized
INFO - 2016-11-03 05:41:21 --> Model Class Initialized
ERROR - 2016-11-03 05:41:21 --> Unable to delete cache file for admin/index/cetakJaminan/0286dd552c9bea9a69ecb3759e7b94777635514b
DEBUG - 2016-11-03 05:41:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/stjaminan.php
INFO - 2016-11-03 05:41:21 --> Final output sent to browser
DEBUG - 2016-11-03 05:41:21 --> Total execution time: 0.6670
INFO - 2016-11-03 05:41:29 --> Config Class Initialized
INFO - 2016-11-03 05:41:29 --> Hooks Class Initialized
DEBUG - 2016-11-03 05:41:29 --> UTF-8 Support Enabled
INFO - 2016-11-03 05:41:29 --> Utf8 Class Initialized
INFO - 2016-11-03 05:41:29 --> URI Class Initialized
INFO - 2016-11-03 05:41:29 --> Router Class Initialized
INFO - 2016-11-03 05:41:29 --> Output Class Initialized
INFO - 2016-11-03 05:41:29 --> Security Class Initialized
DEBUG - 2016-11-03 05:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 05:41:29 --> Input Class Initialized
INFO - 2016-11-03 05:41:29 --> Language Class Initialized
INFO - 2016-11-03 05:41:29 --> Language Class Initialized
INFO - 2016-11-03 05:41:29 --> Config Class Initialized
INFO - 2016-11-03 05:41:29 --> Loader Class Initialized
INFO - 2016-11-03 05:41:29 --> Helper loaded: url_helper
INFO - 2016-11-03 05:41:30 --> Database Driver Class Initialized
INFO - 2016-11-03 05:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 05:41:30 --> Controller Class Initialized
DEBUG - 2016-11-03 05:41:30 --> Index MX_Controller Initialized
INFO - 2016-11-03 05:41:30 --> Model Class Initialized
INFO - 2016-11-03 05:41:30 --> Model Class Initialized
ERROR - 2016-11-03 05:41:30 --> Unable to delete cache file for admin/index/cetakJaminan/0286dd552c9bea9a69ecb3759e7b94777635514b
DEBUG - 2016-11-03 05:41:30 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/stjaminan.php
INFO - 2016-11-03 05:41:30 --> Final output sent to browser
DEBUG - 2016-11-03 05:41:30 --> Total execution time: 0.6849
INFO - 2016-11-03 05:41:51 --> Config Class Initialized
INFO - 2016-11-03 05:41:51 --> Hooks Class Initialized
DEBUG - 2016-11-03 05:41:51 --> UTF-8 Support Enabled
INFO - 2016-11-03 05:41:51 --> Utf8 Class Initialized
INFO - 2016-11-03 05:41:51 --> URI Class Initialized
INFO - 2016-11-03 05:41:51 --> Router Class Initialized
INFO - 2016-11-03 05:41:51 --> Output Class Initialized
INFO - 2016-11-03 05:41:51 --> Security Class Initialized
DEBUG - 2016-11-03 05:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 05:41:51 --> Input Class Initialized
INFO - 2016-11-03 05:41:51 --> Language Class Initialized
INFO - 2016-11-03 05:41:51 --> Language Class Initialized
INFO - 2016-11-03 05:41:51 --> Config Class Initialized
INFO - 2016-11-03 05:41:51 --> Loader Class Initialized
INFO - 2016-11-03 05:41:51 --> Helper loaded: url_helper
INFO - 2016-11-03 05:41:51 --> Database Driver Class Initialized
INFO - 2016-11-03 05:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 05:41:51 --> Controller Class Initialized
DEBUG - 2016-11-03 05:41:51 --> Index MX_Controller Initialized
INFO - 2016-11-03 05:41:51 --> Model Class Initialized
INFO - 2016-11-03 05:41:51 --> Model Class Initialized
ERROR - 2016-11-03 05:41:51 --> Unable to delete cache file for admin/index/cetakJaminan/0286dd552c9bea9a69ecb3759e7b94777635514b
DEBUG - 2016-11-03 05:41:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/stjaminan.php
INFO - 2016-11-03 05:41:51 --> Final output sent to browser
DEBUG - 2016-11-03 05:41:51 --> Total execution time: 0.6999
INFO - 2016-11-03 06:12:00 --> Config Class Initialized
INFO - 2016-11-03 06:12:01 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:12:01 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:12:01 --> Utf8 Class Initialized
INFO - 2016-11-03 06:12:01 --> URI Class Initialized
INFO - 2016-11-03 06:12:01 --> Router Class Initialized
INFO - 2016-11-03 06:12:01 --> Output Class Initialized
INFO - 2016-11-03 06:12:01 --> Security Class Initialized
DEBUG - 2016-11-03 06:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:12:01 --> Input Class Initialized
INFO - 2016-11-03 06:12:01 --> Language Class Initialized
INFO - 2016-11-03 06:12:01 --> Language Class Initialized
INFO - 2016-11-03 06:12:01 --> Config Class Initialized
INFO - 2016-11-03 06:12:01 --> Loader Class Initialized
INFO - 2016-11-03 06:12:01 --> Helper loaded: url_helper
INFO - 2016-11-03 06:12:01 --> Database Driver Class Initialized
INFO - 2016-11-03 06:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:12:01 --> Controller Class Initialized
DEBUG - 2016-11-03 06:12:01 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:12:01 --> Model Class Initialized
INFO - 2016-11-03 06:12:01 --> Model Class Initialized
ERROR - 2016-11-03 06:12:01 --> Unable to delete cache file for admin/index/cetakJaminan/0286dd552c9bea9a69ecb3759e7b94777635514b
DEBUG - 2016-11-03 06:12:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/stjaminan.php
INFO - 2016-11-03 06:12:01 --> Final output sent to browser
DEBUG - 2016-11-03 06:12:01 --> Total execution time: 0.7959
INFO - 2016-11-03 06:12:21 --> Config Class Initialized
INFO - 2016-11-03 06:12:21 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:12:21 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:12:21 --> Utf8 Class Initialized
INFO - 2016-11-03 06:12:21 --> URI Class Initialized
INFO - 2016-11-03 06:12:21 --> Router Class Initialized
INFO - 2016-11-03 06:12:21 --> Output Class Initialized
INFO - 2016-11-03 06:12:21 --> Security Class Initialized
DEBUG - 2016-11-03 06:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:12:21 --> Input Class Initialized
INFO - 2016-11-03 06:12:21 --> Language Class Initialized
INFO - 2016-11-03 06:12:21 --> Language Class Initialized
INFO - 2016-11-03 06:12:21 --> Config Class Initialized
INFO - 2016-11-03 06:12:21 --> Loader Class Initialized
INFO - 2016-11-03 06:12:21 --> Helper loaded: url_helper
INFO - 2016-11-03 06:12:22 --> Database Driver Class Initialized
INFO - 2016-11-03 06:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:12:22 --> Controller Class Initialized
DEBUG - 2016-11-03 06:12:22 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:12:22 --> Model Class Initialized
INFO - 2016-11-03 06:12:22 --> Model Class Initialized
ERROR - 2016-11-03 06:12:22 --> Unable to delete cache file for admin/index/cetakJaminan/0286dd552c9bea9a69ecb3759e7b94777635514b
DEBUG - 2016-11-03 06:12:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/stjaminan.php
INFO - 2016-11-03 06:12:22 --> Final output sent to browser
DEBUG - 2016-11-03 06:12:22 --> Total execution time: 0.7032
INFO - 2016-11-03 06:13:00 --> Config Class Initialized
INFO - 2016-11-03 06:13:00 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:13:00 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:13:00 --> Utf8 Class Initialized
INFO - 2016-11-03 06:13:00 --> URI Class Initialized
INFO - 2016-11-03 06:13:00 --> Router Class Initialized
INFO - 2016-11-03 06:13:00 --> Output Class Initialized
INFO - 2016-11-03 06:13:00 --> Security Class Initialized
DEBUG - 2016-11-03 06:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:13:00 --> Input Class Initialized
INFO - 2016-11-03 06:13:00 --> Language Class Initialized
INFO - 2016-11-03 06:13:00 --> Language Class Initialized
INFO - 2016-11-03 06:13:01 --> Config Class Initialized
INFO - 2016-11-03 06:13:01 --> Loader Class Initialized
INFO - 2016-11-03 06:13:01 --> Helper loaded: url_helper
INFO - 2016-11-03 06:13:01 --> Database Driver Class Initialized
INFO - 2016-11-03 06:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:13:01 --> Controller Class Initialized
DEBUG - 2016-11-03 06:13:01 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:13:01 --> Model Class Initialized
INFO - 2016-11-03 06:13:01 --> Model Class Initialized
ERROR - 2016-11-03 06:13:01 --> Unable to delete cache file for admin/index/cetakJaminan/0286dd552c9bea9a69ecb3759e7b94777635514b
DEBUG - 2016-11-03 06:13:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/stjaminan.php
INFO - 2016-11-03 06:13:01 --> Final output sent to browser
DEBUG - 2016-11-03 06:13:01 --> Total execution time: 0.7019
INFO - 2016-11-03 06:13:34 --> Config Class Initialized
INFO - 2016-11-03 06:13:34 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:13:34 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:13:34 --> Utf8 Class Initialized
INFO - 2016-11-03 06:13:34 --> URI Class Initialized
INFO - 2016-11-03 06:13:34 --> Router Class Initialized
INFO - 2016-11-03 06:13:34 --> Output Class Initialized
INFO - 2016-11-03 06:13:34 --> Security Class Initialized
DEBUG - 2016-11-03 06:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:13:34 --> Input Class Initialized
INFO - 2016-11-03 06:13:34 --> Language Class Initialized
INFO - 2016-11-03 06:13:34 --> Language Class Initialized
INFO - 2016-11-03 06:13:34 --> Config Class Initialized
INFO - 2016-11-03 06:13:34 --> Loader Class Initialized
INFO - 2016-11-03 06:13:34 --> Helper loaded: url_helper
INFO - 2016-11-03 06:13:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:13:34 --> Controller Class Initialized
DEBUG - 2016-11-03 06:13:34 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:13:34 --> Model Class Initialized
INFO - 2016-11-03 06:13:34 --> Model Class Initialized
ERROR - 2016-11-03 06:13:34 --> Unable to delete cache file for admin/index/cetakJaminan/0286dd552c9bea9a69ecb3759e7b94777635514b
DEBUG - 2016-11-03 06:13:34 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/stjaminan.php
INFO - 2016-11-03 06:13:34 --> Final output sent to browser
DEBUG - 2016-11-03 06:13:35 --> Total execution time: 0.7549
INFO - 2016-11-03 06:13:59 --> Config Class Initialized
INFO - 2016-11-03 06:13:59 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:13:59 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:13:59 --> Utf8 Class Initialized
INFO - 2016-11-03 06:13:59 --> URI Class Initialized
INFO - 2016-11-03 06:13:59 --> Router Class Initialized
INFO - 2016-11-03 06:13:59 --> Output Class Initialized
INFO - 2016-11-03 06:13:59 --> Security Class Initialized
DEBUG - 2016-11-03 06:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:13:59 --> Input Class Initialized
INFO - 2016-11-03 06:13:59 --> Language Class Initialized
INFO - 2016-11-03 06:13:59 --> Language Class Initialized
INFO - 2016-11-03 06:13:59 --> Config Class Initialized
INFO - 2016-11-03 06:13:59 --> Loader Class Initialized
INFO - 2016-11-03 06:13:59 --> Helper loaded: url_helper
INFO - 2016-11-03 06:13:59 --> Database Driver Class Initialized
INFO - 2016-11-03 06:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:14:00 --> Controller Class Initialized
DEBUG - 2016-11-03 06:14:00 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:14:00 --> Model Class Initialized
INFO - 2016-11-03 06:14:00 --> Model Class Initialized
ERROR - 2016-11-03 06:14:00 --> Unable to delete cache file for admin/index/cetakJaminan/0286dd552c9bea9a69ecb3759e7b94777635514b
DEBUG - 2016-11-03 06:14:00 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/stjaminan.php
INFO - 2016-11-03 06:14:00 --> Final output sent to browser
DEBUG - 2016-11-03 06:14:00 --> Total execution time: 0.7206
INFO - 2016-11-03 06:14:10 --> Config Class Initialized
INFO - 2016-11-03 06:14:10 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:14:10 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:14:10 --> Utf8 Class Initialized
INFO - 2016-11-03 06:14:10 --> URI Class Initialized
INFO - 2016-11-03 06:14:10 --> Router Class Initialized
INFO - 2016-11-03 06:14:10 --> Output Class Initialized
INFO - 2016-11-03 06:14:10 --> Security Class Initialized
DEBUG - 2016-11-03 06:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:14:10 --> Input Class Initialized
INFO - 2016-11-03 06:14:10 --> Language Class Initialized
INFO - 2016-11-03 06:14:10 --> Language Class Initialized
INFO - 2016-11-03 06:14:10 --> Config Class Initialized
INFO - 2016-11-03 06:14:10 --> Loader Class Initialized
INFO - 2016-11-03 06:14:10 --> Helper loaded: url_helper
INFO - 2016-11-03 06:14:10 --> Database Driver Class Initialized
INFO - 2016-11-03 06:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:14:11 --> Controller Class Initialized
DEBUG - 2016-11-03 06:14:11 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:14:11 --> Model Class Initialized
INFO - 2016-11-03 06:14:11 --> Model Class Initialized
ERROR - 2016-11-03 06:14:11 --> Unable to delete cache file for admin/index/cetakJaminan/0286dd552c9bea9a69ecb3759e7b94777635514b
DEBUG - 2016-11-03 06:14:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/stjaminan.php
INFO - 2016-11-03 06:14:11 --> Final output sent to browser
DEBUG - 2016-11-03 06:14:11 --> Total execution time: 0.7659
INFO - 2016-11-03 06:14:20 --> Config Class Initialized
INFO - 2016-11-03 06:14:20 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:14:20 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:14:20 --> Utf8 Class Initialized
INFO - 2016-11-03 06:14:20 --> URI Class Initialized
INFO - 2016-11-03 06:14:20 --> Router Class Initialized
INFO - 2016-11-03 06:14:20 --> Output Class Initialized
INFO - 2016-11-03 06:14:20 --> Security Class Initialized
DEBUG - 2016-11-03 06:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:14:20 --> Input Class Initialized
INFO - 2016-11-03 06:14:20 --> Language Class Initialized
INFO - 2016-11-03 06:14:20 --> Language Class Initialized
INFO - 2016-11-03 06:14:20 --> Config Class Initialized
INFO - 2016-11-03 06:14:20 --> Loader Class Initialized
INFO - 2016-11-03 06:14:20 --> Helper loaded: url_helper
INFO - 2016-11-03 06:14:20 --> Database Driver Class Initialized
INFO - 2016-11-03 06:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:14:20 --> Controller Class Initialized
DEBUG - 2016-11-03 06:14:20 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:14:20 --> Model Class Initialized
INFO - 2016-11-03 06:14:20 --> Model Class Initialized
ERROR - 2016-11-03 06:14:20 --> Unable to delete cache file for admin/index/cetakJaminan/0286dd552c9bea9a69ecb3759e7b94777635514b
DEBUG - 2016-11-03 06:14:20 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/stjaminan.php
INFO - 2016-11-03 06:14:20 --> Final output sent to browser
DEBUG - 2016-11-03 06:14:20 --> Total execution time: 0.7698
INFO - 2016-11-03 06:14:54 --> Config Class Initialized
INFO - 2016-11-03 06:14:54 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:14:54 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:14:54 --> Utf8 Class Initialized
INFO - 2016-11-03 06:14:54 --> URI Class Initialized
INFO - 2016-11-03 06:14:54 --> Router Class Initialized
INFO - 2016-11-03 06:14:54 --> Output Class Initialized
INFO - 2016-11-03 06:14:54 --> Security Class Initialized
DEBUG - 2016-11-03 06:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:14:55 --> Input Class Initialized
INFO - 2016-11-03 06:14:55 --> Language Class Initialized
INFO - 2016-11-03 06:14:55 --> Language Class Initialized
INFO - 2016-11-03 06:14:55 --> Config Class Initialized
INFO - 2016-11-03 06:14:55 --> Loader Class Initialized
INFO - 2016-11-03 06:14:55 --> Helper loaded: url_helper
INFO - 2016-11-03 06:14:55 --> Database Driver Class Initialized
INFO - 2016-11-03 06:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:14:55 --> Controller Class Initialized
DEBUG - 2016-11-03 06:14:55 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:14:55 --> Model Class Initialized
INFO - 2016-11-03 06:14:55 --> Model Class Initialized
ERROR - 2016-11-03 06:14:55 --> Unable to delete cache file for admin/index/cetakJaminan/0286dd552c9bea9a69ecb3759e7b94777635514b
DEBUG - 2016-11-03 06:14:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/stjaminan.php
INFO - 2016-11-03 06:14:55 --> Final output sent to browser
DEBUG - 2016-11-03 06:14:55 --> Total execution time: 0.7172
INFO - 2016-11-03 06:15:47 --> Config Class Initialized
INFO - 2016-11-03 06:15:48 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:15:48 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:15:48 --> Utf8 Class Initialized
INFO - 2016-11-03 06:15:48 --> URI Class Initialized
INFO - 2016-11-03 06:15:48 --> Router Class Initialized
INFO - 2016-11-03 06:15:48 --> Output Class Initialized
INFO - 2016-11-03 06:15:48 --> Security Class Initialized
DEBUG - 2016-11-03 06:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:15:48 --> Input Class Initialized
INFO - 2016-11-03 06:15:48 --> Language Class Initialized
INFO - 2016-11-03 06:15:48 --> Language Class Initialized
INFO - 2016-11-03 06:15:48 --> Config Class Initialized
INFO - 2016-11-03 06:15:48 --> Loader Class Initialized
INFO - 2016-11-03 06:15:48 --> Helper loaded: url_helper
INFO - 2016-11-03 06:15:48 --> Database Driver Class Initialized
INFO - 2016-11-03 06:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:15:48 --> Controller Class Initialized
DEBUG - 2016-11-03 06:15:48 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:15:48 --> Model Class Initialized
INFO - 2016-11-03 06:15:48 --> Model Class Initialized
ERROR - 2016-11-03 06:15:48 --> Unable to delete cache file for admin/index/cetakJaminan/0286dd552c9bea9a69ecb3759e7b94777635514b
DEBUG - 2016-11-03 06:15:48 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/stjaminan.php
INFO - 2016-11-03 06:15:48 --> Final output sent to browser
DEBUG - 2016-11-03 06:15:48 --> Total execution time: 0.7280
INFO - 2016-11-03 06:16:31 --> Config Class Initialized
INFO - 2016-11-03 06:16:31 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:16:31 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:16:31 --> Utf8 Class Initialized
INFO - 2016-11-03 06:16:31 --> URI Class Initialized
INFO - 2016-11-03 06:16:31 --> Router Class Initialized
INFO - 2016-11-03 06:16:31 --> Output Class Initialized
INFO - 2016-11-03 06:16:31 --> Security Class Initialized
DEBUG - 2016-11-03 06:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:16:31 --> Input Class Initialized
INFO - 2016-11-03 06:16:31 --> Language Class Initialized
INFO - 2016-11-03 06:16:31 --> Language Class Initialized
INFO - 2016-11-03 06:16:31 --> Config Class Initialized
INFO - 2016-11-03 06:16:31 --> Loader Class Initialized
INFO - 2016-11-03 06:16:31 --> Helper loaded: url_helper
INFO - 2016-11-03 06:16:31 --> Database Driver Class Initialized
INFO - 2016-11-03 06:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:16:31 --> Controller Class Initialized
DEBUG - 2016-11-03 06:16:31 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:16:31 --> Model Class Initialized
INFO - 2016-11-03 06:16:31 --> Model Class Initialized
ERROR - 2016-11-03 06:16:31 --> Unable to delete cache file for admin/index/cetakJaminan/0286dd552c9bea9a69ecb3759e7b94777635514b
DEBUG - 2016-11-03 06:16:31 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/stjaminan.php
INFO - 2016-11-03 06:16:31 --> Final output sent to browser
DEBUG - 2016-11-03 06:16:31 --> Total execution time: 0.7419
INFO - 2016-11-03 06:17:11 --> Config Class Initialized
INFO - 2016-11-03 06:17:11 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:17:11 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:17:11 --> Utf8 Class Initialized
INFO - 2016-11-03 06:17:11 --> URI Class Initialized
INFO - 2016-11-03 06:17:11 --> Router Class Initialized
INFO - 2016-11-03 06:17:12 --> Output Class Initialized
INFO - 2016-11-03 06:17:12 --> Security Class Initialized
DEBUG - 2016-11-03 06:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:17:12 --> Input Class Initialized
INFO - 2016-11-03 06:17:12 --> Language Class Initialized
INFO - 2016-11-03 06:17:12 --> Language Class Initialized
INFO - 2016-11-03 06:17:12 --> Config Class Initialized
INFO - 2016-11-03 06:17:12 --> Loader Class Initialized
INFO - 2016-11-03 06:17:12 --> Helper loaded: url_helper
INFO - 2016-11-03 06:17:12 --> Database Driver Class Initialized
INFO - 2016-11-03 06:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:17:12 --> Controller Class Initialized
DEBUG - 2016-11-03 06:17:12 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:17:12 --> Model Class Initialized
INFO - 2016-11-03 06:17:12 --> Model Class Initialized
ERROR - 2016-11-03 06:17:12 --> Unable to delete cache file for admin/index/cetakJaminan/0286dd552c9bea9a69ecb3759e7b94777635514b
DEBUG - 2016-11-03 06:17:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/stjaminan.php
INFO - 2016-11-03 06:17:12 --> Final output sent to browser
DEBUG - 2016-11-03 06:17:12 --> Total execution time: 0.7686
INFO - 2016-11-03 06:17:24 --> Config Class Initialized
INFO - 2016-11-03 06:17:24 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:17:24 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:17:24 --> Utf8 Class Initialized
INFO - 2016-11-03 06:17:24 --> URI Class Initialized
INFO - 2016-11-03 06:17:24 --> Router Class Initialized
INFO - 2016-11-03 06:17:24 --> Output Class Initialized
INFO - 2016-11-03 06:17:24 --> Security Class Initialized
DEBUG - 2016-11-03 06:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:17:24 --> Input Class Initialized
INFO - 2016-11-03 06:17:24 --> Language Class Initialized
INFO - 2016-11-03 06:17:25 --> Language Class Initialized
INFO - 2016-11-03 06:17:25 --> Config Class Initialized
INFO - 2016-11-03 06:17:25 --> Loader Class Initialized
INFO - 2016-11-03 06:17:25 --> Helper loaded: url_helper
INFO - 2016-11-03 06:17:25 --> Database Driver Class Initialized
INFO - 2016-11-03 06:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:17:25 --> Controller Class Initialized
DEBUG - 2016-11-03 06:17:25 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:17:25 --> Model Class Initialized
INFO - 2016-11-03 06:17:25 --> Model Class Initialized
ERROR - 2016-11-03 06:17:25 --> Unable to delete cache file for admin/index/cetakJaminan/0286dd552c9bea9a69ecb3759e7b94777635514b
DEBUG - 2016-11-03 06:17:25 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/stjaminan.php
INFO - 2016-11-03 06:17:25 --> Final output sent to browser
DEBUG - 2016-11-03 06:17:25 --> Total execution time: 0.7372
INFO - 2016-11-03 06:18:18 --> Config Class Initialized
INFO - 2016-11-03 06:18:18 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:18:18 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:18:18 --> Utf8 Class Initialized
INFO - 2016-11-03 06:18:18 --> URI Class Initialized
INFO - 2016-11-03 06:18:18 --> Router Class Initialized
INFO - 2016-11-03 06:18:19 --> Output Class Initialized
INFO - 2016-11-03 06:18:19 --> Security Class Initialized
DEBUG - 2016-11-03 06:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:18:19 --> Input Class Initialized
INFO - 2016-11-03 06:18:19 --> Language Class Initialized
INFO - 2016-11-03 06:18:19 --> Language Class Initialized
INFO - 2016-11-03 06:18:19 --> Config Class Initialized
INFO - 2016-11-03 06:18:19 --> Loader Class Initialized
INFO - 2016-11-03 06:18:19 --> Helper loaded: url_helper
INFO - 2016-11-03 06:18:19 --> Database Driver Class Initialized
INFO - 2016-11-03 06:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:18:19 --> Controller Class Initialized
DEBUG - 2016-11-03 06:18:19 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:18:19 --> Model Class Initialized
INFO - 2016-11-03 06:18:19 --> Model Class Initialized
ERROR - 2016-11-03 06:18:19 --> Unable to delete cache file for admin/index/cetakJaminan/0286dd552c9bea9a69ecb3759e7b94777635514b
DEBUG - 2016-11-03 06:18:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/stjaminan.php
INFO - 2016-11-03 06:18:19 --> Final output sent to browser
DEBUG - 2016-11-03 06:18:19 --> Total execution time: 0.7175
INFO - 2016-11-03 06:19:55 --> Config Class Initialized
INFO - 2016-11-03 06:19:55 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:19:55 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:19:55 --> Utf8 Class Initialized
INFO - 2016-11-03 06:19:55 --> URI Class Initialized
INFO - 2016-11-03 06:19:55 --> Router Class Initialized
INFO - 2016-11-03 06:19:55 --> Output Class Initialized
INFO - 2016-11-03 06:19:55 --> Security Class Initialized
DEBUG - 2016-11-03 06:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:19:55 --> Input Class Initialized
INFO - 2016-11-03 06:19:55 --> Language Class Initialized
INFO - 2016-11-03 06:19:55 --> Language Class Initialized
INFO - 2016-11-03 06:19:55 --> Config Class Initialized
INFO - 2016-11-03 06:19:55 --> Loader Class Initialized
INFO - 2016-11-03 06:19:55 --> Helper loaded: url_helper
INFO - 2016-11-03 06:19:55 --> Database Driver Class Initialized
INFO - 2016-11-03 06:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:19:55 --> Controller Class Initialized
DEBUG - 2016-11-03 06:19:55 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:19:55 --> Model Class Initialized
INFO - 2016-11-03 06:19:55 --> Model Class Initialized
ERROR - 2016-11-03 06:19:55 --> Unable to delete cache file for admin/index/cetakJaminan/0286dd552c9bea9a69ecb3759e7b94777635514b
INFO - 2016-11-03 06:19:55 --> Database Driver Class Initialized
INFO - 2016-11-03 06:19:55 --> Database Driver Class Initialized
DEBUG - 2016-11-03 06:19:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/stjaminan.php
INFO - 2016-11-03 06:19:55 --> Final output sent to browser
DEBUG - 2016-11-03 06:19:55 --> Total execution time: 0.8497
INFO - 2016-11-03 06:21:16 --> Config Class Initialized
INFO - 2016-11-03 06:21:16 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:21:16 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:21:16 --> Utf8 Class Initialized
INFO - 2016-11-03 06:21:16 --> URI Class Initialized
INFO - 2016-11-03 06:21:16 --> Router Class Initialized
INFO - 2016-11-03 06:21:16 --> Output Class Initialized
INFO - 2016-11-03 06:21:17 --> Security Class Initialized
DEBUG - 2016-11-03 06:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:21:17 --> Input Class Initialized
INFO - 2016-11-03 06:21:17 --> Language Class Initialized
INFO - 2016-11-03 06:21:17 --> Language Class Initialized
INFO - 2016-11-03 06:21:17 --> Config Class Initialized
INFO - 2016-11-03 06:21:17 --> Loader Class Initialized
INFO - 2016-11-03 06:21:17 --> Helper loaded: url_helper
INFO - 2016-11-03 06:21:18 --> Database Driver Class Initialized
INFO - 2016-11-03 06:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:21:18 --> Controller Class Initialized
DEBUG - 2016-11-03 06:21:18 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:21:18 --> Model Class Initialized
INFO - 2016-11-03 06:21:18 --> Model Class Initialized
ERROR - 2016-11-03 06:21:18 --> Unable to delete cache file for admin/index/cetakJaminan/0286dd552c9bea9a69ecb3759e7b94777635514b
INFO - 2016-11-03 06:21:18 --> Database Driver Class Initialized
INFO - 2016-11-03 06:21:18 --> Database Driver Class Initialized
DEBUG - 2016-11-03 06:21:18 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/stjaminan.php
INFO - 2016-11-03 06:21:18 --> Final output sent to browser
DEBUG - 2016-11-03 06:21:18 --> Total execution time: 2.6700
INFO - 2016-11-03 06:22:41 --> Config Class Initialized
INFO - 2016-11-03 06:22:41 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:22:41 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:22:41 --> Utf8 Class Initialized
INFO - 2016-11-03 06:22:41 --> URI Class Initialized
INFO - 2016-11-03 06:22:41 --> Router Class Initialized
INFO - 2016-11-03 06:22:41 --> Output Class Initialized
INFO - 2016-11-03 06:22:41 --> Security Class Initialized
DEBUG - 2016-11-03 06:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:22:41 --> Input Class Initialized
INFO - 2016-11-03 06:22:41 --> Language Class Initialized
INFO - 2016-11-03 06:22:41 --> Language Class Initialized
INFO - 2016-11-03 06:22:41 --> Config Class Initialized
INFO - 2016-11-03 06:22:41 --> Loader Class Initialized
INFO - 2016-11-03 06:22:41 --> Helper loaded: url_helper
INFO - 2016-11-03 06:22:41 --> Database Driver Class Initialized
INFO - 2016-11-03 06:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:22:41 --> Controller Class Initialized
DEBUG - 2016-11-03 06:22:41 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:22:41 --> Model Class Initialized
INFO - 2016-11-03 06:22:41 --> Model Class Initialized
ERROR - 2016-11-03 06:22:41 --> Unable to delete cache file for admin/index/cetakJaminan/0286dd552c9bea9a69ecb3759e7b94777635514b
INFO - 2016-11-03 06:22:41 --> Database Driver Class Initialized
INFO - 2016-11-03 06:22:41 --> Database Driver Class Initialized
DEBUG - 2016-11-03 06:22:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/stjaminan.php
INFO - 2016-11-03 06:22:41 --> Final output sent to browser
DEBUG - 2016-11-03 06:22:41 --> Total execution time: 0.7805
INFO - 2016-11-03 06:23:58 --> Config Class Initialized
INFO - 2016-11-03 06:23:58 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:23:58 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:23:58 --> Utf8 Class Initialized
INFO - 2016-11-03 06:23:58 --> URI Class Initialized
INFO - 2016-11-03 06:23:58 --> Router Class Initialized
INFO - 2016-11-03 06:23:58 --> Output Class Initialized
INFO - 2016-11-03 06:23:58 --> Security Class Initialized
DEBUG - 2016-11-03 06:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:23:58 --> Input Class Initialized
INFO - 2016-11-03 06:23:58 --> Language Class Initialized
INFO - 2016-11-03 06:23:59 --> Language Class Initialized
INFO - 2016-11-03 06:23:59 --> Config Class Initialized
INFO - 2016-11-03 06:23:59 --> Loader Class Initialized
INFO - 2016-11-03 06:23:59 --> Helper loaded: url_helper
INFO - 2016-11-03 06:23:59 --> Database Driver Class Initialized
INFO - 2016-11-03 06:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:23:59 --> Controller Class Initialized
DEBUG - 2016-11-03 06:23:59 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:23:59 --> Model Class Initialized
INFO - 2016-11-03 06:23:59 --> Model Class Initialized
ERROR - 2016-11-03 06:23:59 --> Unable to delete cache file for admin/index/getDetailAngsuran
INFO - 2016-11-03 06:23:59 --> Final output sent to browser
DEBUG - 2016-11-03 06:23:59 --> Total execution time: 0.5730
INFO - 2016-11-03 06:24:00 --> Config Class Initialized
INFO - 2016-11-03 06:24:01 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:24:01 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:24:01 --> Utf8 Class Initialized
INFO - 2016-11-03 06:24:01 --> URI Class Initialized
INFO - 2016-11-03 06:24:01 --> Router Class Initialized
INFO - 2016-11-03 06:24:01 --> Output Class Initialized
INFO - 2016-11-03 06:24:01 --> Security Class Initialized
DEBUG - 2016-11-03 06:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:24:01 --> Input Class Initialized
INFO - 2016-11-03 06:24:01 --> Language Class Initialized
INFO - 2016-11-03 06:24:01 --> Language Class Initialized
INFO - 2016-11-03 06:24:01 --> Config Class Initialized
INFO - 2016-11-03 06:24:01 --> Loader Class Initialized
INFO - 2016-11-03 06:24:01 --> Helper loaded: url_helper
INFO - 2016-11-03 06:24:01 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:24:01 --> Controller Class Initialized
DEBUG - 2016-11-03 06:24:01 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:24:01 --> Model Class Initialized
INFO - 2016-11-03 06:24:01 --> Model Class Initialized
ERROR - 2016-11-03 06:24:01 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-11-03 06:24:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-11-03 06:24:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-11-03 06:24:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-11-03 06:24:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-11-03 06:24:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-11-03 06:24:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-11-03 06:24:02 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:02 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:02 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:02 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:02 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:02 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:02 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:02 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:02 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:02 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:02 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:02 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:02 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:02 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:02 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:02 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:02 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:02 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:02 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:02 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:02 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:02 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:02 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:02 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:02 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:02 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:03 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:03 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:03 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:03 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:03 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:03 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:03 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:03 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:03 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:03 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:03 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:03 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:03 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:03 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:03 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:03 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:03 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:03 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:03 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:03 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:03 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:03 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:03 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:03 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:03 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:03 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:03 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:03 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:03 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:03 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:03 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:04 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:04 --> Database Driver Class Initialized
DEBUG - 2016-11-03 06:24:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-11-03 06:24:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-11-03 06:24:04 --> Final output sent to browser
DEBUG - 2016-11-03 06:24:04 --> Total execution time: 3.1491
INFO - 2016-11-03 06:24:14 --> Config Class Initialized
INFO - 2016-11-03 06:24:14 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:24:14 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:24:14 --> Utf8 Class Initialized
INFO - 2016-11-03 06:24:14 --> URI Class Initialized
INFO - 2016-11-03 06:24:14 --> Router Class Initialized
INFO - 2016-11-03 06:24:14 --> Output Class Initialized
INFO - 2016-11-03 06:24:14 --> Security Class Initialized
DEBUG - 2016-11-03 06:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:24:14 --> Input Class Initialized
INFO - 2016-11-03 06:24:14 --> Language Class Initialized
INFO - 2016-11-03 06:24:14 --> Language Class Initialized
INFO - 2016-11-03 06:24:14 --> Config Class Initialized
INFO - 2016-11-03 06:24:14 --> Loader Class Initialized
INFO - 2016-11-03 06:24:14 --> Helper loaded: url_helper
INFO - 2016-11-03 06:24:14 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:24:14 --> Controller Class Initialized
DEBUG - 2016-11-03 06:24:14 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:24:14 --> Model Class Initialized
INFO - 2016-11-03 06:24:14 --> Model Class Initialized
ERROR - 2016-11-03 06:24:14 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-11-03 06:24:14 --> Anggota MX_Controller Initialized
INFO - 2016-11-03 06:24:14 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:14 --> Final output sent to browser
DEBUG - 2016-11-03 06:24:14 --> Total execution time: 0.6501
INFO - 2016-11-03 06:24:18 --> Config Class Initialized
INFO - 2016-11-03 06:24:18 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:24:18 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:24:18 --> Utf8 Class Initialized
INFO - 2016-11-03 06:24:18 --> URI Class Initialized
INFO - 2016-11-03 06:24:18 --> Router Class Initialized
INFO - 2016-11-03 06:24:18 --> Output Class Initialized
INFO - 2016-11-03 06:24:18 --> Security Class Initialized
DEBUG - 2016-11-03 06:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:24:18 --> Input Class Initialized
INFO - 2016-11-03 06:24:18 --> Language Class Initialized
INFO - 2016-11-03 06:24:18 --> Language Class Initialized
INFO - 2016-11-03 06:24:18 --> Config Class Initialized
INFO - 2016-11-03 06:24:18 --> Loader Class Initialized
INFO - 2016-11-03 06:24:18 --> Helper loaded: url_helper
INFO - 2016-11-03 06:24:18 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:24:18 --> Controller Class Initialized
DEBUG - 2016-11-03 06:24:18 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:24:18 --> Model Class Initialized
INFO - 2016-11-03 06:24:19 --> Model Class Initialized
ERROR - 2016-11-03 06:24:19 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-11-03 06:24:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-11-03 06:24:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-11-03 06:24:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-11-03 06:24:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_umum.php
DEBUG - 2016-11-03 06:24:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-11-03 06:24:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-11-03 06:24:19 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:19 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:19 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:19 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:19 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:19 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:19 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:19 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:19 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:19 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:19 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:19 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:19 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:19 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:19 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:19 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:19 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:19 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:19 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:19 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:19 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:19 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:19 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:19 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:19 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:20 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:20 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:20 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:20 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:20 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:20 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:20 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:20 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:20 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:20 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:20 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:20 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:20 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:20 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:20 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:20 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:20 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:20 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:20 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:20 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:20 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:20 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:20 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:20 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:20 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:20 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:20 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:20 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:20 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:21 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:21 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:21 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:21 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:21 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:21 --> Database Driver Class Initialized
DEBUG - 2016-11-03 06:24:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-11-03 06:24:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-11-03 06:24:21 --> Final output sent to browser
DEBUG - 2016-11-03 06:24:21 --> Total execution time: 2.9607
INFO - 2016-11-03 06:24:26 --> Config Class Initialized
INFO - 2016-11-03 06:24:26 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:24:26 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:24:26 --> Utf8 Class Initialized
INFO - 2016-11-03 06:24:26 --> URI Class Initialized
INFO - 2016-11-03 06:24:26 --> Router Class Initialized
INFO - 2016-11-03 06:24:26 --> Output Class Initialized
INFO - 2016-11-03 06:24:26 --> Security Class Initialized
DEBUG - 2016-11-03 06:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:24:26 --> Input Class Initialized
INFO - 2016-11-03 06:24:26 --> Language Class Initialized
INFO - 2016-11-03 06:24:26 --> Language Class Initialized
INFO - 2016-11-03 06:24:26 --> Config Class Initialized
INFO - 2016-11-03 06:24:26 --> Loader Class Initialized
INFO - 2016-11-03 06:24:26 --> Helper loaded: url_helper
INFO - 2016-11-03 06:24:26 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:24:27 --> Controller Class Initialized
DEBUG - 2016-11-03 06:24:27 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:24:27 --> Model Class Initialized
INFO - 2016-11-03 06:24:27 --> Model Class Initialized
ERROR - 2016-11-03 06:24:27 --> Unable to delete cache file for admin/index/do_ajukan_pinjaman
INFO - 2016-11-03 06:24:27 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:27 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:27 --> Final output sent to browser
DEBUG - 2016-11-03 06:24:27 --> Total execution time: 0.8237
INFO - 2016-11-03 06:24:40 --> Config Class Initialized
INFO - 2016-11-03 06:24:40 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:24:40 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:24:40 --> Utf8 Class Initialized
INFO - 2016-11-03 06:24:40 --> URI Class Initialized
INFO - 2016-11-03 06:24:40 --> Router Class Initialized
INFO - 2016-11-03 06:24:40 --> Output Class Initialized
INFO - 2016-11-03 06:24:40 --> Security Class Initialized
DEBUG - 2016-11-03 06:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:24:41 --> Input Class Initialized
INFO - 2016-11-03 06:24:41 --> Language Class Initialized
INFO - 2016-11-03 06:24:41 --> Language Class Initialized
INFO - 2016-11-03 06:24:41 --> Config Class Initialized
INFO - 2016-11-03 06:24:41 --> Loader Class Initialized
INFO - 2016-11-03 06:24:41 --> Helper loaded: url_helper
INFO - 2016-11-03 06:24:41 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:24:41 --> Controller Class Initialized
DEBUG - 2016-11-03 06:24:41 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:24:41 --> Model Class Initialized
INFO - 2016-11-03 06:24:41 --> Model Class Initialized
ERROR - 2016-11-03 06:24:41 --> Unable to delete cache file for admin/index/do_save_jaminan/sertifikat
INFO - 2016-11-03 06:24:41 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:41 --> Final output sent to browser
DEBUG - 2016-11-03 06:24:41 --> Total execution time: 0.8336
INFO - 2016-11-03 06:24:46 --> Config Class Initialized
INFO - 2016-11-03 06:24:46 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:24:46 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:24:46 --> Utf8 Class Initialized
INFO - 2016-11-03 06:24:46 --> URI Class Initialized
INFO - 2016-11-03 06:24:46 --> Router Class Initialized
INFO - 2016-11-03 06:24:46 --> Output Class Initialized
INFO - 2016-11-03 06:24:46 --> Security Class Initialized
DEBUG - 2016-11-03 06:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:24:46 --> Input Class Initialized
INFO - 2016-11-03 06:24:47 --> Language Class Initialized
INFO - 2016-11-03 06:24:47 --> Language Class Initialized
INFO - 2016-11-03 06:24:47 --> Config Class Initialized
INFO - 2016-11-03 06:24:47 --> Loader Class Initialized
INFO - 2016-11-03 06:24:47 --> Helper loaded: url_helper
INFO - 2016-11-03 06:24:47 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:24:47 --> Controller Class Initialized
DEBUG - 2016-11-03 06:24:47 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:24:47 --> Model Class Initialized
INFO - 2016-11-03 06:24:47 --> Model Class Initialized
ERROR - 2016-11-03 06:24:47 --> Unable to delete cache file for admin/index/proses_peminjaman
INFO - 2016-11-03 06:24:47 --> Final output sent to browser
DEBUG - 2016-11-03 06:24:47 --> Total execution time: 0.9536
INFO - 2016-11-03 06:24:47 --> Config Class Initialized
INFO - 2016-11-03 06:24:47 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:24:47 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:24:47 --> Utf8 Class Initialized
INFO - 2016-11-03 06:24:47 --> URI Class Initialized
INFO - 2016-11-03 06:24:47 --> Router Class Initialized
INFO - 2016-11-03 06:24:47 --> Output Class Initialized
INFO - 2016-11-03 06:24:47 --> Security Class Initialized
DEBUG - 2016-11-03 06:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:24:47 --> Input Class Initialized
INFO - 2016-11-03 06:24:48 --> Language Class Initialized
INFO - 2016-11-03 06:24:48 --> Language Class Initialized
INFO - 2016-11-03 06:24:48 --> Config Class Initialized
INFO - 2016-11-03 06:24:48 --> Loader Class Initialized
INFO - 2016-11-03 06:24:48 --> Helper loaded: url_helper
INFO - 2016-11-03 06:24:48 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:24:48 --> Controller Class Initialized
DEBUG - 2016-11-03 06:24:48 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:24:48 --> Model Class Initialized
INFO - 2016-11-03 06:24:48 --> Model Class Initialized
ERROR - 2016-11-03 06:24:48 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-11-03 06:24:48 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-11-03 06:24:48 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-11-03 06:24:48 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-11-03 06:24:48 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-11-03 06:24:48 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-11-03 06:24:48 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-11-03 06:24:48 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:48 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:48 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:48 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:48 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:48 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:48 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:48 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:48 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:48 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:48 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:48 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:48 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:48 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:48 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:49 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:49 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:49 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:49 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:49 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:49 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:49 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:49 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:49 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:49 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:49 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:49 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:49 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:49 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:49 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:49 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:49 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:49 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:49 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:49 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:49 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:49 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:49 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:49 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:49 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:49 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:49 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:49 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:49 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:49 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:50 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:50 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:50 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:50 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:50 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:50 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:50 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:50 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:50 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:50 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:50 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:50 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:50 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:50 --> Database Driver Class Initialized
DEBUG - 2016-11-03 06:24:50 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-11-03 06:24:50 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-11-03 06:24:50 --> Final output sent to browser
DEBUG - 2016-11-03 06:24:50 --> Total execution time: 2.9409
INFO - 2016-11-03 06:24:54 --> Config Class Initialized
INFO - 2016-11-03 06:24:54 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:24:54 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:24:54 --> Utf8 Class Initialized
INFO - 2016-11-03 06:24:54 --> URI Class Initialized
INFO - 2016-11-03 06:24:54 --> Router Class Initialized
INFO - 2016-11-03 06:24:54 --> Output Class Initialized
INFO - 2016-11-03 06:24:54 --> Security Class Initialized
DEBUG - 2016-11-03 06:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:24:54 --> Input Class Initialized
INFO - 2016-11-03 06:24:54 --> Language Class Initialized
INFO - 2016-11-03 06:24:54 --> Language Class Initialized
INFO - 2016-11-03 06:24:54 --> Config Class Initialized
INFO - 2016-11-03 06:24:54 --> Loader Class Initialized
INFO - 2016-11-03 06:24:54 --> Helper loaded: url_helper
INFO - 2016-11-03 06:24:54 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:24:54 --> Controller Class Initialized
DEBUG - 2016-11-03 06:24:54 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:24:54 --> Model Class Initialized
INFO - 2016-11-03 06:24:55 --> Model Class Initialized
ERROR - 2016-11-03 06:24:55 --> Unable to delete cache file for admin/index/cetak/0286dd552c9bea9a69ecb3759e7b94777635514b
INFO - 2016-11-03 06:24:55 --> Database Driver Class Initialized
INFO - 2016-11-03 06:24:55 --> Database Driver Class Initialized
DEBUG - 2016-11-03 06:24:55 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/perjanijan.php
INFO - 2016-11-03 06:24:55 --> Final output sent to browser
DEBUG - 2016-11-03 06:24:55 --> Total execution time: 1.0955
INFO - 2016-11-03 06:25:25 --> Config Class Initialized
INFO - 2016-11-03 06:25:25 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:25:25 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:25:25 --> Utf8 Class Initialized
INFO - 2016-11-03 06:25:25 --> URI Class Initialized
INFO - 2016-11-03 06:25:25 --> Router Class Initialized
INFO - 2016-11-03 06:25:25 --> Output Class Initialized
INFO - 2016-11-03 06:25:25 --> Security Class Initialized
DEBUG - 2016-11-03 06:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:25:25 --> Input Class Initialized
INFO - 2016-11-03 06:25:25 --> Language Class Initialized
INFO - 2016-11-03 06:25:25 --> Language Class Initialized
INFO - 2016-11-03 06:25:25 --> Config Class Initialized
INFO - 2016-11-03 06:25:25 --> Loader Class Initialized
INFO - 2016-11-03 06:25:25 --> Helper loaded: url_helper
INFO - 2016-11-03 06:25:25 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:25:26 --> Controller Class Initialized
DEBUG - 2016-11-03 06:25:26 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:25:26 --> Model Class Initialized
INFO - 2016-11-03 06:25:26 --> Model Class Initialized
ERROR - 2016-11-03 06:25:26 --> Unable to delete cache file for admin/index/finish_pinjaman/0286dd552c9bea9a69ecb3759e7b94777635514b
INFO - 2016-11-03 06:25:26 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:26 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:26 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:26 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:26 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:26 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:26 --> Final output sent to browser
DEBUG - 2016-11-03 06:25:26 --> Total execution time: 1.4415
INFO - 2016-11-03 06:25:26 --> Config Class Initialized
INFO - 2016-11-03 06:25:26 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:25:26 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:25:27 --> Utf8 Class Initialized
INFO - 2016-11-03 06:25:27 --> URI Class Initialized
INFO - 2016-11-03 06:25:27 --> Router Class Initialized
INFO - 2016-11-03 06:25:27 --> Output Class Initialized
INFO - 2016-11-03 06:25:27 --> Security Class Initialized
DEBUG - 2016-11-03 06:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:25:27 --> Input Class Initialized
INFO - 2016-11-03 06:25:27 --> Language Class Initialized
INFO - 2016-11-03 06:25:27 --> Language Class Initialized
INFO - 2016-11-03 06:25:27 --> Config Class Initialized
INFO - 2016-11-03 06:25:27 --> Loader Class Initialized
INFO - 2016-11-03 06:25:27 --> Helper loaded: url_helper
INFO - 2016-11-03 06:25:27 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:25:27 --> Controller Class Initialized
DEBUG - 2016-11-03 06:25:27 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:25:27 --> Model Class Initialized
INFO - 2016-11-03 06:25:27 --> Model Class Initialized
ERROR - 2016-11-03 06:25:27 --> Unable to delete cache file for admin/index/data_peminjam
DEBUG - 2016-11-03 06:25:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-11-03 06:25:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-11-03 06:25:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-11-03 06:25:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_peminjam.php
DEBUG - 2016-11-03 06:25:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-11-03 06:25:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-11-03 06:25:27 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:27 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:27 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:27 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:27 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:28 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:28 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:28 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:28 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:28 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:28 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:28 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:28 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:28 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:28 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:28 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:28 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:28 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:28 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:28 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:28 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:28 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:28 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:28 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:28 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:28 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:28 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:28 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:28 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:28 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:28 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:28 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:28 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:29 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:29 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:29 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:29 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:29 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:29 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:29 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:29 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:29 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:29 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:29 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:29 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:29 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:29 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:29 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:29 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:29 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:29 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:29 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:29 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:29 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:29 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:29 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:29 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:29 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:29 --> Database Driver Class Initialized
DEBUG - 2016-11-03 06:25:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-11-03 06:25:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-11-03 06:25:29 --> Final output sent to browser
DEBUG - 2016-11-03 06:25:30 --> Total execution time: 3.0482
INFO - 2016-11-03 06:25:32 --> Config Class Initialized
INFO - 2016-11-03 06:25:32 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:25:32 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:25:32 --> Utf8 Class Initialized
INFO - 2016-11-03 06:25:33 --> URI Class Initialized
INFO - 2016-11-03 06:25:33 --> Router Class Initialized
INFO - 2016-11-03 06:25:33 --> Output Class Initialized
INFO - 2016-11-03 06:25:33 --> Security Class Initialized
DEBUG - 2016-11-03 06:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:25:33 --> Input Class Initialized
INFO - 2016-11-03 06:25:33 --> Language Class Initialized
INFO - 2016-11-03 06:25:33 --> Language Class Initialized
INFO - 2016-11-03 06:25:33 --> Config Class Initialized
INFO - 2016-11-03 06:25:33 --> Loader Class Initialized
INFO - 2016-11-03 06:25:33 --> Helper loaded: url_helper
INFO - 2016-11-03 06:25:33 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:25:33 --> Controller Class Initialized
DEBUG - 2016-11-03 06:25:33 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:25:33 --> Model Class Initialized
INFO - 2016-11-03 06:25:33 --> Model Class Initialized
ERROR - 2016-11-03 06:25:33 --> Unable to delete cache file for admin/index/tutup_angsuran
DEBUG - 2016-11-03 06:25:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-11-03 06:25:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-11-03 06:25:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-11-03 06:25:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_tutup_angsuran.php
DEBUG - 2016-11-03 06:25:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-11-03 06:25:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-11-03 06:25:33 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:33 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:35 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:35 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:35 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:35 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:35 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:35 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:35 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:35 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:35 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:35 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:35 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:35 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:35 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:35 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:35 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:35 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:35 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:35 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:35 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:35 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:35 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:35 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:35 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:35 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:35 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:35 --> Database Driver Class Initialized
DEBUG - 2016-11-03 06:25:35 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-11-03 06:25:35 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-11-03 06:25:35 --> Final output sent to browser
DEBUG - 2016-11-03 06:25:36 --> Total execution time: 3.0986
INFO - 2016-11-03 06:25:43 --> Config Class Initialized
INFO - 2016-11-03 06:25:43 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:25:43 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:25:43 --> Utf8 Class Initialized
INFO - 2016-11-03 06:25:43 --> URI Class Initialized
INFO - 2016-11-03 06:25:43 --> Router Class Initialized
INFO - 2016-11-03 06:25:43 --> Output Class Initialized
INFO - 2016-11-03 06:25:43 --> Security Class Initialized
DEBUG - 2016-11-03 06:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:25:43 --> Input Class Initialized
INFO - 2016-11-03 06:25:43 --> Language Class Initialized
INFO - 2016-11-03 06:25:43 --> Language Class Initialized
INFO - 2016-11-03 06:25:43 --> Config Class Initialized
INFO - 2016-11-03 06:25:43 --> Loader Class Initialized
INFO - 2016-11-03 06:25:43 --> Helper loaded: url_helper
INFO - 2016-11-03 06:25:43 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:25:44 --> Controller Class Initialized
DEBUG - 2016-11-03 06:25:44 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:25:44 --> Model Class Initialized
INFO - 2016-11-03 06:25:44 --> Model Class Initialized
ERROR - 2016-11-03 06:25:44 --> Unable to delete cache file for admin/index/getDetailLunas
INFO - 2016-11-03 06:25:44 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:44 --> Final output sent to browser
DEBUG - 2016-11-03 06:25:44 --> Total execution time: 0.6887
INFO - 2016-11-03 06:25:48 --> Config Class Initialized
INFO - 2016-11-03 06:25:48 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:25:48 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:25:48 --> Utf8 Class Initialized
INFO - 2016-11-03 06:25:48 --> URI Class Initialized
INFO - 2016-11-03 06:25:48 --> Router Class Initialized
INFO - 2016-11-03 06:25:48 --> Output Class Initialized
INFO - 2016-11-03 06:25:49 --> Security Class Initialized
DEBUG - 2016-11-03 06:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:25:49 --> Input Class Initialized
INFO - 2016-11-03 06:25:49 --> Language Class Initialized
INFO - 2016-11-03 06:25:49 --> Language Class Initialized
INFO - 2016-11-03 06:25:49 --> Config Class Initialized
INFO - 2016-11-03 06:25:49 --> Loader Class Initialized
INFO - 2016-11-03 06:25:49 --> Helper loaded: url_helper
INFO - 2016-11-03 06:25:49 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:25:49 --> Controller Class Initialized
DEBUG - 2016-11-03 06:25:49 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:25:49 --> Model Class Initialized
INFO - 2016-11-03 06:25:49 --> Model Class Initialized
ERROR - 2016-11-03 06:25:49 --> Unable to delete cache file for admin/index/do_lunas
INFO - 2016-11-03 06:25:49 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:49 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:49 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:49 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:49 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:49 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:49 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:49 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:49 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:50 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:50 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:50 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:50 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:50 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:50 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:50 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:50 --> Final output sent to browser
DEBUG - 2016-11-03 06:25:50 --> Total execution time: 1.8407
INFO - 2016-11-03 06:25:53 --> Config Class Initialized
INFO - 2016-11-03 06:25:53 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:25:53 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:25:53 --> Utf8 Class Initialized
INFO - 2016-11-03 06:25:53 --> URI Class Initialized
INFO - 2016-11-03 06:25:53 --> Router Class Initialized
INFO - 2016-11-03 06:25:53 --> Output Class Initialized
INFO - 2016-11-03 06:25:53 --> Security Class Initialized
DEBUG - 2016-11-03 06:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:25:53 --> Input Class Initialized
INFO - 2016-11-03 06:25:53 --> Language Class Initialized
INFO - 2016-11-03 06:25:53 --> Language Class Initialized
INFO - 2016-11-03 06:25:53 --> Config Class Initialized
INFO - 2016-11-03 06:25:53 --> Loader Class Initialized
INFO - 2016-11-03 06:25:53 --> Helper loaded: url_helper
INFO - 2016-11-03 06:25:54 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:25:54 --> Controller Class Initialized
DEBUG - 2016-11-03 06:25:54 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:25:54 --> Model Class Initialized
INFO - 2016-11-03 06:25:54 --> Model Class Initialized
ERROR - 2016-11-03 06:25:54 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-11-03 06:25:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-11-03 06:25:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-11-03 06:25:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-11-03 06:25:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-11-03 06:25:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-11-03 06:25:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-11-03 06:25:54 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:54 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:54 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:54 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:54 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:54 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:54 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:55 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:55 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:55 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:55 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:55 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:55 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:55 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:55 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:55 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:55 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:55 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:55 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:55 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:55 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:55 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:55 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:55 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:55 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:55 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:55 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:55 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:55 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:55 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:55 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:55 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:56 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:56 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:56 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:56 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:56 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:56 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:56 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:56 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:56 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:56 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:56 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:56 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:56 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:56 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:56 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:25:57 --> Database Driver Class Initialized
DEBUG - 2016-11-03 06:25:57 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-11-03 06:25:57 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-11-03 06:25:57 --> Final output sent to browser
DEBUG - 2016-11-03 06:25:57 --> Total execution time: 4.5325
INFO - 2016-11-03 06:26:09 --> Config Class Initialized
INFO - 2016-11-03 06:26:09 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:26:09 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:26:09 --> Utf8 Class Initialized
INFO - 2016-11-03 06:26:09 --> URI Class Initialized
INFO - 2016-11-03 06:26:09 --> Router Class Initialized
INFO - 2016-11-03 06:26:09 --> Output Class Initialized
INFO - 2016-11-03 06:26:09 --> Security Class Initialized
DEBUG - 2016-11-03 06:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:26:09 --> Input Class Initialized
INFO - 2016-11-03 06:26:09 --> Language Class Initialized
INFO - 2016-11-03 06:26:09 --> Language Class Initialized
INFO - 2016-11-03 06:26:09 --> Config Class Initialized
INFO - 2016-11-03 06:26:09 --> Loader Class Initialized
INFO - 2016-11-03 06:26:09 --> Helper loaded: url_helper
INFO - 2016-11-03 06:26:09 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:26:09 --> Controller Class Initialized
DEBUG - 2016-11-03 06:26:09 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:26:09 --> Model Class Initialized
INFO - 2016-11-03 06:26:09 --> Model Class Initialized
ERROR - 2016-11-03 06:26:09 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-11-03 06:26:09 --> Anggota MX_Controller Initialized
INFO - 2016-11-03 06:26:09 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:09 --> Final output sent to browser
DEBUG - 2016-11-03 06:26:09 --> Total execution time: 0.6724
INFO - 2016-11-03 06:26:13 --> Config Class Initialized
INFO - 2016-11-03 06:26:13 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:26:13 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:26:13 --> Utf8 Class Initialized
INFO - 2016-11-03 06:26:13 --> URI Class Initialized
INFO - 2016-11-03 06:26:13 --> Router Class Initialized
INFO - 2016-11-03 06:26:13 --> Output Class Initialized
INFO - 2016-11-03 06:26:13 --> Security Class Initialized
DEBUG - 2016-11-03 06:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:26:13 --> Input Class Initialized
INFO - 2016-11-03 06:26:13 --> Language Class Initialized
INFO - 2016-11-03 06:26:13 --> Language Class Initialized
INFO - 2016-11-03 06:26:13 --> Config Class Initialized
INFO - 2016-11-03 06:26:13 --> Loader Class Initialized
INFO - 2016-11-03 06:26:13 --> Helper loaded: url_helper
INFO - 2016-11-03 06:26:13 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:26:13 --> Controller Class Initialized
DEBUG - 2016-11-03 06:26:13 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:26:13 --> Model Class Initialized
INFO - 2016-11-03 06:26:13 --> Model Class Initialized
ERROR - 2016-11-03 06:26:13 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-11-03 06:26:14 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-11-03 06:26:14 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-11-03 06:26:14 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-11-03 06:26:14 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_umum.php
DEBUG - 2016-11-03 06:26:14 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-11-03 06:26:14 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-11-03 06:26:14 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:14 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:14 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:14 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:14 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:14 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:14 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:14 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:14 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:14 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:14 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:14 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:14 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:14 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:14 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:14 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:14 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:14 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:14 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:14 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:14 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:14 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:14 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:14 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:14 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:15 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:15 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:15 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:15 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:15 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:15 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:15 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:15 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:15 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:15 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:15 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:15 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:15 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:15 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:15 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:15 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:15 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:15 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:15 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:15 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:15 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:15 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:15 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:15 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:15 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:15 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:15 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:15 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:15 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:16 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:16 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:16 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:16 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:16 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:16 --> Database Driver Class Initialized
DEBUG - 2016-11-03 06:26:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-11-03 06:26:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-11-03 06:26:16 --> Final output sent to browser
DEBUG - 2016-11-03 06:26:16 --> Total execution time: 3.0058
INFO - 2016-11-03 06:26:20 --> Config Class Initialized
INFO - 2016-11-03 06:26:20 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:26:20 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:26:20 --> Utf8 Class Initialized
INFO - 2016-11-03 06:26:20 --> URI Class Initialized
INFO - 2016-11-03 06:26:20 --> Router Class Initialized
INFO - 2016-11-03 06:26:20 --> Output Class Initialized
INFO - 2016-11-03 06:26:21 --> Security Class Initialized
DEBUG - 2016-11-03 06:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:26:21 --> Input Class Initialized
INFO - 2016-11-03 06:26:21 --> Language Class Initialized
INFO - 2016-11-03 06:26:21 --> Language Class Initialized
INFO - 2016-11-03 06:26:21 --> Config Class Initialized
INFO - 2016-11-03 06:26:21 --> Loader Class Initialized
INFO - 2016-11-03 06:26:21 --> Helper loaded: url_helper
INFO - 2016-11-03 06:26:21 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:26:21 --> Controller Class Initialized
DEBUG - 2016-11-03 06:26:21 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:26:21 --> Model Class Initialized
INFO - 2016-11-03 06:26:21 --> Model Class Initialized
ERROR - 2016-11-03 06:26:21 --> Unable to delete cache file for admin/index/do_ajukan_pinjaman
INFO - 2016-11-03 06:26:21 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:21 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:21 --> Final output sent to browser
DEBUG - 2016-11-03 06:26:21 --> Total execution time: 0.8495
INFO - 2016-11-03 06:26:31 --> Config Class Initialized
INFO - 2016-11-03 06:26:31 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:26:31 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:26:31 --> Utf8 Class Initialized
INFO - 2016-11-03 06:26:31 --> URI Class Initialized
INFO - 2016-11-03 06:26:31 --> Router Class Initialized
INFO - 2016-11-03 06:26:31 --> Output Class Initialized
INFO - 2016-11-03 06:26:31 --> Security Class Initialized
DEBUG - 2016-11-03 06:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:26:31 --> Input Class Initialized
INFO - 2016-11-03 06:26:31 --> Language Class Initialized
INFO - 2016-11-03 06:26:31 --> Language Class Initialized
INFO - 2016-11-03 06:26:31 --> Config Class Initialized
INFO - 2016-11-03 06:26:31 --> Loader Class Initialized
INFO - 2016-11-03 06:26:31 --> Helper loaded: url_helper
INFO - 2016-11-03 06:26:31 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:26:31 --> Controller Class Initialized
DEBUG - 2016-11-03 06:26:31 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:26:31 --> Model Class Initialized
INFO - 2016-11-03 06:26:31 --> Model Class Initialized
ERROR - 2016-11-03 06:26:31 --> Unable to delete cache file for admin/index/do_save_jaminan/sertifikat
INFO - 2016-11-03 06:26:32 --> Database Driver Class Initialized
INFO - 2016-11-03 06:26:32 --> Final output sent to browser
DEBUG - 2016-11-03 06:26:32 --> Total execution time: 0.8279
INFO - 2016-11-03 06:27:08 --> Config Class Initialized
INFO - 2016-11-03 06:27:08 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:27:08 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:27:08 --> Utf8 Class Initialized
INFO - 2016-11-03 06:27:08 --> URI Class Initialized
INFO - 2016-11-03 06:27:08 --> Router Class Initialized
INFO - 2016-11-03 06:27:08 --> Output Class Initialized
INFO - 2016-11-03 06:27:08 --> Security Class Initialized
DEBUG - 2016-11-03 06:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:27:08 --> Input Class Initialized
INFO - 2016-11-03 06:27:08 --> Language Class Initialized
INFO - 2016-11-03 06:27:08 --> Language Class Initialized
INFO - 2016-11-03 06:27:08 --> Config Class Initialized
INFO - 2016-11-03 06:27:08 --> Loader Class Initialized
INFO - 2016-11-03 06:27:08 --> Helper loaded: url_helper
INFO - 2016-11-03 06:27:08 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:27:08 --> Controller Class Initialized
DEBUG - 2016-11-03 06:27:08 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:27:08 --> Model Class Initialized
INFO - 2016-11-03 06:27:08 --> Model Class Initialized
ERROR - 2016-11-03 06:27:08 --> Unable to delete cache file for admin/index/batal/0286dd552c9bea9a69ecb3759e7b94777635514b
INFO - 2016-11-03 06:27:08 --> Database Driver Class Initialized
ERROR - 2016-11-03 06:27:09 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`koperasi`.`tt_angsuran`, CONSTRAINT `FK_tt_angsuran_tm_pinjaman` FOREIGN KEY (`kd_pinjaman`) REFERENCES `tm_pinjaman` (`kd_pinjaman`)) - Invalid query: DELETE FROM `tm_pinjaman`
WHERE sha1(kd_pinjaman) = '0286dd552c9bea9a69ecb3759e7b94777635514b'
INFO - 2016-11-03 06:27:09 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-03 06:27:16 --> Config Class Initialized
INFO - 2016-11-03 06:27:16 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:27:16 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:27:16 --> Utf8 Class Initialized
INFO - 2016-11-03 06:27:16 --> URI Class Initialized
INFO - 2016-11-03 06:27:16 --> Router Class Initialized
INFO - 2016-11-03 06:27:16 --> Output Class Initialized
INFO - 2016-11-03 06:27:16 --> Security Class Initialized
DEBUG - 2016-11-03 06:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:27:16 --> Input Class Initialized
INFO - 2016-11-03 06:27:16 --> Language Class Initialized
INFO - 2016-11-03 06:27:16 --> Language Class Initialized
INFO - 2016-11-03 06:27:16 --> Config Class Initialized
INFO - 2016-11-03 06:27:16 --> Loader Class Initialized
INFO - 2016-11-03 06:27:16 --> Helper loaded: url_helper
INFO - 2016-11-03 06:27:16 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:27:16 --> Controller Class Initialized
DEBUG - 2016-11-03 06:27:16 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:27:16 --> Model Class Initialized
INFO - 2016-11-03 06:27:16 --> Model Class Initialized
ERROR - 2016-11-03 06:27:16 --> Unable to delete cache file for admin/index/batal/0286dd552c9bea9a69ecb3759e7b94777635514b
INFO - 2016-11-03 06:27:16 --> Database Driver Class Initialized
ERROR - 2016-11-03 06:27:16 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`koperasi`.`tt_angsuran`, CONSTRAINT `FK_tt_angsuran_tm_pinjaman` FOREIGN KEY (`kd_pinjaman`) REFERENCES `tm_pinjaman` (`kd_pinjaman`)) - Invalid query: DELETE FROM `tm_pinjaman`
WHERE sha1(kd_pinjaman) = '0286dd552c9bea9a69ecb3759e7b94777635514b'
INFO - 2016-11-03 06:27:16 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-03 06:27:19 --> Config Class Initialized
INFO - 2016-11-03 06:27:19 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:27:20 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:27:20 --> Utf8 Class Initialized
INFO - 2016-11-03 06:27:20 --> URI Class Initialized
INFO - 2016-11-03 06:27:20 --> Router Class Initialized
INFO - 2016-11-03 06:27:20 --> Output Class Initialized
INFO - 2016-11-03 06:27:20 --> Security Class Initialized
DEBUG - 2016-11-03 06:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:27:20 --> Input Class Initialized
INFO - 2016-11-03 06:27:20 --> Language Class Initialized
INFO - 2016-11-03 06:27:20 --> Language Class Initialized
INFO - 2016-11-03 06:27:20 --> Config Class Initialized
INFO - 2016-11-03 06:27:20 --> Loader Class Initialized
INFO - 2016-11-03 06:27:20 --> Helper loaded: url_helper
INFO - 2016-11-03 06:27:20 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:27:20 --> Controller Class Initialized
DEBUG - 2016-11-03 06:27:20 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:27:20 --> Model Class Initialized
INFO - 2016-11-03 06:27:20 --> Model Class Initialized
ERROR - 2016-11-03 06:27:20 --> Unable to delete cache file for admin/index/batal/0286dd552c9bea9a69ecb3759e7b94777635514b
INFO - 2016-11-03 06:27:20 --> Database Driver Class Initialized
ERROR - 2016-11-03 06:27:20 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`koperasi`.`tt_angsuran`, CONSTRAINT `FK_tt_angsuran_tm_pinjaman` FOREIGN KEY (`kd_pinjaman`) REFERENCES `tm_pinjaman` (`kd_pinjaman`)) - Invalid query: DELETE FROM `tm_pinjaman`
WHERE sha1(kd_pinjaman) = '0286dd552c9bea9a69ecb3759e7b94777635514b'
INFO - 2016-11-03 06:27:20 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-03 06:27:23 --> Config Class Initialized
INFO - 2016-11-03 06:27:23 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:27:23 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:27:23 --> Utf8 Class Initialized
INFO - 2016-11-03 06:27:24 --> URI Class Initialized
INFO - 2016-11-03 06:27:24 --> Router Class Initialized
INFO - 2016-11-03 06:27:24 --> Output Class Initialized
INFO - 2016-11-03 06:27:24 --> Security Class Initialized
DEBUG - 2016-11-03 06:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:27:24 --> Input Class Initialized
INFO - 2016-11-03 06:27:24 --> Language Class Initialized
INFO - 2016-11-03 06:27:24 --> Language Class Initialized
INFO - 2016-11-03 06:27:24 --> Config Class Initialized
INFO - 2016-11-03 06:27:24 --> Loader Class Initialized
INFO - 2016-11-03 06:27:24 --> Helper loaded: url_helper
INFO - 2016-11-03 06:27:24 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:27:24 --> Controller Class Initialized
DEBUG - 2016-11-03 06:27:24 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:27:24 --> Model Class Initialized
INFO - 2016-11-03 06:27:24 --> Model Class Initialized
ERROR - 2016-11-03 06:27:24 --> Unable to delete cache file for admin/index/batal/0286dd552c9bea9a69ecb3759e7b94777635514b
INFO - 2016-11-03 06:27:24 --> Database Driver Class Initialized
ERROR - 2016-11-03 06:27:24 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`koperasi`.`tt_angsuran`, CONSTRAINT `FK_tt_angsuran_tm_pinjaman` FOREIGN KEY (`kd_pinjaman`) REFERENCES `tm_pinjaman` (`kd_pinjaman`)) - Invalid query: DELETE FROM `tm_pinjaman`
WHERE sha1(kd_pinjaman) = '0286dd552c9bea9a69ecb3759e7b94777635514b'
INFO - 2016-11-03 06:27:24 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-03 06:27:26 --> Config Class Initialized
INFO - 2016-11-03 06:27:26 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:27:26 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:27:26 --> Utf8 Class Initialized
INFO - 2016-11-03 06:27:26 --> URI Class Initialized
INFO - 2016-11-03 06:27:26 --> Router Class Initialized
INFO - 2016-11-03 06:27:26 --> Output Class Initialized
INFO - 2016-11-03 06:27:26 --> Security Class Initialized
DEBUG - 2016-11-03 06:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:27:26 --> Input Class Initialized
INFO - 2016-11-03 06:27:26 --> Language Class Initialized
INFO - 2016-11-03 06:27:26 --> Language Class Initialized
INFO - 2016-11-03 06:27:26 --> Config Class Initialized
INFO - 2016-11-03 06:27:26 --> Loader Class Initialized
INFO - 2016-11-03 06:27:26 --> Helper loaded: url_helper
INFO - 2016-11-03 06:27:26 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:27:26 --> Controller Class Initialized
DEBUG - 2016-11-03 06:27:26 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:27:26 --> Model Class Initialized
INFO - 2016-11-03 06:27:26 --> Model Class Initialized
ERROR - 2016-11-03 06:27:26 --> Unable to delete cache file for admin/index/finish_pinjaman/0286dd552c9bea9a69ecb3759e7b94777635514b
INFO - 2016-11-03 06:27:26 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:26 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:26 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:26 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:27 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:27 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:27 --> Final output sent to browser
DEBUG - 2016-11-03 06:27:27 --> Total execution time: 0.9732
INFO - 2016-11-03 06:27:27 --> Config Class Initialized
INFO - 2016-11-03 06:27:27 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:27:27 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:27:27 --> Utf8 Class Initialized
INFO - 2016-11-03 06:27:27 --> URI Class Initialized
INFO - 2016-11-03 06:27:27 --> Router Class Initialized
INFO - 2016-11-03 06:27:27 --> Output Class Initialized
INFO - 2016-11-03 06:27:27 --> Security Class Initialized
DEBUG - 2016-11-03 06:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:27:27 --> Input Class Initialized
INFO - 2016-11-03 06:27:27 --> Language Class Initialized
INFO - 2016-11-03 06:27:27 --> Language Class Initialized
INFO - 2016-11-03 06:27:27 --> Config Class Initialized
INFO - 2016-11-03 06:27:27 --> Loader Class Initialized
INFO - 2016-11-03 06:27:27 --> Helper loaded: url_helper
INFO - 2016-11-03 06:27:27 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:27:28 --> Controller Class Initialized
DEBUG - 2016-11-03 06:27:28 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:27:28 --> Model Class Initialized
INFO - 2016-11-03 06:27:28 --> Model Class Initialized
ERROR - 2016-11-03 06:27:28 --> Unable to delete cache file for admin/index/data_peminjam
DEBUG - 2016-11-03 06:27:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-11-03 06:27:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-11-03 06:27:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-11-03 06:27:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_peminjam.php
DEBUG - 2016-11-03 06:27:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-11-03 06:27:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-11-03 06:27:28 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:28 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:28 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:28 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:28 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:28 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:28 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:28 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:28 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:28 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:28 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:28 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:28 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:28 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:28 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:28 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:28 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:28 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:28 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:29 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:29 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:29 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:29 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:29 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:29 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:29 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:29 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:29 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:29 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:29 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:29 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:29 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:29 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:29 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:29 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:29 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:29 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:29 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:29 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:29 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:29 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:29 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:29 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:29 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:29 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:30 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:30 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:30 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:30 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:30 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:30 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:30 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:30 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:30 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:30 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:30 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:30 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:30 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:30 --> Database Driver Class Initialized
DEBUG - 2016-11-03 06:27:30 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-11-03 06:27:30 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-11-03 06:27:30 --> Final output sent to browser
DEBUG - 2016-11-03 06:27:30 --> Total execution time: 3.2835
INFO - 2016-11-03 06:27:35 --> Config Class Initialized
INFO - 2016-11-03 06:27:35 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:27:35 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:27:35 --> Utf8 Class Initialized
INFO - 2016-11-03 06:27:35 --> URI Class Initialized
INFO - 2016-11-03 06:27:35 --> Router Class Initialized
INFO - 2016-11-03 06:27:35 --> Output Class Initialized
INFO - 2016-11-03 06:27:35 --> Security Class Initialized
DEBUG - 2016-11-03 06:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:27:35 --> Input Class Initialized
INFO - 2016-11-03 06:27:35 --> Language Class Initialized
INFO - 2016-11-03 06:27:35 --> Language Class Initialized
INFO - 2016-11-03 06:27:35 --> Config Class Initialized
INFO - 2016-11-03 06:27:35 --> Loader Class Initialized
INFO - 2016-11-03 06:27:35 --> Helper loaded: url_helper
INFO - 2016-11-03 06:27:35 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:27:36 --> Controller Class Initialized
DEBUG - 2016-11-03 06:27:36 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:27:36 --> Model Class Initialized
INFO - 2016-11-03 06:27:36 --> Model Class Initialized
ERROR - 2016-11-03 06:27:36 --> Unable to delete cache file for admin/index/tutup_angsuran
DEBUG - 2016-11-03 06:27:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-11-03 06:27:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-11-03 06:27:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-11-03 06:27:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_tutup_angsuran.php
DEBUG - 2016-11-03 06:27:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-11-03 06:27:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-11-03 06:27:36 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:36 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:36 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:36 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:36 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:36 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:36 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:36 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:36 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:36 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:36 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:36 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:36 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:36 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:36 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:36 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:36 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:36 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:36 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:36 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:37 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:37 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:37 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:37 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:37 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:37 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:37 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:37 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:37 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:37 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:37 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:37 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:37 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:37 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:37 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:37 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:37 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:37 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:37 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:37 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:37 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:37 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:37 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:37 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:37 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:37 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:37 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:37 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:38 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:38 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:38 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:38 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:38 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:38 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:38 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:38 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:38 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:38 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:38 --> Database Driver Class Initialized
DEBUG - 2016-11-03 06:27:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-11-03 06:27:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-11-03 06:27:38 --> Final output sent to browser
DEBUG - 2016-11-03 06:27:38 --> Total execution time: 3.1253
INFO - 2016-11-03 06:27:41 --> Config Class Initialized
INFO - 2016-11-03 06:27:41 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:27:41 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:27:41 --> Utf8 Class Initialized
INFO - 2016-11-03 06:27:41 --> URI Class Initialized
INFO - 2016-11-03 06:27:41 --> Router Class Initialized
INFO - 2016-11-03 06:27:41 --> Output Class Initialized
INFO - 2016-11-03 06:27:41 --> Security Class Initialized
DEBUG - 2016-11-03 06:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:27:41 --> Input Class Initialized
INFO - 2016-11-03 06:27:41 --> Language Class Initialized
INFO - 2016-11-03 06:27:41 --> Language Class Initialized
INFO - 2016-11-03 06:27:41 --> Config Class Initialized
INFO - 2016-11-03 06:27:41 --> Loader Class Initialized
INFO - 2016-11-03 06:27:41 --> Helper loaded: url_helper
INFO - 2016-11-03 06:27:41 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:27:41 --> Controller Class Initialized
DEBUG - 2016-11-03 06:27:42 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:27:42 --> Model Class Initialized
INFO - 2016-11-03 06:27:42 --> Model Class Initialized
ERROR - 2016-11-03 06:27:42 --> Unable to delete cache file for admin/index/getDetailLunas
INFO - 2016-11-03 06:27:42 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:42 --> Final output sent to browser
DEBUG - 2016-11-03 06:27:42 --> Total execution time: 0.7158
INFO - 2016-11-03 06:27:46 --> Config Class Initialized
INFO - 2016-11-03 06:27:46 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:27:46 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:27:46 --> Utf8 Class Initialized
INFO - 2016-11-03 06:27:46 --> URI Class Initialized
INFO - 2016-11-03 06:27:46 --> Router Class Initialized
INFO - 2016-11-03 06:27:47 --> Output Class Initialized
INFO - 2016-11-03 06:27:47 --> Security Class Initialized
DEBUG - 2016-11-03 06:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:27:47 --> Input Class Initialized
INFO - 2016-11-03 06:27:47 --> Language Class Initialized
INFO - 2016-11-03 06:27:47 --> Language Class Initialized
INFO - 2016-11-03 06:27:47 --> Config Class Initialized
INFO - 2016-11-03 06:27:47 --> Loader Class Initialized
INFO - 2016-11-03 06:27:47 --> Helper loaded: url_helper
INFO - 2016-11-03 06:27:47 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:27:47 --> Controller Class Initialized
DEBUG - 2016-11-03 06:27:47 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:27:47 --> Model Class Initialized
INFO - 2016-11-03 06:27:47 --> Model Class Initialized
ERROR - 2016-11-03 06:27:47 --> Unable to delete cache file for admin/index/do_lunas
INFO - 2016-11-03 06:27:47 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:47 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:47 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:47 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:47 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:47 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:47 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:48 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:48 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:48 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:48 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:48 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:48 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:48 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:48 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:48 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:48 --> Final output sent to browser
DEBUG - 2016-11-03 06:27:48 --> Total execution time: 2.0428
INFO - 2016-11-03 06:27:55 --> Config Class Initialized
INFO - 2016-11-03 06:27:55 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:27:55 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:27:55 --> Utf8 Class Initialized
INFO - 2016-11-03 06:27:55 --> URI Class Initialized
INFO - 2016-11-03 06:27:55 --> Router Class Initialized
INFO - 2016-11-03 06:27:55 --> Output Class Initialized
INFO - 2016-11-03 06:27:56 --> Security Class Initialized
DEBUG - 2016-11-03 06:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:27:56 --> Input Class Initialized
INFO - 2016-11-03 06:27:56 --> Language Class Initialized
INFO - 2016-11-03 06:27:56 --> Language Class Initialized
INFO - 2016-11-03 06:27:56 --> Config Class Initialized
INFO - 2016-11-03 06:27:56 --> Loader Class Initialized
INFO - 2016-11-03 06:27:56 --> Helper loaded: url_helper
INFO - 2016-11-03 06:27:56 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:27:56 --> Controller Class Initialized
DEBUG - 2016-11-03 06:27:56 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:27:56 --> Model Class Initialized
INFO - 2016-11-03 06:27:56 --> Model Class Initialized
ERROR - 2016-11-03 06:27:56 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-11-03 06:27:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-11-03 06:27:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-11-03 06:27:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-11-03 06:27:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-11-03 06:27:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-11-03 06:27:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-11-03 06:27:56 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:56 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:56 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:56 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:56 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:56 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:58 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:58 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:58 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:58 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:58 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:58 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:58 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:58 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:58 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:58 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:58 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:58 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:58 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:58 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:58 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:58 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:58 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:58 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:58 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:58 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:58 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:58 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:58 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:58 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:58 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:58 --> Database Driver Class Initialized
INFO - 2016-11-03 06:27:58 --> Database Driver Class Initialized
DEBUG - 2016-11-03 06:27:58 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-11-03 06:27:59 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-11-03 06:27:59 --> Final output sent to browser
DEBUG - 2016-11-03 06:27:59 --> Total execution time: 3.3233
INFO - 2016-11-03 06:29:51 --> Config Class Initialized
INFO - 2016-11-03 06:29:51 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:29:51 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:29:51 --> Utf8 Class Initialized
INFO - 2016-11-03 06:29:51 --> URI Class Initialized
INFO - 2016-11-03 06:29:51 --> Router Class Initialized
INFO - 2016-11-03 06:29:51 --> Output Class Initialized
INFO - 2016-11-03 06:29:51 --> Security Class Initialized
DEBUG - 2016-11-03 06:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:29:51 --> Input Class Initialized
INFO - 2016-11-03 06:29:51 --> Language Class Initialized
INFO - 2016-11-03 06:29:51 --> Language Class Initialized
INFO - 2016-11-03 06:29:51 --> Config Class Initialized
INFO - 2016-11-03 06:29:51 --> Loader Class Initialized
INFO - 2016-11-03 06:29:51 --> Helper loaded: url_helper
INFO - 2016-11-03 06:29:51 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:29:51 --> Controller Class Initialized
DEBUG - 2016-11-03 06:29:51 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:29:51 --> Model Class Initialized
INFO - 2016-11-03 06:29:51 --> Model Class Initialized
ERROR - 2016-11-03 06:29:51 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-11-03 06:29:51 --> Anggota MX_Controller Initialized
INFO - 2016-11-03 06:29:51 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:51 --> Final output sent to browser
DEBUG - 2016-11-03 06:29:51 --> Total execution time: 0.7878
INFO - 2016-11-03 06:29:55 --> Config Class Initialized
INFO - 2016-11-03 06:29:55 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:29:55 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:29:55 --> Utf8 Class Initialized
INFO - 2016-11-03 06:29:55 --> URI Class Initialized
INFO - 2016-11-03 06:29:55 --> Router Class Initialized
INFO - 2016-11-03 06:29:55 --> Output Class Initialized
INFO - 2016-11-03 06:29:55 --> Security Class Initialized
DEBUG - 2016-11-03 06:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:29:56 --> Input Class Initialized
INFO - 2016-11-03 06:29:56 --> Language Class Initialized
INFO - 2016-11-03 06:29:56 --> Language Class Initialized
INFO - 2016-11-03 06:29:56 --> Config Class Initialized
INFO - 2016-11-03 06:29:56 --> Loader Class Initialized
INFO - 2016-11-03 06:29:56 --> Helper loaded: url_helper
INFO - 2016-11-03 06:29:56 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:29:56 --> Controller Class Initialized
DEBUG - 2016-11-03 06:29:56 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:29:56 --> Model Class Initialized
INFO - 2016-11-03 06:29:56 --> Model Class Initialized
ERROR - 2016-11-03 06:29:56 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-11-03 06:29:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-11-03 06:29:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-11-03 06:29:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-11-03 06:29:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-11-03 06:29:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-11-03 06:29:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-11-03 06:29:56 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:56 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:56 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:56 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:56 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:56 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:56 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:57 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:58 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:58 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:58 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:58 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:58 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:58 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:58 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:58 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:58 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:58 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:58 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:58 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:58 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:58 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:58 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:58 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:58 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:58 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:58 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:58 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:58 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:58 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:58 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:58 --> Database Driver Class Initialized
INFO - 2016-11-03 06:29:58 --> Database Driver Class Initialized
DEBUG - 2016-11-03 06:29:58 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-11-03 06:29:58 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-11-03 06:29:58 --> Final output sent to browser
DEBUG - 2016-11-03 06:29:59 --> Total execution time: 3.2967
INFO - 2016-11-03 06:30:18 --> Config Class Initialized
INFO - 2016-11-03 06:30:19 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:30:19 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:30:19 --> Utf8 Class Initialized
INFO - 2016-11-03 06:30:19 --> URI Class Initialized
INFO - 2016-11-03 06:30:19 --> Router Class Initialized
INFO - 2016-11-03 06:30:19 --> Output Class Initialized
INFO - 2016-11-03 06:30:19 --> Security Class Initialized
DEBUG - 2016-11-03 06:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:30:19 --> Input Class Initialized
INFO - 2016-11-03 06:30:19 --> Language Class Initialized
INFO - 2016-11-03 06:30:19 --> Language Class Initialized
INFO - 2016-11-03 06:30:19 --> Config Class Initialized
INFO - 2016-11-03 06:30:19 --> Loader Class Initialized
INFO - 2016-11-03 06:30:19 --> Helper loaded: url_helper
INFO - 2016-11-03 06:30:19 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:30:19 --> Controller Class Initialized
DEBUG - 2016-11-03 06:30:19 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:30:19 --> Model Class Initialized
INFO - 2016-11-03 06:30:19 --> Model Class Initialized
ERROR - 2016-11-03 06:30:19 --> Unable to delete cache file for admin/index/do_ajukan_pinjaman
INFO - 2016-11-03 06:30:19 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:19 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:19 --> Final output sent to browser
DEBUG - 2016-11-03 06:30:19 --> Total execution time: 0.9041
INFO - 2016-11-03 06:30:20 --> Config Class Initialized
INFO - 2016-11-03 06:30:20 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:30:20 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:30:20 --> Utf8 Class Initialized
INFO - 2016-11-03 06:30:20 --> URI Class Initialized
INFO - 2016-11-03 06:30:20 --> Router Class Initialized
INFO - 2016-11-03 06:30:20 --> Output Class Initialized
INFO - 2016-11-03 06:30:20 --> Security Class Initialized
DEBUG - 2016-11-03 06:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:30:20 --> Input Class Initialized
INFO - 2016-11-03 06:30:20 --> Language Class Initialized
INFO - 2016-11-03 06:30:21 --> Language Class Initialized
INFO - 2016-11-03 06:30:21 --> Config Class Initialized
INFO - 2016-11-03 06:30:21 --> Loader Class Initialized
INFO - 2016-11-03 06:30:21 --> Helper loaded: url_helper
INFO - 2016-11-03 06:30:21 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:30:21 --> Controller Class Initialized
DEBUG - 2016-11-03 06:30:21 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:30:21 --> Model Class Initialized
INFO - 2016-11-03 06:30:21 --> Model Class Initialized
ERROR - 2016-11-03 06:30:21 --> Unable to delete cache file for admin/index/batal/827bfc458708f0b442009c9c9836f7e4b65557fb
INFO - 2016-11-03 06:30:21 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:21 --> Final output sent to browser
DEBUG - 2016-11-03 06:30:21 --> Total execution time: 0.8165
INFO - 2016-11-03 06:30:21 --> Config Class Initialized
INFO - 2016-11-03 06:30:21 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:30:21 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:30:21 --> Utf8 Class Initialized
INFO - 2016-11-03 06:30:21 --> URI Class Initialized
INFO - 2016-11-03 06:30:21 --> Router Class Initialized
INFO - 2016-11-03 06:30:21 --> Output Class Initialized
INFO - 2016-11-03 06:30:22 --> Security Class Initialized
DEBUG - 2016-11-03 06:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:30:22 --> Input Class Initialized
INFO - 2016-11-03 06:30:22 --> Language Class Initialized
INFO - 2016-11-03 06:30:22 --> Language Class Initialized
INFO - 2016-11-03 06:30:22 --> Config Class Initialized
INFO - 2016-11-03 06:30:22 --> Loader Class Initialized
INFO - 2016-11-03 06:30:22 --> Helper loaded: url_helper
INFO - 2016-11-03 06:30:22 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:30:22 --> Controller Class Initialized
DEBUG - 2016-11-03 06:30:22 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:30:22 --> Model Class Initialized
INFO - 2016-11-03 06:30:22 --> Model Class Initialized
ERROR - 2016-11-03 06:30:22 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-11-03 06:30:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-11-03 06:30:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-11-03 06:30:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-11-03 06:30:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-11-03 06:30:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-11-03 06:30:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-11-03 06:30:22 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:22 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:22 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:23 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:23 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:23 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:23 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:23 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:23 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:23 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:23 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:23 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:23 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:23 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:23 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:23 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:23 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:23 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:23 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:23 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:23 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:23 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:23 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:23 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:23 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:23 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:23 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:23 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:23 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:23 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:23 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:24 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:24 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:24 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:24 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:24 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:24 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:24 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:24 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:24 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:24 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:24 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:24 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:24 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:24 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:24 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:24 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:24 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:24 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:24 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:24 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:24 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:24 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:24 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:24 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:24 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:24 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:24 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:24 --> Database Driver Class Initialized
DEBUG - 2016-11-03 06:30:25 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-11-03 06:30:25 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-11-03 06:30:25 --> Final output sent to browser
DEBUG - 2016-11-03 06:30:25 --> Total execution time: 3.4625
INFO - 2016-11-03 06:30:28 --> Config Class Initialized
INFO - 2016-11-03 06:30:28 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:30:29 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:30:29 --> Utf8 Class Initialized
INFO - 2016-11-03 06:30:29 --> URI Class Initialized
INFO - 2016-11-03 06:30:29 --> Router Class Initialized
INFO - 2016-11-03 06:30:29 --> Output Class Initialized
INFO - 2016-11-03 06:30:29 --> Security Class Initialized
DEBUG - 2016-11-03 06:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:30:29 --> Input Class Initialized
INFO - 2016-11-03 06:30:29 --> Language Class Initialized
INFO - 2016-11-03 06:30:29 --> Language Class Initialized
INFO - 2016-11-03 06:30:29 --> Config Class Initialized
INFO - 2016-11-03 06:30:29 --> Loader Class Initialized
INFO - 2016-11-03 06:30:29 --> Helper loaded: url_helper
INFO - 2016-11-03 06:30:29 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:30:29 --> Controller Class Initialized
DEBUG - 2016-11-03 06:30:29 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:30:29 --> Model Class Initialized
INFO - 2016-11-03 06:30:29 --> Model Class Initialized
ERROR - 2016-11-03 06:30:29 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-11-03 06:30:29 --> Anggota MX_Controller Initialized
INFO - 2016-11-03 06:30:29 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:29 --> Final output sent to browser
DEBUG - 2016-11-03 06:30:29 --> Total execution time: 0.7320
INFO - 2016-11-03 06:30:31 --> Config Class Initialized
INFO - 2016-11-03 06:30:31 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:30:31 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:30:31 --> Utf8 Class Initialized
INFO - 2016-11-03 06:30:31 --> URI Class Initialized
INFO - 2016-11-03 06:30:32 --> Router Class Initialized
INFO - 2016-11-03 06:30:32 --> Output Class Initialized
INFO - 2016-11-03 06:30:32 --> Security Class Initialized
DEBUG - 2016-11-03 06:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:30:32 --> Input Class Initialized
INFO - 2016-11-03 06:30:32 --> Language Class Initialized
INFO - 2016-11-03 06:30:32 --> Language Class Initialized
INFO - 2016-11-03 06:30:32 --> Config Class Initialized
INFO - 2016-11-03 06:30:32 --> Loader Class Initialized
INFO - 2016-11-03 06:30:32 --> Helper loaded: url_helper
INFO - 2016-11-03 06:30:32 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:30:32 --> Controller Class Initialized
DEBUG - 2016-11-03 06:30:32 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:30:32 --> Model Class Initialized
INFO - 2016-11-03 06:30:32 --> Model Class Initialized
ERROR - 2016-11-03 06:30:32 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-11-03 06:30:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-11-03 06:30:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-11-03 06:30:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-11-03 06:30:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_umum.php
DEBUG - 2016-11-03 06:30:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-11-03 06:30:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-11-03 06:30:32 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:32 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:32 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:32 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:32 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:33 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:33 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:33 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:33 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:33 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:33 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:33 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:33 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:33 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:33 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:33 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:33 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:33 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:33 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:33 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:33 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:33 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:33 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:33 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:33 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:33 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:33 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:33 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:33 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:33 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:33 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:33 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:33 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:34 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:34 --> Database Driver Class Initialized
DEBUG - 2016-11-03 06:30:34 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-11-03 06:30:35 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-11-03 06:30:35 --> Final output sent to browser
DEBUG - 2016-11-03 06:30:35 --> Total execution time: 3.1984
INFO - 2016-11-03 06:30:39 --> Config Class Initialized
INFO - 2016-11-03 06:30:39 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:30:39 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:30:39 --> Utf8 Class Initialized
INFO - 2016-11-03 06:30:39 --> URI Class Initialized
INFO - 2016-11-03 06:30:39 --> Router Class Initialized
INFO - 2016-11-03 06:30:39 --> Output Class Initialized
INFO - 2016-11-03 06:30:39 --> Security Class Initialized
DEBUG - 2016-11-03 06:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:30:39 --> Input Class Initialized
INFO - 2016-11-03 06:30:39 --> Language Class Initialized
INFO - 2016-11-03 06:30:39 --> Language Class Initialized
INFO - 2016-11-03 06:30:39 --> Config Class Initialized
INFO - 2016-11-03 06:30:39 --> Loader Class Initialized
INFO - 2016-11-03 06:30:39 --> Helper loaded: url_helper
INFO - 2016-11-03 06:30:39 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:30:39 --> Controller Class Initialized
DEBUG - 2016-11-03 06:30:39 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:30:39 --> Model Class Initialized
INFO - 2016-11-03 06:30:39 --> Model Class Initialized
ERROR - 2016-11-03 06:30:39 --> Unable to delete cache file for admin/index/do_ajukan_pinjaman
INFO - 2016-11-03 06:30:39 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:39 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:39 --> Final output sent to browser
DEBUG - 2016-11-03 06:30:39 --> Total execution time: 0.7777
INFO - 2016-11-03 06:30:53 --> Config Class Initialized
INFO - 2016-11-03 06:30:54 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:30:54 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:30:54 --> Utf8 Class Initialized
INFO - 2016-11-03 06:30:54 --> URI Class Initialized
INFO - 2016-11-03 06:30:54 --> Router Class Initialized
INFO - 2016-11-03 06:30:54 --> Output Class Initialized
INFO - 2016-11-03 06:30:54 --> Security Class Initialized
DEBUG - 2016-11-03 06:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:30:54 --> Input Class Initialized
INFO - 2016-11-03 06:30:54 --> Language Class Initialized
INFO - 2016-11-03 06:30:54 --> Language Class Initialized
INFO - 2016-11-03 06:30:54 --> Config Class Initialized
INFO - 2016-11-03 06:30:54 --> Loader Class Initialized
INFO - 2016-11-03 06:30:54 --> Helper loaded: url_helper
INFO - 2016-11-03 06:30:54 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:30:54 --> Controller Class Initialized
DEBUG - 2016-11-03 06:30:54 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:30:54 --> Model Class Initialized
INFO - 2016-11-03 06:30:54 --> Model Class Initialized
ERROR - 2016-11-03 06:30:54 --> Unable to delete cache file for admin/index/do_save_jaminan/sertifikat
INFO - 2016-11-03 06:30:54 --> Database Driver Class Initialized
INFO - 2016-11-03 06:30:54 --> Final output sent to browser
DEBUG - 2016-11-03 06:30:54 --> Total execution time: 0.8415
INFO - 2016-11-03 06:31:03 --> Config Class Initialized
INFO - 2016-11-03 06:31:03 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:31:03 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:31:03 --> Utf8 Class Initialized
INFO - 2016-11-03 06:31:03 --> URI Class Initialized
INFO - 2016-11-03 06:31:03 --> Router Class Initialized
INFO - 2016-11-03 06:31:03 --> Output Class Initialized
INFO - 2016-11-03 06:31:03 --> Security Class Initialized
DEBUG - 2016-11-03 06:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:31:03 --> Input Class Initialized
INFO - 2016-11-03 06:31:03 --> Language Class Initialized
INFO - 2016-11-03 06:31:03 --> Language Class Initialized
INFO - 2016-11-03 06:31:03 --> Config Class Initialized
INFO - 2016-11-03 06:31:03 --> Loader Class Initialized
INFO - 2016-11-03 06:31:03 --> Helper loaded: url_helper
INFO - 2016-11-03 06:31:03 --> Database Driver Class Initialized
INFO - 2016-11-03 06:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:31:03 --> Controller Class Initialized
DEBUG - 2016-11-03 06:31:03 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:31:03 --> Model Class Initialized
INFO - 2016-11-03 06:31:03 --> Model Class Initialized
ERROR - 2016-11-03 06:31:03 --> Unable to delete cache file for admin/index/cetakJaminan/0286dd552c9bea9a69ecb3759e7b94777635514b
INFO - 2016-11-03 06:31:03 --> Database Driver Class Initialized
INFO - 2016-11-03 06:31:03 --> Database Driver Class Initialized
DEBUG - 2016-11-03 06:31:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/stjaminan.php
INFO - 2016-11-03 06:31:03 --> Final output sent to browser
DEBUG - 2016-11-03 06:31:04 --> Total execution time: 1.0087
INFO - 2016-11-03 06:31:08 --> Config Class Initialized
INFO - 2016-11-03 06:31:08 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:31:08 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:31:08 --> Utf8 Class Initialized
INFO - 2016-11-03 06:31:09 --> URI Class Initialized
INFO - 2016-11-03 06:31:09 --> Router Class Initialized
INFO - 2016-11-03 06:31:09 --> Output Class Initialized
INFO - 2016-11-03 06:31:09 --> Security Class Initialized
DEBUG - 2016-11-03 06:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:31:09 --> Input Class Initialized
INFO - 2016-11-03 06:31:09 --> Language Class Initialized
INFO - 2016-11-03 06:31:09 --> Language Class Initialized
INFO - 2016-11-03 06:31:09 --> Config Class Initialized
INFO - 2016-11-03 06:31:09 --> Loader Class Initialized
INFO - 2016-11-03 06:31:09 --> Helper loaded: url_helper
INFO - 2016-11-03 06:31:09 --> Database Driver Class Initialized
INFO - 2016-11-03 06:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:31:09 --> Controller Class Initialized
DEBUG - 2016-11-03 06:31:09 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:31:09 --> Model Class Initialized
INFO - 2016-11-03 06:31:09 --> Model Class Initialized
ERROR - 2016-11-03 06:31:09 --> Unable to delete cache file for admin/index/cetak/0286dd552c9bea9a69ecb3759e7b94777635514b
INFO - 2016-11-03 06:31:09 --> Database Driver Class Initialized
INFO - 2016-11-03 06:31:09 --> Database Driver Class Initialized
DEBUG - 2016-11-03 06:31:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/perjanijan.php
INFO - 2016-11-03 06:31:09 --> Final output sent to browser
DEBUG - 2016-11-03 06:31:09 --> Total execution time: 1.1458
INFO - 2016-11-03 06:31:48 --> Config Class Initialized
INFO - 2016-11-03 06:31:48 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:31:49 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:31:49 --> Utf8 Class Initialized
INFO - 2016-11-03 06:31:49 --> URI Class Initialized
INFO - 2016-11-03 06:31:49 --> Router Class Initialized
INFO - 2016-11-03 06:31:49 --> Output Class Initialized
INFO - 2016-11-03 06:31:49 --> Security Class Initialized
DEBUG - 2016-11-03 06:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:31:49 --> Input Class Initialized
INFO - 2016-11-03 06:31:49 --> Language Class Initialized
INFO - 2016-11-03 06:31:49 --> Language Class Initialized
INFO - 2016-11-03 06:31:49 --> Config Class Initialized
INFO - 2016-11-03 06:31:49 --> Loader Class Initialized
INFO - 2016-11-03 06:31:49 --> Helper loaded: url_helper
INFO - 2016-11-03 06:31:49 --> Database Driver Class Initialized
INFO - 2016-11-03 06:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:31:49 --> Controller Class Initialized
DEBUG - 2016-11-03 06:31:49 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:31:49 --> Model Class Initialized
INFO - 2016-11-03 06:31:49 --> Model Class Initialized
ERROR - 2016-11-03 06:31:49 --> Unable to delete cache file for admin/index/cetakJaminan/0286dd552c9bea9a69ecb3759e7b94777635514b
INFO - 2016-11-03 06:31:49 --> Database Driver Class Initialized
INFO - 2016-11-03 06:31:49 --> Database Driver Class Initialized
DEBUG - 2016-11-03 06:31:49 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/stjaminan.php
ERROR - 2016-11-03 06:31:49 --> Severity: Notice --> ob_end_clean(): failed to delete buffer. No buffer to delete E:\SERVER\htdocs\kops\application\modules\admin\controllers\Index.php 1590
ERROR - 2016-11-03 12:31:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\SERVER\htdocs\kops\system\core\Exceptions.php:272) E:\SERVER\htdocs\kops\application\libraries\_tcpdf_5.0.002\tcpdf.php 6122
INFO - 2016-11-03 06:32:16 --> Config Class Initialized
INFO - 2016-11-03 06:32:16 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:32:16 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:32:16 --> Utf8 Class Initialized
INFO - 2016-11-03 06:32:16 --> URI Class Initialized
INFO - 2016-11-03 06:32:16 --> Router Class Initialized
INFO - 2016-11-03 06:32:16 --> Output Class Initialized
INFO - 2016-11-03 06:32:16 --> Security Class Initialized
DEBUG - 2016-11-03 06:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:32:16 --> Input Class Initialized
INFO - 2016-11-03 06:32:16 --> Language Class Initialized
INFO - 2016-11-03 06:32:17 --> Language Class Initialized
INFO - 2016-11-03 06:32:17 --> Config Class Initialized
INFO - 2016-11-03 06:32:17 --> Loader Class Initialized
INFO - 2016-11-03 06:32:17 --> Helper loaded: url_helper
INFO - 2016-11-03 06:32:17 --> Database Driver Class Initialized
INFO - 2016-11-03 06:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:32:17 --> Controller Class Initialized
DEBUG - 2016-11-03 06:32:17 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:32:17 --> Model Class Initialized
INFO - 2016-11-03 06:32:17 --> Model Class Initialized
ERROR - 2016-11-03 06:32:17 --> Unable to delete cache file for admin/index/cetakJaminan/0286dd552c9bea9a69ecb3759e7b94777635514b
INFO - 2016-11-03 06:32:17 --> Database Driver Class Initialized
INFO - 2016-11-03 06:32:17 --> Database Driver Class Initialized
DEBUG - 2016-11-03 06:32:17 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/stjaminan.php
INFO - 2016-11-03 12:32:18 --> Final output sent to browser
DEBUG - 2016-11-03 12:32:18 --> Total execution time: 1.6372
INFO - 2016-11-03 06:32:34 --> Config Class Initialized
INFO - 2016-11-03 06:32:34 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:32:34 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:32:34 --> Utf8 Class Initialized
INFO - 2016-11-03 06:32:34 --> URI Class Initialized
INFO - 2016-11-03 06:32:34 --> Router Class Initialized
INFO - 2016-11-03 06:32:34 --> Output Class Initialized
INFO - 2016-11-03 06:32:34 --> Security Class Initialized
DEBUG - 2016-11-03 06:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:32:34 --> Input Class Initialized
INFO - 2016-11-03 06:32:34 --> Language Class Initialized
INFO - 2016-11-03 06:32:34 --> Language Class Initialized
INFO - 2016-11-03 06:32:35 --> Config Class Initialized
INFO - 2016-11-03 06:32:35 --> Loader Class Initialized
INFO - 2016-11-03 06:32:35 --> Helper loaded: url_helper
INFO - 2016-11-03 06:32:35 --> Database Driver Class Initialized
INFO - 2016-11-03 06:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:32:35 --> Controller Class Initialized
DEBUG - 2016-11-03 06:32:35 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:32:35 --> Model Class Initialized
INFO - 2016-11-03 06:32:35 --> Model Class Initialized
ERROR - 2016-11-03 06:32:35 --> Unable to delete cache file for admin/index/cetakJaminan/0286dd552c9bea9a69ecb3759e7b94777635514b
INFO - 2016-11-03 06:32:35 --> Database Driver Class Initialized
INFO - 2016-11-03 06:32:35 --> Database Driver Class Initialized
DEBUG - 2016-11-03 06:32:35 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/stjaminan.php
INFO - 2016-11-03 12:32:36 --> Final output sent to browser
DEBUG - 2016-11-03 12:32:36 --> Total execution time: 1.9839
INFO - 2016-11-03 06:32:51 --> Config Class Initialized
INFO - 2016-11-03 06:32:51 --> Hooks Class Initialized
DEBUG - 2016-11-03 06:32:51 --> UTF-8 Support Enabled
INFO - 2016-11-03 06:32:51 --> Utf8 Class Initialized
INFO - 2016-11-03 06:32:51 --> URI Class Initialized
INFO - 2016-11-03 06:32:51 --> Router Class Initialized
INFO - 2016-11-03 06:32:51 --> Output Class Initialized
INFO - 2016-11-03 06:32:51 --> Security Class Initialized
DEBUG - 2016-11-03 06:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 06:32:51 --> Input Class Initialized
INFO - 2016-11-03 06:32:51 --> Language Class Initialized
INFO - 2016-11-03 06:32:51 --> Language Class Initialized
INFO - 2016-11-03 06:32:51 --> Config Class Initialized
INFO - 2016-11-03 06:32:52 --> Loader Class Initialized
INFO - 2016-11-03 06:32:52 --> Helper loaded: url_helper
INFO - 2016-11-03 06:32:52 --> Database Driver Class Initialized
INFO - 2016-11-03 06:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 06:32:52 --> Controller Class Initialized
DEBUG - 2016-11-03 06:32:52 --> Index MX_Controller Initialized
INFO - 2016-11-03 06:32:52 --> Model Class Initialized
INFO - 2016-11-03 06:32:52 --> Model Class Initialized
ERROR - 2016-11-03 06:32:52 --> Unable to delete cache file for admin/index/cetakJaminan/0286dd552c9bea9a69ecb3759e7b94777635514b
INFO - 2016-11-03 06:32:52 --> Database Driver Class Initialized
INFO - 2016-11-03 06:32:52 --> Database Driver Class Initialized
DEBUG - 2016-11-03 06:32:52 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/stjaminan.php
INFO - 2016-11-03 12:32:53 --> Final output sent to browser
DEBUG - 2016-11-03 12:32:53 --> Total execution time: 1.9702
