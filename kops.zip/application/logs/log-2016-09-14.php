<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-09-14 00:15:15 --> Config Class Initialized
INFO - 2016-09-14 00:15:15 --> Hooks Class Initialized
DEBUG - 2016-09-14 00:15:16 --> UTF-8 Support Enabled
INFO - 2016-09-14 00:15:16 --> Utf8 Class Initialized
INFO - 2016-09-14 00:15:16 --> URI Class Initialized
INFO - 2016-09-14 00:15:16 --> Router Class Initialized
INFO - 2016-09-14 00:15:16 --> Output Class Initialized
INFO - 2016-09-14 00:15:16 --> Security Class Initialized
DEBUG - 2016-09-14 00:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 00:15:16 --> Input Class Initialized
INFO - 2016-09-14 00:15:16 --> Language Class Initialized
INFO - 2016-09-14 00:15:16 --> Language Class Initialized
INFO - 2016-09-14 00:15:16 --> Config Class Initialized
INFO - 2016-09-14 00:15:17 --> Loader Class Initialized
INFO - 2016-09-14 00:15:17 --> Helper loaded: url_helper
INFO - 2016-09-14 00:15:17 --> Database Driver Class Initialized
INFO - 2016-09-14 00:15:17 --> Controller Class Initialized
DEBUG - 2016-09-14 00:15:17 --> Index MX_Controller Initialized
INFO - 2016-09-14 00:15:17 --> Model Class Initialized
INFO - 2016-09-14 00:15:17 --> Model Class Initialized
DEBUG - 2016-09-14 00:15:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 00:15:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 00:15:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 00:15:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-14 00:15:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 00:15:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 00:15:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 00:15:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 00:15:17 --> Final output sent to browser
DEBUG - 2016-09-14 00:15:18 --> Total execution time: 2.2841
INFO - 2016-09-14 00:15:42 --> Config Class Initialized
INFO - 2016-09-14 00:15:42 --> Hooks Class Initialized
DEBUG - 2016-09-14 00:15:42 --> UTF-8 Support Enabled
INFO - 2016-09-14 00:15:43 --> Utf8 Class Initialized
INFO - 2016-09-14 00:15:43 --> URI Class Initialized
INFO - 2016-09-14 00:15:43 --> Router Class Initialized
INFO - 2016-09-14 00:15:43 --> Output Class Initialized
INFO - 2016-09-14 00:15:43 --> Security Class Initialized
DEBUG - 2016-09-14 00:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 00:15:43 --> Input Class Initialized
INFO - 2016-09-14 00:15:43 --> Language Class Initialized
INFO - 2016-09-14 00:15:43 --> Language Class Initialized
INFO - 2016-09-14 00:15:43 --> Config Class Initialized
INFO - 2016-09-14 00:15:43 --> Loader Class Initialized
INFO - 2016-09-14 00:15:43 --> Helper loaded: url_helper
INFO - 2016-09-14 00:15:43 --> Database Driver Class Initialized
INFO - 2016-09-14 00:15:43 --> Controller Class Initialized
DEBUG - 2016-09-14 00:15:43 --> Index MX_Controller Initialized
INFO - 2016-09-14 00:15:43 --> Model Class Initialized
INFO - 2016-09-14 00:15:43 --> Model Class Initialized
DEBUG - 2016-09-14 00:15:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 00:15:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 00:15:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 00:15:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-14 00:15:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 00:15:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 00:15:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 00:15:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 00:15:43 --> Final output sent to browser
DEBUG - 2016-09-14 00:15:43 --> Total execution time: 0.6828
INFO - 2016-09-14 00:16:13 --> Config Class Initialized
INFO - 2016-09-14 00:16:13 --> Hooks Class Initialized
DEBUG - 2016-09-14 00:16:13 --> UTF-8 Support Enabled
INFO - 2016-09-14 00:16:13 --> Utf8 Class Initialized
INFO - 2016-09-14 00:16:13 --> URI Class Initialized
INFO - 2016-09-14 00:16:13 --> Router Class Initialized
INFO - 2016-09-14 00:16:13 --> Output Class Initialized
INFO - 2016-09-14 00:16:13 --> Security Class Initialized
DEBUG - 2016-09-14 00:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 00:16:13 --> Input Class Initialized
INFO - 2016-09-14 00:16:13 --> Language Class Initialized
INFO - 2016-09-14 00:16:13 --> Language Class Initialized
INFO - 2016-09-14 00:16:13 --> Config Class Initialized
INFO - 2016-09-14 00:16:13 --> Loader Class Initialized
INFO - 2016-09-14 00:16:13 --> Helper loaded: url_helper
INFO - 2016-09-14 00:16:13 --> Database Driver Class Initialized
INFO - 2016-09-14 00:16:13 --> Controller Class Initialized
DEBUG - 2016-09-14 00:16:13 --> Index MX_Controller Initialized
INFO - 2016-09-14 00:16:13 --> Model Class Initialized
INFO - 2016-09-14 00:16:13 --> Model Class Initialized
DEBUG - 2016-09-14 00:16:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 00:16:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 00:16:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 00:16:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-14 00:16:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 00:16:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 00:16:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 00:16:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 00:16:13 --> Final output sent to browser
DEBUG - 2016-09-14 00:16:14 --> Total execution time: 0.4919
INFO - 2016-09-14 00:17:08 --> Config Class Initialized
INFO - 2016-09-14 00:17:08 --> Hooks Class Initialized
DEBUG - 2016-09-14 00:17:08 --> UTF-8 Support Enabled
INFO - 2016-09-14 00:17:08 --> Utf8 Class Initialized
INFO - 2016-09-14 00:17:08 --> URI Class Initialized
INFO - 2016-09-14 00:17:08 --> Router Class Initialized
INFO - 2016-09-14 00:17:08 --> Output Class Initialized
INFO - 2016-09-14 00:17:08 --> Security Class Initialized
DEBUG - 2016-09-14 00:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 00:17:08 --> Input Class Initialized
INFO - 2016-09-14 00:17:08 --> Language Class Initialized
INFO - 2016-09-14 00:17:08 --> Language Class Initialized
INFO - 2016-09-14 00:17:09 --> Config Class Initialized
INFO - 2016-09-14 00:17:09 --> Loader Class Initialized
INFO - 2016-09-14 00:17:09 --> Helper loaded: url_helper
INFO - 2016-09-14 00:17:09 --> Database Driver Class Initialized
INFO - 2016-09-14 00:17:09 --> Controller Class Initialized
DEBUG - 2016-09-14 00:17:09 --> Index MX_Controller Initialized
INFO - 2016-09-14 00:17:09 --> Model Class Initialized
INFO - 2016-09-14 00:17:09 --> Model Class Initialized
DEBUG - 2016-09-14 00:17:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 00:17:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 00:17:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 00:17:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-14 00:17:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 00:17:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 00:17:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 00:17:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 00:17:09 --> Final output sent to browser
DEBUG - 2016-09-14 00:17:09 --> Total execution time: 0.5004
INFO - 2016-09-14 00:18:01 --> Config Class Initialized
INFO - 2016-09-14 00:18:01 --> Hooks Class Initialized
DEBUG - 2016-09-14 00:18:01 --> UTF-8 Support Enabled
INFO - 2016-09-14 00:18:01 --> Utf8 Class Initialized
INFO - 2016-09-14 00:18:01 --> URI Class Initialized
INFO - 2016-09-14 00:18:01 --> Router Class Initialized
INFO - 2016-09-14 00:18:01 --> Output Class Initialized
INFO - 2016-09-14 00:18:01 --> Security Class Initialized
DEBUG - 2016-09-14 00:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 00:18:01 --> Input Class Initialized
INFO - 2016-09-14 00:18:01 --> Language Class Initialized
INFO - 2016-09-14 00:18:01 --> Language Class Initialized
INFO - 2016-09-14 00:18:01 --> Config Class Initialized
INFO - 2016-09-14 00:18:01 --> Loader Class Initialized
INFO - 2016-09-14 00:18:01 --> Helper loaded: url_helper
INFO - 2016-09-14 00:18:01 --> Database Driver Class Initialized
INFO - 2016-09-14 00:18:01 --> Controller Class Initialized
DEBUG - 2016-09-14 00:18:01 --> Index MX_Controller Initialized
INFO - 2016-09-14 00:18:01 --> Model Class Initialized
INFO - 2016-09-14 00:18:01 --> Model Class Initialized
DEBUG - 2016-09-14 00:18:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 00:18:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 00:18:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 00:18:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-14 00:18:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 00:18:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 00:18:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 00:18:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 00:18:01 --> Final output sent to browser
DEBUG - 2016-09-14 00:18:01 --> Total execution time: 0.5373
INFO - 2016-09-14 00:18:32 --> Config Class Initialized
INFO - 2016-09-14 00:18:32 --> Hooks Class Initialized
DEBUG - 2016-09-14 00:18:32 --> UTF-8 Support Enabled
INFO - 2016-09-14 00:18:32 --> Utf8 Class Initialized
INFO - 2016-09-14 00:18:32 --> URI Class Initialized
INFO - 2016-09-14 00:18:32 --> Router Class Initialized
INFO - 2016-09-14 00:18:32 --> Output Class Initialized
INFO - 2016-09-14 00:18:32 --> Security Class Initialized
DEBUG - 2016-09-14 00:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 00:18:32 --> Input Class Initialized
INFO - 2016-09-14 00:18:32 --> Language Class Initialized
INFO - 2016-09-14 00:18:32 --> Language Class Initialized
INFO - 2016-09-14 00:18:32 --> Config Class Initialized
INFO - 2016-09-14 00:18:32 --> Loader Class Initialized
INFO - 2016-09-14 00:18:32 --> Helper loaded: url_helper
INFO - 2016-09-14 00:18:32 --> Database Driver Class Initialized
INFO - 2016-09-14 00:18:32 --> Controller Class Initialized
DEBUG - 2016-09-14 00:18:32 --> Index MX_Controller Initialized
INFO - 2016-09-14 00:18:32 --> Model Class Initialized
INFO - 2016-09-14 00:18:32 --> Model Class Initialized
DEBUG - 2016-09-14 00:18:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 00:18:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 00:18:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 00:18:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-14 00:18:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 00:18:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 00:18:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 00:18:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 00:18:32 --> Final output sent to browser
DEBUG - 2016-09-14 00:18:32 --> Total execution time: 0.5046
INFO - 2016-09-14 00:18:56 --> Config Class Initialized
INFO - 2016-09-14 00:18:56 --> Hooks Class Initialized
DEBUG - 2016-09-14 00:18:56 --> UTF-8 Support Enabled
INFO - 2016-09-14 00:18:56 --> Utf8 Class Initialized
INFO - 2016-09-14 00:18:56 --> URI Class Initialized
INFO - 2016-09-14 00:18:56 --> Router Class Initialized
INFO - 2016-09-14 00:18:56 --> Output Class Initialized
INFO - 2016-09-14 00:18:57 --> Security Class Initialized
DEBUG - 2016-09-14 00:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 00:18:57 --> Input Class Initialized
INFO - 2016-09-14 00:18:57 --> Language Class Initialized
INFO - 2016-09-14 00:18:57 --> Language Class Initialized
INFO - 2016-09-14 00:18:57 --> Config Class Initialized
INFO - 2016-09-14 00:18:57 --> Loader Class Initialized
INFO - 2016-09-14 00:18:57 --> Helper loaded: url_helper
INFO - 2016-09-14 00:18:57 --> Database Driver Class Initialized
INFO - 2016-09-14 00:18:57 --> Controller Class Initialized
DEBUG - 2016-09-14 00:18:57 --> Index MX_Controller Initialized
INFO - 2016-09-14 00:18:57 --> Model Class Initialized
INFO - 2016-09-14 00:18:57 --> Model Class Initialized
DEBUG - 2016-09-14 00:18:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 00:18:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 00:18:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 00:18:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-14 00:18:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 00:18:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 00:18:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 00:18:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 00:18:57 --> Final output sent to browser
DEBUG - 2016-09-14 00:18:57 --> Total execution time: 0.5332
INFO - 2016-09-14 00:26:29 --> Config Class Initialized
INFO - 2016-09-14 00:26:29 --> Hooks Class Initialized
DEBUG - 2016-09-14 00:26:29 --> UTF-8 Support Enabled
INFO - 2016-09-14 00:26:29 --> Utf8 Class Initialized
INFO - 2016-09-14 00:26:29 --> URI Class Initialized
INFO - 2016-09-14 00:26:29 --> Router Class Initialized
INFO - 2016-09-14 00:26:29 --> Output Class Initialized
INFO - 2016-09-14 00:26:29 --> Security Class Initialized
DEBUG - 2016-09-14 00:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 00:26:29 --> Input Class Initialized
INFO - 2016-09-14 00:26:29 --> Language Class Initialized
INFO - 2016-09-14 00:26:29 --> Language Class Initialized
INFO - 2016-09-14 00:26:29 --> Config Class Initialized
INFO - 2016-09-14 00:26:29 --> Loader Class Initialized
INFO - 2016-09-14 00:26:29 --> Helper loaded: url_helper
INFO - 2016-09-14 00:26:30 --> Database Driver Class Initialized
INFO - 2016-09-14 00:26:30 --> Controller Class Initialized
DEBUG - 2016-09-14 00:26:30 --> Index MX_Controller Initialized
INFO - 2016-09-14 00:26:30 --> Model Class Initialized
INFO - 2016-09-14 00:26:30 --> Model Class Initialized
DEBUG - 2016-09-14 00:26:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 00:26:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 00:26:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 00:26:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-14 00:26:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 00:26:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 00:26:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 00:26:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 00:26:30 --> Final output sent to browser
DEBUG - 2016-09-14 00:26:30 --> Total execution time: 0.8110
INFO - 2016-09-14 00:26:46 --> Config Class Initialized
INFO - 2016-09-14 00:26:46 --> Hooks Class Initialized
DEBUG - 2016-09-14 00:26:46 --> UTF-8 Support Enabled
INFO - 2016-09-14 00:26:46 --> Utf8 Class Initialized
INFO - 2016-09-14 00:26:46 --> URI Class Initialized
INFO - 2016-09-14 00:26:46 --> Router Class Initialized
INFO - 2016-09-14 00:26:46 --> Output Class Initialized
INFO - 2016-09-14 00:26:46 --> Security Class Initialized
DEBUG - 2016-09-14 00:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 00:26:46 --> Input Class Initialized
INFO - 2016-09-14 00:26:46 --> Language Class Initialized
INFO - 2016-09-14 00:26:46 --> Language Class Initialized
INFO - 2016-09-14 00:26:46 --> Config Class Initialized
INFO - 2016-09-14 00:26:46 --> Loader Class Initialized
INFO - 2016-09-14 00:26:46 --> Helper loaded: url_helper
INFO - 2016-09-14 00:26:46 --> Database Driver Class Initialized
INFO - 2016-09-14 00:26:46 --> Controller Class Initialized
DEBUG - 2016-09-14 00:26:46 --> Index MX_Controller Initialized
INFO - 2016-09-14 00:26:46 --> Model Class Initialized
INFO - 2016-09-14 00:26:46 --> Model Class Initialized
DEBUG - 2016-09-14 00:26:46 --> Anggota MX_Controller Initialized
ERROR - 2016-09-14 00:26:47 --> Severity: Notice --> Undefined property: CI::$table E:\SERVER\htdocs\koperasiweda\application\third_party\MX\Controller.php 59
ERROR - 2016-09-14 00:26:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'WHERE `no_identitas` = '3573032002930011'' at line 2 - Invalid query: SELECT *
WHERE `no_identitas` = '3573032002930011'
INFO - 2016-09-14 00:26:47 --> Language file loaded: language/english/db_lang.php
INFO - 2016-09-14 00:27:01 --> Config Class Initialized
INFO - 2016-09-14 00:27:01 --> Hooks Class Initialized
DEBUG - 2016-09-14 00:27:01 --> UTF-8 Support Enabled
INFO - 2016-09-14 00:27:01 --> Utf8 Class Initialized
INFO - 2016-09-14 00:27:01 --> URI Class Initialized
INFO - 2016-09-14 00:27:01 --> Router Class Initialized
INFO - 2016-09-14 00:27:01 --> Output Class Initialized
INFO - 2016-09-14 00:27:01 --> Security Class Initialized
DEBUG - 2016-09-14 00:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 00:27:01 --> Input Class Initialized
INFO - 2016-09-14 00:27:01 --> Language Class Initialized
INFO - 2016-09-14 00:27:01 --> Language Class Initialized
INFO - 2016-09-14 00:27:01 --> Config Class Initialized
INFO - 2016-09-14 00:27:01 --> Loader Class Initialized
INFO - 2016-09-14 00:27:01 --> Helper loaded: url_helper
INFO - 2016-09-14 00:27:01 --> Database Driver Class Initialized
INFO - 2016-09-14 00:27:01 --> Controller Class Initialized
DEBUG - 2016-09-14 00:27:01 --> Index MX_Controller Initialized
INFO - 2016-09-14 00:27:01 --> Model Class Initialized
INFO - 2016-09-14 00:27:01 --> Model Class Initialized
DEBUG - 2016-09-14 00:27:01 --> Anggota MX_Controller Initialized
ERROR - 2016-09-14 00:27:01 --> Severity: Notice --> Undefined property: CI::$table E:\SERVER\htdocs\koperasiweda\application\third_party\MX\Controller.php 59
ERROR - 2016-09-14 00:27:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'WHERE `no_identitas` = '3573032002930011'' at line 2 - Invalid query: SELECT *
WHERE `no_identitas` = '3573032002930011'
INFO - 2016-09-14 00:27:01 --> Language file loaded: language/english/db_lang.php
INFO - 2016-09-14 00:27:49 --> Config Class Initialized
INFO - 2016-09-14 00:27:49 --> Hooks Class Initialized
DEBUG - 2016-09-14 00:27:49 --> UTF-8 Support Enabled
INFO - 2016-09-14 00:27:49 --> Utf8 Class Initialized
INFO - 2016-09-14 00:27:49 --> URI Class Initialized
INFO - 2016-09-14 00:27:49 --> Router Class Initialized
INFO - 2016-09-14 00:27:49 --> Output Class Initialized
INFO - 2016-09-14 00:27:50 --> Security Class Initialized
DEBUG - 2016-09-14 00:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 00:27:50 --> Input Class Initialized
INFO - 2016-09-14 00:27:50 --> Language Class Initialized
INFO - 2016-09-14 00:27:50 --> Language Class Initialized
INFO - 2016-09-14 00:27:50 --> Config Class Initialized
INFO - 2016-09-14 00:27:50 --> Loader Class Initialized
INFO - 2016-09-14 00:27:50 --> Helper loaded: url_helper
INFO - 2016-09-14 00:27:50 --> Database Driver Class Initialized
INFO - 2016-09-14 00:27:50 --> Controller Class Initialized
DEBUG - 2016-09-14 00:27:50 --> Index MX_Controller Initialized
INFO - 2016-09-14 00:27:50 --> Model Class Initialized
INFO - 2016-09-14 00:27:50 --> Model Class Initialized
DEBUG - 2016-09-14 00:27:50 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 00:27:50 --> Final output sent to browser
DEBUG - 2016-09-14 00:27:50 --> Total execution time: 0.6843
INFO - 2016-09-14 00:31:50 --> Config Class Initialized
INFO - 2016-09-14 00:31:50 --> Hooks Class Initialized
DEBUG - 2016-09-14 00:31:50 --> UTF-8 Support Enabled
INFO - 2016-09-14 00:31:50 --> Utf8 Class Initialized
INFO - 2016-09-14 00:31:50 --> URI Class Initialized
INFO - 2016-09-14 00:31:50 --> Router Class Initialized
INFO - 2016-09-14 00:31:50 --> Output Class Initialized
INFO - 2016-09-14 00:31:50 --> Security Class Initialized
DEBUG - 2016-09-14 00:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 00:31:50 --> Input Class Initialized
INFO - 2016-09-14 00:31:50 --> Language Class Initialized
INFO - 2016-09-14 00:31:50 --> Language Class Initialized
INFO - 2016-09-14 00:31:50 --> Config Class Initialized
INFO - 2016-09-14 00:31:50 --> Loader Class Initialized
INFO - 2016-09-14 00:31:50 --> Helper loaded: url_helper
INFO - 2016-09-14 00:31:50 --> Database Driver Class Initialized
INFO - 2016-09-14 00:31:50 --> Controller Class Initialized
DEBUG - 2016-09-14 00:31:50 --> Index MX_Controller Initialized
INFO - 2016-09-14 00:31:50 --> Model Class Initialized
INFO - 2016-09-14 00:31:50 --> Model Class Initialized
DEBUG - 2016-09-14 00:31:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 00:31:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 00:31:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 00:31:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-14 00:31:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 00:31:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 00:31:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 00:31:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 00:31:50 --> Final output sent to browser
DEBUG - 2016-09-14 00:31:50 --> Total execution time: 0.5453
INFO - 2016-09-14 00:31:55 --> Config Class Initialized
INFO - 2016-09-14 00:31:55 --> Hooks Class Initialized
DEBUG - 2016-09-14 00:31:55 --> UTF-8 Support Enabled
INFO - 2016-09-14 00:31:55 --> Utf8 Class Initialized
INFO - 2016-09-14 00:31:55 --> URI Class Initialized
INFO - 2016-09-14 00:31:55 --> Router Class Initialized
INFO - 2016-09-14 00:31:55 --> Output Class Initialized
INFO - 2016-09-14 00:31:55 --> Security Class Initialized
DEBUG - 2016-09-14 00:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 00:31:55 --> Input Class Initialized
INFO - 2016-09-14 00:31:55 --> Language Class Initialized
INFO - 2016-09-14 00:31:55 --> Language Class Initialized
INFO - 2016-09-14 00:31:55 --> Config Class Initialized
INFO - 2016-09-14 00:31:55 --> Loader Class Initialized
INFO - 2016-09-14 00:31:55 --> Helper loaded: url_helper
INFO - 2016-09-14 00:31:55 --> Database Driver Class Initialized
INFO - 2016-09-14 00:31:55 --> Controller Class Initialized
DEBUG - 2016-09-14 00:31:55 --> Index MX_Controller Initialized
INFO - 2016-09-14 00:31:55 --> Model Class Initialized
INFO - 2016-09-14 00:31:55 --> Model Class Initialized
DEBUG - 2016-09-14 00:31:55 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 00:31:55 --> Final output sent to browser
DEBUG - 2016-09-14 00:31:55 --> Total execution time: 0.4861
INFO - 2016-09-14 00:33:46 --> Config Class Initialized
INFO - 2016-09-14 00:33:46 --> Hooks Class Initialized
DEBUG - 2016-09-14 00:33:46 --> UTF-8 Support Enabled
INFO - 2016-09-14 00:33:46 --> Utf8 Class Initialized
INFO - 2016-09-14 00:33:46 --> URI Class Initialized
INFO - 2016-09-14 00:33:46 --> Router Class Initialized
INFO - 2016-09-14 00:33:46 --> Output Class Initialized
INFO - 2016-09-14 00:33:46 --> Security Class Initialized
DEBUG - 2016-09-14 00:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 00:33:47 --> Input Class Initialized
INFO - 2016-09-14 00:33:47 --> Language Class Initialized
INFO - 2016-09-14 00:33:47 --> Language Class Initialized
INFO - 2016-09-14 00:33:47 --> Config Class Initialized
INFO - 2016-09-14 00:33:47 --> Loader Class Initialized
INFO - 2016-09-14 00:33:47 --> Helper loaded: url_helper
INFO - 2016-09-14 00:33:47 --> Database Driver Class Initialized
INFO - 2016-09-14 00:33:47 --> Controller Class Initialized
DEBUG - 2016-09-14 00:33:47 --> Index MX_Controller Initialized
INFO - 2016-09-14 00:33:47 --> Model Class Initialized
INFO - 2016-09-14 00:33:47 --> Model Class Initialized
DEBUG - 2016-09-14 00:33:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 00:33:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 00:33:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 00:33:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-14 00:33:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 00:33:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 00:33:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 00:33:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 00:33:47 --> Final output sent to browser
DEBUG - 2016-09-14 00:33:47 --> Total execution time: 0.6436
INFO - 2016-09-14 00:33:52 --> Config Class Initialized
INFO - 2016-09-14 00:33:52 --> Hooks Class Initialized
DEBUG - 2016-09-14 00:33:52 --> UTF-8 Support Enabled
INFO - 2016-09-14 00:33:52 --> Utf8 Class Initialized
INFO - 2016-09-14 00:33:52 --> URI Class Initialized
INFO - 2016-09-14 00:33:52 --> Router Class Initialized
INFO - 2016-09-14 00:33:52 --> Output Class Initialized
INFO - 2016-09-14 00:33:52 --> Security Class Initialized
DEBUG - 2016-09-14 00:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 00:33:52 --> Input Class Initialized
INFO - 2016-09-14 00:33:52 --> Language Class Initialized
INFO - 2016-09-14 00:33:52 --> Language Class Initialized
INFO - 2016-09-14 00:33:52 --> Config Class Initialized
INFO - 2016-09-14 00:33:52 --> Loader Class Initialized
INFO - 2016-09-14 00:33:52 --> Helper loaded: url_helper
INFO - 2016-09-14 00:33:52 --> Database Driver Class Initialized
INFO - 2016-09-14 00:33:52 --> Controller Class Initialized
DEBUG - 2016-09-14 00:33:52 --> Index MX_Controller Initialized
INFO - 2016-09-14 00:33:52 --> Model Class Initialized
INFO - 2016-09-14 00:33:52 --> Model Class Initialized
DEBUG - 2016-09-14 00:33:52 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 00:33:52 --> Final output sent to browser
DEBUG - 2016-09-14 00:33:52 --> Total execution time: 0.4223
INFO - 2016-09-14 00:33:58 --> Config Class Initialized
INFO - 2016-09-14 00:33:58 --> Hooks Class Initialized
DEBUG - 2016-09-14 00:33:58 --> UTF-8 Support Enabled
INFO - 2016-09-14 00:33:58 --> Utf8 Class Initialized
INFO - 2016-09-14 00:33:58 --> URI Class Initialized
INFO - 2016-09-14 00:33:58 --> Router Class Initialized
INFO - 2016-09-14 00:33:58 --> Output Class Initialized
INFO - 2016-09-14 00:33:58 --> Security Class Initialized
DEBUG - 2016-09-14 00:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 00:33:58 --> Input Class Initialized
INFO - 2016-09-14 00:33:58 --> Language Class Initialized
INFO - 2016-09-14 00:33:59 --> Language Class Initialized
INFO - 2016-09-14 00:33:59 --> Config Class Initialized
INFO - 2016-09-14 00:33:59 --> Loader Class Initialized
INFO - 2016-09-14 00:33:59 --> Helper loaded: url_helper
INFO - 2016-09-14 00:33:59 --> Database Driver Class Initialized
INFO - 2016-09-14 00:33:59 --> Controller Class Initialized
DEBUG - 2016-09-14 00:33:59 --> Index MX_Controller Initialized
INFO - 2016-09-14 00:33:59 --> Model Class Initialized
INFO - 2016-09-14 00:33:59 --> Model Class Initialized
DEBUG - 2016-09-14 00:33:59 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 00:33:59 --> Final output sent to browser
DEBUG - 2016-09-14 00:33:59 --> Total execution time: 0.5310
INFO - 2016-09-14 00:34:14 --> Config Class Initialized
INFO - 2016-09-14 00:34:14 --> Hooks Class Initialized
DEBUG - 2016-09-14 00:34:14 --> UTF-8 Support Enabled
INFO - 2016-09-14 00:34:14 --> Utf8 Class Initialized
INFO - 2016-09-14 00:34:14 --> URI Class Initialized
INFO - 2016-09-14 00:34:14 --> Router Class Initialized
INFO - 2016-09-14 00:34:14 --> Output Class Initialized
INFO - 2016-09-14 00:34:14 --> Security Class Initialized
DEBUG - 2016-09-14 00:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 00:34:14 --> Input Class Initialized
INFO - 2016-09-14 00:34:14 --> Language Class Initialized
INFO - 2016-09-14 00:34:14 --> Language Class Initialized
INFO - 2016-09-14 00:34:14 --> Config Class Initialized
INFO - 2016-09-14 00:34:14 --> Loader Class Initialized
INFO - 2016-09-14 00:34:14 --> Helper loaded: url_helper
INFO - 2016-09-14 00:34:14 --> Database Driver Class Initialized
INFO - 2016-09-14 00:34:14 --> Controller Class Initialized
DEBUG - 2016-09-14 00:34:14 --> Index MX_Controller Initialized
INFO - 2016-09-14 00:34:14 --> Model Class Initialized
INFO - 2016-09-14 00:34:14 --> Model Class Initialized
DEBUG - 2016-09-14 00:34:14 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 00:34:14 --> Final output sent to browser
DEBUG - 2016-09-14 00:34:14 --> Total execution time: 0.4723
INFO - 2016-09-14 00:34:20 --> Config Class Initialized
INFO - 2016-09-14 00:34:20 --> Hooks Class Initialized
DEBUG - 2016-09-14 00:34:20 --> UTF-8 Support Enabled
INFO - 2016-09-14 00:34:20 --> Utf8 Class Initialized
INFO - 2016-09-14 00:34:20 --> URI Class Initialized
INFO - 2016-09-14 00:34:20 --> Router Class Initialized
INFO - 2016-09-14 00:34:20 --> Output Class Initialized
INFO - 2016-09-14 00:34:20 --> Security Class Initialized
DEBUG - 2016-09-14 00:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 00:34:20 --> Input Class Initialized
INFO - 2016-09-14 00:34:20 --> Language Class Initialized
INFO - 2016-09-14 00:34:20 --> Language Class Initialized
INFO - 2016-09-14 00:34:20 --> Config Class Initialized
INFO - 2016-09-14 00:34:20 --> Loader Class Initialized
INFO - 2016-09-14 00:34:21 --> Helper loaded: url_helper
INFO - 2016-09-14 00:34:21 --> Database Driver Class Initialized
INFO - 2016-09-14 00:34:21 --> Controller Class Initialized
DEBUG - 2016-09-14 00:34:21 --> Index MX_Controller Initialized
INFO - 2016-09-14 00:34:21 --> Model Class Initialized
INFO - 2016-09-14 00:34:21 --> Model Class Initialized
DEBUG - 2016-09-14 00:34:21 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 00:34:21 --> Final output sent to browser
DEBUG - 2016-09-14 00:34:21 --> Total execution time: 0.4828
INFO - 2016-09-14 00:34:26 --> Config Class Initialized
INFO - 2016-09-14 00:34:27 --> Hooks Class Initialized
DEBUG - 2016-09-14 00:34:27 --> UTF-8 Support Enabled
INFO - 2016-09-14 00:34:27 --> Utf8 Class Initialized
INFO - 2016-09-14 00:34:27 --> URI Class Initialized
INFO - 2016-09-14 00:34:27 --> Router Class Initialized
INFO - 2016-09-14 00:34:27 --> Output Class Initialized
INFO - 2016-09-14 00:34:27 --> Security Class Initialized
DEBUG - 2016-09-14 00:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 00:34:27 --> Input Class Initialized
INFO - 2016-09-14 00:34:27 --> Language Class Initialized
INFO - 2016-09-14 00:34:27 --> Language Class Initialized
INFO - 2016-09-14 00:34:27 --> Config Class Initialized
INFO - 2016-09-14 00:34:27 --> Loader Class Initialized
INFO - 2016-09-14 00:34:27 --> Helper loaded: url_helper
INFO - 2016-09-14 00:34:27 --> Database Driver Class Initialized
INFO - 2016-09-14 00:34:27 --> Controller Class Initialized
DEBUG - 2016-09-14 00:34:27 --> Index MX_Controller Initialized
INFO - 2016-09-14 00:34:27 --> Model Class Initialized
INFO - 2016-09-14 00:34:27 --> Model Class Initialized
DEBUG - 2016-09-14 00:34:27 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 00:34:27 --> Final output sent to browser
DEBUG - 2016-09-14 00:34:27 --> Total execution time: 0.5615
INFO - 2016-09-14 00:36:06 --> Config Class Initialized
INFO - 2016-09-14 00:36:06 --> Hooks Class Initialized
DEBUG - 2016-09-14 00:36:06 --> UTF-8 Support Enabled
INFO - 2016-09-14 00:36:06 --> Utf8 Class Initialized
INFO - 2016-09-14 00:36:06 --> URI Class Initialized
INFO - 2016-09-14 00:36:06 --> Router Class Initialized
INFO - 2016-09-14 00:36:06 --> Output Class Initialized
INFO - 2016-09-14 00:36:06 --> Security Class Initialized
DEBUG - 2016-09-14 00:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 00:36:06 --> Input Class Initialized
INFO - 2016-09-14 00:36:06 --> Language Class Initialized
INFO - 2016-09-14 00:36:06 --> Language Class Initialized
INFO - 2016-09-14 00:36:06 --> Config Class Initialized
INFO - 2016-09-14 00:36:06 --> Loader Class Initialized
INFO - 2016-09-14 00:36:06 --> Helper loaded: url_helper
INFO - 2016-09-14 00:36:06 --> Database Driver Class Initialized
INFO - 2016-09-14 00:36:06 --> Controller Class Initialized
DEBUG - 2016-09-14 00:36:06 --> Index MX_Controller Initialized
INFO - 2016-09-14 00:36:06 --> Model Class Initialized
INFO - 2016-09-14 00:36:06 --> Model Class Initialized
DEBUG - 2016-09-14 00:36:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 00:36:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 00:36:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 00:36:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-14 00:36:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 00:36:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 00:36:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 00:36:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 00:36:07 --> Final output sent to browser
DEBUG - 2016-09-14 00:36:07 --> Total execution time: 0.5719
INFO - 2016-09-14 00:52:26 --> Config Class Initialized
INFO - 2016-09-14 00:52:26 --> Hooks Class Initialized
DEBUG - 2016-09-14 00:52:26 --> UTF-8 Support Enabled
INFO - 2016-09-14 00:52:26 --> Utf8 Class Initialized
INFO - 2016-09-14 00:52:26 --> URI Class Initialized
INFO - 2016-09-14 00:52:26 --> Router Class Initialized
INFO - 2016-09-14 00:52:26 --> Output Class Initialized
INFO - 2016-09-14 00:52:26 --> Security Class Initialized
DEBUG - 2016-09-14 00:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 00:52:26 --> Input Class Initialized
INFO - 2016-09-14 00:52:26 --> Language Class Initialized
ERROR - 2016-09-14 00:52:26 --> Severity: Parsing Error --> syntax error, unexpected '>' E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 140
INFO - 2016-09-14 00:52:41 --> Config Class Initialized
INFO - 2016-09-14 00:52:41 --> Hooks Class Initialized
DEBUG - 2016-09-14 00:52:41 --> UTF-8 Support Enabled
INFO - 2016-09-14 00:52:41 --> Utf8 Class Initialized
INFO - 2016-09-14 00:52:41 --> URI Class Initialized
INFO - 2016-09-14 00:52:41 --> Router Class Initialized
INFO - 2016-09-14 00:52:42 --> Output Class Initialized
INFO - 2016-09-14 00:52:42 --> Security Class Initialized
DEBUG - 2016-09-14 00:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 00:52:42 --> Input Class Initialized
INFO - 2016-09-14 00:52:42 --> Language Class Initialized
ERROR - 2016-09-14 00:52:42 --> Severity: Parsing Error --> syntax error, unexpected '>' E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 140
INFO - 2016-09-14 00:53:08 --> Config Class Initialized
INFO - 2016-09-14 00:53:08 --> Hooks Class Initialized
DEBUG - 2016-09-14 00:53:08 --> UTF-8 Support Enabled
INFO - 2016-09-14 00:53:08 --> Utf8 Class Initialized
INFO - 2016-09-14 00:53:08 --> URI Class Initialized
INFO - 2016-09-14 00:53:08 --> Router Class Initialized
INFO - 2016-09-14 00:53:08 --> Output Class Initialized
INFO - 2016-09-14 00:53:08 --> Security Class Initialized
DEBUG - 2016-09-14 00:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 00:53:08 --> Input Class Initialized
INFO - 2016-09-14 00:53:08 --> Language Class Initialized
INFO - 2016-09-14 00:53:08 --> Language Class Initialized
INFO - 2016-09-14 00:53:08 --> Config Class Initialized
INFO - 2016-09-14 00:53:08 --> Loader Class Initialized
INFO - 2016-09-14 00:53:08 --> Helper loaded: url_helper
INFO - 2016-09-14 00:53:08 --> Database Driver Class Initialized
INFO - 2016-09-14 00:53:08 --> Controller Class Initialized
DEBUG - 2016-09-14 00:53:09 --> Index MX_Controller Initialized
INFO - 2016-09-14 00:53:09 --> Model Class Initialized
INFO - 2016-09-14 00:53:09 --> Model Class Initialized
DEBUG - 2016-09-14 00:53:09 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 00:53:09 --> Database Driver Class Initialized
ERROR - 2016-09-14 00:53:09 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 149
ERROR - 2016-09-14 00:53:09 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 149
INFO - 2016-09-14 00:53:09 --> Final output sent to browser
DEBUG - 2016-09-14 00:53:09 --> Total execution time: 0.5947
INFO - 2016-09-14 00:54:31 --> Config Class Initialized
INFO - 2016-09-14 00:54:31 --> Hooks Class Initialized
DEBUG - 2016-09-14 00:54:31 --> UTF-8 Support Enabled
INFO - 2016-09-14 00:54:31 --> Utf8 Class Initialized
INFO - 2016-09-14 00:54:31 --> URI Class Initialized
INFO - 2016-09-14 00:54:31 --> Router Class Initialized
INFO - 2016-09-14 00:54:31 --> Output Class Initialized
INFO - 2016-09-14 00:54:31 --> Security Class Initialized
DEBUG - 2016-09-14 00:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 00:54:31 --> Input Class Initialized
INFO - 2016-09-14 00:54:31 --> Language Class Initialized
INFO - 2016-09-14 00:54:31 --> Language Class Initialized
INFO - 2016-09-14 00:54:31 --> Config Class Initialized
INFO - 2016-09-14 00:54:31 --> Loader Class Initialized
INFO - 2016-09-14 00:54:31 --> Helper loaded: url_helper
INFO - 2016-09-14 00:54:31 --> Database Driver Class Initialized
INFO - 2016-09-14 00:54:31 --> Controller Class Initialized
DEBUG - 2016-09-14 00:54:31 --> Index MX_Controller Initialized
INFO - 2016-09-14 00:54:31 --> Model Class Initialized
INFO - 2016-09-14 00:54:31 --> Model Class Initialized
DEBUG - 2016-09-14 00:54:31 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 00:54:32 --> Database Driver Class Initialized
ERROR - 2016-09-14 00:54:32 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 149
ERROR - 2016-09-14 00:54:32 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 149
INFO - 2016-09-14 00:54:32 --> Final output sent to browser
DEBUG - 2016-09-14 00:54:32 --> Total execution time: 0.6135
INFO - 2016-09-14 00:55:28 --> Config Class Initialized
INFO - 2016-09-14 00:55:28 --> Hooks Class Initialized
DEBUG - 2016-09-14 00:55:28 --> UTF-8 Support Enabled
INFO - 2016-09-14 00:55:28 --> Utf8 Class Initialized
INFO - 2016-09-14 00:55:29 --> URI Class Initialized
INFO - 2016-09-14 00:55:29 --> Router Class Initialized
INFO - 2016-09-14 00:55:29 --> Output Class Initialized
INFO - 2016-09-14 00:55:29 --> Security Class Initialized
DEBUG - 2016-09-14 00:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 00:55:29 --> Input Class Initialized
INFO - 2016-09-14 00:55:29 --> Language Class Initialized
INFO - 2016-09-14 00:55:29 --> Language Class Initialized
INFO - 2016-09-14 00:55:29 --> Config Class Initialized
INFO - 2016-09-14 00:55:29 --> Loader Class Initialized
INFO - 2016-09-14 00:55:29 --> Helper loaded: url_helper
INFO - 2016-09-14 00:55:29 --> Database Driver Class Initialized
INFO - 2016-09-14 00:55:29 --> Controller Class Initialized
DEBUG - 2016-09-14 00:55:29 --> Index MX_Controller Initialized
INFO - 2016-09-14 00:55:29 --> Model Class Initialized
INFO - 2016-09-14 00:55:29 --> Model Class Initialized
DEBUG - 2016-09-14 00:55:29 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 00:55:29 --> Database Driver Class Initialized
ERROR - 2016-09-14 00:55:29 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 149
ERROR - 2016-09-14 00:55:29 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 149
INFO - 2016-09-14 00:55:29 --> Final output sent to browser
DEBUG - 2016-09-14 00:55:29 --> Total execution time: 0.6590
INFO - 2016-09-14 00:58:07 --> Config Class Initialized
INFO - 2016-09-14 00:58:07 --> Hooks Class Initialized
DEBUG - 2016-09-14 00:58:07 --> UTF-8 Support Enabled
INFO - 2016-09-14 00:58:07 --> Utf8 Class Initialized
INFO - 2016-09-14 00:58:07 --> URI Class Initialized
INFO - 2016-09-14 00:58:07 --> Router Class Initialized
INFO - 2016-09-14 00:58:07 --> Output Class Initialized
INFO - 2016-09-14 00:58:07 --> Security Class Initialized
DEBUG - 2016-09-14 00:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 00:58:07 --> Input Class Initialized
INFO - 2016-09-14 00:58:07 --> Language Class Initialized
INFO - 2016-09-14 00:58:07 --> Language Class Initialized
INFO - 2016-09-14 00:58:07 --> Config Class Initialized
INFO - 2016-09-14 00:58:08 --> Loader Class Initialized
INFO - 2016-09-14 00:58:08 --> Helper loaded: url_helper
INFO - 2016-09-14 00:58:08 --> Database Driver Class Initialized
INFO - 2016-09-14 00:58:08 --> Controller Class Initialized
DEBUG - 2016-09-14 00:58:08 --> Index MX_Controller Initialized
INFO - 2016-09-14 00:58:08 --> Model Class Initialized
INFO - 2016-09-14 00:58:08 --> Model Class Initialized
DEBUG - 2016-09-14 00:58:08 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 00:58:08 --> Database Driver Class Initialized
INFO - 2016-09-14 00:58:08 --> Final output sent to browser
DEBUG - 2016-09-14 00:58:08 --> Total execution time: 0.6085
INFO - 2016-09-14 01:04:21 --> Config Class Initialized
INFO - 2016-09-14 01:04:21 --> Hooks Class Initialized
DEBUG - 2016-09-14 01:04:21 --> UTF-8 Support Enabled
INFO - 2016-09-14 01:04:21 --> Utf8 Class Initialized
INFO - 2016-09-14 01:04:21 --> URI Class Initialized
INFO - 2016-09-14 01:04:21 --> Router Class Initialized
INFO - 2016-09-14 01:04:21 --> Output Class Initialized
INFO - 2016-09-14 01:04:22 --> Security Class Initialized
DEBUG - 2016-09-14 01:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 01:04:22 --> Input Class Initialized
INFO - 2016-09-14 01:04:22 --> Language Class Initialized
INFO - 2016-09-14 01:04:22 --> Language Class Initialized
INFO - 2016-09-14 01:04:22 --> Config Class Initialized
INFO - 2016-09-14 01:04:22 --> Loader Class Initialized
INFO - 2016-09-14 01:04:22 --> Helper loaded: url_helper
INFO - 2016-09-14 01:04:22 --> Database Driver Class Initialized
INFO - 2016-09-14 01:04:22 --> Controller Class Initialized
DEBUG - 2016-09-14 01:04:22 --> Index MX_Controller Initialized
INFO - 2016-09-14 01:04:22 --> Model Class Initialized
INFO - 2016-09-14 01:04:22 --> Model Class Initialized
DEBUG - 2016-09-14 01:04:22 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 01:04:22 --> Database Driver Class Initialized
INFO - 2016-09-14 01:04:22 --> Final output sent to browser
DEBUG - 2016-09-14 01:04:22 --> Total execution time: 0.6863
INFO - 2016-09-14 01:04:56 --> Config Class Initialized
INFO - 2016-09-14 01:04:56 --> Hooks Class Initialized
DEBUG - 2016-09-14 01:04:56 --> UTF-8 Support Enabled
INFO - 2016-09-14 01:04:56 --> Utf8 Class Initialized
INFO - 2016-09-14 01:04:56 --> URI Class Initialized
INFO - 2016-09-14 01:04:56 --> Router Class Initialized
INFO - 2016-09-14 01:04:56 --> Output Class Initialized
INFO - 2016-09-14 01:04:56 --> Security Class Initialized
DEBUG - 2016-09-14 01:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 01:04:56 --> Input Class Initialized
INFO - 2016-09-14 01:04:56 --> Language Class Initialized
INFO - 2016-09-14 01:04:56 --> Language Class Initialized
INFO - 2016-09-14 01:04:56 --> Config Class Initialized
INFO - 2016-09-14 01:04:56 --> Loader Class Initialized
INFO - 2016-09-14 01:04:56 --> Helper loaded: url_helper
INFO - 2016-09-14 01:04:56 --> Database Driver Class Initialized
INFO - 2016-09-14 01:04:56 --> Controller Class Initialized
DEBUG - 2016-09-14 01:04:56 --> Index MX_Controller Initialized
INFO - 2016-09-14 01:04:56 --> Model Class Initialized
INFO - 2016-09-14 01:04:56 --> Model Class Initialized
DEBUG - 2016-09-14 01:04:56 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 01:04:56 --> Database Driver Class Initialized
INFO - 2016-09-14 01:04:56 --> Final output sent to browser
DEBUG - 2016-09-14 01:04:56 --> Total execution time: 0.5833
INFO - 2016-09-14 01:05:00 --> Config Class Initialized
INFO - 2016-09-14 01:05:00 --> Hooks Class Initialized
DEBUG - 2016-09-14 01:05:00 --> UTF-8 Support Enabled
INFO - 2016-09-14 01:05:00 --> Utf8 Class Initialized
INFO - 2016-09-14 01:05:00 --> URI Class Initialized
INFO - 2016-09-14 01:05:00 --> Router Class Initialized
INFO - 2016-09-14 01:05:00 --> Output Class Initialized
INFO - 2016-09-14 01:05:00 --> Security Class Initialized
DEBUG - 2016-09-14 01:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 01:05:00 --> Input Class Initialized
INFO - 2016-09-14 01:05:00 --> Language Class Initialized
INFO - 2016-09-14 01:05:00 --> Language Class Initialized
INFO - 2016-09-14 01:05:01 --> Config Class Initialized
INFO - 2016-09-14 01:05:01 --> Loader Class Initialized
INFO - 2016-09-14 01:05:01 --> Helper loaded: url_helper
INFO - 2016-09-14 01:05:01 --> Database Driver Class Initialized
INFO - 2016-09-14 01:05:01 --> Controller Class Initialized
DEBUG - 2016-09-14 01:05:01 --> Index MX_Controller Initialized
INFO - 2016-09-14 01:05:01 --> Model Class Initialized
INFO - 2016-09-14 01:05:01 --> Model Class Initialized
DEBUG - 2016-09-14 01:05:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 01:05:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 01:05:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 01:05:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-14 01:05:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 01:05:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 01:05:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 01:05:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 01:05:01 --> Final output sent to browser
DEBUG - 2016-09-14 01:05:01 --> Total execution time: 0.6981
INFO - 2016-09-14 01:05:11 --> Config Class Initialized
INFO - 2016-09-14 01:05:11 --> Hooks Class Initialized
DEBUG - 2016-09-14 01:05:11 --> UTF-8 Support Enabled
INFO - 2016-09-14 01:05:11 --> Utf8 Class Initialized
INFO - 2016-09-14 01:05:11 --> URI Class Initialized
INFO - 2016-09-14 01:05:11 --> Router Class Initialized
INFO - 2016-09-14 01:05:12 --> Output Class Initialized
INFO - 2016-09-14 01:05:12 --> Security Class Initialized
DEBUG - 2016-09-14 01:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 01:05:12 --> Input Class Initialized
INFO - 2016-09-14 01:05:12 --> Language Class Initialized
INFO - 2016-09-14 01:05:12 --> Language Class Initialized
INFO - 2016-09-14 01:05:12 --> Config Class Initialized
INFO - 2016-09-14 01:05:12 --> Loader Class Initialized
INFO - 2016-09-14 01:05:12 --> Helper loaded: url_helper
INFO - 2016-09-14 01:05:12 --> Database Driver Class Initialized
INFO - 2016-09-14 01:05:12 --> Controller Class Initialized
DEBUG - 2016-09-14 01:05:12 --> Index MX_Controller Initialized
INFO - 2016-09-14 01:05:12 --> Model Class Initialized
INFO - 2016-09-14 01:05:12 --> Model Class Initialized
DEBUG - 2016-09-14 01:05:12 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 01:05:12 --> Database Driver Class Initialized
INFO - 2016-09-14 01:05:12 --> Final output sent to browser
DEBUG - 2016-09-14 01:05:12 --> Total execution time: 0.6527
INFO - 2016-09-14 01:06:44 --> Config Class Initialized
INFO - 2016-09-14 01:06:44 --> Hooks Class Initialized
DEBUG - 2016-09-14 01:06:44 --> UTF-8 Support Enabled
INFO - 2016-09-14 01:06:44 --> Utf8 Class Initialized
INFO - 2016-09-14 01:06:44 --> URI Class Initialized
INFO - 2016-09-14 01:06:44 --> Router Class Initialized
INFO - 2016-09-14 01:06:45 --> Output Class Initialized
INFO - 2016-09-14 01:06:45 --> Security Class Initialized
DEBUG - 2016-09-14 01:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 01:06:45 --> Input Class Initialized
INFO - 2016-09-14 01:06:45 --> Language Class Initialized
INFO - 2016-09-14 01:06:45 --> Language Class Initialized
INFO - 2016-09-14 01:06:45 --> Config Class Initialized
INFO - 2016-09-14 01:06:45 --> Loader Class Initialized
INFO - 2016-09-14 01:06:45 --> Helper loaded: url_helper
INFO - 2016-09-14 01:06:45 --> Database Driver Class Initialized
INFO - 2016-09-14 01:06:45 --> Controller Class Initialized
DEBUG - 2016-09-14 01:06:45 --> Index MX_Controller Initialized
INFO - 2016-09-14 01:06:45 --> Model Class Initialized
INFO - 2016-09-14 01:06:45 --> Model Class Initialized
DEBUG - 2016-09-14 01:06:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 01:06:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 01:06:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 01:06:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-14 01:06:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 01:06:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 01:06:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 01:06:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 01:06:45 --> Final output sent to browser
DEBUG - 2016-09-14 01:06:45 --> Total execution time: 0.6386
INFO - 2016-09-14 01:07:00 --> Config Class Initialized
INFO - 2016-09-14 01:07:00 --> Hooks Class Initialized
DEBUG - 2016-09-14 01:07:00 --> UTF-8 Support Enabled
INFO - 2016-09-14 01:07:00 --> Utf8 Class Initialized
INFO - 2016-09-14 01:07:01 --> URI Class Initialized
INFO - 2016-09-14 01:07:01 --> Router Class Initialized
INFO - 2016-09-14 01:07:01 --> Output Class Initialized
INFO - 2016-09-14 01:07:01 --> Security Class Initialized
DEBUG - 2016-09-14 01:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 01:07:01 --> Input Class Initialized
INFO - 2016-09-14 01:07:01 --> Language Class Initialized
INFO - 2016-09-14 01:07:01 --> Language Class Initialized
INFO - 2016-09-14 01:07:01 --> Config Class Initialized
INFO - 2016-09-14 01:07:01 --> Loader Class Initialized
INFO - 2016-09-14 01:07:01 --> Helper loaded: url_helper
INFO - 2016-09-14 01:07:01 --> Database Driver Class Initialized
INFO - 2016-09-14 01:07:01 --> Controller Class Initialized
DEBUG - 2016-09-14 01:07:01 --> Index MX_Controller Initialized
INFO - 2016-09-14 01:07:01 --> Model Class Initialized
INFO - 2016-09-14 01:07:01 --> Model Class Initialized
DEBUG - 2016-09-14 01:07:01 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 01:07:01 --> Database Driver Class Initialized
INFO - 2016-09-14 01:07:01 --> Final output sent to browser
DEBUG - 2016-09-14 01:07:01 --> Total execution time: 0.5954
INFO - 2016-09-14 01:07:23 --> Config Class Initialized
INFO - 2016-09-14 01:07:23 --> Hooks Class Initialized
DEBUG - 2016-09-14 01:07:23 --> UTF-8 Support Enabled
INFO - 2016-09-14 01:07:23 --> Utf8 Class Initialized
INFO - 2016-09-14 01:07:23 --> URI Class Initialized
INFO - 2016-09-14 01:07:23 --> Router Class Initialized
INFO - 2016-09-14 01:07:23 --> Output Class Initialized
INFO - 2016-09-14 01:07:23 --> Security Class Initialized
DEBUG - 2016-09-14 01:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 01:07:23 --> Input Class Initialized
INFO - 2016-09-14 01:07:23 --> Language Class Initialized
INFO - 2016-09-14 01:07:23 --> Language Class Initialized
INFO - 2016-09-14 01:07:24 --> Config Class Initialized
INFO - 2016-09-14 01:07:24 --> Loader Class Initialized
INFO - 2016-09-14 01:07:24 --> Helper loaded: url_helper
INFO - 2016-09-14 01:07:24 --> Database Driver Class Initialized
INFO - 2016-09-14 01:07:24 --> Controller Class Initialized
DEBUG - 2016-09-14 01:07:24 --> Index MX_Controller Initialized
INFO - 2016-09-14 01:07:24 --> Model Class Initialized
INFO - 2016-09-14 01:07:24 --> Model Class Initialized
DEBUG - 2016-09-14 01:07:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 01:07:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 01:07:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 01:07:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-14 01:07:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 01:07:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 01:07:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 01:07:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 01:07:24 --> Final output sent to browser
DEBUG - 2016-09-14 01:07:24 --> Total execution time: 0.6424
INFO - 2016-09-14 01:07:36 --> Config Class Initialized
INFO - 2016-09-14 01:07:36 --> Hooks Class Initialized
DEBUG - 2016-09-14 01:07:36 --> UTF-8 Support Enabled
INFO - 2016-09-14 01:07:36 --> Utf8 Class Initialized
INFO - 2016-09-14 01:07:36 --> URI Class Initialized
INFO - 2016-09-14 01:07:36 --> Router Class Initialized
INFO - 2016-09-14 01:07:36 --> Output Class Initialized
INFO - 2016-09-14 01:07:36 --> Security Class Initialized
DEBUG - 2016-09-14 01:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 01:07:36 --> Input Class Initialized
INFO - 2016-09-14 01:07:36 --> Language Class Initialized
INFO - 2016-09-14 01:07:36 --> Language Class Initialized
INFO - 2016-09-14 01:07:37 --> Config Class Initialized
INFO - 2016-09-14 01:07:37 --> Loader Class Initialized
INFO - 2016-09-14 01:07:37 --> Helper loaded: url_helper
INFO - 2016-09-14 01:07:37 --> Database Driver Class Initialized
INFO - 2016-09-14 01:07:37 --> Controller Class Initialized
DEBUG - 2016-09-14 01:07:37 --> Index MX_Controller Initialized
INFO - 2016-09-14 01:07:37 --> Model Class Initialized
INFO - 2016-09-14 01:07:37 --> Model Class Initialized
DEBUG - 2016-09-14 01:07:37 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 01:07:37 --> Database Driver Class Initialized
INFO - 2016-09-14 01:07:37 --> Final output sent to browser
DEBUG - 2016-09-14 01:07:37 --> Total execution time: 0.5937
INFO - 2016-09-14 06:09:33 --> Config Class Initialized
INFO - 2016-09-14 06:09:33 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:09:33 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:09:34 --> Utf8 Class Initialized
INFO - 2016-09-14 06:09:34 --> URI Class Initialized
INFO - 2016-09-14 06:09:34 --> Router Class Initialized
INFO - 2016-09-14 06:09:34 --> Output Class Initialized
INFO - 2016-09-14 06:09:34 --> Security Class Initialized
DEBUG - 2016-09-14 06:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:09:34 --> Input Class Initialized
INFO - 2016-09-14 06:09:34 --> Language Class Initialized
INFO - 2016-09-14 06:09:34 --> Language Class Initialized
INFO - 2016-09-14 06:09:34 --> Config Class Initialized
INFO - 2016-09-14 06:09:35 --> Loader Class Initialized
INFO - 2016-09-14 06:09:35 --> Helper loaded: url_helper
INFO - 2016-09-14 06:09:35 --> Database Driver Class Initialized
INFO - 2016-09-14 06:09:35 --> Controller Class Initialized
DEBUG - 2016-09-14 06:09:35 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:09:35 --> Model Class Initialized
INFO - 2016-09-14 06:09:35 --> Model Class Initialized
DEBUG - 2016-09-14 06:09:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 06:09:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 06:09:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 06:09:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-14 06:09:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 06:09:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 06:09:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 06:09:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 06:09:35 --> Final output sent to browser
DEBUG - 2016-09-14 06:09:36 --> Total execution time: 2.4690
INFO - 2016-09-14 06:09:43 --> Config Class Initialized
INFO - 2016-09-14 06:09:43 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:09:44 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:09:44 --> Utf8 Class Initialized
INFO - 2016-09-14 06:09:44 --> URI Class Initialized
INFO - 2016-09-14 06:09:44 --> Router Class Initialized
INFO - 2016-09-14 06:09:44 --> Output Class Initialized
INFO - 2016-09-14 06:09:44 --> Security Class Initialized
DEBUG - 2016-09-14 06:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:09:44 --> Input Class Initialized
INFO - 2016-09-14 06:09:44 --> Language Class Initialized
INFO - 2016-09-14 06:09:44 --> Language Class Initialized
INFO - 2016-09-14 06:09:44 --> Config Class Initialized
INFO - 2016-09-14 06:09:44 --> Loader Class Initialized
INFO - 2016-09-14 06:09:44 --> Helper loaded: url_helper
INFO - 2016-09-14 06:09:44 --> Database Driver Class Initialized
INFO - 2016-09-14 06:09:44 --> Controller Class Initialized
DEBUG - 2016-09-14 06:09:44 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:09:44 --> Model Class Initialized
INFO - 2016-09-14 06:09:44 --> Model Class Initialized
DEBUG - 2016-09-14 06:09:44 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 06:09:44 --> Database Driver Class Initialized
INFO - 2016-09-14 06:09:44 --> Final output sent to browser
DEBUG - 2016-09-14 06:09:44 --> Total execution time: 0.7722
INFO - 2016-09-14 06:09:48 --> Config Class Initialized
INFO - 2016-09-14 06:09:48 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:09:48 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:09:49 --> Utf8 Class Initialized
INFO - 2016-09-14 06:09:49 --> URI Class Initialized
INFO - 2016-09-14 06:09:49 --> Router Class Initialized
INFO - 2016-09-14 06:09:49 --> Output Class Initialized
INFO - 2016-09-14 06:09:49 --> Security Class Initialized
DEBUG - 2016-09-14 06:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:09:49 --> Input Class Initialized
INFO - 2016-09-14 06:09:49 --> Language Class Initialized
INFO - 2016-09-14 06:09:49 --> Language Class Initialized
INFO - 2016-09-14 06:09:49 --> Config Class Initialized
INFO - 2016-09-14 06:09:49 --> Loader Class Initialized
INFO - 2016-09-14 06:09:49 --> Helper loaded: url_helper
INFO - 2016-09-14 06:09:49 --> Database Driver Class Initialized
INFO - 2016-09-14 06:09:49 --> Controller Class Initialized
DEBUG - 2016-09-14 06:09:49 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:09:49 --> Model Class Initialized
INFO - 2016-09-14 06:09:49 --> Model Class Initialized
DEBUG - 2016-09-14 06:09:49 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 06:09:49 --> Database Driver Class Initialized
INFO - 2016-09-14 06:09:49 --> Final output sent to browser
DEBUG - 2016-09-14 06:09:49 --> Total execution time: 0.6701
INFO - 2016-09-14 06:10:06 --> Config Class Initialized
INFO - 2016-09-14 06:10:06 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:10:06 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:10:06 --> Utf8 Class Initialized
INFO - 2016-09-14 06:10:06 --> URI Class Initialized
INFO - 2016-09-14 06:10:06 --> Router Class Initialized
INFO - 2016-09-14 06:10:06 --> Output Class Initialized
INFO - 2016-09-14 06:10:06 --> Security Class Initialized
DEBUG - 2016-09-14 06:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:10:06 --> Input Class Initialized
INFO - 2016-09-14 06:10:06 --> Language Class Initialized
INFO - 2016-09-14 06:10:06 --> Language Class Initialized
INFO - 2016-09-14 06:10:06 --> Config Class Initialized
INFO - 2016-09-14 06:10:06 --> Loader Class Initialized
INFO - 2016-09-14 06:10:06 --> Helper loaded: url_helper
INFO - 2016-09-14 06:10:06 --> Database Driver Class Initialized
INFO - 2016-09-14 06:10:06 --> Controller Class Initialized
DEBUG - 2016-09-14 06:10:06 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:10:06 --> Model Class Initialized
INFO - 2016-09-14 06:10:07 --> Model Class Initialized
DEBUG - 2016-09-14 06:10:07 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 06:10:07 --> Database Driver Class Initialized
INFO - 2016-09-14 06:10:07 --> Final output sent to browser
DEBUG - 2016-09-14 06:10:07 --> Total execution time: 0.6371
INFO - 2016-09-14 06:10:20 --> Config Class Initialized
INFO - 2016-09-14 06:10:20 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:10:20 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:10:20 --> Utf8 Class Initialized
INFO - 2016-09-14 06:10:20 --> URI Class Initialized
INFO - 2016-09-14 06:10:20 --> Router Class Initialized
INFO - 2016-09-14 06:10:20 --> Output Class Initialized
INFO - 2016-09-14 06:10:20 --> Security Class Initialized
DEBUG - 2016-09-14 06:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:10:20 --> Input Class Initialized
INFO - 2016-09-14 06:10:20 --> Language Class Initialized
INFO - 2016-09-14 06:10:20 --> Language Class Initialized
INFO - 2016-09-14 06:10:20 --> Config Class Initialized
INFO - 2016-09-14 06:10:20 --> Loader Class Initialized
INFO - 2016-09-14 06:10:20 --> Helper loaded: url_helper
INFO - 2016-09-14 06:10:20 --> Database Driver Class Initialized
INFO - 2016-09-14 06:10:20 --> Controller Class Initialized
DEBUG - 2016-09-14 06:10:20 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:10:20 --> Model Class Initialized
INFO - 2016-09-14 06:10:20 --> Model Class Initialized
DEBUG - 2016-09-14 06:10:20 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 06:10:20 --> Database Driver Class Initialized
INFO - 2016-09-14 06:10:20 --> Final output sent to browser
DEBUG - 2016-09-14 06:10:21 --> Total execution time: 0.6287
INFO - 2016-09-14 06:11:00 --> Config Class Initialized
INFO - 2016-09-14 06:11:01 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:11:01 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:11:01 --> Utf8 Class Initialized
INFO - 2016-09-14 06:11:01 --> URI Class Initialized
INFO - 2016-09-14 06:11:01 --> Router Class Initialized
INFO - 2016-09-14 06:11:01 --> Output Class Initialized
INFO - 2016-09-14 06:11:01 --> Security Class Initialized
DEBUG - 2016-09-14 06:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:11:01 --> Input Class Initialized
INFO - 2016-09-14 06:11:01 --> Language Class Initialized
INFO - 2016-09-14 06:11:01 --> Language Class Initialized
INFO - 2016-09-14 06:11:01 --> Config Class Initialized
INFO - 2016-09-14 06:11:01 --> Loader Class Initialized
INFO - 2016-09-14 06:11:01 --> Helper loaded: url_helper
INFO - 2016-09-14 06:11:01 --> Database Driver Class Initialized
INFO - 2016-09-14 06:11:01 --> Controller Class Initialized
DEBUG - 2016-09-14 06:11:01 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:11:01 --> Model Class Initialized
INFO - 2016-09-14 06:11:01 --> Model Class Initialized
DEBUG - 2016-09-14 06:11:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 06:11:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 06:11:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 06:11:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-14 06:11:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 06:11:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 06:11:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 06:11:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 06:11:01 --> Final output sent to browser
DEBUG - 2016-09-14 06:11:01 --> Total execution time: 0.7224
INFO - 2016-09-14 06:11:14 --> Config Class Initialized
INFO - 2016-09-14 06:11:14 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:11:14 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:11:14 --> Utf8 Class Initialized
INFO - 2016-09-14 06:11:15 --> URI Class Initialized
INFO - 2016-09-14 06:11:15 --> Router Class Initialized
INFO - 2016-09-14 06:11:15 --> Output Class Initialized
INFO - 2016-09-14 06:11:15 --> Security Class Initialized
DEBUG - 2016-09-14 06:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:11:15 --> Input Class Initialized
INFO - 2016-09-14 06:11:15 --> Language Class Initialized
INFO - 2016-09-14 06:11:15 --> Language Class Initialized
INFO - 2016-09-14 06:11:15 --> Config Class Initialized
INFO - 2016-09-14 06:11:15 --> Loader Class Initialized
INFO - 2016-09-14 06:11:15 --> Helper loaded: url_helper
INFO - 2016-09-14 06:11:15 --> Database Driver Class Initialized
INFO - 2016-09-14 06:11:15 --> Controller Class Initialized
DEBUG - 2016-09-14 06:11:15 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:11:15 --> Model Class Initialized
INFO - 2016-09-14 06:11:15 --> Model Class Initialized
DEBUG - 2016-09-14 06:11:15 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 06:11:15 --> Database Driver Class Initialized
INFO - 2016-09-14 06:11:15 --> Final output sent to browser
DEBUG - 2016-09-14 06:11:15 --> Total execution time: 0.5836
INFO - 2016-09-14 06:11:46 --> Config Class Initialized
INFO - 2016-09-14 06:11:46 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:11:46 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:11:46 --> Utf8 Class Initialized
INFO - 2016-09-14 06:11:46 --> URI Class Initialized
INFO - 2016-09-14 06:11:46 --> Router Class Initialized
INFO - 2016-09-14 06:11:46 --> Output Class Initialized
INFO - 2016-09-14 06:11:46 --> Security Class Initialized
DEBUG - 2016-09-14 06:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:11:46 --> Input Class Initialized
INFO - 2016-09-14 06:11:46 --> Language Class Initialized
INFO - 2016-09-14 06:11:46 --> Language Class Initialized
INFO - 2016-09-14 06:11:46 --> Config Class Initialized
INFO - 2016-09-14 06:11:46 --> Loader Class Initialized
INFO - 2016-09-14 06:11:46 --> Helper loaded: url_helper
INFO - 2016-09-14 06:11:46 --> Database Driver Class Initialized
INFO - 2016-09-14 06:11:46 --> Controller Class Initialized
DEBUG - 2016-09-14 06:11:46 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:11:46 --> Model Class Initialized
INFO - 2016-09-14 06:11:46 --> Model Class Initialized
DEBUG - 2016-09-14 06:11:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 06:11:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 06:11:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 06:11:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-14 06:11:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 06:11:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 06:11:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 06:11:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 06:11:47 --> Final output sent to browser
DEBUG - 2016-09-14 06:11:47 --> Total execution time: 0.7217
INFO - 2016-09-14 06:12:02 --> Config Class Initialized
INFO - 2016-09-14 06:12:02 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:12:02 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:12:02 --> Utf8 Class Initialized
INFO - 2016-09-14 06:12:02 --> URI Class Initialized
INFO - 2016-09-14 06:12:02 --> Router Class Initialized
INFO - 2016-09-14 06:12:02 --> Output Class Initialized
INFO - 2016-09-14 06:12:02 --> Security Class Initialized
DEBUG - 2016-09-14 06:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:12:02 --> Input Class Initialized
INFO - 2016-09-14 06:12:02 --> Language Class Initialized
INFO - 2016-09-14 06:12:02 --> Language Class Initialized
INFO - 2016-09-14 06:12:03 --> Config Class Initialized
INFO - 2016-09-14 06:12:03 --> Loader Class Initialized
INFO - 2016-09-14 06:12:03 --> Helper loaded: url_helper
INFO - 2016-09-14 06:12:03 --> Database Driver Class Initialized
INFO - 2016-09-14 06:12:03 --> Controller Class Initialized
DEBUG - 2016-09-14 06:12:03 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:12:03 --> Model Class Initialized
INFO - 2016-09-14 06:12:03 --> Model Class Initialized
DEBUG - 2016-09-14 06:12:03 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 06:12:03 --> Database Driver Class Initialized
INFO - 2016-09-14 06:12:03 --> Final output sent to browser
DEBUG - 2016-09-14 06:12:03 --> Total execution time: 0.6093
INFO - 2016-09-14 06:12:19 --> Config Class Initialized
INFO - 2016-09-14 06:12:19 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:12:19 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:12:19 --> Utf8 Class Initialized
INFO - 2016-09-14 06:12:19 --> URI Class Initialized
INFO - 2016-09-14 06:12:19 --> Router Class Initialized
INFO - 2016-09-14 06:12:19 --> Output Class Initialized
INFO - 2016-09-14 06:12:19 --> Security Class Initialized
DEBUG - 2016-09-14 06:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:12:19 --> Input Class Initialized
INFO - 2016-09-14 06:12:19 --> Language Class Initialized
INFO - 2016-09-14 06:12:19 --> Language Class Initialized
INFO - 2016-09-14 06:12:19 --> Config Class Initialized
INFO - 2016-09-14 06:12:19 --> Loader Class Initialized
INFO - 2016-09-14 06:12:19 --> Helper loaded: url_helper
INFO - 2016-09-14 06:12:19 --> Database Driver Class Initialized
INFO - 2016-09-14 06:12:19 --> Controller Class Initialized
DEBUG - 2016-09-14 06:12:19 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:12:19 --> Model Class Initialized
INFO - 2016-09-14 06:12:19 --> Model Class Initialized
DEBUG - 2016-09-14 06:12:19 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 06:12:19 --> Database Driver Class Initialized
INFO - 2016-09-14 06:12:19 --> Final output sent to browser
DEBUG - 2016-09-14 06:12:19 --> Total execution time: 0.5306
INFO - 2016-09-14 06:13:18 --> Config Class Initialized
INFO - 2016-09-14 06:13:18 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:13:18 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:13:18 --> Utf8 Class Initialized
INFO - 2016-09-14 06:13:18 --> URI Class Initialized
INFO - 2016-09-14 06:13:18 --> Router Class Initialized
INFO - 2016-09-14 06:13:18 --> Output Class Initialized
INFO - 2016-09-14 06:13:18 --> Security Class Initialized
DEBUG - 2016-09-14 06:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:13:18 --> Input Class Initialized
INFO - 2016-09-14 06:13:18 --> Language Class Initialized
INFO - 2016-09-14 06:13:18 --> Language Class Initialized
INFO - 2016-09-14 06:13:18 --> Config Class Initialized
INFO - 2016-09-14 06:13:18 --> Loader Class Initialized
INFO - 2016-09-14 06:13:18 --> Helper loaded: url_helper
INFO - 2016-09-14 06:13:18 --> Database Driver Class Initialized
INFO - 2016-09-14 06:13:18 --> Controller Class Initialized
DEBUG - 2016-09-14 06:13:18 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:13:18 --> Model Class Initialized
INFO - 2016-09-14 06:13:18 --> Model Class Initialized
DEBUG - 2016-09-14 06:13:18 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 06:13:18 --> Database Driver Class Initialized
INFO - 2016-09-14 06:13:18 --> Final output sent to browser
DEBUG - 2016-09-14 06:13:18 --> Total execution time: 0.5020
INFO - 2016-09-14 06:13:22 --> Config Class Initialized
INFO - 2016-09-14 06:13:22 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:13:22 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:13:23 --> Utf8 Class Initialized
INFO - 2016-09-14 06:13:23 --> URI Class Initialized
INFO - 2016-09-14 06:13:23 --> Router Class Initialized
INFO - 2016-09-14 06:13:23 --> Output Class Initialized
INFO - 2016-09-14 06:13:23 --> Security Class Initialized
DEBUG - 2016-09-14 06:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:13:23 --> Input Class Initialized
INFO - 2016-09-14 06:13:23 --> Language Class Initialized
INFO - 2016-09-14 06:13:23 --> Language Class Initialized
INFO - 2016-09-14 06:13:23 --> Config Class Initialized
INFO - 2016-09-14 06:13:23 --> Loader Class Initialized
INFO - 2016-09-14 06:13:23 --> Helper loaded: url_helper
INFO - 2016-09-14 06:13:23 --> Database Driver Class Initialized
INFO - 2016-09-14 06:13:23 --> Controller Class Initialized
DEBUG - 2016-09-14 06:13:23 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:13:23 --> Model Class Initialized
INFO - 2016-09-14 06:13:23 --> Model Class Initialized
DEBUG - 2016-09-14 06:13:23 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 06:13:23 --> Database Driver Class Initialized
INFO - 2016-09-14 06:13:23 --> Final output sent to browser
DEBUG - 2016-09-14 06:13:23 --> Total execution time: 0.5023
INFO - 2016-09-14 06:14:18 --> Config Class Initialized
INFO - 2016-09-14 06:14:18 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:14:18 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:14:19 --> Utf8 Class Initialized
INFO - 2016-09-14 06:14:19 --> URI Class Initialized
INFO - 2016-09-14 06:14:19 --> Router Class Initialized
INFO - 2016-09-14 06:14:19 --> Output Class Initialized
INFO - 2016-09-14 06:14:19 --> Security Class Initialized
DEBUG - 2016-09-14 06:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:14:19 --> Input Class Initialized
INFO - 2016-09-14 06:14:19 --> Language Class Initialized
INFO - 2016-09-14 06:14:19 --> Language Class Initialized
INFO - 2016-09-14 06:14:19 --> Config Class Initialized
INFO - 2016-09-14 06:14:19 --> Loader Class Initialized
INFO - 2016-09-14 06:14:19 --> Helper loaded: url_helper
INFO - 2016-09-14 06:14:19 --> Database Driver Class Initialized
INFO - 2016-09-14 06:14:19 --> Controller Class Initialized
DEBUG - 2016-09-14 06:14:19 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:14:19 --> Model Class Initialized
INFO - 2016-09-14 06:14:19 --> Model Class Initialized
DEBUG - 2016-09-14 06:14:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 06:14:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 06:14:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 06:14:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-14 06:14:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 06:14:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 06:14:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 06:14:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 06:14:19 --> Final output sent to browser
DEBUG - 2016-09-14 06:14:19 --> Total execution time: 0.6922
INFO - 2016-09-14 06:14:25 --> Config Class Initialized
INFO - 2016-09-14 06:14:25 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:14:25 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:14:25 --> Utf8 Class Initialized
INFO - 2016-09-14 06:14:25 --> URI Class Initialized
INFO - 2016-09-14 06:14:25 --> Router Class Initialized
INFO - 2016-09-14 06:14:25 --> Output Class Initialized
INFO - 2016-09-14 06:14:25 --> Security Class Initialized
DEBUG - 2016-09-14 06:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:14:25 --> Input Class Initialized
INFO - 2016-09-14 06:14:25 --> Language Class Initialized
INFO - 2016-09-14 06:14:25 --> Language Class Initialized
INFO - 2016-09-14 06:14:25 --> Config Class Initialized
INFO - 2016-09-14 06:14:25 --> Loader Class Initialized
INFO - 2016-09-14 06:14:25 --> Helper loaded: url_helper
INFO - 2016-09-14 06:14:25 --> Database Driver Class Initialized
INFO - 2016-09-14 06:14:25 --> Controller Class Initialized
DEBUG - 2016-09-14 06:14:25 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:14:25 --> Model Class Initialized
INFO - 2016-09-14 06:14:25 --> Model Class Initialized
DEBUG - 2016-09-14 06:14:25 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 06:14:26 --> Database Driver Class Initialized
INFO - 2016-09-14 06:14:26 --> Final output sent to browser
DEBUG - 2016-09-14 06:14:26 --> Total execution time: 0.5362
INFO - 2016-09-14 06:14:29 --> Config Class Initialized
INFO - 2016-09-14 06:14:29 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:14:29 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:14:29 --> Utf8 Class Initialized
INFO - 2016-09-14 06:14:29 --> URI Class Initialized
INFO - 2016-09-14 06:14:29 --> Router Class Initialized
INFO - 2016-09-14 06:14:29 --> Output Class Initialized
INFO - 2016-09-14 06:14:29 --> Security Class Initialized
DEBUG - 2016-09-14 06:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:14:29 --> Input Class Initialized
INFO - 2016-09-14 06:14:29 --> Language Class Initialized
INFO - 2016-09-14 06:14:29 --> Language Class Initialized
INFO - 2016-09-14 06:14:29 --> Config Class Initialized
INFO - 2016-09-14 06:14:29 --> Loader Class Initialized
INFO - 2016-09-14 06:14:29 --> Helper loaded: url_helper
INFO - 2016-09-14 06:14:29 --> Database Driver Class Initialized
INFO - 2016-09-14 06:14:30 --> Controller Class Initialized
DEBUG - 2016-09-14 06:14:30 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:14:30 --> Model Class Initialized
INFO - 2016-09-14 06:14:30 --> Model Class Initialized
DEBUG - 2016-09-14 06:14:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 06:14:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 06:14:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 06:14:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-14 06:14:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 06:14:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 06:14:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 06:14:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 06:14:30 --> Final output sent to browser
DEBUG - 2016-09-14 06:14:30 --> Total execution time: 0.6958
INFO - 2016-09-14 06:17:08 --> Config Class Initialized
INFO - 2016-09-14 06:17:08 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:17:08 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:17:08 --> Utf8 Class Initialized
INFO - 2016-09-14 06:17:08 --> URI Class Initialized
INFO - 2016-09-14 06:17:08 --> Router Class Initialized
INFO - 2016-09-14 06:17:08 --> Output Class Initialized
INFO - 2016-09-14 06:17:08 --> Security Class Initialized
DEBUG - 2016-09-14 06:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:17:08 --> Input Class Initialized
INFO - 2016-09-14 06:17:08 --> Language Class Initialized
INFO - 2016-09-14 06:17:08 --> Language Class Initialized
INFO - 2016-09-14 06:17:08 --> Config Class Initialized
INFO - 2016-09-14 06:17:08 --> Loader Class Initialized
INFO - 2016-09-14 06:17:08 --> Helper loaded: url_helper
INFO - 2016-09-14 06:17:08 --> Database Driver Class Initialized
INFO - 2016-09-14 06:17:08 --> Controller Class Initialized
DEBUG - 2016-09-14 06:17:08 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:17:08 --> Model Class Initialized
INFO - 2016-09-14 06:17:08 --> Model Class Initialized
DEBUG - 2016-09-14 06:17:08 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 06:17:08 --> Final output sent to browser
DEBUG - 2016-09-14 06:17:08 --> Total execution time: 0.5297
INFO - 2016-09-14 06:17:10 --> Config Class Initialized
INFO - 2016-09-14 06:17:10 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:17:10 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:17:10 --> Utf8 Class Initialized
INFO - 2016-09-14 06:17:10 --> URI Class Initialized
INFO - 2016-09-14 06:17:10 --> Router Class Initialized
INFO - 2016-09-14 06:17:10 --> Output Class Initialized
INFO - 2016-09-14 06:17:11 --> Security Class Initialized
DEBUG - 2016-09-14 06:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:17:11 --> Input Class Initialized
INFO - 2016-09-14 06:17:11 --> Language Class Initialized
INFO - 2016-09-14 06:17:11 --> Language Class Initialized
INFO - 2016-09-14 06:17:11 --> Config Class Initialized
INFO - 2016-09-14 06:17:11 --> Loader Class Initialized
INFO - 2016-09-14 06:17:11 --> Helper loaded: url_helper
INFO - 2016-09-14 06:17:11 --> Database Driver Class Initialized
INFO - 2016-09-14 06:17:11 --> Controller Class Initialized
DEBUG - 2016-09-14 06:17:11 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:17:11 --> Model Class Initialized
INFO - 2016-09-14 06:17:11 --> Model Class Initialized
DEBUG - 2016-09-14 06:17:11 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 06:17:11 --> Database Driver Class Initialized
INFO - 2016-09-14 06:17:11 --> Final output sent to browser
DEBUG - 2016-09-14 06:17:11 --> Total execution time: 0.5035
INFO - 2016-09-14 06:17:16 --> Config Class Initialized
INFO - 2016-09-14 06:17:16 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:17:16 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:17:16 --> Utf8 Class Initialized
INFO - 2016-09-14 06:17:16 --> URI Class Initialized
INFO - 2016-09-14 06:17:16 --> Router Class Initialized
INFO - 2016-09-14 06:17:16 --> Output Class Initialized
INFO - 2016-09-14 06:17:16 --> Security Class Initialized
DEBUG - 2016-09-14 06:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:17:16 --> Input Class Initialized
INFO - 2016-09-14 06:17:16 --> Language Class Initialized
INFO - 2016-09-14 06:17:16 --> Language Class Initialized
INFO - 2016-09-14 06:17:16 --> Config Class Initialized
INFO - 2016-09-14 06:17:16 --> Loader Class Initialized
INFO - 2016-09-14 06:17:16 --> Helper loaded: url_helper
INFO - 2016-09-14 06:17:16 --> Database Driver Class Initialized
INFO - 2016-09-14 06:17:16 --> Controller Class Initialized
DEBUG - 2016-09-14 06:17:16 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:17:16 --> Model Class Initialized
INFO - 2016-09-14 06:17:16 --> Model Class Initialized
DEBUG - 2016-09-14 06:17:16 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 06:17:16 --> Database Driver Class Initialized
INFO - 2016-09-14 06:17:16 --> Final output sent to browser
DEBUG - 2016-09-14 06:17:16 --> Total execution time: 0.5440
INFO - 2016-09-14 06:18:10 --> Config Class Initialized
INFO - 2016-09-14 06:18:10 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:18:10 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:18:10 --> Utf8 Class Initialized
INFO - 2016-09-14 06:18:10 --> URI Class Initialized
INFO - 2016-09-14 06:18:10 --> Router Class Initialized
INFO - 2016-09-14 06:18:10 --> Output Class Initialized
INFO - 2016-09-14 06:18:10 --> Security Class Initialized
DEBUG - 2016-09-14 06:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:18:10 --> Input Class Initialized
INFO - 2016-09-14 06:18:10 --> Language Class Initialized
INFO - 2016-09-14 06:18:10 --> Language Class Initialized
INFO - 2016-09-14 06:18:10 --> Config Class Initialized
INFO - 2016-09-14 06:18:10 --> Loader Class Initialized
INFO - 2016-09-14 06:18:10 --> Helper loaded: url_helper
INFO - 2016-09-14 06:18:10 --> Database Driver Class Initialized
INFO - 2016-09-14 06:18:10 --> Controller Class Initialized
DEBUG - 2016-09-14 06:18:10 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:18:10 --> Model Class Initialized
INFO - 2016-09-14 06:18:10 --> Model Class Initialized
DEBUG - 2016-09-14 06:18:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 06:18:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 06:18:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 06:18:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-14 06:18:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 06:18:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 06:18:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 06:18:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 06:18:10 --> Final output sent to browser
DEBUG - 2016-09-14 06:18:11 --> Total execution time: 0.6508
INFO - 2016-09-14 06:18:17 --> Config Class Initialized
INFO - 2016-09-14 06:18:17 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:18:17 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:18:17 --> Utf8 Class Initialized
INFO - 2016-09-14 06:18:17 --> URI Class Initialized
INFO - 2016-09-14 06:18:17 --> Router Class Initialized
INFO - 2016-09-14 06:18:17 --> Output Class Initialized
INFO - 2016-09-14 06:18:17 --> Security Class Initialized
DEBUG - 2016-09-14 06:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:18:17 --> Input Class Initialized
INFO - 2016-09-14 06:18:17 --> Language Class Initialized
INFO - 2016-09-14 06:18:17 --> Language Class Initialized
INFO - 2016-09-14 06:18:17 --> Config Class Initialized
INFO - 2016-09-14 06:18:17 --> Loader Class Initialized
INFO - 2016-09-14 06:18:17 --> Helper loaded: url_helper
INFO - 2016-09-14 06:18:17 --> Database Driver Class Initialized
INFO - 2016-09-14 06:18:17 --> Controller Class Initialized
DEBUG - 2016-09-14 06:18:17 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:18:17 --> Model Class Initialized
INFO - 2016-09-14 06:18:17 --> Model Class Initialized
DEBUG - 2016-09-14 06:18:17 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 06:18:18 --> Final output sent to browser
DEBUG - 2016-09-14 06:18:18 --> Total execution time: 0.5061
INFO - 2016-09-14 06:18:23 --> Config Class Initialized
INFO - 2016-09-14 06:18:23 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:18:23 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:18:23 --> Utf8 Class Initialized
INFO - 2016-09-14 06:18:23 --> URI Class Initialized
INFO - 2016-09-14 06:18:23 --> Router Class Initialized
INFO - 2016-09-14 06:18:24 --> Output Class Initialized
INFO - 2016-09-14 06:18:24 --> Security Class Initialized
DEBUG - 2016-09-14 06:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:18:24 --> Input Class Initialized
INFO - 2016-09-14 06:18:24 --> Language Class Initialized
INFO - 2016-09-14 06:18:24 --> Language Class Initialized
INFO - 2016-09-14 06:18:24 --> Config Class Initialized
INFO - 2016-09-14 06:18:24 --> Loader Class Initialized
INFO - 2016-09-14 06:18:24 --> Helper loaded: url_helper
INFO - 2016-09-14 06:18:24 --> Database Driver Class Initialized
INFO - 2016-09-14 06:18:24 --> Controller Class Initialized
DEBUG - 2016-09-14 06:18:24 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:18:24 --> Model Class Initialized
INFO - 2016-09-14 06:18:24 --> Model Class Initialized
DEBUG - 2016-09-14 06:18:24 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 06:18:24 --> Final output sent to browser
DEBUG - 2016-09-14 06:18:24 --> Total execution time: 0.5534
INFO - 2016-09-14 06:18:36 --> Config Class Initialized
INFO - 2016-09-14 06:18:36 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:18:36 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:18:36 --> Utf8 Class Initialized
INFO - 2016-09-14 06:18:36 --> URI Class Initialized
INFO - 2016-09-14 06:18:37 --> Router Class Initialized
INFO - 2016-09-14 06:18:37 --> Output Class Initialized
INFO - 2016-09-14 06:18:37 --> Security Class Initialized
DEBUG - 2016-09-14 06:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:18:37 --> Input Class Initialized
INFO - 2016-09-14 06:18:37 --> Language Class Initialized
INFO - 2016-09-14 06:18:37 --> Language Class Initialized
INFO - 2016-09-14 06:18:37 --> Config Class Initialized
INFO - 2016-09-14 06:18:37 --> Loader Class Initialized
INFO - 2016-09-14 06:18:37 --> Helper loaded: url_helper
INFO - 2016-09-14 06:18:37 --> Database Driver Class Initialized
INFO - 2016-09-14 06:18:37 --> Controller Class Initialized
DEBUG - 2016-09-14 06:18:37 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:18:37 --> Model Class Initialized
INFO - 2016-09-14 06:18:37 --> Model Class Initialized
DEBUG - 2016-09-14 06:18:37 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 06:18:37 --> Database Driver Class Initialized
INFO - 2016-09-14 06:18:37 --> Final output sent to browser
DEBUG - 2016-09-14 06:18:37 --> Total execution time: 0.5175
INFO - 2016-09-14 06:19:03 --> Config Class Initialized
INFO - 2016-09-14 06:19:03 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:19:03 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:19:03 --> Utf8 Class Initialized
INFO - 2016-09-14 06:19:03 --> URI Class Initialized
INFO - 2016-09-14 06:19:03 --> Router Class Initialized
INFO - 2016-09-14 06:19:03 --> Output Class Initialized
INFO - 2016-09-14 06:19:03 --> Security Class Initialized
DEBUG - 2016-09-14 06:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:19:03 --> Input Class Initialized
INFO - 2016-09-14 06:19:03 --> Language Class Initialized
INFO - 2016-09-14 06:19:03 --> Language Class Initialized
INFO - 2016-09-14 06:19:03 --> Config Class Initialized
INFO - 2016-09-14 06:19:03 --> Loader Class Initialized
INFO - 2016-09-14 06:19:03 --> Helper loaded: url_helper
INFO - 2016-09-14 06:19:03 --> Database Driver Class Initialized
INFO - 2016-09-14 06:19:03 --> Controller Class Initialized
DEBUG - 2016-09-14 06:19:03 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:19:03 --> Model Class Initialized
INFO - 2016-09-14 06:19:03 --> Model Class Initialized
DEBUG - 2016-09-14 06:19:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 06:19:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 06:19:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 06:19:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-14 06:19:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 06:19:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 06:19:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 06:19:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 06:19:03 --> Final output sent to browser
DEBUG - 2016-09-14 06:19:03 --> Total execution time: 0.6701
INFO - 2016-09-14 06:19:09 --> Config Class Initialized
INFO - 2016-09-14 06:19:09 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:19:09 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:19:09 --> Utf8 Class Initialized
INFO - 2016-09-14 06:19:09 --> URI Class Initialized
INFO - 2016-09-14 06:19:09 --> Router Class Initialized
INFO - 2016-09-14 06:19:09 --> Output Class Initialized
INFO - 2016-09-14 06:19:09 --> Security Class Initialized
DEBUG - 2016-09-14 06:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:19:09 --> Input Class Initialized
INFO - 2016-09-14 06:19:09 --> Language Class Initialized
INFO - 2016-09-14 06:19:09 --> Language Class Initialized
INFO - 2016-09-14 06:19:09 --> Config Class Initialized
INFO - 2016-09-14 06:19:10 --> Loader Class Initialized
INFO - 2016-09-14 06:19:10 --> Helper loaded: url_helper
INFO - 2016-09-14 06:19:10 --> Database Driver Class Initialized
INFO - 2016-09-14 06:19:10 --> Controller Class Initialized
DEBUG - 2016-09-14 06:19:10 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:19:10 --> Model Class Initialized
INFO - 2016-09-14 06:19:10 --> Model Class Initialized
DEBUG - 2016-09-14 06:19:10 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 06:19:10 --> Final output sent to browser
DEBUG - 2016-09-14 06:19:10 --> Total execution time: 0.5345
INFO - 2016-09-14 06:19:23 --> Config Class Initialized
INFO - 2016-09-14 06:19:23 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:19:23 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:19:23 --> Utf8 Class Initialized
INFO - 2016-09-14 06:19:24 --> URI Class Initialized
INFO - 2016-09-14 06:19:24 --> Router Class Initialized
INFO - 2016-09-14 06:19:24 --> Output Class Initialized
INFO - 2016-09-14 06:19:24 --> Security Class Initialized
DEBUG - 2016-09-14 06:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:19:24 --> Input Class Initialized
INFO - 2016-09-14 06:19:24 --> Language Class Initialized
INFO - 2016-09-14 06:19:24 --> Language Class Initialized
INFO - 2016-09-14 06:19:24 --> Config Class Initialized
INFO - 2016-09-14 06:19:24 --> Loader Class Initialized
INFO - 2016-09-14 06:19:24 --> Helper loaded: url_helper
INFO - 2016-09-14 06:19:24 --> Database Driver Class Initialized
INFO - 2016-09-14 06:19:24 --> Controller Class Initialized
DEBUG - 2016-09-14 06:19:24 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:19:24 --> Model Class Initialized
INFO - 2016-09-14 06:19:24 --> Model Class Initialized
DEBUG - 2016-09-14 06:19:24 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 06:19:24 --> Final output sent to browser
DEBUG - 2016-09-14 06:19:24 --> Total execution time: 0.4999
INFO - 2016-09-14 06:19:37 --> Config Class Initialized
INFO - 2016-09-14 06:19:37 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:19:37 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:19:37 --> Utf8 Class Initialized
INFO - 2016-09-14 06:19:37 --> URI Class Initialized
INFO - 2016-09-14 06:19:37 --> Router Class Initialized
INFO - 2016-09-14 06:19:37 --> Output Class Initialized
INFO - 2016-09-14 06:19:37 --> Security Class Initialized
DEBUG - 2016-09-14 06:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:19:37 --> Input Class Initialized
INFO - 2016-09-14 06:19:37 --> Language Class Initialized
INFO - 2016-09-14 06:19:37 --> Language Class Initialized
INFO - 2016-09-14 06:19:37 --> Config Class Initialized
INFO - 2016-09-14 06:19:37 --> Loader Class Initialized
INFO - 2016-09-14 06:19:37 --> Helper loaded: url_helper
INFO - 2016-09-14 06:19:37 --> Database Driver Class Initialized
INFO - 2016-09-14 06:19:37 --> Controller Class Initialized
DEBUG - 2016-09-14 06:19:37 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:19:37 --> Model Class Initialized
INFO - 2016-09-14 06:19:37 --> Model Class Initialized
DEBUG - 2016-09-14 06:19:37 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 06:19:37 --> Database Driver Class Initialized
INFO - 2016-09-14 06:19:37 --> Final output sent to browser
DEBUG - 2016-09-14 06:19:37 --> Total execution time: 0.5064
INFO - 2016-09-14 06:20:03 --> Config Class Initialized
INFO - 2016-09-14 06:20:03 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:20:03 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:20:03 --> Utf8 Class Initialized
INFO - 2016-09-14 06:20:03 --> URI Class Initialized
INFO - 2016-09-14 06:20:03 --> Router Class Initialized
INFO - 2016-09-14 06:20:03 --> Output Class Initialized
INFO - 2016-09-14 06:20:03 --> Security Class Initialized
DEBUG - 2016-09-14 06:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:20:03 --> Input Class Initialized
INFO - 2016-09-14 06:20:03 --> Language Class Initialized
INFO - 2016-09-14 06:20:03 --> Language Class Initialized
INFO - 2016-09-14 06:20:03 --> Config Class Initialized
INFO - 2016-09-14 06:20:03 --> Loader Class Initialized
INFO - 2016-09-14 06:20:03 --> Helper loaded: url_helper
INFO - 2016-09-14 06:20:03 --> Database Driver Class Initialized
INFO - 2016-09-14 06:20:03 --> Controller Class Initialized
DEBUG - 2016-09-14 06:20:03 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:20:03 --> Model Class Initialized
INFO - 2016-09-14 06:20:03 --> Model Class Initialized
DEBUG - 2016-09-14 06:20:03 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 06:20:03 --> Database Driver Class Initialized
INFO - 2016-09-14 06:20:03 --> Final output sent to browser
DEBUG - 2016-09-14 06:20:03 --> Total execution time: 0.6541
INFO - 2016-09-14 06:21:15 --> Config Class Initialized
INFO - 2016-09-14 06:21:15 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:21:15 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:21:15 --> Utf8 Class Initialized
INFO - 2016-09-14 06:21:15 --> URI Class Initialized
INFO - 2016-09-14 06:21:15 --> Router Class Initialized
INFO - 2016-09-14 06:21:15 --> Output Class Initialized
INFO - 2016-09-14 06:21:15 --> Security Class Initialized
DEBUG - 2016-09-14 06:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:21:15 --> Input Class Initialized
INFO - 2016-09-14 06:21:15 --> Language Class Initialized
INFO - 2016-09-14 06:21:15 --> Language Class Initialized
INFO - 2016-09-14 06:21:15 --> Config Class Initialized
INFO - 2016-09-14 06:21:15 --> Loader Class Initialized
INFO - 2016-09-14 06:21:15 --> Helper loaded: url_helper
INFO - 2016-09-14 06:21:15 --> Database Driver Class Initialized
INFO - 2016-09-14 06:21:15 --> Controller Class Initialized
DEBUG - 2016-09-14 06:21:15 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:21:15 --> Model Class Initialized
INFO - 2016-09-14 06:21:15 --> Model Class Initialized
DEBUG - 2016-09-14 06:21:15 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 06:21:15 --> Database Driver Class Initialized
INFO - 2016-09-14 06:21:15 --> Final output sent to browser
DEBUG - 2016-09-14 06:21:15 --> Total execution time: 0.6043
INFO - 2016-09-14 06:21:44 --> Config Class Initialized
INFO - 2016-09-14 06:21:44 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:21:44 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:21:44 --> Utf8 Class Initialized
INFO - 2016-09-14 06:21:44 --> URI Class Initialized
INFO - 2016-09-14 06:21:44 --> Router Class Initialized
INFO - 2016-09-14 06:21:44 --> Output Class Initialized
INFO - 2016-09-14 06:21:44 --> Security Class Initialized
DEBUG - 2016-09-14 06:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:21:44 --> Input Class Initialized
INFO - 2016-09-14 06:21:44 --> Language Class Initialized
INFO - 2016-09-14 06:21:44 --> Language Class Initialized
INFO - 2016-09-14 06:21:44 --> Config Class Initialized
INFO - 2016-09-14 06:21:44 --> Loader Class Initialized
INFO - 2016-09-14 06:21:44 --> Helper loaded: url_helper
INFO - 2016-09-14 06:21:44 --> Database Driver Class Initialized
INFO - 2016-09-14 06:21:44 --> Controller Class Initialized
DEBUG - 2016-09-14 06:21:44 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:21:44 --> Model Class Initialized
INFO - 2016-09-14 06:21:44 --> Model Class Initialized
DEBUG - 2016-09-14 06:21:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 06:21:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 06:21:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 06:21:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-14 06:21:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 06:21:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 06:21:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 06:21:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 06:21:44 --> Final output sent to browser
DEBUG - 2016-09-14 06:21:44 --> Total execution time: 0.6985
INFO - 2016-09-14 06:21:52 --> Config Class Initialized
INFO - 2016-09-14 06:21:52 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:21:53 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:21:53 --> Utf8 Class Initialized
INFO - 2016-09-14 06:21:53 --> URI Class Initialized
INFO - 2016-09-14 06:21:53 --> Router Class Initialized
INFO - 2016-09-14 06:21:53 --> Output Class Initialized
INFO - 2016-09-14 06:21:53 --> Security Class Initialized
DEBUG - 2016-09-14 06:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:21:53 --> Input Class Initialized
INFO - 2016-09-14 06:21:53 --> Language Class Initialized
INFO - 2016-09-14 06:21:53 --> Language Class Initialized
INFO - 2016-09-14 06:21:53 --> Config Class Initialized
INFO - 2016-09-14 06:21:53 --> Loader Class Initialized
INFO - 2016-09-14 06:21:53 --> Helper loaded: url_helper
INFO - 2016-09-14 06:21:53 --> Database Driver Class Initialized
INFO - 2016-09-14 06:21:53 --> Controller Class Initialized
DEBUG - 2016-09-14 06:21:53 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:21:53 --> Model Class Initialized
INFO - 2016-09-14 06:21:53 --> Model Class Initialized
DEBUG - 2016-09-14 06:21:53 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 06:21:53 --> Final output sent to browser
DEBUG - 2016-09-14 06:21:53 --> Total execution time: 0.5117
INFO - 2016-09-14 06:22:00 --> Config Class Initialized
INFO - 2016-09-14 06:22:00 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:22:00 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:22:00 --> Utf8 Class Initialized
INFO - 2016-09-14 06:22:00 --> URI Class Initialized
INFO - 2016-09-14 06:22:00 --> Router Class Initialized
INFO - 2016-09-14 06:22:00 --> Output Class Initialized
INFO - 2016-09-14 06:22:00 --> Security Class Initialized
DEBUG - 2016-09-14 06:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:22:00 --> Input Class Initialized
INFO - 2016-09-14 06:22:00 --> Language Class Initialized
INFO - 2016-09-14 06:22:00 --> Language Class Initialized
INFO - 2016-09-14 06:22:00 --> Config Class Initialized
INFO - 2016-09-14 06:22:00 --> Loader Class Initialized
INFO - 2016-09-14 06:22:00 --> Helper loaded: url_helper
INFO - 2016-09-14 06:22:00 --> Database Driver Class Initialized
INFO - 2016-09-14 06:22:00 --> Controller Class Initialized
DEBUG - 2016-09-14 06:22:00 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:22:00 --> Model Class Initialized
INFO - 2016-09-14 06:22:00 --> Model Class Initialized
DEBUG - 2016-09-14 06:22:00 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 06:22:00 --> Database Driver Class Initialized
INFO - 2016-09-14 06:22:00 --> Final output sent to browser
DEBUG - 2016-09-14 06:22:00 --> Total execution time: 0.5622
INFO - 2016-09-14 06:22:34 --> Config Class Initialized
INFO - 2016-09-14 06:22:34 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:22:34 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:22:34 --> Utf8 Class Initialized
INFO - 2016-09-14 06:22:34 --> URI Class Initialized
INFO - 2016-09-14 06:22:34 --> Router Class Initialized
INFO - 2016-09-14 06:22:34 --> Output Class Initialized
INFO - 2016-09-14 06:22:34 --> Security Class Initialized
DEBUG - 2016-09-14 06:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:22:34 --> Input Class Initialized
INFO - 2016-09-14 06:22:34 --> Language Class Initialized
INFO - 2016-09-14 06:22:34 --> Language Class Initialized
INFO - 2016-09-14 06:22:34 --> Config Class Initialized
INFO - 2016-09-14 06:22:34 --> Loader Class Initialized
INFO - 2016-09-14 06:22:34 --> Helper loaded: url_helper
INFO - 2016-09-14 06:22:34 --> Database Driver Class Initialized
INFO - 2016-09-14 06:22:34 --> Controller Class Initialized
DEBUG - 2016-09-14 06:22:34 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:22:34 --> Model Class Initialized
INFO - 2016-09-14 06:22:34 --> Model Class Initialized
DEBUG - 2016-09-14 06:22:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 06:22:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 06:22:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 06:22:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-14 06:22:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 06:22:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 06:22:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 06:22:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 06:22:34 --> Final output sent to browser
DEBUG - 2016-09-14 06:22:34 --> Total execution time: 0.6591
INFO - 2016-09-14 06:22:53 --> Config Class Initialized
INFO - 2016-09-14 06:22:53 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:22:53 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:22:53 --> Utf8 Class Initialized
INFO - 2016-09-14 06:22:53 --> URI Class Initialized
INFO - 2016-09-14 06:22:53 --> Router Class Initialized
INFO - 2016-09-14 06:22:53 --> Output Class Initialized
INFO - 2016-09-14 06:22:53 --> Security Class Initialized
DEBUG - 2016-09-14 06:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:22:53 --> Input Class Initialized
INFO - 2016-09-14 06:22:54 --> Language Class Initialized
INFO - 2016-09-14 06:22:54 --> Language Class Initialized
INFO - 2016-09-14 06:22:54 --> Config Class Initialized
INFO - 2016-09-14 06:22:54 --> Loader Class Initialized
INFO - 2016-09-14 06:22:54 --> Helper loaded: url_helper
INFO - 2016-09-14 06:22:54 --> Database Driver Class Initialized
INFO - 2016-09-14 06:22:54 --> Controller Class Initialized
DEBUG - 2016-09-14 06:22:54 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:22:54 --> Model Class Initialized
INFO - 2016-09-14 06:22:54 --> Model Class Initialized
DEBUG - 2016-09-14 06:22:54 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 06:22:54 --> Database Driver Class Initialized
INFO - 2016-09-14 06:22:54 --> Final output sent to browser
DEBUG - 2016-09-14 06:22:54 --> Total execution time: 0.5689
INFO - 2016-09-14 06:23:07 --> Config Class Initialized
INFO - 2016-09-14 06:23:07 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:23:07 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:23:07 --> Utf8 Class Initialized
INFO - 2016-09-14 06:23:07 --> URI Class Initialized
INFO - 2016-09-14 06:23:07 --> Router Class Initialized
INFO - 2016-09-14 06:23:07 --> Output Class Initialized
INFO - 2016-09-14 06:23:07 --> Security Class Initialized
DEBUG - 2016-09-14 06:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:23:07 --> Input Class Initialized
INFO - 2016-09-14 06:23:07 --> Language Class Initialized
INFO - 2016-09-14 06:23:07 --> Language Class Initialized
INFO - 2016-09-14 06:23:07 --> Config Class Initialized
INFO - 2016-09-14 06:23:07 --> Loader Class Initialized
INFO - 2016-09-14 06:23:07 --> Helper loaded: url_helper
INFO - 2016-09-14 06:23:07 --> Database Driver Class Initialized
INFO - 2016-09-14 06:23:07 --> Controller Class Initialized
DEBUG - 2016-09-14 06:23:07 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:23:07 --> Model Class Initialized
INFO - 2016-09-14 06:23:07 --> Model Class Initialized
DEBUG - 2016-09-14 06:23:07 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 06:23:07 --> Final output sent to browser
DEBUG - 2016-09-14 06:23:07 --> Total execution time: 0.5612
INFO - 2016-09-14 06:23:12 --> Config Class Initialized
INFO - 2016-09-14 06:23:12 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:23:12 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:23:12 --> Utf8 Class Initialized
INFO - 2016-09-14 06:23:12 --> URI Class Initialized
INFO - 2016-09-14 06:23:12 --> Router Class Initialized
INFO - 2016-09-14 06:23:13 --> Output Class Initialized
INFO - 2016-09-14 06:23:13 --> Security Class Initialized
DEBUG - 2016-09-14 06:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:23:13 --> Input Class Initialized
INFO - 2016-09-14 06:23:13 --> Language Class Initialized
INFO - 2016-09-14 06:23:13 --> Language Class Initialized
INFO - 2016-09-14 06:23:13 --> Config Class Initialized
INFO - 2016-09-14 06:23:13 --> Loader Class Initialized
INFO - 2016-09-14 06:23:13 --> Helper loaded: url_helper
INFO - 2016-09-14 06:23:13 --> Database Driver Class Initialized
INFO - 2016-09-14 06:23:13 --> Controller Class Initialized
DEBUG - 2016-09-14 06:23:13 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:23:13 --> Model Class Initialized
INFO - 2016-09-14 06:23:13 --> Model Class Initialized
DEBUG - 2016-09-14 06:23:13 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 06:23:13 --> Database Driver Class Initialized
INFO - 2016-09-14 06:23:13 --> Final output sent to browser
DEBUG - 2016-09-14 06:23:13 --> Total execution time: 0.5377
INFO - 2016-09-14 06:23:17 --> Config Class Initialized
INFO - 2016-09-14 06:23:17 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:23:17 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:23:17 --> Utf8 Class Initialized
INFO - 2016-09-14 06:23:17 --> URI Class Initialized
INFO - 2016-09-14 06:23:17 --> Router Class Initialized
INFO - 2016-09-14 06:23:17 --> Output Class Initialized
INFO - 2016-09-14 06:23:17 --> Security Class Initialized
DEBUG - 2016-09-14 06:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:23:17 --> Input Class Initialized
INFO - 2016-09-14 06:23:17 --> Language Class Initialized
INFO - 2016-09-14 06:23:17 --> Language Class Initialized
INFO - 2016-09-14 06:23:17 --> Config Class Initialized
INFO - 2016-09-14 06:23:17 --> Loader Class Initialized
INFO - 2016-09-14 06:23:17 --> Helper loaded: url_helper
INFO - 2016-09-14 06:23:17 --> Database Driver Class Initialized
INFO - 2016-09-14 06:23:17 --> Controller Class Initialized
DEBUG - 2016-09-14 06:23:17 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:23:17 --> Model Class Initialized
INFO - 2016-09-14 06:23:17 --> Model Class Initialized
DEBUG - 2016-09-14 06:23:17 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 06:23:17 --> Database Driver Class Initialized
INFO - 2016-09-14 06:23:17 --> Final output sent to browser
DEBUG - 2016-09-14 06:23:17 --> Total execution time: 0.5238
INFO - 2016-09-14 06:23:39 --> Config Class Initialized
INFO - 2016-09-14 06:23:39 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:23:39 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:23:39 --> Utf8 Class Initialized
INFO - 2016-09-14 06:23:39 --> URI Class Initialized
INFO - 2016-09-14 06:23:39 --> Router Class Initialized
INFO - 2016-09-14 06:23:40 --> Output Class Initialized
INFO - 2016-09-14 06:23:40 --> Security Class Initialized
DEBUG - 2016-09-14 06:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:23:40 --> Input Class Initialized
INFO - 2016-09-14 06:23:40 --> Language Class Initialized
INFO - 2016-09-14 06:23:40 --> Language Class Initialized
INFO - 2016-09-14 06:23:40 --> Config Class Initialized
INFO - 2016-09-14 06:23:40 --> Loader Class Initialized
INFO - 2016-09-14 06:23:40 --> Helper loaded: url_helper
INFO - 2016-09-14 06:23:40 --> Database Driver Class Initialized
INFO - 2016-09-14 06:23:40 --> Controller Class Initialized
DEBUG - 2016-09-14 06:23:40 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:23:40 --> Model Class Initialized
INFO - 2016-09-14 06:23:40 --> Model Class Initialized
DEBUG - 2016-09-14 06:23:40 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 06:23:40 --> Database Driver Class Initialized
ERROR - 2016-09-14 06:23:40 --> Query error: Table 'koperasi.tm_pinjama' doesn't exist - Invalid query: select * from tm_pinjama
                                                            inner join tm_anggota on tm_anggota.kd_anggota = tm_pinjaman.kd_anggota
                                                            where tm_pinjaman.`status` = '1'
                                                            and tm_anggota.no_identitas = '3573032002930011'
INFO - 2016-09-14 06:23:40 --> Language file loaded: language/english/db_lang.php
INFO - 2016-09-14 06:25:08 --> Config Class Initialized
INFO - 2016-09-14 06:25:08 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:25:08 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:25:08 --> Utf8 Class Initialized
INFO - 2016-09-14 06:25:08 --> URI Class Initialized
INFO - 2016-09-14 06:25:08 --> Router Class Initialized
INFO - 2016-09-14 06:25:08 --> Output Class Initialized
INFO - 2016-09-14 06:25:08 --> Security Class Initialized
DEBUG - 2016-09-14 06:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:25:08 --> Input Class Initialized
INFO - 2016-09-14 06:25:08 --> Language Class Initialized
INFO - 2016-09-14 06:25:08 --> Language Class Initialized
INFO - 2016-09-14 06:25:08 --> Config Class Initialized
INFO - 2016-09-14 06:25:08 --> Loader Class Initialized
INFO - 2016-09-14 06:25:08 --> Helper loaded: url_helper
INFO - 2016-09-14 06:25:08 --> Database Driver Class Initialized
INFO - 2016-09-14 06:25:08 --> Controller Class Initialized
DEBUG - 2016-09-14 06:25:09 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:25:09 --> Model Class Initialized
INFO - 2016-09-14 06:25:09 --> Model Class Initialized
DEBUG - 2016-09-14 06:25:09 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 06:25:09 --> Database Driver Class Initialized
ERROR - 2016-09-14 06:25:09 --> Query error: Table 'koperasi.tm_pinjama' doesn't exist - Invalid query: select * from tm_pinjama
                                                            inner join tm_anggota on tm_anggota.kd_anggota = tm_pinjaman.kd_anggota
                                                            where tm_pinjaman.`status` = '1'
                                                            and tm_anggota.no_identitas = '3573032002930011'
INFO - 2016-09-14 06:25:09 --> Language file loaded: language/english/db_lang.php
INFO - 2016-09-14 06:25:15 --> Config Class Initialized
INFO - 2016-09-14 06:25:15 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:25:15 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:25:15 --> Utf8 Class Initialized
INFO - 2016-09-14 06:25:15 --> URI Class Initialized
INFO - 2016-09-14 06:25:15 --> Router Class Initialized
INFO - 2016-09-14 06:25:15 --> Output Class Initialized
INFO - 2016-09-14 06:25:15 --> Security Class Initialized
DEBUG - 2016-09-14 06:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:25:15 --> Input Class Initialized
INFO - 2016-09-14 06:25:15 --> Language Class Initialized
INFO - 2016-09-14 06:25:15 --> Language Class Initialized
INFO - 2016-09-14 06:25:15 --> Config Class Initialized
INFO - 2016-09-14 06:25:15 --> Loader Class Initialized
INFO - 2016-09-14 06:25:15 --> Helper loaded: url_helper
INFO - 2016-09-14 06:25:15 --> Database Driver Class Initialized
INFO - 2016-09-14 06:25:15 --> Controller Class Initialized
DEBUG - 2016-09-14 06:25:15 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:25:15 --> Model Class Initialized
INFO - 2016-09-14 06:25:15 --> Model Class Initialized
DEBUG - 2016-09-14 06:25:15 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 06:25:15 --> Database Driver Class Initialized
INFO - 2016-09-14 06:25:15 --> Final output sent to browser
DEBUG - 2016-09-14 06:25:15 --> Total execution time: 0.6181
INFO - 2016-09-14 06:25:20 --> Config Class Initialized
INFO - 2016-09-14 06:25:20 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:25:20 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:25:20 --> Utf8 Class Initialized
INFO - 2016-09-14 06:25:20 --> URI Class Initialized
INFO - 2016-09-14 06:25:20 --> Router Class Initialized
INFO - 2016-09-14 06:25:20 --> Output Class Initialized
INFO - 2016-09-14 06:25:20 --> Security Class Initialized
DEBUG - 2016-09-14 06:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:25:20 --> Input Class Initialized
INFO - 2016-09-14 06:25:20 --> Language Class Initialized
INFO - 2016-09-14 06:25:20 --> Language Class Initialized
INFO - 2016-09-14 06:25:20 --> Config Class Initialized
INFO - 2016-09-14 06:25:21 --> Loader Class Initialized
INFO - 2016-09-14 06:25:21 --> Helper loaded: url_helper
INFO - 2016-09-14 06:25:21 --> Database Driver Class Initialized
INFO - 2016-09-14 06:25:21 --> Controller Class Initialized
DEBUG - 2016-09-14 06:25:21 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:25:21 --> Model Class Initialized
INFO - 2016-09-14 06:25:21 --> Model Class Initialized
DEBUG - 2016-09-14 06:25:21 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 06:25:21 --> Database Driver Class Initialized
INFO - 2016-09-14 06:25:21 --> Final output sent to browser
DEBUG - 2016-09-14 06:25:21 --> Total execution time: 0.6196
INFO - 2016-09-14 06:26:23 --> Config Class Initialized
INFO - 2016-09-14 06:26:23 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:26:23 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:26:23 --> Utf8 Class Initialized
INFO - 2016-09-14 06:26:23 --> URI Class Initialized
INFO - 2016-09-14 06:26:23 --> Router Class Initialized
INFO - 2016-09-14 06:26:23 --> Output Class Initialized
INFO - 2016-09-14 06:26:23 --> Security Class Initialized
DEBUG - 2016-09-14 06:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:26:23 --> Input Class Initialized
INFO - 2016-09-14 06:26:23 --> Language Class Initialized
INFO - 2016-09-14 06:26:23 --> Language Class Initialized
INFO - 2016-09-14 06:26:23 --> Config Class Initialized
INFO - 2016-09-14 06:26:23 --> Loader Class Initialized
INFO - 2016-09-14 06:26:23 --> Helper loaded: url_helper
INFO - 2016-09-14 06:26:23 --> Database Driver Class Initialized
INFO - 2016-09-14 06:26:23 --> Controller Class Initialized
DEBUG - 2016-09-14 06:26:23 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:26:23 --> Model Class Initialized
INFO - 2016-09-14 06:26:23 --> Model Class Initialized
DEBUG - 2016-09-14 06:26:23 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 06:26:23 --> Database Driver Class Initialized
INFO - 2016-09-14 06:26:23 --> Final output sent to browser
DEBUG - 2016-09-14 06:26:23 --> Total execution time: 0.6484
INFO - 2016-09-14 06:27:15 --> Config Class Initialized
INFO - 2016-09-14 06:27:15 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:27:15 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:27:15 --> Utf8 Class Initialized
INFO - 2016-09-14 06:27:15 --> URI Class Initialized
INFO - 2016-09-14 06:27:15 --> Router Class Initialized
INFO - 2016-09-14 06:27:15 --> Output Class Initialized
INFO - 2016-09-14 06:27:15 --> Security Class Initialized
DEBUG - 2016-09-14 06:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:27:15 --> Input Class Initialized
INFO - 2016-09-14 06:27:15 --> Language Class Initialized
INFO - 2016-09-14 06:27:15 --> Language Class Initialized
INFO - 2016-09-14 06:27:15 --> Config Class Initialized
INFO - 2016-09-14 06:27:15 --> Loader Class Initialized
INFO - 2016-09-14 06:27:15 --> Helper loaded: url_helper
INFO - 2016-09-14 06:27:15 --> Database Driver Class Initialized
INFO - 2016-09-14 06:27:15 --> Controller Class Initialized
DEBUG - 2016-09-14 06:27:15 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:27:15 --> Model Class Initialized
INFO - 2016-09-14 06:27:15 --> Model Class Initialized
DEBUG - 2016-09-14 06:27:15 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 06:27:15 --> Database Driver Class Initialized
INFO - 2016-09-14 06:27:15 --> Final output sent to browser
DEBUG - 2016-09-14 06:27:16 --> Total execution time: 0.5968
INFO - 2016-09-14 06:27:26 --> Config Class Initialized
INFO - 2016-09-14 06:27:26 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:27:26 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:27:26 --> Utf8 Class Initialized
INFO - 2016-09-14 06:27:26 --> URI Class Initialized
INFO - 2016-09-14 06:27:26 --> Router Class Initialized
INFO - 2016-09-14 06:27:26 --> Output Class Initialized
INFO - 2016-09-14 06:27:26 --> Security Class Initialized
DEBUG - 2016-09-14 06:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:27:26 --> Input Class Initialized
INFO - 2016-09-14 06:27:26 --> Language Class Initialized
INFO - 2016-09-14 06:27:26 --> Language Class Initialized
INFO - 2016-09-14 06:27:26 --> Config Class Initialized
INFO - 2016-09-14 06:27:26 --> Loader Class Initialized
INFO - 2016-09-14 06:27:26 --> Helper loaded: url_helper
INFO - 2016-09-14 06:27:26 --> Database Driver Class Initialized
INFO - 2016-09-14 06:27:26 --> Controller Class Initialized
DEBUG - 2016-09-14 06:27:27 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:27:27 --> Model Class Initialized
INFO - 2016-09-14 06:27:27 --> Model Class Initialized
DEBUG - 2016-09-14 06:27:27 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 06:27:27 --> Database Driver Class Initialized
INFO - 2016-09-14 06:27:27 --> Final output sent to browser
DEBUG - 2016-09-14 06:27:27 --> Total execution time: 0.6407
INFO - 2016-09-14 06:27:49 --> Config Class Initialized
INFO - 2016-09-14 06:27:49 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:27:49 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:27:50 --> Utf8 Class Initialized
INFO - 2016-09-14 06:27:50 --> URI Class Initialized
INFO - 2016-09-14 06:27:50 --> Router Class Initialized
INFO - 2016-09-14 06:27:50 --> Output Class Initialized
INFO - 2016-09-14 06:27:50 --> Security Class Initialized
DEBUG - 2016-09-14 06:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:27:50 --> Input Class Initialized
INFO - 2016-09-14 06:27:50 --> Language Class Initialized
INFO - 2016-09-14 06:27:50 --> Language Class Initialized
INFO - 2016-09-14 06:27:50 --> Config Class Initialized
INFO - 2016-09-14 06:27:50 --> Loader Class Initialized
INFO - 2016-09-14 06:27:50 --> Helper loaded: url_helper
INFO - 2016-09-14 06:27:50 --> Database Driver Class Initialized
INFO - 2016-09-14 06:27:50 --> Controller Class Initialized
DEBUG - 2016-09-14 06:27:50 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:27:50 --> Model Class Initialized
INFO - 2016-09-14 06:27:50 --> Model Class Initialized
DEBUG - 2016-09-14 06:27:50 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 06:27:50 --> Database Driver Class Initialized
INFO - 2016-09-14 06:27:50 --> Final output sent to browser
DEBUG - 2016-09-14 06:27:50 --> Total execution time: 0.6022
INFO - 2016-09-14 06:27:59 --> Config Class Initialized
INFO - 2016-09-14 06:27:59 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:27:59 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:27:59 --> Utf8 Class Initialized
INFO - 2016-09-14 06:27:59 --> URI Class Initialized
INFO - 2016-09-14 06:27:59 --> Router Class Initialized
INFO - 2016-09-14 06:27:59 --> Output Class Initialized
INFO - 2016-09-14 06:27:59 --> Security Class Initialized
DEBUG - 2016-09-14 06:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:27:59 --> Input Class Initialized
INFO - 2016-09-14 06:27:59 --> Language Class Initialized
INFO - 2016-09-14 06:27:59 --> Language Class Initialized
INFO - 2016-09-14 06:27:59 --> Config Class Initialized
INFO - 2016-09-14 06:27:59 --> Loader Class Initialized
INFO - 2016-09-14 06:27:59 --> Helper loaded: url_helper
INFO - 2016-09-14 06:27:59 --> Database Driver Class Initialized
INFO - 2016-09-14 06:27:59 --> Controller Class Initialized
DEBUG - 2016-09-14 06:27:59 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:27:59 --> Model Class Initialized
INFO - 2016-09-14 06:27:59 --> Model Class Initialized
DEBUG - 2016-09-14 06:27:59 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 06:27:59 --> Database Driver Class Initialized
INFO - 2016-09-14 06:27:59 --> Final output sent to browser
DEBUG - 2016-09-14 06:27:59 --> Total execution time: 0.5509
INFO - 2016-09-14 06:28:10 --> Config Class Initialized
INFO - 2016-09-14 06:28:10 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:28:10 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:28:10 --> Utf8 Class Initialized
INFO - 2016-09-14 06:28:10 --> URI Class Initialized
INFO - 2016-09-14 06:28:10 --> Router Class Initialized
INFO - 2016-09-14 06:28:10 --> Output Class Initialized
INFO - 2016-09-14 06:28:10 --> Security Class Initialized
DEBUG - 2016-09-14 06:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:28:10 --> Input Class Initialized
INFO - 2016-09-14 06:28:10 --> Language Class Initialized
INFO - 2016-09-14 06:28:10 --> Language Class Initialized
INFO - 2016-09-14 06:28:10 --> Config Class Initialized
INFO - 2016-09-14 06:28:10 --> Loader Class Initialized
INFO - 2016-09-14 06:28:10 --> Helper loaded: url_helper
INFO - 2016-09-14 06:28:11 --> Database Driver Class Initialized
INFO - 2016-09-14 06:28:11 --> Controller Class Initialized
DEBUG - 2016-09-14 06:28:11 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:28:11 --> Model Class Initialized
INFO - 2016-09-14 06:28:11 --> Model Class Initialized
DEBUG - 2016-09-14 06:28:11 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 06:28:11 --> Final output sent to browser
DEBUG - 2016-09-14 06:28:11 --> Total execution time: 0.5298
INFO - 2016-09-14 06:28:42 --> Config Class Initialized
INFO - 2016-09-14 06:28:42 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:28:42 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:28:42 --> Utf8 Class Initialized
INFO - 2016-09-14 06:28:42 --> URI Class Initialized
INFO - 2016-09-14 06:28:42 --> Router Class Initialized
INFO - 2016-09-14 06:28:42 --> Output Class Initialized
INFO - 2016-09-14 06:28:42 --> Security Class Initialized
DEBUG - 2016-09-14 06:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:28:42 --> Input Class Initialized
INFO - 2016-09-14 06:28:42 --> Language Class Initialized
INFO - 2016-09-14 06:28:42 --> Language Class Initialized
INFO - 2016-09-14 06:28:42 --> Config Class Initialized
INFO - 2016-09-14 06:28:42 --> Loader Class Initialized
INFO - 2016-09-14 06:28:42 --> Helper loaded: url_helper
INFO - 2016-09-14 06:28:42 --> Database Driver Class Initialized
INFO - 2016-09-14 06:28:42 --> Controller Class Initialized
DEBUG - 2016-09-14 06:28:42 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:28:42 --> Model Class Initialized
INFO - 2016-09-14 06:28:42 --> Model Class Initialized
DEBUG - 2016-09-14 06:28:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 06:28:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 06:28:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 06:28:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-14 06:28:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 06:28:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 06:28:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 06:28:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 06:28:43 --> Final output sent to browser
DEBUG - 2016-09-14 06:28:43 --> Total execution time: 0.6901
INFO - 2016-09-14 06:28:53 --> Config Class Initialized
INFO - 2016-09-14 06:28:53 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:28:53 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:28:53 --> Utf8 Class Initialized
INFO - 2016-09-14 06:28:53 --> URI Class Initialized
INFO - 2016-09-14 06:28:53 --> Router Class Initialized
INFO - 2016-09-14 06:28:53 --> Output Class Initialized
INFO - 2016-09-14 06:28:53 --> Security Class Initialized
DEBUG - 2016-09-14 06:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:28:53 --> Input Class Initialized
INFO - 2016-09-14 06:28:53 --> Language Class Initialized
INFO - 2016-09-14 06:28:54 --> Language Class Initialized
INFO - 2016-09-14 06:28:54 --> Config Class Initialized
INFO - 2016-09-14 06:28:54 --> Loader Class Initialized
INFO - 2016-09-14 06:28:54 --> Helper loaded: url_helper
INFO - 2016-09-14 06:28:54 --> Database Driver Class Initialized
INFO - 2016-09-14 06:28:54 --> Controller Class Initialized
DEBUG - 2016-09-14 06:28:54 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:28:54 --> Model Class Initialized
INFO - 2016-09-14 06:28:54 --> Model Class Initialized
DEBUG - 2016-09-14 06:28:54 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 06:28:54 --> Final output sent to browser
DEBUG - 2016-09-14 06:28:54 --> Total execution time: 0.5109
INFO - 2016-09-14 06:28:59 --> Config Class Initialized
INFO - 2016-09-14 06:28:59 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:28:59 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:28:59 --> Utf8 Class Initialized
INFO - 2016-09-14 06:28:59 --> URI Class Initialized
INFO - 2016-09-14 06:28:59 --> Router Class Initialized
INFO - 2016-09-14 06:28:59 --> Output Class Initialized
INFO - 2016-09-14 06:28:59 --> Security Class Initialized
DEBUG - 2016-09-14 06:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:28:59 --> Input Class Initialized
INFO - 2016-09-14 06:28:59 --> Language Class Initialized
INFO - 2016-09-14 06:28:59 --> Language Class Initialized
INFO - 2016-09-14 06:28:59 --> Config Class Initialized
INFO - 2016-09-14 06:28:59 --> Loader Class Initialized
INFO - 2016-09-14 06:28:59 --> Helper loaded: url_helper
INFO - 2016-09-14 06:28:59 --> Database Driver Class Initialized
INFO - 2016-09-14 06:28:59 --> Controller Class Initialized
DEBUG - 2016-09-14 06:28:59 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:28:59 --> Model Class Initialized
INFO - 2016-09-14 06:28:59 --> Model Class Initialized
DEBUG - 2016-09-14 06:28:59 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 06:28:59 --> Database Driver Class Initialized
INFO - 2016-09-14 06:28:59 --> Final output sent to browser
DEBUG - 2016-09-14 06:28:59 --> Total execution time: 0.5585
INFO - 2016-09-14 06:29:04 --> Config Class Initialized
INFO - 2016-09-14 06:29:04 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:29:04 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:29:04 --> Utf8 Class Initialized
INFO - 2016-09-14 06:29:04 --> URI Class Initialized
INFO - 2016-09-14 06:29:04 --> Router Class Initialized
INFO - 2016-09-14 06:29:04 --> Output Class Initialized
INFO - 2016-09-14 06:29:04 --> Security Class Initialized
DEBUG - 2016-09-14 06:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:29:04 --> Input Class Initialized
INFO - 2016-09-14 06:29:04 --> Language Class Initialized
INFO - 2016-09-14 06:29:04 --> Language Class Initialized
INFO - 2016-09-14 06:29:04 --> Config Class Initialized
INFO - 2016-09-14 06:29:04 --> Loader Class Initialized
INFO - 2016-09-14 06:29:04 --> Helper loaded: url_helper
INFO - 2016-09-14 06:29:04 --> Database Driver Class Initialized
INFO - 2016-09-14 06:29:04 --> Controller Class Initialized
DEBUG - 2016-09-14 06:29:04 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:29:04 --> Model Class Initialized
INFO - 2016-09-14 06:29:04 --> Model Class Initialized
DEBUG - 2016-09-14 06:29:04 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 06:29:04 --> Database Driver Class Initialized
INFO - 2016-09-14 06:29:04 --> Final output sent to browser
DEBUG - 2016-09-14 06:29:05 --> Total execution time: 0.5634
INFO - 2016-09-14 06:29:09 --> Config Class Initialized
INFO - 2016-09-14 06:29:09 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:29:09 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:29:09 --> Utf8 Class Initialized
INFO - 2016-09-14 06:29:09 --> URI Class Initialized
INFO - 2016-09-14 06:29:09 --> Router Class Initialized
INFO - 2016-09-14 06:29:09 --> Output Class Initialized
INFO - 2016-09-14 06:29:09 --> Security Class Initialized
DEBUG - 2016-09-14 06:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:29:10 --> Input Class Initialized
INFO - 2016-09-14 06:29:10 --> Language Class Initialized
INFO - 2016-09-14 06:29:10 --> Language Class Initialized
INFO - 2016-09-14 06:29:10 --> Config Class Initialized
INFO - 2016-09-14 06:29:10 --> Loader Class Initialized
INFO - 2016-09-14 06:29:10 --> Helper loaded: url_helper
INFO - 2016-09-14 06:29:10 --> Database Driver Class Initialized
INFO - 2016-09-14 06:29:10 --> Controller Class Initialized
DEBUG - 2016-09-14 06:29:10 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:29:10 --> Model Class Initialized
INFO - 2016-09-14 06:29:10 --> Model Class Initialized
DEBUG - 2016-09-14 06:29:10 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 06:29:10 --> Database Driver Class Initialized
INFO - 2016-09-14 06:29:10 --> Final output sent to browser
DEBUG - 2016-09-14 06:29:10 --> Total execution time: 0.5396
INFO - 2016-09-14 06:32:24 --> Config Class Initialized
INFO - 2016-09-14 06:32:24 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:32:24 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:32:25 --> Utf8 Class Initialized
INFO - 2016-09-14 06:32:25 --> URI Class Initialized
INFO - 2016-09-14 06:32:25 --> Router Class Initialized
INFO - 2016-09-14 06:32:25 --> Output Class Initialized
INFO - 2016-09-14 06:32:25 --> Security Class Initialized
DEBUG - 2016-09-14 06:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:32:25 --> Input Class Initialized
INFO - 2016-09-14 06:32:25 --> Language Class Initialized
INFO - 2016-09-14 06:32:25 --> Language Class Initialized
INFO - 2016-09-14 06:32:25 --> Config Class Initialized
INFO - 2016-09-14 06:32:25 --> Loader Class Initialized
INFO - 2016-09-14 06:32:25 --> Helper loaded: url_helper
INFO - 2016-09-14 06:32:25 --> Database Driver Class Initialized
INFO - 2016-09-14 06:32:25 --> Controller Class Initialized
DEBUG - 2016-09-14 06:32:25 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:32:25 --> Model Class Initialized
INFO - 2016-09-14 06:32:25 --> Model Class Initialized
DEBUG - 2016-09-14 06:32:25 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 06:32:25 --> Database Driver Class Initialized
INFO - 2016-09-14 06:32:25 --> Final output sent to browser
DEBUG - 2016-09-14 06:32:25 --> Total execution time: 0.5225
INFO - 2016-09-14 06:40:23 --> Config Class Initialized
INFO - 2016-09-14 06:40:23 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:40:23 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:40:23 --> Utf8 Class Initialized
INFO - 2016-09-14 06:40:23 --> URI Class Initialized
INFO - 2016-09-14 06:40:23 --> Router Class Initialized
INFO - 2016-09-14 06:40:23 --> Output Class Initialized
INFO - 2016-09-14 06:40:23 --> Security Class Initialized
DEBUG - 2016-09-14 06:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:40:23 --> Input Class Initialized
INFO - 2016-09-14 06:40:23 --> Language Class Initialized
INFO - 2016-09-14 06:40:23 --> Language Class Initialized
INFO - 2016-09-14 06:40:23 --> Config Class Initialized
INFO - 2016-09-14 06:40:23 --> Loader Class Initialized
INFO - 2016-09-14 06:40:23 --> Helper loaded: url_helper
INFO - 2016-09-14 06:40:23 --> Database Driver Class Initialized
INFO - 2016-09-14 06:40:23 --> Controller Class Initialized
DEBUG - 2016-09-14 06:40:23 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:40:23 --> Model Class Initialized
INFO - 2016-09-14 06:40:23 --> Model Class Initialized
DEBUG - 2016-09-14 06:40:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 06:40:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 06:40:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 06:40:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-14 06:40:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 06:40:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 06:40:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 06:40:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 06:40:23 --> Final output sent to browser
DEBUG - 2016-09-14 06:40:24 --> Total execution time: 0.8437
INFO - 2016-09-14 06:40:37 --> Config Class Initialized
INFO - 2016-09-14 06:40:37 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:40:37 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:40:37 --> Utf8 Class Initialized
INFO - 2016-09-14 06:40:37 --> URI Class Initialized
INFO - 2016-09-14 06:40:37 --> Router Class Initialized
INFO - 2016-09-14 06:40:37 --> Output Class Initialized
INFO - 2016-09-14 06:40:37 --> Security Class Initialized
DEBUG - 2016-09-14 06:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:40:37 --> Input Class Initialized
INFO - 2016-09-14 06:40:37 --> Language Class Initialized
INFO - 2016-09-14 06:40:37 --> Language Class Initialized
INFO - 2016-09-14 06:40:37 --> Config Class Initialized
INFO - 2016-09-14 06:40:37 --> Loader Class Initialized
INFO - 2016-09-14 06:40:38 --> Helper loaded: url_helper
INFO - 2016-09-14 06:40:38 --> Database Driver Class Initialized
INFO - 2016-09-14 06:40:38 --> Controller Class Initialized
DEBUG - 2016-09-14 06:40:38 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:40:38 --> Model Class Initialized
INFO - 2016-09-14 06:40:38 --> Model Class Initialized
DEBUG - 2016-09-14 06:40:38 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 06:40:38 --> Database Driver Class Initialized
INFO - 2016-09-14 06:40:38 --> Final output sent to browser
DEBUG - 2016-09-14 06:40:38 --> Total execution time: 0.5683
INFO - 2016-09-14 06:40:39 --> Config Class Initialized
INFO - 2016-09-14 06:40:39 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:40:39 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:40:39 --> Utf8 Class Initialized
INFO - 2016-09-14 06:40:39 --> URI Class Initialized
INFO - 2016-09-14 06:40:39 --> Router Class Initialized
INFO - 2016-09-14 06:40:39 --> Output Class Initialized
INFO - 2016-09-14 06:40:39 --> Security Class Initialized
DEBUG - 2016-09-14 06:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:40:39 --> Input Class Initialized
INFO - 2016-09-14 06:40:39 --> Language Class Initialized
ERROR - 2016-09-14 06:40:39 --> 404 Page Not Found: /index
INFO - 2016-09-14 06:40:50 --> Config Class Initialized
INFO - 2016-09-14 06:40:50 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:40:51 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:40:51 --> Utf8 Class Initialized
INFO - 2016-09-14 06:40:51 --> URI Class Initialized
INFO - 2016-09-14 06:40:51 --> Router Class Initialized
INFO - 2016-09-14 06:40:51 --> Output Class Initialized
INFO - 2016-09-14 06:40:51 --> Security Class Initialized
DEBUG - 2016-09-14 06:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:40:51 --> Input Class Initialized
INFO - 2016-09-14 06:40:51 --> Language Class Initialized
INFO - 2016-09-14 06:40:51 --> Language Class Initialized
INFO - 2016-09-14 06:40:51 --> Config Class Initialized
INFO - 2016-09-14 06:40:51 --> Loader Class Initialized
INFO - 2016-09-14 06:40:51 --> Helper loaded: url_helper
INFO - 2016-09-14 06:40:51 --> Database Driver Class Initialized
INFO - 2016-09-14 06:40:51 --> Controller Class Initialized
DEBUG - 2016-09-14 06:40:51 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:40:51 --> Model Class Initialized
INFO - 2016-09-14 06:40:51 --> Model Class Initialized
DEBUG - 2016-09-14 06:40:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 06:40:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 06:40:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 06:40:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-14 06:40:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 06:40:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 06:40:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 06:40:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 06:40:51 --> Final output sent to browser
DEBUG - 2016-09-14 06:40:51 --> Total execution time: 0.7177
INFO - 2016-09-14 06:41:05 --> Config Class Initialized
INFO - 2016-09-14 06:41:05 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:41:05 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:41:05 --> Utf8 Class Initialized
INFO - 2016-09-14 06:41:05 --> URI Class Initialized
INFO - 2016-09-14 06:41:05 --> Router Class Initialized
INFO - 2016-09-14 06:41:05 --> Output Class Initialized
INFO - 2016-09-14 06:41:05 --> Security Class Initialized
DEBUG - 2016-09-14 06:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:41:05 --> Input Class Initialized
INFO - 2016-09-14 06:41:05 --> Language Class Initialized
INFO - 2016-09-14 06:41:05 --> Language Class Initialized
INFO - 2016-09-14 06:41:05 --> Config Class Initialized
INFO - 2016-09-14 06:41:05 --> Loader Class Initialized
INFO - 2016-09-14 06:41:05 --> Helper loaded: url_helper
INFO - 2016-09-14 06:41:05 --> Database Driver Class Initialized
INFO - 2016-09-14 06:41:05 --> Controller Class Initialized
DEBUG - 2016-09-14 06:41:05 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:41:05 --> Model Class Initialized
INFO - 2016-09-14 06:41:05 --> Model Class Initialized
DEBUG - 2016-09-14 06:41:05 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 06:41:05 --> Database Driver Class Initialized
INFO - 2016-09-14 06:41:05 --> Final output sent to browser
DEBUG - 2016-09-14 06:41:05 --> Total execution time: 0.5953
INFO - 2016-09-14 06:41:06 --> Config Class Initialized
INFO - 2016-09-14 06:41:06 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:41:06 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:41:06 --> Utf8 Class Initialized
INFO - 2016-09-14 06:41:06 --> URI Class Initialized
INFO - 2016-09-14 06:41:06 --> Router Class Initialized
INFO - 2016-09-14 06:41:06 --> Output Class Initialized
INFO - 2016-09-14 06:41:06 --> Security Class Initialized
DEBUG - 2016-09-14 06:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:41:06 --> Input Class Initialized
INFO - 2016-09-14 06:41:06 --> Language Class Initialized
INFO - 2016-09-14 06:41:06 --> Language Class Initialized
INFO - 2016-09-14 06:41:06 --> Config Class Initialized
INFO - 2016-09-14 06:41:06 --> Loader Class Initialized
INFO - 2016-09-14 06:41:06 --> Helper loaded: url_helper
INFO - 2016-09-14 06:41:06 --> Database Driver Class Initialized
INFO - 2016-09-14 06:41:06 --> Controller Class Initialized
DEBUG - 2016-09-14 06:41:06 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:41:06 --> Model Class Initialized
INFO - 2016-09-14 06:41:06 --> Model Class Initialized
INFO - 2016-09-14 06:41:06 --> Final output sent to browser
DEBUG - 2016-09-14 06:41:07 --> Total execution time: 0.5205
INFO - 2016-09-14 06:41:15 --> Config Class Initialized
INFO - 2016-09-14 06:41:15 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:41:15 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:41:15 --> Utf8 Class Initialized
INFO - 2016-09-14 06:41:15 --> URI Class Initialized
INFO - 2016-09-14 06:41:15 --> Router Class Initialized
INFO - 2016-09-14 06:41:15 --> Output Class Initialized
INFO - 2016-09-14 06:41:15 --> Security Class Initialized
DEBUG - 2016-09-14 06:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:41:15 --> Input Class Initialized
INFO - 2016-09-14 06:41:15 --> Language Class Initialized
INFO - 2016-09-14 06:41:15 --> Language Class Initialized
INFO - 2016-09-14 06:41:15 --> Config Class Initialized
INFO - 2016-09-14 06:41:15 --> Loader Class Initialized
INFO - 2016-09-14 06:41:15 --> Helper loaded: url_helper
INFO - 2016-09-14 06:41:15 --> Database Driver Class Initialized
INFO - 2016-09-14 06:41:15 --> Controller Class Initialized
DEBUG - 2016-09-14 06:41:15 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:41:15 --> Model Class Initialized
INFO - 2016-09-14 06:41:15 --> Model Class Initialized
INFO - 2016-09-14 06:41:15 --> Final output sent to browser
DEBUG - 2016-09-14 06:41:15 --> Total execution time: 0.5297
INFO - 2016-09-14 06:42:04 --> Config Class Initialized
INFO - 2016-09-14 06:42:04 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:42:04 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:42:04 --> Utf8 Class Initialized
INFO - 2016-09-14 06:42:04 --> URI Class Initialized
INFO - 2016-09-14 06:42:04 --> Router Class Initialized
INFO - 2016-09-14 06:42:04 --> Output Class Initialized
INFO - 2016-09-14 06:42:04 --> Security Class Initialized
DEBUG - 2016-09-14 06:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:42:04 --> Input Class Initialized
INFO - 2016-09-14 06:42:04 --> Language Class Initialized
INFO - 2016-09-14 06:42:04 --> Language Class Initialized
INFO - 2016-09-14 06:42:04 --> Config Class Initialized
INFO - 2016-09-14 06:42:04 --> Loader Class Initialized
INFO - 2016-09-14 06:42:04 --> Helper loaded: url_helper
INFO - 2016-09-14 06:42:04 --> Database Driver Class Initialized
INFO - 2016-09-14 06:42:04 --> Controller Class Initialized
DEBUG - 2016-09-14 06:42:04 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:42:04 --> Model Class Initialized
INFO - 2016-09-14 06:42:04 --> Model Class Initialized
DEBUG - 2016-09-14 06:42:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 06:42:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 06:42:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 06:42:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-14 06:42:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 06:42:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 06:42:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 06:42:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 06:42:04 --> Final output sent to browser
DEBUG - 2016-09-14 06:42:04 --> Total execution time: 0.7938
INFO - 2016-09-14 06:42:09 --> Config Class Initialized
INFO - 2016-09-14 06:42:09 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:42:09 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:42:09 --> Utf8 Class Initialized
INFO - 2016-09-14 06:42:09 --> URI Class Initialized
INFO - 2016-09-14 06:42:09 --> Router Class Initialized
INFO - 2016-09-14 06:42:09 --> Output Class Initialized
INFO - 2016-09-14 06:42:09 --> Security Class Initialized
DEBUG - 2016-09-14 06:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:42:09 --> Input Class Initialized
INFO - 2016-09-14 06:42:09 --> Language Class Initialized
INFO - 2016-09-14 06:42:09 --> Language Class Initialized
INFO - 2016-09-14 06:42:09 --> Config Class Initialized
INFO - 2016-09-14 06:42:09 --> Loader Class Initialized
INFO - 2016-09-14 06:42:09 --> Helper loaded: url_helper
INFO - 2016-09-14 06:42:09 --> Database Driver Class Initialized
INFO - 2016-09-14 06:42:10 --> Controller Class Initialized
DEBUG - 2016-09-14 06:42:10 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:42:10 --> Model Class Initialized
INFO - 2016-09-14 06:42:10 --> Model Class Initialized
DEBUG - 2016-09-14 06:42:10 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 06:42:10 --> Database Driver Class Initialized
INFO - 2016-09-14 06:42:10 --> Final output sent to browser
DEBUG - 2016-09-14 06:42:10 --> Total execution time: 0.5688
INFO - 2016-09-14 06:42:10 --> Config Class Initialized
INFO - 2016-09-14 06:42:10 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:42:10 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:42:11 --> Utf8 Class Initialized
INFO - 2016-09-14 06:42:11 --> URI Class Initialized
INFO - 2016-09-14 06:42:11 --> Router Class Initialized
INFO - 2016-09-14 06:42:11 --> Output Class Initialized
INFO - 2016-09-14 06:42:11 --> Security Class Initialized
DEBUG - 2016-09-14 06:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:42:11 --> Input Class Initialized
INFO - 2016-09-14 06:42:11 --> Language Class Initialized
INFO - 2016-09-14 06:42:11 --> Language Class Initialized
INFO - 2016-09-14 06:42:11 --> Config Class Initialized
INFO - 2016-09-14 06:42:11 --> Loader Class Initialized
INFO - 2016-09-14 06:42:11 --> Helper loaded: url_helper
INFO - 2016-09-14 06:42:11 --> Database Driver Class Initialized
INFO - 2016-09-14 06:42:11 --> Controller Class Initialized
DEBUG - 2016-09-14 06:42:11 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:42:11 --> Model Class Initialized
INFO - 2016-09-14 06:42:11 --> Model Class Initialized
INFO - 2016-09-14 06:42:11 --> Final output sent to browser
DEBUG - 2016-09-14 06:42:11 --> Total execution time: 0.5431
INFO - 2016-09-14 06:42:15 --> Config Class Initialized
INFO - 2016-09-14 06:42:15 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:42:15 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:42:15 --> Utf8 Class Initialized
INFO - 2016-09-14 06:42:15 --> URI Class Initialized
INFO - 2016-09-14 06:42:15 --> Router Class Initialized
INFO - 2016-09-14 06:42:15 --> Output Class Initialized
INFO - 2016-09-14 06:42:15 --> Security Class Initialized
DEBUG - 2016-09-14 06:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:42:15 --> Input Class Initialized
INFO - 2016-09-14 06:42:15 --> Language Class Initialized
INFO - 2016-09-14 06:42:15 --> Language Class Initialized
INFO - 2016-09-14 06:42:15 --> Config Class Initialized
INFO - 2016-09-14 06:42:15 --> Loader Class Initialized
INFO - 2016-09-14 06:42:15 --> Helper loaded: url_helper
INFO - 2016-09-14 06:42:15 --> Database Driver Class Initialized
INFO - 2016-09-14 06:42:15 --> Controller Class Initialized
DEBUG - 2016-09-14 06:42:15 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:42:15 --> Model Class Initialized
INFO - 2016-09-14 06:42:15 --> Model Class Initialized
ERROR - 2016-09-14 06:42:15 --> Severity: Notice --> Undefined index: type E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 125
INFO - 2016-09-14 06:42:15 --> Final output sent to browser
DEBUG - 2016-09-14 06:42:15 --> Total execution time: 0.6179
INFO - 2016-09-14 06:42:39 --> Config Class Initialized
INFO - 2016-09-14 06:42:39 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:42:39 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:42:39 --> Utf8 Class Initialized
INFO - 2016-09-14 06:42:39 --> URI Class Initialized
INFO - 2016-09-14 06:42:39 --> Router Class Initialized
INFO - 2016-09-14 06:42:39 --> Output Class Initialized
INFO - 2016-09-14 06:42:39 --> Security Class Initialized
DEBUG - 2016-09-14 06:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:42:39 --> Input Class Initialized
INFO - 2016-09-14 06:42:39 --> Language Class Initialized
ERROR - 2016-09-14 06:42:39 --> Severity: Parsing Error --> syntax error, unexpected '{' E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 125
INFO - 2016-09-14 06:42:48 --> Config Class Initialized
INFO - 2016-09-14 06:42:48 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:42:48 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:42:48 --> Utf8 Class Initialized
INFO - 2016-09-14 06:42:48 --> URI Class Initialized
INFO - 2016-09-14 06:42:48 --> Router Class Initialized
INFO - 2016-09-14 06:42:48 --> Output Class Initialized
INFO - 2016-09-14 06:42:48 --> Security Class Initialized
DEBUG - 2016-09-14 06:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:42:48 --> Input Class Initialized
INFO - 2016-09-14 06:42:48 --> Language Class Initialized
INFO - 2016-09-14 06:42:48 --> Language Class Initialized
INFO - 2016-09-14 06:42:48 --> Config Class Initialized
INFO - 2016-09-14 06:42:48 --> Loader Class Initialized
INFO - 2016-09-14 06:42:48 --> Helper loaded: url_helper
INFO - 2016-09-14 06:42:48 --> Database Driver Class Initialized
INFO - 2016-09-14 06:42:48 --> Controller Class Initialized
DEBUG - 2016-09-14 06:42:48 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:42:48 --> Model Class Initialized
INFO - 2016-09-14 06:42:48 --> Model Class Initialized
INFO - 2016-09-14 06:42:48 --> Final output sent to browser
DEBUG - 2016-09-14 06:42:48 --> Total execution time: 0.5558
INFO - 2016-09-14 06:42:52 --> Config Class Initialized
INFO - 2016-09-14 06:42:52 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:42:52 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:42:52 --> Utf8 Class Initialized
INFO - 2016-09-14 06:42:52 --> URI Class Initialized
INFO - 2016-09-14 06:42:52 --> Router Class Initialized
INFO - 2016-09-14 06:42:52 --> Output Class Initialized
INFO - 2016-09-14 06:42:52 --> Security Class Initialized
DEBUG - 2016-09-14 06:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:42:52 --> Input Class Initialized
INFO - 2016-09-14 06:42:52 --> Language Class Initialized
INFO - 2016-09-14 06:42:52 --> Language Class Initialized
INFO - 2016-09-14 06:42:52 --> Config Class Initialized
INFO - 2016-09-14 06:42:52 --> Loader Class Initialized
INFO - 2016-09-14 06:42:52 --> Helper loaded: url_helper
INFO - 2016-09-14 06:42:52 --> Database Driver Class Initialized
INFO - 2016-09-14 06:42:52 --> Controller Class Initialized
DEBUG - 2016-09-14 06:42:52 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:42:52 --> Model Class Initialized
INFO - 2016-09-14 06:42:52 --> Model Class Initialized
INFO - 2016-09-14 06:42:52 --> Final output sent to browser
DEBUG - 2016-09-14 06:42:52 --> Total execution time: 0.6482
INFO - 2016-09-14 06:44:04 --> Config Class Initialized
INFO - 2016-09-14 06:44:04 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:44:04 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:44:04 --> Utf8 Class Initialized
INFO - 2016-09-14 06:44:04 --> URI Class Initialized
INFO - 2016-09-14 06:44:04 --> Router Class Initialized
INFO - 2016-09-14 06:44:04 --> Output Class Initialized
INFO - 2016-09-14 06:44:04 --> Security Class Initialized
DEBUG - 2016-09-14 06:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:44:04 --> Input Class Initialized
INFO - 2016-09-14 06:44:04 --> Language Class Initialized
INFO - 2016-09-14 06:44:04 --> Language Class Initialized
INFO - 2016-09-14 06:44:04 --> Config Class Initialized
INFO - 2016-09-14 06:44:04 --> Loader Class Initialized
INFO - 2016-09-14 06:44:04 --> Helper loaded: url_helper
INFO - 2016-09-14 06:44:04 --> Database Driver Class Initialized
INFO - 2016-09-14 06:44:04 --> Controller Class Initialized
DEBUG - 2016-09-14 06:44:04 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:44:04 --> Model Class Initialized
INFO - 2016-09-14 06:44:04 --> Model Class Initialized
DEBUG - 2016-09-14 06:44:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 06:44:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 06:44:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 06:44:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-14 06:44:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 06:44:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 06:44:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 06:44:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 06:44:05 --> Final output sent to browser
DEBUG - 2016-09-14 06:44:05 --> Total execution time: 0.7455
INFO - 2016-09-14 06:44:11 --> Config Class Initialized
INFO - 2016-09-14 06:44:11 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:44:11 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:44:11 --> Utf8 Class Initialized
INFO - 2016-09-14 06:44:11 --> URI Class Initialized
INFO - 2016-09-14 06:44:11 --> Router Class Initialized
INFO - 2016-09-14 06:44:11 --> Output Class Initialized
INFO - 2016-09-14 06:44:11 --> Security Class Initialized
DEBUG - 2016-09-14 06:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:44:11 --> Input Class Initialized
INFO - 2016-09-14 06:44:11 --> Language Class Initialized
INFO - 2016-09-14 06:44:12 --> Language Class Initialized
INFO - 2016-09-14 06:44:12 --> Config Class Initialized
INFO - 2016-09-14 06:44:12 --> Loader Class Initialized
INFO - 2016-09-14 06:44:12 --> Helper loaded: url_helper
INFO - 2016-09-14 06:44:12 --> Database Driver Class Initialized
INFO - 2016-09-14 06:44:12 --> Controller Class Initialized
DEBUG - 2016-09-14 06:44:12 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:44:12 --> Model Class Initialized
INFO - 2016-09-14 06:44:12 --> Model Class Initialized
DEBUG - 2016-09-14 06:44:12 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 06:44:12 --> Database Driver Class Initialized
INFO - 2016-09-14 06:44:12 --> Final output sent to browser
DEBUG - 2016-09-14 06:44:12 --> Total execution time: 0.5647
INFO - 2016-09-14 06:44:13 --> Config Class Initialized
INFO - 2016-09-14 06:44:13 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:44:13 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:44:13 --> Utf8 Class Initialized
INFO - 2016-09-14 06:44:13 --> URI Class Initialized
INFO - 2016-09-14 06:44:13 --> Router Class Initialized
INFO - 2016-09-14 06:44:13 --> Output Class Initialized
INFO - 2016-09-14 06:44:13 --> Security Class Initialized
DEBUG - 2016-09-14 06:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:44:13 --> Input Class Initialized
INFO - 2016-09-14 06:44:13 --> Language Class Initialized
INFO - 2016-09-14 06:44:13 --> Language Class Initialized
INFO - 2016-09-14 06:44:13 --> Config Class Initialized
INFO - 2016-09-14 06:44:13 --> Loader Class Initialized
INFO - 2016-09-14 06:44:13 --> Helper loaded: url_helper
INFO - 2016-09-14 06:44:13 --> Database Driver Class Initialized
INFO - 2016-09-14 06:44:13 --> Controller Class Initialized
DEBUG - 2016-09-14 06:44:13 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:44:13 --> Model Class Initialized
INFO - 2016-09-14 06:44:13 --> Model Class Initialized
DEBUG - 2016-09-14 06:44:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 06:44:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 06:44:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 06:44:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-09-14 06:44:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 06:44:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 06:44:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 06:44:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 06:44:14 --> Final output sent to browser
DEBUG - 2016-09-14 06:44:14 --> Total execution time: 0.7061
INFO - 2016-09-14 06:44:23 --> Config Class Initialized
INFO - 2016-09-14 06:44:23 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:44:23 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:44:23 --> Utf8 Class Initialized
INFO - 2016-09-14 06:44:23 --> URI Class Initialized
INFO - 2016-09-14 06:44:23 --> Router Class Initialized
INFO - 2016-09-14 06:44:23 --> Output Class Initialized
INFO - 2016-09-14 06:44:23 --> Security Class Initialized
DEBUG - 2016-09-14 06:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:44:23 --> Input Class Initialized
INFO - 2016-09-14 06:44:23 --> Language Class Initialized
INFO - 2016-09-14 06:44:23 --> Language Class Initialized
INFO - 2016-09-14 06:44:23 --> Config Class Initialized
INFO - 2016-09-14 06:44:23 --> Loader Class Initialized
INFO - 2016-09-14 06:44:23 --> Helper loaded: url_helper
INFO - 2016-09-14 06:44:23 --> Database Driver Class Initialized
INFO - 2016-09-14 06:44:23 --> Controller Class Initialized
DEBUG - 2016-09-14 06:44:23 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:44:23 --> Model Class Initialized
INFO - 2016-09-14 06:44:23 --> Model Class Initialized
DEBUG - 2016-09-14 06:44:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 06:44:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 06:44:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 06:44:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_umum.php
DEBUG - 2016-09-14 06:44:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 06:44:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 06:44:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 06:44:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 06:44:23 --> Final output sent to browser
DEBUG - 2016-09-14 06:44:23 --> Total execution time: 0.8648
INFO - 2016-09-14 06:45:44 --> Config Class Initialized
INFO - 2016-09-14 06:45:44 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:45:44 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:45:44 --> Utf8 Class Initialized
INFO - 2016-09-14 06:45:44 --> URI Class Initialized
INFO - 2016-09-14 06:45:44 --> Router Class Initialized
INFO - 2016-09-14 06:45:44 --> Output Class Initialized
INFO - 2016-09-14 06:45:44 --> Security Class Initialized
DEBUG - 2016-09-14 06:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:45:44 --> Input Class Initialized
INFO - 2016-09-14 06:45:44 --> Language Class Initialized
INFO - 2016-09-14 06:45:44 --> Language Class Initialized
INFO - 2016-09-14 06:45:44 --> Config Class Initialized
INFO - 2016-09-14 06:45:44 --> Loader Class Initialized
INFO - 2016-09-14 06:45:44 --> Helper loaded: url_helper
INFO - 2016-09-14 06:45:44 --> Database Driver Class Initialized
INFO - 2016-09-14 06:45:44 --> Controller Class Initialized
DEBUG - 2016-09-14 06:45:44 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:45:44 --> Model Class Initialized
INFO - 2016-09-14 06:45:44 --> Model Class Initialized
DEBUG - 2016-09-14 06:45:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 06:45:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 06:45:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 06:45:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_umum.php
DEBUG - 2016-09-14 06:45:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 06:45:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 06:45:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 06:45:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 06:45:45 --> Final output sent to browser
DEBUG - 2016-09-14 06:45:45 --> Total execution time: 0.7324
INFO - 2016-09-14 06:47:33 --> Config Class Initialized
INFO - 2016-09-14 06:47:33 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:47:33 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:47:33 --> Utf8 Class Initialized
INFO - 2016-09-14 06:47:33 --> URI Class Initialized
INFO - 2016-09-14 06:47:33 --> Router Class Initialized
INFO - 2016-09-14 06:47:33 --> Output Class Initialized
INFO - 2016-09-14 06:47:33 --> Security Class Initialized
DEBUG - 2016-09-14 06:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:47:33 --> Input Class Initialized
INFO - 2016-09-14 06:47:33 --> Language Class Initialized
INFO - 2016-09-14 06:47:33 --> Language Class Initialized
INFO - 2016-09-14 06:47:33 --> Config Class Initialized
INFO - 2016-09-14 06:47:33 --> Loader Class Initialized
INFO - 2016-09-14 06:47:33 --> Helper loaded: url_helper
INFO - 2016-09-14 06:47:33 --> Database Driver Class Initialized
INFO - 2016-09-14 06:47:33 --> Controller Class Initialized
DEBUG - 2016-09-14 06:47:33 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:47:33 --> Model Class Initialized
INFO - 2016-09-14 06:47:33 --> Model Class Initialized
DEBUG - 2016-09-14 06:47:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 06:47:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 06:47:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 06:47:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_umum.php
DEBUG - 2016-09-14 06:47:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 06:47:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 06:47:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 06:47:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 06:47:33 --> Final output sent to browser
DEBUG - 2016-09-14 06:47:33 --> Total execution time: 0.7696
INFO - 2016-09-14 06:47:55 --> Config Class Initialized
INFO - 2016-09-14 06:47:55 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:47:55 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:47:55 --> Utf8 Class Initialized
INFO - 2016-09-14 06:47:55 --> URI Class Initialized
INFO - 2016-09-14 06:47:55 --> Router Class Initialized
INFO - 2016-09-14 06:47:55 --> Output Class Initialized
INFO - 2016-09-14 06:47:55 --> Security Class Initialized
DEBUG - 2016-09-14 06:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:47:55 --> Input Class Initialized
INFO - 2016-09-14 06:47:55 --> Language Class Initialized
INFO - 2016-09-14 06:47:55 --> Language Class Initialized
INFO - 2016-09-14 06:47:55 --> Config Class Initialized
INFO - 2016-09-14 06:47:55 --> Loader Class Initialized
INFO - 2016-09-14 06:47:55 --> Helper loaded: url_helper
INFO - 2016-09-14 06:47:55 --> Database Driver Class Initialized
INFO - 2016-09-14 06:47:55 --> Controller Class Initialized
DEBUG - 2016-09-14 06:47:55 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:47:55 --> Model Class Initialized
INFO - 2016-09-14 06:47:55 --> Model Class Initialized
DEBUG - 2016-09-14 06:47:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 06:47:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 06:47:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 06:47:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-09-14 06:47:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 06:47:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 06:47:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 06:47:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 06:47:55 --> Final output sent to browser
DEBUG - 2016-09-14 06:47:55 --> Total execution time: 0.7959
INFO - 2016-09-14 06:48:40 --> Config Class Initialized
INFO - 2016-09-14 06:48:40 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:48:40 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:48:40 --> Utf8 Class Initialized
INFO - 2016-09-14 06:48:40 --> URI Class Initialized
INFO - 2016-09-14 06:48:40 --> Router Class Initialized
INFO - 2016-09-14 06:48:40 --> Output Class Initialized
INFO - 2016-09-14 06:48:40 --> Security Class Initialized
DEBUG - 2016-09-14 06:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:48:40 --> Input Class Initialized
INFO - 2016-09-14 06:48:40 --> Language Class Initialized
INFO - 2016-09-14 06:48:40 --> Language Class Initialized
INFO - 2016-09-14 06:48:40 --> Config Class Initialized
INFO - 2016-09-14 06:48:40 --> Loader Class Initialized
INFO - 2016-09-14 06:48:40 --> Helper loaded: url_helper
INFO - 2016-09-14 06:48:40 --> Database Driver Class Initialized
INFO - 2016-09-14 06:48:40 --> Controller Class Initialized
DEBUG - 2016-09-14 06:48:40 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:48:40 --> Model Class Initialized
INFO - 2016-09-14 06:48:40 --> Model Class Initialized
DEBUG - 2016-09-14 06:48:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 06:48:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 06:48:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 06:48:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_umum.php
DEBUG - 2016-09-14 06:48:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 06:48:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 06:48:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 06:48:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 06:48:41 --> Final output sent to browser
DEBUG - 2016-09-14 06:48:41 --> Total execution time: 0.7620
INFO - 2016-09-14 06:48:56 --> Config Class Initialized
INFO - 2016-09-14 06:48:56 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:48:56 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:48:56 --> Utf8 Class Initialized
INFO - 2016-09-14 06:48:56 --> URI Class Initialized
INFO - 2016-09-14 06:48:56 --> Router Class Initialized
INFO - 2016-09-14 06:48:56 --> Output Class Initialized
INFO - 2016-09-14 06:48:56 --> Security Class Initialized
DEBUG - 2016-09-14 06:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:48:56 --> Input Class Initialized
INFO - 2016-09-14 06:48:56 --> Language Class Initialized
INFO - 2016-09-14 06:48:56 --> Language Class Initialized
INFO - 2016-09-14 06:48:56 --> Config Class Initialized
INFO - 2016-09-14 06:48:56 --> Loader Class Initialized
INFO - 2016-09-14 06:48:56 --> Helper loaded: url_helper
INFO - 2016-09-14 06:48:56 --> Database Driver Class Initialized
INFO - 2016-09-14 06:48:56 --> Controller Class Initialized
DEBUG - 2016-09-14 06:48:56 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:48:56 --> Model Class Initialized
INFO - 2016-09-14 06:48:56 --> Model Class Initialized
DEBUG - 2016-09-14 06:48:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 06:48:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 06:48:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 06:48:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-09-14 06:48:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 06:48:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 06:48:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 06:48:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 06:48:56 --> Final output sent to browser
DEBUG - 2016-09-14 06:48:56 --> Total execution time: 0.8482
INFO - 2016-09-14 06:51:58 --> Config Class Initialized
INFO - 2016-09-14 06:51:58 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:51:58 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:51:58 --> Utf8 Class Initialized
INFO - 2016-09-14 06:51:58 --> URI Class Initialized
INFO - 2016-09-14 06:51:58 --> Router Class Initialized
INFO - 2016-09-14 06:51:58 --> Output Class Initialized
INFO - 2016-09-14 06:51:58 --> Security Class Initialized
DEBUG - 2016-09-14 06:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:51:58 --> Input Class Initialized
INFO - 2016-09-14 06:51:58 --> Language Class Initialized
INFO - 2016-09-14 06:51:58 --> Language Class Initialized
INFO - 2016-09-14 06:51:58 --> Config Class Initialized
INFO - 2016-09-14 06:51:58 --> Loader Class Initialized
INFO - 2016-09-14 06:51:58 --> Helper loaded: url_helper
INFO - 2016-09-14 06:51:58 --> Database Driver Class Initialized
INFO - 2016-09-14 06:51:58 --> Controller Class Initialized
DEBUG - 2016-09-14 06:51:58 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:51:58 --> Model Class Initialized
INFO - 2016-09-14 06:51:58 --> Model Class Initialized
DEBUG - 2016-09-14 06:51:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 06:51:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 06:51:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 06:51:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_umum.php
DEBUG - 2016-09-14 06:51:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 06:51:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 06:51:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 06:51:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 06:51:59 --> Final output sent to browser
DEBUG - 2016-09-14 06:51:59 --> Total execution time: 0.8437
INFO - 2016-09-14 06:59:25 --> Config Class Initialized
INFO - 2016-09-14 06:59:25 --> Hooks Class Initialized
DEBUG - 2016-09-14 06:59:25 --> UTF-8 Support Enabled
INFO - 2016-09-14 06:59:25 --> Utf8 Class Initialized
INFO - 2016-09-14 06:59:25 --> URI Class Initialized
INFO - 2016-09-14 06:59:25 --> Router Class Initialized
INFO - 2016-09-14 06:59:25 --> Output Class Initialized
INFO - 2016-09-14 06:59:25 --> Security Class Initialized
DEBUG - 2016-09-14 06:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 06:59:26 --> Input Class Initialized
INFO - 2016-09-14 06:59:26 --> Language Class Initialized
INFO - 2016-09-14 06:59:26 --> Language Class Initialized
INFO - 2016-09-14 06:59:26 --> Config Class Initialized
INFO - 2016-09-14 06:59:26 --> Loader Class Initialized
INFO - 2016-09-14 06:59:26 --> Helper loaded: url_helper
INFO - 2016-09-14 06:59:26 --> Database Driver Class Initialized
INFO - 2016-09-14 06:59:26 --> Controller Class Initialized
DEBUG - 2016-09-14 06:59:26 --> Index MX_Controller Initialized
INFO - 2016-09-14 06:59:26 --> Model Class Initialized
INFO - 2016-09-14 06:59:26 --> Model Class Initialized
DEBUG - 2016-09-14 06:59:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 06:59:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 06:59:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 06:59:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_umum.php
DEBUG - 2016-09-14 06:59:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 06:59:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 06:59:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 06:59:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 06:59:26 --> Final output sent to browser
DEBUG - 2016-09-14 06:59:26 --> Total execution time: 0.7279
INFO - 2016-09-14 07:00:36 --> Config Class Initialized
INFO - 2016-09-14 07:00:36 --> Hooks Class Initialized
DEBUG - 2016-09-14 07:00:36 --> UTF-8 Support Enabled
INFO - 2016-09-14 07:00:37 --> Utf8 Class Initialized
INFO - 2016-09-14 07:00:37 --> URI Class Initialized
INFO - 2016-09-14 07:00:37 --> Router Class Initialized
INFO - 2016-09-14 07:00:37 --> Output Class Initialized
INFO - 2016-09-14 07:00:37 --> Security Class Initialized
DEBUG - 2016-09-14 07:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 07:00:37 --> Input Class Initialized
INFO - 2016-09-14 07:00:37 --> Language Class Initialized
INFO - 2016-09-14 07:00:37 --> Language Class Initialized
INFO - 2016-09-14 07:00:37 --> Config Class Initialized
INFO - 2016-09-14 07:00:37 --> Loader Class Initialized
INFO - 2016-09-14 07:00:37 --> Helper loaded: url_helper
INFO - 2016-09-14 07:00:37 --> Database Driver Class Initialized
INFO - 2016-09-14 07:00:37 --> Controller Class Initialized
DEBUG - 2016-09-14 07:00:37 --> Index MX_Controller Initialized
INFO - 2016-09-14 07:00:37 --> Model Class Initialized
INFO - 2016-09-14 07:00:37 --> Model Class Initialized
DEBUG - 2016-09-14 07:00:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 07:00:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 07:00:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 07:00:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-09-14 07:00:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 07:00:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 07:00:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 07:00:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 07:00:37 --> Final output sent to browser
DEBUG - 2016-09-14 07:00:37 --> Total execution time: 0.7881
INFO - 2016-09-14 07:04:17 --> Config Class Initialized
INFO - 2016-09-14 07:04:17 --> Hooks Class Initialized
DEBUG - 2016-09-14 07:04:17 --> UTF-8 Support Enabled
INFO - 2016-09-14 07:04:17 --> Utf8 Class Initialized
INFO - 2016-09-14 07:04:17 --> URI Class Initialized
INFO - 2016-09-14 07:04:17 --> Router Class Initialized
INFO - 2016-09-14 07:04:17 --> Output Class Initialized
INFO - 2016-09-14 07:04:17 --> Security Class Initialized
DEBUG - 2016-09-14 07:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 07:04:17 --> Input Class Initialized
INFO - 2016-09-14 07:04:17 --> Language Class Initialized
INFO - 2016-09-14 07:04:17 --> Language Class Initialized
INFO - 2016-09-14 07:04:17 --> Config Class Initialized
INFO - 2016-09-14 07:04:17 --> Loader Class Initialized
INFO - 2016-09-14 07:04:17 --> Helper loaded: url_helper
INFO - 2016-09-14 07:04:17 --> Database Driver Class Initialized
INFO - 2016-09-14 07:04:17 --> Controller Class Initialized
DEBUG - 2016-09-14 07:04:17 --> Index MX_Controller Initialized
INFO - 2016-09-14 07:04:17 --> Model Class Initialized
INFO - 2016-09-14 07:04:17 --> Model Class Initialized
DEBUG - 2016-09-14 07:04:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 07:04:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 07:04:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 07:04:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-09-14 07:04:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 07:04:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 07:04:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 07:04:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 07:04:17 --> Final output sent to browser
DEBUG - 2016-09-14 07:04:17 --> Total execution time: 0.7368
INFO - 2016-09-14 07:04:40 --> Config Class Initialized
INFO - 2016-09-14 07:04:40 --> Hooks Class Initialized
DEBUG - 2016-09-14 07:04:40 --> UTF-8 Support Enabled
INFO - 2016-09-14 07:04:40 --> Utf8 Class Initialized
INFO - 2016-09-14 07:04:40 --> URI Class Initialized
INFO - 2016-09-14 07:04:40 --> Router Class Initialized
INFO - 2016-09-14 07:04:40 --> Output Class Initialized
INFO - 2016-09-14 07:04:40 --> Security Class Initialized
DEBUG - 2016-09-14 07:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 07:04:40 --> Input Class Initialized
INFO - 2016-09-14 07:04:40 --> Language Class Initialized
INFO - 2016-09-14 07:04:40 --> Language Class Initialized
INFO - 2016-09-14 07:04:40 --> Config Class Initialized
INFO - 2016-09-14 07:04:40 --> Loader Class Initialized
INFO - 2016-09-14 07:04:40 --> Helper loaded: url_helper
INFO - 2016-09-14 07:04:40 --> Database Driver Class Initialized
INFO - 2016-09-14 07:04:40 --> Controller Class Initialized
DEBUG - 2016-09-14 07:04:40 --> Index MX_Controller Initialized
INFO - 2016-09-14 07:04:40 --> Model Class Initialized
INFO - 2016-09-14 07:04:40 --> Model Class Initialized
DEBUG - 2016-09-14 07:04:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 07:04:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 07:04:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 07:04:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_umum.php
DEBUG - 2016-09-14 07:04:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 07:04:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 07:04:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 07:04:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 07:04:41 --> Final output sent to browser
DEBUG - 2016-09-14 07:04:41 --> Total execution time: 0.7265
INFO - 2016-09-14 07:05:16 --> Config Class Initialized
INFO - 2016-09-14 07:05:16 --> Hooks Class Initialized
DEBUG - 2016-09-14 07:05:16 --> UTF-8 Support Enabled
INFO - 2016-09-14 07:05:16 --> Utf8 Class Initialized
INFO - 2016-09-14 07:05:16 --> URI Class Initialized
INFO - 2016-09-14 07:05:17 --> Router Class Initialized
INFO - 2016-09-14 07:05:17 --> Output Class Initialized
INFO - 2016-09-14 07:05:17 --> Security Class Initialized
DEBUG - 2016-09-14 07:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 07:05:17 --> Input Class Initialized
INFO - 2016-09-14 07:05:17 --> Language Class Initialized
INFO - 2016-09-14 07:05:17 --> Language Class Initialized
INFO - 2016-09-14 07:05:17 --> Config Class Initialized
INFO - 2016-09-14 07:05:17 --> Loader Class Initialized
INFO - 2016-09-14 07:05:17 --> Helper loaded: url_helper
INFO - 2016-09-14 07:05:17 --> Database Driver Class Initialized
INFO - 2016-09-14 07:05:17 --> Controller Class Initialized
DEBUG - 2016-09-14 07:05:17 --> Index MX_Controller Initialized
INFO - 2016-09-14 07:05:17 --> Model Class Initialized
INFO - 2016-09-14 07:05:17 --> Model Class Initialized
DEBUG - 2016-09-14 07:05:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 07:05:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 07:05:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 07:05:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_umum.php
DEBUG - 2016-09-14 07:05:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 07:05:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 07:05:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 07:05:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 07:05:17 --> Final output sent to browser
DEBUG - 2016-09-14 07:05:17 --> Total execution time: 0.7558
INFO - 2016-09-14 07:33:21 --> Config Class Initialized
INFO - 2016-09-14 07:33:21 --> Hooks Class Initialized
DEBUG - 2016-09-14 07:33:21 --> UTF-8 Support Enabled
INFO - 2016-09-14 07:33:21 --> Utf8 Class Initialized
INFO - 2016-09-14 07:33:21 --> URI Class Initialized
INFO - 2016-09-14 07:33:22 --> Router Class Initialized
INFO - 2016-09-14 07:33:22 --> Output Class Initialized
INFO - 2016-09-14 07:33:22 --> Security Class Initialized
DEBUG - 2016-09-14 07:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 07:33:22 --> Input Class Initialized
INFO - 2016-09-14 07:33:22 --> Language Class Initialized
INFO - 2016-09-14 07:33:22 --> Language Class Initialized
INFO - 2016-09-14 07:33:22 --> Config Class Initialized
INFO - 2016-09-14 07:33:22 --> Loader Class Initialized
INFO - 2016-09-14 07:33:22 --> Helper loaded: url_helper
INFO - 2016-09-14 07:33:22 --> Database Driver Class Initialized
INFO - 2016-09-14 07:33:22 --> Controller Class Initialized
DEBUG - 2016-09-14 07:33:22 --> Index MX_Controller Initialized
INFO - 2016-09-14 07:33:22 --> Model Class Initialized
INFO - 2016-09-14 07:33:22 --> Model Class Initialized
DEBUG - 2016-09-14 07:33:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 07:33:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 07:33:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 07:33:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-09-14 07:33:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 07:33:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 07:33:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 07:33:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 07:33:22 --> Final output sent to browser
DEBUG - 2016-09-14 07:33:22 --> Total execution time: 0.8210
INFO - 2016-09-14 07:33:56 --> Config Class Initialized
INFO - 2016-09-14 07:33:56 --> Hooks Class Initialized
DEBUG - 2016-09-14 07:33:56 --> UTF-8 Support Enabled
INFO - 2016-09-14 07:33:56 --> Utf8 Class Initialized
INFO - 2016-09-14 07:33:56 --> URI Class Initialized
INFO - 2016-09-14 07:33:56 --> Router Class Initialized
INFO - 2016-09-14 07:33:56 --> Output Class Initialized
INFO - 2016-09-14 07:33:56 --> Security Class Initialized
DEBUG - 2016-09-14 07:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 07:33:56 --> Input Class Initialized
INFO - 2016-09-14 07:33:56 --> Language Class Initialized
INFO - 2016-09-14 07:33:56 --> Language Class Initialized
INFO - 2016-09-14 07:33:56 --> Config Class Initialized
INFO - 2016-09-14 07:33:56 --> Loader Class Initialized
INFO - 2016-09-14 07:33:56 --> Helper loaded: url_helper
INFO - 2016-09-14 07:33:56 --> Database Driver Class Initialized
INFO - 2016-09-14 07:33:56 --> Controller Class Initialized
DEBUG - 2016-09-14 07:33:57 --> Index MX_Controller Initialized
INFO - 2016-09-14 07:33:57 --> Model Class Initialized
INFO - 2016-09-14 07:33:57 --> Model Class Initialized
DEBUG - 2016-09-14 07:33:57 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 07:33:57 --> Database Driver Class Initialized
INFO - 2016-09-14 07:33:57 --> Final output sent to browser
DEBUG - 2016-09-14 07:33:57 --> Total execution time: 0.6654
INFO - 2016-09-14 07:34:04 --> Config Class Initialized
INFO - 2016-09-14 07:34:04 --> Hooks Class Initialized
DEBUG - 2016-09-14 07:34:04 --> UTF-8 Support Enabled
INFO - 2016-09-14 07:34:04 --> Utf8 Class Initialized
INFO - 2016-09-14 07:34:04 --> URI Class Initialized
INFO - 2016-09-14 07:34:04 --> Router Class Initialized
INFO - 2016-09-14 07:34:04 --> Output Class Initialized
INFO - 2016-09-14 07:34:04 --> Security Class Initialized
DEBUG - 2016-09-14 07:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 07:34:04 --> Input Class Initialized
INFO - 2016-09-14 07:34:04 --> Language Class Initialized
INFO - 2016-09-14 07:34:04 --> Language Class Initialized
INFO - 2016-09-14 07:34:04 --> Config Class Initialized
INFO - 2016-09-14 07:34:05 --> Loader Class Initialized
INFO - 2016-09-14 07:34:05 --> Helper loaded: url_helper
INFO - 2016-09-14 07:34:05 --> Database Driver Class Initialized
INFO - 2016-09-14 07:34:05 --> Controller Class Initialized
DEBUG - 2016-09-14 07:34:05 --> Index MX_Controller Initialized
INFO - 2016-09-14 07:34:05 --> Model Class Initialized
INFO - 2016-09-14 07:34:05 --> Model Class Initialized
DEBUG - 2016-09-14 07:34:05 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 07:34:05 --> Final output sent to browser
DEBUG - 2016-09-14 07:34:05 --> Total execution time: 0.5902
INFO - 2016-09-14 07:34:30 --> Config Class Initialized
INFO - 2016-09-14 07:34:30 --> Hooks Class Initialized
DEBUG - 2016-09-14 07:34:30 --> UTF-8 Support Enabled
INFO - 2016-09-14 07:34:30 --> Utf8 Class Initialized
INFO - 2016-09-14 07:34:30 --> URI Class Initialized
INFO - 2016-09-14 07:34:30 --> Router Class Initialized
INFO - 2016-09-14 07:34:30 --> Output Class Initialized
INFO - 2016-09-14 07:34:30 --> Security Class Initialized
DEBUG - 2016-09-14 07:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 07:34:30 --> Input Class Initialized
INFO - 2016-09-14 07:34:30 --> Language Class Initialized
INFO - 2016-09-14 07:34:30 --> Language Class Initialized
INFO - 2016-09-14 07:34:30 --> Config Class Initialized
INFO - 2016-09-14 07:34:30 --> Loader Class Initialized
INFO - 2016-09-14 07:34:30 --> Helper loaded: url_helper
INFO - 2016-09-14 07:34:30 --> Database Driver Class Initialized
INFO - 2016-09-14 07:34:30 --> Controller Class Initialized
DEBUG - 2016-09-14 07:34:30 --> Index MX_Controller Initialized
INFO - 2016-09-14 07:34:30 --> Model Class Initialized
INFO - 2016-09-14 07:34:30 --> Model Class Initialized
DEBUG - 2016-09-14 07:34:30 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 07:34:30 --> Database Driver Class Initialized
INFO - 2016-09-14 07:34:30 --> Final output sent to browser
DEBUG - 2016-09-14 07:34:30 --> Total execution time: 0.6480
INFO - 2016-09-14 07:34:43 --> Config Class Initialized
INFO - 2016-09-14 07:34:43 --> Hooks Class Initialized
DEBUG - 2016-09-14 07:34:43 --> UTF-8 Support Enabled
INFO - 2016-09-14 07:34:43 --> Utf8 Class Initialized
INFO - 2016-09-14 07:34:43 --> URI Class Initialized
INFO - 2016-09-14 07:34:43 --> Router Class Initialized
INFO - 2016-09-14 07:34:43 --> Output Class Initialized
INFO - 2016-09-14 07:34:43 --> Security Class Initialized
DEBUG - 2016-09-14 07:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 07:34:43 --> Input Class Initialized
INFO - 2016-09-14 07:34:43 --> Language Class Initialized
INFO - 2016-09-14 07:34:43 --> Language Class Initialized
INFO - 2016-09-14 07:34:43 --> Config Class Initialized
INFO - 2016-09-14 07:34:43 --> Loader Class Initialized
INFO - 2016-09-14 07:34:43 --> Helper loaded: url_helper
INFO - 2016-09-14 07:34:43 --> Database Driver Class Initialized
INFO - 2016-09-14 07:34:43 --> Controller Class Initialized
DEBUG - 2016-09-14 07:34:43 --> Index MX_Controller Initialized
INFO - 2016-09-14 07:34:43 --> Model Class Initialized
INFO - 2016-09-14 07:34:43 --> Model Class Initialized
DEBUG - 2016-09-14 07:34:43 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 07:34:44 --> Database Driver Class Initialized
INFO - 2016-09-14 07:34:44 --> Final output sent to browser
DEBUG - 2016-09-14 07:34:44 --> Total execution time: 0.6366
INFO - 2016-09-14 07:35:17 --> Config Class Initialized
INFO - 2016-09-14 07:35:17 --> Hooks Class Initialized
DEBUG - 2016-09-14 07:35:17 --> UTF-8 Support Enabled
INFO - 2016-09-14 07:35:17 --> Utf8 Class Initialized
INFO - 2016-09-14 07:35:17 --> URI Class Initialized
INFO - 2016-09-14 07:35:17 --> Router Class Initialized
INFO - 2016-09-14 07:35:17 --> Output Class Initialized
INFO - 2016-09-14 07:35:17 --> Security Class Initialized
DEBUG - 2016-09-14 07:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 07:35:17 --> Input Class Initialized
INFO - 2016-09-14 07:35:17 --> Language Class Initialized
INFO - 2016-09-14 07:35:17 --> Language Class Initialized
INFO - 2016-09-14 07:35:17 --> Config Class Initialized
INFO - 2016-09-14 07:35:17 --> Loader Class Initialized
INFO - 2016-09-14 07:35:17 --> Helper loaded: url_helper
INFO - 2016-09-14 07:35:17 --> Database Driver Class Initialized
INFO - 2016-09-14 07:35:17 --> Controller Class Initialized
DEBUG - 2016-09-14 07:35:17 --> Index MX_Controller Initialized
INFO - 2016-09-14 07:35:17 --> Model Class Initialized
INFO - 2016-09-14 07:35:17 --> Model Class Initialized
DEBUG - 2016-09-14 07:35:17 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 07:35:17 --> Database Driver Class Initialized
INFO - 2016-09-14 07:35:17 --> Final output sent to browser
DEBUG - 2016-09-14 07:35:17 --> Total execution time: 0.6194
INFO - 2016-09-14 07:35:32 --> Config Class Initialized
INFO - 2016-09-14 07:35:32 --> Hooks Class Initialized
DEBUG - 2016-09-14 07:35:32 --> UTF-8 Support Enabled
INFO - 2016-09-14 07:35:32 --> Utf8 Class Initialized
INFO - 2016-09-14 07:35:32 --> URI Class Initialized
INFO - 2016-09-14 07:35:32 --> Router Class Initialized
INFO - 2016-09-14 07:35:32 --> Output Class Initialized
INFO - 2016-09-14 07:35:32 --> Security Class Initialized
DEBUG - 2016-09-14 07:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 07:35:32 --> Input Class Initialized
INFO - 2016-09-14 07:35:32 --> Language Class Initialized
INFO - 2016-09-14 07:35:32 --> Language Class Initialized
INFO - 2016-09-14 07:35:32 --> Config Class Initialized
INFO - 2016-09-14 07:35:32 --> Loader Class Initialized
INFO - 2016-09-14 07:35:32 --> Helper loaded: url_helper
INFO - 2016-09-14 07:35:32 --> Database Driver Class Initialized
INFO - 2016-09-14 07:35:32 --> Controller Class Initialized
DEBUG - 2016-09-14 07:35:32 --> Index MX_Controller Initialized
INFO - 2016-09-14 07:35:32 --> Model Class Initialized
INFO - 2016-09-14 07:35:32 --> Model Class Initialized
DEBUG - 2016-09-14 07:35:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 07:35:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 07:35:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 07:35:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-09-14 07:35:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 07:35:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 07:35:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 07:35:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 07:35:32 --> Final output sent to browser
DEBUG - 2016-09-14 07:35:32 --> Total execution time: 0.8068
INFO - 2016-09-14 07:35:46 --> Config Class Initialized
INFO - 2016-09-14 07:35:46 --> Hooks Class Initialized
DEBUG - 2016-09-14 07:35:46 --> UTF-8 Support Enabled
INFO - 2016-09-14 07:35:46 --> Utf8 Class Initialized
INFO - 2016-09-14 07:35:46 --> URI Class Initialized
INFO - 2016-09-14 07:35:46 --> Router Class Initialized
INFO - 2016-09-14 07:35:46 --> Output Class Initialized
INFO - 2016-09-14 07:35:46 --> Security Class Initialized
DEBUG - 2016-09-14 07:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 07:35:46 --> Input Class Initialized
INFO - 2016-09-14 07:35:46 --> Language Class Initialized
INFO - 2016-09-14 07:35:46 --> Language Class Initialized
INFO - 2016-09-14 07:35:46 --> Config Class Initialized
INFO - 2016-09-14 07:35:46 --> Loader Class Initialized
INFO - 2016-09-14 07:35:46 --> Helper loaded: url_helper
INFO - 2016-09-14 07:35:46 --> Database Driver Class Initialized
INFO - 2016-09-14 07:35:46 --> Controller Class Initialized
DEBUG - 2016-09-14 07:35:46 --> Index MX_Controller Initialized
INFO - 2016-09-14 07:35:46 --> Model Class Initialized
INFO - 2016-09-14 07:35:46 --> Model Class Initialized
DEBUG - 2016-09-14 07:35:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 07:35:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 07:35:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 07:35:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_umum.php
DEBUG - 2016-09-14 07:35:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 07:35:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 07:35:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 07:35:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 07:35:47 --> Final output sent to browser
DEBUG - 2016-09-14 07:35:47 --> Total execution time: 0.8384
INFO - 2016-09-14 08:22:05 --> Config Class Initialized
INFO - 2016-09-14 08:22:05 --> Hooks Class Initialized
DEBUG - 2016-09-14 08:22:05 --> UTF-8 Support Enabled
INFO - 2016-09-14 08:22:05 --> Utf8 Class Initialized
INFO - 2016-09-14 08:22:05 --> URI Class Initialized
INFO - 2016-09-14 08:22:05 --> Router Class Initialized
INFO - 2016-09-14 08:22:05 --> Output Class Initialized
INFO - 2016-09-14 08:22:05 --> Security Class Initialized
DEBUG - 2016-09-14 08:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 08:22:05 --> Input Class Initialized
INFO - 2016-09-14 08:22:05 --> Language Class Initialized
INFO - 2016-09-14 08:22:05 --> Language Class Initialized
INFO - 2016-09-14 08:22:05 --> Config Class Initialized
INFO - 2016-09-14 08:22:05 --> Loader Class Initialized
INFO - 2016-09-14 08:22:05 --> Helper loaded: url_helper
INFO - 2016-09-14 08:22:05 --> Database Driver Class Initialized
INFO - 2016-09-14 08:22:05 --> Controller Class Initialized
DEBUG - 2016-09-14 08:22:05 --> Index MX_Controller Initialized
INFO - 2016-09-14 08:22:05 --> Model Class Initialized
INFO - 2016-09-14 08:22:05 --> Model Class Initialized
INFO - 2016-09-14 08:22:06 --> Final output sent to browser
DEBUG - 2016-09-14 08:22:06 --> Total execution time: 0.6049
INFO - 2016-09-14 08:22:06 --> Config Class Initialized
INFO - 2016-09-14 08:22:06 --> Hooks Class Initialized
DEBUG - 2016-09-14 08:22:06 --> UTF-8 Support Enabled
INFO - 2016-09-14 08:22:06 --> Utf8 Class Initialized
INFO - 2016-09-14 08:22:06 --> URI Class Initialized
INFO - 2016-09-14 08:22:06 --> Router Class Initialized
INFO - 2016-09-14 08:22:06 --> Output Class Initialized
INFO - 2016-09-14 08:22:06 --> Security Class Initialized
DEBUG - 2016-09-14 08:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 08:22:06 --> Input Class Initialized
INFO - 2016-09-14 08:22:06 --> Language Class Initialized
INFO - 2016-09-14 08:22:06 --> Language Class Initialized
INFO - 2016-09-14 08:22:06 --> Config Class Initialized
INFO - 2016-09-14 08:22:06 --> Loader Class Initialized
INFO - 2016-09-14 08:22:06 --> Helper loaded: url_helper
INFO - 2016-09-14 08:22:06 --> Database Driver Class Initialized
INFO - 2016-09-14 08:22:06 --> Controller Class Initialized
DEBUG - 2016-09-14 08:22:06 --> Index MX_Controller Initialized
INFO - 2016-09-14 08:22:06 --> Model Class Initialized
INFO - 2016-09-14 08:22:06 --> Model Class Initialized
DEBUG - 2016-09-14 08:22:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 08:22:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 08:22:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 08:22:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-14 08:22:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 08:22:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 08:22:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 08:22:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 08:22:06 --> Final output sent to browser
DEBUG - 2016-09-14 08:22:06 --> Total execution time: 0.7476
INFO - 2016-09-14 08:22:11 --> Config Class Initialized
INFO - 2016-09-14 08:22:11 --> Hooks Class Initialized
DEBUG - 2016-09-14 08:22:11 --> UTF-8 Support Enabled
INFO - 2016-09-14 08:22:12 --> Utf8 Class Initialized
INFO - 2016-09-14 08:22:12 --> URI Class Initialized
INFO - 2016-09-14 08:22:12 --> Router Class Initialized
INFO - 2016-09-14 08:22:12 --> Output Class Initialized
INFO - 2016-09-14 08:22:12 --> Security Class Initialized
DEBUG - 2016-09-14 08:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 08:22:12 --> Input Class Initialized
INFO - 2016-09-14 08:22:12 --> Language Class Initialized
INFO - 2016-09-14 08:22:12 --> Language Class Initialized
INFO - 2016-09-14 08:22:12 --> Config Class Initialized
INFO - 2016-09-14 08:22:12 --> Loader Class Initialized
INFO - 2016-09-14 08:22:12 --> Helper loaded: url_helper
INFO - 2016-09-14 08:22:12 --> Database Driver Class Initialized
INFO - 2016-09-14 08:22:12 --> Controller Class Initialized
DEBUG - 2016-09-14 08:22:12 --> Index MX_Controller Initialized
INFO - 2016-09-14 08:22:12 --> Model Class Initialized
INFO - 2016-09-14 08:22:12 --> Model Class Initialized
DEBUG - 2016-09-14 08:22:12 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 08:22:12 --> Database Driver Class Initialized
INFO - 2016-09-14 08:22:12 --> Final output sent to browser
DEBUG - 2016-09-14 08:22:12 --> Total execution time: 0.6363
INFO - 2016-09-14 08:22:13 --> Config Class Initialized
INFO - 2016-09-14 08:22:13 --> Hooks Class Initialized
DEBUG - 2016-09-14 08:22:13 --> UTF-8 Support Enabled
INFO - 2016-09-14 08:22:13 --> Utf8 Class Initialized
INFO - 2016-09-14 08:22:13 --> URI Class Initialized
INFO - 2016-09-14 08:22:13 --> Router Class Initialized
INFO - 2016-09-14 08:22:14 --> Output Class Initialized
INFO - 2016-09-14 08:22:14 --> Security Class Initialized
DEBUG - 2016-09-14 08:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 08:22:14 --> Input Class Initialized
INFO - 2016-09-14 08:22:14 --> Language Class Initialized
INFO - 2016-09-14 08:22:14 --> Language Class Initialized
INFO - 2016-09-14 08:22:14 --> Config Class Initialized
INFO - 2016-09-14 08:22:14 --> Loader Class Initialized
INFO - 2016-09-14 08:22:14 --> Helper loaded: url_helper
INFO - 2016-09-14 08:22:14 --> Database Driver Class Initialized
INFO - 2016-09-14 08:22:14 --> Controller Class Initialized
DEBUG - 2016-09-14 08:22:14 --> Index MX_Controller Initialized
INFO - 2016-09-14 08:22:14 --> Model Class Initialized
INFO - 2016-09-14 08:22:14 --> Model Class Initialized
DEBUG - 2016-09-14 08:22:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 08:22:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 08:22:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 08:22:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_umum.php
DEBUG - 2016-09-14 08:22:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 08:22:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 08:22:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 08:22:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 08:22:14 --> Final output sent to browser
DEBUG - 2016-09-14 08:22:14 --> Total execution time: 0.8396
INFO - 2016-09-14 08:22:19 --> Config Class Initialized
INFO - 2016-09-14 08:22:19 --> Hooks Class Initialized
DEBUG - 2016-09-14 08:22:19 --> UTF-8 Support Enabled
INFO - 2016-09-14 08:22:19 --> Utf8 Class Initialized
INFO - 2016-09-14 08:22:19 --> URI Class Initialized
INFO - 2016-09-14 08:22:19 --> Router Class Initialized
INFO - 2016-09-14 08:22:19 --> Output Class Initialized
INFO - 2016-09-14 08:22:19 --> Security Class Initialized
DEBUG - 2016-09-14 08:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 08:22:19 --> Input Class Initialized
INFO - 2016-09-14 08:22:19 --> Language Class Initialized
INFO - 2016-09-14 08:22:19 --> Language Class Initialized
INFO - 2016-09-14 08:22:19 --> Config Class Initialized
INFO - 2016-09-14 08:22:19 --> Loader Class Initialized
INFO - 2016-09-14 08:22:19 --> Helper loaded: url_helper
INFO - 2016-09-14 08:22:20 --> Database Driver Class Initialized
INFO - 2016-09-14 08:22:20 --> Controller Class Initialized
DEBUG - 2016-09-14 08:22:20 --> Index MX_Controller Initialized
INFO - 2016-09-14 08:22:20 --> Model Class Initialized
INFO - 2016-09-14 08:22:20 --> Model Class Initialized
INFO - 2016-09-14 08:22:20 --> Final output sent to browser
DEBUG - 2016-09-14 08:22:20 --> Total execution time: 1.1187
INFO - 2016-09-14 08:22:20 --> Config Class Initialized
INFO - 2016-09-14 08:22:20 --> Hooks Class Initialized
DEBUG - 2016-09-14 08:22:20 --> UTF-8 Support Enabled
INFO - 2016-09-14 08:22:20 --> Utf8 Class Initialized
INFO - 2016-09-14 08:22:20 --> URI Class Initialized
INFO - 2016-09-14 08:22:20 --> Router Class Initialized
INFO - 2016-09-14 08:22:20 --> Output Class Initialized
INFO - 2016-09-14 08:22:20 --> Security Class Initialized
DEBUG - 2016-09-14 08:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 08:22:20 --> Input Class Initialized
INFO - 2016-09-14 08:22:20 --> Language Class Initialized
INFO - 2016-09-14 08:22:20 --> Language Class Initialized
INFO - 2016-09-14 08:22:20 --> Config Class Initialized
INFO - 2016-09-14 08:22:20 --> Loader Class Initialized
INFO - 2016-09-14 08:22:20 --> Helper loaded: url_helper
INFO - 2016-09-14 08:22:20 --> Database Driver Class Initialized
INFO - 2016-09-14 08:22:20 --> Controller Class Initialized
DEBUG - 2016-09-14 08:22:20 --> Index MX_Controller Initialized
INFO - 2016-09-14 08:22:20 --> Model Class Initialized
INFO - 2016-09-14 08:22:20 --> Model Class Initialized
DEBUG - 2016-09-14 08:22:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 08:22:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 08:22:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 08:22:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-14 08:22:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 08:22:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 08:22:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 08:22:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 08:22:21 --> Final output sent to browser
DEBUG - 2016-09-14 08:22:21 --> Total execution time: 0.9266
INFO - 2016-09-14 08:23:49 --> Config Class Initialized
INFO - 2016-09-14 08:23:49 --> Hooks Class Initialized
DEBUG - 2016-09-14 08:23:49 --> UTF-8 Support Enabled
INFO - 2016-09-14 08:23:49 --> Utf8 Class Initialized
INFO - 2016-09-14 08:23:49 --> URI Class Initialized
INFO - 2016-09-14 08:23:49 --> Router Class Initialized
INFO - 2016-09-14 08:23:49 --> Output Class Initialized
INFO - 2016-09-14 08:23:49 --> Security Class Initialized
DEBUG - 2016-09-14 08:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 08:23:49 --> Input Class Initialized
INFO - 2016-09-14 08:23:49 --> Language Class Initialized
INFO - 2016-09-14 08:23:49 --> Language Class Initialized
INFO - 2016-09-14 08:23:49 --> Config Class Initialized
INFO - 2016-09-14 08:23:49 --> Loader Class Initialized
INFO - 2016-09-14 08:23:49 --> Helper loaded: url_helper
INFO - 2016-09-14 08:23:49 --> Database Driver Class Initialized
INFO - 2016-09-14 08:23:49 --> Controller Class Initialized
DEBUG - 2016-09-14 08:23:49 --> Index MX_Controller Initialized
INFO - 2016-09-14 08:23:49 --> Model Class Initialized
INFO - 2016-09-14 08:23:49 --> Model Class Initialized
DEBUG - 2016-09-14 08:23:49 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 08:23:49 --> Database Driver Class Initialized
INFO - 2016-09-14 08:23:49 --> Final output sent to browser
DEBUG - 2016-09-14 08:23:49 --> Total execution time: 0.6308
INFO - 2016-09-14 08:23:51 --> Config Class Initialized
INFO - 2016-09-14 08:23:51 --> Hooks Class Initialized
DEBUG - 2016-09-14 08:23:51 --> UTF-8 Support Enabled
INFO - 2016-09-14 08:23:51 --> Utf8 Class Initialized
INFO - 2016-09-14 08:23:51 --> URI Class Initialized
INFO - 2016-09-14 08:23:51 --> Router Class Initialized
INFO - 2016-09-14 08:23:51 --> Output Class Initialized
INFO - 2016-09-14 08:23:51 --> Security Class Initialized
DEBUG - 2016-09-14 08:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 08:23:51 --> Input Class Initialized
INFO - 2016-09-14 08:23:51 --> Language Class Initialized
INFO - 2016-09-14 08:23:51 --> Language Class Initialized
INFO - 2016-09-14 08:23:51 --> Config Class Initialized
INFO - 2016-09-14 08:23:51 --> Loader Class Initialized
INFO - 2016-09-14 08:23:51 --> Helper loaded: url_helper
INFO - 2016-09-14 08:23:51 --> Database Driver Class Initialized
INFO - 2016-09-14 08:23:51 --> Controller Class Initialized
DEBUG - 2016-09-14 08:23:51 --> Index MX_Controller Initialized
INFO - 2016-09-14 08:23:51 --> Model Class Initialized
INFO - 2016-09-14 08:23:51 --> Model Class Initialized
DEBUG - 2016-09-14 08:23:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 08:23:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 08:23:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 08:23:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-09-14 08:23:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 08:23:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 08:23:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 08:23:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 08:23:52 --> Final output sent to browser
DEBUG - 2016-09-14 08:23:52 --> Total execution time: 0.8169
INFO - 2016-09-14 08:27:58 --> Config Class Initialized
INFO - 2016-09-14 08:27:58 --> Hooks Class Initialized
DEBUG - 2016-09-14 08:27:58 --> UTF-8 Support Enabled
INFO - 2016-09-14 08:27:58 --> Utf8 Class Initialized
INFO - 2016-09-14 08:27:58 --> URI Class Initialized
INFO - 2016-09-14 08:27:58 --> Router Class Initialized
INFO - 2016-09-14 08:27:58 --> Output Class Initialized
INFO - 2016-09-14 08:27:58 --> Security Class Initialized
DEBUG - 2016-09-14 08:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 08:27:58 --> Input Class Initialized
INFO - 2016-09-14 08:27:58 --> Language Class Initialized
INFO - 2016-09-14 08:27:58 --> Language Class Initialized
INFO - 2016-09-14 08:27:58 --> Config Class Initialized
INFO - 2016-09-14 08:27:58 --> Loader Class Initialized
INFO - 2016-09-14 08:27:58 --> Helper loaded: url_helper
INFO - 2016-09-14 08:27:58 --> Database Driver Class Initialized
INFO - 2016-09-14 08:27:58 --> Controller Class Initialized
DEBUG - 2016-09-14 08:27:58 --> Index MX_Controller Initialized
INFO - 2016-09-14 08:27:58 --> Model Class Initialized
INFO - 2016-09-14 08:27:58 --> Model Class Initialized
DEBUG - 2016-09-14 08:27:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 08:27:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 08:27:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 08:27:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-09-14 08:27:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 08:27:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 08:27:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 08:27:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 08:27:59 --> Final output sent to browser
DEBUG - 2016-09-14 08:27:59 --> Total execution time: 0.8034
INFO - 2016-09-14 08:28:49 --> Config Class Initialized
INFO - 2016-09-14 08:28:49 --> Hooks Class Initialized
DEBUG - 2016-09-14 08:28:49 --> UTF-8 Support Enabled
INFO - 2016-09-14 08:28:49 --> Utf8 Class Initialized
INFO - 2016-09-14 08:28:49 --> URI Class Initialized
INFO - 2016-09-14 08:28:49 --> Router Class Initialized
INFO - 2016-09-14 08:28:49 --> Output Class Initialized
INFO - 2016-09-14 08:28:49 --> Security Class Initialized
DEBUG - 2016-09-14 08:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 08:28:49 --> Input Class Initialized
INFO - 2016-09-14 08:28:49 --> Language Class Initialized
INFO - 2016-09-14 08:28:49 --> Language Class Initialized
INFO - 2016-09-14 08:28:49 --> Config Class Initialized
INFO - 2016-09-14 08:28:49 --> Loader Class Initialized
INFO - 2016-09-14 08:28:49 --> Helper loaded: url_helper
INFO - 2016-09-14 08:28:49 --> Database Driver Class Initialized
INFO - 2016-09-14 08:28:49 --> Controller Class Initialized
DEBUG - 2016-09-14 08:28:49 --> Index MX_Controller Initialized
INFO - 2016-09-14 08:28:49 --> Model Class Initialized
INFO - 2016-09-14 08:28:49 --> Model Class Initialized
DEBUG - 2016-09-14 08:28:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 08:28:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 08:28:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 08:28:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-09-14 08:28:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 08:28:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 08:28:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 08:28:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 08:28:50 --> Final output sent to browser
DEBUG - 2016-09-14 08:28:50 --> Total execution time: 0.9624
INFO - 2016-09-14 08:34:15 --> Config Class Initialized
INFO - 2016-09-14 08:34:15 --> Hooks Class Initialized
DEBUG - 2016-09-14 08:34:15 --> UTF-8 Support Enabled
INFO - 2016-09-14 08:34:15 --> Utf8 Class Initialized
INFO - 2016-09-14 08:34:15 --> URI Class Initialized
INFO - 2016-09-14 08:34:15 --> Router Class Initialized
INFO - 2016-09-14 08:34:15 --> Output Class Initialized
INFO - 2016-09-14 08:34:15 --> Security Class Initialized
DEBUG - 2016-09-14 08:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 08:34:15 --> Input Class Initialized
INFO - 2016-09-14 08:34:15 --> Language Class Initialized
INFO - 2016-09-14 08:34:15 --> Language Class Initialized
INFO - 2016-09-14 08:34:15 --> Config Class Initialized
INFO - 2016-09-14 08:34:15 --> Loader Class Initialized
INFO - 2016-09-14 08:34:15 --> Helper loaded: url_helper
INFO - 2016-09-14 08:34:15 --> Database Driver Class Initialized
INFO - 2016-09-14 08:34:15 --> Controller Class Initialized
DEBUG - 2016-09-14 08:34:15 --> Index MX_Controller Initialized
INFO - 2016-09-14 08:34:15 --> Model Class Initialized
INFO - 2016-09-14 08:34:15 --> Model Class Initialized
DEBUG - 2016-09-14 08:34:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 08:34:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 08:34:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 08:34:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-09-14 08:34:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 08:34:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 08:34:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 08:34:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 08:34:16 --> Final output sent to browser
DEBUG - 2016-09-14 08:34:16 --> Total execution time: 0.9508
INFO - 2016-09-14 08:34:16 --> Config Class Initialized
INFO - 2016-09-14 08:34:16 --> Hooks Class Initialized
DEBUG - 2016-09-14 08:34:16 --> UTF-8 Support Enabled
INFO - 2016-09-14 08:34:16 --> Utf8 Class Initialized
INFO - 2016-09-14 08:34:16 --> URI Class Initialized
INFO - 2016-09-14 08:34:16 --> Router Class Initialized
INFO - 2016-09-14 08:34:17 --> Output Class Initialized
INFO - 2016-09-14 08:34:17 --> Security Class Initialized
DEBUG - 2016-09-14 08:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 08:34:17 --> Input Class Initialized
INFO - 2016-09-14 08:34:17 --> Language Class Initialized
ERROR - 2016-09-14 08:34:17 --> 404 Page Not Found: ../modules/admin/controllers//index
INFO - 2016-09-14 08:34:31 --> Config Class Initialized
INFO - 2016-09-14 08:34:31 --> Hooks Class Initialized
DEBUG - 2016-09-14 08:34:31 --> UTF-8 Support Enabled
INFO - 2016-09-14 08:34:31 --> Utf8 Class Initialized
INFO - 2016-09-14 08:34:31 --> URI Class Initialized
INFO - 2016-09-14 08:34:32 --> Router Class Initialized
INFO - 2016-09-14 08:34:32 --> Output Class Initialized
INFO - 2016-09-14 08:34:32 --> Security Class Initialized
DEBUG - 2016-09-14 08:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 08:34:32 --> Input Class Initialized
INFO - 2016-09-14 08:34:32 --> Language Class Initialized
INFO - 2016-09-14 08:34:32 --> Language Class Initialized
INFO - 2016-09-14 08:34:32 --> Config Class Initialized
INFO - 2016-09-14 08:34:32 --> Loader Class Initialized
INFO - 2016-09-14 08:34:32 --> Helper loaded: url_helper
INFO - 2016-09-14 08:34:32 --> Database Driver Class Initialized
INFO - 2016-09-14 08:34:32 --> Controller Class Initialized
DEBUG - 2016-09-14 08:34:32 --> Index MX_Controller Initialized
INFO - 2016-09-14 08:34:32 --> Model Class Initialized
INFO - 2016-09-14 08:34:32 --> Model Class Initialized
DEBUG - 2016-09-14 08:34:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 08:34:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 08:34:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 08:34:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-09-14 08:34:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 08:34:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 08:34:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 08:34:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 08:34:32 --> Final output sent to browser
DEBUG - 2016-09-14 08:34:32 --> Total execution time: 0.8895
INFO - 2016-09-14 08:34:56 --> Config Class Initialized
INFO - 2016-09-14 08:34:56 --> Hooks Class Initialized
DEBUG - 2016-09-14 08:34:56 --> UTF-8 Support Enabled
INFO - 2016-09-14 08:34:56 --> Utf8 Class Initialized
INFO - 2016-09-14 08:34:56 --> URI Class Initialized
INFO - 2016-09-14 08:34:56 --> Router Class Initialized
INFO - 2016-09-14 08:34:56 --> Output Class Initialized
INFO - 2016-09-14 08:34:56 --> Security Class Initialized
DEBUG - 2016-09-14 08:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 08:34:56 --> Input Class Initialized
INFO - 2016-09-14 08:34:56 --> Language Class Initialized
INFO - 2016-09-14 08:34:57 --> Language Class Initialized
INFO - 2016-09-14 08:34:57 --> Config Class Initialized
INFO - 2016-09-14 08:34:57 --> Loader Class Initialized
INFO - 2016-09-14 08:34:57 --> Helper loaded: url_helper
INFO - 2016-09-14 08:34:57 --> Database Driver Class Initialized
INFO - 2016-09-14 08:34:57 --> Controller Class Initialized
DEBUG - 2016-09-14 08:34:57 --> Index MX_Controller Initialized
INFO - 2016-09-14 08:34:57 --> Model Class Initialized
INFO - 2016-09-14 08:34:57 --> Model Class Initialized
DEBUG - 2016-09-14 08:34:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 08:34:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 08:34:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 08:34:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-09-14 08:34:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 08:34:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 08:34:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 08:34:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 08:34:57 --> Final output sent to browser
DEBUG - 2016-09-14 08:34:57 --> Total execution time: 0.9836
INFO - 2016-09-14 08:35:16 --> Config Class Initialized
INFO - 2016-09-14 08:35:16 --> Hooks Class Initialized
DEBUG - 2016-09-14 08:35:16 --> UTF-8 Support Enabled
INFO - 2016-09-14 08:35:16 --> Utf8 Class Initialized
INFO - 2016-09-14 08:35:16 --> URI Class Initialized
INFO - 2016-09-14 08:35:16 --> Router Class Initialized
INFO - 2016-09-14 08:35:16 --> Output Class Initialized
INFO - 2016-09-14 08:35:16 --> Security Class Initialized
DEBUG - 2016-09-14 08:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 08:35:16 --> Input Class Initialized
INFO - 2016-09-14 08:35:16 --> Language Class Initialized
INFO - 2016-09-14 08:35:16 --> Language Class Initialized
INFO - 2016-09-14 08:35:16 --> Config Class Initialized
INFO - 2016-09-14 08:35:16 --> Loader Class Initialized
INFO - 2016-09-14 08:35:16 --> Helper loaded: url_helper
INFO - 2016-09-14 08:35:16 --> Database Driver Class Initialized
INFO - 2016-09-14 08:35:16 --> Controller Class Initialized
DEBUG - 2016-09-14 08:35:16 --> Index MX_Controller Initialized
INFO - 2016-09-14 08:35:16 --> Model Class Initialized
INFO - 2016-09-14 08:35:16 --> Model Class Initialized
DEBUG - 2016-09-14 08:35:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 08:35:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 08:35:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 08:35:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-09-14 08:35:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 08:35:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 08:35:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 08:35:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 08:35:17 --> Final output sent to browser
DEBUG - 2016-09-14 08:35:17 --> Total execution time: 0.9188
INFO - 2016-09-14 08:36:05 --> Config Class Initialized
INFO - 2016-09-14 08:36:06 --> Hooks Class Initialized
DEBUG - 2016-09-14 08:36:06 --> UTF-8 Support Enabled
INFO - 2016-09-14 08:36:06 --> Utf8 Class Initialized
INFO - 2016-09-14 08:36:06 --> URI Class Initialized
INFO - 2016-09-14 08:36:06 --> Router Class Initialized
INFO - 2016-09-14 08:36:06 --> Output Class Initialized
INFO - 2016-09-14 08:36:06 --> Security Class Initialized
DEBUG - 2016-09-14 08:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 08:36:06 --> Input Class Initialized
INFO - 2016-09-14 08:36:06 --> Language Class Initialized
INFO - 2016-09-14 08:36:06 --> Language Class Initialized
INFO - 2016-09-14 08:36:06 --> Config Class Initialized
INFO - 2016-09-14 08:36:06 --> Loader Class Initialized
INFO - 2016-09-14 08:36:06 --> Helper loaded: url_helper
INFO - 2016-09-14 08:36:06 --> Database Driver Class Initialized
INFO - 2016-09-14 08:36:06 --> Controller Class Initialized
DEBUG - 2016-09-14 08:36:06 --> Index MX_Controller Initialized
INFO - 2016-09-14 08:36:06 --> Model Class Initialized
INFO - 2016-09-14 08:36:06 --> Model Class Initialized
DEBUG - 2016-09-14 08:36:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 08:36:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 08:36:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 08:36:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-09-14 08:36:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 08:36:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 08:36:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 08:36:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 08:36:06 --> Final output sent to browser
DEBUG - 2016-09-14 08:36:06 --> Total execution time: 0.9015
INFO - 2016-09-14 08:39:43 --> Config Class Initialized
INFO - 2016-09-14 08:39:43 --> Hooks Class Initialized
DEBUG - 2016-09-14 08:39:43 --> UTF-8 Support Enabled
INFO - 2016-09-14 08:39:43 --> Utf8 Class Initialized
INFO - 2016-09-14 08:39:43 --> URI Class Initialized
INFO - 2016-09-14 08:39:43 --> Router Class Initialized
INFO - 2016-09-14 08:39:43 --> Output Class Initialized
INFO - 2016-09-14 08:39:43 --> Security Class Initialized
DEBUG - 2016-09-14 08:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 08:39:43 --> Input Class Initialized
INFO - 2016-09-14 08:39:43 --> Language Class Initialized
INFO - 2016-09-14 08:39:43 --> Language Class Initialized
INFO - 2016-09-14 08:39:43 --> Config Class Initialized
INFO - 2016-09-14 08:39:43 --> Loader Class Initialized
INFO - 2016-09-14 08:39:43 --> Helper loaded: url_helper
INFO - 2016-09-14 08:39:43 --> Database Driver Class Initialized
INFO - 2016-09-14 08:39:43 --> Controller Class Initialized
DEBUG - 2016-09-14 08:39:43 --> Index MX_Controller Initialized
INFO - 2016-09-14 08:39:43 --> Model Class Initialized
INFO - 2016-09-14 08:39:43 --> Model Class Initialized
DEBUG - 2016-09-14 08:39:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 08:39:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 08:39:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 08:39:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-09-14 08:39:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 08:39:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 08:39:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 08:39:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 08:39:44 --> Final output sent to browser
DEBUG - 2016-09-14 08:39:44 --> Total execution time: 0.8328
INFO - 2016-09-14 08:40:10 --> Config Class Initialized
INFO - 2016-09-14 08:40:10 --> Hooks Class Initialized
DEBUG - 2016-09-14 08:40:10 --> UTF-8 Support Enabled
INFO - 2016-09-14 08:40:10 --> Utf8 Class Initialized
INFO - 2016-09-14 08:40:10 --> URI Class Initialized
INFO - 2016-09-14 08:40:10 --> Router Class Initialized
INFO - 2016-09-14 08:40:10 --> Output Class Initialized
INFO - 2016-09-14 08:40:10 --> Security Class Initialized
DEBUG - 2016-09-14 08:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 08:40:10 --> Input Class Initialized
INFO - 2016-09-14 08:40:10 --> Language Class Initialized
INFO - 2016-09-14 08:40:10 --> Language Class Initialized
INFO - 2016-09-14 08:40:10 --> Config Class Initialized
INFO - 2016-09-14 08:40:11 --> Loader Class Initialized
INFO - 2016-09-14 08:40:11 --> Helper loaded: url_helper
INFO - 2016-09-14 08:40:11 --> Database Driver Class Initialized
INFO - 2016-09-14 08:40:11 --> Controller Class Initialized
DEBUG - 2016-09-14 08:40:11 --> Index MX_Controller Initialized
INFO - 2016-09-14 08:40:11 --> Model Class Initialized
INFO - 2016-09-14 08:40:11 --> Model Class Initialized
DEBUG - 2016-09-14 08:40:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 08:40:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 08:40:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 08:40:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-09-14 08:40:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 08:40:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 08:40:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 08:40:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 08:40:11 --> Final output sent to browser
DEBUG - 2016-09-14 08:40:11 --> Total execution time: 0.9170
INFO - 2016-09-14 08:40:25 --> Config Class Initialized
INFO - 2016-09-14 08:40:25 --> Hooks Class Initialized
DEBUG - 2016-09-14 08:40:25 --> UTF-8 Support Enabled
INFO - 2016-09-14 08:40:25 --> Utf8 Class Initialized
INFO - 2016-09-14 08:40:25 --> URI Class Initialized
INFO - 2016-09-14 08:40:25 --> Router Class Initialized
INFO - 2016-09-14 08:40:25 --> Output Class Initialized
INFO - 2016-09-14 08:40:25 --> Security Class Initialized
DEBUG - 2016-09-14 08:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 08:40:25 --> Input Class Initialized
INFO - 2016-09-14 08:40:25 --> Language Class Initialized
INFO - 2016-09-14 08:40:25 --> Language Class Initialized
INFO - 2016-09-14 08:40:25 --> Config Class Initialized
INFO - 2016-09-14 08:40:25 --> Loader Class Initialized
INFO - 2016-09-14 08:40:25 --> Helper loaded: url_helper
INFO - 2016-09-14 08:40:25 --> Database Driver Class Initialized
INFO - 2016-09-14 08:40:26 --> Controller Class Initialized
DEBUG - 2016-09-14 08:40:26 --> Index MX_Controller Initialized
INFO - 2016-09-14 08:40:26 --> Model Class Initialized
INFO - 2016-09-14 08:40:26 --> Model Class Initialized
DEBUG - 2016-09-14 08:40:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 08:40:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 08:40:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 08:40:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-09-14 08:40:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 08:40:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 08:40:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 08:40:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 08:40:26 --> Final output sent to browser
DEBUG - 2016-09-14 08:40:26 --> Total execution time: 0.8667
INFO - 2016-09-14 08:40:34 --> Config Class Initialized
INFO - 2016-09-14 08:40:34 --> Hooks Class Initialized
DEBUG - 2016-09-14 08:40:34 --> UTF-8 Support Enabled
INFO - 2016-09-14 08:40:34 --> Utf8 Class Initialized
INFO - 2016-09-14 08:40:34 --> URI Class Initialized
INFO - 2016-09-14 08:40:34 --> Router Class Initialized
INFO - 2016-09-14 08:40:34 --> Output Class Initialized
INFO - 2016-09-14 08:40:35 --> Security Class Initialized
DEBUG - 2016-09-14 08:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 08:40:35 --> Input Class Initialized
INFO - 2016-09-14 08:40:35 --> Language Class Initialized
INFO - 2016-09-14 08:40:35 --> Language Class Initialized
INFO - 2016-09-14 08:40:35 --> Config Class Initialized
INFO - 2016-09-14 08:40:35 --> Loader Class Initialized
INFO - 2016-09-14 08:40:35 --> Helper loaded: url_helper
INFO - 2016-09-14 08:40:35 --> Database Driver Class Initialized
INFO - 2016-09-14 08:40:35 --> Controller Class Initialized
DEBUG - 2016-09-14 08:40:35 --> Index MX_Controller Initialized
INFO - 2016-09-14 08:40:35 --> Model Class Initialized
INFO - 2016-09-14 08:40:35 --> Model Class Initialized
DEBUG - 2016-09-14 08:40:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 08:40:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 08:40:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 08:40:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-09-14 08:40:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 08:40:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 08:40:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 08:40:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 08:40:35 --> Final output sent to browser
DEBUG - 2016-09-14 08:40:35 --> Total execution time: 0.8408
INFO - 2016-09-14 08:42:42 --> Config Class Initialized
INFO - 2016-09-14 08:42:42 --> Hooks Class Initialized
DEBUG - 2016-09-14 08:42:42 --> UTF-8 Support Enabled
INFO - 2016-09-14 08:42:42 --> Utf8 Class Initialized
INFO - 2016-09-14 08:42:42 --> URI Class Initialized
INFO - 2016-09-14 08:42:42 --> Router Class Initialized
INFO - 2016-09-14 08:42:42 --> Output Class Initialized
INFO - 2016-09-14 08:42:42 --> Security Class Initialized
DEBUG - 2016-09-14 08:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 08:42:42 --> Input Class Initialized
INFO - 2016-09-14 08:42:42 --> Language Class Initialized
INFO - 2016-09-14 08:42:42 --> Language Class Initialized
INFO - 2016-09-14 08:42:42 --> Config Class Initialized
INFO - 2016-09-14 08:42:42 --> Loader Class Initialized
INFO - 2016-09-14 08:42:42 --> Helper loaded: url_helper
INFO - 2016-09-14 08:42:42 --> Database Driver Class Initialized
INFO - 2016-09-14 08:42:42 --> Controller Class Initialized
DEBUG - 2016-09-14 08:42:42 --> Index MX_Controller Initialized
INFO - 2016-09-14 08:42:42 --> Model Class Initialized
INFO - 2016-09-14 08:42:42 --> Model Class Initialized
DEBUG - 2016-09-14 08:42:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 08:42:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 08:42:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 08:42:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-09-14 08:42:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 08:42:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 08:42:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 08:42:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 08:42:43 --> Final output sent to browser
DEBUG - 2016-09-14 08:42:43 --> Total execution time: 0.8493
INFO - 2016-09-14 08:43:26 --> Config Class Initialized
INFO - 2016-09-14 08:43:26 --> Hooks Class Initialized
DEBUG - 2016-09-14 08:43:26 --> UTF-8 Support Enabled
INFO - 2016-09-14 08:43:26 --> Utf8 Class Initialized
INFO - 2016-09-14 08:43:26 --> URI Class Initialized
INFO - 2016-09-14 08:43:26 --> Router Class Initialized
INFO - 2016-09-14 08:43:26 --> Output Class Initialized
INFO - 2016-09-14 08:43:26 --> Security Class Initialized
DEBUG - 2016-09-14 08:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 08:43:26 --> Input Class Initialized
INFO - 2016-09-14 08:43:26 --> Language Class Initialized
INFO - 2016-09-14 08:43:26 --> Language Class Initialized
INFO - 2016-09-14 08:43:26 --> Config Class Initialized
INFO - 2016-09-14 08:43:26 --> Loader Class Initialized
INFO - 2016-09-14 08:43:26 --> Helper loaded: url_helper
INFO - 2016-09-14 08:43:26 --> Database Driver Class Initialized
INFO - 2016-09-14 08:43:26 --> Controller Class Initialized
DEBUG - 2016-09-14 08:43:26 --> Index MX_Controller Initialized
INFO - 2016-09-14 08:43:26 --> Model Class Initialized
INFO - 2016-09-14 08:43:26 --> Model Class Initialized
DEBUG - 2016-09-14 08:43:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 08:43:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 08:43:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 08:43:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-09-14 08:43:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 08:43:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 08:43:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 08:43:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 08:43:27 --> Final output sent to browser
DEBUG - 2016-09-14 08:43:27 --> Total execution time: 0.8621
INFO - 2016-09-14 08:45:14 --> Config Class Initialized
INFO - 2016-09-14 08:45:14 --> Hooks Class Initialized
DEBUG - 2016-09-14 08:45:14 --> UTF-8 Support Enabled
INFO - 2016-09-14 08:45:14 --> Utf8 Class Initialized
INFO - 2016-09-14 08:45:14 --> URI Class Initialized
INFO - 2016-09-14 08:45:14 --> Router Class Initialized
INFO - 2016-09-14 08:45:14 --> Output Class Initialized
INFO - 2016-09-14 08:45:14 --> Security Class Initialized
DEBUG - 2016-09-14 08:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 08:45:14 --> Input Class Initialized
INFO - 2016-09-14 08:45:14 --> Language Class Initialized
INFO - 2016-09-14 08:45:14 --> Language Class Initialized
INFO - 2016-09-14 08:45:14 --> Config Class Initialized
INFO - 2016-09-14 08:45:14 --> Loader Class Initialized
INFO - 2016-09-14 08:45:15 --> Helper loaded: url_helper
INFO - 2016-09-14 08:45:15 --> Database Driver Class Initialized
INFO - 2016-09-14 08:45:15 --> Controller Class Initialized
DEBUG - 2016-09-14 08:45:15 --> Index MX_Controller Initialized
INFO - 2016-09-14 08:45:15 --> Model Class Initialized
INFO - 2016-09-14 08:45:15 --> Model Class Initialized
DEBUG - 2016-09-14 08:45:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 08:45:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 08:45:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 08:45:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-09-14 08:45:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 08:45:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 08:45:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 08:45:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 08:45:15 --> Final output sent to browser
DEBUG - 2016-09-14 08:45:15 --> Total execution time: 0.9361
INFO - 2016-09-14 08:54:23 --> Config Class Initialized
INFO - 2016-09-14 08:54:23 --> Hooks Class Initialized
DEBUG - 2016-09-14 08:54:23 --> UTF-8 Support Enabled
INFO - 2016-09-14 08:54:23 --> Utf8 Class Initialized
INFO - 2016-09-14 08:54:23 --> URI Class Initialized
INFO - 2016-09-14 08:54:23 --> Router Class Initialized
INFO - 2016-09-14 08:54:23 --> Output Class Initialized
INFO - 2016-09-14 08:54:23 --> Security Class Initialized
DEBUG - 2016-09-14 08:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 08:54:23 --> Input Class Initialized
INFO - 2016-09-14 08:54:23 --> Language Class Initialized
INFO - 2016-09-14 08:54:23 --> Language Class Initialized
INFO - 2016-09-14 08:54:23 --> Config Class Initialized
INFO - 2016-09-14 08:54:23 --> Loader Class Initialized
INFO - 2016-09-14 08:54:23 --> Helper loaded: url_helper
INFO - 2016-09-14 08:54:23 --> Database Driver Class Initialized
INFO - 2016-09-14 08:54:24 --> Controller Class Initialized
DEBUG - 2016-09-14 08:54:24 --> Index MX_Controller Initialized
INFO - 2016-09-14 08:54:24 --> Model Class Initialized
INFO - 2016-09-14 08:54:24 --> Model Class Initialized
DEBUG - 2016-09-14 08:54:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 08:54:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 08:54:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 08:54:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-09-14 08:54:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 08:54:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 08:54:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 08:54:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 08:54:24 --> Final output sent to browser
DEBUG - 2016-09-14 08:54:24 --> Total execution time: 0.9908
INFO - 2016-09-14 09:29:09 --> Config Class Initialized
INFO - 2016-09-14 09:29:09 --> Hooks Class Initialized
DEBUG - 2016-09-14 09:29:10 --> UTF-8 Support Enabled
INFO - 2016-09-14 09:29:10 --> Utf8 Class Initialized
INFO - 2016-09-14 09:29:10 --> URI Class Initialized
INFO - 2016-09-14 09:29:10 --> Router Class Initialized
INFO - 2016-09-14 09:29:10 --> Output Class Initialized
INFO - 2016-09-14 09:29:10 --> Security Class Initialized
DEBUG - 2016-09-14 09:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 09:29:10 --> Input Class Initialized
INFO - 2016-09-14 09:29:10 --> Language Class Initialized
INFO - 2016-09-14 09:29:11 --> Language Class Initialized
INFO - 2016-09-14 09:29:11 --> Config Class Initialized
INFO - 2016-09-14 09:29:11 --> Loader Class Initialized
INFO - 2016-09-14 09:29:11 --> Helper loaded: url_helper
INFO - 2016-09-14 09:29:11 --> Database Driver Class Initialized
INFO - 2016-09-14 09:29:11 --> Controller Class Initialized
DEBUG - 2016-09-14 09:29:11 --> Index MX_Controller Initialized
INFO - 2016-09-14 09:29:11 --> Model Class Initialized
INFO - 2016-09-14 09:29:11 --> Model Class Initialized
DEBUG - 2016-09-14 09:29:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 09:29:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 09:29:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 09:29:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-09-14 09:29:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 09:29:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 09:29:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 09:29:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 09:29:12 --> Final output sent to browser
DEBUG - 2016-09-14 09:29:12 --> Total execution time: 2.6891
INFO - 2016-09-14 09:30:07 --> Config Class Initialized
INFO - 2016-09-14 09:30:07 --> Hooks Class Initialized
DEBUG - 2016-09-14 09:30:07 --> UTF-8 Support Enabled
INFO - 2016-09-14 09:30:07 --> Utf8 Class Initialized
INFO - 2016-09-14 09:30:07 --> URI Class Initialized
INFO - 2016-09-14 09:30:07 --> Router Class Initialized
INFO - 2016-09-14 09:30:07 --> Output Class Initialized
INFO - 2016-09-14 09:30:07 --> Security Class Initialized
DEBUG - 2016-09-14 09:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 09:30:07 --> Input Class Initialized
INFO - 2016-09-14 09:30:07 --> Language Class Initialized
INFO - 2016-09-14 09:30:07 --> Language Class Initialized
INFO - 2016-09-14 09:30:07 --> Config Class Initialized
INFO - 2016-09-14 09:30:08 --> Loader Class Initialized
INFO - 2016-09-14 09:30:08 --> Helper loaded: url_helper
INFO - 2016-09-14 09:30:08 --> Database Driver Class Initialized
INFO - 2016-09-14 09:30:08 --> Controller Class Initialized
DEBUG - 2016-09-14 09:30:08 --> Index MX_Controller Initialized
INFO - 2016-09-14 09:30:08 --> Model Class Initialized
INFO - 2016-09-14 09:30:08 --> Model Class Initialized
INFO - 2016-09-14 09:30:08 --> Final output sent to browser
DEBUG - 2016-09-14 09:30:08 --> Total execution time: 0.7654
INFO - 2016-09-14 09:30:22 --> Config Class Initialized
INFO - 2016-09-14 09:30:22 --> Hooks Class Initialized
DEBUG - 2016-09-14 09:30:22 --> UTF-8 Support Enabled
INFO - 2016-09-14 09:30:22 --> Utf8 Class Initialized
INFO - 2016-09-14 09:30:22 --> URI Class Initialized
INFO - 2016-09-14 09:30:22 --> Router Class Initialized
INFO - 2016-09-14 09:30:23 --> Output Class Initialized
INFO - 2016-09-14 09:30:23 --> Security Class Initialized
DEBUG - 2016-09-14 09:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 09:30:23 --> Input Class Initialized
INFO - 2016-09-14 09:30:23 --> Language Class Initialized
INFO - 2016-09-14 09:30:23 --> Language Class Initialized
INFO - 2016-09-14 09:30:23 --> Config Class Initialized
INFO - 2016-09-14 09:30:23 --> Loader Class Initialized
INFO - 2016-09-14 09:30:23 --> Helper loaded: url_helper
INFO - 2016-09-14 09:30:23 --> Database Driver Class Initialized
INFO - 2016-09-14 09:30:23 --> Controller Class Initialized
DEBUG - 2016-09-14 09:30:23 --> Index MX_Controller Initialized
INFO - 2016-09-14 09:30:23 --> Model Class Initialized
INFO - 2016-09-14 09:30:23 --> Model Class Initialized
INFO - 2016-09-14 09:30:23 --> Final output sent to browser
DEBUG - 2016-09-14 09:30:23 --> Total execution time: 0.7541
INFO - 2016-09-14 09:35:17 --> Config Class Initialized
INFO - 2016-09-14 09:35:18 --> Hooks Class Initialized
DEBUG - 2016-09-14 09:35:18 --> UTF-8 Support Enabled
INFO - 2016-09-14 09:35:18 --> Utf8 Class Initialized
INFO - 2016-09-14 09:35:18 --> URI Class Initialized
INFO - 2016-09-14 09:35:18 --> Router Class Initialized
INFO - 2016-09-14 09:35:18 --> Output Class Initialized
INFO - 2016-09-14 09:35:18 --> Security Class Initialized
DEBUG - 2016-09-14 09:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 09:35:18 --> Input Class Initialized
INFO - 2016-09-14 09:35:18 --> Language Class Initialized
INFO - 2016-09-14 09:35:18 --> Language Class Initialized
INFO - 2016-09-14 09:35:18 --> Config Class Initialized
INFO - 2016-09-14 09:35:18 --> Loader Class Initialized
INFO - 2016-09-14 09:35:18 --> Helper loaded: url_helper
INFO - 2016-09-14 09:35:18 --> Database Driver Class Initialized
INFO - 2016-09-14 09:35:18 --> Controller Class Initialized
DEBUG - 2016-09-14 09:35:18 --> Index MX_Controller Initialized
INFO - 2016-09-14 09:35:18 --> Model Class Initialized
INFO - 2016-09-14 09:35:18 --> Model Class Initialized
DEBUG - 2016-09-14 09:35:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 09:35:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 09:35:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 09:35:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-09-14 09:35:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 09:35:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 09:35:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 09:35:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 09:35:18 --> Final output sent to browser
DEBUG - 2016-09-14 09:35:18 --> Total execution time: 0.9039
INFO - 2016-09-14 09:35:24 --> Config Class Initialized
INFO - 2016-09-14 09:35:24 --> Hooks Class Initialized
DEBUG - 2016-09-14 09:35:24 --> UTF-8 Support Enabled
INFO - 2016-09-14 09:35:24 --> Utf8 Class Initialized
INFO - 2016-09-14 09:35:24 --> URI Class Initialized
INFO - 2016-09-14 09:35:24 --> Router Class Initialized
INFO - 2016-09-14 09:35:24 --> Output Class Initialized
INFO - 2016-09-14 09:35:24 --> Security Class Initialized
DEBUG - 2016-09-14 09:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 09:35:24 --> Input Class Initialized
INFO - 2016-09-14 09:35:24 --> Language Class Initialized
INFO - 2016-09-14 09:35:24 --> Language Class Initialized
INFO - 2016-09-14 09:35:24 --> Config Class Initialized
INFO - 2016-09-14 09:35:24 --> Loader Class Initialized
INFO - 2016-09-14 09:35:24 --> Helper loaded: url_helper
INFO - 2016-09-14 09:35:24 --> Database Driver Class Initialized
INFO - 2016-09-14 09:35:24 --> Controller Class Initialized
DEBUG - 2016-09-14 09:35:24 --> Index MX_Controller Initialized
INFO - 2016-09-14 09:35:25 --> Model Class Initialized
INFO - 2016-09-14 09:35:25 --> Model Class Initialized
INFO - 2016-09-14 09:35:25 --> Final output sent to browser
DEBUG - 2016-09-14 09:35:25 --> Total execution time: 0.8108
INFO - 2016-09-14 09:35:27 --> Config Class Initialized
INFO - 2016-09-14 09:35:27 --> Hooks Class Initialized
DEBUG - 2016-09-14 09:35:27 --> UTF-8 Support Enabled
INFO - 2016-09-14 09:35:27 --> Utf8 Class Initialized
INFO - 2016-09-14 09:35:27 --> URI Class Initialized
INFO - 2016-09-14 09:35:27 --> Router Class Initialized
INFO - 2016-09-14 09:35:27 --> Output Class Initialized
INFO - 2016-09-14 09:35:27 --> Security Class Initialized
DEBUG - 2016-09-14 09:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 09:35:28 --> Input Class Initialized
INFO - 2016-09-14 09:35:28 --> Language Class Initialized
INFO - 2016-09-14 09:35:28 --> Language Class Initialized
INFO - 2016-09-14 09:35:28 --> Config Class Initialized
INFO - 2016-09-14 09:35:28 --> Loader Class Initialized
INFO - 2016-09-14 09:35:28 --> Helper loaded: url_helper
INFO - 2016-09-14 09:35:28 --> Database Driver Class Initialized
INFO - 2016-09-14 09:35:28 --> Controller Class Initialized
DEBUG - 2016-09-14 09:35:28 --> Index MX_Controller Initialized
INFO - 2016-09-14 09:35:28 --> Model Class Initialized
INFO - 2016-09-14 09:35:28 --> Model Class Initialized
INFO - 2016-09-14 09:35:28 --> Final output sent to browser
DEBUG - 2016-09-14 09:35:28 --> Total execution time: 0.7893
INFO - 2016-09-14 09:38:34 --> Config Class Initialized
INFO - 2016-09-14 09:38:34 --> Hooks Class Initialized
DEBUG - 2016-09-14 09:38:34 --> UTF-8 Support Enabled
INFO - 2016-09-14 09:38:34 --> Utf8 Class Initialized
INFO - 2016-09-14 09:38:34 --> URI Class Initialized
INFO - 2016-09-14 09:38:34 --> Router Class Initialized
INFO - 2016-09-14 09:38:34 --> Output Class Initialized
INFO - 2016-09-14 09:38:34 --> Security Class Initialized
DEBUG - 2016-09-14 09:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 09:38:35 --> Input Class Initialized
INFO - 2016-09-14 09:38:35 --> Language Class Initialized
INFO - 2016-09-14 09:38:35 --> Language Class Initialized
INFO - 2016-09-14 09:38:35 --> Config Class Initialized
INFO - 2016-09-14 09:38:35 --> Loader Class Initialized
INFO - 2016-09-14 09:38:35 --> Helper loaded: url_helper
INFO - 2016-09-14 09:38:35 --> Database Driver Class Initialized
INFO - 2016-09-14 09:38:35 --> Controller Class Initialized
DEBUG - 2016-09-14 09:38:35 --> Index MX_Controller Initialized
INFO - 2016-09-14 09:38:35 --> Model Class Initialized
INFO - 2016-09-14 09:38:35 --> Model Class Initialized
DEBUG - 2016-09-14 09:38:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 09:38:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 09:38:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 09:38:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-09-14 09:38:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 09:38:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 09:38:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 09:38:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 09:38:35 --> Final output sent to browser
DEBUG - 2016-09-14 09:38:35 --> Total execution time: 0.8965
INFO - 2016-09-14 09:38:44 --> Config Class Initialized
INFO - 2016-09-14 09:38:44 --> Hooks Class Initialized
DEBUG - 2016-09-14 09:38:44 --> UTF-8 Support Enabled
INFO - 2016-09-14 09:38:44 --> Utf8 Class Initialized
INFO - 2016-09-14 09:38:44 --> URI Class Initialized
INFO - 2016-09-14 09:38:44 --> Router Class Initialized
INFO - 2016-09-14 09:38:44 --> Output Class Initialized
INFO - 2016-09-14 09:38:44 --> Security Class Initialized
DEBUG - 2016-09-14 09:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 09:38:44 --> Input Class Initialized
INFO - 2016-09-14 09:38:44 --> Language Class Initialized
INFO - 2016-09-14 09:38:44 --> Language Class Initialized
INFO - 2016-09-14 09:38:44 --> Config Class Initialized
INFO - 2016-09-14 09:38:44 --> Loader Class Initialized
INFO - 2016-09-14 09:38:44 --> Helper loaded: url_helper
INFO - 2016-09-14 09:38:44 --> Database Driver Class Initialized
INFO - 2016-09-14 09:38:44 --> Controller Class Initialized
DEBUG - 2016-09-14 09:38:44 --> Index MX_Controller Initialized
INFO - 2016-09-14 09:38:44 --> Model Class Initialized
INFO - 2016-09-14 09:38:44 --> Model Class Initialized
INFO - 2016-09-14 09:38:45 --> Final output sent to browser
DEBUG - 2016-09-14 09:38:45 --> Total execution time: 0.8027
INFO - 2016-09-14 12:16:38 --> Config Class Initialized
INFO - 2016-09-14 12:16:38 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:16:38 --> UTF-8 Support Enabled
INFO - 2016-09-14 12:16:38 --> Utf8 Class Initialized
INFO - 2016-09-14 12:16:38 --> URI Class Initialized
INFO - 2016-09-14 12:16:38 --> Router Class Initialized
INFO - 2016-09-14 12:16:38 --> Output Class Initialized
INFO - 2016-09-14 12:16:38 --> Security Class Initialized
DEBUG - 2016-09-14 12:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 12:16:38 --> Input Class Initialized
INFO - 2016-09-14 12:16:38 --> Language Class Initialized
INFO - 2016-09-14 12:16:38 --> Language Class Initialized
INFO - 2016-09-14 12:16:38 --> Config Class Initialized
INFO - 2016-09-14 12:16:38 --> Loader Class Initialized
INFO - 2016-09-14 12:16:38 --> Helper loaded: url_helper
INFO - 2016-09-14 12:16:38 --> Database Driver Class Initialized
INFO - 2016-09-14 12:16:38 --> Controller Class Initialized
DEBUG - 2016-09-14 12:16:38 --> Index MX_Controller Initialized
INFO - 2016-09-14 12:16:38 --> Model Class Initialized
INFO - 2016-09-14 12:16:38 --> Model Class Initialized
DEBUG - 2016-09-14 12:16:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 12:16:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 12:16:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 12:16:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-09-14 12:16:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 12:16:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 12:16:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 12:16:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 12:16:39 --> Final output sent to browser
DEBUG - 2016-09-14 12:16:39 --> Total execution time: 0.8181
INFO - 2016-09-14 12:16:51 --> Config Class Initialized
INFO - 2016-09-14 12:16:51 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:16:51 --> UTF-8 Support Enabled
INFO - 2016-09-14 12:16:51 --> Utf8 Class Initialized
INFO - 2016-09-14 12:16:51 --> URI Class Initialized
INFO - 2016-09-14 12:16:51 --> Router Class Initialized
INFO - 2016-09-14 12:16:51 --> Output Class Initialized
INFO - 2016-09-14 12:16:51 --> Security Class Initialized
DEBUG - 2016-09-14 12:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 12:16:51 --> Input Class Initialized
INFO - 2016-09-14 12:16:51 --> Language Class Initialized
INFO - 2016-09-14 12:16:51 --> Language Class Initialized
INFO - 2016-09-14 12:16:51 --> Config Class Initialized
INFO - 2016-09-14 12:16:51 --> Loader Class Initialized
INFO - 2016-09-14 12:16:51 --> Helper loaded: url_helper
INFO - 2016-09-14 12:16:51 --> Database Driver Class Initialized
INFO - 2016-09-14 12:16:51 --> Controller Class Initialized
DEBUG - 2016-09-14 12:16:51 --> Index MX_Controller Initialized
INFO - 2016-09-14 12:16:51 --> Model Class Initialized
INFO - 2016-09-14 12:16:51 --> Model Class Initialized
DEBUG - 2016-09-14 12:16:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 12:16:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 12:16:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 12:16:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-09-14 12:16:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 12:16:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 12:16:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 12:16:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 12:16:51 --> Final output sent to browser
DEBUG - 2016-09-14 12:16:51 --> Total execution time: 0.8821
INFO - 2016-09-14 12:17:08 --> Config Class Initialized
INFO - 2016-09-14 12:17:08 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:17:08 --> UTF-8 Support Enabled
INFO - 2016-09-14 12:17:08 --> Utf8 Class Initialized
INFO - 2016-09-14 12:17:08 --> URI Class Initialized
INFO - 2016-09-14 12:17:08 --> Router Class Initialized
INFO - 2016-09-14 12:17:08 --> Output Class Initialized
INFO - 2016-09-14 12:17:08 --> Security Class Initialized
DEBUG - 2016-09-14 12:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 12:17:08 --> Input Class Initialized
INFO - 2016-09-14 12:17:08 --> Language Class Initialized
INFO - 2016-09-14 12:17:08 --> Language Class Initialized
INFO - 2016-09-14 12:17:08 --> Config Class Initialized
INFO - 2016-09-14 12:17:08 --> Loader Class Initialized
INFO - 2016-09-14 12:17:08 --> Helper loaded: url_helper
INFO - 2016-09-14 12:17:08 --> Database Driver Class Initialized
INFO - 2016-09-14 12:17:08 --> Controller Class Initialized
DEBUG - 2016-09-14 12:17:08 --> Index MX_Controller Initialized
INFO - 2016-09-14 12:17:08 --> Model Class Initialized
INFO - 2016-09-14 12:17:08 --> Model Class Initialized
INFO - 2016-09-14 12:17:08 --> Final output sent to browser
DEBUG - 2016-09-14 12:17:08 --> Total execution time: 0.6175
INFO - 2016-09-14 12:17:08 --> Config Class Initialized
INFO - 2016-09-14 12:17:08 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:17:08 --> UTF-8 Support Enabled
INFO - 2016-09-14 12:17:08 --> Utf8 Class Initialized
INFO - 2016-09-14 12:17:08 --> URI Class Initialized
INFO - 2016-09-14 12:17:08 --> Router Class Initialized
INFO - 2016-09-14 12:17:09 --> Output Class Initialized
INFO - 2016-09-14 12:17:09 --> Security Class Initialized
DEBUG - 2016-09-14 12:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 12:17:09 --> Input Class Initialized
INFO - 2016-09-14 12:17:09 --> Language Class Initialized
INFO - 2016-09-14 12:17:09 --> Language Class Initialized
INFO - 2016-09-14 12:17:09 --> Config Class Initialized
INFO - 2016-09-14 12:17:09 --> Loader Class Initialized
INFO - 2016-09-14 12:17:09 --> Helper loaded: url_helper
INFO - 2016-09-14 12:17:09 --> Database Driver Class Initialized
INFO - 2016-09-14 12:17:09 --> Controller Class Initialized
DEBUG - 2016-09-14 12:17:09 --> Index MX_Controller Initialized
INFO - 2016-09-14 12:17:09 --> Model Class Initialized
INFO - 2016-09-14 12:17:09 --> Model Class Initialized
DEBUG - 2016-09-14 12:17:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 12:17:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 12:17:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 12:17:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-14 12:17:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 12:17:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 12:17:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 12:17:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 12:17:09 --> Final output sent to browser
DEBUG - 2016-09-14 12:17:09 --> Total execution time: 0.8989
INFO - 2016-09-14 12:17:14 --> Config Class Initialized
INFO - 2016-09-14 12:17:14 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:17:14 --> UTF-8 Support Enabled
INFO - 2016-09-14 12:17:14 --> Utf8 Class Initialized
INFO - 2016-09-14 12:17:14 --> URI Class Initialized
INFO - 2016-09-14 12:17:14 --> Router Class Initialized
INFO - 2016-09-14 12:17:14 --> Output Class Initialized
INFO - 2016-09-14 12:17:14 --> Security Class Initialized
DEBUG - 2016-09-14 12:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 12:17:14 --> Input Class Initialized
INFO - 2016-09-14 12:17:14 --> Language Class Initialized
INFO - 2016-09-14 12:17:14 --> Language Class Initialized
INFO - 2016-09-14 12:17:14 --> Config Class Initialized
INFO - 2016-09-14 12:17:14 --> Loader Class Initialized
INFO - 2016-09-14 12:17:14 --> Helper loaded: url_helper
INFO - 2016-09-14 12:17:14 --> Database Driver Class Initialized
INFO - 2016-09-14 12:17:14 --> Controller Class Initialized
DEBUG - 2016-09-14 12:17:14 --> Index MX_Controller Initialized
INFO - 2016-09-14 12:17:14 --> Model Class Initialized
INFO - 2016-09-14 12:17:14 --> Model Class Initialized
DEBUG - 2016-09-14 12:17:14 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 12:17:14 --> Database Driver Class Initialized
INFO - 2016-09-14 12:17:14 --> Final output sent to browser
DEBUG - 2016-09-14 12:17:14 --> Total execution time: 0.6693
INFO - 2016-09-14 12:17:15 --> Config Class Initialized
INFO - 2016-09-14 12:17:15 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:17:15 --> UTF-8 Support Enabled
INFO - 2016-09-14 12:17:15 --> Utf8 Class Initialized
INFO - 2016-09-14 12:17:15 --> URI Class Initialized
INFO - 2016-09-14 12:17:15 --> Router Class Initialized
INFO - 2016-09-14 12:17:15 --> Output Class Initialized
INFO - 2016-09-14 12:17:15 --> Security Class Initialized
DEBUG - 2016-09-14 12:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 12:17:15 --> Input Class Initialized
INFO - 2016-09-14 12:17:15 --> Language Class Initialized
INFO - 2016-09-14 12:17:15 --> Language Class Initialized
INFO - 2016-09-14 12:17:15 --> Config Class Initialized
INFO - 2016-09-14 12:17:15 --> Loader Class Initialized
INFO - 2016-09-14 12:17:15 --> Helper loaded: url_helper
INFO - 2016-09-14 12:17:15 --> Database Driver Class Initialized
INFO - 2016-09-14 12:17:16 --> Controller Class Initialized
DEBUG - 2016-09-14 12:17:16 --> Index MX_Controller Initialized
INFO - 2016-09-14 12:17:16 --> Model Class Initialized
INFO - 2016-09-14 12:17:16 --> Model Class Initialized
DEBUG - 2016-09-14 12:17:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 12:17:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 12:17:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 12:17:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_umum.php
DEBUG - 2016-09-14 12:17:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 12:17:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 12:17:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 12:17:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 12:17:16 --> Final output sent to browser
DEBUG - 2016-09-14 12:17:16 --> Total execution time: 0.8425
INFO - 2016-09-14 12:17:22 --> Config Class Initialized
INFO - 2016-09-14 12:17:22 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:17:22 --> UTF-8 Support Enabled
INFO - 2016-09-14 12:17:22 --> Utf8 Class Initialized
INFO - 2016-09-14 12:17:22 --> URI Class Initialized
INFO - 2016-09-14 12:17:22 --> Router Class Initialized
INFO - 2016-09-14 12:17:22 --> Output Class Initialized
INFO - 2016-09-14 12:17:22 --> Security Class Initialized
DEBUG - 2016-09-14 12:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 12:17:22 --> Input Class Initialized
INFO - 2016-09-14 12:17:22 --> Language Class Initialized
INFO - 2016-09-14 12:17:22 --> Language Class Initialized
INFO - 2016-09-14 12:17:22 --> Config Class Initialized
INFO - 2016-09-14 12:17:22 --> Loader Class Initialized
INFO - 2016-09-14 12:17:22 --> Helper loaded: url_helper
INFO - 2016-09-14 12:17:22 --> Database Driver Class Initialized
INFO - 2016-09-14 12:17:22 --> Controller Class Initialized
DEBUG - 2016-09-14 12:17:22 --> Index MX_Controller Initialized
INFO - 2016-09-14 12:17:23 --> Model Class Initialized
INFO - 2016-09-14 12:17:23 --> Model Class Initialized
DEBUG - 2016-09-14 12:17:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 12:17:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 12:17:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 12:17:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-09-14 12:17:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 12:17:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 12:17:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 12:17:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 12:17:23 --> Final output sent to browser
DEBUG - 2016-09-14 12:17:23 --> Total execution time: 0.8193
INFO - 2016-09-14 12:17:29 --> Config Class Initialized
INFO - 2016-09-14 12:17:29 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:17:29 --> UTF-8 Support Enabled
INFO - 2016-09-14 12:17:29 --> Utf8 Class Initialized
INFO - 2016-09-14 12:17:29 --> URI Class Initialized
INFO - 2016-09-14 12:17:29 --> Router Class Initialized
INFO - 2016-09-14 12:17:29 --> Output Class Initialized
INFO - 2016-09-14 12:17:29 --> Security Class Initialized
DEBUG - 2016-09-14 12:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 12:17:29 --> Input Class Initialized
INFO - 2016-09-14 12:17:29 --> Language Class Initialized
INFO - 2016-09-14 12:17:29 --> Language Class Initialized
INFO - 2016-09-14 12:17:29 --> Config Class Initialized
INFO - 2016-09-14 12:17:29 --> Loader Class Initialized
INFO - 2016-09-14 12:17:29 --> Helper loaded: url_helper
INFO - 2016-09-14 12:17:30 --> Database Driver Class Initialized
INFO - 2016-09-14 12:17:30 --> Controller Class Initialized
DEBUG - 2016-09-14 12:17:30 --> Index MX_Controller Initialized
INFO - 2016-09-14 12:17:30 --> Model Class Initialized
INFO - 2016-09-14 12:17:30 --> Model Class Initialized
INFO - 2016-09-14 12:17:30 --> Final output sent to browser
DEBUG - 2016-09-14 12:17:30 --> Total execution time: 0.6296
INFO - 2016-09-14 12:18:05 --> Config Class Initialized
INFO - 2016-09-14 12:18:05 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:18:05 --> UTF-8 Support Enabled
INFO - 2016-09-14 12:18:05 --> Utf8 Class Initialized
INFO - 2016-09-14 12:18:05 --> URI Class Initialized
INFO - 2016-09-14 12:18:05 --> Router Class Initialized
INFO - 2016-09-14 12:18:05 --> Output Class Initialized
INFO - 2016-09-14 12:18:05 --> Security Class Initialized
DEBUG - 2016-09-14 12:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 12:18:05 --> Input Class Initialized
INFO - 2016-09-14 12:18:05 --> Language Class Initialized
INFO - 2016-09-14 12:18:05 --> Language Class Initialized
INFO - 2016-09-14 12:18:05 --> Config Class Initialized
INFO - 2016-09-14 12:18:05 --> Loader Class Initialized
INFO - 2016-09-14 12:18:05 --> Helper loaded: url_helper
INFO - 2016-09-14 12:18:05 --> Database Driver Class Initialized
INFO - 2016-09-14 12:18:05 --> Controller Class Initialized
DEBUG - 2016-09-14 12:18:05 --> Index MX_Controller Initialized
INFO - 2016-09-14 12:18:05 --> Model Class Initialized
INFO - 2016-09-14 12:18:05 --> Model Class Initialized
INFO - 2016-09-14 12:18:05 --> Final output sent to browser
DEBUG - 2016-09-14 12:18:05 --> Total execution time: 0.7266
INFO - 2016-09-14 12:18:48 --> Config Class Initialized
INFO - 2016-09-14 12:18:48 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:18:48 --> UTF-8 Support Enabled
INFO - 2016-09-14 12:18:48 --> Utf8 Class Initialized
INFO - 2016-09-14 12:18:48 --> URI Class Initialized
INFO - 2016-09-14 12:18:48 --> Router Class Initialized
INFO - 2016-09-14 12:18:48 --> Output Class Initialized
INFO - 2016-09-14 12:18:48 --> Security Class Initialized
DEBUG - 2016-09-14 12:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 12:18:48 --> Input Class Initialized
INFO - 2016-09-14 12:18:48 --> Language Class Initialized
INFO - 2016-09-14 12:18:48 --> Language Class Initialized
INFO - 2016-09-14 12:18:48 --> Config Class Initialized
INFO - 2016-09-14 12:18:48 --> Loader Class Initialized
INFO - 2016-09-14 12:18:48 --> Helper loaded: url_helper
INFO - 2016-09-14 12:18:48 --> Database Driver Class Initialized
INFO - 2016-09-14 12:18:48 --> Controller Class Initialized
DEBUG - 2016-09-14 12:18:48 --> Index MX_Controller Initialized
INFO - 2016-09-14 12:18:48 --> Model Class Initialized
INFO - 2016-09-14 12:18:48 --> Model Class Initialized
INFO - 2016-09-14 12:18:48 --> Final output sent to browser
DEBUG - 2016-09-14 12:18:48 --> Total execution time: 0.6032
INFO - 2016-09-14 12:20:46 --> Config Class Initialized
INFO - 2016-09-14 12:20:46 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:20:46 --> UTF-8 Support Enabled
INFO - 2016-09-14 12:20:46 --> Utf8 Class Initialized
INFO - 2016-09-14 12:20:46 --> URI Class Initialized
INFO - 2016-09-14 12:20:46 --> Router Class Initialized
INFO - 2016-09-14 12:20:46 --> Output Class Initialized
INFO - 2016-09-14 12:20:46 --> Security Class Initialized
DEBUG - 2016-09-14 12:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 12:20:46 --> Input Class Initialized
INFO - 2016-09-14 12:20:46 --> Language Class Initialized
INFO - 2016-09-14 12:20:46 --> Language Class Initialized
INFO - 2016-09-14 12:20:46 --> Config Class Initialized
INFO - 2016-09-14 12:20:46 --> Loader Class Initialized
INFO - 2016-09-14 12:20:46 --> Helper loaded: url_helper
INFO - 2016-09-14 12:20:46 --> Database Driver Class Initialized
INFO - 2016-09-14 12:20:46 --> Controller Class Initialized
DEBUG - 2016-09-14 12:20:46 --> Index MX_Controller Initialized
INFO - 2016-09-14 12:20:46 --> Model Class Initialized
INFO - 2016-09-14 12:20:46 --> Model Class Initialized
INFO - 2016-09-14 12:20:47 --> Final output sent to browser
DEBUG - 2016-09-14 12:20:47 --> Total execution time: 0.7159
INFO - 2016-09-14 12:21:45 --> Config Class Initialized
INFO - 2016-09-14 12:21:45 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:21:45 --> UTF-8 Support Enabled
INFO - 2016-09-14 12:21:45 --> Utf8 Class Initialized
INFO - 2016-09-14 12:21:45 --> URI Class Initialized
INFO - 2016-09-14 12:21:45 --> Router Class Initialized
INFO - 2016-09-14 12:21:46 --> Output Class Initialized
INFO - 2016-09-14 12:21:46 --> Security Class Initialized
DEBUG - 2016-09-14 12:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 12:21:46 --> Input Class Initialized
INFO - 2016-09-14 12:21:46 --> Language Class Initialized
INFO - 2016-09-14 12:21:46 --> Language Class Initialized
INFO - 2016-09-14 12:21:46 --> Config Class Initialized
INFO - 2016-09-14 12:21:46 --> Loader Class Initialized
INFO - 2016-09-14 12:21:46 --> Helper loaded: url_helper
INFO - 2016-09-14 12:21:46 --> Database Driver Class Initialized
INFO - 2016-09-14 12:21:46 --> Controller Class Initialized
DEBUG - 2016-09-14 12:21:46 --> Index MX_Controller Initialized
INFO - 2016-09-14 12:21:46 --> Model Class Initialized
INFO - 2016-09-14 12:21:46 --> Model Class Initialized
INFO - 2016-09-14 12:21:46 --> Final output sent to browser
DEBUG - 2016-09-14 12:21:46 --> Total execution time: 0.7916
INFO - 2016-09-14 12:23:06 --> Config Class Initialized
INFO - 2016-09-14 12:23:06 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:23:06 --> UTF-8 Support Enabled
INFO - 2016-09-14 12:23:06 --> Utf8 Class Initialized
INFO - 2016-09-14 12:23:06 --> URI Class Initialized
INFO - 2016-09-14 12:23:06 --> Router Class Initialized
INFO - 2016-09-14 12:23:06 --> Output Class Initialized
INFO - 2016-09-14 12:23:06 --> Security Class Initialized
DEBUG - 2016-09-14 12:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 12:23:06 --> Input Class Initialized
INFO - 2016-09-14 12:23:06 --> Language Class Initialized
INFO - 2016-09-14 12:23:06 --> Language Class Initialized
INFO - 2016-09-14 12:23:06 --> Config Class Initialized
INFO - 2016-09-14 12:23:06 --> Loader Class Initialized
INFO - 2016-09-14 12:23:07 --> Helper loaded: url_helper
INFO - 2016-09-14 12:23:07 --> Database Driver Class Initialized
INFO - 2016-09-14 12:23:07 --> Controller Class Initialized
DEBUG - 2016-09-14 12:23:07 --> Index MX_Controller Initialized
INFO - 2016-09-14 12:23:07 --> Model Class Initialized
INFO - 2016-09-14 12:23:07 --> Model Class Initialized
DEBUG - 2016-09-14 12:23:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 12:23:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 12:23:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 12:23:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-09-14 12:23:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 12:23:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 12:23:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 12:23:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 12:23:07 --> Final output sent to browser
DEBUG - 2016-09-14 12:23:07 --> Total execution time: 0.8546
INFO - 2016-09-14 12:23:14 --> Config Class Initialized
INFO - 2016-09-14 12:23:14 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:23:14 --> UTF-8 Support Enabled
INFO - 2016-09-14 12:23:14 --> Utf8 Class Initialized
INFO - 2016-09-14 12:23:14 --> URI Class Initialized
INFO - 2016-09-14 12:23:14 --> Router Class Initialized
INFO - 2016-09-14 12:23:14 --> Output Class Initialized
INFO - 2016-09-14 12:23:14 --> Security Class Initialized
DEBUG - 2016-09-14 12:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 12:23:14 --> Input Class Initialized
INFO - 2016-09-14 12:23:14 --> Language Class Initialized
INFO - 2016-09-14 12:23:14 --> Language Class Initialized
INFO - 2016-09-14 12:23:14 --> Config Class Initialized
INFO - 2016-09-14 12:23:14 --> Loader Class Initialized
INFO - 2016-09-14 12:23:14 --> Helper loaded: url_helper
INFO - 2016-09-14 12:23:14 --> Database Driver Class Initialized
INFO - 2016-09-14 12:23:14 --> Controller Class Initialized
DEBUG - 2016-09-14 12:23:14 --> Index MX_Controller Initialized
INFO - 2016-09-14 12:23:14 --> Model Class Initialized
INFO - 2016-09-14 12:23:14 --> Model Class Initialized
INFO - 2016-09-14 12:23:14 --> Final output sent to browser
DEBUG - 2016-09-14 12:23:14 --> Total execution time: 0.7603
INFO - 2016-09-14 12:23:24 --> Config Class Initialized
INFO - 2016-09-14 12:23:24 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:23:25 --> UTF-8 Support Enabled
INFO - 2016-09-14 12:23:25 --> Utf8 Class Initialized
INFO - 2016-09-14 12:23:25 --> URI Class Initialized
INFO - 2016-09-14 12:23:25 --> Router Class Initialized
INFO - 2016-09-14 12:23:25 --> Output Class Initialized
INFO - 2016-09-14 12:23:25 --> Security Class Initialized
DEBUG - 2016-09-14 12:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 12:23:25 --> Input Class Initialized
INFO - 2016-09-14 12:23:25 --> Language Class Initialized
INFO - 2016-09-14 12:23:25 --> Language Class Initialized
INFO - 2016-09-14 12:23:25 --> Config Class Initialized
INFO - 2016-09-14 12:23:25 --> Loader Class Initialized
INFO - 2016-09-14 12:23:25 --> Helper loaded: url_helper
INFO - 2016-09-14 12:23:25 --> Database Driver Class Initialized
INFO - 2016-09-14 12:23:25 --> Controller Class Initialized
DEBUG - 2016-09-14 12:23:25 --> Index MX_Controller Initialized
INFO - 2016-09-14 12:23:25 --> Model Class Initialized
INFO - 2016-09-14 12:23:25 --> Model Class Initialized
INFO - 2016-09-14 12:23:25 --> Final output sent to browser
DEBUG - 2016-09-14 12:23:25 --> Total execution time: 0.7866
INFO - 2016-09-14 12:25:21 --> Config Class Initialized
INFO - 2016-09-14 12:25:21 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:25:21 --> UTF-8 Support Enabled
INFO - 2016-09-14 12:25:21 --> Utf8 Class Initialized
INFO - 2016-09-14 12:25:21 --> URI Class Initialized
INFO - 2016-09-14 12:25:21 --> Router Class Initialized
INFO - 2016-09-14 12:25:21 --> Output Class Initialized
INFO - 2016-09-14 12:25:21 --> Security Class Initialized
DEBUG - 2016-09-14 12:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 12:25:21 --> Input Class Initialized
INFO - 2016-09-14 12:25:21 --> Language Class Initialized
INFO - 2016-09-14 12:25:21 --> Language Class Initialized
INFO - 2016-09-14 12:25:21 --> Config Class Initialized
INFO - 2016-09-14 12:25:21 --> Loader Class Initialized
INFO - 2016-09-14 12:25:21 --> Helper loaded: url_helper
INFO - 2016-09-14 12:25:21 --> Database Driver Class Initialized
INFO - 2016-09-14 12:25:21 --> Controller Class Initialized
DEBUG - 2016-09-14 12:25:21 --> Index MX_Controller Initialized
INFO - 2016-09-14 12:25:22 --> Model Class Initialized
INFO - 2016-09-14 12:25:22 --> Model Class Initialized
DEBUG - 2016-09-14 12:25:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 12:25:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 12:25:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 12:25:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-09-14 12:25:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 12:25:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 12:25:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 12:25:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 12:25:22 --> Final output sent to browser
DEBUG - 2016-09-14 12:25:22 --> Total execution time: 0.8814
INFO - 2016-09-14 12:25:29 --> Config Class Initialized
INFO - 2016-09-14 12:25:29 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:25:29 --> UTF-8 Support Enabled
INFO - 2016-09-14 12:25:29 --> Utf8 Class Initialized
INFO - 2016-09-14 12:25:29 --> URI Class Initialized
INFO - 2016-09-14 12:25:29 --> Router Class Initialized
INFO - 2016-09-14 12:25:29 --> Output Class Initialized
INFO - 2016-09-14 12:25:29 --> Security Class Initialized
DEBUG - 2016-09-14 12:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 12:25:29 --> Input Class Initialized
INFO - 2016-09-14 12:25:29 --> Language Class Initialized
INFO - 2016-09-14 12:25:29 --> Language Class Initialized
INFO - 2016-09-14 12:25:29 --> Config Class Initialized
INFO - 2016-09-14 12:25:29 --> Loader Class Initialized
INFO - 2016-09-14 12:25:29 --> Helper loaded: url_helper
INFO - 2016-09-14 12:25:29 --> Database Driver Class Initialized
INFO - 2016-09-14 12:25:29 --> Controller Class Initialized
DEBUG - 2016-09-14 12:25:29 --> Index MX_Controller Initialized
INFO - 2016-09-14 12:25:29 --> Model Class Initialized
INFO - 2016-09-14 12:25:29 --> Model Class Initialized
INFO - 2016-09-14 12:25:29 --> Final output sent to browser
DEBUG - 2016-09-14 12:25:30 --> Total execution time: 0.8132
INFO - 2016-09-14 12:25:41 --> Config Class Initialized
INFO - 2016-09-14 12:25:41 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:25:41 --> UTF-8 Support Enabled
INFO - 2016-09-14 12:25:41 --> Utf8 Class Initialized
INFO - 2016-09-14 12:25:41 --> URI Class Initialized
INFO - 2016-09-14 12:25:41 --> Router Class Initialized
INFO - 2016-09-14 12:25:41 --> Output Class Initialized
INFO - 2016-09-14 12:25:41 --> Security Class Initialized
DEBUG - 2016-09-14 12:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 12:25:41 --> Input Class Initialized
INFO - 2016-09-14 12:25:41 --> Language Class Initialized
INFO - 2016-09-14 12:25:41 --> Language Class Initialized
INFO - 2016-09-14 12:25:41 --> Config Class Initialized
INFO - 2016-09-14 12:25:41 --> Loader Class Initialized
INFO - 2016-09-14 12:25:41 --> Helper loaded: url_helper
INFO - 2016-09-14 12:25:41 --> Database Driver Class Initialized
INFO - 2016-09-14 12:25:41 --> Controller Class Initialized
DEBUG - 2016-09-14 12:25:41 --> Index MX_Controller Initialized
INFO - 2016-09-14 12:25:41 --> Model Class Initialized
INFO - 2016-09-14 12:25:41 --> Model Class Initialized
INFO - 2016-09-14 12:25:42 --> Final output sent to browser
DEBUG - 2016-09-14 12:25:42 --> Total execution time: 0.6582
INFO - 2016-09-14 12:25:42 --> Config Class Initialized
INFO - 2016-09-14 12:25:42 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:25:42 --> UTF-8 Support Enabled
INFO - 2016-09-14 12:25:42 --> Utf8 Class Initialized
INFO - 2016-09-14 12:25:42 --> URI Class Initialized
INFO - 2016-09-14 12:25:42 --> Router Class Initialized
INFO - 2016-09-14 12:25:42 --> Output Class Initialized
INFO - 2016-09-14 12:25:42 --> Security Class Initialized
DEBUG - 2016-09-14 12:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 12:25:42 --> Input Class Initialized
INFO - 2016-09-14 12:25:42 --> Language Class Initialized
INFO - 2016-09-14 12:25:42 --> Language Class Initialized
INFO - 2016-09-14 12:25:42 --> Config Class Initialized
INFO - 2016-09-14 12:25:42 --> Loader Class Initialized
INFO - 2016-09-14 12:25:42 --> Helper loaded: url_helper
INFO - 2016-09-14 12:25:42 --> Database Driver Class Initialized
INFO - 2016-09-14 12:25:42 --> Controller Class Initialized
DEBUG - 2016-09-14 12:25:42 --> Index MX_Controller Initialized
INFO - 2016-09-14 12:25:42 --> Model Class Initialized
INFO - 2016-09-14 12:25:42 --> Model Class Initialized
DEBUG - 2016-09-14 12:25:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 12:25:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 12:25:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 12:25:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-14 12:25:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 12:25:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 12:25:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 12:25:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 12:25:43 --> Final output sent to browser
DEBUG - 2016-09-14 12:25:43 --> Total execution time: 0.8392
INFO - 2016-09-14 12:26:01 --> Config Class Initialized
INFO - 2016-09-14 12:26:01 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:26:01 --> UTF-8 Support Enabled
INFO - 2016-09-14 12:26:01 --> Utf8 Class Initialized
INFO - 2016-09-14 12:26:01 --> URI Class Initialized
INFO - 2016-09-14 12:26:01 --> Router Class Initialized
INFO - 2016-09-14 12:26:01 --> Output Class Initialized
INFO - 2016-09-14 12:26:01 --> Security Class Initialized
DEBUG - 2016-09-14 12:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 12:26:01 --> Input Class Initialized
INFO - 2016-09-14 12:26:01 --> Language Class Initialized
INFO - 2016-09-14 12:26:01 --> Language Class Initialized
INFO - 2016-09-14 12:26:01 --> Config Class Initialized
INFO - 2016-09-14 12:26:01 --> Loader Class Initialized
INFO - 2016-09-14 12:26:01 --> Helper loaded: url_helper
INFO - 2016-09-14 12:26:01 --> Database Driver Class Initialized
INFO - 2016-09-14 12:26:01 --> Controller Class Initialized
DEBUG - 2016-09-14 12:26:01 --> Index MX_Controller Initialized
INFO - 2016-09-14 12:26:01 --> Model Class Initialized
INFO - 2016-09-14 12:26:01 --> Model Class Initialized
DEBUG - 2016-09-14 12:26:01 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 12:26:01 --> Database Driver Class Initialized
INFO - 2016-09-14 12:26:01 --> Final output sent to browser
DEBUG - 2016-09-14 12:26:01 --> Total execution time: 0.8378
INFO - 2016-09-14 12:26:04 --> Config Class Initialized
INFO - 2016-09-14 12:26:04 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:26:04 --> UTF-8 Support Enabled
INFO - 2016-09-14 12:26:04 --> Utf8 Class Initialized
INFO - 2016-09-14 12:26:04 --> URI Class Initialized
INFO - 2016-09-14 12:26:04 --> Router Class Initialized
INFO - 2016-09-14 12:26:05 --> Output Class Initialized
INFO - 2016-09-14 12:26:05 --> Security Class Initialized
DEBUG - 2016-09-14 12:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 12:26:05 --> Input Class Initialized
INFO - 2016-09-14 12:26:05 --> Language Class Initialized
INFO - 2016-09-14 12:26:05 --> Language Class Initialized
INFO - 2016-09-14 12:26:05 --> Config Class Initialized
INFO - 2016-09-14 12:26:05 --> Loader Class Initialized
INFO - 2016-09-14 12:26:05 --> Helper loaded: url_helper
INFO - 2016-09-14 12:26:05 --> Database Driver Class Initialized
INFO - 2016-09-14 12:26:05 --> Controller Class Initialized
DEBUG - 2016-09-14 12:26:05 --> Index MX_Controller Initialized
INFO - 2016-09-14 12:26:05 --> Model Class Initialized
INFO - 2016-09-14 12:26:05 --> Model Class Initialized
DEBUG - 2016-09-14 12:26:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 12:26:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 12:26:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 12:26:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-09-14 12:26:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 12:26:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 12:26:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 12:26:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 12:26:05 --> Final output sent to browser
DEBUG - 2016-09-14 12:26:05 --> Total execution time: 0.9327
INFO - 2016-09-14 12:26:22 --> Config Class Initialized
INFO - 2016-09-14 12:26:22 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:26:22 --> UTF-8 Support Enabled
INFO - 2016-09-14 12:26:22 --> Utf8 Class Initialized
INFO - 2016-09-14 12:26:22 --> URI Class Initialized
INFO - 2016-09-14 12:26:22 --> Router Class Initialized
INFO - 2016-09-14 12:26:22 --> Output Class Initialized
INFO - 2016-09-14 12:26:22 --> Security Class Initialized
DEBUG - 2016-09-14 12:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 12:26:22 --> Input Class Initialized
INFO - 2016-09-14 12:26:22 --> Language Class Initialized
INFO - 2016-09-14 12:26:22 --> Language Class Initialized
INFO - 2016-09-14 12:26:22 --> Config Class Initialized
INFO - 2016-09-14 12:26:22 --> Loader Class Initialized
INFO - 2016-09-14 12:26:22 --> Helper loaded: url_helper
INFO - 2016-09-14 12:26:22 --> Database Driver Class Initialized
INFO - 2016-09-14 12:26:22 --> Controller Class Initialized
DEBUG - 2016-09-14 12:26:22 --> Index MX_Controller Initialized
INFO - 2016-09-14 12:26:22 --> Model Class Initialized
INFO - 2016-09-14 12:26:22 --> Model Class Initialized
INFO - 2016-09-14 12:26:22 --> Final output sent to browser
DEBUG - 2016-09-14 12:26:22 --> Total execution time: 0.7204
INFO - 2016-09-14 12:30:17 --> Config Class Initialized
INFO - 2016-09-14 12:30:17 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:30:17 --> UTF-8 Support Enabled
INFO - 2016-09-14 12:30:17 --> Utf8 Class Initialized
INFO - 2016-09-14 12:30:17 --> URI Class Initialized
INFO - 2016-09-14 12:30:17 --> Router Class Initialized
INFO - 2016-09-14 12:30:17 --> Output Class Initialized
INFO - 2016-09-14 12:30:17 --> Security Class Initialized
DEBUG - 2016-09-14 12:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 12:30:17 --> Input Class Initialized
INFO - 2016-09-14 12:30:17 --> Language Class Initialized
INFO - 2016-09-14 12:30:17 --> Language Class Initialized
INFO - 2016-09-14 12:30:17 --> Config Class Initialized
INFO - 2016-09-14 12:30:17 --> Loader Class Initialized
INFO - 2016-09-14 12:30:17 --> Helper loaded: url_helper
INFO - 2016-09-14 12:30:17 --> Database Driver Class Initialized
INFO - 2016-09-14 12:30:17 --> Controller Class Initialized
DEBUG - 2016-09-14 12:30:17 --> Index MX_Controller Initialized
INFO - 2016-09-14 12:30:17 --> Model Class Initialized
INFO - 2016-09-14 12:30:17 --> Model Class Initialized
INFO - 2016-09-14 12:30:17 --> Final output sent to browser
DEBUG - 2016-09-14 12:30:17 --> Total execution time: 0.6355
INFO - 2016-09-14 12:30:17 --> Config Class Initialized
INFO - 2016-09-14 12:30:17 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:30:17 --> UTF-8 Support Enabled
INFO - 2016-09-14 12:30:17 --> Utf8 Class Initialized
INFO - 2016-09-14 12:30:17 --> URI Class Initialized
INFO - 2016-09-14 12:30:17 --> Router Class Initialized
INFO - 2016-09-14 12:30:17 --> Output Class Initialized
INFO - 2016-09-14 12:30:17 --> Security Class Initialized
DEBUG - 2016-09-14 12:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 12:30:18 --> Input Class Initialized
INFO - 2016-09-14 12:30:18 --> Language Class Initialized
INFO - 2016-09-14 12:30:18 --> Language Class Initialized
INFO - 2016-09-14 12:30:18 --> Config Class Initialized
INFO - 2016-09-14 12:30:18 --> Loader Class Initialized
INFO - 2016-09-14 12:30:18 --> Helper loaded: url_helper
INFO - 2016-09-14 12:30:18 --> Database Driver Class Initialized
INFO - 2016-09-14 12:30:18 --> Controller Class Initialized
DEBUG - 2016-09-14 12:30:18 --> Index MX_Controller Initialized
INFO - 2016-09-14 12:30:18 --> Model Class Initialized
INFO - 2016-09-14 12:30:18 --> Model Class Initialized
DEBUG - 2016-09-14 12:30:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 12:30:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 12:30:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 12:30:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-14 12:30:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 12:30:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 12:30:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 12:30:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 12:30:18 --> Final output sent to browser
DEBUG - 2016-09-14 12:30:18 --> Total execution time: 0.8487
INFO - 2016-09-14 12:30:26 --> Config Class Initialized
INFO - 2016-09-14 12:30:26 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:30:26 --> UTF-8 Support Enabled
INFO - 2016-09-14 12:30:26 --> Utf8 Class Initialized
INFO - 2016-09-14 12:30:26 --> URI Class Initialized
INFO - 2016-09-14 12:30:26 --> Router Class Initialized
INFO - 2016-09-14 12:30:26 --> Output Class Initialized
INFO - 2016-09-14 12:30:26 --> Security Class Initialized
DEBUG - 2016-09-14 12:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 12:30:26 --> Input Class Initialized
INFO - 2016-09-14 12:30:26 --> Language Class Initialized
INFO - 2016-09-14 12:30:26 --> Language Class Initialized
INFO - 2016-09-14 12:30:26 --> Config Class Initialized
INFO - 2016-09-14 12:30:26 --> Loader Class Initialized
INFO - 2016-09-14 12:30:26 --> Helper loaded: url_helper
INFO - 2016-09-14 12:30:27 --> Database Driver Class Initialized
INFO - 2016-09-14 12:30:27 --> Controller Class Initialized
DEBUG - 2016-09-14 12:30:27 --> Index MX_Controller Initialized
INFO - 2016-09-14 12:30:27 --> Model Class Initialized
INFO - 2016-09-14 12:30:27 --> Model Class Initialized
DEBUG - 2016-09-14 12:30:27 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 12:30:27 --> Database Driver Class Initialized
INFO - 2016-09-14 12:30:27 --> Final output sent to browser
DEBUG - 2016-09-14 12:30:27 --> Total execution time: 0.7977
INFO - 2016-09-14 12:30:28 --> Config Class Initialized
INFO - 2016-09-14 12:30:28 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:30:28 --> UTF-8 Support Enabled
INFO - 2016-09-14 12:30:28 --> Utf8 Class Initialized
INFO - 2016-09-14 12:30:28 --> URI Class Initialized
INFO - 2016-09-14 12:30:28 --> Router Class Initialized
INFO - 2016-09-14 12:30:29 --> Output Class Initialized
INFO - 2016-09-14 12:30:29 --> Security Class Initialized
DEBUG - 2016-09-14 12:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 12:30:29 --> Input Class Initialized
INFO - 2016-09-14 12:30:29 --> Language Class Initialized
INFO - 2016-09-14 12:30:29 --> Language Class Initialized
INFO - 2016-09-14 12:30:29 --> Config Class Initialized
INFO - 2016-09-14 12:30:29 --> Loader Class Initialized
INFO - 2016-09-14 12:30:29 --> Helper loaded: url_helper
INFO - 2016-09-14 12:30:29 --> Database Driver Class Initialized
INFO - 2016-09-14 12:30:29 --> Controller Class Initialized
DEBUG - 2016-09-14 12:30:29 --> Index MX_Controller Initialized
INFO - 2016-09-14 12:30:29 --> Model Class Initialized
INFO - 2016-09-14 12:30:29 --> Model Class Initialized
DEBUG - 2016-09-14 12:30:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 12:30:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 12:30:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 12:30:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-09-14 12:30:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 12:30:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 12:30:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 12:30:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 12:30:29 --> Final output sent to browser
DEBUG - 2016-09-14 12:30:29 --> Total execution time: 0.9634
INFO - 2016-09-14 12:30:40 --> Config Class Initialized
INFO - 2016-09-14 12:30:40 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:30:40 --> UTF-8 Support Enabled
INFO - 2016-09-14 12:30:40 --> Utf8 Class Initialized
INFO - 2016-09-14 12:30:40 --> URI Class Initialized
INFO - 2016-09-14 12:30:40 --> Router Class Initialized
INFO - 2016-09-14 12:30:40 --> Output Class Initialized
INFO - 2016-09-14 12:30:40 --> Security Class Initialized
DEBUG - 2016-09-14 12:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 12:30:40 --> Input Class Initialized
INFO - 2016-09-14 12:30:40 --> Language Class Initialized
INFO - 2016-09-14 12:30:40 --> Language Class Initialized
INFO - 2016-09-14 12:30:40 --> Config Class Initialized
INFO - 2016-09-14 12:30:40 --> Loader Class Initialized
INFO - 2016-09-14 12:30:40 --> Helper loaded: url_helper
INFO - 2016-09-14 12:30:40 --> Database Driver Class Initialized
INFO - 2016-09-14 12:30:40 --> Controller Class Initialized
DEBUG - 2016-09-14 12:30:40 --> Index MX_Controller Initialized
INFO - 2016-09-14 12:30:40 --> Model Class Initialized
INFO - 2016-09-14 12:30:40 --> Model Class Initialized
INFO - 2016-09-14 12:30:41 --> Final output sent to browser
DEBUG - 2016-09-14 12:30:41 --> Total execution time: 0.6960
INFO - 2016-09-14 12:31:57 --> Config Class Initialized
INFO - 2016-09-14 12:31:57 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:31:57 --> UTF-8 Support Enabled
INFO - 2016-09-14 12:31:57 --> Utf8 Class Initialized
INFO - 2016-09-14 12:31:57 --> URI Class Initialized
INFO - 2016-09-14 12:31:57 --> Router Class Initialized
INFO - 2016-09-14 12:31:57 --> Output Class Initialized
INFO - 2016-09-14 12:31:57 --> Security Class Initialized
DEBUG - 2016-09-14 12:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 12:31:58 --> Input Class Initialized
INFO - 2016-09-14 12:31:58 --> Language Class Initialized
INFO - 2016-09-14 12:31:58 --> Language Class Initialized
INFO - 2016-09-14 12:31:58 --> Config Class Initialized
INFO - 2016-09-14 12:31:58 --> Loader Class Initialized
INFO - 2016-09-14 12:31:58 --> Helper loaded: url_helper
INFO - 2016-09-14 12:31:58 --> Database Driver Class Initialized
INFO - 2016-09-14 12:31:58 --> Controller Class Initialized
DEBUG - 2016-09-14 12:31:58 --> Index MX_Controller Initialized
INFO - 2016-09-14 12:31:58 --> Model Class Initialized
INFO - 2016-09-14 12:31:58 --> Model Class Initialized
INFO - 2016-09-14 12:31:58 --> Final output sent to browser
DEBUG - 2016-09-14 12:31:58 --> Total execution time: 0.6658
INFO - 2016-09-14 12:31:58 --> Config Class Initialized
INFO - 2016-09-14 12:31:58 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:31:58 --> UTF-8 Support Enabled
INFO - 2016-09-14 12:31:58 --> Utf8 Class Initialized
INFO - 2016-09-14 12:31:58 --> URI Class Initialized
INFO - 2016-09-14 12:31:58 --> Router Class Initialized
INFO - 2016-09-14 12:31:58 --> Output Class Initialized
INFO - 2016-09-14 12:31:58 --> Security Class Initialized
DEBUG - 2016-09-14 12:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 12:31:58 --> Input Class Initialized
INFO - 2016-09-14 12:31:58 --> Language Class Initialized
INFO - 2016-09-14 12:31:58 --> Language Class Initialized
INFO - 2016-09-14 12:31:58 --> Config Class Initialized
INFO - 2016-09-14 12:31:58 --> Loader Class Initialized
INFO - 2016-09-14 12:31:58 --> Helper loaded: url_helper
INFO - 2016-09-14 12:31:58 --> Database Driver Class Initialized
INFO - 2016-09-14 12:31:58 --> Controller Class Initialized
DEBUG - 2016-09-14 12:31:58 --> Index MX_Controller Initialized
INFO - 2016-09-14 12:31:58 --> Model Class Initialized
INFO - 2016-09-14 12:31:59 --> Model Class Initialized
DEBUG - 2016-09-14 12:31:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 12:31:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 12:31:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 12:31:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-14 12:31:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 12:31:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 12:31:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 12:31:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 12:31:59 --> Final output sent to browser
DEBUG - 2016-09-14 12:31:59 --> Total execution time: 0.8549
INFO - 2016-09-14 12:33:27 --> Config Class Initialized
INFO - 2016-09-14 12:33:27 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:33:27 --> UTF-8 Support Enabled
INFO - 2016-09-14 12:33:27 --> Utf8 Class Initialized
INFO - 2016-09-14 12:33:27 --> URI Class Initialized
INFO - 2016-09-14 12:33:27 --> Router Class Initialized
INFO - 2016-09-14 12:33:27 --> Output Class Initialized
INFO - 2016-09-14 12:33:28 --> Security Class Initialized
DEBUG - 2016-09-14 12:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 12:33:28 --> Input Class Initialized
INFO - 2016-09-14 12:33:28 --> Language Class Initialized
INFO - 2016-09-14 12:33:28 --> Language Class Initialized
INFO - 2016-09-14 12:33:28 --> Config Class Initialized
INFO - 2016-09-14 12:33:28 --> Loader Class Initialized
INFO - 2016-09-14 12:33:28 --> Helper loaded: url_helper
INFO - 2016-09-14 12:33:28 --> Database Driver Class Initialized
INFO - 2016-09-14 12:33:28 --> Controller Class Initialized
DEBUG - 2016-09-14 12:33:28 --> Index MX_Controller Initialized
INFO - 2016-09-14 12:33:28 --> Model Class Initialized
INFO - 2016-09-14 12:33:28 --> Model Class Initialized
DEBUG - 2016-09-14 12:33:28 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 12:33:28 --> Database Driver Class Initialized
INFO - 2016-09-14 12:33:28 --> Final output sent to browser
DEBUG - 2016-09-14 12:33:28 --> Total execution time: 0.6663
INFO - 2016-09-14 12:33:30 --> Config Class Initialized
INFO - 2016-09-14 12:33:30 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:33:30 --> UTF-8 Support Enabled
INFO - 2016-09-14 12:33:30 --> Utf8 Class Initialized
INFO - 2016-09-14 12:33:30 --> URI Class Initialized
INFO - 2016-09-14 12:33:30 --> Router Class Initialized
INFO - 2016-09-14 12:33:30 --> Output Class Initialized
INFO - 2016-09-14 12:33:30 --> Security Class Initialized
DEBUG - 2016-09-14 12:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 12:33:30 --> Input Class Initialized
INFO - 2016-09-14 12:33:30 --> Language Class Initialized
INFO - 2016-09-14 12:33:30 --> Language Class Initialized
INFO - 2016-09-14 12:33:30 --> Config Class Initialized
INFO - 2016-09-14 12:33:30 --> Loader Class Initialized
INFO - 2016-09-14 12:33:30 --> Helper loaded: url_helper
INFO - 2016-09-14 12:33:30 --> Database Driver Class Initialized
INFO - 2016-09-14 12:33:30 --> Controller Class Initialized
DEBUG - 2016-09-14 12:33:31 --> Index MX_Controller Initialized
INFO - 2016-09-14 12:33:31 --> Model Class Initialized
INFO - 2016-09-14 12:33:31 --> Model Class Initialized
DEBUG - 2016-09-14 12:33:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 12:33:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 12:33:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 12:33:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-09-14 12:33:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 12:33:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 12:33:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 12:33:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 12:33:31 --> Final output sent to browser
DEBUG - 2016-09-14 12:33:31 --> Total execution time: 0.8537
INFO - 2016-09-14 12:33:45 --> Config Class Initialized
INFO - 2016-09-14 12:33:45 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:33:45 --> UTF-8 Support Enabled
INFO - 2016-09-14 12:33:45 --> Utf8 Class Initialized
INFO - 2016-09-14 12:33:45 --> URI Class Initialized
INFO - 2016-09-14 12:33:45 --> Router Class Initialized
INFO - 2016-09-14 12:33:45 --> Output Class Initialized
INFO - 2016-09-14 12:33:45 --> Security Class Initialized
DEBUG - 2016-09-14 12:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 12:33:45 --> Input Class Initialized
INFO - 2016-09-14 12:33:45 --> Language Class Initialized
INFO - 2016-09-14 12:33:45 --> Language Class Initialized
INFO - 2016-09-14 12:33:45 --> Config Class Initialized
INFO - 2016-09-14 12:33:45 --> Loader Class Initialized
INFO - 2016-09-14 12:33:45 --> Helper loaded: url_helper
INFO - 2016-09-14 12:33:45 --> Database Driver Class Initialized
INFO - 2016-09-14 12:33:45 --> Controller Class Initialized
DEBUG - 2016-09-14 12:33:45 --> Index MX_Controller Initialized
INFO - 2016-09-14 12:33:45 --> Model Class Initialized
INFO - 2016-09-14 12:33:45 --> Model Class Initialized
INFO - 2016-09-14 12:33:46 --> Final output sent to browser
DEBUG - 2016-09-14 12:33:46 --> Total execution time: 0.8094
INFO - 2016-09-14 12:39:43 --> Config Class Initialized
INFO - 2016-09-14 12:39:43 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:39:43 --> UTF-8 Support Enabled
INFO - 2016-09-14 12:39:44 --> Utf8 Class Initialized
INFO - 2016-09-14 12:39:44 --> URI Class Initialized
INFO - 2016-09-14 12:39:44 --> Router Class Initialized
INFO - 2016-09-14 12:39:44 --> Output Class Initialized
INFO - 2016-09-14 12:39:44 --> Security Class Initialized
DEBUG - 2016-09-14 12:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 12:39:44 --> Input Class Initialized
INFO - 2016-09-14 12:39:44 --> Language Class Initialized
INFO - 2016-09-14 12:39:44 --> Language Class Initialized
INFO - 2016-09-14 12:39:44 --> Config Class Initialized
INFO - 2016-09-14 12:39:44 --> Loader Class Initialized
INFO - 2016-09-14 12:39:44 --> Helper loaded: url_helper
INFO - 2016-09-14 12:39:44 --> Database Driver Class Initialized
INFO - 2016-09-14 12:39:44 --> Controller Class Initialized
DEBUG - 2016-09-14 12:39:44 --> Index MX_Controller Initialized
INFO - 2016-09-14 12:39:44 --> Model Class Initialized
INFO - 2016-09-14 12:39:44 --> Model Class Initialized
INFO - 2016-09-14 12:39:44 --> Final output sent to browser
DEBUG - 2016-09-14 12:39:44 --> Total execution time: 0.6378
INFO - 2016-09-14 12:39:44 --> Config Class Initialized
INFO - 2016-09-14 12:39:44 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:39:44 --> UTF-8 Support Enabled
INFO - 2016-09-14 12:39:44 --> Utf8 Class Initialized
INFO - 2016-09-14 12:39:44 --> URI Class Initialized
INFO - 2016-09-14 12:39:44 --> Router Class Initialized
INFO - 2016-09-14 12:39:44 --> Output Class Initialized
INFO - 2016-09-14 12:39:44 --> Security Class Initialized
DEBUG - 2016-09-14 12:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 12:39:44 --> Input Class Initialized
INFO - 2016-09-14 12:39:44 --> Language Class Initialized
INFO - 2016-09-14 12:39:44 --> Language Class Initialized
INFO - 2016-09-14 12:39:44 --> Config Class Initialized
INFO - 2016-09-14 12:39:45 --> Loader Class Initialized
INFO - 2016-09-14 12:39:45 --> Helper loaded: url_helper
INFO - 2016-09-14 12:39:45 --> Database Driver Class Initialized
INFO - 2016-09-14 12:39:45 --> Controller Class Initialized
DEBUG - 2016-09-14 12:39:45 --> Index MX_Controller Initialized
INFO - 2016-09-14 12:39:45 --> Model Class Initialized
INFO - 2016-09-14 12:39:45 --> Model Class Initialized
DEBUG - 2016-09-14 12:39:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 12:39:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 12:39:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 12:39:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-14 12:39:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 12:39:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 12:39:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 12:39:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 12:39:45 --> Final output sent to browser
DEBUG - 2016-09-14 12:39:45 --> Total execution time: 0.8574
INFO - 2016-09-14 12:39:54 --> Config Class Initialized
INFO - 2016-09-14 12:39:54 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:39:54 --> UTF-8 Support Enabled
INFO - 2016-09-14 12:39:54 --> Utf8 Class Initialized
INFO - 2016-09-14 12:39:54 --> URI Class Initialized
INFO - 2016-09-14 12:39:54 --> Router Class Initialized
INFO - 2016-09-14 12:39:54 --> Output Class Initialized
INFO - 2016-09-14 12:39:54 --> Security Class Initialized
DEBUG - 2016-09-14 12:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 12:39:54 --> Input Class Initialized
INFO - 2016-09-14 12:39:54 --> Language Class Initialized
INFO - 2016-09-14 12:39:54 --> Language Class Initialized
INFO - 2016-09-14 12:39:54 --> Config Class Initialized
INFO - 2016-09-14 12:39:54 --> Loader Class Initialized
INFO - 2016-09-14 12:39:54 --> Helper loaded: url_helper
INFO - 2016-09-14 12:39:55 --> Database Driver Class Initialized
INFO - 2016-09-14 12:39:55 --> Controller Class Initialized
DEBUG - 2016-09-14 12:39:55 --> Index MX_Controller Initialized
INFO - 2016-09-14 12:39:55 --> Model Class Initialized
INFO - 2016-09-14 12:39:55 --> Model Class Initialized
DEBUG - 2016-09-14 12:39:55 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 12:39:55 --> Database Driver Class Initialized
INFO - 2016-09-14 12:39:55 --> Final output sent to browser
DEBUG - 2016-09-14 12:39:55 --> Total execution time: 0.7655
INFO - 2016-09-14 12:39:58 --> Config Class Initialized
INFO - 2016-09-14 12:39:58 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:39:58 --> UTF-8 Support Enabled
INFO - 2016-09-14 12:39:58 --> Utf8 Class Initialized
INFO - 2016-09-14 12:39:58 --> URI Class Initialized
INFO - 2016-09-14 12:39:58 --> Router Class Initialized
INFO - 2016-09-14 12:39:58 --> Output Class Initialized
INFO - 2016-09-14 12:39:58 --> Security Class Initialized
DEBUG - 2016-09-14 12:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 12:39:58 --> Input Class Initialized
INFO - 2016-09-14 12:39:58 --> Language Class Initialized
INFO - 2016-09-14 12:39:58 --> Language Class Initialized
INFO - 2016-09-14 12:39:58 --> Config Class Initialized
INFO - 2016-09-14 12:39:58 --> Loader Class Initialized
INFO - 2016-09-14 12:39:58 --> Helper loaded: url_helper
INFO - 2016-09-14 12:39:58 --> Database Driver Class Initialized
INFO - 2016-09-14 12:39:58 --> Controller Class Initialized
DEBUG - 2016-09-14 12:39:58 --> Index MX_Controller Initialized
INFO - 2016-09-14 12:39:58 --> Model Class Initialized
INFO - 2016-09-14 12:39:58 --> Model Class Initialized
DEBUG - 2016-09-14 12:39:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 12:39:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 12:39:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 12:39:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-09-14 12:39:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 12:39:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 12:39:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 12:39:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 12:39:58 --> Final output sent to browser
DEBUG - 2016-09-14 12:39:58 --> Total execution time: 0.8679
INFO - 2016-09-14 12:40:15 --> Config Class Initialized
INFO - 2016-09-14 12:40:15 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:40:15 --> UTF-8 Support Enabled
INFO - 2016-09-14 12:40:15 --> Utf8 Class Initialized
INFO - 2016-09-14 12:40:15 --> URI Class Initialized
INFO - 2016-09-14 12:40:15 --> Router Class Initialized
INFO - 2016-09-14 12:40:15 --> Output Class Initialized
INFO - 2016-09-14 12:40:15 --> Security Class Initialized
DEBUG - 2016-09-14 12:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 12:40:15 --> Input Class Initialized
INFO - 2016-09-14 12:40:15 --> Language Class Initialized
INFO - 2016-09-14 12:40:15 --> Language Class Initialized
INFO - 2016-09-14 12:40:15 --> Config Class Initialized
INFO - 2016-09-14 12:40:15 --> Loader Class Initialized
INFO - 2016-09-14 12:40:15 --> Helper loaded: url_helper
INFO - 2016-09-14 12:40:15 --> Database Driver Class Initialized
INFO - 2016-09-14 12:40:15 --> Controller Class Initialized
DEBUG - 2016-09-14 12:40:15 --> Index MX_Controller Initialized
INFO - 2016-09-14 12:40:15 --> Model Class Initialized
INFO - 2016-09-14 12:40:15 --> Model Class Initialized
INFO - 2016-09-14 12:40:15 --> Final output sent to browser
DEBUG - 2016-09-14 12:40:16 --> Total execution time: 0.7359
INFO - 2016-09-14 12:40:54 --> Config Class Initialized
INFO - 2016-09-14 12:40:54 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:40:55 --> UTF-8 Support Enabled
INFO - 2016-09-14 12:40:55 --> Utf8 Class Initialized
INFO - 2016-09-14 12:40:55 --> URI Class Initialized
INFO - 2016-09-14 12:40:55 --> Router Class Initialized
INFO - 2016-09-14 12:40:55 --> Output Class Initialized
INFO - 2016-09-14 12:40:55 --> Security Class Initialized
DEBUG - 2016-09-14 12:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 12:40:55 --> Input Class Initialized
INFO - 2016-09-14 12:40:55 --> Language Class Initialized
INFO - 2016-09-14 12:40:55 --> Language Class Initialized
INFO - 2016-09-14 12:40:55 --> Config Class Initialized
INFO - 2016-09-14 12:40:55 --> Loader Class Initialized
INFO - 2016-09-14 12:40:55 --> Helper loaded: url_helper
INFO - 2016-09-14 12:40:55 --> Database Driver Class Initialized
INFO - 2016-09-14 12:40:55 --> Controller Class Initialized
DEBUG - 2016-09-14 12:40:55 --> Index MX_Controller Initialized
INFO - 2016-09-14 12:40:55 --> Model Class Initialized
INFO - 2016-09-14 12:40:55 --> Model Class Initialized
INFO - 2016-09-14 12:40:55 --> Final output sent to browser
DEBUG - 2016-09-14 12:40:55 --> Total execution time: 0.6452
INFO - 2016-09-14 12:40:55 --> Config Class Initialized
INFO - 2016-09-14 12:40:55 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:40:55 --> UTF-8 Support Enabled
INFO - 2016-09-14 12:40:55 --> Utf8 Class Initialized
INFO - 2016-09-14 12:40:55 --> URI Class Initialized
INFO - 2016-09-14 12:40:55 --> Router Class Initialized
INFO - 2016-09-14 12:40:55 --> Output Class Initialized
INFO - 2016-09-14 12:40:55 --> Security Class Initialized
DEBUG - 2016-09-14 12:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 12:40:55 --> Input Class Initialized
INFO - 2016-09-14 12:40:55 --> Language Class Initialized
INFO - 2016-09-14 12:40:56 --> Language Class Initialized
INFO - 2016-09-14 12:40:56 --> Config Class Initialized
INFO - 2016-09-14 12:40:56 --> Loader Class Initialized
INFO - 2016-09-14 12:40:56 --> Helper loaded: url_helper
INFO - 2016-09-14 12:40:56 --> Database Driver Class Initialized
INFO - 2016-09-14 12:40:56 --> Controller Class Initialized
DEBUG - 2016-09-14 12:40:56 --> Index MX_Controller Initialized
INFO - 2016-09-14 12:40:56 --> Model Class Initialized
INFO - 2016-09-14 12:40:56 --> Model Class Initialized
DEBUG - 2016-09-14 12:40:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 12:40:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 12:40:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 12:40:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-14 12:40:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 12:40:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 12:40:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 12:40:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 12:40:56 --> Final output sent to browser
DEBUG - 2016-09-14 12:40:56 --> Total execution time: 0.8799
INFO - 2016-09-14 12:41:04 --> Config Class Initialized
INFO - 2016-09-14 12:41:04 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:41:04 --> UTF-8 Support Enabled
INFO - 2016-09-14 12:41:04 --> Utf8 Class Initialized
INFO - 2016-09-14 12:41:04 --> URI Class Initialized
INFO - 2016-09-14 12:41:04 --> Router Class Initialized
INFO - 2016-09-14 12:41:04 --> Output Class Initialized
INFO - 2016-09-14 12:41:04 --> Security Class Initialized
DEBUG - 2016-09-14 12:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 12:41:04 --> Input Class Initialized
INFO - 2016-09-14 12:41:04 --> Language Class Initialized
INFO - 2016-09-14 12:41:04 --> Language Class Initialized
INFO - 2016-09-14 12:41:04 --> Config Class Initialized
INFO - 2016-09-14 12:41:04 --> Loader Class Initialized
INFO - 2016-09-14 12:41:05 --> Helper loaded: url_helper
INFO - 2016-09-14 12:41:05 --> Database Driver Class Initialized
INFO - 2016-09-14 12:41:05 --> Controller Class Initialized
DEBUG - 2016-09-14 12:41:05 --> Index MX_Controller Initialized
INFO - 2016-09-14 12:41:05 --> Model Class Initialized
INFO - 2016-09-14 12:41:05 --> Model Class Initialized
DEBUG - 2016-09-14 12:41:05 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 12:41:05 --> Database Driver Class Initialized
INFO - 2016-09-14 12:41:05 --> Final output sent to browser
DEBUG - 2016-09-14 12:41:05 --> Total execution time: 0.7605
INFO - 2016-09-14 12:41:08 --> Config Class Initialized
INFO - 2016-09-14 12:41:08 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:41:08 --> UTF-8 Support Enabled
INFO - 2016-09-14 12:41:08 --> Utf8 Class Initialized
INFO - 2016-09-14 12:41:08 --> URI Class Initialized
INFO - 2016-09-14 12:41:08 --> Router Class Initialized
INFO - 2016-09-14 12:41:08 --> Output Class Initialized
INFO - 2016-09-14 12:41:08 --> Security Class Initialized
DEBUG - 2016-09-14 12:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 12:41:08 --> Input Class Initialized
INFO - 2016-09-14 12:41:08 --> Language Class Initialized
INFO - 2016-09-14 12:41:08 --> Language Class Initialized
INFO - 2016-09-14 12:41:08 --> Config Class Initialized
INFO - 2016-09-14 12:41:08 --> Loader Class Initialized
INFO - 2016-09-14 12:41:08 --> Helper loaded: url_helper
INFO - 2016-09-14 12:41:08 --> Database Driver Class Initialized
INFO - 2016-09-14 12:41:08 --> Controller Class Initialized
DEBUG - 2016-09-14 12:41:08 --> Index MX_Controller Initialized
INFO - 2016-09-14 12:41:08 --> Model Class Initialized
INFO - 2016-09-14 12:41:08 --> Model Class Initialized
DEBUG - 2016-09-14 12:41:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 12:41:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 12:41:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 12:41:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_umum.php
DEBUG - 2016-09-14 12:41:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 12:41:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 12:41:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 12:41:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 12:41:08 --> Final output sent to browser
DEBUG - 2016-09-14 12:41:08 --> Total execution time: 0.8757
INFO - 2016-09-14 12:41:15 --> Config Class Initialized
INFO - 2016-09-14 12:41:15 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:41:15 --> UTF-8 Support Enabled
INFO - 2016-09-14 12:41:15 --> Utf8 Class Initialized
INFO - 2016-09-14 12:41:15 --> URI Class Initialized
INFO - 2016-09-14 12:41:15 --> Router Class Initialized
INFO - 2016-09-14 12:41:15 --> Output Class Initialized
INFO - 2016-09-14 12:41:15 --> Security Class Initialized
DEBUG - 2016-09-14 12:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 12:41:15 --> Input Class Initialized
INFO - 2016-09-14 12:41:15 --> Language Class Initialized
INFO - 2016-09-14 12:41:15 --> Language Class Initialized
INFO - 2016-09-14 12:41:15 --> Config Class Initialized
INFO - 2016-09-14 12:41:15 --> Loader Class Initialized
INFO - 2016-09-14 12:41:16 --> Helper loaded: url_helper
INFO - 2016-09-14 12:41:16 --> Database Driver Class Initialized
INFO - 2016-09-14 12:41:16 --> Controller Class Initialized
DEBUG - 2016-09-14 12:41:16 --> Index MX_Controller Initialized
INFO - 2016-09-14 12:41:16 --> Model Class Initialized
INFO - 2016-09-14 12:41:16 --> Model Class Initialized
DEBUG - 2016-09-14 12:41:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 12:41:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 12:41:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 12:41:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-09-14 12:41:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 12:41:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 12:41:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 12:41:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 12:41:16 --> Final output sent to browser
DEBUG - 2016-09-14 12:41:16 --> Total execution time: 0.8707
INFO - 2016-09-14 12:41:24 --> Config Class Initialized
INFO - 2016-09-14 12:41:24 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:41:24 --> UTF-8 Support Enabled
INFO - 2016-09-14 12:41:24 --> Utf8 Class Initialized
INFO - 2016-09-14 12:41:24 --> URI Class Initialized
INFO - 2016-09-14 12:41:24 --> Router Class Initialized
INFO - 2016-09-14 12:41:24 --> Output Class Initialized
INFO - 2016-09-14 12:41:24 --> Security Class Initialized
DEBUG - 2016-09-14 12:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 12:41:25 --> Input Class Initialized
INFO - 2016-09-14 12:41:25 --> Language Class Initialized
INFO - 2016-09-14 12:41:25 --> Language Class Initialized
INFO - 2016-09-14 12:41:25 --> Config Class Initialized
INFO - 2016-09-14 12:41:25 --> Loader Class Initialized
INFO - 2016-09-14 12:41:25 --> Helper loaded: url_helper
INFO - 2016-09-14 12:41:25 --> Database Driver Class Initialized
INFO - 2016-09-14 12:41:25 --> Controller Class Initialized
DEBUG - 2016-09-14 12:41:25 --> Index MX_Controller Initialized
INFO - 2016-09-14 12:41:25 --> Model Class Initialized
INFO - 2016-09-14 12:41:25 --> Model Class Initialized
INFO - 2016-09-14 12:41:25 --> Final output sent to browser
DEBUG - 2016-09-14 12:41:25 --> Total execution time: 0.7426
INFO - 2016-09-14 14:09:36 --> Config Class Initialized
INFO - 2016-09-14 14:09:37 --> Hooks Class Initialized
DEBUG - 2016-09-14 14:09:37 --> UTF-8 Support Enabled
INFO - 2016-09-14 14:09:37 --> Utf8 Class Initialized
INFO - 2016-09-14 14:09:37 --> URI Class Initialized
INFO - 2016-09-14 14:09:37 --> Router Class Initialized
INFO - 2016-09-14 14:09:37 --> Output Class Initialized
INFO - 2016-09-14 14:09:38 --> Security Class Initialized
DEBUG - 2016-09-14 14:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 14:09:38 --> Input Class Initialized
INFO - 2016-09-14 14:09:38 --> Language Class Initialized
INFO - 2016-09-14 14:09:38 --> Language Class Initialized
INFO - 2016-09-14 14:09:38 --> Config Class Initialized
INFO - 2016-09-14 14:09:38 --> Loader Class Initialized
INFO - 2016-09-14 14:09:38 --> Helper loaded: url_helper
INFO - 2016-09-14 14:09:38 --> Database Driver Class Initialized
INFO - 2016-09-14 14:09:38 --> Controller Class Initialized
DEBUG - 2016-09-14 14:09:39 --> Index MX_Controller Initialized
INFO - 2016-09-14 14:09:39 --> Model Class Initialized
INFO - 2016-09-14 14:09:39 --> Model Class Initialized
DEBUG - 2016-09-14 14:09:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 14:09:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 14:09:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 14:09:39 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-14 14:09:39 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-14 14:09:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-14 14:09:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 14:09:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 14:09:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 14:09:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 14:09:39 --> Final output sent to browser
DEBUG - 2016-09-14 14:09:39 --> Total execution time: 3.2456
INFO - 2016-09-14 14:09:46 --> Config Class Initialized
INFO - 2016-09-14 14:09:46 --> Hooks Class Initialized
DEBUG - 2016-09-14 14:09:46 --> UTF-8 Support Enabled
INFO - 2016-09-14 14:09:46 --> Utf8 Class Initialized
INFO - 2016-09-14 14:09:46 --> URI Class Initialized
INFO - 2016-09-14 14:09:46 --> Router Class Initialized
INFO - 2016-09-14 14:09:46 --> Output Class Initialized
INFO - 2016-09-14 14:09:46 --> Security Class Initialized
DEBUG - 2016-09-14 14:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 14:09:46 --> Input Class Initialized
INFO - 2016-09-14 14:09:46 --> Language Class Initialized
INFO - 2016-09-14 14:09:46 --> Language Class Initialized
INFO - 2016-09-14 14:09:46 --> Config Class Initialized
INFO - 2016-09-14 14:09:46 --> Loader Class Initialized
INFO - 2016-09-14 14:09:46 --> Helper loaded: url_helper
INFO - 2016-09-14 14:09:46 --> Database Driver Class Initialized
INFO - 2016-09-14 14:09:46 --> Controller Class Initialized
DEBUG - 2016-09-14 14:09:46 --> Index MX_Controller Initialized
INFO - 2016-09-14 14:09:46 --> Model Class Initialized
INFO - 2016-09-14 14:09:46 --> Model Class Initialized
DEBUG - 2016-09-14 14:09:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 14:09:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 14:09:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 14:09:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-14 14:09:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 14:09:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 14:09:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 14:09:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 14:09:46 --> Final output sent to browser
DEBUG - 2016-09-14 14:09:46 --> Total execution time: 0.9194
INFO - 2016-09-14 14:10:00 --> Config Class Initialized
INFO - 2016-09-14 14:10:00 --> Hooks Class Initialized
DEBUG - 2016-09-14 14:10:00 --> UTF-8 Support Enabled
INFO - 2016-09-14 14:10:00 --> Utf8 Class Initialized
INFO - 2016-09-14 14:10:00 --> URI Class Initialized
INFO - 2016-09-14 14:10:00 --> Router Class Initialized
INFO - 2016-09-14 14:10:00 --> Output Class Initialized
INFO - 2016-09-14 14:10:01 --> Security Class Initialized
DEBUG - 2016-09-14 14:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 14:10:01 --> Input Class Initialized
INFO - 2016-09-14 14:10:01 --> Language Class Initialized
INFO - 2016-09-14 14:10:01 --> Language Class Initialized
INFO - 2016-09-14 14:10:01 --> Config Class Initialized
INFO - 2016-09-14 14:10:01 --> Loader Class Initialized
INFO - 2016-09-14 14:10:01 --> Helper loaded: url_helper
INFO - 2016-09-14 14:10:01 --> Database Driver Class Initialized
INFO - 2016-09-14 14:10:01 --> Controller Class Initialized
DEBUG - 2016-09-14 14:10:01 --> Index MX_Controller Initialized
INFO - 2016-09-14 14:10:01 --> Model Class Initialized
INFO - 2016-09-14 14:10:01 --> Model Class Initialized
DEBUG - 2016-09-14 14:10:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 14:10:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 14:10:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 14:10:01 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-14 14:10:01 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-14 14:10:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-14 14:10:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 14:10:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 14:10:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 14:10:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 14:10:01 --> Final output sent to browser
DEBUG - 2016-09-14 14:10:01 --> Total execution time: 0.8467
INFO - 2016-09-14 14:10:19 --> Config Class Initialized
INFO - 2016-09-14 14:10:19 --> Hooks Class Initialized
DEBUG - 2016-09-14 14:10:19 --> UTF-8 Support Enabled
INFO - 2016-09-14 14:10:19 --> Utf8 Class Initialized
INFO - 2016-09-14 14:10:19 --> URI Class Initialized
INFO - 2016-09-14 14:10:19 --> Router Class Initialized
INFO - 2016-09-14 14:10:19 --> Output Class Initialized
INFO - 2016-09-14 14:10:19 --> Security Class Initialized
DEBUG - 2016-09-14 14:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 14:10:19 --> Input Class Initialized
INFO - 2016-09-14 14:10:19 --> Language Class Initialized
INFO - 2016-09-14 14:10:19 --> Language Class Initialized
INFO - 2016-09-14 14:10:19 --> Config Class Initialized
INFO - 2016-09-14 14:10:19 --> Loader Class Initialized
INFO - 2016-09-14 14:10:20 --> Helper loaded: url_helper
INFO - 2016-09-14 14:10:20 --> Database Driver Class Initialized
INFO - 2016-09-14 14:10:20 --> Controller Class Initialized
DEBUG - 2016-09-14 14:10:20 --> Index MX_Controller Initialized
INFO - 2016-09-14 14:10:20 --> Model Class Initialized
INFO - 2016-09-14 14:10:20 --> Model Class Initialized
DEBUG - 2016-09-14 14:10:20 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-14 14:10:20 --> Users MX_Controller Initialized
INFO - 2016-09-14 14:10:20 --> Final output sent to browser
DEBUG - 2016-09-14 14:10:20 --> Total execution time: 0.7789
INFO - 2016-09-14 14:10:25 --> Config Class Initialized
INFO - 2016-09-14 14:10:25 --> Hooks Class Initialized
DEBUG - 2016-09-14 14:10:25 --> UTF-8 Support Enabled
INFO - 2016-09-14 14:10:25 --> Utf8 Class Initialized
INFO - 2016-09-14 14:10:25 --> URI Class Initialized
INFO - 2016-09-14 14:10:25 --> Router Class Initialized
INFO - 2016-09-14 14:10:25 --> Output Class Initialized
INFO - 2016-09-14 14:10:25 --> Security Class Initialized
DEBUG - 2016-09-14 14:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 14:10:25 --> Input Class Initialized
INFO - 2016-09-14 14:10:25 --> Language Class Initialized
INFO - 2016-09-14 14:10:25 --> Language Class Initialized
INFO - 2016-09-14 14:10:25 --> Config Class Initialized
INFO - 2016-09-14 14:10:25 --> Loader Class Initialized
INFO - 2016-09-14 14:10:25 --> Helper loaded: url_helper
INFO - 2016-09-14 14:10:25 --> Database Driver Class Initialized
INFO - 2016-09-14 14:10:25 --> Controller Class Initialized
DEBUG - 2016-09-14 14:10:25 --> Index MX_Controller Initialized
INFO - 2016-09-14 14:10:25 --> Model Class Initialized
INFO - 2016-09-14 14:10:25 --> Model Class Initialized
DEBUG - 2016-09-14 14:10:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 14:10:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 14:10:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 14:10:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-14 14:10:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 14:10:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 14:10:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 14:10:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 14:10:26 --> Final output sent to browser
DEBUG - 2016-09-14 14:10:26 --> Total execution time: 0.7871
INFO - 2016-09-14 14:10:36 --> Config Class Initialized
INFO - 2016-09-14 14:10:36 --> Hooks Class Initialized
DEBUG - 2016-09-14 14:10:36 --> UTF-8 Support Enabled
INFO - 2016-09-14 14:10:36 --> Utf8 Class Initialized
INFO - 2016-09-14 14:10:36 --> URI Class Initialized
INFO - 2016-09-14 14:10:36 --> Router Class Initialized
INFO - 2016-09-14 14:10:36 --> Output Class Initialized
INFO - 2016-09-14 14:10:36 --> Security Class Initialized
DEBUG - 2016-09-14 14:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 14:10:37 --> Input Class Initialized
INFO - 2016-09-14 14:10:37 --> Language Class Initialized
INFO - 2016-09-14 14:10:37 --> Language Class Initialized
INFO - 2016-09-14 14:10:37 --> Config Class Initialized
INFO - 2016-09-14 14:10:37 --> Loader Class Initialized
INFO - 2016-09-14 14:10:37 --> Helper loaded: url_helper
INFO - 2016-09-14 14:10:37 --> Database Driver Class Initialized
INFO - 2016-09-14 14:10:37 --> Controller Class Initialized
DEBUG - 2016-09-14 14:10:37 --> Index MX_Controller Initialized
INFO - 2016-09-14 14:10:37 --> Model Class Initialized
INFO - 2016-09-14 14:10:37 --> Model Class Initialized
DEBUG - 2016-09-14 14:10:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 14:10:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 14:10:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 14:10:37 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-14 14:10:37 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-14 14:10:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-14 14:10:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 14:10:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 14:10:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 14:10:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 14:10:37 --> Final output sent to browser
DEBUG - 2016-09-14 14:10:37 --> Total execution time: 0.8715
INFO - 2016-09-14 14:10:46 --> Config Class Initialized
INFO - 2016-09-14 14:10:46 --> Hooks Class Initialized
DEBUG - 2016-09-14 14:10:46 --> UTF-8 Support Enabled
INFO - 2016-09-14 14:10:46 --> Utf8 Class Initialized
INFO - 2016-09-14 14:10:46 --> URI Class Initialized
INFO - 2016-09-14 14:10:46 --> Router Class Initialized
INFO - 2016-09-14 14:10:46 --> Output Class Initialized
INFO - 2016-09-14 14:10:46 --> Security Class Initialized
DEBUG - 2016-09-14 14:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 14:10:46 --> Input Class Initialized
INFO - 2016-09-14 14:10:46 --> Language Class Initialized
INFO - 2016-09-14 14:10:46 --> Language Class Initialized
INFO - 2016-09-14 14:10:46 --> Config Class Initialized
INFO - 2016-09-14 14:10:46 --> Loader Class Initialized
INFO - 2016-09-14 14:10:46 --> Helper loaded: url_helper
INFO - 2016-09-14 14:10:46 --> Database Driver Class Initialized
INFO - 2016-09-14 14:10:46 --> Controller Class Initialized
DEBUG - 2016-09-14 14:10:46 --> Index MX_Controller Initialized
INFO - 2016-09-14 14:10:46 --> Model Class Initialized
INFO - 2016-09-14 14:10:46 --> Model Class Initialized
DEBUG - 2016-09-14 14:10:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 14:10:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 14:10:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 14:10:47 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/user/controllers/Users.php
DEBUG - 2016-09-14 14:10:47 --> Users MX_Controller Initialized
DEBUG - 2016-09-14 14:10:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_user.php
DEBUG - 2016-09-14 14:10:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 14:10:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 14:10:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 14:10:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 14:10:47 --> Final output sent to browser
DEBUG - 2016-09-14 14:10:47 --> Total execution time: 1.0317
INFO - 2016-09-14 14:10:53 --> Config Class Initialized
INFO - 2016-09-14 14:10:53 --> Hooks Class Initialized
DEBUG - 2016-09-14 14:10:53 --> UTF-8 Support Enabled
INFO - 2016-09-14 14:10:53 --> Utf8 Class Initialized
INFO - 2016-09-14 14:10:53 --> URI Class Initialized
INFO - 2016-09-14 14:10:53 --> Router Class Initialized
INFO - 2016-09-14 14:10:54 --> Output Class Initialized
INFO - 2016-09-14 14:10:54 --> Security Class Initialized
DEBUG - 2016-09-14 14:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 14:10:54 --> Input Class Initialized
INFO - 2016-09-14 14:10:54 --> Language Class Initialized
INFO - 2016-09-14 14:10:54 --> Language Class Initialized
INFO - 2016-09-14 14:10:54 --> Config Class Initialized
INFO - 2016-09-14 14:10:54 --> Loader Class Initialized
INFO - 2016-09-14 14:10:54 --> Helper loaded: url_helper
INFO - 2016-09-14 14:10:54 --> Database Driver Class Initialized
INFO - 2016-09-14 14:10:54 --> Controller Class Initialized
DEBUG - 2016-09-14 14:10:54 --> Index MX_Controller Initialized
INFO - 2016-09-14 14:10:54 --> Model Class Initialized
INFO - 2016-09-14 14:10:54 --> Model Class Initialized
DEBUG - 2016-09-14 14:10:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 14:10:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 14:10:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 14:10:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_user.php
DEBUG - 2016-09-14 14:10:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 14:10:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 14:10:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 14:10:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 14:10:54 --> Final output sent to browser
DEBUG - 2016-09-14 14:10:54 --> Total execution time: 0.8408
INFO - 2016-09-14 14:11:29 --> Config Class Initialized
INFO - 2016-09-14 14:11:29 --> Hooks Class Initialized
DEBUG - 2016-09-14 14:11:29 --> UTF-8 Support Enabled
INFO - 2016-09-14 14:11:29 --> Utf8 Class Initialized
INFO - 2016-09-14 14:11:29 --> URI Class Initialized
INFO - 2016-09-14 14:11:29 --> Router Class Initialized
INFO - 2016-09-14 14:11:29 --> Output Class Initialized
INFO - 2016-09-14 14:11:29 --> Security Class Initialized
DEBUG - 2016-09-14 14:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 14:11:29 --> Input Class Initialized
INFO - 2016-09-14 14:11:29 --> Language Class Initialized
INFO - 2016-09-14 14:11:29 --> Language Class Initialized
INFO - 2016-09-14 14:11:29 --> Config Class Initialized
INFO - 2016-09-14 14:11:29 --> Loader Class Initialized
INFO - 2016-09-14 14:11:29 --> Helper loaded: url_helper
INFO - 2016-09-14 14:11:29 --> Database Driver Class Initialized
INFO - 2016-09-14 14:11:29 --> Controller Class Initialized
DEBUG - 2016-09-14 14:11:29 --> Index MX_Controller Initialized
INFO - 2016-09-14 14:11:29 --> Model Class Initialized
INFO - 2016-09-14 14:11:29 --> Model Class Initialized
DEBUG - 2016-09-14 14:11:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 14:11:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 14:11:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 14:11:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-14 14:11:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 14:11:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 14:11:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 14:11:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 14:11:29 --> Final output sent to browser
DEBUG - 2016-09-14 14:11:30 --> Total execution time: 0.8033
INFO - 2016-09-14 14:11:44 --> Config Class Initialized
INFO - 2016-09-14 14:11:44 --> Hooks Class Initialized
DEBUG - 2016-09-14 14:11:44 --> UTF-8 Support Enabled
INFO - 2016-09-14 14:11:44 --> Utf8 Class Initialized
INFO - 2016-09-14 14:11:44 --> URI Class Initialized
INFO - 2016-09-14 14:11:44 --> Router Class Initialized
INFO - 2016-09-14 14:11:44 --> Output Class Initialized
INFO - 2016-09-14 14:11:44 --> Security Class Initialized
DEBUG - 2016-09-14 14:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 14:11:44 --> Input Class Initialized
INFO - 2016-09-14 14:11:44 --> Language Class Initialized
INFO - 2016-09-14 14:11:44 --> Language Class Initialized
INFO - 2016-09-14 14:11:44 --> Config Class Initialized
INFO - 2016-09-14 14:11:44 --> Loader Class Initialized
INFO - 2016-09-14 14:11:44 --> Helper loaded: url_helper
INFO - 2016-09-14 14:11:44 --> Database Driver Class Initialized
INFO - 2016-09-14 14:11:44 --> Controller Class Initialized
DEBUG - 2016-09-14 14:11:44 --> Index MX_Controller Initialized
INFO - 2016-09-14 14:11:44 --> Model Class Initialized
INFO - 2016-09-14 14:11:44 --> Model Class Initialized
DEBUG - 2016-09-14 14:11:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 14:11:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 14:11:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 14:11:44 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/user/controllers/Users.php
DEBUG - 2016-09-14 14:11:45 --> Users MX_Controller Initialized
DEBUG - 2016-09-14 14:11:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_user.php
DEBUG - 2016-09-14 14:11:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 14:11:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 14:11:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 14:11:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 14:11:45 --> Final output sent to browser
DEBUG - 2016-09-14 14:11:45 --> Total execution time: 0.8641
INFO - 2016-09-14 14:12:27 --> Config Class Initialized
INFO - 2016-09-14 14:12:27 --> Hooks Class Initialized
DEBUG - 2016-09-14 14:12:27 --> UTF-8 Support Enabled
INFO - 2016-09-14 14:12:27 --> Utf8 Class Initialized
INFO - 2016-09-14 14:12:27 --> URI Class Initialized
INFO - 2016-09-14 14:12:27 --> Router Class Initialized
INFO - 2016-09-14 14:12:27 --> Output Class Initialized
INFO - 2016-09-14 14:12:27 --> Security Class Initialized
DEBUG - 2016-09-14 14:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 14:12:27 --> Input Class Initialized
INFO - 2016-09-14 14:12:27 --> Language Class Initialized
INFO - 2016-09-14 14:12:27 --> Language Class Initialized
INFO - 2016-09-14 14:12:27 --> Config Class Initialized
INFO - 2016-09-14 14:12:28 --> Loader Class Initialized
INFO - 2016-09-14 14:12:28 --> Helper loaded: url_helper
INFO - 2016-09-14 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-14 14:12:28 --> Controller Class Initialized
DEBUG - 2016-09-14 14:12:28 --> Index MX_Controller Initialized
INFO - 2016-09-14 14:12:28 --> Model Class Initialized
INFO - 2016-09-14 14:12:28 --> Model Class Initialized
DEBUG - 2016-09-14 14:12:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 14:12:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 14:12:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 14:12:28 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-14 14:12:28 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-14 14:12:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-14 14:12:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 14:12:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 14:12:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 14:12:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 14:12:28 --> Final output sent to browser
DEBUG - 2016-09-14 14:12:28 --> Total execution time: 0.8617
INFO - 2016-09-14 14:12:44 --> Config Class Initialized
INFO - 2016-09-14 14:12:44 --> Hooks Class Initialized
DEBUG - 2016-09-14 14:12:44 --> UTF-8 Support Enabled
INFO - 2016-09-14 14:12:44 --> Utf8 Class Initialized
INFO - 2016-09-14 14:12:44 --> URI Class Initialized
INFO - 2016-09-14 14:12:44 --> Router Class Initialized
INFO - 2016-09-14 14:12:44 --> Output Class Initialized
INFO - 2016-09-14 14:12:44 --> Security Class Initialized
DEBUG - 2016-09-14 14:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 14:12:44 --> Input Class Initialized
INFO - 2016-09-14 14:12:45 --> Language Class Initialized
INFO - 2016-09-14 14:12:45 --> Language Class Initialized
INFO - 2016-09-14 14:12:45 --> Config Class Initialized
INFO - 2016-09-14 14:12:45 --> Loader Class Initialized
INFO - 2016-09-14 14:12:45 --> Helper loaded: url_helper
INFO - 2016-09-14 14:12:45 --> Database Driver Class Initialized
INFO - 2016-09-14 14:12:45 --> Controller Class Initialized
DEBUG - 2016-09-14 14:12:45 --> Index MX_Controller Initialized
INFO - 2016-09-14 14:12:45 --> Model Class Initialized
INFO - 2016-09-14 14:12:45 --> Model Class Initialized
DEBUG - 2016-09-14 14:12:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 14:12:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 14:12:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 14:12:45 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-14 14:12:45 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-14 14:12:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-14 14:12:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 14:12:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 14:12:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 14:12:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 14:12:45 --> Final output sent to browser
DEBUG - 2016-09-14 14:12:45 --> Total execution time: 0.8708
INFO - 2016-09-14 14:12:54 --> Config Class Initialized
INFO - 2016-09-14 14:12:54 --> Hooks Class Initialized
DEBUG - 2016-09-14 14:12:54 --> UTF-8 Support Enabled
INFO - 2016-09-14 14:12:54 --> Utf8 Class Initialized
INFO - 2016-09-14 14:12:54 --> URI Class Initialized
INFO - 2016-09-14 14:12:54 --> Router Class Initialized
INFO - 2016-09-14 14:12:54 --> Output Class Initialized
INFO - 2016-09-14 14:12:54 --> Security Class Initialized
DEBUG - 2016-09-14 14:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 14:12:54 --> Input Class Initialized
INFO - 2016-09-14 14:12:54 --> Language Class Initialized
INFO - 2016-09-14 14:12:54 --> Language Class Initialized
INFO - 2016-09-14 14:12:54 --> Config Class Initialized
INFO - 2016-09-14 14:12:54 --> Loader Class Initialized
INFO - 2016-09-14 14:12:54 --> Helper loaded: url_helper
INFO - 2016-09-14 14:12:54 --> Database Driver Class Initialized
INFO - 2016-09-14 14:12:54 --> Controller Class Initialized
DEBUG - 2016-09-14 14:12:54 --> Index MX_Controller Initialized
INFO - 2016-09-14 14:12:54 --> Model Class Initialized
INFO - 2016-09-14 14:12:54 --> Model Class Initialized
DEBUG - 2016-09-14 14:12:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 14:12:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 14:12:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 14:12:54 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-14 14:12:54 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-14 14:12:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-14 14:12:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 14:12:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 14:12:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 14:12:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 14:12:55 --> Final output sent to browser
DEBUG - 2016-09-14 14:12:55 --> Total execution time: 0.9423
INFO - 2016-09-14 14:13:02 --> Config Class Initialized
INFO - 2016-09-14 14:13:02 --> Hooks Class Initialized
DEBUG - 2016-09-14 14:13:02 --> UTF-8 Support Enabled
INFO - 2016-09-14 14:13:02 --> Utf8 Class Initialized
INFO - 2016-09-14 14:13:02 --> URI Class Initialized
INFO - 2016-09-14 14:13:02 --> Router Class Initialized
INFO - 2016-09-14 14:13:02 --> Output Class Initialized
INFO - 2016-09-14 14:13:02 --> Security Class Initialized
DEBUG - 2016-09-14 14:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 14:13:02 --> Input Class Initialized
INFO - 2016-09-14 14:13:02 --> Language Class Initialized
INFO - 2016-09-14 14:13:02 --> Language Class Initialized
INFO - 2016-09-14 14:13:02 --> Config Class Initialized
INFO - 2016-09-14 14:13:02 --> Loader Class Initialized
INFO - 2016-09-14 14:13:02 --> Helper loaded: url_helper
INFO - 2016-09-14 14:13:02 --> Database Driver Class Initialized
INFO - 2016-09-14 14:13:02 --> Controller Class Initialized
DEBUG - 2016-09-14 14:13:02 --> Index MX_Controller Initialized
INFO - 2016-09-14 14:13:02 --> Model Class Initialized
INFO - 2016-09-14 14:13:03 --> Model Class Initialized
DEBUG - 2016-09-14 14:13:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 14:13:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 14:13:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 14:13:03 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-14 14:13:03 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-14 14:13:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-14 14:13:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 14:13:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 14:13:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 14:13:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 14:13:03 --> Final output sent to browser
DEBUG - 2016-09-14 14:13:03 --> Total execution time: 0.9069
INFO - 2016-09-14 14:13:10 --> Config Class Initialized
INFO - 2016-09-14 14:13:10 --> Hooks Class Initialized
DEBUG - 2016-09-14 14:13:10 --> UTF-8 Support Enabled
INFO - 2016-09-14 14:13:10 --> Utf8 Class Initialized
INFO - 2016-09-14 14:13:10 --> URI Class Initialized
INFO - 2016-09-14 14:13:10 --> Router Class Initialized
INFO - 2016-09-14 14:13:10 --> Output Class Initialized
INFO - 2016-09-14 14:13:10 --> Security Class Initialized
DEBUG - 2016-09-14 14:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 14:13:10 --> Input Class Initialized
INFO - 2016-09-14 14:13:10 --> Language Class Initialized
INFO - 2016-09-14 14:13:10 --> Language Class Initialized
INFO - 2016-09-14 14:13:10 --> Config Class Initialized
INFO - 2016-09-14 14:13:10 --> Loader Class Initialized
INFO - 2016-09-14 14:13:10 --> Helper loaded: url_helper
INFO - 2016-09-14 14:13:10 --> Database Driver Class Initialized
INFO - 2016-09-14 14:13:10 --> Controller Class Initialized
DEBUG - 2016-09-14 14:13:10 --> Index MX_Controller Initialized
INFO - 2016-09-14 14:13:10 --> Model Class Initialized
INFO - 2016-09-14 14:13:10 --> Model Class Initialized
DEBUG - 2016-09-14 14:13:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 14:13:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 14:13:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 14:13:10 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-14 14:13:10 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-14 14:13:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-14 14:13:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 14:13:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 14:13:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 14:13:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 14:13:11 --> Final output sent to browser
DEBUG - 2016-09-14 14:13:11 --> Total execution time: 0.8603
INFO - 2016-09-14 14:15:40 --> Config Class Initialized
INFO - 2016-09-14 14:15:40 --> Hooks Class Initialized
DEBUG - 2016-09-14 14:15:40 --> UTF-8 Support Enabled
INFO - 2016-09-14 14:15:40 --> Utf8 Class Initialized
INFO - 2016-09-14 14:15:40 --> URI Class Initialized
INFO - 2016-09-14 14:15:40 --> Router Class Initialized
INFO - 2016-09-14 14:15:40 --> Output Class Initialized
INFO - 2016-09-14 14:15:40 --> Security Class Initialized
DEBUG - 2016-09-14 14:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 14:15:40 --> Input Class Initialized
INFO - 2016-09-14 14:15:40 --> Language Class Initialized
INFO - 2016-09-14 14:15:40 --> Language Class Initialized
INFO - 2016-09-14 14:15:40 --> Config Class Initialized
INFO - 2016-09-14 14:15:40 --> Loader Class Initialized
INFO - 2016-09-14 14:15:40 --> Helper loaded: url_helper
INFO - 2016-09-14 14:15:40 --> Database Driver Class Initialized
INFO - 2016-09-14 14:15:40 --> Controller Class Initialized
DEBUG - 2016-09-14 14:15:40 --> Index MX_Controller Initialized
INFO - 2016-09-14 14:15:40 --> Model Class Initialized
INFO - 2016-09-14 14:15:40 --> Model Class Initialized
DEBUG - 2016-09-14 14:15:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 14:15:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 14:15:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 14:15:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-14 14:15:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 14:15:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 14:15:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 14:15:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 14:15:40 --> Final output sent to browser
DEBUG - 2016-09-14 14:15:40 --> Total execution time: 0.8407
INFO - 2016-09-14 14:16:23 --> Config Class Initialized
INFO - 2016-09-14 14:16:23 --> Hooks Class Initialized
DEBUG - 2016-09-14 14:16:23 --> UTF-8 Support Enabled
INFO - 2016-09-14 14:16:23 --> Utf8 Class Initialized
INFO - 2016-09-14 14:16:23 --> URI Class Initialized
INFO - 2016-09-14 14:16:23 --> Router Class Initialized
INFO - 2016-09-14 14:16:23 --> Output Class Initialized
INFO - 2016-09-14 14:16:24 --> Security Class Initialized
DEBUG - 2016-09-14 14:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 14:16:24 --> Input Class Initialized
INFO - 2016-09-14 14:16:24 --> Language Class Initialized
INFO - 2016-09-14 14:16:24 --> Language Class Initialized
INFO - 2016-09-14 14:16:24 --> Config Class Initialized
INFO - 2016-09-14 14:16:24 --> Loader Class Initialized
INFO - 2016-09-14 14:16:24 --> Helper loaded: url_helper
INFO - 2016-09-14 14:16:24 --> Database Driver Class Initialized
INFO - 2016-09-14 14:16:24 --> Controller Class Initialized
DEBUG - 2016-09-14 14:16:24 --> Index MX_Controller Initialized
INFO - 2016-09-14 14:16:24 --> Model Class Initialized
INFO - 2016-09-14 14:16:24 --> Model Class Initialized
DEBUG - 2016-09-14 14:16:24 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 14:16:24 --> Database Driver Class Initialized
INFO - 2016-09-14 14:16:24 --> Final output sent to browser
DEBUG - 2016-09-14 14:16:24 --> Total execution time: 0.6864
INFO - 2016-09-14 14:16:29 --> Config Class Initialized
INFO - 2016-09-14 14:16:29 --> Hooks Class Initialized
DEBUG - 2016-09-14 14:16:29 --> UTF-8 Support Enabled
INFO - 2016-09-14 14:16:30 --> Utf8 Class Initialized
INFO - 2016-09-14 14:16:30 --> URI Class Initialized
INFO - 2016-09-14 14:16:30 --> Router Class Initialized
INFO - 2016-09-14 14:16:30 --> Output Class Initialized
INFO - 2016-09-14 14:16:30 --> Security Class Initialized
DEBUG - 2016-09-14 14:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 14:16:30 --> Input Class Initialized
INFO - 2016-09-14 14:16:30 --> Language Class Initialized
INFO - 2016-09-14 14:16:30 --> Language Class Initialized
INFO - 2016-09-14 14:16:30 --> Config Class Initialized
INFO - 2016-09-14 14:16:30 --> Loader Class Initialized
INFO - 2016-09-14 14:16:30 --> Helper loaded: url_helper
INFO - 2016-09-14 14:16:30 --> Database Driver Class Initialized
INFO - 2016-09-14 14:16:30 --> Controller Class Initialized
DEBUG - 2016-09-14 14:16:30 --> Index MX_Controller Initialized
INFO - 2016-09-14 14:16:30 --> Model Class Initialized
INFO - 2016-09-14 14:16:30 --> Model Class Initialized
DEBUG - 2016-09-14 14:16:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 14:16:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 14:16:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 14:16:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_umum.php
DEBUG - 2016-09-14 14:16:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 14:16:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 14:16:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 14:16:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 14:16:30 --> Final output sent to browser
DEBUG - 2016-09-14 14:16:30 --> Total execution time: 0.9148
INFO - 2016-09-14 14:17:26 --> Config Class Initialized
INFO - 2016-09-14 14:17:27 --> Hooks Class Initialized
DEBUG - 2016-09-14 14:17:27 --> UTF-8 Support Enabled
INFO - 2016-09-14 14:17:27 --> Utf8 Class Initialized
INFO - 2016-09-14 14:17:27 --> URI Class Initialized
INFO - 2016-09-14 14:17:27 --> Router Class Initialized
INFO - 2016-09-14 14:17:27 --> Output Class Initialized
INFO - 2016-09-14 14:17:27 --> Security Class Initialized
DEBUG - 2016-09-14 14:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 14:17:27 --> Input Class Initialized
INFO - 2016-09-14 14:17:27 --> Language Class Initialized
INFO - 2016-09-14 14:17:27 --> Language Class Initialized
INFO - 2016-09-14 14:17:27 --> Config Class Initialized
INFO - 2016-09-14 14:17:27 --> Loader Class Initialized
INFO - 2016-09-14 14:17:27 --> Helper loaded: url_helper
INFO - 2016-09-14 14:17:27 --> Database Driver Class Initialized
INFO - 2016-09-14 14:17:27 --> Controller Class Initialized
DEBUG - 2016-09-14 14:17:27 --> Index MX_Controller Initialized
INFO - 2016-09-14 14:17:27 --> Model Class Initialized
INFO - 2016-09-14 14:17:27 --> Model Class Initialized
DEBUG - 2016-09-14 14:17:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 14:17:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 14:17:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 14:17:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_umum.php
DEBUG - 2016-09-14 14:17:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 14:17:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 14:17:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 14:17:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 14:17:27 --> Final output sent to browser
DEBUG - 2016-09-14 14:17:27 --> Total execution time: 0.8415
INFO - 2016-09-14 14:17:36 --> Config Class Initialized
INFO - 2016-09-14 14:17:36 --> Hooks Class Initialized
DEBUG - 2016-09-14 14:17:36 --> UTF-8 Support Enabled
INFO - 2016-09-14 14:17:37 --> Utf8 Class Initialized
INFO - 2016-09-14 14:17:37 --> URI Class Initialized
INFO - 2016-09-14 14:17:37 --> Router Class Initialized
INFO - 2016-09-14 14:17:37 --> Output Class Initialized
INFO - 2016-09-14 14:17:37 --> Security Class Initialized
DEBUG - 2016-09-14 14:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 14:17:37 --> Input Class Initialized
INFO - 2016-09-14 14:17:37 --> Language Class Initialized
INFO - 2016-09-14 14:17:37 --> Language Class Initialized
INFO - 2016-09-14 14:17:37 --> Config Class Initialized
INFO - 2016-09-14 14:17:37 --> Loader Class Initialized
INFO - 2016-09-14 14:17:37 --> Helper loaded: url_helper
INFO - 2016-09-14 14:17:37 --> Database Driver Class Initialized
INFO - 2016-09-14 14:17:37 --> Controller Class Initialized
DEBUG - 2016-09-14 14:17:37 --> Index MX_Controller Initialized
INFO - 2016-09-14 14:17:37 --> Model Class Initialized
INFO - 2016-09-14 14:17:37 --> Model Class Initialized
DEBUG - 2016-09-14 14:17:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 14:17:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 14:17:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 14:17:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-09-14 14:17:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 14:17:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 14:17:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 14:17:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 14:17:37 --> Final output sent to browser
DEBUG - 2016-09-14 14:17:37 --> Total execution time: 0.9299
INFO - 2016-09-14 14:18:16 --> Config Class Initialized
INFO - 2016-09-14 14:18:16 --> Hooks Class Initialized
DEBUG - 2016-09-14 14:18:16 --> UTF-8 Support Enabled
INFO - 2016-09-14 14:18:16 --> Utf8 Class Initialized
INFO - 2016-09-14 14:18:16 --> URI Class Initialized
INFO - 2016-09-14 14:18:16 --> Router Class Initialized
INFO - 2016-09-14 14:18:16 --> Output Class Initialized
INFO - 2016-09-14 14:18:16 --> Security Class Initialized
DEBUG - 2016-09-14 14:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 14:18:16 --> Input Class Initialized
INFO - 2016-09-14 14:18:16 --> Language Class Initialized
INFO - 2016-09-14 14:18:16 --> Language Class Initialized
INFO - 2016-09-14 14:18:16 --> Config Class Initialized
INFO - 2016-09-14 14:18:16 --> Loader Class Initialized
INFO - 2016-09-14 14:18:16 --> Helper loaded: url_helper
INFO - 2016-09-14 14:18:17 --> Database Driver Class Initialized
INFO - 2016-09-14 14:18:17 --> Controller Class Initialized
DEBUG - 2016-09-14 14:18:17 --> Index MX_Controller Initialized
INFO - 2016-09-14 14:18:17 --> Model Class Initialized
INFO - 2016-09-14 14:18:17 --> Model Class Initialized
DEBUG - 2016-09-14 14:18:17 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 14:18:17 --> Final output sent to browser
DEBUG - 2016-09-14 14:18:17 --> Total execution time: 0.6543
INFO - 2016-09-14 14:18:30 --> Config Class Initialized
INFO - 2016-09-14 14:18:30 --> Hooks Class Initialized
DEBUG - 2016-09-14 14:18:30 --> UTF-8 Support Enabled
INFO - 2016-09-14 14:18:30 --> Utf8 Class Initialized
INFO - 2016-09-14 14:18:30 --> URI Class Initialized
INFO - 2016-09-14 14:18:30 --> Router Class Initialized
INFO - 2016-09-14 14:18:30 --> Output Class Initialized
INFO - 2016-09-14 14:18:30 --> Security Class Initialized
DEBUG - 2016-09-14 14:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 14:18:30 --> Input Class Initialized
INFO - 2016-09-14 14:18:30 --> Language Class Initialized
INFO - 2016-09-14 14:18:30 --> Language Class Initialized
INFO - 2016-09-14 14:18:30 --> Config Class Initialized
INFO - 2016-09-14 14:18:31 --> Loader Class Initialized
INFO - 2016-09-14 14:18:31 --> Helper loaded: url_helper
INFO - 2016-09-14 14:18:31 --> Database Driver Class Initialized
INFO - 2016-09-14 14:18:31 --> Controller Class Initialized
DEBUG - 2016-09-14 14:18:31 --> Index MX_Controller Initialized
INFO - 2016-09-14 14:18:31 --> Model Class Initialized
INFO - 2016-09-14 14:18:31 --> Model Class Initialized
ERROR - 2016-09-14 14:18:31 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 129
DEBUG - 2016-09-14 14:18:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 14:18:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 14:18:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 14:18:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-09-14 14:18:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 14:18:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 14:18:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 14:18:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 14:18:31 --> Final output sent to browser
DEBUG - 2016-09-14 14:18:31 --> Total execution time: 0.9328
INFO - 2016-09-14 14:18:43 --> Config Class Initialized
INFO - 2016-09-14 14:18:43 --> Hooks Class Initialized
DEBUG - 2016-09-14 14:18:43 --> UTF-8 Support Enabled
INFO - 2016-09-14 14:18:43 --> Utf8 Class Initialized
INFO - 2016-09-14 14:18:43 --> URI Class Initialized
INFO - 2016-09-14 14:18:43 --> Router Class Initialized
INFO - 2016-09-14 14:18:43 --> Output Class Initialized
INFO - 2016-09-14 14:18:43 --> Security Class Initialized
DEBUG - 2016-09-14 14:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 14:18:43 --> Input Class Initialized
INFO - 2016-09-14 14:18:43 --> Language Class Initialized
INFO - 2016-09-14 14:18:43 --> Language Class Initialized
INFO - 2016-09-14 14:18:43 --> Config Class Initialized
INFO - 2016-09-14 14:18:44 --> Loader Class Initialized
INFO - 2016-09-14 14:18:44 --> Helper loaded: url_helper
INFO - 2016-09-14 14:18:44 --> Database Driver Class Initialized
INFO - 2016-09-14 14:18:44 --> Controller Class Initialized
DEBUG - 2016-09-14 14:18:44 --> Index MX_Controller Initialized
INFO - 2016-09-14 14:18:44 --> Model Class Initialized
INFO - 2016-09-14 14:18:44 --> Model Class Initialized
DEBUG - 2016-09-14 14:18:44 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 14:18:44 --> Final output sent to browser
DEBUG - 2016-09-14 14:18:44 --> Total execution time: 0.6642
INFO - 2016-09-14 14:18:46 --> Config Class Initialized
INFO - 2016-09-14 14:18:46 --> Hooks Class Initialized
DEBUG - 2016-09-14 14:18:46 --> UTF-8 Support Enabled
INFO - 2016-09-14 14:18:46 --> Utf8 Class Initialized
INFO - 2016-09-14 14:18:46 --> URI Class Initialized
INFO - 2016-09-14 14:18:46 --> Router Class Initialized
INFO - 2016-09-14 14:18:46 --> Output Class Initialized
INFO - 2016-09-14 14:18:46 --> Security Class Initialized
DEBUG - 2016-09-14 14:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 14:18:47 --> Input Class Initialized
INFO - 2016-09-14 14:18:47 --> Language Class Initialized
INFO - 2016-09-14 14:18:47 --> Language Class Initialized
INFO - 2016-09-14 14:18:47 --> Config Class Initialized
INFO - 2016-09-14 14:18:47 --> Loader Class Initialized
INFO - 2016-09-14 14:18:47 --> Helper loaded: url_helper
INFO - 2016-09-14 14:18:47 --> Database Driver Class Initialized
INFO - 2016-09-14 14:18:47 --> Controller Class Initialized
DEBUG - 2016-09-14 14:18:47 --> Index MX_Controller Initialized
INFO - 2016-09-14 14:18:47 --> Model Class Initialized
INFO - 2016-09-14 14:18:47 --> Model Class Initialized
ERROR - 2016-09-14 14:18:47 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 129
DEBUG - 2016-09-14 14:18:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 14:18:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 14:18:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 14:18:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-09-14 14:18:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 14:18:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 14:18:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 14:18:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 14:18:47 --> Final output sent to browser
DEBUG - 2016-09-14 14:18:47 --> Total execution time: 0.8715
INFO - 2016-09-14 14:18:58 --> Config Class Initialized
INFO - 2016-09-14 14:18:58 --> Hooks Class Initialized
DEBUG - 2016-09-14 14:18:58 --> UTF-8 Support Enabled
INFO - 2016-09-14 14:18:58 --> Utf8 Class Initialized
INFO - 2016-09-14 14:18:58 --> URI Class Initialized
INFO - 2016-09-14 14:18:58 --> Router Class Initialized
INFO - 2016-09-14 14:18:58 --> Output Class Initialized
INFO - 2016-09-14 14:18:58 --> Security Class Initialized
DEBUG - 2016-09-14 14:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 14:18:58 --> Input Class Initialized
INFO - 2016-09-14 14:18:58 --> Language Class Initialized
INFO - 2016-09-14 14:18:58 --> Language Class Initialized
INFO - 2016-09-14 14:18:58 --> Config Class Initialized
INFO - 2016-09-14 14:18:59 --> Loader Class Initialized
INFO - 2016-09-14 14:18:59 --> Helper loaded: url_helper
INFO - 2016-09-14 14:18:59 --> Database Driver Class Initialized
INFO - 2016-09-14 14:18:59 --> Controller Class Initialized
DEBUG - 2016-09-14 14:18:59 --> Index MX_Controller Initialized
INFO - 2016-09-14 14:18:59 --> Model Class Initialized
INFO - 2016-09-14 14:18:59 --> Model Class Initialized
DEBUG - 2016-09-14 14:18:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 14:18:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 14:18:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 14:18:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-14 14:18:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 14:18:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 14:18:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 14:18:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 14:18:59 --> Final output sent to browser
DEBUG - 2016-09-14 14:18:59 --> Total execution time: 0.8835
INFO - 2016-09-14 14:19:02 --> Config Class Initialized
INFO - 2016-09-14 14:19:02 --> Hooks Class Initialized
DEBUG - 2016-09-14 14:19:02 --> UTF-8 Support Enabled
INFO - 2016-09-14 14:19:02 --> Utf8 Class Initialized
INFO - 2016-09-14 14:19:02 --> URI Class Initialized
INFO - 2016-09-14 14:19:02 --> Router Class Initialized
INFO - 2016-09-14 14:19:02 --> Output Class Initialized
INFO - 2016-09-14 14:19:02 --> Security Class Initialized
DEBUG - 2016-09-14 14:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 14:19:03 --> Input Class Initialized
INFO - 2016-09-14 14:19:03 --> Language Class Initialized
INFO - 2016-09-14 14:19:03 --> Language Class Initialized
INFO - 2016-09-14 14:19:03 --> Config Class Initialized
INFO - 2016-09-14 14:19:03 --> Loader Class Initialized
INFO - 2016-09-14 14:19:03 --> Helper loaded: url_helper
INFO - 2016-09-14 14:19:03 --> Database Driver Class Initialized
INFO - 2016-09-14 14:19:03 --> Controller Class Initialized
DEBUG - 2016-09-14 14:19:03 --> Index MX_Controller Initialized
INFO - 2016-09-14 14:19:03 --> Model Class Initialized
INFO - 2016-09-14 14:19:03 --> Model Class Initialized
DEBUG - 2016-09-14 14:19:03 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 14:19:03 --> Final output sent to browser
DEBUG - 2016-09-14 14:19:03 --> Total execution time: 0.9723
INFO - 2016-09-14 14:19:09 --> Config Class Initialized
INFO - 2016-09-14 14:19:09 --> Hooks Class Initialized
DEBUG - 2016-09-14 14:19:09 --> UTF-8 Support Enabled
INFO - 2016-09-14 14:19:09 --> Utf8 Class Initialized
INFO - 2016-09-14 14:19:09 --> URI Class Initialized
INFO - 2016-09-14 14:19:09 --> Router Class Initialized
INFO - 2016-09-14 14:19:09 --> Output Class Initialized
INFO - 2016-09-14 14:19:09 --> Security Class Initialized
DEBUG - 2016-09-14 14:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 14:19:09 --> Input Class Initialized
INFO - 2016-09-14 14:19:09 --> Language Class Initialized
INFO - 2016-09-14 14:19:09 --> Language Class Initialized
INFO - 2016-09-14 14:19:09 --> Config Class Initialized
INFO - 2016-09-14 14:19:09 --> Loader Class Initialized
INFO - 2016-09-14 14:19:09 --> Helper loaded: url_helper
INFO - 2016-09-14 14:19:09 --> Database Driver Class Initialized
INFO - 2016-09-14 14:19:09 --> Controller Class Initialized
DEBUG - 2016-09-14 14:19:09 --> Index MX_Controller Initialized
INFO - 2016-09-14 14:19:09 --> Model Class Initialized
INFO - 2016-09-14 14:19:09 --> Model Class Initialized
DEBUG - 2016-09-14 14:19:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 14:19:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 14:19:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 14:19:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-14 14:19:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 14:19:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 14:19:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 14:19:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 14:19:09 --> Final output sent to browser
DEBUG - 2016-09-14 14:19:10 --> Total execution time: 0.8493
INFO - 2016-09-14 14:19:14 --> Config Class Initialized
INFO - 2016-09-14 14:19:14 --> Hooks Class Initialized
DEBUG - 2016-09-14 14:19:14 --> UTF-8 Support Enabled
INFO - 2016-09-14 14:19:14 --> Utf8 Class Initialized
INFO - 2016-09-14 14:19:14 --> URI Class Initialized
INFO - 2016-09-14 14:19:14 --> Router Class Initialized
INFO - 2016-09-14 14:19:14 --> Output Class Initialized
INFO - 2016-09-14 14:19:14 --> Security Class Initialized
DEBUG - 2016-09-14 14:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 14:19:14 --> Input Class Initialized
INFO - 2016-09-14 14:19:14 --> Language Class Initialized
INFO - 2016-09-14 14:19:15 --> Language Class Initialized
INFO - 2016-09-14 14:19:15 --> Config Class Initialized
INFO - 2016-09-14 14:19:15 --> Loader Class Initialized
INFO - 2016-09-14 14:19:15 --> Helper loaded: url_helper
INFO - 2016-09-14 14:19:15 --> Database Driver Class Initialized
INFO - 2016-09-14 14:19:15 --> Controller Class Initialized
DEBUG - 2016-09-14 14:19:15 --> Index MX_Controller Initialized
INFO - 2016-09-14 14:19:15 --> Model Class Initialized
INFO - 2016-09-14 14:19:15 --> Model Class Initialized
DEBUG - 2016-09-14 14:19:15 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 14:19:15 --> Final output sent to browser
DEBUG - 2016-09-14 14:19:15 --> Total execution time: 0.6581
INFO - 2016-09-14 14:19:19 --> Config Class Initialized
INFO - 2016-09-14 14:19:19 --> Hooks Class Initialized
DEBUG - 2016-09-14 14:19:19 --> UTF-8 Support Enabled
INFO - 2016-09-14 14:19:19 --> Utf8 Class Initialized
INFO - 2016-09-14 14:19:19 --> URI Class Initialized
INFO - 2016-09-14 14:19:19 --> Router Class Initialized
INFO - 2016-09-14 14:19:19 --> Output Class Initialized
INFO - 2016-09-14 14:19:19 --> Security Class Initialized
DEBUG - 2016-09-14 14:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 14:19:19 --> Input Class Initialized
INFO - 2016-09-14 14:19:19 --> Language Class Initialized
INFO - 2016-09-14 14:19:19 --> Language Class Initialized
INFO - 2016-09-14 14:19:19 --> Config Class Initialized
INFO - 2016-09-14 14:19:20 --> Loader Class Initialized
INFO - 2016-09-14 14:19:20 --> Helper loaded: url_helper
INFO - 2016-09-14 14:19:20 --> Database Driver Class Initialized
INFO - 2016-09-14 14:19:20 --> Controller Class Initialized
DEBUG - 2016-09-14 14:19:20 --> Index MX_Controller Initialized
INFO - 2016-09-14 14:19:20 --> Model Class Initialized
INFO - 2016-09-14 14:19:20 --> Model Class Initialized
DEBUG - 2016-09-14 14:19:20 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 14:19:20 --> Final output sent to browser
DEBUG - 2016-09-14 14:19:20 --> Total execution time: 0.7112
INFO - 2016-09-14 14:19:26 --> Config Class Initialized
INFO - 2016-09-14 14:19:26 --> Hooks Class Initialized
DEBUG - 2016-09-14 14:19:26 --> UTF-8 Support Enabled
INFO - 2016-09-14 14:19:26 --> Utf8 Class Initialized
INFO - 2016-09-14 14:19:26 --> URI Class Initialized
INFO - 2016-09-14 14:19:26 --> Router Class Initialized
INFO - 2016-09-14 14:19:26 --> Output Class Initialized
INFO - 2016-09-14 14:19:26 --> Security Class Initialized
DEBUG - 2016-09-14 14:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 14:19:26 --> Input Class Initialized
INFO - 2016-09-14 14:19:26 --> Language Class Initialized
INFO - 2016-09-14 14:19:26 --> Language Class Initialized
INFO - 2016-09-14 14:19:26 --> Config Class Initialized
INFO - 2016-09-14 14:19:26 --> Loader Class Initialized
INFO - 2016-09-14 14:19:26 --> Helper loaded: url_helper
INFO - 2016-09-14 14:19:26 --> Database Driver Class Initialized
INFO - 2016-09-14 14:19:26 --> Controller Class Initialized
DEBUG - 2016-09-14 14:19:26 --> Index MX_Controller Initialized
INFO - 2016-09-14 14:19:26 --> Model Class Initialized
INFO - 2016-09-14 14:19:26 --> Model Class Initialized
DEBUG - 2016-09-14 14:19:26 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 14:19:26 --> Database Driver Class Initialized
INFO - 2016-09-14 14:19:27 --> Final output sent to browser
DEBUG - 2016-09-14 14:19:27 --> Total execution time: 0.7133
INFO - 2016-09-14 14:19:31 --> Config Class Initialized
INFO - 2016-09-14 14:19:31 --> Hooks Class Initialized
DEBUG - 2016-09-14 14:19:31 --> UTF-8 Support Enabled
INFO - 2016-09-14 14:19:31 --> Utf8 Class Initialized
INFO - 2016-09-14 14:19:31 --> URI Class Initialized
INFO - 2016-09-14 14:19:31 --> Router Class Initialized
INFO - 2016-09-14 14:19:31 --> Output Class Initialized
INFO - 2016-09-14 14:19:31 --> Security Class Initialized
DEBUG - 2016-09-14 14:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 14:19:31 --> Input Class Initialized
INFO - 2016-09-14 14:19:31 --> Language Class Initialized
INFO - 2016-09-14 14:19:31 --> Language Class Initialized
INFO - 2016-09-14 14:19:31 --> Config Class Initialized
INFO - 2016-09-14 14:19:31 --> Loader Class Initialized
INFO - 2016-09-14 14:19:31 --> Helper loaded: url_helper
INFO - 2016-09-14 14:19:31 --> Database Driver Class Initialized
INFO - 2016-09-14 14:19:31 --> Controller Class Initialized
DEBUG - 2016-09-14 14:19:31 --> Index MX_Controller Initialized
INFO - 2016-09-14 14:19:31 --> Model Class Initialized
INFO - 2016-09-14 14:19:31 --> Model Class Initialized
ERROR - 2016-09-14 14:19:31 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 129
DEBUG - 2016-09-14 14:19:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 14:19:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 14:19:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 14:19:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_umum.php
DEBUG - 2016-09-14 14:19:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 14:19:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 14:19:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 14:19:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 14:19:32 --> Final output sent to browser
DEBUG - 2016-09-14 14:19:32 --> Total execution time: 0.8967
INFO - 2016-09-14 14:19:44 --> Config Class Initialized
INFO - 2016-09-14 14:19:44 --> Hooks Class Initialized
DEBUG - 2016-09-14 14:19:44 --> UTF-8 Support Enabled
INFO - 2016-09-14 14:19:44 --> Utf8 Class Initialized
INFO - 2016-09-14 14:19:44 --> URI Class Initialized
INFO - 2016-09-14 14:19:44 --> Router Class Initialized
INFO - 2016-09-14 14:19:44 --> Output Class Initialized
INFO - 2016-09-14 14:19:44 --> Security Class Initialized
DEBUG - 2016-09-14 14:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 14:19:44 --> Input Class Initialized
INFO - 2016-09-14 14:19:44 --> Language Class Initialized
INFO - 2016-09-14 14:19:45 --> Language Class Initialized
INFO - 2016-09-14 14:19:45 --> Config Class Initialized
INFO - 2016-09-14 14:19:45 --> Loader Class Initialized
INFO - 2016-09-14 14:19:45 --> Helper loaded: url_helper
INFO - 2016-09-14 14:19:45 --> Database Driver Class Initialized
INFO - 2016-09-14 14:19:45 --> Controller Class Initialized
ERROR - 2016-09-14 14:19:45 --> 404 Page Not Found: ../modules/admin/controllers/Index/form_advanced.html
INFO - 2016-09-14 14:24:38 --> Config Class Initialized
INFO - 2016-09-14 14:24:38 --> Hooks Class Initialized
DEBUG - 2016-09-14 14:24:38 --> UTF-8 Support Enabled
INFO - 2016-09-14 14:24:38 --> Utf8 Class Initialized
INFO - 2016-09-14 14:24:38 --> URI Class Initialized
INFO - 2016-09-14 14:24:38 --> Router Class Initialized
INFO - 2016-09-14 14:24:38 --> Output Class Initialized
INFO - 2016-09-14 14:24:39 --> Security Class Initialized
DEBUG - 2016-09-14 14:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 14:24:39 --> Input Class Initialized
INFO - 2016-09-14 14:24:39 --> Language Class Initialized
INFO - 2016-09-14 14:24:39 --> Language Class Initialized
INFO - 2016-09-14 14:24:39 --> Config Class Initialized
INFO - 2016-09-14 14:24:39 --> Loader Class Initialized
INFO - 2016-09-14 14:24:39 --> Helper loaded: url_helper
INFO - 2016-09-14 14:24:39 --> Database Driver Class Initialized
INFO - 2016-09-14 14:24:39 --> Controller Class Initialized
DEBUG - 2016-09-14 14:24:39 --> Index MX_Controller Initialized
INFO - 2016-09-14 14:24:39 --> Model Class Initialized
INFO - 2016-09-14 14:24:39 --> Model Class Initialized
DEBUG - 2016-09-14 14:24:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 14:24:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 14:24:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 14:24:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_bayar_angsuran.php
DEBUG - 2016-09-14 14:24:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 14:24:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 14:24:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 14:24:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 14:24:39 --> Final output sent to browser
DEBUG - 2016-09-14 14:24:39 --> Total execution time: 0.8854
INFO - 2016-09-14 14:25:07 --> Config Class Initialized
INFO - 2016-09-14 14:25:07 --> Hooks Class Initialized
DEBUG - 2016-09-14 14:25:07 --> UTF-8 Support Enabled
INFO - 2016-09-14 14:25:07 --> Utf8 Class Initialized
INFO - 2016-09-14 14:25:07 --> URI Class Initialized
INFO - 2016-09-14 14:25:07 --> Router Class Initialized
INFO - 2016-09-14 14:25:07 --> Output Class Initialized
INFO - 2016-09-14 14:25:07 --> Security Class Initialized
DEBUG - 2016-09-14 14:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 14:25:07 --> Input Class Initialized
INFO - 2016-09-14 14:25:07 --> Language Class Initialized
INFO - 2016-09-14 14:25:07 --> Language Class Initialized
INFO - 2016-09-14 14:25:07 --> Config Class Initialized
INFO - 2016-09-14 14:25:07 --> Loader Class Initialized
INFO - 2016-09-14 14:25:07 --> Helper loaded: url_helper
INFO - 2016-09-14 14:25:08 --> Database Driver Class Initialized
INFO - 2016-09-14 14:25:08 --> Controller Class Initialized
DEBUG - 2016-09-14 14:25:08 --> Index MX_Controller Initialized
INFO - 2016-09-14 14:25:08 --> Model Class Initialized
INFO - 2016-09-14 14:25:08 --> Model Class Initialized
DEBUG - 2016-09-14 14:25:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 14:25:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 14:25:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 14:25:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_bayar_angsuran.php
DEBUG - 2016-09-14 14:25:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 14:25:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 14:25:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 14:25:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 14:25:08 --> Final output sent to browser
DEBUG - 2016-09-14 14:25:08 --> Total execution time: 0.9123
INFO - 2016-09-14 14:51:59 --> Config Class Initialized
INFO - 2016-09-14 14:51:59 --> Hooks Class Initialized
DEBUG - 2016-09-14 14:52:00 --> UTF-8 Support Enabled
INFO - 2016-09-14 14:52:00 --> Utf8 Class Initialized
INFO - 2016-09-14 14:52:00 --> URI Class Initialized
INFO - 2016-09-14 14:52:00 --> Router Class Initialized
INFO - 2016-09-14 14:52:00 --> Output Class Initialized
INFO - 2016-09-14 14:52:00 --> Security Class Initialized
DEBUG - 2016-09-14 14:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 14:52:00 --> Input Class Initialized
INFO - 2016-09-14 14:52:00 --> Language Class Initialized
INFO - 2016-09-14 14:52:00 --> Language Class Initialized
INFO - 2016-09-14 14:52:00 --> Config Class Initialized
INFO - 2016-09-14 14:52:00 --> Loader Class Initialized
INFO - 2016-09-14 14:52:00 --> Helper loaded: url_helper
INFO - 2016-09-14 14:52:00 --> Database Driver Class Initialized
INFO - 2016-09-14 14:52:00 --> Controller Class Initialized
DEBUG - 2016-09-14 14:52:00 --> Index MX_Controller Initialized
INFO - 2016-09-14 14:52:00 --> Model Class Initialized
INFO - 2016-09-14 14:52:00 --> Model Class Initialized
DEBUG - 2016-09-14 14:52:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 14:52:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 14:52:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 14:52:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_bayar_angsuran.php
DEBUG - 2016-09-14 14:52:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 14:52:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 14:52:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 14:52:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 14:52:00 --> Final output sent to browser
DEBUG - 2016-09-14 14:52:01 --> Total execution time: 0.9637
INFO - 2016-09-14 14:52:04 --> Config Class Initialized
INFO - 2016-09-14 14:52:04 --> Hooks Class Initialized
DEBUG - 2016-09-14 14:52:04 --> UTF-8 Support Enabled
INFO - 2016-09-14 14:52:04 --> Utf8 Class Initialized
INFO - 2016-09-14 14:52:04 --> URI Class Initialized
INFO - 2016-09-14 14:52:04 --> Router Class Initialized
INFO - 2016-09-14 14:52:04 --> Output Class Initialized
INFO - 2016-09-14 14:52:05 --> Security Class Initialized
DEBUG - 2016-09-14 14:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 14:52:05 --> Input Class Initialized
INFO - 2016-09-14 14:52:05 --> Language Class Initialized
INFO - 2016-09-14 14:52:05 --> Language Class Initialized
INFO - 2016-09-14 14:52:05 --> Config Class Initialized
INFO - 2016-09-14 14:52:05 --> Loader Class Initialized
INFO - 2016-09-14 14:52:05 --> Helper loaded: url_helper
INFO - 2016-09-14 14:52:05 --> Database Driver Class Initialized
INFO - 2016-09-14 14:52:05 --> Controller Class Initialized
DEBUG - 2016-09-14 14:52:05 --> Index MX_Controller Initialized
INFO - 2016-09-14 14:52:05 --> Model Class Initialized
INFO - 2016-09-14 14:52:05 --> Model Class Initialized
INFO - 2016-09-14 14:52:05 --> Database Driver Class Initialized
INFO - 2016-09-14 14:52:05 --> Final output sent to browser
DEBUG - 2016-09-14 14:52:05 --> Total execution time: 0.7062
INFO - 2016-09-14 14:52:20 --> Config Class Initialized
INFO - 2016-09-14 14:52:20 --> Hooks Class Initialized
DEBUG - 2016-09-14 14:52:20 --> UTF-8 Support Enabled
INFO - 2016-09-14 14:52:20 --> Utf8 Class Initialized
INFO - 2016-09-14 14:52:20 --> URI Class Initialized
INFO - 2016-09-14 14:52:20 --> Router Class Initialized
INFO - 2016-09-14 14:52:21 --> Output Class Initialized
INFO - 2016-09-14 14:52:21 --> Security Class Initialized
DEBUG - 2016-09-14 14:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 14:52:21 --> Input Class Initialized
INFO - 2016-09-14 14:52:21 --> Language Class Initialized
INFO - 2016-09-14 14:52:21 --> Language Class Initialized
INFO - 2016-09-14 14:52:21 --> Config Class Initialized
INFO - 2016-09-14 14:52:21 --> Loader Class Initialized
INFO - 2016-09-14 14:52:21 --> Helper loaded: url_helper
INFO - 2016-09-14 14:52:21 --> Database Driver Class Initialized
INFO - 2016-09-14 14:52:21 --> Controller Class Initialized
DEBUG - 2016-09-14 14:52:21 --> Index MX_Controller Initialized
INFO - 2016-09-14 14:52:21 --> Model Class Initialized
INFO - 2016-09-14 14:52:21 --> Model Class Initialized
INFO - 2016-09-14 14:52:21 --> Database Driver Class Initialized
INFO - 2016-09-14 14:52:21 --> Final output sent to browser
DEBUG - 2016-09-14 14:52:21 --> Total execution time: 0.7533
INFO - 2016-09-14 14:53:36 --> Config Class Initialized
INFO - 2016-09-14 14:53:36 --> Hooks Class Initialized
DEBUG - 2016-09-14 14:53:36 --> UTF-8 Support Enabled
INFO - 2016-09-14 14:53:36 --> Utf8 Class Initialized
INFO - 2016-09-14 14:53:36 --> URI Class Initialized
INFO - 2016-09-14 14:53:36 --> Router Class Initialized
INFO - 2016-09-14 14:53:36 --> Output Class Initialized
INFO - 2016-09-14 14:53:36 --> Security Class Initialized
DEBUG - 2016-09-14 14:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 14:53:36 --> Input Class Initialized
INFO - 2016-09-14 14:53:36 --> Language Class Initialized
INFO - 2016-09-14 14:53:36 --> Language Class Initialized
INFO - 2016-09-14 14:53:36 --> Config Class Initialized
INFO - 2016-09-14 14:53:36 --> Loader Class Initialized
INFO - 2016-09-14 14:53:36 --> Helper loaded: url_helper
INFO - 2016-09-14 14:53:36 --> Database Driver Class Initialized
INFO - 2016-09-14 14:53:36 --> Controller Class Initialized
DEBUG - 2016-09-14 14:53:36 --> Index MX_Controller Initialized
INFO - 2016-09-14 14:53:36 --> Model Class Initialized
INFO - 2016-09-14 14:53:36 --> Model Class Initialized
DEBUG - 2016-09-14 14:53:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 14:53:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 14:53:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 14:53:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_bayar_angsuran.php
DEBUG - 2016-09-14 14:53:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 14:53:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 14:53:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 14:53:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 14:53:37 --> Final output sent to browser
DEBUG - 2016-09-14 14:53:37 --> Total execution time: 1.0069
INFO - 2016-09-14 14:53:45 --> Config Class Initialized
INFO - 2016-09-14 14:53:45 --> Hooks Class Initialized
DEBUG - 2016-09-14 14:53:45 --> UTF-8 Support Enabled
INFO - 2016-09-14 14:53:45 --> Utf8 Class Initialized
INFO - 2016-09-14 14:53:45 --> URI Class Initialized
INFO - 2016-09-14 14:53:45 --> Router Class Initialized
INFO - 2016-09-14 14:53:45 --> Output Class Initialized
INFO - 2016-09-14 14:53:45 --> Security Class Initialized
DEBUG - 2016-09-14 14:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 14:53:45 --> Input Class Initialized
INFO - 2016-09-14 14:53:45 --> Language Class Initialized
INFO - 2016-09-14 14:53:45 --> Language Class Initialized
INFO - 2016-09-14 14:53:46 --> Config Class Initialized
INFO - 2016-09-14 14:53:46 --> Loader Class Initialized
INFO - 2016-09-14 14:53:46 --> Helper loaded: url_helper
INFO - 2016-09-14 14:53:46 --> Database Driver Class Initialized
INFO - 2016-09-14 14:53:46 --> Controller Class Initialized
DEBUG - 2016-09-14 14:53:46 --> Index MX_Controller Initialized
INFO - 2016-09-14 14:53:46 --> Model Class Initialized
INFO - 2016-09-14 14:53:46 --> Model Class Initialized
INFO - 2016-09-14 14:53:46 --> Final output sent to browser
DEBUG - 2016-09-14 14:53:46 --> Total execution time: 0.6670
INFO - 2016-09-14 14:53:49 --> Config Class Initialized
INFO - 2016-09-14 14:53:49 --> Hooks Class Initialized
DEBUG - 2016-09-14 14:53:49 --> UTF-8 Support Enabled
INFO - 2016-09-14 14:53:49 --> Utf8 Class Initialized
INFO - 2016-09-14 14:53:49 --> URI Class Initialized
INFO - 2016-09-14 14:53:49 --> Router Class Initialized
INFO - 2016-09-14 14:53:49 --> Output Class Initialized
INFO - 2016-09-14 14:53:49 --> Security Class Initialized
DEBUG - 2016-09-14 14:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 14:53:49 --> Input Class Initialized
INFO - 2016-09-14 14:53:49 --> Language Class Initialized
INFO - 2016-09-14 14:53:49 --> Language Class Initialized
INFO - 2016-09-14 14:53:49 --> Config Class Initialized
INFO - 2016-09-14 14:53:49 --> Loader Class Initialized
INFO - 2016-09-14 14:53:49 --> Helper loaded: url_helper
INFO - 2016-09-14 14:53:49 --> Database Driver Class Initialized
INFO - 2016-09-14 14:53:49 --> Controller Class Initialized
DEBUG - 2016-09-14 14:53:49 --> Index MX_Controller Initialized
INFO - 2016-09-14 14:53:49 --> Model Class Initialized
INFO - 2016-09-14 14:53:49 --> Model Class Initialized
INFO - 2016-09-14 14:53:49 --> Database Driver Class Initialized
INFO - 2016-09-14 14:53:49 --> Final output sent to browser
DEBUG - 2016-09-14 14:53:49 --> Total execution time: 0.7796
INFO - 2016-09-14 14:54:18 --> Config Class Initialized
INFO - 2016-09-14 14:54:18 --> Hooks Class Initialized
DEBUG - 2016-09-14 14:54:18 --> UTF-8 Support Enabled
INFO - 2016-09-14 14:54:18 --> Utf8 Class Initialized
INFO - 2016-09-14 14:54:18 --> URI Class Initialized
INFO - 2016-09-14 14:54:18 --> Router Class Initialized
INFO - 2016-09-14 14:54:18 --> Output Class Initialized
INFO - 2016-09-14 14:54:18 --> Security Class Initialized
DEBUG - 2016-09-14 14:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 14:54:18 --> Input Class Initialized
INFO - 2016-09-14 14:54:18 --> Language Class Initialized
INFO - 2016-09-14 14:54:18 --> Language Class Initialized
INFO - 2016-09-14 14:54:18 --> Config Class Initialized
INFO - 2016-09-14 14:54:18 --> Loader Class Initialized
INFO - 2016-09-14 14:54:18 --> Helper loaded: url_helper
INFO - 2016-09-14 14:54:19 --> Database Driver Class Initialized
INFO - 2016-09-14 14:54:19 --> Controller Class Initialized
DEBUG - 2016-09-14 14:54:19 --> Index MX_Controller Initialized
INFO - 2016-09-14 14:54:19 --> Model Class Initialized
INFO - 2016-09-14 14:54:19 --> Model Class Initialized
INFO - 2016-09-14 14:54:19 --> Database Driver Class Initialized
INFO - 2016-09-14 14:54:19 --> Final output sent to browser
DEBUG - 2016-09-14 14:54:19 --> Total execution time: 0.7118
INFO - 2016-09-14 14:55:04 --> Config Class Initialized
INFO - 2016-09-14 14:55:04 --> Hooks Class Initialized
DEBUG - 2016-09-14 14:55:04 --> UTF-8 Support Enabled
INFO - 2016-09-14 14:55:04 --> Utf8 Class Initialized
INFO - 2016-09-14 14:55:04 --> URI Class Initialized
INFO - 2016-09-14 14:55:04 --> Router Class Initialized
INFO - 2016-09-14 14:55:04 --> Output Class Initialized
INFO - 2016-09-14 14:55:04 --> Security Class Initialized
DEBUG - 2016-09-14 14:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 14:55:04 --> Input Class Initialized
INFO - 2016-09-14 14:55:04 --> Language Class Initialized
INFO - 2016-09-14 14:55:04 --> Language Class Initialized
INFO - 2016-09-14 14:55:04 --> Config Class Initialized
INFO - 2016-09-14 14:55:04 --> Loader Class Initialized
INFO - 2016-09-14 14:55:04 --> Helper loaded: url_helper
INFO - 2016-09-14 14:55:04 --> Database Driver Class Initialized
INFO - 2016-09-14 14:55:04 --> Controller Class Initialized
DEBUG - 2016-09-14 14:55:04 --> Index MX_Controller Initialized
INFO - 2016-09-14 14:55:04 --> Model Class Initialized
INFO - 2016-09-14 14:55:04 --> Model Class Initialized
DEBUG - 2016-09-14 14:55:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 14:55:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 14:55:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 14:55:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_bayar_angsuran.php
DEBUG - 2016-09-14 14:55:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 14:55:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 14:55:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 14:55:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 14:55:04 --> Final output sent to browser
DEBUG - 2016-09-14 14:55:04 --> Total execution time: 0.9077
INFO - 2016-09-14 14:55:08 --> Config Class Initialized
INFO - 2016-09-14 14:55:08 --> Hooks Class Initialized
DEBUG - 2016-09-14 14:55:08 --> UTF-8 Support Enabled
INFO - 2016-09-14 14:55:08 --> Utf8 Class Initialized
INFO - 2016-09-14 14:55:08 --> URI Class Initialized
INFO - 2016-09-14 14:55:08 --> Router Class Initialized
INFO - 2016-09-14 14:55:08 --> Output Class Initialized
INFO - 2016-09-14 14:55:08 --> Security Class Initialized
DEBUG - 2016-09-14 14:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 14:55:09 --> Input Class Initialized
INFO - 2016-09-14 14:55:09 --> Language Class Initialized
INFO - 2016-09-14 14:55:09 --> Language Class Initialized
INFO - 2016-09-14 14:55:09 --> Config Class Initialized
INFO - 2016-09-14 14:55:09 --> Loader Class Initialized
INFO - 2016-09-14 14:55:09 --> Helper loaded: url_helper
INFO - 2016-09-14 14:55:09 --> Database Driver Class Initialized
INFO - 2016-09-14 14:55:09 --> Controller Class Initialized
DEBUG - 2016-09-14 14:55:09 --> Index MX_Controller Initialized
INFO - 2016-09-14 14:55:09 --> Model Class Initialized
INFO - 2016-09-14 14:55:09 --> Model Class Initialized
INFO - 2016-09-14 14:55:09 --> Database Driver Class Initialized
INFO - 2016-09-14 14:55:09 --> Final output sent to browser
DEBUG - 2016-09-14 14:55:09 --> Total execution time: 0.7493
INFO - 2016-09-14 14:55:49 --> Config Class Initialized
INFO - 2016-09-14 14:55:49 --> Hooks Class Initialized
DEBUG - 2016-09-14 14:55:49 --> UTF-8 Support Enabled
INFO - 2016-09-14 14:55:49 --> Utf8 Class Initialized
INFO - 2016-09-14 14:55:49 --> URI Class Initialized
INFO - 2016-09-14 14:55:49 --> Router Class Initialized
INFO - 2016-09-14 14:55:49 --> Output Class Initialized
INFO - 2016-09-14 14:55:49 --> Security Class Initialized
DEBUG - 2016-09-14 14:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 14:55:49 --> Input Class Initialized
INFO - 2016-09-14 14:55:49 --> Language Class Initialized
INFO - 2016-09-14 14:55:49 --> Language Class Initialized
INFO - 2016-09-14 14:55:49 --> Config Class Initialized
INFO - 2016-09-14 14:55:49 --> Loader Class Initialized
INFO - 2016-09-14 14:55:49 --> Helper loaded: url_helper
INFO - 2016-09-14 14:55:49 --> Database Driver Class Initialized
INFO - 2016-09-14 14:55:49 --> Controller Class Initialized
DEBUG - 2016-09-14 14:55:50 --> Index MX_Controller Initialized
INFO - 2016-09-14 14:55:50 --> Model Class Initialized
INFO - 2016-09-14 14:55:50 --> Model Class Initialized
DEBUG - 2016-09-14 14:55:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 14:55:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 14:55:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 14:55:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_bayar_angsuran.php
DEBUG - 2016-09-14 14:55:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 14:55:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 14:55:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 14:55:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 14:55:50 --> Final output sent to browser
DEBUG - 2016-09-14 14:55:50 --> Total execution time: 0.9014
INFO - 2016-09-14 14:55:54 --> Config Class Initialized
INFO - 2016-09-14 14:55:54 --> Hooks Class Initialized
DEBUG - 2016-09-14 14:55:54 --> UTF-8 Support Enabled
INFO - 2016-09-14 14:55:54 --> Utf8 Class Initialized
INFO - 2016-09-14 14:55:54 --> URI Class Initialized
INFO - 2016-09-14 14:55:54 --> Router Class Initialized
INFO - 2016-09-14 14:55:54 --> Output Class Initialized
INFO - 2016-09-14 14:55:54 --> Security Class Initialized
DEBUG - 2016-09-14 14:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 14:55:54 --> Input Class Initialized
INFO - 2016-09-14 14:55:54 --> Language Class Initialized
INFO - 2016-09-14 14:55:54 --> Language Class Initialized
INFO - 2016-09-14 14:55:54 --> Config Class Initialized
INFO - 2016-09-14 14:55:54 --> Loader Class Initialized
INFO - 2016-09-14 14:55:54 --> Helper loaded: url_helper
INFO - 2016-09-14 14:55:54 --> Database Driver Class Initialized
INFO - 2016-09-14 14:55:54 --> Controller Class Initialized
DEBUG - 2016-09-14 14:55:54 --> Index MX_Controller Initialized
INFO - 2016-09-14 14:55:54 --> Model Class Initialized
INFO - 2016-09-14 14:55:54 --> Model Class Initialized
INFO - 2016-09-14 14:55:54 --> Database Driver Class Initialized
INFO - 2016-09-14 14:55:54 --> Final output sent to browser
DEBUG - 2016-09-14 14:55:55 --> Total execution time: 0.8163
INFO - 2016-09-14 14:56:05 --> Config Class Initialized
INFO - 2016-09-14 14:56:05 --> Hooks Class Initialized
DEBUG - 2016-09-14 14:56:05 --> UTF-8 Support Enabled
INFO - 2016-09-14 14:56:05 --> Utf8 Class Initialized
INFO - 2016-09-14 14:56:05 --> URI Class Initialized
INFO - 2016-09-14 14:56:05 --> Router Class Initialized
INFO - 2016-09-14 14:56:05 --> Output Class Initialized
INFO - 2016-09-14 14:56:05 --> Security Class Initialized
DEBUG - 2016-09-14 14:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 14:56:06 --> Input Class Initialized
INFO - 2016-09-14 14:56:06 --> Language Class Initialized
INFO - 2016-09-14 14:56:06 --> Language Class Initialized
INFO - 2016-09-14 14:56:06 --> Config Class Initialized
INFO - 2016-09-14 14:56:06 --> Loader Class Initialized
INFO - 2016-09-14 14:56:06 --> Helper loaded: url_helper
INFO - 2016-09-14 14:56:06 --> Database Driver Class Initialized
INFO - 2016-09-14 14:56:06 --> Controller Class Initialized
DEBUG - 2016-09-14 14:56:06 --> Index MX_Controller Initialized
INFO - 2016-09-14 14:56:06 --> Model Class Initialized
INFO - 2016-09-14 14:56:06 --> Model Class Initialized
DEBUG - 2016-09-14 14:56:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 14:56:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 14:56:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 14:56:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_bayar_angsuran.php
DEBUG - 2016-09-14 14:56:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 14:56:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 14:56:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 14:56:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 14:56:06 --> Final output sent to browser
DEBUG - 2016-09-14 14:56:06 --> Total execution time: 0.9001
INFO - 2016-09-14 14:56:12 --> Config Class Initialized
INFO - 2016-09-14 14:56:12 --> Hooks Class Initialized
DEBUG - 2016-09-14 14:56:12 --> UTF-8 Support Enabled
INFO - 2016-09-14 14:56:12 --> Utf8 Class Initialized
INFO - 2016-09-14 14:56:12 --> URI Class Initialized
INFO - 2016-09-14 14:56:12 --> Router Class Initialized
INFO - 2016-09-14 14:56:12 --> Output Class Initialized
INFO - 2016-09-14 14:56:12 --> Security Class Initialized
DEBUG - 2016-09-14 14:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 14:56:12 --> Input Class Initialized
INFO - 2016-09-14 14:56:13 --> Language Class Initialized
INFO - 2016-09-14 14:56:13 --> Language Class Initialized
INFO - 2016-09-14 14:56:13 --> Config Class Initialized
INFO - 2016-09-14 14:56:13 --> Loader Class Initialized
INFO - 2016-09-14 14:56:13 --> Helper loaded: url_helper
INFO - 2016-09-14 14:56:13 --> Database Driver Class Initialized
INFO - 2016-09-14 14:56:13 --> Controller Class Initialized
DEBUG - 2016-09-14 14:56:13 --> Index MX_Controller Initialized
INFO - 2016-09-14 14:56:13 --> Model Class Initialized
INFO - 2016-09-14 14:56:13 --> Model Class Initialized
INFO - 2016-09-14 14:56:13 --> Final output sent to browser
DEBUG - 2016-09-14 14:56:13 --> Total execution time: 0.6731
INFO - 2016-09-14 14:56:22 --> Config Class Initialized
INFO - 2016-09-14 14:56:22 --> Hooks Class Initialized
DEBUG - 2016-09-14 14:56:22 --> UTF-8 Support Enabled
INFO - 2016-09-14 14:56:22 --> Utf8 Class Initialized
INFO - 2016-09-14 14:56:22 --> URI Class Initialized
INFO - 2016-09-14 14:56:22 --> Router Class Initialized
INFO - 2016-09-14 14:56:22 --> Output Class Initialized
INFO - 2016-09-14 14:56:22 --> Security Class Initialized
DEBUG - 2016-09-14 14:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 14:56:22 --> Input Class Initialized
INFO - 2016-09-14 14:56:22 --> Language Class Initialized
INFO - 2016-09-14 14:56:22 --> Language Class Initialized
INFO - 2016-09-14 14:56:22 --> Config Class Initialized
INFO - 2016-09-14 14:56:22 --> Loader Class Initialized
INFO - 2016-09-14 14:56:22 --> Helper loaded: url_helper
INFO - 2016-09-14 14:56:23 --> Database Driver Class Initialized
INFO - 2016-09-14 14:56:23 --> Controller Class Initialized
DEBUG - 2016-09-14 14:56:23 --> Index MX_Controller Initialized
INFO - 2016-09-14 14:56:23 --> Model Class Initialized
INFO - 2016-09-14 14:56:23 --> Model Class Initialized
INFO - 2016-09-14 14:56:23 --> Database Driver Class Initialized
INFO - 2016-09-14 14:56:23 --> Final output sent to browser
DEBUG - 2016-09-14 14:56:23 --> Total execution time: 0.6705
INFO - 2016-09-14 15:16:39 --> Config Class Initialized
INFO - 2016-09-14 15:16:40 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:16:40 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:16:40 --> Utf8 Class Initialized
INFO - 2016-09-14 15:16:40 --> URI Class Initialized
INFO - 2016-09-14 15:16:40 --> Router Class Initialized
INFO - 2016-09-14 15:16:40 --> Output Class Initialized
INFO - 2016-09-14 15:16:40 --> Security Class Initialized
DEBUG - 2016-09-14 15:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:16:40 --> Input Class Initialized
INFO - 2016-09-14 15:16:40 --> Language Class Initialized
INFO - 2016-09-14 15:16:40 --> Language Class Initialized
INFO - 2016-09-14 15:16:40 --> Config Class Initialized
INFO - 2016-09-14 15:16:40 --> Loader Class Initialized
INFO - 2016-09-14 15:16:40 --> Helper loaded: url_helper
INFO - 2016-09-14 15:16:40 --> Database Driver Class Initialized
INFO - 2016-09-14 15:16:40 --> Controller Class Initialized
DEBUG - 2016-09-14 15:16:40 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:16:40 --> Model Class Initialized
INFO - 2016-09-14 15:16:40 --> Model Class Initialized
DEBUG - 2016-09-14 15:16:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 15:16:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 15:16:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 15:16:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_bayar_angsuran.php
DEBUG - 2016-09-14 15:16:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 15:16:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 15:16:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 15:16:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 15:16:40 --> Final output sent to browser
DEBUG - 2016-09-14 15:16:41 --> Total execution time: 1.0494
INFO - 2016-09-14 15:16:59 --> Config Class Initialized
INFO - 2016-09-14 15:16:59 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:16:59 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:16:59 --> Utf8 Class Initialized
INFO - 2016-09-14 15:16:59 --> URI Class Initialized
INFO - 2016-09-14 15:17:00 --> Router Class Initialized
INFO - 2016-09-14 15:17:00 --> Output Class Initialized
INFO - 2016-09-14 15:17:00 --> Security Class Initialized
DEBUG - 2016-09-14 15:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:17:00 --> Input Class Initialized
INFO - 2016-09-14 15:17:00 --> Language Class Initialized
INFO - 2016-09-14 15:17:00 --> Language Class Initialized
INFO - 2016-09-14 15:17:00 --> Config Class Initialized
INFO - 2016-09-14 15:17:00 --> Loader Class Initialized
INFO - 2016-09-14 15:17:00 --> Helper loaded: url_helper
INFO - 2016-09-14 15:17:00 --> Database Driver Class Initialized
INFO - 2016-09-14 15:17:00 --> Controller Class Initialized
DEBUG - 2016-09-14 15:17:00 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:17:00 --> Model Class Initialized
INFO - 2016-09-14 15:17:00 --> Model Class Initialized
DEBUG - 2016-09-14 15:17:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 15:17:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 15:17:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 15:17:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_bayar_angsuran.php
DEBUG - 2016-09-14 15:17:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 15:17:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 15:17:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 15:17:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 15:17:00 --> Final output sent to browser
DEBUG - 2016-09-14 15:17:00 --> Total execution time: 0.9059
INFO - 2016-09-14 15:17:08 --> Config Class Initialized
INFO - 2016-09-14 15:17:08 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:17:08 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:17:08 --> Utf8 Class Initialized
INFO - 2016-09-14 15:17:08 --> URI Class Initialized
INFO - 2016-09-14 15:17:08 --> Router Class Initialized
INFO - 2016-09-14 15:17:08 --> Output Class Initialized
INFO - 2016-09-14 15:17:08 --> Security Class Initialized
DEBUG - 2016-09-14 15:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:17:08 --> Input Class Initialized
INFO - 2016-09-14 15:17:08 --> Language Class Initialized
INFO - 2016-09-14 15:17:08 --> Language Class Initialized
INFO - 2016-09-14 15:17:08 --> Config Class Initialized
INFO - 2016-09-14 15:17:08 --> Loader Class Initialized
INFO - 2016-09-14 15:17:08 --> Helper loaded: url_helper
INFO - 2016-09-14 15:17:08 --> Database Driver Class Initialized
INFO - 2016-09-14 15:17:08 --> Controller Class Initialized
DEBUG - 2016-09-14 15:17:08 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:17:08 --> Model Class Initialized
INFO - 2016-09-14 15:17:08 --> Model Class Initialized
INFO - 2016-09-14 15:17:08 --> Database Driver Class Initialized
INFO - 2016-09-14 15:17:08 --> Final output sent to browser
DEBUG - 2016-09-14 15:17:08 --> Total execution time: 0.6924
INFO - 2016-09-14 15:17:52 --> Config Class Initialized
INFO - 2016-09-14 15:17:52 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:17:52 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:17:52 --> Utf8 Class Initialized
INFO - 2016-09-14 15:17:52 --> URI Class Initialized
INFO - 2016-09-14 15:17:52 --> Router Class Initialized
INFO - 2016-09-14 15:17:52 --> Output Class Initialized
INFO - 2016-09-14 15:17:52 --> Security Class Initialized
DEBUG - 2016-09-14 15:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:17:52 --> Input Class Initialized
INFO - 2016-09-14 15:17:52 --> Language Class Initialized
INFO - 2016-09-14 15:17:52 --> Language Class Initialized
INFO - 2016-09-14 15:17:52 --> Config Class Initialized
INFO - 2016-09-14 15:17:52 --> Loader Class Initialized
INFO - 2016-09-14 15:17:52 --> Helper loaded: url_helper
INFO - 2016-09-14 15:17:52 --> Database Driver Class Initialized
INFO - 2016-09-14 15:17:52 --> Controller Class Initialized
DEBUG - 2016-09-14 15:17:52 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:17:53 --> Model Class Initialized
INFO - 2016-09-14 15:17:53 --> Model Class Initialized
INFO - 2016-09-14 15:17:53 --> Database Driver Class Initialized
INFO - 2016-09-14 15:17:53 --> Final output sent to browser
DEBUG - 2016-09-14 15:17:53 --> Total execution time: 0.7473
INFO - 2016-09-14 15:17:54 --> Config Class Initialized
INFO - 2016-09-14 15:17:54 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:17:54 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:17:54 --> Utf8 Class Initialized
INFO - 2016-09-14 15:17:54 --> URI Class Initialized
INFO - 2016-09-14 15:17:54 --> Router Class Initialized
INFO - 2016-09-14 15:17:54 --> Output Class Initialized
INFO - 2016-09-14 15:17:54 --> Security Class Initialized
DEBUG - 2016-09-14 15:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:17:54 --> Input Class Initialized
INFO - 2016-09-14 15:17:54 --> Language Class Initialized
INFO - 2016-09-14 15:17:54 --> Language Class Initialized
INFO - 2016-09-14 15:17:54 --> Config Class Initialized
INFO - 2016-09-14 15:17:54 --> Loader Class Initialized
INFO - 2016-09-14 15:17:54 --> Helper loaded: url_helper
INFO - 2016-09-14 15:17:54 --> Database Driver Class Initialized
INFO - 2016-09-14 15:17:54 --> Controller Class Initialized
DEBUG - 2016-09-14 15:17:54 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:17:55 --> Model Class Initialized
INFO - 2016-09-14 15:17:55 --> Model Class Initialized
DEBUG - 2016-09-14 15:17:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 15:17:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 15:17:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 15:17:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_bayar_angsuran.php
DEBUG - 2016-09-14 15:17:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 15:17:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 15:17:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 15:17:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 15:17:55 --> Final output sent to browser
DEBUG - 2016-09-14 15:17:55 --> Total execution time: 0.9480
INFO - 2016-09-14 15:17:58 --> Config Class Initialized
INFO - 2016-09-14 15:17:58 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:17:58 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:17:58 --> Utf8 Class Initialized
INFO - 2016-09-14 15:17:58 --> URI Class Initialized
INFO - 2016-09-14 15:17:58 --> Router Class Initialized
INFO - 2016-09-14 15:17:58 --> Output Class Initialized
INFO - 2016-09-14 15:17:58 --> Security Class Initialized
DEBUG - 2016-09-14 15:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:17:58 --> Input Class Initialized
INFO - 2016-09-14 15:17:58 --> Language Class Initialized
INFO - 2016-09-14 15:17:58 --> Language Class Initialized
INFO - 2016-09-14 15:17:58 --> Config Class Initialized
INFO - 2016-09-14 15:17:58 --> Loader Class Initialized
INFO - 2016-09-14 15:17:58 --> Helper loaded: url_helper
INFO - 2016-09-14 15:17:58 --> Database Driver Class Initialized
INFO - 2016-09-14 15:17:58 --> Controller Class Initialized
DEBUG - 2016-09-14 15:17:58 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:17:59 --> Model Class Initialized
INFO - 2016-09-14 15:17:59 --> Model Class Initialized
INFO - 2016-09-14 15:17:59 --> Database Driver Class Initialized
INFO - 2016-09-14 15:17:59 --> Final output sent to browser
DEBUG - 2016-09-14 15:17:59 --> Total execution time: 0.7142
INFO - 2016-09-14 15:23:56 --> Config Class Initialized
INFO - 2016-09-14 15:23:56 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:23:56 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:23:56 --> Utf8 Class Initialized
INFO - 2016-09-14 15:23:56 --> URI Class Initialized
INFO - 2016-09-14 15:23:56 --> Router Class Initialized
INFO - 2016-09-14 15:23:57 --> Output Class Initialized
INFO - 2016-09-14 15:23:57 --> Security Class Initialized
DEBUG - 2016-09-14 15:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:23:57 --> Input Class Initialized
INFO - 2016-09-14 15:23:57 --> Language Class Initialized
INFO - 2016-09-14 15:23:57 --> Language Class Initialized
INFO - 2016-09-14 15:23:57 --> Config Class Initialized
INFO - 2016-09-14 15:23:57 --> Loader Class Initialized
INFO - 2016-09-14 15:23:57 --> Helper loaded: url_helper
INFO - 2016-09-14 15:23:57 --> Database Driver Class Initialized
INFO - 2016-09-14 15:23:57 --> Controller Class Initialized
DEBUG - 2016-09-14 15:23:57 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:23:57 --> Model Class Initialized
INFO - 2016-09-14 15:23:57 --> Model Class Initialized
DEBUG - 2016-09-14 15:23:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 15:23:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 15:23:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 15:23:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_bayar_angsuran.php
DEBUG - 2016-09-14 15:23:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 15:23:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 15:23:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 15:23:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 15:23:57 --> Final output sent to browser
DEBUG - 2016-09-14 15:23:57 --> Total execution time: 1.0064
INFO - 2016-09-14 15:24:01 --> Config Class Initialized
INFO - 2016-09-14 15:24:01 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:24:01 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:24:01 --> Utf8 Class Initialized
INFO - 2016-09-14 15:24:01 --> URI Class Initialized
INFO - 2016-09-14 15:24:01 --> Router Class Initialized
INFO - 2016-09-14 15:24:01 --> Output Class Initialized
INFO - 2016-09-14 15:24:01 --> Security Class Initialized
DEBUG - 2016-09-14 15:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:24:01 --> Input Class Initialized
INFO - 2016-09-14 15:24:01 --> Language Class Initialized
INFO - 2016-09-14 15:24:01 --> Language Class Initialized
INFO - 2016-09-14 15:24:02 --> Config Class Initialized
INFO - 2016-09-14 15:24:02 --> Loader Class Initialized
INFO - 2016-09-14 15:24:02 --> Helper loaded: url_helper
INFO - 2016-09-14 15:24:02 --> Database Driver Class Initialized
INFO - 2016-09-14 15:24:02 --> Controller Class Initialized
DEBUG - 2016-09-14 15:24:02 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:24:02 --> Model Class Initialized
INFO - 2016-09-14 15:24:02 --> Model Class Initialized
INFO - 2016-09-14 15:24:02 --> Database Driver Class Initialized
INFO - 2016-09-14 15:24:02 --> Final output sent to browser
DEBUG - 2016-09-14 15:24:02 --> Total execution time: 0.7151
INFO - 2016-09-14 15:24:15 --> Config Class Initialized
INFO - 2016-09-14 15:24:15 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:24:15 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:24:15 --> Utf8 Class Initialized
INFO - 2016-09-14 15:24:15 --> URI Class Initialized
INFO - 2016-09-14 15:24:15 --> Router Class Initialized
INFO - 2016-09-14 15:24:15 --> Output Class Initialized
INFO - 2016-09-14 15:24:15 --> Security Class Initialized
DEBUG - 2016-09-14 15:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:24:16 --> Input Class Initialized
INFO - 2016-09-14 15:24:16 --> Language Class Initialized
INFO - 2016-09-14 15:24:16 --> Language Class Initialized
INFO - 2016-09-14 15:24:16 --> Config Class Initialized
INFO - 2016-09-14 15:24:16 --> Loader Class Initialized
INFO - 2016-09-14 15:24:16 --> Helper loaded: url_helper
INFO - 2016-09-14 15:24:16 --> Database Driver Class Initialized
INFO - 2016-09-14 15:24:16 --> Controller Class Initialized
DEBUG - 2016-09-14 15:24:16 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:24:16 --> Model Class Initialized
INFO - 2016-09-14 15:24:16 --> Model Class Initialized
DEBUG - 2016-09-14 15:24:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 15:24:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 15:24:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 15:24:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_bayar_angsuran.php
DEBUG - 2016-09-14 15:24:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 15:24:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 15:24:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 15:24:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 15:24:16 --> Final output sent to browser
DEBUG - 2016-09-14 15:24:16 --> Total execution time: 0.9280
INFO - 2016-09-14 15:24:21 --> Config Class Initialized
INFO - 2016-09-14 15:24:21 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:24:21 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:24:21 --> Utf8 Class Initialized
INFO - 2016-09-14 15:24:21 --> URI Class Initialized
INFO - 2016-09-14 15:24:21 --> Router Class Initialized
INFO - 2016-09-14 15:24:21 --> Output Class Initialized
INFO - 2016-09-14 15:24:21 --> Security Class Initialized
DEBUG - 2016-09-14 15:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:24:21 --> Input Class Initialized
INFO - 2016-09-14 15:24:21 --> Language Class Initialized
INFO - 2016-09-14 15:24:21 --> Language Class Initialized
INFO - 2016-09-14 15:24:21 --> Config Class Initialized
INFO - 2016-09-14 15:24:21 --> Loader Class Initialized
INFO - 2016-09-14 15:24:21 --> Helper loaded: url_helper
INFO - 2016-09-14 15:24:21 --> Database Driver Class Initialized
INFO - 2016-09-14 15:24:21 --> Controller Class Initialized
DEBUG - 2016-09-14 15:24:21 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:24:21 --> Model Class Initialized
INFO - 2016-09-14 15:24:21 --> Model Class Initialized
INFO - 2016-09-14 15:24:21 --> Database Driver Class Initialized
INFO - 2016-09-14 15:24:21 --> Final output sent to browser
DEBUG - 2016-09-14 15:24:22 --> Total execution time: 0.8134
INFO - 2016-09-14 15:24:32 --> Config Class Initialized
INFO - 2016-09-14 15:24:32 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:24:33 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:24:33 --> Utf8 Class Initialized
INFO - 2016-09-14 15:24:33 --> URI Class Initialized
INFO - 2016-09-14 15:24:33 --> Router Class Initialized
INFO - 2016-09-14 15:24:33 --> Output Class Initialized
INFO - 2016-09-14 15:24:33 --> Security Class Initialized
DEBUG - 2016-09-14 15:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:24:33 --> Input Class Initialized
INFO - 2016-09-14 15:24:33 --> Language Class Initialized
INFO - 2016-09-14 15:24:33 --> Language Class Initialized
INFO - 2016-09-14 15:24:33 --> Config Class Initialized
INFO - 2016-09-14 15:24:33 --> Loader Class Initialized
INFO - 2016-09-14 15:24:33 --> Helper loaded: url_helper
INFO - 2016-09-14 15:24:33 --> Database Driver Class Initialized
INFO - 2016-09-14 15:24:33 --> Controller Class Initialized
DEBUG - 2016-09-14 15:24:33 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:24:33 --> Model Class Initialized
INFO - 2016-09-14 15:24:33 --> Model Class Initialized
ERROR - 2016-09-14 15:24:33 --> Severity: Notice --> Undefined index: total_angsuran E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 256
INFO - 2016-09-14 15:24:33 --> Database Driver Class Initialized
INFO - 2016-09-14 15:24:33 --> Final output sent to browser
DEBUG - 2016-09-14 15:24:33 --> Total execution time: 0.8965
INFO - 2016-09-14 15:24:55 --> Config Class Initialized
INFO - 2016-09-14 15:24:55 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:24:55 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:24:55 --> Utf8 Class Initialized
INFO - 2016-09-14 15:24:55 --> URI Class Initialized
INFO - 2016-09-14 15:24:55 --> Router Class Initialized
INFO - 2016-09-14 15:24:55 --> Output Class Initialized
INFO - 2016-09-14 15:24:55 --> Security Class Initialized
DEBUG - 2016-09-14 15:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:24:55 --> Input Class Initialized
INFO - 2016-09-14 15:24:55 --> Language Class Initialized
INFO - 2016-09-14 15:24:56 --> Language Class Initialized
INFO - 2016-09-14 15:24:56 --> Config Class Initialized
INFO - 2016-09-14 15:24:56 --> Loader Class Initialized
INFO - 2016-09-14 15:24:56 --> Helper loaded: url_helper
INFO - 2016-09-14 15:24:56 --> Database Driver Class Initialized
INFO - 2016-09-14 15:24:56 --> Controller Class Initialized
DEBUG - 2016-09-14 15:24:56 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:24:56 --> Model Class Initialized
INFO - 2016-09-14 15:24:56 --> Model Class Initialized
ERROR - 2016-09-14 15:24:56 --> Severity: Notice --> Undefined index: total_angsuran E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 256
INFO - 2016-09-14 15:24:56 --> Database Driver Class Initialized
INFO - 2016-09-14 15:24:56 --> Final output sent to browser
DEBUG - 2016-09-14 15:24:56 --> Total execution time: 1.0209
INFO - 2016-09-14 15:26:22 --> Config Class Initialized
INFO - 2016-09-14 15:26:22 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:26:22 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:26:22 --> Utf8 Class Initialized
INFO - 2016-09-14 15:26:22 --> URI Class Initialized
INFO - 2016-09-14 15:26:22 --> Router Class Initialized
INFO - 2016-09-14 15:26:22 --> Output Class Initialized
INFO - 2016-09-14 15:26:22 --> Security Class Initialized
DEBUG - 2016-09-14 15:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:26:22 --> Input Class Initialized
INFO - 2016-09-14 15:26:22 --> Language Class Initialized
INFO - 2016-09-14 15:26:22 --> Language Class Initialized
INFO - 2016-09-14 15:26:22 --> Config Class Initialized
INFO - 2016-09-14 15:26:22 --> Loader Class Initialized
INFO - 2016-09-14 15:26:22 --> Helper loaded: url_helper
INFO - 2016-09-14 15:26:22 --> Database Driver Class Initialized
INFO - 2016-09-14 15:26:22 --> Controller Class Initialized
DEBUG - 2016-09-14 15:26:22 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:26:22 --> Model Class Initialized
INFO - 2016-09-14 15:26:22 --> Model Class Initialized
DEBUG - 2016-09-14 15:26:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 15:26:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 15:26:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 15:26:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_bayar_angsuran.php
DEBUG - 2016-09-14 15:26:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 15:26:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 15:26:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 15:26:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 15:26:22 --> Final output sent to browser
DEBUG - 2016-09-14 15:26:23 --> Total execution time: 0.9808
INFO - 2016-09-14 15:26:29 --> Config Class Initialized
INFO - 2016-09-14 15:26:29 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:26:29 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:26:30 --> Utf8 Class Initialized
INFO - 2016-09-14 15:26:30 --> URI Class Initialized
INFO - 2016-09-14 15:26:30 --> Router Class Initialized
INFO - 2016-09-14 15:26:30 --> Output Class Initialized
INFO - 2016-09-14 15:26:30 --> Security Class Initialized
DEBUG - 2016-09-14 15:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:26:30 --> Input Class Initialized
INFO - 2016-09-14 15:26:30 --> Language Class Initialized
INFO - 2016-09-14 15:26:30 --> Language Class Initialized
INFO - 2016-09-14 15:26:30 --> Config Class Initialized
INFO - 2016-09-14 15:26:30 --> Loader Class Initialized
INFO - 2016-09-14 15:26:30 --> Helper loaded: url_helper
INFO - 2016-09-14 15:26:30 --> Database Driver Class Initialized
INFO - 2016-09-14 15:26:30 --> Controller Class Initialized
DEBUG - 2016-09-14 15:26:30 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:26:30 --> Model Class Initialized
INFO - 2016-09-14 15:26:30 --> Model Class Initialized
INFO - 2016-09-14 15:26:30 --> Database Driver Class Initialized
INFO - 2016-09-14 15:26:30 --> Final output sent to browser
DEBUG - 2016-09-14 15:26:30 --> Total execution time: 0.8288
INFO - 2016-09-14 15:26:40 --> Config Class Initialized
INFO - 2016-09-14 15:26:40 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:26:40 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:26:40 --> Utf8 Class Initialized
INFO - 2016-09-14 15:26:40 --> URI Class Initialized
INFO - 2016-09-14 15:26:40 --> Router Class Initialized
INFO - 2016-09-14 15:26:40 --> Output Class Initialized
INFO - 2016-09-14 15:26:40 --> Security Class Initialized
DEBUG - 2016-09-14 15:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:26:40 --> Input Class Initialized
INFO - 2016-09-14 15:26:40 --> Language Class Initialized
INFO - 2016-09-14 15:26:40 --> Language Class Initialized
INFO - 2016-09-14 15:26:40 --> Config Class Initialized
INFO - 2016-09-14 15:26:40 --> Loader Class Initialized
INFO - 2016-09-14 15:26:40 --> Helper loaded: url_helper
INFO - 2016-09-14 15:26:40 --> Database Driver Class Initialized
INFO - 2016-09-14 15:26:40 --> Controller Class Initialized
DEBUG - 2016-09-14 15:26:40 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:26:40 --> Model Class Initialized
INFO - 2016-09-14 15:26:40 --> Model Class Initialized
ERROR - 2016-09-14 15:26:40 --> Severity: Notice --> Undefined index: total_angsuran E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 256
INFO - 2016-09-14 15:26:40 --> Database Driver Class Initialized
INFO - 2016-09-14 15:26:40 --> Final output sent to browser
DEBUG - 2016-09-14 15:26:41 --> Total execution time: 0.8850
INFO - 2016-09-14 15:27:51 --> Config Class Initialized
INFO - 2016-09-14 15:27:51 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:27:51 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:27:51 --> Utf8 Class Initialized
INFO - 2016-09-14 15:27:51 --> URI Class Initialized
INFO - 2016-09-14 15:27:51 --> Router Class Initialized
INFO - 2016-09-14 15:27:51 --> Output Class Initialized
INFO - 2016-09-14 15:27:51 --> Security Class Initialized
DEBUG - 2016-09-14 15:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:27:51 --> Input Class Initialized
INFO - 2016-09-14 15:27:51 --> Language Class Initialized
INFO - 2016-09-14 15:27:51 --> Language Class Initialized
INFO - 2016-09-14 15:27:51 --> Config Class Initialized
INFO - 2016-09-14 15:27:51 --> Loader Class Initialized
INFO - 2016-09-14 15:27:51 --> Helper loaded: url_helper
INFO - 2016-09-14 15:27:51 --> Database Driver Class Initialized
INFO - 2016-09-14 15:27:51 --> Controller Class Initialized
DEBUG - 2016-09-14 15:27:51 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:27:51 --> Model Class Initialized
INFO - 2016-09-14 15:27:51 --> Model Class Initialized
DEBUG - 2016-09-14 15:27:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 15:27:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 15:27:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 15:27:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_bayar_angsuran.php
DEBUG - 2016-09-14 15:27:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 15:27:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 15:27:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 15:27:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 15:27:52 --> Final output sent to browser
DEBUG - 2016-09-14 15:27:52 --> Total execution time: 1.0915
INFO - 2016-09-14 15:28:00 --> Config Class Initialized
INFO - 2016-09-14 15:28:00 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:28:00 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:28:00 --> Utf8 Class Initialized
INFO - 2016-09-14 15:28:00 --> URI Class Initialized
INFO - 2016-09-14 15:28:00 --> Router Class Initialized
INFO - 2016-09-14 15:28:00 --> Output Class Initialized
INFO - 2016-09-14 15:28:00 --> Security Class Initialized
DEBUG - 2016-09-14 15:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:28:00 --> Input Class Initialized
INFO - 2016-09-14 15:28:00 --> Language Class Initialized
INFO - 2016-09-14 15:28:00 --> Language Class Initialized
INFO - 2016-09-14 15:28:00 --> Config Class Initialized
INFO - 2016-09-14 15:28:00 --> Loader Class Initialized
INFO - 2016-09-14 15:28:00 --> Helper loaded: url_helper
INFO - 2016-09-14 15:28:00 --> Database Driver Class Initialized
INFO - 2016-09-14 15:28:00 --> Controller Class Initialized
DEBUG - 2016-09-14 15:28:01 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:28:01 --> Model Class Initialized
INFO - 2016-09-14 15:28:01 --> Model Class Initialized
INFO - 2016-09-14 15:28:01 --> Database Driver Class Initialized
INFO - 2016-09-14 15:28:01 --> Final output sent to browser
DEBUG - 2016-09-14 15:28:01 --> Total execution time: 0.8354
INFO - 2016-09-14 15:28:14 --> Config Class Initialized
INFO - 2016-09-14 15:28:14 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:28:14 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:28:14 --> Utf8 Class Initialized
INFO - 2016-09-14 15:28:14 --> URI Class Initialized
INFO - 2016-09-14 15:28:14 --> Router Class Initialized
INFO - 2016-09-14 15:28:14 --> Output Class Initialized
INFO - 2016-09-14 15:28:15 --> Security Class Initialized
DEBUG - 2016-09-14 15:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:28:15 --> Input Class Initialized
INFO - 2016-09-14 15:28:15 --> Language Class Initialized
INFO - 2016-09-14 15:28:15 --> Language Class Initialized
INFO - 2016-09-14 15:28:15 --> Config Class Initialized
INFO - 2016-09-14 15:28:15 --> Loader Class Initialized
INFO - 2016-09-14 15:28:15 --> Helper loaded: url_helper
INFO - 2016-09-14 15:28:15 --> Database Driver Class Initialized
INFO - 2016-09-14 15:28:15 --> Controller Class Initialized
DEBUG - 2016-09-14 15:28:15 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:28:15 --> Model Class Initialized
INFO - 2016-09-14 15:28:15 --> Model Class Initialized
INFO - 2016-09-14 15:28:15 --> Database Driver Class Initialized
INFO - 2016-09-14 15:28:15 --> Final output sent to browser
DEBUG - 2016-09-14 15:28:15 --> Total execution time: 0.8292
INFO - 2016-09-14 15:28:37 --> Config Class Initialized
INFO - 2016-09-14 15:28:37 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:28:37 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:28:37 --> Utf8 Class Initialized
INFO - 2016-09-14 15:28:37 --> URI Class Initialized
INFO - 2016-09-14 15:28:37 --> Router Class Initialized
INFO - 2016-09-14 15:28:37 --> Output Class Initialized
INFO - 2016-09-14 15:28:37 --> Security Class Initialized
DEBUG - 2016-09-14 15:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:28:37 --> Input Class Initialized
INFO - 2016-09-14 15:28:37 --> Language Class Initialized
INFO - 2016-09-14 15:28:37 --> Language Class Initialized
INFO - 2016-09-14 15:28:37 --> Config Class Initialized
INFO - 2016-09-14 15:28:37 --> Loader Class Initialized
INFO - 2016-09-14 15:28:37 --> Helper loaded: url_helper
INFO - 2016-09-14 15:28:37 --> Database Driver Class Initialized
INFO - 2016-09-14 15:28:37 --> Controller Class Initialized
DEBUG - 2016-09-14 15:28:37 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:28:37 --> Model Class Initialized
INFO - 2016-09-14 15:28:37 --> Model Class Initialized
INFO - 2016-09-14 15:28:37 --> Database Driver Class Initialized
INFO - 2016-09-14 15:28:37 --> Final output sent to browser
DEBUG - 2016-09-14 15:28:37 --> Total execution time: 0.7908
INFO - 2016-09-14 15:28:43 --> Config Class Initialized
INFO - 2016-09-14 15:28:43 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:28:43 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:28:43 --> Utf8 Class Initialized
INFO - 2016-09-14 15:28:43 --> URI Class Initialized
INFO - 2016-09-14 15:28:43 --> Router Class Initialized
INFO - 2016-09-14 15:28:43 --> Output Class Initialized
INFO - 2016-09-14 15:28:43 --> Security Class Initialized
DEBUG - 2016-09-14 15:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:28:43 --> Input Class Initialized
INFO - 2016-09-14 15:28:43 --> Language Class Initialized
INFO - 2016-09-14 15:28:43 --> Language Class Initialized
INFO - 2016-09-14 15:28:43 --> Config Class Initialized
INFO - 2016-09-14 15:28:43 --> Loader Class Initialized
INFO - 2016-09-14 15:28:43 --> Helper loaded: url_helper
INFO - 2016-09-14 15:28:43 --> Database Driver Class Initialized
INFO - 2016-09-14 15:28:43 --> Controller Class Initialized
DEBUG - 2016-09-14 15:28:43 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:28:43 --> Model Class Initialized
INFO - 2016-09-14 15:28:43 --> Model Class Initialized
INFO - 2016-09-14 15:28:43 --> Database Driver Class Initialized
INFO - 2016-09-14 15:28:44 --> Final output sent to browser
DEBUG - 2016-09-14 15:28:44 --> Total execution time: 0.8584
INFO - 2016-09-14 15:31:30 --> Config Class Initialized
INFO - 2016-09-14 15:31:30 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:31:30 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:31:30 --> Utf8 Class Initialized
INFO - 2016-09-14 15:31:30 --> URI Class Initialized
INFO - 2016-09-14 15:31:30 --> Router Class Initialized
INFO - 2016-09-14 15:31:30 --> Output Class Initialized
INFO - 2016-09-14 15:31:30 --> Security Class Initialized
DEBUG - 2016-09-14 15:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:31:30 --> Input Class Initialized
INFO - 2016-09-14 15:31:30 --> Language Class Initialized
INFO - 2016-09-14 15:31:30 --> Language Class Initialized
INFO - 2016-09-14 15:31:30 --> Config Class Initialized
INFO - 2016-09-14 15:31:30 --> Loader Class Initialized
INFO - 2016-09-14 15:31:30 --> Helper loaded: url_helper
INFO - 2016-09-14 15:31:30 --> Database Driver Class Initialized
INFO - 2016-09-14 15:31:30 --> Controller Class Initialized
DEBUG - 2016-09-14 15:31:30 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:31:30 --> Model Class Initialized
INFO - 2016-09-14 15:31:30 --> Model Class Initialized
DEBUG - 2016-09-14 15:31:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 15:31:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 15:31:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 15:31:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_bayar_angsuran.php
DEBUG - 2016-09-14 15:31:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 15:31:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 15:31:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 15:31:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 15:31:30 --> Final output sent to browser
DEBUG - 2016-09-14 15:31:31 --> Total execution time: 0.9370
INFO - 2016-09-14 15:31:37 --> Config Class Initialized
INFO - 2016-09-14 15:31:37 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:31:37 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:31:37 --> Utf8 Class Initialized
INFO - 2016-09-14 15:31:37 --> URI Class Initialized
INFO - 2016-09-14 15:31:37 --> Router Class Initialized
INFO - 2016-09-14 15:31:37 --> Output Class Initialized
INFO - 2016-09-14 15:31:37 --> Security Class Initialized
DEBUG - 2016-09-14 15:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:31:37 --> Input Class Initialized
INFO - 2016-09-14 15:31:37 --> Language Class Initialized
INFO - 2016-09-14 15:31:37 --> Language Class Initialized
INFO - 2016-09-14 15:31:37 --> Config Class Initialized
INFO - 2016-09-14 15:31:37 --> Loader Class Initialized
INFO - 2016-09-14 15:31:37 --> Helper loaded: url_helper
INFO - 2016-09-14 15:31:37 --> Database Driver Class Initialized
INFO - 2016-09-14 15:31:37 --> Controller Class Initialized
DEBUG - 2016-09-14 15:31:37 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:31:37 --> Model Class Initialized
INFO - 2016-09-14 15:31:37 --> Model Class Initialized
INFO - 2016-09-14 15:31:37 --> Database Driver Class Initialized
INFO - 2016-09-14 15:31:38 --> Final output sent to browser
DEBUG - 2016-09-14 15:31:38 --> Total execution time: 0.7081
INFO - 2016-09-14 15:31:41 --> Config Class Initialized
INFO - 2016-09-14 15:31:41 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:31:41 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:31:41 --> Utf8 Class Initialized
INFO - 2016-09-14 15:31:41 --> URI Class Initialized
INFO - 2016-09-14 15:31:41 --> Router Class Initialized
INFO - 2016-09-14 15:31:41 --> Output Class Initialized
INFO - 2016-09-14 15:31:41 --> Security Class Initialized
DEBUG - 2016-09-14 15:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:31:41 --> Input Class Initialized
INFO - 2016-09-14 15:31:41 --> Language Class Initialized
INFO - 2016-09-14 15:31:41 --> Language Class Initialized
INFO - 2016-09-14 15:31:41 --> Config Class Initialized
INFO - 2016-09-14 15:31:41 --> Loader Class Initialized
INFO - 2016-09-14 15:31:41 --> Helper loaded: url_helper
INFO - 2016-09-14 15:31:41 --> Database Driver Class Initialized
INFO - 2016-09-14 15:31:41 --> Controller Class Initialized
DEBUG - 2016-09-14 15:31:41 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:31:42 --> Model Class Initialized
INFO - 2016-09-14 15:31:42 --> Model Class Initialized
INFO - 2016-09-14 15:31:42 --> Database Driver Class Initialized
INFO - 2016-09-14 15:31:42 --> Final output sent to browser
DEBUG - 2016-09-14 15:31:42 --> Total execution time: 0.8538
INFO - 2016-09-14 15:31:44 --> Config Class Initialized
INFO - 2016-09-14 15:31:44 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:31:44 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:31:44 --> Utf8 Class Initialized
INFO - 2016-09-14 15:31:44 --> URI Class Initialized
INFO - 2016-09-14 15:31:44 --> Router Class Initialized
INFO - 2016-09-14 15:31:44 --> Output Class Initialized
INFO - 2016-09-14 15:31:44 --> Security Class Initialized
DEBUG - 2016-09-14 15:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:31:44 --> Input Class Initialized
INFO - 2016-09-14 15:31:44 --> Language Class Initialized
INFO - 2016-09-14 15:31:44 --> Language Class Initialized
INFO - 2016-09-14 15:31:44 --> Config Class Initialized
INFO - 2016-09-14 15:31:44 --> Loader Class Initialized
INFO - 2016-09-14 15:31:44 --> Helper loaded: url_helper
INFO - 2016-09-14 15:31:44 --> Database Driver Class Initialized
INFO - 2016-09-14 15:31:45 --> Controller Class Initialized
DEBUG - 2016-09-14 15:31:45 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:31:45 --> Model Class Initialized
INFO - 2016-09-14 15:31:45 --> Model Class Initialized
INFO - 2016-09-14 15:31:45 --> Database Driver Class Initialized
INFO - 2016-09-14 15:31:45 --> Final output sent to browser
DEBUG - 2016-09-14 15:31:45 --> Total execution time: 0.7224
INFO - 2016-09-14 15:31:47 --> Config Class Initialized
INFO - 2016-09-14 15:31:47 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:31:47 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:31:47 --> Utf8 Class Initialized
INFO - 2016-09-14 15:31:47 --> URI Class Initialized
INFO - 2016-09-14 15:31:47 --> Router Class Initialized
INFO - 2016-09-14 15:31:47 --> Output Class Initialized
INFO - 2016-09-14 15:31:47 --> Security Class Initialized
DEBUG - 2016-09-14 15:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:31:47 --> Input Class Initialized
INFO - 2016-09-14 15:31:47 --> Language Class Initialized
INFO - 2016-09-14 15:31:47 --> Language Class Initialized
INFO - 2016-09-14 15:31:47 --> Config Class Initialized
INFO - 2016-09-14 15:31:47 --> Loader Class Initialized
INFO - 2016-09-14 15:31:47 --> Helper loaded: url_helper
INFO - 2016-09-14 15:31:47 --> Database Driver Class Initialized
INFO - 2016-09-14 15:31:47 --> Controller Class Initialized
DEBUG - 2016-09-14 15:31:47 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:31:47 --> Model Class Initialized
INFO - 2016-09-14 15:31:47 --> Model Class Initialized
INFO - 2016-09-14 15:31:47 --> Database Driver Class Initialized
INFO - 2016-09-14 15:31:47 --> Final output sent to browser
DEBUG - 2016-09-14 15:31:48 --> Total execution time: 0.9139
INFO - 2016-09-14 15:31:49 --> Config Class Initialized
INFO - 2016-09-14 15:31:49 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:31:49 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:31:49 --> Config Class Initialized
INFO - 2016-09-14 15:31:49 --> Hooks Class Initialized
INFO - 2016-09-14 15:31:49 --> Utf8 Class Initialized
INFO - 2016-09-14 15:31:50 --> URI Class Initialized
DEBUG - 2016-09-14 15:31:50 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:31:50 --> Utf8 Class Initialized
INFO - 2016-09-14 15:31:50 --> Router Class Initialized
INFO - 2016-09-14 15:31:50 --> URI Class Initialized
INFO - 2016-09-14 15:31:50 --> Output Class Initialized
INFO - 2016-09-14 15:31:50 --> Security Class Initialized
INFO - 2016-09-14 15:31:50 --> Router Class Initialized
DEBUG - 2016-09-14 15:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:31:50 --> Output Class Initialized
INFO - 2016-09-14 15:31:50 --> Input Class Initialized
INFO - 2016-09-14 15:31:50 --> Security Class Initialized
INFO - 2016-09-14 15:31:50 --> Language Class Initialized
DEBUG - 2016-09-14 15:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:31:50 --> Input Class Initialized
INFO - 2016-09-14 15:31:50 --> Language Class Initialized
INFO - 2016-09-14 15:31:50 --> Config Class Initialized
INFO - 2016-09-14 15:31:50 --> Language Class Initialized
INFO - 2016-09-14 15:31:50 --> Language Class Initialized
INFO - 2016-09-14 15:31:50 --> Loader Class Initialized
INFO - 2016-09-14 15:31:50 --> Config Class Initialized
INFO - 2016-09-14 15:31:50 --> Helper loaded: url_helper
INFO - 2016-09-14 15:31:50 --> Loader Class Initialized
INFO - 2016-09-14 15:31:50 --> Database Driver Class Initialized
INFO - 2016-09-14 15:31:50 --> Helper loaded: url_helper
INFO - 2016-09-14 15:31:50 --> Controller Class Initialized
DEBUG - 2016-09-14 15:31:50 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:31:50 --> Database Driver Class Initialized
INFO - 2016-09-14 15:31:50 --> Model Class Initialized
INFO - 2016-09-14 15:31:50 --> Controller Class Initialized
DEBUG - 2016-09-14 15:31:50 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:31:50 --> Model Class Initialized
INFO - 2016-09-14 15:31:50 --> Model Class Initialized
INFO - 2016-09-14 15:31:50 --> Database Driver Class Initialized
INFO - 2016-09-14 15:31:50 --> Model Class Initialized
INFO - 2016-09-14 15:31:50 --> Final output sent to browser
DEBUG - 2016-09-14 15:31:50 --> Total execution time: 0.8371
INFO - 2016-09-14 15:31:50 --> Database Driver Class Initialized
INFO - 2016-09-14 15:31:50 --> Final output sent to browser
DEBUG - 2016-09-14 15:31:50 --> Total execution time: 0.8077
INFO - 2016-09-14 15:31:52 --> Config Class Initialized
INFO - 2016-09-14 15:31:52 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:31:52 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:31:52 --> Utf8 Class Initialized
INFO - 2016-09-14 15:31:52 --> URI Class Initialized
INFO - 2016-09-14 15:31:52 --> Router Class Initialized
INFO - 2016-09-14 15:31:52 --> Output Class Initialized
INFO - 2016-09-14 15:31:52 --> Security Class Initialized
DEBUG - 2016-09-14 15:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:31:52 --> Input Class Initialized
INFO - 2016-09-14 15:31:52 --> Language Class Initialized
INFO - 2016-09-14 15:31:52 --> Language Class Initialized
INFO - 2016-09-14 15:31:52 --> Config Class Initialized
INFO - 2016-09-14 15:31:52 --> Loader Class Initialized
INFO - 2016-09-14 15:31:52 --> Helper loaded: url_helper
INFO - 2016-09-14 15:31:52 --> Database Driver Class Initialized
INFO - 2016-09-14 15:31:52 --> Controller Class Initialized
DEBUG - 2016-09-14 15:31:52 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:31:52 --> Model Class Initialized
INFO - 2016-09-14 15:31:53 --> Model Class Initialized
INFO - 2016-09-14 15:31:53 --> Database Driver Class Initialized
INFO - 2016-09-14 15:31:53 --> Final output sent to browser
DEBUG - 2016-09-14 15:31:53 --> Total execution time: 1.0001
INFO - 2016-09-14 15:31:55 --> Config Class Initialized
INFO - 2016-09-14 15:31:55 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:31:55 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:31:55 --> Utf8 Class Initialized
INFO - 2016-09-14 15:31:55 --> URI Class Initialized
INFO - 2016-09-14 15:31:55 --> Router Class Initialized
INFO - 2016-09-14 15:31:55 --> Output Class Initialized
INFO - 2016-09-14 15:31:55 --> Security Class Initialized
DEBUG - 2016-09-14 15:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:31:55 --> Input Class Initialized
INFO - 2016-09-14 15:31:55 --> Language Class Initialized
INFO - 2016-09-14 15:31:55 --> Language Class Initialized
INFO - 2016-09-14 15:31:55 --> Config Class Initialized
INFO - 2016-09-14 15:31:55 --> Loader Class Initialized
INFO - 2016-09-14 15:31:55 --> Helper loaded: url_helper
INFO - 2016-09-14 15:31:55 --> Database Driver Class Initialized
INFO - 2016-09-14 15:31:56 --> Controller Class Initialized
DEBUG - 2016-09-14 15:31:56 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:31:56 --> Model Class Initialized
INFO - 2016-09-14 15:31:56 --> Model Class Initialized
INFO - 2016-09-14 15:31:56 --> Database Driver Class Initialized
INFO - 2016-09-14 15:31:56 --> Final output sent to browser
DEBUG - 2016-09-14 15:31:56 --> Total execution time: 0.7790
INFO - 2016-09-14 15:31:57 --> Config Class Initialized
INFO - 2016-09-14 15:31:57 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:31:57 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:31:57 --> Utf8 Class Initialized
INFO - 2016-09-14 15:31:57 --> URI Class Initialized
INFO - 2016-09-14 15:31:57 --> Router Class Initialized
INFO - 2016-09-14 15:31:57 --> Output Class Initialized
INFO - 2016-09-14 15:31:57 --> Security Class Initialized
DEBUG - 2016-09-14 15:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:31:57 --> Input Class Initialized
INFO - 2016-09-14 15:31:57 --> Language Class Initialized
INFO - 2016-09-14 15:31:57 --> Language Class Initialized
INFO - 2016-09-14 15:31:57 --> Config Class Initialized
INFO - 2016-09-14 15:31:57 --> Loader Class Initialized
INFO - 2016-09-14 15:31:57 --> Helper loaded: url_helper
INFO - 2016-09-14 15:31:57 --> Database Driver Class Initialized
INFO - 2016-09-14 15:31:57 --> Controller Class Initialized
DEBUG - 2016-09-14 15:31:57 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:31:57 --> Model Class Initialized
INFO - 2016-09-14 15:31:58 --> Model Class Initialized
INFO - 2016-09-14 15:31:58 --> Database Driver Class Initialized
INFO - 2016-09-14 15:31:58 --> Final output sent to browser
DEBUG - 2016-09-14 15:31:58 --> Total execution time: 0.8814
INFO - 2016-09-14 15:32:00 --> Config Class Initialized
INFO - 2016-09-14 15:32:00 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:32:00 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:32:00 --> Utf8 Class Initialized
INFO - 2016-09-14 15:32:00 --> URI Class Initialized
INFO - 2016-09-14 15:32:00 --> Router Class Initialized
INFO - 2016-09-14 15:32:00 --> Output Class Initialized
INFO - 2016-09-14 15:32:00 --> Security Class Initialized
DEBUG - 2016-09-14 15:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:32:00 --> Input Class Initialized
INFO - 2016-09-14 15:32:01 --> Language Class Initialized
INFO - 2016-09-14 15:32:01 --> Language Class Initialized
INFO - 2016-09-14 15:32:01 --> Config Class Initialized
INFO - 2016-09-14 15:32:01 --> Loader Class Initialized
INFO - 2016-09-14 15:32:01 --> Helper loaded: url_helper
INFO - 2016-09-14 15:32:01 --> Database Driver Class Initialized
INFO - 2016-09-14 15:32:01 --> Controller Class Initialized
DEBUG - 2016-09-14 15:32:01 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:32:01 --> Model Class Initialized
INFO - 2016-09-14 15:32:01 --> Model Class Initialized
INFO - 2016-09-14 15:32:01 --> Database Driver Class Initialized
INFO - 2016-09-14 15:32:01 --> Final output sent to browser
DEBUG - 2016-09-14 15:32:01 --> Total execution time: 0.8019
INFO - 2016-09-14 15:32:02 --> Config Class Initialized
INFO - 2016-09-14 15:32:02 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:32:02 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:32:02 --> Utf8 Class Initialized
INFO - 2016-09-14 15:32:02 --> URI Class Initialized
INFO - 2016-09-14 15:32:02 --> Router Class Initialized
INFO - 2016-09-14 15:32:02 --> Output Class Initialized
INFO - 2016-09-14 15:32:02 --> Security Class Initialized
DEBUG - 2016-09-14 15:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:32:02 --> Input Class Initialized
INFO - 2016-09-14 15:32:02 --> Language Class Initialized
INFO - 2016-09-14 15:32:02 --> Language Class Initialized
INFO - 2016-09-14 15:32:02 --> Config Class Initialized
INFO - 2016-09-14 15:32:03 --> Loader Class Initialized
INFO - 2016-09-14 15:32:03 --> Helper loaded: url_helper
INFO - 2016-09-14 15:32:03 --> Database Driver Class Initialized
INFO - 2016-09-14 15:32:03 --> Controller Class Initialized
DEBUG - 2016-09-14 15:32:03 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:32:03 --> Model Class Initialized
INFO - 2016-09-14 15:32:03 --> Model Class Initialized
INFO - 2016-09-14 15:32:03 --> Database Driver Class Initialized
INFO - 2016-09-14 15:32:03 --> Final output sent to browser
DEBUG - 2016-09-14 15:32:03 --> Total execution time: 0.9638
INFO - 2016-09-14 15:32:06 --> Config Class Initialized
INFO - 2016-09-14 15:32:06 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:32:06 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:32:06 --> Utf8 Class Initialized
INFO - 2016-09-14 15:32:06 --> URI Class Initialized
INFO - 2016-09-14 15:32:06 --> Router Class Initialized
INFO - 2016-09-14 15:32:06 --> Output Class Initialized
INFO - 2016-09-14 15:32:06 --> Security Class Initialized
DEBUG - 2016-09-14 15:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:32:06 --> Input Class Initialized
INFO - 2016-09-14 15:32:06 --> Language Class Initialized
INFO - 2016-09-14 15:32:06 --> Language Class Initialized
INFO - 2016-09-14 15:32:06 --> Config Class Initialized
INFO - 2016-09-14 15:32:06 --> Loader Class Initialized
INFO - 2016-09-14 15:32:06 --> Helper loaded: url_helper
INFO - 2016-09-14 15:32:06 --> Database Driver Class Initialized
INFO - 2016-09-14 15:32:06 --> Controller Class Initialized
DEBUG - 2016-09-14 15:32:06 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:32:06 --> Model Class Initialized
INFO - 2016-09-14 15:32:06 --> Model Class Initialized
INFO - 2016-09-14 15:32:06 --> Database Driver Class Initialized
INFO - 2016-09-14 15:32:07 --> Final output sent to browser
DEBUG - 2016-09-14 15:32:07 --> Total execution time: 0.8070
INFO - 2016-09-14 15:32:08 --> Config Class Initialized
INFO - 2016-09-14 15:32:08 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:32:08 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:32:08 --> Utf8 Class Initialized
INFO - 2016-09-14 15:32:08 --> URI Class Initialized
INFO - 2016-09-14 15:32:08 --> Router Class Initialized
INFO - 2016-09-14 15:32:08 --> Output Class Initialized
INFO - 2016-09-14 15:32:08 --> Security Class Initialized
DEBUG - 2016-09-14 15:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:32:08 --> Input Class Initialized
INFO - 2016-09-14 15:32:08 --> Language Class Initialized
INFO - 2016-09-14 15:32:08 --> Language Class Initialized
INFO - 2016-09-14 15:32:08 --> Config Class Initialized
INFO - 2016-09-14 15:32:08 --> Loader Class Initialized
INFO - 2016-09-14 15:32:08 --> Helper loaded: url_helper
INFO - 2016-09-14 15:32:08 --> Database Driver Class Initialized
INFO - 2016-09-14 15:32:08 --> Controller Class Initialized
DEBUG - 2016-09-14 15:32:08 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:32:09 --> Model Class Initialized
INFO - 2016-09-14 15:32:09 --> Model Class Initialized
INFO - 2016-09-14 15:32:09 --> Database Driver Class Initialized
INFO - 2016-09-14 15:32:09 --> Final output sent to browser
DEBUG - 2016-09-14 15:32:09 --> Total execution time: 0.8238
INFO - 2016-09-14 15:32:11 --> Config Class Initialized
INFO - 2016-09-14 15:32:11 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:32:11 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:32:11 --> Utf8 Class Initialized
INFO - 2016-09-14 15:32:11 --> URI Class Initialized
INFO - 2016-09-14 15:32:12 --> Router Class Initialized
INFO - 2016-09-14 15:32:12 --> Output Class Initialized
INFO - 2016-09-14 15:32:12 --> Security Class Initialized
DEBUG - 2016-09-14 15:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:32:12 --> Input Class Initialized
INFO - 2016-09-14 15:32:12 --> Language Class Initialized
INFO - 2016-09-14 15:32:12 --> Language Class Initialized
INFO - 2016-09-14 15:32:12 --> Config Class Initialized
INFO - 2016-09-14 15:32:12 --> Loader Class Initialized
INFO - 2016-09-14 15:32:12 --> Helper loaded: url_helper
INFO - 2016-09-14 15:32:12 --> Database Driver Class Initialized
INFO - 2016-09-14 15:32:12 --> Controller Class Initialized
DEBUG - 2016-09-14 15:32:12 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:32:12 --> Model Class Initialized
INFO - 2016-09-14 15:32:12 --> Model Class Initialized
INFO - 2016-09-14 15:32:12 --> Database Driver Class Initialized
INFO - 2016-09-14 15:32:12 --> Final output sent to browser
DEBUG - 2016-09-14 15:32:12 --> Total execution time: 0.9603
INFO - 2016-09-14 15:32:14 --> Config Class Initialized
INFO - 2016-09-14 15:32:14 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:32:14 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:32:14 --> Utf8 Class Initialized
INFO - 2016-09-14 15:32:14 --> URI Class Initialized
INFO - 2016-09-14 15:32:14 --> Router Class Initialized
INFO - 2016-09-14 15:32:14 --> Output Class Initialized
INFO - 2016-09-14 15:32:14 --> Security Class Initialized
DEBUG - 2016-09-14 15:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:32:14 --> Input Class Initialized
INFO - 2016-09-14 15:32:14 --> Language Class Initialized
INFO - 2016-09-14 15:32:14 --> Language Class Initialized
INFO - 2016-09-14 15:32:14 --> Config Class Initialized
INFO - 2016-09-14 15:32:14 --> Loader Class Initialized
INFO - 2016-09-14 15:32:14 --> Helper loaded: url_helper
INFO - 2016-09-14 15:32:14 --> Database Driver Class Initialized
INFO - 2016-09-14 15:32:14 --> Controller Class Initialized
DEBUG - 2016-09-14 15:32:14 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:32:14 --> Model Class Initialized
INFO - 2016-09-14 15:32:14 --> Model Class Initialized
INFO - 2016-09-14 15:32:14 --> Database Driver Class Initialized
INFO - 2016-09-14 15:32:14 --> Final output sent to browser
DEBUG - 2016-09-14 15:32:14 --> Total execution time: 0.8730
INFO - 2016-09-14 15:32:16 --> Config Class Initialized
INFO - 2016-09-14 15:32:16 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:32:16 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:32:16 --> Utf8 Class Initialized
INFO - 2016-09-14 15:32:16 --> URI Class Initialized
INFO - 2016-09-14 15:32:16 --> Router Class Initialized
INFO - 2016-09-14 15:32:16 --> Output Class Initialized
INFO - 2016-09-14 15:32:16 --> Security Class Initialized
DEBUG - 2016-09-14 15:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:32:16 --> Input Class Initialized
INFO - 2016-09-14 15:32:16 --> Language Class Initialized
INFO - 2016-09-14 15:32:16 --> Language Class Initialized
INFO - 2016-09-14 15:32:16 --> Config Class Initialized
INFO - 2016-09-14 15:32:16 --> Loader Class Initialized
INFO - 2016-09-14 15:32:16 --> Helper loaded: url_helper
INFO - 2016-09-14 15:32:16 --> Database Driver Class Initialized
INFO - 2016-09-14 15:32:16 --> Controller Class Initialized
DEBUG - 2016-09-14 15:32:17 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:32:17 --> Model Class Initialized
INFO - 2016-09-14 15:32:17 --> Model Class Initialized
INFO - 2016-09-14 15:32:17 --> Database Driver Class Initialized
INFO - 2016-09-14 15:32:17 --> Final output sent to browser
DEBUG - 2016-09-14 15:32:17 --> Total execution time: 0.7206
INFO - 2016-09-14 15:32:50 --> Config Class Initialized
INFO - 2016-09-14 15:32:50 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:32:50 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:32:50 --> Utf8 Class Initialized
INFO - 2016-09-14 15:32:50 --> URI Class Initialized
INFO - 2016-09-14 15:32:50 --> Router Class Initialized
INFO - 2016-09-14 15:32:50 --> Output Class Initialized
INFO - 2016-09-14 15:32:50 --> Security Class Initialized
DEBUG - 2016-09-14 15:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:32:50 --> Input Class Initialized
INFO - 2016-09-14 15:32:50 --> Language Class Initialized
INFO - 2016-09-14 15:32:51 --> Language Class Initialized
INFO - 2016-09-14 15:32:51 --> Config Class Initialized
INFO - 2016-09-14 15:32:51 --> Loader Class Initialized
INFO - 2016-09-14 15:32:51 --> Helper loaded: url_helper
INFO - 2016-09-14 15:32:51 --> Database Driver Class Initialized
INFO - 2016-09-14 15:32:51 --> Controller Class Initialized
DEBUG - 2016-09-14 15:32:51 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:32:51 --> Model Class Initialized
INFO - 2016-09-14 15:32:51 --> Model Class Initialized
INFO - 2016-09-14 15:32:51 --> Database Driver Class Initialized
INFO - 2016-09-14 15:32:51 --> Final output sent to browser
DEBUG - 2016-09-14 15:32:51 --> Total execution time: 0.6922
INFO - 2016-09-14 15:33:54 --> Config Class Initialized
INFO - 2016-09-14 15:33:54 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:33:54 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:33:54 --> Utf8 Class Initialized
INFO - 2016-09-14 15:33:54 --> URI Class Initialized
INFO - 2016-09-14 15:33:54 --> Router Class Initialized
INFO - 2016-09-14 15:33:54 --> Output Class Initialized
INFO - 2016-09-14 15:33:54 --> Security Class Initialized
DEBUG - 2016-09-14 15:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:33:54 --> Input Class Initialized
INFO - 2016-09-14 15:33:54 --> Language Class Initialized
INFO - 2016-09-14 15:33:54 --> Language Class Initialized
INFO - 2016-09-14 15:33:54 --> Config Class Initialized
INFO - 2016-09-14 15:33:54 --> Loader Class Initialized
INFO - 2016-09-14 15:33:54 --> Helper loaded: url_helper
INFO - 2016-09-14 15:33:54 --> Database Driver Class Initialized
INFO - 2016-09-14 15:33:54 --> Controller Class Initialized
DEBUG - 2016-09-14 15:33:54 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:33:54 --> Model Class Initialized
INFO - 2016-09-14 15:33:55 --> Model Class Initialized
DEBUG - 2016-09-14 15:33:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 15:33:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 15:33:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 15:33:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_bayar_angsuran.php
DEBUG - 2016-09-14 15:33:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 15:33:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 15:33:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 15:33:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 15:33:55 --> Final output sent to browser
DEBUG - 2016-09-14 15:33:55 --> Total execution time: 0.9442
INFO - 2016-09-14 15:33:58 --> Config Class Initialized
INFO - 2016-09-14 15:33:58 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:33:58 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:33:59 --> Utf8 Class Initialized
INFO - 2016-09-14 15:33:59 --> URI Class Initialized
INFO - 2016-09-14 15:33:59 --> Router Class Initialized
INFO - 2016-09-14 15:33:59 --> Output Class Initialized
INFO - 2016-09-14 15:33:59 --> Security Class Initialized
DEBUG - 2016-09-14 15:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:33:59 --> Input Class Initialized
INFO - 2016-09-14 15:33:59 --> Language Class Initialized
INFO - 2016-09-14 15:33:59 --> Language Class Initialized
INFO - 2016-09-14 15:33:59 --> Config Class Initialized
INFO - 2016-09-14 15:33:59 --> Loader Class Initialized
INFO - 2016-09-14 15:33:59 --> Helper loaded: url_helper
INFO - 2016-09-14 15:33:59 --> Database Driver Class Initialized
INFO - 2016-09-14 15:33:59 --> Controller Class Initialized
DEBUG - 2016-09-14 15:33:59 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:33:59 --> Model Class Initialized
INFO - 2016-09-14 15:33:59 --> Model Class Initialized
INFO - 2016-09-14 15:33:59 --> Database Driver Class Initialized
INFO - 2016-09-14 15:33:59 --> Final output sent to browser
DEBUG - 2016-09-14 15:33:59 --> Total execution time: 0.7481
INFO - 2016-09-14 15:34:38 --> Config Class Initialized
INFO - 2016-09-14 15:34:38 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:34:38 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:34:38 --> Utf8 Class Initialized
INFO - 2016-09-14 15:34:38 --> URI Class Initialized
INFO - 2016-09-14 15:34:38 --> Router Class Initialized
INFO - 2016-09-14 15:34:38 --> Output Class Initialized
INFO - 2016-09-14 15:34:38 --> Security Class Initialized
DEBUG - 2016-09-14 15:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:34:38 --> Input Class Initialized
INFO - 2016-09-14 15:34:38 --> Language Class Initialized
INFO - 2016-09-14 15:34:38 --> Language Class Initialized
INFO - 2016-09-14 15:34:38 --> Config Class Initialized
INFO - 2016-09-14 15:34:38 --> Loader Class Initialized
INFO - 2016-09-14 15:34:38 --> Helper loaded: url_helper
INFO - 2016-09-14 15:34:39 --> Database Driver Class Initialized
INFO - 2016-09-14 15:34:39 --> Controller Class Initialized
DEBUG - 2016-09-14 15:34:39 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:34:39 --> Model Class Initialized
INFO - 2016-09-14 15:34:39 --> Model Class Initialized
INFO - 2016-09-14 15:34:39 --> Database Driver Class Initialized
INFO - 2016-09-14 15:34:39 --> Final output sent to browser
DEBUG - 2016-09-14 15:34:39 --> Total execution time: 0.7171
INFO - 2016-09-14 15:34:48 --> Config Class Initialized
INFO - 2016-09-14 15:34:49 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:34:49 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:34:49 --> Utf8 Class Initialized
INFO - 2016-09-14 15:34:49 --> URI Class Initialized
INFO - 2016-09-14 15:34:49 --> Router Class Initialized
INFO - 2016-09-14 15:34:49 --> Output Class Initialized
INFO - 2016-09-14 15:34:49 --> Security Class Initialized
DEBUG - 2016-09-14 15:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:34:49 --> Input Class Initialized
INFO - 2016-09-14 15:34:49 --> Language Class Initialized
INFO - 2016-09-14 15:34:49 --> Language Class Initialized
INFO - 2016-09-14 15:34:49 --> Config Class Initialized
INFO - 2016-09-14 15:34:49 --> Loader Class Initialized
INFO - 2016-09-14 15:34:49 --> Helper loaded: url_helper
INFO - 2016-09-14 15:34:49 --> Database Driver Class Initialized
INFO - 2016-09-14 15:34:49 --> Controller Class Initialized
DEBUG - 2016-09-14 15:34:49 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:34:49 --> Model Class Initialized
INFO - 2016-09-14 15:34:49 --> Model Class Initialized
INFO - 2016-09-14 15:34:49 --> Database Driver Class Initialized
INFO - 2016-09-14 15:34:49 --> Final output sent to browser
DEBUG - 2016-09-14 15:34:49 --> Total execution time: 0.6943
INFO - 2016-09-14 15:34:53 --> Config Class Initialized
INFO - 2016-09-14 15:34:53 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:34:53 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:34:53 --> Utf8 Class Initialized
INFO - 2016-09-14 15:34:53 --> URI Class Initialized
INFO - 2016-09-14 15:34:53 --> Router Class Initialized
INFO - 2016-09-14 15:34:53 --> Output Class Initialized
INFO - 2016-09-14 15:34:53 --> Security Class Initialized
DEBUG - 2016-09-14 15:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:34:54 --> Input Class Initialized
INFO - 2016-09-14 15:34:54 --> Language Class Initialized
INFO - 2016-09-14 15:34:54 --> Language Class Initialized
INFO - 2016-09-14 15:34:54 --> Config Class Initialized
INFO - 2016-09-14 15:34:54 --> Loader Class Initialized
INFO - 2016-09-14 15:34:54 --> Helper loaded: url_helper
INFO - 2016-09-14 15:34:54 --> Database Driver Class Initialized
INFO - 2016-09-14 15:34:54 --> Controller Class Initialized
DEBUG - 2016-09-14 15:34:54 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:34:54 --> Model Class Initialized
INFO - 2016-09-14 15:34:54 --> Model Class Initialized
INFO - 2016-09-14 15:34:54 --> Database Driver Class Initialized
INFO - 2016-09-14 15:34:54 --> Final output sent to browser
DEBUG - 2016-09-14 15:34:54 --> Total execution time: 0.8610
INFO - 2016-09-14 15:34:56 --> Config Class Initialized
INFO - 2016-09-14 15:34:56 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:34:56 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:34:56 --> Utf8 Class Initialized
INFO - 2016-09-14 15:34:56 --> URI Class Initialized
INFO - 2016-09-14 15:34:56 --> Router Class Initialized
INFO - 2016-09-14 15:34:57 --> Output Class Initialized
INFO - 2016-09-14 15:34:57 --> Security Class Initialized
DEBUG - 2016-09-14 15:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:34:57 --> Input Class Initialized
INFO - 2016-09-14 15:34:57 --> Language Class Initialized
INFO - 2016-09-14 15:34:57 --> Language Class Initialized
INFO - 2016-09-14 15:34:57 --> Config Class Initialized
INFO - 2016-09-14 15:34:57 --> Loader Class Initialized
INFO - 2016-09-14 15:34:57 --> Helper loaded: url_helper
INFO - 2016-09-14 15:34:57 --> Database Driver Class Initialized
INFO - 2016-09-14 15:34:57 --> Controller Class Initialized
DEBUG - 2016-09-14 15:34:57 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:34:57 --> Model Class Initialized
INFO - 2016-09-14 15:34:57 --> Model Class Initialized
INFO - 2016-09-14 15:34:57 --> Database Driver Class Initialized
INFO - 2016-09-14 15:34:57 --> Final output sent to browser
DEBUG - 2016-09-14 15:34:57 --> Total execution time: 0.7515
INFO - 2016-09-14 15:35:29 --> Config Class Initialized
INFO - 2016-09-14 15:35:29 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:35:29 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:35:29 --> Utf8 Class Initialized
INFO - 2016-09-14 15:35:29 --> URI Class Initialized
INFO - 2016-09-14 15:35:29 --> Router Class Initialized
INFO - 2016-09-14 15:35:29 --> Output Class Initialized
INFO - 2016-09-14 15:35:29 --> Security Class Initialized
DEBUG - 2016-09-14 15:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:35:29 --> Input Class Initialized
INFO - 2016-09-14 15:35:29 --> Language Class Initialized
INFO - 2016-09-14 15:35:29 --> Language Class Initialized
INFO - 2016-09-14 15:35:30 --> Config Class Initialized
INFO - 2016-09-14 15:35:30 --> Loader Class Initialized
INFO - 2016-09-14 15:35:30 --> Helper loaded: url_helper
INFO - 2016-09-14 15:35:30 --> Database Driver Class Initialized
INFO - 2016-09-14 15:35:30 --> Controller Class Initialized
DEBUG - 2016-09-14 15:35:30 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:35:30 --> Model Class Initialized
INFO - 2016-09-14 15:35:30 --> Model Class Initialized
DEBUG - 2016-09-14 15:35:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 15:35:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 15:35:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 15:35:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_bayar_angsuran.php
DEBUG - 2016-09-14 15:35:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 15:35:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 15:35:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 15:35:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 15:35:30 --> Final output sent to browser
DEBUG - 2016-09-14 15:35:30 --> Total execution time: 1.0216
INFO - 2016-09-14 15:35:39 --> Config Class Initialized
INFO - 2016-09-14 15:35:39 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:35:39 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:35:39 --> Utf8 Class Initialized
INFO - 2016-09-14 15:35:39 --> URI Class Initialized
INFO - 2016-09-14 15:35:39 --> Router Class Initialized
INFO - 2016-09-14 15:35:39 --> Output Class Initialized
INFO - 2016-09-14 15:35:39 --> Security Class Initialized
DEBUG - 2016-09-14 15:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:35:39 --> Input Class Initialized
INFO - 2016-09-14 15:35:39 --> Language Class Initialized
INFO - 2016-09-14 15:35:39 --> Language Class Initialized
INFO - 2016-09-14 15:35:39 --> Config Class Initialized
INFO - 2016-09-14 15:35:39 --> Loader Class Initialized
INFO - 2016-09-14 15:35:39 --> Helper loaded: url_helper
INFO - 2016-09-14 15:35:39 --> Database Driver Class Initialized
INFO - 2016-09-14 15:35:39 --> Controller Class Initialized
DEBUG - 2016-09-14 15:35:39 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:35:39 --> Model Class Initialized
INFO - 2016-09-14 15:35:39 --> Model Class Initialized
INFO - 2016-09-14 15:35:39 --> Database Driver Class Initialized
INFO - 2016-09-14 15:35:39 --> Final output sent to browser
DEBUG - 2016-09-14 15:35:39 --> Total execution time: 0.7281
INFO - 2016-09-14 15:35:43 --> Config Class Initialized
INFO - 2016-09-14 15:35:43 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:35:43 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:35:43 --> Utf8 Class Initialized
INFO - 2016-09-14 15:35:43 --> URI Class Initialized
INFO - 2016-09-14 15:35:43 --> Router Class Initialized
INFO - 2016-09-14 15:35:43 --> Output Class Initialized
INFO - 2016-09-14 15:35:43 --> Security Class Initialized
DEBUG - 2016-09-14 15:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:35:43 --> Input Class Initialized
INFO - 2016-09-14 15:35:43 --> Language Class Initialized
INFO - 2016-09-14 15:35:43 --> Language Class Initialized
INFO - 2016-09-14 15:35:43 --> Config Class Initialized
INFO - 2016-09-14 15:35:43 --> Loader Class Initialized
INFO - 2016-09-14 15:35:43 --> Helper loaded: url_helper
INFO - 2016-09-14 15:35:43 --> Database Driver Class Initialized
INFO - 2016-09-14 15:35:44 --> Controller Class Initialized
DEBUG - 2016-09-14 15:35:44 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:35:44 --> Model Class Initialized
INFO - 2016-09-14 15:35:44 --> Model Class Initialized
INFO - 2016-09-14 15:35:44 --> Database Driver Class Initialized
INFO - 2016-09-14 15:35:44 --> Final output sent to browser
DEBUG - 2016-09-14 15:35:44 --> Total execution time: 0.8744
INFO - 2016-09-14 15:35:48 --> Config Class Initialized
INFO - 2016-09-14 15:35:48 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:35:48 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:35:48 --> Utf8 Class Initialized
INFO - 2016-09-14 15:35:48 --> URI Class Initialized
INFO - 2016-09-14 15:35:48 --> Router Class Initialized
INFO - 2016-09-14 15:35:48 --> Output Class Initialized
INFO - 2016-09-14 15:35:48 --> Security Class Initialized
DEBUG - 2016-09-14 15:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:35:48 --> Input Class Initialized
INFO - 2016-09-14 15:35:48 --> Language Class Initialized
INFO - 2016-09-14 15:35:48 --> Language Class Initialized
INFO - 2016-09-14 15:35:48 --> Config Class Initialized
INFO - 2016-09-14 15:35:48 --> Loader Class Initialized
INFO - 2016-09-14 15:35:48 --> Helper loaded: url_helper
INFO - 2016-09-14 15:35:48 --> Database Driver Class Initialized
INFO - 2016-09-14 15:35:48 --> Controller Class Initialized
DEBUG - 2016-09-14 15:35:48 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:35:48 --> Model Class Initialized
INFO - 2016-09-14 15:35:48 --> Model Class Initialized
INFO - 2016-09-14 15:35:48 --> Database Driver Class Initialized
INFO - 2016-09-14 15:35:48 --> Final output sent to browser
DEBUG - 2016-09-14 15:35:48 --> Total execution time: 0.7383
INFO - 2016-09-14 15:43:07 --> Config Class Initialized
INFO - 2016-09-14 15:43:07 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:43:07 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:43:07 --> Utf8 Class Initialized
INFO - 2016-09-14 15:43:07 --> URI Class Initialized
INFO - 2016-09-14 15:43:07 --> Router Class Initialized
INFO - 2016-09-14 15:43:07 --> Output Class Initialized
INFO - 2016-09-14 15:43:07 --> Security Class Initialized
DEBUG - 2016-09-14 15:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:43:07 --> Input Class Initialized
INFO - 2016-09-14 15:43:07 --> Language Class Initialized
INFO - 2016-09-14 15:43:08 --> Language Class Initialized
INFO - 2016-09-14 15:43:08 --> Config Class Initialized
INFO - 2016-09-14 15:43:08 --> Loader Class Initialized
INFO - 2016-09-14 15:43:08 --> Helper loaded: url_helper
INFO - 2016-09-14 15:43:08 --> Database Driver Class Initialized
INFO - 2016-09-14 15:43:08 --> Controller Class Initialized
DEBUG - 2016-09-14 15:43:08 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:43:08 --> Model Class Initialized
INFO - 2016-09-14 15:43:08 --> Model Class Initialized
DEBUG - 2016-09-14 15:43:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 15:43:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 15:43:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 15:43:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tutup_angsuran.php
DEBUG - 2016-09-14 15:43:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 15:43:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 15:43:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 15:43:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 15:43:08 --> Final output sent to browser
DEBUG - 2016-09-14 15:43:08 --> Total execution time: 1.0860
INFO - 2016-09-14 15:53:50 --> Config Class Initialized
INFO - 2016-09-14 15:53:50 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:53:50 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:53:50 --> Utf8 Class Initialized
INFO - 2016-09-14 15:53:50 --> URI Class Initialized
INFO - 2016-09-14 15:53:50 --> Router Class Initialized
INFO - 2016-09-14 15:53:50 --> Output Class Initialized
INFO - 2016-09-14 15:53:51 --> Security Class Initialized
DEBUG - 2016-09-14 15:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:53:51 --> Input Class Initialized
INFO - 2016-09-14 15:53:51 --> Language Class Initialized
INFO - 2016-09-14 15:53:51 --> Language Class Initialized
INFO - 2016-09-14 15:53:51 --> Config Class Initialized
INFO - 2016-09-14 15:53:51 --> Loader Class Initialized
INFO - 2016-09-14 15:53:51 --> Helper loaded: url_helper
INFO - 2016-09-14 15:53:51 --> Database Driver Class Initialized
INFO - 2016-09-14 15:53:51 --> Controller Class Initialized
DEBUG - 2016-09-14 15:53:51 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:53:51 --> Model Class Initialized
INFO - 2016-09-14 15:53:51 --> Model Class Initialized
DEBUG - 2016-09-14 15:53:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 15:53:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 15:53:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 15:53:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tutup_angsuran.php
DEBUG - 2016-09-14 15:53:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 15:53:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 15:53:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 15:53:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 15:53:51 --> Final output sent to browser
DEBUG - 2016-09-14 15:53:51 --> Total execution time: 1.0670
INFO - 2016-09-14 15:54:07 --> Config Class Initialized
INFO - 2016-09-14 15:54:07 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:54:07 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:54:07 --> Utf8 Class Initialized
INFO - 2016-09-14 15:54:07 --> URI Class Initialized
INFO - 2016-09-14 15:54:07 --> Router Class Initialized
INFO - 2016-09-14 15:54:07 --> Output Class Initialized
INFO - 2016-09-14 15:54:07 --> Security Class Initialized
DEBUG - 2016-09-14 15:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:54:07 --> Input Class Initialized
INFO - 2016-09-14 15:54:07 --> Language Class Initialized
INFO - 2016-09-14 15:54:07 --> Language Class Initialized
INFO - 2016-09-14 15:54:07 --> Config Class Initialized
INFO - 2016-09-14 15:54:07 --> Loader Class Initialized
INFO - 2016-09-14 15:54:07 --> Helper loaded: url_helper
INFO - 2016-09-14 15:54:07 --> Database Driver Class Initialized
INFO - 2016-09-14 15:54:07 --> Controller Class Initialized
DEBUG - 2016-09-14 15:54:07 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:54:08 --> Model Class Initialized
INFO - 2016-09-14 15:54:08 --> Model Class Initialized
INFO - 2016-09-14 15:54:08 --> Database Driver Class Initialized
INFO - 2016-09-14 15:54:08 --> Final output sent to browser
DEBUG - 2016-09-14 15:54:08 --> Total execution time: 0.7682
INFO - 2016-09-14 15:54:30 --> Config Class Initialized
INFO - 2016-09-14 15:54:30 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:54:31 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:54:31 --> Utf8 Class Initialized
INFO - 2016-09-14 15:54:31 --> URI Class Initialized
INFO - 2016-09-14 15:54:31 --> Router Class Initialized
INFO - 2016-09-14 15:54:31 --> Output Class Initialized
INFO - 2016-09-14 15:54:31 --> Security Class Initialized
DEBUG - 2016-09-14 15:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:54:31 --> Input Class Initialized
INFO - 2016-09-14 15:54:31 --> Language Class Initialized
INFO - 2016-09-14 15:54:31 --> Language Class Initialized
INFO - 2016-09-14 15:54:31 --> Config Class Initialized
INFO - 2016-09-14 15:54:31 --> Loader Class Initialized
INFO - 2016-09-14 15:54:31 --> Helper loaded: url_helper
INFO - 2016-09-14 15:54:31 --> Database Driver Class Initialized
INFO - 2016-09-14 15:54:31 --> Controller Class Initialized
DEBUG - 2016-09-14 15:54:31 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:54:31 --> Model Class Initialized
INFO - 2016-09-14 15:54:31 --> Model Class Initialized
INFO - 2016-09-14 15:54:31 --> Database Driver Class Initialized
INFO - 2016-09-14 15:54:31 --> Final output sent to browser
DEBUG - 2016-09-14 15:54:31 --> Total execution time: 0.7274
INFO - 2016-09-14 15:54:59 --> Config Class Initialized
INFO - 2016-09-14 15:54:59 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:54:59 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:54:59 --> Utf8 Class Initialized
INFO - 2016-09-14 15:54:59 --> URI Class Initialized
INFO - 2016-09-14 15:54:59 --> Router Class Initialized
INFO - 2016-09-14 15:54:59 --> Output Class Initialized
INFO - 2016-09-14 15:54:59 --> Security Class Initialized
DEBUG - 2016-09-14 15:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:54:59 --> Input Class Initialized
INFO - 2016-09-14 15:54:59 --> Language Class Initialized
INFO - 2016-09-14 15:54:59 --> Language Class Initialized
INFO - 2016-09-14 15:54:59 --> Config Class Initialized
INFO - 2016-09-14 15:54:59 --> Loader Class Initialized
INFO - 2016-09-14 15:54:59 --> Helper loaded: url_helper
INFO - 2016-09-14 15:55:00 --> Database Driver Class Initialized
INFO - 2016-09-14 15:55:00 --> Controller Class Initialized
DEBUG - 2016-09-14 15:55:00 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:55:00 --> Model Class Initialized
INFO - 2016-09-14 15:55:00 --> Model Class Initialized
INFO - 2016-09-14 15:55:00 --> Database Driver Class Initialized
ERROR - 2016-09-14 15:55:00 --> Severity: Notice --> Undefined variable: getMasterPinjaman E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 247
ERROR - 2016-09-14 15:55:00 --> Severity: Error --> Call to a member function row() on null E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 247
INFO - 2016-09-14 15:55:06 --> Config Class Initialized
INFO - 2016-09-14 15:55:06 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:55:06 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:55:06 --> Utf8 Class Initialized
INFO - 2016-09-14 15:55:06 --> URI Class Initialized
INFO - 2016-09-14 15:55:06 --> Router Class Initialized
INFO - 2016-09-14 15:55:06 --> Output Class Initialized
INFO - 2016-09-14 15:55:06 --> Security Class Initialized
DEBUG - 2016-09-14 15:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:55:06 --> Input Class Initialized
INFO - 2016-09-14 15:55:06 --> Language Class Initialized
INFO - 2016-09-14 15:55:06 --> Language Class Initialized
INFO - 2016-09-14 15:55:06 --> Config Class Initialized
INFO - 2016-09-14 15:55:06 --> Loader Class Initialized
INFO - 2016-09-14 15:55:06 --> Helper loaded: url_helper
INFO - 2016-09-14 15:55:06 --> Database Driver Class Initialized
INFO - 2016-09-14 15:55:06 --> Controller Class Initialized
DEBUG - 2016-09-14 15:55:06 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:55:06 --> Model Class Initialized
INFO - 2016-09-14 15:55:06 --> Model Class Initialized
INFO - 2016-09-14 15:55:06 --> Database Driver Class Initialized
ERROR - 2016-09-14 15:55:06 --> Severity: Notice --> Undefined variable: getMasterPinjaman E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 247
ERROR - 2016-09-14 15:55:06 --> Severity: Error --> Call to a member function row() on null E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 247
INFO - 2016-09-14 15:55:10 --> Config Class Initialized
INFO - 2016-09-14 15:55:10 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:55:10 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:55:10 --> Utf8 Class Initialized
INFO - 2016-09-14 15:55:10 --> URI Class Initialized
INFO - 2016-09-14 15:55:10 --> Router Class Initialized
INFO - 2016-09-14 15:55:10 --> Output Class Initialized
INFO - 2016-09-14 15:55:10 --> Security Class Initialized
DEBUG - 2016-09-14 15:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:55:10 --> Input Class Initialized
INFO - 2016-09-14 15:55:10 --> Language Class Initialized
INFO - 2016-09-14 15:55:10 --> Language Class Initialized
INFO - 2016-09-14 15:55:10 --> Config Class Initialized
INFO - 2016-09-14 15:55:10 --> Loader Class Initialized
INFO - 2016-09-14 15:55:10 --> Helper loaded: url_helper
INFO - 2016-09-14 15:55:10 --> Database Driver Class Initialized
INFO - 2016-09-14 15:55:10 --> Controller Class Initialized
DEBUG - 2016-09-14 15:55:10 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:55:10 --> Model Class Initialized
INFO - 2016-09-14 15:55:10 --> Model Class Initialized
DEBUG - 2016-09-14 15:55:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 15:55:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 15:55:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 15:55:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tutup_angsuran.php
DEBUG - 2016-09-14 15:55:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 15:55:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 15:55:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 15:55:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 15:55:11 --> Final output sent to browser
DEBUG - 2016-09-14 15:55:11 --> Total execution time: 1.0720
INFO - 2016-09-14 15:55:14 --> Config Class Initialized
INFO - 2016-09-14 15:55:14 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:55:14 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:55:14 --> Utf8 Class Initialized
INFO - 2016-09-14 15:55:14 --> URI Class Initialized
INFO - 2016-09-14 15:55:14 --> Router Class Initialized
INFO - 2016-09-14 15:55:14 --> Output Class Initialized
INFO - 2016-09-14 15:55:14 --> Security Class Initialized
DEBUG - 2016-09-14 15:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:55:14 --> Input Class Initialized
INFO - 2016-09-14 15:55:14 --> Language Class Initialized
INFO - 2016-09-14 15:55:14 --> Language Class Initialized
INFO - 2016-09-14 15:55:14 --> Config Class Initialized
INFO - 2016-09-14 15:55:14 --> Loader Class Initialized
INFO - 2016-09-14 15:55:14 --> Helper loaded: url_helper
INFO - 2016-09-14 15:55:15 --> Database Driver Class Initialized
INFO - 2016-09-14 15:55:15 --> Controller Class Initialized
DEBUG - 2016-09-14 15:55:15 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:55:15 --> Model Class Initialized
INFO - 2016-09-14 15:55:15 --> Model Class Initialized
INFO - 2016-09-14 15:55:15 --> Database Driver Class Initialized
ERROR - 2016-09-14 15:55:15 --> Severity: Notice --> Undefined variable: getMasterPinjaman E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 247
ERROR - 2016-09-14 15:55:15 --> Severity: Error --> Call to a member function row() on null E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 247
INFO - 2016-09-14 15:55:33 --> Config Class Initialized
INFO - 2016-09-14 15:55:33 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:55:33 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:55:33 --> Utf8 Class Initialized
INFO - 2016-09-14 15:55:33 --> URI Class Initialized
INFO - 2016-09-14 15:55:33 --> Router Class Initialized
INFO - 2016-09-14 15:55:33 --> Output Class Initialized
INFO - 2016-09-14 15:55:33 --> Security Class Initialized
DEBUG - 2016-09-14 15:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:55:33 --> Input Class Initialized
INFO - 2016-09-14 15:55:33 --> Language Class Initialized
INFO - 2016-09-14 15:55:33 --> Language Class Initialized
INFO - 2016-09-14 15:55:33 --> Config Class Initialized
INFO - 2016-09-14 15:55:33 --> Loader Class Initialized
INFO - 2016-09-14 15:55:33 --> Helper loaded: url_helper
INFO - 2016-09-14 15:55:34 --> Database Driver Class Initialized
INFO - 2016-09-14 15:55:34 --> Controller Class Initialized
DEBUG - 2016-09-14 15:55:34 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:55:34 --> Model Class Initialized
INFO - 2016-09-14 15:55:34 --> Model Class Initialized
INFO - 2016-09-14 15:55:34 --> Database Driver Class Initialized
ERROR - 2016-09-14 15:55:34 --> Severity: Notice --> Undefined variable: getMasterPinjaman E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 247
ERROR - 2016-09-14 15:55:34 --> Severity: Error --> Call to a member function row() on null E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 247
INFO - 2016-09-14 15:55:55 --> Config Class Initialized
INFO - 2016-09-14 15:55:55 --> Hooks Class Initialized
DEBUG - 2016-09-14 15:55:55 --> UTF-8 Support Enabled
INFO - 2016-09-14 15:55:55 --> Utf8 Class Initialized
INFO - 2016-09-14 15:55:55 --> URI Class Initialized
INFO - 2016-09-14 15:55:55 --> Router Class Initialized
INFO - 2016-09-14 15:55:55 --> Output Class Initialized
INFO - 2016-09-14 15:55:55 --> Security Class Initialized
DEBUG - 2016-09-14 15:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 15:55:55 --> Input Class Initialized
INFO - 2016-09-14 15:55:55 --> Language Class Initialized
INFO - 2016-09-14 15:55:55 --> Language Class Initialized
INFO - 2016-09-14 15:55:55 --> Config Class Initialized
INFO - 2016-09-14 15:55:55 --> Loader Class Initialized
INFO - 2016-09-14 15:55:55 --> Helper loaded: url_helper
INFO - 2016-09-14 15:55:56 --> Database Driver Class Initialized
INFO - 2016-09-14 15:55:56 --> Controller Class Initialized
DEBUG - 2016-09-14 15:55:56 --> Index MX_Controller Initialized
INFO - 2016-09-14 15:55:56 --> Model Class Initialized
INFO - 2016-09-14 15:55:56 --> Model Class Initialized
INFO - 2016-09-14 15:55:56 --> Database Driver Class Initialized
INFO - 2016-09-14 15:55:56 --> Final output sent to browser
DEBUG - 2016-09-14 15:55:56 --> Total execution time: 0.7878
INFO - 2016-09-14 18:14:04 --> Config Class Initialized
INFO - 2016-09-14 18:14:05 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:14:05 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:14:05 --> Utf8 Class Initialized
INFO - 2016-09-14 18:14:05 --> URI Class Initialized
INFO - 2016-09-14 18:14:05 --> Router Class Initialized
INFO - 2016-09-14 18:14:05 --> Output Class Initialized
INFO - 2016-09-14 18:14:05 --> Security Class Initialized
DEBUG - 2016-09-14 18:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:14:05 --> Input Class Initialized
INFO - 2016-09-14 18:14:05 --> Language Class Initialized
INFO - 2016-09-14 18:14:05 --> Language Class Initialized
INFO - 2016-09-14 18:14:05 --> Config Class Initialized
INFO - 2016-09-14 18:14:05 --> Loader Class Initialized
INFO - 2016-09-14 18:14:05 --> Helper loaded: url_helper
INFO - 2016-09-14 18:14:05 --> Database Driver Class Initialized
INFO - 2016-09-14 18:14:05 --> Controller Class Initialized
DEBUG - 2016-09-14 18:14:05 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:14:05 --> Model Class Initialized
INFO - 2016-09-14 18:14:05 --> Model Class Initialized
DEBUG - 2016-09-14 18:14:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 18:14:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 18:14:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 18:14:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tutup_angsuran.php
DEBUG - 2016-09-14 18:14:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 18:14:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 18:14:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 18:14:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 18:14:06 --> Final output sent to browser
DEBUG - 2016-09-14 18:14:06 --> Total execution time: 1.6643
INFO - 2016-09-14 18:14:09 --> Config Class Initialized
INFO - 2016-09-14 18:14:09 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:14:09 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:14:09 --> Utf8 Class Initialized
INFO - 2016-09-14 18:14:09 --> URI Class Initialized
INFO - 2016-09-14 18:14:09 --> Router Class Initialized
INFO - 2016-09-14 18:14:09 --> Output Class Initialized
INFO - 2016-09-14 18:14:09 --> Security Class Initialized
DEBUG - 2016-09-14 18:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:14:09 --> Input Class Initialized
INFO - 2016-09-14 18:14:10 --> Language Class Initialized
INFO - 2016-09-14 18:14:10 --> Language Class Initialized
INFO - 2016-09-14 18:14:10 --> Config Class Initialized
INFO - 2016-09-14 18:14:10 --> Loader Class Initialized
INFO - 2016-09-14 18:14:10 --> Helper loaded: url_helper
INFO - 2016-09-14 18:14:10 --> Database Driver Class Initialized
INFO - 2016-09-14 18:14:10 --> Controller Class Initialized
DEBUG - 2016-09-14 18:14:10 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:14:10 --> Model Class Initialized
INFO - 2016-09-14 18:14:10 --> Model Class Initialized
INFO - 2016-09-14 18:14:10 --> Database Driver Class Initialized
INFO - 2016-09-14 18:14:10 --> Final output sent to browser
DEBUG - 2016-09-14 18:14:10 --> Total execution time: 0.8292
INFO - 2016-09-14 18:14:41 --> Config Class Initialized
INFO - 2016-09-14 18:14:41 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:14:41 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:14:41 --> Utf8 Class Initialized
INFO - 2016-09-14 18:14:41 --> URI Class Initialized
INFO - 2016-09-14 18:14:41 --> Router Class Initialized
INFO - 2016-09-14 18:14:41 --> Output Class Initialized
INFO - 2016-09-14 18:14:41 --> Security Class Initialized
DEBUG - 2016-09-14 18:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:14:41 --> Input Class Initialized
INFO - 2016-09-14 18:14:41 --> Language Class Initialized
INFO - 2016-09-14 18:14:41 --> Language Class Initialized
INFO - 2016-09-14 18:14:41 --> Config Class Initialized
INFO - 2016-09-14 18:14:41 --> Loader Class Initialized
INFO - 2016-09-14 18:14:41 --> Helper loaded: url_helper
INFO - 2016-09-14 18:14:41 --> Database Driver Class Initialized
INFO - 2016-09-14 18:14:41 --> Controller Class Initialized
DEBUG - 2016-09-14 18:14:41 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:14:41 --> Model Class Initialized
INFO - 2016-09-14 18:14:41 --> Model Class Initialized
INFO - 2016-09-14 18:14:41 --> Database Driver Class Initialized
INFO - 2016-09-14 18:14:42 --> Final output sent to browser
DEBUG - 2016-09-14 18:14:42 --> Total execution time: 0.6857
INFO - 2016-09-14 18:19:11 --> Config Class Initialized
INFO - 2016-09-14 18:19:12 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:19:12 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:19:12 --> Utf8 Class Initialized
INFO - 2016-09-14 18:19:12 --> URI Class Initialized
INFO - 2016-09-14 18:19:12 --> Router Class Initialized
INFO - 2016-09-14 18:19:12 --> Output Class Initialized
INFO - 2016-09-14 18:19:12 --> Security Class Initialized
DEBUG - 2016-09-14 18:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:19:12 --> Input Class Initialized
INFO - 2016-09-14 18:19:12 --> Language Class Initialized
INFO - 2016-09-14 18:19:12 --> Language Class Initialized
INFO - 2016-09-14 18:19:12 --> Config Class Initialized
INFO - 2016-09-14 18:19:12 --> Loader Class Initialized
INFO - 2016-09-14 18:19:12 --> Helper loaded: url_helper
INFO - 2016-09-14 18:19:12 --> Database Driver Class Initialized
INFO - 2016-09-14 18:19:12 --> Controller Class Initialized
DEBUG - 2016-09-14 18:19:12 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:19:12 --> Model Class Initialized
INFO - 2016-09-14 18:19:12 --> Model Class Initialized
INFO - 2016-09-14 18:19:12 --> Database Driver Class Initialized
INFO - 2016-09-14 18:19:12 --> Final output sent to browser
DEBUG - 2016-09-14 18:19:12 --> Total execution time: 0.6958
INFO - 2016-09-14 18:27:31 --> Config Class Initialized
INFO - 2016-09-14 18:27:31 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:27:31 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:27:31 --> Utf8 Class Initialized
INFO - 2016-09-14 18:27:31 --> URI Class Initialized
INFO - 2016-09-14 18:27:31 --> Router Class Initialized
INFO - 2016-09-14 18:27:31 --> Output Class Initialized
INFO - 2016-09-14 18:27:31 --> Security Class Initialized
DEBUG - 2016-09-14 18:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:27:31 --> Input Class Initialized
INFO - 2016-09-14 18:27:31 --> Language Class Initialized
INFO - 2016-09-14 18:27:31 --> Language Class Initialized
INFO - 2016-09-14 18:27:31 --> Config Class Initialized
INFO - 2016-09-14 18:27:31 --> Loader Class Initialized
INFO - 2016-09-14 18:27:31 --> Helper loaded: url_helper
INFO - 2016-09-14 18:27:31 --> Database Driver Class Initialized
INFO - 2016-09-14 18:27:31 --> Controller Class Initialized
DEBUG - 2016-09-14 18:27:31 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:27:31 --> Model Class Initialized
INFO - 2016-09-14 18:27:31 --> Model Class Initialized
DEBUG - 2016-09-14 18:27:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 18:27:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 18:27:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 18:27:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tutup_angsuran.php
DEBUG - 2016-09-14 18:27:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 18:27:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 18:27:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 18:27:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 18:27:31 --> Final output sent to browser
DEBUG - 2016-09-14 18:27:32 --> Total execution time: 0.9770
INFO - 2016-09-14 18:27:35 --> Config Class Initialized
INFO - 2016-09-14 18:27:35 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:27:35 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:27:35 --> Utf8 Class Initialized
INFO - 2016-09-14 18:27:35 --> URI Class Initialized
INFO - 2016-09-14 18:27:35 --> Router Class Initialized
INFO - 2016-09-14 18:27:35 --> Output Class Initialized
INFO - 2016-09-14 18:27:35 --> Security Class Initialized
DEBUG - 2016-09-14 18:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:27:35 --> Input Class Initialized
INFO - 2016-09-14 18:27:35 --> Language Class Initialized
INFO - 2016-09-14 18:27:35 --> Language Class Initialized
INFO - 2016-09-14 18:27:36 --> Config Class Initialized
INFO - 2016-09-14 18:27:36 --> Loader Class Initialized
INFO - 2016-09-14 18:27:36 --> Helper loaded: url_helper
INFO - 2016-09-14 18:27:36 --> Database Driver Class Initialized
INFO - 2016-09-14 18:27:36 --> Controller Class Initialized
DEBUG - 2016-09-14 18:27:36 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:27:36 --> Model Class Initialized
INFO - 2016-09-14 18:27:36 --> Model Class Initialized
INFO - 2016-09-14 18:27:36 --> Database Driver Class Initialized
INFO - 2016-09-14 18:27:36 --> Final output sent to browser
DEBUG - 2016-09-14 18:27:36 --> Total execution time: 0.7817
INFO - 2016-09-14 18:27:41 --> Config Class Initialized
INFO - 2016-09-14 18:27:41 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:27:41 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:27:41 --> Utf8 Class Initialized
INFO - 2016-09-14 18:27:42 --> URI Class Initialized
INFO - 2016-09-14 18:27:42 --> Router Class Initialized
INFO - 2016-09-14 18:27:42 --> Output Class Initialized
INFO - 2016-09-14 18:27:42 --> Security Class Initialized
DEBUG - 2016-09-14 18:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:27:42 --> Input Class Initialized
INFO - 2016-09-14 18:27:42 --> Language Class Initialized
INFO - 2016-09-14 18:27:42 --> Language Class Initialized
INFO - 2016-09-14 18:27:42 --> Config Class Initialized
INFO - 2016-09-14 18:27:42 --> Loader Class Initialized
INFO - 2016-09-14 18:27:42 --> Helper loaded: url_helper
INFO - 2016-09-14 18:27:42 --> Database Driver Class Initialized
INFO - 2016-09-14 18:27:42 --> Controller Class Initialized
DEBUG - 2016-09-14 18:27:42 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:27:42 --> Model Class Initialized
INFO - 2016-09-14 18:27:42 --> Model Class Initialized
INFO - 2016-09-14 18:27:42 --> Database Driver Class Initialized
INFO - 2016-09-14 18:27:42 --> Final output sent to browser
DEBUG - 2016-09-14 18:27:42 --> Total execution time: 0.8737
INFO - 2016-09-14 18:27:57 --> Config Class Initialized
INFO - 2016-09-14 18:27:57 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:27:57 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:27:57 --> Utf8 Class Initialized
INFO - 2016-09-14 18:27:57 --> URI Class Initialized
INFO - 2016-09-14 18:27:57 --> Router Class Initialized
INFO - 2016-09-14 18:27:57 --> Output Class Initialized
INFO - 2016-09-14 18:27:57 --> Security Class Initialized
DEBUG - 2016-09-14 18:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:27:57 --> Input Class Initialized
INFO - 2016-09-14 18:27:57 --> Language Class Initialized
INFO - 2016-09-14 18:27:57 --> Language Class Initialized
INFO - 2016-09-14 18:27:57 --> Config Class Initialized
INFO - 2016-09-14 18:27:57 --> Loader Class Initialized
INFO - 2016-09-14 18:27:57 --> Helper loaded: url_helper
INFO - 2016-09-14 18:27:57 --> Database Driver Class Initialized
INFO - 2016-09-14 18:27:57 --> Controller Class Initialized
DEBUG - 2016-09-14 18:27:57 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:27:57 --> Model Class Initialized
INFO - 2016-09-14 18:27:57 --> Model Class Initialized
INFO - 2016-09-14 18:27:57 --> Database Driver Class Initialized
INFO - 2016-09-14 18:27:57 --> Final output sent to browser
DEBUG - 2016-09-14 18:27:57 --> Total execution time: 0.8141
INFO - 2016-09-14 18:29:04 --> Config Class Initialized
INFO - 2016-09-14 18:29:04 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:29:04 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:29:04 --> Utf8 Class Initialized
INFO - 2016-09-14 18:29:04 --> URI Class Initialized
INFO - 2016-09-14 18:29:04 --> Router Class Initialized
INFO - 2016-09-14 18:29:04 --> Output Class Initialized
INFO - 2016-09-14 18:29:04 --> Security Class Initialized
DEBUG - 2016-09-14 18:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:29:04 --> Input Class Initialized
INFO - 2016-09-14 18:29:04 --> Language Class Initialized
INFO - 2016-09-14 18:29:04 --> Language Class Initialized
INFO - 2016-09-14 18:29:04 --> Config Class Initialized
INFO - 2016-09-14 18:29:04 --> Loader Class Initialized
INFO - 2016-09-14 18:29:04 --> Helper loaded: url_helper
INFO - 2016-09-14 18:29:04 --> Database Driver Class Initialized
INFO - 2016-09-14 18:29:04 --> Controller Class Initialized
DEBUG - 2016-09-14 18:29:05 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:29:05 --> Model Class Initialized
INFO - 2016-09-14 18:29:05 --> Model Class Initialized
DEBUG - 2016-09-14 18:29:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 18:29:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 18:29:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 18:29:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tutup_angsuran.php
DEBUG - 2016-09-14 18:29:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 18:29:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 18:29:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 18:29:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 18:29:05 --> Final output sent to browser
DEBUG - 2016-09-14 18:29:05 --> Total execution time: 1.1480
INFO - 2016-09-14 18:29:12 --> Config Class Initialized
INFO - 2016-09-14 18:29:12 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:29:12 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:29:12 --> Utf8 Class Initialized
INFO - 2016-09-14 18:29:12 --> URI Class Initialized
INFO - 2016-09-14 18:29:12 --> Router Class Initialized
INFO - 2016-09-14 18:29:13 --> Output Class Initialized
INFO - 2016-09-14 18:29:13 --> Security Class Initialized
DEBUG - 2016-09-14 18:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:29:13 --> Input Class Initialized
INFO - 2016-09-14 18:29:13 --> Language Class Initialized
INFO - 2016-09-14 18:29:13 --> Language Class Initialized
INFO - 2016-09-14 18:29:13 --> Config Class Initialized
INFO - 2016-09-14 18:29:13 --> Loader Class Initialized
INFO - 2016-09-14 18:29:13 --> Helper loaded: url_helper
INFO - 2016-09-14 18:29:13 --> Database Driver Class Initialized
INFO - 2016-09-14 18:29:13 --> Controller Class Initialized
DEBUG - 2016-09-14 18:29:13 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:29:13 --> Model Class Initialized
INFO - 2016-09-14 18:29:13 --> Model Class Initialized
INFO - 2016-09-14 18:29:13 --> Database Driver Class Initialized
INFO - 2016-09-14 18:29:13 --> Final output sent to browser
DEBUG - 2016-09-14 18:29:13 --> Total execution time: 1.0340
INFO - 2016-09-14 18:29:38 --> Config Class Initialized
INFO - 2016-09-14 18:29:38 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:29:38 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:29:38 --> Utf8 Class Initialized
INFO - 2016-09-14 18:29:38 --> URI Class Initialized
INFO - 2016-09-14 18:29:38 --> Router Class Initialized
INFO - 2016-09-14 18:29:38 --> Output Class Initialized
INFO - 2016-09-14 18:29:38 --> Security Class Initialized
DEBUG - 2016-09-14 18:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:29:38 --> Input Class Initialized
INFO - 2016-09-14 18:29:39 --> Language Class Initialized
INFO - 2016-09-14 18:29:39 --> Language Class Initialized
INFO - 2016-09-14 18:29:39 --> Config Class Initialized
INFO - 2016-09-14 18:29:39 --> Loader Class Initialized
INFO - 2016-09-14 18:29:39 --> Helper loaded: url_helper
INFO - 2016-09-14 18:29:39 --> Database Driver Class Initialized
INFO - 2016-09-14 18:29:39 --> Controller Class Initialized
DEBUG - 2016-09-14 18:29:39 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:29:39 --> Model Class Initialized
INFO - 2016-09-14 18:29:39 --> Model Class Initialized
DEBUG - 2016-09-14 18:29:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 18:29:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 18:29:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 18:29:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tutup_angsuran.php
DEBUG - 2016-09-14 18:29:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 18:29:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 18:29:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 18:29:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 18:29:39 --> Final output sent to browser
DEBUG - 2016-09-14 18:29:39 --> Total execution time: 1.0633
INFO - 2016-09-14 18:29:56 --> Config Class Initialized
INFO - 2016-09-14 18:29:56 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:29:57 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:29:57 --> Utf8 Class Initialized
INFO - 2016-09-14 18:29:57 --> URI Class Initialized
INFO - 2016-09-14 18:29:57 --> Router Class Initialized
INFO - 2016-09-14 18:29:57 --> Output Class Initialized
INFO - 2016-09-14 18:29:57 --> Security Class Initialized
DEBUG - 2016-09-14 18:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:29:57 --> Input Class Initialized
INFO - 2016-09-14 18:29:57 --> Language Class Initialized
INFO - 2016-09-14 18:29:57 --> Language Class Initialized
INFO - 2016-09-14 18:29:57 --> Config Class Initialized
INFO - 2016-09-14 18:29:57 --> Loader Class Initialized
INFO - 2016-09-14 18:29:57 --> Helper loaded: url_helper
INFO - 2016-09-14 18:29:57 --> Database Driver Class Initialized
INFO - 2016-09-14 18:29:57 --> Controller Class Initialized
DEBUG - 2016-09-14 18:29:57 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:29:57 --> Model Class Initialized
INFO - 2016-09-14 18:29:57 --> Model Class Initialized
INFO - 2016-09-14 18:29:57 --> Database Driver Class Initialized
INFO - 2016-09-14 18:29:57 --> Final output sent to browser
DEBUG - 2016-09-14 18:29:57 --> Total execution time: 0.8504
INFO - 2016-09-14 18:31:03 --> Config Class Initialized
INFO - 2016-09-14 18:31:03 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:31:04 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:31:04 --> Utf8 Class Initialized
INFO - 2016-09-14 18:31:04 --> URI Class Initialized
INFO - 2016-09-14 18:31:04 --> Router Class Initialized
INFO - 2016-09-14 18:31:04 --> Output Class Initialized
INFO - 2016-09-14 18:31:04 --> Security Class Initialized
DEBUG - 2016-09-14 18:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:31:04 --> Input Class Initialized
INFO - 2016-09-14 18:31:04 --> Language Class Initialized
INFO - 2016-09-14 18:31:04 --> Language Class Initialized
INFO - 2016-09-14 18:31:04 --> Config Class Initialized
INFO - 2016-09-14 18:31:04 --> Loader Class Initialized
INFO - 2016-09-14 18:31:04 --> Helper loaded: url_helper
INFO - 2016-09-14 18:31:04 --> Database Driver Class Initialized
INFO - 2016-09-14 18:31:04 --> Controller Class Initialized
DEBUG - 2016-09-14 18:31:04 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:31:04 --> Model Class Initialized
INFO - 2016-09-14 18:31:04 --> Model Class Initialized
INFO - 2016-09-14 18:31:04 --> Final output sent to browser
DEBUG - 2016-09-14 18:31:04 --> Total execution time: 0.8547
INFO - 2016-09-14 18:35:21 --> Config Class Initialized
INFO - 2016-09-14 18:35:21 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:35:21 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:35:21 --> Utf8 Class Initialized
INFO - 2016-09-14 18:35:21 --> URI Class Initialized
INFO - 2016-09-14 18:35:21 --> Router Class Initialized
INFO - 2016-09-14 18:35:21 --> Output Class Initialized
INFO - 2016-09-14 18:35:21 --> Security Class Initialized
DEBUG - 2016-09-14 18:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:35:21 --> Input Class Initialized
INFO - 2016-09-14 18:35:21 --> Language Class Initialized
INFO - 2016-09-14 18:35:21 --> Language Class Initialized
INFO - 2016-09-14 18:35:21 --> Config Class Initialized
INFO - 2016-09-14 18:35:21 --> Loader Class Initialized
INFO - 2016-09-14 18:35:21 --> Helper loaded: url_helper
INFO - 2016-09-14 18:35:21 --> Database Driver Class Initialized
INFO - 2016-09-14 18:35:21 --> Controller Class Initialized
DEBUG - 2016-09-14 18:35:21 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:35:21 --> Model Class Initialized
INFO - 2016-09-14 18:35:21 --> Model Class Initialized
INFO - 2016-09-14 18:35:21 --> Database Driver Class Initialized
INFO - 2016-09-14 18:35:21 --> Database Driver Class Initialized
INFO - 2016-09-14 18:35:22 --> Database Driver Class Initialized
INFO - 2016-09-14 18:35:22 --> Database Driver Class Initialized
INFO - 2016-09-14 18:35:22 --> Database Driver Class Initialized
INFO - 2016-09-14 18:35:22 --> Database Driver Class Initialized
INFO - 2016-09-14 18:35:22 --> Database Driver Class Initialized
INFO - 2016-09-14 18:35:22 --> Final output sent to browser
DEBUG - 2016-09-14 18:35:22 --> Total execution time: 1.5478
INFO - 2016-09-14 18:36:51 --> Config Class Initialized
INFO - 2016-09-14 18:36:51 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:36:52 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:36:52 --> Utf8 Class Initialized
INFO - 2016-09-14 18:36:52 --> URI Class Initialized
INFO - 2016-09-14 18:36:52 --> Router Class Initialized
INFO - 2016-09-14 18:36:52 --> Output Class Initialized
INFO - 2016-09-14 18:36:52 --> Security Class Initialized
DEBUG - 2016-09-14 18:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:36:52 --> Input Class Initialized
INFO - 2016-09-14 18:36:52 --> Language Class Initialized
INFO - 2016-09-14 18:36:52 --> Language Class Initialized
INFO - 2016-09-14 18:36:52 --> Config Class Initialized
INFO - 2016-09-14 18:36:52 --> Loader Class Initialized
INFO - 2016-09-14 18:36:52 --> Helper loaded: url_helper
INFO - 2016-09-14 18:36:52 --> Database Driver Class Initialized
INFO - 2016-09-14 18:36:52 --> Controller Class Initialized
DEBUG - 2016-09-14 18:36:52 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:36:52 --> Model Class Initialized
INFO - 2016-09-14 18:36:52 --> Model Class Initialized
INFO - 2016-09-14 18:36:52 --> Database Driver Class Initialized
INFO - 2016-09-14 18:36:52 --> Final output sent to browser
DEBUG - 2016-09-14 18:36:52 --> Total execution time: 0.7490
INFO - 2016-09-14 18:37:05 --> Config Class Initialized
INFO - 2016-09-14 18:37:05 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:37:05 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:37:05 --> Utf8 Class Initialized
INFO - 2016-09-14 18:37:05 --> URI Class Initialized
INFO - 2016-09-14 18:37:05 --> Router Class Initialized
INFO - 2016-09-14 18:37:05 --> Output Class Initialized
INFO - 2016-09-14 18:37:05 --> Security Class Initialized
DEBUG - 2016-09-14 18:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:37:05 --> Input Class Initialized
INFO - 2016-09-14 18:37:05 --> Language Class Initialized
INFO - 2016-09-14 18:37:05 --> Language Class Initialized
INFO - 2016-09-14 18:37:05 --> Config Class Initialized
INFO - 2016-09-14 18:37:05 --> Loader Class Initialized
INFO - 2016-09-14 18:37:05 --> Helper loaded: url_helper
INFO - 2016-09-14 18:37:05 --> Database Driver Class Initialized
INFO - 2016-09-14 18:37:05 --> Controller Class Initialized
DEBUG - 2016-09-14 18:37:05 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:37:05 --> Model Class Initialized
INFO - 2016-09-14 18:37:05 --> Model Class Initialized
DEBUG - 2016-09-14 18:37:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 18:37:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 18:37:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 18:37:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-14 18:37:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 18:37:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 18:37:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 18:37:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 18:37:06 --> Final output sent to browser
DEBUG - 2016-09-14 18:37:06 --> Total execution time: 1.1487
INFO - 2016-09-14 18:37:12 --> Config Class Initialized
INFO - 2016-09-14 18:37:12 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:37:12 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:37:12 --> Utf8 Class Initialized
INFO - 2016-09-14 18:37:12 --> URI Class Initialized
INFO - 2016-09-14 18:37:12 --> Router Class Initialized
INFO - 2016-09-14 18:37:12 --> Output Class Initialized
INFO - 2016-09-14 18:37:12 --> Security Class Initialized
DEBUG - 2016-09-14 18:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:37:12 --> Input Class Initialized
INFO - 2016-09-14 18:37:12 --> Language Class Initialized
INFO - 2016-09-14 18:37:12 --> Language Class Initialized
INFO - 2016-09-14 18:37:12 --> Config Class Initialized
INFO - 2016-09-14 18:37:12 --> Loader Class Initialized
INFO - 2016-09-14 18:37:12 --> Helper loaded: url_helper
INFO - 2016-09-14 18:37:12 --> Database Driver Class Initialized
INFO - 2016-09-14 18:37:12 --> Controller Class Initialized
DEBUG - 2016-09-14 18:37:12 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:37:12 --> Model Class Initialized
INFO - 2016-09-14 18:37:12 --> Model Class Initialized
DEBUG - 2016-09-14 18:37:12 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 18:37:12 --> Database Driver Class Initialized
INFO - 2016-09-14 18:37:12 --> Final output sent to browser
DEBUG - 2016-09-14 18:37:12 --> Total execution time: 0.7944
INFO - 2016-09-14 18:38:47 --> Config Class Initialized
INFO - 2016-09-14 18:38:47 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:38:47 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:38:47 --> Utf8 Class Initialized
INFO - 2016-09-14 18:38:47 --> URI Class Initialized
INFO - 2016-09-14 18:38:47 --> Router Class Initialized
INFO - 2016-09-14 18:38:47 --> Output Class Initialized
INFO - 2016-09-14 18:38:47 --> Security Class Initialized
DEBUG - 2016-09-14 18:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:38:47 --> Input Class Initialized
INFO - 2016-09-14 18:38:47 --> Language Class Initialized
INFO - 2016-09-14 18:38:47 --> Language Class Initialized
INFO - 2016-09-14 18:38:47 --> Config Class Initialized
INFO - 2016-09-14 18:38:47 --> Loader Class Initialized
INFO - 2016-09-14 18:38:47 --> Helper loaded: url_helper
INFO - 2016-09-14 18:38:47 --> Database Driver Class Initialized
INFO - 2016-09-14 18:38:47 --> Controller Class Initialized
DEBUG - 2016-09-14 18:38:47 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:38:47 --> Model Class Initialized
INFO - 2016-09-14 18:38:47 --> Model Class Initialized
DEBUG - 2016-09-14 18:38:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 18:38:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 18:38:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 18:38:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tutup_angsuran.php
DEBUG - 2016-09-14 18:38:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 18:38:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 18:38:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 18:38:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 18:38:48 --> Final output sent to browser
DEBUG - 2016-09-14 18:38:48 --> Total execution time: 0.9783
INFO - 2016-09-14 18:38:51 --> Config Class Initialized
INFO - 2016-09-14 18:38:51 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:38:51 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:38:51 --> Utf8 Class Initialized
INFO - 2016-09-14 18:38:51 --> URI Class Initialized
INFO - 2016-09-14 18:38:51 --> Router Class Initialized
INFO - 2016-09-14 18:38:51 --> Output Class Initialized
INFO - 2016-09-14 18:38:51 --> Security Class Initialized
DEBUG - 2016-09-14 18:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:38:52 --> Input Class Initialized
INFO - 2016-09-14 18:38:52 --> Language Class Initialized
INFO - 2016-09-14 18:38:52 --> Language Class Initialized
INFO - 2016-09-14 18:38:52 --> Config Class Initialized
INFO - 2016-09-14 18:38:52 --> Loader Class Initialized
INFO - 2016-09-14 18:38:52 --> Helper loaded: url_helper
INFO - 2016-09-14 18:38:52 --> Database Driver Class Initialized
INFO - 2016-09-14 18:38:52 --> Controller Class Initialized
DEBUG - 2016-09-14 18:38:52 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:38:52 --> Model Class Initialized
INFO - 2016-09-14 18:38:52 --> Model Class Initialized
INFO - 2016-09-14 18:38:52 --> Database Driver Class Initialized
INFO - 2016-09-14 18:38:52 --> Final output sent to browser
DEBUG - 2016-09-14 18:38:52 --> Total execution time: 0.7680
INFO - 2016-09-14 18:39:02 --> Config Class Initialized
INFO - 2016-09-14 18:39:03 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:39:03 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:39:03 --> Utf8 Class Initialized
INFO - 2016-09-14 18:39:03 --> URI Class Initialized
INFO - 2016-09-14 18:39:03 --> Router Class Initialized
INFO - 2016-09-14 18:39:03 --> Output Class Initialized
INFO - 2016-09-14 18:39:03 --> Security Class Initialized
DEBUG - 2016-09-14 18:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:39:03 --> Input Class Initialized
INFO - 2016-09-14 18:39:03 --> Language Class Initialized
INFO - 2016-09-14 18:39:03 --> Language Class Initialized
INFO - 2016-09-14 18:39:03 --> Config Class Initialized
INFO - 2016-09-14 18:39:03 --> Loader Class Initialized
INFO - 2016-09-14 18:39:03 --> Helper loaded: url_helper
INFO - 2016-09-14 18:39:03 --> Database Driver Class Initialized
INFO - 2016-09-14 18:39:03 --> Controller Class Initialized
DEBUG - 2016-09-14 18:39:03 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:39:03 --> Model Class Initialized
INFO - 2016-09-14 18:39:03 --> Model Class Initialized
INFO - 2016-09-14 18:39:03 --> Database Driver Class Initialized
INFO - 2016-09-14 18:39:03 --> Database Driver Class Initialized
INFO - 2016-09-14 18:39:03 --> Database Driver Class Initialized
INFO - 2016-09-14 18:39:04 --> Database Driver Class Initialized
INFO - 2016-09-14 18:39:04 --> Database Driver Class Initialized
INFO - 2016-09-14 18:39:04 --> Database Driver Class Initialized
INFO - 2016-09-14 18:39:04 --> Database Driver Class Initialized
INFO - 2016-09-14 18:39:04 --> Database Driver Class Initialized
INFO - 2016-09-14 18:39:04 --> Final output sent to browser
DEBUG - 2016-09-14 18:39:04 --> Total execution time: 1.5277
INFO - 2016-09-14 18:39:14 --> Config Class Initialized
INFO - 2016-09-14 18:39:14 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:39:14 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:39:14 --> Utf8 Class Initialized
INFO - 2016-09-14 18:39:14 --> URI Class Initialized
INFO - 2016-09-14 18:39:14 --> Router Class Initialized
INFO - 2016-09-14 18:39:14 --> Output Class Initialized
INFO - 2016-09-14 18:39:14 --> Security Class Initialized
DEBUG - 2016-09-14 18:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:39:14 --> Input Class Initialized
INFO - 2016-09-14 18:39:14 --> Language Class Initialized
INFO - 2016-09-14 18:39:14 --> Language Class Initialized
INFO - 2016-09-14 18:39:14 --> Config Class Initialized
INFO - 2016-09-14 18:39:14 --> Loader Class Initialized
INFO - 2016-09-14 18:39:14 --> Helper loaded: url_helper
INFO - 2016-09-14 18:39:14 --> Database Driver Class Initialized
INFO - 2016-09-14 18:39:14 --> Controller Class Initialized
DEBUG - 2016-09-14 18:39:14 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:39:14 --> Model Class Initialized
INFO - 2016-09-14 18:39:14 --> Model Class Initialized
DEBUG - 2016-09-14 18:39:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 18:39:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 18:39:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 18:39:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-14 18:39:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 18:39:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 18:39:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 18:39:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 18:39:15 --> Final output sent to browser
DEBUG - 2016-09-14 18:39:15 --> Total execution time: 1.0740
INFO - 2016-09-14 18:39:19 --> Config Class Initialized
INFO - 2016-09-14 18:39:19 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:39:19 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:39:19 --> Utf8 Class Initialized
INFO - 2016-09-14 18:39:19 --> URI Class Initialized
INFO - 2016-09-14 18:39:19 --> Router Class Initialized
INFO - 2016-09-14 18:39:19 --> Output Class Initialized
INFO - 2016-09-14 18:39:20 --> Security Class Initialized
DEBUG - 2016-09-14 18:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:39:20 --> Input Class Initialized
INFO - 2016-09-14 18:39:20 --> Language Class Initialized
INFO - 2016-09-14 18:39:20 --> Language Class Initialized
INFO - 2016-09-14 18:39:20 --> Config Class Initialized
INFO - 2016-09-14 18:39:20 --> Loader Class Initialized
INFO - 2016-09-14 18:39:20 --> Helper loaded: url_helper
INFO - 2016-09-14 18:39:20 --> Database Driver Class Initialized
INFO - 2016-09-14 18:39:20 --> Controller Class Initialized
DEBUG - 2016-09-14 18:39:20 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:39:20 --> Model Class Initialized
INFO - 2016-09-14 18:39:20 --> Model Class Initialized
DEBUG - 2016-09-14 18:39:20 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 18:39:20 --> Database Driver Class Initialized
INFO - 2016-09-14 18:39:20 --> Final output sent to browser
DEBUG - 2016-09-14 18:39:20 --> Total execution time: 0.8302
INFO - 2016-09-14 18:39:23 --> Config Class Initialized
INFO - 2016-09-14 18:39:23 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:39:23 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:39:23 --> Utf8 Class Initialized
INFO - 2016-09-14 18:39:23 --> URI Class Initialized
INFO - 2016-09-14 18:39:23 --> Router Class Initialized
INFO - 2016-09-14 18:39:23 --> Output Class Initialized
INFO - 2016-09-14 18:39:23 --> Security Class Initialized
DEBUG - 2016-09-14 18:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:39:23 --> Input Class Initialized
INFO - 2016-09-14 18:39:23 --> Language Class Initialized
INFO - 2016-09-14 18:39:23 --> Language Class Initialized
INFO - 2016-09-14 18:39:23 --> Config Class Initialized
INFO - 2016-09-14 18:39:23 --> Loader Class Initialized
INFO - 2016-09-14 18:39:23 --> Helper loaded: url_helper
INFO - 2016-09-14 18:39:23 --> Database Driver Class Initialized
INFO - 2016-09-14 18:39:24 --> Controller Class Initialized
DEBUG - 2016-09-14 18:39:24 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:39:24 --> Model Class Initialized
INFO - 2016-09-14 18:39:24 --> Model Class Initialized
DEBUG - 2016-09-14 18:39:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 18:39:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 18:39:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 18:39:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-09-14 18:39:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 18:39:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 18:39:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 18:39:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 18:39:24 --> Final output sent to browser
DEBUG - 2016-09-14 18:39:24 --> Total execution time: 1.0459
INFO - 2016-09-14 18:39:43 --> Config Class Initialized
INFO - 2016-09-14 18:39:43 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:39:43 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:39:43 --> Utf8 Class Initialized
INFO - 2016-09-14 18:39:43 --> URI Class Initialized
INFO - 2016-09-14 18:39:43 --> Router Class Initialized
INFO - 2016-09-14 18:39:43 --> Output Class Initialized
INFO - 2016-09-14 18:39:43 --> Security Class Initialized
DEBUG - 2016-09-14 18:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:39:43 --> Input Class Initialized
INFO - 2016-09-14 18:39:43 --> Language Class Initialized
INFO - 2016-09-14 18:39:43 --> Language Class Initialized
INFO - 2016-09-14 18:39:43 --> Config Class Initialized
INFO - 2016-09-14 18:39:43 --> Loader Class Initialized
INFO - 2016-09-14 18:39:43 --> Helper loaded: url_helper
INFO - 2016-09-14 18:39:43 --> Database Driver Class Initialized
INFO - 2016-09-14 18:39:43 --> Controller Class Initialized
DEBUG - 2016-09-14 18:39:43 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:39:43 --> Model Class Initialized
INFO - 2016-09-14 18:39:43 --> Model Class Initialized
INFO - 2016-09-14 18:39:44 --> Final output sent to browser
DEBUG - 2016-09-14 18:39:44 --> Total execution time: 0.8578
INFO - 2016-09-14 18:40:14 --> Config Class Initialized
INFO - 2016-09-14 18:40:14 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:40:14 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:40:14 --> Utf8 Class Initialized
INFO - 2016-09-14 18:40:14 --> URI Class Initialized
INFO - 2016-09-14 18:40:14 --> Router Class Initialized
INFO - 2016-09-14 18:40:14 --> Output Class Initialized
INFO - 2016-09-14 18:40:14 --> Security Class Initialized
DEBUG - 2016-09-14 18:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:40:14 --> Input Class Initialized
INFO - 2016-09-14 18:40:14 --> Language Class Initialized
INFO - 2016-09-14 18:40:14 --> Language Class Initialized
INFO - 2016-09-14 18:40:14 --> Config Class Initialized
INFO - 2016-09-14 18:40:14 --> Loader Class Initialized
INFO - 2016-09-14 18:40:14 --> Helper loaded: url_helper
INFO - 2016-09-14 18:40:14 --> Database Driver Class Initialized
INFO - 2016-09-14 18:40:14 --> Controller Class Initialized
DEBUG - 2016-09-14 18:40:14 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:40:15 --> Model Class Initialized
INFO - 2016-09-14 18:40:15 --> Model Class Initialized
DEBUG - 2016-09-14 18:40:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 18:40:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 18:40:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 18:40:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_bayar_angsuran.php
DEBUG - 2016-09-14 18:40:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 18:40:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 18:40:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 18:40:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 18:40:15 --> Final output sent to browser
DEBUG - 2016-09-14 18:40:15 --> Total execution time: 1.0475
INFO - 2016-09-14 18:40:19 --> Config Class Initialized
INFO - 2016-09-14 18:40:19 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:40:19 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:40:19 --> Utf8 Class Initialized
INFO - 2016-09-14 18:40:19 --> URI Class Initialized
INFO - 2016-09-14 18:40:19 --> Router Class Initialized
INFO - 2016-09-14 18:40:19 --> Output Class Initialized
INFO - 2016-09-14 18:40:19 --> Security Class Initialized
DEBUG - 2016-09-14 18:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:40:19 --> Input Class Initialized
INFO - 2016-09-14 18:40:19 --> Language Class Initialized
INFO - 2016-09-14 18:40:19 --> Language Class Initialized
INFO - 2016-09-14 18:40:19 --> Config Class Initialized
INFO - 2016-09-14 18:40:19 --> Loader Class Initialized
INFO - 2016-09-14 18:40:19 --> Helper loaded: url_helper
INFO - 2016-09-14 18:40:19 --> Database Driver Class Initialized
INFO - 2016-09-14 18:40:20 --> Controller Class Initialized
DEBUG - 2016-09-14 18:40:20 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:40:20 --> Model Class Initialized
INFO - 2016-09-14 18:40:20 --> Model Class Initialized
INFO - 2016-09-14 18:40:20 --> Database Driver Class Initialized
INFO - 2016-09-14 18:40:20 --> Final output sent to browser
DEBUG - 2016-09-14 18:40:20 --> Total execution time: 1.0132
INFO - 2016-09-14 18:40:34 --> Config Class Initialized
INFO - 2016-09-14 18:40:34 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:40:34 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:40:34 --> Utf8 Class Initialized
INFO - 2016-09-14 18:40:34 --> URI Class Initialized
INFO - 2016-09-14 18:40:34 --> Router Class Initialized
INFO - 2016-09-14 18:40:34 --> Output Class Initialized
INFO - 2016-09-14 18:40:34 --> Security Class Initialized
DEBUG - 2016-09-14 18:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:40:34 --> Input Class Initialized
INFO - 2016-09-14 18:40:34 --> Language Class Initialized
INFO - 2016-09-14 18:40:34 --> Language Class Initialized
INFO - 2016-09-14 18:40:34 --> Config Class Initialized
INFO - 2016-09-14 18:40:34 --> Loader Class Initialized
INFO - 2016-09-14 18:40:34 --> Helper loaded: url_helper
INFO - 2016-09-14 18:40:34 --> Database Driver Class Initialized
INFO - 2016-09-14 18:40:34 --> Controller Class Initialized
DEBUG - 2016-09-14 18:40:34 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:40:34 --> Model Class Initialized
INFO - 2016-09-14 18:40:34 --> Model Class Initialized
INFO - 2016-09-14 18:40:34 --> Database Driver Class Initialized
INFO - 2016-09-14 18:40:35 --> Final output sent to browser
DEBUG - 2016-09-14 18:40:35 --> Total execution time: 0.8891
INFO - 2016-09-14 18:40:37 --> Config Class Initialized
INFO - 2016-09-14 18:40:37 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:40:37 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:40:37 --> Utf8 Class Initialized
INFO - 2016-09-14 18:40:37 --> URI Class Initialized
INFO - 2016-09-14 18:40:37 --> Router Class Initialized
INFO - 2016-09-14 18:40:37 --> Output Class Initialized
INFO - 2016-09-14 18:40:37 --> Security Class Initialized
DEBUG - 2016-09-14 18:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:40:37 --> Input Class Initialized
INFO - 2016-09-14 18:40:37 --> Language Class Initialized
INFO - 2016-09-14 18:40:37 --> Language Class Initialized
INFO - 2016-09-14 18:40:37 --> Config Class Initialized
INFO - 2016-09-14 18:40:37 --> Loader Class Initialized
INFO - 2016-09-14 18:40:37 --> Helper loaded: url_helper
INFO - 2016-09-14 18:40:38 --> Database Driver Class Initialized
INFO - 2016-09-14 18:40:38 --> Controller Class Initialized
DEBUG - 2016-09-14 18:40:38 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:40:38 --> Model Class Initialized
INFO - 2016-09-14 18:40:38 --> Model Class Initialized
INFO - 2016-09-14 18:40:38 --> Database Driver Class Initialized
INFO - 2016-09-14 18:40:38 --> Final output sent to browser
DEBUG - 2016-09-14 18:40:38 --> Total execution time: 0.7626
INFO - 2016-09-14 18:40:40 --> Config Class Initialized
INFO - 2016-09-14 18:40:40 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:40:40 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:40:40 --> Utf8 Class Initialized
INFO - 2016-09-14 18:40:40 --> URI Class Initialized
INFO - 2016-09-14 18:40:40 --> Router Class Initialized
INFO - 2016-09-14 18:40:40 --> Output Class Initialized
INFO - 2016-09-14 18:40:40 --> Security Class Initialized
DEBUG - 2016-09-14 18:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:40:40 --> Input Class Initialized
INFO - 2016-09-14 18:40:40 --> Language Class Initialized
INFO - 2016-09-14 18:40:40 --> Language Class Initialized
INFO - 2016-09-14 18:40:40 --> Config Class Initialized
INFO - 2016-09-14 18:40:40 --> Loader Class Initialized
INFO - 2016-09-14 18:40:40 --> Helper loaded: url_helper
INFO - 2016-09-14 18:40:40 --> Database Driver Class Initialized
INFO - 2016-09-14 18:40:40 --> Controller Class Initialized
DEBUG - 2016-09-14 18:40:40 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:40:40 --> Model Class Initialized
INFO - 2016-09-14 18:40:40 --> Model Class Initialized
INFO - 2016-09-14 18:40:40 --> Database Driver Class Initialized
INFO - 2016-09-14 18:40:41 --> Final output sent to browser
DEBUG - 2016-09-14 18:40:41 --> Total execution time: 0.8761
INFO - 2016-09-14 18:40:42 --> Config Class Initialized
INFO - 2016-09-14 18:40:42 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:40:42 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:40:42 --> Utf8 Class Initialized
INFO - 2016-09-14 18:40:42 --> URI Class Initialized
INFO - 2016-09-14 18:40:42 --> Router Class Initialized
INFO - 2016-09-14 18:40:42 --> Output Class Initialized
INFO - 2016-09-14 18:40:42 --> Security Class Initialized
DEBUG - 2016-09-14 18:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:40:43 --> Input Class Initialized
INFO - 2016-09-14 18:40:43 --> Language Class Initialized
INFO - 2016-09-14 18:40:43 --> Language Class Initialized
INFO - 2016-09-14 18:40:43 --> Config Class Initialized
INFO - 2016-09-14 18:40:43 --> Loader Class Initialized
INFO - 2016-09-14 18:40:43 --> Helper loaded: url_helper
INFO - 2016-09-14 18:40:43 --> Database Driver Class Initialized
INFO - 2016-09-14 18:40:43 --> Controller Class Initialized
DEBUG - 2016-09-14 18:40:43 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:40:43 --> Model Class Initialized
INFO - 2016-09-14 18:40:43 --> Model Class Initialized
INFO - 2016-09-14 18:40:43 --> Database Driver Class Initialized
INFO - 2016-09-14 18:40:43 --> Final output sent to browser
DEBUG - 2016-09-14 18:40:43 --> Total execution time: 0.7668
INFO - 2016-09-14 18:40:44 --> Config Class Initialized
INFO - 2016-09-14 18:40:44 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:40:45 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:40:45 --> Utf8 Class Initialized
INFO - 2016-09-14 18:40:45 --> URI Class Initialized
INFO - 2016-09-14 18:40:45 --> Router Class Initialized
INFO - 2016-09-14 18:40:45 --> Output Class Initialized
INFO - 2016-09-14 18:40:45 --> Security Class Initialized
DEBUG - 2016-09-14 18:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:40:45 --> Input Class Initialized
INFO - 2016-09-14 18:40:45 --> Language Class Initialized
INFO - 2016-09-14 18:40:45 --> Language Class Initialized
INFO - 2016-09-14 18:40:45 --> Config Class Initialized
INFO - 2016-09-14 18:40:45 --> Loader Class Initialized
INFO - 2016-09-14 18:40:45 --> Helper loaded: url_helper
INFO - 2016-09-14 18:40:45 --> Database Driver Class Initialized
INFO - 2016-09-14 18:40:45 --> Controller Class Initialized
DEBUG - 2016-09-14 18:40:45 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:40:45 --> Model Class Initialized
INFO - 2016-09-14 18:40:45 --> Model Class Initialized
INFO - 2016-09-14 18:40:45 --> Database Driver Class Initialized
INFO - 2016-09-14 18:40:45 --> Final output sent to browser
DEBUG - 2016-09-14 18:40:45 --> Total execution time: 0.9351
INFO - 2016-09-14 18:40:47 --> Config Class Initialized
INFO - 2016-09-14 18:40:47 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:40:47 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:40:47 --> Utf8 Class Initialized
INFO - 2016-09-14 18:40:47 --> URI Class Initialized
INFO - 2016-09-14 18:40:47 --> Router Class Initialized
INFO - 2016-09-14 18:40:47 --> Output Class Initialized
INFO - 2016-09-14 18:40:47 --> Security Class Initialized
DEBUG - 2016-09-14 18:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:40:47 --> Input Class Initialized
INFO - 2016-09-14 18:40:47 --> Language Class Initialized
INFO - 2016-09-14 18:40:47 --> Language Class Initialized
INFO - 2016-09-14 18:40:48 --> Config Class Initialized
INFO - 2016-09-14 18:40:48 --> Loader Class Initialized
INFO - 2016-09-14 18:40:48 --> Helper loaded: url_helper
INFO - 2016-09-14 18:40:48 --> Database Driver Class Initialized
INFO - 2016-09-14 18:40:48 --> Controller Class Initialized
DEBUG - 2016-09-14 18:40:48 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:40:48 --> Model Class Initialized
INFO - 2016-09-14 18:40:48 --> Model Class Initialized
INFO - 2016-09-14 18:40:48 --> Database Driver Class Initialized
INFO - 2016-09-14 18:40:48 --> Final output sent to browser
DEBUG - 2016-09-14 18:40:48 --> Total execution time: 0.7902
INFO - 2016-09-14 18:40:50 --> Config Class Initialized
INFO - 2016-09-14 18:40:50 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:40:50 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:40:50 --> Utf8 Class Initialized
INFO - 2016-09-14 18:40:50 --> URI Class Initialized
INFO - 2016-09-14 18:40:50 --> Router Class Initialized
INFO - 2016-09-14 18:40:50 --> Output Class Initialized
INFO - 2016-09-14 18:40:50 --> Security Class Initialized
DEBUG - 2016-09-14 18:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:40:50 --> Input Class Initialized
INFO - 2016-09-14 18:40:50 --> Language Class Initialized
INFO - 2016-09-14 18:40:50 --> Language Class Initialized
INFO - 2016-09-14 18:40:50 --> Config Class Initialized
INFO - 2016-09-14 18:40:50 --> Loader Class Initialized
INFO - 2016-09-14 18:40:50 --> Helper loaded: url_helper
INFO - 2016-09-14 18:40:50 --> Database Driver Class Initialized
INFO - 2016-09-14 18:40:51 --> Controller Class Initialized
DEBUG - 2016-09-14 18:40:51 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:40:51 --> Model Class Initialized
INFO - 2016-09-14 18:40:51 --> Model Class Initialized
INFO - 2016-09-14 18:40:51 --> Database Driver Class Initialized
INFO - 2016-09-14 18:40:51 --> Final output sent to browser
DEBUG - 2016-09-14 18:40:51 --> Total execution time: 0.8699
INFO - 2016-09-14 18:40:52 --> Config Class Initialized
INFO - 2016-09-14 18:40:53 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:40:53 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:40:53 --> Utf8 Class Initialized
INFO - 2016-09-14 18:40:53 --> URI Class Initialized
INFO - 2016-09-14 18:40:53 --> Router Class Initialized
INFO - 2016-09-14 18:40:53 --> Output Class Initialized
INFO - 2016-09-14 18:40:53 --> Security Class Initialized
DEBUG - 2016-09-14 18:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:40:53 --> Input Class Initialized
INFO - 2016-09-14 18:40:53 --> Language Class Initialized
INFO - 2016-09-14 18:40:53 --> Language Class Initialized
INFO - 2016-09-14 18:40:53 --> Config Class Initialized
INFO - 2016-09-14 18:40:53 --> Loader Class Initialized
INFO - 2016-09-14 18:40:53 --> Helper loaded: url_helper
INFO - 2016-09-14 18:40:53 --> Database Driver Class Initialized
INFO - 2016-09-14 18:40:53 --> Controller Class Initialized
DEBUG - 2016-09-14 18:40:53 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:40:53 --> Model Class Initialized
INFO - 2016-09-14 18:40:53 --> Model Class Initialized
INFO - 2016-09-14 18:40:53 --> Database Driver Class Initialized
INFO - 2016-09-14 18:40:53 --> Final output sent to browser
DEBUG - 2016-09-14 18:40:53 --> Total execution time: 0.8208
INFO - 2016-09-14 18:40:55 --> Config Class Initialized
INFO - 2016-09-14 18:40:55 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:40:55 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:40:55 --> Utf8 Class Initialized
INFO - 2016-09-14 18:40:55 --> URI Class Initialized
INFO - 2016-09-14 18:40:55 --> Router Class Initialized
INFO - 2016-09-14 18:40:55 --> Output Class Initialized
INFO - 2016-09-14 18:40:55 --> Security Class Initialized
DEBUG - 2016-09-14 18:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:40:55 --> Input Class Initialized
INFO - 2016-09-14 18:40:55 --> Language Class Initialized
INFO - 2016-09-14 18:40:55 --> Language Class Initialized
INFO - 2016-09-14 18:40:55 --> Config Class Initialized
INFO - 2016-09-14 18:40:55 --> Loader Class Initialized
INFO - 2016-09-14 18:40:55 --> Helper loaded: url_helper
INFO - 2016-09-14 18:40:55 --> Database Driver Class Initialized
INFO - 2016-09-14 18:40:55 --> Controller Class Initialized
DEBUG - 2016-09-14 18:40:55 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:40:55 --> Model Class Initialized
INFO - 2016-09-14 18:40:55 --> Model Class Initialized
INFO - 2016-09-14 18:40:56 --> Database Driver Class Initialized
INFO - 2016-09-14 18:40:56 --> Final output sent to browser
DEBUG - 2016-09-14 18:40:56 --> Total execution time: 0.9093
INFO - 2016-09-14 18:40:57 --> Config Class Initialized
INFO - 2016-09-14 18:40:57 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:40:57 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:40:57 --> Utf8 Class Initialized
INFO - 2016-09-14 18:40:57 --> URI Class Initialized
INFO - 2016-09-14 18:40:57 --> Router Class Initialized
INFO - 2016-09-14 18:40:57 --> Output Class Initialized
INFO - 2016-09-14 18:40:57 --> Security Class Initialized
DEBUG - 2016-09-14 18:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:40:57 --> Input Class Initialized
INFO - 2016-09-14 18:40:57 --> Language Class Initialized
INFO - 2016-09-14 18:40:57 --> Language Class Initialized
INFO - 2016-09-14 18:40:57 --> Config Class Initialized
INFO - 2016-09-14 18:40:57 --> Loader Class Initialized
INFO - 2016-09-14 18:40:57 --> Helper loaded: url_helper
INFO - 2016-09-14 18:40:57 --> Database Driver Class Initialized
INFO - 2016-09-14 18:40:57 --> Controller Class Initialized
DEBUG - 2016-09-14 18:40:57 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:40:57 --> Model Class Initialized
INFO - 2016-09-14 18:40:57 --> Model Class Initialized
INFO - 2016-09-14 18:40:57 --> Database Driver Class Initialized
INFO - 2016-09-14 18:40:57 --> Final output sent to browser
DEBUG - 2016-09-14 18:40:57 --> Total execution time: 0.7698
INFO - 2016-09-14 18:40:58 --> Config Class Initialized
INFO - 2016-09-14 18:40:58 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:40:58 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:40:58 --> Utf8 Class Initialized
INFO - 2016-09-14 18:40:59 --> URI Class Initialized
INFO - 2016-09-14 18:40:59 --> Router Class Initialized
INFO - 2016-09-14 18:40:59 --> Output Class Initialized
INFO - 2016-09-14 18:40:59 --> Security Class Initialized
DEBUG - 2016-09-14 18:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:40:59 --> Input Class Initialized
INFO - 2016-09-14 18:40:59 --> Language Class Initialized
INFO - 2016-09-14 18:40:59 --> Language Class Initialized
INFO - 2016-09-14 18:40:59 --> Config Class Initialized
INFO - 2016-09-14 18:40:59 --> Loader Class Initialized
INFO - 2016-09-14 18:40:59 --> Helper loaded: url_helper
INFO - 2016-09-14 18:40:59 --> Database Driver Class Initialized
INFO - 2016-09-14 18:40:59 --> Controller Class Initialized
DEBUG - 2016-09-14 18:40:59 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:40:59 --> Model Class Initialized
INFO - 2016-09-14 18:40:59 --> Model Class Initialized
INFO - 2016-09-14 18:40:59 --> Database Driver Class Initialized
INFO - 2016-09-14 18:40:59 --> Final output sent to browser
DEBUG - 2016-09-14 18:40:59 --> Total execution time: 0.8223
INFO - 2016-09-14 18:41:01 --> Config Class Initialized
INFO - 2016-09-14 18:41:01 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:41:01 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:41:01 --> Utf8 Class Initialized
INFO - 2016-09-14 18:41:01 --> URI Class Initialized
INFO - 2016-09-14 18:41:01 --> Router Class Initialized
INFO - 2016-09-14 18:41:01 --> Output Class Initialized
INFO - 2016-09-14 18:41:01 --> Security Class Initialized
DEBUG - 2016-09-14 18:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:41:01 --> Input Class Initialized
INFO - 2016-09-14 18:41:01 --> Language Class Initialized
INFO - 2016-09-14 18:41:01 --> Language Class Initialized
INFO - 2016-09-14 18:41:01 --> Config Class Initialized
INFO - 2016-09-14 18:41:01 --> Loader Class Initialized
INFO - 2016-09-14 18:41:01 --> Helper loaded: url_helper
INFO - 2016-09-14 18:41:01 --> Database Driver Class Initialized
INFO - 2016-09-14 18:41:01 --> Controller Class Initialized
DEBUG - 2016-09-14 18:41:01 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:41:01 --> Model Class Initialized
INFO - 2016-09-14 18:41:01 --> Model Class Initialized
INFO - 2016-09-14 18:41:02 --> Database Driver Class Initialized
INFO - 2016-09-14 18:41:02 --> Final output sent to browser
DEBUG - 2016-09-14 18:41:02 --> Total execution time: 0.7730
INFO - 2016-09-14 18:41:02 --> Config Class Initialized
INFO - 2016-09-14 18:41:02 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:41:02 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:41:02 --> Utf8 Class Initialized
INFO - 2016-09-14 18:41:02 --> URI Class Initialized
INFO - 2016-09-14 18:41:03 --> Router Class Initialized
INFO - 2016-09-14 18:41:03 --> Output Class Initialized
INFO - 2016-09-14 18:41:03 --> Security Class Initialized
DEBUG - 2016-09-14 18:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:41:03 --> Input Class Initialized
INFO - 2016-09-14 18:41:03 --> Language Class Initialized
INFO - 2016-09-14 18:41:03 --> Language Class Initialized
INFO - 2016-09-14 18:41:03 --> Config Class Initialized
INFO - 2016-09-14 18:41:03 --> Loader Class Initialized
INFO - 2016-09-14 18:41:03 --> Helper loaded: url_helper
INFO - 2016-09-14 18:41:03 --> Database Driver Class Initialized
INFO - 2016-09-14 18:41:03 --> Controller Class Initialized
DEBUG - 2016-09-14 18:41:03 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:41:03 --> Model Class Initialized
INFO - 2016-09-14 18:41:03 --> Model Class Initialized
INFO - 2016-09-14 18:41:03 --> Database Driver Class Initialized
INFO - 2016-09-14 18:41:03 --> Final output sent to browser
DEBUG - 2016-09-14 18:41:03 --> Total execution time: 0.9143
INFO - 2016-09-14 18:41:05 --> Config Class Initialized
INFO - 2016-09-14 18:41:05 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:41:05 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:41:05 --> Utf8 Class Initialized
INFO - 2016-09-14 18:41:05 --> URI Class Initialized
INFO - 2016-09-14 18:41:05 --> Router Class Initialized
INFO - 2016-09-14 18:41:05 --> Output Class Initialized
INFO - 2016-09-14 18:41:05 --> Security Class Initialized
DEBUG - 2016-09-14 18:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:41:05 --> Input Class Initialized
INFO - 2016-09-14 18:41:05 --> Language Class Initialized
INFO - 2016-09-14 18:41:05 --> Language Class Initialized
INFO - 2016-09-14 18:41:05 --> Config Class Initialized
INFO - 2016-09-14 18:41:05 --> Loader Class Initialized
INFO - 2016-09-14 18:41:05 --> Helper loaded: url_helper
INFO - 2016-09-14 18:41:06 --> Database Driver Class Initialized
INFO - 2016-09-14 18:41:06 --> Controller Class Initialized
DEBUG - 2016-09-14 18:41:06 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:41:06 --> Model Class Initialized
INFO - 2016-09-14 18:41:06 --> Model Class Initialized
INFO - 2016-09-14 18:41:06 --> Database Driver Class Initialized
INFO - 2016-09-14 18:41:06 --> Final output sent to browser
DEBUG - 2016-09-14 18:41:06 --> Total execution time: 0.8871
INFO - 2016-09-14 18:41:07 --> Config Class Initialized
INFO - 2016-09-14 18:41:07 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:41:07 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:41:07 --> Utf8 Class Initialized
INFO - 2016-09-14 18:41:07 --> URI Class Initialized
INFO - 2016-09-14 18:41:07 --> Router Class Initialized
INFO - 2016-09-14 18:41:07 --> Output Class Initialized
INFO - 2016-09-14 18:41:07 --> Security Class Initialized
DEBUG - 2016-09-14 18:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:41:07 --> Input Class Initialized
INFO - 2016-09-14 18:41:07 --> Language Class Initialized
INFO - 2016-09-14 18:41:07 --> Language Class Initialized
INFO - 2016-09-14 18:41:07 --> Config Class Initialized
INFO - 2016-09-14 18:41:07 --> Loader Class Initialized
INFO - 2016-09-14 18:41:07 --> Helper loaded: url_helper
INFO - 2016-09-14 18:41:07 --> Database Driver Class Initialized
INFO - 2016-09-14 18:41:07 --> Controller Class Initialized
DEBUG - 2016-09-14 18:41:07 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:41:07 --> Model Class Initialized
INFO - 2016-09-14 18:41:07 --> Model Class Initialized
INFO - 2016-09-14 18:41:08 --> Database Driver Class Initialized
INFO - 2016-09-14 18:41:08 --> Final output sent to browser
DEBUG - 2016-09-14 18:41:08 --> Total execution time: 0.8852
INFO - 2016-09-14 18:41:10 --> Config Class Initialized
INFO - 2016-09-14 18:41:10 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:41:10 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:41:10 --> Utf8 Class Initialized
INFO - 2016-09-14 18:41:10 --> URI Class Initialized
INFO - 2016-09-14 18:41:10 --> Router Class Initialized
INFO - 2016-09-14 18:41:10 --> Output Class Initialized
INFO - 2016-09-14 18:41:10 --> Security Class Initialized
DEBUG - 2016-09-14 18:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:41:10 --> Input Class Initialized
INFO - 2016-09-14 18:41:10 --> Language Class Initialized
INFO - 2016-09-14 18:41:10 --> Language Class Initialized
INFO - 2016-09-14 18:41:10 --> Config Class Initialized
INFO - 2016-09-14 18:41:10 --> Loader Class Initialized
INFO - 2016-09-14 18:41:10 --> Helper loaded: url_helper
INFO - 2016-09-14 18:41:10 --> Database Driver Class Initialized
INFO - 2016-09-14 18:41:11 --> Controller Class Initialized
DEBUG - 2016-09-14 18:41:11 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:41:11 --> Model Class Initialized
INFO - 2016-09-14 18:41:11 --> Model Class Initialized
INFO - 2016-09-14 18:41:11 --> Database Driver Class Initialized
INFO - 2016-09-14 18:41:11 --> Final output sent to browser
DEBUG - 2016-09-14 18:41:11 --> Total execution time: 0.7664
INFO - 2016-09-14 18:41:12 --> Config Class Initialized
INFO - 2016-09-14 18:41:12 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:41:12 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:41:12 --> Utf8 Class Initialized
INFO - 2016-09-14 18:41:12 --> URI Class Initialized
INFO - 2016-09-14 18:41:12 --> Router Class Initialized
INFO - 2016-09-14 18:41:12 --> Output Class Initialized
INFO - 2016-09-14 18:41:12 --> Security Class Initialized
DEBUG - 2016-09-14 18:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:41:12 --> Input Class Initialized
INFO - 2016-09-14 18:41:12 --> Language Class Initialized
INFO - 2016-09-14 18:41:12 --> Language Class Initialized
INFO - 2016-09-14 18:41:12 --> Config Class Initialized
INFO - 2016-09-14 18:41:12 --> Loader Class Initialized
INFO - 2016-09-14 18:41:12 --> Helper loaded: url_helper
INFO - 2016-09-14 18:41:12 --> Database Driver Class Initialized
INFO - 2016-09-14 18:41:12 --> Controller Class Initialized
DEBUG - 2016-09-14 18:41:12 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:41:12 --> Model Class Initialized
INFO - 2016-09-14 18:41:12 --> Model Class Initialized
INFO - 2016-09-14 18:41:12 --> Database Driver Class Initialized
INFO - 2016-09-14 18:41:13 --> Final output sent to browser
DEBUG - 2016-09-14 18:41:13 --> Total execution time: 1.1483
INFO - 2016-09-14 18:41:34 --> Config Class Initialized
INFO - 2016-09-14 18:41:34 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:41:34 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:41:35 --> Utf8 Class Initialized
INFO - 2016-09-14 18:41:35 --> URI Class Initialized
INFO - 2016-09-14 18:41:35 --> Router Class Initialized
INFO - 2016-09-14 18:41:35 --> Output Class Initialized
INFO - 2016-09-14 18:41:35 --> Security Class Initialized
DEBUG - 2016-09-14 18:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:41:35 --> Input Class Initialized
INFO - 2016-09-14 18:41:35 --> Language Class Initialized
INFO - 2016-09-14 18:41:35 --> Language Class Initialized
INFO - 2016-09-14 18:41:35 --> Config Class Initialized
INFO - 2016-09-14 18:41:35 --> Loader Class Initialized
INFO - 2016-09-14 18:41:35 --> Helper loaded: url_helper
INFO - 2016-09-14 18:41:35 --> Database Driver Class Initialized
INFO - 2016-09-14 18:41:35 --> Controller Class Initialized
DEBUG - 2016-09-14 18:41:35 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:41:35 --> Model Class Initialized
INFO - 2016-09-14 18:41:35 --> Model Class Initialized
DEBUG - 2016-09-14 18:41:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 18:41:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 18:41:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 18:41:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tutup_angsuran.php
DEBUG - 2016-09-14 18:41:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 18:41:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 18:41:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 18:41:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 18:41:35 --> Final output sent to browser
DEBUG - 2016-09-14 18:41:36 --> Total execution time: 1.0870
INFO - 2016-09-14 18:41:39 --> Config Class Initialized
INFO - 2016-09-14 18:41:39 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:41:39 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:41:39 --> Utf8 Class Initialized
INFO - 2016-09-14 18:41:39 --> URI Class Initialized
INFO - 2016-09-14 18:41:39 --> Router Class Initialized
INFO - 2016-09-14 18:41:39 --> Output Class Initialized
INFO - 2016-09-14 18:41:39 --> Security Class Initialized
DEBUG - 2016-09-14 18:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:41:39 --> Input Class Initialized
INFO - 2016-09-14 18:41:39 --> Language Class Initialized
INFO - 2016-09-14 18:41:39 --> Language Class Initialized
INFO - 2016-09-14 18:41:39 --> Config Class Initialized
INFO - 2016-09-14 18:41:39 --> Loader Class Initialized
INFO - 2016-09-14 18:41:40 --> Helper loaded: url_helper
INFO - 2016-09-14 18:41:40 --> Database Driver Class Initialized
INFO - 2016-09-14 18:41:40 --> Controller Class Initialized
DEBUG - 2016-09-14 18:41:40 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:41:40 --> Model Class Initialized
INFO - 2016-09-14 18:41:40 --> Model Class Initialized
INFO - 2016-09-14 18:41:40 --> Database Driver Class Initialized
INFO - 2016-09-14 18:41:40 --> Final output sent to browser
DEBUG - 2016-09-14 18:41:40 --> Total execution time: 0.8430
INFO - 2016-09-14 18:41:57 --> Config Class Initialized
INFO - 2016-09-14 18:41:57 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:41:57 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:41:57 --> Utf8 Class Initialized
INFO - 2016-09-14 18:41:57 --> URI Class Initialized
INFO - 2016-09-14 18:41:57 --> Router Class Initialized
INFO - 2016-09-14 18:41:57 --> Output Class Initialized
INFO - 2016-09-14 18:41:57 --> Security Class Initialized
DEBUG - 2016-09-14 18:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:41:57 --> Input Class Initialized
INFO - 2016-09-14 18:41:58 --> Language Class Initialized
INFO - 2016-09-14 18:41:58 --> Language Class Initialized
INFO - 2016-09-14 18:41:58 --> Config Class Initialized
INFO - 2016-09-14 18:41:58 --> Loader Class Initialized
INFO - 2016-09-14 18:41:58 --> Helper loaded: url_helper
INFO - 2016-09-14 18:41:58 --> Database Driver Class Initialized
INFO - 2016-09-14 18:41:58 --> Controller Class Initialized
DEBUG - 2016-09-14 18:41:58 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:41:58 --> Model Class Initialized
INFO - 2016-09-14 18:41:58 --> Model Class Initialized
INFO - 2016-09-14 18:41:58 --> Database Driver Class Initialized
INFO - 2016-09-14 18:41:58 --> Database Driver Class Initialized
INFO - 2016-09-14 18:41:58 --> Database Driver Class Initialized
INFO - 2016-09-14 18:41:58 --> Database Driver Class Initialized
INFO - 2016-09-14 18:41:58 --> Final output sent to browser
DEBUG - 2016-09-14 18:41:59 --> Total execution time: 1.3738
INFO - 2016-09-14 18:45:11 --> Config Class Initialized
INFO - 2016-09-14 18:45:11 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:45:11 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:45:11 --> Utf8 Class Initialized
INFO - 2016-09-14 18:45:11 --> URI Class Initialized
INFO - 2016-09-14 18:45:11 --> Router Class Initialized
INFO - 2016-09-14 18:45:11 --> Output Class Initialized
INFO - 2016-09-14 18:45:11 --> Security Class Initialized
DEBUG - 2016-09-14 18:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:45:12 --> Input Class Initialized
INFO - 2016-09-14 18:45:12 --> Language Class Initialized
INFO - 2016-09-14 18:45:12 --> Language Class Initialized
INFO - 2016-09-14 18:45:12 --> Config Class Initialized
INFO - 2016-09-14 18:45:12 --> Loader Class Initialized
INFO - 2016-09-14 18:45:12 --> Helper loaded: url_helper
INFO - 2016-09-14 18:45:12 --> Database Driver Class Initialized
INFO - 2016-09-14 18:45:12 --> Controller Class Initialized
DEBUG - 2016-09-14 18:45:12 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:45:12 --> Model Class Initialized
INFO - 2016-09-14 18:45:12 --> Model Class Initialized
INFO - 2016-09-14 18:45:12 --> Final output sent to browser
DEBUG - 2016-09-14 18:45:12 --> Total execution time: 0.7636
INFO - 2016-09-14 18:45:20 --> Config Class Initialized
INFO - 2016-09-14 18:45:20 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:45:20 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:45:21 --> Utf8 Class Initialized
INFO - 2016-09-14 18:45:21 --> URI Class Initialized
INFO - 2016-09-14 18:45:21 --> Router Class Initialized
INFO - 2016-09-14 18:45:21 --> Output Class Initialized
INFO - 2016-09-14 18:45:21 --> Security Class Initialized
DEBUG - 2016-09-14 18:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:45:21 --> Input Class Initialized
INFO - 2016-09-14 18:45:21 --> Language Class Initialized
INFO - 2016-09-14 18:45:21 --> Language Class Initialized
INFO - 2016-09-14 18:45:21 --> Config Class Initialized
INFO - 2016-09-14 18:45:21 --> Loader Class Initialized
INFO - 2016-09-14 18:45:21 --> Helper loaded: url_helper
INFO - 2016-09-14 18:45:21 --> Database Driver Class Initialized
INFO - 2016-09-14 18:45:21 --> Controller Class Initialized
DEBUG - 2016-09-14 18:45:21 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:45:21 --> Model Class Initialized
INFO - 2016-09-14 18:45:21 --> Model Class Initialized
DEBUG - 2016-09-14 18:45:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 18:45:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 18:45:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 18:45:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-14 18:45:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 18:45:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 18:45:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 18:45:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 18:45:21 --> Final output sent to browser
DEBUG - 2016-09-14 18:45:22 --> Total execution time: 1.0208
INFO - 2016-09-14 18:45:25 --> Config Class Initialized
INFO - 2016-09-14 18:45:25 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:45:25 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:45:25 --> Utf8 Class Initialized
INFO - 2016-09-14 18:45:25 --> URI Class Initialized
INFO - 2016-09-14 18:45:25 --> Router Class Initialized
INFO - 2016-09-14 18:45:26 --> Output Class Initialized
INFO - 2016-09-14 18:45:26 --> Security Class Initialized
DEBUG - 2016-09-14 18:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:45:26 --> Input Class Initialized
INFO - 2016-09-14 18:45:26 --> Language Class Initialized
INFO - 2016-09-14 18:45:26 --> Language Class Initialized
INFO - 2016-09-14 18:45:26 --> Config Class Initialized
INFO - 2016-09-14 18:45:26 --> Loader Class Initialized
INFO - 2016-09-14 18:45:26 --> Helper loaded: url_helper
INFO - 2016-09-14 18:45:26 --> Database Driver Class Initialized
INFO - 2016-09-14 18:45:26 --> Controller Class Initialized
DEBUG - 2016-09-14 18:45:26 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:45:26 --> Model Class Initialized
INFO - 2016-09-14 18:45:26 --> Model Class Initialized
DEBUG - 2016-09-14 18:45:26 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 18:45:26 --> Database Driver Class Initialized
INFO - 2016-09-14 18:45:26 --> Final output sent to browser
DEBUG - 2016-09-14 18:45:26 --> Total execution time: 0.8564
INFO - 2016-09-14 18:46:17 --> Config Class Initialized
INFO - 2016-09-14 18:46:17 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:46:17 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:46:17 --> Utf8 Class Initialized
INFO - 2016-09-14 18:46:17 --> URI Class Initialized
INFO - 2016-09-14 18:46:17 --> Router Class Initialized
INFO - 2016-09-14 18:46:18 --> Output Class Initialized
INFO - 2016-09-14 18:46:18 --> Security Class Initialized
DEBUG - 2016-09-14 18:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:46:18 --> Input Class Initialized
INFO - 2016-09-14 18:46:18 --> Language Class Initialized
INFO - 2016-09-14 18:46:18 --> Language Class Initialized
INFO - 2016-09-14 18:46:18 --> Config Class Initialized
INFO - 2016-09-14 18:46:18 --> Loader Class Initialized
INFO - 2016-09-14 18:46:18 --> Helper loaded: url_helper
INFO - 2016-09-14 18:46:18 --> Database Driver Class Initialized
INFO - 2016-09-14 18:46:18 --> Controller Class Initialized
DEBUG - 2016-09-14 18:46:18 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:46:18 --> Model Class Initialized
INFO - 2016-09-14 18:46:18 --> Model Class Initialized
DEBUG - 2016-09-14 18:46:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 18:46:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 18:46:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 18:46:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-09-14 18:46:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 18:46:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 18:46:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 18:46:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 18:46:18 --> Final output sent to browser
DEBUG - 2016-09-14 18:46:18 --> Total execution time: 1.0545
INFO - 2016-09-14 18:47:58 --> Config Class Initialized
INFO - 2016-09-14 18:47:58 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:47:58 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:47:58 --> Utf8 Class Initialized
INFO - 2016-09-14 18:47:58 --> URI Class Initialized
INFO - 2016-09-14 18:47:58 --> Router Class Initialized
INFO - 2016-09-14 18:47:58 --> Output Class Initialized
INFO - 2016-09-14 18:47:58 --> Security Class Initialized
DEBUG - 2016-09-14 18:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:47:58 --> Input Class Initialized
INFO - 2016-09-14 18:47:58 --> Language Class Initialized
INFO - 2016-09-14 18:47:58 --> Language Class Initialized
INFO - 2016-09-14 18:47:58 --> Config Class Initialized
INFO - 2016-09-14 18:47:58 --> Loader Class Initialized
INFO - 2016-09-14 18:47:58 --> Helper loaded: url_helper
INFO - 2016-09-14 18:47:58 --> Database Driver Class Initialized
INFO - 2016-09-14 18:47:58 --> Controller Class Initialized
DEBUG - 2016-09-14 18:47:58 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:47:58 --> Model Class Initialized
INFO - 2016-09-14 18:47:58 --> Model Class Initialized
INFO - 2016-09-14 18:47:58 --> Final output sent to browser
DEBUG - 2016-09-14 18:47:58 --> Total execution time: 0.7756
INFO - 2016-09-14 18:47:58 --> Config Class Initialized
INFO - 2016-09-14 18:47:59 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:47:59 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:47:59 --> Utf8 Class Initialized
INFO - 2016-09-14 18:47:59 --> URI Class Initialized
INFO - 2016-09-14 18:47:59 --> Router Class Initialized
INFO - 2016-09-14 18:47:59 --> Output Class Initialized
INFO - 2016-09-14 18:47:59 --> Security Class Initialized
DEBUG - 2016-09-14 18:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:47:59 --> Input Class Initialized
INFO - 2016-09-14 18:47:59 --> Language Class Initialized
INFO - 2016-09-14 18:47:59 --> Language Class Initialized
INFO - 2016-09-14 18:47:59 --> Config Class Initialized
INFO - 2016-09-14 18:47:59 --> Loader Class Initialized
INFO - 2016-09-14 18:47:59 --> Helper loaded: url_helper
INFO - 2016-09-14 18:47:59 --> Database Driver Class Initialized
INFO - 2016-09-14 18:47:59 --> Controller Class Initialized
DEBUG - 2016-09-14 18:47:59 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:47:59 --> Model Class Initialized
INFO - 2016-09-14 18:47:59 --> Model Class Initialized
DEBUG - 2016-09-14 18:47:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 18:47:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 18:47:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 18:47:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-14 18:47:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 18:47:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 18:47:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 18:47:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 18:47:59 --> Final output sent to browser
DEBUG - 2016-09-14 18:48:00 --> Total execution time: 1.0090
INFO - 2016-09-14 18:48:04 --> Config Class Initialized
INFO - 2016-09-14 18:48:04 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:48:04 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:48:04 --> Utf8 Class Initialized
INFO - 2016-09-14 18:48:05 --> URI Class Initialized
INFO - 2016-09-14 18:48:05 --> Router Class Initialized
INFO - 2016-09-14 18:48:05 --> Output Class Initialized
INFO - 2016-09-14 18:48:05 --> Security Class Initialized
DEBUG - 2016-09-14 18:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:48:05 --> Input Class Initialized
INFO - 2016-09-14 18:48:05 --> Language Class Initialized
INFO - 2016-09-14 18:48:05 --> Language Class Initialized
INFO - 2016-09-14 18:48:05 --> Config Class Initialized
INFO - 2016-09-14 18:48:05 --> Loader Class Initialized
INFO - 2016-09-14 18:48:05 --> Helper loaded: url_helper
INFO - 2016-09-14 18:48:05 --> Database Driver Class Initialized
INFO - 2016-09-14 18:48:05 --> Controller Class Initialized
DEBUG - 2016-09-14 18:48:05 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:48:05 --> Model Class Initialized
INFO - 2016-09-14 18:48:05 --> Model Class Initialized
DEBUG - 2016-09-14 18:48:05 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 18:48:05 --> Database Driver Class Initialized
INFO - 2016-09-14 18:48:05 --> Final output sent to browser
DEBUG - 2016-09-14 18:48:05 --> Total execution time: 0.8311
INFO - 2016-09-14 18:48:06 --> Config Class Initialized
INFO - 2016-09-14 18:48:06 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:48:06 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:48:06 --> Utf8 Class Initialized
INFO - 2016-09-14 18:48:06 --> URI Class Initialized
INFO - 2016-09-14 18:48:06 --> Router Class Initialized
INFO - 2016-09-14 18:48:06 --> Output Class Initialized
INFO - 2016-09-14 18:48:06 --> Security Class Initialized
DEBUG - 2016-09-14 18:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:48:06 --> Input Class Initialized
INFO - 2016-09-14 18:48:07 --> Language Class Initialized
INFO - 2016-09-14 18:48:07 --> Language Class Initialized
INFO - 2016-09-14 18:48:07 --> Config Class Initialized
INFO - 2016-09-14 18:48:07 --> Loader Class Initialized
INFO - 2016-09-14 18:48:07 --> Helper loaded: url_helper
INFO - 2016-09-14 18:48:07 --> Database Driver Class Initialized
INFO - 2016-09-14 18:48:07 --> Controller Class Initialized
DEBUG - 2016-09-14 18:48:07 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:48:07 --> Model Class Initialized
INFO - 2016-09-14 18:48:07 --> Model Class Initialized
DEBUG - 2016-09-14 18:48:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 18:48:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 18:48:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 18:48:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_umum.php
DEBUG - 2016-09-14 18:48:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 18:48:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 18:48:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 18:48:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 18:48:07 --> Final output sent to browser
DEBUG - 2016-09-14 18:48:07 --> Total execution time: 1.1173
INFO - 2016-09-14 18:48:28 --> Config Class Initialized
INFO - 2016-09-14 18:48:28 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:48:28 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:48:28 --> Utf8 Class Initialized
INFO - 2016-09-14 18:48:28 --> URI Class Initialized
INFO - 2016-09-14 18:48:28 --> Router Class Initialized
INFO - 2016-09-14 18:48:28 --> Output Class Initialized
INFO - 2016-09-14 18:48:28 --> Security Class Initialized
DEBUG - 2016-09-14 18:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:48:28 --> Input Class Initialized
INFO - 2016-09-14 18:48:28 --> Language Class Initialized
INFO - 2016-09-14 18:48:28 --> Language Class Initialized
INFO - 2016-09-14 18:48:28 --> Config Class Initialized
INFO - 2016-09-14 18:48:28 --> Loader Class Initialized
INFO - 2016-09-14 18:48:28 --> Helper loaded: url_helper
INFO - 2016-09-14 18:48:28 --> Database Driver Class Initialized
INFO - 2016-09-14 18:48:28 --> Controller Class Initialized
DEBUG - 2016-09-14 18:48:28 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:48:28 --> Model Class Initialized
INFO - 2016-09-14 18:48:28 --> Model Class Initialized
INFO - 2016-09-14 18:48:28 --> Final output sent to browser
DEBUG - 2016-09-14 18:48:28 --> Total execution time: 0.7675
INFO - 2016-09-14 18:48:29 --> Config Class Initialized
INFO - 2016-09-14 18:48:29 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:48:29 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:48:29 --> Utf8 Class Initialized
INFO - 2016-09-14 18:48:29 --> URI Class Initialized
INFO - 2016-09-14 18:48:29 --> Router Class Initialized
INFO - 2016-09-14 18:48:29 --> Output Class Initialized
INFO - 2016-09-14 18:48:29 --> Security Class Initialized
DEBUG - 2016-09-14 18:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:48:29 --> Input Class Initialized
INFO - 2016-09-14 18:48:29 --> Language Class Initialized
INFO - 2016-09-14 18:48:29 --> Language Class Initialized
INFO - 2016-09-14 18:48:29 --> Config Class Initialized
INFO - 2016-09-14 18:48:29 --> Loader Class Initialized
INFO - 2016-09-14 18:48:29 --> Helper loaded: url_helper
INFO - 2016-09-14 18:48:29 --> Database Driver Class Initialized
INFO - 2016-09-14 18:48:29 --> Controller Class Initialized
DEBUG - 2016-09-14 18:48:29 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:48:29 --> Model Class Initialized
INFO - 2016-09-14 18:48:29 --> Model Class Initialized
DEBUG - 2016-09-14 18:48:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 18:48:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 18:48:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 18:48:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-14 18:48:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 18:48:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 18:48:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 18:48:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 18:48:30 --> Final output sent to browser
DEBUG - 2016-09-14 18:48:30 --> Total execution time: 1.1635
INFO - 2016-09-14 18:48:34 --> Config Class Initialized
INFO - 2016-09-14 18:48:34 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:48:34 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:48:34 --> Utf8 Class Initialized
INFO - 2016-09-14 18:48:34 --> URI Class Initialized
INFO - 2016-09-14 18:48:34 --> Router Class Initialized
INFO - 2016-09-14 18:48:34 --> Output Class Initialized
INFO - 2016-09-14 18:48:34 --> Security Class Initialized
DEBUG - 2016-09-14 18:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:48:34 --> Input Class Initialized
INFO - 2016-09-14 18:48:34 --> Language Class Initialized
INFO - 2016-09-14 18:48:34 --> Language Class Initialized
INFO - 2016-09-14 18:48:34 --> Config Class Initialized
INFO - 2016-09-14 18:48:34 --> Loader Class Initialized
INFO - 2016-09-14 18:48:34 --> Helper loaded: url_helper
INFO - 2016-09-14 18:48:34 --> Database Driver Class Initialized
INFO - 2016-09-14 18:48:34 --> Controller Class Initialized
DEBUG - 2016-09-14 18:48:34 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:48:34 --> Model Class Initialized
INFO - 2016-09-14 18:48:34 --> Model Class Initialized
DEBUG - 2016-09-14 18:48:34 --> Anggota MX_Controller Initialized
INFO - 2016-09-14 18:48:34 --> Database Driver Class Initialized
INFO - 2016-09-14 18:48:34 --> Final output sent to browser
DEBUG - 2016-09-14 18:48:34 --> Total execution time: 0.8225
INFO - 2016-09-14 18:48:35 --> Config Class Initialized
INFO - 2016-09-14 18:48:35 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:48:35 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:48:35 --> Utf8 Class Initialized
INFO - 2016-09-14 18:48:35 --> URI Class Initialized
INFO - 2016-09-14 18:48:35 --> Router Class Initialized
INFO - 2016-09-14 18:48:36 --> Output Class Initialized
INFO - 2016-09-14 18:48:36 --> Security Class Initialized
DEBUG - 2016-09-14 18:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:48:36 --> Input Class Initialized
INFO - 2016-09-14 18:48:36 --> Language Class Initialized
INFO - 2016-09-14 18:48:36 --> Language Class Initialized
INFO - 2016-09-14 18:48:36 --> Config Class Initialized
INFO - 2016-09-14 18:48:36 --> Loader Class Initialized
INFO - 2016-09-14 18:48:36 --> Helper loaded: url_helper
INFO - 2016-09-14 18:48:36 --> Database Driver Class Initialized
INFO - 2016-09-14 18:48:36 --> Controller Class Initialized
DEBUG - 2016-09-14 18:48:36 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:48:36 --> Model Class Initialized
INFO - 2016-09-14 18:48:36 --> Model Class Initialized
DEBUG - 2016-09-14 18:48:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 18:48:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 18:48:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 18:48:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/step_umum.php
DEBUG - 2016-09-14 18:48:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 18:48:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 18:48:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 18:48:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 18:48:36 --> Final output sent to browser
DEBUG - 2016-09-14 18:48:36 --> Total execution time: 1.0717
INFO - 2016-09-14 18:48:52 --> Config Class Initialized
INFO - 2016-09-14 18:48:52 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:48:52 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:48:52 --> Utf8 Class Initialized
INFO - 2016-09-14 18:48:52 --> URI Class Initialized
INFO - 2016-09-14 18:48:52 --> Router Class Initialized
INFO - 2016-09-14 18:48:53 --> Output Class Initialized
INFO - 2016-09-14 18:48:53 --> Security Class Initialized
DEBUG - 2016-09-14 18:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:48:53 --> Input Class Initialized
INFO - 2016-09-14 18:48:53 --> Language Class Initialized
INFO - 2016-09-14 18:48:53 --> Language Class Initialized
INFO - 2016-09-14 18:48:53 --> Config Class Initialized
INFO - 2016-09-14 18:48:53 --> Loader Class Initialized
INFO - 2016-09-14 18:48:53 --> Helper loaded: url_helper
INFO - 2016-09-14 18:48:53 --> Database Driver Class Initialized
INFO - 2016-09-14 18:48:53 --> Controller Class Initialized
DEBUG - 2016-09-14 18:48:53 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:48:53 --> Model Class Initialized
INFO - 2016-09-14 18:48:53 --> Model Class Initialized
INFO - 2016-09-14 18:48:53 --> Final output sent to browser
DEBUG - 2016-09-14 18:48:53 --> Total execution time: 1.0533
INFO - 2016-09-14 18:50:41 --> Config Class Initialized
INFO - 2016-09-14 18:50:41 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:50:42 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:50:42 --> Utf8 Class Initialized
INFO - 2016-09-14 18:50:42 --> URI Class Initialized
INFO - 2016-09-14 18:50:42 --> Router Class Initialized
INFO - 2016-09-14 18:50:42 --> Output Class Initialized
INFO - 2016-09-14 18:50:42 --> Security Class Initialized
DEBUG - 2016-09-14 18:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:50:42 --> Input Class Initialized
INFO - 2016-09-14 18:50:42 --> Language Class Initialized
INFO - 2016-09-14 18:50:42 --> Language Class Initialized
INFO - 2016-09-14 18:50:42 --> Config Class Initialized
INFO - 2016-09-14 18:50:42 --> Loader Class Initialized
INFO - 2016-09-14 18:50:42 --> Helper loaded: url_helper
INFO - 2016-09-14 18:50:42 --> Database Driver Class Initialized
INFO - 2016-09-14 18:50:42 --> Controller Class Initialized
DEBUG - 2016-09-14 18:50:42 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:50:42 --> Model Class Initialized
INFO - 2016-09-14 18:50:42 --> Model Class Initialized
DEBUG - 2016-09-14 18:50:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 18:50:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 18:50:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 18:50:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-14 18:50:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 18:50:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 18:50:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 18:50:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 18:50:43 --> Final output sent to browser
DEBUG - 2016-09-14 18:50:43 --> Total execution time: 1.1916
INFO - 2016-09-14 18:51:22 --> Config Class Initialized
INFO - 2016-09-14 18:51:22 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:51:22 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:51:22 --> Utf8 Class Initialized
INFO - 2016-09-14 18:51:22 --> URI Class Initialized
INFO - 2016-09-14 18:51:22 --> Router Class Initialized
INFO - 2016-09-14 18:51:22 --> Output Class Initialized
INFO - 2016-09-14 18:51:23 --> Security Class Initialized
DEBUG - 2016-09-14 18:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:51:23 --> Input Class Initialized
INFO - 2016-09-14 18:51:23 --> Language Class Initialized
INFO - 2016-09-14 18:51:23 --> Language Class Initialized
INFO - 2016-09-14 18:51:23 --> Config Class Initialized
INFO - 2016-09-14 18:51:23 --> Loader Class Initialized
INFO - 2016-09-14 18:51:23 --> Helper loaded: url_helper
INFO - 2016-09-14 18:51:23 --> Database Driver Class Initialized
INFO - 2016-09-14 18:51:23 --> Controller Class Initialized
DEBUG - 2016-09-14 18:51:23 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:51:23 --> Model Class Initialized
INFO - 2016-09-14 18:51:23 --> Model Class Initialized
DEBUG - 2016-09-14 18:51:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 18:51:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 18:51:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 18:51:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_bayar_angsuran.php
DEBUG - 2016-09-14 18:51:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 18:51:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 18:51:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 18:51:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 18:51:23 --> Final output sent to browser
DEBUG - 2016-09-14 18:51:23 --> Total execution time: 1.0555
INFO - 2016-09-14 18:51:35 --> Config Class Initialized
INFO - 2016-09-14 18:51:35 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:51:35 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:51:35 --> Utf8 Class Initialized
INFO - 2016-09-14 18:51:35 --> URI Class Initialized
INFO - 2016-09-14 18:51:35 --> Router Class Initialized
INFO - 2016-09-14 18:51:35 --> Output Class Initialized
INFO - 2016-09-14 18:51:36 --> Security Class Initialized
DEBUG - 2016-09-14 18:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:51:36 --> Input Class Initialized
INFO - 2016-09-14 18:51:36 --> Language Class Initialized
INFO - 2016-09-14 18:51:36 --> Language Class Initialized
INFO - 2016-09-14 18:51:36 --> Config Class Initialized
INFO - 2016-09-14 18:51:36 --> Loader Class Initialized
INFO - 2016-09-14 18:51:36 --> Helper loaded: url_helper
INFO - 2016-09-14 18:51:36 --> Database Driver Class Initialized
INFO - 2016-09-14 18:51:36 --> Controller Class Initialized
DEBUG - 2016-09-14 18:51:36 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:51:36 --> Model Class Initialized
INFO - 2016-09-14 18:51:36 --> Model Class Initialized
DEBUG - 2016-09-14 18:51:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 18:51:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 18:51:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 18:51:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tutup_angsuran.php
DEBUG - 2016-09-14 18:51:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 18:51:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 18:51:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 18:51:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 18:51:36 --> Final output sent to browser
DEBUG - 2016-09-14 18:51:36 --> Total execution time: 1.0675
INFO - 2016-09-14 18:52:14 --> Config Class Initialized
INFO - 2016-09-14 18:52:14 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:52:14 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:52:14 --> Utf8 Class Initialized
INFO - 2016-09-14 18:52:14 --> URI Class Initialized
INFO - 2016-09-14 18:52:14 --> Router Class Initialized
INFO - 2016-09-14 18:52:14 --> Output Class Initialized
INFO - 2016-09-14 18:52:14 --> Security Class Initialized
DEBUG - 2016-09-14 18:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:52:15 --> Input Class Initialized
INFO - 2016-09-14 18:52:15 --> Language Class Initialized
INFO - 2016-09-14 18:52:15 --> Language Class Initialized
INFO - 2016-09-14 18:52:15 --> Config Class Initialized
INFO - 2016-09-14 18:52:15 --> Loader Class Initialized
INFO - 2016-09-14 18:52:15 --> Helper loaded: url_helper
INFO - 2016-09-14 18:52:15 --> Database Driver Class Initialized
INFO - 2016-09-14 18:52:15 --> Controller Class Initialized
DEBUG - 2016-09-14 18:52:15 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:52:15 --> Model Class Initialized
INFO - 2016-09-14 18:52:15 --> Model Class Initialized
DEBUG - 2016-09-14 18:52:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 18:52:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 18:52:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 18:52:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tutup_angsuran.php
DEBUG - 2016-09-14 18:52:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 18:52:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 18:52:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 18:52:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 18:52:15 --> Final output sent to browser
DEBUG - 2016-09-14 18:52:15 --> Total execution time: 1.0761
INFO - 2016-09-14 18:52:19 --> Config Class Initialized
INFO - 2016-09-14 18:52:19 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:52:19 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:52:19 --> Utf8 Class Initialized
INFO - 2016-09-14 18:52:19 --> URI Class Initialized
INFO - 2016-09-14 18:52:19 --> Router Class Initialized
INFO - 2016-09-14 18:52:19 --> Output Class Initialized
INFO - 2016-09-14 18:52:19 --> Security Class Initialized
DEBUG - 2016-09-14 18:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:52:19 --> Input Class Initialized
INFO - 2016-09-14 18:52:19 --> Language Class Initialized
INFO - 2016-09-14 18:52:19 --> Language Class Initialized
INFO - 2016-09-14 18:52:19 --> Config Class Initialized
INFO - 2016-09-14 18:52:19 --> Loader Class Initialized
INFO - 2016-09-14 18:52:19 --> Helper loaded: url_helper
INFO - 2016-09-14 18:52:19 --> Database Driver Class Initialized
INFO - 2016-09-14 18:52:19 --> Controller Class Initialized
DEBUG - 2016-09-14 18:52:19 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:52:19 --> Model Class Initialized
INFO - 2016-09-14 18:52:19 --> Model Class Initialized
DEBUG - 2016-09-14 18:52:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 18:52:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 18:52:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 18:52:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_bayar_angsuran.php
DEBUG - 2016-09-14 18:52:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 18:52:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 18:52:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 18:52:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 18:52:20 --> Final output sent to browser
DEBUG - 2016-09-14 18:52:20 --> Total execution time: 1.0621
INFO - 2016-09-14 18:52:23 --> Config Class Initialized
INFO - 2016-09-14 18:52:23 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:52:23 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:52:23 --> Utf8 Class Initialized
INFO - 2016-09-14 18:52:23 --> URI Class Initialized
INFO - 2016-09-14 18:52:23 --> Router Class Initialized
INFO - 2016-09-14 18:52:23 --> Output Class Initialized
INFO - 2016-09-14 18:52:23 --> Security Class Initialized
DEBUG - 2016-09-14 18:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:52:23 --> Input Class Initialized
INFO - 2016-09-14 18:52:23 --> Language Class Initialized
INFO - 2016-09-14 18:52:23 --> Language Class Initialized
INFO - 2016-09-14 18:52:23 --> Config Class Initialized
INFO - 2016-09-14 18:52:23 --> Loader Class Initialized
INFO - 2016-09-14 18:52:23 --> Helper loaded: url_helper
INFO - 2016-09-14 18:52:23 --> Database Driver Class Initialized
INFO - 2016-09-14 18:52:23 --> Controller Class Initialized
DEBUG - 2016-09-14 18:52:23 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:52:23 --> Model Class Initialized
INFO - 2016-09-14 18:52:23 --> Model Class Initialized
DEBUG - 2016-09-14 18:52:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 18:52:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 18:52:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 18:52:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-14 18:52:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 18:52:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 18:52:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 18:52:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 18:52:24 --> Final output sent to browser
DEBUG - 2016-09-14 18:52:24 --> Total execution time: 1.0654
INFO - 2016-09-14 18:52:44 --> Config Class Initialized
INFO - 2016-09-14 18:52:44 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:52:44 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:52:44 --> Utf8 Class Initialized
INFO - 2016-09-14 18:52:44 --> URI Class Initialized
INFO - 2016-09-14 18:52:44 --> Router Class Initialized
INFO - 2016-09-14 18:52:44 --> Output Class Initialized
INFO - 2016-09-14 18:52:44 --> Security Class Initialized
DEBUG - 2016-09-14 18:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:52:44 --> Input Class Initialized
INFO - 2016-09-14 18:52:44 --> Language Class Initialized
INFO - 2016-09-14 18:52:44 --> Language Class Initialized
INFO - 2016-09-14 18:52:45 --> Config Class Initialized
INFO - 2016-09-14 18:52:45 --> Loader Class Initialized
INFO - 2016-09-14 18:52:45 --> Helper loaded: url_helper
INFO - 2016-09-14 18:52:45 --> Database Driver Class Initialized
INFO - 2016-09-14 18:52:45 --> Controller Class Initialized
DEBUG - 2016-09-14 18:52:45 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:52:45 --> Model Class Initialized
INFO - 2016-09-14 18:52:45 --> Model Class Initialized
DEBUG - 2016-09-14 18:52:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 18:52:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 18:52:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 18:52:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_bayar_angsuran.php
DEBUG - 2016-09-14 18:52:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 18:52:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 18:52:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 18:52:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 18:52:45 --> Final output sent to browser
DEBUG - 2016-09-14 18:52:45 --> Total execution time: 1.0547
INFO - 2016-09-14 18:52:49 --> Config Class Initialized
INFO - 2016-09-14 18:52:49 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:52:49 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:52:49 --> Utf8 Class Initialized
INFO - 2016-09-14 18:52:49 --> URI Class Initialized
INFO - 2016-09-14 18:52:49 --> Router Class Initialized
INFO - 2016-09-14 18:52:49 --> Output Class Initialized
INFO - 2016-09-14 18:52:49 --> Security Class Initialized
DEBUG - 2016-09-14 18:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:52:49 --> Input Class Initialized
INFO - 2016-09-14 18:52:49 --> Language Class Initialized
INFO - 2016-09-14 18:52:49 --> Language Class Initialized
INFO - 2016-09-14 18:52:49 --> Config Class Initialized
INFO - 2016-09-14 18:52:49 --> Loader Class Initialized
INFO - 2016-09-14 18:52:49 --> Helper loaded: url_helper
INFO - 2016-09-14 18:52:49 --> Database Driver Class Initialized
INFO - 2016-09-14 18:52:49 --> Controller Class Initialized
DEBUG - 2016-09-14 18:52:49 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:52:49 --> Model Class Initialized
INFO - 2016-09-14 18:52:49 --> Model Class Initialized
DEBUG - 2016-09-14 18:52:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 18:52:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 18:52:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 18:52:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_tutup_angsuran.php
DEBUG - 2016-09-14 18:52:49 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 18:52:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 18:52:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 18:52:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 18:52:50 --> Final output sent to browser
DEBUG - 2016-09-14 18:52:50 --> Total execution time: 1.1138
INFO - 2016-09-14 18:53:04 --> Config Class Initialized
INFO - 2016-09-14 18:53:04 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:53:04 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:53:04 --> Utf8 Class Initialized
INFO - 2016-09-14 18:53:04 --> URI Class Initialized
INFO - 2016-09-14 18:53:04 --> Router Class Initialized
INFO - 2016-09-14 18:53:04 --> Output Class Initialized
INFO - 2016-09-14 18:53:04 --> Security Class Initialized
DEBUG - 2016-09-14 18:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:53:05 --> Input Class Initialized
INFO - 2016-09-14 18:53:05 --> Language Class Initialized
INFO - 2016-09-14 18:53:05 --> Language Class Initialized
INFO - 2016-09-14 18:53:05 --> Config Class Initialized
INFO - 2016-09-14 18:53:05 --> Loader Class Initialized
INFO - 2016-09-14 18:53:05 --> Helper loaded: url_helper
INFO - 2016-09-14 18:53:05 --> Database Driver Class Initialized
INFO - 2016-09-14 18:53:05 --> Controller Class Initialized
DEBUG - 2016-09-14 18:53:05 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:53:05 --> Model Class Initialized
INFO - 2016-09-14 18:53:05 --> Model Class Initialized
DEBUG - 2016-09-14 18:53:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 18:53:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 18:53:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 18:53:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_bayar_angsuran.php
DEBUG - 2016-09-14 18:53:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 18:53:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 18:53:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 18:53:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 18:53:05 --> Final output sent to browser
DEBUG - 2016-09-14 18:53:05 --> Total execution time: 1.1044
INFO - 2016-09-14 18:53:09 --> Config Class Initialized
INFO - 2016-09-14 18:53:09 --> Hooks Class Initialized
DEBUG - 2016-09-14 18:53:09 --> UTF-8 Support Enabled
INFO - 2016-09-14 18:53:09 --> Utf8 Class Initialized
INFO - 2016-09-14 18:53:09 --> URI Class Initialized
INFO - 2016-09-14 18:53:09 --> Router Class Initialized
INFO - 2016-09-14 18:53:09 --> Output Class Initialized
INFO - 2016-09-14 18:53:09 --> Security Class Initialized
DEBUG - 2016-09-14 18:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-14 18:53:09 --> Input Class Initialized
INFO - 2016-09-14 18:53:09 --> Language Class Initialized
INFO - 2016-09-14 18:53:09 --> Language Class Initialized
INFO - 2016-09-14 18:53:10 --> Config Class Initialized
INFO - 2016-09-14 18:53:10 --> Loader Class Initialized
INFO - 2016-09-14 18:53:10 --> Helper loaded: url_helper
INFO - 2016-09-14 18:53:10 --> Database Driver Class Initialized
INFO - 2016-09-14 18:53:10 --> Controller Class Initialized
DEBUG - 2016-09-14 18:53:10 --> Index MX_Controller Initialized
INFO - 2016-09-14 18:53:10 --> Model Class Initialized
INFO - 2016-09-14 18:53:10 --> Model Class Initialized
DEBUG - 2016-09-14 18:53:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-14 18:53:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-14 18:53:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-14 18:53:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-09-14 18:53:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-14 18:53:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-14 18:53:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-14 18:53:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-14 18:53:10 --> Final output sent to browser
DEBUG - 2016-09-14 18:53:10 --> Total execution time: 1.1512
