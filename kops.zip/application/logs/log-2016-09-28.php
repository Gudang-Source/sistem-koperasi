<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-09-28 00:03:52 --> Config Class Initialized
INFO - 2016-09-28 00:03:52 --> Hooks Class Initialized
DEBUG - 2016-09-28 00:03:52 --> UTF-8 Support Enabled
INFO - 2016-09-28 00:03:52 --> Utf8 Class Initialized
INFO - 2016-09-28 00:03:52 --> URI Class Initialized
DEBUG - 2016-09-28 00:03:52 --> No URI present. Default controller set.
INFO - 2016-09-28 00:03:52 --> Router Class Initialized
INFO - 2016-09-28 00:03:52 --> Output Class Initialized
INFO - 2016-09-28 00:03:52 --> Security Class Initialized
DEBUG - 2016-09-28 00:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 00:03:52 --> Input Class Initialized
INFO - 2016-09-28 00:03:52 --> Language Class Initialized
INFO - 2016-09-28 00:03:52 --> Language Class Initialized
INFO - 2016-09-28 00:03:52 --> Config Class Initialized
INFO - 2016-09-28 00:03:52 --> Loader Class Initialized
INFO - 2016-09-28 00:03:52 --> Helper loaded: url_helper
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-28 00:03:52 --> Controller Class Initialized
DEBUG - 2016-09-28 00:03:52 --> Index MX_Controller Initialized
INFO - 2016-09-28 00:03:52 --> Model Class Initialized
INFO - 2016-09-28 00:03:52 --> Model Class Initialized
ERROR - 2016-09-28 00:03:52 --> Unable to delete cache file for 
DEBUG - 2016-09-28 00:03:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-28 00:03:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-28 00:03:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-28 00:03:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-28 00:03:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-28 00:03:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
INFO - 2016-09-28 00:03:52 --> Database Driver Class Initialized
DEBUG - 2016-09-28 00:03:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-28 00:03:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-28 00:03:52 --> Final output sent to browser
DEBUG - 2016-09-28 00:03:52 --> Total execution time: 0.1475
INFO - 2016-09-28 00:03:53 --> Config Class Initialized
INFO - 2016-09-28 00:03:53 --> Hooks Class Initialized
DEBUG - 2016-09-28 00:03:53 --> UTF-8 Support Enabled
INFO - 2016-09-28 00:03:53 --> Utf8 Class Initialized
INFO - 2016-09-28 00:03:53 --> URI Class Initialized
INFO - 2016-09-28 00:03:53 --> Router Class Initialized
INFO - 2016-09-28 00:03:53 --> Output Class Initialized
INFO - 2016-09-28 00:03:53 --> Security Class Initialized
DEBUG - 2016-09-28 00:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 00:03:53 --> Input Class Initialized
INFO - 2016-09-28 00:03:53 --> Language Class Initialized
ERROR - 2016-09-28 00:03:53 --> 404 Page Not Found: /index
INFO - 2016-09-28 00:03:53 --> Config Class Initialized
INFO - 2016-09-28 00:03:53 --> Hooks Class Initialized
DEBUG - 2016-09-28 00:03:53 --> UTF-8 Support Enabled
INFO - 2016-09-28 00:03:53 --> Utf8 Class Initialized
INFO - 2016-09-28 00:03:53 --> URI Class Initialized
INFO - 2016-09-28 00:03:53 --> Router Class Initialized
INFO - 2016-09-28 00:03:53 --> Output Class Initialized
INFO - 2016-09-28 00:03:53 --> Security Class Initialized
DEBUG - 2016-09-28 00:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 00:03:53 --> Input Class Initialized
INFO - 2016-09-28 00:03:53 --> Language Class Initialized
ERROR - 2016-09-28 00:03:53 --> 404 Page Not Found: /index
INFO - 2016-09-28 00:03:54 --> Config Class Initialized
INFO - 2016-09-28 00:03:54 --> Hooks Class Initialized
DEBUG - 2016-09-28 00:03:54 --> UTF-8 Support Enabled
INFO - 2016-09-28 00:03:54 --> Utf8 Class Initialized
INFO - 2016-09-28 00:03:54 --> URI Class Initialized
INFO - 2016-09-28 00:03:54 --> Router Class Initialized
INFO - 2016-09-28 00:03:54 --> Output Class Initialized
INFO - 2016-09-28 00:03:54 --> Security Class Initialized
DEBUG - 2016-09-28 00:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 00:03:54 --> Input Class Initialized
INFO - 2016-09-28 00:03:54 --> Language Class Initialized
ERROR - 2016-09-28 00:03:54 --> 404 Page Not Found: /index
INFO - 2016-09-28 00:03:54 --> Config Class Initialized
INFO - 2016-09-28 00:03:54 --> Hooks Class Initialized
DEBUG - 2016-09-28 00:03:54 --> UTF-8 Support Enabled
INFO - 2016-09-28 00:03:54 --> Utf8 Class Initialized
INFO - 2016-09-28 00:03:54 --> URI Class Initialized
INFO - 2016-09-28 00:03:54 --> Router Class Initialized
INFO - 2016-09-28 00:03:54 --> Output Class Initialized
INFO - 2016-09-28 00:03:54 --> Security Class Initialized
DEBUG - 2016-09-28 00:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 00:03:54 --> Input Class Initialized
INFO - 2016-09-28 00:03:54 --> Language Class Initialized
ERROR - 2016-09-28 00:03:54 --> 404 Page Not Found: /index
INFO - 2016-09-28 00:03:55 --> Config Class Initialized
INFO - 2016-09-28 00:03:55 --> Hooks Class Initialized
DEBUG - 2016-09-28 00:03:55 --> UTF-8 Support Enabled
INFO - 2016-09-28 00:03:55 --> Utf8 Class Initialized
INFO - 2016-09-28 00:03:55 --> URI Class Initialized
INFO - 2016-09-28 00:03:55 --> Router Class Initialized
INFO - 2016-09-28 00:03:55 --> Output Class Initialized
INFO - 2016-09-28 00:03:55 --> Security Class Initialized
DEBUG - 2016-09-28 00:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 00:03:55 --> Input Class Initialized
INFO - 2016-09-28 00:03:55 --> Language Class Initialized
ERROR - 2016-09-28 00:03:55 --> 404 Page Not Found: /index
INFO - 2016-09-28 00:03:56 --> Config Class Initialized
INFO - 2016-09-28 00:03:56 --> Hooks Class Initialized
DEBUG - 2016-09-28 00:03:56 --> UTF-8 Support Enabled
INFO - 2016-09-28 00:03:56 --> Utf8 Class Initialized
INFO - 2016-09-28 00:03:56 --> URI Class Initialized
INFO - 2016-09-28 00:03:56 --> Router Class Initialized
INFO - 2016-09-28 00:03:56 --> Output Class Initialized
INFO - 2016-09-28 00:03:56 --> Security Class Initialized
DEBUG - 2016-09-28 00:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 00:03:56 --> Input Class Initialized
INFO - 2016-09-28 00:03:56 --> Language Class Initialized
ERROR - 2016-09-28 00:03:56 --> 404 Page Not Found: /index
INFO - 2016-09-28 00:03:56 --> Config Class Initialized
INFO - 2016-09-28 00:03:56 --> Hooks Class Initialized
DEBUG - 2016-09-28 00:03:56 --> UTF-8 Support Enabled
INFO - 2016-09-28 00:03:56 --> Utf8 Class Initialized
INFO - 2016-09-28 00:03:56 --> URI Class Initialized
INFO - 2016-09-28 00:03:56 --> Router Class Initialized
INFO - 2016-09-28 00:03:56 --> Output Class Initialized
INFO - 2016-09-28 00:03:56 --> Security Class Initialized
DEBUG - 2016-09-28 00:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 00:03:56 --> Input Class Initialized
INFO - 2016-09-28 00:03:56 --> Language Class Initialized
ERROR - 2016-09-28 00:03:56 --> 404 Page Not Found: /index
INFO - 2016-09-28 00:03:57 --> Config Class Initialized
INFO - 2016-09-28 00:03:57 --> Hooks Class Initialized
DEBUG - 2016-09-28 00:03:57 --> UTF-8 Support Enabled
INFO - 2016-09-28 00:03:57 --> Utf8 Class Initialized
INFO - 2016-09-28 00:03:57 --> URI Class Initialized
INFO - 2016-09-28 00:03:57 --> Router Class Initialized
INFO - 2016-09-28 00:03:57 --> Output Class Initialized
INFO - 2016-09-28 00:03:57 --> Security Class Initialized
DEBUG - 2016-09-28 00:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 00:03:57 --> Input Class Initialized
INFO - 2016-09-28 00:03:57 --> Language Class Initialized
ERROR - 2016-09-28 00:03:57 --> 404 Page Not Found: /index
INFO - 2016-09-28 00:03:58 --> Config Class Initialized
INFO - 2016-09-28 00:03:58 --> Hooks Class Initialized
DEBUG - 2016-09-28 00:03:58 --> UTF-8 Support Enabled
INFO - 2016-09-28 00:03:58 --> Utf8 Class Initialized
INFO - 2016-09-28 00:03:58 --> URI Class Initialized
INFO - 2016-09-28 00:03:58 --> Router Class Initialized
INFO - 2016-09-28 00:03:58 --> Output Class Initialized
INFO - 2016-09-28 00:03:58 --> Security Class Initialized
DEBUG - 2016-09-28 00:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 00:03:58 --> Input Class Initialized
INFO - 2016-09-28 00:03:58 --> Language Class Initialized
ERROR - 2016-09-28 00:03:58 --> 404 Page Not Found: /index
INFO - 2016-09-28 00:03:58 --> Config Class Initialized
INFO - 2016-09-28 00:03:58 --> Hooks Class Initialized
DEBUG - 2016-09-28 00:03:58 --> UTF-8 Support Enabled
INFO - 2016-09-28 00:03:58 --> Utf8 Class Initialized
INFO - 2016-09-28 00:03:58 --> URI Class Initialized
INFO - 2016-09-28 00:03:58 --> Router Class Initialized
INFO - 2016-09-28 00:03:58 --> Output Class Initialized
INFO - 2016-09-28 00:03:58 --> Security Class Initialized
DEBUG - 2016-09-28 00:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 00:03:58 --> Input Class Initialized
INFO - 2016-09-28 00:03:58 --> Language Class Initialized
ERROR - 2016-09-28 00:03:58 --> 404 Page Not Found: /index
INFO - 2016-09-28 00:03:59 --> Config Class Initialized
INFO - 2016-09-28 00:03:59 --> Hooks Class Initialized
DEBUG - 2016-09-28 00:03:59 --> UTF-8 Support Enabled
INFO - 2016-09-28 00:03:59 --> Utf8 Class Initialized
INFO - 2016-09-28 00:03:59 --> URI Class Initialized
INFO - 2016-09-28 00:03:59 --> Router Class Initialized
INFO - 2016-09-28 00:03:59 --> Output Class Initialized
INFO - 2016-09-28 00:03:59 --> Security Class Initialized
DEBUG - 2016-09-28 00:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 00:03:59 --> Input Class Initialized
INFO - 2016-09-28 00:03:59 --> Language Class Initialized
ERROR - 2016-09-28 00:03:59 --> 404 Page Not Found: /index
INFO - 2016-09-28 00:03:59 --> Config Class Initialized
INFO - 2016-09-28 00:03:59 --> Hooks Class Initialized
DEBUG - 2016-09-28 00:03:59 --> UTF-8 Support Enabled
INFO - 2016-09-28 00:03:59 --> Utf8 Class Initialized
INFO - 2016-09-28 00:03:59 --> URI Class Initialized
INFO - 2016-09-28 00:03:59 --> Router Class Initialized
INFO - 2016-09-28 00:03:59 --> Output Class Initialized
INFO - 2016-09-28 00:03:59 --> Security Class Initialized
DEBUG - 2016-09-28 00:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 00:03:59 --> Input Class Initialized
INFO - 2016-09-28 00:03:59 --> Language Class Initialized
ERROR - 2016-09-28 00:03:59 --> 404 Page Not Found: /index
INFO - 2016-09-28 00:04:00 --> Config Class Initialized
INFO - 2016-09-28 00:04:00 --> Hooks Class Initialized
DEBUG - 2016-09-28 00:04:00 --> UTF-8 Support Enabled
INFO - 2016-09-28 00:04:00 --> Utf8 Class Initialized
INFO - 2016-09-28 00:04:00 --> URI Class Initialized
INFO - 2016-09-28 00:04:00 --> Router Class Initialized
INFO - 2016-09-28 00:04:00 --> Output Class Initialized
INFO - 2016-09-28 00:04:00 --> Security Class Initialized
DEBUG - 2016-09-28 00:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 00:04:00 --> Input Class Initialized
INFO - 2016-09-28 00:04:00 --> Language Class Initialized
ERROR - 2016-09-28 00:04:00 --> 404 Page Not Found: /index
INFO - 2016-09-28 03:16:01 --> Config Class Initialized
INFO - 2016-09-28 03:16:01 --> Hooks Class Initialized
DEBUG - 2016-09-28 03:16:01 --> UTF-8 Support Enabled
INFO - 2016-09-28 03:16:01 --> Utf8 Class Initialized
INFO - 2016-09-28 03:16:01 --> URI Class Initialized
DEBUG - 2016-09-28 03:16:01 --> No URI present. Default controller set.
INFO - 2016-09-28 03:16:01 --> Router Class Initialized
INFO - 2016-09-28 03:16:01 --> Output Class Initialized
INFO - 2016-09-28 03:16:01 --> Security Class Initialized
DEBUG - 2016-09-28 03:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 03:16:01 --> Input Class Initialized
INFO - 2016-09-28 03:16:01 --> Language Class Initialized
INFO - 2016-09-28 03:16:01 --> Language Class Initialized
INFO - 2016-09-28 03:16:01 --> Config Class Initialized
INFO - 2016-09-28 03:16:01 --> Loader Class Initialized
INFO - 2016-09-28 03:16:01 --> Helper loaded: url_helper
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-28 03:16:01 --> Controller Class Initialized
DEBUG - 2016-09-28 03:16:01 --> Index MX_Controller Initialized
INFO - 2016-09-28 03:16:01 --> Model Class Initialized
INFO - 2016-09-28 03:16:01 --> Model Class Initialized
ERROR - 2016-09-28 03:16:01 --> Unable to delete cache file for 
DEBUG - 2016-09-28 03:16:01 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-28 03:16:01 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-28 03:16:01 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-28 03:16:01 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-28 03:16:01 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-28 03:16:01 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:01 --> Database Driver Class Initialized
DEBUG - 2016-09-28 03:16:01 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-28 03:16:01 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-28 03:16:01 --> Final output sent to browser
DEBUG - 2016-09-28 03:16:01 --> Total execution time: 0.3639
INFO - 2016-09-28 03:16:02 --> Config Class Initialized
INFO - 2016-09-28 03:16:02 --> Hooks Class Initialized
DEBUG - 2016-09-28 03:16:02 --> UTF-8 Support Enabled
INFO - 2016-09-28 03:16:02 --> Utf8 Class Initialized
INFO - 2016-09-28 03:16:02 --> URI Class Initialized
INFO - 2016-09-28 03:16:02 --> Router Class Initialized
INFO - 2016-09-28 03:16:02 --> Output Class Initialized
INFO - 2016-09-28 03:16:02 --> Security Class Initialized
DEBUG - 2016-09-28 03:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 03:16:02 --> Input Class Initialized
INFO - 2016-09-28 03:16:02 --> Language Class Initialized
INFO - 2016-09-28 03:16:02 --> Language Class Initialized
INFO - 2016-09-28 03:16:02 --> Config Class Initialized
INFO - 2016-09-28 03:16:02 --> Loader Class Initialized
INFO - 2016-09-28 03:16:02 --> Helper loaded: url_helper
INFO - 2016-09-28 03:16:02 --> Database Driver Class Initialized
INFO - 2016-09-28 03:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-28 03:16:02 --> Controller Class Initialized
DEBUG - 2016-09-28 03:16:02 --> login MX_Controller Initialized
INFO - 2016-09-28 03:16:02 --> Model Class Initialized
INFO - 2016-09-28 03:16:02 --> Model Class Initialized
DEBUG - 2016-09-28 03:16:02 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-28 03:16:02 --> Final output sent to browser
DEBUG - 2016-09-28 03:16:02 --> Total execution time: 0.0358
INFO - 2016-09-28 04:55:26 --> Config Class Initialized
INFO - 2016-09-28 04:55:26 --> Hooks Class Initialized
DEBUG - 2016-09-28 04:55:26 --> UTF-8 Support Enabled
INFO - 2016-09-28 04:55:26 --> Utf8 Class Initialized
INFO - 2016-09-28 04:55:26 --> URI Class Initialized
INFO - 2016-09-28 04:55:26 --> Router Class Initialized
INFO - 2016-09-28 04:55:26 --> Output Class Initialized
INFO - 2016-09-28 04:55:26 --> Security Class Initialized
DEBUG - 2016-09-28 04:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 04:55:26 --> Input Class Initialized
INFO - 2016-09-28 04:55:26 --> Language Class Initialized
INFO - 2016-09-28 04:55:26 --> Language Class Initialized
INFO - 2016-09-28 04:55:26 --> Config Class Initialized
INFO - 2016-09-28 04:55:26 --> Loader Class Initialized
INFO - 2016-09-28 04:55:26 --> Helper loaded: url_helper
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-28 04:55:26 --> Controller Class Initialized
DEBUG - 2016-09-28 04:55:26 --> Index MX_Controller Initialized
INFO - 2016-09-28 04:55:26 --> Model Class Initialized
INFO - 2016-09-28 04:55:26 --> Model Class Initialized
ERROR - 2016-09-28 04:55:26 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-28 04:55:26 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-28 04:55:26 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-28 04:55:26 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-28 04:55:26 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-28 04:55:26 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-28 04:55:26 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
DEBUG - 2016-09-28 04:55:26 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-28 04:55:26 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-28 04:55:26 --> Final output sent to browser
DEBUG - 2016-09-28 04:55:26 --> Total execution time: 0.0981
INFO - 2016-09-28 04:55:26 --> Config Class Initialized
INFO - 2016-09-28 04:55:26 --> Hooks Class Initialized
DEBUG - 2016-09-28 04:55:26 --> UTF-8 Support Enabled
INFO - 2016-09-28 04:55:26 --> Utf8 Class Initialized
INFO - 2016-09-28 04:55:26 --> URI Class Initialized
INFO - 2016-09-28 04:55:26 --> Router Class Initialized
INFO - 2016-09-28 04:55:26 --> Output Class Initialized
INFO - 2016-09-28 04:55:26 --> Security Class Initialized
DEBUG - 2016-09-28 04:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 04:55:26 --> Input Class Initialized
INFO - 2016-09-28 04:55:26 --> Language Class Initialized
INFO - 2016-09-28 04:55:26 --> Language Class Initialized
INFO - 2016-09-28 04:55:26 --> Config Class Initialized
INFO - 2016-09-28 04:55:26 --> Loader Class Initialized
INFO - 2016-09-28 04:55:26 --> Helper loaded: url_helper
INFO - 2016-09-28 04:55:26 --> Database Driver Class Initialized
INFO - 2016-09-28 04:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-28 04:55:26 --> Controller Class Initialized
DEBUG - 2016-09-28 04:55:26 --> login MX_Controller Initialized
INFO - 2016-09-28 04:55:26 --> Model Class Initialized
INFO - 2016-09-28 04:55:26 --> Model Class Initialized
DEBUG - 2016-09-28 04:55:26 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-28 04:55:26 --> Final output sent to browser
DEBUG - 2016-09-28 04:55:26 --> Total execution time: 0.0226
INFO - 2016-09-28 05:27:36 --> Config Class Initialized
INFO - 2016-09-28 05:27:36 --> Hooks Class Initialized
DEBUG - 2016-09-28 05:27:36 --> UTF-8 Support Enabled
INFO - 2016-09-28 05:27:36 --> Utf8 Class Initialized
INFO - 2016-09-28 05:27:36 --> URI Class Initialized
DEBUG - 2016-09-28 05:27:36 --> No URI present. Default controller set.
INFO - 2016-09-28 05:27:36 --> Router Class Initialized
INFO - 2016-09-28 05:27:36 --> Output Class Initialized
INFO - 2016-09-28 05:27:36 --> Security Class Initialized
DEBUG - 2016-09-28 05:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 05:27:36 --> Input Class Initialized
INFO - 2016-09-28 05:27:36 --> Language Class Initialized
INFO - 2016-09-28 05:27:36 --> Language Class Initialized
INFO - 2016-09-28 05:27:36 --> Config Class Initialized
INFO - 2016-09-28 05:27:36 --> Loader Class Initialized
INFO - 2016-09-28 05:27:36 --> Helper loaded: url_helper
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-28 05:27:36 --> Controller Class Initialized
DEBUG - 2016-09-28 05:27:36 --> Index MX_Controller Initialized
INFO - 2016-09-28 05:27:36 --> Model Class Initialized
INFO - 2016-09-28 05:27:36 --> Model Class Initialized
ERROR - 2016-09-28 05:27:36 --> Unable to delete cache file for 
DEBUG - 2016-09-28 05:27:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-28 05:27:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-28 05:27:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-28 05:27:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-28 05:27:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-28 05:27:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
DEBUG - 2016-09-28 05:27:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-28 05:27:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-28 05:27:36 --> Final output sent to browser
DEBUG - 2016-09-28 05:27:36 --> Total execution time: 0.1160
INFO - 2016-09-28 05:27:36 --> Config Class Initialized
INFO - 2016-09-28 05:27:36 --> Hooks Class Initialized
DEBUG - 2016-09-28 05:27:36 --> UTF-8 Support Enabled
INFO - 2016-09-28 05:27:36 --> Utf8 Class Initialized
INFO - 2016-09-28 05:27:36 --> URI Class Initialized
INFO - 2016-09-28 05:27:36 --> Router Class Initialized
INFO - 2016-09-28 05:27:36 --> Output Class Initialized
INFO - 2016-09-28 05:27:36 --> Security Class Initialized
DEBUG - 2016-09-28 05:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 05:27:36 --> Input Class Initialized
INFO - 2016-09-28 05:27:36 --> Language Class Initialized
INFO - 2016-09-28 05:27:36 --> Language Class Initialized
INFO - 2016-09-28 05:27:36 --> Config Class Initialized
INFO - 2016-09-28 05:27:36 --> Loader Class Initialized
INFO - 2016-09-28 05:27:36 --> Helper loaded: url_helper
INFO - 2016-09-28 05:27:36 --> Database Driver Class Initialized
INFO - 2016-09-28 05:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-28 05:27:36 --> Controller Class Initialized
DEBUG - 2016-09-28 05:27:36 --> login MX_Controller Initialized
INFO - 2016-09-28 05:27:36 --> Model Class Initialized
INFO - 2016-09-28 05:27:36 --> Model Class Initialized
DEBUG - 2016-09-28 05:27:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-28 05:27:36 --> Final output sent to browser
DEBUG - 2016-09-28 05:27:36 --> Total execution time: 0.0335
INFO - 2016-09-28 05:27:37 --> Config Class Initialized
INFO - 2016-09-28 05:27:37 --> Hooks Class Initialized
DEBUG - 2016-09-28 05:27:37 --> UTF-8 Support Enabled
INFO - 2016-09-28 05:27:37 --> Utf8 Class Initialized
INFO - 2016-09-28 05:27:37 --> URI Class Initialized
INFO - 2016-09-28 05:27:37 --> Router Class Initialized
INFO - 2016-09-28 05:27:37 --> Output Class Initialized
INFO - 2016-09-28 05:27:37 --> Security Class Initialized
DEBUG - 2016-09-28 05:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 05:27:37 --> Input Class Initialized
INFO - 2016-09-28 05:27:37 --> Language Class Initialized
ERROR - 2016-09-28 05:27:37 --> 404 Page Not Found: /index
INFO - 2016-09-28 05:43:42 --> Config Class Initialized
INFO - 2016-09-28 05:43:42 --> Hooks Class Initialized
DEBUG - 2016-09-28 05:43:42 --> UTF-8 Support Enabled
INFO - 2016-09-28 05:43:42 --> Utf8 Class Initialized
INFO - 2016-09-28 05:43:42 --> URI Class Initialized
DEBUG - 2016-09-28 05:43:42 --> No URI present. Default controller set.
INFO - 2016-09-28 05:43:42 --> Router Class Initialized
INFO - 2016-09-28 05:43:42 --> Output Class Initialized
INFO - 2016-09-28 05:43:42 --> Security Class Initialized
DEBUG - 2016-09-28 05:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 05:43:42 --> Input Class Initialized
INFO - 2016-09-28 05:43:42 --> Language Class Initialized
INFO - 2016-09-28 05:43:42 --> Language Class Initialized
INFO - 2016-09-28 05:43:42 --> Config Class Initialized
INFO - 2016-09-28 05:43:42 --> Loader Class Initialized
INFO - 2016-09-28 05:43:42 --> Helper loaded: url_helper
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-28 05:43:42 --> Controller Class Initialized
DEBUG - 2016-09-28 05:43:42 --> Index MX_Controller Initialized
INFO - 2016-09-28 05:43:42 --> Model Class Initialized
INFO - 2016-09-28 05:43:42 --> Model Class Initialized
ERROR - 2016-09-28 05:43:42 --> Unable to delete cache file for 
DEBUG - 2016-09-28 05:43:42 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-28 05:43:42 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-28 05:43:42 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-28 05:43:42 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-28 05:43:42 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-28 05:43:42 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
DEBUG - 2016-09-28 05:43:42 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-28 05:43:42 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-28 05:43:42 --> Final output sent to browser
DEBUG - 2016-09-28 05:43:42 --> Total execution time: 0.1116
INFO - 2016-09-28 05:43:42 --> Config Class Initialized
INFO - 2016-09-28 05:43:42 --> Hooks Class Initialized
DEBUG - 2016-09-28 05:43:42 --> UTF-8 Support Enabled
INFO - 2016-09-28 05:43:42 --> Utf8 Class Initialized
INFO - 2016-09-28 05:43:42 --> URI Class Initialized
INFO - 2016-09-28 05:43:42 --> Router Class Initialized
INFO - 2016-09-28 05:43:42 --> Output Class Initialized
INFO - 2016-09-28 05:43:42 --> Security Class Initialized
DEBUG - 2016-09-28 05:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 05:43:42 --> Input Class Initialized
INFO - 2016-09-28 05:43:42 --> Language Class Initialized
INFO - 2016-09-28 05:43:42 --> Language Class Initialized
INFO - 2016-09-28 05:43:42 --> Config Class Initialized
INFO - 2016-09-28 05:43:42 --> Loader Class Initialized
INFO - 2016-09-28 05:43:42 --> Helper loaded: url_helper
INFO - 2016-09-28 05:43:42 --> Database Driver Class Initialized
INFO - 2016-09-28 05:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-28 05:43:42 --> Controller Class Initialized
DEBUG - 2016-09-28 05:43:42 --> login MX_Controller Initialized
INFO - 2016-09-28 05:43:42 --> Model Class Initialized
INFO - 2016-09-28 05:43:42 --> Model Class Initialized
DEBUG - 2016-09-28 05:43:42 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-28 05:43:42 --> Final output sent to browser
DEBUG - 2016-09-28 05:43:42 --> Total execution time: 0.0220
INFO - 2016-09-28 09:17:22 --> Config Class Initialized
INFO - 2016-09-28 09:17:22 --> Hooks Class Initialized
DEBUG - 2016-09-28 09:17:22 --> UTF-8 Support Enabled
INFO - 2016-09-28 09:17:22 --> Utf8 Class Initialized
INFO - 2016-09-28 09:17:22 --> URI Class Initialized
DEBUG - 2016-09-28 09:17:22 --> No URI present. Default controller set.
INFO - 2016-09-28 09:17:22 --> Router Class Initialized
INFO - 2016-09-28 09:17:22 --> Output Class Initialized
INFO - 2016-09-28 09:17:22 --> Security Class Initialized
DEBUG - 2016-09-28 09:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 09:17:22 --> Input Class Initialized
INFO - 2016-09-28 09:17:22 --> Language Class Initialized
INFO - 2016-09-28 09:17:22 --> Language Class Initialized
INFO - 2016-09-28 09:17:22 --> Config Class Initialized
INFO - 2016-09-28 09:17:22 --> Loader Class Initialized
INFO - 2016-09-28 09:17:22 --> Helper loaded: url_helper
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-28 09:17:22 --> Controller Class Initialized
DEBUG - 2016-09-28 09:17:22 --> Index MX_Controller Initialized
INFO - 2016-09-28 09:17:22 --> Model Class Initialized
INFO - 2016-09-28 09:17:22 --> Model Class Initialized
ERROR - 2016-09-28 09:17:22 --> Unable to delete cache file for 
DEBUG - 2016-09-28 09:17:22 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-28 09:17:22 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-28 09:17:22 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-28 09:17:22 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-28 09:17:22 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-28 09:17:22 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
DEBUG - 2016-09-28 09:17:22 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-28 09:17:22 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-28 09:17:22 --> Final output sent to browser
DEBUG - 2016-09-28 09:17:22 --> Total execution time: 0.1516
INFO - 2016-09-28 09:17:22 --> Config Class Initialized
INFO - 2016-09-28 09:17:22 --> Hooks Class Initialized
DEBUG - 2016-09-28 09:17:22 --> UTF-8 Support Enabled
INFO - 2016-09-28 09:17:22 --> Utf8 Class Initialized
INFO - 2016-09-28 09:17:22 --> URI Class Initialized
INFO - 2016-09-28 09:17:22 --> Router Class Initialized
INFO - 2016-09-28 09:17:22 --> Output Class Initialized
INFO - 2016-09-28 09:17:22 --> Security Class Initialized
DEBUG - 2016-09-28 09:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 09:17:22 --> Input Class Initialized
INFO - 2016-09-28 09:17:22 --> Language Class Initialized
INFO - 2016-09-28 09:17:22 --> Language Class Initialized
INFO - 2016-09-28 09:17:22 --> Config Class Initialized
INFO - 2016-09-28 09:17:22 --> Loader Class Initialized
INFO - 2016-09-28 09:17:22 --> Helper loaded: url_helper
INFO - 2016-09-28 09:17:22 --> Database Driver Class Initialized
INFO - 2016-09-28 09:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-28 09:17:22 --> Controller Class Initialized
DEBUG - 2016-09-28 09:17:22 --> login MX_Controller Initialized
INFO - 2016-09-28 09:17:22 --> Model Class Initialized
INFO - 2016-09-28 09:17:22 --> Model Class Initialized
DEBUG - 2016-09-28 09:17:22 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-28 09:17:22 --> Final output sent to browser
DEBUG - 2016-09-28 09:17:22 --> Total execution time: 0.0256
INFO - 2016-09-28 14:37:10 --> Config Class Initialized
INFO - 2016-09-28 14:37:10 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:37:10 --> UTF-8 Support Enabled
INFO - 2016-09-28 14:37:10 --> Utf8 Class Initialized
INFO - 2016-09-28 14:37:10 --> URI Class Initialized
DEBUG - 2016-09-28 14:37:10 --> No URI present. Default controller set.
INFO - 2016-09-28 14:37:10 --> Router Class Initialized
INFO - 2016-09-28 14:37:10 --> Output Class Initialized
INFO - 2016-09-28 14:37:10 --> Security Class Initialized
DEBUG - 2016-09-28 14:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 14:37:10 --> Input Class Initialized
INFO - 2016-09-28 14:37:10 --> Language Class Initialized
INFO - 2016-09-28 14:37:10 --> Language Class Initialized
INFO - 2016-09-28 14:37:10 --> Config Class Initialized
INFO - 2016-09-28 14:37:10 --> Loader Class Initialized
INFO - 2016-09-28 14:37:10 --> Helper loaded: url_helper
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-28 14:37:10 --> Controller Class Initialized
DEBUG - 2016-09-28 14:37:10 --> Index MX_Controller Initialized
INFO - 2016-09-28 14:37:10 --> Model Class Initialized
INFO - 2016-09-28 14:37:10 --> Model Class Initialized
ERROR - 2016-09-28 14:37:10 --> Unable to delete cache file for 
DEBUG - 2016-09-28 14:37:10 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-28 14:37:10 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-28 14:37:10 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-28 14:37:10 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-28 14:37:10 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-28 14:37:10 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:10 --> Database Driver Class Initialized
DEBUG - 2016-09-28 14:37:10 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-28 14:37:10 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-28 14:37:10 --> Final output sent to browser
DEBUG - 2016-09-28 14:37:10 --> Total execution time: 0.1389
INFO - 2016-09-28 14:37:11 --> Config Class Initialized
INFO - 2016-09-28 14:37:11 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:37:11 --> UTF-8 Support Enabled
INFO - 2016-09-28 14:37:11 --> Utf8 Class Initialized
INFO - 2016-09-28 14:37:11 --> URI Class Initialized
INFO - 2016-09-28 14:37:11 --> Router Class Initialized
INFO - 2016-09-28 14:37:11 --> Output Class Initialized
INFO - 2016-09-28 14:37:11 --> Security Class Initialized
DEBUG - 2016-09-28 14:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 14:37:11 --> Input Class Initialized
INFO - 2016-09-28 14:37:11 --> Language Class Initialized
INFO - 2016-09-28 14:37:11 --> Language Class Initialized
INFO - 2016-09-28 14:37:11 --> Config Class Initialized
INFO - 2016-09-28 14:37:11 --> Loader Class Initialized
INFO - 2016-09-28 14:37:11 --> Helper loaded: url_helper
INFO - 2016-09-28 14:37:11 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-28 14:37:11 --> Controller Class Initialized
DEBUG - 2016-09-28 14:37:11 --> login MX_Controller Initialized
INFO - 2016-09-28 14:37:11 --> Model Class Initialized
INFO - 2016-09-28 14:37:11 --> Model Class Initialized
DEBUG - 2016-09-28 14:37:11 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-28 14:37:11 --> Final output sent to browser
DEBUG - 2016-09-28 14:37:11 --> Total execution time: 0.0250
INFO - 2016-09-28 14:37:22 --> Config Class Initialized
INFO - 2016-09-28 14:37:22 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:37:22 --> UTF-8 Support Enabled
INFO - 2016-09-28 14:37:22 --> Utf8 Class Initialized
INFO - 2016-09-28 14:37:22 --> URI Class Initialized
DEBUG - 2016-09-28 14:37:22 --> No URI present. Default controller set.
INFO - 2016-09-28 14:37:22 --> Router Class Initialized
INFO - 2016-09-28 14:37:22 --> Output Class Initialized
INFO - 2016-09-28 14:37:22 --> Security Class Initialized
DEBUG - 2016-09-28 14:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 14:37:22 --> Input Class Initialized
INFO - 2016-09-28 14:37:22 --> Language Class Initialized
INFO - 2016-09-28 14:37:22 --> Language Class Initialized
INFO - 2016-09-28 14:37:22 --> Config Class Initialized
INFO - 2016-09-28 14:37:22 --> Loader Class Initialized
INFO - 2016-09-28 14:37:22 --> Helper loaded: url_helper
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-28 14:37:22 --> Controller Class Initialized
DEBUG - 2016-09-28 14:37:22 --> Index MX_Controller Initialized
INFO - 2016-09-28 14:37:22 --> Model Class Initialized
INFO - 2016-09-28 14:37:22 --> Model Class Initialized
ERROR - 2016-09-28 14:37:22 --> Unable to delete cache file for 
DEBUG - 2016-09-28 14:37:22 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-28 14:37:22 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-28 14:37:22 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-28 14:37:22 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-28 14:37:22 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-28 14:37:22 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:22 --> Database Driver Class Initialized
DEBUG - 2016-09-28 14:37:22 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-28 14:37:22 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-28 14:37:22 --> Final output sent to browser
DEBUG - 2016-09-28 14:37:22 --> Total execution time: 0.1336
INFO - 2016-09-28 14:37:23 --> Config Class Initialized
INFO - 2016-09-28 14:37:23 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:37:23 --> UTF-8 Support Enabled
INFO - 2016-09-28 14:37:23 --> Utf8 Class Initialized
INFO - 2016-09-28 14:37:23 --> URI Class Initialized
INFO - 2016-09-28 14:37:23 --> Router Class Initialized
INFO - 2016-09-28 14:37:23 --> Output Class Initialized
INFO - 2016-09-28 14:37:23 --> Security Class Initialized
DEBUG - 2016-09-28 14:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 14:37:23 --> Input Class Initialized
INFO - 2016-09-28 14:37:23 --> Language Class Initialized
INFO - 2016-09-28 14:37:23 --> Language Class Initialized
INFO - 2016-09-28 14:37:23 --> Config Class Initialized
INFO - 2016-09-28 14:37:23 --> Loader Class Initialized
INFO - 2016-09-28 14:37:23 --> Helper loaded: url_helper
INFO - 2016-09-28 14:37:23 --> Database Driver Class Initialized
INFO - 2016-09-28 14:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-28 14:37:23 --> Controller Class Initialized
DEBUG - 2016-09-28 14:37:23 --> login MX_Controller Initialized
INFO - 2016-09-28 14:37:23 --> Model Class Initialized
INFO - 2016-09-28 14:37:23 --> Model Class Initialized
DEBUG - 2016-09-28 14:37:23 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-28 14:37:23 --> Final output sent to browser
DEBUG - 2016-09-28 14:37:23 --> Total execution time: 0.0245
INFO - 2016-09-28 15:25:08 --> Config Class Initialized
INFO - 2016-09-28 15:25:08 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:25:08 --> UTF-8 Support Enabled
INFO - 2016-09-28 15:25:08 --> Utf8 Class Initialized
INFO - 2016-09-28 15:25:08 --> URI Class Initialized
DEBUG - 2016-09-28 15:25:08 --> No URI present. Default controller set.
INFO - 2016-09-28 15:25:08 --> Router Class Initialized
INFO - 2016-09-28 15:25:08 --> Output Class Initialized
INFO - 2016-09-28 15:25:08 --> Security Class Initialized
DEBUG - 2016-09-28 15:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 15:25:08 --> Input Class Initialized
INFO - 2016-09-28 15:25:08 --> Language Class Initialized
INFO - 2016-09-28 15:25:08 --> Language Class Initialized
INFO - 2016-09-28 15:25:08 --> Config Class Initialized
INFO - 2016-09-28 15:25:08 --> Loader Class Initialized
INFO - 2016-09-28 15:25:08 --> Helper loaded: url_helper
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-28 15:25:08 --> Controller Class Initialized
DEBUG - 2016-09-28 15:25:08 --> Index MX_Controller Initialized
INFO - 2016-09-28 15:25:08 --> Model Class Initialized
INFO - 2016-09-28 15:25:08 --> Model Class Initialized
ERROR - 2016-09-28 15:25:08 --> Unable to delete cache file for 
DEBUG - 2016-09-28 15:25:08 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-28 15:25:08 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-28 15:25:08 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-28 15:25:08 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-28 15:25:08 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-28 15:25:08 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
DEBUG - 2016-09-28 15:25:08 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-28 15:25:08 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-28 15:25:08 --> Final output sent to browser
DEBUG - 2016-09-28 15:25:08 --> Total execution time: 0.1175
INFO - 2016-09-28 15:25:08 --> Config Class Initialized
INFO - 2016-09-28 15:25:08 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:25:08 --> UTF-8 Support Enabled
INFO - 2016-09-28 15:25:08 --> Utf8 Class Initialized
INFO - 2016-09-28 15:25:08 --> URI Class Initialized
INFO - 2016-09-28 15:25:08 --> Router Class Initialized
INFO - 2016-09-28 15:25:08 --> Output Class Initialized
INFO - 2016-09-28 15:25:08 --> Security Class Initialized
DEBUG - 2016-09-28 15:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 15:25:08 --> Input Class Initialized
INFO - 2016-09-28 15:25:08 --> Language Class Initialized
INFO - 2016-09-28 15:25:08 --> Language Class Initialized
INFO - 2016-09-28 15:25:08 --> Config Class Initialized
INFO - 2016-09-28 15:25:08 --> Loader Class Initialized
INFO - 2016-09-28 15:25:08 --> Helper loaded: url_helper
INFO - 2016-09-28 15:25:08 --> Database Driver Class Initialized
INFO - 2016-09-28 15:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-28 15:25:08 --> Controller Class Initialized
DEBUG - 2016-09-28 15:25:08 --> login MX_Controller Initialized
INFO - 2016-09-28 15:25:08 --> Model Class Initialized
INFO - 2016-09-28 15:25:08 --> Model Class Initialized
DEBUG - 2016-09-28 15:25:08 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-28 15:25:08 --> Final output sent to browser
DEBUG - 2016-09-28 15:25:08 --> Total execution time: 0.0370
INFO - 2016-09-28 17:57:41 --> Config Class Initialized
INFO - 2016-09-28 17:57:41 --> Hooks Class Initialized
DEBUG - 2016-09-28 17:57:41 --> UTF-8 Support Enabled
INFO - 2016-09-28 17:57:41 --> Utf8 Class Initialized
INFO - 2016-09-28 17:57:41 --> URI Class Initialized
INFO - 2016-09-28 17:57:41 --> Router Class Initialized
INFO - 2016-09-28 17:57:41 --> Output Class Initialized
INFO - 2016-09-28 17:57:41 --> Security Class Initialized
DEBUG - 2016-09-28 17:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 17:57:41 --> Input Class Initialized
INFO - 2016-09-28 17:57:41 --> Language Class Initialized
INFO - 2016-09-28 17:57:41 --> Language Class Initialized
INFO - 2016-09-28 17:57:41 --> Config Class Initialized
INFO - 2016-09-28 17:57:41 --> Loader Class Initialized
INFO - 2016-09-28 17:57:41 --> Helper loaded: url_helper
INFO - 2016-09-28 17:57:41 --> Database Driver Class Initialized
INFO - 2016-09-28 17:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-28 17:57:41 --> Controller Class Initialized
DEBUG - 2016-09-28 17:57:41 --> login MX_Controller Initialized
INFO - 2016-09-28 17:57:41 --> Model Class Initialized
INFO - 2016-09-28 17:57:41 --> Model Class Initialized
DEBUG - 2016-09-28 17:57:41 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-28 17:57:41 --> Final output sent to browser
DEBUG - 2016-09-28 17:57:41 --> Total execution time: 0.0401
INFO - 2016-09-28 19:52:53 --> Config Class Initialized
INFO - 2016-09-28 19:52:53 --> Hooks Class Initialized
DEBUG - 2016-09-28 19:52:53 --> UTF-8 Support Enabled
INFO - 2016-09-28 19:52:53 --> Utf8 Class Initialized
INFO - 2016-09-28 19:52:53 --> URI Class Initialized
INFO - 2016-09-28 19:52:53 --> Router Class Initialized
INFO - 2016-09-28 19:52:53 --> Output Class Initialized
INFO - 2016-09-28 19:52:53 --> Security Class Initialized
DEBUG - 2016-09-28 19:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 19:52:53 --> Input Class Initialized
INFO - 2016-09-28 19:52:53 --> Language Class Initialized
INFO - 2016-09-28 19:52:53 --> Language Class Initialized
INFO - 2016-09-28 19:52:53 --> Config Class Initialized
INFO - 2016-09-28 19:52:53 --> Loader Class Initialized
INFO - 2016-09-28 19:52:53 --> Helper loaded: url_helper
INFO - 2016-09-28 19:52:53 --> Database Driver Class Initialized
INFO - 2016-09-28 19:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-28 19:52:53 --> Controller Class Initialized
DEBUG - 2016-09-28 19:52:53 --> login MX_Controller Initialized
INFO - 2016-09-28 19:52:53 --> Model Class Initialized
INFO - 2016-09-28 19:52:53 --> Model Class Initialized
DEBUG - 2016-09-28 19:52:53 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-28 19:52:53 --> Final output sent to browser
DEBUG - 2016-09-28 19:52:53 --> Total execution time: 0.0231
INFO - 2016-09-28 19:52:56 --> Config Class Initialized
INFO - 2016-09-28 19:52:56 --> Hooks Class Initialized
DEBUG - 2016-09-28 19:52:56 --> UTF-8 Support Enabled
INFO - 2016-09-28 19:52:56 --> Utf8 Class Initialized
INFO - 2016-09-28 19:52:56 --> URI Class Initialized
INFO - 2016-09-28 19:52:56 --> Router Class Initialized
INFO - 2016-09-28 19:52:56 --> Output Class Initialized
INFO - 2016-09-28 19:52:56 --> Security Class Initialized
DEBUG - 2016-09-28 19:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 19:52:56 --> Input Class Initialized
INFO - 2016-09-28 19:52:56 --> Language Class Initialized
ERROR - 2016-09-28 19:52:56 --> 404 Page Not Found: /index
INFO - 2016-09-28 21:12:47 --> Config Class Initialized
INFO - 2016-09-28 21:12:47 --> Hooks Class Initialized
DEBUG - 2016-09-28 21:12:47 --> UTF-8 Support Enabled
INFO - 2016-09-28 21:12:47 --> Utf8 Class Initialized
INFO - 2016-09-28 21:12:47 --> URI Class Initialized
DEBUG - 2016-09-28 21:12:47 --> No URI present. Default controller set.
INFO - 2016-09-28 21:12:47 --> Router Class Initialized
INFO - 2016-09-28 21:12:47 --> Output Class Initialized
INFO - 2016-09-28 21:12:47 --> Security Class Initialized
DEBUG - 2016-09-28 21:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 21:12:47 --> Input Class Initialized
INFO - 2016-09-28 21:12:47 --> Language Class Initialized
INFO - 2016-09-28 21:12:47 --> Language Class Initialized
INFO - 2016-09-28 21:12:47 --> Config Class Initialized
INFO - 2016-09-28 21:12:47 --> Loader Class Initialized
INFO - 2016-09-28 21:12:47 --> Helper loaded: url_helper
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-28 21:12:47 --> Controller Class Initialized
DEBUG - 2016-09-28 21:12:47 --> Index MX_Controller Initialized
INFO - 2016-09-28 21:12:47 --> Model Class Initialized
INFO - 2016-09-28 21:12:47 --> Model Class Initialized
ERROR - 2016-09-28 21:12:47 --> Unable to delete cache file for 
DEBUG - 2016-09-28 21:12:47 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-28 21:12:47 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-28 21:12:47 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-28 21:12:47 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-28 21:12:47 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-28 21:12:47 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
DEBUG - 2016-09-28 21:12:47 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-28 21:12:47 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-28 21:12:47 --> Final output sent to browser
DEBUG - 2016-09-28 21:12:47 --> Total execution time: 0.1108
INFO - 2016-09-28 21:12:47 --> Config Class Initialized
INFO - 2016-09-28 21:12:47 --> Hooks Class Initialized
DEBUG - 2016-09-28 21:12:47 --> UTF-8 Support Enabled
INFO - 2016-09-28 21:12:47 --> Utf8 Class Initialized
INFO - 2016-09-28 21:12:47 --> URI Class Initialized
INFO - 2016-09-28 21:12:47 --> Router Class Initialized
INFO - 2016-09-28 21:12:47 --> Output Class Initialized
INFO - 2016-09-28 21:12:47 --> Security Class Initialized
DEBUG - 2016-09-28 21:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 21:12:47 --> Input Class Initialized
INFO - 2016-09-28 21:12:47 --> Language Class Initialized
INFO - 2016-09-28 21:12:47 --> Language Class Initialized
INFO - 2016-09-28 21:12:47 --> Config Class Initialized
INFO - 2016-09-28 21:12:47 --> Loader Class Initialized
INFO - 2016-09-28 21:12:47 --> Helper loaded: url_helper
INFO - 2016-09-28 21:12:47 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-28 21:12:47 --> Controller Class Initialized
DEBUG - 2016-09-28 21:12:47 --> login MX_Controller Initialized
INFO - 2016-09-28 21:12:47 --> Model Class Initialized
INFO - 2016-09-28 21:12:47 --> Model Class Initialized
DEBUG - 2016-09-28 21:12:47 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-28 21:12:47 --> Final output sent to browser
DEBUG - 2016-09-28 21:12:47 --> Total execution time: 0.0309
INFO - 2016-09-28 21:12:48 --> Config Class Initialized
INFO - 2016-09-28 21:12:48 --> Hooks Class Initialized
DEBUG - 2016-09-28 21:12:48 --> UTF-8 Support Enabled
INFO - 2016-09-28 21:12:48 --> Utf8 Class Initialized
INFO - 2016-09-28 21:12:48 --> URI Class Initialized
INFO - 2016-09-28 21:12:48 --> Router Class Initialized
INFO - 2016-09-28 21:12:48 --> Output Class Initialized
INFO - 2016-09-28 21:12:48 --> Security Class Initialized
DEBUG - 2016-09-28 21:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 21:12:48 --> Input Class Initialized
INFO - 2016-09-28 21:12:48 --> Language Class Initialized
INFO - 2016-09-28 21:12:48 --> Language Class Initialized
INFO - 2016-09-28 21:12:48 --> Config Class Initialized
INFO - 2016-09-28 21:12:48 --> Loader Class Initialized
INFO - 2016-09-28 21:12:48 --> Helper loaded: url_helper
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-28 21:12:48 --> Controller Class Initialized
DEBUG - 2016-09-28 21:12:48 --> Index MX_Controller Initialized
INFO - 2016-09-28 21:12:48 --> Model Class Initialized
INFO - 2016-09-28 21:12:48 --> Model Class Initialized
ERROR - 2016-09-28 21:12:48 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-28 21:12:48 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-28 21:12:48 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-28 21:12:48 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-28 21:12:48 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-28 21:12:48 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-28 21:12:48 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:48 --> Database Driver Class Initialized
DEBUG - 2016-09-28 21:12:48 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-28 21:12:48 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-28 21:12:48 --> Final output sent to browser
DEBUG - 2016-09-28 21:12:48 --> Total execution time: 0.1438
INFO - 2016-09-28 21:12:49 --> Config Class Initialized
INFO - 2016-09-28 21:12:49 --> Hooks Class Initialized
DEBUG - 2016-09-28 21:12:49 --> UTF-8 Support Enabled
INFO - 2016-09-28 21:12:49 --> Utf8 Class Initialized
INFO - 2016-09-28 21:12:49 --> URI Class Initialized
INFO - 2016-09-28 21:12:49 --> Router Class Initialized
INFO - 2016-09-28 21:12:49 --> Output Class Initialized
INFO - 2016-09-28 21:12:49 --> Security Class Initialized
DEBUG - 2016-09-28 21:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 21:12:49 --> Input Class Initialized
INFO - 2016-09-28 21:12:49 --> Language Class Initialized
INFO - 2016-09-28 21:12:49 --> Language Class Initialized
INFO - 2016-09-28 21:12:49 --> Config Class Initialized
INFO - 2016-09-28 21:12:49 --> Loader Class Initialized
INFO - 2016-09-28 21:12:49 --> Helper loaded: url_helper
INFO - 2016-09-28 21:12:49 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-28 21:12:49 --> Controller Class Initialized
DEBUG - 2016-09-28 21:12:49 --> login MX_Controller Initialized
INFO - 2016-09-28 21:12:49 --> Model Class Initialized
INFO - 2016-09-28 21:12:49 --> Model Class Initialized
DEBUG - 2016-09-28 21:12:49 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-28 21:12:49 --> Final output sent to browser
DEBUG - 2016-09-28 21:12:49 --> Total execution time: 0.0304
INFO - 2016-09-28 21:12:50 --> Config Class Initialized
INFO - 2016-09-28 21:12:50 --> Hooks Class Initialized
DEBUG - 2016-09-28 21:12:50 --> UTF-8 Support Enabled
INFO - 2016-09-28 21:12:50 --> Utf8 Class Initialized
INFO - 2016-09-28 21:12:50 --> URI Class Initialized
INFO - 2016-09-28 21:12:50 --> Router Class Initialized
INFO - 2016-09-28 21:12:50 --> Output Class Initialized
INFO - 2016-09-28 21:12:50 --> Security Class Initialized
DEBUG - 2016-09-28 21:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 21:12:50 --> Input Class Initialized
INFO - 2016-09-28 21:12:50 --> Language Class Initialized
INFO - 2016-09-28 21:12:50 --> Language Class Initialized
INFO - 2016-09-28 21:12:50 --> Config Class Initialized
INFO - 2016-09-28 21:12:50 --> Loader Class Initialized
INFO - 2016-09-28 21:12:50 --> Helper loaded: url_helper
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-28 21:12:50 --> Controller Class Initialized
DEBUG - 2016-09-28 21:12:50 --> Index MX_Controller Initialized
INFO - 2016-09-28 21:12:50 --> Model Class Initialized
INFO - 2016-09-28 21:12:50 --> Model Class Initialized
ERROR - 2016-09-28 21:12:50 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-28 21:12:50 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-28 21:12:50 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-28 21:12:50 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-28 21:12:50 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-28 21:12:50 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-28 21:12:50 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
DEBUG - 2016-09-28 21:12:50 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-28 21:12:50 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-28 21:12:50 --> Final output sent to browser
DEBUG - 2016-09-28 21:12:50 --> Total execution time: 0.0934
INFO - 2016-09-28 21:12:50 --> Config Class Initialized
INFO - 2016-09-28 21:12:50 --> Hooks Class Initialized
DEBUG - 2016-09-28 21:12:50 --> UTF-8 Support Enabled
INFO - 2016-09-28 21:12:50 --> Utf8 Class Initialized
INFO - 2016-09-28 21:12:50 --> URI Class Initialized
INFO - 2016-09-28 21:12:50 --> Router Class Initialized
INFO - 2016-09-28 21:12:50 --> Output Class Initialized
INFO - 2016-09-28 21:12:50 --> Security Class Initialized
DEBUG - 2016-09-28 21:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 21:12:50 --> Input Class Initialized
INFO - 2016-09-28 21:12:50 --> Language Class Initialized
INFO - 2016-09-28 21:12:50 --> Language Class Initialized
INFO - 2016-09-28 21:12:50 --> Config Class Initialized
INFO - 2016-09-28 21:12:50 --> Loader Class Initialized
INFO - 2016-09-28 21:12:50 --> Helper loaded: url_helper
INFO - 2016-09-28 21:12:50 --> Database Driver Class Initialized
INFO - 2016-09-28 21:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-28 21:12:50 --> Controller Class Initialized
DEBUG - 2016-09-28 21:12:50 --> login MX_Controller Initialized
INFO - 2016-09-28 21:12:50 --> Model Class Initialized
INFO - 2016-09-28 21:12:50 --> Model Class Initialized
DEBUG - 2016-09-28 21:12:50 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-28 21:12:50 --> Final output sent to browser
DEBUG - 2016-09-28 21:12:50 --> Total execution time: 0.0305
