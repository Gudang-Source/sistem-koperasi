<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-09-11 02:50:18 --> Config Class Initialized
INFO - 2016-09-11 02:50:18 --> Hooks Class Initialized
DEBUG - 2016-09-11 02:50:18 --> UTF-8 Support Enabled
INFO - 2016-09-11 02:50:18 --> Utf8 Class Initialized
INFO - 2016-09-11 02:50:18 --> URI Class Initialized
INFO - 2016-09-11 02:50:18 --> Router Class Initialized
INFO - 2016-09-11 02:50:18 --> Output Class Initialized
INFO - 2016-09-11 02:50:18 --> Security Class Initialized
DEBUG - 2016-09-11 02:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 02:50:18 --> Input Class Initialized
INFO - 2016-09-11 02:50:18 --> Language Class Initialized
INFO - 2016-09-11 02:50:18 --> Language Class Initialized
INFO - 2016-09-11 02:50:18 --> Config Class Initialized
INFO - 2016-09-11 02:50:18 --> Loader Class Initialized
INFO - 2016-09-11 02:50:18 --> Helper loaded: url_helper
INFO - 2016-09-11 02:50:18 --> Database Driver Class Initialized
INFO - 2016-09-11 02:50:18 --> Controller Class Initialized
DEBUG - 2016-09-11 02:50:18 --> Index MX_Controller Initialized
INFO - 2016-09-11 02:50:18 --> Model Class Initialized
INFO - 2016-09-11 02:50:18 --> Model Class Initialized
DEBUG - 2016-09-11 02:50:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-11 02:50:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-11 02:50:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-11 02:50:18 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-11 02:50:18 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 02:50:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-11 02:50:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-11 02:50:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-11 02:50:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-11 02:50:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-11 02:50:18 --> Final output sent to browser
DEBUG - 2016-09-11 02:50:18 --> Total execution time: 0.5342
INFO - 2016-09-11 02:50:25 --> Config Class Initialized
INFO - 2016-09-11 02:50:25 --> Hooks Class Initialized
DEBUG - 2016-09-11 02:50:25 --> UTF-8 Support Enabled
INFO - 2016-09-11 02:50:26 --> Utf8 Class Initialized
INFO - 2016-09-11 02:50:26 --> URI Class Initialized
INFO - 2016-09-11 02:50:26 --> Router Class Initialized
INFO - 2016-09-11 02:50:26 --> Output Class Initialized
INFO - 2016-09-11 02:50:26 --> Security Class Initialized
DEBUG - 2016-09-11 02:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 02:50:26 --> Input Class Initialized
INFO - 2016-09-11 02:50:26 --> Language Class Initialized
INFO - 2016-09-11 02:50:26 --> Language Class Initialized
INFO - 2016-09-11 02:50:26 --> Config Class Initialized
INFO - 2016-09-11 02:50:26 --> Loader Class Initialized
INFO - 2016-09-11 02:50:26 --> Helper loaded: url_helper
INFO - 2016-09-11 02:50:26 --> Database Driver Class Initialized
INFO - 2016-09-11 02:50:26 --> Controller Class Initialized
DEBUG - 2016-09-11 02:50:26 --> Index MX_Controller Initialized
INFO - 2016-09-11 02:50:26 --> Model Class Initialized
INFO - 2016-09-11 02:50:26 --> Model Class Initialized
DEBUG - 2016-09-11 02:50:26 --> Anggota MX_Controller Initialized
INFO - 2016-09-11 02:50:26 --> Final output sent to browser
DEBUG - 2016-09-11 02:50:26 --> Total execution time: 0.5049
INFO - 2016-09-11 02:50:29 --> Config Class Initialized
INFO - 2016-09-11 02:50:29 --> Hooks Class Initialized
DEBUG - 2016-09-11 02:50:29 --> UTF-8 Support Enabled
INFO - 2016-09-11 02:50:29 --> Utf8 Class Initialized
INFO - 2016-09-11 02:50:29 --> URI Class Initialized
INFO - 2016-09-11 02:50:29 --> Router Class Initialized
INFO - 2016-09-11 02:50:29 --> Output Class Initialized
INFO - 2016-09-11 02:50:29 --> Security Class Initialized
DEBUG - 2016-09-11 02:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 02:50:29 --> Input Class Initialized
INFO - 2016-09-11 02:50:29 --> Language Class Initialized
INFO - 2016-09-11 02:50:29 --> Language Class Initialized
INFO - 2016-09-11 02:50:30 --> Config Class Initialized
INFO - 2016-09-11 02:50:30 --> Loader Class Initialized
INFO - 2016-09-11 02:50:30 --> Helper loaded: url_helper
INFO - 2016-09-11 02:50:30 --> Database Driver Class Initialized
INFO - 2016-09-11 02:50:30 --> Controller Class Initialized
DEBUG - 2016-09-11 02:50:30 --> Index MX_Controller Initialized
INFO - 2016-09-11 02:50:30 --> Model Class Initialized
INFO - 2016-09-11 02:50:30 --> Model Class Initialized
DEBUG - 2016-09-11 02:50:30 --> Anggota MX_Controller Initialized
INFO - 2016-09-11 02:50:30 --> Final output sent to browser
DEBUG - 2016-09-11 02:50:30 --> Total execution time: 0.5584
INFO - 2016-09-11 02:50:33 --> Config Class Initialized
INFO - 2016-09-11 02:50:33 --> Hooks Class Initialized
DEBUG - 2016-09-11 02:50:33 --> UTF-8 Support Enabled
INFO - 2016-09-11 02:50:33 --> Utf8 Class Initialized
INFO - 2016-09-11 02:50:33 --> URI Class Initialized
INFO - 2016-09-11 02:50:33 --> Router Class Initialized
INFO - 2016-09-11 02:50:33 --> Output Class Initialized
INFO - 2016-09-11 02:50:33 --> Security Class Initialized
DEBUG - 2016-09-11 02:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 02:50:33 --> Input Class Initialized
INFO - 2016-09-11 02:50:33 --> Language Class Initialized
INFO - 2016-09-11 02:50:33 --> Language Class Initialized
INFO - 2016-09-11 02:50:33 --> Config Class Initialized
INFO - 2016-09-11 02:50:33 --> Loader Class Initialized
INFO - 2016-09-11 02:50:33 --> Helper loaded: url_helper
INFO - 2016-09-11 02:50:33 --> Database Driver Class Initialized
INFO - 2016-09-11 02:50:33 --> Controller Class Initialized
DEBUG - 2016-09-11 02:50:33 --> Index MX_Controller Initialized
INFO - 2016-09-11 02:50:33 --> Model Class Initialized
INFO - 2016-09-11 02:50:33 --> Model Class Initialized
DEBUG - 2016-09-11 02:50:33 --> Anggota MX_Controller Initialized
INFO - 2016-09-11 02:50:33 --> Final output sent to browser
DEBUG - 2016-09-11 02:50:33 --> Total execution time: 0.5565
INFO - 2016-09-11 02:50:35 --> Config Class Initialized
INFO - 2016-09-11 02:50:35 --> Hooks Class Initialized
DEBUG - 2016-09-11 02:50:35 --> UTF-8 Support Enabled
INFO - 2016-09-11 02:50:35 --> Utf8 Class Initialized
INFO - 2016-09-11 02:50:35 --> URI Class Initialized
INFO - 2016-09-11 02:50:35 --> Router Class Initialized
INFO - 2016-09-11 02:50:35 --> Output Class Initialized
INFO - 2016-09-11 02:50:35 --> Security Class Initialized
DEBUG - 2016-09-11 02:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 02:50:36 --> Input Class Initialized
INFO - 2016-09-11 02:50:36 --> Language Class Initialized
INFO - 2016-09-11 02:50:36 --> Language Class Initialized
INFO - 2016-09-11 02:50:36 --> Config Class Initialized
INFO - 2016-09-11 02:50:36 --> Loader Class Initialized
INFO - 2016-09-11 02:50:36 --> Helper loaded: url_helper
INFO - 2016-09-11 02:50:36 --> Database Driver Class Initialized
INFO - 2016-09-11 02:50:36 --> Controller Class Initialized
DEBUG - 2016-09-11 02:50:36 --> Index MX_Controller Initialized
INFO - 2016-09-11 02:50:36 --> Model Class Initialized
INFO - 2016-09-11 02:50:36 --> Model Class Initialized
DEBUG - 2016-09-11 02:50:36 --> Anggota MX_Controller Initialized
INFO - 2016-09-11 02:50:36 --> Final output sent to browser
DEBUG - 2016-09-11 02:50:36 --> Total execution time: 0.5673
INFO - 2016-09-11 02:50:38 --> Config Class Initialized
INFO - 2016-09-11 02:50:38 --> Hooks Class Initialized
DEBUG - 2016-09-11 02:50:38 --> UTF-8 Support Enabled
INFO - 2016-09-11 02:50:38 --> Utf8 Class Initialized
INFO - 2016-09-11 02:50:38 --> URI Class Initialized
INFO - 2016-09-11 02:50:38 --> Router Class Initialized
INFO - 2016-09-11 02:50:38 --> Output Class Initialized
INFO - 2016-09-11 02:50:38 --> Security Class Initialized
DEBUG - 2016-09-11 02:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 02:50:38 --> Input Class Initialized
INFO - 2016-09-11 02:50:38 --> Language Class Initialized
INFO - 2016-09-11 02:50:38 --> Language Class Initialized
INFO - 2016-09-11 02:50:39 --> Config Class Initialized
INFO - 2016-09-11 02:50:39 --> Loader Class Initialized
INFO - 2016-09-11 02:50:39 --> Helper loaded: url_helper
INFO - 2016-09-11 02:50:39 --> Database Driver Class Initialized
INFO - 2016-09-11 02:50:39 --> Controller Class Initialized
DEBUG - 2016-09-11 02:50:39 --> Index MX_Controller Initialized
INFO - 2016-09-11 02:50:39 --> Model Class Initialized
INFO - 2016-09-11 02:50:39 --> Model Class Initialized
DEBUG - 2016-09-11 02:50:39 --> Anggota MX_Controller Initialized
INFO - 2016-09-11 02:50:39 --> Final output sent to browser
DEBUG - 2016-09-11 02:50:39 --> Total execution time: 0.5048
INFO - 2016-09-11 02:56:46 --> Config Class Initialized
INFO - 2016-09-11 02:56:46 --> Hooks Class Initialized
DEBUG - 2016-09-11 02:56:46 --> UTF-8 Support Enabled
INFO - 2016-09-11 02:56:46 --> Utf8 Class Initialized
INFO - 2016-09-11 02:56:46 --> URI Class Initialized
INFO - 2016-09-11 02:56:46 --> Router Class Initialized
INFO - 2016-09-11 02:56:46 --> Output Class Initialized
INFO - 2016-09-11 02:56:46 --> Security Class Initialized
DEBUG - 2016-09-11 02:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 02:56:46 --> Input Class Initialized
INFO - 2016-09-11 02:56:46 --> Language Class Initialized
INFO - 2016-09-11 02:56:46 --> Language Class Initialized
INFO - 2016-09-11 02:56:46 --> Config Class Initialized
INFO - 2016-09-11 02:56:47 --> Loader Class Initialized
INFO - 2016-09-11 02:56:47 --> Helper loaded: url_helper
INFO - 2016-09-11 02:56:47 --> Database Driver Class Initialized
INFO - 2016-09-11 02:56:47 --> Controller Class Initialized
DEBUG - 2016-09-11 02:56:47 --> Index MX_Controller Initialized
INFO - 2016-09-11 02:56:47 --> Model Class Initialized
INFO - 2016-09-11 02:56:47 --> Model Class Initialized
DEBUG - 2016-09-11 02:56:47 --> Anggota MX_Controller Initialized
INFO - 2016-09-11 02:56:47 --> Final output sent to browser
DEBUG - 2016-09-11 02:56:47 --> Total execution time: 0.6172
INFO - 2016-09-11 02:56:53 --> Config Class Initialized
INFO - 2016-09-11 02:56:53 --> Hooks Class Initialized
DEBUG - 2016-09-11 02:56:53 --> UTF-8 Support Enabled
INFO - 2016-09-11 02:56:53 --> Utf8 Class Initialized
INFO - 2016-09-11 02:56:53 --> URI Class Initialized
INFO - 2016-09-11 02:56:53 --> Router Class Initialized
INFO - 2016-09-11 02:56:53 --> Output Class Initialized
INFO - 2016-09-11 02:56:53 --> Security Class Initialized
DEBUG - 2016-09-11 02:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 02:56:53 --> Input Class Initialized
INFO - 2016-09-11 02:56:53 --> Language Class Initialized
INFO - 2016-09-11 02:56:53 --> Language Class Initialized
INFO - 2016-09-11 02:56:53 --> Config Class Initialized
INFO - 2016-09-11 02:56:53 --> Loader Class Initialized
INFO - 2016-09-11 02:56:53 --> Helper loaded: url_helper
INFO - 2016-09-11 02:56:53 --> Database Driver Class Initialized
INFO - 2016-09-11 02:56:53 --> Controller Class Initialized
DEBUG - 2016-09-11 02:56:53 --> Index MX_Controller Initialized
INFO - 2016-09-11 02:56:53 --> Model Class Initialized
INFO - 2016-09-11 02:56:53 --> Model Class Initialized
DEBUG - 2016-09-11 02:56:53 --> Anggota MX_Controller Initialized
INFO - 2016-09-11 02:56:53 --> Final output sent to browser
DEBUG - 2016-09-11 02:56:53 --> Total execution time: 0.5445
INFO - 2016-09-11 02:56:55 --> Config Class Initialized
INFO - 2016-09-11 02:56:55 --> Hooks Class Initialized
DEBUG - 2016-09-11 02:56:55 --> UTF-8 Support Enabled
INFO - 2016-09-11 02:56:55 --> Utf8 Class Initialized
INFO - 2016-09-11 02:56:55 --> URI Class Initialized
INFO - 2016-09-11 02:56:55 --> Router Class Initialized
INFO - 2016-09-11 02:56:55 --> Output Class Initialized
INFO - 2016-09-11 02:56:55 --> Security Class Initialized
DEBUG - 2016-09-11 02:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 02:56:55 --> Input Class Initialized
INFO - 2016-09-11 02:56:55 --> Language Class Initialized
INFO - 2016-09-11 02:56:55 --> Language Class Initialized
INFO - 2016-09-11 02:56:55 --> Config Class Initialized
INFO - 2016-09-11 02:56:55 --> Loader Class Initialized
INFO - 2016-09-11 02:56:55 --> Helper loaded: url_helper
INFO - 2016-09-11 02:56:55 --> Database Driver Class Initialized
INFO - 2016-09-11 02:56:55 --> Controller Class Initialized
DEBUG - 2016-09-11 02:56:55 --> Index MX_Controller Initialized
INFO - 2016-09-11 02:56:55 --> Model Class Initialized
INFO - 2016-09-11 02:56:55 --> Model Class Initialized
DEBUG - 2016-09-11 02:56:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-11 02:56:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-11 02:56:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-11 02:56:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-11 02:56:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-11 02:56:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-11 02:56:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-11 02:56:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-11 02:56:56 --> Final output sent to browser
DEBUG - 2016-09-11 02:56:56 --> Total execution time: 0.5333
INFO - 2016-09-11 02:57:00 --> Config Class Initialized
INFO - 2016-09-11 02:57:00 --> Hooks Class Initialized
DEBUG - 2016-09-11 02:57:00 --> UTF-8 Support Enabled
INFO - 2016-09-11 02:57:00 --> Utf8 Class Initialized
INFO - 2016-09-11 02:57:00 --> URI Class Initialized
INFO - 2016-09-11 02:57:00 --> Router Class Initialized
INFO - 2016-09-11 02:57:00 --> Output Class Initialized
INFO - 2016-09-11 02:57:00 --> Security Class Initialized
DEBUG - 2016-09-11 02:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 02:57:00 --> Input Class Initialized
INFO - 2016-09-11 02:57:00 --> Language Class Initialized
INFO - 2016-09-11 02:57:00 --> Language Class Initialized
INFO - 2016-09-11 02:57:00 --> Config Class Initialized
INFO - 2016-09-11 02:57:00 --> Loader Class Initialized
INFO - 2016-09-11 02:57:00 --> Helper loaded: url_helper
INFO - 2016-09-11 02:57:00 --> Database Driver Class Initialized
INFO - 2016-09-11 02:57:00 --> Controller Class Initialized
DEBUG - 2016-09-11 02:57:00 --> Index MX_Controller Initialized
INFO - 2016-09-11 02:57:00 --> Model Class Initialized
INFO - 2016-09-11 02:57:00 --> Model Class Initialized
DEBUG - 2016-09-11 02:57:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-11 02:57:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-11 02:57:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-11 02:57:00 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-11 02:57:00 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 02:57:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-11 02:57:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-11 02:57:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-11 02:57:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-11 02:57:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-11 02:57:00 --> Final output sent to browser
DEBUG - 2016-09-11 02:57:00 --> Total execution time: 0.7045
INFO - 2016-09-11 03:16:34 --> Config Class Initialized
INFO - 2016-09-11 03:16:34 --> Hooks Class Initialized
DEBUG - 2016-09-11 03:16:34 --> UTF-8 Support Enabled
INFO - 2016-09-11 03:16:34 --> Utf8 Class Initialized
INFO - 2016-09-11 03:16:34 --> URI Class Initialized
INFO - 2016-09-11 03:16:34 --> Router Class Initialized
INFO - 2016-09-11 03:16:34 --> Output Class Initialized
INFO - 2016-09-11 03:16:34 --> Security Class Initialized
DEBUG - 2016-09-11 03:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 03:16:34 --> Input Class Initialized
INFO - 2016-09-11 03:16:34 --> Language Class Initialized
ERROR - 2016-09-11 03:16:34 --> Severity: Parsing Error --> syntax error, unexpected ')' E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 34
INFO - 2016-09-11 03:16:46 --> Config Class Initialized
INFO - 2016-09-11 03:16:46 --> Hooks Class Initialized
DEBUG - 2016-09-11 03:16:46 --> UTF-8 Support Enabled
INFO - 2016-09-11 03:16:46 --> Utf8 Class Initialized
INFO - 2016-09-11 03:16:46 --> URI Class Initialized
INFO - 2016-09-11 03:16:47 --> Router Class Initialized
INFO - 2016-09-11 03:16:47 --> Output Class Initialized
INFO - 2016-09-11 03:16:47 --> Security Class Initialized
DEBUG - 2016-09-11 03:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 03:16:47 --> Input Class Initialized
INFO - 2016-09-11 03:16:47 --> Language Class Initialized
INFO - 2016-09-11 03:16:47 --> Language Class Initialized
INFO - 2016-09-11 03:16:47 --> Config Class Initialized
INFO - 2016-09-11 03:16:47 --> Loader Class Initialized
INFO - 2016-09-11 03:16:47 --> Helper loaded: url_helper
INFO - 2016-09-11 03:16:47 --> Database Driver Class Initialized
INFO - 2016-09-11 03:16:47 --> Controller Class Initialized
DEBUG - 2016-09-11 03:16:47 --> Index MX_Controller Initialized
INFO - 2016-09-11 03:16:47 --> Model Class Initialized
INFO - 2016-09-11 03:16:47 --> Model Class Initialized
DEBUG - 2016-09-11 03:16:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-11 03:16:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-11 03:16:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-11 03:16:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-11 03:16:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-11 03:16:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-11 03:16:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-11 03:16:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-11 03:16:47 --> Final output sent to browser
DEBUG - 2016-09-11 03:16:47 --> Total execution time: 0.5148
INFO - 2016-09-11 03:16:53 --> Config Class Initialized
INFO - 2016-09-11 03:16:53 --> Hooks Class Initialized
DEBUG - 2016-09-11 03:16:53 --> UTF-8 Support Enabled
INFO - 2016-09-11 03:16:53 --> Utf8 Class Initialized
INFO - 2016-09-11 03:16:53 --> URI Class Initialized
INFO - 2016-09-11 03:16:53 --> Router Class Initialized
INFO - 2016-09-11 03:16:53 --> Output Class Initialized
INFO - 2016-09-11 03:16:53 --> Security Class Initialized
DEBUG - 2016-09-11 03:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 03:16:53 --> Input Class Initialized
INFO - 2016-09-11 03:16:53 --> Language Class Initialized
INFO - 2016-09-11 03:16:53 --> Language Class Initialized
INFO - 2016-09-11 03:16:53 --> Config Class Initialized
INFO - 2016-09-11 03:16:53 --> Loader Class Initialized
INFO - 2016-09-11 03:16:53 --> Helper loaded: url_helper
INFO - 2016-09-11 03:16:54 --> Database Driver Class Initialized
INFO - 2016-09-11 03:16:54 --> Controller Class Initialized
DEBUG - 2016-09-11 03:16:54 --> Index MX_Controller Initialized
INFO - 2016-09-11 03:16:54 --> Model Class Initialized
INFO - 2016-09-11 03:16:54 --> Model Class Initialized
DEBUG - 2016-09-11 03:16:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-11 03:16:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-11 03:16:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-11 03:16:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_user.php
DEBUG - 2016-09-11 03:16:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-11 03:16:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-11 03:16:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-11 03:16:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-11 03:16:54 --> Final output sent to browser
DEBUG - 2016-09-11 03:16:54 --> Total execution time: 0.6860
INFO - 2016-09-11 03:17:58 --> Config Class Initialized
INFO - 2016-09-11 03:17:58 --> Hooks Class Initialized
DEBUG - 2016-09-11 03:17:58 --> UTF-8 Support Enabled
INFO - 2016-09-11 03:17:58 --> Utf8 Class Initialized
INFO - 2016-09-11 03:17:58 --> URI Class Initialized
INFO - 2016-09-11 03:17:58 --> Router Class Initialized
INFO - 2016-09-11 03:17:58 --> Output Class Initialized
INFO - 2016-09-11 03:17:58 --> Security Class Initialized
DEBUG - 2016-09-11 03:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 03:17:58 --> Input Class Initialized
INFO - 2016-09-11 03:17:58 --> Language Class Initialized
INFO - 2016-09-11 03:17:58 --> Language Class Initialized
INFO - 2016-09-11 03:17:59 --> Config Class Initialized
INFO - 2016-09-11 03:17:59 --> Loader Class Initialized
INFO - 2016-09-11 03:17:59 --> Helper loaded: url_helper
INFO - 2016-09-11 03:17:59 --> Database Driver Class Initialized
INFO - 2016-09-11 03:17:59 --> Controller Class Initialized
DEBUG - 2016-09-11 03:17:59 --> Index MX_Controller Initialized
INFO - 2016-09-11 03:17:59 --> Model Class Initialized
INFO - 2016-09-11 03:17:59 --> Model Class Initialized
DEBUG - 2016-09-11 03:17:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-11 03:17:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-11 03:17:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-11 03:17:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_user.php
DEBUG - 2016-09-11 03:17:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-11 03:17:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-11 03:17:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-11 03:17:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-11 03:17:59 --> Final output sent to browser
DEBUG - 2016-09-11 03:17:59 --> Total execution time: 0.5640
INFO - 2016-09-11 13:08:18 --> Config Class Initialized
INFO - 2016-09-11 13:08:18 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:08:18 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:08:18 --> Utf8 Class Initialized
INFO - 2016-09-11 13:08:18 --> URI Class Initialized
INFO - 2016-09-11 13:08:18 --> Router Class Initialized
INFO - 2016-09-11 13:08:18 --> Output Class Initialized
INFO - 2016-09-11 13:08:19 --> Security Class Initialized
DEBUG - 2016-09-11 13:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:08:19 --> Input Class Initialized
INFO - 2016-09-11 13:08:19 --> Language Class Initialized
INFO - 2016-09-11 13:08:19 --> Language Class Initialized
INFO - 2016-09-11 13:08:19 --> Config Class Initialized
INFO - 2016-09-11 13:08:19 --> Loader Class Initialized
INFO - 2016-09-11 13:08:19 --> Helper loaded: url_helper
INFO - 2016-09-11 13:08:19 --> Database Driver Class Initialized
INFO - 2016-09-11 13:08:19 --> Controller Class Initialized
DEBUG - 2016-09-11 13:08:19 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:08:19 --> Model Class Initialized
INFO - 2016-09-11 13:08:19 --> Model Class Initialized
DEBUG - 2016-09-11 13:08:19 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 13:08:19 --> Users MX_Controller Initialized
INFO - 2016-09-11 13:08:19 --> Final output sent to browser
DEBUG - 2016-09-11 13:08:20 --> Total execution time: 1.8122
INFO - 2016-09-11 13:08:47 --> Config Class Initialized
INFO - 2016-09-11 13:08:47 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:08:47 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:08:47 --> Utf8 Class Initialized
INFO - 2016-09-11 13:08:47 --> URI Class Initialized
INFO - 2016-09-11 13:08:47 --> Router Class Initialized
INFO - 2016-09-11 13:08:47 --> Output Class Initialized
INFO - 2016-09-11 13:08:47 --> Security Class Initialized
DEBUG - 2016-09-11 13:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:08:47 --> Input Class Initialized
INFO - 2016-09-11 13:08:47 --> Language Class Initialized
INFO - 2016-09-11 13:08:47 --> Language Class Initialized
INFO - 2016-09-11 13:08:47 --> Config Class Initialized
INFO - 2016-09-11 13:08:47 --> Loader Class Initialized
INFO - 2016-09-11 13:08:47 --> Helper loaded: url_helper
INFO - 2016-09-11 13:08:47 --> Database Driver Class Initialized
INFO - 2016-09-11 13:08:47 --> Controller Class Initialized
DEBUG - 2016-09-11 13:08:47 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:08:47 --> Model Class Initialized
INFO - 2016-09-11 13:08:47 --> Model Class Initialized
DEBUG - 2016-09-11 13:08:47 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 13:08:47 --> Users MX_Controller Initialized
INFO - 2016-09-11 13:08:47 --> Final output sent to browser
DEBUG - 2016-09-11 13:08:47 --> Total execution time: 0.5007
INFO - 2016-09-11 13:11:39 --> Config Class Initialized
INFO - 2016-09-11 13:11:39 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:11:39 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:11:39 --> Utf8 Class Initialized
INFO - 2016-09-11 13:11:39 --> URI Class Initialized
INFO - 2016-09-11 13:11:39 --> Router Class Initialized
INFO - 2016-09-11 13:11:39 --> Output Class Initialized
INFO - 2016-09-11 13:11:39 --> Security Class Initialized
DEBUG - 2016-09-11 13:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:11:39 --> Input Class Initialized
INFO - 2016-09-11 13:11:39 --> Language Class Initialized
INFO - 2016-09-11 13:11:39 --> Language Class Initialized
INFO - 2016-09-11 13:11:39 --> Config Class Initialized
INFO - 2016-09-11 13:11:39 --> Loader Class Initialized
INFO - 2016-09-11 13:11:39 --> Helper loaded: url_helper
INFO - 2016-09-11 13:11:39 --> Database Driver Class Initialized
INFO - 2016-09-11 13:11:39 --> Controller Class Initialized
DEBUG - 2016-09-11 13:11:39 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:11:39 --> Model Class Initialized
INFO - 2016-09-11 13:11:39 --> Model Class Initialized
DEBUG - 2016-09-11 13:11:39 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 13:11:39 --> Users MX_Controller Initialized
INFO - 2016-09-11 13:11:39 --> Final output sent to browser
DEBUG - 2016-09-11 13:11:39 --> Total execution time: 0.5273
INFO - 2016-09-11 13:11:55 --> Config Class Initialized
INFO - 2016-09-11 13:11:55 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:11:55 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:11:55 --> Utf8 Class Initialized
INFO - 2016-09-11 13:11:55 --> URI Class Initialized
INFO - 2016-09-11 13:11:55 --> Router Class Initialized
INFO - 2016-09-11 13:11:55 --> Output Class Initialized
INFO - 2016-09-11 13:11:55 --> Security Class Initialized
DEBUG - 2016-09-11 13:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:11:55 --> Input Class Initialized
INFO - 2016-09-11 13:11:55 --> Language Class Initialized
INFO - 2016-09-11 13:11:55 --> Language Class Initialized
INFO - 2016-09-11 13:11:55 --> Config Class Initialized
INFO - 2016-09-11 13:11:56 --> Loader Class Initialized
INFO - 2016-09-11 13:11:56 --> Helper loaded: url_helper
INFO - 2016-09-11 13:11:56 --> Database Driver Class Initialized
INFO - 2016-09-11 13:11:56 --> Controller Class Initialized
DEBUG - 2016-09-11 13:11:56 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:11:56 --> Model Class Initialized
INFO - 2016-09-11 13:11:56 --> Model Class Initialized
DEBUG - 2016-09-11 13:11:56 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 13:11:56 --> Users MX_Controller Initialized
INFO - 2016-09-11 13:11:56 --> Final output sent to browser
DEBUG - 2016-09-11 13:11:56 --> Total execution time: 0.4947
INFO - 2016-09-11 13:12:16 --> Config Class Initialized
INFO - 2016-09-11 13:12:16 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:12:16 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:12:16 --> Utf8 Class Initialized
INFO - 2016-09-11 13:12:16 --> URI Class Initialized
INFO - 2016-09-11 13:12:16 --> Router Class Initialized
INFO - 2016-09-11 13:12:16 --> Output Class Initialized
INFO - 2016-09-11 13:12:16 --> Security Class Initialized
DEBUG - 2016-09-11 13:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:12:16 --> Input Class Initialized
INFO - 2016-09-11 13:12:16 --> Language Class Initialized
INFO - 2016-09-11 13:12:16 --> Language Class Initialized
INFO - 2016-09-11 13:12:16 --> Config Class Initialized
INFO - 2016-09-11 13:12:16 --> Loader Class Initialized
INFO - 2016-09-11 13:12:16 --> Helper loaded: url_helper
INFO - 2016-09-11 13:12:16 --> Database Driver Class Initialized
INFO - 2016-09-11 13:12:16 --> Controller Class Initialized
DEBUG - 2016-09-11 13:12:16 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:12:16 --> Model Class Initialized
INFO - 2016-09-11 13:12:16 --> Model Class Initialized
DEBUG - 2016-09-11 13:12:16 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 13:12:16 --> Users MX_Controller Initialized
INFO - 2016-09-11 13:12:16 --> Final output sent to browser
DEBUG - 2016-09-11 13:12:16 --> Total execution time: 0.4778
INFO - 2016-09-11 13:12:31 --> Config Class Initialized
INFO - 2016-09-11 13:12:31 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:12:31 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:12:31 --> Utf8 Class Initialized
INFO - 2016-09-11 13:12:31 --> URI Class Initialized
INFO - 2016-09-11 13:12:31 --> Router Class Initialized
INFO - 2016-09-11 13:12:31 --> Output Class Initialized
INFO - 2016-09-11 13:12:31 --> Security Class Initialized
DEBUG - 2016-09-11 13:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:12:31 --> Input Class Initialized
INFO - 2016-09-11 13:12:31 --> Language Class Initialized
INFO - 2016-09-11 13:12:31 --> Language Class Initialized
INFO - 2016-09-11 13:12:31 --> Config Class Initialized
INFO - 2016-09-11 13:12:31 --> Loader Class Initialized
INFO - 2016-09-11 13:12:31 --> Helper loaded: url_helper
INFO - 2016-09-11 13:12:31 --> Database Driver Class Initialized
INFO - 2016-09-11 13:12:31 --> Controller Class Initialized
DEBUG - 2016-09-11 13:12:31 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:12:32 --> Model Class Initialized
INFO - 2016-09-11 13:12:32 --> Model Class Initialized
DEBUG - 2016-09-11 13:12:32 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 13:12:32 --> Users MX_Controller Initialized
INFO - 2016-09-11 13:12:32 --> Final output sent to browser
DEBUG - 2016-09-11 13:12:32 --> Total execution time: 0.4499
INFO - 2016-09-11 13:13:09 --> Config Class Initialized
INFO - 2016-09-11 13:13:09 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:13:09 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:13:09 --> Utf8 Class Initialized
INFO - 2016-09-11 13:13:09 --> URI Class Initialized
INFO - 2016-09-11 13:13:09 --> Router Class Initialized
INFO - 2016-09-11 13:13:09 --> Output Class Initialized
INFO - 2016-09-11 13:13:09 --> Security Class Initialized
DEBUG - 2016-09-11 13:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:13:09 --> Input Class Initialized
INFO - 2016-09-11 13:13:09 --> Language Class Initialized
INFO - 2016-09-11 13:13:09 --> Language Class Initialized
INFO - 2016-09-11 13:13:09 --> Config Class Initialized
INFO - 2016-09-11 13:13:09 --> Loader Class Initialized
INFO - 2016-09-11 13:13:09 --> Helper loaded: url_helper
INFO - 2016-09-11 13:13:09 --> Database Driver Class Initialized
INFO - 2016-09-11 13:13:09 --> Controller Class Initialized
DEBUG - 2016-09-11 13:13:09 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:13:09 --> Model Class Initialized
INFO - 2016-09-11 13:13:09 --> Model Class Initialized
DEBUG - 2016-09-11 13:13:09 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 13:13:09 --> Users MX_Controller Initialized
INFO - 2016-09-11 13:13:09 --> Final output sent to browser
DEBUG - 2016-09-11 13:13:09 --> Total execution time: 0.5730
INFO - 2016-09-11 13:13:13 --> Config Class Initialized
INFO - 2016-09-11 13:13:13 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:13:14 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:13:14 --> Utf8 Class Initialized
INFO - 2016-09-11 13:13:14 --> URI Class Initialized
INFO - 2016-09-11 13:13:14 --> Router Class Initialized
INFO - 2016-09-11 13:13:14 --> Output Class Initialized
INFO - 2016-09-11 13:13:14 --> Security Class Initialized
DEBUG - 2016-09-11 13:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:13:14 --> Input Class Initialized
INFO - 2016-09-11 13:13:14 --> Language Class Initialized
INFO - 2016-09-11 13:13:14 --> Language Class Initialized
INFO - 2016-09-11 13:13:14 --> Config Class Initialized
INFO - 2016-09-11 13:13:14 --> Loader Class Initialized
INFO - 2016-09-11 13:13:14 --> Helper loaded: url_helper
INFO - 2016-09-11 13:13:14 --> Database Driver Class Initialized
INFO - 2016-09-11 13:13:14 --> Controller Class Initialized
DEBUG - 2016-09-11 13:13:14 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:13:14 --> Model Class Initialized
INFO - 2016-09-11 13:13:14 --> Model Class Initialized
DEBUG - 2016-09-11 13:13:14 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 13:13:14 --> Users MX_Controller Initialized
INFO - 2016-09-11 13:13:14 --> Final output sent to browser
DEBUG - 2016-09-11 13:13:14 --> Total execution time: 0.5257
INFO - 2016-09-11 13:21:50 --> Config Class Initialized
INFO - 2016-09-11 13:21:50 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:21:50 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:21:50 --> Utf8 Class Initialized
INFO - 2016-09-11 13:21:50 --> URI Class Initialized
INFO - 2016-09-11 13:21:50 --> Router Class Initialized
INFO - 2016-09-11 13:21:50 --> Output Class Initialized
INFO - 2016-09-11 13:21:50 --> Security Class Initialized
DEBUG - 2016-09-11 13:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:21:50 --> Input Class Initialized
INFO - 2016-09-11 13:21:50 --> Language Class Initialized
INFO - 2016-09-11 13:21:50 --> Language Class Initialized
INFO - 2016-09-11 13:21:50 --> Config Class Initialized
INFO - 2016-09-11 13:21:50 --> Loader Class Initialized
INFO - 2016-09-11 13:21:50 --> Helper loaded: url_helper
INFO - 2016-09-11 13:21:50 --> Database Driver Class Initialized
INFO - 2016-09-11 13:21:50 --> Controller Class Initialized
DEBUG - 2016-09-11 13:21:50 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:21:50 --> Model Class Initialized
INFO - 2016-09-11 13:21:50 --> Model Class Initialized
DEBUG - 2016-09-11 13:21:50 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 13:21:50 --> Users MX_Controller Initialized
ERROR - 2016-09-11 13:21:50 --> Query error: Unknown column 'no_identita' in 'where clause' - Invalid query: SELECT *
FROM `tm_user`
WHERE `no_identita` = '3573032002930011'
INFO - 2016-09-11 13:21:50 --> Language file loaded: language/english/db_lang.php
INFO - 2016-09-11 13:22:49 --> Config Class Initialized
INFO - 2016-09-11 13:22:49 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:22:49 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:22:49 --> Utf8 Class Initialized
INFO - 2016-09-11 13:22:49 --> URI Class Initialized
INFO - 2016-09-11 13:22:49 --> Router Class Initialized
INFO - 2016-09-11 13:22:49 --> Output Class Initialized
INFO - 2016-09-11 13:22:49 --> Security Class Initialized
DEBUG - 2016-09-11 13:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:22:49 --> Input Class Initialized
INFO - 2016-09-11 13:22:49 --> Language Class Initialized
INFO - 2016-09-11 13:22:49 --> Language Class Initialized
INFO - 2016-09-11 13:22:49 --> Config Class Initialized
INFO - 2016-09-11 13:22:49 --> Loader Class Initialized
INFO - 2016-09-11 13:22:49 --> Helper loaded: url_helper
INFO - 2016-09-11 13:22:49 --> Database Driver Class Initialized
INFO - 2016-09-11 13:22:49 --> Controller Class Initialized
DEBUG - 2016-09-11 13:22:49 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:22:49 --> Model Class Initialized
INFO - 2016-09-11 13:22:49 --> Model Class Initialized
DEBUG - 2016-09-11 13:22:49 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 13:22:49 --> Users MX_Controller Initialized
INFO - 2016-09-11 13:22:50 --> Final output sent to browser
DEBUG - 2016-09-11 13:22:50 --> Total execution time: 0.4589
INFO - 2016-09-11 13:23:28 --> Config Class Initialized
INFO - 2016-09-11 13:23:28 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:23:28 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:23:28 --> Utf8 Class Initialized
INFO - 2016-09-11 13:23:28 --> URI Class Initialized
INFO - 2016-09-11 13:23:28 --> Router Class Initialized
INFO - 2016-09-11 13:23:28 --> Output Class Initialized
INFO - 2016-09-11 13:23:28 --> Security Class Initialized
DEBUG - 2016-09-11 13:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:23:28 --> Input Class Initialized
INFO - 2016-09-11 13:23:28 --> Language Class Initialized
INFO - 2016-09-11 13:23:28 --> Language Class Initialized
INFO - 2016-09-11 13:23:28 --> Config Class Initialized
INFO - 2016-09-11 13:23:28 --> Loader Class Initialized
INFO - 2016-09-11 13:23:28 --> Helper loaded: url_helper
INFO - 2016-09-11 13:23:28 --> Database Driver Class Initialized
INFO - 2016-09-11 13:23:28 --> Controller Class Initialized
DEBUG - 2016-09-11 13:23:28 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:23:28 --> Model Class Initialized
INFO - 2016-09-11 13:23:29 --> Model Class Initialized
DEBUG - 2016-09-11 13:23:29 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 13:23:29 --> Users MX_Controller Initialized
ERROR - 2016-09-11 13:23:29 --> Severity: Notice --> Undefined index: no_hp E:\SERVER\htdocs\koperasiweda\application\modules\User\controllers\Users.php 32
ERROR - 2016-09-11 13:23:29 --> Severity: Notice --> Undefined index: kd_level E:\SERVER\htdocs\koperasiweda\application\modules\User\controllers\Users.php 35
INFO - 2016-09-11 13:23:29 --> Database Driver Class Initialized
INFO - 2016-09-11 13:23:29 --> Final output sent to browser
DEBUG - 2016-09-11 13:23:29 --> Total execution time: 0.6562
INFO - 2016-09-11 13:24:06 --> Config Class Initialized
INFO - 2016-09-11 13:24:06 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:24:06 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:24:06 --> Utf8 Class Initialized
INFO - 2016-09-11 13:24:06 --> URI Class Initialized
INFO - 2016-09-11 13:24:06 --> Router Class Initialized
INFO - 2016-09-11 13:24:06 --> Output Class Initialized
INFO - 2016-09-11 13:24:06 --> Security Class Initialized
DEBUG - 2016-09-11 13:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:24:06 --> Input Class Initialized
INFO - 2016-09-11 13:24:06 --> Language Class Initialized
INFO - 2016-09-11 13:24:06 --> Language Class Initialized
INFO - 2016-09-11 13:24:06 --> Config Class Initialized
INFO - 2016-09-11 13:24:06 --> Loader Class Initialized
INFO - 2016-09-11 13:24:06 --> Helper loaded: url_helper
INFO - 2016-09-11 13:24:06 --> Database Driver Class Initialized
INFO - 2016-09-11 13:24:06 --> Controller Class Initialized
DEBUG - 2016-09-11 13:24:06 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:24:06 --> Model Class Initialized
INFO - 2016-09-11 13:24:06 --> Model Class Initialized
DEBUG - 2016-09-11 13:24:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-11 13:24:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-11 13:24:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-11 13:24:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_user.php
DEBUG - 2016-09-11 13:24:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-11 13:24:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-11 13:24:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-11 13:24:06 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-11 13:24:06 --> Final output sent to browser
DEBUG - 2016-09-11 13:24:06 --> Total execution time: 0.7000
INFO - 2016-09-11 13:24:38 --> Config Class Initialized
INFO - 2016-09-11 13:24:38 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:24:38 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:24:38 --> Utf8 Class Initialized
INFO - 2016-09-11 13:24:38 --> URI Class Initialized
INFO - 2016-09-11 13:24:38 --> Router Class Initialized
INFO - 2016-09-11 13:24:38 --> Output Class Initialized
INFO - 2016-09-11 13:24:38 --> Security Class Initialized
DEBUG - 2016-09-11 13:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:24:38 --> Input Class Initialized
INFO - 2016-09-11 13:24:38 --> Language Class Initialized
INFO - 2016-09-11 13:24:38 --> Language Class Initialized
INFO - 2016-09-11 13:24:38 --> Config Class Initialized
INFO - 2016-09-11 13:24:38 --> Loader Class Initialized
INFO - 2016-09-11 13:24:38 --> Helper loaded: url_helper
INFO - 2016-09-11 13:24:38 --> Database Driver Class Initialized
INFO - 2016-09-11 13:24:38 --> Controller Class Initialized
DEBUG - 2016-09-11 13:24:38 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:24:38 --> Model Class Initialized
INFO - 2016-09-11 13:24:38 --> Model Class Initialized
DEBUG - 2016-09-11 13:24:38 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 13:24:38 --> Users MX_Controller Initialized
INFO - 2016-09-11 13:24:38 --> Final output sent to browser
DEBUG - 2016-09-11 13:24:38 --> Total execution time: 0.5791
INFO - 2016-09-11 13:24:47 --> Config Class Initialized
INFO - 2016-09-11 13:24:47 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:24:47 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:24:47 --> Utf8 Class Initialized
INFO - 2016-09-11 13:24:47 --> URI Class Initialized
INFO - 2016-09-11 13:24:47 --> Router Class Initialized
INFO - 2016-09-11 13:24:47 --> Output Class Initialized
INFO - 2016-09-11 13:24:47 --> Security Class Initialized
DEBUG - 2016-09-11 13:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:24:47 --> Input Class Initialized
INFO - 2016-09-11 13:24:47 --> Language Class Initialized
INFO - 2016-09-11 13:24:47 --> Language Class Initialized
INFO - 2016-09-11 13:24:47 --> Config Class Initialized
INFO - 2016-09-11 13:24:47 --> Loader Class Initialized
INFO - 2016-09-11 13:24:47 --> Helper loaded: url_helper
INFO - 2016-09-11 13:24:47 --> Database Driver Class Initialized
INFO - 2016-09-11 13:24:47 --> Controller Class Initialized
DEBUG - 2016-09-11 13:24:47 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:24:47 --> Model Class Initialized
INFO - 2016-09-11 13:24:47 --> Model Class Initialized
DEBUG - 2016-09-11 13:24:47 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 13:24:47 --> Users MX_Controller Initialized
ERROR - 2016-09-11 13:24:47 --> Severity: Notice --> Undefined index: kd_level E:\SERVER\htdocs\koperasiweda\application\modules\User\controllers\Users.php 35
INFO - 2016-09-11 13:24:47 --> Database Driver Class Initialized
INFO - 2016-09-11 13:24:47 --> Final output sent to browser
DEBUG - 2016-09-11 13:24:47 --> Total execution time: 0.6931
INFO - 2016-09-11 13:25:08 --> Config Class Initialized
INFO - 2016-09-11 13:25:08 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:25:08 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:25:08 --> Utf8 Class Initialized
INFO - 2016-09-11 13:25:08 --> URI Class Initialized
INFO - 2016-09-11 13:25:08 --> Router Class Initialized
INFO - 2016-09-11 13:25:08 --> Output Class Initialized
INFO - 2016-09-11 13:25:08 --> Security Class Initialized
DEBUG - 2016-09-11 13:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:25:08 --> Input Class Initialized
INFO - 2016-09-11 13:25:08 --> Language Class Initialized
INFO - 2016-09-11 13:25:08 --> Language Class Initialized
INFO - 2016-09-11 13:25:08 --> Config Class Initialized
INFO - 2016-09-11 13:25:08 --> Loader Class Initialized
INFO - 2016-09-11 13:25:08 --> Helper loaded: url_helper
INFO - 2016-09-11 13:25:08 --> Database Driver Class Initialized
INFO - 2016-09-11 13:25:08 --> Controller Class Initialized
DEBUG - 2016-09-11 13:25:08 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:25:08 --> Model Class Initialized
INFO - 2016-09-11 13:25:08 --> Model Class Initialized
DEBUG - 2016-09-11 13:25:08 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 13:25:08 --> Users MX_Controller Initialized
INFO - 2016-09-11 13:25:08 --> Final output sent to browser
DEBUG - 2016-09-11 13:25:08 --> Total execution time: 0.5052
INFO - 2016-09-11 13:25:23 --> Config Class Initialized
INFO - 2016-09-11 13:25:23 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:25:23 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:25:23 --> Utf8 Class Initialized
INFO - 2016-09-11 13:25:23 --> URI Class Initialized
INFO - 2016-09-11 13:25:23 --> Router Class Initialized
INFO - 2016-09-11 13:25:23 --> Output Class Initialized
INFO - 2016-09-11 13:25:23 --> Security Class Initialized
DEBUG - 2016-09-11 13:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:25:23 --> Input Class Initialized
INFO - 2016-09-11 13:25:23 --> Language Class Initialized
INFO - 2016-09-11 13:25:23 --> Language Class Initialized
INFO - 2016-09-11 13:25:23 --> Config Class Initialized
INFO - 2016-09-11 13:25:23 --> Loader Class Initialized
INFO - 2016-09-11 13:25:23 --> Helper loaded: url_helper
INFO - 2016-09-11 13:25:23 --> Database Driver Class Initialized
INFO - 2016-09-11 13:25:23 --> Controller Class Initialized
DEBUG - 2016-09-11 13:25:23 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:25:23 --> Model Class Initialized
INFO - 2016-09-11 13:25:23 --> Model Class Initialized
DEBUG - 2016-09-11 13:25:23 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 13:25:23 --> Users MX_Controller Initialized
INFO - 2016-09-11 13:25:23 --> Database Driver Class Initialized
ERROR - 2016-09-11 13:25:24 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`koperasi`.`tm_user`, CONSTRAINT `FK_tm_user_tm_level` FOREIGN KEY (`kd_level`) REFERENCES `tm_level` (`kd_level`)) - Invalid query: INSERT INTO `tm_user` (`nama`, `alamat`, `tanggal_lahir`, `tanggal_masuk`, `no_identitas`, `no_hp`, `username`, `password`, `kd_level`) VALUES ('Muhammad Handharbeni', 'Puri Cempaka Putih AS 20', '1993-02-20', '2016-09-11', '3573032002930011', '081556617741', 'mhandharbeni', '827ccb0eea8a706c4c34a16891f84e7b', '0')
INFO - 2016-09-11 13:25:24 --> Language file loaded: language/english/db_lang.php
INFO - 2016-09-11 13:26:26 --> Config Class Initialized
INFO - 2016-09-11 13:26:26 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:26:26 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:26:26 --> Utf8 Class Initialized
INFO - 2016-09-11 13:26:26 --> URI Class Initialized
INFO - 2016-09-11 13:26:26 --> Router Class Initialized
INFO - 2016-09-11 13:26:26 --> Output Class Initialized
INFO - 2016-09-11 13:26:26 --> Security Class Initialized
DEBUG - 2016-09-11 13:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:26:26 --> Input Class Initialized
INFO - 2016-09-11 13:26:26 --> Language Class Initialized
INFO - 2016-09-11 13:26:26 --> Language Class Initialized
INFO - 2016-09-11 13:26:26 --> Config Class Initialized
INFO - 2016-09-11 13:26:26 --> Loader Class Initialized
INFO - 2016-09-11 13:26:26 --> Helper loaded: url_helper
INFO - 2016-09-11 13:26:26 --> Database Driver Class Initialized
INFO - 2016-09-11 13:26:26 --> Controller Class Initialized
DEBUG - 2016-09-11 13:26:26 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:26:26 --> Model Class Initialized
INFO - 2016-09-11 13:26:26 --> Model Class Initialized
DEBUG - 2016-09-11 13:26:26 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 13:26:26 --> Users MX_Controller Initialized
INFO - 2016-09-11 13:26:26 --> Database Driver Class Initialized
INFO - 2016-09-11 13:26:26 --> Final output sent to browser
DEBUG - 2016-09-11 13:26:26 --> Total execution time: 0.6239
INFO - 2016-09-11 13:26:34 --> Config Class Initialized
INFO - 2016-09-11 13:26:34 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:26:34 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:26:34 --> Utf8 Class Initialized
INFO - 2016-09-11 13:26:34 --> URI Class Initialized
INFO - 2016-09-11 13:26:34 --> Router Class Initialized
INFO - 2016-09-11 13:26:34 --> Output Class Initialized
INFO - 2016-09-11 13:26:34 --> Security Class Initialized
DEBUG - 2016-09-11 13:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:26:34 --> Input Class Initialized
INFO - 2016-09-11 13:26:34 --> Language Class Initialized
INFO - 2016-09-11 13:26:34 --> Language Class Initialized
INFO - 2016-09-11 13:26:34 --> Config Class Initialized
INFO - 2016-09-11 13:26:34 --> Loader Class Initialized
INFO - 2016-09-11 13:26:34 --> Helper loaded: url_helper
INFO - 2016-09-11 13:26:34 --> Database Driver Class Initialized
INFO - 2016-09-11 13:26:34 --> Controller Class Initialized
DEBUG - 2016-09-11 13:26:34 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:26:34 --> Model Class Initialized
INFO - 2016-09-11 13:26:35 --> Model Class Initialized
DEBUG - 2016-09-11 13:26:35 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 13:26:35 --> Users MX_Controller Initialized
INFO - 2016-09-11 13:26:35 --> Final output sent to browser
DEBUG - 2016-09-11 13:26:35 --> Total execution time: 0.5166
INFO - 2016-09-11 13:39:59 --> Config Class Initialized
INFO - 2016-09-11 13:39:59 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:39:59 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:39:59 --> Utf8 Class Initialized
INFO - 2016-09-11 13:39:59 --> URI Class Initialized
INFO - 2016-09-11 13:39:59 --> Router Class Initialized
INFO - 2016-09-11 13:39:59 --> Output Class Initialized
INFO - 2016-09-11 13:39:59 --> Security Class Initialized
DEBUG - 2016-09-11 13:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:39:59 --> Input Class Initialized
INFO - 2016-09-11 13:39:59 --> Language Class Initialized
INFO - 2016-09-11 13:39:59 --> Language Class Initialized
INFO - 2016-09-11 13:39:59 --> Config Class Initialized
INFO - 2016-09-11 13:39:59 --> Loader Class Initialized
INFO - 2016-09-11 13:39:59 --> Helper loaded: url_helper
INFO - 2016-09-11 13:39:59 --> Database Driver Class Initialized
INFO - 2016-09-11 13:39:59 --> Controller Class Initialized
DEBUG - 2016-09-11 13:39:59 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:39:59 --> Model Class Initialized
INFO - 2016-09-11 13:39:59 --> Model Class Initialized
DEBUG - 2016-09-11 13:39:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-11 13:40:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-11 13:40:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-11 13:40:00 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-11 13:40:00 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 13:40:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_user.php
DEBUG - 2016-09-11 13:40:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-11 13:40:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-11 13:40:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-11 13:40:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-11 13:40:00 --> Final output sent to browser
DEBUG - 2016-09-11 13:40:00 --> Total execution time: 1.1242
INFO - 2016-09-11 13:40:53 --> Config Class Initialized
INFO - 2016-09-11 13:40:53 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:40:54 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:40:54 --> Utf8 Class Initialized
INFO - 2016-09-11 13:40:54 --> URI Class Initialized
INFO - 2016-09-11 13:40:54 --> Router Class Initialized
INFO - 2016-09-11 13:40:54 --> Output Class Initialized
INFO - 2016-09-11 13:40:54 --> Security Class Initialized
DEBUG - 2016-09-11 13:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:40:54 --> Input Class Initialized
INFO - 2016-09-11 13:40:54 --> Language Class Initialized
INFO - 2016-09-11 13:40:54 --> Language Class Initialized
INFO - 2016-09-11 13:40:54 --> Config Class Initialized
INFO - 2016-09-11 13:40:54 --> Loader Class Initialized
INFO - 2016-09-11 13:40:54 --> Helper loaded: url_helper
INFO - 2016-09-11 13:40:54 --> Database Driver Class Initialized
INFO - 2016-09-11 13:40:54 --> Controller Class Initialized
DEBUG - 2016-09-11 13:40:54 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:40:54 --> Model Class Initialized
INFO - 2016-09-11 13:40:54 --> Model Class Initialized
DEBUG - 2016-09-11 13:40:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-11 13:40:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-11 13:40:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-11 13:40:54 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/user/controllers/Users.php
DEBUG - 2016-09-11 13:40:54 --> Users MX_Controller Initialized
ERROR - 2016-09-11 13:40:54 --> Severity: Notice --> Undefined index: kd_anggota E:\SERVER\htdocs\koperasiweda\application\views\main_html\content\list_user.php 32
ERROR - 2016-09-11 13:40:54 --> Severity: Notice --> Undefined index: kd_anggota E:\SERVER\htdocs\koperasiweda\application\views\main_html\content\list_user.php 32
ERROR - 2016-09-11 13:40:54 --> Severity: Notice --> Undefined index: kd_anggota E:\SERVER\htdocs\koperasiweda\application\views\main_html\content\list_user.php 32
ERROR - 2016-09-11 13:40:54 --> Severity: Notice --> Undefined index: kd_anggota E:\SERVER\htdocs\koperasiweda\application\views\main_html\content\list_user.php 34
ERROR - 2016-09-11 13:40:54 --> Severity: Notice --> Undefined index: kd_anggota E:\SERVER\htdocs\koperasiweda\application\views\main_html\content\list_user.php 34
ERROR - 2016-09-11 13:40:54 --> Severity: Notice --> Undefined index: kd_anggota E:\SERVER\htdocs\koperasiweda\application\views\main_html\content\list_user.php 34
ERROR - 2016-09-11 13:40:54 --> Severity: Notice --> Undefined index: kd_anggota E:\SERVER\htdocs\koperasiweda\application\views\main_html\content\list_user.php 32
ERROR - 2016-09-11 13:40:54 --> Severity: Notice --> Undefined index: kd_anggota E:\SERVER\htdocs\koperasiweda\application\views\main_html\content\list_user.php 32
ERROR - 2016-09-11 13:40:54 --> Severity: Notice --> Undefined index: kd_anggota E:\SERVER\htdocs\koperasiweda\application\views\main_html\content\list_user.php 32
ERROR - 2016-09-11 13:40:54 --> Severity: Notice --> Undefined index: kd_anggota E:\SERVER\htdocs\koperasiweda\application\views\main_html\content\list_user.php 34
ERROR - 2016-09-11 13:40:54 --> Severity: Notice --> Undefined index: kd_anggota E:\SERVER\htdocs\koperasiweda\application\views\main_html\content\list_user.php 34
ERROR - 2016-09-11 13:40:54 --> Severity: Notice --> Undefined index: kd_anggota E:\SERVER\htdocs\koperasiweda\application\views\main_html\content\list_user.php 34
ERROR - 2016-09-11 13:40:54 --> Severity: Notice --> Undefined index: kd_anggota E:\SERVER\htdocs\koperasiweda\application\views\main_html\content\list_user.php 32
ERROR - 2016-09-11 13:40:54 --> Severity: Notice --> Undefined index: kd_anggota E:\SERVER\htdocs\koperasiweda\application\views\main_html\content\list_user.php 32
ERROR - 2016-09-11 13:40:54 --> Severity: Notice --> Undefined index: kd_anggota E:\SERVER\htdocs\koperasiweda\application\views\main_html\content\list_user.php 32
ERROR - 2016-09-11 13:40:54 --> Severity: Notice --> Undefined index: kd_anggota E:\SERVER\htdocs\koperasiweda\application\views\main_html\content\list_user.php 34
ERROR - 2016-09-11 13:40:54 --> Severity: Notice --> Undefined index: kd_anggota E:\SERVER\htdocs\koperasiweda\application\views\main_html\content\list_user.php 34
ERROR - 2016-09-11 13:40:54 --> Severity: Notice --> Undefined index: kd_anggota E:\SERVER\htdocs\koperasiweda\application\views\main_html\content\list_user.php 34
ERROR - 2016-09-11 13:40:54 --> Severity: Notice --> Undefined index: kd_anggota E:\SERVER\htdocs\koperasiweda\application\views\main_html\content\list_user.php 32
ERROR - 2016-09-11 13:40:55 --> Severity: Notice --> Undefined index: kd_anggota E:\SERVER\htdocs\koperasiweda\application\views\main_html\content\list_user.php 32
ERROR - 2016-09-11 13:40:55 --> Severity: Notice --> Undefined index: kd_anggota E:\SERVER\htdocs\koperasiweda\application\views\main_html\content\list_user.php 32
ERROR - 2016-09-11 13:40:55 --> Severity: Notice --> Undefined index: kd_anggota E:\SERVER\htdocs\koperasiweda\application\views\main_html\content\list_user.php 34
ERROR - 2016-09-11 13:40:55 --> Severity: Notice --> Undefined index: kd_anggota E:\SERVER\htdocs\koperasiweda\application\views\main_html\content\list_user.php 34
ERROR - 2016-09-11 13:40:55 --> Severity: Notice --> Undefined index: kd_anggota E:\SERVER\htdocs\koperasiweda\application\views\main_html\content\list_user.php 34
DEBUG - 2016-09-11 13:40:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_user.php
DEBUG - 2016-09-11 13:40:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-11 13:40:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-11 13:40:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-11 13:40:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-11 13:40:55 --> Final output sent to browser
DEBUG - 2016-09-11 13:40:55 --> Total execution time: 1.3002
INFO - 2016-09-11 13:41:18 --> Config Class Initialized
INFO - 2016-09-11 13:41:18 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:41:18 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:41:18 --> Utf8 Class Initialized
INFO - 2016-09-11 13:41:18 --> URI Class Initialized
INFO - 2016-09-11 13:41:18 --> Router Class Initialized
INFO - 2016-09-11 13:41:18 --> Output Class Initialized
INFO - 2016-09-11 13:41:18 --> Security Class Initialized
DEBUG - 2016-09-11 13:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:41:19 --> Input Class Initialized
INFO - 2016-09-11 13:41:19 --> Language Class Initialized
INFO - 2016-09-11 13:41:19 --> Language Class Initialized
INFO - 2016-09-11 13:41:19 --> Config Class Initialized
INFO - 2016-09-11 13:41:19 --> Loader Class Initialized
INFO - 2016-09-11 13:41:19 --> Helper loaded: url_helper
INFO - 2016-09-11 13:41:19 --> Database Driver Class Initialized
INFO - 2016-09-11 13:41:19 --> Controller Class Initialized
DEBUG - 2016-09-11 13:41:19 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:41:19 --> Model Class Initialized
INFO - 2016-09-11 13:41:19 --> Model Class Initialized
DEBUG - 2016-09-11 13:41:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-11 13:41:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-11 13:41:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-11 13:41:19 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/user/controllers/Users.php
DEBUG - 2016-09-11 13:41:19 --> Users MX_Controller Initialized
DEBUG - 2016-09-11 13:41:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_user.php
DEBUG - 2016-09-11 13:41:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-11 13:41:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-11 13:41:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-11 13:41:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-11 13:41:19 --> Final output sent to browser
DEBUG - 2016-09-11 13:41:19 --> Total execution time: 0.6943
INFO - 2016-09-11 13:41:23 --> Config Class Initialized
INFO - 2016-09-11 13:41:23 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:41:23 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:41:23 --> Utf8 Class Initialized
INFO - 2016-09-11 13:41:23 --> URI Class Initialized
INFO - 2016-09-11 13:41:23 --> Router Class Initialized
INFO - 2016-09-11 13:41:23 --> Output Class Initialized
INFO - 2016-09-11 13:41:23 --> Security Class Initialized
DEBUG - 2016-09-11 13:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:41:23 --> Input Class Initialized
INFO - 2016-09-11 13:41:23 --> Language Class Initialized
INFO - 2016-09-11 13:41:23 --> Language Class Initialized
INFO - 2016-09-11 13:41:23 --> Config Class Initialized
INFO - 2016-09-11 13:41:23 --> Loader Class Initialized
INFO - 2016-09-11 13:41:23 --> Helper loaded: url_helper
INFO - 2016-09-11 13:41:23 --> Database Driver Class Initialized
INFO - 2016-09-11 13:41:23 --> Controller Class Initialized
DEBUG - 2016-09-11 13:41:23 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:41:23 --> Model Class Initialized
INFO - 2016-09-11 13:41:23 --> Model Class Initialized
DEBUG - 2016-09-11 13:41:23 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 13:41:23 --> Users MX_Controller Initialized
ERROR - 2016-09-11 13:41:23 --> Severity: Notice --> Undefined variable: item E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 116
INFO - 2016-09-11 13:41:23 --> Final output sent to browser
DEBUG - 2016-09-11 13:41:23 --> Total execution time: 0.7264
INFO - 2016-09-11 13:42:24 --> Config Class Initialized
INFO - 2016-09-11 13:42:24 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:42:24 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:42:24 --> Utf8 Class Initialized
INFO - 2016-09-11 13:42:24 --> URI Class Initialized
INFO - 2016-09-11 13:42:24 --> Router Class Initialized
INFO - 2016-09-11 13:42:24 --> Output Class Initialized
INFO - 2016-09-11 13:42:24 --> Security Class Initialized
DEBUG - 2016-09-11 13:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:42:24 --> Input Class Initialized
INFO - 2016-09-11 13:42:24 --> Language Class Initialized
INFO - 2016-09-11 13:42:24 --> Language Class Initialized
INFO - 2016-09-11 13:42:25 --> Config Class Initialized
INFO - 2016-09-11 13:42:25 --> Loader Class Initialized
INFO - 2016-09-11 13:42:25 --> Helper loaded: url_helper
INFO - 2016-09-11 13:42:25 --> Database Driver Class Initialized
INFO - 2016-09-11 13:42:25 --> Controller Class Initialized
DEBUG - 2016-09-11 13:42:25 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:42:25 --> Model Class Initialized
INFO - 2016-09-11 13:42:25 --> Model Class Initialized
DEBUG - 2016-09-11 13:42:25 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 13:42:25 --> Users MX_Controller Initialized
ERROR - 2016-09-11 13:42:25 --> Severity: Notice --> Undefined variable: item E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 116
INFO - 2016-09-11 13:42:25 --> Final output sent to browser
DEBUG - 2016-09-11 13:42:25 --> Total execution time: 0.8036
INFO - 2016-09-11 13:43:28 --> Config Class Initialized
INFO - 2016-09-11 13:43:28 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:43:28 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:43:28 --> Utf8 Class Initialized
INFO - 2016-09-11 13:43:28 --> URI Class Initialized
INFO - 2016-09-11 13:43:28 --> Router Class Initialized
INFO - 2016-09-11 13:43:28 --> Output Class Initialized
INFO - 2016-09-11 13:43:28 --> Security Class Initialized
DEBUG - 2016-09-11 13:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:43:28 --> Input Class Initialized
INFO - 2016-09-11 13:43:28 --> Language Class Initialized
INFO - 2016-09-11 13:43:28 --> Language Class Initialized
INFO - 2016-09-11 13:43:28 --> Config Class Initialized
INFO - 2016-09-11 13:43:28 --> Loader Class Initialized
INFO - 2016-09-11 13:43:28 --> Helper loaded: url_helper
INFO - 2016-09-11 13:43:28 --> Database Driver Class Initialized
INFO - 2016-09-11 13:43:28 --> Controller Class Initialized
DEBUG - 2016-09-11 13:43:28 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:43:28 --> Model Class Initialized
INFO - 2016-09-11 13:43:28 --> Model Class Initialized
DEBUG - 2016-09-11 13:43:28 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 13:43:28 --> Users MX_Controller Initialized
INFO - 2016-09-11 13:43:28 --> Final output sent to browser
DEBUG - 2016-09-11 13:43:28 --> Total execution time: 0.5232
INFO - 2016-09-11 13:44:23 --> Config Class Initialized
INFO - 2016-09-11 13:44:23 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:44:23 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:44:23 --> Utf8 Class Initialized
INFO - 2016-09-11 13:44:23 --> URI Class Initialized
INFO - 2016-09-11 13:44:23 --> Router Class Initialized
INFO - 2016-09-11 13:44:23 --> Output Class Initialized
INFO - 2016-09-11 13:44:24 --> Security Class Initialized
DEBUG - 2016-09-11 13:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:44:24 --> Input Class Initialized
INFO - 2016-09-11 13:44:24 --> Language Class Initialized
INFO - 2016-09-11 13:44:24 --> Language Class Initialized
INFO - 2016-09-11 13:44:24 --> Config Class Initialized
INFO - 2016-09-11 13:44:24 --> Loader Class Initialized
INFO - 2016-09-11 13:44:24 --> Helper loaded: url_helper
INFO - 2016-09-11 13:44:24 --> Database Driver Class Initialized
INFO - 2016-09-11 13:44:24 --> Controller Class Initialized
DEBUG - 2016-09-11 13:44:24 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:44:24 --> Model Class Initialized
INFO - 2016-09-11 13:44:24 --> Model Class Initialized
DEBUG - 2016-09-11 13:44:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-11 13:44:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-11 13:44:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-11 13:44:24 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/user/controllers/Users.php
DEBUG - 2016-09-11 13:44:24 --> Users MX_Controller Initialized
DEBUG - 2016-09-11 13:44:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_user.php
DEBUG - 2016-09-11 13:44:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-11 13:44:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-11 13:44:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-11 13:44:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-11 13:44:24 --> Final output sent to browser
DEBUG - 2016-09-11 13:44:24 --> Total execution time: 0.6882
INFO - 2016-09-11 13:44:31 --> Config Class Initialized
INFO - 2016-09-11 13:44:31 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:44:31 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:44:31 --> Utf8 Class Initialized
INFO - 2016-09-11 13:44:31 --> URI Class Initialized
INFO - 2016-09-11 13:44:31 --> Router Class Initialized
INFO - 2016-09-11 13:44:31 --> Output Class Initialized
INFO - 2016-09-11 13:44:31 --> Security Class Initialized
DEBUG - 2016-09-11 13:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:44:31 --> Input Class Initialized
INFO - 2016-09-11 13:44:31 --> Language Class Initialized
INFO - 2016-09-11 13:44:31 --> Language Class Initialized
INFO - 2016-09-11 13:44:31 --> Config Class Initialized
INFO - 2016-09-11 13:44:31 --> Loader Class Initialized
INFO - 2016-09-11 13:44:31 --> Helper loaded: url_helper
INFO - 2016-09-11 13:44:31 --> Database Driver Class Initialized
INFO - 2016-09-11 13:44:31 --> Controller Class Initialized
DEBUG - 2016-09-11 13:44:31 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:44:31 --> Model Class Initialized
INFO - 2016-09-11 13:44:31 --> Model Class Initialized
DEBUG - 2016-09-11 13:44:31 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 13:44:31 --> Users MX_Controller Initialized
INFO - 2016-09-11 13:44:32 --> Final output sent to browser
DEBUG - 2016-09-11 13:44:32 --> Total execution time: 0.6417
INFO - 2016-09-11 13:44:35 --> Config Class Initialized
INFO - 2016-09-11 13:44:35 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:44:35 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:44:35 --> Utf8 Class Initialized
INFO - 2016-09-11 13:44:36 --> URI Class Initialized
INFO - 2016-09-11 13:44:36 --> Router Class Initialized
INFO - 2016-09-11 13:44:36 --> Output Class Initialized
INFO - 2016-09-11 13:44:36 --> Security Class Initialized
DEBUG - 2016-09-11 13:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:44:36 --> Input Class Initialized
INFO - 2016-09-11 13:44:36 --> Language Class Initialized
INFO - 2016-09-11 13:44:36 --> Language Class Initialized
INFO - 2016-09-11 13:44:36 --> Config Class Initialized
INFO - 2016-09-11 13:44:36 --> Loader Class Initialized
INFO - 2016-09-11 13:44:36 --> Helper loaded: url_helper
INFO - 2016-09-11 13:44:36 --> Database Driver Class Initialized
INFO - 2016-09-11 13:44:36 --> Controller Class Initialized
DEBUG - 2016-09-11 13:44:36 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:44:36 --> Model Class Initialized
INFO - 2016-09-11 13:44:36 --> Model Class Initialized
DEBUG - 2016-09-11 13:44:36 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 13:44:36 --> Users MX_Controller Initialized
ERROR - 2016-09-11 13:44:36 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`koperasi`.`tm_anggota`, CONSTRAINT `FK_tm_anggota_tm_user` FOREIGN KEY (`kd_user`) REFERENCES `tm_user` (`kd_user`)) - Invalid query: DELETE FROM `tm_user`
WHERE sha1(kd_user) = '356a192b7913b04c54574d18c28d46e6395428ab'
INFO - 2016-09-11 13:44:36 --> Language file loaded: language/english/db_lang.php
INFO - 2016-09-11 13:44:40 --> Config Class Initialized
INFO - 2016-09-11 13:44:40 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:44:40 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:44:40 --> Utf8 Class Initialized
INFO - 2016-09-11 13:44:40 --> URI Class Initialized
INFO - 2016-09-11 13:44:40 --> Router Class Initialized
INFO - 2016-09-11 13:44:40 --> Output Class Initialized
INFO - 2016-09-11 13:44:40 --> Security Class Initialized
DEBUG - 2016-09-11 13:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:44:40 --> Input Class Initialized
INFO - 2016-09-11 13:44:40 --> Language Class Initialized
INFO - 2016-09-11 13:44:40 --> Language Class Initialized
INFO - 2016-09-11 13:44:40 --> Config Class Initialized
INFO - 2016-09-11 13:44:40 --> Loader Class Initialized
INFO - 2016-09-11 13:44:40 --> Helper loaded: url_helper
INFO - 2016-09-11 13:44:40 --> Database Driver Class Initialized
INFO - 2016-09-11 13:44:41 --> Controller Class Initialized
DEBUG - 2016-09-11 13:44:41 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:44:41 --> Model Class Initialized
INFO - 2016-09-11 13:44:41 --> Model Class Initialized
DEBUG - 2016-09-11 13:44:41 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 13:44:41 --> Users MX_Controller Initialized
ERROR - 2016-09-11 13:44:41 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`koperasi`.`tm_anggota`, CONSTRAINT `FK_tm_anggota_tm_user` FOREIGN KEY (`kd_user`) REFERENCES `tm_user` (`kd_user`)) - Invalid query: DELETE FROM `tm_user`
WHERE sha1(kd_user) = '356a192b7913b04c54574d18c28d46e6395428ab'
INFO - 2016-09-11 13:44:41 --> Language file loaded: language/english/db_lang.php
INFO - 2016-09-11 13:44:45 --> Config Class Initialized
INFO - 2016-09-11 13:44:45 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:44:45 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:44:45 --> Utf8 Class Initialized
INFO - 2016-09-11 13:44:45 --> URI Class Initialized
INFO - 2016-09-11 13:44:45 --> Router Class Initialized
INFO - 2016-09-11 13:44:45 --> Output Class Initialized
INFO - 2016-09-11 13:44:45 --> Security Class Initialized
DEBUG - 2016-09-11 13:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:44:45 --> Input Class Initialized
INFO - 2016-09-11 13:44:45 --> Language Class Initialized
INFO - 2016-09-11 13:44:45 --> Language Class Initialized
INFO - 2016-09-11 13:44:45 --> Config Class Initialized
INFO - 2016-09-11 13:44:45 --> Loader Class Initialized
INFO - 2016-09-11 13:44:45 --> Helper loaded: url_helper
INFO - 2016-09-11 13:44:45 --> Database Driver Class Initialized
INFO - 2016-09-11 13:44:45 --> Controller Class Initialized
DEBUG - 2016-09-11 13:44:45 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:44:45 --> Model Class Initialized
INFO - 2016-09-11 13:44:45 --> Model Class Initialized
DEBUG - 2016-09-11 13:44:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-11 13:44:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-11 13:44:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-11 13:44:46 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/user/controllers/Users.php
DEBUG - 2016-09-11 13:44:46 --> Users MX_Controller Initialized
DEBUG - 2016-09-11 13:44:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_user.php
DEBUG - 2016-09-11 13:44:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-11 13:44:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-11 13:44:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-11 13:44:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-11 13:44:46 --> Final output sent to browser
DEBUG - 2016-09-11 13:44:46 --> Total execution time: 0.7293
INFO - 2016-09-11 13:44:51 --> Config Class Initialized
INFO - 2016-09-11 13:44:51 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:44:51 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:44:51 --> Utf8 Class Initialized
INFO - 2016-09-11 13:44:51 --> URI Class Initialized
INFO - 2016-09-11 13:44:51 --> Router Class Initialized
INFO - 2016-09-11 13:44:51 --> Output Class Initialized
INFO - 2016-09-11 13:44:52 --> Security Class Initialized
DEBUG - 2016-09-11 13:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:44:52 --> Input Class Initialized
INFO - 2016-09-11 13:44:52 --> Language Class Initialized
INFO - 2016-09-11 13:44:52 --> Language Class Initialized
INFO - 2016-09-11 13:44:52 --> Config Class Initialized
INFO - 2016-09-11 13:44:52 --> Loader Class Initialized
INFO - 2016-09-11 13:44:52 --> Helper loaded: url_helper
INFO - 2016-09-11 13:44:52 --> Database Driver Class Initialized
INFO - 2016-09-11 13:44:52 --> Controller Class Initialized
DEBUG - 2016-09-11 13:44:52 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:44:52 --> Model Class Initialized
INFO - 2016-09-11 13:44:52 --> Model Class Initialized
DEBUG - 2016-09-11 13:44:52 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 13:44:52 --> Users MX_Controller Initialized
ERROR - 2016-09-11 13:44:52 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`koperasi`.`tm_anggota`, CONSTRAINT `FK_tm_anggota_tm_user` FOREIGN KEY (`kd_user`) REFERENCES `tm_user` (`kd_user`)) - Invalid query: DELETE FROM `tm_user`
WHERE sha1(kd_user) = '356a192b7913b04c54574d18c28d46e6395428ab'
INFO - 2016-09-11 13:44:52 --> Language file loaded: language/english/db_lang.php
INFO - 2016-09-11 13:44:56 --> Config Class Initialized
INFO - 2016-09-11 13:44:56 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:44:56 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:44:56 --> Utf8 Class Initialized
INFO - 2016-09-11 13:44:57 --> URI Class Initialized
INFO - 2016-09-11 13:44:57 --> Router Class Initialized
INFO - 2016-09-11 13:44:57 --> Output Class Initialized
INFO - 2016-09-11 13:44:57 --> Security Class Initialized
DEBUG - 2016-09-11 13:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:44:57 --> Input Class Initialized
INFO - 2016-09-11 13:44:57 --> Language Class Initialized
INFO - 2016-09-11 13:44:57 --> Language Class Initialized
INFO - 2016-09-11 13:44:57 --> Config Class Initialized
INFO - 2016-09-11 13:44:57 --> Loader Class Initialized
INFO - 2016-09-11 13:44:57 --> Helper loaded: url_helper
INFO - 2016-09-11 13:44:57 --> Database Driver Class Initialized
INFO - 2016-09-11 13:44:57 --> Controller Class Initialized
DEBUG - 2016-09-11 13:44:57 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:44:57 --> Model Class Initialized
INFO - 2016-09-11 13:44:57 --> Model Class Initialized
DEBUG - 2016-09-11 13:44:57 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 13:44:57 --> Users MX_Controller Initialized
INFO - 2016-09-11 13:44:57 --> Final output sent to browser
DEBUG - 2016-09-11 13:44:57 --> Total execution time: 0.6623
INFO - 2016-09-11 13:45:01 --> Config Class Initialized
INFO - 2016-09-11 13:45:01 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:45:01 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:45:01 --> Utf8 Class Initialized
INFO - 2016-09-11 13:45:01 --> URI Class Initialized
INFO - 2016-09-11 13:45:01 --> Router Class Initialized
INFO - 2016-09-11 13:45:01 --> Output Class Initialized
INFO - 2016-09-11 13:45:01 --> Security Class Initialized
DEBUG - 2016-09-11 13:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:45:01 --> Input Class Initialized
INFO - 2016-09-11 13:45:02 --> Language Class Initialized
INFO - 2016-09-11 13:45:02 --> Language Class Initialized
INFO - 2016-09-11 13:45:02 --> Config Class Initialized
INFO - 2016-09-11 13:45:02 --> Loader Class Initialized
INFO - 2016-09-11 13:45:02 --> Helper loaded: url_helper
INFO - 2016-09-11 13:45:02 --> Database Driver Class Initialized
INFO - 2016-09-11 13:45:02 --> Controller Class Initialized
DEBUG - 2016-09-11 13:45:02 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:45:02 --> Model Class Initialized
INFO - 2016-09-11 13:45:02 --> Model Class Initialized
DEBUG - 2016-09-11 13:45:02 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 13:45:02 --> Users MX_Controller Initialized
INFO - 2016-09-11 13:45:02 --> Final output sent to browser
DEBUG - 2016-09-11 13:45:02 --> Total execution time: 0.5976
INFO - 2016-09-11 13:45:04 --> Config Class Initialized
INFO - 2016-09-11 13:45:04 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:45:04 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:45:04 --> Utf8 Class Initialized
INFO - 2016-09-11 13:45:04 --> URI Class Initialized
INFO - 2016-09-11 13:45:04 --> Router Class Initialized
INFO - 2016-09-11 13:45:04 --> Output Class Initialized
INFO - 2016-09-11 13:45:04 --> Security Class Initialized
DEBUG - 2016-09-11 13:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:45:04 --> Input Class Initialized
INFO - 2016-09-11 13:45:04 --> Language Class Initialized
INFO - 2016-09-11 13:45:04 --> Language Class Initialized
INFO - 2016-09-11 13:45:04 --> Config Class Initialized
INFO - 2016-09-11 13:45:04 --> Loader Class Initialized
INFO - 2016-09-11 13:45:04 --> Helper loaded: url_helper
INFO - 2016-09-11 13:45:04 --> Database Driver Class Initialized
INFO - 2016-09-11 13:45:04 --> Controller Class Initialized
DEBUG - 2016-09-11 13:45:04 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:45:05 --> Model Class Initialized
INFO - 2016-09-11 13:45:05 --> Model Class Initialized
DEBUG - 2016-09-11 13:45:05 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 13:45:05 --> Users MX_Controller Initialized
ERROR - 2016-09-11 13:45:05 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`koperasi`.`tm_anggota`, CONSTRAINT `FK_tm_anggota_tm_user` FOREIGN KEY (`kd_user`) REFERENCES `tm_user` (`kd_user`)) - Invalid query: DELETE FROM `tm_user`
WHERE sha1(kd_user) = '356a192b7913b04c54574d18c28d46e6395428ab'
INFO - 2016-09-11 13:45:05 --> Language file loaded: language/english/db_lang.php
INFO - 2016-09-11 13:45:14 --> Config Class Initialized
INFO - 2016-09-11 13:45:14 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:45:14 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:45:14 --> Utf8 Class Initialized
INFO - 2016-09-11 13:45:14 --> URI Class Initialized
INFO - 2016-09-11 13:45:14 --> Router Class Initialized
INFO - 2016-09-11 13:45:14 --> Output Class Initialized
INFO - 2016-09-11 13:45:14 --> Security Class Initialized
DEBUG - 2016-09-11 13:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:45:14 --> Input Class Initialized
INFO - 2016-09-11 13:45:14 --> Language Class Initialized
INFO - 2016-09-11 13:45:14 --> Language Class Initialized
INFO - 2016-09-11 13:45:14 --> Config Class Initialized
INFO - 2016-09-11 13:45:14 --> Loader Class Initialized
INFO - 2016-09-11 13:45:14 --> Helper loaded: url_helper
INFO - 2016-09-11 13:45:14 --> Database Driver Class Initialized
INFO - 2016-09-11 13:45:14 --> Controller Class Initialized
DEBUG - 2016-09-11 13:45:14 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:45:14 --> Model Class Initialized
INFO - 2016-09-11 13:45:14 --> Model Class Initialized
DEBUG - 2016-09-11 13:45:14 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 13:45:14 --> Users MX_Controller Initialized
INFO - 2016-09-11 13:45:14 --> Final output sent to browser
DEBUG - 2016-09-11 13:45:14 --> Total execution time: 0.7844
INFO - 2016-09-11 13:50:39 --> Config Class Initialized
INFO - 2016-09-11 13:50:39 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:50:39 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:50:39 --> Utf8 Class Initialized
INFO - 2016-09-11 13:50:39 --> URI Class Initialized
INFO - 2016-09-11 13:50:39 --> Router Class Initialized
INFO - 2016-09-11 13:50:39 --> Output Class Initialized
INFO - 2016-09-11 13:50:39 --> Security Class Initialized
DEBUG - 2016-09-11 13:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:50:39 --> Input Class Initialized
INFO - 2016-09-11 13:50:39 --> Language Class Initialized
INFO - 2016-09-11 13:50:39 --> Language Class Initialized
INFO - 2016-09-11 13:50:39 --> Config Class Initialized
INFO - 2016-09-11 13:50:39 --> Loader Class Initialized
INFO - 2016-09-11 13:50:39 --> Helper loaded: url_helper
INFO - 2016-09-11 13:50:39 --> Database Driver Class Initialized
INFO - 2016-09-11 13:50:39 --> Controller Class Initialized
DEBUG - 2016-09-11 13:50:39 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:50:40 --> Model Class Initialized
INFO - 2016-09-11 13:50:40 --> Model Class Initialized
DEBUG - 2016-09-11 13:50:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-11 13:50:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-11 13:50:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-11 13:50:40 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/user/controllers/Users.php
DEBUG - 2016-09-11 13:50:40 --> Users MX_Controller Initialized
DEBUG - 2016-09-11 13:50:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_user.php
DEBUG - 2016-09-11 13:50:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-11 13:50:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-11 13:50:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-11 13:50:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-11 13:50:40 --> Final output sent to browser
DEBUG - 2016-09-11 13:50:40 --> Total execution time: 0.8062
INFO - 2016-09-11 13:50:44 --> Config Class Initialized
INFO - 2016-09-11 13:50:44 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:50:44 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:50:44 --> Utf8 Class Initialized
INFO - 2016-09-11 13:50:44 --> URI Class Initialized
INFO - 2016-09-11 13:50:44 --> Router Class Initialized
INFO - 2016-09-11 13:50:44 --> Output Class Initialized
INFO - 2016-09-11 13:50:44 --> Security Class Initialized
DEBUG - 2016-09-11 13:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:50:44 --> Input Class Initialized
INFO - 2016-09-11 13:50:44 --> Language Class Initialized
INFO - 2016-09-11 13:50:44 --> Language Class Initialized
INFO - 2016-09-11 13:50:44 --> Config Class Initialized
INFO - 2016-09-11 13:50:44 --> Loader Class Initialized
INFO - 2016-09-11 13:50:44 --> Helper loaded: url_helper
INFO - 2016-09-11 13:50:44 --> Database Driver Class Initialized
INFO - 2016-09-11 13:50:45 --> Controller Class Initialized
DEBUG - 2016-09-11 13:50:45 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:50:45 --> Model Class Initialized
INFO - 2016-09-11 13:50:45 --> Model Class Initialized
DEBUG - 2016-09-11 13:50:45 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 13:50:45 --> Users MX_Controller Initialized
INFO - 2016-09-11 13:50:45 --> Final output sent to browser
DEBUG - 2016-09-11 13:50:45 --> Total execution time: 0.8833
INFO - 2016-09-11 13:50:51 --> Config Class Initialized
INFO - 2016-09-11 13:50:51 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:50:51 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:50:51 --> Utf8 Class Initialized
INFO - 2016-09-11 13:50:51 --> URI Class Initialized
INFO - 2016-09-11 13:50:51 --> Router Class Initialized
INFO - 2016-09-11 13:50:51 --> Output Class Initialized
INFO - 2016-09-11 13:50:51 --> Security Class Initialized
DEBUG - 2016-09-11 13:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:50:51 --> Input Class Initialized
INFO - 2016-09-11 13:50:51 --> Language Class Initialized
INFO - 2016-09-11 13:50:51 --> Language Class Initialized
INFO - 2016-09-11 13:50:51 --> Config Class Initialized
INFO - 2016-09-11 13:50:51 --> Loader Class Initialized
INFO - 2016-09-11 13:50:51 --> Helper loaded: url_helper
INFO - 2016-09-11 13:50:51 --> Database Driver Class Initialized
INFO - 2016-09-11 13:50:51 --> Controller Class Initialized
DEBUG - 2016-09-11 13:50:51 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:50:51 --> Model Class Initialized
INFO - 2016-09-11 13:50:51 --> Model Class Initialized
DEBUG - 2016-09-11 13:50:51 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 13:50:51 --> Users MX_Controller Initialized
ERROR - 2016-09-11 13:50:51 --> Severity: Notice --> Undefined index: no_identitas E:\SERVER\htdocs\koperasiweda\application\modules\User\controllers\Users.php 68
ERROR - 2016-09-11 13:50:51 --> Severity: Notice --> Undefined index: no_hp E:\SERVER\htdocs\koperasiweda\application\modules\User\controllers\Users.php 69
ERROR - 2016-09-11 13:50:51 --> Severity: Notice --> Undefined index: password E:\SERVER\htdocs\koperasiweda\application\modules\User\controllers\Users.php 71
ERROR - 2016-09-11 13:50:51 --> Severity: Notice --> Undefined index: kd_level E:\SERVER\htdocs\koperasiweda\application\modules\User\controllers\Users.php 72
INFO - 2016-09-11 13:50:51 --> Language file loaded: language/english/db_lang.php
INFO - 2016-09-11 13:51:04 --> Config Class Initialized
INFO - 2016-09-11 13:51:04 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:51:04 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:51:04 --> Utf8 Class Initialized
INFO - 2016-09-11 13:51:04 --> URI Class Initialized
INFO - 2016-09-11 13:51:04 --> Router Class Initialized
INFO - 2016-09-11 13:51:04 --> Output Class Initialized
INFO - 2016-09-11 13:51:04 --> Security Class Initialized
DEBUG - 2016-09-11 13:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:51:04 --> Input Class Initialized
INFO - 2016-09-11 13:51:04 --> Language Class Initialized
INFO - 2016-09-11 13:51:04 --> Language Class Initialized
INFO - 2016-09-11 13:51:04 --> Config Class Initialized
INFO - 2016-09-11 13:51:04 --> Loader Class Initialized
INFO - 2016-09-11 13:51:04 --> Helper loaded: url_helper
INFO - 2016-09-11 13:51:04 --> Database Driver Class Initialized
INFO - 2016-09-11 13:51:04 --> Controller Class Initialized
DEBUG - 2016-09-11 13:51:04 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:51:04 --> Model Class Initialized
INFO - 2016-09-11 13:51:04 --> Model Class Initialized
DEBUG - 2016-09-11 13:51:04 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 13:51:04 --> Users MX_Controller Initialized
ERROR - 2016-09-11 13:51:04 --> Severity: Notice --> Undefined index: no_identitas E:\SERVER\htdocs\koperasiweda\application\modules\User\controllers\Users.php 68
ERROR - 2016-09-11 13:51:04 --> Severity: Notice --> Undefined index: no_hp E:\SERVER\htdocs\koperasiweda\application\modules\User\controllers\Users.php 69
ERROR - 2016-09-11 13:51:04 --> Severity: Notice --> Undefined index: password E:\SERVER\htdocs\koperasiweda\application\modules\User\controllers\Users.php 71
ERROR - 2016-09-11 13:51:04 --> Severity: Notice --> Undefined index: kd_level E:\SERVER\htdocs\koperasiweda\application\modules\User\controllers\Users.php 72
INFO - 2016-09-11 13:51:04 --> Language file loaded: language/english/db_lang.php
INFO - 2016-09-11 13:51:52 --> Config Class Initialized
INFO - 2016-09-11 13:51:52 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:51:52 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:51:52 --> Utf8 Class Initialized
INFO - 2016-09-11 13:51:52 --> URI Class Initialized
INFO - 2016-09-11 13:51:52 --> Router Class Initialized
INFO - 2016-09-11 13:51:52 --> Output Class Initialized
INFO - 2016-09-11 13:51:52 --> Security Class Initialized
DEBUG - 2016-09-11 13:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:51:52 --> Input Class Initialized
INFO - 2016-09-11 13:51:52 --> Language Class Initialized
INFO - 2016-09-11 13:51:52 --> Language Class Initialized
INFO - 2016-09-11 13:51:52 --> Config Class Initialized
INFO - 2016-09-11 13:51:52 --> Loader Class Initialized
INFO - 2016-09-11 13:51:52 --> Helper loaded: url_helper
INFO - 2016-09-11 13:51:52 --> Database Driver Class Initialized
INFO - 2016-09-11 13:51:52 --> Controller Class Initialized
DEBUG - 2016-09-11 13:51:52 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:51:52 --> Model Class Initialized
INFO - 2016-09-11 13:51:52 --> Model Class Initialized
DEBUG - 2016-09-11 13:51:52 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 13:51:53 --> Users MX_Controller Initialized
ERROR - 2016-09-11 13:51:53 --> Severity: Notice --> Undefined index: no_identitas E:\SERVER\htdocs\koperasiweda\application\modules\User\controllers\Users.php 68
ERROR - 2016-09-11 13:51:53 --> Severity: Notice --> Undefined index: no_hp E:\SERVER\htdocs\koperasiweda\application\modules\User\controllers\Users.php 69
ERROR - 2016-09-11 13:51:53 --> Severity: Notice --> Undefined index: password E:\SERVER\htdocs\koperasiweda\application\modules\User\controllers\Users.php 71
ERROR - 2016-09-11 13:51:53 --> Severity: Notice --> Undefined index: kd_level E:\SERVER\htdocs\koperasiweda\application\modules\User\controllers\Users.php 72
INFO - 2016-09-11 13:51:53 --> Final output sent to browser
DEBUG - 2016-09-11 13:51:53 --> Total execution time: 0.7304
INFO - 2016-09-11 13:52:28 --> Config Class Initialized
INFO - 2016-09-11 13:52:28 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:52:28 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:52:28 --> Utf8 Class Initialized
INFO - 2016-09-11 13:52:28 --> URI Class Initialized
INFO - 2016-09-11 13:52:28 --> Router Class Initialized
INFO - 2016-09-11 13:52:28 --> Output Class Initialized
INFO - 2016-09-11 13:52:28 --> Security Class Initialized
DEBUG - 2016-09-11 13:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:52:28 --> Input Class Initialized
INFO - 2016-09-11 13:52:28 --> Language Class Initialized
INFO - 2016-09-11 13:52:28 --> Language Class Initialized
INFO - 2016-09-11 13:52:28 --> Config Class Initialized
INFO - 2016-09-11 13:52:28 --> Loader Class Initialized
INFO - 2016-09-11 13:52:29 --> Helper loaded: url_helper
INFO - 2016-09-11 13:52:29 --> Database Driver Class Initialized
INFO - 2016-09-11 13:52:29 --> Controller Class Initialized
DEBUG - 2016-09-11 13:52:29 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:52:29 --> Model Class Initialized
INFO - 2016-09-11 13:52:29 --> Model Class Initialized
DEBUG - 2016-09-11 13:52:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-11 13:52:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-11 13:52:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-11 13:52:29 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/user/controllers/Users.php
DEBUG - 2016-09-11 13:52:29 --> Users MX_Controller Initialized
DEBUG - 2016-09-11 13:52:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_user.php
DEBUG - 2016-09-11 13:52:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-11 13:52:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-11 13:52:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-11 13:52:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-11 13:52:29 --> Final output sent to browser
DEBUG - 2016-09-11 13:52:29 --> Total execution time: 0.8763
INFO - 2016-09-11 13:52:39 --> Config Class Initialized
INFO - 2016-09-11 13:52:39 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:52:39 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:52:39 --> Utf8 Class Initialized
INFO - 2016-09-11 13:52:39 --> URI Class Initialized
INFO - 2016-09-11 13:52:40 --> Router Class Initialized
INFO - 2016-09-11 13:52:40 --> Output Class Initialized
INFO - 2016-09-11 13:52:40 --> Security Class Initialized
DEBUG - 2016-09-11 13:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:52:40 --> Input Class Initialized
INFO - 2016-09-11 13:52:40 --> Language Class Initialized
INFO - 2016-09-11 13:52:40 --> Language Class Initialized
INFO - 2016-09-11 13:52:40 --> Config Class Initialized
INFO - 2016-09-11 13:52:40 --> Loader Class Initialized
INFO - 2016-09-11 13:52:40 --> Helper loaded: url_helper
INFO - 2016-09-11 13:52:40 --> Database Driver Class Initialized
INFO - 2016-09-11 13:52:40 --> Controller Class Initialized
DEBUG - 2016-09-11 13:52:40 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:52:40 --> Model Class Initialized
INFO - 2016-09-11 13:52:40 --> Model Class Initialized
DEBUG - 2016-09-11 13:52:40 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 13:52:40 --> Users MX_Controller Initialized
INFO - 2016-09-11 13:52:40 --> Final output sent to browser
DEBUG - 2016-09-11 13:52:40 --> Total execution time: 0.6602
INFO - 2016-09-11 13:53:10 --> Config Class Initialized
INFO - 2016-09-11 13:53:10 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:53:10 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:53:10 --> Utf8 Class Initialized
INFO - 2016-09-11 13:53:10 --> URI Class Initialized
INFO - 2016-09-11 13:53:10 --> Router Class Initialized
INFO - 2016-09-11 13:53:10 --> Output Class Initialized
INFO - 2016-09-11 13:53:10 --> Security Class Initialized
DEBUG - 2016-09-11 13:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:53:10 --> Input Class Initialized
INFO - 2016-09-11 13:53:11 --> Language Class Initialized
INFO - 2016-09-11 13:53:11 --> Language Class Initialized
INFO - 2016-09-11 13:53:11 --> Config Class Initialized
INFO - 2016-09-11 13:53:11 --> Loader Class Initialized
INFO - 2016-09-11 13:53:11 --> Helper loaded: url_helper
INFO - 2016-09-11 13:53:11 --> Database Driver Class Initialized
INFO - 2016-09-11 13:53:11 --> Controller Class Initialized
DEBUG - 2016-09-11 13:53:11 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:53:11 --> Model Class Initialized
INFO - 2016-09-11 13:53:11 --> Model Class Initialized
DEBUG - 2016-09-11 13:53:11 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 13:53:11 --> Users MX_Controller Initialized
ERROR - 2016-09-11 13:53:11 --> Severity: Notice --> Undefined index: password E:\SERVER\htdocs\koperasiweda\application\modules\User\controllers\Users.php 71
ERROR - 2016-09-11 13:53:11 --> Severity: Notice --> Undefined index: kd_level E:\SERVER\htdocs\koperasiweda\application\modules\User\controllers\Users.php 72
INFO - 2016-09-11 13:53:11 --> Final output sent to browser
DEBUG - 2016-09-11 13:53:11 --> Total execution time: 0.6989
INFO - 2016-09-11 13:53:42 --> Config Class Initialized
INFO - 2016-09-11 13:53:42 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:53:42 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:53:42 --> Utf8 Class Initialized
INFO - 2016-09-11 13:53:42 --> URI Class Initialized
INFO - 2016-09-11 13:53:42 --> Router Class Initialized
INFO - 2016-09-11 13:53:42 --> Output Class Initialized
INFO - 2016-09-11 13:53:43 --> Security Class Initialized
DEBUG - 2016-09-11 13:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:53:43 --> Input Class Initialized
INFO - 2016-09-11 13:53:43 --> Language Class Initialized
INFO - 2016-09-11 13:53:43 --> Language Class Initialized
INFO - 2016-09-11 13:53:43 --> Config Class Initialized
INFO - 2016-09-11 13:53:43 --> Loader Class Initialized
INFO - 2016-09-11 13:53:43 --> Helper loaded: url_helper
INFO - 2016-09-11 13:53:43 --> Database Driver Class Initialized
INFO - 2016-09-11 13:53:43 --> Controller Class Initialized
DEBUG - 2016-09-11 13:53:43 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:53:43 --> Model Class Initialized
INFO - 2016-09-11 13:53:43 --> Model Class Initialized
DEBUG - 2016-09-11 13:53:43 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 13:53:43 --> Users MX_Controller Initialized
INFO - 2016-09-11 13:53:43 --> Final output sent to browser
DEBUG - 2016-09-11 13:53:43 --> Total execution time: 0.5717
INFO - 2016-09-11 13:53:47 --> Config Class Initialized
INFO - 2016-09-11 13:53:47 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:53:47 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:53:47 --> Utf8 Class Initialized
INFO - 2016-09-11 13:53:47 --> URI Class Initialized
INFO - 2016-09-11 13:53:47 --> Router Class Initialized
INFO - 2016-09-11 13:53:47 --> Output Class Initialized
INFO - 2016-09-11 13:53:47 --> Security Class Initialized
DEBUG - 2016-09-11 13:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:53:47 --> Input Class Initialized
INFO - 2016-09-11 13:53:47 --> Language Class Initialized
INFO - 2016-09-11 13:53:47 --> Language Class Initialized
INFO - 2016-09-11 13:53:47 --> Config Class Initialized
INFO - 2016-09-11 13:53:47 --> Loader Class Initialized
INFO - 2016-09-11 13:53:47 --> Helper loaded: url_helper
INFO - 2016-09-11 13:53:47 --> Database Driver Class Initialized
INFO - 2016-09-11 13:53:47 --> Controller Class Initialized
DEBUG - 2016-09-11 13:53:47 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:53:48 --> Model Class Initialized
INFO - 2016-09-11 13:53:48 --> Model Class Initialized
DEBUG - 2016-09-11 13:53:48 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 13:53:48 --> Users MX_Controller Initialized
INFO - 2016-09-11 13:53:48 --> Final output sent to browser
DEBUG - 2016-09-11 13:53:48 --> Total execution time: 0.6334
INFO - 2016-09-11 13:53:53 --> Config Class Initialized
INFO - 2016-09-11 13:53:53 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:53:53 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:53:53 --> Utf8 Class Initialized
INFO - 2016-09-11 13:53:54 --> URI Class Initialized
INFO - 2016-09-11 13:53:54 --> Router Class Initialized
INFO - 2016-09-11 13:53:54 --> Output Class Initialized
INFO - 2016-09-11 13:53:54 --> Security Class Initialized
DEBUG - 2016-09-11 13:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:53:54 --> Input Class Initialized
INFO - 2016-09-11 13:53:54 --> Language Class Initialized
INFO - 2016-09-11 13:53:54 --> Language Class Initialized
INFO - 2016-09-11 13:53:54 --> Config Class Initialized
INFO - 2016-09-11 13:53:54 --> Loader Class Initialized
INFO - 2016-09-11 13:53:54 --> Helper loaded: url_helper
INFO - 2016-09-11 13:53:54 --> Database Driver Class Initialized
INFO - 2016-09-11 13:53:54 --> Controller Class Initialized
DEBUG - 2016-09-11 13:53:54 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:53:54 --> Model Class Initialized
INFO - 2016-09-11 13:53:54 --> Model Class Initialized
DEBUG - 2016-09-11 13:53:54 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 13:53:54 --> Users MX_Controller Initialized
INFO - 2016-09-11 13:53:54 --> Final output sent to browser
DEBUG - 2016-09-11 13:53:54 --> Total execution time: 0.6222
INFO - 2016-09-11 13:54:37 --> Config Class Initialized
INFO - 2016-09-11 13:54:37 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:54:37 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:54:37 --> Utf8 Class Initialized
INFO - 2016-09-11 13:54:37 --> URI Class Initialized
INFO - 2016-09-11 13:54:37 --> Router Class Initialized
INFO - 2016-09-11 13:54:37 --> Output Class Initialized
INFO - 2016-09-11 13:54:37 --> Security Class Initialized
DEBUG - 2016-09-11 13:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:54:37 --> Input Class Initialized
INFO - 2016-09-11 13:54:37 --> Language Class Initialized
INFO - 2016-09-11 13:54:37 --> Language Class Initialized
INFO - 2016-09-11 13:54:37 --> Config Class Initialized
INFO - 2016-09-11 13:54:37 --> Loader Class Initialized
INFO - 2016-09-11 13:54:37 --> Helper loaded: url_helper
INFO - 2016-09-11 13:54:37 --> Database Driver Class Initialized
INFO - 2016-09-11 13:54:37 --> Controller Class Initialized
DEBUG - 2016-09-11 13:54:37 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:54:38 --> Model Class Initialized
INFO - 2016-09-11 13:54:38 --> Model Class Initialized
DEBUG - 2016-09-11 13:54:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-11 13:54:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-11 13:54:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-11 13:54:38 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/user/controllers/Users.php
DEBUG - 2016-09-11 13:54:38 --> Users MX_Controller Initialized
DEBUG - 2016-09-11 13:54:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_user.php
DEBUG - 2016-09-11 13:54:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-11 13:54:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-11 13:54:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-11 13:54:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-11 13:54:38 --> Final output sent to browser
DEBUG - 2016-09-11 13:54:38 --> Total execution time: 0.7229
INFO - 2016-09-11 13:54:44 --> Config Class Initialized
INFO - 2016-09-11 13:54:44 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:54:44 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:54:44 --> Utf8 Class Initialized
INFO - 2016-09-11 13:54:44 --> URI Class Initialized
INFO - 2016-09-11 13:54:44 --> Router Class Initialized
INFO - 2016-09-11 13:54:44 --> Output Class Initialized
INFO - 2016-09-11 13:54:44 --> Security Class Initialized
DEBUG - 2016-09-11 13:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:54:44 --> Input Class Initialized
INFO - 2016-09-11 13:54:44 --> Language Class Initialized
INFO - 2016-09-11 13:54:44 --> Language Class Initialized
INFO - 2016-09-11 13:54:44 --> Config Class Initialized
INFO - 2016-09-11 13:54:44 --> Loader Class Initialized
INFO - 2016-09-11 13:54:44 --> Helper loaded: url_helper
INFO - 2016-09-11 13:54:44 --> Database Driver Class Initialized
INFO - 2016-09-11 13:54:44 --> Controller Class Initialized
DEBUG - 2016-09-11 13:54:44 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:54:44 --> Model Class Initialized
INFO - 2016-09-11 13:54:44 --> Model Class Initialized
DEBUG - 2016-09-11 13:54:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-11 13:54:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-11 13:54:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-11 13:54:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_user.php
DEBUG - 2016-09-11 13:54:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-11 13:54:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-11 13:54:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-11 13:54:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-11 13:54:44 --> Final output sent to browser
DEBUG - 2016-09-11 13:54:44 --> Total execution time: 0.6214
INFO - 2016-09-11 13:54:47 --> Config Class Initialized
INFO - 2016-09-11 13:54:47 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:54:47 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:54:47 --> Utf8 Class Initialized
INFO - 2016-09-11 13:54:47 --> URI Class Initialized
INFO - 2016-09-11 13:54:47 --> Router Class Initialized
INFO - 2016-09-11 13:54:47 --> Output Class Initialized
INFO - 2016-09-11 13:54:47 --> Security Class Initialized
DEBUG - 2016-09-11 13:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:54:47 --> Input Class Initialized
INFO - 2016-09-11 13:54:47 --> Language Class Initialized
INFO - 2016-09-11 13:54:47 --> Language Class Initialized
INFO - 2016-09-11 13:54:47 --> Config Class Initialized
INFO - 2016-09-11 13:54:47 --> Loader Class Initialized
INFO - 2016-09-11 13:54:47 --> Helper loaded: url_helper
INFO - 2016-09-11 13:54:47 --> Database Driver Class Initialized
INFO - 2016-09-11 13:54:47 --> Controller Class Initialized
DEBUG - 2016-09-11 13:54:47 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:54:47 --> Model Class Initialized
INFO - 2016-09-11 13:54:48 --> Model Class Initialized
DEBUG - 2016-09-11 13:54:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-11 13:54:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-11 13:54:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-11 13:54:48 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/user/controllers/Users.php
DEBUG - 2016-09-11 13:54:48 --> Users MX_Controller Initialized
DEBUG - 2016-09-11 13:54:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_user.php
DEBUG - 2016-09-11 13:54:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-11 13:54:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-11 13:54:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-11 13:54:48 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-11 13:54:48 --> Final output sent to browser
DEBUG - 2016-09-11 13:54:48 --> Total execution time: 0.8560
INFO - 2016-09-11 13:55:22 --> Config Class Initialized
INFO - 2016-09-11 13:55:22 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:55:22 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:55:22 --> Utf8 Class Initialized
INFO - 2016-09-11 13:55:22 --> URI Class Initialized
INFO - 2016-09-11 13:55:22 --> Router Class Initialized
INFO - 2016-09-11 13:55:22 --> Output Class Initialized
INFO - 2016-09-11 13:55:22 --> Security Class Initialized
DEBUG - 2016-09-11 13:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:55:22 --> Input Class Initialized
INFO - 2016-09-11 13:55:22 --> Language Class Initialized
INFO - 2016-09-11 13:55:22 --> Language Class Initialized
INFO - 2016-09-11 13:55:22 --> Config Class Initialized
INFO - 2016-09-11 13:55:22 --> Loader Class Initialized
INFO - 2016-09-11 13:55:22 --> Helper loaded: url_helper
INFO - 2016-09-11 13:55:22 --> Database Driver Class Initialized
INFO - 2016-09-11 13:55:22 --> Controller Class Initialized
DEBUG - 2016-09-11 13:55:22 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:55:22 --> Model Class Initialized
INFO - 2016-09-11 13:55:22 --> Model Class Initialized
DEBUG - 2016-09-11 13:55:22 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 13:55:22 --> Users MX_Controller Initialized
INFO - 2016-09-11 13:55:22 --> Final output sent to browser
DEBUG - 2016-09-11 13:55:22 --> Total execution time: 0.7179
INFO - 2016-09-11 13:56:53 --> Config Class Initialized
INFO - 2016-09-11 13:56:53 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:56:53 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:56:53 --> Utf8 Class Initialized
INFO - 2016-09-11 13:56:53 --> URI Class Initialized
INFO - 2016-09-11 13:56:53 --> Router Class Initialized
INFO - 2016-09-11 13:56:53 --> Output Class Initialized
INFO - 2016-09-11 13:56:53 --> Security Class Initialized
DEBUG - 2016-09-11 13:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:56:53 --> Input Class Initialized
INFO - 2016-09-11 13:56:53 --> Language Class Initialized
INFO - 2016-09-11 13:56:53 --> Language Class Initialized
INFO - 2016-09-11 13:56:53 --> Config Class Initialized
INFO - 2016-09-11 13:56:53 --> Loader Class Initialized
INFO - 2016-09-11 13:56:53 --> Helper loaded: url_helper
INFO - 2016-09-11 13:56:53 --> Database Driver Class Initialized
INFO - 2016-09-11 13:56:53 --> Controller Class Initialized
DEBUG - 2016-09-11 13:56:53 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:56:53 --> Model Class Initialized
INFO - 2016-09-11 13:56:53 --> Model Class Initialized
DEBUG - 2016-09-11 13:56:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-11 13:56:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-11 13:56:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-11 13:56:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_user.php
DEBUG - 2016-09-11 13:56:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-11 13:56:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-11 13:56:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-11 13:56:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-11 13:56:53 --> Final output sent to browser
DEBUG - 2016-09-11 13:56:53 --> Total execution time: 0.6638
INFO - 2016-09-11 13:56:56 --> Config Class Initialized
INFO - 2016-09-11 13:56:56 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:56:56 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:56:56 --> Utf8 Class Initialized
INFO - 2016-09-11 13:56:56 --> URI Class Initialized
INFO - 2016-09-11 13:56:56 --> Router Class Initialized
INFO - 2016-09-11 13:56:56 --> Output Class Initialized
INFO - 2016-09-11 13:56:56 --> Security Class Initialized
DEBUG - 2016-09-11 13:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:56:57 --> Input Class Initialized
INFO - 2016-09-11 13:56:57 --> Language Class Initialized
INFO - 2016-09-11 13:56:57 --> Language Class Initialized
INFO - 2016-09-11 13:56:57 --> Config Class Initialized
INFO - 2016-09-11 13:56:57 --> Loader Class Initialized
INFO - 2016-09-11 13:56:57 --> Helper loaded: url_helper
INFO - 2016-09-11 13:56:57 --> Database Driver Class Initialized
INFO - 2016-09-11 13:56:57 --> Controller Class Initialized
DEBUG - 2016-09-11 13:56:57 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:56:57 --> Model Class Initialized
INFO - 2016-09-11 13:56:57 --> Model Class Initialized
DEBUG - 2016-09-11 13:56:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-11 13:56:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-11 13:56:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-11 13:56:57 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/user/controllers/Users.php
DEBUG - 2016-09-11 13:56:57 --> Users MX_Controller Initialized
DEBUG - 2016-09-11 13:56:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_user.php
DEBUG - 2016-09-11 13:56:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-11 13:56:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-11 13:56:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-11 13:56:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-11 13:56:57 --> Final output sent to browser
DEBUG - 2016-09-11 13:56:57 --> Total execution time: 0.7653
INFO - 2016-09-11 13:57:03 --> Config Class Initialized
INFO - 2016-09-11 13:57:03 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:57:03 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:57:03 --> Utf8 Class Initialized
INFO - 2016-09-11 13:57:03 --> URI Class Initialized
INFO - 2016-09-11 13:57:03 --> Router Class Initialized
INFO - 2016-09-11 13:57:03 --> Output Class Initialized
INFO - 2016-09-11 13:57:03 --> Security Class Initialized
DEBUG - 2016-09-11 13:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:57:03 --> Input Class Initialized
INFO - 2016-09-11 13:57:03 --> Language Class Initialized
INFO - 2016-09-11 13:57:03 --> Language Class Initialized
INFO - 2016-09-11 13:57:03 --> Config Class Initialized
INFO - 2016-09-11 13:57:03 --> Loader Class Initialized
INFO - 2016-09-11 13:57:03 --> Helper loaded: url_helper
INFO - 2016-09-11 13:57:03 --> Database Driver Class Initialized
INFO - 2016-09-11 13:57:03 --> Controller Class Initialized
DEBUG - 2016-09-11 13:57:03 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:57:03 --> Model Class Initialized
INFO - 2016-09-11 13:57:04 --> Model Class Initialized
DEBUG - 2016-09-11 13:57:04 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 13:57:04 --> Users MX_Controller Initialized
INFO - 2016-09-11 13:57:04 --> Final output sent to browser
DEBUG - 2016-09-11 13:57:04 --> Total execution time: 0.7044
INFO - 2016-09-11 13:57:09 --> Config Class Initialized
INFO - 2016-09-11 13:57:09 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:57:09 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:57:09 --> Utf8 Class Initialized
INFO - 2016-09-11 13:57:09 --> URI Class Initialized
INFO - 2016-09-11 13:57:09 --> Router Class Initialized
INFO - 2016-09-11 13:57:09 --> Output Class Initialized
INFO - 2016-09-11 13:57:09 --> Security Class Initialized
DEBUG - 2016-09-11 13:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:57:09 --> Input Class Initialized
INFO - 2016-09-11 13:57:09 --> Language Class Initialized
INFO - 2016-09-11 13:57:09 --> Language Class Initialized
INFO - 2016-09-11 13:57:09 --> Config Class Initialized
INFO - 2016-09-11 13:57:09 --> Loader Class Initialized
INFO - 2016-09-11 13:57:09 --> Helper loaded: url_helper
INFO - 2016-09-11 13:57:09 --> Database Driver Class Initialized
INFO - 2016-09-11 13:57:09 --> Controller Class Initialized
DEBUG - 2016-09-11 13:57:09 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:57:09 --> Model Class Initialized
INFO - 2016-09-11 13:57:09 --> Model Class Initialized
DEBUG - 2016-09-11 13:57:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-11 13:57:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-11 13:57:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-11 13:57:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-11 13:57:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-11 13:57:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-11 13:57:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-11 13:57:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-11 13:57:10 --> Final output sent to browser
DEBUG - 2016-09-11 13:57:10 --> Total execution time: 0.6692
INFO - 2016-09-11 13:57:13 --> Config Class Initialized
INFO - 2016-09-11 13:57:13 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:57:13 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:57:13 --> Utf8 Class Initialized
INFO - 2016-09-11 13:57:13 --> URI Class Initialized
INFO - 2016-09-11 13:57:13 --> Router Class Initialized
INFO - 2016-09-11 13:57:13 --> Output Class Initialized
INFO - 2016-09-11 13:57:13 --> Security Class Initialized
DEBUG - 2016-09-11 13:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:57:13 --> Input Class Initialized
INFO - 2016-09-11 13:57:13 --> Language Class Initialized
INFO - 2016-09-11 13:57:13 --> Language Class Initialized
INFO - 2016-09-11 13:57:13 --> Config Class Initialized
INFO - 2016-09-11 13:57:13 --> Loader Class Initialized
INFO - 2016-09-11 13:57:13 --> Helper loaded: url_helper
INFO - 2016-09-11 13:57:13 --> Database Driver Class Initialized
INFO - 2016-09-11 13:57:13 --> Controller Class Initialized
DEBUG - 2016-09-11 13:57:13 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:57:13 --> Model Class Initialized
INFO - 2016-09-11 13:57:13 --> Model Class Initialized
DEBUG - 2016-09-11 13:57:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-11 13:57:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-11 13:57:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-11 13:57:14 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-11 13:57:14 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 13:57:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-11 13:57:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-11 13:57:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-11 13:57:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-11 13:57:14 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-11 13:57:14 --> Final output sent to browser
DEBUG - 2016-09-11 13:57:14 --> Total execution time: 1.0775
INFO - 2016-09-11 13:57:19 --> Config Class Initialized
INFO - 2016-09-11 13:57:19 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:57:19 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:57:19 --> Utf8 Class Initialized
INFO - 2016-09-11 13:57:19 --> URI Class Initialized
INFO - 2016-09-11 13:57:19 --> Router Class Initialized
INFO - 2016-09-11 13:57:19 --> Output Class Initialized
INFO - 2016-09-11 13:57:19 --> Security Class Initialized
DEBUG - 2016-09-11 13:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:57:19 --> Input Class Initialized
INFO - 2016-09-11 13:57:19 --> Language Class Initialized
INFO - 2016-09-11 13:57:19 --> Language Class Initialized
INFO - 2016-09-11 13:57:19 --> Config Class Initialized
INFO - 2016-09-11 13:57:19 --> Loader Class Initialized
INFO - 2016-09-11 13:57:19 --> Helper loaded: url_helper
INFO - 2016-09-11 13:57:19 --> Database Driver Class Initialized
INFO - 2016-09-11 13:57:19 --> Controller Class Initialized
DEBUG - 2016-09-11 13:57:19 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:57:19 --> Model Class Initialized
INFO - 2016-09-11 13:57:20 --> Model Class Initialized
DEBUG - 2016-09-11 13:57:20 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 13:57:20 --> Users MX_Controller Initialized
INFO - 2016-09-11 13:57:20 --> Final output sent to browser
DEBUG - 2016-09-11 13:57:20 --> Total execution time: 0.7757
INFO - 2016-09-11 13:57:25 --> Config Class Initialized
INFO - 2016-09-11 13:57:25 --> Hooks Class Initialized
DEBUG - 2016-09-11 13:57:25 --> UTF-8 Support Enabled
INFO - 2016-09-11 13:57:25 --> Utf8 Class Initialized
INFO - 2016-09-11 13:57:25 --> URI Class Initialized
INFO - 2016-09-11 13:57:25 --> Router Class Initialized
INFO - 2016-09-11 13:57:25 --> Output Class Initialized
INFO - 2016-09-11 13:57:25 --> Security Class Initialized
DEBUG - 2016-09-11 13:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 13:57:25 --> Input Class Initialized
INFO - 2016-09-11 13:57:25 --> Language Class Initialized
INFO - 2016-09-11 13:57:25 --> Language Class Initialized
INFO - 2016-09-11 13:57:25 --> Config Class Initialized
INFO - 2016-09-11 13:57:25 --> Loader Class Initialized
INFO - 2016-09-11 13:57:25 --> Helper loaded: url_helper
INFO - 2016-09-11 13:57:25 --> Database Driver Class Initialized
INFO - 2016-09-11 13:57:25 --> Controller Class Initialized
DEBUG - 2016-09-11 13:57:25 --> Index MX_Controller Initialized
INFO - 2016-09-11 13:57:25 --> Model Class Initialized
INFO - 2016-09-11 13:57:25 --> Model Class Initialized
DEBUG - 2016-09-11 13:57:25 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 13:57:25 --> Users MX_Controller Initialized
INFO - 2016-09-11 13:57:25 --> Final output sent to browser
DEBUG - 2016-09-11 13:57:25 --> Total execution time: 0.6339
INFO - 2016-09-11 14:00:20 --> Config Class Initialized
INFO - 2016-09-11 14:00:20 --> Hooks Class Initialized
DEBUG - 2016-09-11 14:00:20 --> UTF-8 Support Enabled
INFO - 2016-09-11 14:00:20 --> Utf8 Class Initialized
INFO - 2016-09-11 14:00:20 --> URI Class Initialized
INFO - 2016-09-11 14:00:21 --> Router Class Initialized
INFO - 2016-09-11 14:00:21 --> Output Class Initialized
INFO - 2016-09-11 14:00:21 --> Security Class Initialized
DEBUG - 2016-09-11 14:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 14:00:21 --> Input Class Initialized
INFO - 2016-09-11 14:00:21 --> Language Class Initialized
INFO - 2016-09-11 14:00:21 --> Language Class Initialized
INFO - 2016-09-11 14:00:21 --> Config Class Initialized
INFO - 2016-09-11 14:00:21 --> Loader Class Initialized
INFO - 2016-09-11 14:00:21 --> Helper loaded: url_helper
INFO - 2016-09-11 14:00:21 --> Database Driver Class Initialized
INFO - 2016-09-11 14:00:21 --> Controller Class Initialized
DEBUG - 2016-09-11 14:00:21 --> Index MX_Controller Initialized
INFO - 2016-09-11 14:00:21 --> Model Class Initialized
INFO - 2016-09-11 14:00:21 --> Model Class Initialized
DEBUG - 2016-09-11 14:00:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-11 14:00:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-11 14:00:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-11 14:00:21 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-11 14:00:21 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 14:00:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-11 14:00:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-11 14:00:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-11 14:00:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-11 14:00:21 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-11 14:00:21 --> Final output sent to browser
DEBUG - 2016-09-11 14:00:21 --> Total execution time: 0.7884
INFO - 2016-09-11 14:00:26 --> Config Class Initialized
INFO - 2016-09-11 14:00:26 --> Hooks Class Initialized
DEBUG - 2016-09-11 14:00:26 --> UTF-8 Support Enabled
INFO - 2016-09-11 14:00:26 --> Utf8 Class Initialized
INFO - 2016-09-11 14:00:26 --> URI Class Initialized
INFO - 2016-09-11 14:00:26 --> Router Class Initialized
INFO - 2016-09-11 14:00:26 --> Output Class Initialized
INFO - 2016-09-11 14:00:26 --> Security Class Initialized
DEBUG - 2016-09-11 14:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 14:00:26 --> Input Class Initialized
INFO - 2016-09-11 14:00:26 --> Language Class Initialized
INFO - 2016-09-11 14:00:26 --> Language Class Initialized
INFO - 2016-09-11 14:00:26 --> Config Class Initialized
INFO - 2016-09-11 14:00:26 --> Loader Class Initialized
INFO - 2016-09-11 14:00:26 --> Helper loaded: url_helper
INFO - 2016-09-11 14:00:26 --> Database Driver Class Initialized
INFO - 2016-09-11 14:00:26 --> Controller Class Initialized
DEBUG - 2016-09-11 14:00:26 --> Index MX_Controller Initialized
INFO - 2016-09-11 14:00:26 --> Model Class Initialized
INFO - 2016-09-11 14:00:26 --> Model Class Initialized
DEBUG - 2016-09-11 14:00:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-11 14:00:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-11 14:00:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-11 14:00:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-11 14:00:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-11 14:00:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-11 14:00:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-11 14:00:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-11 14:00:26 --> Final output sent to browser
DEBUG - 2016-09-11 14:00:26 --> Total execution time: 0.6658
INFO - 2016-09-11 14:00:30 --> Config Class Initialized
INFO - 2016-09-11 14:00:30 --> Hooks Class Initialized
DEBUG - 2016-09-11 14:00:30 --> UTF-8 Support Enabled
INFO - 2016-09-11 14:00:30 --> Utf8 Class Initialized
INFO - 2016-09-11 14:00:30 --> URI Class Initialized
INFO - 2016-09-11 14:00:30 --> Router Class Initialized
INFO - 2016-09-11 14:00:30 --> Output Class Initialized
INFO - 2016-09-11 14:00:30 --> Security Class Initialized
DEBUG - 2016-09-11 14:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 14:00:30 --> Input Class Initialized
INFO - 2016-09-11 14:00:30 --> Language Class Initialized
INFO - 2016-09-11 14:00:30 --> Language Class Initialized
INFO - 2016-09-11 14:00:30 --> Config Class Initialized
INFO - 2016-09-11 14:00:30 --> Loader Class Initialized
INFO - 2016-09-11 14:00:30 --> Helper loaded: url_helper
INFO - 2016-09-11 14:00:30 --> Database Driver Class Initialized
INFO - 2016-09-11 14:00:30 --> Controller Class Initialized
DEBUG - 2016-09-11 14:00:30 --> Index MX_Controller Initialized
INFO - 2016-09-11 14:00:30 --> Model Class Initialized
INFO - 2016-09-11 14:00:30 --> Model Class Initialized
DEBUG - 2016-09-11 14:00:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-11 14:00:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-11 14:00:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-11 14:00:30 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-11 14:00:30 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 14:00:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-11 14:00:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-11 14:00:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-11 14:00:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-11 14:00:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-11 14:00:30 --> Final output sent to browser
DEBUG - 2016-09-11 14:00:30 --> Total execution time: 0.8143
INFO - 2016-09-11 14:01:19 --> Config Class Initialized
INFO - 2016-09-11 14:01:19 --> Hooks Class Initialized
DEBUG - 2016-09-11 14:01:19 --> UTF-8 Support Enabled
INFO - 2016-09-11 14:01:19 --> Utf8 Class Initialized
INFO - 2016-09-11 14:01:19 --> URI Class Initialized
INFO - 2016-09-11 14:01:19 --> Router Class Initialized
INFO - 2016-09-11 14:01:19 --> Output Class Initialized
INFO - 2016-09-11 14:01:19 --> Security Class Initialized
DEBUG - 2016-09-11 14:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 14:01:19 --> Input Class Initialized
INFO - 2016-09-11 14:01:19 --> Language Class Initialized
INFO - 2016-09-11 14:01:19 --> Language Class Initialized
INFO - 2016-09-11 14:01:19 --> Config Class Initialized
INFO - 2016-09-11 14:01:19 --> Loader Class Initialized
INFO - 2016-09-11 14:01:19 --> Helper loaded: url_helper
INFO - 2016-09-11 14:01:19 --> Database Driver Class Initialized
INFO - 2016-09-11 14:01:19 --> Controller Class Initialized
DEBUG - 2016-09-11 14:01:19 --> Index MX_Controller Initialized
INFO - 2016-09-11 14:01:19 --> Model Class Initialized
INFO - 2016-09-11 14:01:19 --> Model Class Initialized
DEBUG - 2016-09-11 14:01:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-11 14:01:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-11 14:01:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-11 14:01:19 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-11 14:01:19 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 14:01:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-11 14:01:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-11 14:01:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-11 14:01:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-11 14:01:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-11 14:01:19 --> Final output sent to browser
DEBUG - 2016-09-11 14:01:19 --> Total execution time: 0.6967
INFO - 2016-09-11 14:01:25 --> Config Class Initialized
INFO - 2016-09-11 14:01:25 --> Hooks Class Initialized
DEBUG - 2016-09-11 14:01:25 --> UTF-8 Support Enabled
INFO - 2016-09-11 14:01:25 --> Utf8 Class Initialized
INFO - 2016-09-11 14:01:25 --> URI Class Initialized
INFO - 2016-09-11 14:01:25 --> Router Class Initialized
INFO - 2016-09-11 14:01:25 --> Output Class Initialized
INFO - 2016-09-11 14:01:25 --> Security Class Initialized
DEBUG - 2016-09-11 14:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 14:01:25 --> Input Class Initialized
INFO - 2016-09-11 14:01:25 --> Language Class Initialized
INFO - 2016-09-11 14:01:25 --> Language Class Initialized
INFO - 2016-09-11 14:01:25 --> Config Class Initialized
INFO - 2016-09-11 14:01:25 --> Loader Class Initialized
INFO - 2016-09-11 14:01:25 --> Helper loaded: url_helper
INFO - 2016-09-11 14:01:25 --> Database Driver Class Initialized
INFO - 2016-09-11 14:01:25 --> Controller Class Initialized
DEBUG - 2016-09-11 14:01:25 --> Index MX_Controller Initialized
INFO - 2016-09-11 14:01:25 --> Model Class Initialized
INFO - 2016-09-11 14:01:25 --> Model Class Initialized
DEBUG - 2016-09-11 14:01:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-11 14:01:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-11 14:01:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-11 14:01:25 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/user/controllers/Users.php
DEBUG - 2016-09-11 14:01:26 --> Users MX_Controller Initialized
DEBUG - 2016-09-11 14:01:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_user.php
DEBUG - 2016-09-11 14:01:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-11 14:01:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-11 14:01:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-11 14:01:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-11 14:01:26 --> Final output sent to browser
DEBUG - 2016-09-11 14:01:26 --> Total execution time: 0.7055
INFO - 2016-09-11 14:01:33 --> Config Class Initialized
INFO - 2016-09-11 14:01:33 --> Hooks Class Initialized
DEBUG - 2016-09-11 14:01:33 --> UTF-8 Support Enabled
INFO - 2016-09-11 14:01:33 --> Utf8 Class Initialized
INFO - 2016-09-11 14:01:33 --> URI Class Initialized
INFO - 2016-09-11 14:01:34 --> Router Class Initialized
INFO - 2016-09-11 14:01:34 --> Output Class Initialized
INFO - 2016-09-11 14:01:34 --> Security Class Initialized
DEBUG - 2016-09-11 14:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 14:01:34 --> Input Class Initialized
INFO - 2016-09-11 14:01:34 --> Language Class Initialized
INFO - 2016-09-11 14:01:34 --> Language Class Initialized
INFO - 2016-09-11 14:01:34 --> Config Class Initialized
INFO - 2016-09-11 14:01:34 --> Loader Class Initialized
INFO - 2016-09-11 14:01:34 --> Helper loaded: url_helper
INFO - 2016-09-11 14:01:34 --> Database Driver Class Initialized
INFO - 2016-09-11 14:01:34 --> Controller Class Initialized
DEBUG - 2016-09-11 14:01:34 --> Index MX_Controller Initialized
INFO - 2016-09-11 14:01:34 --> Model Class Initialized
INFO - 2016-09-11 14:01:34 --> Model Class Initialized
DEBUG - 2016-09-11 14:01:34 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 14:01:34 --> Users MX_Controller Initialized
INFO - 2016-09-11 14:01:34 --> Final output sent to browser
DEBUG - 2016-09-11 14:01:34 --> Total execution time: 0.7504
INFO - 2016-09-11 14:01:41 --> Config Class Initialized
INFO - 2016-09-11 14:01:41 --> Hooks Class Initialized
DEBUG - 2016-09-11 14:01:41 --> UTF-8 Support Enabled
INFO - 2016-09-11 14:01:41 --> Utf8 Class Initialized
INFO - 2016-09-11 14:01:41 --> URI Class Initialized
INFO - 2016-09-11 14:01:41 --> Router Class Initialized
INFO - 2016-09-11 14:01:41 --> Output Class Initialized
INFO - 2016-09-11 14:01:41 --> Security Class Initialized
DEBUG - 2016-09-11 14:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 14:01:41 --> Input Class Initialized
INFO - 2016-09-11 14:01:41 --> Language Class Initialized
INFO - 2016-09-11 14:01:41 --> Language Class Initialized
INFO - 2016-09-11 14:01:41 --> Config Class Initialized
INFO - 2016-09-11 14:01:41 --> Loader Class Initialized
INFO - 2016-09-11 14:01:41 --> Helper loaded: url_helper
INFO - 2016-09-11 14:01:41 --> Database Driver Class Initialized
INFO - 2016-09-11 14:01:41 --> Controller Class Initialized
DEBUG - 2016-09-11 14:01:41 --> Index MX_Controller Initialized
INFO - 2016-09-11 14:01:41 --> Model Class Initialized
INFO - 2016-09-11 14:01:41 --> Model Class Initialized
DEBUG - 2016-09-11 14:01:41 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 14:01:41 --> Users MX_Controller Initialized
INFO - 2016-09-11 14:01:41 --> Final output sent to browser
DEBUG - 2016-09-11 14:01:42 --> Total execution time: 0.7776
INFO - 2016-09-11 14:01:46 --> Config Class Initialized
INFO - 2016-09-11 14:01:46 --> Hooks Class Initialized
DEBUG - 2016-09-11 14:01:46 --> UTF-8 Support Enabled
INFO - 2016-09-11 14:01:46 --> Utf8 Class Initialized
INFO - 2016-09-11 14:01:46 --> URI Class Initialized
INFO - 2016-09-11 14:01:46 --> Router Class Initialized
INFO - 2016-09-11 14:01:46 --> Output Class Initialized
INFO - 2016-09-11 14:01:46 --> Security Class Initialized
DEBUG - 2016-09-11 14:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 14:01:46 --> Input Class Initialized
INFO - 2016-09-11 14:01:46 --> Language Class Initialized
INFO - 2016-09-11 14:01:46 --> Language Class Initialized
INFO - 2016-09-11 14:01:46 --> Config Class Initialized
INFO - 2016-09-11 14:01:46 --> Loader Class Initialized
INFO - 2016-09-11 14:01:46 --> Helper loaded: url_helper
INFO - 2016-09-11 14:01:47 --> Database Driver Class Initialized
INFO - 2016-09-11 14:01:47 --> Controller Class Initialized
DEBUG - 2016-09-11 14:01:47 --> Index MX_Controller Initialized
INFO - 2016-09-11 14:01:47 --> Model Class Initialized
INFO - 2016-09-11 14:01:47 --> Model Class Initialized
DEBUG - 2016-09-11 14:01:47 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 14:01:47 --> Users MX_Controller Initialized
INFO - 2016-09-11 14:01:47 --> Final output sent to browser
DEBUG - 2016-09-11 14:01:47 --> Total execution time: 0.6236
INFO - 2016-09-11 14:02:18 --> Config Class Initialized
INFO - 2016-09-11 14:02:18 --> Hooks Class Initialized
DEBUG - 2016-09-11 14:02:18 --> UTF-8 Support Enabled
INFO - 2016-09-11 14:02:18 --> Utf8 Class Initialized
INFO - 2016-09-11 14:02:18 --> URI Class Initialized
INFO - 2016-09-11 14:02:18 --> Router Class Initialized
INFO - 2016-09-11 14:02:18 --> Output Class Initialized
INFO - 2016-09-11 14:02:18 --> Security Class Initialized
DEBUG - 2016-09-11 14:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 14:02:18 --> Input Class Initialized
INFO - 2016-09-11 14:02:18 --> Language Class Initialized
INFO - 2016-09-11 14:02:18 --> Language Class Initialized
INFO - 2016-09-11 14:02:18 --> Config Class Initialized
INFO - 2016-09-11 14:02:18 --> Loader Class Initialized
INFO - 2016-09-11 14:02:18 --> Helper loaded: url_helper
INFO - 2016-09-11 14:02:18 --> Database Driver Class Initialized
INFO - 2016-09-11 14:02:18 --> Controller Class Initialized
DEBUG - 2016-09-11 14:02:19 --> Index MX_Controller Initialized
INFO - 2016-09-11 14:02:19 --> Model Class Initialized
INFO - 2016-09-11 14:02:19 --> Model Class Initialized
DEBUG - 2016-09-11 14:02:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-11 14:02:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-11 14:02:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-11 14:02:19 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/user/controllers/Users.php
DEBUG - 2016-09-11 14:02:19 --> Users MX_Controller Initialized
DEBUG - 2016-09-11 14:02:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_user.php
DEBUG - 2016-09-11 14:02:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-11 14:02:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-11 14:02:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-11 14:02:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-11 14:02:19 --> Final output sent to browser
DEBUG - 2016-09-11 14:02:19 --> Total execution time: 0.7142
INFO - 2016-09-11 14:02:22 --> Config Class Initialized
INFO - 2016-09-11 14:02:22 --> Hooks Class Initialized
DEBUG - 2016-09-11 14:02:22 --> UTF-8 Support Enabled
INFO - 2016-09-11 14:02:23 --> Utf8 Class Initialized
INFO - 2016-09-11 14:02:23 --> URI Class Initialized
INFO - 2016-09-11 14:02:23 --> Router Class Initialized
INFO - 2016-09-11 14:02:23 --> Output Class Initialized
INFO - 2016-09-11 14:02:23 --> Security Class Initialized
DEBUG - 2016-09-11 14:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 14:02:23 --> Input Class Initialized
INFO - 2016-09-11 14:02:23 --> Language Class Initialized
INFO - 2016-09-11 14:02:23 --> Language Class Initialized
INFO - 2016-09-11 14:02:23 --> Config Class Initialized
INFO - 2016-09-11 14:02:23 --> Loader Class Initialized
INFO - 2016-09-11 14:02:23 --> Helper loaded: url_helper
INFO - 2016-09-11 14:02:23 --> Database Driver Class Initialized
INFO - 2016-09-11 14:02:23 --> Controller Class Initialized
DEBUG - 2016-09-11 14:02:23 --> Index MX_Controller Initialized
INFO - 2016-09-11 14:02:23 --> Model Class Initialized
INFO - 2016-09-11 14:02:23 --> Model Class Initialized
DEBUG - 2016-09-11 14:02:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-11 14:02:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-11 14:02:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-11 14:02:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_user.php
DEBUG - 2016-09-11 14:02:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-11 14:02:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-11 14:02:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-11 14:02:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-11 14:02:23 --> Final output sent to browser
DEBUG - 2016-09-11 14:02:23 --> Total execution time: 1.0992
INFO - 2016-09-11 14:02:28 --> Config Class Initialized
INFO - 2016-09-11 14:02:28 --> Hooks Class Initialized
DEBUG - 2016-09-11 14:02:28 --> UTF-8 Support Enabled
INFO - 2016-09-11 14:02:28 --> Utf8 Class Initialized
INFO - 2016-09-11 14:02:28 --> URI Class Initialized
INFO - 2016-09-11 14:02:28 --> Router Class Initialized
INFO - 2016-09-11 14:02:28 --> Output Class Initialized
INFO - 2016-09-11 14:02:28 --> Security Class Initialized
DEBUG - 2016-09-11 14:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 14:02:28 --> Input Class Initialized
INFO - 2016-09-11 14:02:28 --> Language Class Initialized
INFO - 2016-09-11 14:02:28 --> Language Class Initialized
INFO - 2016-09-11 14:02:28 --> Config Class Initialized
INFO - 2016-09-11 14:02:29 --> Loader Class Initialized
INFO - 2016-09-11 14:02:29 --> Helper loaded: url_helper
INFO - 2016-09-11 14:02:29 --> Database Driver Class Initialized
INFO - 2016-09-11 14:02:29 --> Controller Class Initialized
DEBUG - 2016-09-11 14:02:29 --> Index MX_Controller Initialized
INFO - 2016-09-11 14:02:29 --> Model Class Initialized
INFO - 2016-09-11 14:02:29 --> Model Class Initialized
DEBUG - 2016-09-11 14:02:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-11 14:02:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-11 14:02:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-11 14:02:29 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/user/controllers/Users.php
DEBUG - 2016-09-11 14:02:29 --> Users MX_Controller Initialized
DEBUG - 2016-09-11 14:02:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_user.php
DEBUG - 2016-09-11 14:02:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-11 14:02:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-11 14:02:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-11 14:02:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-11 14:02:29 --> Final output sent to browser
DEBUG - 2016-09-11 14:02:29 --> Total execution time: 0.7989
INFO - 2016-09-11 14:03:05 --> Config Class Initialized
INFO - 2016-09-11 14:03:05 --> Hooks Class Initialized
DEBUG - 2016-09-11 14:03:05 --> UTF-8 Support Enabled
INFO - 2016-09-11 14:03:05 --> Utf8 Class Initialized
INFO - 2016-09-11 14:03:05 --> URI Class Initialized
INFO - 2016-09-11 14:03:05 --> Router Class Initialized
INFO - 2016-09-11 14:03:05 --> Output Class Initialized
INFO - 2016-09-11 14:03:05 --> Security Class Initialized
DEBUG - 2016-09-11 14:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 14:03:05 --> Input Class Initialized
INFO - 2016-09-11 14:03:05 --> Language Class Initialized
INFO - 2016-09-11 14:03:05 --> Language Class Initialized
INFO - 2016-09-11 14:03:05 --> Config Class Initialized
INFO - 2016-09-11 14:03:05 --> Loader Class Initialized
INFO - 2016-09-11 14:03:05 --> Helper loaded: url_helper
INFO - 2016-09-11 14:03:05 --> Database Driver Class Initialized
INFO - 2016-09-11 14:03:05 --> Controller Class Initialized
DEBUG - 2016-09-11 14:03:05 --> Index MX_Controller Initialized
INFO - 2016-09-11 14:03:05 --> Model Class Initialized
INFO - 2016-09-11 14:03:05 --> Model Class Initialized
DEBUG - 2016-09-11 14:03:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-11 14:03:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-11 14:03:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-11 14:03:05 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/user/controllers/Users.php
DEBUG - 2016-09-11 14:03:05 --> Users MX_Controller Initialized
DEBUG - 2016-09-11 14:03:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_user.php
DEBUG - 2016-09-11 14:03:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-11 14:03:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-11 14:03:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-11 14:03:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-11 14:03:05 --> Final output sent to browser
DEBUG - 2016-09-11 14:03:05 --> Total execution time: 0.7299
INFO - 2016-09-11 14:03:11 --> Config Class Initialized
INFO - 2016-09-11 14:03:11 --> Hooks Class Initialized
DEBUG - 2016-09-11 14:03:11 --> UTF-8 Support Enabled
INFO - 2016-09-11 14:03:11 --> Utf8 Class Initialized
INFO - 2016-09-11 14:03:11 --> URI Class Initialized
INFO - 2016-09-11 14:03:11 --> Router Class Initialized
INFO - 2016-09-11 14:03:12 --> Output Class Initialized
INFO - 2016-09-11 14:03:12 --> Security Class Initialized
DEBUG - 2016-09-11 14:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 14:03:12 --> Input Class Initialized
INFO - 2016-09-11 14:03:12 --> Language Class Initialized
INFO - 2016-09-11 14:03:12 --> Language Class Initialized
INFO - 2016-09-11 14:03:12 --> Config Class Initialized
INFO - 2016-09-11 14:03:12 --> Loader Class Initialized
INFO - 2016-09-11 14:03:12 --> Helper loaded: url_helper
INFO - 2016-09-11 14:03:12 --> Database Driver Class Initialized
INFO - 2016-09-11 14:03:12 --> Controller Class Initialized
DEBUG - 2016-09-11 14:03:12 --> Index MX_Controller Initialized
INFO - 2016-09-11 14:03:12 --> Model Class Initialized
INFO - 2016-09-11 14:03:12 --> Model Class Initialized
DEBUG - 2016-09-11 14:03:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-11 14:03:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-11 14:03:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-11 14:03:12 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-11 14:03:12 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 14:03:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-11 14:03:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-11 14:03:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-11 14:03:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-11 14:03:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-11 14:03:12 --> Final output sent to browser
DEBUG - 2016-09-11 14:03:12 --> Total execution time: 0.7482
INFO - 2016-09-11 14:04:53 --> Config Class Initialized
INFO - 2016-09-11 14:04:53 --> Hooks Class Initialized
DEBUG - 2016-09-11 14:04:53 --> UTF-8 Support Enabled
INFO - 2016-09-11 14:04:53 --> Utf8 Class Initialized
INFO - 2016-09-11 14:04:53 --> URI Class Initialized
INFO - 2016-09-11 14:04:53 --> Router Class Initialized
INFO - 2016-09-11 14:04:53 --> Output Class Initialized
INFO - 2016-09-11 14:04:53 --> Security Class Initialized
DEBUG - 2016-09-11 14:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 14:04:53 --> Input Class Initialized
INFO - 2016-09-11 14:04:53 --> Language Class Initialized
INFO - 2016-09-11 14:04:53 --> Language Class Initialized
INFO - 2016-09-11 14:04:53 --> Config Class Initialized
INFO - 2016-09-11 14:04:53 --> Loader Class Initialized
INFO - 2016-09-11 14:04:53 --> Helper loaded: url_helper
INFO - 2016-09-11 14:04:53 --> Database Driver Class Initialized
INFO - 2016-09-11 14:04:53 --> Controller Class Initialized
DEBUG - 2016-09-11 14:04:53 --> Index MX_Controller Initialized
INFO - 2016-09-11 14:04:53 --> Model Class Initialized
INFO - 2016-09-11 14:04:53 --> Model Class Initialized
DEBUG - 2016-09-11 14:04:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-11 14:04:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-11 14:04:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-11 14:04:53 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-11 14:04:53 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 14:04:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-11 14:04:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-11 14:04:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-11 14:04:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-11 14:04:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-11 14:04:53 --> Final output sent to browser
DEBUG - 2016-09-11 14:04:53 --> Total execution time: 0.7481
INFO - 2016-09-11 14:05:26 --> Config Class Initialized
INFO - 2016-09-11 14:05:26 --> Hooks Class Initialized
DEBUG - 2016-09-11 14:05:26 --> UTF-8 Support Enabled
INFO - 2016-09-11 14:05:26 --> Utf8 Class Initialized
INFO - 2016-09-11 14:05:27 --> URI Class Initialized
INFO - 2016-09-11 14:05:27 --> Router Class Initialized
INFO - 2016-09-11 14:05:27 --> Output Class Initialized
INFO - 2016-09-11 14:05:27 --> Security Class Initialized
DEBUG - 2016-09-11 14:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 14:05:27 --> Input Class Initialized
INFO - 2016-09-11 14:05:27 --> Language Class Initialized
INFO - 2016-09-11 14:05:27 --> Language Class Initialized
INFO - 2016-09-11 14:05:27 --> Config Class Initialized
INFO - 2016-09-11 14:05:27 --> Loader Class Initialized
INFO - 2016-09-11 14:05:27 --> Helper loaded: url_helper
INFO - 2016-09-11 14:05:27 --> Database Driver Class Initialized
INFO - 2016-09-11 14:05:27 --> Controller Class Initialized
DEBUG - 2016-09-11 14:05:27 --> Index MX_Controller Initialized
INFO - 2016-09-11 14:05:27 --> Model Class Initialized
INFO - 2016-09-11 14:05:27 --> Model Class Initialized
DEBUG - 2016-09-11 14:05:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-11 14:05:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-11 14:05:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-11 14:05:27 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-11 14:05:27 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 14:05:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-11 14:05:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-11 14:05:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-11 14:05:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-11 14:05:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-11 14:05:27 --> Final output sent to browser
DEBUG - 2016-09-11 14:05:27 --> Total execution time: 0.7491
INFO - 2016-09-11 14:06:59 --> Config Class Initialized
INFO - 2016-09-11 14:06:59 --> Hooks Class Initialized
DEBUG - 2016-09-11 14:06:59 --> UTF-8 Support Enabled
INFO - 2016-09-11 14:06:59 --> Utf8 Class Initialized
INFO - 2016-09-11 14:06:59 --> URI Class Initialized
INFO - 2016-09-11 14:06:59 --> Router Class Initialized
INFO - 2016-09-11 14:06:59 --> Output Class Initialized
INFO - 2016-09-11 14:06:59 --> Security Class Initialized
DEBUG - 2016-09-11 14:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 14:06:59 --> Input Class Initialized
INFO - 2016-09-11 14:06:59 --> Language Class Initialized
INFO - 2016-09-11 14:06:59 --> Language Class Initialized
INFO - 2016-09-11 14:06:59 --> Config Class Initialized
INFO - 2016-09-11 14:06:59 --> Loader Class Initialized
INFO - 2016-09-11 14:06:59 --> Helper loaded: url_helper
INFO - 2016-09-11 14:06:59 --> Database Driver Class Initialized
INFO - 2016-09-11 14:06:59 --> Controller Class Initialized
DEBUG - 2016-09-11 14:07:00 --> Index MX_Controller Initialized
INFO - 2016-09-11 14:07:00 --> Model Class Initialized
INFO - 2016-09-11 14:07:00 --> Model Class Initialized
DEBUG - 2016-09-11 14:07:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-11 14:07:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-11 14:07:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-11 14:07:00 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-11 14:07:00 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 14:07:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-11 14:07:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-11 14:07:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-11 14:07:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-11 14:07:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-11 14:07:00 --> Final output sent to browser
DEBUG - 2016-09-11 14:07:00 --> Total execution time: 0.8890
INFO - 2016-09-11 14:08:34 --> Config Class Initialized
INFO - 2016-09-11 14:08:34 --> Hooks Class Initialized
DEBUG - 2016-09-11 14:08:34 --> UTF-8 Support Enabled
INFO - 2016-09-11 14:08:34 --> Utf8 Class Initialized
INFO - 2016-09-11 14:08:34 --> URI Class Initialized
INFO - 2016-09-11 14:08:34 --> Router Class Initialized
INFO - 2016-09-11 14:08:34 --> Output Class Initialized
INFO - 2016-09-11 14:08:34 --> Security Class Initialized
DEBUG - 2016-09-11 14:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 14:08:34 --> Input Class Initialized
INFO - 2016-09-11 14:08:34 --> Language Class Initialized
INFO - 2016-09-11 14:08:34 --> Language Class Initialized
INFO - 2016-09-11 14:08:34 --> Config Class Initialized
INFO - 2016-09-11 14:08:35 --> Loader Class Initialized
INFO - 2016-09-11 14:08:35 --> Helper loaded: url_helper
INFO - 2016-09-11 14:08:35 --> Database Driver Class Initialized
INFO - 2016-09-11 14:08:35 --> Controller Class Initialized
DEBUG - 2016-09-11 14:08:35 --> Index MX_Controller Initialized
INFO - 2016-09-11 14:08:35 --> Model Class Initialized
INFO - 2016-09-11 14:08:35 --> Model Class Initialized
DEBUG - 2016-09-11 14:08:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-11 14:08:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-11 14:08:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-11 14:08:35 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-11 14:08:35 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 14:08:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-11 14:08:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-11 14:08:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-11 14:08:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-11 14:08:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-11 14:08:35 --> Final output sent to browser
DEBUG - 2016-09-11 14:08:35 --> Total execution time: 0.8479
INFO - 2016-09-11 14:08:41 --> Config Class Initialized
INFO - 2016-09-11 14:08:41 --> Hooks Class Initialized
DEBUG - 2016-09-11 14:08:41 --> UTF-8 Support Enabled
INFO - 2016-09-11 14:08:41 --> Utf8 Class Initialized
INFO - 2016-09-11 14:08:41 --> URI Class Initialized
INFO - 2016-09-11 14:08:41 --> Router Class Initialized
INFO - 2016-09-11 14:08:41 --> Output Class Initialized
INFO - 2016-09-11 14:08:41 --> Security Class Initialized
DEBUG - 2016-09-11 14:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 14:08:41 --> Input Class Initialized
INFO - 2016-09-11 14:08:41 --> Language Class Initialized
INFO - 2016-09-11 14:08:41 --> Language Class Initialized
INFO - 2016-09-11 14:08:41 --> Config Class Initialized
INFO - 2016-09-11 14:08:41 --> Loader Class Initialized
INFO - 2016-09-11 14:08:41 --> Helper loaded: url_helper
INFO - 2016-09-11 14:08:41 --> Database Driver Class Initialized
INFO - 2016-09-11 14:08:41 --> Controller Class Initialized
DEBUG - 2016-09-11 14:08:41 --> Index MX_Controller Initialized
INFO - 2016-09-11 14:08:41 --> Model Class Initialized
INFO - 2016-09-11 14:08:41 --> Model Class Initialized
INFO - 2016-09-11 14:08:41 --> Final output sent to browser
DEBUG - 2016-09-11 14:08:41 --> Total execution time: 0.4992
INFO - 2016-09-11 14:08:41 --> Config Class Initialized
INFO - 2016-09-11 14:08:41 --> Hooks Class Initialized
DEBUG - 2016-09-11 14:08:42 --> UTF-8 Support Enabled
INFO - 2016-09-11 14:08:42 --> Utf8 Class Initialized
INFO - 2016-09-11 14:08:42 --> URI Class Initialized
INFO - 2016-09-11 14:08:42 --> Router Class Initialized
INFO - 2016-09-11 14:08:42 --> Output Class Initialized
INFO - 2016-09-11 14:08:42 --> Security Class Initialized
DEBUG - 2016-09-11 14:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 14:08:42 --> Input Class Initialized
INFO - 2016-09-11 14:08:42 --> Language Class Initialized
INFO - 2016-09-11 14:08:42 --> Language Class Initialized
INFO - 2016-09-11 14:08:42 --> Config Class Initialized
INFO - 2016-09-11 14:08:42 --> Loader Class Initialized
INFO - 2016-09-11 14:08:42 --> Helper loaded: url_helper
INFO - 2016-09-11 14:08:42 --> Database Driver Class Initialized
INFO - 2016-09-11 14:08:42 --> Controller Class Initialized
DEBUG - 2016-09-11 14:08:42 --> Index MX_Controller Initialized
INFO - 2016-09-11 14:08:42 --> Model Class Initialized
INFO - 2016-09-11 14:08:42 --> Model Class Initialized
DEBUG - 2016-09-11 14:08:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-11 14:08:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-11 14:08:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-11 14:08:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/dashboard.php
DEBUG - 2016-09-11 14:08:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-11 14:08:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-11 14:08:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-11 14:08:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-11 14:08:42 --> Final output sent to browser
DEBUG - 2016-09-11 14:08:42 --> Total execution time: 0.6941
INFO - 2016-09-11 14:08:50 --> Config Class Initialized
INFO - 2016-09-11 14:08:50 --> Hooks Class Initialized
DEBUG - 2016-09-11 14:08:50 --> UTF-8 Support Enabled
INFO - 2016-09-11 14:08:50 --> Utf8 Class Initialized
INFO - 2016-09-11 14:08:50 --> URI Class Initialized
INFO - 2016-09-11 14:08:51 --> Router Class Initialized
INFO - 2016-09-11 14:08:51 --> Output Class Initialized
INFO - 2016-09-11 14:08:51 --> Security Class Initialized
DEBUG - 2016-09-11 14:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 14:08:51 --> Input Class Initialized
INFO - 2016-09-11 14:08:51 --> Language Class Initialized
INFO - 2016-09-11 14:08:51 --> Language Class Initialized
INFO - 2016-09-11 14:08:51 --> Config Class Initialized
INFO - 2016-09-11 14:08:51 --> Loader Class Initialized
INFO - 2016-09-11 14:08:51 --> Helper loaded: url_helper
INFO - 2016-09-11 14:08:51 --> Database Driver Class Initialized
INFO - 2016-09-11 14:08:51 --> Controller Class Initialized
DEBUG - 2016-09-11 14:08:51 --> Index MX_Controller Initialized
INFO - 2016-09-11 14:08:51 --> Model Class Initialized
INFO - 2016-09-11 14:08:51 --> Model Class Initialized
DEBUG - 2016-09-11 14:08:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-11 14:08:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-11 14:08:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-11 14:08:51 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-11 14:08:51 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 14:08:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-11 14:08:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-11 14:08:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-11 14:08:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-11 14:08:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-11 14:08:51 --> Final output sent to browser
DEBUG - 2016-09-11 14:08:51 --> Total execution time: 0.7700
INFO - 2016-09-11 14:09:23 --> Config Class Initialized
INFO - 2016-09-11 14:09:23 --> Hooks Class Initialized
DEBUG - 2016-09-11 14:09:23 --> UTF-8 Support Enabled
INFO - 2016-09-11 14:09:23 --> Utf8 Class Initialized
INFO - 2016-09-11 14:09:23 --> URI Class Initialized
INFO - 2016-09-11 14:09:23 --> Router Class Initialized
INFO - 2016-09-11 14:09:23 --> Output Class Initialized
INFO - 2016-09-11 14:09:23 --> Security Class Initialized
DEBUG - 2016-09-11 14:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 14:09:23 --> Input Class Initialized
INFO - 2016-09-11 14:09:23 --> Language Class Initialized
INFO - 2016-09-11 14:09:23 --> Language Class Initialized
INFO - 2016-09-11 14:09:23 --> Config Class Initialized
INFO - 2016-09-11 14:09:23 --> Loader Class Initialized
INFO - 2016-09-11 14:09:23 --> Helper loaded: url_helper
INFO - 2016-09-11 14:09:23 --> Database Driver Class Initialized
INFO - 2016-09-11 14:09:23 --> Controller Class Initialized
DEBUG - 2016-09-11 14:09:23 --> Index MX_Controller Initialized
INFO - 2016-09-11 14:09:24 --> Model Class Initialized
INFO - 2016-09-11 14:09:24 --> Model Class Initialized
DEBUG - 2016-09-11 14:09:24 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 14:09:24 --> Users MX_Controller Initialized
INFO - 2016-09-11 14:09:24 --> Final output sent to browser
DEBUG - 2016-09-11 14:09:24 --> Total execution time: 0.7726
INFO - 2016-09-11 14:09:40 --> Config Class Initialized
INFO - 2016-09-11 14:09:40 --> Hooks Class Initialized
DEBUG - 2016-09-11 14:09:40 --> UTF-8 Support Enabled
INFO - 2016-09-11 14:09:40 --> Utf8 Class Initialized
INFO - 2016-09-11 14:09:40 --> URI Class Initialized
INFO - 2016-09-11 14:09:40 --> Router Class Initialized
INFO - 2016-09-11 14:09:40 --> Output Class Initialized
INFO - 2016-09-11 14:09:40 --> Security Class Initialized
DEBUG - 2016-09-11 14:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 14:09:40 --> Input Class Initialized
INFO - 2016-09-11 14:09:40 --> Language Class Initialized
INFO - 2016-09-11 14:09:41 --> Language Class Initialized
INFO - 2016-09-11 14:09:41 --> Config Class Initialized
INFO - 2016-09-11 14:09:41 --> Loader Class Initialized
INFO - 2016-09-11 14:09:41 --> Helper loaded: url_helper
INFO - 2016-09-11 14:09:41 --> Database Driver Class Initialized
INFO - 2016-09-11 14:09:41 --> Controller Class Initialized
DEBUG - 2016-09-11 14:09:41 --> Index MX_Controller Initialized
INFO - 2016-09-11 14:09:41 --> Model Class Initialized
INFO - 2016-09-11 14:09:41 --> Model Class Initialized
DEBUG - 2016-09-11 14:09:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-11 14:09:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-11 14:09:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-11 14:09:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_user.php
DEBUG - 2016-09-11 14:09:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-11 14:09:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-11 14:09:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-11 14:09:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-11 14:09:41 --> Final output sent to browser
DEBUG - 2016-09-11 14:09:41 --> Total execution time: 0.6866
INFO - 2016-09-11 14:09:44 --> Config Class Initialized
INFO - 2016-09-11 14:09:44 --> Hooks Class Initialized
DEBUG - 2016-09-11 14:09:44 --> UTF-8 Support Enabled
INFO - 2016-09-11 14:09:44 --> Utf8 Class Initialized
INFO - 2016-09-11 14:09:44 --> URI Class Initialized
INFO - 2016-09-11 14:09:44 --> Router Class Initialized
INFO - 2016-09-11 14:09:44 --> Output Class Initialized
INFO - 2016-09-11 14:09:45 --> Security Class Initialized
DEBUG - 2016-09-11 14:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 14:09:45 --> Input Class Initialized
INFO - 2016-09-11 14:09:45 --> Language Class Initialized
INFO - 2016-09-11 14:09:45 --> Language Class Initialized
INFO - 2016-09-11 14:09:45 --> Config Class Initialized
INFO - 2016-09-11 14:09:45 --> Loader Class Initialized
INFO - 2016-09-11 14:09:45 --> Helper loaded: url_helper
INFO - 2016-09-11 14:09:45 --> Database Driver Class Initialized
INFO - 2016-09-11 14:09:45 --> Controller Class Initialized
DEBUG - 2016-09-11 14:09:45 --> Index MX_Controller Initialized
INFO - 2016-09-11 14:09:45 --> Model Class Initialized
INFO - 2016-09-11 14:09:45 --> Model Class Initialized
DEBUG - 2016-09-11 14:09:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-11 14:09:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-11 14:09:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-11 14:09:45 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/user/controllers/Users.php
DEBUG - 2016-09-11 14:09:45 --> Users MX_Controller Initialized
DEBUG - 2016-09-11 14:09:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_user.php
DEBUG - 2016-09-11 14:09:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-11 14:09:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-11 14:09:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-11 14:09:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-11 14:09:45 --> Final output sent to browser
DEBUG - 2016-09-11 14:09:45 --> Total execution time: 0.7805
INFO - 2016-09-11 14:09:50 --> Config Class Initialized
INFO - 2016-09-11 14:09:50 --> Hooks Class Initialized
DEBUG - 2016-09-11 14:09:50 --> UTF-8 Support Enabled
INFO - 2016-09-11 14:09:50 --> Utf8 Class Initialized
INFO - 2016-09-11 14:09:50 --> URI Class Initialized
INFO - 2016-09-11 14:09:50 --> Router Class Initialized
INFO - 2016-09-11 14:09:50 --> Output Class Initialized
INFO - 2016-09-11 14:09:51 --> Security Class Initialized
DEBUG - 2016-09-11 14:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-11 14:09:51 --> Input Class Initialized
INFO - 2016-09-11 14:09:51 --> Language Class Initialized
INFO - 2016-09-11 14:09:51 --> Language Class Initialized
INFO - 2016-09-11 14:09:51 --> Config Class Initialized
INFO - 2016-09-11 14:09:51 --> Loader Class Initialized
INFO - 2016-09-11 14:09:51 --> Helper loaded: url_helper
INFO - 2016-09-11 14:09:51 --> Database Driver Class Initialized
INFO - 2016-09-11 14:09:51 --> Controller Class Initialized
DEBUG - 2016-09-11 14:09:51 --> Index MX_Controller Initialized
INFO - 2016-09-11 14:09:51 --> Model Class Initialized
INFO - 2016-09-11 14:09:51 --> Model Class Initialized
DEBUG - 2016-09-11 14:09:51 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-11 14:09:51 --> Users MX_Controller Initialized
INFO - 2016-09-11 14:09:51 --> Final output sent to browser
DEBUG - 2016-09-11 14:09:51 --> Total execution time: 1.0088
