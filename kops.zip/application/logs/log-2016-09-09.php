<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-09-09 03:43:21 --> Config Class Initialized
INFO - 2016-09-09 03:43:21 --> Hooks Class Initialized
DEBUG - 2016-09-09 03:43:22 --> UTF-8 Support Enabled
INFO - 2016-09-09 03:43:22 --> Utf8 Class Initialized
INFO - 2016-09-09 03:43:22 --> URI Class Initialized
INFO - 2016-09-09 03:43:22 --> Router Class Initialized
INFO - 2016-09-09 03:43:22 --> Output Class Initialized
INFO - 2016-09-09 03:43:22 --> Security Class Initialized
DEBUG - 2016-09-09 03:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 03:43:22 --> Input Class Initialized
INFO - 2016-09-09 03:43:22 --> Language Class Initialized
INFO - 2016-09-09 03:43:22 --> Language Class Initialized
INFO - 2016-09-09 03:43:22 --> Config Class Initialized
INFO - 2016-09-09 03:43:23 --> Loader Class Initialized
INFO - 2016-09-09 03:43:23 --> Helper loaded: url_helper
INFO - 2016-09-09 03:43:23 --> Database Driver Class Initialized
INFO - 2016-09-09 03:43:23 --> Controller Class Initialized
DEBUG - 2016-09-09 03:43:23 --> Index MX_Controller Initialized
INFO - 2016-09-09 03:43:23 --> Model Class Initialized
INFO - 2016-09-09 03:43:23 --> Model Class Initialized
DEBUG - 2016-09-09 03:43:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-09 03:43:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-09 03:43:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-09 03:43:23 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-09 03:43:23 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-09 03:43:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-09 03:43:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-09 03:43:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-09 03:43:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-09 03:43:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-09 03:43:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-09 03:43:23 --> Final output sent to browser
DEBUG - 2016-09-09 03:43:23 --> Total execution time: 2.1235
INFO - 2016-09-09 03:43:39 --> Config Class Initialized
INFO - 2016-09-09 03:43:39 --> Hooks Class Initialized
DEBUG - 2016-09-09 03:43:39 --> UTF-8 Support Enabled
INFO - 2016-09-09 03:43:39 --> Utf8 Class Initialized
INFO - 2016-09-09 03:43:39 --> URI Class Initialized
INFO - 2016-09-09 03:43:39 --> Router Class Initialized
INFO - 2016-09-09 03:43:39 --> Output Class Initialized
INFO - 2016-09-09 03:43:39 --> Security Class Initialized
DEBUG - 2016-09-09 03:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 03:43:39 --> Input Class Initialized
INFO - 2016-09-09 03:43:39 --> Language Class Initialized
INFO - 2016-09-09 03:43:39 --> Language Class Initialized
INFO - 2016-09-09 03:43:39 --> Config Class Initialized
INFO - 2016-09-09 03:43:39 --> Loader Class Initialized
INFO - 2016-09-09 03:43:39 --> Helper loaded: url_helper
INFO - 2016-09-09 03:43:39 --> Database Driver Class Initialized
INFO - 2016-09-09 03:43:39 --> Controller Class Initialized
DEBUG - 2016-09-09 03:43:39 --> Index MX_Controller Initialized
INFO - 2016-09-09 03:43:39 --> Model Class Initialized
INFO - 2016-09-09 03:43:40 --> Model Class Initialized
DEBUG - 2016-09-09 03:43:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-09 03:43:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-09 03:43:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-09 03:43:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-09 03:43:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-09 03:43:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-09 03:43:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-09 03:43:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-09 03:43:40 --> Final output sent to browser
DEBUG - 2016-09-09 03:43:40 --> Total execution time: 0.4847
INFO - 2016-09-09 03:43:54 --> Config Class Initialized
INFO - 2016-09-09 03:43:54 --> Hooks Class Initialized
DEBUG - 2016-09-09 03:43:54 --> UTF-8 Support Enabled
INFO - 2016-09-09 03:43:54 --> Utf8 Class Initialized
INFO - 2016-09-09 03:43:54 --> URI Class Initialized
INFO - 2016-09-09 03:43:54 --> Router Class Initialized
INFO - 2016-09-09 03:43:54 --> Output Class Initialized
INFO - 2016-09-09 03:43:54 --> Security Class Initialized
DEBUG - 2016-09-09 03:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 03:43:54 --> Input Class Initialized
INFO - 2016-09-09 03:43:54 --> Language Class Initialized
INFO - 2016-09-09 03:43:54 --> Language Class Initialized
INFO - 2016-09-09 03:43:54 --> Config Class Initialized
INFO - 2016-09-09 03:43:54 --> Loader Class Initialized
INFO - 2016-09-09 03:43:54 --> Helper loaded: url_helper
INFO - 2016-09-09 03:43:54 --> Database Driver Class Initialized
INFO - 2016-09-09 03:43:54 --> Controller Class Initialized
DEBUG - 2016-09-09 03:43:54 --> Index MX_Controller Initialized
INFO - 2016-09-09 03:43:54 --> Model Class Initialized
INFO - 2016-09-09 03:43:54 --> Model Class Initialized
DEBUG - 2016-09-09 03:43:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-09 03:43:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-09 03:43:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-09 03:43:54 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-09 03:43:54 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-09 03:43:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-09 03:43:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-09 03:43:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-09 03:43:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-09 03:43:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-09 03:43:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-09 03:43:54 --> Final output sent to browser
DEBUG - 2016-09-09 03:43:55 --> Total execution time: 0.6631
INFO - 2016-09-09 17:22:08 --> Config Class Initialized
INFO - 2016-09-09 17:22:08 --> Hooks Class Initialized
DEBUG - 2016-09-09 17:22:08 --> UTF-8 Support Enabled
INFO - 2016-09-09 17:22:08 --> Utf8 Class Initialized
INFO - 2016-09-09 17:22:08 --> URI Class Initialized
INFO - 2016-09-09 17:22:08 --> Router Class Initialized
INFO - 2016-09-09 17:22:08 --> Output Class Initialized
INFO - 2016-09-09 17:22:08 --> Security Class Initialized
DEBUG - 2016-09-09 17:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 17:22:08 --> Input Class Initialized
INFO - 2016-09-09 17:22:08 --> Language Class Initialized
INFO - 2016-09-09 17:22:08 --> Language Class Initialized
INFO - 2016-09-09 17:22:08 --> Config Class Initialized
INFO - 2016-09-09 17:22:08 --> Loader Class Initialized
INFO - 2016-09-09 17:22:08 --> Helper loaded: url_helper
INFO - 2016-09-09 17:22:09 --> Database Driver Class Initialized
INFO - 2016-09-09 17:22:09 --> Controller Class Initialized
DEBUG - 2016-09-09 17:22:09 --> Index MX_Controller Initialized
INFO - 2016-09-09 17:22:09 --> Model Class Initialized
INFO - 2016-09-09 17:22:09 --> Model Class Initialized
DEBUG - 2016-09-09 17:22:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-09 17:22:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-09 17:22:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-09 17:22:09 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-09 17:22:09 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-09 17:22:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-09 17:22:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-09 17:22:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-09 17:22:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-09 17:22:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-09 17:22:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-09 17:22:09 --> Final output sent to browser
DEBUG - 2016-09-09 17:22:09 --> Total execution time: 1.0352
INFO - 2016-09-09 18:30:29 --> Config Class Initialized
INFO - 2016-09-09 18:30:29 --> Hooks Class Initialized
DEBUG - 2016-09-09 18:30:29 --> UTF-8 Support Enabled
INFO - 2016-09-09 18:30:29 --> Utf8 Class Initialized
INFO - 2016-09-09 18:30:29 --> URI Class Initialized
INFO - 2016-09-09 18:30:29 --> Router Class Initialized
INFO - 2016-09-09 18:30:29 --> Output Class Initialized
INFO - 2016-09-09 18:30:29 --> Security Class Initialized
DEBUG - 2016-09-09 18:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 18:30:29 --> Input Class Initialized
INFO - 2016-09-09 18:30:29 --> Language Class Initialized
INFO - 2016-09-09 18:30:29 --> Language Class Initialized
INFO - 2016-09-09 18:30:29 --> Config Class Initialized
INFO - 2016-09-09 18:30:29 --> Loader Class Initialized
INFO - 2016-09-09 18:30:29 --> Helper loaded: url_helper
INFO - 2016-09-09 18:30:29 --> Database Driver Class Initialized
INFO - 2016-09-09 18:30:29 --> Controller Class Initialized
DEBUG - 2016-09-09 18:30:29 --> Index MX_Controller Initialized
INFO - 2016-09-09 18:30:29 --> Model Class Initialized
INFO - 2016-09-09 18:30:29 --> Model Class Initialized
DEBUG - 2016-09-09 18:30:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-09 18:30:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-09 18:30:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-09 18:30:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-09 18:30:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-09 18:30:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-09 18:30:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-09 18:30:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-09 18:30:30 --> Final output sent to browser
DEBUG - 2016-09-09 18:30:30 --> Total execution time: 0.8776
INFO - 2016-09-09 18:30:33 --> Config Class Initialized
INFO - 2016-09-09 18:30:33 --> Hooks Class Initialized
DEBUG - 2016-09-09 18:30:33 --> UTF-8 Support Enabled
INFO - 2016-09-09 18:30:33 --> Utf8 Class Initialized
INFO - 2016-09-09 18:30:33 --> URI Class Initialized
INFO - 2016-09-09 18:30:33 --> Router Class Initialized
INFO - 2016-09-09 18:30:33 --> Output Class Initialized
INFO - 2016-09-09 18:30:33 --> Security Class Initialized
DEBUG - 2016-09-09 18:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 18:30:33 --> Input Class Initialized
INFO - 2016-09-09 18:30:33 --> Language Class Initialized
INFO - 2016-09-09 18:30:33 --> Language Class Initialized
INFO - 2016-09-09 18:30:33 --> Config Class Initialized
INFO - 2016-09-09 18:30:33 --> Loader Class Initialized
INFO - 2016-09-09 18:30:33 --> Helper loaded: url_helper
INFO - 2016-09-09 18:30:33 --> Database Driver Class Initialized
INFO - 2016-09-09 18:30:33 --> Controller Class Initialized
DEBUG - 2016-09-09 18:30:33 --> Index MX_Controller Initialized
INFO - 2016-09-09 18:30:34 --> Model Class Initialized
INFO - 2016-09-09 18:30:34 --> Model Class Initialized
DEBUG - 2016-09-09 18:30:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-09 18:30:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-09 18:30:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-09 18:30:34 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-09 18:30:34 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-09 18:30:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-09 18:30:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-09 18:30:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-09 18:30:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-09 18:30:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-09 18:30:34 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-09 18:30:34 --> Final output sent to browser
DEBUG - 2016-09-09 18:30:34 --> Total execution time: 0.7588
