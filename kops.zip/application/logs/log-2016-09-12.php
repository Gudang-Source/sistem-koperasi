<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-09-12 12:49:08 --> Config Class Initialized
INFO - 2016-09-12 12:49:08 --> Hooks Class Initialized
DEBUG - 2016-09-12 12:49:08 --> UTF-8 Support Enabled
INFO - 2016-09-12 12:49:08 --> Utf8 Class Initialized
INFO - 2016-09-12 12:49:08 --> URI Class Initialized
INFO - 2016-09-12 12:49:09 --> Router Class Initialized
INFO - 2016-09-12 12:49:09 --> Output Class Initialized
INFO - 2016-09-12 12:49:09 --> Security Class Initialized
DEBUG - 2016-09-12 12:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-12 12:49:09 --> Input Class Initialized
INFO - 2016-09-12 12:49:09 --> Language Class Initialized
INFO - 2016-09-12 12:49:09 --> Language Class Initialized
INFO - 2016-09-12 12:49:09 --> Config Class Initialized
INFO - 2016-09-12 12:49:09 --> Loader Class Initialized
INFO - 2016-09-12 12:49:10 --> Helper loaded: url_helper
INFO - 2016-09-12 12:49:10 --> Database Driver Class Initialized
INFO - 2016-09-12 12:49:10 --> Controller Class Initialized
DEBUG - 2016-09-12 12:49:10 --> Index MX_Controller Initialized
INFO - 2016-09-12 12:49:10 --> Model Class Initialized
INFO - 2016-09-12 12:49:10 --> Model Class Initialized
DEBUG - 2016-09-12 12:49:10 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-12 12:49:10 --> Users MX_Controller Initialized
INFO - 2016-09-12 12:49:10 --> Final output sent to browser
DEBUG - 2016-09-12 12:49:10 --> Total execution time: 2.5907
INFO - 2016-09-12 12:49:12 --> Config Class Initialized
INFO - 2016-09-12 12:49:12 --> Hooks Class Initialized
DEBUG - 2016-09-12 12:49:12 --> UTF-8 Support Enabled
INFO - 2016-09-12 12:49:12 --> Utf8 Class Initialized
INFO - 2016-09-12 12:49:12 --> URI Class Initialized
INFO - 2016-09-12 12:49:12 --> Router Class Initialized
INFO - 2016-09-12 12:49:12 --> Output Class Initialized
INFO - 2016-09-12 12:49:12 --> Security Class Initialized
DEBUG - 2016-09-12 12:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-12 12:49:12 --> Input Class Initialized
INFO - 2016-09-12 12:49:12 --> Language Class Initialized
INFO - 2016-09-12 12:49:12 --> Language Class Initialized
INFO - 2016-09-12 12:49:12 --> Config Class Initialized
INFO - 2016-09-12 12:49:12 --> Loader Class Initialized
INFO - 2016-09-12 12:49:12 --> Helper loaded: url_helper
INFO - 2016-09-12 12:49:12 --> Database Driver Class Initialized
INFO - 2016-09-12 12:49:12 --> Controller Class Initialized
DEBUG - 2016-09-12 12:49:12 --> Index MX_Controller Initialized
INFO - 2016-09-12 12:49:12 --> Model Class Initialized
INFO - 2016-09-12 12:49:12 --> Model Class Initialized
DEBUG - 2016-09-12 12:49:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-12 12:49:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-12 12:49:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-12 12:49:12 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-12 12:49:12 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-12 12:49:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-12 12:49:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-12 12:49:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-12 12:49:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-12 12:49:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-12 12:49:13 --> Final output sent to browser
DEBUG - 2016-09-12 12:49:13 --> Total execution time: 0.8360
INFO - 2016-09-12 12:49:19 --> Config Class Initialized
INFO - 2016-09-12 12:49:19 --> Hooks Class Initialized
DEBUG - 2016-09-12 12:49:19 --> UTF-8 Support Enabled
INFO - 2016-09-12 12:49:19 --> Utf8 Class Initialized
INFO - 2016-09-12 12:49:19 --> URI Class Initialized
INFO - 2016-09-12 12:49:19 --> Router Class Initialized
INFO - 2016-09-12 12:49:19 --> Output Class Initialized
INFO - 2016-09-12 12:49:19 --> Security Class Initialized
DEBUG - 2016-09-12 12:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-12 12:49:19 --> Input Class Initialized
INFO - 2016-09-12 12:49:19 --> Language Class Initialized
INFO - 2016-09-12 12:49:19 --> Language Class Initialized
INFO - 2016-09-12 12:49:19 --> Config Class Initialized
INFO - 2016-09-12 12:49:19 --> Loader Class Initialized
INFO - 2016-09-12 12:49:19 --> Helper loaded: url_helper
INFO - 2016-09-12 12:49:19 --> Database Driver Class Initialized
INFO - 2016-09-12 12:49:19 --> Controller Class Initialized
DEBUG - 2016-09-12 12:49:19 --> Index MX_Controller Initialized
INFO - 2016-09-12 12:49:19 --> Model Class Initialized
INFO - 2016-09-12 12:49:19 --> Model Class Initialized
DEBUG - 2016-09-12 12:49:19 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-12 12:49:19 --> Users MX_Controller Initialized
INFO - 2016-09-12 12:49:19 --> Final output sent to browser
DEBUG - 2016-09-12 12:49:19 --> Total execution time: 0.6369
INFO - 2016-09-12 12:49:22 --> Config Class Initialized
INFO - 2016-09-12 12:49:22 --> Hooks Class Initialized
DEBUG - 2016-09-12 12:49:22 --> UTF-8 Support Enabled
INFO - 2016-09-12 12:49:22 --> Utf8 Class Initialized
INFO - 2016-09-12 12:49:22 --> URI Class Initialized
INFO - 2016-09-12 12:49:22 --> Router Class Initialized
INFO - 2016-09-12 12:49:22 --> Output Class Initialized
INFO - 2016-09-12 12:49:22 --> Security Class Initialized
DEBUG - 2016-09-12 12:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-12 12:49:22 --> Input Class Initialized
INFO - 2016-09-12 12:49:22 --> Language Class Initialized
INFO - 2016-09-12 12:49:22 --> Language Class Initialized
INFO - 2016-09-12 12:49:22 --> Config Class Initialized
INFO - 2016-09-12 12:49:22 --> Loader Class Initialized
INFO - 2016-09-12 12:49:23 --> Helper loaded: url_helper
INFO - 2016-09-12 12:49:23 --> Database Driver Class Initialized
INFO - 2016-09-12 12:49:23 --> Controller Class Initialized
DEBUG - 2016-09-12 12:49:23 --> Index MX_Controller Initialized
INFO - 2016-09-12 12:49:23 --> Model Class Initialized
INFO - 2016-09-12 12:49:23 --> Model Class Initialized
DEBUG - 2016-09-12 12:49:23 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-12 12:49:23 --> Users MX_Controller Initialized
INFO - 2016-09-12 12:49:23 --> Final output sent to browser
DEBUG - 2016-09-12 12:49:23 --> Total execution time: 0.6037
INFO - 2016-09-12 12:49:26 --> Config Class Initialized
INFO - 2016-09-12 12:49:26 --> Hooks Class Initialized
DEBUG - 2016-09-12 12:49:26 --> UTF-8 Support Enabled
INFO - 2016-09-12 12:49:26 --> Utf8 Class Initialized
INFO - 2016-09-12 12:49:26 --> URI Class Initialized
INFO - 2016-09-12 12:49:26 --> Router Class Initialized
INFO - 2016-09-12 12:49:26 --> Output Class Initialized
INFO - 2016-09-12 12:49:26 --> Security Class Initialized
DEBUG - 2016-09-12 12:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-12 12:49:26 --> Input Class Initialized
INFO - 2016-09-12 12:49:26 --> Language Class Initialized
INFO - 2016-09-12 12:49:26 --> Language Class Initialized
INFO - 2016-09-12 12:49:26 --> Config Class Initialized
INFO - 2016-09-12 12:49:26 --> Loader Class Initialized
INFO - 2016-09-12 12:49:26 --> Helper loaded: url_helper
INFO - 2016-09-12 12:49:26 --> Database Driver Class Initialized
INFO - 2016-09-12 12:49:26 --> Controller Class Initialized
DEBUG - 2016-09-12 12:49:26 --> Index MX_Controller Initialized
INFO - 2016-09-12 12:49:26 --> Model Class Initialized
INFO - 2016-09-12 12:49:26 --> Model Class Initialized
DEBUG - 2016-09-12 12:49:26 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-12 12:49:26 --> Users MX_Controller Initialized
INFO - 2016-09-12 12:49:26 --> Final output sent to browser
DEBUG - 2016-09-12 12:49:26 --> Total execution time: 0.6695
