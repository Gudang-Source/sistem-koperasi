<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-10-05 17:09:43 --> Config Class Initialized
INFO - 2016-10-05 17:09:43 --> Hooks Class Initialized
DEBUG - 2016-10-05 17:09:44 --> UTF-8 Support Enabled
INFO - 2016-10-05 17:09:44 --> Utf8 Class Initialized
INFO - 2016-10-05 17:09:44 --> URI Class Initialized
DEBUG - 2016-10-05 17:09:44 --> No URI present. Default controller set.
INFO - 2016-10-05 17:09:44 --> Router Class Initialized
INFO - 2016-10-05 17:09:44 --> Output Class Initialized
INFO - 2016-10-05 17:09:44 --> Security Class Initialized
DEBUG - 2016-10-05 17:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 17:09:45 --> Input Class Initialized
INFO - 2016-10-05 17:09:45 --> Language Class Initialized
INFO - 2016-10-05 17:09:45 --> Language Class Initialized
INFO - 2016-10-05 17:09:45 --> Config Class Initialized
INFO - 2016-10-05 17:09:45 --> Loader Class Initialized
INFO - 2016-10-05 17:09:45 --> Helper loaded: url_helper
INFO - 2016-10-05 17:09:46 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 17:09:46 --> Controller Class Initialized
DEBUG - 2016-10-05 17:09:46 --> Index MX_Controller Initialized
INFO - 2016-10-05 17:09:46 --> Model Class Initialized
INFO - 2016-10-05 17:09:46 --> Model Class Initialized
ERROR - 2016-10-05 17:09:47 --> Unable to delete cache file for 
DEBUG - 2016-10-05 17:09:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-05 17:09:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-05 17:09:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-05 17:09:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/dashboard.php
DEBUG - 2016-10-05 17:09:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-05 17:09:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-05 17:09:47 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:47 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:47 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:47 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:47 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:47 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:47 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:47 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:47 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:47 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:47 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:47 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:47 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:48 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:48 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:48 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:48 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:48 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:48 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:48 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:48 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:48 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:48 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:48 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:48 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:48 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:48 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:48 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:48 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:48 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:48 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:48 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:48 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:48 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:48 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:48 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:48 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:48 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:48 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:48 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:48 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:48 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:48 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:48 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:48 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:48 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:48 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:48 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:48 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:48 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:48 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:48 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:49 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:49 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:49 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:49 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:49 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:49 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:49 --> Database Driver Class Initialized
DEBUG - 2016-10-05 17:09:49 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-05 17:09:49 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-05 17:09:49 --> Final output sent to browser
INFO - 2016-10-05 17:09:49 --> Config Class Initialized
INFO - 2016-10-05 17:09:49 --> Hooks Class Initialized
DEBUG - 2016-10-05 17:09:49 --> Total execution time: 5.7027
DEBUG - 2016-10-05 17:09:49 --> UTF-8 Support Enabled
INFO - 2016-10-05 17:09:49 --> Utf8 Class Initialized
INFO - 2016-10-05 17:09:49 --> URI Class Initialized
INFO - 2016-10-05 17:09:49 --> Router Class Initialized
INFO - 2016-10-05 17:09:49 --> Output Class Initialized
INFO - 2016-10-05 17:09:49 --> Security Class Initialized
DEBUG - 2016-10-05 17:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 17:09:49 --> Input Class Initialized
INFO - 2016-10-05 17:09:49 --> Language Class Initialized
INFO - 2016-10-05 17:09:49 --> Language Class Initialized
INFO - 2016-10-05 17:09:49 --> Config Class Initialized
INFO - 2016-10-05 17:09:49 --> Loader Class Initialized
INFO - 2016-10-05 17:09:49 --> Helper loaded: url_helper
INFO - 2016-10-05 17:09:49 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 17:09:49 --> Controller Class Initialized
DEBUG - 2016-10-05 17:09:49 --> login MX_Controller Initialized
INFO - 2016-10-05 17:09:49 --> Model Class Initialized
INFO - 2016-10-05 17:09:49 --> Model Class Initialized
DEBUG - 2016-10-05 17:09:49 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/login.php
INFO - 2016-10-05 17:09:49 --> Final output sent to browser
DEBUG - 2016-10-05 17:09:49 --> Total execution time: 0.6338
INFO - 2016-10-05 17:09:54 --> Config Class Initialized
INFO - 2016-10-05 17:09:54 --> Hooks Class Initialized
DEBUG - 2016-10-05 17:09:54 --> UTF-8 Support Enabled
INFO - 2016-10-05 17:09:55 --> Utf8 Class Initialized
INFO - 2016-10-05 17:09:55 --> URI Class Initialized
INFO - 2016-10-05 17:09:55 --> Router Class Initialized
INFO - 2016-10-05 17:09:55 --> Output Class Initialized
INFO - 2016-10-05 17:09:55 --> Security Class Initialized
DEBUG - 2016-10-05 17:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 17:09:55 --> Input Class Initialized
INFO - 2016-10-05 17:09:55 --> Language Class Initialized
INFO - 2016-10-05 17:09:55 --> Language Class Initialized
INFO - 2016-10-05 17:09:55 --> Config Class Initialized
INFO - 2016-10-05 17:09:55 --> Loader Class Initialized
INFO - 2016-10-05 17:09:55 --> Helper loaded: url_helper
INFO - 2016-10-05 17:09:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 17:09:55 --> Controller Class Initialized
DEBUG - 2016-10-05 17:09:55 --> login MX_Controller Initialized
INFO - 2016-10-05 17:09:55 --> Model Class Initialized
INFO - 2016-10-05 17:09:55 --> Model Class Initialized
INFO - 2016-10-05 17:09:55 --> Final output sent to browser
DEBUG - 2016-10-05 17:09:55 --> Total execution time: 0.5124
INFO - 2016-10-05 17:09:55 --> Config Class Initialized
INFO - 2016-10-05 17:09:55 --> Hooks Class Initialized
DEBUG - 2016-10-05 17:09:55 --> UTF-8 Support Enabled
INFO - 2016-10-05 17:09:55 --> Utf8 Class Initialized
INFO - 2016-10-05 17:09:55 --> URI Class Initialized
INFO - 2016-10-05 17:09:55 --> Router Class Initialized
INFO - 2016-10-05 17:09:55 --> Output Class Initialized
INFO - 2016-10-05 17:09:55 --> Security Class Initialized
DEBUG - 2016-10-05 17:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 17:09:55 --> Input Class Initialized
INFO - 2016-10-05 17:09:55 --> Language Class Initialized
INFO - 2016-10-05 17:09:56 --> Language Class Initialized
INFO - 2016-10-05 17:09:56 --> Config Class Initialized
INFO - 2016-10-05 17:09:56 --> Loader Class Initialized
INFO - 2016-10-05 17:09:56 --> Helper loaded: url_helper
INFO - 2016-10-05 17:09:56 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 17:09:56 --> Controller Class Initialized
DEBUG - 2016-10-05 17:09:56 --> Index MX_Controller Initialized
INFO - 2016-10-05 17:09:56 --> Model Class Initialized
INFO - 2016-10-05 17:09:56 --> Model Class Initialized
ERROR - 2016-10-05 17:09:56 --> Unable to delete cache file for admin/index
DEBUG - 2016-10-05 17:09:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-05 17:09:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-05 17:09:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-05 17:09:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/dashboard.php
DEBUG - 2016-10-05 17:09:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-05 17:09:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-05 17:09:56 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:56 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:56 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:56 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:56 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:56 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:56 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:56 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:56 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:56 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:56 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:56 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:56 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:56 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:56 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:56 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:56 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:56 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:56 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:56 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:56 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:57 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:57 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:57 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:57 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:57 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:57 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:57 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:57 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:57 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:57 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:57 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:57 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:57 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:57 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:57 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:57 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:57 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:57 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:57 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:57 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:57 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:57 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:57 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:57 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:57 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:57 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:57 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:57 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:57 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:57 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:57 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:57 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:57 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:57 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:57 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:57 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:57 --> Database Driver Class Initialized
INFO - 2016-10-05 17:09:57 --> Database Driver Class Initialized
DEBUG - 2016-10-05 17:09:57 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-05 17:09:57 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-05 17:09:58 --> Final output sent to browser
DEBUG - 2016-10-05 17:09:58 --> Total execution time: 2.4092
INFO - 2016-10-05 17:10:05 --> Config Class Initialized
INFO - 2016-10-05 17:10:05 --> Hooks Class Initialized
DEBUG - 2016-10-05 17:10:05 --> UTF-8 Support Enabled
INFO - 2016-10-05 17:10:05 --> Utf8 Class Initialized
INFO - 2016-10-05 17:10:05 --> URI Class Initialized
INFO - 2016-10-05 17:10:05 --> Router Class Initialized
INFO - 2016-10-05 17:10:05 --> Output Class Initialized
INFO - 2016-10-05 17:10:05 --> Security Class Initialized
DEBUG - 2016-10-05 17:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 17:10:05 --> Input Class Initialized
INFO - 2016-10-05 17:10:05 --> Language Class Initialized
INFO - 2016-10-05 17:10:05 --> Language Class Initialized
INFO - 2016-10-05 17:10:05 --> Config Class Initialized
INFO - 2016-10-05 17:10:05 --> Loader Class Initialized
INFO - 2016-10-05 17:10:05 --> Helper loaded: url_helper
INFO - 2016-10-05 17:10:05 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 17:10:05 --> Controller Class Initialized
DEBUG - 2016-10-05 17:10:05 --> Index MX_Controller Initialized
INFO - 2016-10-05 17:10:05 --> Model Class Initialized
INFO - 2016-10-05 17:10:05 --> Model Class Initialized
ERROR - 2016-10-05 17:10:05 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-10-05 17:10:05 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-05 17:10:05 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-05 17:10:05 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-05 17:10:05 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-10-05 17:10:05 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-05 17:10:05 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-05 17:10:05 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:05 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:06 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:06 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:06 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:06 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:06 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:06 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:06 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:06 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:06 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:06 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:06 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:06 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:06 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:06 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:06 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:06 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:06 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:06 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:06 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:06 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:06 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:06 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:06 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:06 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:06 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:06 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:06 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:06 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:06 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:06 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:06 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:06 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:06 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:06 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:06 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:06 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:07 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:07 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:07 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:07 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:07 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:07 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:07 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:07 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:07 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:07 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:07 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:07 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:07 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:07 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:07 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:07 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:07 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:07 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:07 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:07 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:07 --> Database Driver Class Initialized
DEBUG - 2016-10-05 17:10:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-05 17:10:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-05 17:10:07 --> Final output sent to browser
DEBUG - 2016-10-05 17:10:07 --> Total execution time: 2.3950
INFO - 2016-10-05 17:10:30 --> Config Class Initialized
INFO - 2016-10-05 17:10:30 --> Hooks Class Initialized
DEBUG - 2016-10-05 17:10:30 --> UTF-8 Support Enabled
INFO - 2016-10-05 17:10:30 --> Utf8 Class Initialized
INFO - 2016-10-05 17:10:30 --> URI Class Initialized
INFO - 2016-10-05 17:10:30 --> Router Class Initialized
INFO - 2016-10-05 17:10:30 --> Output Class Initialized
INFO - 2016-10-05 17:10:30 --> Security Class Initialized
DEBUG - 2016-10-05 17:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 17:10:30 --> Input Class Initialized
INFO - 2016-10-05 17:10:30 --> Language Class Initialized
INFO - 2016-10-05 17:10:30 --> Language Class Initialized
INFO - 2016-10-05 17:10:30 --> Config Class Initialized
INFO - 2016-10-05 17:10:30 --> Loader Class Initialized
INFO - 2016-10-05 17:10:30 --> Helper loaded: url_helper
INFO - 2016-10-05 17:10:30 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 17:10:30 --> Controller Class Initialized
DEBUG - 2016-10-05 17:10:30 --> Index MX_Controller Initialized
INFO - 2016-10-05 17:10:30 --> Model Class Initialized
INFO - 2016-10-05 17:10:30 --> Model Class Initialized
ERROR - 2016-10-05 17:10:30 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-10-05 17:10:30 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-05 17:10:30 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-05 17:10:30 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-05 17:10:30 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-10-05 17:10:30 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-05 17:10:31 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-05 17:10:31 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:31 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:31 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:31 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:31 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:31 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:31 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:31 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:31 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:31 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:31 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:31 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:31 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:31 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:31 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:31 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:31 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:31 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:31 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:31 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:31 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:31 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:31 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:31 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:31 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:31 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:31 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:31 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:31 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:31 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:31 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:31 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:31 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:31 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:31 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:31 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:31 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:31 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:31 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:32 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:32 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:32 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:32 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:32 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:32 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:32 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:32 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:32 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:32 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:32 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:32 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:32 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:32 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:32 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:32 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:32 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:32 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:32 --> Database Driver Class Initialized
INFO - 2016-10-05 17:10:32 --> Database Driver Class Initialized
DEBUG - 2016-10-05 17:10:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-05 17:10:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-05 17:10:32 --> Final output sent to browser
DEBUG - 2016-10-05 17:10:32 --> Total execution time: 2.2351
INFO - 2016-10-05 17:11:51 --> Config Class Initialized
INFO - 2016-10-05 17:11:51 --> Hooks Class Initialized
DEBUG - 2016-10-05 17:11:51 --> UTF-8 Support Enabled
INFO - 2016-10-05 17:11:51 --> Utf8 Class Initialized
INFO - 2016-10-05 17:11:51 --> URI Class Initialized
INFO - 2016-10-05 17:11:51 --> Router Class Initialized
INFO - 2016-10-05 17:11:51 --> Output Class Initialized
INFO - 2016-10-05 17:11:51 --> Security Class Initialized
DEBUG - 2016-10-05 17:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 17:11:51 --> Input Class Initialized
INFO - 2016-10-05 17:11:51 --> Language Class Initialized
INFO - 2016-10-05 17:11:51 --> Language Class Initialized
INFO - 2016-10-05 17:11:51 --> Config Class Initialized
INFO - 2016-10-05 17:11:51 --> Loader Class Initialized
INFO - 2016-10-05 17:11:51 --> Helper loaded: url_helper
INFO - 2016-10-05 17:11:51 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 17:11:51 --> Controller Class Initialized
DEBUG - 2016-10-05 17:11:51 --> Index MX_Controller Initialized
INFO - 2016-10-05 17:11:51 --> Model Class Initialized
INFO - 2016-10-05 17:11:51 --> Model Class Initialized
ERROR - 2016-10-05 17:11:51 --> Unable to delete cache file for admin/index/perpanjang_angsuran
DEBUG - 2016-10-05 17:11:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-05 17:11:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-05 17:11:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-05 17:11:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_perpanjangan.php
DEBUG - 2016-10-05 17:11:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-05 17:11:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-05 17:11:51 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:51 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:51 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:52 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:52 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:52 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:52 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:52 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:52 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:52 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:52 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:52 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:52 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:52 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:52 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:52 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:52 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:52 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:52 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:52 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:52 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:52 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:52 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:52 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:52 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:52 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:52 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:52 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:52 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:52 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:52 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:52 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:52 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:52 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:11:53 --> Database Driver Class Initialized
DEBUG - 2016-10-05 17:11:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-05 17:11:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-05 17:11:54 --> Final output sent to browser
DEBUG - 2016-10-05 17:11:54 --> Total execution time: 2.8711
INFO - 2016-10-05 17:12:01 --> Config Class Initialized
INFO - 2016-10-05 17:12:01 --> Hooks Class Initialized
DEBUG - 2016-10-05 17:12:01 --> UTF-8 Support Enabled
INFO - 2016-10-05 17:12:01 --> Utf8 Class Initialized
INFO - 2016-10-05 17:12:01 --> URI Class Initialized
INFO - 2016-10-05 17:12:01 --> Router Class Initialized
INFO - 2016-10-05 17:12:01 --> Output Class Initialized
INFO - 2016-10-05 17:12:01 --> Security Class Initialized
DEBUG - 2016-10-05 17:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 17:12:01 --> Input Class Initialized
INFO - 2016-10-05 17:12:01 --> Language Class Initialized
INFO - 2016-10-05 17:12:01 --> Language Class Initialized
INFO - 2016-10-05 17:12:01 --> Config Class Initialized
INFO - 2016-10-05 17:12:01 --> Loader Class Initialized
INFO - 2016-10-05 17:12:01 --> Helper loaded: url_helper
INFO - 2016-10-05 17:12:01 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 17:12:01 --> Controller Class Initialized
DEBUG - 2016-10-05 17:12:01 --> Index MX_Controller Initialized
INFO - 2016-10-05 17:12:01 --> Model Class Initialized
INFO - 2016-10-05 17:12:01 --> Model Class Initialized
ERROR - 2016-10-05 17:12:01 --> Unable to delete cache file for admin/index/getDetailPinjaman
INFO - 2016-10-05 17:12:01 --> Final output sent to browser
DEBUG - 2016-10-05 17:12:01 --> Total execution time: 0.5385
INFO - 2016-10-05 17:12:06 --> Config Class Initialized
INFO - 2016-10-05 17:12:06 --> Hooks Class Initialized
DEBUG - 2016-10-05 17:12:06 --> UTF-8 Support Enabled
INFO - 2016-10-05 17:12:06 --> Utf8 Class Initialized
INFO - 2016-10-05 17:12:06 --> URI Class Initialized
INFO - 2016-10-05 17:12:06 --> Router Class Initialized
INFO - 2016-10-05 17:12:06 --> Output Class Initialized
INFO - 2016-10-05 17:12:06 --> Security Class Initialized
DEBUG - 2016-10-05 17:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 17:12:06 --> Input Class Initialized
INFO - 2016-10-05 17:12:06 --> Language Class Initialized
INFO - 2016-10-05 17:12:06 --> Language Class Initialized
INFO - 2016-10-05 17:12:06 --> Config Class Initialized
INFO - 2016-10-05 17:12:06 --> Loader Class Initialized
INFO - 2016-10-05 17:12:06 --> Helper loaded: url_helper
INFO - 2016-10-05 17:12:06 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 17:12:06 --> Controller Class Initialized
DEBUG - 2016-10-05 17:12:07 --> Index MX_Controller Initialized
INFO - 2016-10-05 17:12:07 --> Model Class Initialized
INFO - 2016-10-05 17:12:07 --> Model Class Initialized
ERROR - 2016-10-05 17:12:07 --> Unable to delete cache file for admin/index/data/anggota
DEBUG - 2016-10-05 17:12:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-05 17:12:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-05 17:12:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-05 17:12:07 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-05 17:12:07 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-05 17:12:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-05 17:12:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-05 17:12:07 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-05 17:12:07 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:07 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:07 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:07 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:07 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:07 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:07 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:07 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:07 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:07 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:07 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:07 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:07 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:07 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:07 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:07 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:07 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:07 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:07 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:07 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:07 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:07 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:07 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:07 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:07 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:07 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:08 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:08 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:08 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:08 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:08 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:08 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:08 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:08 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:08 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:08 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:08 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:08 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:08 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:08 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:08 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:08 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:08 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:08 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:08 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:08 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:08 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:08 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:08 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:08 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:08 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:08 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:08 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:08 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:08 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:08 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:08 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:08 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:08 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:08 --> Database Driver Class Initialized
DEBUG - 2016-10-05 17:12:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-05 17:12:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-05 17:12:08 --> Final output sent to browser
DEBUG - 2016-10-05 17:12:08 --> Total execution time: 2.3617
INFO - 2016-10-05 17:12:14 --> Config Class Initialized
INFO - 2016-10-05 17:12:14 --> Hooks Class Initialized
DEBUG - 2016-10-05 17:12:14 --> UTF-8 Support Enabled
INFO - 2016-10-05 17:12:14 --> Utf8 Class Initialized
INFO - 2016-10-05 17:12:14 --> URI Class Initialized
INFO - 2016-10-05 17:12:14 --> Router Class Initialized
INFO - 2016-10-05 17:12:14 --> Output Class Initialized
INFO - 2016-10-05 17:12:14 --> Security Class Initialized
DEBUG - 2016-10-05 17:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 17:12:14 --> Input Class Initialized
INFO - 2016-10-05 17:12:14 --> Language Class Initialized
INFO - 2016-10-05 17:12:14 --> Language Class Initialized
INFO - 2016-10-05 17:12:14 --> Config Class Initialized
INFO - 2016-10-05 17:12:14 --> Loader Class Initialized
INFO - 2016-10-05 17:12:14 --> Helper loaded: url_helper
INFO - 2016-10-05 17:12:14 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 17:12:14 --> Controller Class Initialized
DEBUG - 2016-10-05 17:12:14 --> Index MX_Controller Initialized
INFO - 2016-10-05 17:12:14 --> Model Class Initialized
INFO - 2016-10-05 17:12:14 --> Model Class Initialized
ERROR - 2016-10-05 17:12:14 --> Unable to delete cache file for admin/index/add/anggota
DEBUG - 2016-10-05 17:12:14 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-05 17:12:14 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-05 17:12:14 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-05 17:12:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_anggota.php
DEBUG - 2016-10-05 17:12:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-05 17:12:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-05 17:12:15 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:15 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:15 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:15 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:15 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:15 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:15 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:15 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:15 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:15 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:15 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:15 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:15 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:15 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:15 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:15 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:15 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:15 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:15 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:15 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:15 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:15 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:15 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:15 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:15 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:15 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:15 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:15 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:15 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:15 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:15 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:15 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:15 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:16 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:16 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:16 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:16 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:16 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:16 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:16 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:16 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:16 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:16 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:16 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:16 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:16 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:16 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:16 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:16 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:16 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:16 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:16 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:16 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:16 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:16 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:16 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:16 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:16 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:16 --> Database Driver Class Initialized
DEBUG - 2016-10-05 17:12:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-05 17:12:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-05 17:12:16 --> Final output sent to browser
DEBUG - 2016-10-05 17:12:16 --> Total execution time: 2.3974
INFO - 2016-10-05 17:12:52 --> Config Class Initialized
INFO - 2016-10-05 17:12:52 --> Hooks Class Initialized
DEBUG - 2016-10-05 17:12:52 --> UTF-8 Support Enabled
INFO - 2016-10-05 17:12:52 --> Utf8 Class Initialized
INFO - 2016-10-05 17:12:52 --> URI Class Initialized
INFO - 2016-10-05 17:12:52 --> Router Class Initialized
INFO - 2016-10-05 17:12:52 --> Output Class Initialized
INFO - 2016-10-05 17:12:52 --> Security Class Initialized
DEBUG - 2016-10-05 17:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 17:12:52 --> Input Class Initialized
INFO - 2016-10-05 17:12:52 --> Language Class Initialized
INFO - 2016-10-05 17:12:52 --> Language Class Initialized
INFO - 2016-10-05 17:12:53 --> Config Class Initialized
INFO - 2016-10-05 17:12:53 --> Loader Class Initialized
INFO - 2016-10-05 17:12:53 --> Helper loaded: url_helper
INFO - 2016-10-05 17:12:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 17:12:53 --> Controller Class Initialized
DEBUG - 2016-10-05 17:12:53 --> Index MX_Controller Initialized
INFO - 2016-10-05 17:12:53 --> Model Class Initialized
INFO - 2016-10-05 17:12:53 --> Model Class Initialized
ERROR - 2016-10-05 17:12:53 --> Unable to delete cache file for admin/index/post_add
DEBUG - 2016-10-05 17:12:53 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-05 17:12:53 --> Users MX_Controller Initialized
DEBUG - 2016-10-05 17:12:53 --> Index MX_Controller Initialized
ERROR - 2016-10-05 17:12:53 --> Unable to delete cache file for admin/index/post_add
INFO - 2016-10-05 17:12:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:53 --> Final output sent to browser
DEBUG - 2016-10-05 17:12:53 --> Total execution time: 0.8102
INFO - 2016-10-05 17:12:53 --> Config Class Initialized
INFO - 2016-10-05 17:12:53 --> Hooks Class Initialized
DEBUG - 2016-10-05 17:12:53 --> UTF-8 Support Enabled
INFO - 2016-10-05 17:12:53 --> Utf8 Class Initialized
INFO - 2016-10-05 17:12:53 --> URI Class Initialized
INFO - 2016-10-05 17:12:53 --> Router Class Initialized
INFO - 2016-10-05 17:12:53 --> Output Class Initialized
INFO - 2016-10-05 17:12:53 --> Security Class Initialized
DEBUG - 2016-10-05 17:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 17:12:53 --> Input Class Initialized
INFO - 2016-10-05 17:12:53 --> Language Class Initialized
INFO - 2016-10-05 17:12:53 --> Language Class Initialized
INFO - 2016-10-05 17:12:53 --> Config Class Initialized
INFO - 2016-10-05 17:12:53 --> Loader Class Initialized
INFO - 2016-10-05 17:12:53 --> Helper loaded: url_helper
INFO - 2016-10-05 17:12:54 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 17:12:54 --> Controller Class Initialized
DEBUG - 2016-10-05 17:12:54 --> Index MX_Controller Initialized
INFO - 2016-10-05 17:12:54 --> Model Class Initialized
INFO - 2016-10-05 17:12:54 --> Model Class Initialized
ERROR - 2016-10-05 17:12:54 --> Unable to delete cache file for admin/index/data/anggota
DEBUG - 2016-10-05 17:12:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-05 17:12:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-05 17:12:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-05 17:12:54 --> File already loaded: E:\SERVER\htdocs\kops\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-10-05 17:12:54 --> Anggota MX_Controller Initialized
DEBUG - 2016-10-05 17:12:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_anggota.php
DEBUG - 2016-10-05 17:12:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-05 17:12:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-05 17:12:54 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:54 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:54 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:54 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:54 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:54 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:54 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:54 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:54 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:54 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:54 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:54 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:54 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:54 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:54 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:54 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:54 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:54 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:54 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:54 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:54 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:54 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:54 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:12:55 --> Database Driver Class Initialized
DEBUG - 2016-10-05 17:12:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-05 17:12:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-05 17:12:56 --> Final output sent to browser
DEBUG - 2016-10-05 17:12:56 --> Total execution time: 2.4338
INFO - 2016-10-05 17:13:01 --> Config Class Initialized
INFO - 2016-10-05 17:13:01 --> Hooks Class Initialized
DEBUG - 2016-10-05 17:13:01 --> UTF-8 Support Enabled
INFO - 2016-10-05 17:13:01 --> Utf8 Class Initialized
INFO - 2016-10-05 17:13:01 --> URI Class Initialized
INFO - 2016-10-05 17:13:01 --> Router Class Initialized
INFO - 2016-10-05 17:13:01 --> Output Class Initialized
INFO - 2016-10-05 17:13:01 --> Security Class Initialized
DEBUG - 2016-10-05 17:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 17:13:01 --> Input Class Initialized
INFO - 2016-10-05 17:13:01 --> Language Class Initialized
INFO - 2016-10-05 17:13:01 --> Language Class Initialized
INFO - 2016-10-05 17:13:01 --> Config Class Initialized
INFO - 2016-10-05 17:13:01 --> Loader Class Initialized
INFO - 2016-10-05 17:13:01 --> Helper loaded: url_helper
INFO - 2016-10-05 17:13:02 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 17:13:02 --> Controller Class Initialized
DEBUG - 2016-10-05 17:13:02 --> Index MX_Controller Initialized
INFO - 2016-10-05 17:13:02 --> Model Class Initialized
INFO - 2016-10-05 17:13:02 --> Model Class Initialized
ERROR - 2016-10-05 17:13:02 --> Unable to delete cache file for admin/index/data_peminjam
DEBUG - 2016-10-05 17:13:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-05 17:13:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-05 17:13:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-05 17:13:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_peminjam.php
DEBUG - 2016-10-05 17:13:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-05 17:13:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-05 17:13:02 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:02 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:02 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:02 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:02 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:02 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:02 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:02 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:02 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:02 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:02 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:02 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:02 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:02 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:02 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:02 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:02 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:02 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:02 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:02 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:04 --> Database Driver Class Initialized
DEBUG - 2016-10-05 17:13:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-05 17:13:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-05 17:13:04 --> Final output sent to browser
DEBUG - 2016-10-05 17:13:04 --> Total execution time: 2.4827
INFO - 2016-10-05 17:13:08 --> Config Class Initialized
INFO - 2016-10-05 17:13:08 --> Hooks Class Initialized
DEBUG - 2016-10-05 17:13:08 --> UTF-8 Support Enabled
INFO - 2016-10-05 17:13:08 --> Utf8 Class Initialized
INFO - 2016-10-05 17:13:08 --> URI Class Initialized
INFO - 2016-10-05 17:13:08 --> Router Class Initialized
INFO - 2016-10-05 17:13:08 --> Output Class Initialized
INFO - 2016-10-05 17:13:08 --> Security Class Initialized
DEBUG - 2016-10-05 17:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 17:13:08 --> Input Class Initialized
INFO - 2016-10-05 17:13:08 --> Language Class Initialized
INFO - 2016-10-05 17:13:08 --> Language Class Initialized
INFO - 2016-10-05 17:13:08 --> Config Class Initialized
INFO - 2016-10-05 17:13:08 --> Loader Class Initialized
INFO - 2016-10-05 17:13:08 --> Helper loaded: url_helper
INFO - 2016-10-05 17:13:08 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 17:13:09 --> Controller Class Initialized
DEBUG - 2016-10-05 17:13:09 --> Index MX_Controller Initialized
INFO - 2016-10-05 17:13:09 --> Model Class Initialized
INFO - 2016-10-05 17:13:09 --> Model Class Initialized
ERROR - 2016-10-05 17:13:09 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-10-05 17:13:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-05 17:13:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-05 17:13:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-05 17:13:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-10-05 17:13:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-05 17:13:09 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-05 17:13:09 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:09 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:09 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:09 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:09 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:09 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:09 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:09 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:09 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:09 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:09 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:09 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:09 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:09 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:09 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:09 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:09 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:09 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:09 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:09 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:09 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:09 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:09 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:09 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:09 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:09 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:09 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:09 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:09 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:10 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:10 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:10 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:10 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:10 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:10 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:10 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:10 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:10 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:10 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:10 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:10 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:10 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:10 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:10 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:10 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:10 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:10 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:10 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:10 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:10 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:10 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:10 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:10 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:10 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:10 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:10 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:10 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:10 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:10 --> Database Driver Class Initialized
DEBUG - 2016-10-05 17:13:10 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-05 17:13:10 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-05 17:13:10 --> Final output sent to browser
DEBUG - 2016-10-05 17:13:10 --> Total execution time: 2.5700
INFO - 2016-10-05 17:13:16 --> Config Class Initialized
INFO - 2016-10-05 17:13:17 --> Hooks Class Initialized
DEBUG - 2016-10-05 17:13:17 --> UTF-8 Support Enabled
INFO - 2016-10-05 17:13:17 --> Utf8 Class Initialized
INFO - 2016-10-05 17:13:17 --> URI Class Initialized
INFO - 2016-10-05 17:13:17 --> Router Class Initialized
INFO - 2016-10-05 17:13:17 --> Output Class Initialized
INFO - 2016-10-05 17:13:17 --> Security Class Initialized
DEBUG - 2016-10-05 17:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 17:13:17 --> Input Class Initialized
INFO - 2016-10-05 17:13:17 --> Language Class Initialized
INFO - 2016-10-05 17:13:17 --> Language Class Initialized
INFO - 2016-10-05 17:13:17 --> Config Class Initialized
INFO - 2016-10-05 17:13:17 --> Loader Class Initialized
INFO - 2016-10-05 17:13:17 --> Helper loaded: url_helper
INFO - 2016-10-05 17:13:17 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 17:13:17 --> Controller Class Initialized
DEBUG - 2016-10-05 17:13:17 --> Index MX_Controller Initialized
INFO - 2016-10-05 17:13:17 --> Model Class Initialized
INFO - 2016-10-05 17:13:17 --> Model Class Initialized
ERROR - 2016-10-05 17:13:17 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-05 17:13:17 --> Anggota MX_Controller Initialized
INFO - 2016-10-05 17:13:17 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:17 --> Final output sent to browser
DEBUG - 2016-10-05 17:13:17 --> Total execution time: 0.7797
INFO - 2016-10-05 17:13:21 --> Config Class Initialized
INFO - 2016-10-05 17:13:21 --> Hooks Class Initialized
DEBUG - 2016-10-05 17:13:21 --> UTF-8 Support Enabled
INFO - 2016-10-05 17:13:22 --> Utf8 Class Initialized
INFO - 2016-10-05 17:13:22 --> URI Class Initialized
INFO - 2016-10-05 17:13:22 --> Router Class Initialized
INFO - 2016-10-05 17:13:22 --> Output Class Initialized
INFO - 2016-10-05 17:13:22 --> Security Class Initialized
DEBUG - 2016-10-05 17:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 17:13:22 --> Input Class Initialized
INFO - 2016-10-05 17:13:22 --> Language Class Initialized
INFO - 2016-10-05 17:13:22 --> Language Class Initialized
INFO - 2016-10-05 17:13:22 --> Config Class Initialized
INFO - 2016-10-05 17:13:22 --> Loader Class Initialized
INFO - 2016-10-05 17:13:22 --> Helper loaded: url_helper
INFO - 2016-10-05 17:13:22 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 17:13:22 --> Controller Class Initialized
DEBUG - 2016-10-05 17:13:22 --> Index MX_Controller Initialized
INFO - 2016-10-05 17:13:22 --> Model Class Initialized
INFO - 2016-10-05 17:13:22 --> Model Class Initialized
ERROR - 2016-10-05 17:13:22 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-10-05 17:13:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-05 17:13:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-05 17:13:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-05 17:13:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-10-05 17:13:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-05 17:13:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-05 17:13:22 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:22 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:22 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:22 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:22 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:22 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:22 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:22 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:22 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:22 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:22 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:23 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:23 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:23 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:23 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:23 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:23 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:23 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:23 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:23 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:23 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:23 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:23 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:23 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:23 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:23 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:23 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:23 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:23 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:23 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:23 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:23 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:23 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:23 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:23 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:23 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:23 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:23 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:23 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:23 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:23 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:23 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:23 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:23 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:23 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:23 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:24 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:24 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:24 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:24 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:24 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:24 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:24 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:24 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:24 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:24 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:24 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:24 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:24 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:24 --> Database Driver Class Initialized
DEBUG - 2016-10-05 17:13:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-05 17:13:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-05 17:13:24 --> Final output sent to browser
DEBUG - 2016-10-05 17:13:24 --> Total execution time: 2.5332
INFO - 2016-10-05 17:13:51 --> Config Class Initialized
INFO - 2016-10-05 17:13:51 --> Hooks Class Initialized
DEBUG - 2016-10-05 17:13:51 --> UTF-8 Support Enabled
INFO - 2016-10-05 17:13:51 --> Utf8 Class Initialized
INFO - 2016-10-05 17:13:51 --> URI Class Initialized
INFO - 2016-10-05 17:13:51 --> Router Class Initialized
INFO - 2016-10-05 17:13:51 --> Output Class Initialized
INFO - 2016-10-05 17:13:51 --> Security Class Initialized
DEBUG - 2016-10-05 17:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 17:13:51 --> Input Class Initialized
INFO - 2016-10-05 17:13:51 --> Language Class Initialized
INFO - 2016-10-05 17:13:51 --> Language Class Initialized
INFO - 2016-10-05 17:13:51 --> Config Class Initialized
INFO - 2016-10-05 17:13:51 --> Loader Class Initialized
INFO - 2016-10-05 17:13:52 --> Helper loaded: url_helper
INFO - 2016-10-05 17:13:52 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 17:13:52 --> Controller Class Initialized
DEBUG - 2016-10-05 17:13:52 --> Index MX_Controller Initialized
INFO - 2016-10-05 17:13:52 --> Model Class Initialized
INFO - 2016-10-05 17:13:52 --> Model Class Initialized
ERROR - 2016-10-05 17:13:52 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-10-05 17:13:52 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-05 17:13:52 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-05 17:13:52 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-05 17:13:52 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_karyawan.php
DEBUG - 2016-10-05 17:13:52 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-05 17:13:52 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-05 17:13:52 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:52 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:52 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:52 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:52 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:52 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:52 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:52 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:52 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:52 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:52 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:52 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:52 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:52 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:52 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:52 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:52 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:52 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:53 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:54 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:54 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:54 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:54 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:54 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:54 --> Database Driver Class Initialized
INFO - 2016-10-05 17:13:54 --> Database Driver Class Initialized
DEBUG - 2016-10-05 17:13:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-05 17:13:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-05 17:13:54 --> Final output sent to browser
DEBUG - 2016-10-05 17:13:54 --> Total execution time: 2.6686
INFO - 2016-10-05 17:17:26 --> Config Class Initialized
INFO - 2016-10-05 17:17:26 --> Hooks Class Initialized
DEBUG - 2016-10-05 17:17:26 --> UTF-8 Support Enabled
INFO - 2016-10-05 17:17:26 --> Utf8 Class Initialized
INFO - 2016-10-05 17:17:26 --> URI Class Initialized
INFO - 2016-10-05 17:17:26 --> Router Class Initialized
INFO - 2016-10-05 17:17:26 --> Output Class Initialized
INFO - 2016-10-05 17:17:26 --> Security Class Initialized
DEBUG - 2016-10-05 17:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 17:17:26 --> Input Class Initialized
INFO - 2016-10-05 17:17:26 --> Language Class Initialized
INFO - 2016-10-05 17:17:26 --> Language Class Initialized
INFO - 2016-10-05 17:17:26 --> Config Class Initialized
INFO - 2016-10-05 17:17:26 --> Loader Class Initialized
INFO - 2016-10-05 17:17:26 --> Helper loaded: url_helper
INFO - 2016-10-05 17:17:26 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 17:17:26 --> Controller Class Initialized
DEBUG - 2016-10-05 17:17:26 --> Index MX_Controller Initialized
INFO - 2016-10-05 17:17:26 --> Model Class Initialized
INFO - 2016-10-05 17:17:26 --> Model Class Initialized
ERROR - 2016-10-05 17:17:26 --> Unable to delete cache file for admin/index/buku_besar
DEBUG - 2016-10-05 17:17:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-05 17:17:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-05 17:17:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-05 17:17:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/buku_besar.php
DEBUG - 2016-10-05 17:17:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-05 17:17:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-05 17:17:27 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:27 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:27 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:27 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:27 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:27 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:27 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:27 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:27 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:27 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:27 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:27 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:27 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:27 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:27 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:27 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:27 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:27 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:29 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:29 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:29 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:29 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:29 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:29 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:29 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:29 --> Database Driver Class Initialized
INFO - 2016-10-05 17:17:29 --> Database Driver Class Initialized
DEBUG - 2016-10-05 17:17:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-05 17:17:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-05 17:17:29 --> Final output sent to browser
DEBUG - 2016-10-05 17:17:29 --> Total execution time: 3.1427
INFO - 2016-10-05 17:18:36 --> Config Class Initialized
INFO - 2016-10-05 17:18:36 --> Hooks Class Initialized
DEBUG - 2016-10-05 17:18:36 --> UTF-8 Support Enabled
INFO - 2016-10-05 17:18:36 --> Utf8 Class Initialized
INFO - 2016-10-05 17:18:36 --> URI Class Initialized
INFO - 2016-10-05 17:18:36 --> Router Class Initialized
INFO - 2016-10-05 17:18:36 --> Output Class Initialized
INFO - 2016-10-05 17:18:36 --> Security Class Initialized
DEBUG - 2016-10-05 17:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 17:18:36 --> Input Class Initialized
INFO - 2016-10-05 17:18:36 --> Language Class Initialized
INFO - 2016-10-05 17:18:36 --> Language Class Initialized
INFO - 2016-10-05 17:18:36 --> Config Class Initialized
INFO - 2016-10-05 17:18:37 --> Loader Class Initialized
INFO - 2016-10-05 17:18:37 --> Helper loaded: url_helper
INFO - 2016-10-05 17:18:37 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 17:18:37 --> Controller Class Initialized
DEBUG - 2016-10-05 17:18:37 --> Index MX_Controller Initialized
INFO - 2016-10-05 17:18:37 --> Model Class Initialized
INFO - 2016-10-05 17:18:37 --> Model Class Initialized
ERROR - 2016-10-05 17:18:37 --> Unable to delete cache file for admin/index/buku_besar
DEBUG - 2016-10-05 17:18:37 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-05 17:18:37 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-05 17:18:37 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-05 17:18:37 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/buku_besar.php
DEBUG - 2016-10-05 17:18:37 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-05 17:18:37 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-05 17:18:37 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:37 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:37 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:37 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:37 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:37 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:37 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:37 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:37 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:37 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:37 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:37 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:37 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:37 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:37 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:37 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:37 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:37 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:37 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:37 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:37 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:37 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:38 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:38 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:38 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:38 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:38 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:38 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:38 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:38 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:38 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:38 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:38 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:38 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:38 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:38 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:38 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:38 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:38 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:38 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:38 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:38 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:38 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:38 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:38 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:38 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:38 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:38 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:38 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:38 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:38 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:38 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:38 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:38 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:38 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:39 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:39 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:39 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:39 --> Database Driver Class Initialized
INFO - 2016-10-05 17:18:39 --> Database Driver Class Initialized
DEBUG - 2016-10-05 17:18:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-05 17:18:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-05 17:18:39 --> Final output sent to browser
DEBUG - 2016-10-05 17:18:39 --> Total execution time: 2.5963
INFO - 2016-10-05 17:21:01 --> Config Class Initialized
INFO - 2016-10-05 17:21:01 --> Hooks Class Initialized
DEBUG - 2016-10-05 17:21:01 --> UTF-8 Support Enabled
INFO - 2016-10-05 17:21:01 --> Utf8 Class Initialized
INFO - 2016-10-05 17:21:01 --> URI Class Initialized
INFO - 2016-10-05 17:21:01 --> Router Class Initialized
INFO - 2016-10-05 17:21:01 --> Output Class Initialized
INFO - 2016-10-05 17:21:01 --> Security Class Initialized
DEBUG - 2016-10-05 17:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 17:21:01 --> Input Class Initialized
INFO - 2016-10-05 17:21:01 --> Language Class Initialized
INFO - 2016-10-05 17:21:01 --> Language Class Initialized
INFO - 2016-10-05 17:21:02 --> Config Class Initialized
INFO - 2016-10-05 17:21:02 --> Loader Class Initialized
INFO - 2016-10-05 17:21:02 --> Helper loaded: url_helper
INFO - 2016-10-05 17:21:02 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 17:21:02 --> Controller Class Initialized
DEBUG - 2016-10-05 17:21:02 --> Index MX_Controller Initialized
INFO - 2016-10-05 17:21:02 --> Model Class Initialized
INFO - 2016-10-05 17:21:02 --> Model Class Initialized
ERROR - 2016-10-05 17:21:02 --> Unable to delete cache file for admin/index/data_peminjam
DEBUG - 2016-10-05 17:21:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-05 17:21:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-05 17:21:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-05 17:21:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_peminjam.php
DEBUG - 2016-10-05 17:21:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-05 17:21:02 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-05 17:21:02 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:02 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:02 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:02 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:02 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:02 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:02 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:02 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:02 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:02 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:02 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:02 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:02 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:02 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:02 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:04 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:04 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:04 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:04 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:04 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:04 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:04 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:04 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:04 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:04 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:04 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:04 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:04 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:04 --> Database Driver Class Initialized
DEBUG - 2016-10-05 17:21:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-05 17:21:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-05 17:21:04 --> Final output sent to browser
DEBUG - 2016-10-05 17:21:04 --> Total execution time: 2.8889
INFO - 2016-10-05 17:21:12 --> Config Class Initialized
INFO - 2016-10-05 17:21:12 --> Hooks Class Initialized
DEBUG - 2016-10-05 17:21:12 --> UTF-8 Support Enabled
INFO - 2016-10-05 17:21:12 --> Utf8 Class Initialized
INFO - 2016-10-05 17:21:12 --> URI Class Initialized
INFO - 2016-10-05 17:21:12 --> Router Class Initialized
INFO - 2016-10-05 17:21:12 --> Output Class Initialized
INFO - 2016-10-05 17:21:12 --> Security Class Initialized
DEBUG - 2016-10-05 17:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 17:21:12 --> Input Class Initialized
INFO - 2016-10-05 17:21:12 --> Language Class Initialized
INFO - 2016-10-05 17:21:12 --> Language Class Initialized
INFO - 2016-10-05 17:21:12 --> Config Class Initialized
INFO - 2016-10-05 17:21:12 --> Loader Class Initialized
INFO - 2016-10-05 17:21:12 --> Helper loaded: url_helper
INFO - 2016-10-05 17:21:12 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 17:21:12 --> Controller Class Initialized
DEBUG - 2016-10-05 17:21:12 --> Index MX_Controller Initialized
INFO - 2016-10-05 17:21:12 --> Model Class Initialized
INFO - 2016-10-05 17:21:12 --> Model Class Initialized
ERROR - 2016-10-05 17:21:12 --> Unable to delete cache file for admin/index/getDataPeminjam
DEBUG - 2016-10-05 17:21:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-10-05 17:21:13 --> Final output sent to browser
DEBUG - 2016-10-05 17:21:13 --> Total execution time: 0.6898
INFO - 2016-10-05 17:21:13 --> Config Class Initialized
INFO - 2016-10-05 17:21:13 --> Hooks Class Initialized
DEBUG - 2016-10-05 17:21:13 --> UTF-8 Support Enabled
INFO - 2016-10-05 17:21:13 --> Utf8 Class Initialized
INFO - 2016-10-05 17:21:13 --> URI Class Initialized
INFO - 2016-10-05 17:21:13 --> Router Class Initialized
INFO - 2016-10-05 17:21:13 --> Output Class Initialized
INFO - 2016-10-05 17:21:13 --> Security Class Initialized
DEBUG - 2016-10-05 17:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 17:21:13 --> Input Class Initialized
INFO - 2016-10-05 17:21:13 --> Language Class Initialized
INFO - 2016-10-05 17:21:13 --> Language Class Initialized
INFO - 2016-10-05 17:21:13 --> Config Class Initialized
INFO - 2016-10-05 17:21:13 --> Loader Class Initialized
INFO - 2016-10-05 17:21:13 --> Helper loaded: url_helper
INFO - 2016-10-05 17:21:13 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 17:21:13 --> Controller Class Initialized
DEBUG - 2016-10-05 17:21:13 --> Index MX_Controller Initialized
INFO - 2016-10-05 17:21:13 --> Model Class Initialized
INFO - 2016-10-05 17:21:13 --> Model Class Initialized
ERROR - 2016-10-05 17:21:13 --> Unable to delete cache file for admin/index/getDataPeminjam/umum
DEBUG - 2016-10-05 17:21:13 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-10-05 17:21:13 --> Final output sent to browser
DEBUG - 2016-10-05 17:21:13 --> Total execution time: 0.6082
INFO - 2016-10-05 17:21:15 --> Config Class Initialized
INFO - 2016-10-05 17:21:15 --> Hooks Class Initialized
DEBUG - 2016-10-05 17:21:15 --> UTF-8 Support Enabled
INFO - 2016-10-05 17:21:15 --> Utf8 Class Initialized
INFO - 2016-10-05 17:21:15 --> URI Class Initialized
INFO - 2016-10-05 17:21:15 --> Router Class Initialized
INFO - 2016-10-05 17:21:15 --> Output Class Initialized
INFO - 2016-10-05 17:21:15 --> Security Class Initialized
DEBUG - 2016-10-05 17:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 17:21:15 --> Input Class Initialized
INFO - 2016-10-05 17:21:15 --> Language Class Initialized
INFO - 2016-10-05 17:21:15 --> Language Class Initialized
INFO - 2016-10-05 17:21:15 --> Config Class Initialized
INFO - 2016-10-05 17:21:15 --> Loader Class Initialized
INFO - 2016-10-05 17:21:15 --> Helper loaded: url_helper
INFO - 2016-10-05 17:21:15 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 17:21:15 --> Config Class Initialized
INFO - 2016-10-05 17:21:15 --> Controller Class Initialized
INFO - 2016-10-05 17:21:15 --> Hooks Class Initialized
DEBUG - 2016-10-05 17:21:15 --> Index MX_Controller Initialized
INFO - 2016-10-05 17:21:15 --> Model Class Initialized
DEBUG - 2016-10-05 17:21:15 --> UTF-8 Support Enabled
INFO - 2016-10-05 17:21:15 --> Utf8 Class Initialized
INFO - 2016-10-05 17:21:15 --> Model Class Initialized
INFO - 2016-10-05 17:21:15 --> URI Class Initialized
ERROR - 2016-10-05 17:21:15 --> Unable to delete cache file for admin/index/getDataPeminjam/karyawan
INFO - 2016-10-05 17:21:15 --> Router Class Initialized
DEBUG - 2016-10-05 17:21:15 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-10-05 17:21:15 --> Output Class Initialized
INFO - 2016-10-05 17:21:16 --> Final output sent to browser
DEBUG - 2016-10-05 17:21:16 --> Total execution time: 0.8020
INFO - 2016-10-05 17:21:16 --> Security Class Initialized
DEBUG - 2016-10-05 17:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 17:21:16 --> Input Class Initialized
INFO - 2016-10-05 17:21:16 --> Language Class Initialized
INFO - 2016-10-05 17:21:16 --> Language Class Initialized
INFO - 2016-10-05 17:21:16 --> Config Class Initialized
INFO - 2016-10-05 17:21:16 --> Loader Class Initialized
INFO - 2016-10-05 17:21:16 --> Helper loaded: url_helper
INFO - 2016-10-05 17:21:16 --> Database Driver Class Initialized
INFO - 2016-10-05 17:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 17:21:16 --> Controller Class Initialized
DEBUG - 2016-10-05 17:21:16 --> Index MX_Controller Initialized
INFO - 2016-10-05 17:21:16 --> Model Class Initialized
INFO - 2016-10-05 17:21:16 --> Model Class Initialized
ERROR - 2016-10-05 17:21:16 --> Unable to delete cache file for admin/index/getDataPeminjam
DEBUG - 2016-10-05 17:21:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/subcontent/data_peminjam.php
INFO - 2016-10-05 17:21:16 --> Final output sent to browser
DEBUG - 2016-10-05 17:21:16 --> Total execution time: 0.8344
INFO - 2016-10-05 17:29:53 --> Config Class Initialized
INFO - 2016-10-05 17:29:53 --> Hooks Class Initialized
DEBUG - 2016-10-05 17:29:53 --> UTF-8 Support Enabled
INFO - 2016-10-05 17:29:53 --> Utf8 Class Initialized
INFO - 2016-10-05 17:29:53 --> URI Class Initialized
INFO - 2016-10-05 17:29:53 --> Router Class Initialized
INFO - 2016-10-05 17:29:53 --> Output Class Initialized
INFO - 2016-10-05 17:29:53 --> Security Class Initialized
DEBUG - 2016-10-05 17:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 17:29:53 --> Input Class Initialized
INFO - 2016-10-05 17:29:53 --> Language Class Initialized
INFO - 2016-10-05 17:29:53 --> Language Class Initialized
INFO - 2016-10-05 17:29:53 --> Config Class Initialized
INFO - 2016-10-05 17:29:53 --> Loader Class Initialized
INFO - 2016-10-05 17:29:53 --> Helper loaded: url_helper
INFO - 2016-10-05 17:29:54 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 17:29:54 --> Controller Class Initialized
DEBUG - 2016-10-05 17:29:54 --> Index MX_Controller Initialized
INFO - 2016-10-05 17:29:54 --> Model Class Initialized
INFO - 2016-10-05 17:29:54 --> Model Class Initialized
ERROR - 2016-10-05 17:29:54 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-10-05 17:29:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-05 17:29:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-05 17:29:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-05 17:29:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_get_anggota.php
DEBUG - 2016-10-05 17:29:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-05 17:29:54 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-05 17:29:54 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:54 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:54 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:54 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:54 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:54 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:54 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:54 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:54 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:54 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:54 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:54 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:54 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:54 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:54 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:54 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:54 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:54 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:54 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:54 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:54 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:54 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:55 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:56 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:56 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:56 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:56 --> Database Driver Class Initialized
INFO - 2016-10-05 17:29:56 --> Database Driver Class Initialized
DEBUG - 2016-10-05 17:29:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-05 17:29:56 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-05 17:29:56 --> Final output sent to browser
DEBUG - 2016-10-05 17:29:56 --> Total execution time: 2.5993
INFO - 2016-10-05 17:30:11 --> Config Class Initialized
INFO - 2016-10-05 17:30:11 --> Hooks Class Initialized
DEBUG - 2016-10-05 17:30:11 --> UTF-8 Support Enabled
INFO - 2016-10-05 17:30:11 --> Utf8 Class Initialized
INFO - 2016-10-05 17:30:11 --> URI Class Initialized
INFO - 2016-10-05 17:30:11 --> Router Class Initialized
INFO - 2016-10-05 17:30:11 --> Output Class Initialized
INFO - 2016-10-05 17:30:11 --> Security Class Initialized
DEBUG - 2016-10-05 17:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 17:30:11 --> Input Class Initialized
INFO - 2016-10-05 17:30:11 --> Language Class Initialized
INFO - 2016-10-05 17:30:11 --> Language Class Initialized
INFO - 2016-10-05 17:30:11 --> Config Class Initialized
INFO - 2016-10-05 17:30:11 --> Loader Class Initialized
INFO - 2016-10-05 17:30:11 --> Helper loaded: url_helper
INFO - 2016-10-05 17:30:11 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 17:30:11 --> Controller Class Initialized
DEBUG - 2016-10-05 17:30:11 --> Index MX_Controller Initialized
INFO - 2016-10-05 17:30:11 --> Model Class Initialized
INFO - 2016-10-05 17:30:11 --> Model Class Initialized
ERROR - 2016-10-05 17:30:11 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-10-05 17:30:11 --> Anggota MX_Controller Initialized
INFO - 2016-10-05 17:30:11 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:12 --> Final output sent to browser
DEBUG - 2016-10-05 17:30:12 --> Total execution time: 0.7435
INFO - 2016-10-05 17:30:26 --> Config Class Initialized
INFO - 2016-10-05 17:30:26 --> Hooks Class Initialized
DEBUG - 2016-10-05 17:30:26 --> UTF-8 Support Enabled
INFO - 2016-10-05 17:30:26 --> Utf8 Class Initialized
INFO - 2016-10-05 17:30:26 --> URI Class Initialized
INFO - 2016-10-05 17:30:26 --> Router Class Initialized
INFO - 2016-10-05 17:30:26 --> Output Class Initialized
INFO - 2016-10-05 17:30:26 --> Security Class Initialized
DEBUG - 2016-10-05 17:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 17:30:26 --> Input Class Initialized
INFO - 2016-10-05 17:30:26 --> Language Class Initialized
INFO - 2016-10-05 17:30:26 --> Language Class Initialized
INFO - 2016-10-05 17:30:26 --> Config Class Initialized
INFO - 2016-10-05 17:30:26 --> Loader Class Initialized
INFO - 2016-10-05 17:30:26 --> Helper loaded: url_helper
INFO - 2016-10-05 17:30:26 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 17:30:26 --> Controller Class Initialized
DEBUG - 2016-10-05 17:30:26 --> Index MX_Controller Initialized
INFO - 2016-10-05 17:30:26 --> Model Class Initialized
INFO - 2016-10-05 17:30:26 --> Model Class Initialized
ERROR - 2016-10-05 17:30:26 --> Unable to delete cache file for admin/index/proses_peminjaman
DEBUG - 2016-10-05 17:30:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-05 17:30:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-05 17:30:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-05 17:30:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/step_umum.php
DEBUG - 2016-10-05 17:30:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-05 17:30:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-05 17:30:26 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:26 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:26 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:26 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:27 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:27 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:27 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:27 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:27 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:27 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:27 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:27 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:27 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:27 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:27 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:27 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:27 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:27 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:27 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:27 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:27 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:27 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:27 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:27 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:27 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:27 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:27 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:27 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:27 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:27 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:27 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:27 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:27 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:27 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:27 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:28 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:28 --> Database Driver Class Initialized
DEBUG - 2016-10-05 17:30:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-05 17:30:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-05 17:30:28 --> Final output sent to browser
DEBUG - 2016-10-05 17:30:28 --> Total execution time: 2.8535
INFO - 2016-10-05 17:30:42 --> Config Class Initialized
INFO - 2016-10-05 17:30:42 --> Hooks Class Initialized
DEBUG - 2016-10-05 17:30:42 --> UTF-8 Support Enabled
INFO - 2016-10-05 17:30:42 --> Utf8 Class Initialized
INFO - 2016-10-05 17:30:42 --> URI Class Initialized
INFO - 2016-10-05 17:30:42 --> Router Class Initialized
INFO - 2016-10-05 17:30:42 --> Output Class Initialized
INFO - 2016-10-05 17:30:42 --> Security Class Initialized
DEBUG - 2016-10-05 17:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 17:30:42 --> Input Class Initialized
INFO - 2016-10-05 17:30:42 --> Language Class Initialized
INFO - 2016-10-05 17:30:42 --> Language Class Initialized
INFO - 2016-10-05 17:30:42 --> Config Class Initialized
INFO - 2016-10-05 17:30:42 --> Loader Class Initialized
INFO - 2016-10-05 17:30:43 --> Helper loaded: url_helper
INFO - 2016-10-05 17:30:43 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 17:30:43 --> Controller Class Initialized
DEBUG - 2016-10-05 17:30:43 --> Index MX_Controller Initialized
INFO - 2016-10-05 17:30:43 --> Model Class Initialized
INFO - 2016-10-05 17:30:43 --> Model Class Initialized
ERROR - 2016-10-05 17:30:43 --> Unable to delete cache file for admin/index/do_ajukan_pinjaman
INFO - 2016-10-05 17:30:43 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:43 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:43 --> Final output sent to browser
DEBUG - 2016-10-05 17:30:43 --> Total execution time: 0.8514
INFO - 2016-10-05 17:30:48 --> Config Class Initialized
INFO - 2016-10-05 17:30:48 --> Hooks Class Initialized
DEBUG - 2016-10-05 17:30:48 --> UTF-8 Support Enabled
INFO - 2016-10-05 17:30:48 --> Utf8 Class Initialized
INFO - 2016-10-05 17:30:48 --> URI Class Initialized
INFO - 2016-10-05 17:30:48 --> Router Class Initialized
INFO - 2016-10-05 17:30:48 --> Output Class Initialized
INFO - 2016-10-05 17:30:49 --> Security Class Initialized
DEBUG - 2016-10-05 17:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 17:30:49 --> Input Class Initialized
INFO - 2016-10-05 17:30:49 --> Language Class Initialized
INFO - 2016-10-05 17:30:49 --> Language Class Initialized
INFO - 2016-10-05 17:30:49 --> Config Class Initialized
INFO - 2016-10-05 17:30:49 --> Loader Class Initialized
INFO - 2016-10-05 17:30:49 --> Helper loaded: url_helper
INFO - 2016-10-05 17:30:49 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 17:30:49 --> Controller Class Initialized
DEBUG - 2016-10-05 17:30:49 --> Index MX_Controller Initialized
INFO - 2016-10-05 17:30:49 --> Model Class Initialized
INFO - 2016-10-05 17:30:49 --> Model Class Initialized
ERROR - 2016-10-05 17:30:49 --> Unable to delete cache file for admin/index/do_save_jaminan
INFO - 2016-10-05 17:30:49 --> Database Driver Class Initialized
INFO - 2016-10-05 17:30:49 --> Final output sent to browser
DEBUG - 2016-10-05 17:30:49 --> Total execution time: 0.8035
INFO - 2016-10-05 17:31:01 --> Config Class Initialized
INFO - 2016-10-05 17:31:01 --> Hooks Class Initialized
DEBUG - 2016-10-05 17:31:01 --> UTF-8 Support Enabled
INFO - 2016-10-05 17:31:01 --> Utf8 Class Initialized
INFO - 2016-10-05 17:31:01 --> URI Class Initialized
INFO - 2016-10-05 17:31:01 --> Router Class Initialized
INFO - 2016-10-05 17:31:01 --> Output Class Initialized
INFO - 2016-10-05 17:31:01 --> Security Class Initialized
DEBUG - 2016-10-05 17:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 17:31:01 --> Input Class Initialized
INFO - 2016-10-05 17:31:01 --> Language Class Initialized
INFO - 2016-10-05 17:31:01 --> Language Class Initialized
INFO - 2016-10-05 17:31:01 --> Config Class Initialized
INFO - 2016-10-05 17:31:01 --> Loader Class Initialized
INFO - 2016-10-05 17:31:01 --> Helper loaded: url_helper
INFO - 2016-10-05 17:31:01 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 17:31:01 --> Controller Class Initialized
DEBUG - 2016-10-05 17:31:01 --> Index MX_Controller Initialized
INFO - 2016-10-05 17:31:01 --> Model Class Initialized
INFO - 2016-10-05 17:31:01 --> Model Class Initialized
ERROR - 2016-10-05 17:31:01 --> Unable to delete cache file for admin/index/finish_pinjaman/356a192b7913b04c54574d18c28d46e6395428ab
INFO - 2016-10-05 17:31:01 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:01 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:02 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:02 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:02 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:02 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:02 --> Final output sent to browser
DEBUG - 2016-10-05 17:31:02 --> Total execution time: 1.1105
INFO - 2016-10-05 17:31:02 --> Config Class Initialized
INFO - 2016-10-05 17:31:02 --> Hooks Class Initialized
DEBUG - 2016-10-05 17:31:02 --> UTF-8 Support Enabled
INFO - 2016-10-05 17:31:02 --> Utf8 Class Initialized
INFO - 2016-10-05 17:31:02 --> URI Class Initialized
INFO - 2016-10-05 17:31:02 --> Router Class Initialized
INFO - 2016-10-05 17:31:02 --> Output Class Initialized
INFO - 2016-10-05 17:31:02 --> Security Class Initialized
DEBUG - 2016-10-05 17:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 17:31:02 --> Input Class Initialized
INFO - 2016-10-05 17:31:02 --> Language Class Initialized
INFO - 2016-10-05 17:31:03 --> Language Class Initialized
INFO - 2016-10-05 17:31:03 --> Config Class Initialized
INFO - 2016-10-05 17:31:03 --> Loader Class Initialized
INFO - 2016-10-05 17:31:03 --> Helper loaded: url_helper
INFO - 2016-10-05 17:31:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 17:31:03 --> Controller Class Initialized
DEBUG - 2016-10-05 17:31:03 --> Index MX_Controller Initialized
INFO - 2016-10-05 17:31:03 --> Model Class Initialized
INFO - 2016-10-05 17:31:03 --> Model Class Initialized
ERROR - 2016-10-05 17:31:03 --> Unable to delete cache file for admin/index/data_peminjam
DEBUG - 2016-10-05 17:31:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-05 17:31:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-05 17:31:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-05 17:31:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/list_peminjam.php
DEBUG - 2016-10-05 17:31:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-05 17:31:03 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-05 17:31:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:03 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:04 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:04 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:04 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:04 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:04 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:04 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:04 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:04 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:04 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:04 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:04 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:04 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:04 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:04 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:04 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:04 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:04 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:04 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:04 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:04 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:04 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:04 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:04 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:04 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:04 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:04 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:04 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:04 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:04 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:04 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:04 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:05 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:05 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:05 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:05 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:05 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:05 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:05 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:05 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:05 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:05 --> Database Driver Class Initialized
DEBUG - 2016-10-05 17:31:05 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-05 17:31:05 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-05 17:31:05 --> Final output sent to browser
DEBUG - 2016-10-05 17:31:05 --> Total execution time: 2.8305
INFO - 2016-10-05 17:31:11 --> Config Class Initialized
INFO - 2016-10-05 17:31:11 --> Hooks Class Initialized
DEBUG - 2016-10-05 17:31:11 --> UTF-8 Support Enabled
INFO - 2016-10-05 17:31:11 --> Utf8 Class Initialized
INFO - 2016-10-05 17:31:11 --> URI Class Initialized
INFO - 2016-10-05 17:31:11 --> Router Class Initialized
INFO - 2016-10-05 17:31:11 --> Output Class Initialized
INFO - 2016-10-05 17:31:11 --> Security Class Initialized
DEBUG - 2016-10-05 17:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 17:31:12 --> Input Class Initialized
INFO - 2016-10-05 17:31:12 --> Language Class Initialized
INFO - 2016-10-05 17:31:12 --> Language Class Initialized
INFO - 2016-10-05 17:31:12 --> Config Class Initialized
INFO - 2016-10-05 17:31:12 --> Loader Class Initialized
INFO - 2016-10-05 17:31:12 --> Helper loaded: url_helper
INFO - 2016-10-05 17:31:12 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 17:31:12 --> Controller Class Initialized
DEBUG - 2016-10-05 17:31:12 --> Index MX_Controller Initialized
INFO - 2016-10-05 17:31:12 --> Model Class Initialized
INFO - 2016-10-05 17:31:12 --> Model Class Initialized
ERROR - 2016-10-05 17:31:12 --> Unable to delete cache file for admin/index/buku_besar
DEBUG - 2016-10-05 17:31:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-05 17:31:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-05 17:31:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-05 17:31:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/buku_besar.php
DEBUG - 2016-10-05 17:31:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-05 17:31:12 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-05 17:31:12 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:12 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:12 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:12 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:12 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:12 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:12 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:12 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:12 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:12 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:12 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:12 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:12 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:13 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:13 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:13 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:13 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:13 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:13 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:13 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:13 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:13 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:13 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:13 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:13 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:13 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:13 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:13 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:13 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:13 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:13 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:13 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:13 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:13 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:13 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:13 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:13 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:13 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:13 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:13 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:13 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:14 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:14 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:14 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:14 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:14 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:14 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:14 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:14 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:14 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:14 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:14 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:14 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:14 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:14 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:14 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:14 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:14 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:14 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:14 --> Database Driver Class Initialized
DEBUG - 2016-10-05 17:31:14 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-05 17:31:14 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-05 17:31:14 --> Final output sent to browser
DEBUG - 2016-10-05 17:31:15 --> Total execution time: 3.2305
INFO - 2016-10-05 17:31:26 --> Config Class Initialized
INFO - 2016-10-05 17:31:26 --> Hooks Class Initialized
DEBUG - 2016-10-05 17:31:26 --> UTF-8 Support Enabled
INFO - 2016-10-05 17:31:26 --> Utf8 Class Initialized
INFO - 2016-10-05 17:31:26 --> URI Class Initialized
INFO - 2016-10-05 17:31:26 --> Router Class Initialized
INFO - 2016-10-05 17:31:26 --> Output Class Initialized
INFO - 2016-10-05 17:31:26 --> Security Class Initialized
DEBUG - 2016-10-05 17:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 17:31:26 --> Input Class Initialized
INFO - 2016-10-05 17:31:27 --> Language Class Initialized
INFO - 2016-10-05 17:31:27 --> Language Class Initialized
INFO - 2016-10-05 17:31:27 --> Config Class Initialized
INFO - 2016-10-05 17:31:27 --> Loader Class Initialized
INFO - 2016-10-05 17:31:27 --> Helper loaded: url_helper
INFO - 2016-10-05 17:31:27 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 17:31:27 --> Controller Class Initialized
DEBUG - 2016-10-05 17:31:27 --> Index MX_Controller Initialized
INFO - 2016-10-05 17:31:27 --> Model Class Initialized
INFO - 2016-10-05 17:31:27 --> Model Class Initialized
ERROR - 2016-10-05 17:31:27 --> Unable to delete cache file for admin/index/do_laporan_buku_besar
DEBUG - 2016-10-05 17:31:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_buku_besar.php
INFO - 2016-10-05 17:31:27 --> Final output sent to browser
DEBUG - 2016-10-05 17:31:27 --> Total execution time: 0.6682
INFO - 2016-10-05 17:31:31 --> Config Class Initialized
INFO - 2016-10-05 17:31:32 --> Hooks Class Initialized
DEBUG - 2016-10-05 17:31:32 --> UTF-8 Support Enabled
INFO - 2016-10-05 17:31:32 --> Utf8 Class Initialized
INFO - 2016-10-05 17:31:32 --> URI Class Initialized
INFO - 2016-10-05 17:31:32 --> Router Class Initialized
INFO - 2016-10-05 17:31:32 --> Output Class Initialized
INFO - 2016-10-05 17:31:32 --> Security Class Initialized
DEBUG - 2016-10-05 17:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 17:31:32 --> Input Class Initialized
INFO - 2016-10-05 17:31:32 --> Language Class Initialized
INFO - 2016-10-05 17:31:32 --> Language Class Initialized
INFO - 2016-10-05 17:31:32 --> Config Class Initialized
INFO - 2016-10-05 17:31:32 --> Loader Class Initialized
INFO - 2016-10-05 17:31:32 --> Helper loaded: url_helper
INFO - 2016-10-05 17:31:32 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 17:31:32 --> Controller Class Initialized
DEBUG - 2016-10-05 17:31:32 --> Index MX_Controller Initialized
INFO - 2016-10-05 17:31:32 --> Model Class Initialized
INFO - 2016-10-05 17:31:32 --> Model Class Initialized
ERROR - 2016-10-05 17:31:32 --> Unable to delete cache file for admin/index/do_laporan_buku_besar
DEBUG - 2016-10-05 17:31:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_buku_besar.php
INFO - 2016-10-05 17:31:32 --> Final output sent to browser
DEBUG - 2016-10-05 17:31:32 --> Total execution time: 0.6674
INFO - 2016-10-05 17:31:37 --> Config Class Initialized
INFO - 2016-10-05 17:31:38 --> Hooks Class Initialized
DEBUG - 2016-10-05 17:31:38 --> UTF-8 Support Enabled
INFO - 2016-10-05 17:31:38 --> Utf8 Class Initialized
INFO - 2016-10-05 17:31:38 --> URI Class Initialized
INFO - 2016-10-05 17:31:38 --> Router Class Initialized
INFO - 2016-10-05 17:31:38 --> Output Class Initialized
INFO - 2016-10-05 17:31:38 --> Security Class Initialized
DEBUG - 2016-10-05 17:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 17:31:38 --> Input Class Initialized
INFO - 2016-10-05 17:31:38 --> Language Class Initialized
INFO - 2016-10-05 17:31:38 --> Language Class Initialized
INFO - 2016-10-05 17:31:38 --> Config Class Initialized
INFO - 2016-10-05 17:31:38 --> Loader Class Initialized
INFO - 2016-10-05 17:31:38 --> Helper loaded: url_helper
INFO - 2016-10-05 17:31:38 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 17:31:38 --> Controller Class Initialized
DEBUG - 2016-10-05 17:31:38 --> Index MX_Controller Initialized
INFO - 2016-10-05 17:31:38 --> Model Class Initialized
INFO - 2016-10-05 17:31:38 --> Model Class Initialized
ERROR - 2016-10-05 17:31:38 --> Unable to delete cache file for admin/index/do_laporan_buku_besar
DEBUG - 2016-10-05 17:31:38 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/laporan/data_buku_besar.php
INFO - 2016-10-05 17:31:38 --> Final output sent to browser
DEBUG - 2016-10-05 17:31:38 --> Total execution time: 0.6621
INFO - 2016-10-05 17:31:56 --> Config Class Initialized
INFO - 2016-10-05 17:31:56 --> Hooks Class Initialized
DEBUG - 2016-10-05 17:31:56 --> UTF-8 Support Enabled
INFO - 2016-10-05 17:31:56 --> Utf8 Class Initialized
INFO - 2016-10-05 17:31:56 --> URI Class Initialized
INFO - 2016-10-05 17:31:57 --> Router Class Initialized
INFO - 2016-10-05 17:31:57 --> Output Class Initialized
INFO - 2016-10-05 17:31:57 --> Security Class Initialized
DEBUG - 2016-10-05 17:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 17:31:57 --> Input Class Initialized
INFO - 2016-10-05 17:31:57 --> Language Class Initialized
INFO - 2016-10-05 17:31:57 --> Language Class Initialized
INFO - 2016-10-05 17:31:57 --> Config Class Initialized
INFO - 2016-10-05 17:31:57 --> Loader Class Initialized
INFO - 2016-10-05 17:31:57 --> Helper loaded: url_helper
INFO - 2016-10-05 17:31:57 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 17:31:57 --> Controller Class Initialized
DEBUG - 2016-10-05 17:31:57 --> Index MX_Controller Initialized
INFO - 2016-10-05 17:31:57 --> Model Class Initialized
INFO - 2016-10-05 17:31:57 --> Model Class Initialized
ERROR - 2016-10-05 17:31:57 --> Unable to delete cache file for admin/index/bayar_angsuran
DEBUG - 2016-10-05 17:31:57 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-05 17:31:57 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-05 17:31:57 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-05 17:31:57 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_bayar_angsuran.php
DEBUG - 2016-10-05 17:31:57 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-05 17:31:57 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-05 17:31:57 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:57 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:57 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:57 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:57 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:57 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:57 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:57 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:57 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:57 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:58 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:58 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:58 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:58 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:58 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:58 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:58 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:58 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:58 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:58 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:58 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:58 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:58 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:58 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:58 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:58 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:58 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:58 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:58 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:58 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:58 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:58 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:58 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:58 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:58 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:58 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:58 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:58 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:58 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:58 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:58 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:59 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:59 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:59 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:59 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:59 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:59 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:59 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:59 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:59 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:59 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:59 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:59 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:59 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:59 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:59 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:59 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:59 --> Database Driver Class Initialized
INFO - 2016-10-05 17:31:59 --> Database Driver Class Initialized
DEBUG - 2016-10-05 17:31:59 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-05 17:31:59 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-05 17:31:59 --> Final output sent to browser
DEBUG - 2016-10-05 17:31:59 --> Total execution time: 2.8181
INFO - 2016-10-05 18:54:34 --> Config Class Initialized
INFO - 2016-10-05 18:54:34 --> Hooks Class Initialized
DEBUG - 2016-10-05 18:54:34 --> UTF-8 Support Enabled
INFO - 2016-10-05 18:54:34 --> Utf8 Class Initialized
INFO - 2016-10-05 18:54:34 --> URI Class Initialized
INFO - 2016-10-05 18:54:34 --> Router Class Initialized
INFO - 2016-10-05 18:54:34 --> Output Class Initialized
INFO - 2016-10-05 18:54:34 --> Security Class Initialized
DEBUG - 2016-10-05 18:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 18:54:34 --> Input Class Initialized
INFO - 2016-10-05 18:54:34 --> Language Class Initialized
INFO - 2016-10-05 18:54:34 --> Language Class Initialized
INFO - 2016-10-05 18:54:34 --> Config Class Initialized
INFO - 2016-10-05 18:54:34 --> Loader Class Initialized
INFO - 2016-10-05 18:54:34 --> Helper loaded: url_helper
INFO - 2016-10-05 18:54:34 --> Database Driver Class Initialized
INFO - 2016-10-05 18:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 18:54:34 --> Controller Class Initialized
DEBUG - 2016-10-05 18:54:34 --> Index MX_Controller Initialized
INFO - 2016-10-05 18:54:34 --> Model Class Initialized
INFO - 2016-10-05 18:54:35 --> Model Class Initialized
ERROR - 2016-10-05 18:54:35 --> Unable to delete cache file for admin/index/test_date
INFO - 2016-10-05 18:54:35 --> Final output sent to browser
DEBUG - 2016-10-05 18:54:35 --> Total execution time: 0.8679
INFO - 2016-10-05 18:54:58 --> Config Class Initialized
INFO - 2016-10-05 18:54:58 --> Hooks Class Initialized
DEBUG - 2016-10-05 18:54:58 --> UTF-8 Support Enabled
INFO - 2016-10-05 18:54:58 --> Utf8 Class Initialized
INFO - 2016-10-05 18:54:58 --> URI Class Initialized
INFO - 2016-10-05 18:54:58 --> Router Class Initialized
INFO - 2016-10-05 18:54:58 --> Output Class Initialized
INFO - 2016-10-05 18:54:58 --> Security Class Initialized
DEBUG - 2016-10-05 18:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 18:54:58 --> Input Class Initialized
INFO - 2016-10-05 18:54:58 --> Language Class Initialized
INFO - 2016-10-05 18:54:58 --> Language Class Initialized
INFO - 2016-10-05 18:54:58 --> Config Class Initialized
INFO - 2016-10-05 18:54:59 --> Loader Class Initialized
INFO - 2016-10-05 18:54:59 --> Helper loaded: url_helper
INFO - 2016-10-05 18:54:59 --> Database Driver Class Initialized
INFO - 2016-10-05 18:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 18:54:59 --> Controller Class Initialized
DEBUG - 2016-10-05 18:54:59 --> Index MX_Controller Initialized
INFO - 2016-10-05 18:54:59 --> Model Class Initialized
INFO - 2016-10-05 18:54:59 --> Model Class Initialized
ERROR - 2016-10-05 18:54:59 --> Unable to delete cache file for admin/index/test_date
INFO - 2016-10-05 18:54:59 --> Final output sent to browser
DEBUG - 2016-10-05 18:54:59 --> Total execution time: 0.7347
INFO - 2016-10-05 18:55:08 --> Config Class Initialized
INFO - 2016-10-05 18:55:08 --> Hooks Class Initialized
DEBUG - 2016-10-05 18:55:08 --> UTF-8 Support Enabled
INFO - 2016-10-05 18:55:08 --> Utf8 Class Initialized
INFO - 2016-10-05 18:55:08 --> URI Class Initialized
INFO - 2016-10-05 18:55:08 --> Router Class Initialized
INFO - 2016-10-05 18:55:08 --> Output Class Initialized
INFO - 2016-10-05 18:55:08 --> Security Class Initialized
DEBUG - 2016-10-05 18:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 18:55:08 --> Input Class Initialized
INFO - 2016-10-05 18:55:08 --> Language Class Initialized
INFO - 2016-10-05 18:55:08 --> Language Class Initialized
INFO - 2016-10-05 18:55:08 --> Config Class Initialized
INFO - 2016-10-05 18:55:08 --> Loader Class Initialized
INFO - 2016-10-05 18:55:08 --> Helper loaded: url_helper
INFO - 2016-10-05 18:55:08 --> Database Driver Class Initialized
INFO - 2016-10-05 18:55:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 18:55:08 --> Controller Class Initialized
DEBUG - 2016-10-05 18:55:08 --> Index MX_Controller Initialized
INFO - 2016-10-05 18:55:08 --> Model Class Initialized
INFO - 2016-10-05 18:55:08 --> Model Class Initialized
ERROR - 2016-10-05 18:55:08 --> Unable to delete cache file for admin/index/test_date
INFO - 2016-10-05 18:55:09 --> Final output sent to browser
DEBUG - 2016-10-05 18:55:09 --> Total execution time: 0.6710
INFO - 2016-10-05 18:55:18 --> Config Class Initialized
INFO - 2016-10-05 18:55:18 --> Hooks Class Initialized
DEBUG - 2016-10-05 18:55:18 --> UTF-8 Support Enabled
INFO - 2016-10-05 18:55:18 --> Utf8 Class Initialized
INFO - 2016-10-05 18:55:18 --> URI Class Initialized
INFO - 2016-10-05 18:55:18 --> Router Class Initialized
INFO - 2016-10-05 18:55:18 --> Output Class Initialized
INFO - 2016-10-05 18:55:18 --> Security Class Initialized
DEBUG - 2016-10-05 18:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 18:55:18 --> Input Class Initialized
INFO - 2016-10-05 18:55:18 --> Language Class Initialized
INFO - 2016-10-05 18:55:18 --> Language Class Initialized
INFO - 2016-10-05 18:55:18 --> Config Class Initialized
INFO - 2016-10-05 18:55:19 --> Loader Class Initialized
INFO - 2016-10-05 18:55:19 --> Helper loaded: url_helper
INFO - 2016-10-05 18:55:19 --> Database Driver Class Initialized
INFO - 2016-10-05 18:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 18:55:19 --> Controller Class Initialized
DEBUG - 2016-10-05 18:55:19 --> Index MX_Controller Initialized
INFO - 2016-10-05 18:55:19 --> Model Class Initialized
INFO - 2016-10-05 18:55:19 --> Model Class Initialized
ERROR - 2016-10-05 18:55:19 --> Unable to delete cache file for admin/index/test_date
INFO - 2016-10-05 18:55:19 --> Final output sent to browser
DEBUG - 2016-10-05 18:55:19 --> Total execution time: 0.6491
INFO - 2016-10-05 18:55:34 --> Config Class Initialized
INFO - 2016-10-05 18:55:34 --> Hooks Class Initialized
DEBUG - 2016-10-05 18:55:35 --> UTF-8 Support Enabled
INFO - 2016-10-05 18:55:35 --> Utf8 Class Initialized
INFO - 2016-10-05 18:55:35 --> URI Class Initialized
INFO - 2016-10-05 18:55:35 --> Router Class Initialized
INFO - 2016-10-05 18:55:35 --> Output Class Initialized
INFO - 2016-10-05 18:55:35 --> Security Class Initialized
DEBUG - 2016-10-05 18:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 18:55:35 --> Input Class Initialized
INFO - 2016-10-05 18:55:35 --> Language Class Initialized
INFO - 2016-10-05 18:55:35 --> Language Class Initialized
INFO - 2016-10-05 18:55:35 --> Config Class Initialized
INFO - 2016-10-05 18:55:35 --> Loader Class Initialized
INFO - 2016-10-05 18:55:35 --> Helper loaded: url_helper
INFO - 2016-10-05 18:55:35 --> Database Driver Class Initialized
INFO - 2016-10-05 18:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 18:55:35 --> Controller Class Initialized
DEBUG - 2016-10-05 18:55:35 --> Index MX_Controller Initialized
INFO - 2016-10-05 18:55:35 --> Model Class Initialized
INFO - 2016-10-05 18:55:35 --> Model Class Initialized
ERROR - 2016-10-05 18:55:35 --> Unable to delete cache file for admin/index/test_date
INFO - 2016-10-05 18:55:35 --> Final output sent to browser
DEBUG - 2016-10-05 18:55:35 --> Total execution time: 0.6593
INFO - 2016-10-05 18:55:42 --> Config Class Initialized
INFO - 2016-10-05 18:55:42 --> Hooks Class Initialized
DEBUG - 2016-10-05 18:55:42 --> UTF-8 Support Enabled
INFO - 2016-10-05 18:55:42 --> Utf8 Class Initialized
INFO - 2016-10-05 18:55:42 --> URI Class Initialized
INFO - 2016-10-05 18:55:42 --> Router Class Initialized
INFO - 2016-10-05 18:55:42 --> Output Class Initialized
INFO - 2016-10-05 18:55:42 --> Security Class Initialized
DEBUG - 2016-10-05 18:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 18:55:43 --> Input Class Initialized
INFO - 2016-10-05 18:55:43 --> Language Class Initialized
INFO - 2016-10-05 18:55:43 --> Language Class Initialized
INFO - 2016-10-05 18:55:43 --> Config Class Initialized
INFO - 2016-10-05 18:55:43 --> Loader Class Initialized
INFO - 2016-10-05 18:55:43 --> Helper loaded: url_helper
INFO - 2016-10-05 18:55:43 --> Database Driver Class Initialized
INFO - 2016-10-05 18:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 18:55:43 --> Controller Class Initialized
DEBUG - 2016-10-05 18:55:43 --> Index MX_Controller Initialized
INFO - 2016-10-05 18:55:43 --> Model Class Initialized
INFO - 2016-10-05 18:55:43 --> Model Class Initialized
ERROR - 2016-10-05 18:55:43 --> Unable to delete cache file for admin/index/test_date
INFO - 2016-10-05 18:55:43 --> Final output sent to browser
DEBUG - 2016-10-05 18:55:43 --> Total execution time: 0.6418
INFO - 2016-10-05 18:55:48 --> Config Class Initialized
INFO - 2016-10-05 18:55:48 --> Hooks Class Initialized
DEBUG - 2016-10-05 18:55:49 --> UTF-8 Support Enabled
INFO - 2016-10-05 18:55:49 --> Utf8 Class Initialized
INFO - 2016-10-05 18:55:49 --> URI Class Initialized
INFO - 2016-10-05 18:55:49 --> Router Class Initialized
INFO - 2016-10-05 18:55:49 --> Output Class Initialized
INFO - 2016-10-05 18:55:49 --> Security Class Initialized
DEBUG - 2016-10-05 18:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 18:55:49 --> Input Class Initialized
INFO - 2016-10-05 18:55:49 --> Language Class Initialized
INFO - 2016-10-05 18:55:49 --> Language Class Initialized
INFO - 2016-10-05 18:55:49 --> Config Class Initialized
INFO - 2016-10-05 18:55:49 --> Loader Class Initialized
INFO - 2016-10-05 18:55:49 --> Helper loaded: url_helper
INFO - 2016-10-05 18:55:49 --> Database Driver Class Initialized
INFO - 2016-10-05 18:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 18:55:49 --> Controller Class Initialized
DEBUG - 2016-10-05 18:55:49 --> Index MX_Controller Initialized
INFO - 2016-10-05 18:55:49 --> Model Class Initialized
INFO - 2016-10-05 18:55:49 --> Model Class Initialized
ERROR - 2016-10-05 18:55:49 --> Unable to delete cache file for admin/index/test_date
INFO - 2016-10-05 18:55:49 --> Final output sent to browser
DEBUG - 2016-10-05 18:55:49 --> Total execution time: 0.6664
INFO - 2016-10-05 18:55:54 --> Config Class Initialized
INFO - 2016-10-05 18:55:54 --> Hooks Class Initialized
DEBUG - 2016-10-05 18:55:54 --> UTF-8 Support Enabled
INFO - 2016-10-05 18:55:54 --> Utf8 Class Initialized
INFO - 2016-10-05 18:55:54 --> URI Class Initialized
INFO - 2016-10-05 18:55:55 --> Router Class Initialized
INFO - 2016-10-05 18:55:55 --> Output Class Initialized
INFO - 2016-10-05 18:55:55 --> Security Class Initialized
DEBUG - 2016-10-05 18:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 18:55:55 --> Input Class Initialized
INFO - 2016-10-05 18:55:55 --> Language Class Initialized
INFO - 2016-10-05 18:55:55 --> Language Class Initialized
INFO - 2016-10-05 18:55:55 --> Config Class Initialized
INFO - 2016-10-05 18:55:55 --> Loader Class Initialized
INFO - 2016-10-05 18:55:55 --> Helper loaded: url_helper
INFO - 2016-10-05 18:55:55 --> Database Driver Class Initialized
INFO - 2016-10-05 18:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 18:55:55 --> Controller Class Initialized
DEBUG - 2016-10-05 18:55:55 --> Index MX_Controller Initialized
INFO - 2016-10-05 18:55:55 --> Model Class Initialized
INFO - 2016-10-05 18:55:55 --> Model Class Initialized
ERROR - 2016-10-05 18:55:55 --> Unable to delete cache file for admin/index/test_date
INFO - 2016-10-05 18:55:55 --> Final output sent to browser
DEBUG - 2016-10-05 18:55:55 --> Total execution time: 0.8460
INFO - 2016-10-05 18:55:59 --> Config Class Initialized
INFO - 2016-10-05 18:55:59 --> Hooks Class Initialized
DEBUG - 2016-10-05 18:55:59 --> UTF-8 Support Enabled
INFO - 2016-10-05 18:55:59 --> Utf8 Class Initialized
INFO - 2016-10-05 18:55:59 --> URI Class Initialized
INFO - 2016-10-05 18:55:59 --> Router Class Initialized
INFO - 2016-10-05 18:55:59 --> Output Class Initialized
INFO - 2016-10-05 18:55:59 --> Security Class Initialized
DEBUG - 2016-10-05 18:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 18:55:59 --> Input Class Initialized
INFO - 2016-10-05 18:55:59 --> Language Class Initialized
INFO - 2016-10-05 18:55:59 --> Language Class Initialized
INFO - 2016-10-05 18:55:59 --> Config Class Initialized
INFO - 2016-10-05 18:56:00 --> Loader Class Initialized
INFO - 2016-10-05 18:56:00 --> Helper loaded: url_helper
INFO - 2016-10-05 18:56:00 --> Database Driver Class Initialized
INFO - 2016-10-05 18:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 18:56:00 --> Controller Class Initialized
DEBUG - 2016-10-05 18:56:00 --> Index MX_Controller Initialized
INFO - 2016-10-05 18:56:00 --> Model Class Initialized
INFO - 2016-10-05 18:56:00 --> Model Class Initialized
ERROR - 2016-10-05 18:56:00 --> Unable to delete cache file for admin/index/test_date
INFO - 2016-10-05 18:56:00 --> Final output sent to browser
DEBUG - 2016-10-05 18:56:00 --> Total execution time: 0.6770
INFO - 2016-10-05 18:56:12 --> Config Class Initialized
INFO - 2016-10-05 18:56:12 --> Hooks Class Initialized
DEBUG - 2016-10-05 18:56:12 --> UTF-8 Support Enabled
INFO - 2016-10-05 18:56:12 --> Utf8 Class Initialized
INFO - 2016-10-05 18:56:12 --> URI Class Initialized
INFO - 2016-10-05 18:56:12 --> Router Class Initialized
INFO - 2016-10-05 18:56:12 --> Output Class Initialized
INFO - 2016-10-05 18:56:12 --> Security Class Initialized
DEBUG - 2016-10-05 18:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 18:56:12 --> Input Class Initialized
INFO - 2016-10-05 18:56:12 --> Language Class Initialized
INFO - 2016-10-05 18:56:12 --> Language Class Initialized
INFO - 2016-10-05 18:56:12 --> Config Class Initialized
INFO - 2016-10-05 18:56:12 --> Loader Class Initialized
INFO - 2016-10-05 18:56:12 --> Helper loaded: url_helper
INFO - 2016-10-05 18:56:12 --> Database Driver Class Initialized
INFO - 2016-10-05 18:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 18:56:12 --> Controller Class Initialized
DEBUG - 2016-10-05 18:56:12 --> Index MX_Controller Initialized
INFO - 2016-10-05 18:56:12 --> Model Class Initialized
INFO - 2016-10-05 18:56:12 --> Model Class Initialized
ERROR - 2016-10-05 18:56:12 --> Unable to delete cache file for admin/index/test_date
INFO - 2016-10-05 18:56:12 --> Final output sent to browser
DEBUG - 2016-10-05 18:56:12 --> Total execution time: 0.6141
INFO - 2016-10-05 18:56:18 --> Config Class Initialized
INFO - 2016-10-05 18:56:18 --> Hooks Class Initialized
DEBUG - 2016-10-05 18:56:19 --> UTF-8 Support Enabled
INFO - 2016-10-05 18:56:19 --> Utf8 Class Initialized
INFO - 2016-10-05 18:56:19 --> URI Class Initialized
INFO - 2016-10-05 18:56:19 --> Router Class Initialized
INFO - 2016-10-05 18:56:19 --> Output Class Initialized
INFO - 2016-10-05 18:56:19 --> Security Class Initialized
DEBUG - 2016-10-05 18:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 18:56:19 --> Input Class Initialized
INFO - 2016-10-05 18:56:19 --> Language Class Initialized
INFO - 2016-10-05 18:56:19 --> Language Class Initialized
INFO - 2016-10-05 18:56:19 --> Config Class Initialized
INFO - 2016-10-05 18:56:19 --> Loader Class Initialized
INFO - 2016-10-05 18:56:19 --> Helper loaded: url_helper
INFO - 2016-10-05 18:56:19 --> Database Driver Class Initialized
INFO - 2016-10-05 18:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 18:56:19 --> Controller Class Initialized
DEBUG - 2016-10-05 18:56:19 --> Index MX_Controller Initialized
INFO - 2016-10-05 18:56:19 --> Model Class Initialized
INFO - 2016-10-05 18:56:19 --> Model Class Initialized
ERROR - 2016-10-05 18:56:19 --> Unable to delete cache file for admin/index/test_date
INFO - 2016-10-05 18:56:19 --> Final output sent to browser
DEBUG - 2016-10-05 18:56:19 --> Total execution time: 0.7593
INFO - 2016-10-05 18:56:24 --> Config Class Initialized
INFO - 2016-10-05 18:56:24 --> Hooks Class Initialized
DEBUG - 2016-10-05 18:56:24 --> UTF-8 Support Enabled
INFO - 2016-10-05 18:56:24 --> Utf8 Class Initialized
INFO - 2016-10-05 18:56:25 --> URI Class Initialized
INFO - 2016-10-05 18:56:25 --> Router Class Initialized
INFO - 2016-10-05 18:56:25 --> Output Class Initialized
INFO - 2016-10-05 18:56:25 --> Security Class Initialized
DEBUG - 2016-10-05 18:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 18:56:25 --> Input Class Initialized
INFO - 2016-10-05 18:56:25 --> Language Class Initialized
INFO - 2016-10-05 18:56:25 --> Language Class Initialized
INFO - 2016-10-05 18:56:25 --> Config Class Initialized
INFO - 2016-10-05 18:56:25 --> Loader Class Initialized
INFO - 2016-10-05 18:56:25 --> Helper loaded: url_helper
INFO - 2016-10-05 18:56:25 --> Database Driver Class Initialized
INFO - 2016-10-05 18:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 18:56:25 --> Controller Class Initialized
DEBUG - 2016-10-05 18:56:25 --> Index MX_Controller Initialized
INFO - 2016-10-05 18:56:25 --> Model Class Initialized
INFO - 2016-10-05 18:56:25 --> Model Class Initialized
ERROR - 2016-10-05 18:56:25 --> Unable to delete cache file for admin/index/test_date
INFO - 2016-10-05 18:56:25 --> Final output sent to browser
DEBUG - 2016-10-05 18:56:25 --> Total execution time: 0.6724
INFO - 2016-10-05 18:56:31 --> Config Class Initialized
INFO - 2016-10-05 18:56:31 --> Hooks Class Initialized
DEBUG - 2016-10-05 18:56:31 --> UTF-8 Support Enabled
INFO - 2016-10-05 18:56:31 --> Utf8 Class Initialized
INFO - 2016-10-05 18:56:31 --> URI Class Initialized
INFO - 2016-10-05 18:56:31 --> Router Class Initialized
INFO - 2016-10-05 18:56:31 --> Output Class Initialized
INFO - 2016-10-05 18:56:31 --> Security Class Initialized
DEBUG - 2016-10-05 18:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 18:56:31 --> Input Class Initialized
INFO - 2016-10-05 18:56:31 --> Language Class Initialized
INFO - 2016-10-05 18:56:31 --> Language Class Initialized
INFO - 2016-10-05 18:56:31 --> Config Class Initialized
INFO - 2016-10-05 18:56:31 --> Loader Class Initialized
INFO - 2016-10-05 18:56:31 --> Helper loaded: url_helper
INFO - 2016-10-05 18:56:32 --> Database Driver Class Initialized
INFO - 2016-10-05 18:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 18:56:32 --> Controller Class Initialized
DEBUG - 2016-10-05 18:56:32 --> Index MX_Controller Initialized
INFO - 2016-10-05 18:56:32 --> Model Class Initialized
INFO - 2016-10-05 18:56:32 --> Model Class Initialized
ERROR - 2016-10-05 18:56:32 --> Unable to delete cache file for admin/index/test_date
INFO - 2016-10-05 18:56:32 --> Final output sent to browser
DEBUG - 2016-10-05 18:56:32 --> Total execution time: 0.6363
INFO - 2016-10-05 18:56:41 --> Config Class Initialized
INFO - 2016-10-05 18:56:41 --> Hooks Class Initialized
DEBUG - 2016-10-05 18:56:41 --> UTF-8 Support Enabled
INFO - 2016-10-05 18:56:41 --> Utf8 Class Initialized
INFO - 2016-10-05 18:56:41 --> URI Class Initialized
INFO - 2016-10-05 18:56:41 --> Router Class Initialized
INFO - 2016-10-05 18:56:41 --> Output Class Initialized
INFO - 2016-10-05 18:56:41 --> Security Class Initialized
DEBUG - 2016-10-05 18:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 18:56:41 --> Input Class Initialized
INFO - 2016-10-05 18:56:41 --> Language Class Initialized
INFO - 2016-10-05 18:56:41 --> Language Class Initialized
INFO - 2016-10-05 18:56:41 --> Config Class Initialized
INFO - 2016-10-05 18:56:41 --> Loader Class Initialized
INFO - 2016-10-05 18:56:41 --> Helper loaded: url_helper
INFO - 2016-10-05 18:56:41 --> Database Driver Class Initialized
INFO - 2016-10-05 18:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 18:56:41 --> Controller Class Initialized
DEBUG - 2016-10-05 18:56:41 --> Index MX_Controller Initialized
INFO - 2016-10-05 18:56:41 --> Model Class Initialized
INFO - 2016-10-05 18:56:41 --> Model Class Initialized
ERROR - 2016-10-05 18:56:41 --> Unable to delete cache file for admin/index/test_date
INFO - 2016-10-05 18:56:41 --> Final output sent to browser
DEBUG - 2016-10-05 18:56:41 --> Total execution time: 0.5749
INFO - 2016-10-05 18:56:47 --> Config Class Initialized
INFO - 2016-10-05 18:56:47 --> Hooks Class Initialized
DEBUG - 2016-10-05 18:56:47 --> UTF-8 Support Enabled
INFO - 2016-10-05 18:56:47 --> Utf8 Class Initialized
INFO - 2016-10-05 18:56:47 --> URI Class Initialized
INFO - 2016-10-05 18:56:47 --> Router Class Initialized
INFO - 2016-10-05 18:56:47 --> Output Class Initialized
INFO - 2016-10-05 18:56:47 --> Security Class Initialized
DEBUG - 2016-10-05 18:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 18:56:47 --> Input Class Initialized
INFO - 2016-10-05 18:56:47 --> Language Class Initialized
INFO - 2016-10-05 18:56:47 --> Language Class Initialized
INFO - 2016-10-05 18:56:47 --> Config Class Initialized
INFO - 2016-10-05 18:56:47 --> Loader Class Initialized
INFO - 2016-10-05 18:56:47 --> Helper loaded: url_helper
INFO - 2016-10-05 18:56:47 --> Database Driver Class Initialized
INFO - 2016-10-05 18:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 18:56:48 --> Controller Class Initialized
DEBUG - 2016-10-05 18:56:48 --> Index MX_Controller Initialized
INFO - 2016-10-05 18:56:48 --> Model Class Initialized
INFO - 2016-10-05 18:56:48 --> Model Class Initialized
ERROR - 2016-10-05 18:56:48 --> Unable to delete cache file for admin/index/test_date
INFO - 2016-10-05 18:56:48 --> Final output sent to browser
DEBUG - 2016-10-05 18:56:48 --> Total execution time: 0.5813
INFO - 2016-10-05 18:56:56 --> Config Class Initialized
INFO - 2016-10-05 18:56:56 --> Hooks Class Initialized
DEBUG - 2016-10-05 18:56:56 --> UTF-8 Support Enabled
INFO - 2016-10-05 18:56:56 --> Utf8 Class Initialized
INFO - 2016-10-05 18:56:56 --> URI Class Initialized
INFO - 2016-10-05 18:56:56 --> Router Class Initialized
INFO - 2016-10-05 18:56:56 --> Output Class Initialized
INFO - 2016-10-05 18:56:56 --> Security Class Initialized
DEBUG - 2016-10-05 18:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 18:56:56 --> Input Class Initialized
INFO - 2016-10-05 18:56:56 --> Language Class Initialized
INFO - 2016-10-05 18:56:56 --> Language Class Initialized
INFO - 2016-10-05 18:56:56 --> Config Class Initialized
INFO - 2016-10-05 18:56:56 --> Loader Class Initialized
INFO - 2016-10-05 18:56:56 --> Helper loaded: url_helper
INFO - 2016-10-05 18:56:56 --> Database Driver Class Initialized
INFO - 2016-10-05 18:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 18:56:56 --> Controller Class Initialized
DEBUG - 2016-10-05 18:56:56 --> Index MX_Controller Initialized
INFO - 2016-10-05 18:56:56 --> Model Class Initialized
INFO - 2016-10-05 18:56:56 --> Model Class Initialized
ERROR - 2016-10-05 18:56:56 --> Unable to delete cache file for admin/index/test_date
INFO - 2016-10-05 18:56:56 --> Final output sent to browser
DEBUG - 2016-10-05 18:56:56 --> Total execution time: 0.5864
INFO - 2016-10-05 18:57:12 --> Config Class Initialized
INFO - 2016-10-05 18:57:12 --> Hooks Class Initialized
DEBUG - 2016-10-05 18:57:12 --> UTF-8 Support Enabled
INFO - 2016-10-05 18:57:12 --> Utf8 Class Initialized
INFO - 2016-10-05 18:57:12 --> URI Class Initialized
INFO - 2016-10-05 18:57:12 --> Router Class Initialized
INFO - 2016-10-05 18:57:12 --> Output Class Initialized
INFO - 2016-10-05 18:57:12 --> Security Class Initialized
DEBUG - 2016-10-05 18:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 18:57:12 --> Input Class Initialized
INFO - 2016-10-05 18:57:12 --> Language Class Initialized
INFO - 2016-10-05 18:57:12 --> Language Class Initialized
INFO - 2016-10-05 18:57:12 --> Config Class Initialized
INFO - 2016-10-05 18:57:12 --> Loader Class Initialized
INFO - 2016-10-05 18:57:13 --> Helper loaded: url_helper
INFO - 2016-10-05 18:57:13 --> Database Driver Class Initialized
INFO - 2016-10-05 18:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 18:57:13 --> Controller Class Initialized
DEBUG - 2016-10-05 18:57:13 --> Index MX_Controller Initialized
INFO - 2016-10-05 18:57:13 --> Model Class Initialized
INFO - 2016-10-05 18:57:13 --> Model Class Initialized
ERROR - 2016-10-05 18:57:13 --> Unable to delete cache file for admin/index/test_date
INFO - 2016-10-05 18:57:13 --> Final output sent to browser
DEBUG - 2016-10-05 18:57:13 --> Total execution time: 0.5803
INFO - 2016-10-05 18:57:17 --> Config Class Initialized
INFO - 2016-10-05 18:57:17 --> Hooks Class Initialized
DEBUG - 2016-10-05 18:57:17 --> UTF-8 Support Enabled
INFO - 2016-10-05 18:57:17 --> Utf8 Class Initialized
INFO - 2016-10-05 18:57:17 --> URI Class Initialized
INFO - 2016-10-05 18:57:17 --> Router Class Initialized
INFO - 2016-10-05 18:57:17 --> Output Class Initialized
INFO - 2016-10-05 18:57:17 --> Security Class Initialized
DEBUG - 2016-10-05 18:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 18:57:17 --> Input Class Initialized
INFO - 2016-10-05 18:57:17 --> Language Class Initialized
INFO - 2016-10-05 18:57:17 --> Language Class Initialized
INFO - 2016-10-05 18:57:17 --> Config Class Initialized
INFO - 2016-10-05 18:57:17 --> Loader Class Initialized
INFO - 2016-10-05 18:57:17 --> Helper loaded: url_helper
INFO - 2016-10-05 18:57:17 --> Database Driver Class Initialized
INFO - 2016-10-05 18:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 18:57:18 --> Controller Class Initialized
DEBUG - 2016-10-05 18:57:18 --> Index MX_Controller Initialized
INFO - 2016-10-05 18:57:18 --> Model Class Initialized
INFO - 2016-10-05 18:57:18 --> Model Class Initialized
ERROR - 2016-10-05 18:57:18 --> Unable to delete cache file for admin/index/test_date
INFO - 2016-10-05 18:57:18 --> Final output sent to browser
DEBUG - 2016-10-05 18:57:18 --> Total execution time: 0.6429
INFO - 2016-10-05 18:57:23 --> Config Class Initialized
INFO - 2016-10-05 18:57:23 --> Hooks Class Initialized
DEBUG - 2016-10-05 18:57:23 --> UTF-8 Support Enabled
INFO - 2016-10-05 18:57:23 --> Utf8 Class Initialized
INFO - 2016-10-05 18:57:23 --> URI Class Initialized
INFO - 2016-10-05 18:57:23 --> Router Class Initialized
INFO - 2016-10-05 18:57:23 --> Output Class Initialized
INFO - 2016-10-05 18:57:23 --> Security Class Initialized
DEBUG - 2016-10-05 18:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 18:57:23 --> Input Class Initialized
INFO - 2016-10-05 18:57:23 --> Language Class Initialized
INFO - 2016-10-05 18:57:23 --> Language Class Initialized
INFO - 2016-10-05 18:57:23 --> Config Class Initialized
INFO - 2016-10-05 18:57:24 --> Loader Class Initialized
INFO - 2016-10-05 18:57:24 --> Helper loaded: url_helper
INFO - 2016-10-05 18:57:24 --> Database Driver Class Initialized
INFO - 2016-10-05 18:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 18:57:24 --> Controller Class Initialized
DEBUG - 2016-10-05 18:57:24 --> Index MX_Controller Initialized
INFO - 2016-10-05 18:57:24 --> Model Class Initialized
INFO - 2016-10-05 18:57:24 --> Model Class Initialized
ERROR - 2016-10-05 18:57:24 --> Unable to delete cache file for admin/index/test_date
INFO - 2016-10-05 18:57:24 --> Final output sent to browser
DEBUG - 2016-10-05 18:57:24 --> Total execution time: 0.6080
INFO - 2016-10-05 18:57:47 --> Config Class Initialized
INFO - 2016-10-05 18:57:47 --> Hooks Class Initialized
DEBUG - 2016-10-05 18:57:47 --> UTF-8 Support Enabled
INFO - 2016-10-05 18:57:47 --> Utf8 Class Initialized
INFO - 2016-10-05 18:57:47 --> URI Class Initialized
INFO - 2016-10-05 18:57:47 --> Router Class Initialized
INFO - 2016-10-05 18:57:47 --> Output Class Initialized
INFO - 2016-10-05 18:57:47 --> Security Class Initialized
DEBUG - 2016-10-05 18:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 18:57:47 --> Input Class Initialized
INFO - 2016-10-05 18:57:48 --> Language Class Initialized
INFO - 2016-10-05 18:57:48 --> Language Class Initialized
INFO - 2016-10-05 18:57:48 --> Config Class Initialized
INFO - 2016-10-05 18:57:48 --> Loader Class Initialized
INFO - 2016-10-05 18:57:48 --> Helper loaded: url_helper
INFO - 2016-10-05 18:57:48 --> Database Driver Class Initialized
INFO - 2016-10-05 18:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 18:57:48 --> Controller Class Initialized
DEBUG - 2016-10-05 18:57:48 --> Index MX_Controller Initialized
INFO - 2016-10-05 18:57:48 --> Model Class Initialized
INFO - 2016-10-05 18:57:48 --> Model Class Initialized
ERROR - 2016-10-05 18:57:48 --> Unable to delete cache file for admin/index/test_date
INFO - 2016-10-05 18:57:48 --> Final output sent to browser
DEBUG - 2016-10-05 18:57:48 --> Total execution time: 0.6121
INFO - 2016-10-05 18:58:10 --> Config Class Initialized
INFO - 2016-10-05 18:58:10 --> Hooks Class Initialized
DEBUG - 2016-10-05 18:58:10 --> UTF-8 Support Enabled
INFO - 2016-10-05 18:58:10 --> Utf8 Class Initialized
INFO - 2016-10-05 18:58:10 --> URI Class Initialized
INFO - 2016-10-05 18:58:10 --> Router Class Initialized
INFO - 2016-10-05 18:58:10 --> Output Class Initialized
INFO - 2016-10-05 18:58:10 --> Security Class Initialized
DEBUG - 2016-10-05 18:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 18:58:10 --> Input Class Initialized
INFO - 2016-10-05 18:58:10 --> Language Class Initialized
INFO - 2016-10-05 18:58:10 --> Language Class Initialized
INFO - 2016-10-05 18:58:10 --> Config Class Initialized
INFO - 2016-10-05 18:58:10 --> Loader Class Initialized
INFO - 2016-10-05 18:58:10 --> Helper loaded: url_helper
INFO - 2016-10-05 18:58:11 --> Database Driver Class Initialized
INFO - 2016-10-05 18:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 18:58:11 --> Controller Class Initialized
DEBUG - 2016-10-05 18:58:11 --> Index MX_Controller Initialized
INFO - 2016-10-05 18:58:11 --> Model Class Initialized
INFO - 2016-10-05 18:58:11 --> Model Class Initialized
ERROR - 2016-10-05 18:58:11 --> Unable to delete cache file for admin/index/test_date
INFO - 2016-10-05 18:58:11 --> Final output sent to browser
DEBUG - 2016-10-05 18:58:11 --> Total execution time: 0.5936
INFO - 2016-10-05 18:58:25 --> Config Class Initialized
INFO - 2016-10-05 18:58:25 --> Hooks Class Initialized
DEBUG - 2016-10-05 18:58:25 --> UTF-8 Support Enabled
INFO - 2016-10-05 18:58:25 --> Utf8 Class Initialized
INFO - 2016-10-05 18:58:25 --> URI Class Initialized
INFO - 2016-10-05 18:58:25 --> Router Class Initialized
INFO - 2016-10-05 18:58:25 --> Output Class Initialized
INFO - 2016-10-05 18:58:25 --> Security Class Initialized
DEBUG - 2016-10-05 18:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 18:58:25 --> Input Class Initialized
INFO - 2016-10-05 18:58:25 --> Language Class Initialized
INFO - 2016-10-05 18:58:25 --> Language Class Initialized
INFO - 2016-10-05 18:58:25 --> Config Class Initialized
INFO - 2016-10-05 18:58:25 --> Loader Class Initialized
INFO - 2016-10-05 18:58:25 --> Helper loaded: url_helper
INFO - 2016-10-05 18:58:25 --> Database Driver Class Initialized
INFO - 2016-10-05 18:58:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 18:58:26 --> Controller Class Initialized
DEBUG - 2016-10-05 18:58:26 --> Index MX_Controller Initialized
INFO - 2016-10-05 18:58:26 --> Model Class Initialized
INFO - 2016-10-05 18:58:26 --> Model Class Initialized
ERROR - 2016-10-05 18:58:26 --> Unable to delete cache file for admin/index/test_date
INFO - 2016-10-05 18:58:26 --> Final output sent to browser
DEBUG - 2016-10-05 18:58:26 --> Total execution time: 0.5922
INFO - 2016-10-05 18:58:33 --> Config Class Initialized
INFO - 2016-10-05 18:58:33 --> Hooks Class Initialized
DEBUG - 2016-10-05 18:58:33 --> UTF-8 Support Enabled
INFO - 2016-10-05 18:58:33 --> Utf8 Class Initialized
INFO - 2016-10-05 18:58:34 --> URI Class Initialized
INFO - 2016-10-05 18:58:34 --> Router Class Initialized
INFO - 2016-10-05 18:58:34 --> Output Class Initialized
INFO - 2016-10-05 18:58:34 --> Security Class Initialized
DEBUG - 2016-10-05 18:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 18:58:34 --> Input Class Initialized
INFO - 2016-10-05 18:58:34 --> Language Class Initialized
INFO - 2016-10-05 18:58:34 --> Language Class Initialized
INFO - 2016-10-05 18:58:34 --> Config Class Initialized
INFO - 2016-10-05 18:58:34 --> Loader Class Initialized
INFO - 2016-10-05 18:58:34 --> Helper loaded: url_helper
INFO - 2016-10-05 18:58:34 --> Database Driver Class Initialized
INFO - 2016-10-05 18:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 18:58:34 --> Controller Class Initialized
DEBUG - 2016-10-05 18:58:34 --> Index MX_Controller Initialized
INFO - 2016-10-05 18:58:34 --> Model Class Initialized
INFO - 2016-10-05 18:58:34 --> Model Class Initialized
ERROR - 2016-10-05 18:58:34 --> Unable to delete cache file for admin/index/test_date
INFO - 2016-10-05 18:58:34 --> Final output sent to browser
DEBUG - 2016-10-05 18:58:34 --> Total execution time: 0.5925
INFO - 2016-10-05 18:59:22 --> Config Class Initialized
INFO - 2016-10-05 18:59:22 --> Hooks Class Initialized
DEBUG - 2016-10-05 18:59:22 --> UTF-8 Support Enabled
INFO - 2016-10-05 18:59:22 --> Utf8 Class Initialized
INFO - 2016-10-05 18:59:22 --> URI Class Initialized
INFO - 2016-10-05 18:59:22 --> Router Class Initialized
INFO - 2016-10-05 18:59:22 --> Output Class Initialized
INFO - 2016-10-05 18:59:22 --> Security Class Initialized
DEBUG - 2016-10-05 18:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 18:59:22 --> Input Class Initialized
INFO - 2016-10-05 18:59:22 --> Language Class Initialized
INFO - 2016-10-05 18:59:22 --> Language Class Initialized
INFO - 2016-10-05 18:59:22 --> Config Class Initialized
INFO - 2016-10-05 18:59:22 --> Loader Class Initialized
INFO - 2016-10-05 18:59:23 --> Helper loaded: url_helper
INFO - 2016-10-05 18:59:23 --> Database Driver Class Initialized
INFO - 2016-10-05 18:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 18:59:23 --> Controller Class Initialized
DEBUG - 2016-10-05 18:59:23 --> Index MX_Controller Initialized
INFO - 2016-10-05 18:59:23 --> Model Class Initialized
INFO - 2016-10-05 18:59:23 --> Model Class Initialized
ERROR - 2016-10-05 18:59:23 --> Unable to delete cache file for admin/index/test_date
INFO - 2016-10-05 18:59:23 --> Final output sent to browser
DEBUG - 2016-10-05 18:59:23 --> Total execution time: 0.6291
INFO - 2016-10-05 18:59:32 --> Config Class Initialized
INFO - 2016-10-05 18:59:32 --> Hooks Class Initialized
DEBUG - 2016-10-05 18:59:32 --> UTF-8 Support Enabled
INFO - 2016-10-05 18:59:32 --> Utf8 Class Initialized
INFO - 2016-10-05 18:59:32 --> URI Class Initialized
INFO - 2016-10-05 18:59:32 --> Router Class Initialized
INFO - 2016-10-05 18:59:32 --> Output Class Initialized
INFO - 2016-10-05 18:59:32 --> Security Class Initialized
DEBUG - 2016-10-05 18:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 18:59:32 --> Input Class Initialized
INFO - 2016-10-05 18:59:32 --> Language Class Initialized
INFO - 2016-10-05 18:59:32 --> Language Class Initialized
INFO - 2016-10-05 18:59:32 --> Config Class Initialized
INFO - 2016-10-05 18:59:32 --> Loader Class Initialized
INFO - 2016-10-05 18:59:32 --> Helper loaded: url_helper
INFO - 2016-10-05 18:59:32 --> Database Driver Class Initialized
INFO - 2016-10-05 18:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 18:59:32 --> Controller Class Initialized
DEBUG - 2016-10-05 18:59:32 --> Index MX_Controller Initialized
INFO - 2016-10-05 18:59:32 --> Model Class Initialized
INFO - 2016-10-05 18:59:32 --> Model Class Initialized
ERROR - 2016-10-05 18:59:32 --> Unable to delete cache file for admin/index/test_date
INFO - 2016-10-05 18:59:32 --> Final output sent to browser
DEBUG - 2016-10-05 18:59:32 --> Total execution time: 0.5914
INFO - 2016-10-05 19:03:45 --> Config Class Initialized
INFO - 2016-10-05 19:03:45 --> Hooks Class Initialized
DEBUG - 2016-10-05 19:03:45 --> UTF-8 Support Enabled
INFO - 2016-10-05 19:03:45 --> Utf8 Class Initialized
INFO - 2016-10-05 19:03:45 --> URI Class Initialized
INFO - 2016-10-05 19:03:45 --> Router Class Initialized
INFO - 2016-10-05 19:03:45 --> Output Class Initialized
INFO - 2016-10-05 19:03:45 --> Security Class Initialized
DEBUG - 2016-10-05 19:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 19:03:45 --> Input Class Initialized
INFO - 2016-10-05 19:03:45 --> Language Class Initialized
INFO - 2016-10-05 19:03:45 --> Language Class Initialized
INFO - 2016-10-05 19:03:45 --> Config Class Initialized
INFO - 2016-10-05 19:03:45 --> Loader Class Initialized
INFO - 2016-10-05 19:03:45 --> Helper loaded: url_helper
INFO - 2016-10-05 19:03:45 --> Database Driver Class Initialized
INFO - 2016-10-05 19:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 19:03:45 --> Controller Class Initialized
DEBUG - 2016-10-05 19:03:45 --> Index MX_Controller Initialized
INFO - 2016-10-05 19:03:45 --> Model Class Initialized
INFO - 2016-10-05 19:03:45 --> Model Class Initialized
ERROR - 2016-10-05 19:03:45 --> Unable to delete cache file for admin/index/getDetailAngsuran
INFO - 2016-10-05 19:03:45 --> Database Driver Class Initialized
INFO - 2016-10-05 19:03:45 --> Final output sent to browser
DEBUG - 2016-10-05 19:03:45 --> Total execution time: 0.7258
INFO - 2016-10-05 19:05:33 --> Config Class Initialized
INFO - 2016-10-05 19:05:33 --> Hooks Class Initialized
DEBUG - 2016-10-05 19:05:33 --> UTF-8 Support Enabled
INFO - 2016-10-05 19:05:33 --> Utf8 Class Initialized
INFO - 2016-10-05 19:05:33 --> URI Class Initialized
INFO - 2016-10-05 19:05:33 --> Router Class Initialized
INFO - 2016-10-05 19:05:33 --> Output Class Initialized
INFO - 2016-10-05 19:05:33 --> Security Class Initialized
DEBUG - 2016-10-05 19:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 19:05:33 --> Input Class Initialized
INFO - 2016-10-05 19:05:33 --> Language Class Initialized
INFO - 2016-10-05 19:05:33 --> Language Class Initialized
INFO - 2016-10-05 19:05:33 --> Config Class Initialized
INFO - 2016-10-05 19:05:33 --> Loader Class Initialized
INFO - 2016-10-05 19:05:33 --> Helper loaded: url_helper
INFO - 2016-10-05 19:05:33 --> Database Driver Class Initialized
INFO - 2016-10-05 19:05:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 19:05:34 --> Controller Class Initialized
DEBUG - 2016-10-05 19:05:34 --> Index MX_Controller Initialized
INFO - 2016-10-05 19:05:34 --> Model Class Initialized
INFO - 2016-10-05 19:05:34 --> Model Class Initialized
ERROR - 2016-10-05 19:05:34 --> Unable to delete cache file for admin/index/getDetailAngsuran
INFO - 2016-10-05 19:05:34 --> Database Driver Class Initialized
INFO - 2016-10-05 19:05:34 --> Final output sent to browser
DEBUG - 2016-10-05 19:05:34 --> Total execution time: 0.6995
INFO - 2016-10-05 19:06:31 --> Config Class Initialized
INFO - 2016-10-05 19:06:31 --> Hooks Class Initialized
DEBUG - 2016-10-05 19:06:31 --> UTF-8 Support Enabled
INFO - 2016-10-05 19:06:31 --> Utf8 Class Initialized
INFO - 2016-10-05 19:06:31 --> URI Class Initialized
INFO - 2016-10-05 19:06:31 --> Router Class Initialized
INFO - 2016-10-05 19:06:31 --> Output Class Initialized
INFO - 2016-10-05 19:06:31 --> Security Class Initialized
DEBUG - 2016-10-05 19:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 19:06:31 --> Input Class Initialized
INFO - 2016-10-05 19:06:31 --> Language Class Initialized
INFO - 2016-10-05 19:06:31 --> Language Class Initialized
INFO - 2016-10-05 19:06:31 --> Config Class Initialized
INFO - 2016-10-05 19:06:31 --> Loader Class Initialized
INFO - 2016-10-05 19:06:32 --> Helper loaded: url_helper
INFO - 2016-10-05 19:06:32 --> Database Driver Class Initialized
INFO - 2016-10-05 19:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 19:06:32 --> Controller Class Initialized
DEBUG - 2016-10-05 19:06:32 --> Index MX_Controller Initialized
INFO - 2016-10-05 19:06:32 --> Model Class Initialized
INFO - 2016-10-05 19:06:32 --> Model Class Initialized
ERROR - 2016-10-05 19:06:32 --> Unable to delete cache file for admin/index/getDetailAngsuran
INFO - 2016-10-05 19:06:32 --> Database Driver Class Initialized
INFO - 2016-10-05 19:06:32 --> Final output sent to browser
DEBUG - 2016-10-05 19:06:32 --> Total execution time: 0.6487
