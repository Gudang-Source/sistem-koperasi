<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-09-24 00:58:07 --> Config Class Initialized
INFO - 2016-09-24 00:58:07 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:58:07 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:58:07 --> Utf8 Class Initialized
INFO - 2016-09-24 00:58:07 --> URI Class Initialized
DEBUG - 2016-09-24 00:58:07 --> No URI present. Default controller set.
INFO - 2016-09-24 00:58:07 --> Router Class Initialized
INFO - 2016-09-24 00:58:07 --> Output Class Initialized
INFO - 2016-09-24 00:58:07 --> Security Class Initialized
DEBUG - 2016-09-24 00:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:58:07 --> Input Class Initialized
INFO - 2016-09-24 00:58:07 --> Language Class Initialized
INFO - 2016-09-24 00:58:07 --> Language Class Initialized
INFO - 2016-09-24 00:58:07 --> Config Class Initialized
INFO - 2016-09-24 00:58:07 --> Loader Class Initialized
INFO - 2016-09-24 00:58:07 --> Helper loaded: url_helper
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:58:07 --> Controller Class Initialized
DEBUG - 2016-09-24 00:58:07 --> Index MX_Controller Initialized
INFO - 2016-09-24 00:58:07 --> Model Class Initialized
INFO - 2016-09-24 00:58:07 --> Model Class Initialized
ERROR - 2016-09-24 00:58:07 --> Unable to delete cache file for 
DEBUG - 2016-09-24 00:58:07 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-24 00:58:07 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-24 00:58:07 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-24 00:58:07 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-24 00:58:07 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-24 00:58:07 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
DEBUG - 2016-09-24 00:58:07 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-24 00:58:07 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-24 00:58:07 --> Final output sent to browser
DEBUG - 2016-09-24 00:58:07 --> Total execution time: 0.1736
INFO - 2016-09-24 00:58:07 --> Config Class Initialized
INFO - 2016-09-24 00:58:07 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:58:07 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:58:07 --> Utf8 Class Initialized
INFO - 2016-09-24 00:58:07 --> URI Class Initialized
INFO - 2016-09-24 00:58:07 --> Router Class Initialized
INFO - 2016-09-24 00:58:07 --> Output Class Initialized
INFO - 2016-09-24 00:58:07 --> Security Class Initialized
DEBUG - 2016-09-24 00:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:58:07 --> Input Class Initialized
INFO - 2016-09-24 00:58:07 --> Language Class Initialized
INFO - 2016-09-24 00:58:07 --> Language Class Initialized
INFO - 2016-09-24 00:58:07 --> Config Class Initialized
INFO - 2016-09-24 00:58:07 --> Loader Class Initialized
INFO - 2016-09-24 00:58:07 --> Helper loaded: url_helper
INFO - 2016-09-24 00:58:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:58:07 --> Controller Class Initialized
DEBUG - 2016-09-24 00:58:07 --> login MX_Controller Initialized
INFO - 2016-09-24 00:58:07 --> Model Class Initialized
INFO - 2016-09-24 00:58:07 --> Model Class Initialized
DEBUG - 2016-09-24 00:58:07 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-24 00:58:07 --> Final output sent to browser
DEBUG - 2016-09-24 00:58:07 --> Total execution time: 0.0279
INFO - 2016-09-24 00:58:15 --> Config Class Initialized
INFO - 2016-09-24 00:58:15 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:58:15 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:58:15 --> Utf8 Class Initialized
INFO - 2016-09-24 00:58:15 --> URI Class Initialized
INFO - 2016-09-24 00:58:15 --> Router Class Initialized
INFO - 2016-09-24 00:58:15 --> Output Class Initialized
INFO - 2016-09-24 00:58:15 --> Security Class Initialized
DEBUG - 2016-09-24 00:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:58:15 --> Input Class Initialized
INFO - 2016-09-24 00:58:15 --> Language Class Initialized
ERROR - 2016-09-24 00:58:15 --> 404 Page Not Found: /index
INFO - 2016-09-24 00:59:23 --> Config Class Initialized
INFO - 2016-09-24 00:59:23 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:59:23 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:59:23 --> Utf8 Class Initialized
INFO - 2016-09-24 00:59:23 --> URI Class Initialized
INFO - 2016-09-24 00:59:23 --> Router Class Initialized
INFO - 2016-09-24 00:59:23 --> Output Class Initialized
INFO - 2016-09-24 00:59:23 --> Security Class Initialized
DEBUG - 2016-09-24 00:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:59:23 --> Input Class Initialized
INFO - 2016-09-24 00:59:23 --> Language Class Initialized
INFO - 2016-09-24 00:59:23 --> Language Class Initialized
INFO - 2016-09-24 00:59:23 --> Config Class Initialized
INFO - 2016-09-24 00:59:23 --> Loader Class Initialized
INFO - 2016-09-24 00:59:23 --> Helper loaded: url_helper
INFO - 2016-09-24 00:59:23 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:59:23 --> Controller Class Initialized
DEBUG - 2016-09-24 00:59:23 --> login MX_Controller Initialized
INFO - 2016-09-24 00:59:23 --> Model Class Initialized
INFO - 2016-09-24 00:59:23 --> Model Class Initialized
INFO - 2016-09-24 00:59:23 --> Final output sent to browser
DEBUG - 2016-09-24 00:59:23 --> Total execution time: 0.0280
INFO - 2016-09-24 00:59:24 --> Config Class Initialized
INFO - 2016-09-24 00:59:24 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:59:24 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:59:24 --> Utf8 Class Initialized
INFO - 2016-09-24 00:59:24 --> URI Class Initialized
INFO - 2016-09-24 00:59:24 --> Router Class Initialized
INFO - 2016-09-24 00:59:24 --> Output Class Initialized
INFO - 2016-09-24 00:59:24 --> Security Class Initialized
DEBUG - 2016-09-24 00:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:59:24 --> Input Class Initialized
INFO - 2016-09-24 00:59:24 --> Language Class Initialized
INFO - 2016-09-24 00:59:24 --> Language Class Initialized
INFO - 2016-09-24 00:59:24 --> Config Class Initialized
INFO - 2016-09-24 00:59:24 --> Loader Class Initialized
INFO - 2016-09-24 00:59:24 --> Helper loaded: url_helper
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:59:24 --> Controller Class Initialized
DEBUG - 2016-09-24 00:59:24 --> Index MX_Controller Initialized
INFO - 2016-09-24 00:59:24 --> Model Class Initialized
INFO - 2016-09-24 00:59:24 --> Model Class Initialized
ERROR - 2016-09-24 00:59:24 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-24 00:59:24 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-24 00:59:24 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-24 00:59:24 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-24 00:59:24 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-24 00:59:24 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-24 00:59:24 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:24 --> Database Driver Class Initialized
DEBUG - 2016-09-24 00:59:24 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-24 00:59:24 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-24 00:59:24 --> Final output sent to browser
DEBUG - 2016-09-24 00:59:24 --> Total execution time: 0.1067
INFO - 2016-09-24 00:59:27 --> Config Class Initialized
INFO - 2016-09-24 00:59:27 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:59:27 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:59:27 --> Utf8 Class Initialized
INFO - 2016-09-24 00:59:27 --> URI Class Initialized
INFO - 2016-09-24 00:59:27 --> Router Class Initialized
INFO - 2016-09-24 00:59:27 --> Output Class Initialized
INFO - 2016-09-24 00:59:27 --> Security Class Initialized
DEBUG - 2016-09-24 00:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:59:27 --> Input Class Initialized
INFO - 2016-09-24 00:59:27 --> Language Class Initialized
ERROR - 2016-09-24 00:59:27 --> 404 Page Not Found: /index
INFO - 2016-09-24 00:59:30 --> Config Class Initialized
INFO - 2016-09-24 00:59:30 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:59:30 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:59:30 --> Utf8 Class Initialized
INFO - 2016-09-24 00:59:30 --> URI Class Initialized
INFO - 2016-09-24 00:59:30 --> Router Class Initialized
INFO - 2016-09-24 00:59:30 --> Output Class Initialized
INFO - 2016-09-24 00:59:30 --> Security Class Initialized
DEBUG - 2016-09-24 00:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:59:30 --> Input Class Initialized
INFO - 2016-09-24 00:59:30 --> Language Class Initialized
ERROR - 2016-09-24 00:59:30 --> 404 Page Not Found: /index
INFO - 2016-09-24 00:59:43 --> Config Class Initialized
INFO - 2016-09-24 00:59:43 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:59:43 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:59:43 --> Utf8 Class Initialized
INFO - 2016-09-24 00:59:43 --> URI Class Initialized
INFO - 2016-09-24 00:59:43 --> Router Class Initialized
INFO - 2016-09-24 00:59:43 --> Output Class Initialized
INFO - 2016-09-24 00:59:43 --> Security Class Initialized
DEBUG - 2016-09-24 00:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:59:43 --> Input Class Initialized
INFO - 2016-09-24 00:59:43 --> Language Class Initialized
INFO - 2016-09-24 00:59:43 --> Language Class Initialized
INFO - 2016-09-24 00:59:43 --> Config Class Initialized
INFO - 2016-09-24 00:59:43 --> Loader Class Initialized
INFO - 2016-09-24 00:59:43 --> Helper loaded: url_helper
INFO - 2016-09-24 00:59:43 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:59:43 --> Controller Class Initialized
DEBUG - 2016-09-24 00:59:43 --> Index MX_Controller Initialized
INFO - 2016-09-24 00:59:43 --> Model Class Initialized
INFO - 2016-09-24 00:59:43 --> Model Class Initialized
ERROR - 2016-09-24 00:59:43 --> Unable to delete cache file for admin/index/upload_foto
DEBUG - 2016-09-24 00:59:43 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-24 00:59:43 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-24 00:59:43 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-24 00:59:43 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/upload_foto.php
DEBUG - 2016-09-24 00:59:43 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-24 00:59:43 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-24 00:59:43 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:43 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:43 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:43 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:43 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:43 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:43 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:43 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:43 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:43 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:43 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:43 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:43 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:43 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:43 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:43 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:43 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:43 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:43 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:43 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:43 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
DEBUG - 2016-09-24 00:59:44 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-24 00:59:44 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-24 00:59:44 --> Final output sent to browser
DEBUG - 2016-09-24 00:59:44 --> Total execution time: 0.0999
INFO - 2016-09-24 00:59:44 --> Config Class Initialized
INFO - 2016-09-24 00:59:44 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:59:44 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:59:44 --> Utf8 Class Initialized
INFO - 2016-09-24 00:59:44 --> URI Class Initialized
INFO - 2016-09-24 00:59:44 --> Router Class Initialized
INFO - 2016-09-24 00:59:44 --> Output Class Initialized
INFO - 2016-09-24 00:59:44 --> Security Class Initialized
DEBUG - 2016-09-24 00:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:59:44 --> Input Class Initialized
INFO - 2016-09-24 00:59:44 --> Language Class Initialized
INFO - 2016-09-24 00:59:44 --> Language Class Initialized
INFO - 2016-09-24 00:59:44 --> Config Class Initialized
INFO - 2016-09-24 00:59:44 --> Loader Class Initialized
INFO - 2016-09-24 00:59:44 --> Helper loaded: url_helper
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:59:44 --> Controller Class Initialized
DEBUG - 2016-09-24 00:59:44 --> Index MX_Controller Initialized
INFO - 2016-09-24 00:59:44 --> Model Class Initialized
INFO - 2016-09-24 00:59:44 --> Model Class Initialized
ERROR - 2016-09-24 00:59:44 --> Unable to delete cache file for admin/index/upload_foto
DEBUG - 2016-09-24 00:59:44 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-24 00:59:44 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-24 00:59:44 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-24 00:59:44 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/upload_foto.php
DEBUG - 2016-09-24 00:59:44 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-24 00:59:44 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:59:44 --> Database Driver Class Initialized
DEBUG - 2016-09-24 00:59:44 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-24 00:59:44 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-24 00:59:44 --> Final output sent to browser
DEBUG - 2016-09-24 00:59:44 --> Total execution time: 0.0842
INFO - 2016-09-24 00:59:45 --> Config Class Initialized
INFO - 2016-09-24 00:59:45 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:59:45 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:59:45 --> Utf8 Class Initialized
INFO - 2016-09-24 00:59:45 --> URI Class Initialized
INFO - 2016-09-24 00:59:45 --> Router Class Initialized
INFO - 2016-09-24 00:59:45 --> Output Class Initialized
INFO - 2016-09-24 00:59:45 --> Security Class Initialized
DEBUG - 2016-09-24 00:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:59:45 --> Input Class Initialized
INFO - 2016-09-24 00:59:45 --> Language Class Initialized
ERROR - 2016-09-24 00:59:45 --> 404 Page Not Found: /index
INFO - 2016-09-24 01:05:33 --> Config Class Initialized
INFO - 2016-09-24 01:05:33 --> Hooks Class Initialized
DEBUG - 2016-09-24 01:05:33 --> UTF-8 Support Enabled
INFO - 2016-09-24 01:05:33 --> Utf8 Class Initialized
INFO - 2016-09-24 01:05:33 --> URI Class Initialized
INFO - 2016-09-24 01:05:33 --> Router Class Initialized
INFO - 2016-09-24 01:05:33 --> Output Class Initialized
INFO - 2016-09-24 01:05:33 --> Security Class Initialized
DEBUG - 2016-09-24 01:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 01:05:33 --> Input Class Initialized
INFO - 2016-09-24 01:05:33 --> Language Class Initialized
INFO - 2016-09-24 01:05:33 --> Language Class Initialized
INFO - 2016-09-24 01:05:33 --> Config Class Initialized
INFO - 2016-09-24 01:05:33 --> Loader Class Initialized
INFO - 2016-09-24 01:05:33 --> Helper loaded: url_helper
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 01:05:33 --> Controller Class Initialized
DEBUG - 2016-09-24 01:05:33 --> Index MX_Controller Initialized
INFO - 2016-09-24 01:05:33 --> Model Class Initialized
INFO - 2016-09-24 01:05:33 --> Model Class Initialized
ERROR - 2016-09-24 01:05:33 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-24 01:05:33 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-24 01:05:33 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-24 01:05:33 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-24 01:05:33 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-24 01:05:33 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-24 01:05:33 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
INFO - 2016-09-24 01:05:33 --> Database Driver Class Initialized
DEBUG - 2016-09-24 01:05:33 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-24 01:05:33 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-24 01:05:33 --> Final output sent to browser
DEBUG - 2016-09-24 01:05:33 --> Total execution time: 0.1548
INFO - 2016-09-24 01:05:34 --> Config Class Initialized
INFO - 2016-09-24 01:05:34 --> Hooks Class Initialized
DEBUG - 2016-09-24 01:05:34 --> UTF-8 Support Enabled
INFO - 2016-09-24 01:05:34 --> Utf8 Class Initialized
INFO - 2016-09-24 01:05:34 --> URI Class Initialized
INFO - 2016-09-24 01:05:34 --> Router Class Initialized
INFO - 2016-09-24 01:05:34 --> Output Class Initialized
INFO - 2016-09-24 01:05:34 --> Security Class Initialized
DEBUG - 2016-09-24 01:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 01:05:34 --> Input Class Initialized
INFO - 2016-09-24 01:05:34 --> Language Class Initialized
ERROR - 2016-09-24 01:05:34 --> 404 Page Not Found: /index
INFO - 2016-09-24 01:06:03 --> Config Class Initialized
INFO - 2016-09-24 01:06:03 --> Hooks Class Initialized
DEBUG - 2016-09-24 01:06:03 --> UTF-8 Support Enabled
INFO - 2016-09-24 01:06:03 --> Utf8 Class Initialized
INFO - 2016-09-24 01:06:03 --> URI Class Initialized
INFO - 2016-09-24 01:06:03 --> Router Class Initialized
INFO - 2016-09-24 01:06:03 --> Output Class Initialized
INFO - 2016-09-24 01:06:03 --> Security Class Initialized
DEBUG - 2016-09-24 01:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 01:06:03 --> Input Class Initialized
INFO - 2016-09-24 01:06:03 --> Language Class Initialized
INFO - 2016-09-24 01:06:03 --> Language Class Initialized
INFO - 2016-09-24 01:06:03 --> Config Class Initialized
INFO - 2016-09-24 01:06:03 --> Loader Class Initialized
INFO - 2016-09-24 01:06:03 --> Helper loaded: url_helper
INFO - 2016-09-24 01:06:03 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 01:06:03 --> Controller Class Initialized
DEBUG - 2016-09-24 01:06:03 --> Index MX_Controller Initialized
INFO - 2016-09-24 01:06:03 --> Model Class Initialized
INFO - 2016-09-24 01:06:03 --> Model Class Initialized
ERROR - 2016-09-24 01:06:03 --> Unable to delete cache file for admin/index/data/user
DEBUG - 2016-09-24 01:06:03 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-24 01:06:03 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-24 01:06:03 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-24 01:06:03 --> File already loaded: /home/koperasi/public_html/application/controllers/../modules/user/controllers/Users.php
DEBUG - 2016-09-24 01:06:03 --> Users MX_Controller Initialized
DEBUG - 2016-09-24 01:06:03 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/list_user.php
DEBUG - 2016-09-24 01:06:03 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-24 01:06:03 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-24 01:06:03 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:03 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:03 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:03 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:03 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:03 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:03 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:03 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:03 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:03 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:03 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:03 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:03 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:03 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:03 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:03 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:03 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:03 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:03 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:03 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:03 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:03 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:03 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:03 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:03 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:03 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:03 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:03 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:03 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:03 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:03 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:03 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:03 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:03 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:03 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:03 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:03 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:04 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:04 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:04 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:04 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:04 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:04 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:04 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:04 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:04 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:04 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:04 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:04 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:04 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:04 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:04 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:04 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:04 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:04 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:04 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:04 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:04 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:04 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:04 --> Database Driver Class Initialized
DEBUG - 2016-09-24 01:06:04 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-24 01:06:04 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-24 01:06:04 --> Final output sent to browser
DEBUG - 2016-09-24 01:06:04 --> Total execution time: 0.1100
INFO - 2016-09-24 01:06:04 --> Config Class Initialized
INFO - 2016-09-24 01:06:04 --> Hooks Class Initialized
DEBUG - 2016-09-24 01:06:04 --> UTF-8 Support Enabled
INFO - 2016-09-24 01:06:04 --> Utf8 Class Initialized
INFO - 2016-09-24 01:06:04 --> URI Class Initialized
INFO - 2016-09-24 01:06:04 --> Router Class Initialized
INFO - 2016-09-24 01:06:04 --> Output Class Initialized
INFO - 2016-09-24 01:06:04 --> Security Class Initialized
DEBUG - 2016-09-24 01:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 01:06:04 --> Input Class Initialized
INFO - 2016-09-24 01:06:04 --> Language Class Initialized
ERROR - 2016-09-24 01:06:04 --> 404 Page Not Found: /index
INFO - 2016-09-24 01:06:12 --> Config Class Initialized
INFO - 2016-09-24 01:06:12 --> Hooks Class Initialized
DEBUG - 2016-09-24 01:06:12 --> UTF-8 Support Enabled
INFO - 2016-09-24 01:06:12 --> Utf8 Class Initialized
INFO - 2016-09-24 01:06:12 --> URI Class Initialized
INFO - 2016-09-24 01:06:12 --> Router Class Initialized
INFO - 2016-09-24 01:06:12 --> Output Class Initialized
INFO - 2016-09-24 01:06:12 --> Security Class Initialized
DEBUG - 2016-09-24 01:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 01:06:12 --> Input Class Initialized
INFO - 2016-09-24 01:06:12 --> Language Class Initialized
INFO - 2016-09-24 01:06:12 --> Language Class Initialized
INFO - 2016-09-24 01:06:12 --> Config Class Initialized
INFO - 2016-09-24 01:06:12 --> Loader Class Initialized
INFO - 2016-09-24 01:06:12 --> Helper loaded: url_helper
INFO - 2016-09-24 01:06:12 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 01:06:12 --> Controller Class Initialized
DEBUG - 2016-09-24 01:06:12 --> Index MX_Controller Initialized
INFO - 2016-09-24 01:06:12 --> Model Class Initialized
INFO - 2016-09-24 01:06:12 --> Model Class Initialized
ERROR - 2016-09-24 01:06:12 --> Unable to delete cache file for admin/index/post_get/user/0ade7c2cf97f75d009975f4d720d1fa6c19f4897
DEBUG - 2016-09-24 01:06:12 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-24 01:06:12 --> Users MX_Controller Initialized
INFO - 2016-09-24 01:06:12 --> Final output sent to browser
DEBUG - 2016-09-24 01:06:12 --> Total execution time: 0.0380
INFO - 2016-09-24 01:06:22 --> Config Class Initialized
INFO - 2016-09-24 01:06:22 --> Hooks Class Initialized
DEBUG - 2016-09-24 01:06:22 --> UTF-8 Support Enabled
INFO - 2016-09-24 01:06:22 --> Utf8 Class Initialized
INFO - 2016-09-24 01:06:22 --> URI Class Initialized
INFO - 2016-09-24 01:06:22 --> Router Class Initialized
INFO - 2016-09-24 01:06:22 --> Output Class Initialized
INFO - 2016-09-24 01:06:22 --> Security Class Initialized
DEBUG - 2016-09-24 01:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 01:06:22 --> Input Class Initialized
INFO - 2016-09-24 01:06:22 --> Language Class Initialized
INFO - 2016-09-24 01:06:22 --> Language Class Initialized
INFO - 2016-09-24 01:06:22 --> Config Class Initialized
INFO - 2016-09-24 01:06:22 --> Loader Class Initialized
INFO - 2016-09-24 01:06:22 --> Helper loaded: url_helper
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 01:06:22 --> Controller Class Initialized
DEBUG - 2016-09-24 01:06:22 --> Index MX_Controller Initialized
INFO - 2016-09-24 01:06:22 --> Model Class Initialized
INFO - 2016-09-24 01:06:22 --> Model Class Initialized
ERROR - 2016-09-24 01:06:22 --> Unable to delete cache file for admin/index/add/user
DEBUG - 2016-09-24 01:06:22 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-24 01:06:22 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-24 01:06:22 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-24 01:06:22 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/form_user.php
DEBUG - 2016-09-24 01:06:22 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-24 01:06:22 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:06:22 --> Database Driver Class Initialized
DEBUG - 2016-09-24 01:06:22 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-24 01:06:22 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-24 01:06:22 --> Final output sent to browser
DEBUG - 2016-09-24 01:06:22 --> Total execution time: 0.1031
INFO - 2016-09-24 01:06:23 --> Config Class Initialized
INFO - 2016-09-24 01:06:23 --> Hooks Class Initialized
DEBUG - 2016-09-24 01:06:23 --> UTF-8 Support Enabled
INFO - 2016-09-24 01:06:23 --> Utf8 Class Initialized
INFO - 2016-09-24 01:06:23 --> URI Class Initialized
INFO - 2016-09-24 01:06:23 --> Router Class Initialized
INFO - 2016-09-24 01:06:23 --> Output Class Initialized
INFO - 2016-09-24 01:06:23 --> Security Class Initialized
DEBUG - 2016-09-24 01:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 01:06:23 --> Input Class Initialized
INFO - 2016-09-24 01:06:23 --> Language Class Initialized
ERROR - 2016-09-24 01:06:23 --> 404 Page Not Found: /index
INFO - 2016-09-24 01:16:18 --> Config Class Initialized
INFO - 2016-09-24 01:16:18 --> Hooks Class Initialized
DEBUG - 2016-09-24 01:16:18 --> UTF-8 Support Enabled
INFO - 2016-09-24 01:16:18 --> Utf8 Class Initialized
INFO - 2016-09-24 01:16:18 --> URI Class Initialized
INFO - 2016-09-24 01:16:18 --> Router Class Initialized
INFO - 2016-09-24 01:16:18 --> Output Class Initialized
INFO - 2016-09-24 01:16:18 --> Security Class Initialized
DEBUG - 2016-09-24 01:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 01:16:18 --> Input Class Initialized
INFO - 2016-09-24 01:16:18 --> Language Class Initialized
INFO - 2016-09-24 01:16:18 --> Language Class Initialized
INFO - 2016-09-24 01:16:18 --> Config Class Initialized
INFO - 2016-09-24 01:16:18 --> Loader Class Initialized
INFO - 2016-09-24 01:16:18 --> Helper loaded: url_helper
INFO - 2016-09-24 01:16:18 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 01:16:18 --> Controller Class Initialized
DEBUG - 2016-09-24 01:16:18 --> Index MX_Controller Initialized
INFO - 2016-09-24 01:16:18 --> Model Class Initialized
INFO - 2016-09-24 01:16:18 --> Model Class Initialized
ERROR - 2016-09-24 01:16:18 --> Unable to delete cache file for admin/index/post_add/user
DEBUG - 2016-09-24 01:16:18 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-24 01:16:18 --> Users MX_Controller Initialized
INFO - 2016-09-24 01:16:18 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:18 --> Final output sent to browser
DEBUG - 2016-09-24 01:16:18 --> Total execution time: 0.0421
INFO - 2016-09-24 01:16:20 --> Config Class Initialized
INFO - 2016-09-24 01:16:20 --> Hooks Class Initialized
DEBUG - 2016-09-24 01:16:20 --> UTF-8 Support Enabled
INFO - 2016-09-24 01:16:20 --> Utf8 Class Initialized
INFO - 2016-09-24 01:16:20 --> URI Class Initialized
INFO - 2016-09-24 01:16:20 --> Router Class Initialized
INFO - 2016-09-24 01:16:20 --> Output Class Initialized
INFO - 2016-09-24 01:16:20 --> Security Class Initialized
DEBUG - 2016-09-24 01:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 01:16:20 --> Input Class Initialized
INFO - 2016-09-24 01:16:20 --> Language Class Initialized
INFO - 2016-09-24 01:16:20 --> Language Class Initialized
INFO - 2016-09-24 01:16:20 --> Config Class Initialized
INFO - 2016-09-24 01:16:20 --> Loader Class Initialized
INFO - 2016-09-24 01:16:20 --> Helper loaded: url_helper
INFO - 2016-09-24 01:16:20 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 01:16:20 --> Controller Class Initialized
DEBUG - 2016-09-24 01:16:20 --> Index MX_Controller Initialized
INFO - 2016-09-24 01:16:20 --> Model Class Initialized
INFO - 2016-09-24 01:16:20 --> Model Class Initialized
ERROR - 2016-09-24 01:16:20 --> Unable to delete cache file for admin/index/data/user
DEBUG - 2016-09-24 01:16:20 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-24 01:16:20 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-24 01:16:20 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-24 01:16:20 --> File already loaded: /home/koperasi/public_html/application/controllers/../modules/user/controllers/Users.php
DEBUG - 2016-09-24 01:16:20 --> Users MX_Controller Initialized
DEBUG - 2016-09-24 01:16:20 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/list_user.php
DEBUG - 2016-09-24 01:16:20 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-24 01:16:20 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-24 01:16:20 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:20 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:20 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:20 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:20 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:20 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:20 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:20 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:20 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:20 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:20 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:21 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:21 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:21 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:21 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:21 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:21 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:21 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:21 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:21 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:21 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:21 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:21 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:21 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:21 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:21 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:21 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:21 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:21 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:21 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:21 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:21 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:21 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:21 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:21 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:21 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:21 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:21 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:21 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:21 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:21 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:21 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:21 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:21 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:21 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:21 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:21 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:21 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:21 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:21 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:21 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:21 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:21 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:21 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:21 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:21 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:21 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:21 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:21 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:21 --> Database Driver Class Initialized
DEBUG - 2016-09-24 01:16:21 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-24 01:16:21 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-24 01:16:21 --> Final output sent to browser
DEBUG - 2016-09-24 01:16:21 --> Total execution time: 0.1403
INFO - 2016-09-24 01:16:22 --> Config Class Initialized
INFO - 2016-09-24 01:16:22 --> Hooks Class Initialized
DEBUG - 2016-09-24 01:16:22 --> UTF-8 Support Enabled
INFO - 2016-09-24 01:16:22 --> Utf8 Class Initialized
INFO - 2016-09-24 01:16:22 --> URI Class Initialized
INFO - 2016-09-24 01:16:22 --> Router Class Initialized
INFO - 2016-09-24 01:16:22 --> Output Class Initialized
INFO - 2016-09-24 01:16:22 --> Security Class Initialized
DEBUG - 2016-09-24 01:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 01:16:22 --> Input Class Initialized
INFO - 2016-09-24 01:16:22 --> Language Class Initialized
INFO - 2016-09-24 01:16:22 --> Language Class Initialized
INFO - 2016-09-24 01:16:22 --> Config Class Initialized
INFO - 2016-09-24 01:16:22 --> Loader Class Initialized
INFO - 2016-09-24 01:16:22 --> Helper loaded: url_helper
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 01:16:22 --> Controller Class Initialized
DEBUG - 2016-09-24 01:16:22 --> Index MX_Controller Initialized
INFO - 2016-09-24 01:16:22 --> Model Class Initialized
INFO - 2016-09-24 01:16:22 --> Model Class Initialized
ERROR - 2016-09-24 01:16:22 --> Unable to delete cache file for admin/index/data/user
DEBUG - 2016-09-24 01:16:22 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-24 01:16:22 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-24 01:16:22 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-24 01:16:22 --> File already loaded: /home/koperasi/public_html/application/controllers/../modules/user/controllers/Users.php
DEBUG - 2016-09-24 01:16:22 --> Users MX_Controller Initialized
DEBUG - 2016-09-24 01:16:22 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/list_user.php
DEBUG - 2016-09-24 01:16:22 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-24 01:16:22 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
INFO - 2016-09-24 01:16:22 --> Database Driver Class Initialized
DEBUG - 2016-09-24 01:16:22 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-24 01:16:22 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-24 01:16:22 --> Final output sent to browser
DEBUG - 2016-09-24 01:16:22 --> Total execution time: 0.1057
INFO - 2016-09-24 01:16:22 --> Config Class Initialized
INFO - 2016-09-24 01:16:22 --> Hooks Class Initialized
DEBUG - 2016-09-24 01:16:22 --> UTF-8 Support Enabled
INFO - 2016-09-24 01:16:22 --> Utf8 Class Initialized
INFO - 2016-09-24 01:16:22 --> URI Class Initialized
INFO - 2016-09-24 01:16:22 --> Router Class Initialized
INFO - 2016-09-24 01:16:22 --> Output Class Initialized
INFO - 2016-09-24 01:16:22 --> Security Class Initialized
DEBUG - 2016-09-24 01:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 01:16:22 --> Input Class Initialized
INFO - 2016-09-24 01:16:22 --> Language Class Initialized
ERROR - 2016-09-24 01:16:22 --> 404 Page Not Found: /index
INFO - 2016-09-24 03:59:04 --> Config Class Initialized
INFO - 2016-09-24 03:59:04 --> Hooks Class Initialized
DEBUG - 2016-09-24 03:59:04 --> UTF-8 Support Enabled
INFO - 2016-09-24 03:59:04 --> Utf8 Class Initialized
INFO - 2016-09-24 03:59:04 --> URI Class Initialized
DEBUG - 2016-09-24 03:59:04 --> No URI present. Default controller set.
INFO - 2016-09-24 03:59:04 --> Router Class Initialized
INFO - 2016-09-24 03:59:04 --> Output Class Initialized
INFO - 2016-09-24 03:59:04 --> Security Class Initialized
DEBUG - 2016-09-24 03:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 03:59:04 --> Input Class Initialized
INFO - 2016-09-24 03:59:04 --> Language Class Initialized
INFO - 2016-09-24 03:59:04 --> Language Class Initialized
INFO - 2016-09-24 03:59:04 --> Config Class Initialized
INFO - 2016-09-24 03:59:04 --> Loader Class Initialized
INFO - 2016-09-24 03:59:04 --> Helper loaded: url_helper
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 03:59:04 --> Controller Class Initialized
DEBUG - 2016-09-24 03:59:04 --> Index MX_Controller Initialized
INFO - 2016-09-24 03:59:04 --> Model Class Initialized
INFO - 2016-09-24 03:59:04 --> Model Class Initialized
ERROR - 2016-09-24 03:59:04 --> Unable to delete cache file for 
DEBUG - 2016-09-24 03:59:04 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-24 03:59:04 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-24 03:59:04 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-24 03:59:04 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-24 03:59:04 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-24 03:59:04 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:04 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:05 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:05 --> Database Driver Class Initialized
DEBUG - 2016-09-24 03:59:05 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-24 03:59:05 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-24 03:59:05 --> Final output sent to browser
DEBUG - 2016-09-24 03:59:05 --> Total execution time: 0.1722
INFO - 2016-09-24 03:59:05 --> Config Class Initialized
INFO - 2016-09-24 03:59:05 --> Hooks Class Initialized
DEBUG - 2016-09-24 03:59:05 --> UTF-8 Support Enabled
INFO - 2016-09-24 03:59:05 --> Utf8 Class Initialized
INFO - 2016-09-24 03:59:05 --> URI Class Initialized
INFO - 2016-09-24 03:59:05 --> Router Class Initialized
INFO - 2016-09-24 03:59:05 --> Output Class Initialized
INFO - 2016-09-24 03:59:05 --> Security Class Initialized
DEBUG - 2016-09-24 03:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 03:59:05 --> Input Class Initialized
INFO - 2016-09-24 03:59:05 --> Language Class Initialized
INFO - 2016-09-24 03:59:05 --> Language Class Initialized
INFO - 2016-09-24 03:59:05 --> Config Class Initialized
INFO - 2016-09-24 03:59:05 --> Loader Class Initialized
INFO - 2016-09-24 03:59:05 --> Helper loaded: url_helper
INFO - 2016-09-24 03:59:05 --> Database Driver Class Initialized
INFO - 2016-09-24 03:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 03:59:05 --> Controller Class Initialized
DEBUG - 2016-09-24 03:59:05 --> login MX_Controller Initialized
INFO - 2016-09-24 03:59:05 --> Model Class Initialized
INFO - 2016-09-24 03:59:05 --> Model Class Initialized
DEBUG - 2016-09-24 03:59:05 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-24 03:59:05 --> Final output sent to browser
DEBUG - 2016-09-24 03:59:05 --> Total execution time: 0.0302
INFO - 2016-09-24 04:07:44 --> Config Class Initialized
INFO - 2016-09-24 04:07:44 --> Hooks Class Initialized
DEBUG - 2016-09-24 04:07:44 --> UTF-8 Support Enabled
INFO - 2016-09-24 04:07:44 --> Utf8 Class Initialized
INFO - 2016-09-24 04:07:44 --> URI Class Initialized
INFO - 2016-09-24 04:07:44 --> Router Class Initialized
INFO - 2016-09-24 04:07:44 --> Output Class Initialized
INFO - 2016-09-24 04:07:44 --> Security Class Initialized
DEBUG - 2016-09-24 04:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 04:07:44 --> Input Class Initialized
INFO - 2016-09-24 04:07:44 --> Language Class Initialized
INFO - 2016-09-24 04:07:44 --> Language Class Initialized
INFO - 2016-09-24 04:07:44 --> Config Class Initialized
INFO - 2016-09-24 04:07:44 --> Loader Class Initialized
INFO - 2016-09-24 04:07:44 --> Helper loaded: url_helper
INFO - 2016-09-24 04:07:44 --> Database Driver Class Initialized
INFO - 2016-09-24 04:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 04:07:44 --> Controller Class Initialized
DEBUG - 2016-09-24 04:07:44 --> login MX_Controller Initialized
INFO - 2016-09-24 04:07:44 --> Model Class Initialized
INFO - 2016-09-24 04:07:44 --> Model Class Initialized
DEBUG - 2016-09-24 04:07:44 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-24 04:07:44 --> Final output sent to browser
DEBUG - 2016-09-24 04:07:44 --> Total execution time: 0.0220
INFO - 2016-09-24 04:15:55 --> Config Class Initialized
INFO - 2016-09-24 04:15:55 --> Hooks Class Initialized
DEBUG - 2016-09-24 04:15:55 --> UTF-8 Support Enabled
INFO - 2016-09-24 04:15:55 --> Utf8 Class Initialized
INFO - 2016-09-24 04:15:55 --> URI Class Initialized
DEBUG - 2016-09-24 04:15:55 --> No URI present. Default controller set.
INFO - 2016-09-24 04:15:55 --> Router Class Initialized
INFO - 2016-09-24 04:15:55 --> Output Class Initialized
INFO - 2016-09-24 04:15:55 --> Security Class Initialized
DEBUG - 2016-09-24 04:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 04:15:55 --> Input Class Initialized
INFO - 2016-09-24 04:15:55 --> Language Class Initialized
INFO - 2016-09-24 04:15:55 --> Language Class Initialized
INFO - 2016-09-24 04:15:55 --> Config Class Initialized
INFO - 2016-09-24 04:15:55 --> Loader Class Initialized
INFO - 2016-09-24 04:15:55 --> Helper loaded: url_helper
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 04:15:55 --> Controller Class Initialized
DEBUG - 2016-09-24 04:15:55 --> Index MX_Controller Initialized
INFO - 2016-09-24 04:15:55 --> Model Class Initialized
INFO - 2016-09-24 04:15:55 --> Model Class Initialized
ERROR - 2016-09-24 04:15:55 --> Unable to delete cache file for 
DEBUG - 2016-09-24 04:15:55 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-24 04:15:55 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-24 04:15:55 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-24 04:15:55 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-24 04:15:55 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-24 04:15:55 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:55 --> Database Driver Class Initialized
DEBUG - 2016-09-24 04:15:55 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-24 04:15:55 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-24 04:15:55 --> Final output sent to browser
DEBUG - 2016-09-24 04:15:55 --> Total execution time: 0.1444
INFO - 2016-09-24 04:15:55 --> Config Class Initialized
INFO - 2016-09-24 04:15:55 --> Hooks Class Initialized
DEBUG - 2016-09-24 04:15:55 --> UTF-8 Support Enabled
INFO - 2016-09-24 04:15:55 --> Utf8 Class Initialized
INFO - 2016-09-24 04:15:55 --> URI Class Initialized
INFO - 2016-09-24 04:15:55 --> Router Class Initialized
INFO - 2016-09-24 04:15:55 --> Output Class Initialized
INFO - 2016-09-24 04:15:55 --> Security Class Initialized
DEBUG - 2016-09-24 04:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 04:15:55 --> Input Class Initialized
INFO - 2016-09-24 04:15:55 --> Language Class Initialized
INFO - 2016-09-24 04:15:55 --> Language Class Initialized
INFO - 2016-09-24 04:15:55 --> Config Class Initialized
INFO - 2016-09-24 04:15:55 --> Loader Class Initialized
INFO - 2016-09-24 04:15:55 --> Helper loaded: url_helper
INFO - 2016-09-24 04:15:56 --> Database Driver Class Initialized
INFO - 2016-09-24 04:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 04:15:56 --> Controller Class Initialized
DEBUG - 2016-09-24 04:15:56 --> login MX_Controller Initialized
INFO - 2016-09-24 04:15:56 --> Model Class Initialized
INFO - 2016-09-24 04:15:56 --> Model Class Initialized
DEBUG - 2016-09-24 04:15:56 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-24 04:15:56 --> Final output sent to browser
DEBUG - 2016-09-24 04:15:56 --> Total execution time: 0.0265
INFO - 2016-09-24 04:18:07 --> Config Class Initialized
INFO - 2016-09-24 04:18:07 --> Hooks Class Initialized
DEBUG - 2016-09-24 04:18:07 --> UTF-8 Support Enabled
INFO - 2016-09-24 04:18:07 --> Utf8 Class Initialized
INFO - 2016-09-24 04:18:07 --> URI Class Initialized
DEBUG - 2016-09-24 04:18:07 --> No URI present. Default controller set.
INFO - 2016-09-24 04:18:07 --> Router Class Initialized
INFO - 2016-09-24 04:18:07 --> Output Class Initialized
INFO - 2016-09-24 04:18:07 --> Security Class Initialized
DEBUG - 2016-09-24 04:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 04:18:07 --> Input Class Initialized
INFO - 2016-09-24 04:18:07 --> Language Class Initialized
INFO - 2016-09-24 04:18:07 --> Language Class Initialized
INFO - 2016-09-24 04:18:07 --> Config Class Initialized
INFO - 2016-09-24 04:18:07 --> Loader Class Initialized
INFO - 2016-09-24 04:18:07 --> Helper loaded: url_helper
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 04:18:07 --> Controller Class Initialized
DEBUG - 2016-09-24 04:18:07 --> Index MX_Controller Initialized
INFO - 2016-09-24 04:18:07 --> Model Class Initialized
INFO - 2016-09-24 04:18:07 --> Model Class Initialized
ERROR - 2016-09-24 04:18:07 --> Unable to delete cache file for 
DEBUG - 2016-09-24 04:18:07 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-24 04:18:07 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-24 04:18:07 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-24 04:18:07 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-24 04:18:07 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-24 04:18:07 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
INFO - 2016-09-24 04:18:07 --> Database Driver Class Initialized
DEBUG - 2016-09-24 04:18:07 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-24 04:18:07 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-24 04:18:07 --> Final output sent to browser
DEBUG - 2016-09-24 04:18:07 --> Total execution time: 0.1108
INFO - 2016-09-24 10:17:55 --> Config Class Initialized
INFO - 2016-09-24 10:17:55 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:17:55 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:17:55 --> Utf8 Class Initialized
INFO - 2016-09-24 10:17:55 --> URI Class Initialized
DEBUG - 2016-09-24 10:17:55 --> No URI present. Default controller set.
INFO - 2016-09-24 10:17:55 --> Router Class Initialized
INFO - 2016-09-24 10:17:55 --> Output Class Initialized
INFO - 2016-09-24 10:17:55 --> Security Class Initialized
DEBUG - 2016-09-24 10:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:17:55 --> Input Class Initialized
INFO - 2016-09-24 10:17:55 --> Language Class Initialized
INFO - 2016-09-24 10:17:55 --> Language Class Initialized
INFO - 2016-09-24 10:17:55 --> Config Class Initialized
INFO - 2016-09-24 10:17:55 --> Loader Class Initialized
INFO - 2016-09-24 10:17:55 --> Helper loaded: url_helper
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 10:17:55 --> Controller Class Initialized
DEBUG - 2016-09-24 10:17:55 --> Index MX_Controller Initialized
INFO - 2016-09-24 10:17:55 --> Model Class Initialized
INFO - 2016-09-24 10:17:55 --> Model Class Initialized
ERROR - 2016-09-24 10:17:55 --> Unable to delete cache file for 
DEBUG - 2016-09-24 10:17:55 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-24 10:17:55 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-24 10:17:55 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-24 10:17:55 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-24 10:17:55 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-24 10:17:55 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:55 --> Database Driver Class Initialized
DEBUG - 2016-09-24 10:17:55 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-24 10:17:55 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-24 10:17:55 --> Final output sent to browser
DEBUG - 2016-09-24 10:17:55 --> Total execution time: 0.1801
INFO - 2016-09-24 10:17:56 --> Config Class Initialized
INFO - 2016-09-24 10:17:56 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:17:56 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:17:56 --> Utf8 Class Initialized
INFO - 2016-09-24 10:17:56 --> URI Class Initialized
INFO - 2016-09-24 10:17:56 --> Router Class Initialized
INFO - 2016-09-24 10:17:56 --> Output Class Initialized
INFO - 2016-09-24 10:17:56 --> Security Class Initialized
DEBUG - 2016-09-24 10:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:17:56 --> Input Class Initialized
INFO - 2016-09-24 10:17:56 --> Language Class Initialized
INFO - 2016-09-24 10:17:56 --> Language Class Initialized
INFO - 2016-09-24 10:17:56 --> Config Class Initialized
INFO - 2016-09-24 10:17:56 --> Loader Class Initialized
INFO - 2016-09-24 10:17:56 --> Helper loaded: url_helper
INFO - 2016-09-24 10:17:57 --> Database Driver Class Initialized
INFO - 2016-09-24 10:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 10:17:57 --> Controller Class Initialized
DEBUG - 2016-09-24 10:17:57 --> login MX_Controller Initialized
INFO - 2016-09-24 10:17:57 --> Model Class Initialized
INFO - 2016-09-24 10:17:57 --> Model Class Initialized
DEBUG - 2016-09-24 10:17:57 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-24 10:17:57 --> Final output sent to browser
DEBUG - 2016-09-24 10:17:57 --> Total execution time: 0.0223
INFO - 2016-09-24 14:01:42 --> Config Class Initialized
INFO - 2016-09-24 14:01:42 --> Hooks Class Initialized
DEBUG - 2016-09-24 14:01:42 --> UTF-8 Support Enabled
INFO - 2016-09-24 14:01:42 --> Utf8 Class Initialized
INFO - 2016-09-24 14:01:42 --> URI Class Initialized
DEBUG - 2016-09-24 14:01:42 --> No URI present. Default controller set.
INFO - 2016-09-24 14:01:42 --> Router Class Initialized
INFO - 2016-09-24 14:01:42 --> Output Class Initialized
INFO - 2016-09-24 14:01:42 --> Security Class Initialized
DEBUG - 2016-09-24 14:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 14:01:42 --> Input Class Initialized
INFO - 2016-09-24 14:01:42 --> Language Class Initialized
INFO - 2016-09-24 14:01:42 --> Language Class Initialized
INFO - 2016-09-24 14:01:42 --> Config Class Initialized
INFO - 2016-09-24 14:01:42 --> Loader Class Initialized
INFO - 2016-09-24 14:01:42 --> Helper loaded: url_helper
INFO - 2016-09-24 14:01:42 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 14:01:42 --> Controller Class Initialized
DEBUG - 2016-09-24 14:01:42 --> Index MX_Controller Initialized
INFO - 2016-09-24 14:01:42 --> Model Class Initialized
INFO - 2016-09-24 14:01:42 --> Model Class Initialized
ERROR - 2016-09-24 14:01:42 --> Unable to delete cache file for 
DEBUG - 2016-09-24 14:01:42 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-24 14:01:42 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-24 14:01:42 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-24 14:01:42 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-24 14:01:42 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-24 14:01:42 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-24 14:01:42 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:42 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:42 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:42 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:42 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:42 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:42 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:42 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:42 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:42 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:42 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:42 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:42 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:42 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:42 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:42 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:42 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:42 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:42 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:42 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:42 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:42 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:42 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:42 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:42 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:43 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:43 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:43 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:43 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:43 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:43 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:43 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:43 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:43 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:43 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:43 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:43 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:43 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:43 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:43 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:43 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:43 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:43 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:43 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:43 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:43 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:43 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:43 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:43 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:43 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:43 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:43 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:43 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:43 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:43 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:43 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:43 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:43 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:43 --> Database Driver Class Initialized
DEBUG - 2016-09-24 14:01:43 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-24 14:01:43 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-24 14:01:43 --> Final output sent to browser
DEBUG - 2016-09-24 14:01:43 --> Total execution time: 0.1204
INFO - 2016-09-24 14:01:43 --> Config Class Initialized
INFO - 2016-09-24 14:01:43 --> Hooks Class Initialized
DEBUG - 2016-09-24 14:01:43 --> UTF-8 Support Enabled
INFO - 2016-09-24 14:01:43 --> Utf8 Class Initialized
INFO - 2016-09-24 14:01:43 --> URI Class Initialized
INFO - 2016-09-24 14:01:43 --> Router Class Initialized
INFO - 2016-09-24 14:01:43 --> Output Class Initialized
INFO - 2016-09-24 14:01:43 --> Security Class Initialized
DEBUG - 2016-09-24 14:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 14:01:43 --> Input Class Initialized
INFO - 2016-09-24 14:01:43 --> Language Class Initialized
INFO - 2016-09-24 14:01:43 --> Language Class Initialized
INFO - 2016-09-24 14:01:43 --> Config Class Initialized
INFO - 2016-09-24 14:01:43 --> Loader Class Initialized
INFO - 2016-09-24 14:01:43 --> Helper loaded: url_helper
INFO - 2016-09-24 14:01:43 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 14:01:43 --> Controller Class Initialized
DEBUG - 2016-09-24 14:01:43 --> login MX_Controller Initialized
INFO - 2016-09-24 14:01:43 --> Model Class Initialized
INFO - 2016-09-24 14:01:43 --> Model Class Initialized
DEBUG - 2016-09-24 14:01:43 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-24 14:01:43 --> Final output sent to browser
DEBUG - 2016-09-24 14:01:43 --> Total execution time: 0.0330
INFO - 2016-09-24 14:01:55 --> Config Class Initialized
INFO - 2016-09-24 14:01:55 --> Hooks Class Initialized
DEBUG - 2016-09-24 14:01:55 --> UTF-8 Support Enabled
INFO - 2016-09-24 14:01:55 --> Utf8 Class Initialized
INFO - 2016-09-24 14:01:55 --> URI Class Initialized
INFO - 2016-09-24 14:01:55 --> Router Class Initialized
INFO - 2016-09-24 14:01:55 --> Output Class Initialized
INFO - 2016-09-24 14:01:55 --> Security Class Initialized
DEBUG - 2016-09-24 14:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 14:01:55 --> Input Class Initialized
INFO - 2016-09-24 14:01:55 --> Language Class Initialized
INFO - 2016-09-24 14:01:55 --> Language Class Initialized
INFO - 2016-09-24 14:01:55 --> Config Class Initialized
INFO - 2016-09-24 14:01:55 --> Loader Class Initialized
INFO - 2016-09-24 14:01:55 --> Helper loaded: url_helper
INFO - 2016-09-24 14:01:55 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 14:01:55 --> Controller Class Initialized
DEBUG - 2016-09-24 14:01:55 --> login MX_Controller Initialized
INFO - 2016-09-24 14:01:55 --> Model Class Initialized
INFO - 2016-09-24 14:01:55 --> Model Class Initialized
INFO - 2016-09-24 14:01:55 --> Final output sent to browser
DEBUG - 2016-09-24 14:01:55 --> Total execution time: 0.0361
INFO - 2016-09-24 14:01:56 --> Config Class Initialized
INFO - 2016-09-24 14:01:56 --> Hooks Class Initialized
DEBUG - 2016-09-24 14:01:56 --> UTF-8 Support Enabled
INFO - 2016-09-24 14:01:56 --> Utf8 Class Initialized
INFO - 2016-09-24 14:01:56 --> URI Class Initialized
INFO - 2016-09-24 14:01:56 --> Router Class Initialized
INFO - 2016-09-24 14:01:56 --> Output Class Initialized
INFO - 2016-09-24 14:01:56 --> Security Class Initialized
DEBUG - 2016-09-24 14:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 14:01:56 --> Input Class Initialized
INFO - 2016-09-24 14:01:56 --> Language Class Initialized
INFO - 2016-09-24 14:01:56 --> Language Class Initialized
INFO - 2016-09-24 14:01:56 --> Config Class Initialized
INFO - 2016-09-24 14:01:56 --> Loader Class Initialized
INFO - 2016-09-24 14:01:56 --> Helper loaded: url_helper
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 14:01:56 --> Controller Class Initialized
DEBUG - 2016-09-24 14:01:56 --> Index MX_Controller Initialized
INFO - 2016-09-24 14:01:56 --> Model Class Initialized
INFO - 2016-09-24 14:01:56 --> Model Class Initialized
ERROR - 2016-09-24 14:01:56 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-24 14:01:56 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-24 14:01:56 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-24 14:01:56 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-24 14:01:56 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-24 14:01:56 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-24 14:01:56 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
INFO - 2016-09-24 14:01:56 --> Database Driver Class Initialized
DEBUG - 2016-09-24 14:01:56 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-24 14:01:56 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-24 14:01:56 --> Final output sent to browser
DEBUG - 2016-09-24 14:01:56 --> Total execution time: 0.1124
INFO - 2016-09-24 14:01:57 --> Config Class Initialized
INFO - 2016-09-24 14:01:57 --> Hooks Class Initialized
DEBUG - 2016-09-24 14:01:57 --> UTF-8 Support Enabled
INFO - 2016-09-24 14:01:57 --> Utf8 Class Initialized
INFO - 2016-09-24 14:01:57 --> URI Class Initialized
INFO - 2016-09-24 14:01:57 --> Router Class Initialized
INFO - 2016-09-24 14:01:57 --> Output Class Initialized
INFO - 2016-09-24 14:01:57 --> Security Class Initialized
DEBUG - 2016-09-24 14:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 14:01:57 --> Input Class Initialized
INFO - 2016-09-24 14:01:57 --> Language Class Initialized
ERROR - 2016-09-24 14:01:57 --> 404 Page Not Found: /index
INFO - 2016-09-24 14:02:12 --> Config Class Initialized
INFO - 2016-09-24 14:02:12 --> Hooks Class Initialized
DEBUG - 2016-09-24 14:02:12 --> UTF-8 Support Enabled
INFO - 2016-09-24 14:02:12 --> Utf8 Class Initialized
INFO - 2016-09-24 14:02:12 --> URI Class Initialized
INFO - 2016-09-24 14:02:12 --> Router Class Initialized
INFO - 2016-09-24 14:02:12 --> Output Class Initialized
INFO - 2016-09-24 14:02:12 --> Security Class Initialized
DEBUG - 2016-09-24 14:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 14:02:12 --> Input Class Initialized
INFO - 2016-09-24 14:02:12 --> Language Class Initialized
INFO - 2016-09-24 14:02:12 --> Language Class Initialized
INFO - 2016-09-24 14:02:12 --> Config Class Initialized
INFO - 2016-09-24 14:02:12 --> Loader Class Initialized
INFO - 2016-09-24 14:02:12 --> Helper loaded: url_helper
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 14:02:12 --> Controller Class Initialized
DEBUG - 2016-09-24 14:02:12 --> Index MX_Controller Initialized
INFO - 2016-09-24 14:02:12 --> Model Class Initialized
INFO - 2016-09-24 14:02:12 --> Model Class Initialized
ERROR - 2016-09-24 14:02:12 --> Unable to delete cache file for admin/index/add/anggota
DEBUG - 2016-09-24 14:02:12 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-24 14:02:12 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-24 14:02:12 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-24 14:02:12 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/form_anggota.php
DEBUG - 2016-09-24 14:02:12 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-24 14:02:12 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:12 --> Database Driver Class Initialized
DEBUG - 2016-09-24 14:02:12 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-24 14:02:12 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-24 14:02:12 --> Final output sent to browser
DEBUG - 2016-09-24 14:02:12 --> Total execution time: 0.1253
INFO - 2016-09-24 14:02:13 --> Config Class Initialized
INFO - 2016-09-24 14:02:13 --> Hooks Class Initialized
DEBUG - 2016-09-24 14:02:13 --> UTF-8 Support Enabled
INFO - 2016-09-24 14:02:13 --> Utf8 Class Initialized
INFO - 2016-09-24 14:02:13 --> URI Class Initialized
INFO - 2016-09-24 14:02:13 --> Router Class Initialized
INFO - 2016-09-24 14:02:13 --> Output Class Initialized
INFO - 2016-09-24 14:02:13 --> Security Class Initialized
DEBUG - 2016-09-24 14:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 14:02:13 --> Input Class Initialized
INFO - 2016-09-24 14:02:13 --> Language Class Initialized
ERROR - 2016-09-24 14:02:13 --> 404 Page Not Found: /index
INFO - 2016-09-24 14:02:21 --> Config Class Initialized
INFO - 2016-09-24 14:02:21 --> Hooks Class Initialized
DEBUG - 2016-09-24 14:02:21 --> UTF-8 Support Enabled
INFO - 2016-09-24 14:02:21 --> Utf8 Class Initialized
INFO - 2016-09-24 14:02:21 --> URI Class Initialized
INFO - 2016-09-24 14:02:21 --> Router Class Initialized
INFO - 2016-09-24 14:02:21 --> Output Class Initialized
INFO - 2016-09-24 14:02:21 --> Security Class Initialized
DEBUG - 2016-09-24 14:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 14:02:21 --> Input Class Initialized
INFO - 2016-09-24 14:02:21 --> Language Class Initialized
INFO - 2016-09-24 14:02:21 --> Language Class Initialized
INFO - 2016-09-24 14:02:21 --> Config Class Initialized
INFO - 2016-09-24 14:02:21 --> Loader Class Initialized
INFO - 2016-09-24 14:02:21 --> Helper loaded: url_helper
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 14:02:21 --> Controller Class Initialized
DEBUG - 2016-09-24 14:02:21 --> Index MX_Controller Initialized
INFO - 2016-09-24 14:02:21 --> Model Class Initialized
INFO - 2016-09-24 14:02:21 --> Model Class Initialized
ERROR - 2016-09-24 14:02:21 --> Unable to delete cache file for admin/index/upload_foto
DEBUG - 2016-09-24 14:02:21 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-24 14:02:21 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-24 14:02:21 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-24 14:02:21 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/upload_foto.php
DEBUG - 2016-09-24 14:02:21 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-24 14:02:21 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2016-09-24 14:02:21 --> Database Driver Class Initialized
DEBUG - 2016-09-24 14:02:21 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-24 14:02:21 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-24 14:02:21 --> Final output sent to browser
DEBUG - 2016-09-24 14:02:21 --> Total execution time: 0.1439
INFO - 2016-09-24 14:02:22 --> Config Class Initialized
INFO - 2016-09-24 14:02:22 --> Hooks Class Initialized
DEBUG - 2016-09-24 14:02:22 --> UTF-8 Support Enabled
INFO - 2016-09-24 14:02:22 --> Utf8 Class Initialized
INFO - 2016-09-24 14:02:22 --> URI Class Initialized
INFO - 2016-09-24 14:02:22 --> Router Class Initialized
INFO - 2016-09-24 14:02:22 --> Output Class Initialized
INFO - 2016-09-24 14:02:22 --> Security Class Initialized
DEBUG - 2016-09-24 14:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 14:02:22 --> Input Class Initialized
INFO - 2016-09-24 14:02:22 --> Language Class Initialized
ERROR - 2016-09-24 14:02:22 --> 404 Page Not Found: /index
INFO - 2016-09-24 14:08:50 --> Config Class Initialized
INFO - 2016-09-24 14:08:50 --> Hooks Class Initialized
DEBUG - 2016-09-24 14:08:50 --> UTF-8 Support Enabled
INFO - 2016-09-24 14:08:50 --> Utf8 Class Initialized
INFO - 2016-09-24 14:08:50 --> URI Class Initialized
DEBUG - 2016-09-24 14:08:50 --> No URI present. Default controller set.
INFO - 2016-09-24 14:08:50 --> Router Class Initialized
INFO - 2016-09-24 14:08:50 --> Output Class Initialized
INFO - 2016-09-24 14:08:50 --> Security Class Initialized
DEBUG - 2016-09-24 14:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 14:08:50 --> Input Class Initialized
INFO - 2016-09-24 14:08:50 --> Language Class Initialized
INFO - 2016-09-24 14:08:50 --> Language Class Initialized
INFO - 2016-09-24 14:08:50 --> Config Class Initialized
INFO - 2016-09-24 14:08:50 --> Loader Class Initialized
INFO - 2016-09-24 14:08:50 --> Helper loaded: url_helper
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 14:08:50 --> Controller Class Initialized
DEBUG - 2016-09-24 14:08:50 --> Index MX_Controller Initialized
INFO - 2016-09-24 14:08:50 --> Model Class Initialized
INFO - 2016-09-24 14:08:50 --> Model Class Initialized
ERROR - 2016-09-24 14:08:50 --> Unable to delete cache file for 
DEBUG - 2016-09-24 14:08:50 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-24 14:08:50 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-24 14:08:50 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-24 14:08:50 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-24 14:08:50 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-24 14:08:50 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:50 --> Database Driver Class Initialized
DEBUG - 2016-09-24 14:08:50 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-24 14:08:50 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-24 14:08:50 --> Final output sent to browser
DEBUG - 2016-09-24 14:08:50 --> Total execution time: 0.1099
INFO - 2016-09-24 14:08:51 --> Config Class Initialized
INFO - 2016-09-24 14:08:51 --> Hooks Class Initialized
DEBUG - 2016-09-24 14:08:51 --> UTF-8 Support Enabled
INFO - 2016-09-24 14:08:51 --> Utf8 Class Initialized
INFO - 2016-09-24 14:08:51 --> URI Class Initialized
INFO - 2016-09-24 14:08:51 --> Router Class Initialized
INFO - 2016-09-24 14:08:51 --> Output Class Initialized
INFO - 2016-09-24 14:08:51 --> Security Class Initialized
DEBUG - 2016-09-24 14:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 14:08:51 --> Input Class Initialized
INFO - 2016-09-24 14:08:51 --> Language Class Initialized
INFO - 2016-09-24 14:08:51 --> Language Class Initialized
INFO - 2016-09-24 14:08:51 --> Config Class Initialized
INFO - 2016-09-24 14:08:51 --> Loader Class Initialized
INFO - 2016-09-24 14:08:51 --> Helper loaded: url_helper
INFO - 2016-09-24 14:08:51 --> Database Driver Class Initialized
INFO - 2016-09-24 14:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 14:08:51 --> Controller Class Initialized
DEBUG - 2016-09-24 14:08:51 --> login MX_Controller Initialized
INFO - 2016-09-24 14:08:51 --> Model Class Initialized
INFO - 2016-09-24 14:08:51 --> Model Class Initialized
DEBUG - 2016-09-24 14:08:51 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-24 14:08:51 --> Final output sent to browser
DEBUG - 2016-09-24 14:08:51 --> Total execution time: 0.0289
INFO - 2016-09-24 16:56:52 --> Config Class Initialized
INFO - 2016-09-24 16:56:52 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:56:52 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:56:52 --> Utf8 Class Initialized
INFO - 2016-09-24 16:56:52 --> URI Class Initialized
DEBUG - 2016-09-24 16:56:52 --> No URI present. Default controller set.
INFO - 2016-09-24 16:56:52 --> Router Class Initialized
INFO - 2016-09-24 16:56:52 --> Output Class Initialized
INFO - 2016-09-24 16:56:52 --> Security Class Initialized
DEBUG - 2016-09-24 16:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:56:52 --> Input Class Initialized
INFO - 2016-09-24 16:56:52 --> Language Class Initialized
INFO - 2016-09-24 16:56:52 --> Language Class Initialized
INFO - 2016-09-24 16:56:52 --> Config Class Initialized
INFO - 2016-09-24 16:56:52 --> Loader Class Initialized
INFO - 2016-09-24 16:56:52 --> Helper loaded: url_helper
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 16:56:52 --> Controller Class Initialized
DEBUG - 2016-09-24 16:56:52 --> Index MX_Controller Initialized
INFO - 2016-09-24 16:56:52 --> Model Class Initialized
INFO - 2016-09-24 16:56:52 --> Model Class Initialized
ERROR - 2016-09-24 16:56:52 --> Unable to delete cache file for 
DEBUG - 2016-09-24 16:56:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-24 16:56:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-24 16:56:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-24 16:56:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-24 16:56:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-24 16:56:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
DEBUG - 2016-09-24 16:56:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-24 16:56:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-24 16:56:52 --> Final output sent to browser
DEBUG - 2016-09-24 16:56:52 --> Total execution time: 0.1132
INFO - 2016-09-24 16:56:52 --> Config Class Initialized
INFO - 2016-09-24 16:56:52 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:56:52 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:56:52 --> Utf8 Class Initialized
INFO - 2016-09-24 16:56:52 --> URI Class Initialized
INFO - 2016-09-24 16:56:52 --> Router Class Initialized
INFO - 2016-09-24 16:56:52 --> Output Class Initialized
INFO - 2016-09-24 16:56:52 --> Security Class Initialized
DEBUG - 2016-09-24 16:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:56:52 --> Input Class Initialized
INFO - 2016-09-24 16:56:52 --> Language Class Initialized
INFO - 2016-09-24 16:56:52 --> Language Class Initialized
INFO - 2016-09-24 16:56:52 --> Config Class Initialized
INFO - 2016-09-24 16:56:52 --> Loader Class Initialized
INFO - 2016-09-24 16:56:52 --> Helper loaded: url_helper
INFO - 2016-09-24 16:56:52 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 16:56:52 --> Controller Class Initialized
DEBUG - 2016-09-24 16:56:52 --> login MX_Controller Initialized
INFO - 2016-09-24 16:56:52 --> Model Class Initialized
INFO - 2016-09-24 16:56:52 --> Model Class Initialized
DEBUG - 2016-09-24 16:56:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-24 16:56:52 --> Final output sent to browser
DEBUG - 2016-09-24 16:56:52 --> Total execution time: 0.0235
INFO - 2016-09-24 16:56:54 --> Config Class Initialized
INFO - 2016-09-24 16:56:54 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:56:54 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:56:54 --> Utf8 Class Initialized
INFO - 2016-09-24 16:56:54 --> URI Class Initialized
DEBUG - 2016-09-24 16:56:54 --> No URI present. Default controller set.
INFO - 2016-09-24 16:56:54 --> Router Class Initialized
INFO - 2016-09-24 16:56:54 --> Output Class Initialized
INFO - 2016-09-24 16:56:54 --> Security Class Initialized
DEBUG - 2016-09-24 16:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:56:54 --> Input Class Initialized
INFO - 2016-09-24 16:56:54 --> Language Class Initialized
INFO - 2016-09-24 16:56:54 --> Language Class Initialized
INFO - 2016-09-24 16:56:54 --> Config Class Initialized
INFO - 2016-09-24 16:56:54 --> Loader Class Initialized
INFO - 2016-09-24 16:56:54 --> Helper loaded: url_helper
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 16:56:54 --> Controller Class Initialized
DEBUG - 2016-09-24 16:56:54 --> Index MX_Controller Initialized
INFO - 2016-09-24 16:56:54 --> Model Class Initialized
INFO - 2016-09-24 16:56:54 --> Model Class Initialized
ERROR - 2016-09-24 16:56:54 --> Unable to delete cache file for 
DEBUG - 2016-09-24 16:56:54 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-24 16:56:54 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-24 16:56:54 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-24 16:56:54 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-24 16:56:54 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-24 16:56:54 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
DEBUG - 2016-09-24 16:56:54 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-24 16:56:54 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-24 16:56:54 --> Final output sent to browser
DEBUG - 2016-09-24 16:56:54 --> Total execution time: 0.1234
INFO - 2016-09-24 16:56:54 --> Config Class Initialized
INFO - 2016-09-24 16:56:54 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:56:54 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:56:54 --> Utf8 Class Initialized
INFO - 2016-09-24 16:56:54 --> URI Class Initialized
INFO - 2016-09-24 16:56:54 --> Router Class Initialized
INFO - 2016-09-24 16:56:54 --> Output Class Initialized
INFO - 2016-09-24 16:56:54 --> Security Class Initialized
DEBUG - 2016-09-24 16:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:56:54 --> Input Class Initialized
INFO - 2016-09-24 16:56:54 --> Language Class Initialized
INFO - 2016-09-24 16:56:54 --> Language Class Initialized
INFO - 2016-09-24 16:56:54 --> Config Class Initialized
INFO - 2016-09-24 16:56:54 --> Loader Class Initialized
INFO - 2016-09-24 16:56:54 --> Helper loaded: url_helper
INFO - 2016-09-24 16:56:54 --> Database Driver Class Initialized
INFO - 2016-09-24 16:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 16:56:54 --> Controller Class Initialized
DEBUG - 2016-09-24 16:56:54 --> login MX_Controller Initialized
INFO - 2016-09-24 16:56:54 --> Model Class Initialized
INFO - 2016-09-24 16:56:54 --> Model Class Initialized
DEBUG - 2016-09-24 16:56:54 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-24 16:56:54 --> Final output sent to browser
DEBUG - 2016-09-24 16:56:54 --> Total execution time: 0.0298
INFO - 2016-09-24 18:14:28 --> Config Class Initialized
INFO - 2016-09-24 18:14:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:14:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:14:28 --> Utf8 Class Initialized
INFO - 2016-09-24 18:14:28 --> URI Class Initialized
INFO - 2016-09-24 18:14:28 --> Router Class Initialized
INFO - 2016-09-24 18:14:28 --> Output Class Initialized
INFO - 2016-09-24 18:14:28 --> Security Class Initialized
DEBUG - 2016-09-24 18:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:14:28 --> Input Class Initialized
INFO - 2016-09-24 18:14:28 --> Language Class Initialized
ERROR - 2016-09-24 18:14:28 --> 404 Page Not Found: /index
INFO - 2016-09-24 18:14:28 --> Config Class Initialized
INFO - 2016-09-24 18:14:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:14:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:14:28 --> Utf8 Class Initialized
INFO - 2016-09-24 18:14:28 --> URI Class Initialized
INFO - 2016-09-24 18:14:28 --> Router Class Initialized
INFO - 2016-09-24 18:14:28 --> Output Class Initialized
INFO - 2016-09-24 18:14:28 --> Security Class Initialized
DEBUG - 2016-09-24 18:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:14:28 --> Input Class Initialized
INFO - 2016-09-24 18:14:28 --> Language Class Initialized
ERROR - 2016-09-24 18:14:28 --> 404 Page Not Found: /index
INFO - 2016-09-24 18:14:29 --> Config Class Initialized
INFO - 2016-09-24 18:14:29 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:14:29 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:14:29 --> Utf8 Class Initialized
INFO - 2016-09-24 18:14:29 --> URI Class Initialized
INFO - 2016-09-24 18:14:29 --> Router Class Initialized
INFO - 2016-09-24 18:14:29 --> Output Class Initialized
INFO - 2016-09-24 18:14:29 --> Security Class Initialized
DEBUG - 2016-09-24 18:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:14:29 --> Input Class Initialized
INFO - 2016-09-24 18:14:29 --> Language Class Initialized
ERROR - 2016-09-24 18:14:29 --> 404 Page Not Found: /index
INFO - 2016-09-24 18:28:19 --> Config Class Initialized
INFO - 2016-09-24 18:28:19 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:28:19 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:28:19 --> Utf8 Class Initialized
INFO - 2016-09-24 18:28:19 --> URI Class Initialized
DEBUG - 2016-09-24 18:28:19 --> No URI present. Default controller set.
INFO - 2016-09-24 18:28:19 --> Router Class Initialized
INFO - 2016-09-24 18:28:19 --> Output Class Initialized
INFO - 2016-09-24 18:28:19 --> Security Class Initialized
DEBUG - 2016-09-24 18:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:28:19 --> Input Class Initialized
INFO - 2016-09-24 18:28:19 --> Language Class Initialized
INFO - 2016-09-24 18:28:19 --> Language Class Initialized
INFO - 2016-09-24 18:28:19 --> Config Class Initialized
INFO - 2016-09-24 18:28:19 --> Loader Class Initialized
INFO - 2016-09-24 18:28:19 --> Helper loaded: url_helper
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 18:28:19 --> Controller Class Initialized
DEBUG - 2016-09-24 18:28:19 --> Index MX_Controller Initialized
INFO - 2016-09-24 18:28:19 --> Model Class Initialized
INFO - 2016-09-24 18:28:19 --> Model Class Initialized
ERROR - 2016-09-24 18:28:19 --> Unable to delete cache file for 
DEBUG - 2016-09-24 18:28:19 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-24 18:28:19 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-24 18:28:19 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-24 18:28:19 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-24 18:28:19 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-24 18:28:19 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
DEBUG - 2016-09-24 18:28:19 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-24 18:28:19 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-24 18:28:19 --> Final output sent to browser
DEBUG - 2016-09-24 18:28:19 --> Total execution time: 0.1688
INFO - 2016-09-24 18:28:19 --> Config Class Initialized
INFO - 2016-09-24 18:28:19 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:28:19 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:28:19 --> Utf8 Class Initialized
INFO - 2016-09-24 18:28:19 --> URI Class Initialized
INFO - 2016-09-24 18:28:19 --> Router Class Initialized
INFO - 2016-09-24 18:28:19 --> Output Class Initialized
INFO - 2016-09-24 18:28:19 --> Security Class Initialized
DEBUG - 2016-09-24 18:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:28:19 --> Input Class Initialized
INFO - 2016-09-24 18:28:19 --> Language Class Initialized
INFO - 2016-09-24 18:28:19 --> Language Class Initialized
INFO - 2016-09-24 18:28:19 --> Config Class Initialized
INFO - 2016-09-24 18:28:19 --> Loader Class Initialized
INFO - 2016-09-24 18:28:19 --> Helper loaded: url_helper
INFO - 2016-09-24 18:28:19 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 18:28:19 --> Controller Class Initialized
DEBUG - 2016-09-24 18:28:19 --> login MX_Controller Initialized
INFO - 2016-09-24 18:28:19 --> Model Class Initialized
INFO - 2016-09-24 18:28:19 --> Model Class Initialized
DEBUG - 2016-09-24 18:28:19 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-24 18:28:19 --> Final output sent to browser
DEBUG - 2016-09-24 18:28:19 --> Total execution time: 0.0373
INFO - 2016-09-24 18:28:20 --> Config Class Initialized
INFO - 2016-09-24 18:28:20 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:28:20 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:28:20 --> Utf8 Class Initialized
INFO - 2016-09-24 18:28:20 --> URI Class Initialized
DEBUG - 2016-09-24 18:28:20 --> No URI present. Default controller set.
INFO - 2016-09-24 18:28:20 --> Router Class Initialized
INFO - 2016-09-24 18:28:20 --> Output Class Initialized
INFO - 2016-09-24 18:28:20 --> Security Class Initialized
DEBUG - 2016-09-24 18:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:28:20 --> Input Class Initialized
INFO - 2016-09-24 18:28:20 --> Language Class Initialized
INFO - 2016-09-24 18:28:20 --> Language Class Initialized
INFO - 2016-09-24 18:28:20 --> Config Class Initialized
INFO - 2016-09-24 18:28:20 --> Loader Class Initialized
INFO - 2016-09-24 18:28:20 --> Helper loaded: url_helper
INFO - 2016-09-24 18:28:20 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 18:28:20 --> Controller Class Initialized
DEBUG - 2016-09-24 18:28:20 --> Index MX_Controller Initialized
INFO - 2016-09-24 18:28:20 --> Model Class Initialized
INFO - 2016-09-24 18:28:20 --> Model Class Initialized
ERROR - 2016-09-24 18:28:20 --> Unable to delete cache file for 
DEBUG - 2016-09-24 18:28:20 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-24 18:28:20 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-24 18:28:20 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-24 18:28:20 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-24 18:28:20 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-24 18:28:20 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-24 18:28:20 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:20 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:20 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:20 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:20 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:20 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:20 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:20 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:20 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:20 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:20 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:20 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:20 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:20 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:20 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:20 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:20 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:20 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:20 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:20 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:20 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:20 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:20 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:20 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:20 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:20 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:20 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:20 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:20 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:20 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:20 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:20 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:20 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:20 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:20 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:20 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:20 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:20 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:20 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:20 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:21 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:21 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:21 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:21 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:21 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:21 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:21 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:21 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:21 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:21 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:21 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:21 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:21 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:21 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:21 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:21 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:21 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:21 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:21 --> Database Driver Class Initialized
DEBUG - 2016-09-24 18:28:21 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-24 18:28:21 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-24 18:28:21 --> Final output sent to browser
DEBUG - 2016-09-24 18:28:21 --> Total execution time: 0.1452
INFO - 2016-09-24 18:28:21 --> Config Class Initialized
INFO - 2016-09-24 18:28:21 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:28:21 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:28:21 --> Utf8 Class Initialized
INFO - 2016-09-24 18:28:21 --> URI Class Initialized
INFO - 2016-09-24 18:28:21 --> Router Class Initialized
INFO - 2016-09-24 18:28:21 --> Output Class Initialized
INFO - 2016-09-24 18:28:21 --> Security Class Initialized
DEBUG - 2016-09-24 18:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:28:21 --> Input Class Initialized
INFO - 2016-09-24 18:28:21 --> Language Class Initialized
INFO - 2016-09-24 18:28:21 --> Language Class Initialized
INFO - 2016-09-24 18:28:21 --> Config Class Initialized
INFO - 2016-09-24 18:28:21 --> Loader Class Initialized
INFO - 2016-09-24 18:28:21 --> Helper loaded: url_helper
INFO - 2016-09-24 18:28:21 --> Database Driver Class Initialized
INFO - 2016-09-24 18:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 18:28:21 --> Controller Class Initialized
DEBUG - 2016-09-24 18:28:21 --> login MX_Controller Initialized
INFO - 2016-09-24 18:28:21 --> Model Class Initialized
INFO - 2016-09-24 18:28:21 --> Model Class Initialized
DEBUG - 2016-09-24 18:28:21 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-24 18:28:21 --> Final output sent to browser
DEBUG - 2016-09-24 18:28:21 --> Total execution time: 0.0376
INFO - 2016-09-24 21:45:37 --> Config Class Initialized
INFO - 2016-09-24 21:45:37 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:45:37 --> UTF-8 Support Enabled
INFO - 2016-09-24 21:45:37 --> Utf8 Class Initialized
INFO - 2016-09-24 21:45:37 --> URI Class Initialized
DEBUG - 2016-09-24 21:45:37 --> No URI present. Default controller set.
INFO - 2016-09-24 21:45:37 --> Router Class Initialized
INFO - 2016-09-24 21:45:37 --> Output Class Initialized
INFO - 2016-09-24 21:45:37 --> Security Class Initialized
DEBUG - 2016-09-24 21:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 21:45:37 --> Input Class Initialized
INFO - 2016-09-24 21:45:37 --> Language Class Initialized
INFO - 2016-09-24 21:45:37 --> Language Class Initialized
INFO - 2016-09-24 21:45:37 --> Config Class Initialized
INFO - 2016-09-24 21:45:37 --> Loader Class Initialized
INFO - 2016-09-24 21:45:37 --> Helper loaded: url_helper
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 21:45:37 --> Controller Class Initialized
DEBUG - 2016-09-24 21:45:37 --> Index MX_Controller Initialized
INFO - 2016-09-24 21:45:37 --> Model Class Initialized
INFO - 2016-09-24 21:45:37 --> Model Class Initialized
ERROR - 2016-09-24 21:45:37 --> Unable to delete cache file for 
DEBUG - 2016-09-24 21:45:37 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-24 21:45:37 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-24 21:45:37 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-24 21:45:37 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-24 21:45:37 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-24 21:45:37 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
DEBUG - 2016-09-24 21:45:37 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-24 21:45:37 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-24 21:45:37 --> Final output sent to browser
DEBUG - 2016-09-24 21:45:37 --> Total execution time: 0.1534
INFO - 2016-09-24 21:45:37 --> Config Class Initialized
INFO - 2016-09-24 21:45:37 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:45:37 --> UTF-8 Support Enabled
INFO - 2016-09-24 21:45:37 --> Utf8 Class Initialized
INFO - 2016-09-24 21:45:37 --> URI Class Initialized
INFO - 2016-09-24 21:45:37 --> Router Class Initialized
INFO - 2016-09-24 21:45:37 --> Output Class Initialized
INFO - 2016-09-24 21:45:37 --> Security Class Initialized
DEBUG - 2016-09-24 21:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 21:45:37 --> Input Class Initialized
INFO - 2016-09-24 21:45:37 --> Language Class Initialized
INFO - 2016-09-24 21:45:37 --> Language Class Initialized
INFO - 2016-09-24 21:45:37 --> Config Class Initialized
INFO - 2016-09-24 21:45:37 --> Loader Class Initialized
INFO - 2016-09-24 21:45:37 --> Helper loaded: url_helper
INFO - 2016-09-24 21:45:37 --> Database Driver Class Initialized
INFO - 2016-09-24 21:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 21:45:37 --> Controller Class Initialized
DEBUG - 2016-09-24 21:45:37 --> login MX_Controller Initialized
INFO - 2016-09-24 21:45:37 --> Model Class Initialized
INFO - 2016-09-24 21:45:37 --> Model Class Initialized
DEBUG - 2016-09-24 21:45:37 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-24 21:45:37 --> Final output sent to browser
DEBUG - 2016-09-24 21:45:37 --> Total execution time: 0.0354
