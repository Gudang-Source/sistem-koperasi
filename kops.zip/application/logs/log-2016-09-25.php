<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-09-25 02:06:16 --> Config Class Initialized
INFO - 2016-09-25 02:06:16 --> Hooks Class Initialized
DEBUG - 2016-09-25 02:06:16 --> UTF-8 Support Enabled
INFO - 2016-09-25 02:06:16 --> Utf8 Class Initialized
INFO - 2016-09-25 02:06:16 --> URI Class Initialized
DEBUG - 2016-09-25 02:06:16 --> No URI present. Default controller set.
INFO - 2016-09-25 02:06:16 --> Router Class Initialized
INFO - 2016-09-25 02:06:16 --> Output Class Initialized
INFO - 2016-09-25 02:06:16 --> Security Class Initialized
DEBUG - 2016-09-25 02:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 02:06:16 --> Input Class Initialized
INFO - 2016-09-25 02:06:16 --> Language Class Initialized
INFO - 2016-09-25 02:06:16 --> Language Class Initialized
INFO - 2016-09-25 02:06:16 --> Config Class Initialized
INFO - 2016-09-25 02:06:16 --> Loader Class Initialized
INFO - 2016-09-25 02:06:16 --> Helper loaded: url_helper
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-25 02:06:16 --> Controller Class Initialized
DEBUG - 2016-09-25 02:06:16 --> Index MX_Controller Initialized
INFO - 2016-09-25 02:06:16 --> Model Class Initialized
INFO - 2016-09-25 02:06:16 --> Model Class Initialized
ERROR - 2016-09-25 02:06:16 --> Unable to delete cache file for 
DEBUG - 2016-09-25 02:06:16 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-25 02:06:16 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-25 02:06:16 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-25 02:06:16 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-25 02:06:16 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-25 02:06:16 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:16 --> Database Driver Class Initialized
DEBUG - 2016-09-25 02:06:16 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-25 02:06:16 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-25 02:06:16 --> Final output sent to browser
DEBUG - 2016-09-25 02:06:16 --> Total execution time: 0.1674
INFO - 2016-09-25 02:06:18 --> Config Class Initialized
INFO - 2016-09-25 02:06:18 --> Hooks Class Initialized
DEBUG - 2016-09-25 02:06:18 --> UTF-8 Support Enabled
INFO - 2016-09-25 02:06:18 --> Utf8 Class Initialized
INFO - 2016-09-25 02:06:18 --> URI Class Initialized
INFO - 2016-09-25 02:06:18 --> Router Class Initialized
INFO - 2016-09-25 02:06:18 --> Output Class Initialized
INFO - 2016-09-25 02:06:18 --> Security Class Initialized
DEBUG - 2016-09-25 02:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 02:06:18 --> Input Class Initialized
INFO - 2016-09-25 02:06:18 --> Language Class Initialized
INFO - 2016-09-25 02:06:18 --> Language Class Initialized
INFO - 2016-09-25 02:06:18 --> Config Class Initialized
INFO - 2016-09-25 02:06:18 --> Loader Class Initialized
INFO - 2016-09-25 02:06:18 --> Helper loaded: url_helper
INFO - 2016-09-25 02:06:18 --> Database Driver Class Initialized
INFO - 2016-09-25 02:06:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-25 02:06:18 --> Controller Class Initialized
DEBUG - 2016-09-25 02:06:18 --> login MX_Controller Initialized
INFO - 2016-09-25 02:06:18 --> Model Class Initialized
INFO - 2016-09-25 02:06:18 --> Model Class Initialized
DEBUG - 2016-09-25 02:06:18 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-25 02:06:18 --> Final output sent to browser
DEBUG - 2016-09-25 02:06:18 --> Total execution time: 0.0264
INFO - 2016-09-25 04:11:00 --> Config Class Initialized
INFO - 2016-09-25 04:11:00 --> Hooks Class Initialized
DEBUG - 2016-09-25 04:11:00 --> UTF-8 Support Enabled
INFO - 2016-09-25 04:11:00 --> Utf8 Class Initialized
INFO - 2016-09-25 04:11:00 --> URI Class Initialized
DEBUG - 2016-09-25 04:11:00 --> No URI present. Default controller set.
INFO - 2016-09-25 04:11:00 --> Router Class Initialized
INFO - 2016-09-25 04:11:00 --> Output Class Initialized
INFO - 2016-09-25 04:11:00 --> Security Class Initialized
DEBUG - 2016-09-25 04:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 04:11:00 --> Input Class Initialized
INFO - 2016-09-25 04:11:00 --> Language Class Initialized
INFO - 2016-09-25 04:11:00 --> Language Class Initialized
INFO - 2016-09-25 04:11:00 --> Config Class Initialized
INFO - 2016-09-25 04:11:00 --> Loader Class Initialized
INFO - 2016-09-25 04:11:00 --> Helper loaded: url_helper
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-25 04:11:00 --> Controller Class Initialized
DEBUG - 2016-09-25 04:11:00 --> Index MX_Controller Initialized
INFO - 2016-09-25 04:11:00 --> Model Class Initialized
INFO - 2016-09-25 04:11:00 --> Model Class Initialized
ERROR - 2016-09-25 04:11:00 --> Unable to delete cache file for 
DEBUG - 2016-09-25 04:11:00 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-25 04:11:00 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-25 04:11:00 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-25 04:11:00 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-25 04:11:00 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-25 04:11:00 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
INFO - 2016-09-25 04:11:00 --> Database Driver Class Initialized
DEBUG - 2016-09-25 04:11:00 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-25 04:11:00 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-25 04:11:00 --> Final output sent to browser
DEBUG - 2016-09-25 04:11:00 --> Total execution time: 0.1331
INFO - 2016-09-25 07:53:44 --> Config Class Initialized
INFO - 2016-09-25 07:53:44 --> Hooks Class Initialized
DEBUG - 2016-09-25 07:53:44 --> UTF-8 Support Enabled
INFO - 2016-09-25 07:53:44 --> Utf8 Class Initialized
INFO - 2016-09-25 07:53:44 --> URI Class Initialized
INFO - 2016-09-25 07:53:44 --> Router Class Initialized
INFO - 2016-09-25 07:53:44 --> Output Class Initialized
INFO - 2016-09-25 07:53:44 --> Security Class Initialized
DEBUG - 2016-09-25 07:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 07:53:44 --> Input Class Initialized
INFO - 2016-09-25 07:53:44 --> Language Class Initialized
ERROR - 2016-09-25 07:53:44 --> 404 Page Not Found: /index
INFO - 2016-09-25 07:54:01 --> Config Class Initialized
INFO - 2016-09-25 07:54:01 --> Hooks Class Initialized
DEBUG - 2016-09-25 07:54:01 --> UTF-8 Support Enabled
INFO - 2016-09-25 07:54:01 --> Utf8 Class Initialized
INFO - 2016-09-25 07:54:01 --> URI Class Initialized
DEBUG - 2016-09-25 07:54:01 --> No URI present. Default controller set.
INFO - 2016-09-25 07:54:01 --> Router Class Initialized
INFO - 2016-09-25 07:54:01 --> Output Class Initialized
INFO - 2016-09-25 07:54:01 --> Security Class Initialized
DEBUG - 2016-09-25 07:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 07:54:01 --> Input Class Initialized
INFO - 2016-09-25 07:54:01 --> Language Class Initialized
INFO - 2016-09-25 07:54:01 --> Language Class Initialized
INFO - 2016-09-25 07:54:01 --> Config Class Initialized
INFO - 2016-09-25 07:54:01 --> Loader Class Initialized
INFO - 2016-09-25 07:54:01 --> Helper loaded: url_helper
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-25 07:54:01 --> Controller Class Initialized
DEBUG - 2016-09-25 07:54:01 --> Index MX_Controller Initialized
INFO - 2016-09-25 07:54:01 --> Model Class Initialized
INFO - 2016-09-25 07:54:01 --> Model Class Initialized
ERROR - 2016-09-25 07:54:01 --> Unable to delete cache file for 
DEBUG - 2016-09-25 07:54:01 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-25 07:54:01 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-25 07:54:01 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-25 07:54:01 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-25 07:54:01 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-25 07:54:01 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:01 --> Database Driver Class Initialized
DEBUG - 2016-09-25 07:54:01 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-25 07:54:01 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-25 07:54:01 --> Final output sent to browser
DEBUG - 2016-09-25 07:54:01 --> Total execution time: 0.2111
INFO - 2016-09-25 07:54:09 --> Config Class Initialized
INFO - 2016-09-25 07:54:09 --> Hooks Class Initialized
DEBUG - 2016-09-25 07:54:09 --> UTF-8 Support Enabled
INFO - 2016-09-25 07:54:09 --> Utf8 Class Initialized
INFO - 2016-09-25 07:54:09 --> URI Class Initialized
INFO - 2016-09-25 07:54:09 --> Router Class Initialized
INFO - 2016-09-25 07:54:09 --> Output Class Initialized
INFO - 2016-09-25 07:54:09 --> Security Class Initialized
DEBUG - 2016-09-25 07:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 07:54:09 --> Input Class Initialized
INFO - 2016-09-25 07:54:09 --> Language Class Initialized
INFO - 2016-09-25 07:54:09 --> Language Class Initialized
INFO - 2016-09-25 07:54:09 --> Config Class Initialized
INFO - 2016-09-25 07:54:09 --> Loader Class Initialized
INFO - 2016-09-25 07:54:09 --> Helper loaded: url_helper
INFO - 2016-09-25 07:54:09 --> Database Driver Class Initialized
INFO - 2016-09-25 07:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-25 07:54:09 --> Controller Class Initialized
DEBUG - 2016-09-25 07:54:09 --> login MX_Controller Initialized
INFO - 2016-09-25 07:54:09 --> Model Class Initialized
INFO - 2016-09-25 07:54:09 --> Model Class Initialized
DEBUG - 2016-09-25 07:54:09 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-25 07:54:09 --> Final output sent to browser
DEBUG - 2016-09-25 07:54:09 --> Total execution time: 0.0222
INFO - 2016-09-25 09:32:26 --> Config Class Initialized
INFO - 2016-09-25 09:32:26 --> Hooks Class Initialized
DEBUG - 2016-09-25 09:32:26 --> UTF-8 Support Enabled
INFO - 2016-09-25 09:32:26 --> Utf8 Class Initialized
INFO - 2016-09-25 09:32:26 --> URI Class Initialized
DEBUG - 2016-09-25 09:32:26 --> No URI present. Default controller set.
INFO - 2016-09-25 09:32:26 --> Router Class Initialized
INFO - 2016-09-25 09:32:26 --> Output Class Initialized
INFO - 2016-09-25 09:32:26 --> Security Class Initialized
DEBUG - 2016-09-25 09:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 09:32:26 --> Input Class Initialized
INFO - 2016-09-25 09:32:26 --> Language Class Initialized
INFO - 2016-09-25 09:32:26 --> Language Class Initialized
INFO - 2016-09-25 09:32:26 --> Config Class Initialized
INFO - 2016-09-25 09:32:26 --> Loader Class Initialized
INFO - 2016-09-25 09:32:26 --> Helper loaded: url_helper
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-25 09:32:26 --> Controller Class Initialized
DEBUG - 2016-09-25 09:32:26 --> Index MX_Controller Initialized
INFO - 2016-09-25 09:32:26 --> Model Class Initialized
INFO - 2016-09-25 09:32:26 --> Model Class Initialized
ERROR - 2016-09-25 09:32:26 --> Unable to delete cache file for 
DEBUG - 2016-09-25 09:32:26 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-25 09:32:26 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-25 09:32:26 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-25 09:32:26 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-25 09:32:26 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-25 09:32:26 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:26 --> Database Driver Class Initialized
DEBUG - 2016-09-25 09:32:26 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-25 09:32:26 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-25 09:32:26 --> Final output sent to browser
DEBUG - 2016-09-25 09:32:26 --> Total execution time: 0.1342
INFO - 2016-09-25 09:32:27 --> Config Class Initialized
INFO - 2016-09-25 09:32:27 --> Hooks Class Initialized
DEBUG - 2016-09-25 09:32:27 --> UTF-8 Support Enabled
INFO - 2016-09-25 09:32:27 --> Utf8 Class Initialized
INFO - 2016-09-25 09:32:27 --> URI Class Initialized
INFO - 2016-09-25 09:32:27 --> Router Class Initialized
INFO - 2016-09-25 09:32:27 --> Output Class Initialized
INFO - 2016-09-25 09:32:27 --> Security Class Initialized
DEBUG - 2016-09-25 09:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 09:32:27 --> Input Class Initialized
INFO - 2016-09-25 09:32:27 --> Language Class Initialized
INFO - 2016-09-25 09:32:27 --> Language Class Initialized
INFO - 2016-09-25 09:32:27 --> Config Class Initialized
INFO - 2016-09-25 09:32:27 --> Loader Class Initialized
INFO - 2016-09-25 09:32:27 --> Helper loaded: url_helper
INFO - 2016-09-25 09:32:27 --> Database Driver Class Initialized
INFO - 2016-09-25 09:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-25 09:32:27 --> Controller Class Initialized
DEBUG - 2016-09-25 09:32:27 --> login MX_Controller Initialized
INFO - 2016-09-25 09:32:27 --> Model Class Initialized
INFO - 2016-09-25 09:32:27 --> Model Class Initialized
DEBUG - 2016-09-25 09:32:27 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-25 09:32:27 --> Final output sent to browser
DEBUG - 2016-09-25 09:32:27 --> Total execution time: 0.0253
INFO - 2016-09-25 12:00:46 --> Config Class Initialized
INFO - 2016-09-25 12:00:46 --> Hooks Class Initialized
DEBUG - 2016-09-25 12:00:46 --> UTF-8 Support Enabled
INFO - 2016-09-25 12:00:46 --> Utf8 Class Initialized
INFO - 2016-09-25 12:00:46 --> URI Class Initialized
DEBUG - 2016-09-25 12:00:46 --> No URI present. Default controller set.
INFO - 2016-09-25 12:00:46 --> Router Class Initialized
INFO - 2016-09-25 12:00:46 --> Output Class Initialized
INFO - 2016-09-25 12:00:46 --> Security Class Initialized
DEBUG - 2016-09-25 12:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 12:00:46 --> Input Class Initialized
INFO - 2016-09-25 12:00:46 --> Language Class Initialized
INFO - 2016-09-25 12:00:46 --> Language Class Initialized
INFO - 2016-09-25 12:00:46 --> Config Class Initialized
INFO - 2016-09-25 12:00:46 --> Loader Class Initialized
INFO - 2016-09-25 12:00:46 --> Helper loaded: url_helper
INFO - 2016-09-25 12:00:46 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-25 12:00:46 --> Controller Class Initialized
DEBUG - 2016-09-25 12:00:46 --> Index MX_Controller Initialized
INFO - 2016-09-25 12:00:46 --> Model Class Initialized
INFO - 2016-09-25 12:00:46 --> Model Class Initialized
ERROR - 2016-09-25 12:00:46 --> Unable to delete cache file for 
DEBUG - 2016-09-25 12:00:46 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-25 12:00:46 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-25 12:00:46 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-25 12:00:46 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-25 12:00:46 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-25 12:00:46 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-25 12:00:46 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:46 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:46 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:46 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:46 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:46 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:47 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:47 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:47 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:47 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:47 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:47 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:47 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:47 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:47 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:47 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:47 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:47 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:47 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:47 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:47 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:47 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:47 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:47 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:47 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:47 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:47 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:47 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:47 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:47 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:47 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:47 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:47 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:47 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:47 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:47 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:47 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:47 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:47 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:47 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:47 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:47 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:47 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:47 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:47 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:47 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:47 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:47 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:47 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:47 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:47 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:47 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:47 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:47 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:47 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:47 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:47 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:47 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:47 --> Database Driver Class Initialized
DEBUG - 2016-09-25 12:00:47 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-25 12:00:47 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-25 12:00:47 --> Final output sent to browser
DEBUG - 2016-09-25 12:00:47 --> Total execution time: 0.1056
INFO - 2016-09-25 12:00:47 --> Config Class Initialized
INFO - 2016-09-25 12:00:47 --> Hooks Class Initialized
DEBUG - 2016-09-25 12:00:47 --> UTF-8 Support Enabled
INFO - 2016-09-25 12:00:47 --> Utf8 Class Initialized
INFO - 2016-09-25 12:00:47 --> URI Class Initialized
INFO - 2016-09-25 12:00:47 --> Router Class Initialized
INFO - 2016-09-25 12:00:47 --> Output Class Initialized
INFO - 2016-09-25 12:00:47 --> Security Class Initialized
DEBUG - 2016-09-25 12:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 12:00:47 --> Input Class Initialized
INFO - 2016-09-25 12:00:47 --> Language Class Initialized
INFO - 2016-09-25 12:00:47 --> Language Class Initialized
INFO - 2016-09-25 12:00:47 --> Config Class Initialized
INFO - 2016-09-25 12:00:47 --> Loader Class Initialized
INFO - 2016-09-25 12:00:47 --> Helper loaded: url_helper
INFO - 2016-09-25 12:00:47 --> Database Driver Class Initialized
INFO - 2016-09-25 12:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-25 12:00:47 --> Controller Class Initialized
DEBUG - 2016-09-25 12:00:47 --> login MX_Controller Initialized
INFO - 2016-09-25 12:00:47 --> Model Class Initialized
INFO - 2016-09-25 12:00:47 --> Model Class Initialized
DEBUG - 2016-09-25 12:00:47 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-25 12:00:47 --> Final output sent to browser
DEBUG - 2016-09-25 12:00:47 --> Total execution time: 0.0234
INFO - 2016-09-25 12:12:53 --> Config Class Initialized
INFO - 2016-09-25 12:12:53 --> Hooks Class Initialized
DEBUG - 2016-09-25 12:12:53 --> UTF-8 Support Enabled
INFO - 2016-09-25 12:12:53 --> Utf8 Class Initialized
INFO - 2016-09-25 12:12:53 --> URI Class Initialized
DEBUG - 2016-09-25 12:12:53 --> No URI present. Default controller set.
INFO - 2016-09-25 12:12:53 --> Router Class Initialized
INFO - 2016-09-25 12:12:53 --> Output Class Initialized
INFO - 2016-09-25 12:12:53 --> Security Class Initialized
DEBUG - 2016-09-25 12:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 12:12:53 --> Input Class Initialized
INFO - 2016-09-25 12:12:53 --> Language Class Initialized
INFO - 2016-09-25 12:12:53 --> Language Class Initialized
INFO - 2016-09-25 12:12:53 --> Config Class Initialized
INFO - 2016-09-25 12:12:53 --> Loader Class Initialized
INFO - 2016-09-25 12:12:53 --> Helper loaded: url_helper
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-25 12:12:53 --> Controller Class Initialized
DEBUG - 2016-09-25 12:12:53 --> Index MX_Controller Initialized
INFO - 2016-09-25 12:12:53 --> Model Class Initialized
INFO - 2016-09-25 12:12:53 --> Model Class Initialized
ERROR - 2016-09-25 12:12:53 --> Unable to delete cache file for 
DEBUG - 2016-09-25 12:12:53 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-25 12:12:53 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-25 12:12:53 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-25 12:12:53 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-25 12:12:53 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-25 12:12:53 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:53 --> Database Driver Class Initialized
DEBUG - 2016-09-25 12:12:53 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-25 12:12:53 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-25 12:12:53 --> Final output sent to browser
DEBUG - 2016-09-25 12:12:53 --> Total execution time: 0.0817
INFO - 2016-09-25 12:12:54 --> Config Class Initialized
INFO - 2016-09-25 12:12:54 --> Hooks Class Initialized
DEBUG - 2016-09-25 12:12:54 --> UTF-8 Support Enabled
INFO - 2016-09-25 12:12:54 --> Utf8 Class Initialized
INFO - 2016-09-25 12:12:54 --> URI Class Initialized
INFO - 2016-09-25 12:12:54 --> Router Class Initialized
INFO - 2016-09-25 12:12:54 --> Output Class Initialized
INFO - 2016-09-25 12:12:54 --> Security Class Initialized
DEBUG - 2016-09-25 12:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 12:12:54 --> Input Class Initialized
INFO - 2016-09-25 12:12:54 --> Language Class Initialized
INFO - 2016-09-25 12:12:54 --> Language Class Initialized
INFO - 2016-09-25 12:12:54 --> Config Class Initialized
INFO - 2016-09-25 12:12:54 --> Loader Class Initialized
INFO - 2016-09-25 12:12:54 --> Helper loaded: url_helper
INFO - 2016-09-25 12:12:54 --> Database Driver Class Initialized
INFO - 2016-09-25 12:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-25 12:12:54 --> Controller Class Initialized
DEBUG - 2016-09-25 12:12:54 --> login MX_Controller Initialized
INFO - 2016-09-25 12:12:54 --> Model Class Initialized
INFO - 2016-09-25 12:12:54 --> Model Class Initialized
DEBUG - 2016-09-25 12:12:54 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-25 12:12:54 --> Final output sent to browser
DEBUG - 2016-09-25 12:12:54 --> Total execution time: 0.0259
INFO - 2016-09-25 12:27:45 --> Config Class Initialized
INFO - 2016-09-25 12:27:45 --> Hooks Class Initialized
DEBUG - 2016-09-25 12:27:45 --> UTF-8 Support Enabled
INFO - 2016-09-25 12:27:45 --> Utf8 Class Initialized
INFO - 2016-09-25 12:27:45 --> URI Class Initialized
DEBUG - 2016-09-25 12:27:45 --> No URI present. Default controller set.
INFO - 2016-09-25 12:27:45 --> Router Class Initialized
INFO - 2016-09-25 12:27:45 --> Output Class Initialized
INFO - 2016-09-25 12:27:45 --> Security Class Initialized
DEBUG - 2016-09-25 12:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 12:27:45 --> Input Class Initialized
INFO - 2016-09-25 12:27:45 --> Language Class Initialized
INFO - 2016-09-25 12:27:45 --> Language Class Initialized
INFO - 2016-09-25 12:27:45 --> Config Class Initialized
INFO - 2016-09-25 12:27:45 --> Loader Class Initialized
INFO - 2016-09-25 12:27:45 --> Helper loaded: url_helper
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-25 12:27:45 --> Controller Class Initialized
DEBUG - 2016-09-25 12:27:45 --> Index MX_Controller Initialized
INFO - 2016-09-25 12:27:45 --> Model Class Initialized
INFO - 2016-09-25 12:27:45 --> Model Class Initialized
ERROR - 2016-09-25 12:27:45 --> Unable to delete cache file for 
DEBUG - 2016-09-25 12:27:45 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-25 12:27:45 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-25 12:27:45 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-25 12:27:45 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-25 12:27:45 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-25 12:27:45 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
DEBUG - 2016-09-25 12:27:45 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-25 12:27:45 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-25 12:27:45 --> Final output sent to browser
DEBUG - 2016-09-25 12:27:45 --> Total execution time: 0.0963
INFO - 2016-09-25 12:27:45 --> Config Class Initialized
INFO - 2016-09-25 12:27:45 --> Hooks Class Initialized
DEBUG - 2016-09-25 12:27:45 --> UTF-8 Support Enabled
INFO - 2016-09-25 12:27:45 --> Utf8 Class Initialized
INFO - 2016-09-25 12:27:45 --> URI Class Initialized
INFO - 2016-09-25 12:27:45 --> Router Class Initialized
INFO - 2016-09-25 12:27:45 --> Output Class Initialized
INFO - 2016-09-25 12:27:45 --> Security Class Initialized
DEBUG - 2016-09-25 12:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 12:27:45 --> Input Class Initialized
INFO - 2016-09-25 12:27:45 --> Language Class Initialized
INFO - 2016-09-25 12:27:45 --> Language Class Initialized
INFO - 2016-09-25 12:27:45 --> Config Class Initialized
INFO - 2016-09-25 12:27:45 --> Loader Class Initialized
INFO - 2016-09-25 12:27:45 --> Helper loaded: url_helper
INFO - 2016-09-25 12:27:45 --> Database Driver Class Initialized
INFO - 2016-09-25 12:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-25 12:27:45 --> Controller Class Initialized
DEBUG - 2016-09-25 12:27:45 --> login MX_Controller Initialized
INFO - 2016-09-25 12:27:45 --> Model Class Initialized
INFO - 2016-09-25 12:27:45 --> Model Class Initialized
DEBUG - 2016-09-25 12:27:45 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-25 12:27:45 --> Final output sent to browser
DEBUG - 2016-09-25 12:27:45 --> Total execution time: 0.0341
INFO - 2016-09-25 13:14:11 --> Config Class Initialized
INFO - 2016-09-25 13:14:11 --> Hooks Class Initialized
DEBUG - 2016-09-25 13:14:11 --> UTF-8 Support Enabled
INFO - 2016-09-25 13:14:11 --> Utf8 Class Initialized
INFO - 2016-09-25 13:14:11 --> URI Class Initialized
DEBUG - 2016-09-25 13:14:11 --> No URI present. Default controller set.
INFO - 2016-09-25 13:14:11 --> Router Class Initialized
INFO - 2016-09-25 13:14:11 --> Output Class Initialized
INFO - 2016-09-25 13:14:11 --> Security Class Initialized
DEBUG - 2016-09-25 13:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 13:14:11 --> Input Class Initialized
INFO - 2016-09-25 13:14:11 --> Language Class Initialized
INFO - 2016-09-25 13:14:11 --> Language Class Initialized
INFO - 2016-09-25 13:14:11 --> Config Class Initialized
INFO - 2016-09-25 13:14:11 --> Loader Class Initialized
INFO - 2016-09-25 13:14:11 --> Helper loaded: url_helper
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-25 13:14:11 --> Controller Class Initialized
DEBUG - 2016-09-25 13:14:11 --> Index MX_Controller Initialized
INFO - 2016-09-25 13:14:11 --> Model Class Initialized
INFO - 2016-09-25 13:14:11 --> Model Class Initialized
ERROR - 2016-09-25 13:14:11 --> Unable to delete cache file for 
DEBUG - 2016-09-25 13:14:11 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-25 13:14:11 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-25 13:14:11 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-25 13:14:11 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-25 13:14:11 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-25 13:14:11 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
DEBUG - 2016-09-25 13:14:11 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-25 13:14:11 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-25 13:14:11 --> Final output sent to browser
DEBUG - 2016-09-25 13:14:11 --> Total execution time: 0.1247
INFO - 2016-09-25 13:14:11 --> Config Class Initialized
INFO - 2016-09-25 13:14:11 --> Hooks Class Initialized
DEBUG - 2016-09-25 13:14:11 --> UTF-8 Support Enabled
INFO - 2016-09-25 13:14:11 --> Utf8 Class Initialized
INFO - 2016-09-25 13:14:11 --> URI Class Initialized
DEBUG - 2016-09-25 13:14:11 --> No URI present. Default controller set.
INFO - 2016-09-25 13:14:11 --> Router Class Initialized
INFO - 2016-09-25 13:14:11 --> Output Class Initialized
INFO - 2016-09-25 13:14:11 --> Security Class Initialized
DEBUG - 2016-09-25 13:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 13:14:11 --> Input Class Initialized
INFO - 2016-09-25 13:14:11 --> Language Class Initialized
INFO - 2016-09-25 13:14:11 --> Language Class Initialized
INFO - 2016-09-25 13:14:11 --> Config Class Initialized
INFO - 2016-09-25 13:14:11 --> Loader Class Initialized
INFO - 2016-09-25 13:14:11 --> Helper loaded: url_helper
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-25 13:14:11 --> Controller Class Initialized
DEBUG - 2016-09-25 13:14:11 --> Index MX_Controller Initialized
INFO - 2016-09-25 13:14:11 --> Model Class Initialized
INFO - 2016-09-25 13:14:11 --> Model Class Initialized
ERROR - 2016-09-25 13:14:11 --> Unable to delete cache file for 
DEBUG - 2016-09-25 13:14:11 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-25 13:14:11 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-25 13:14:11 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-25 13:14:11 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-25 13:14:11 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-25 13:14:11 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:11 --> Database Driver Class Initialized
DEBUG - 2016-09-25 13:14:11 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-25 13:14:11 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-25 13:14:11 --> Final output sent to browser
DEBUG - 2016-09-25 13:14:11 --> Total execution time: 0.1164
INFO - 2016-09-25 13:14:12 --> Config Class Initialized
INFO - 2016-09-25 13:14:12 --> Hooks Class Initialized
DEBUG - 2016-09-25 13:14:12 --> UTF-8 Support Enabled
INFO - 2016-09-25 13:14:12 --> Utf8 Class Initialized
INFO - 2016-09-25 13:14:12 --> URI Class Initialized
INFO - 2016-09-25 13:14:12 --> Router Class Initialized
INFO - 2016-09-25 13:14:12 --> Output Class Initialized
INFO - 2016-09-25 13:14:12 --> Security Class Initialized
DEBUG - 2016-09-25 13:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 13:14:12 --> Input Class Initialized
INFO - 2016-09-25 13:14:12 --> Language Class Initialized
INFO - 2016-09-25 13:14:12 --> Language Class Initialized
INFO - 2016-09-25 13:14:12 --> Config Class Initialized
INFO - 2016-09-25 13:14:12 --> Loader Class Initialized
INFO - 2016-09-25 13:14:12 --> Helper loaded: url_helper
INFO - 2016-09-25 13:14:12 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-25 13:14:12 --> Controller Class Initialized
DEBUG - 2016-09-25 13:14:12 --> login MX_Controller Initialized
INFO - 2016-09-25 13:14:12 --> Model Class Initialized
INFO - 2016-09-25 13:14:12 --> Model Class Initialized
DEBUG - 2016-09-25 13:14:12 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-25 13:14:12 --> Final output sent to browser
DEBUG - 2016-09-25 13:14:12 --> Total execution time: 0.0284
INFO - 2016-09-25 13:14:12 --> Config Class Initialized
INFO - 2016-09-25 13:14:12 --> Hooks Class Initialized
DEBUG - 2016-09-25 13:14:12 --> UTF-8 Support Enabled
INFO - 2016-09-25 13:14:12 --> Utf8 Class Initialized
INFO - 2016-09-25 13:14:12 --> URI Class Initialized
INFO - 2016-09-25 13:14:12 --> Router Class Initialized
INFO - 2016-09-25 13:14:12 --> Output Class Initialized
INFO - 2016-09-25 13:14:12 --> Security Class Initialized
DEBUG - 2016-09-25 13:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 13:14:12 --> Input Class Initialized
INFO - 2016-09-25 13:14:12 --> Language Class Initialized
INFO - 2016-09-25 13:14:12 --> Language Class Initialized
INFO - 2016-09-25 13:14:12 --> Config Class Initialized
INFO - 2016-09-25 13:14:12 --> Loader Class Initialized
INFO - 2016-09-25 13:14:12 --> Helper loaded: url_helper
INFO - 2016-09-25 13:14:12 --> Database Driver Class Initialized
INFO - 2016-09-25 13:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-25 13:14:12 --> Controller Class Initialized
DEBUG - 2016-09-25 13:14:12 --> login MX_Controller Initialized
INFO - 2016-09-25 13:14:12 --> Model Class Initialized
INFO - 2016-09-25 13:14:12 --> Model Class Initialized
DEBUG - 2016-09-25 13:14:12 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-25 13:14:12 --> Final output sent to browser
DEBUG - 2016-09-25 13:14:12 --> Total execution time: 0.0301
INFO - 2016-09-25 13:26:30 --> Config Class Initialized
INFO - 2016-09-25 13:26:30 --> Hooks Class Initialized
DEBUG - 2016-09-25 13:26:30 --> UTF-8 Support Enabled
INFO - 2016-09-25 13:26:30 --> Utf8 Class Initialized
INFO - 2016-09-25 13:26:30 --> URI Class Initialized
DEBUG - 2016-09-25 13:26:30 --> No URI present. Default controller set.
INFO - 2016-09-25 13:26:30 --> Router Class Initialized
INFO - 2016-09-25 13:26:30 --> Output Class Initialized
INFO - 2016-09-25 13:26:30 --> Security Class Initialized
DEBUG - 2016-09-25 13:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 13:26:30 --> Input Class Initialized
INFO - 2016-09-25 13:26:30 --> Language Class Initialized
INFO - 2016-09-25 13:26:30 --> Language Class Initialized
INFO - 2016-09-25 13:26:30 --> Config Class Initialized
INFO - 2016-09-25 13:26:30 --> Loader Class Initialized
INFO - 2016-09-25 13:26:30 --> Helper loaded: url_helper
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-25 13:26:30 --> Controller Class Initialized
DEBUG - 2016-09-25 13:26:30 --> Index MX_Controller Initialized
INFO - 2016-09-25 13:26:30 --> Model Class Initialized
INFO - 2016-09-25 13:26:30 --> Model Class Initialized
ERROR - 2016-09-25 13:26:30 --> Unable to delete cache file for 
DEBUG - 2016-09-25 13:26:30 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-25 13:26:30 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-25 13:26:30 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-25 13:26:30 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-25 13:26:30 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-25 13:26:30 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
DEBUG - 2016-09-25 13:26:30 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-25 13:26:30 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-25 13:26:30 --> Final output sent to browser
DEBUG - 2016-09-25 13:26:30 --> Total execution time: 0.1225
INFO - 2016-09-25 13:26:30 --> Config Class Initialized
INFO - 2016-09-25 13:26:30 --> Hooks Class Initialized
DEBUG - 2016-09-25 13:26:30 --> UTF-8 Support Enabled
INFO - 2016-09-25 13:26:30 --> Utf8 Class Initialized
INFO - 2016-09-25 13:26:30 --> URI Class Initialized
INFO - 2016-09-25 13:26:30 --> Router Class Initialized
INFO - 2016-09-25 13:26:30 --> Output Class Initialized
INFO - 2016-09-25 13:26:30 --> Security Class Initialized
DEBUG - 2016-09-25 13:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 13:26:30 --> Input Class Initialized
INFO - 2016-09-25 13:26:30 --> Language Class Initialized
INFO - 2016-09-25 13:26:30 --> Language Class Initialized
INFO - 2016-09-25 13:26:30 --> Config Class Initialized
INFO - 2016-09-25 13:26:30 --> Loader Class Initialized
INFO - 2016-09-25 13:26:30 --> Helper loaded: url_helper
INFO - 2016-09-25 13:26:30 --> Database Driver Class Initialized
INFO - 2016-09-25 13:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-25 13:26:30 --> Controller Class Initialized
DEBUG - 2016-09-25 13:26:30 --> login MX_Controller Initialized
INFO - 2016-09-25 13:26:30 --> Model Class Initialized
INFO - 2016-09-25 13:26:30 --> Model Class Initialized
DEBUG - 2016-09-25 13:26:30 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-25 13:26:30 --> Final output sent to browser
DEBUG - 2016-09-25 13:26:30 --> Total execution time: 0.0246
INFO - 2016-09-25 16:35:17 --> Config Class Initialized
INFO - 2016-09-25 16:35:17 --> Hooks Class Initialized
DEBUG - 2016-09-25 16:35:17 --> UTF-8 Support Enabled
INFO - 2016-09-25 16:35:17 --> Utf8 Class Initialized
INFO - 2016-09-25 16:35:17 --> URI Class Initialized
DEBUG - 2016-09-25 16:35:17 --> No URI present. Default controller set.
INFO - 2016-09-25 16:35:17 --> Router Class Initialized
INFO - 2016-09-25 16:35:17 --> Output Class Initialized
INFO - 2016-09-25 16:35:17 --> Security Class Initialized
DEBUG - 2016-09-25 16:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 16:35:17 --> Input Class Initialized
INFO - 2016-09-25 16:35:17 --> Language Class Initialized
INFO - 2016-09-25 16:35:17 --> Language Class Initialized
INFO - 2016-09-25 16:35:17 --> Config Class Initialized
INFO - 2016-09-25 16:35:17 --> Loader Class Initialized
INFO - 2016-09-25 16:35:17 --> Helper loaded: url_helper
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-25 16:35:17 --> Controller Class Initialized
DEBUG - 2016-09-25 16:35:17 --> Index MX_Controller Initialized
INFO - 2016-09-25 16:35:17 --> Model Class Initialized
INFO - 2016-09-25 16:35:17 --> Model Class Initialized
ERROR - 2016-09-25 16:35:17 --> Unable to delete cache file for 
DEBUG - 2016-09-25 16:35:17 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-25 16:35:17 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-25 16:35:17 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-25 16:35:17 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-25 16:35:17 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-25 16:35:17 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
DEBUG - 2016-09-25 16:35:17 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-25 16:35:17 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-25 16:35:17 --> Final output sent to browser
DEBUG - 2016-09-25 16:35:17 --> Total execution time: 0.1458
INFO - 2016-09-25 16:35:17 --> Config Class Initialized
INFO - 2016-09-25 16:35:17 --> Hooks Class Initialized
DEBUG - 2016-09-25 16:35:17 --> UTF-8 Support Enabled
INFO - 2016-09-25 16:35:17 --> Utf8 Class Initialized
INFO - 2016-09-25 16:35:17 --> URI Class Initialized
INFO - 2016-09-25 16:35:17 --> Router Class Initialized
INFO - 2016-09-25 16:35:17 --> Output Class Initialized
INFO - 2016-09-25 16:35:17 --> Security Class Initialized
DEBUG - 2016-09-25 16:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 16:35:17 --> Input Class Initialized
INFO - 2016-09-25 16:35:17 --> Language Class Initialized
INFO - 2016-09-25 16:35:17 --> Language Class Initialized
INFO - 2016-09-25 16:35:17 --> Config Class Initialized
INFO - 2016-09-25 16:35:17 --> Loader Class Initialized
INFO - 2016-09-25 16:35:17 --> Helper loaded: url_helper
INFO - 2016-09-25 16:35:17 --> Database Driver Class Initialized
INFO - 2016-09-25 16:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-25 16:35:17 --> Controller Class Initialized
DEBUG - 2016-09-25 16:35:17 --> login MX_Controller Initialized
INFO - 2016-09-25 16:35:17 --> Model Class Initialized
INFO - 2016-09-25 16:35:17 --> Model Class Initialized
DEBUG - 2016-09-25 16:35:17 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-25 16:35:17 --> Final output sent to browser
DEBUG - 2016-09-25 16:35:17 --> Total execution time: 0.0381
INFO - 2016-09-25 20:45:11 --> Config Class Initialized
INFO - 2016-09-25 20:45:11 --> Hooks Class Initialized
DEBUG - 2016-09-25 20:45:11 --> UTF-8 Support Enabled
INFO - 2016-09-25 20:45:11 --> Utf8 Class Initialized
INFO - 2016-09-25 20:45:11 --> URI Class Initialized
DEBUG - 2016-09-25 20:45:11 --> No URI present. Default controller set.
INFO - 2016-09-25 20:45:11 --> Router Class Initialized
INFO - 2016-09-25 20:45:11 --> Output Class Initialized
INFO - 2016-09-25 20:45:11 --> Security Class Initialized
DEBUG - 2016-09-25 20:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 20:45:11 --> Input Class Initialized
INFO - 2016-09-25 20:45:11 --> Language Class Initialized
INFO - 2016-09-25 20:45:11 --> Language Class Initialized
INFO - 2016-09-25 20:45:11 --> Config Class Initialized
INFO - 2016-09-25 20:45:11 --> Loader Class Initialized
INFO - 2016-09-25 20:45:11 --> Helper loaded: url_helper
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-25 20:45:11 --> Controller Class Initialized
DEBUG - 2016-09-25 20:45:11 --> Index MX_Controller Initialized
INFO - 2016-09-25 20:45:11 --> Model Class Initialized
INFO - 2016-09-25 20:45:11 --> Model Class Initialized
ERROR - 2016-09-25 20:45:11 --> Unable to delete cache file for 
DEBUG - 2016-09-25 20:45:11 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-25 20:45:11 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-25 20:45:11 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-25 20:45:11 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-25 20:45:11 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-25 20:45:11 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:11 --> Database Driver Class Initialized
DEBUG - 2016-09-25 20:45:12 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-25 20:45:12 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-25 20:45:12 --> Final output sent to browser
DEBUG - 2016-09-25 20:45:12 --> Total execution time: 0.1762
INFO - 2016-09-25 20:45:12 --> Config Class Initialized
INFO - 2016-09-25 20:45:12 --> Hooks Class Initialized
DEBUG - 2016-09-25 20:45:12 --> UTF-8 Support Enabled
INFO - 2016-09-25 20:45:12 --> Utf8 Class Initialized
INFO - 2016-09-25 20:45:12 --> URI Class Initialized
INFO - 2016-09-25 20:45:12 --> Router Class Initialized
INFO - 2016-09-25 20:45:12 --> Output Class Initialized
INFO - 2016-09-25 20:45:12 --> Security Class Initialized
DEBUG - 2016-09-25 20:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 20:45:12 --> Input Class Initialized
INFO - 2016-09-25 20:45:12 --> Language Class Initialized
INFO - 2016-09-25 20:45:12 --> Language Class Initialized
INFO - 2016-09-25 20:45:12 --> Config Class Initialized
INFO - 2016-09-25 20:45:12 --> Loader Class Initialized
INFO - 2016-09-25 20:45:12 --> Helper loaded: url_helper
INFO - 2016-09-25 20:45:12 --> Database Driver Class Initialized
INFO - 2016-09-25 20:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-25 20:45:12 --> Controller Class Initialized
DEBUG - 2016-09-25 20:45:12 --> login MX_Controller Initialized
INFO - 2016-09-25 20:45:12 --> Model Class Initialized
INFO - 2016-09-25 20:45:12 --> Model Class Initialized
DEBUG - 2016-09-25 20:45:12 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-25 20:45:12 --> Final output sent to browser
DEBUG - 2016-09-25 20:45:12 --> Total execution time: 0.0296
INFO - 2016-09-25 20:45:12 --> Config Class Initialized
INFO - 2016-09-25 20:45:12 --> Hooks Class Initialized
DEBUG - 2016-09-25 20:45:12 --> UTF-8 Support Enabled
INFO - 2016-09-25 20:45:12 --> Utf8 Class Initialized
INFO - 2016-09-25 20:45:12 --> URI Class Initialized
INFO - 2016-09-25 20:45:12 --> Router Class Initialized
INFO - 2016-09-25 20:45:12 --> Output Class Initialized
INFO - 2016-09-25 20:45:12 --> Security Class Initialized
DEBUG - 2016-09-25 20:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 20:45:12 --> Input Class Initialized
INFO - 2016-09-25 20:45:12 --> Language Class Initialized
ERROR - 2016-09-25 20:45:12 --> 404 Page Not Found: /index
INFO - 2016-09-25 21:58:41 --> Config Class Initialized
INFO - 2016-09-25 21:58:41 --> Hooks Class Initialized
DEBUG - 2016-09-25 21:58:41 --> UTF-8 Support Enabled
INFO - 2016-09-25 21:58:41 --> Utf8 Class Initialized
INFO - 2016-09-25 21:58:41 --> URI Class Initialized
DEBUG - 2016-09-25 21:58:41 --> No URI present. Default controller set.
INFO - 2016-09-25 21:58:41 --> Router Class Initialized
INFO - 2016-09-25 21:58:41 --> Output Class Initialized
INFO - 2016-09-25 21:58:41 --> Security Class Initialized
DEBUG - 2016-09-25 21:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 21:58:41 --> Input Class Initialized
INFO - 2016-09-25 21:58:41 --> Language Class Initialized
INFO - 2016-09-25 21:58:41 --> Language Class Initialized
INFO - 2016-09-25 21:58:41 --> Config Class Initialized
INFO - 2016-09-25 21:58:41 --> Loader Class Initialized
INFO - 2016-09-25 21:58:41 --> Helper loaded: url_helper
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-25 21:58:41 --> Controller Class Initialized
DEBUG - 2016-09-25 21:58:41 --> Index MX_Controller Initialized
INFO - 2016-09-25 21:58:41 --> Model Class Initialized
INFO - 2016-09-25 21:58:41 --> Model Class Initialized
ERROR - 2016-09-25 21:58:41 --> Unable to delete cache file for 
DEBUG - 2016-09-25 21:58:41 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-25 21:58:41 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-25 21:58:41 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-25 21:58:41 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-25 21:58:41 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-25 21:58:41 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:41 --> Database Driver Class Initialized
DEBUG - 2016-09-25 21:58:41 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-25 21:58:41 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-25 21:58:41 --> Final output sent to browser
DEBUG - 2016-09-25 21:58:41 --> Total execution time: 0.1837
INFO - 2016-09-25 21:58:42 --> Config Class Initialized
INFO - 2016-09-25 21:58:42 --> Hooks Class Initialized
DEBUG - 2016-09-25 21:58:42 --> UTF-8 Support Enabled
INFO - 2016-09-25 21:58:42 --> Utf8 Class Initialized
INFO - 2016-09-25 21:58:42 --> URI Class Initialized
INFO - 2016-09-25 21:58:42 --> Router Class Initialized
INFO - 2016-09-25 21:58:42 --> Output Class Initialized
INFO - 2016-09-25 21:58:42 --> Security Class Initialized
DEBUG - 2016-09-25 21:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 21:58:42 --> Input Class Initialized
INFO - 2016-09-25 21:58:42 --> Language Class Initialized
INFO - 2016-09-25 21:58:42 --> Language Class Initialized
INFO - 2016-09-25 21:58:42 --> Config Class Initialized
INFO - 2016-09-25 21:58:42 --> Loader Class Initialized
INFO - 2016-09-25 21:58:42 --> Helper loaded: url_helper
INFO - 2016-09-25 21:58:42 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-25 21:58:42 --> Controller Class Initialized
DEBUG - 2016-09-25 21:58:42 --> login MX_Controller Initialized
INFO - 2016-09-25 21:58:42 --> Model Class Initialized
INFO - 2016-09-25 21:58:42 --> Model Class Initialized
DEBUG - 2016-09-25 21:58:42 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-25 21:58:42 --> Final output sent to browser
DEBUG - 2016-09-25 21:58:42 --> Total execution time: 0.0383
INFO - 2016-09-25 21:58:52 --> Config Class Initialized
INFO - 2016-09-25 21:58:52 --> Hooks Class Initialized
DEBUG - 2016-09-25 21:58:52 --> UTF-8 Support Enabled
INFO - 2016-09-25 21:58:52 --> Utf8 Class Initialized
INFO - 2016-09-25 21:58:52 --> URI Class Initialized
INFO - 2016-09-25 21:58:52 --> Router Class Initialized
INFO - 2016-09-25 21:58:52 --> Output Class Initialized
INFO - 2016-09-25 21:58:52 --> Security Class Initialized
DEBUG - 2016-09-25 21:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 21:58:52 --> Input Class Initialized
INFO - 2016-09-25 21:58:52 --> Language Class Initialized
INFO - 2016-09-25 21:58:52 --> Language Class Initialized
INFO - 2016-09-25 21:58:52 --> Config Class Initialized
INFO - 2016-09-25 21:58:52 --> Loader Class Initialized
INFO - 2016-09-25 21:58:52 --> Helper loaded: url_helper
INFO - 2016-09-25 21:58:52 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-25 21:58:52 --> Controller Class Initialized
DEBUG - 2016-09-25 21:58:52 --> login MX_Controller Initialized
INFO - 2016-09-25 21:58:52 --> Model Class Initialized
INFO - 2016-09-25 21:58:52 --> Model Class Initialized
INFO - 2016-09-25 21:58:52 --> Final output sent to browser
DEBUG - 2016-09-25 21:58:52 --> Total execution time: 0.0251
INFO - 2016-09-25 21:58:53 --> Config Class Initialized
INFO - 2016-09-25 21:58:53 --> Hooks Class Initialized
DEBUG - 2016-09-25 21:58:53 --> UTF-8 Support Enabled
INFO - 2016-09-25 21:58:53 --> Utf8 Class Initialized
INFO - 2016-09-25 21:58:53 --> URI Class Initialized
INFO - 2016-09-25 21:58:53 --> Router Class Initialized
INFO - 2016-09-25 21:58:53 --> Output Class Initialized
INFO - 2016-09-25 21:58:53 --> Security Class Initialized
DEBUG - 2016-09-25 21:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 21:58:53 --> Input Class Initialized
INFO - 2016-09-25 21:58:53 --> Language Class Initialized
INFO - 2016-09-25 21:58:53 --> Language Class Initialized
INFO - 2016-09-25 21:58:53 --> Config Class Initialized
INFO - 2016-09-25 21:58:53 --> Loader Class Initialized
INFO - 2016-09-25 21:58:53 --> Helper loaded: url_helper
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-25 21:58:53 --> Controller Class Initialized
DEBUG - 2016-09-25 21:58:53 --> Index MX_Controller Initialized
INFO - 2016-09-25 21:58:53 --> Model Class Initialized
INFO - 2016-09-25 21:58:53 --> Model Class Initialized
ERROR - 2016-09-25 21:58:53 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-25 21:58:53 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-25 21:58:53 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-25 21:58:53 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-25 21:58:53 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-25 21:58:53 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-25 21:58:53 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
INFO - 2016-09-25 21:58:53 --> Database Driver Class Initialized
DEBUG - 2016-09-25 21:58:53 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-25 21:58:53 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-25 21:58:53 --> Final output sent to browser
DEBUG - 2016-09-25 21:58:53 --> Total execution time: 0.1092
INFO - 2016-09-25 21:58:54 --> Config Class Initialized
INFO - 2016-09-25 21:58:54 --> Hooks Class Initialized
DEBUG - 2016-09-25 21:58:54 --> UTF-8 Support Enabled
INFO - 2016-09-25 21:58:54 --> Utf8 Class Initialized
INFO - 2016-09-25 21:58:54 --> URI Class Initialized
INFO - 2016-09-25 21:58:54 --> Router Class Initialized
INFO - 2016-09-25 21:58:54 --> Output Class Initialized
INFO - 2016-09-25 21:58:54 --> Security Class Initialized
DEBUG - 2016-09-25 21:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 21:58:54 --> Input Class Initialized
INFO - 2016-09-25 21:58:54 --> Language Class Initialized
ERROR - 2016-09-25 21:58:54 --> 404 Page Not Found: /index
INFO - 2016-09-25 21:59:03 --> Config Class Initialized
INFO - 2016-09-25 21:59:03 --> Hooks Class Initialized
DEBUG - 2016-09-25 21:59:03 --> UTF-8 Support Enabled
INFO - 2016-09-25 21:59:03 --> Utf8 Class Initialized
INFO - 2016-09-25 21:59:03 --> URI Class Initialized
DEBUG - 2016-09-25 21:59:03 --> No URI present. Default controller set.
INFO - 2016-09-25 21:59:03 --> Router Class Initialized
INFO - 2016-09-25 21:59:03 --> Output Class Initialized
INFO - 2016-09-25 21:59:03 --> Security Class Initialized
DEBUG - 2016-09-25 21:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 21:59:03 --> Input Class Initialized
INFO - 2016-09-25 21:59:03 --> Language Class Initialized
INFO - 2016-09-25 21:59:03 --> Language Class Initialized
INFO - 2016-09-25 21:59:03 --> Config Class Initialized
INFO - 2016-09-25 21:59:03 --> Loader Class Initialized
INFO - 2016-09-25 21:59:03 --> Helper loaded: url_helper
INFO - 2016-09-25 21:59:03 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-25 21:59:03 --> Controller Class Initialized
DEBUG - 2016-09-25 21:59:03 --> Index MX_Controller Initialized
INFO - 2016-09-25 21:59:03 --> Model Class Initialized
INFO - 2016-09-25 21:59:03 --> Model Class Initialized
ERROR - 2016-09-25 21:59:03 --> Unable to delete cache file for 
DEBUG - 2016-09-25 21:59:03 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-25 21:59:03 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-25 21:59:03 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-25 21:59:03 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-25 21:59:03 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-25 21:59:03 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-25 21:59:03 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:03 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:03 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:03 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:03 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:03 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:03 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:03 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:03 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:03 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:03 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:03 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:03 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:03 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:03 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:03 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:03 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:03 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:03 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:03 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:04 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:04 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:04 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:04 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:04 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:04 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:04 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:04 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:04 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:04 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:04 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:04 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:04 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:04 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:04 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:04 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:04 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:04 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:04 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:04 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:04 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:04 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:04 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:04 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:04 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:04 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:04 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:04 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:04 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:04 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:04 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:04 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:04 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:04 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:04 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:04 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:04 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:04 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:04 --> Database Driver Class Initialized
DEBUG - 2016-09-25 21:59:04 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-25 21:59:04 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-25 21:59:04 --> Final output sent to browser
DEBUG - 2016-09-25 21:59:04 --> Total execution time: 0.2854
INFO - 2016-09-25 21:59:05 --> Config Class Initialized
INFO - 2016-09-25 21:59:05 --> Hooks Class Initialized
DEBUG - 2016-09-25 21:59:05 --> UTF-8 Support Enabled
INFO - 2016-09-25 21:59:05 --> Utf8 Class Initialized
INFO - 2016-09-25 21:59:05 --> URI Class Initialized
INFO - 2016-09-25 21:59:05 --> Router Class Initialized
INFO - 2016-09-25 21:59:05 --> Output Class Initialized
INFO - 2016-09-25 21:59:05 --> Security Class Initialized
DEBUG - 2016-09-25 21:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 21:59:05 --> Input Class Initialized
INFO - 2016-09-25 21:59:05 --> Language Class Initialized
INFO - 2016-09-25 21:59:05 --> Language Class Initialized
INFO - 2016-09-25 21:59:05 --> Config Class Initialized
INFO - 2016-09-25 21:59:05 --> Loader Class Initialized
INFO - 2016-09-25 21:59:05 --> Helper loaded: url_helper
INFO - 2016-09-25 21:59:05 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-25 21:59:05 --> Controller Class Initialized
DEBUG - 2016-09-25 21:59:05 --> login MX_Controller Initialized
INFO - 2016-09-25 21:59:05 --> Model Class Initialized
INFO - 2016-09-25 21:59:05 --> Model Class Initialized
DEBUG - 2016-09-25 21:59:05 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-25 21:59:05 --> Final output sent to browser
DEBUG - 2016-09-25 21:59:05 --> Total execution time: 0.0503
INFO - 2016-09-25 21:59:31 --> Config Class Initialized
INFO - 2016-09-25 21:59:31 --> Hooks Class Initialized
DEBUG - 2016-09-25 21:59:31 --> UTF-8 Support Enabled
INFO - 2016-09-25 21:59:31 --> Utf8 Class Initialized
INFO - 2016-09-25 21:59:31 --> URI Class Initialized
INFO - 2016-09-25 21:59:31 --> Router Class Initialized
INFO - 2016-09-25 21:59:31 --> Output Class Initialized
INFO - 2016-09-25 21:59:31 --> Security Class Initialized
DEBUG - 2016-09-25 21:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 21:59:31 --> Input Class Initialized
INFO - 2016-09-25 21:59:31 --> Language Class Initialized
ERROR - 2016-09-25 21:59:31 --> 404 Page Not Found: /index
INFO - 2016-09-25 21:59:46 --> Config Class Initialized
INFO - 2016-09-25 21:59:46 --> Hooks Class Initialized
DEBUG - 2016-09-25 21:59:46 --> UTF-8 Support Enabled
INFO - 2016-09-25 21:59:46 --> Utf8 Class Initialized
INFO - 2016-09-25 21:59:46 --> URI Class Initialized
INFO - 2016-09-25 21:59:46 --> Router Class Initialized
INFO - 2016-09-25 21:59:46 --> Output Class Initialized
INFO - 2016-09-25 21:59:46 --> Security Class Initialized
DEBUG - 2016-09-25 21:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 21:59:46 --> Input Class Initialized
INFO - 2016-09-25 21:59:46 --> Language Class Initialized
INFO - 2016-09-25 21:59:46 --> Language Class Initialized
INFO - 2016-09-25 21:59:46 --> Config Class Initialized
INFO - 2016-09-25 21:59:46 --> Loader Class Initialized
INFO - 2016-09-25 21:59:46 --> Helper loaded: url_helper
INFO - 2016-09-25 21:59:46 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-25 21:59:46 --> Controller Class Initialized
DEBUG - 2016-09-25 21:59:46 --> login MX_Controller Initialized
INFO - 2016-09-25 21:59:46 --> Model Class Initialized
INFO - 2016-09-25 21:59:46 --> Model Class Initialized
INFO - 2016-09-25 21:59:46 --> Final output sent to browser
DEBUG - 2016-09-25 21:59:46 --> Total execution time: 0.0322
INFO - 2016-09-25 21:59:49 --> Config Class Initialized
INFO - 2016-09-25 21:59:49 --> Hooks Class Initialized
DEBUG - 2016-09-25 21:59:49 --> UTF-8 Support Enabled
INFO - 2016-09-25 21:59:49 --> Utf8 Class Initialized
INFO - 2016-09-25 21:59:49 --> URI Class Initialized
INFO - 2016-09-25 21:59:49 --> Router Class Initialized
INFO - 2016-09-25 21:59:49 --> Output Class Initialized
INFO - 2016-09-25 21:59:49 --> Security Class Initialized
DEBUG - 2016-09-25 21:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 21:59:49 --> Input Class Initialized
INFO - 2016-09-25 21:59:49 --> Language Class Initialized
INFO - 2016-09-25 21:59:49 --> Language Class Initialized
INFO - 2016-09-25 21:59:49 --> Config Class Initialized
INFO - 2016-09-25 21:59:49 --> Loader Class Initialized
INFO - 2016-09-25 21:59:49 --> Helper loaded: url_helper
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-25 21:59:49 --> Controller Class Initialized
DEBUG - 2016-09-25 21:59:49 --> Index MX_Controller Initialized
INFO - 2016-09-25 21:59:49 --> Model Class Initialized
INFO - 2016-09-25 21:59:49 --> Model Class Initialized
ERROR - 2016-09-25 21:59:49 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-25 21:59:49 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-25 21:59:49 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-25 21:59:49 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-25 21:59:49 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-25 21:59:49 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-25 21:59:49 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
INFO - 2016-09-25 21:59:49 --> Database Driver Class Initialized
DEBUG - 2016-09-25 21:59:49 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-25 21:59:49 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-25 21:59:49 --> Final output sent to browser
DEBUG - 2016-09-25 21:59:49 --> Total execution time: 0.1035
INFO - 2016-09-25 21:59:51 --> Config Class Initialized
INFO - 2016-09-25 21:59:51 --> Hooks Class Initialized
DEBUG - 2016-09-25 21:59:51 --> UTF-8 Support Enabled
INFO - 2016-09-25 21:59:51 --> Utf8 Class Initialized
INFO - 2016-09-25 21:59:51 --> URI Class Initialized
INFO - 2016-09-25 21:59:51 --> Router Class Initialized
INFO - 2016-09-25 21:59:51 --> Output Class Initialized
INFO - 2016-09-25 21:59:51 --> Security Class Initialized
DEBUG - 2016-09-25 21:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 21:59:51 --> Input Class Initialized
INFO - 2016-09-25 21:59:51 --> Language Class Initialized
ERROR - 2016-09-25 21:59:51 --> 404 Page Not Found: /index
INFO - 2016-09-25 22:00:41 --> Config Class Initialized
INFO - 2016-09-25 22:00:41 --> Hooks Class Initialized
DEBUG - 2016-09-25 22:00:41 --> UTF-8 Support Enabled
INFO - 2016-09-25 22:00:41 --> Utf8 Class Initialized
INFO - 2016-09-25 22:00:41 --> URI Class Initialized
DEBUG - 2016-09-25 22:00:41 --> No URI present. Default controller set.
INFO - 2016-09-25 22:00:41 --> Router Class Initialized
INFO - 2016-09-25 22:00:41 --> Output Class Initialized
INFO - 2016-09-25 22:00:41 --> Security Class Initialized
DEBUG - 2016-09-25 22:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 22:00:41 --> Input Class Initialized
INFO - 2016-09-25 22:00:41 --> Language Class Initialized
INFO - 2016-09-25 22:00:41 --> Language Class Initialized
INFO - 2016-09-25 22:00:41 --> Config Class Initialized
INFO - 2016-09-25 22:00:41 --> Loader Class Initialized
INFO - 2016-09-25 22:00:41 --> Helper loaded: url_helper
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-25 22:00:41 --> Controller Class Initialized
DEBUG - 2016-09-25 22:00:41 --> Index MX_Controller Initialized
INFO - 2016-09-25 22:00:41 --> Model Class Initialized
INFO - 2016-09-25 22:00:41 --> Model Class Initialized
ERROR - 2016-09-25 22:00:41 --> Unable to delete cache file for 
DEBUG - 2016-09-25 22:00:41 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-25 22:00:41 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-25 22:00:41 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-25 22:00:41 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-25 22:00:41 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-25 22:00:41 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:41 --> Database Driver Class Initialized
DEBUG - 2016-09-25 22:00:41 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-25 22:00:41 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-25 22:00:41 --> Final output sent to browser
DEBUG - 2016-09-25 22:00:41 --> Total execution time: 0.1498
INFO - 2016-09-25 22:00:42 --> Config Class Initialized
INFO - 2016-09-25 22:00:42 --> Hooks Class Initialized
DEBUG - 2016-09-25 22:00:42 --> UTF-8 Support Enabled
INFO - 2016-09-25 22:00:42 --> Utf8 Class Initialized
INFO - 2016-09-25 22:00:42 --> URI Class Initialized
INFO - 2016-09-25 22:00:42 --> Router Class Initialized
INFO - 2016-09-25 22:00:42 --> Output Class Initialized
INFO - 2016-09-25 22:00:42 --> Security Class Initialized
DEBUG - 2016-09-25 22:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 22:00:42 --> Input Class Initialized
INFO - 2016-09-25 22:00:42 --> Language Class Initialized
INFO - 2016-09-25 22:00:42 --> Language Class Initialized
INFO - 2016-09-25 22:00:42 --> Config Class Initialized
INFO - 2016-09-25 22:00:42 --> Loader Class Initialized
INFO - 2016-09-25 22:00:42 --> Helper loaded: url_helper
INFO - 2016-09-25 22:00:42 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-25 22:00:42 --> Controller Class Initialized
DEBUG - 2016-09-25 22:00:42 --> login MX_Controller Initialized
INFO - 2016-09-25 22:00:42 --> Model Class Initialized
INFO - 2016-09-25 22:00:42 --> Model Class Initialized
DEBUG - 2016-09-25 22:00:42 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-25 22:00:42 --> Final output sent to browser
DEBUG - 2016-09-25 22:00:42 --> Total execution time: 0.0290
INFO - 2016-09-25 22:00:56 --> Config Class Initialized
INFO - 2016-09-25 22:00:56 --> Hooks Class Initialized
DEBUG - 2016-09-25 22:00:56 --> UTF-8 Support Enabled
INFO - 2016-09-25 22:00:56 --> Utf8 Class Initialized
INFO - 2016-09-25 22:00:56 --> URI Class Initialized
INFO - 2016-09-25 22:00:56 --> Router Class Initialized
INFO - 2016-09-25 22:00:56 --> Output Class Initialized
INFO - 2016-09-25 22:00:56 --> Security Class Initialized
DEBUG - 2016-09-25 22:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 22:00:56 --> Input Class Initialized
INFO - 2016-09-25 22:00:56 --> Language Class Initialized
INFO - 2016-09-25 22:00:56 --> Language Class Initialized
INFO - 2016-09-25 22:00:56 --> Config Class Initialized
INFO - 2016-09-25 22:00:56 --> Loader Class Initialized
INFO - 2016-09-25 22:00:56 --> Helper loaded: url_helper
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-25 22:00:56 --> Controller Class Initialized
DEBUG - 2016-09-25 22:00:56 --> login MX_Controller Initialized
INFO - 2016-09-25 22:00:56 --> Model Class Initialized
INFO - 2016-09-25 22:00:56 --> Model Class Initialized
INFO - 2016-09-25 22:00:56 --> Final output sent to browser
DEBUG - 2016-09-25 22:00:56 --> Total execution time: 0.0308
INFO - 2016-09-25 22:00:56 --> Config Class Initialized
INFO - 2016-09-25 22:00:56 --> Hooks Class Initialized
DEBUG - 2016-09-25 22:00:56 --> UTF-8 Support Enabled
INFO - 2016-09-25 22:00:56 --> Utf8 Class Initialized
INFO - 2016-09-25 22:00:56 --> URI Class Initialized
INFO - 2016-09-25 22:00:56 --> Router Class Initialized
INFO - 2016-09-25 22:00:56 --> Output Class Initialized
INFO - 2016-09-25 22:00:56 --> Security Class Initialized
DEBUG - 2016-09-25 22:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 22:00:56 --> Input Class Initialized
INFO - 2016-09-25 22:00:56 --> Language Class Initialized
INFO - 2016-09-25 22:00:56 --> Language Class Initialized
INFO - 2016-09-25 22:00:56 --> Config Class Initialized
INFO - 2016-09-25 22:00:56 --> Loader Class Initialized
INFO - 2016-09-25 22:00:56 --> Helper loaded: url_helper
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-25 22:00:56 --> Controller Class Initialized
DEBUG - 2016-09-25 22:00:56 --> Index MX_Controller Initialized
INFO - 2016-09-25 22:00:56 --> Model Class Initialized
INFO - 2016-09-25 22:00:56 --> Model Class Initialized
ERROR - 2016-09-25 22:00:56 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-25 22:00:56 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-25 22:00:56 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-25 22:00:56 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-25 22:00:56 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-25 22:00:56 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-25 22:00:56 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:56 --> Database Driver Class Initialized
INFO - 2016-09-25 22:00:57 --> Database Driver Class Initialized
DEBUG - 2016-09-25 22:00:57 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-25 22:00:57 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-25 22:00:57 --> Final output sent to browser
DEBUG - 2016-09-25 22:00:57 --> Total execution time: 0.1171
INFO - 2016-09-25 22:00:58 --> Config Class Initialized
INFO - 2016-09-25 22:00:58 --> Hooks Class Initialized
DEBUG - 2016-09-25 22:00:58 --> UTF-8 Support Enabled
INFO - 2016-09-25 22:00:58 --> Utf8 Class Initialized
INFO - 2016-09-25 22:00:58 --> URI Class Initialized
INFO - 2016-09-25 22:00:58 --> Router Class Initialized
INFO - 2016-09-25 22:00:58 --> Output Class Initialized
INFO - 2016-09-25 22:00:58 --> Security Class Initialized
DEBUG - 2016-09-25 22:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 22:00:58 --> Input Class Initialized
INFO - 2016-09-25 22:00:58 --> Language Class Initialized
ERROR - 2016-09-25 22:00:58 --> 404 Page Not Found: /index
INFO - 2016-09-25 22:03:39 --> Config Class Initialized
INFO - 2016-09-25 22:03:39 --> Hooks Class Initialized
DEBUG - 2016-09-25 22:03:39 --> UTF-8 Support Enabled
INFO - 2016-09-25 22:03:39 --> Utf8 Class Initialized
INFO - 2016-09-25 22:03:39 --> URI Class Initialized
DEBUG - 2016-09-25 22:03:39 --> No URI present. Default controller set.
INFO - 2016-09-25 22:03:39 --> Router Class Initialized
INFO - 2016-09-25 22:03:39 --> Output Class Initialized
INFO - 2016-09-25 22:03:39 --> Security Class Initialized
DEBUG - 2016-09-25 22:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 22:03:39 --> Input Class Initialized
INFO - 2016-09-25 22:03:39 --> Language Class Initialized
INFO - 2016-09-25 22:03:39 --> Language Class Initialized
INFO - 2016-09-25 22:03:40 --> Config Class Initialized
INFO - 2016-09-25 22:03:40 --> Loader Class Initialized
INFO - 2016-09-25 22:03:40 --> Helper loaded: url_helper
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-25 22:03:40 --> Controller Class Initialized
DEBUG - 2016-09-25 22:03:40 --> Index MX_Controller Initialized
INFO - 2016-09-25 22:03:40 --> Model Class Initialized
INFO - 2016-09-25 22:03:40 --> Model Class Initialized
ERROR - 2016-09-25 22:03:40 --> Unable to delete cache file for 
DEBUG - 2016-09-25 22:03:40 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-25 22:03:40 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-25 22:03:40 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-25 22:03:40 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-25 22:03:40 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-25 22:03:40 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
DEBUG - 2016-09-25 22:03:40 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-25 22:03:40 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-25 22:03:40 --> Final output sent to browser
DEBUG - 2016-09-25 22:03:40 --> Total execution time: 0.1889
INFO - 2016-09-25 22:03:40 --> Config Class Initialized
INFO - 2016-09-25 22:03:40 --> Hooks Class Initialized
DEBUG - 2016-09-25 22:03:40 --> UTF-8 Support Enabled
INFO - 2016-09-25 22:03:40 --> Utf8 Class Initialized
INFO - 2016-09-25 22:03:40 --> URI Class Initialized
INFO - 2016-09-25 22:03:40 --> Router Class Initialized
INFO - 2016-09-25 22:03:40 --> Output Class Initialized
INFO - 2016-09-25 22:03:40 --> Security Class Initialized
DEBUG - 2016-09-25 22:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 22:03:40 --> Input Class Initialized
INFO - 2016-09-25 22:03:40 --> Language Class Initialized
INFO - 2016-09-25 22:03:40 --> Language Class Initialized
INFO - 2016-09-25 22:03:40 --> Config Class Initialized
INFO - 2016-09-25 22:03:40 --> Loader Class Initialized
INFO - 2016-09-25 22:03:40 --> Helper loaded: url_helper
INFO - 2016-09-25 22:03:40 --> Database Driver Class Initialized
INFO - 2016-09-25 22:03:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-25 22:03:40 --> Controller Class Initialized
DEBUG - 2016-09-25 22:03:40 --> login MX_Controller Initialized
INFO - 2016-09-25 22:03:40 --> Model Class Initialized
INFO - 2016-09-25 22:03:40 --> Model Class Initialized
DEBUG - 2016-09-25 22:03:40 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-25 22:03:40 --> Final output sent to browser
DEBUG - 2016-09-25 22:03:40 --> Total execution time: 0.0466
INFO - 2016-09-25 22:03:46 --> Config Class Initialized
INFO - 2016-09-25 22:03:46 --> Hooks Class Initialized
DEBUG - 2016-09-25 22:03:46 --> UTF-8 Support Enabled
INFO - 2016-09-25 22:03:46 --> Utf8 Class Initialized
INFO - 2016-09-25 22:03:46 --> URI Class Initialized
INFO - 2016-09-25 22:03:46 --> Router Class Initialized
INFO - 2016-09-25 22:03:46 --> Output Class Initialized
INFO - 2016-09-25 22:03:46 --> Security Class Initialized
DEBUG - 2016-09-25 22:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 22:03:46 --> Input Class Initialized
INFO - 2016-09-25 22:03:46 --> Language Class Initialized
ERROR - 2016-09-25 22:03:46 --> 404 Page Not Found: /index
INFO - 2016-09-25 22:04:50 --> Config Class Initialized
INFO - 2016-09-25 22:04:50 --> Hooks Class Initialized
DEBUG - 2016-09-25 22:04:50 --> UTF-8 Support Enabled
INFO - 2016-09-25 22:04:50 --> Utf8 Class Initialized
INFO - 2016-09-25 22:04:50 --> URI Class Initialized
INFO - 2016-09-25 22:04:50 --> Router Class Initialized
INFO - 2016-09-25 22:04:50 --> Output Class Initialized
INFO - 2016-09-25 22:04:50 --> Security Class Initialized
DEBUG - 2016-09-25 22:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 22:04:50 --> Input Class Initialized
INFO - 2016-09-25 22:04:50 --> Language Class Initialized
INFO - 2016-09-25 22:04:50 --> Language Class Initialized
INFO - 2016-09-25 22:04:50 --> Config Class Initialized
INFO - 2016-09-25 22:04:50 --> Loader Class Initialized
INFO - 2016-09-25 22:04:50 --> Helper loaded: url_helper
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-25 22:04:51 --> Controller Class Initialized
DEBUG - 2016-09-25 22:04:51 --> login MX_Controller Initialized
INFO - 2016-09-25 22:04:51 --> Model Class Initialized
INFO - 2016-09-25 22:04:51 --> Model Class Initialized
INFO - 2016-09-25 22:04:51 --> Final output sent to browser
DEBUG - 2016-09-25 22:04:51 --> Total execution time: 0.0364
INFO - 2016-09-25 22:04:51 --> Config Class Initialized
INFO - 2016-09-25 22:04:51 --> Hooks Class Initialized
DEBUG - 2016-09-25 22:04:51 --> UTF-8 Support Enabled
INFO - 2016-09-25 22:04:51 --> Utf8 Class Initialized
INFO - 2016-09-25 22:04:51 --> URI Class Initialized
INFO - 2016-09-25 22:04:51 --> Router Class Initialized
INFO - 2016-09-25 22:04:51 --> Output Class Initialized
INFO - 2016-09-25 22:04:51 --> Security Class Initialized
DEBUG - 2016-09-25 22:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 22:04:51 --> Input Class Initialized
INFO - 2016-09-25 22:04:51 --> Language Class Initialized
INFO - 2016-09-25 22:04:51 --> Language Class Initialized
INFO - 2016-09-25 22:04:51 --> Config Class Initialized
INFO - 2016-09-25 22:04:51 --> Loader Class Initialized
INFO - 2016-09-25 22:04:51 --> Helper loaded: url_helper
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-25 22:04:51 --> Controller Class Initialized
DEBUG - 2016-09-25 22:04:51 --> Index MX_Controller Initialized
INFO - 2016-09-25 22:04:51 --> Model Class Initialized
INFO - 2016-09-25 22:04:51 --> Model Class Initialized
ERROR - 2016-09-25 22:04:51 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-25 22:04:51 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-25 22:04:51 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-25 22:04:51 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-25 22:04:51 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-25 22:04:51 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-25 22:04:51 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
INFO - 2016-09-25 22:04:51 --> Database Driver Class Initialized
DEBUG - 2016-09-25 22:04:51 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-25 22:04:51 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-25 22:04:51 --> Final output sent to browser
DEBUG - 2016-09-25 22:04:51 --> Total execution time: 0.1066
INFO - 2016-09-25 22:04:56 --> Config Class Initialized
INFO - 2016-09-25 22:04:56 --> Hooks Class Initialized
DEBUG - 2016-09-25 22:04:56 --> UTF-8 Support Enabled
INFO - 2016-09-25 22:04:56 --> Utf8 Class Initialized
INFO - 2016-09-25 22:04:56 --> URI Class Initialized
INFO - 2016-09-25 22:04:56 --> Router Class Initialized
INFO - 2016-09-25 22:04:56 --> Output Class Initialized
INFO - 2016-09-25 22:04:56 --> Security Class Initialized
DEBUG - 2016-09-25 22:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 22:04:56 --> Input Class Initialized
INFO - 2016-09-25 22:04:56 --> Language Class Initialized
ERROR - 2016-09-25 22:04:56 --> 404 Page Not Found: /index
INFO - 2016-09-25 22:05:31 --> Config Class Initialized
INFO - 2016-09-25 22:05:31 --> Hooks Class Initialized
DEBUG - 2016-09-25 22:05:31 --> UTF-8 Support Enabled
INFO - 2016-09-25 22:05:31 --> Utf8 Class Initialized
INFO - 2016-09-25 22:05:31 --> URI Class Initialized
INFO - 2016-09-25 22:05:31 --> Router Class Initialized
INFO - 2016-09-25 22:05:31 --> Output Class Initialized
INFO - 2016-09-25 22:05:31 --> Security Class Initialized
DEBUG - 2016-09-25 22:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 22:05:31 --> Input Class Initialized
INFO - 2016-09-25 22:05:31 --> Language Class Initialized
INFO - 2016-09-25 22:05:31 --> Language Class Initialized
INFO - 2016-09-25 22:05:31 --> Config Class Initialized
INFO - 2016-09-25 22:05:31 --> Loader Class Initialized
INFO - 2016-09-25 22:05:31 --> Helper loaded: url_helper
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-25 22:05:31 --> Controller Class Initialized
DEBUG - 2016-09-25 22:05:31 --> Index MX_Controller Initialized
INFO - 2016-09-25 22:05:31 --> Model Class Initialized
INFO - 2016-09-25 22:05:31 --> Model Class Initialized
ERROR - 2016-09-25 22:05:31 --> Unable to delete cache file for admin/index/data/user
DEBUG - 2016-09-25 22:05:31 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-25 22:05:31 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-25 22:05:31 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-25 22:05:31 --> File already loaded: /home/koperasi/public_html/application/controllers/../modules/user/controllers/Users.php
DEBUG - 2016-09-25 22:05:31 --> Users MX_Controller Initialized
DEBUG - 2016-09-25 22:05:31 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/list_user.php
DEBUG - 2016-09-25 22:05:31 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-25 22:05:31 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
INFO - 2016-09-25 22:05:31 --> Database Driver Class Initialized
DEBUG - 2016-09-25 22:05:31 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-25 22:05:31 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-25 22:05:31 --> Final output sent to browser
DEBUG - 2016-09-25 22:05:31 --> Total execution time: 0.1542
INFO - 2016-09-25 22:05:32 --> Config Class Initialized
INFO - 2016-09-25 22:05:32 --> Hooks Class Initialized
DEBUG - 2016-09-25 22:05:32 --> UTF-8 Support Enabled
INFO - 2016-09-25 22:05:32 --> Utf8 Class Initialized
INFO - 2016-09-25 22:05:32 --> URI Class Initialized
INFO - 2016-09-25 22:05:32 --> Router Class Initialized
INFO - 2016-09-25 22:05:32 --> Output Class Initialized
INFO - 2016-09-25 22:05:32 --> Security Class Initialized
DEBUG - 2016-09-25 22:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 22:05:32 --> Input Class Initialized
INFO - 2016-09-25 22:05:32 --> Language Class Initialized
ERROR - 2016-09-25 22:05:32 --> 404 Page Not Found: /index
INFO - 2016-09-25 22:06:12 --> Config Class Initialized
INFO - 2016-09-25 22:06:12 --> Hooks Class Initialized
DEBUG - 2016-09-25 22:06:12 --> UTF-8 Support Enabled
INFO - 2016-09-25 22:06:12 --> Utf8 Class Initialized
INFO - 2016-09-25 22:06:12 --> URI Class Initialized
INFO - 2016-09-25 22:06:12 --> Router Class Initialized
INFO - 2016-09-25 22:06:12 --> Output Class Initialized
INFO - 2016-09-25 22:06:12 --> Security Class Initialized
DEBUG - 2016-09-25 22:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 22:06:12 --> Input Class Initialized
INFO - 2016-09-25 22:06:12 --> Language Class Initialized
INFO - 2016-09-25 22:06:12 --> Language Class Initialized
INFO - 2016-09-25 22:06:12 --> Config Class Initialized
INFO - 2016-09-25 22:06:12 --> Loader Class Initialized
INFO - 2016-09-25 22:06:12 --> Helper loaded: url_helper
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-25 22:06:12 --> Controller Class Initialized
DEBUG - 2016-09-25 22:06:12 --> Index MX_Controller Initialized
INFO - 2016-09-25 22:06:12 --> Model Class Initialized
INFO - 2016-09-25 22:06:12 --> Model Class Initialized
ERROR - 2016-09-25 22:06:12 --> Unable to delete cache file for admin/index/data_peminjam
DEBUG - 2016-09-25 22:06:12 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-25 22:06:12 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-25 22:06:12 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-25 22:06:12 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/list_peminjam.php
DEBUG - 2016-09-25 22:06:12 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-25 22:06:12 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:12 --> Database Driver Class Initialized
DEBUG - 2016-09-25 22:06:12 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-25 22:06:12 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-25 22:06:12 --> Final output sent to browser
DEBUG - 2016-09-25 22:06:12 --> Total execution time: 0.1718
INFO - 2016-09-25 22:06:13 --> Config Class Initialized
INFO - 2016-09-25 22:06:13 --> Hooks Class Initialized
DEBUG - 2016-09-25 22:06:13 --> UTF-8 Support Enabled
INFO - 2016-09-25 22:06:13 --> Utf8 Class Initialized
INFO - 2016-09-25 22:06:13 --> URI Class Initialized
INFO - 2016-09-25 22:06:13 --> Router Class Initialized
INFO - 2016-09-25 22:06:13 --> Output Class Initialized
INFO - 2016-09-25 22:06:13 --> Security Class Initialized
DEBUG - 2016-09-25 22:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 22:06:13 --> Input Class Initialized
INFO - 2016-09-25 22:06:13 --> Language Class Initialized
ERROR - 2016-09-25 22:06:13 --> 404 Page Not Found: /index
INFO - 2016-09-25 22:06:21 --> Config Class Initialized
INFO - 2016-09-25 22:06:21 --> Hooks Class Initialized
DEBUG - 2016-09-25 22:06:21 --> UTF-8 Support Enabled
INFO - 2016-09-25 22:06:21 --> Utf8 Class Initialized
INFO - 2016-09-25 22:06:21 --> URI Class Initialized
INFO - 2016-09-25 22:06:21 --> Router Class Initialized
INFO - 2016-09-25 22:06:21 --> Output Class Initialized
INFO - 2016-09-25 22:06:21 --> Security Class Initialized
DEBUG - 2016-09-25 22:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 22:06:21 --> Input Class Initialized
INFO - 2016-09-25 22:06:21 --> Language Class Initialized
INFO - 2016-09-25 22:06:21 --> Language Class Initialized
INFO - 2016-09-25 22:06:21 --> Config Class Initialized
INFO - 2016-09-25 22:06:21 --> Loader Class Initialized
INFO - 2016-09-25 22:06:21 --> Helper loaded: url_helper
INFO - 2016-09-25 22:06:21 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-25 22:06:21 --> Controller Class Initialized
DEBUG - 2016-09-25 22:06:21 --> Index MX_Controller Initialized
INFO - 2016-09-25 22:06:21 --> Model Class Initialized
INFO - 2016-09-25 22:06:21 --> Model Class Initialized
ERROR - 2016-09-25 22:06:21 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-09-25 22:06:21 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-25 22:06:21 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-25 22:06:21 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-25 22:06:21 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/form_get_anggota.php
DEBUG - 2016-09-25 22:06:21 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-25 22:06:21 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-25 22:06:21 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:21 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:21 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:21 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:21 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:21 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:21 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:21 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:21 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:21 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:22 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:22 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:22 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:22 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:22 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:22 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:22 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:22 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:22 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:22 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:22 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:22 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:22 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:22 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:22 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:22 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:22 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:22 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:22 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:22 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:22 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:22 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:22 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:22 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:22 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:22 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:22 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:22 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:22 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:22 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:22 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:22 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:22 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:22 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:22 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:22 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:22 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:22 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:22 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:22 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:22 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:22 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:22 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:22 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:22 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:22 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:22 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:22 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:22 --> Database Driver Class Initialized
DEBUG - 2016-09-25 22:06:22 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-25 22:06:22 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-25 22:06:22 --> Final output sent to browser
DEBUG - 2016-09-25 22:06:22 --> Total execution time: 0.1119
INFO - 2016-09-25 22:06:23 --> Config Class Initialized
INFO - 2016-09-25 22:06:23 --> Hooks Class Initialized
DEBUG - 2016-09-25 22:06:23 --> UTF-8 Support Enabled
INFO - 2016-09-25 22:06:23 --> Utf8 Class Initialized
INFO - 2016-09-25 22:06:23 --> URI Class Initialized
INFO - 2016-09-25 22:06:23 --> Router Class Initialized
INFO - 2016-09-25 22:06:23 --> Output Class Initialized
INFO - 2016-09-25 22:06:23 --> Security Class Initialized
DEBUG - 2016-09-25 22:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 22:06:23 --> Input Class Initialized
INFO - 2016-09-25 22:06:23 --> Language Class Initialized
ERROR - 2016-09-25 22:06:23 --> 404 Page Not Found: /index
INFO - 2016-09-25 22:06:24 --> Config Class Initialized
INFO - 2016-09-25 22:06:24 --> Hooks Class Initialized
DEBUG - 2016-09-25 22:06:24 --> UTF-8 Support Enabled
INFO - 2016-09-25 22:06:24 --> Utf8 Class Initialized
INFO - 2016-09-25 22:06:24 --> URI Class Initialized
INFO - 2016-09-25 22:06:24 --> Router Class Initialized
INFO - 2016-09-25 22:06:24 --> Output Class Initialized
INFO - 2016-09-25 22:06:24 --> Security Class Initialized
DEBUG - 2016-09-25 22:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 22:06:24 --> Input Class Initialized
INFO - 2016-09-25 22:06:24 --> Language Class Initialized
INFO - 2016-09-25 22:06:24 --> Language Class Initialized
INFO - 2016-09-25 22:06:24 --> Config Class Initialized
INFO - 2016-09-25 22:06:24 --> Loader Class Initialized
INFO - 2016-09-25 22:06:24 --> Helper loaded: url_helper
INFO - 2016-09-25 22:06:24 --> Database Driver Class Initialized
INFO - 2016-09-25 22:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-25 22:06:24 --> Controller Class Initialized
DEBUG - 2016-09-25 22:06:24 --> Index MX_Controller Initialized
INFO - 2016-09-25 22:06:24 --> Model Class Initialized
INFO - 2016-09-25 22:06:24 --> Model Class Initialized
ERROR - 2016-09-25 22:06:24 --> Unable to delete cache file for admin/index/getDataPeminjam
DEBUG - 2016-09-25 22:06:24 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-25 22:06:24 --> Final output sent to browser
DEBUG - 2016-09-25 22:06:24 --> Total execution time: 0.0465
INFO - 2016-09-25 22:08:02 --> Config Class Initialized
INFO - 2016-09-25 22:08:02 --> Hooks Class Initialized
DEBUG - 2016-09-25 22:08:02 --> UTF-8 Support Enabled
INFO - 2016-09-25 22:08:02 --> Utf8 Class Initialized
INFO - 2016-09-25 22:08:02 --> URI Class Initialized
INFO - 2016-09-25 22:08:02 --> Router Class Initialized
INFO - 2016-09-25 22:08:02 --> Output Class Initialized
INFO - 2016-09-25 22:08:02 --> Security Class Initialized
DEBUG - 2016-09-25 22:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 22:08:02 --> Input Class Initialized
INFO - 2016-09-25 22:08:02 --> Language Class Initialized
INFO - 2016-09-25 22:08:02 --> Language Class Initialized
INFO - 2016-09-25 22:08:02 --> Config Class Initialized
INFO - 2016-09-25 22:08:02 --> Loader Class Initialized
INFO - 2016-09-25 22:08:02 --> Helper loaded: url_helper
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-25 22:08:02 --> Controller Class Initialized
DEBUG - 2016-09-25 22:08:02 --> Index MX_Controller Initialized
INFO - 2016-09-25 22:08:02 --> Model Class Initialized
INFO - 2016-09-25 22:08:02 --> Model Class Initialized
ERROR - 2016-09-25 22:08:02 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-25 22:08:02 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-25 22:08:02 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-25 22:08:02 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-25 22:08:02 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-25 22:08:02 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-25 22:08:02 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:02 --> Database Driver Class Initialized
DEBUG - 2016-09-25 22:08:02 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-25 22:08:02 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-25 22:08:02 --> Final output sent to browser
DEBUG - 2016-09-25 22:08:02 --> Total execution time: 0.2002
INFO - 2016-09-25 22:08:03 --> Config Class Initialized
INFO - 2016-09-25 22:08:03 --> Hooks Class Initialized
DEBUG - 2016-09-25 22:08:03 --> UTF-8 Support Enabled
INFO - 2016-09-25 22:08:03 --> Utf8 Class Initialized
INFO - 2016-09-25 22:08:03 --> URI Class Initialized
INFO - 2016-09-25 22:08:03 --> Router Class Initialized
INFO - 2016-09-25 22:08:03 --> Output Class Initialized
INFO - 2016-09-25 22:08:03 --> Security Class Initialized
DEBUG - 2016-09-25 22:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 22:08:03 --> Input Class Initialized
INFO - 2016-09-25 22:08:03 --> Language Class Initialized
ERROR - 2016-09-25 22:08:03 --> 404 Page Not Found: /index
INFO - 2016-09-25 22:08:43 --> Config Class Initialized
INFO - 2016-09-25 22:08:43 --> Hooks Class Initialized
DEBUG - 2016-09-25 22:08:43 --> UTF-8 Support Enabled
INFO - 2016-09-25 22:08:43 --> Utf8 Class Initialized
INFO - 2016-09-25 22:08:43 --> URI Class Initialized
INFO - 2016-09-25 22:08:43 --> Router Class Initialized
INFO - 2016-09-25 22:08:43 --> Output Class Initialized
INFO - 2016-09-25 22:08:43 --> Security Class Initialized
DEBUG - 2016-09-25 22:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 22:08:43 --> Input Class Initialized
INFO - 2016-09-25 22:08:43 --> Language Class Initialized
INFO - 2016-09-25 22:08:43 --> Language Class Initialized
INFO - 2016-09-25 22:08:43 --> Config Class Initialized
INFO - 2016-09-25 22:08:43 --> Loader Class Initialized
INFO - 2016-09-25 22:08:43 --> Helper loaded: url_helper
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-25 22:08:43 --> Controller Class Initialized
DEBUG - 2016-09-25 22:08:43 --> Index MX_Controller Initialized
INFO - 2016-09-25 22:08:43 --> Model Class Initialized
INFO - 2016-09-25 22:08:43 --> Model Class Initialized
ERROR - 2016-09-25 22:08:43 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-25 22:08:43 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-25 22:08:43 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-25 22:08:43 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-25 22:08:43 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-25 22:08:43 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-25 22:08:43 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
INFO - 2016-09-25 22:08:43 --> Database Driver Class Initialized
DEBUG - 2016-09-25 22:08:43 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-25 22:08:43 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-25 22:08:43 --> Final output sent to browser
DEBUG - 2016-09-25 22:08:43 --> Total execution time: 0.1133
INFO - 2016-09-25 22:08:44 --> Config Class Initialized
INFO - 2016-09-25 22:08:44 --> Hooks Class Initialized
DEBUG - 2016-09-25 22:08:44 --> UTF-8 Support Enabled
INFO - 2016-09-25 22:08:44 --> Utf8 Class Initialized
INFO - 2016-09-25 22:08:44 --> URI Class Initialized
INFO - 2016-09-25 22:08:44 --> Router Class Initialized
INFO - 2016-09-25 22:08:44 --> Output Class Initialized
INFO - 2016-09-25 22:08:44 --> Security Class Initialized
DEBUG - 2016-09-25 22:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 22:08:44 --> Input Class Initialized
INFO - 2016-09-25 22:08:44 --> Language Class Initialized
ERROR - 2016-09-25 22:08:44 --> 404 Page Not Found: /index
INFO - 2016-09-25 22:42:47 --> Config Class Initialized
INFO - 2016-09-25 22:42:47 --> Hooks Class Initialized
DEBUG - 2016-09-25 22:42:47 --> UTF-8 Support Enabled
INFO - 2016-09-25 22:42:47 --> Utf8 Class Initialized
INFO - 2016-09-25 22:42:47 --> URI Class Initialized
INFO - 2016-09-25 22:42:47 --> Router Class Initialized
INFO - 2016-09-25 22:42:47 --> Output Class Initialized
INFO - 2016-09-25 22:42:47 --> Security Class Initialized
DEBUG - 2016-09-25 22:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 22:42:47 --> Input Class Initialized
INFO - 2016-09-25 22:42:47 --> Language Class Initialized
ERROR - 2016-09-25 22:42:47 --> 404 Page Not Found: /index
INFO - 2016-09-25 22:42:48 --> Config Class Initialized
INFO - 2016-09-25 22:42:48 --> Hooks Class Initialized
DEBUG - 2016-09-25 22:42:48 --> UTF-8 Support Enabled
INFO - 2016-09-25 22:42:48 --> Utf8 Class Initialized
INFO - 2016-09-25 22:42:48 --> URI Class Initialized
DEBUG - 2016-09-25 22:42:48 --> No URI present. Default controller set.
INFO - 2016-09-25 22:42:48 --> Router Class Initialized
INFO - 2016-09-25 22:42:48 --> Output Class Initialized
INFO - 2016-09-25 22:42:48 --> Security Class Initialized
DEBUG - 2016-09-25 22:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-25 22:42:48 --> Input Class Initialized
INFO - 2016-09-25 22:42:48 --> Language Class Initialized
INFO - 2016-09-25 22:42:48 --> Language Class Initialized
INFO - 2016-09-25 22:42:48 --> Config Class Initialized
INFO - 2016-09-25 22:42:48 --> Loader Class Initialized
INFO - 2016-09-25 22:42:48 --> Helper loaded: url_helper
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-25 22:42:48 --> Controller Class Initialized
DEBUG - 2016-09-25 22:42:48 --> Index MX_Controller Initialized
INFO - 2016-09-25 22:42:48 --> Model Class Initialized
INFO - 2016-09-25 22:42:48 --> Model Class Initialized
ERROR - 2016-09-25 22:42:48 --> Unable to delete cache file for 
DEBUG - 2016-09-25 22:42:48 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-25 22:42:48 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-25 22:42:48 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-25 22:42:48 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-25 22:42:48 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-25 22:42:48 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
INFO - 2016-09-25 22:42:48 --> Database Driver Class Initialized
DEBUG - 2016-09-25 22:42:48 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-25 22:42:48 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-25 22:42:48 --> Final output sent to browser
DEBUG - 2016-09-25 22:42:48 --> Total execution time: 0.1279
