<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-09-13 06:40:39 --> Config Class Initialized
INFO - 2016-09-13 06:40:39 --> Hooks Class Initialized
DEBUG - 2016-09-13 06:40:39 --> UTF-8 Support Enabled
INFO - 2016-09-13 06:40:39 --> Utf8 Class Initialized
INFO - 2016-09-13 06:40:39 --> URI Class Initialized
INFO - 2016-09-13 06:40:40 --> Router Class Initialized
INFO - 2016-09-13 06:40:40 --> Output Class Initialized
INFO - 2016-09-13 06:40:40 --> Security Class Initialized
DEBUG - 2016-09-13 06:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-13 06:40:40 --> Input Class Initialized
INFO - 2016-09-13 06:40:40 --> Language Class Initialized
INFO - 2016-09-13 06:40:40 --> Language Class Initialized
INFO - 2016-09-13 06:40:40 --> Config Class Initialized
INFO - 2016-09-13 06:40:41 --> Loader Class Initialized
INFO - 2016-09-13 06:40:41 --> Helper loaded: url_helper
INFO - 2016-09-13 06:40:41 --> Database Driver Class Initialized
INFO - 2016-09-13 06:40:41 --> Controller Class Initialized
DEBUG - 2016-09-13 06:40:41 --> Index MX_Controller Initialized
INFO - 2016-09-13 06:40:41 --> Model Class Initialized
INFO - 2016-09-13 06:40:41 --> Model Class Initialized
DEBUG - 2016-09-13 06:40:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-13 06:40:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-13 06:40:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-13 06:40:42 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-13 06:40:42 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-13 06:40:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-13 06:40:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-13 06:40:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-13 06:40:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-13 06:40:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-13 06:40:42 --> Final output sent to browser
DEBUG - 2016-09-13 06:40:42 --> Total execution time: 2.7659
INFO - 2016-09-13 06:40:52 --> Config Class Initialized
INFO - 2016-09-13 06:40:52 --> Hooks Class Initialized
DEBUG - 2016-09-13 06:40:52 --> UTF-8 Support Enabled
INFO - 2016-09-13 06:40:52 --> Utf8 Class Initialized
INFO - 2016-09-13 06:40:52 --> URI Class Initialized
INFO - 2016-09-13 06:40:52 --> Router Class Initialized
INFO - 2016-09-13 06:40:52 --> Output Class Initialized
INFO - 2016-09-13 06:40:52 --> Security Class Initialized
DEBUG - 2016-09-13 06:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-13 06:40:52 --> Input Class Initialized
INFO - 2016-09-13 06:40:52 --> Language Class Initialized
INFO - 2016-09-13 06:40:52 --> Language Class Initialized
INFO - 2016-09-13 06:40:52 --> Config Class Initialized
INFO - 2016-09-13 06:40:52 --> Loader Class Initialized
INFO - 2016-09-13 06:40:52 --> Helper loaded: url_helper
INFO - 2016-09-13 06:40:52 --> Database Driver Class Initialized
INFO - 2016-09-13 06:40:52 --> Controller Class Initialized
DEBUG - 2016-09-13 06:40:52 --> Index MX_Controller Initialized
INFO - 2016-09-13 06:40:52 --> Model Class Initialized
INFO - 2016-09-13 06:40:52 --> Model Class Initialized
DEBUG - 2016-09-13 06:40:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-13 06:40:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-13 06:40:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-13 06:40:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-13 06:40:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-13 06:40:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-13 06:40:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-13 06:40:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-13 06:40:52 --> Final output sent to browser
DEBUG - 2016-09-13 06:40:52 --> Total execution time: 0.6539
INFO - 2016-09-13 06:45:01 --> Config Class Initialized
INFO - 2016-09-13 06:45:01 --> Hooks Class Initialized
DEBUG - 2016-09-13 06:45:01 --> UTF-8 Support Enabled
INFO - 2016-09-13 06:45:01 --> Utf8 Class Initialized
INFO - 2016-09-13 06:45:01 --> URI Class Initialized
INFO - 2016-09-13 06:45:01 --> Router Class Initialized
INFO - 2016-09-13 06:45:01 --> Output Class Initialized
INFO - 2016-09-13 06:45:01 --> Security Class Initialized
DEBUG - 2016-09-13 06:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-13 06:45:01 --> Input Class Initialized
INFO - 2016-09-13 06:45:01 --> Language Class Initialized
INFO - 2016-09-13 06:45:01 --> Language Class Initialized
INFO - 2016-09-13 06:45:01 --> Config Class Initialized
INFO - 2016-09-13 06:45:01 --> Loader Class Initialized
INFO - 2016-09-13 06:45:01 --> Helper loaded: url_helper
INFO - 2016-09-13 06:45:01 --> Database Driver Class Initialized
INFO - 2016-09-13 06:45:01 --> Controller Class Initialized
DEBUG - 2016-09-13 06:45:01 --> Index MX_Controller Initialized
INFO - 2016-09-13 06:45:01 --> Model Class Initialized
INFO - 2016-09-13 06:45:01 --> Model Class Initialized
DEBUG - 2016-09-13 06:45:01 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-13 06:45:01 --> Users MX_Controller Initialized
INFO - 2016-09-13 06:45:02 --> Database Driver Class Initialized
INFO - 2016-09-13 06:45:02 --> Final output sent to browser
DEBUG - 2016-09-13 06:45:02 --> Total execution time: 0.5138
INFO - 2016-09-13 06:45:06 --> Config Class Initialized
INFO - 2016-09-13 06:45:06 --> Hooks Class Initialized
DEBUG - 2016-09-13 06:45:06 --> UTF-8 Support Enabled
INFO - 2016-09-13 06:45:06 --> Utf8 Class Initialized
INFO - 2016-09-13 06:45:06 --> URI Class Initialized
INFO - 2016-09-13 06:45:06 --> Router Class Initialized
INFO - 2016-09-13 06:45:06 --> Output Class Initialized
INFO - 2016-09-13 06:45:06 --> Security Class Initialized
DEBUG - 2016-09-13 06:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-13 06:45:06 --> Input Class Initialized
INFO - 2016-09-13 06:45:06 --> Language Class Initialized
INFO - 2016-09-13 06:45:06 --> Language Class Initialized
INFO - 2016-09-13 06:45:06 --> Config Class Initialized
INFO - 2016-09-13 06:45:06 --> Loader Class Initialized
INFO - 2016-09-13 06:45:06 --> Helper loaded: url_helper
INFO - 2016-09-13 06:45:07 --> Database Driver Class Initialized
INFO - 2016-09-13 06:45:07 --> Controller Class Initialized
DEBUG - 2016-09-13 06:45:07 --> Index MX_Controller Initialized
INFO - 2016-09-13 06:45:07 --> Model Class Initialized
INFO - 2016-09-13 06:45:07 --> Model Class Initialized
DEBUG - 2016-09-13 06:45:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-13 06:45:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-13 06:45:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-13 06:45:07 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-13 06:45:07 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-13 06:45:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-13 06:45:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-13 06:45:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-13 06:45:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-13 06:45:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-13 06:45:07 --> Final output sent to browser
DEBUG - 2016-09-13 06:45:07 --> Total execution time: 0.5964
INFO - 2016-09-13 06:45:26 --> Config Class Initialized
INFO - 2016-09-13 06:45:26 --> Hooks Class Initialized
DEBUG - 2016-09-13 06:45:26 --> UTF-8 Support Enabled
INFO - 2016-09-13 06:45:26 --> Utf8 Class Initialized
INFO - 2016-09-13 06:45:26 --> URI Class Initialized
INFO - 2016-09-13 06:45:26 --> Router Class Initialized
INFO - 2016-09-13 06:45:26 --> Output Class Initialized
INFO - 2016-09-13 06:45:26 --> Security Class Initialized
DEBUG - 2016-09-13 06:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-13 06:45:26 --> Input Class Initialized
INFO - 2016-09-13 06:45:26 --> Language Class Initialized
INFO - 2016-09-13 06:45:26 --> Language Class Initialized
INFO - 2016-09-13 06:45:26 --> Config Class Initialized
INFO - 2016-09-13 06:45:26 --> Loader Class Initialized
INFO - 2016-09-13 06:45:26 --> Helper loaded: url_helper
INFO - 2016-09-13 06:45:26 --> Database Driver Class Initialized
INFO - 2016-09-13 06:45:26 --> Controller Class Initialized
DEBUG - 2016-09-13 06:45:26 --> Index MX_Controller Initialized
INFO - 2016-09-13 06:45:26 --> Model Class Initialized
INFO - 2016-09-13 06:45:26 --> Model Class Initialized
DEBUG - 2016-09-13 06:45:26 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-13 06:45:26 --> Users MX_Controller Initialized
INFO - 2016-09-13 06:45:26 --> Final output sent to browser
DEBUG - 2016-09-13 06:45:26 --> Total execution time: 0.5832
INFO - 2016-09-13 06:45:40 --> Config Class Initialized
INFO - 2016-09-13 06:45:40 --> Hooks Class Initialized
DEBUG - 2016-09-13 06:45:40 --> UTF-8 Support Enabled
INFO - 2016-09-13 06:45:40 --> Utf8 Class Initialized
INFO - 2016-09-13 06:45:40 --> URI Class Initialized
INFO - 2016-09-13 06:45:40 --> Router Class Initialized
INFO - 2016-09-13 06:45:40 --> Output Class Initialized
INFO - 2016-09-13 06:45:40 --> Security Class Initialized
DEBUG - 2016-09-13 06:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-13 06:45:40 --> Input Class Initialized
INFO - 2016-09-13 06:45:40 --> Language Class Initialized
INFO - 2016-09-13 06:45:40 --> Language Class Initialized
INFO - 2016-09-13 06:45:40 --> Config Class Initialized
INFO - 2016-09-13 06:45:40 --> Loader Class Initialized
INFO - 2016-09-13 06:45:40 --> Helper loaded: url_helper
INFO - 2016-09-13 06:45:40 --> Database Driver Class Initialized
INFO - 2016-09-13 06:45:40 --> Controller Class Initialized
DEBUG - 2016-09-13 06:45:40 --> Index MX_Controller Initialized
INFO - 2016-09-13 06:45:40 --> Model Class Initialized
INFO - 2016-09-13 06:45:40 --> Model Class Initialized
DEBUG - 2016-09-13 06:45:40 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-13 06:45:40 --> Users MX_Controller Initialized
INFO - 2016-09-13 06:45:41 --> Final output sent to browser
DEBUG - 2016-09-13 06:45:41 --> Total execution time: 0.6122
INFO - 2016-09-13 06:46:19 --> Config Class Initialized
INFO - 2016-09-13 06:46:19 --> Hooks Class Initialized
DEBUG - 2016-09-13 06:46:19 --> UTF-8 Support Enabled
INFO - 2016-09-13 06:46:19 --> Utf8 Class Initialized
INFO - 2016-09-13 06:46:19 --> URI Class Initialized
INFO - 2016-09-13 06:46:19 --> Router Class Initialized
INFO - 2016-09-13 06:46:19 --> Output Class Initialized
INFO - 2016-09-13 06:46:19 --> Security Class Initialized
DEBUG - 2016-09-13 06:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-13 06:46:19 --> Input Class Initialized
INFO - 2016-09-13 06:46:19 --> Language Class Initialized
INFO - 2016-09-13 06:46:19 --> Language Class Initialized
INFO - 2016-09-13 06:46:19 --> Config Class Initialized
INFO - 2016-09-13 06:46:19 --> Loader Class Initialized
INFO - 2016-09-13 06:46:19 --> Helper loaded: url_helper
INFO - 2016-09-13 06:46:19 --> Database Driver Class Initialized
INFO - 2016-09-13 06:46:19 --> Controller Class Initialized
DEBUG - 2016-09-13 06:46:19 --> Index MX_Controller Initialized
INFO - 2016-09-13 06:46:19 --> Model Class Initialized
INFO - 2016-09-13 06:46:19 --> Model Class Initialized
DEBUG - 2016-09-13 06:46:19 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-13 06:46:19 --> Users MX_Controller Initialized
INFO - 2016-09-13 06:46:19 --> Final output sent to browser
DEBUG - 2016-09-13 06:46:19 --> Total execution time: 0.5009
INFO - 2016-09-13 06:46:38 --> Config Class Initialized
INFO - 2016-09-13 06:46:38 --> Hooks Class Initialized
DEBUG - 2016-09-13 06:46:38 --> UTF-8 Support Enabled
INFO - 2016-09-13 06:46:38 --> Utf8 Class Initialized
INFO - 2016-09-13 06:46:38 --> URI Class Initialized
INFO - 2016-09-13 06:46:38 --> Router Class Initialized
INFO - 2016-09-13 06:46:38 --> Output Class Initialized
INFO - 2016-09-13 06:46:38 --> Security Class Initialized
DEBUG - 2016-09-13 06:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-13 06:46:38 --> Input Class Initialized
INFO - 2016-09-13 06:46:38 --> Language Class Initialized
INFO - 2016-09-13 06:46:38 --> Language Class Initialized
INFO - 2016-09-13 06:46:38 --> Config Class Initialized
INFO - 2016-09-13 06:46:38 --> Loader Class Initialized
INFO - 2016-09-13 06:46:38 --> Helper loaded: url_helper
INFO - 2016-09-13 06:46:38 --> Database Driver Class Initialized
INFO - 2016-09-13 06:46:38 --> Controller Class Initialized
DEBUG - 2016-09-13 06:46:38 --> Index MX_Controller Initialized
INFO - 2016-09-13 06:46:38 --> Model Class Initialized
INFO - 2016-09-13 06:46:38 --> Model Class Initialized
DEBUG - 2016-09-13 06:46:38 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-13 06:46:38 --> Users MX_Controller Initialized
INFO - 2016-09-13 06:46:38 --> Final output sent to browser
DEBUG - 2016-09-13 06:46:38 --> Total execution time: 0.6371
INFO - 2016-09-13 06:46:48 --> Config Class Initialized
INFO - 2016-09-13 06:46:48 --> Hooks Class Initialized
DEBUG - 2016-09-13 06:46:48 --> UTF-8 Support Enabled
INFO - 2016-09-13 06:46:48 --> Utf8 Class Initialized
INFO - 2016-09-13 06:46:48 --> URI Class Initialized
INFO - 2016-09-13 06:46:48 --> Router Class Initialized
INFO - 2016-09-13 06:46:48 --> Output Class Initialized
INFO - 2016-09-13 06:46:48 --> Security Class Initialized
DEBUG - 2016-09-13 06:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-13 06:46:48 --> Input Class Initialized
INFO - 2016-09-13 06:46:48 --> Language Class Initialized
INFO - 2016-09-13 06:46:48 --> Language Class Initialized
INFO - 2016-09-13 06:46:48 --> Config Class Initialized
INFO - 2016-09-13 06:46:48 --> Loader Class Initialized
INFO - 2016-09-13 06:46:48 --> Helper loaded: url_helper
INFO - 2016-09-13 06:46:48 --> Database Driver Class Initialized
INFO - 2016-09-13 06:46:48 --> Controller Class Initialized
DEBUG - 2016-09-13 06:46:48 --> Index MX_Controller Initialized
INFO - 2016-09-13 06:46:48 --> Model Class Initialized
INFO - 2016-09-13 06:46:48 --> Model Class Initialized
DEBUG - 2016-09-13 06:46:48 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-13 06:46:48 --> Users MX_Controller Initialized
INFO - 2016-09-13 06:46:49 --> Final output sent to browser
DEBUG - 2016-09-13 06:46:49 --> Total execution time: 0.5580
INFO - 2016-09-13 06:46:53 --> Config Class Initialized
INFO - 2016-09-13 06:46:53 --> Hooks Class Initialized
DEBUG - 2016-09-13 06:46:53 --> UTF-8 Support Enabled
INFO - 2016-09-13 06:46:53 --> Utf8 Class Initialized
INFO - 2016-09-13 06:46:53 --> URI Class Initialized
INFO - 2016-09-13 06:46:53 --> Router Class Initialized
INFO - 2016-09-13 06:46:53 --> Output Class Initialized
INFO - 2016-09-13 06:46:53 --> Security Class Initialized
DEBUG - 2016-09-13 06:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-13 06:46:53 --> Input Class Initialized
INFO - 2016-09-13 06:46:53 --> Language Class Initialized
INFO - 2016-09-13 06:46:53 --> Language Class Initialized
INFO - 2016-09-13 06:46:53 --> Config Class Initialized
INFO - 2016-09-13 06:46:53 --> Loader Class Initialized
INFO - 2016-09-13 06:46:53 --> Helper loaded: url_helper
INFO - 2016-09-13 06:46:53 --> Database Driver Class Initialized
INFO - 2016-09-13 06:46:53 --> Controller Class Initialized
DEBUG - 2016-09-13 06:46:53 --> Index MX_Controller Initialized
INFO - 2016-09-13 06:46:53 --> Model Class Initialized
INFO - 2016-09-13 06:46:53 --> Model Class Initialized
DEBUG - 2016-09-13 06:46:53 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-13 06:46:53 --> Users MX_Controller Initialized
INFO - 2016-09-13 06:46:53 --> Final output sent to browser
DEBUG - 2016-09-13 06:46:53 --> Total execution time: 0.7052
INFO - 2016-09-13 06:47:01 --> Config Class Initialized
INFO - 2016-09-13 06:47:01 --> Hooks Class Initialized
DEBUG - 2016-09-13 06:47:01 --> UTF-8 Support Enabled
INFO - 2016-09-13 06:47:01 --> Utf8 Class Initialized
INFO - 2016-09-13 06:47:01 --> URI Class Initialized
INFO - 2016-09-13 06:47:01 --> Router Class Initialized
INFO - 2016-09-13 06:47:01 --> Output Class Initialized
INFO - 2016-09-13 06:47:01 --> Security Class Initialized
DEBUG - 2016-09-13 06:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-13 06:47:01 --> Input Class Initialized
INFO - 2016-09-13 06:47:01 --> Language Class Initialized
INFO - 2016-09-13 06:47:01 --> Language Class Initialized
INFO - 2016-09-13 06:47:01 --> Config Class Initialized
INFO - 2016-09-13 06:47:01 --> Loader Class Initialized
INFO - 2016-09-13 06:47:01 --> Helper loaded: url_helper
INFO - 2016-09-13 06:47:01 --> Database Driver Class Initialized
INFO - 2016-09-13 06:47:01 --> Controller Class Initialized
DEBUG - 2016-09-13 06:47:01 --> Index MX_Controller Initialized
INFO - 2016-09-13 06:47:01 --> Model Class Initialized
INFO - 2016-09-13 06:47:01 --> Model Class Initialized
DEBUG - 2016-09-13 06:47:01 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-13 06:47:01 --> Users MX_Controller Initialized
INFO - 2016-09-13 06:47:01 --> Final output sent to browser
DEBUG - 2016-09-13 06:47:01 --> Total execution time: 0.5807
INFO - 2016-09-13 06:47:32 --> Config Class Initialized
INFO - 2016-09-13 06:47:32 --> Hooks Class Initialized
DEBUG - 2016-09-13 06:47:32 --> UTF-8 Support Enabled
INFO - 2016-09-13 06:47:32 --> Utf8 Class Initialized
INFO - 2016-09-13 06:47:32 --> URI Class Initialized
INFO - 2016-09-13 06:47:32 --> Router Class Initialized
INFO - 2016-09-13 06:47:32 --> Output Class Initialized
INFO - 2016-09-13 06:47:32 --> Security Class Initialized
DEBUG - 2016-09-13 06:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-13 06:47:32 --> Input Class Initialized
INFO - 2016-09-13 06:47:32 --> Language Class Initialized
INFO - 2016-09-13 06:47:33 --> Language Class Initialized
INFO - 2016-09-13 06:47:33 --> Config Class Initialized
INFO - 2016-09-13 06:47:33 --> Loader Class Initialized
INFO - 2016-09-13 06:47:33 --> Helper loaded: url_helper
INFO - 2016-09-13 06:47:33 --> Database Driver Class Initialized
INFO - 2016-09-13 06:47:33 --> Controller Class Initialized
DEBUG - 2016-09-13 06:47:33 --> Index MX_Controller Initialized
INFO - 2016-09-13 06:47:33 --> Model Class Initialized
INFO - 2016-09-13 06:47:33 --> Model Class Initialized
DEBUG - 2016-09-13 06:47:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-13 06:47:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-13 06:47:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-13 06:47:33 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/user/controllers/Users.php
DEBUG - 2016-09-13 06:47:33 --> Users MX_Controller Initialized
DEBUG - 2016-09-13 06:47:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_user.php
DEBUG - 2016-09-13 06:47:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-13 06:47:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-13 06:47:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-13 06:47:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-13 06:47:33 --> Final output sent to browser
DEBUG - 2016-09-13 06:47:33 --> Total execution time: 0.6492
INFO - 2016-09-13 06:48:07 --> Config Class Initialized
INFO - 2016-09-13 06:48:07 --> Hooks Class Initialized
DEBUG - 2016-09-13 06:48:07 --> UTF-8 Support Enabled
INFO - 2016-09-13 06:48:07 --> Utf8 Class Initialized
INFO - 2016-09-13 06:48:07 --> URI Class Initialized
INFO - 2016-09-13 06:48:07 --> Router Class Initialized
INFO - 2016-09-13 06:48:07 --> Output Class Initialized
INFO - 2016-09-13 06:48:07 --> Security Class Initialized
DEBUG - 2016-09-13 06:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-13 06:48:07 --> Input Class Initialized
INFO - 2016-09-13 06:48:07 --> Language Class Initialized
INFO - 2016-09-13 06:48:07 --> Language Class Initialized
INFO - 2016-09-13 06:48:07 --> Config Class Initialized
INFO - 2016-09-13 06:48:07 --> Loader Class Initialized
INFO - 2016-09-13 06:48:08 --> Helper loaded: url_helper
INFO - 2016-09-13 06:48:08 --> Database Driver Class Initialized
INFO - 2016-09-13 06:48:08 --> Controller Class Initialized
DEBUG - 2016-09-13 06:48:08 --> Index MX_Controller Initialized
INFO - 2016-09-13 06:48:08 --> Model Class Initialized
INFO - 2016-09-13 06:48:08 --> Model Class Initialized
DEBUG - 2016-09-13 06:48:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-13 06:48:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-13 06:48:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-13 06:48:08 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-13 06:48:08 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-13 06:48:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-13 06:48:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-13 06:48:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-13 06:48:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-13 06:48:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-13 06:48:08 --> Final output sent to browser
DEBUG - 2016-09-13 06:48:08 --> Total execution time: 0.5728
INFO - 2016-09-13 06:48:38 --> Config Class Initialized
INFO - 2016-09-13 06:48:38 --> Hooks Class Initialized
DEBUG - 2016-09-13 06:48:38 --> UTF-8 Support Enabled
INFO - 2016-09-13 06:48:38 --> Utf8 Class Initialized
INFO - 2016-09-13 06:48:38 --> URI Class Initialized
INFO - 2016-09-13 06:48:38 --> Router Class Initialized
INFO - 2016-09-13 06:48:38 --> Output Class Initialized
INFO - 2016-09-13 06:48:38 --> Security Class Initialized
DEBUG - 2016-09-13 06:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-13 06:48:38 --> Input Class Initialized
INFO - 2016-09-13 06:48:38 --> Language Class Initialized
INFO - 2016-09-13 06:48:38 --> Language Class Initialized
INFO - 2016-09-13 06:48:38 --> Config Class Initialized
INFO - 2016-09-13 06:48:38 --> Loader Class Initialized
INFO - 2016-09-13 06:48:38 --> Helper loaded: url_helper
INFO - 2016-09-13 06:48:38 --> Database Driver Class Initialized
INFO - 2016-09-13 06:48:38 --> Controller Class Initialized
DEBUG - 2016-09-13 06:48:38 --> Index MX_Controller Initialized
INFO - 2016-09-13 06:48:38 --> Model Class Initialized
INFO - 2016-09-13 06:48:39 --> Model Class Initialized
DEBUG - 2016-09-13 06:48:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-13 06:48:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-13 06:48:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-13 06:48:39 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-13 06:48:39 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-13 06:48:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-13 06:48:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-13 06:48:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-13 06:48:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-13 06:48:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-13 06:48:39 --> Final output sent to browser
DEBUG - 2016-09-13 06:48:39 --> Total execution time: 0.5917
INFO - 2016-09-13 06:48:45 --> Config Class Initialized
INFO - 2016-09-13 06:48:45 --> Hooks Class Initialized
DEBUG - 2016-09-13 06:48:45 --> UTF-8 Support Enabled
INFO - 2016-09-13 06:48:45 --> Utf8 Class Initialized
INFO - 2016-09-13 06:48:45 --> URI Class Initialized
INFO - 2016-09-13 06:48:45 --> Router Class Initialized
INFO - 2016-09-13 06:48:45 --> Output Class Initialized
INFO - 2016-09-13 06:48:45 --> Security Class Initialized
DEBUG - 2016-09-13 06:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-13 06:48:45 --> Input Class Initialized
INFO - 2016-09-13 06:48:45 --> Language Class Initialized
INFO - 2016-09-13 06:48:45 --> Language Class Initialized
INFO - 2016-09-13 06:48:45 --> Config Class Initialized
INFO - 2016-09-13 06:48:45 --> Loader Class Initialized
INFO - 2016-09-13 06:48:45 --> Helper loaded: url_helper
INFO - 2016-09-13 06:48:45 --> Database Driver Class Initialized
INFO - 2016-09-13 06:48:45 --> Controller Class Initialized
DEBUG - 2016-09-13 06:48:45 --> Index MX_Controller Initialized
INFO - 2016-09-13 06:48:45 --> Model Class Initialized
INFO - 2016-09-13 06:48:45 --> Model Class Initialized
DEBUG - 2016-09-13 06:48:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-13 06:48:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-13 06:48:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-13 06:48:45 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-13 06:48:45 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-13 06:48:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-13 06:48:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-13 06:48:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-13 06:48:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-13 06:48:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-13 06:48:45 --> Final output sent to browser
DEBUG - 2016-09-13 06:48:45 --> Total execution time: 0.6347
INFO - 2016-09-13 06:49:08 --> Config Class Initialized
INFO - 2016-09-13 06:49:08 --> Hooks Class Initialized
DEBUG - 2016-09-13 06:49:08 --> UTF-8 Support Enabled
INFO - 2016-09-13 06:49:08 --> Utf8 Class Initialized
INFO - 2016-09-13 06:49:09 --> URI Class Initialized
INFO - 2016-09-13 06:49:09 --> Router Class Initialized
INFO - 2016-09-13 06:49:09 --> Output Class Initialized
INFO - 2016-09-13 06:49:09 --> Security Class Initialized
DEBUG - 2016-09-13 06:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-13 06:49:09 --> Input Class Initialized
INFO - 2016-09-13 06:49:09 --> Language Class Initialized
INFO - 2016-09-13 06:49:09 --> Language Class Initialized
INFO - 2016-09-13 06:49:09 --> Config Class Initialized
INFO - 2016-09-13 06:49:09 --> Loader Class Initialized
INFO - 2016-09-13 06:49:09 --> Helper loaded: url_helper
INFO - 2016-09-13 06:49:09 --> Database Driver Class Initialized
INFO - 2016-09-13 06:49:09 --> Controller Class Initialized
DEBUG - 2016-09-13 06:49:09 --> Index MX_Controller Initialized
INFO - 2016-09-13 06:49:09 --> Model Class Initialized
INFO - 2016-09-13 06:49:09 --> Model Class Initialized
DEBUG - 2016-09-13 06:49:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-13 06:49:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-13 06:49:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-13 06:49:09 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-13 06:49:09 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-13 06:49:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-13 06:49:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-13 06:49:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-13 06:49:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-13 06:49:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-13 06:49:09 --> Final output sent to browser
DEBUG - 2016-09-13 06:49:09 --> Total execution time: 0.7533
INFO - 2016-09-13 06:49:19 --> Config Class Initialized
INFO - 2016-09-13 06:49:19 --> Hooks Class Initialized
DEBUG - 2016-09-13 06:49:19 --> UTF-8 Support Enabled
INFO - 2016-09-13 06:49:19 --> Utf8 Class Initialized
INFO - 2016-09-13 06:49:19 --> URI Class Initialized
INFO - 2016-09-13 06:49:19 --> Router Class Initialized
INFO - 2016-09-13 06:49:19 --> Output Class Initialized
INFO - 2016-09-13 06:49:19 --> Security Class Initialized
DEBUG - 2016-09-13 06:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-13 06:49:19 --> Input Class Initialized
INFO - 2016-09-13 06:49:19 --> Language Class Initialized
INFO - 2016-09-13 06:49:19 --> Language Class Initialized
INFO - 2016-09-13 06:49:19 --> Config Class Initialized
INFO - 2016-09-13 06:49:19 --> Loader Class Initialized
INFO - 2016-09-13 06:49:19 --> Helper loaded: url_helper
INFO - 2016-09-13 06:49:19 --> Database Driver Class Initialized
INFO - 2016-09-13 06:49:19 --> Controller Class Initialized
DEBUG - 2016-09-13 06:49:19 --> Index MX_Controller Initialized
INFO - 2016-09-13 06:49:20 --> Model Class Initialized
INFO - 2016-09-13 06:49:20 --> Model Class Initialized
DEBUG - 2016-09-13 06:49:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-13 06:49:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-13 06:49:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-13 06:49:20 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-13 06:49:20 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-13 06:49:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-13 06:49:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-13 06:49:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-13 06:49:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-13 06:49:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-13 06:49:20 --> Final output sent to browser
DEBUG - 2016-09-13 06:49:20 --> Total execution time: 0.6765
