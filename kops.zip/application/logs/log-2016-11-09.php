<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-11-09 18:11:15 --> Config Class Initialized
INFO - 2016-11-09 18:11:15 --> Hooks Class Initialized
DEBUG - 2016-11-09 18:11:15 --> UTF-8 Support Enabled
INFO - 2016-11-09 18:11:15 --> Utf8 Class Initialized
INFO - 2016-11-09 18:11:15 --> URI Class Initialized
INFO - 2016-11-09 18:11:15 --> Router Class Initialized
INFO - 2016-11-09 18:11:15 --> Output Class Initialized
INFO - 2016-11-09 18:11:15 --> Security Class Initialized
DEBUG - 2016-11-09 18:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 18:11:15 --> Input Class Initialized
INFO - 2016-11-09 18:11:15 --> Language Class Initialized
INFO - 2016-11-09 18:11:15 --> Language Class Initialized
INFO - 2016-11-09 18:11:15 --> Config Class Initialized
INFO - 2016-11-09 18:11:15 --> Loader Class Initialized
INFO - 2016-11-09 18:11:15 --> Helper loaded: url_helper
INFO - 2016-11-09 18:11:15 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 18:11:15 --> Controller Class Initialized
DEBUG - 2016-11-09 18:11:15 --> Index MX_Controller Initialized
INFO - 2016-11-09 18:11:15 --> Model Class Initialized
INFO - 2016-11-09 18:11:15 --> Model Class Initialized
ERROR - 2016-11-09 18:11:15 --> Unable to delete cache file for admin/index/test_date
INFO - 2016-11-09 18:11:15 --> Final output sent to browser
DEBUG - 2016-11-09 18:11:15 --> Total execution time: 0.7644
INFO - 2016-11-09 18:11:15 --> Config Class Initialized
INFO - 2016-11-09 18:11:16 --> Hooks Class Initialized
DEBUG - 2016-11-09 18:11:16 --> UTF-8 Support Enabled
INFO - 2016-11-09 18:11:16 --> Utf8 Class Initialized
INFO - 2016-11-09 18:11:16 --> URI Class Initialized
INFO - 2016-11-09 18:11:16 --> Router Class Initialized
INFO - 2016-11-09 18:11:16 --> Output Class Initialized
INFO - 2016-11-09 18:11:16 --> Security Class Initialized
DEBUG - 2016-11-09 18:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 18:11:16 --> Input Class Initialized
INFO - 2016-11-09 18:11:16 --> Language Class Initialized
INFO - 2016-11-09 18:11:16 --> Language Class Initialized
INFO - 2016-11-09 18:11:16 --> Config Class Initialized
INFO - 2016-11-09 18:11:16 --> Loader Class Initialized
INFO - 2016-11-09 18:11:16 --> Helper loaded: url_helper
INFO - 2016-11-09 18:11:16 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 18:11:16 --> Controller Class Initialized
DEBUG - 2016-11-09 18:11:16 --> login MX_Controller Initialized
INFO - 2016-11-09 18:11:16 --> Model Class Initialized
INFO - 2016-11-09 18:11:16 --> Model Class Initialized
DEBUG - 2016-11-09 18:11:16 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/login.php
INFO - 2016-11-09 18:11:16 --> Final output sent to browser
DEBUG - 2016-11-09 18:11:16 --> Total execution time: 0.7452
INFO - 2016-11-09 18:11:20 --> Config Class Initialized
INFO - 2016-11-09 18:11:20 --> Hooks Class Initialized
DEBUG - 2016-11-09 18:11:20 --> UTF-8 Support Enabled
INFO - 2016-11-09 18:11:20 --> Utf8 Class Initialized
INFO - 2016-11-09 18:11:20 --> URI Class Initialized
INFO - 2016-11-09 18:11:20 --> Router Class Initialized
INFO - 2016-11-09 18:11:20 --> Output Class Initialized
INFO - 2016-11-09 18:11:20 --> Security Class Initialized
DEBUG - 2016-11-09 18:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 18:11:20 --> Input Class Initialized
INFO - 2016-11-09 18:11:20 --> Language Class Initialized
INFO - 2016-11-09 18:11:20 --> Language Class Initialized
INFO - 2016-11-09 18:11:20 --> Config Class Initialized
INFO - 2016-11-09 18:11:20 --> Loader Class Initialized
INFO - 2016-11-09 18:11:20 --> Helper loaded: url_helper
INFO - 2016-11-09 18:11:20 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 18:11:20 --> Controller Class Initialized
DEBUG - 2016-11-09 18:11:21 --> login MX_Controller Initialized
INFO - 2016-11-09 18:11:21 --> Model Class Initialized
INFO - 2016-11-09 18:11:21 --> Model Class Initialized
INFO - 2016-11-09 18:11:21 --> Final output sent to browser
DEBUG - 2016-11-09 18:11:21 --> Total execution time: 0.7924
INFO - 2016-11-09 18:11:21 --> Config Class Initialized
INFO - 2016-11-09 18:11:21 --> Hooks Class Initialized
DEBUG - 2016-11-09 18:11:21 --> UTF-8 Support Enabled
INFO - 2016-11-09 18:11:21 --> Utf8 Class Initialized
INFO - 2016-11-09 18:11:21 --> URI Class Initialized
INFO - 2016-11-09 18:11:21 --> Router Class Initialized
INFO - 2016-11-09 18:11:21 --> Output Class Initialized
INFO - 2016-11-09 18:11:21 --> Security Class Initialized
DEBUG - 2016-11-09 18:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 18:11:21 --> Input Class Initialized
INFO - 2016-11-09 18:11:21 --> Language Class Initialized
INFO - 2016-11-09 18:11:21 --> Language Class Initialized
INFO - 2016-11-09 18:11:21 --> Config Class Initialized
INFO - 2016-11-09 18:11:21 --> Loader Class Initialized
INFO - 2016-11-09 18:11:21 --> Helper loaded: url_helper
INFO - 2016-11-09 18:11:21 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 18:11:21 --> Controller Class Initialized
DEBUG - 2016-11-09 18:11:21 --> Index MX_Controller Initialized
INFO - 2016-11-09 18:11:21 --> Model Class Initialized
INFO - 2016-11-09 18:11:21 --> Model Class Initialized
ERROR - 2016-11-09 18:11:21 --> Unable to delete cache file for admin/index
DEBUG - 2016-11-09 18:11:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-11-09 18:11:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-11-09 18:11:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-11-09 18:11:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/dashboard.php
DEBUG - 2016-11-09 18:11:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-11-09 18:11:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-11-09 18:11:22 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:22 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:22 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:22 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:22 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:22 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:22 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:22 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:22 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:22 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:22 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:22 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:22 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:22 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:22 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:22 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:22 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:22 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:22 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:22 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:22 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:22 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:22 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:22 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:22 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:22 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:22 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:22 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:22 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:23 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:23 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:23 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:23 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:23 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:23 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:23 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:23 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:23 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:23 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:23 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:23 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:23 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:23 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:23 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:23 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:23 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:23 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:23 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:23 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:23 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:23 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:23 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:23 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:23 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:23 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:23 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:24 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:24 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:24 --> Database Driver Class Initialized
DEBUG - 2016-11-09 18:11:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-11-09 18:11:24 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-11-09 18:11:24 --> Final output sent to browser
DEBUG - 2016-11-09 18:11:24 --> Total execution time: 3.3860
INFO - 2016-11-09 18:11:29 --> Config Class Initialized
INFO - 2016-11-09 18:11:29 --> Hooks Class Initialized
DEBUG - 2016-11-09 18:11:29 --> UTF-8 Support Enabled
INFO - 2016-11-09 18:11:30 --> Utf8 Class Initialized
INFO - 2016-11-09 18:11:30 --> URI Class Initialized
INFO - 2016-11-09 18:11:30 --> Router Class Initialized
INFO - 2016-11-09 18:11:30 --> Output Class Initialized
INFO - 2016-11-09 18:11:30 --> Security Class Initialized
DEBUG - 2016-11-09 18:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 18:11:30 --> Input Class Initialized
INFO - 2016-11-09 18:11:30 --> Language Class Initialized
INFO - 2016-11-09 18:11:30 --> Language Class Initialized
INFO - 2016-11-09 18:11:30 --> Config Class Initialized
INFO - 2016-11-09 18:11:30 --> Loader Class Initialized
INFO - 2016-11-09 18:11:30 --> Helper loaded: url_helper
INFO - 2016-11-09 18:11:30 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 18:11:30 --> Controller Class Initialized
DEBUG - 2016-11-09 18:11:31 --> Index MX_Controller Initialized
INFO - 2016-11-09 18:11:31 --> Model Class Initialized
INFO - 2016-11-09 18:11:31 --> Model Class Initialized
ERROR - 2016-11-09 18:11:31 --> Unable to delete cache file for admin/index/test_date
INFO - 2016-11-09 18:11:31 --> Final output sent to browser
DEBUG - 2016-11-09 18:11:31 --> Total execution time: 1.6019
INFO - 2016-11-09 18:11:59 --> Config Class Initialized
INFO - 2016-11-09 18:11:59 --> Hooks Class Initialized
DEBUG - 2016-11-09 18:11:59 --> UTF-8 Support Enabled
INFO - 2016-11-09 18:11:59 --> Utf8 Class Initialized
INFO - 2016-11-09 18:11:59 --> URI Class Initialized
INFO - 2016-11-09 18:11:59 --> Router Class Initialized
INFO - 2016-11-09 18:11:59 --> Output Class Initialized
INFO - 2016-11-09 18:11:59 --> Security Class Initialized
DEBUG - 2016-11-09 18:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 18:11:59 --> Input Class Initialized
INFO - 2016-11-09 18:11:59 --> Language Class Initialized
INFO - 2016-11-09 18:11:59 --> Language Class Initialized
INFO - 2016-11-09 18:11:59 --> Config Class Initialized
INFO - 2016-11-09 18:11:59 --> Loader Class Initialized
INFO - 2016-11-09 18:11:59 --> Helper loaded: url_helper
INFO - 2016-11-09 18:11:59 --> Database Driver Class Initialized
INFO - 2016-11-09 18:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 18:11:59 --> Controller Class Initialized
DEBUG - 2016-11-09 18:11:59 --> Index MX_Controller Initialized
INFO - 2016-11-09 18:11:59 --> Model Class Initialized
INFO - 2016-11-09 18:11:59 --> Model Class Initialized
ERROR - 2016-11-09 18:11:59 --> Unable to delete cache file for admin/index/test_date
INFO - 2016-11-09 18:11:59 --> Final output sent to browser
DEBUG - 2016-11-09 18:11:59 --> Total execution time: 0.7509
INFO - 2016-11-09 18:12:26 --> Config Class Initialized
INFO - 2016-11-09 18:12:26 --> Hooks Class Initialized
DEBUG - 2016-11-09 18:12:26 --> UTF-8 Support Enabled
INFO - 2016-11-09 18:12:26 --> Utf8 Class Initialized
INFO - 2016-11-09 18:12:26 --> URI Class Initialized
INFO - 2016-11-09 18:12:26 --> Router Class Initialized
INFO - 2016-11-09 18:12:26 --> Output Class Initialized
INFO - 2016-11-09 18:12:26 --> Security Class Initialized
DEBUG - 2016-11-09 18:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 18:12:26 --> Input Class Initialized
INFO - 2016-11-09 18:12:26 --> Language Class Initialized
INFO - 2016-11-09 18:12:26 --> Language Class Initialized
INFO - 2016-11-09 18:12:26 --> Config Class Initialized
INFO - 2016-11-09 18:12:26 --> Loader Class Initialized
INFO - 2016-11-09 18:12:26 --> Helper loaded: url_helper
INFO - 2016-11-09 18:12:26 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 18:12:26 --> Controller Class Initialized
DEBUG - 2016-11-09 18:12:26 --> Index MX_Controller Initialized
INFO - 2016-11-09 18:12:26 --> Model Class Initialized
INFO - 2016-11-09 18:12:26 --> Model Class Initialized
ERROR - 2016-11-09 18:12:26 --> Unable to delete cache file for admin/index/bayar_angsuran
DEBUG - 2016-11-09 18:12:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-11-09 18:12:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-11-09 18:12:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-11-09 18:12:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/form_bayar_angsuran.php
DEBUG - 2016-11-09 18:12:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-11-09 18:12:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-11-09 18:12:26 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:27 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:27 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:27 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:27 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:27 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:27 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:27 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:27 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:27 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:27 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:27 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:27 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:27 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:27 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:27 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:27 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:27 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:27 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:27 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:27 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:27 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:27 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:27 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:27 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:27 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:27 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:27 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:27 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:27 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:27 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:27 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:27 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:27 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:28 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:28 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:28 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:28 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:28 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:28 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:28 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:28 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:28 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:28 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:28 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:28 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:28 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:28 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:28 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:28 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:28 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:28 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:28 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:28 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:28 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:28 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:28 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:28 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:28 --> Database Driver Class Initialized
DEBUG - 2016-11-09 18:12:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-11-09 18:12:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-11-09 18:12:28 --> Final output sent to browser
DEBUG - 2016-11-09 18:12:29 --> Total execution time: 2.8050
INFO - 2016-11-09 18:12:39 --> Config Class Initialized
INFO - 2016-11-09 18:12:39 --> Hooks Class Initialized
DEBUG - 2016-11-09 18:12:39 --> UTF-8 Support Enabled
INFO - 2016-11-09 18:12:39 --> Utf8 Class Initialized
INFO - 2016-11-09 18:12:39 --> URI Class Initialized
INFO - 2016-11-09 18:12:39 --> Router Class Initialized
INFO - 2016-11-09 18:12:39 --> Output Class Initialized
INFO - 2016-11-09 18:12:39 --> Security Class Initialized
DEBUG - 2016-11-09 18:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 18:12:39 --> Input Class Initialized
INFO - 2016-11-09 18:12:39 --> Language Class Initialized
INFO - 2016-11-09 18:12:39 --> Language Class Initialized
INFO - 2016-11-09 18:12:39 --> Config Class Initialized
INFO - 2016-11-09 18:12:39 --> Loader Class Initialized
INFO - 2016-11-09 18:12:39 --> Helper loaded: url_helper
INFO - 2016-11-09 18:12:39 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 18:12:39 --> Controller Class Initialized
DEBUG - 2016-11-09 18:12:39 --> Index MX_Controller Initialized
INFO - 2016-11-09 18:12:40 --> Model Class Initialized
INFO - 2016-11-09 18:12:40 --> Model Class Initialized
ERROR - 2016-11-09 18:12:40 --> Unable to delete cache file for admin/index/getDetailAngsuran
INFO - 2016-11-09 18:12:40 --> Database Driver Class Initialized
INFO - 2016-11-09 18:12:40 --> Final output sent to browser
DEBUG - 2016-11-09 18:12:40 --> Total execution time: 0.7042
