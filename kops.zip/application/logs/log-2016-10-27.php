<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-10-27 09:07:49 --> Config Class Initialized
INFO - 2016-10-27 09:07:49 --> Hooks Class Initialized
DEBUG - 2016-10-27 09:07:49 --> UTF-8 Support Enabled
INFO - 2016-10-27 09:07:49 --> Utf8 Class Initialized
INFO - 2016-10-27 09:07:49 --> URI Class Initialized
DEBUG - 2016-10-27 09:07:49 --> No URI present. Default controller set.
INFO - 2016-10-27 09:07:49 --> Router Class Initialized
INFO - 2016-10-27 09:07:49 --> Output Class Initialized
INFO - 2016-10-27 09:07:49 --> Security Class Initialized
DEBUG - 2016-10-27 09:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-27 09:07:50 --> Input Class Initialized
INFO - 2016-10-27 09:07:50 --> Language Class Initialized
INFO - 2016-10-27 09:07:50 --> Language Class Initialized
INFO - 2016-10-27 09:07:50 --> Config Class Initialized
INFO - 2016-10-27 09:07:50 --> Loader Class Initialized
INFO - 2016-10-27 09:07:50 --> Helper loaded: url_helper
INFO - 2016-10-27 09:07:50 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-27 09:07:50 --> Controller Class Initialized
DEBUG - 2016-10-27 09:07:50 --> Index MX_Controller Initialized
INFO - 2016-10-27 09:07:51 --> Model Class Initialized
INFO - 2016-10-27 09:07:51 --> Model Class Initialized
ERROR - 2016-10-27 09:07:51 --> Unable to delete cache file for 
DEBUG - 2016-10-27 09:07:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-27 09:07:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-27 09:07:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-27 09:07:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/dashboard.php
DEBUG - 2016-10-27 09:07:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-27 09:07:51 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-27 09:07:51 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:51 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:51 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:51 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:51 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:51 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:51 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:51 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:51 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:51 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:51 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:51 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:51 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:51 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:51 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:52 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:52 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:52 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:52 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:52 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:52 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:52 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:52 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:52 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:52 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:52 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:52 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:52 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:52 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:52 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:52 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:52 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:52 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:52 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:52 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:52 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:52 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:52 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:52 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:52 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:52 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:52 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:52 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:52 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:52 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:52 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:52 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:52 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:52 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:52 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:52 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:53 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:53 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:53 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:53 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:53 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:53 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:53 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:53 --> Database Driver Class Initialized
DEBUG - 2016-10-27 09:07:53 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-27 09:07:53 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-27 09:07:53 --> Final output sent to browser
INFO - 2016-10-27 09:07:53 --> Config Class Initialized
INFO - 2016-10-27 09:07:53 --> Hooks Class Initialized
DEBUG - 2016-10-27 09:07:53 --> Total execution time: 4.1151
DEBUG - 2016-10-27 09:07:53 --> UTF-8 Support Enabled
INFO - 2016-10-27 09:07:53 --> Utf8 Class Initialized
INFO - 2016-10-27 09:07:53 --> URI Class Initialized
INFO - 2016-10-27 09:07:53 --> Router Class Initialized
INFO - 2016-10-27 09:07:53 --> Output Class Initialized
INFO - 2016-10-27 09:07:53 --> Security Class Initialized
DEBUG - 2016-10-27 09:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-27 09:07:53 --> Input Class Initialized
INFO - 2016-10-27 09:07:53 --> Language Class Initialized
INFO - 2016-10-27 09:07:53 --> Language Class Initialized
INFO - 2016-10-27 09:07:53 --> Config Class Initialized
INFO - 2016-10-27 09:07:53 --> Loader Class Initialized
INFO - 2016-10-27 09:07:53 --> Helper loaded: url_helper
INFO - 2016-10-27 09:07:53 --> Database Driver Class Initialized
INFO - 2016-10-27 09:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-27 09:07:53 --> Controller Class Initialized
DEBUG - 2016-10-27 09:07:53 --> login MX_Controller Initialized
INFO - 2016-10-27 09:07:53 --> Model Class Initialized
INFO - 2016-10-27 09:07:53 --> Model Class Initialized
DEBUG - 2016-10-27 09:07:53 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/login.php
INFO - 2016-10-27 09:07:53 --> Final output sent to browser
DEBUG - 2016-10-27 09:07:53 --> Total execution time: 0.5044
INFO - 2016-10-27 09:08:03 --> Config Class Initialized
INFO - 2016-10-27 09:08:03 --> Hooks Class Initialized
DEBUG - 2016-10-27 09:08:03 --> UTF-8 Support Enabled
INFO - 2016-10-27 09:08:03 --> Utf8 Class Initialized
INFO - 2016-10-27 09:08:03 --> URI Class Initialized
INFO - 2016-10-27 09:08:03 --> Router Class Initialized
INFO - 2016-10-27 09:08:03 --> Output Class Initialized
INFO - 2016-10-27 09:08:03 --> Security Class Initialized
DEBUG - 2016-10-27 09:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-27 09:08:03 --> Input Class Initialized
INFO - 2016-10-27 09:08:03 --> Language Class Initialized
INFO - 2016-10-27 09:08:03 --> Language Class Initialized
INFO - 2016-10-27 09:08:03 --> Config Class Initialized
INFO - 2016-10-27 09:08:03 --> Loader Class Initialized
INFO - 2016-10-27 09:08:03 --> Helper loaded: url_helper
INFO - 2016-10-27 09:08:03 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-27 09:08:03 --> Controller Class Initialized
DEBUG - 2016-10-27 09:08:03 --> login MX_Controller Initialized
INFO - 2016-10-27 09:08:03 --> Model Class Initialized
INFO - 2016-10-27 09:08:03 --> Model Class Initialized
INFO - 2016-10-27 09:08:03 --> Final output sent to browser
DEBUG - 2016-10-27 09:08:03 --> Total execution time: 0.4461
INFO - 2016-10-27 09:08:04 --> Config Class Initialized
INFO - 2016-10-27 09:08:04 --> Hooks Class Initialized
DEBUG - 2016-10-27 09:08:04 --> UTF-8 Support Enabled
INFO - 2016-10-27 09:08:04 --> Utf8 Class Initialized
INFO - 2016-10-27 09:08:04 --> URI Class Initialized
INFO - 2016-10-27 09:08:04 --> Router Class Initialized
INFO - 2016-10-27 09:08:04 --> Output Class Initialized
INFO - 2016-10-27 09:08:04 --> Security Class Initialized
DEBUG - 2016-10-27 09:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-27 09:08:04 --> Input Class Initialized
INFO - 2016-10-27 09:08:04 --> Language Class Initialized
INFO - 2016-10-27 09:08:04 --> Language Class Initialized
INFO - 2016-10-27 09:08:04 --> Config Class Initialized
INFO - 2016-10-27 09:08:04 --> Loader Class Initialized
INFO - 2016-10-27 09:08:04 --> Helper loaded: url_helper
INFO - 2016-10-27 09:08:04 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-27 09:08:04 --> Controller Class Initialized
DEBUG - 2016-10-27 09:08:04 --> Index MX_Controller Initialized
INFO - 2016-10-27 09:08:04 --> Model Class Initialized
INFO - 2016-10-27 09:08:04 --> Model Class Initialized
ERROR - 2016-10-27 09:08:04 --> Unable to delete cache file for admin/index
DEBUG - 2016-10-27 09:08:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-10-27 09:08:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-10-27 09:08:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-10-27 09:08:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/dashboard.php
DEBUG - 2016-10-27 09:08:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-10-27 09:08:04 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-10-27 09:08:04 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:04 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:05 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:05 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:05 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:05 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:05 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:05 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:05 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:05 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:05 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:05 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:05 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:05 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:05 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:05 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:05 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:05 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:05 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:05 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:05 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:05 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:05 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:05 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:05 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:05 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:05 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:05 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:05 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:05 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:05 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:05 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:05 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:05 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:05 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:05 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:05 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:05 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:05 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:05 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:05 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:05 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:05 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:05 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:06 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:06 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:06 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:06 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:06 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:06 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:06 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:06 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:06 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:06 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:06 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:06 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:06 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:06 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:06 --> Database Driver Class Initialized
DEBUG - 2016-10-27 09:08:06 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-10-27 09:08:06 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-10-27 09:08:06 --> Final output sent to browser
DEBUG - 2016-10-27 09:08:06 --> Total execution time: 2.1235
INFO - 2016-10-27 09:08:31 --> Config Class Initialized
INFO - 2016-10-27 09:08:31 --> Hooks Class Initialized
DEBUG - 2016-10-27 09:08:32 --> UTF-8 Support Enabled
INFO - 2016-10-27 09:08:32 --> Utf8 Class Initialized
INFO - 2016-10-27 09:08:32 --> URI Class Initialized
INFO - 2016-10-27 09:08:32 --> Router Class Initialized
INFO - 2016-10-27 09:08:32 --> Output Class Initialized
INFO - 2016-10-27 09:08:32 --> Security Class Initialized
DEBUG - 2016-10-27 09:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-27 09:08:32 --> Input Class Initialized
INFO - 2016-10-27 09:08:32 --> Language Class Initialized
INFO - 2016-10-27 09:08:32 --> Language Class Initialized
INFO - 2016-10-27 09:08:32 --> Config Class Initialized
INFO - 2016-10-27 09:08:32 --> Loader Class Initialized
INFO - 2016-10-27 09:08:32 --> Helper loaded: url_helper
INFO - 2016-10-27 09:08:32 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-27 09:08:32 --> Controller Class Initialized
DEBUG - 2016-10-27 09:08:32 --> Index MX_Controller Initialized
INFO - 2016-10-27 09:08:32 --> Model Class Initialized
INFO - 2016-10-27 09:08:32 --> Model Class Initialized
ERROR - 2016-10-27 09:08:32 --> Unable to delete cache file for admin/index/toPdf
DEBUG - 2016-10-27 09:08:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/perjanijan.php
INFO - 2016-10-27 09:08:32 --> Final output sent to browser
DEBUG - 2016-10-27 09:08:32 --> Total execution time: 0.6401
INFO - 2016-10-27 09:08:40 --> Config Class Initialized
INFO - 2016-10-27 09:08:40 --> Hooks Class Initialized
DEBUG - 2016-10-27 09:08:40 --> UTF-8 Support Enabled
INFO - 2016-10-27 09:08:40 --> Utf8 Class Initialized
INFO - 2016-10-27 09:08:40 --> URI Class Initialized
INFO - 2016-10-27 09:08:40 --> Router Class Initialized
INFO - 2016-10-27 09:08:40 --> Output Class Initialized
INFO - 2016-10-27 09:08:40 --> Security Class Initialized
DEBUG - 2016-10-27 09:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-27 09:08:41 --> Input Class Initialized
INFO - 2016-10-27 09:08:41 --> Language Class Initialized
INFO - 2016-10-27 09:08:41 --> Language Class Initialized
INFO - 2016-10-27 09:08:41 --> Config Class Initialized
INFO - 2016-10-27 09:08:41 --> Loader Class Initialized
INFO - 2016-10-27 09:08:41 --> Helper loaded: url_helper
INFO - 2016-10-27 09:08:41 --> Database Driver Class Initialized
INFO - 2016-10-27 09:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-27 09:08:41 --> Controller Class Initialized
DEBUG - 2016-10-27 09:08:41 --> Index MX_Controller Initialized
INFO - 2016-10-27 09:08:41 --> Model Class Initialized
INFO - 2016-10-27 09:08:41 --> Model Class Initialized
ERROR - 2016-10-27 09:08:41 --> Unable to delete cache file for admin/index/toPdf
DEBUG - 2016-10-27 09:08:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/perjanijan.php
INFO - 2016-10-27 09:08:41 --> Final output sent to browser
DEBUG - 2016-10-27 09:08:41 --> Total execution time: 0.5380
INFO - 2016-10-27 09:09:20 --> Config Class Initialized
INFO - 2016-10-27 09:09:20 --> Hooks Class Initialized
DEBUG - 2016-10-27 09:09:20 --> UTF-8 Support Enabled
INFO - 2016-10-27 09:09:20 --> Utf8 Class Initialized
INFO - 2016-10-27 09:09:20 --> URI Class Initialized
INFO - 2016-10-27 09:09:20 --> Router Class Initialized
INFO - 2016-10-27 09:09:20 --> Output Class Initialized
INFO - 2016-10-27 09:09:20 --> Security Class Initialized
DEBUG - 2016-10-27 09:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-27 09:09:20 --> Input Class Initialized
INFO - 2016-10-27 09:09:20 --> Language Class Initialized
INFO - 2016-10-27 09:09:20 --> Language Class Initialized
INFO - 2016-10-27 09:09:20 --> Config Class Initialized
INFO - 2016-10-27 09:09:20 --> Loader Class Initialized
INFO - 2016-10-27 09:09:20 --> Helper loaded: url_helper
INFO - 2016-10-27 09:09:20 --> Database Driver Class Initialized
INFO - 2016-10-27 09:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-27 09:09:20 --> Controller Class Initialized
DEBUG - 2016-10-27 09:09:20 --> Index MX_Controller Initialized
INFO - 2016-10-27 09:09:20 --> Model Class Initialized
INFO - 2016-10-27 09:09:20 --> Model Class Initialized
ERROR - 2016-10-27 09:09:20 --> Unable to delete cache file for admin/index/toPdf
ERROR - 2016-10-27 09:09:20 --> Severity: Notice --> Undefined property: CI::$siswa_model E:\SERVER\htdocs\kops\application\third_party\MX\Controller.php 59
ERROR - 2016-10-27 09:09:21 --> Severity: Error --> Call to a member function view() on null E:\SERVER\htdocs\kops\application\modules\admin\controllers\Index.php 1523
INFO - 2016-10-27 09:09:30 --> Config Class Initialized
INFO - 2016-10-27 09:09:30 --> Hooks Class Initialized
DEBUG - 2016-10-27 09:09:30 --> UTF-8 Support Enabled
INFO - 2016-10-27 09:09:30 --> Utf8 Class Initialized
INFO - 2016-10-27 09:09:30 --> URI Class Initialized
INFO - 2016-10-27 09:09:30 --> Router Class Initialized
INFO - 2016-10-27 09:09:30 --> Output Class Initialized
INFO - 2016-10-27 09:09:30 --> Security Class Initialized
DEBUG - 2016-10-27 09:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-27 09:09:30 --> Input Class Initialized
INFO - 2016-10-27 09:09:30 --> Language Class Initialized
INFO - 2016-10-27 09:09:30 --> Language Class Initialized
INFO - 2016-10-27 09:09:30 --> Config Class Initialized
INFO - 2016-10-27 09:09:30 --> Loader Class Initialized
INFO - 2016-10-27 09:09:30 --> Helper loaded: url_helper
INFO - 2016-10-27 09:09:30 --> Database Driver Class Initialized
INFO - 2016-10-27 09:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-27 09:09:30 --> Controller Class Initialized
DEBUG - 2016-10-27 09:09:30 --> Index MX_Controller Initialized
INFO - 2016-10-27 09:09:30 --> Model Class Initialized
INFO - 2016-10-27 09:09:30 --> Model Class Initialized
ERROR - 2016-10-27 09:09:30 --> Unable to delete cache file for admin/index/toPdf
DEBUG - 2016-10-27 09:09:30 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/perjanijan.php
INFO - 2016-10-27 09:09:57 --> Final output sent to browser
DEBUG - 2016-10-27 09:09:57 --> Total execution time: 27.3610
INFO - 2016-10-27 09:09:57 --> Config Class Initialized
INFO - 2016-10-27 09:09:57 --> Hooks Class Initialized
DEBUG - 2016-10-27 09:09:57 --> UTF-8 Support Enabled
INFO - 2016-10-27 09:09:57 --> Utf8 Class Initialized
INFO - 2016-10-27 09:09:57 --> URI Class Initialized
INFO - 2016-10-27 09:09:57 --> Router Class Initialized
INFO - 2016-10-27 09:09:58 --> Output Class Initialized
INFO - 2016-10-27 09:09:58 --> Security Class Initialized
DEBUG - 2016-10-27 09:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-27 09:09:58 --> Input Class Initialized
INFO - 2016-10-27 09:09:58 --> Language Class Initialized
INFO - 2016-10-27 09:09:58 --> Language Class Initialized
INFO - 2016-10-27 09:09:58 --> Config Class Initialized
INFO - 2016-10-27 09:09:58 --> Loader Class Initialized
INFO - 2016-10-27 09:09:58 --> Helper loaded: url_helper
INFO - 2016-10-27 09:09:58 --> Database Driver Class Initialized
INFO - 2016-10-27 09:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-27 09:09:58 --> Controller Class Initialized
DEBUG - 2016-10-27 09:09:58 --> Index MX_Controller Initialized
INFO - 2016-10-27 09:09:58 --> Model Class Initialized
INFO - 2016-10-27 09:09:58 --> Model Class Initialized
ERROR - 2016-10-27 09:09:58 --> Unable to delete cache file for admin/index/toPdf
DEBUG - 2016-10-27 09:09:58 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/perjanijan.php
INFO - 2016-10-27 09:10:21 --> Final output sent to browser
DEBUG - 2016-10-27 09:10:21 --> Total execution time: 23.5740
INFO - 2016-10-27 09:10:21 --> Config Class Initialized
INFO - 2016-10-27 09:10:21 --> Hooks Class Initialized
DEBUG - 2016-10-27 09:10:22 --> UTF-8 Support Enabled
INFO - 2016-10-27 09:10:22 --> Utf8 Class Initialized
INFO - 2016-10-27 09:10:22 --> URI Class Initialized
INFO - 2016-10-27 09:10:22 --> Router Class Initialized
INFO - 2016-10-27 09:10:22 --> Output Class Initialized
INFO - 2016-10-27 09:10:22 --> Security Class Initialized
DEBUG - 2016-10-27 09:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-27 09:10:22 --> Input Class Initialized
INFO - 2016-10-27 09:10:22 --> Language Class Initialized
INFO - 2016-10-27 09:10:22 --> Language Class Initialized
INFO - 2016-10-27 09:10:22 --> Config Class Initialized
INFO - 2016-10-27 09:10:22 --> Loader Class Initialized
INFO - 2016-10-27 09:10:22 --> Helper loaded: url_helper
INFO - 2016-10-27 09:10:22 --> Database Driver Class Initialized
INFO - 2016-10-27 09:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-27 09:10:22 --> Controller Class Initialized
DEBUG - 2016-10-27 09:10:22 --> Index MX_Controller Initialized
INFO - 2016-10-27 09:10:22 --> Model Class Initialized
INFO - 2016-10-27 09:10:22 --> Model Class Initialized
ERROR - 2016-10-27 09:10:22 --> Unable to delete cache file for admin/index/toPdf
DEBUG - 2016-10-27 09:10:22 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/perjanijan.php
INFO - 2016-10-27 09:10:40 --> Final output sent to browser
DEBUG - 2016-10-27 09:10:40 --> Total execution time: 18.8803
INFO - 2016-10-27 09:10:41 --> Config Class Initialized
INFO - 2016-10-27 09:10:41 --> Hooks Class Initialized
DEBUG - 2016-10-27 09:10:41 --> UTF-8 Support Enabled
INFO - 2016-10-27 09:10:41 --> Utf8 Class Initialized
INFO - 2016-10-27 09:10:41 --> URI Class Initialized
INFO - 2016-10-27 09:10:41 --> Router Class Initialized
INFO - 2016-10-27 09:10:41 --> Output Class Initialized
INFO - 2016-10-27 09:10:41 --> Security Class Initialized
DEBUG - 2016-10-27 09:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-27 09:10:41 --> Input Class Initialized
INFO - 2016-10-27 09:10:41 --> Language Class Initialized
INFO - 2016-10-27 09:10:41 --> Language Class Initialized
INFO - 2016-10-27 09:10:41 --> Config Class Initialized
INFO - 2016-10-27 09:10:41 --> Loader Class Initialized
INFO - 2016-10-27 09:10:41 --> Helper loaded: url_helper
INFO - 2016-10-27 09:10:41 --> Database Driver Class Initialized
INFO - 2016-10-27 09:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-27 09:10:41 --> Controller Class Initialized
DEBUG - 2016-10-27 09:10:41 --> Index MX_Controller Initialized
INFO - 2016-10-27 09:10:41 --> Model Class Initialized
INFO - 2016-10-27 09:10:41 --> Model Class Initialized
ERROR - 2016-10-27 09:10:41 --> Unable to delete cache file for admin/index/toPdf
DEBUG - 2016-10-27 09:10:41 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/perjanijan.php
INFO - 2016-10-27 09:11:07 --> Final output sent to browser
DEBUG - 2016-10-27 09:11:07 --> Total execution time: 26.9600
INFO - 2016-10-27 09:11:09 --> Config Class Initialized
INFO - 2016-10-27 09:11:09 --> Hooks Class Initialized
DEBUG - 2016-10-27 09:11:09 --> UTF-8 Support Enabled
INFO - 2016-10-27 09:11:09 --> Utf8 Class Initialized
INFO - 2016-10-27 09:11:09 --> URI Class Initialized
INFO - 2016-10-27 09:11:09 --> Router Class Initialized
INFO - 2016-10-27 09:11:09 --> Output Class Initialized
INFO - 2016-10-27 09:11:09 --> Security Class Initialized
DEBUG - 2016-10-27 09:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-27 09:11:10 --> Input Class Initialized
INFO - 2016-10-27 09:11:10 --> Language Class Initialized
INFO - 2016-10-27 09:11:10 --> Language Class Initialized
INFO - 2016-10-27 09:11:10 --> Config Class Initialized
INFO - 2016-10-27 09:11:10 --> Loader Class Initialized
INFO - 2016-10-27 09:11:10 --> Helper loaded: url_helper
INFO - 2016-10-27 09:11:10 --> Database Driver Class Initialized
INFO - 2016-10-27 09:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-27 09:11:10 --> Controller Class Initialized
DEBUG - 2016-10-27 09:11:10 --> Index MX_Controller Initialized
INFO - 2016-10-27 09:11:10 --> Model Class Initialized
INFO - 2016-10-27 09:11:10 --> Model Class Initialized
ERROR - 2016-10-27 09:11:10 --> Unable to delete cache file for admin/index/toPdf
DEBUG - 2016-10-27 09:11:10 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/perjanijan.php
INFO - 2016-10-27 09:11:10 --> Final output sent to browser
DEBUG - 2016-10-27 09:11:10 --> Total execution time: 0.9113
INFO - 2016-10-27 09:11:10 --> Config Class Initialized
INFO - 2016-10-27 09:11:10 --> Hooks Class Initialized
DEBUG - 2016-10-27 09:11:10 --> UTF-8 Support Enabled
INFO - 2016-10-27 09:11:10 --> Utf8 Class Initialized
INFO - 2016-10-27 09:11:10 --> URI Class Initialized
INFO - 2016-10-27 09:11:10 --> Router Class Initialized
INFO - 2016-10-27 09:11:10 --> Output Class Initialized
INFO - 2016-10-27 09:11:10 --> Security Class Initialized
DEBUG - 2016-10-27 09:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-27 09:11:10 --> Input Class Initialized
INFO - 2016-10-27 09:11:11 --> Language Class Initialized
INFO - 2016-10-27 09:11:11 --> Language Class Initialized
INFO - 2016-10-27 09:11:11 --> Config Class Initialized
INFO - 2016-10-27 09:11:11 --> Loader Class Initialized
INFO - 2016-10-27 09:11:11 --> Helper loaded: url_helper
INFO - 2016-10-27 09:11:11 --> Database Driver Class Initialized
INFO - 2016-10-27 09:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-27 09:11:11 --> Controller Class Initialized
DEBUG - 2016-10-27 09:11:11 --> Index MX_Controller Initialized
INFO - 2016-10-27 09:11:11 --> Model Class Initialized
INFO - 2016-10-27 09:11:11 --> Model Class Initialized
ERROR - 2016-10-27 09:11:11 --> Unable to delete cache file for admin/index/toPdf
DEBUG - 2016-10-27 09:11:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/perjanijan.php
INFO - 2016-10-27 09:11:11 --> Final output sent to browser
DEBUG - 2016-10-27 09:11:11 --> Total execution time: 0.9074
INFO - 2016-10-27 09:11:29 --> Config Class Initialized
INFO - 2016-10-27 09:11:29 --> Hooks Class Initialized
DEBUG - 2016-10-27 09:11:29 --> UTF-8 Support Enabled
INFO - 2016-10-27 09:11:29 --> Utf8 Class Initialized
INFO - 2016-10-27 09:11:29 --> URI Class Initialized
INFO - 2016-10-27 09:11:29 --> Router Class Initialized
INFO - 2016-10-27 09:11:29 --> Output Class Initialized
INFO - 2016-10-27 09:11:29 --> Security Class Initialized
DEBUG - 2016-10-27 09:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-27 09:11:30 --> Input Class Initialized
INFO - 2016-10-27 09:11:30 --> Language Class Initialized
INFO - 2016-10-27 09:11:30 --> Language Class Initialized
INFO - 2016-10-27 09:11:30 --> Config Class Initialized
INFO - 2016-10-27 09:11:30 --> Loader Class Initialized
INFO - 2016-10-27 09:11:30 --> Helper loaded: url_helper
INFO - 2016-10-27 09:11:30 --> Database Driver Class Initialized
INFO - 2016-10-27 09:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-27 09:11:30 --> Controller Class Initialized
DEBUG - 2016-10-27 09:11:30 --> Index MX_Controller Initialized
INFO - 2016-10-27 09:11:30 --> Model Class Initialized
INFO - 2016-10-27 09:11:30 --> Model Class Initialized
ERROR - 2016-10-27 09:11:30 --> Unable to delete cache file for admin/index/toPdf
INFO - 2016-10-27 09:11:30 --> Final output sent to browser
DEBUG - 2016-10-27 09:11:30 --> Total execution time: 0.8760
INFO - 2016-10-27 09:11:30 --> Config Class Initialized
INFO - 2016-10-27 09:11:30 --> Hooks Class Initialized
DEBUG - 2016-10-27 09:11:30 --> UTF-8 Support Enabled
INFO - 2016-10-27 09:11:30 --> Utf8 Class Initialized
INFO - 2016-10-27 09:11:30 --> URI Class Initialized
INFO - 2016-10-27 09:11:31 --> Router Class Initialized
INFO - 2016-10-27 09:11:31 --> Output Class Initialized
INFO - 2016-10-27 09:11:31 --> Security Class Initialized
DEBUG - 2016-10-27 09:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-27 09:11:31 --> Input Class Initialized
INFO - 2016-10-27 09:11:31 --> Language Class Initialized
INFO - 2016-10-27 09:11:31 --> Language Class Initialized
INFO - 2016-10-27 09:11:31 --> Config Class Initialized
INFO - 2016-10-27 09:11:31 --> Loader Class Initialized
INFO - 2016-10-27 09:11:31 --> Helper loaded: url_helper
INFO - 2016-10-27 09:11:31 --> Database Driver Class Initialized
INFO - 2016-10-27 09:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-27 09:11:31 --> Controller Class Initialized
DEBUG - 2016-10-27 09:11:31 --> Index MX_Controller Initialized
INFO - 2016-10-27 09:11:31 --> Model Class Initialized
INFO - 2016-10-27 09:11:31 --> Model Class Initialized
ERROR - 2016-10-27 09:11:31 --> Unable to delete cache file for admin/index/toPdf
INFO - 2016-10-27 09:11:31 --> Final output sent to browser
DEBUG - 2016-10-27 09:11:31 --> Total execution time: 0.9426
INFO - 2016-10-27 09:11:49 --> Config Class Initialized
INFO - 2016-10-27 09:11:49 --> Hooks Class Initialized
DEBUG - 2016-10-27 09:11:49 --> UTF-8 Support Enabled
INFO - 2016-10-27 09:11:49 --> Utf8 Class Initialized
INFO - 2016-10-27 09:11:49 --> URI Class Initialized
INFO - 2016-10-27 09:11:49 --> Router Class Initialized
INFO - 2016-10-27 09:11:49 --> Output Class Initialized
INFO - 2016-10-27 09:11:49 --> Security Class Initialized
DEBUG - 2016-10-27 09:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-27 09:11:49 --> Input Class Initialized
INFO - 2016-10-27 09:11:49 --> Language Class Initialized
INFO - 2016-10-27 09:11:49 --> Language Class Initialized
INFO - 2016-10-27 09:11:49 --> Config Class Initialized
INFO - 2016-10-27 09:11:49 --> Loader Class Initialized
INFO - 2016-10-27 09:11:49 --> Helper loaded: url_helper
INFO - 2016-10-27 09:11:50 --> Database Driver Class Initialized
INFO - 2016-10-27 09:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-27 09:11:50 --> Controller Class Initialized
DEBUG - 2016-10-27 09:11:50 --> Index MX_Controller Initialized
INFO - 2016-10-27 09:11:50 --> Model Class Initialized
INFO - 2016-10-27 09:11:50 --> Model Class Initialized
ERROR - 2016-10-27 09:11:50 --> Unable to delete cache file for admin/index/toPdf
DEBUG - 2016-10-27 09:11:50 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/perjanijan.php
INFO - 2016-10-27 09:12:07 --> Final output sent to browser
DEBUG - 2016-10-27 09:12:07 --> Total execution time: 17.9305
INFO - 2016-10-27 09:12:07 --> Config Class Initialized
INFO - 2016-10-27 09:12:07 --> Hooks Class Initialized
DEBUG - 2016-10-27 09:12:07 --> UTF-8 Support Enabled
INFO - 2016-10-27 09:12:07 --> Utf8 Class Initialized
INFO - 2016-10-27 09:12:07 --> URI Class Initialized
INFO - 2016-10-27 09:12:07 --> Router Class Initialized
INFO - 2016-10-27 09:12:07 --> Output Class Initialized
INFO - 2016-10-27 09:12:07 --> Security Class Initialized
DEBUG - 2016-10-27 09:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-27 09:12:07 --> Input Class Initialized
INFO - 2016-10-27 09:12:07 --> Language Class Initialized
INFO - 2016-10-27 09:12:07 --> Language Class Initialized
INFO - 2016-10-27 09:12:07 --> Config Class Initialized
INFO - 2016-10-27 09:12:07 --> Loader Class Initialized
INFO - 2016-10-27 09:12:07 --> Helper loaded: url_helper
INFO - 2016-10-27 09:12:07 --> Database Driver Class Initialized
INFO - 2016-10-27 09:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-27 09:12:08 --> Controller Class Initialized
DEBUG - 2016-10-27 09:12:08 --> Index MX_Controller Initialized
INFO - 2016-10-27 09:12:08 --> Model Class Initialized
INFO - 2016-10-27 09:12:08 --> Model Class Initialized
ERROR - 2016-10-27 09:12:08 --> Unable to delete cache file for admin/index/toPdf
DEBUG - 2016-10-27 09:12:08 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/perjanijan.php
INFO - 2016-10-27 09:12:20 --> Config Class Initialized
INFO - 2016-10-27 09:12:20 --> Hooks Class Initialized
DEBUG - 2016-10-27 09:12:20 --> UTF-8 Support Enabled
INFO - 2016-10-27 09:12:20 --> Utf8 Class Initialized
INFO - 2016-10-27 09:12:20 --> URI Class Initialized
INFO - 2016-10-27 09:12:20 --> Router Class Initialized
INFO - 2016-10-27 09:12:20 --> Output Class Initialized
INFO - 2016-10-27 09:12:20 --> Security Class Initialized
DEBUG - 2016-10-27 09:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-27 09:12:21 --> Input Class Initialized
INFO - 2016-10-27 09:12:21 --> Language Class Initialized
INFO - 2016-10-27 09:12:21 --> Language Class Initialized
INFO - 2016-10-27 09:12:21 --> Config Class Initialized
INFO - 2016-10-27 09:12:21 --> Loader Class Initialized
INFO - 2016-10-27 09:12:21 --> Helper loaded: url_helper
INFO - 2016-10-27 09:12:21 --> Database Driver Class Initialized
INFO - 2016-10-27 09:12:26 --> Final output sent to browser
DEBUG - 2016-10-27 09:12:26 --> Total execution time: 18.3939
INFO - 2016-10-27 09:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-27 09:12:26 --> Controller Class Initialized
DEBUG - 2016-10-27 09:12:26 --> Index MX_Controller Initialized
INFO - 2016-10-27 09:12:26 --> Model Class Initialized
INFO - 2016-10-27 09:12:26 --> Model Class Initialized
ERROR - 2016-10-27 09:12:26 --> Unable to delete cache file for admin/index/toPdf
DEBUG - 2016-10-27 09:12:26 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/perjanijan.php
INFO - 2016-10-27 09:12:47 --> Final output sent to browser
DEBUG - 2016-10-27 09:12:47 --> Total execution time: 26.7763
INFO - 2016-10-27 09:12:47 --> Config Class Initialized
INFO - 2016-10-27 09:12:47 --> Hooks Class Initialized
DEBUG - 2016-10-27 09:12:47 --> UTF-8 Support Enabled
INFO - 2016-10-27 09:12:47 --> Utf8 Class Initialized
INFO - 2016-10-27 09:12:47 --> URI Class Initialized
INFO - 2016-10-27 09:12:47 --> Router Class Initialized
INFO - 2016-10-27 09:12:47 --> Output Class Initialized
INFO - 2016-10-27 09:12:47 --> Security Class Initialized
DEBUG - 2016-10-27 09:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-27 09:12:47 --> Input Class Initialized
INFO - 2016-10-27 09:12:47 --> Language Class Initialized
INFO - 2016-10-27 09:12:47 --> Language Class Initialized
INFO - 2016-10-27 09:12:47 --> Config Class Initialized
INFO - 2016-10-27 09:12:47 --> Loader Class Initialized
INFO - 2016-10-27 09:12:47 --> Helper loaded: url_helper
INFO - 2016-10-27 09:12:47 --> Database Driver Class Initialized
INFO - 2016-10-27 09:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-27 09:12:47 --> Controller Class Initialized
DEBUG - 2016-10-27 09:12:48 --> Index MX_Controller Initialized
INFO - 2016-10-27 09:12:48 --> Model Class Initialized
INFO - 2016-10-27 09:12:48 --> Model Class Initialized
ERROR - 2016-10-27 09:12:48 --> Unable to delete cache file for admin/index/toPdf
DEBUG - 2016-10-27 09:12:48 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/perjanijan.php
INFO - 2016-10-27 09:13:12 --> Final output sent to browser
DEBUG - 2016-10-27 09:13:12 --> Total execution time: 24.5327
INFO - 2016-10-27 09:13:59 --> Config Class Initialized
INFO - 2016-10-27 09:13:59 --> Hooks Class Initialized
DEBUG - 2016-10-27 09:13:59 --> UTF-8 Support Enabled
INFO - 2016-10-27 09:13:59 --> Utf8 Class Initialized
INFO - 2016-10-27 09:13:59 --> URI Class Initialized
INFO - 2016-10-27 09:13:59 --> Router Class Initialized
INFO - 2016-10-27 09:13:59 --> Output Class Initialized
INFO - 2016-10-27 09:13:59 --> Security Class Initialized
DEBUG - 2016-10-27 09:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-27 09:13:59 --> Input Class Initialized
INFO - 2016-10-27 09:13:59 --> Language Class Initialized
INFO - 2016-10-27 09:13:59 --> Language Class Initialized
INFO - 2016-10-27 09:13:59 --> Config Class Initialized
INFO - 2016-10-27 09:13:59 --> Loader Class Initialized
INFO - 2016-10-27 09:13:59 --> Helper loaded: url_helper
INFO - 2016-10-27 09:13:59 --> Database Driver Class Initialized
INFO - 2016-10-27 09:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-27 09:13:59 --> Controller Class Initialized
DEBUG - 2016-10-27 09:13:59 --> Index MX_Controller Initialized
INFO - 2016-10-27 09:13:59 --> Model Class Initialized
INFO - 2016-10-27 09:13:59 --> Model Class Initialized
ERROR - 2016-10-27 09:13:59 --> Unable to delete cache file for admin/index/toPdf
DEBUG - 2016-10-27 09:13:59 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/perjanijan.php
INFO - 2016-10-27 09:14:19 --> Final output sent to browser
DEBUG - 2016-10-27 09:14:19 --> Total execution time: 19.7079
INFO - 2016-10-27 09:14:19 --> Config Class Initialized
INFO - 2016-10-27 09:14:19 --> Hooks Class Initialized
DEBUG - 2016-10-27 09:14:19 --> UTF-8 Support Enabled
INFO - 2016-10-27 09:14:19 --> Utf8 Class Initialized
INFO - 2016-10-27 09:14:19 --> URI Class Initialized
INFO - 2016-10-27 09:14:19 --> Router Class Initialized
INFO - 2016-10-27 09:14:19 --> Output Class Initialized
INFO - 2016-10-27 09:14:19 --> Security Class Initialized
DEBUG - 2016-10-27 09:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-27 09:14:19 --> Input Class Initialized
INFO - 2016-10-27 09:14:19 --> Language Class Initialized
INFO - 2016-10-27 09:14:19 --> Language Class Initialized
INFO - 2016-10-27 09:14:19 --> Config Class Initialized
INFO - 2016-10-27 09:14:19 --> Loader Class Initialized
INFO - 2016-10-27 09:14:19 --> Helper loaded: url_helper
INFO - 2016-10-27 09:14:19 --> Database Driver Class Initialized
INFO - 2016-10-27 09:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-27 09:14:19 --> Controller Class Initialized
DEBUG - 2016-10-27 09:14:19 --> Index MX_Controller Initialized
INFO - 2016-10-27 09:14:19 --> Model Class Initialized
INFO - 2016-10-27 09:14:19 --> Model Class Initialized
ERROR - 2016-10-27 09:14:19 --> Unable to delete cache file for admin/index/toPdf
DEBUG - 2016-10-27 09:14:19 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/perjanijan.php
INFO - 2016-10-27 09:20:31 --> Config Class Initialized
INFO - 2016-10-27 09:20:31 --> Hooks Class Initialized
DEBUG - 2016-10-27 09:20:31 --> UTF-8 Support Enabled
INFO - 2016-10-27 09:20:31 --> Utf8 Class Initialized
INFO - 2016-10-27 09:20:31 --> URI Class Initialized
INFO - 2016-10-27 09:20:31 --> Router Class Initialized
INFO - 2016-10-27 09:20:31 --> Output Class Initialized
INFO - 2016-10-27 09:20:31 --> Security Class Initialized
DEBUG - 2016-10-27 09:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-27 09:20:31 --> Input Class Initialized
INFO - 2016-10-27 09:20:31 --> Language Class Initialized
INFO - 2016-10-27 09:20:31 --> Language Class Initialized
INFO - 2016-10-27 09:20:31 --> Config Class Initialized
INFO - 2016-10-27 09:20:31 --> Loader Class Initialized
INFO - 2016-10-27 09:20:31 --> Helper loaded: url_helper
INFO - 2016-10-27 09:20:31 --> Database Driver Class Initialized
INFO - 2016-10-27 09:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-27 09:20:31 --> Controller Class Initialized
DEBUG - 2016-10-27 09:20:31 --> Index MX_Controller Initialized
INFO - 2016-10-27 09:20:31 --> Model Class Initialized
INFO - 2016-10-27 09:20:31 --> Model Class Initialized
ERROR - 2016-10-27 09:20:31 --> Unable to delete cache file for admin/index/toPdf
DEBUG - 2016-10-27 09:20:31 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/perjanijan.php
INFO - 2016-10-27 09:20:32 --> Final output sent to browser
DEBUG - 2016-10-27 09:20:32 --> Total execution time: 0.8420
INFO - 2016-10-27 09:20:32 --> Config Class Initialized
INFO - 2016-10-27 09:20:32 --> Hooks Class Initialized
DEBUG - 2016-10-27 09:20:32 --> UTF-8 Support Enabled
INFO - 2016-10-27 09:20:32 --> Utf8 Class Initialized
INFO - 2016-10-27 09:20:32 --> URI Class Initialized
INFO - 2016-10-27 09:20:32 --> Router Class Initialized
INFO - 2016-10-27 09:20:32 --> Output Class Initialized
INFO - 2016-10-27 09:20:32 --> Security Class Initialized
DEBUG - 2016-10-27 09:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-27 09:20:32 --> Input Class Initialized
INFO - 2016-10-27 09:20:32 --> Language Class Initialized
INFO - 2016-10-27 09:20:32 --> Language Class Initialized
INFO - 2016-10-27 09:20:32 --> Config Class Initialized
INFO - 2016-10-27 09:20:32 --> Loader Class Initialized
INFO - 2016-10-27 09:20:32 --> Helper loaded: url_helper
INFO - 2016-10-27 09:20:32 --> Database Driver Class Initialized
INFO - 2016-10-27 09:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-27 09:20:32 --> Controller Class Initialized
DEBUG - 2016-10-27 09:20:32 --> Index MX_Controller Initialized
INFO - 2016-10-27 09:20:32 --> Model Class Initialized
INFO - 2016-10-27 09:20:32 --> Model Class Initialized
ERROR - 2016-10-27 09:20:32 --> Unable to delete cache file for admin/index/toPdf
DEBUG - 2016-10-27 09:20:33 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/perjanijan.php
INFO - 2016-10-27 09:20:33 --> Final output sent to browser
DEBUG - 2016-10-27 09:20:33 --> Total execution time: 1.1138
INFO - 2016-10-27 09:21:05 --> Config Class Initialized
INFO - 2016-10-27 09:21:05 --> Hooks Class Initialized
DEBUG - 2016-10-27 09:21:05 --> UTF-8 Support Enabled
INFO - 2016-10-27 09:21:05 --> Utf8 Class Initialized
INFO - 2016-10-27 09:21:05 --> URI Class Initialized
INFO - 2016-10-27 09:21:05 --> Router Class Initialized
INFO - 2016-10-27 09:21:05 --> Output Class Initialized
INFO - 2016-10-27 09:21:05 --> Security Class Initialized
DEBUG - 2016-10-27 09:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-27 09:21:05 --> Input Class Initialized
INFO - 2016-10-27 09:21:05 --> Language Class Initialized
INFO - 2016-10-27 09:21:05 --> Language Class Initialized
INFO - 2016-10-27 09:21:05 --> Config Class Initialized
INFO - 2016-10-27 09:21:05 --> Loader Class Initialized
INFO - 2016-10-27 09:21:05 --> Helper loaded: url_helper
INFO - 2016-10-27 09:21:05 --> Database Driver Class Initialized
INFO - 2016-10-27 09:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-27 09:21:05 --> Controller Class Initialized
DEBUG - 2016-10-27 09:21:05 --> Index MX_Controller Initialized
INFO - 2016-10-27 09:21:05 --> Model Class Initialized
INFO - 2016-10-27 09:21:05 --> Model Class Initialized
ERROR - 2016-10-27 09:21:05 --> Unable to delete cache file for admin/index/toPdf
DEBUG - 2016-10-27 09:21:05 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/perjanijan.php
INFO - 2016-10-27 09:21:31 --> Final output sent to browser
DEBUG - 2016-10-27 09:21:31 --> Total execution time: 26.2619
INFO - 2016-10-27 09:21:31 --> Config Class Initialized
INFO - 2016-10-27 09:21:31 --> Hooks Class Initialized
DEBUG - 2016-10-27 09:21:31 --> UTF-8 Support Enabled
INFO - 2016-10-27 09:21:31 --> Utf8 Class Initialized
INFO - 2016-10-27 09:21:31 --> URI Class Initialized
INFO - 2016-10-27 09:21:31 --> Router Class Initialized
INFO - 2016-10-27 09:21:31 --> Output Class Initialized
INFO - 2016-10-27 09:21:31 --> Security Class Initialized
DEBUG - 2016-10-27 09:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-27 09:21:32 --> Input Class Initialized
INFO - 2016-10-27 09:21:32 --> Language Class Initialized
INFO - 2016-10-27 09:21:32 --> Language Class Initialized
INFO - 2016-10-27 09:21:32 --> Config Class Initialized
INFO - 2016-10-27 09:21:32 --> Loader Class Initialized
INFO - 2016-10-27 09:21:32 --> Helper loaded: url_helper
INFO - 2016-10-27 09:21:32 --> Database Driver Class Initialized
INFO - 2016-10-27 09:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-27 09:21:32 --> Controller Class Initialized
DEBUG - 2016-10-27 09:21:32 --> Index MX_Controller Initialized
INFO - 2016-10-27 09:21:32 --> Model Class Initialized
INFO - 2016-10-27 09:21:32 --> Model Class Initialized
ERROR - 2016-10-27 09:21:32 --> Unable to delete cache file for admin/index/toPdf
DEBUG - 2016-10-27 09:21:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/perjanijan.php
INFO - 2016-10-27 09:21:55 --> Final output sent to browser
DEBUG - 2016-10-27 09:21:55 --> Total execution time: 24.2386
INFO - 2016-10-27 09:23:35 --> Config Class Initialized
INFO - 2016-10-27 09:23:35 --> Hooks Class Initialized
DEBUG - 2016-10-27 09:23:35 --> UTF-8 Support Enabled
INFO - 2016-10-27 09:23:35 --> Utf8 Class Initialized
INFO - 2016-10-27 09:23:35 --> URI Class Initialized
INFO - 2016-10-27 09:23:35 --> Router Class Initialized
INFO - 2016-10-27 09:23:35 --> Output Class Initialized
INFO - 2016-10-27 09:23:35 --> Security Class Initialized
DEBUG - 2016-10-27 09:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-27 09:23:35 --> Input Class Initialized
INFO - 2016-10-27 09:23:35 --> Language Class Initialized
INFO - 2016-10-27 09:23:35 --> Language Class Initialized
INFO - 2016-10-27 09:23:35 --> Config Class Initialized
INFO - 2016-10-27 09:23:35 --> Loader Class Initialized
INFO - 2016-10-27 09:23:35 --> Helper loaded: url_helper
INFO - 2016-10-27 09:23:35 --> Database Driver Class Initialized
INFO - 2016-10-27 09:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-27 09:23:35 --> Controller Class Initialized
DEBUG - 2016-10-27 09:23:35 --> Index MX_Controller Initialized
INFO - 2016-10-27 09:23:35 --> Model Class Initialized
INFO - 2016-10-27 09:23:35 --> Model Class Initialized
ERROR - 2016-10-27 09:23:35 --> Unable to delete cache file for admin/index/toPdf
DEBUG - 2016-10-27 09:23:35 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/perjanijan.php
INFO - 2016-10-27 14:23:59 --> Final output sent to browser
DEBUG - 2016-10-27 14:23:59 --> Total execution time: 24.1189
INFO - 2016-10-27 09:23:59 --> Config Class Initialized
INFO - 2016-10-27 09:23:59 --> Hooks Class Initialized
DEBUG - 2016-10-27 09:23:59 --> UTF-8 Support Enabled
INFO - 2016-10-27 09:23:59 --> Utf8 Class Initialized
INFO - 2016-10-27 09:23:59 --> URI Class Initialized
INFO - 2016-10-27 09:23:59 --> Router Class Initialized
INFO - 2016-10-27 09:23:59 --> Output Class Initialized
INFO - 2016-10-27 09:23:59 --> Security Class Initialized
DEBUG - 2016-10-27 09:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-27 09:23:59 --> Input Class Initialized
INFO - 2016-10-27 09:23:59 --> Language Class Initialized
INFO - 2016-10-27 09:23:59 --> Language Class Initialized
INFO - 2016-10-27 09:23:59 --> Config Class Initialized
INFO - 2016-10-27 09:23:59 --> Loader Class Initialized
INFO - 2016-10-27 09:23:59 --> Helper loaded: url_helper
INFO - 2016-10-27 09:23:59 --> Database Driver Class Initialized
INFO - 2016-10-27 09:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-27 09:23:59 --> Controller Class Initialized
DEBUG - 2016-10-27 09:23:59 --> Index MX_Controller Initialized
INFO - 2016-10-27 09:23:59 --> Model Class Initialized
INFO - 2016-10-27 09:23:59 --> Model Class Initialized
ERROR - 2016-10-27 09:23:59 --> Unable to delete cache file for admin/index/toPdf
DEBUG - 2016-10-27 09:23:59 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/perjanijan.php
INFO - 2016-10-27 14:24:24 --> Final output sent to browser
DEBUG - 2016-10-27 14:24:24 --> Total execution time: 24.8360
INFO - 2016-10-27 09:25:04 --> Config Class Initialized
INFO - 2016-10-27 09:25:04 --> Hooks Class Initialized
DEBUG - 2016-10-27 09:25:04 --> UTF-8 Support Enabled
INFO - 2016-10-27 09:25:04 --> Utf8 Class Initialized
INFO - 2016-10-27 09:25:04 --> URI Class Initialized
INFO - 2016-10-27 09:25:04 --> Router Class Initialized
INFO - 2016-10-27 09:25:04 --> Output Class Initialized
INFO - 2016-10-27 09:25:04 --> Security Class Initialized
DEBUG - 2016-10-27 09:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-27 09:25:04 --> Input Class Initialized
INFO - 2016-10-27 09:25:04 --> Language Class Initialized
INFO - 2016-10-27 09:25:04 --> Language Class Initialized
INFO - 2016-10-27 09:25:04 --> Config Class Initialized
INFO - 2016-10-27 09:25:04 --> Loader Class Initialized
INFO - 2016-10-27 09:25:04 --> Helper loaded: url_helper
INFO - 2016-10-27 09:25:05 --> Database Driver Class Initialized
INFO - 2016-10-27 09:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-27 09:25:05 --> Controller Class Initialized
DEBUG - 2016-10-27 09:25:05 --> Index MX_Controller Initialized
INFO - 2016-10-27 09:25:05 --> Model Class Initialized
INFO - 2016-10-27 09:25:05 --> Model Class Initialized
ERROR - 2016-10-27 09:25:05 --> Unable to delete cache file for admin/index/toPdf
DEBUG - 2016-10-27 09:25:05 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/perjanijan.php
INFO - 2016-10-27 14:25:26 --> Final output sent to browser
DEBUG - 2016-10-27 14:25:26 --> Total execution time: 22.2115
INFO - 2016-10-27 09:25:27 --> Config Class Initialized
INFO - 2016-10-27 09:25:27 --> Hooks Class Initialized
DEBUG - 2016-10-27 09:25:27 --> UTF-8 Support Enabled
INFO - 2016-10-27 09:25:27 --> Utf8 Class Initialized
INFO - 2016-10-27 09:25:27 --> URI Class Initialized
INFO - 2016-10-27 09:25:27 --> Router Class Initialized
INFO - 2016-10-27 09:25:27 --> Output Class Initialized
INFO - 2016-10-27 09:25:27 --> Security Class Initialized
DEBUG - 2016-10-27 09:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-27 09:25:27 --> Input Class Initialized
INFO - 2016-10-27 09:25:27 --> Language Class Initialized
INFO - 2016-10-27 09:25:27 --> Language Class Initialized
INFO - 2016-10-27 09:25:27 --> Config Class Initialized
INFO - 2016-10-27 09:25:27 --> Loader Class Initialized
INFO - 2016-10-27 09:25:27 --> Helper loaded: url_helper
INFO - 2016-10-27 09:25:27 --> Database Driver Class Initialized
INFO - 2016-10-27 09:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-27 09:25:27 --> Controller Class Initialized
DEBUG - 2016-10-27 09:25:27 --> Index MX_Controller Initialized
INFO - 2016-10-27 09:25:27 --> Model Class Initialized
INFO - 2016-10-27 09:25:27 --> Model Class Initialized
ERROR - 2016-10-27 09:25:27 --> Unable to delete cache file for admin/index/toPdf
DEBUG - 2016-10-27 09:25:27 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/perjanijan.php
INFO - 2016-10-27 14:25:50 --> Final output sent to browser
DEBUG - 2016-10-27 14:25:50 --> Total execution time: 23.4710
INFO - 2016-10-27 09:26:00 --> Config Class Initialized
INFO - 2016-10-27 09:26:00 --> Hooks Class Initialized
DEBUG - 2016-10-27 09:26:00 --> UTF-8 Support Enabled
INFO - 2016-10-27 09:26:00 --> Utf8 Class Initialized
INFO - 2016-10-27 09:26:00 --> URI Class Initialized
INFO - 2016-10-27 09:26:00 --> Router Class Initialized
INFO - 2016-10-27 09:26:00 --> Output Class Initialized
INFO - 2016-10-27 09:26:00 --> Security Class Initialized
DEBUG - 2016-10-27 09:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-27 09:26:00 --> Input Class Initialized
INFO - 2016-10-27 09:26:00 --> Language Class Initialized
INFO - 2016-10-27 09:26:00 --> Language Class Initialized
INFO - 2016-10-27 09:26:00 --> Config Class Initialized
INFO - 2016-10-27 09:26:00 --> Loader Class Initialized
INFO - 2016-10-27 09:26:00 --> Helper loaded: url_helper
INFO - 2016-10-27 09:26:00 --> Database Driver Class Initialized
INFO - 2016-10-27 09:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-27 09:26:00 --> Controller Class Initialized
DEBUG - 2016-10-27 09:26:00 --> Index MX_Controller Initialized
INFO - 2016-10-27 09:26:00 --> Model Class Initialized
INFO - 2016-10-27 09:26:00 --> Model Class Initialized
ERROR - 2016-10-27 09:26:00 --> Unable to delete cache file for admin/index/toPdf
DEBUG - 2016-10-27 09:26:00 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/perjanijan.php
INFO - 2016-10-27 14:26:24 --> Final output sent to browser
DEBUG - 2016-10-27 14:26:24 --> Total execution time: 24.0302
INFO - 2016-10-27 09:26:24 --> Config Class Initialized
INFO - 2016-10-27 09:26:24 --> Hooks Class Initialized
DEBUG - 2016-10-27 09:26:24 --> UTF-8 Support Enabled
INFO - 2016-10-27 09:26:24 --> Utf8 Class Initialized
INFO - 2016-10-27 09:26:24 --> URI Class Initialized
INFO - 2016-10-27 09:26:24 --> Router Class Initialized
INFO - 2016-10-27 09:26:24 --> Output Class Initialized
INFO - 2016-10-27 09:26:24 --> Security Class Initialized
DEBUG - 2016-10-27 09:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-27 09:26:24 --> Input Class Initialized
INFO - 2016-10-27 09:26:24 --> Language Class Initialized
INFO - 2016-10-27 09:26:24 --> Language Class Initialized
INFO - 2016-10-27 09:26:24 --> Config Class Initialized
INFO - 2016-10-27 09:26:24 --> Loader Class Initialized
INFO - 2016-10-27 09:26:24 --> Helper loaded: url_helper
INFO - 2016-10-27 09:26:24 --> Database Driver Class Initialized
INFO - 2016-10-27 09:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-27 09:26:24 --> Controller Class Initialized
DEBUG - 2016-10-27 09:26:24 --> Index MX_Controller Initialized
INFO - 2016-10-27 09:26:24 --> Model Class Initialized
INFO - 2016-10-27 09:26:24 --> Model Class Initialized
ERROR - 2016-10-27 09:26:25 --> Unable to delete cache file for admin/index/toPdf
DEBUG - 2016-10-27 09:26:25 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/perjanijan.php
INFO - 2016-10-27 14:26:46 --> Final output sent to browser
DEBUG - 2016-10-27 14:26:46 --> Total execution time: 21.8622
INFO - 2016-10-27 09:26:47 --> Config Class Initialized
INFO - 2016-10-27 09:26:47 --> Hooks Class Initialized
DEBUG - 2016-10-27 09:26:47 --> UTF-8 Support Enabled
INFO - 2016-10-27 09:26:47 --> Utf8 Class Initialized
INFO - 2016-10-27 09:26:47 --> URI Class Initialized
INFO - 2016-10-27 09:26:47 --> Router Class Initialized
INFO - 2016-10-27 09:26:47 --> Output Class Initialized
INFO - 2016-10-27 09:26:48 --> Security Class Initialized
DEBUG - 2016-10-27 09:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-27 09:26:48 --> Input Class Initialized
INFO - 2016-10-27 09:26:48 --> Language Class Initialized
INFO - 2016-10-27 09:26:48 --> Language Class Initialized
INFO - 2016-10-27 09:26:48 --> Config Class Initialized
INFO - 2016-10-27 09:26:48 --> Loader Class Initialized
INFO - 2016-10-27 09:26:48 --> Helper loaded: url_helper
INFO - 2016-10-27 09:26:48 --> Database Driver Class Initialized
INFO - 2016-10-27 09:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-27 09:26:48 --> Controller Class Initialized
DEBUG - 2016-10-27 09:26:48 --> Index MX_Controller Initialized
INFO - 2016-10-27 09:26:48 --> Model Class Initialized
INFO - 2016-10-27 09:26:48 --> Model Class Initialized
ERROR - 2016-10-27 09:26:48 --> Unable to delete cache file for admin/index/toPdf
DEBUG - 2016-10-27 09:26:48 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/perjanijan.php
INFO - 2016-10-27 14:27:10 --> Final output sent to browser
DEBUG - 2016-10-27 14:27:10 --> Total execution time: 22.8333
INFO - 2016-10-27 09:27:10 --> Config Class Initialized
INFO - 2016-10-27 09:27:10 --> Hooks Class Initialized
DEBUG - 2016-10-27 09:27:10 --> UTF-8 Support Enabled
INFO - 2016-10-27 09:27:10 --> Utf8 Class Initialized
INFO - 2016-10-27 09:27:10 --> URI Class Initialized
INFO - 2016-10-27 09:27:10 --> Router Class Initialized
INFO - 2016-10-27 09:27:10 --> Output Class Initialized
INFO - 2016-10-27 09:27:10 --> Security Class Initialized
DEBUG - 2016-10-27 09:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-27 09:27:10 --> Input Class Initialized
INFO - 2016-10-27 09:27:10 --> Language Class Initialized
INFO - 2016-10-27 09:27:11 --> Language Class Initialized
INFO - 2016-10-27 09:27:11 --> Config Class Initialized
INFO - 2016-10-27 09:27:11 --> Loader Class Initialized
INFO - 2016-10-27 09:27:11 --> Helper loaded: url_helper
INFO - 2016-10-27 09:27:11 --> Database Driver Class Initialized
INFO - 2016-10-27 09:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-27 09:27:11 --> Controller Class Initialized
DEBUG - 2016-10-27 09:27:11 --> Index MX_Controller Initialized
INFO - 2016-10-27 09:27:11 --> Model Class Initialized
INFO - 2016-10-27 09:27:11 --> Model Class Initialized
ERROR - 2016-10-27 09:27:11 --> Unable to delete cache file for admin/index/toPdf
DEBUG - 2016-10-27 09:27:11 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/perjanijan.php
INFO - 2016-10-27 14:27:32 --> Final output sent to browser
DEBUG - 2016-10-27 14:27:32 --> Total execution time: 21.8251
INFO - 2016-10-27 09:27:35 --> Config Class Initialized
INFO - 2016-10-27 09:27:35 --> Hooks Class Initialized
DEBUG - 2016-10-27 09:27:35 --> UTF-8 Support Enabled
INFO - 2016-10-27 09:27:35 --> Utf8 Class Initialized
INFO - 2016-10-27 09:27:35 --> URI Class Initialized
INFO - 2016-10-27 09:27:35 --> Router Class Initialized
INFO - 2016-10-27 09:27:35 --> Output Class Initialized
INFO - 2016-10-27 09:27:36 --> Security Class Initialized
DEBUG - 2016-10-27 09:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-27 09:27:36 --> Input Class Initialized
INFO - 2016-10-27 09:27:36 --> Language Class Initialized
INFO - 2016-10-27 09:27:36 --> Language Class Initialized
INFO - 2016-10-27 09:27:36 --> Config Class Initialized
INFO - 2016-10-27 09:27:36 --> Loader Class Initialized
INFO - 2016-10-27 09:27:36 --> Helper loaded: url_helper
INFO - 2016-10-27 09:27:36 --> Database Driver Class Initialized
INFO - 2016-10-27 09:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-27 09:27:36 --> Controller Class Initialized
DEBUG - 2016-10-27 09:27:36 --> Index MX_Controller Initialized
INFO - 2016-10-27 09:27:36 --> Model Class Initialized
INFO - 2016-10-27 09:27:36 --> Model Class Initialized
ERROR - 2016-10-27 09:27:36 --> Unable to delete cache file for admin/index/toPdf
DEBUG - 2016-10-27 09:27:36 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/perjanijan.php
INFO - 2016-10-27 14:28:00 --> Final output sent to browser
DEBUG - 2016-10-27 14:28:00 --> Total execution time: 24.6160
INFO - 2016-10-27 09:28:00 --> Config Class Initialized
INFO - 2016-10-27 09:28:00 --> Hooks Class Initialized
DEBUG - 2016-10-27 09:28:00 --> UTF-8 Support Enabled
INFO - 2016-10-27 09:28:00 --> Utf8 Class Initialized
INFO - 2016-10-27 09:28:00 --> URI Class Initialized
INFO - 2016-10-27 09:28:00 --> Router Class Initialized
INFO - 2016-10-27 09:28:00 --> Output Class Initialized
INFO - 2016-10-27 09:28:00 --> Security Class Initialized
DEBUG - 2016-10-27 09:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-27 09:28:00 --> Input Class Initialized
INFO - 2016-10-27 09:28:00 --> Language Class Initialized
INFO - 2016-10-27 09:28:00 --> Language Class Initialized
INFO - 2016-10-27 09:28:00 --> Config Class Initialized
INFO - 2016-10-27 09:28:01 --> Loader Class Initialized
INFO - 2016-10-27 09:28:01 --> Helper loaded: url_helper
INFO - 2016-10-27 09:28:01 --> Database Driver Class Initialized
INFO - 2016-10-27 09:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-27 09:28:01 --> Controller Class Initialized
DEBUG - 2016-10-27 09:28:01 --> Index MX_Controller Initialized
INFO - 2016-10-27 09:28:01 --> Model Class Initialized
INFO - 2016-10-27 09:28:01 --> Model Class Initialized
ERROR - 2016-10-27 09:28:01 --> Unable to delete cache file for admin/index/toPdf
DEBUG - 2016-10-27 09:28:01 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/perjanijan.php
INFO - 2016-10-27 14:28:22 --> Final output sent to browser
DEBUG - 2016-10-27 14:28:22 --> Total execution time: 21.7333
INFO - 2016-10-27 09:37:47 --> Config Class Initialized
INFO - 2016-10-27 09:37:47 --> Hooks Class Initialized
DEBUG - 2016-10-27 09:37:47 --> UTF-8 Support Enabled
INFO - 2016-10-27 09:37:47 --> Utf8 Class Initialized
INFO - 2016-10-27 09:37:47 --> URI Class Initialized
INFO - 2016-10-27 09:37:47 --> Router Class Initialized
INFO - 2016-10-27 09:37:47 --> Output Class Initialized
INFO - 2016-10-27 09:37:47 --> Security Class Initialized
DEBUG - 2016-10-27 09:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-27 09:37:47 --> Input Class Initialized
INFO - 2016-10-27 09:37:47 --> Language Class Initialized
INFO - 2016-10-27 09:37:47 --> Language Class Initialized
INFO - 2016-10-27 09:37:47 --> Config Class Initialized
INFO - 2016-10-27 09:37:47 --> Loader Class Initialized
INFO - 2016-10-27 09:37:47 --> Helper loaded: url_helper
INFO - 2016-10-27 09:37:47 --> Database Driver Class Initialized
INFO - 2016-10-27 09:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-27 09:37:47 --> Controller Class Initialized
DEBUG - 2016-10-27 09:37:47 --> Index MX_Controller Initialized
INFO - 2016-10-27 09:37:47 --> Model Class Initialized
INFO - 2016-10-27 09:37:47 --> Model Class Initialized
ERROR - 2016-10-27 09:37:47 --> Unable to delete cache file for admin/index/toPdf
DEBUG - 2016-10-27 09:37:47 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/perjanijan.php
INFO - 2016-10-27 09:37:47 --> Final output sent to browser
DEBUG - 2016-10-27 09:37:48 --> Total execution time: 0.8336
INFO - 2016-10-27 09:37:59 --> Config Class Initialized
INFO - 2016-10-27 09:37:59 --> Hooks Class Initialized
DEBUG - 2016-10-27 09:37:59 --> UTF-8 Support Enabled
INFO - 2016-10-27 09:37:59 --> Utf8 Class Initialized
INFO - 2016-10-27 09:37:59 --> URI Class Initialized
INFO - 2016-10-27 09:37:59 --> Router Class Initialized
INFO - 2016-10-27 09:37:59 --> Output Class Initialized
INFO - 2016-10-27 09:37:59 --> Security Class Initialized
DEBUG - 2016-10-27 09:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-27 09:37:59 --> Input Class Initialized
INFO - 2016-10-27 09:37:59 --> Language Class Initialized
INFO - 2016-10-27 09:37:59 --> Language Class Initialized
INFO - 2016-10-27 09:37:59 --> Config Class Initialized
INFO - 2016-10-27 09:37:59 --> Loader Class Initialized
INFO - 2016-10-27 09:37:59 --> Helper loaded: url_helper
INFO - 2016-10-27 09:38:00 --> Database Driver Class Initialized
INFO - 2016-10-27 09:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-27 09:38:00 --> Controller Class Initialized
DEBUG - 2016-10-27 09:38:00 --> Index MX_Controller Initialized
INFO - 2016-10-27 09:38:00 --> Model Class Initialized
INFO - 2016-10-27 09:38:00 --> Model Class Initialized
ERROR - 2016-10-27 09:38:00 --> Unable to delete cache file for admin/index/toPdf
DEBUG - 2016-10-27 09:38:00 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/perjanijan.php
INFO - 2016-10-27 09:38:00 --> Final output sent to browser
DEBUG - 2016-10-27 09:38:00 --> Total execution time: 0.6237
INFO - 2016-10-27 09:57:55 --> Config Class Initialized
INFO - 2016-10-27 09:57:55 --> Hooks Class Initialized
DEBUG - 2016-10-27 09:57:55 --> UTF-8 Support Enabled
INFO - 2016-10-27 09:57:55 --> Utf8 Class Initialized
INFO - 2016-10-27 09:57:55 --> URI Class Initialized
INFO - 2016-10-27 09:57:55 --> Router Class Initialized
INFO - 2016-10-27 09:57:55 --> Output Class Initialized
INFO - 2016-10-27 09:57:55 --> Security Class Initialized
DEBUG - 2016-10-27 09:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-27 09:57:55 --> Input Class Initialized
INFO - 2016-10-27 09:57:55 --> Language Class Initialized
ERROR - 2016-10-27 09:57:55 --> Severity: Parsing Error --> syntax error, unexpected 'print' (T_PRINT), expecting identifier (T_STRING) E:\SERVER\htdocs\kops\application\modules\admin\controllers\Index.php 1521
INFO - 2016-10-27 09:58:12 --> Config Class Initialized
INFO - 2016-10-27 09:58:12 --> Hooks Class Initialized
DEBUG - 2016-10-27 09:58:13 --> UTF-8 Support Enabled
INFO - 2016-10-27 09:58:13 --> Utf8 Class Initialized
INFO - 2016-10-27 09:58:13 --> URI Class Initialized
INFO - 2016-10-27 09:58:13 --> Router Class Initialized
INFO - 2016-10-27 09:58:13 --> Output Class Initialized
INFO - 2016-10-27 09:58:13 --> Security Class Initialized
DEBUG - 2016-10-27 09:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-27 09:58:13 --> Input Class Initialized
INFO - 2016-10-27 09:58:13 --> Language Class Initialized
INFO - 2016-10-27 09:58:13 --> Language Class Initialized
INFO - 2016-10-27 09:58:13 --> Config Class Initialized
INFO - 2016-10-27 09:58:13 --> Loader Class Initialized
INFO - 2016-10-27 09:58:13 --> Helper loaded: url_helper
INFO - 2016-10-27 09:58:13 --> Database Driver Class Initialized
INFO - 2016-10-27 09:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-27 09:58:13 --> Controller Class Initialized
DEBUG - 2016-10-27 09:58:13 --> Index MX_Controller Initialized
INFO - 2016-10-27 09:58:13 --> Model Class Initialized
INFO - 2016-10-27 09:58:13 --> Model Class Initialized
ERROR - 2016-10-27 09:58:13 --> Unable to delete cache file for admin/index/cetak
INFO - 2016-10-27 09:58:13 --> Database Driver Class Initialized
INFO - 2016-10-27 09:58:13 --> Database Driver Class Initialized
ERROR - 2016-10-27 09:58:13 --> Severity: Notice --> Trying to get property of non-object E:\SERVER\htdocs\kops\application\views\main_html\content\perjanijan.php 75
DEBUG - 2016-10-27 09:58:13 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/perjanijan.php
INFO - 2016-10-27 09:58:13 --> Final output sent to browser
DEBUG - 2016-10-27 09:58:13 --> Total execution time: 0.7460
INFO - 2016-10-27 09:59:44 --> Config Class Initialized
INFO - 2016-10-27 09:59:44 --> Hooks Class Initialized
DEBUG - 2016-10-27 09:59:44 --> UTF-8 Support Enabled
INFO - 2016-10-27 09:59:44 --> Utf8 Class Initialized
INFO - 2016-10-27 09:59:44 --> URI Class Initialized
INFO - 2016-10-27 09:59:44 --> Router Class Initialized
INFO - 2016-10-27 09:59:44 --> Output Class Initialized
INFO - 2016-10-27 09:59:44 --> Security Class Initialized
DEBUG - 2016-10-27 09:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-27 09:59:44 --> Input Class Initialized
INFO - 2016-10-27 09:59:44 --> Language Class Initialized
INFO - 2016-10-27 09:59:44 --> Language Class Initialized
INFO - 2016-10-27 09:59:44 --> Config Class Initialized
INFO - 2016-10-27 09:59:44 --> Loader Class Initialized
INFO - 2016-10-27 09:59:44 --> Helper loaded: url_helper
INFO - 2016-10-27 09:59:44 --> Database Driver Class Initialized
INFO - 2016-10-27 09:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-27 09:59:44 --> Controller Class Initialized
DEBUG - 2016-10-27 09:59:44 --> Index MX_Controller Initialized
INFO - 2016-10-27 09:59:44 --> Model Class Initialized
INFO - 2016-10-27 09:59:44 --> Model Class Initialized
ERROR - 2016-10-27 09:59:44 --> Unable to delete cache file for admin/index/cetak
INFO - 2016-10-27 09:59:44 --> Database Driver Class Initialized
INFO - 2016-10-27 09:59:44 --> Database Driver Class Initialized
DEBUG - 2016-10-27 09:59:44 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/perjanijan.php
INFO - 2016-10-27 09:59:44 --> Final output sent to browser
DEBUG - 2016-10-27 09:59:44 --> Total execution time: 0.6627
