<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-09-30 05:08:55 --> Config Class Initialized
INFO - 2016-09-30 05:08:55 --> Hooks Class Initialized
DEBUG - 2016-09-30 05:08:55 --> UTF-8 Support Enabled
INFO - 2016-09-30 05:08:55 --> Utf8 Class Initialized
INFO - 2016-09-30 05:08:55 --> URI Class Initialized
INFO - 2016-09-30 05:08:55 --> Router Class Initialized
INFO - 2016-09-30 05:08:55 --> Output Class Initialized
INFO - 2016-09-30 05:08:55 --> Security Class Initialized
DEBUG - 2016-09-30 05:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-30 05:08:55 --> Input Class Initialized
INFO - 2016-09-30 05:08:55 --> Language Class Initialized
ERROR - 2016-09-30 05:08:55 --> 404 Page Not Found: /index
INFO - 2016-09-30 09:48:37 --> Config Class Initialized
INFO - 2016-09-30 09:48:37 --> Hooks Class Initialized
DEBUG - 2016-09-30 09:48:37 --> UTF-8 Support Enabled
INFO - 2016-09-30 09:48:37 --> Utf8 Class Initialized
INFO - 2016-09-30 09:48:37 --> URI Class Initialized
INFO - 2016-09-30 09:48:37 --> Router Class Initialized
INFO - 2016-09-30 09:48:37 --> Output Class Initialized
INFO - 2016-09-30 09:48:37 --> Security Class Initialized
DEBUG - 2016-09-30 09:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-30 09:48:37 --> Input Class Initialized
INFO - 2016-09-30 09:48:37 --> Language Class Initialized
INFO - 2016-09-30 09:48:37 --> Language Class Initialized
INFO - 2016-09-30 09:48:37 --> Config Class Initialized
INFO - 2016-09-30 09:48:37 --> Loader Class Initialized
INFO - 2016-09-30 09:48:37 --> Helper loaded: url_helper
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-30 09:48:37 --> Controller Class Initialized
DEBUG - 2016-09-30 09:48:37 --> Index MX_Controller Initialized
INFO - 2016-09-30 09:48:37 --> Model Class Initialized
INFO - 2016-09-30 09:48:37 --> Model Class Initialized
ERROR - 2016-09-30 09:48:37 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-30 09:48:37 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-30 09:48:37 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-30 09:48:37 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-30 09:48:37 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-30 09:48:37 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-30 09:48:37 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
DEBUG - 2016-09-30 09:48:37 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-30 09:48:37 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-30 09:48:37 --> Final output sent to browser
DEBUG - 2016-09-30 09:48:37 --> Total execution time: 0.2721
INFO - 2016-09-30 09:48:37 --> Config Class Initialized
INFO - 2016-09-30 09:48:37 --> Hooks Class Initialized
DEBUG - 2016-09-30 09:48:37 --> UTF-8 Support Enabled
INFO - 2016-09-30 09:48:37 --> Utf8 Class Initialized
INFO - 2016-09-30 09:48:37 --> URI Class Initialized
INFO - 2016-09-30 09:48:37 --> Router Class Initialized
INFO - 2016-09-30 09:48:37 --> Output Class Initialized
INFO - 2016-09-30 09:48:37 --> Security Class Initialized
DEBUG - 2016-09-30 09:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-30 09:48:37 --> Input Class Initialized
INFO - 2016-09-30 09:48:37 --> Language Class Initialized
INFO - 2016-09-30 09:48:37 --> Language Class Initialized
INFO - 2016-09-30 09:48:37 --> Config Class Initialized
INFO - 2016-09-30 09:48:37 --> Loader Class Initialized
INFO - 2016-09-30 09:48:37 --> Helper loaded: url_helper
INFO - 2016-09-30 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-30 09:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-30 09:48:37 --> Controller Class Initialized
DEBUG - 2016-09-30 09:48:37 --> login MX_Controller Initialized
INFO - 2016-09-30 09:48:37 --> Model Class Initialized
INFO - 2016-09-30 09:48:37 --> Model Class Initialized
DEBUG - 2016-09-30 09:48:37 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-30 09:48:37 --> Final output sent to browser
DEBUG - 2016-09-30 09:48:37 --> Total execution time: 0.0240
INFO - 2016-09-30 09:51:00 --> Config Class Initialized
INFO - 2016-09-30 09:51:00 --> Hooks Class Initialized
DEBUG - 2016-09-30 09:51:00 --> UTF-8 Support Enabled
INFO - 2016-09-30 09:51:00 --> Utf8 Class Initialized
INFO - 2016-09-30 09:51:00 --> URI Class Initialized
INFO - 2016-09-30 09:51:00 --> Router Class Initialized
INFO - 2016-09-30 09:51:00 --> Output Class Initialized
INFO - 2016-09-30 09:51:00 --> Security Class Initialized
DEBUG - 2016-09-30 09:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-30 09:51:00 --> Input Class Initialized
INFO - 2016-09-30 09:51:00 --> Language Class Initialized
INFO - 2016-09-30 09:51:00 --> Language Class Initialized
INFO - 2016-09-30 09:51:00 --> Config Class Initialized
INFO - 2016-09-30 09:51:00 --> Loader Class Initialized
INFO - 2016-09-30 09:51:00 --> Helper loaded: url_helper
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-30 09:51:00 --> Controller Class Initialized
DEBUG - 2016-09-30 09:51:00 --> Index MX_Controller Initialized
INFO - 2016-09-30 09:51:00 --> Model Class Initialized
INFO - 2016-09-30 09:51:00 --> Model Class Initialized
ERROR - 2016-09-30 09:51:00 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-30 09:51:00 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-30 09:51:00 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-30 09:51:00 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-30 09:51:00 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-30 09:51:00 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-30 09:51:00 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:00 --> Database Driver Class Initialized
DEBUG - 2016-09-30 09:51:00 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-30 09:51:00 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-30 09:51:00 --> Final output sent to browser
DEBUG - 2016-09-30 09:51:00 --> Total execution time: 0.1909
INFO - 2016-09-30 09:51:01 --> Config Class Initialized
INFO - 2016-09-30 09:51:01 --> Hooks Class Initialized
DEBUG - 2016-09-30 09:51:01 --> UTF-8 Support Enabled
INFO - 2016-09-30 09:51:01 --> Utf8 Class Initialized
INFO - 2016-09-30 09:51:01 --> URI Class Initialized
INFO - 2016-09-30 09:51:01 --> Router Class Initialized
INFO - 2016-09-30 09:51:01 --> Output Class Initialized
INFO - 2016-09-30 09:51:01 --> Security Class Initialized
DEBUG - 2016-09-30 09:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-30 09:51:01 --> Input Class Initialized
INFO - 2016-09-30 09:51:01 --> Language Class Initialized
INFO - 2016-09-30 09:51:01 --> Language Class Initialized
INFO - 2016-09-30 09:51:01 --> Config Class Initialized
INFO - 2016-09-30 09:51:01 --> Loader Class Initialized
INFO - 2016-09-30 09:51:01 --> Helper loaded: url_helper
INFO - 2016-09-30 09:51:01 --> Database Driver Class Initialized
INFO - 2016-09-30 09:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-30 09:51:01 --> Controller Class Initialized
DEBUG - 2016-09-30 09:51:01 --> login MX_Controller Initialized
INFO - 2016-09-30 09:51:01 --> Model Class Initialized
INFO - 2016-09-30 09:51:01 --> Model Class Initialized
DEBUG - 2016-09-30 09:51:01 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-30 09:51:01 --> Final output sent to browser
DEBUG - 2016-09-30 09:51:01 --> Total execution time: 0.0259
INFO - 2016-09-30 09:57:24 --> Config Class Initialized
INFO - 2016-09-30 09:57:24 --> Hooks Class Initialized
DEBUG - 2016-09-30 09:57:24 --> UTF-8 Support Enabled
INFO - 2016-09-30 09:57:24 --> Utf8 Class Initialized
INFO - 2016-09-30 09:57:24 --> URI Class Initialized
INFO - 2016-09-30 09:57:24 --> Router Class Initialized
INFO - 2016-09-30 09:57:24 --> Output Class Initialized
INFO - 2016-09-30 09:57:24 --> Security Class Initialized
DEBUG - 2016-09-30 09:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-30 09:57:24 --> Input Class Initialized
INFO - 2016-09-30 09:57:24 --> Language Class Initialized
INFO - 2016-09-30 09:57:24 --> Language Class Initialized
INFO - 2016-09-30 09:57:24 --> Config Class Initialized
INFO - 2016-09-30 09:57:24 --> Loader Class Initialized
INFO - 2016-09-30 09:57:24 --> Helper loaded: url_helper
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-30 09:57:24 --> Controller Class Initialized
DEBUG - 2016-09-30 09:57:24 --> Index MX_Controller Initialized
INFO - 2016-09-30 09:57:24 --> Model Class Initialized
INFO - 2016-09-30 09:57:24 --> Model Class Initialized
ERROR - 2016-09-30 09:57:24 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-30 09:57:24 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-30 09:57:24 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-30 09:57:24 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-30 09:57:24 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-30 09:57:24 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-30 09:57:24 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:24 --> Database Driver Class Initialized
DEBUG - 2016-09-30 09:57:24 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-30 09:57:24 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-30 09:57:24 --> Final output sent to browser
DEBUG - 2016-09-30 09:57:24 --> Total execution time: 0.1536
INFO - 2016-09-30 09:57:25 --> Config Class Initialized
INFO - 2016-09-30 09:57:25 --> Hooks Class Initialized
DEBUG - 2016-09-30 09:57:25 --> UTF-8 Support Enabled
INFO - 2016-09-30 09:57:25 --> Utf8 Class Initialized
INFO - 2016-09-30 09:57:25 --> URI Class Initialized
INFO - 2016-09-30 09:57:25 --> Router Class Initialized
INFO - 2016-09-30 09:57:25 --> Output Class Initialized
INFO - 2016-09-30 09:57:25 --> Security Class Initialized
DEBUG - 2016-09-30 09:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-30 09:57:25 --> Input Class Initialized
INFO - 2016-09-30 09:57:25 --> Language Class Initialized
INFO - 2016-09-30 09:57:25 --> Language Class Initialized
INFO - 2016-09-30 09:57:25 --> Config Class Initialized
INFO - 2016-09-30 09:57:25 --> Loader Class Initialized
INFO - 2016-09-30 09:57:25 --> Helper loaded: url_helper
INFO - 2016-09-30 09:57:25 --> Database Driver Class Initialized
INFO - 2016-09-30 09:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-30 09:57:25 --> Controller Class Initialized
DEBUG - 2016-09-30 09:57:25 --> login MX_Controller Initialized
INFO - 2016-09-30 09:57:25 --> Model Class Initialized
INFO - 2016-09-30 09:57:25 --> Model Class Initialized
DEBUG - 2016-09-30 09:57:25 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-30 09:57:25 --> Final output sent to browser
DEBUG - 2016-09-30 09:57:25 --> Total execution time: 0.0384
INFO - 2016-09-30 09:59:53 --> Config Class Initialized
INFO - 2016-09-30 09:59:53 --> Hooks Class Initialized
DEBUG - 2016-09-30 09:59:53 --> UTF-8 Support Enabled
INFO - 2016-09-30 09:59:53 --> Utf8 Class Initialized
INFO - 2016-09-30 09:59:53 --> URI Class Initialized
INFO - 2016-09-30 09:59:53 --> Router Class Initialized
INFO - 2016-09-30 09:59:53 --> Output Class Initialized
INFO - 2016-09-30 09:59:53 --> Security Class Initialized
DEBUG - 2016-09-30 09:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-30 09:59:53 --> Input Class Initialized
INFO - 2016-09-30 09:59:53 --> Language Class Initialized
INFO - 2016-09-30 09:59:53 --> Language Class Initialized
INFO - 2016-09-30 09:59:53 --> Config Class Initialized
INFO - 2016-09-30 09:59:53 --> Loader Class Initialized
INFO - 2016-09-30 09:59:53 --> Helper loaded: url_helper
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-30 09:59:53 --> Controller Class Initialized
DEBUG - 2016-09-30 09:59:53 --> Index MX_Controller Initialized
INFO - 2016-09-30 09:59:53 --> Model Class Initialized
INFO - 2016-09-30 09:59:53 --> Model Class Initialized
ERROR - 2016-09-30 09:59:53 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-30 09:59:53 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-30 09:59:53 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-30 09:59:53 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-30 09:59:53 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-30 09:59:53 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-30 09:59:53 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:53 --> Database Driver Class Initialized
DEBUG - 2016-09-30 09:59:53 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-30 09:59:53 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-30 09:59:53 --> Final output sent to browser
DEBUG - 2016-09-30 09:59:53 --> Total execution time: 0.1167
INFO - 2016-09-30 09:59:54 --> Config Class Initialized
INFO - 2016-09-30 09:59:54 --> Hooks Class Initialized
DEBUG - 2016-09-30 09:59:54 --> UTF-8 Support Enabled
INFO - 2016-09-30 09:59:54 --> Utf8 Class Initialized
INFO - 2016-09-30 09:59:54 --> URI Class Initialized
INFO - 2016-09-30 09:59:54 --> Router Class Initialized
INFO - 2016-09-30 09:59:54 --> Output Class Initialized
INFO - 2016-09-30 09:59:54 --> Security Class Initialized
DEBUG - 2016-09-30 09:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-30 09:59:54 --> Input Class Initialized
INFO - 2016-09-30 09:59:54 --> Language Class Initialized
INFO - 2016-09-30 09:59:54 --> Language Class Initialized
INFO - 2016-09-30 09:59:54 --> Config Class Initialized
INFO - 2016-09-30 09:59:54 --> Loader Class Initialized
INFO - 2016-09-30 09:59:54 --> Helper loaded: url_helper
INFO - 2016-09-30 09:59:54 --> Database Driver Class Initialized
INFO - 2016-09-30 09:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-30 09:59:54 --> Controller Class Initialized
DEBUG - 2016-09-30 09:59:54 --> login MX_Controller Initialized
INFO - 2016-09-30 09:59:54 --> Model Class Initialized
INFO - 2016-09-30 09:59:54 --> Model Class Initialized
DEBUG - 2016-09-30 09:59:54 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-30 09:59:54 --> Final output sent to browser
DEBUG - 2016-09-30 09:59:54 --> Total execution time: 0.0256
INFO - 2016-09-30 10:38:38 --> Config Class Initialized
INFO - 2016-09-30 10:38:38 --> Hooks Class Initialized
DEBUG - 2016-09-30 10:38:38 --> UTF-8 Support Enabled
INFO - 2016-09-30 10:38:38 --> Utf8 Class Initialized
INFO - 2016-09-30 10:38:38 --> URI Class Initialized
INFO - 2016-09-30 10:38:38 --> Router Class Initialized
INFO - 2016-09-30 10:38:38 --> Output Class Initialized
INFO - 2016-09-30 10:38:38 --> Security Class Initialized
DEBUG - 2016-09-30 10:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-30 10:38:38 --> Input Class Initialized
INFO - 2016-09-30 10:38:38 --> Language Class Initialized
INFO - 2016-09-30 10:38:38 --> Language Class Initialized
INFO - 2016-09-30 10:38:38 --> Config Class Initialized
INFO - 2016-09-30 10:38:38 --> Loader Class Initialized
INFO - 2016-09-30 10:38:38 --> Helper loaded: url_helper
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-30 10:38:38 --> Controller Class Initialized
DEBUG - 2016-09-30 10:38:38 --> Index MX_Controller Initialized
INFO - 2016-09-30 10:38:38 --> Model Class Initialized
INFO - 2016-09-30 10:38:38 --> Model Class Initialized
ERROR - 2016-09-30 10:38:38 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-30 10:38:38 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-30 10:38:38 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-30 10:38:38 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-30 10:38:38 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-30 10:38:38 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-30 10:38:38 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:38 --> Database Driver Class Initialized
DEBUG - 2016-09-30 10:38:38 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-30 10:38:38 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-30 10:38:38 --> Final output sent to browser
DEBUG - 2016-09-30 10:38:38 --> Total execution time: 0.1251
INFO - 2016-09-30 10:38:39 --> Config Class Initialized
INFO - 2016-09-30 10:38:39 --> Hooks Class Initialized
DEBUG - 2016-09-30 10:38:39 --> UTF-8 Support Enabled
INFO - 2016-09-30 10:38:39 --> Utf8 Class Initialized
INFO - 2016-09-30 10:38:39 --> URI Class Initialized
INFO - 2016-09-30 10:38:39 --> Router Class Initialized
INFO - 2016-09-30 10:38:39 --> Output Class Initialized
INFO - 2016-09-30 10:38:39 --> Security Class Initialized
DEBUG - 2016-09-30 10:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-30 10:38:39 --> Input Class Initialized
INFO - 2016-09-30 10:38:39 --> Language Class Initialized
INFO - 2016-09-30 10:38:39 --> Language Class Initialized
INFO - 2016-09-30 10:38:39 --> Config Class Initialized
INFO - 2016-09-30 10:38:39 --> Loader Class Initialized
INFO - 2016-09-30 10:38:39 --> Helper loaded: url_helper
INFO - 2016-09-30 10:38:39 --> Database Driver Class Initialized
INFO - 2016-09-30 10:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-30 10:38:39 --> Controller Class Initialized
DEBUG - 2016-09-30 10:38:39 --> login MX_Controller Initialized
INFO - 2016-09-30 10:38:39 --> Model Class Initialized
INFO - 2016-09-30 10:38:39 --> Model Class Initialized
DEBUG - 2016-09-30 10:38:39 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-30 10:38:39 --> Final output sent to browser
DEBUG - 2016-09-30 10:38:39 --> Total execution time: 0.0390
INFO - 2016-09-30 10:46:59 --> Config Class Initialized
INFO - 2016-09-30 10:46:59 --> Hooks Class Initialized
DEBUG - 2016-09-30 10:46:59 --> UTF-8 Support Enabled
INFO - 2016-09-30 10:46:59 --> Utf8 Class Initialized
INFO - 2016-09-30 10:46:59 --> URI Class Initialized
DEBUG - 2016-09-30 10:46:59 --> No URI present. Default controller set.
INFO - 2016-09-30 10:46:59 --> Router Class Initialized
INFO - 2016-09-30 10:46:59 --> Output Class Initialized
INFO - 2016-09-30 10:46:59 --> Security Class Initialized
DEBUG - 2016-09-30 10:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-30 10:46:59 --> Input Class Initialized
INFO - 2016-09-30 10:46:59 --> Language Class Initialized
INFO - 2016-09-30 10:46:59 --> Language Class Initialized
INFO - 2016-09-30 10:46:59 --> Config Class Initialized
INFO - 2016-09-30 10:46:59 --> Loader Class Initialized
INFO - 2016-09-30 10:46:59 --> Helper loaded: url_helper
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-30 10:46:59 --> Controller Class Initialized
DEBUG - 2016-09-30 10:46:59 --> Index MX_Controller Initialized
INFO - 2016-09-30 10:46:59 --> Model Class Initialized
INFO - 2016-09-30 10:46:59 --> Model Class Initialized
ERROR - 2016-09-30 10:46:59 --> Unable to delete cache file for 
DEBUG - 2016-09-30 10:46:59 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-30 10:46:59 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-30 10:46:59 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-30 10:46:59 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-30 10:46:59 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-30 10:46:59 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
INFO - 2016-09-30 10:46:59 --> Database Driver Class Initialized
DEBUG - 2016-09-30 10:46:59 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-30 10:46:59 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-30 10:46:59 --> Final output sent to browser
DEBUG - 2016-09-30 10:46:59 --> Total execution time: 0.1415
INFO - 2016-09-30 10:47:00 --> Config Class Initialized
INFO - 2016-09-30 10:47:00 --> Hooks Class Initialized
DEBUG - 2016-09-30 10:47:00 --> UTF-8 Support Enabled
INFO - 2016-09-30 10:47:00 --> Utf8 Class Initialized
INFO - 2016-09-30 10:47:00 --> URI Class Initialized
INFO - 2016-09-30 10:47:00 --> Router Class Initialized
INFO - 2016-09-30 10:47:00 --> Output Class Initialized
INFO - 2016-09-30 10:47:00 --> Security Class Initialized
DEBUG - 2016-09-30 10:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-30 10:47:00 --> Input Class Initialized
INFO - 2016-09-30 10:47:00 --> Language Class Initialized
INFO - 2016-09-30 10:47:00 --> Language Class Initialized
INFO - 2016-09-30 10:47:00 --> Config Class Initialized
INFO - 2016-09-30 10:47:00 --> Loader Class Initialized
INFO - 2016-09-30 10:47:00 --> Helper loaded: url_helper
INFO - 2016-09-30 10:47:00 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-30 10:47:00 --> Controller Class Initialized
DEBUG - 2016-09-30 10:47:00 --> login MX_Controller Initialized
INFO - 2016-09-30 10:47:00 --> Model Class Initialized
INFO - 2016-09-30 10:47:00 --> Model Class Initialized
DEBUG - 2016-09-30 10:47:00 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-30 10:47:00 --> Final output sent to browser
DEBUG - 2016-09-30 10:47:00 --> Total execution time: 0.0224
INFO - 2016-09-30 10:47:50 --> Config Class Initialized
INFO - 2016-09-30 10:47:50 --> Hooks Class Initialized
DEBUG - 2016-09-30 10:47:50 --> UTF-8 Support Enabled
INFO - 2016-09-30 10:47:50 --> Utf8 Class Initialized
INFO - 2016-09-30 10:47:50 --> URI Class Initialized
DEBUG - 2016-09-30 10:47:50 --> No URI present. Default controller set.
INFO - 2016-09-30 10:47:50 --> Router Class Initialized
INFO - 2016-09-30 10:47:50 --> Output Class Initialized
INFO - 2016-09-30 10:47:50 --> Security Class Initialized
DEBUG - 2016-09-30 10:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-30 10:47:50 --> Input Class Initialized
INFO - 2016-09-30 10:47:50 --> Language Class Initialized
INFO - 2016-09-30 10:47:50 --> Language Class Initialized
INFO - 2016-09-30 10:47:50 --> Config Class Initialized
INFO - 2016-09-30 10:47:50 --> Loader Class Initialized
INFO - 2016-09-30 10:47:50 --> Helper loaded: url_helper
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-30 10:47:50 --> Controller Class Initialized
DEBUG - 2016-09-30 10:47:50 --> Index MX_Controller Initialized
INFO - 2016-09-30 10:47:50 --> Model Class Initialized
INFO - 2016-09-30 10:47:50 --> Model Class Initialized
ERROR - 2016-09-30 10:47:50 --> Unable to delete cache file for 
DEBUG - 2016-09-30 10:47:50 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-30 10:47:50 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-30 10:47:50 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-30 10:47:50 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-30 10:47:50 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-30 10:47:50 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:50 --> Database Driver Class Initialized
DEBUG - 2016-09-30 10:47:50 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-30 10:47:50 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-30 10:47:50 --> Final output sent to browser
DEBUG - 2016-09-30 10:47:50 --> Total execution time: 0.1070
INFO - 2016-09-30 10:47:57 --> Config Class Initialized
INFO - 2016-09-30 10:47:57 --> Hooks Class Initialized
DEBUG - 2016-09-30 10:47:57 --> UTF-8 Support Enabled
INFO - 2016-09-30 10:47:57 --> Utf8 Class Initialized
INFO - 2016-09-30 10:47:57 --> URI Class Initialized
INFO - 2016-09-30 10:47:57 --> Router Class Initialized
INFO - 2016-09-30 10:47:57 --> Output Class Initialized
INFO - 2016-09-30 10:47:57 --> Security Class Initialized
DEBUG - 2016-09-30 10:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-30 10:47:57 --> Input Class Initialized
INFO - 2016-09-30 10:47:57 --> Language Class Initialized
INFO - 2016-09-30 10:47:57 --> Language Class Initialized
INFO - 2016-09-30 10:47:57 --> Config Class Initialized
INFO - 2016-09-30 10:47:57 --> Loader Class Initialized
INFO - 2016-09-30 10:47:57 --> Helper loaded: url_helper
INFO - 2016-09-30 10:47:57 --> Database Driver Class Initialized
INFO - 2016-09-30 10:47:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-30 10:47:57 --> Controller Class Initialized
DEBUG - 2016-09-30 10:47:57 --> login MX_Controller Initialized
INFO - 2016-09-30 10:47:57 --> Model Class Initialized
INFO - 2016-09-30 10:47:57 --> Model Class Initialized
DEBUG - 2016-09-30 10:47:57 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-30 10:47:57 --> Final output sent to browser
DEBUG - 2016-09-30 10:47:57 --> Total execution time: 0.0255
INFO - 2016-09-30 11:27:13 --> Config Class Initialized
INFO - 2016-09-30 11:27:13 --> Hooks Class Initialized
DEBUG - 2016-09-30 11:27:13 --> UTF-8 Support Enabled
INFO - 2016-09-30 11:27:13 --> Utf8 Class Initialized
INFO - 2016-09-30 11:27:13 --> URI Class Initialized
DEBUG - 2016-09-30 11:27:13 --> No URI present. Default controller set.
INFO - 2016-09-30 11:27:13 --> Router Class Initialized
INFO - 2016-09-30 11:27:13 --> Output Class Initialized
INFO - 2016-09-30 11:27:13 --> Security Class Initialized
DEBUG - 2016-09-30 11:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-30 11:27:13 --> Input Class Initialized
INFO - 2016-09-30 11:27:13 --> Language Class Initialized
INFO - 2016-09-30 11:27:13 --> Language Class Initialized
INFO - 2016-09-30 11:27:13 --> Config Class Initialized
INFO - 2016-09-30 11:27:13 --> Loader Class Initialized
INFO - 2016-09-30 11:27:13 --> Helper loaded: url_helper
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-30 11:27:13 --> Controller Class Initialized
DEBUG - 2016-09-30 11:27:13 --> Index MX_Controller Initialized
INFO - 2016-09-30 11:27:13 --> Model Class Initialized
INFO - 2016-09-30 11:27:13 --> Model Class Initialized
ERROR - 2016-09-30 11:27:13 --> Unable to delete cache file for 
DEBUG - 2016-09-30 11:27:13 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-30 11:27:13 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-30 11:27:13 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-30 11:27:13 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-30 11:27:13 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-30 11:27:13 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:13 --> Database Driver Class Initialized
DEBUG - 2016-09-30 11:27:13 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-30 11:27:13 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-30 11:27:13 --> Final output sent to browser
DEBUG - 2016-09-30 11:27:13 --> Total execution time: 0.1302
INFO - 2016-09-30 11:27:14 --> Config Class Initialized
INFO - 2016-09-30 11:27:14 --> Hooks Class Initialized
DEBUG - 2016-09-30 11:27:14 --> UTF-8 Support Enabled
INFO - 2016-09-30 11:27:14 --> Utf8 Class Initialized
INFO - 2016-09-30 11:27:14 --> URI Class Initialized
INFO - 2016-09-30 11:27:14 --> Router Class Initialized
INFO - 2016-09-30 11:27:14 --> Output Class Initialized
INFO - 2016-09-30 11:27:14 --> Security Class Initialized
DEBUG - 2016-09-30 11:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-30 11:27:14 --> Input Class Initialized
INFO - 2016-09-30 11:27:14 --> Language Class Initialized
INFO - 2016-09-30 11:27:14 --> Language Class Initialized
INFO - 2016-09-30 11:27:14 --> Config Class Initialized
INFO - 2016-09-30 11:27:14 --> Loader Class Initialized
INFO - 2016-09-30 11:27:14 --> Helper loaded: url_helper
INFO - 2016-09-30 11:27:14 --> Database Driver Class Initialized
INFO - 2016-09-30 11:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-30 11:27:14 --> Controller Class Initialized
DEBUG - 2016-09-30 11:27:14 --> login MX_Controller Initialized
INFO - 2016-09-30 11:27:14 --> Model Class Initialized
INFO - 2016-09-30 11:27:14 --> Model Class Initialized
DEBUG - 2016-09-30 11:27:14 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-30 11:27:14 --> Final output sent to browser
DEBUG - 2016-09-30 11:27:14 --> Total execution time: 0.0311
INFO - 2016-09-30 11:27:14 --> Config Class Initialized
INFO - 2016-09-30 11:27:14 --> Hooks Class Initialized
DEBUG - 2016-09-30 11:27:14 --> UTF-8 Support Enabled
INFO - 2016-09-30 11:27:14 --> Utf8 Class Initialized
INFO - 2016-09-30 11:27:14 --> URI Class Initialized
INFO - 2016-09-30 11:27:14 --> Router Class Initialized
INFO - 2016-09-30 11:27:14 --> Output Class Initialized
INFO - 2016-09-30 11:27:14 --> Security Class Initialized
DEBUG - 2016-09-30 11:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-30 11:27:14 --> Input Class Initialized
INFO - 2016-09-30 11:27:14 --> Language Class Initialized
ERROR - 2016-09-30 11:27:14 --> 404 Page Not Found: /index
INFO - 2016-09-30 14:12:28 --> Config Class Initialized
INFO - 2016-09-30 14:12:28 --> Hooks Class Initialized
DEBUG - 2016-09-30 14:12:28 --> UTF-8 Support Enabled
INFO - 2016-09-30 14:12:28 --> Utf8 Class Initialized
INFO - 2016-09-30 14:12:28 --> URI Class Initialized
DEBUG - 2016-09-30 14:12:28 --> No URI present. Default controller set.
INFO - 2016-09-30 14:12:28 --> Router Class Initialized
INFO - 2016-09-30 14:12:28 --> Output Class Initialized
INFO - 2016-09-30 14:12:28 --> Security Class Initialized
DEBUG - 2016-09-30 14:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-30 14:12:28 --> Input Class Initialized
INFO - 2016-09-30 14:12:28 --> Language Class Initialized
INFO - 2016-09-30 14:12:28 --> Language Class Initialized
INFO - 2016-09-30 14:12:28 --> Config Class Initialized
INFO - 2016-09-30 14:12:28 --> Loader Class Initialized
INFO - 2016-09-30 14:12:28 --> Helper loaded: url_helper
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-30 14:12:28 --> Controller Class Initialized
DEBUG - 2016-09-30 14:12:28 --> Index MX_Controller Initialized
INFO - 2016-09-30 14:12:28 --> Model Class Initialized
INFO - 2016-09-30 14:12:28 --> Model Class Initialized
ERROR - 2016-09-30 14:12:28 --> Unable to delete cache file for 
DEBUG - 2016-09-30 14:12:28 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-30 14:12:28 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-30 14:12:28 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-30 14:12:28 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-30 14:12:28 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-30 14:12:28 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:28 --> Database Driver Class Initialized
DEBUG - 2016-09-30 14:12:28 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-30 14:12:28 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-30 14:12:28 --> Final output sent to browser
DEBUG - 2016-09-30 14:12:28 --> Total execution time: 0.2425
INFO - 2016-09-30 14:12:29 --> Config Class Initialized
INFO - 2016-09-30 14:12:29 --> Hooks Class Initialized
DEBUG - 2016-09-30 14:12:29 --> UTF-8 Support Enabled
INFO - 2016-09-30 14:12:29 --> Utf8 Class Initialized
INFO - 2016-09-30 14:12:29 --> URI Class Initialized
DEBUG - 2016-09-30 14:12:29 --> No URI present. Default controller set.
INFO - 2016-09-30 14:12:29 --> Router Class Initialized
INFO - 2016-09-30 14:12:29 --> Output Class Initialized
INFO - 2016-09-30 14:12:29 --> Security Class Initialized
DEBUG - 2016-09-30 14:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-30 14:12:29 --> Input Class Initialized
INFO - 2016-09-30 14:12:29 --> Language Class Initialized
INFO - 2016-09-30 14:12:29 --> Language Class Initialized
INFO - 2016-09-30 14:12:29 --> Config Class Initialized
INFO - 2016-09-30 14:12:29 --> Loader Class Initialized
INFO - 2016-09-30 14:12:29 --> Helper loaded: url_helper
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-30 14:12:29 --> Controller Class Initialized
DEBUG - 2016-09-30 14:12:29 --> Index MX_Controller Initialized
INFO - 2016-09-30 14:12:29 --> Model Class Initialized
INFO - 2016-09-30 14:12:29 --> Model Class Initialized
ERROR - 2016-09-30 14:12:29 --> Unable to delete cache file for 
DEBUG - 2016-09-30 14:12:29 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-30 14:12:29 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-30 14:12:29 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-30 14:12:29 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-30 14:12:29 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-30 14:12:29 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:29 --> Database Driver Class Initialized
DEBUG - 2016-09-30 14:12:29 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-30 14:12:29 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-30 14:12:29 --> Final output sent to browser
DEBUG - 2016-09-30 14:12:29 --> Total execution time: 0.2122
INFO - 2016-09-30 14:12:30 --> Config Class Initialized
INFO - 2016-09-30 14:12:30 --> Hooks Class Initialized
DEBUG - 2016-09-30 14:12:30 --> UTF-8 Support Enabled
INFO - 2016-09-30 14:12:30 --> Utf8 Class Initialized
INFO - 2016-09-30 14:12:30 --> URI Class Initialized
INFO - 2016-09-30 14:12:30 --> Router Class Initialized
INFO - 2016-09-30 14:12:30 --> Output Class Initialized
INFO - 2016-09-30 14:12:30 --> Security Class Initialized
DEBUG - 2016-09-30 14:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-30 14:12:30 --> Input Class Initialized
INFO - 2016-09-30 14:12:30 --> Language Class Initialized
INFO - 2016-09-30 14:12:30 --> Language Class Initialized
INFO - 2016-09-30 14:12:30 --> Config Class Initialized
INFO - 2016-09-30 14:12:30 --> Loader Class Initialized
INFO - 2016-09-30 14:12:30 --> Helper loaded: url_helper
INFO - 2016-09-30 14:12:30 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-30 14:12:30 --> Controller Class Initialized
DEBUG - 2016-09-30 14:12:30 --> login MX_Controller Initialized
INFO - 2016-09-30 14:12:30 --> Model Class Initialized
INFO - 2016-09-30 14:12:30 --> Model Class Initialized
DEBUG - 2016-09-30 14:12:30 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-30 14:12:30 --> Final output sent to browser
DEBUG - 2016-09-30 14:12:30 --> Total execution time: 0.0432
INFO - 2016-09-30 14:12:32 --> Config Class Initialized
INFO - 2016-09-30 14:12:32 --> Hooks Class Initialized
DEBUG - 2016-09-30 14:12:32 --> UTF-8 Support Enabled
INFO - 2016-09-30 14:12:32 --> Utf8 Class Initialized
INFO - 2016-09-30 14:12:32 --> URI Class Initialized
INFO - 2016-09-30 14:12:32 --> Router Class Initialized
INFO - 2016-09-30 14:12:32 --> Output Class Initialized
INFO - 2016-09-30 14:12:32 --> Security Class Initialized
DEBUG - 2016-09-30 14:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-30 14:12:32 --> Input Class Initialized
INFO - 2016-09-30 14:12:32 --> Language Class Initialized
INFO - 2016-09-30 14:12:32 --> Language Class Initialized
INFO - 2016-09-30 14:12:32 --> Config Class Initialized
INFO - 2016-09-30 14:12:32 --> Loader Class Initialized
INFO - 2016-09-30 14:12:32 --> Helper loaded: url_helper
INFO - 2016-09-30 14:12:32 --> Database Driver Class Initialized
INFO - 2016-09-30 14:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-30 14:12:32 --> Controller Class Initialized
DEBUG - 2016-09-30 14:12:32 --> login MX_Controller Initialized
INFO - 2016-09-30 14:12:32 --> Model Class Initialized
INFO - 2016-09-30 14:12:32 --> Model Class Initialized
DEBUG - 2016-09-30 14:12:32 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-30 14:12:32 --> Final output sent to browser
DEBUG - 2016-09-30 14:12:32 --> Total execution time: 0.0452
INFO - 2016-09-30 16:23:36 --> Config Class Initialized
INFO - 2016-09-30 16:23:36 --> Hooks Class Initialized
DEBUG - 2016-09-30 16:23:36 --> UTF-8 Support Enabled
INFO - 2016-09-30 16:23:36 --> Utf8 Class Initialized
INFO - 2016-09-30 16:23:36 --> URI Class Initialized
INFO - 2016-09-30 16:23:36 --> Router Class Initialized
INFO - 2016-09-30 16:23:36 --> Output Class Initialized
INFO - 2016-09-30 16:23:36 --> Security Class Initialized
DEBUG - 2016-09-30 16:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-30 16:23:36 --> Input Class Initialized
INFO - 2016-09-30 16:23:36 --> Language Class Initialized
ERROR - 2016-09-30 16:23:36 --> 404 Page Not Found: /index
INFO - 2016-09-30 16:23:40 --> Config Class Initialized
INFO - 2016-09-30 16:23:40 --> Hooks Class Initialized
DEBUG - 2016-09-30 16:23:40 --> UTF-8 Support Enabled
INFO - 2016-09-30 16:23:40 --> Utf8 Class Initialized
INFO - 2016-09-30 16:23:40 --> URI Class Initialized
DEBUG - 2016-09-30 16:23:40 --> No URI present. Default controller set.
INFO - 2016-09-30 16:23:40 --> Router Class Initialized
INFO - 2016-09-30 16:23:40 --> Output Class Initialized
INFO - 2016-09-30 16:23:40 --> Security Class Initialized
DEBUG - 2016-09-30 16:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-30 16:23:40 --> Input Class Initialized
INFO - 2016-09-30 16:23:40 --> Language Class Initialized
INFO - 2016-09-30 16:23:40 --> Language Class Initialized
INFO - 2016-09-30 16:23:40 --> Config Class Initialized
INFO - 2016-09-30 16:23:40 --> Loader Class Initialized
INFO - 2016-09-30 16:23:40 --> Helper loaded: url_helper
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-30 16:23:40 --> Controller Class Initialized
DEBUG - 2016-09-30 16:23:40 --> Index MX_Controller Initialized
INFO - 2016-09-30 16:23:40 --> Model Class Initialized
INFO - 2016-09-30 16:23:40 --> Model Class Initialized
ERROR - 2016-09-30 16:23:40 --> Unable to delete cache file for 
DEBUG - 2016-09-30 16:23:40 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-30 16:23:40 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-30 16:23:40 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-30 16:23:40 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-30 16:23:40 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-30 16:23:40 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:40 --> Database Driver Class Initialized
DEBUG - 2016-09-30 16:23:40 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-30 16:23:40 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-30 16:23:40 --> Final output sent to browser
DEBUG - 2016-09-30 16:23:40 --> Total execution time: 0.2665
INFO - 2016-09-30 16:23:44 --> Config Class Initialized
INFO - 2016-09-30 16:23:44 --> Hooks Class Initialized
DEBUG - 2016-09-30 16:23:44 --> UTF-8 Support Enabled
INFO - 2016-09-30 16:23:44 --> Utf8 Class Initialized
INFO - 2016-09-30 16:23:44 --> URI Class Initialized
INFO - 2016-09-30 16:23:44 --> Router Class Initialized
INFO - 2016-09-30 16:23:44 --> Output Class Initialized
INFO - 2016-09-30 16:23:44 --> Security Class Initialized
DEBUG - 2016-09-30 16:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-30 16:23:44 --> Input Class Initialized
INFO - 2016-09-30 16:23:44 --> Language Class Initialized
INFO - 2016-09-30 16:23:44 --> Language Class Initialized
INFO - 2016-09-30 16:23:44 --> Config Class Initialized
INFO - 2016-09-30 16:23:44 --> Loader Class Initialized
INFO - 2016-09-30 16:23:44 --> Helper loaded: url_helper
INFO - 2016-09-30 16:23:44 --> Database Driver Class Initialized
INFO - 2016-09-30 16:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-30 16:23:44 --> Controller Class Initialized
DEBUG - 2016-09-30 16:23:44 --> login MX_Controller Initialized
INFO - 2016-09-30 16:23:44 --> Model Class Initialized
INFO - 2016-09-30 16:23:44 --> Model Class Initialized
DEBUG - 2016-09-30 16:23:44 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-30 16:23:44 --> Final output sent to browser
DEBUG - 2016-09-30 16:23:44 --> Total execution time: 0.0347
INFO - 2016-09-30 17:49:42 --> Config Class Initialized
INFO - 2016-09-30 17:49:42 --> Hooks Class Initialized
DEBUG - 2016-09-30 17:49:42 --> UTF-8 Support Enabled
INFO - 2016-09-30 17:49:42 --> Utf8 Class Initialized
INFO - 2016-09-30 17:49:42 --> URI Class Initialized
INFO - 2016-09-30 17:49:42 --> Router Class Initialized
INFO - 2016-09-30 17:49:42 --> Output Class Initialized
INFO - 2016-09-30 17:49:42 --> Security Class Initialized
DEBUG - 2016-09-30 17:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-30 17:49:42 --> Input Class Initialized
INFO - 2016-09-30 17:49:42 --> Language Class Initialized
INFO - 2016-09-30 17:49:42 --> Language Class Initialized
INFO - 2016-09-30 17:49:42 --> Config Class Initialized
INFO - 2016-09-30 17:49:42 --> Loader Class Initialized
INFO - 2016-09-30 17:49:42 --> Helper loaded: url_helper
INFO - 2016-09-30 17:49:42 --> Database Driver Class Initialized
INFO - 2016-09-30 17:49:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-30 17:49:42 --> Controller Class Initialized
DEBUG - 2016-09-30 17:49:42 --> login MX_Controller Initialized
INFO - 2016-09-30 17:49:42 --> Model Class Initialized
INFO - 2016-09-30 17:49:42 --> Model Class Initialized
DEBUG - 2016-09-30 17:49:42 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-30 17:49:42 --> Final output sent to browser
DEBUG - 2016-09-30 17:49:42 --> Total execution time: 0.0901
INFO - 2016-09-30 17:49:43 --> Config Class Initialized
INFO - 2016-09-30 17:49:43 --> Hooks Class Initialized
DEBUG - 2016-09-30 17:49:43 --> UTF-8 Support Enabled
INFO - 2016-09-30 17:49:43 --> Utf8 Class Initialized
INFO - 2016-09-30 17:49:43 --> URI Class Initialized
INFO - 2016-09-30 17:49:43 --> Router Class Initialized
INFO - 2016-09-30 17:49:43 --> Output Class Initialized
INFO - 2016-09-30 17:49:43 --> Security Class Initialized
DEBUG - 2016-09-30 17:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-30 17:49:43 --> Input Class Initialized
INFO - 2016-09-30 17:49:43 --> Language Class Initialized
ERROR - 2016-09-30 17:49:43 --> 404 Page Not Found: /index
INFO - 2016-09-30 17:49:43 --> Config Class Initialized
INFO - 2016-09-30 17:49:43 --> Hooks Class Initialized
DEBUG - 2016-09-30 17:49:43 --> UTF-8 Support Enabled
INFO - 2016-09-30 17:49:43 --> Utf8 Class Initialized
INFO - 2016-09-30 17:49:43 --> URI Class Initialized
INFO - 2016-09-30 17:49:43 --> Router Class Initialized
INFO - 2016-09-30 17:49:43 --> Output Class Initialized
INFO - 2016-09-30 17:49:43 --> Security Class Initialized
DEBUG - 2016-09-30 17:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-30 17:49:43 --> Input Class Initialized
INFO - 2016-09-30 17:49:43 --> Language Class Initialized
ERROR - 2016-09-30 17:49:43 --> 404 Page Not Found: /index
INFO - 2016-09-30 17:49:44 --> Config Class Initialized
INFO - 2016-09-30 17:49:44 --> Hooks Class Initialized
DEBUG - 2016-09-30 17:49:44 --> UTF-8 Support Enabled
INFO - 2016-09-30 17:49:44 --> Utf8 Class Initialized
INFO - 2016-09-30 17:49:44 --> URI Class Initialized
INFO - 2016-09-30 17:49:44 --> Router Class Initialized
INFO - 2016-09-30 17:49:44 --> Output Class Initialized
INFO - 2016-09-30 17:49:44 --> Security Class Initialized
DEBUG - 2016-09-30 17:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-30 17:49:44 --> Input Class Initialized
INFO - 2016-09-30 17:49:44 --> Language Class Initialized
ERROR - 2016-09-30 17:49:44 --> 404 Page Not Found: /index
INFO - 2016-09-30 17:49:44 --> Config Class Initialized
INFO - 2016-09-30 17:49:44 --> Hooks Class Initialized
DEBUG - 2016-09-30 17:49:44 --> UTF-8 Support Enabled
INFO - 2016-09-30 17:49:44 --> Utf8 Class Initialized
INFO - 2016-09-30 17:49:44 --> URI Class Initialized
INFO - 2016-09-30 17:49:44 --> Router Class Initialized
INFO - 2016-09-30 17:49:44 --> Output Class Initialized
INFO - 2016-09-30 17:49:44 --> Security Class Initialized
DEBUG - 2016-09-30 17:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-30 17:49:44 --> Input Class Initialized
INFO - 2016-09-30 17:49:44 --> Language Class Initialized
ERROR - 2016-09-30 17:49:44 --> 404 Page Not Found: /index
INFO - 2016-09-30 17:49:45 --> Config Class Initialized
INFO - 2016-09-30 17:49:45 --> Hooks Class Initialized
DEBUG - 2016-09-30 17:49:45 --> UTF-8 Support Enabled
INFO - 2016-09-30 17:49:45 --> Utf8 Class Initialized
INFO - 2016-09-30 17:49:45 --> URI Class Initialized
INFO - 2016-09-30 17:49:45 --> Router Class Initialized
INFO - 2016-09-30 17:49:45 --> Output Class Initialized
INFO - 2016-09-30 17:49:45 --> Security Class Initialized
DEBUG - 2016-09-30 17:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-30 17:49:45 --> Input Class Initialized
INFO - 2016-09-30 17:49:45 --> Language Class Initialized
ERROR - 2016-09-30 17:49:45 --> 404 Page Not Found: /index
INFO - 2016-09-30 17:49:45 --> Config Class Initialized
INFO - 2016-09-30 17:49:45 --> Hooks Class Initialized
DEBUG - 2016-09-30 17:49:45 --> UTF-8 Support Enabled
INFO - 2016-09-30 17:49:45 --> Utf8 Class Initialized
INFO - 2016-09-30 17:49:45 --> URI Class Initialized
INFO - 2016-09-30 17:49:45 --> Router Class Initialized
INFO - 2016-09-30 17:49:45 --> Output Class Initialized
INFO - 2016-09-30 17:49:45 --> Security Class Initialized
DEBUG - 2016-09-30 17:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-30 17:49:45 --> Input Class Initialized
INFO - 2016-09-30 17:49:45 --> Language Class Initialized
ERROR - 2016-09-30 17:49:45 --> 404 Page Not Found: /index
INFO - 2016-09-30 17:49:46 --> Config Class Initialized
INFO - 2016-09-30 17:49:46 --> Hooks Class Initialized
DEBUG - 2016-09-30 17:49:46 --> UTF-8 Support Enabled
INFO - 2016-09-30 17:49:46 --> Utf8 Class Initialized
INFO - 2016-09-30 17:49:46 --> URI Class Initialized
INFO - 2016-09-30 17:49:46 --> Router Class Initialized
INFO - 2016-09-30 17:49:46 --> Output Class Initialized
INFO - 2016-09-30 17:49:46 --> Security Class Initialized
DEBUG - 2016-09-30 17:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-30 17:49:46 --> Input Class Initialized
INFO - 2016-09-30 17:49:46 --> Language Class Initialized
ERROR - 2016-09-30 17:49:46 --> 404 Page Not Found: /index
INFO - 2016-09-30 17:49:46 --> Config Class Initialized
INFO - 2016-09-30 17:49:46 --> Hooks Class Initialized
DEBUG - 2016-09-30 17:49:46 --> UTF-8 Support Enabled
INFO - 2016-09-30 17:49:46 --> Utf8 Class Initialized
INFO - 2016-09-30 17:49:46 --> URI Class Initialized
INFO - 2016-09-30 17:49:46 --> Router Class Initialized
INFO - 2016-09-30 17:49:46 --> Output Class Initialized
INFO - 2016-09-30 17:49:46 --> Security Class Initialized
DEBUG - 2016-09-30 17:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-30 17:49:46 --> Input Class Initialized
INFO - 2016-09-30 17:49:46 --> Language Class Initialized
ERROR - 2016-09-30 17:49:46 --> 404 Page Not Found: /index
INFO - 2016-09-30 17:49:47 --> Config Class Initialized
INFO - 2016-09-30 17:49:47 --> Hooks Class Initialized
DEBUG - 2016-09-30 17:49:47 --> UTF-8 Support Enabled
INFO - 2016-09-30 17:49:47 --> Utf8 Class Initialized
INFO - 2016-09-30 17:49:47 --> URI Class Initialized
INFO - 2016-09-30 17:49:47 --> Router Class Initialized
INFO - 2016-09-30 17:49:47 --> Output Class Initialized
INFO - 2016-09-30 17:49:47 --> Security Class Initialized
DEBUG - 2016-09-30 17:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-30 17:49:47 --> Input Class Initialized
INFO - 2016-09-30 17:49:47 --> Language Class Initialized
ERROR - 2016-09-30 17:49:47 --> 404 Page Not Found: /index
INFO - 2016-09-30 17:49:47 --> Config Class Initialized
INFO - 2016-09-30 17:49:47 --> Hooks Class Initialized
DEBUG - 2016-09-30 17:49:47 --> UTF-8 Support Enabled
INFO - 2016-09-30 17:49:47 --> Utf8 Class Initialized
INFO - 2016-09-30 17:49:47 --> URI Class Initialized
INFO - 2016-09-30 17:49:47 --> Router Class Initialized
INFO - 2016-09-30 17:49:47 --> Output Class Initialized
INFO - 2016-09-30 17:49:47 --> Security Class Initialized
DEBUG - 2016-09-30 17:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-30 17:49:47 --> Input Class Initialized
INFO - 2016-09-30 17:49:47 --> Language Class Initialized
ERROR - 2016-09-30 17:49:47 --> 404 Page Not Found: /index
INFO - 2016-09-30 19:22:28 --> Config Class Initialized
INFO - 2016-09-30 19:22:28 --> Hooks Class Initialized
DEBUG - 2016-09-30 19:22:28 --> UTF-8 Support Enabled
INFO - 2016-09-30 19:22:28 --> Utf8 Class Initialized
INFO - 2016-09-30 19:22:28 --> URI Class Initialized
DEBUG - 2016-09-30 19:22:28 --> No URI present. Default controller set.
INFO - 2016-09-30 19:22:28 --> Router Class Initialized
INFO - 2016-09-30 19:22:28 --> Output Class Initialized
INFO - 2016-09-30 19:22:28 --> Security Class Initialized
DEBUG - 2016-09-30 19:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-30 19:22:28 --> Input Class Initialized
INFO - 2016-09-30 19:22:28 --> Language Class Initialized
INFO - 2016-09-30 19:22:28 --> Language Class Initialized
INFO - 2016-09-30 19:22:28 --> Config Class Initialized
INFO - 2016-09-30 19:22:28 --> Loader Class Initialized
INFO - 2016-09-30 19:22:28 --> Helper loaded: url_helper
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-30 19:22:28 --> Controller Class Initialized
DEBUG - 2016-09-30 19:22:28 --> Index MX_Controller Initialized
INFO - 2016-09-30 19:22:28 --> Model Class Initialized
INFO - 2016-09-30 19:22:28 --> Model Class Initialized
ERROR - 2016-09-30 19:22:28 --> Unable to delete cache file for 
DEBUG - 2016-09-30 19:22:28 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-30 19:22:28 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-30 19:22:28 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-30 19:22:28 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-30 19:22:28 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-30 19:22:28 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:29 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:29 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:29 --> Database Driver Class Initialized
DEBUG - 2016-09-30 19:22:29 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-30 19:22:29 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-30 19:22:29 --> Final output sent to browser
DEBUG - 2016-09-30 19:22:29 --> Total execution time: 0.1703
INFO - 2016-09-30 19:22:38 --> Config Class Initialized
INFO - 2016-09-30 19:22:38 --> Hooks Class Initialized
DEBUG - 2016-09-30 19:22:38 --> UTF-8 Support Enabled
INFO - 2016-09-30 19:22:38 --> Utf8 Class Initialized
INFO - 2016-09-30 19:22:38 --> URI Class Initialized
INFO - 2016-09-30 19:22:38 --> Router Class Initialized
INFO - 2016-09-30 19:22:38 --> Output Class Initialized
INFO - 2016-09-30 19:22:38 --> Security Class Initialized
DEBUG - 2016-09-30 19:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-30 19:22:38 --> Input Class Initialized
INFO - 2016-09-30 19:22:38 --> Language Class Initialized
INFO - 2016-09-30 19:22:38 --> Language Class Initialized
INFO - 2016-09-30 19:22:38 --> Config Class Initialized
INFO - 2016-09-30 19:22:38 --> Loader Class Initialized
INFO - 2016-09-30 19:22:38 --> Helper loaded: url_helper
INFO - 2016-09-30 19:22:38 --> Database Driver Class Initialized
INFO - 2016-09-30 19:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-30 19:22:38 --> Controller Class Initialized
DEBUG - 2016-09-30 19:22:38 --> login MX_Controller Initialized
INFO - 2016-09-30 19:22:38 --> Model Class Initialized
INFO - 2016-09-30 19:22:38 --> Model Class Initialized
DEBUG - 2016-09-30 19:22:38 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-30 19:22:38 --> Final output sent to browser
DEBUG - 2016-09-30 19:22:38 --> Total execution time: 0.0314
INFO - 2016-09-30 21:38:02 --> Config Class Initialized
INFO - 2016-09-30 21:38:02 --> Hooks Class Initialized
DEBUG - 2016-09-30 21:38:02 --> UTF-8 Support Enabled
INFO - 2016-09-30 21:38:02 --> Utf8 Class Initialized
INFO - 2016-09-30 21:38:02 --> URI Class Initialized
DEBUG - 2016-09-30 21:38:02 --> No URI present. Default controller set.
INFO - 2016-09-30 21:38:02 --> Router Class Initialized
INFO - 2016-09-30 21:38:02 --> Output Class Initialized
INFO - 2016-09-30 21:38:02 --> Security Class Initialized
DEBUG - 2016-09-30 21:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-30 21:38:02 --> Input Class Initialized
INFO - 2016-09-30 21:38:02 --> Language Class Initialized
INFO - 2016-09-30 21:38:02 --> Language Class Initialized
INFO - 2016-09-30 21:38:02 --> Config Class Initialized
INFO - 2016-09-30 21:38:02 --> Loader Class Initialized
INFO - 2016-09-30 21:38:02 --> Helper loaded: url_helper
INFO - 2016-09-30 21:38:02 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-30 21:38:02 --> Controller Class Initialized
DEBUG - 2016-09-30 21:38:02 --> Index MX_Controller Initialized
INFO - 2016-09-30 21:38:02 --> Model Class Initialized
INFO - 2016-09-30 21:38:02 --> Model Class Initialized
ERROR - 2016-09-30 21:38:02 --> Unable to delete cache file for 
DEBUG - 2016-09-30 21:38:02 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-30 21:38:02 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-30 21:38:02 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-30 21:38:02 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-30 21:38:02 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-30 21:38:02 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-30 21:38:02 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:02 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:02 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:02 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:02 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:02 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:02 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:02 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:02 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:02 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:02 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:02 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:02 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:02 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:02 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:02 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:02 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:02 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:02 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:02 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:02 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:02 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:02 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:02 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:02 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:02 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:02 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:02 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:02 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:02 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:02 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:02 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:02 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:02 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:02 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:02 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:02 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:02 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:02 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:02 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:02 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:02 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:02 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:02 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:02 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:02 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:03 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:03 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:03 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:03 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:03 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:03 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:03 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:03 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:03 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:03 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:03 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:03 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:03 --> Database Driver Class Initialized
DEBUG - 2016-09-30 21:38:03 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-30 21:38:03 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-30 21:38:03 --> Final output sent to browser
DEBUG - 2016-09-30 21:38:03 --> Total execution time: 0.3240
INFO - 2016-09-30 21:38:03 --> Config Class Initialized
INFO - 2016-09-30 21:38:03 --> Hooks Class Initialized
DEBUG - 2016-09-30 21:38:03 --> UTF-8 Support Enabled
INFO - 2016-09-30 21:38:03 --> Utf8 Class Initialized
INFO - 2016-09-30 21:38:03 --> URI Class Initialized
INFO - 2016-09-30 21:38:03 --> Router Class Initialized
INFO - 2016-09-30 21:38:03 --> Output Class Initialized
INFO - 2016-09-30 21:38:03 --> Security Class Initialized
DEBUG - 2016-09-30 21:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-30 21:38:03 --> Input Class Initialized
INFO - 2016-09-30 21:38:03 --> Language Class Initialized
INFO - 2016-09-30 21:38:03 --> Language Class Initialized
INFO - 2016-09-30 21:38:03 --> Config Class Initialized
INFO - 2016-09-30 21:38:03 --> Loader Class Initialized
INFO - 2016-09-30 21:38:03 --> Helper loaded: url_helper
INFO - 2016-09-30 21:38:03 --> Database Driver Class Initialized
INFO - 2016-09-30 21:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-30 21:38:03 --> Controller Class Initialized
DEBUG - 2016-09-30 21:38:03 --> login MX_Controller Initialized
INFO - 2016-09-30 21:38:03 --> Model Class Initialized
INFO - 2016-09-30 21:38:03 --> Model Class Initialized
DEBUG - 2016-09-30 21:38:03 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-30 21:38:03 --> Final output sent to browser
DEBUG - 2016-09-30 21:38:03 --> Total execution time: 0.0497
INFO - 2016-09-30 22:27:14 --> Config Class Initialized
INFO - 2016-09-30 22:27:14 --> Hooks Class Initialized
DEBUG - 2016-09-30 22:27:14 --> UTF-8 Support Enabled
INFO - 2016-09-30 22:27:14 --> Utf8 Class Initialized
INFO - 2016-09-30 22:27:14 --> URI Class Initialized
INFO - 2016-09-30 22:27:14 --> Router Class Initialized
INFO - 2016-09-30 22:27:14 --> Output Class Initialized
INFO - 2016-09-30 22:27:14 --> Security Class Initialized
DEBUG - 2016-09-30 22:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-30 22:27:14 --> Input Class Initialized
INFO - 2016-09-30 22:27:14 --> Language Class Initialized
ERROR - 2016-09-30 22:27:14 --> 404 Page Not Found: /index
INFO - 2016-09-30 22:27:49 --> Config Class Initialized
INFO - 2016-09-30 22:27:49 --> Hooks Class Initialized
DEBUG - 2016-09-30 22:27:49 --> UTF-8 Support Enabled
INFO - 2016-09-30 22:27:49 --> Utf8 Class Initialized
INFO - 2016-09-30 22:27:49 --> URI Class Initialized
DEBUG - 2016-09-30 22:27:49 --> No URI present. Default controller set.
INFO - 2016-09-30 22:27:49 --> Router Class Initialized
INFO - 2016-09-30 22:27:49 --> Output Class Initialized
INFO - 2016-09-30 22:27:49 --> Security Class Initialized
DEBUG - 2016-09-30 22:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-30 22:27:49 --> Input Class Initialized
INFO - 2016-09-30 22:27:49 --> Language Class Initialized
INFO - 2016-09-30 22:27:49 --> Language Class Initialized
INFO - 2016-09-30 22:27:49 --> Config Class Initialized
INFO - 2016-09-30 22:27:49 --> Loader Class Initialized
INFO - 2016-09-30 22:27:49 --> Helper loaded: url_helper
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-30 22:27:49 --> Controller Class Initialized
DEBUG - 2016-09-30 22:27:49 --> Index MX_Controller Initialized
INFO - 2016-09-30 22:27:49 --> Model Class Initialized
INFO - 2016-09-30 22:27:49 --> Model Class Initialized
ERROR - 2016-09-30 22:27:49 --> Unable to delete cache file for 
DEBUG - 2016-09-30 22:27:49 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-30 22:27:49 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-30 22:27:49 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-30 22:27:49 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-30 22:27:49 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-30 22:27:49 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-09-30 22:27:49 --> Database Driver Class Initialized
DEBUG - 2016-09-30 22:27:49 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-30 22:27:49 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-30 22:27:49 --> Final output sent to browser
DEBUG - 2016-09-30 22:27:49 --> Total execution time: 0.3543
INFO - 2016-09-30 22:28:28 --> Config Class Initialized
INFO - 2016-09-30 22:28:28 --> Hooks Class Initialized
DEBUG - 2016-09-30 22:28:28 --> UTF-8 Support Enabled
INFO - 2016-09-30 22:28:28 --> Utf8 Class Initialized
INFO - 2016-09-30 22:28:28 --> URI Class Initialized
INFO - 2016-09-30 22:28:28 --> Router Class Initialized
INFO - 2016-09-30 22:28:28 --> Output Class Initialized
INFO - 2016-09-30 22:28:28 --> Security Class Initialized
DEBUG - 2016-09-30 22:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-30 22:28:28 --> Input Class Initialized
INFO - 2016-09-30 22:28:28 --> Language Class Initialized
INFO - 2016-09-30 22:28:28 --> Language Class Initialized
INFO - 2016-09-30 22:28:28 --> Config Class Initialized
INFO - 2016-09-30 22:28:28 --> Loader Class Initialized
INFO - 2016-09-30 22:28:28 --> Helper loaded: url_helper
INFO - 2016-09-30 22:28:28 --> Database Driver Class Initialized
INFO - 2016-09-30 22:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-30 22:28:28 --> Controller Class Initialized
DEBUG - 2016-09-30 22:28:28 --> login MX_Controller Initialized
INFO - 2016-09-30 22:28:28 --> Model Class Initialized
INFO - 2016-09-30 22:28:28 --> Model Class Initialized
DEBUG - 2016-09-30 22:28:28 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-30 22:28:28 --> Final output sent to browser
DEBUG - 2016-09-30 22:28:28 --> Total execution time: 0.0584
