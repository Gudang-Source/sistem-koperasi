<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-10-06 01:00:36 --> Config Class Initialized
INFO - 2016-10-06 01:00:36 --> Hooks Class Initialized
DEBUG - 2016-10-06 01:00:36 --> UTF-8 Support Enabled
INFO - 2016-10-06 01:00:36 --> Utf8 Class Initialized
INFO - 2016-10-06 01:00:36 --> URI Class Initialized
INFO - 2016-10-06 01:00:36 --> Router Class Initialized
INFO - 2016-10-06 01:00:36 --> Output Class Initialized
INFO - 2016-10-06 01:00:36 --> Security Class Initialized
DEBUG - 2016-10-06 01:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-06 01:00:36 --> Input Class Initialized
INFO - 2016-10-06 01:00:36 --> Language Class Initialized
INFO - 2016-10-06 01:00:37 --> Language Class Initialized
INFO - 2016-10-06 01:00:37 --> Config Class Initialized
INFO - 2016-10-06 01:00:37 --> Loader Class Initialized
INFO - 2016-10-06 01:00:37 --> Helper loaded: url_helper
INFO - 2016-10-06 01:00:37 --> Database Driver Class Initialized
INFO - 2016-10-06 01:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-06 01:00:38 --> Controller Class Initialized
DEBUG - 2016-10-06 01:00:38 --> Index MX_Controller Initialized
INFO - 2016-10-06 01:00:38 --> Model Class Initialized
INFO - 2016-10-06 01:00:38 --> Model Class Initialized
ERROR - 2016-10-06 01:00:38 --> Unable to delete cache file for admin/index/test_date
INFO - 2016-10-06 01:00:38 --> Final output sent to browser
DEBUG - 2016-10-06 01:00:38 --> Total execution time: 2.3378
INFO - 2016-10-06 01:00:38 --> Config Class Initialized
INFO - 2016-10-06 01:00:38 --> Hooks Class Initialized
DEBUG - 2016-10-06 01:00:39 --> UTF-8 Support Enabled
INFO - 2016-10-06 01:00:39 --> Utf8 Class Initialized
INFO - 2016-10-06 01:00:39 --> URI Class Initialized
INFO - 2016-10-06 01:00:39 --> Router Class Initialized
INFO - 2016-10-06 01:00:39 --> Output Class Initialized
INFO - 2016-10-06 01:00:39 --> Security Class Initialized
DEBUG - 2016-10-06 01:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-06 01:00:39 --> Input Class Initialized
INFO - 2016-10-06 01:00:39 --> Language Class Initialized
INFO - 2016-10-06 01:00:39 --> Language Class Initialized
INFO - 2016-10-06 01:00:39 --> Config Class Initialized
INFO - 2016-10-06 01:00:39 --> Loader Class Initialized
INFO - 2016-10-06 01:00:39 --> Helper loaded: url_helper
INFO - 2016-10-06 01:00:39 --> Database Driver Class Initialized
INFO - 2016-10-06 01:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-06 01:00:39 --> Controller Class Initialized
DEBUG - 2016-10-06 01:00:39 --> login MX_Controller Initialized
INFO - 2016-10-06 01:00:39 --> Model Class Initialized
INFO - 2016-10-06 01:00:39 --> Model Class Initialized
DEBUG - 2016-10-06 01:00:39 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/login.php
INFO - 2016-10-06 01:00:39 --> Final output sent to browser
DEBUG - 2016-10-06 01:00:39 --> Total execution time: 0.9494
