<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-09-26 06:44:29 --> Config Class Initialized
INFO - 2016-09-26 06:44:29 --> Hooks Class Initialized
DEBUG - 2016-09-26 06:44:29 --> UTF-8 Support Enabled
INFO - 2016-09-26 06:44:29 --> Utf8 Class Initialized
INFO - 2016-09-26 06:44:29 --> URI Class Initialized
DEBUG - 2016-09-26 06:44:29 --> No URI present. Default controller set.
INFO - 2016-09-26 06:44:29 --> Router Class Initialized
INFO - 2016-09-26 06:44:29 --> Output Class Initialized
INFO - 2016-09-26 06:44:29 --> Security Class Initialized
DEBUG - 2016-09-26 06:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 06:44:29 --> Input Class Initialized
INFO - 2016-09-26 06:44:29 --> Language Class Initialized
INFO - 2016-09-26 06:44:29 --> Language Class Initialized
INFO - 2016-09-26 06:44:29 --> Config Class Initialized
INFO - 2016-09-26 06:44:29 --> Loader Class Initialized
INFO - 2016-09-26 06:44:29 --> Helper loaded: url_helper
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 06:44:29 --> Controller Class Initialized
DEBUG - 2016-09-26 06:44:29 --> Index MX_Controller Initialized
INFO - 2016-09-26 06:44:29 --> Model Class Initialized
INFO - 2016-09-26 06:44:29 --> Model Class Initialized
ERROR - 2016-09-26 06:44:29 --> Unable to delete cache file for 
DEBUG - 2016-09-26 06:44:29 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-26 06:44:29 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-26 06:44:29 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-26 06:44:29 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-26 06:44:29 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-26 06:44:29 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
DEBUG - 2016-09-26 06:44:29 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-26 06:44:29 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-26 06:44:29 --> Final output sent to browser
DEBUG - 2016-09-26 06:44:29 --> Total execution time: 0.1262
INFO - 2016-09-26 06:44:29 --> Config Class Initialized
INFO - 2016-09-26 06:44:29 --> Hooks Class Initialized
DEBUG - 2016-09-26 06:44:29 --> UTF-8 Support Enabled
INFO - 2016-09-26 06:44:29 --> Utf8 Class Initialized
INFO - 2016-09-26 06:44:29 --> URI Class Initialized
INFO - 2016-09-26 06:44:29 --> Router Class Initialized
INFO - 2016-09-26 06:44:29 --> Output Class Initialized
INFO - 2016-09-26 06:44:29 --> Security Class Initialized
DEBUG - 2016-09-26 06:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 06:44:29 --> Input Class Initialized
INFO - 2016-09-26 06:44:29 --> Language Class Initialized
INFO - 2016-09-26 06:44:29 --> Language Class Initialized
INFO - 2016-09-26 06:44:29 --> Config Class Initialized
INFO - 2016-09-26 06:44:29 --> Loader Class Initialized
INFO - 2016-09-26 06:44:29 --> Helper loaded: url_helper
INFO - 2016-09-26 06:44:29 --> Database Driver Class Initialized
INFO - 2016-09-26 06:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 06:44:29 --> Controller Class Initialized
DEBUG - 2016-09-26 06:44:29 --> login MX_Controller Initialized
INFO - 2016-09-26 06:44:29 --> Model Class Initialized
INFO - 2016-09-26 06:44:29 --> Model Class Initialized
DEBUG - 2016-09-26 06:44:29 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-26 06:44:29 --> Final output sent to browser
DEBUG - 2016-09-26 06:44:29 --> Total execution time: 0.0235
INFO - 2016-09-26 09:21:35 --> Config Class Initialized
INFO - 2016-09-26 09:21:35 --> Hooks Class Initialized
DEBUG - 2016-09-26 09:21:35 --> UTF-8 Support Enabled
INFO - 2016-09-26 09:21:35 --> Utf8 Class Initialized
INFO - 2016-09-26 09:21:35 --> URI Class Initialized
DEBUG - 2016-09-26 09:21:35 --> No URI present. Default controller set.
INFO - 2016-09-26 09:21:35 --> Router Class Initialized
INFO - 2016-09-26 09:21:35 --> Output Class Initialized
INFO - 2016-09-26 09:21:35 --> Security Class Initialized
DEBUG - 2016-09-26 09:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 09:21:35 --> Input Class Initialized
INFO - 2016-09-26 09:21:35 --> Language Class Initialized
INFO - 2016-09-26 09:21:35 --> Language Class Initialized
INFO - 2016-09-26 09:21:35 --> Config Class Initialized
INFO - 2016-09-26 09:21:35 --> Loader Class Initialized
INFO - 2016-09-26 09:21:35 --> Helper loaded: url_helper
INFO - 2016-09-26 09:21:35 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 09:21:35 --> Controller Class Initialized
DEBUG - 2016-09-26 09:21:35 --> Index MX_Controller Initialized
INFO - 2016-09-26 09:21:35 --> Model Class Initialized
INFO - 2016-09-26 09:21:35 --> Model Class Initialized
ERROR - 2016-09-26 09:21:35 --> Unable to delete cache file for 
DEBUG - 2016-09-26 09:21:35 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-26 09:21:35 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-26 09:21:35 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-26 09:21:35 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-26 09:21:35 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-26 09:21:35 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-26 09:21:35 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:35 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:35 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:35 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:35 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:35 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:35 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:35 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:35 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:35 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:35 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:35 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:35 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:35 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:36 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:36 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:36 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:36 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:36 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:36 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:36 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:36 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:36 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:36 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:36 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:36 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:36 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:36 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:36 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:36 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:36 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:36 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:36 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:36 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:36 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:36 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:36 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:36 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:36 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:36 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:36 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:36 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:36 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:36 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:36 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:36 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:36 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:36 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:36 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:36 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:36 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:36 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:36 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:36 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:36 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:36 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:36 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:36 --> Database Driver Class Initialized
INFO - 2016-09-26 09:21:36 --> Database Driver Class Initialized
DEBUG - 2016-09-26 09:21:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-26 09:21:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-26 09:21:36 --> Final output sent to browser
DEBUG - 2016-09-26 09:21:36 --> Total execution time: 0.1099
INFO - 2016-09-26 10:43:13 --> Config Class Initialized
INFO - 2016-09-26 10:43:13 --> Hooks Class Initialized
DEBUG - 2016-09-26 10:43:13 --> UTF-8 Support Enabled
INFO - 2016-09-26 10:43:13 --> Utf8 Class Initialized
INFO - 2016-09-26 10:43:13 --> URI Class Initialized
DEBUG - 2016-09-26 10:43:13 --> No URI present. Default controller set.
INFO - 2016-09-26 10:43:13 --> Router Class Initialized
INFO - 2016-09-26 10:43:13 --> Output Class Initialized
INFO - 2016-09-26 10:43:13 --> Security Class Initialized
DEBUG - 2016-09-26 10:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 10:43:13 --> Input Class Initialized
INFO - 2016-09-26 10:43:13 --> Language Class Initialized
INFO - 2016-09-26 10:43:13 --> Language Class Initialized
INFO - 2016-09-26 10:43:13 --> Config Class Initialized
INFO - 2016-09-26 10:43:13 --> Loader Class Initialized
INFO - 2016-09-26 10:43:13 --> Helper loaded: url_helper
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 10:43:13 --> Controller Class Initialized
DEBUG - 2016-09-26 10:43:13 --> Index MX_Controller Initialized
INFO - 2016-09-26 10:43:13 --> Model Class Initialized
INFO - 2016-09-26 10:43:13 --> Model Class Initialized
ERROR - 2016-09-26 10:43:13 --> Unable to delete cache file for 
DEBUG - 2016-09-26 10:43:13 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-26 10:43:13 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-26 10:43:13 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-26 10:43:13 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-26 10:43:13 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-26 10:43:13 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:13 --> Database Driver Class Initialized
DEBUG - 2016-09-26 10:43:13 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-26 10:43:13 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-26 10:43:13 --> Final output sent to browser
DEBUG - 2016-09-26 10:43:13 --> Total execution time: 0.1142
INFO - 2016-09-26 10:43:14 --> Config Class Initialized
INFO - 2016-09-26 10:43:14 --> Hooks Class Initialized
DEBUG - 2016-09-26 10:43:14 --> UTF-8 Support Enabled
INFO - 2016-09-26 10:43:14 --> Utf8 Class Initialized
INFO - 2016-09-26 10:43:14 --> URI Class Initialized
INFO - 2016-09-26 10:43:14 --> Router Class Initialized
INFO - 2016-09-26 10:43:14 --> Output Class Initialized
INFO - 2016-09-26 10:43:14 --> Security Class Initialized
DEBUG - 2016-09-26 10:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 10:43:14 --> Input Class Initialized
INFO - 2016-09-26 10:43:14 --> Language Class Initialized
INFO - 2016-09-26 10:43:14 --> Language Class Initialized
INFO - 2016-09-26 10:43:14 --> Config Class Initialized
INFO - 2016-09-26 10:43:14 --> Loader Class Initialized
INFO - 2016-09-26 10:43:14 --> Helper loaded: url_helper
INFO - 2016-09-26 10:43:14 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 10:43:14 --> Controller Class Initialized
DEBUG - 2016-09-26 10:43:14 --> login MX_Controller Initialized
INFO - 2016-09-26 10:43:14 --> Model Class Initialized
INFO - 2016-09-26 10:43:14 --> Model Class Initialized
DEBUG - 2016-09-26 10:43:14 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-26 10:43:14 --> Final output sent to browser
DEBUG - 2016-09-26 10:43:14 --> Total execution time: 0.0236
INFO - 2016-09-26 10:43:16 --> Config Class Initialized
INFO - 2016-09-26 10:43:16 --> Hooks Class Initialized
DEBUG - 2016-09-26 10:43:16 --> UTF-8 Support Enabled
INFO - 2016-09-26 10:43:16 --> Utf8 Class Initialized
INFO - 2016-09-26 10:43:16 --> URI Class Initialized
INFO - 2016-09-26 10:43:16 --> Router Class Initialized
INFO - 2016-09-26 10:43:16 --> Output Class Initialized
INFO - 2016-09-26 10:43:16 --> Security Class Initialized
DEBUG - 2016-09-26 10:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 10:43:16 --> Input Class Initialized
INFO - 2016-09-26 10:43:16 --> Language Class Initialized
ERROR - 2016-09-26 10:43:16 --> 404 Page Not Found: /index
INFO - 2016-09-26 10:43:16 --> Config Class Initialized
INFO - 2016-09-26 10:43:16 --> Hooks Class Initialized
DEBUG - 2016-09-26 10:43:16 --> UTF-8 Support Enabled
INFO - 2016-09-26 10:43:16 --> Utf8 Class Initialized
INFO - 2016-09-26 10:43:16 --> URI Class Initialized
INFO - 2016-09-26 10:43:16 --> Router Class Initialized
INFO - 2016-09-26 10:43:16 --> Output Class Initialized
INFO - 2016-09-26 10:43:16 --> Security Class Initialized
DEBUG - 2016-09-26 10:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 10:43:16 --> Input Class Initialized
INFO - 2016-09-26 10:43:16 --> Language Class Initialized
ERROR - 2016-09-26 10:43:16 --> 404 Page Not Found: /index
INFO - 2016-09-26 10:43:18 --> Config Class Initialized
INFO - 2016-09-26 10:43:18 --> Hooks Class Initialized
DEBUG - 2016-09-26 10:43:18 --> UTF-8 Support Enabled
INFO - 2016-09-26 10:43:18 --> Utf8 Class Initialized
INFO - 2016-09-26 10:43:18 --> URI Class Initialized
INFO - 2016-09-26 10:43:18 --> Router Class Initialized
INFO - 2016-09-26 10:43:18 --> Output Class Initialized
INFO - 2016-09-26 10:43:18 --> Security Class Initialized
DEBUG - 2016-09-26 10:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 10:43:18 --> Input Class Initialized
INFO - 2016-09-26 10:43:18 --> Language Class Initialized
INFO - 2016-09-26 10:43:18 --> Language Class Initialized
INFO - 2016-09-26 10:43:18 --> Config Class Initialized
INFO - 2016-09-26 10:43:18 --> Loader Class Initialized
INFO - 2016-09-26 10:43:18 --> Helper loaded: url_helper
INFO - 2016-09-26 10:43:18 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 10:43:18 --> Controller Class Initialized
DEBUG - 2016-09-26 10:43:18 --> login MX_Controller Initialized
INFO - 2016-09-26 10:43:18 --> Model Class Initialized
INFO - 2016-09-26 10:43:18 --> Model Class Initialized
INFO - 2016-09-26 10:43:18 --> Final output sent to browser
DEBUG - 2016-09-26 10:43:18 --> Total execution time: 0.0386
INFO - 2016-09-26 10:43:23 --> Config Class Initialized
INFO - 2016-09-26 10:43:23 --> Hooks Class Initialized
DEBUG - 2016-09-26 10:43:23 --> UTF-8 Support Enabled
INFO - 2016-09-26 10:43:23 --> Utf8 Class Initialized
INFO - 2016-09-26 10:43:23 --> URI Class Initialized
INFO - 2016-09-26 10:43:23 --> Router Class Initialized
INFO - 2016-09-26 10:43:23 --> Output Class Initialized
INFO - 2016-09-26 10:43:23 --> Security Class Initialized
DEBUG - 2016-09-26 10:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 10:43:23 --> Input Class Initialized
INFO - 2016-09-26 10:43:23 --> Language Class Initialized
INFO - 2016-09-26 10:43:23 --> Language Class Initialized
INFO - 2016-09-26 10:43:23 --> Config Class Initialized
INFO - 2016-09-26 10:43:23 --> Loader Class Initialized
INFO - 2016-09-26 10:43:23 --> Helper loaded: url_helper
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 10:43:23 --> Controller Class Initialized
DEBUG - 2016-09-26 10:43:23 --> login MX_Controller Initialized
INFO - 2016-09-26 10:43:23 --> Model Class Initialized
INFO - 2016-09-26 10:43:23 --> Model Class Initialized
INFO - 2016-09-26 10:43:23 --> Final output sent to browser
DEBUG - 2016-09-26 10:43:23 --> Total execution time: 0.0292
INFO - 2016-09-26 10:43:23 --> Config Class Initialized
INFO - 2016-09-26 10:43:23 --> Hooks Class Initialized
DEBUG - 2016-09-26 10:43:23 --> UTF-8 Support Enabled
INFO - 2016-09-26 10:43:23 --> Utf8 Class Initialized
INFO - 2016-09-26 10:43:23 --> URI Class Initialized
INFO - 2016-09-26 10:43:23 --> Router Class Initialized
INFO - 2016-09-26 10:43:23 --> Output Class Initialized
INFO - 2016-09-26 10:43:23 --> Security Class Initialized
DEBUG - 2016-09-26 10:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 10:43:23 --> Input Class Initialized
INFO - 2016-09-26 10:43:23 --> Language Class Initialized
INFO - 2016-09-26 10:43:23 --> Language Class Initialized
INFO - 2016-09-26 10:43:23 --> Config Class Initialized
INFO - 2016-09-26 10:43:23 --> Loader Class Initialized
INFO - 2016-09-26 10:43:23 --> Helper loaded: url_helper
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 10:43:23 --> Controller Class Initialized
DEBUG - 2016-09-26 10:43:23 --> Index MX_Controller Initialized
INFO - 2016-09-26 10:43:23 --> Model Class Initialized
INFO - 2016-09-26 10:43:23 --> Model Class Initialized
ERROR - 2016-09-26 10:43:23 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-26 10:43:23 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-26 10:43:23 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-26 10:43:23 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-26 10:43:23 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-26 10:43:23 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-26 10:43:23 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:23 --> Database Driver Class Initialized
DEBUG - 2016-09-26 10:43:23 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-26 10:43:23 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-26 10:43:23 --> Final output sent to browser
DEBUG - 2016-09-26 10:43:23 --> Total execution time: 0.1116
INFO - 2016-09-26 10:43:28 --> Config Class Initialized
INFO - 2016-09-26 10:43:28 --> Hooks Class Initialized
DEBUG - 2016-09-26 10:43:28 --> UTF-8 Support Enabled
INFO - 2016-09-26 10:43:28 --> Utf8 Class Initialized
INFO - 2016-09-26 10:43:28 --> URI Class Initialized
INFO - 2016-09-26 10:43:28 --> Router Class Initialized
INFO - 2016-09-26 10:43:28 --> Output Class Initialized
INFO - 2016-09-26 10:43:28 --> Security Class Initialized
DEBUG - 2016-09-26 10:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 10:43:28 --> Input Class Initialized
INFO - 2016-09-26 10:43:28 --> Language Class Initialized
ERROR - 2016-09-26 10:43:28 --> 404 Page Not Found: /index
INFO - 2016-09-26 10:43:31 --> Config Class Initialized
INFO - 2016-09-26 10:43:31 --> Hooks Class Initialized
DEBUG - 2016-09-26 10:43:31 --> UTF-8 Support Enabled
INFO - 2016-09-26 10:43:31 --> Utf8 Class Initialized
INFO - 2016-09-26 10:43:31 --> URI Class Initialized
INFO - 2016-09-26 10:43:31 --> Router Class Initialized
INFO - 2016-09-26 10:43:31 --> Output Class Initialized
INFO - 2016-09-26 10:43:31 --> Security Class Initialized
DEBUG - 2016-09-26 10:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 10:43:31 --> Input Class Initialized
INFO - 2016-09-26 10:43:31 --> Language Class Initialized
INFO - 2016-09-26 10:43:31 --> Language Class Initialized
INFO - 2016-09-26 10:43:31 --> Config Class Initialized
INFO - 2016-09-26 10:43:31 --> Loader Class Initialized
INFO - 2016-09-26 10:43:31 --> Helper loaded: url_helper
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 10:43:31 --> Controller Class Initialized
DEBUG - 2016-09-26 10:43:31 --> Index MX_Controller Initialized
INFO - 2016-09-26 10:43:31 --> Model Class Initialized
INFO - 2016-09-26 10:43:31 --> Model Class Initialized
ERROR - 2016-09-26 10:43:31 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-26 10:43:31 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-26 10:43:31 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-26 10:43:31 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-26 10:43:31 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-26 10:43:31 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-26 10:43:31 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:31 --> Database Driver Class Initialized
DEBUG - 2016-09-26 10:43:31 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-26 10:43:31 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-26 10:43:31 --> Final output sent to browser
DEBUG - 2016-09-26 10:43:31 --> Total execution time: 0.0926
INFO - 2016-09-26 10:43:32 --> Config Class Initialized
INFO - 2016-09-26 10:43:32 --> Hooks Class Initialized
DEBUG - 2016-09-26 10:43:32 --> UTF-8 Support Enabled
INFO - 2016-09-26 10:43:32 --> Utf8 Class Initialized
INFO - 2016-09-26 10:43:32 --> URI Class Initialized
INFO - 2016-09-26 10:43:32 --> Router Class Initialized
INFO - 2016-09-26 10:43:32 --> Output Class Initialized
INFO - 2016-09-26 10:43:32 --> Security Class Initialized
DEBUG - 2016-09-26 10:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 10:43:32 --> Input Class Initialized
INFO - 2016-09-26 10:43:32 --> Language Class Initialized
ERROR - 2016-09-26 10:43:32 --> 404 Page Not Found: /index
INFO - 2016-09-26 10:43:32 --> Config Class Initialized
INFO - 2016-09-26 10:43:32 --> Hooks Class Initialized
DEBUG - 2016-09-26 10:43:32 --> UTF-8 Support Enabled
INFO - 2016-09-26 10:43:32 --> Utf8 Class Initialized
INFO - 2016-09-26 10:43:32 --> URI Class Initialized
INFO - 2016-09-26 10:43:32 --> Router Class Initialized
INFO - 2016-09-26 10:43:32 --> Output Class Initialized
INFO - 2016-09-26 10:43:32 --> Security Class Initialized
DEBUG - 2016-09-26 10:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 10:43:32 --> Input Class Initialized
INFO - 2016-09-26 10:43:32 --> Language Class Initialized
ERROR - 2016-09-26 10:43:32 --> 404 Page Not Found: /index
INFO - 2016-09-26 10:43:41 --> Config Class Initialized
INFO - 2016-09-26 10:43:41 --> Hooks Class Initialized
DEBUG - 2016-09-26 10:43:41 --> UTF-8 Support Enabled
INFO - 2016-09-26 10:43:41 --> Utf8 Class Initialized
INFO - 2016-09-26 10:43:41 --> URI Class Initialized
INFO - 2016-09-26 10:43:42 --> Router Class Initialized
INFO - 2016-09-26 10:43:42 --> Output Class Initialized
INFO - 2016-09-26 10:43:42 --> Security Class Initialized
DEBUG - 2016-09-26 10:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 10:43:42 --> Input Class Initialized
INFO - 2016-09-26 10:43:42 --> Language Class Initialized
INFO - 2016-09-26 10:43:42 --> Language Class Initialized
INFO - 2016-09-26 10:43:42 --> Config Class Initialized
INFO - 2016-09-26 10:43:42 --> Loader Class Initialized
INFO - 2016-09-26 10:43:42 --> Helper loaded: url_helper
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 10:43:42 --> Controller Class Initialized
DEBUG - 2016-09-26 10:43:42 --> Index MX_Controller Initialized
INFO - 2016-09-26 10:43:42 --> Model Class Initialized
INFO - 2016-09-26 10:43:42 --> Model Class Initialized
ERROR - 2016-09-26 10:43:42 --> Unable to delete cache file for admin/index/data/anggota
DEBUG - 2016-09-26 10:43:42 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-26 10:43:42 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-26 10:43:42 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-26 10:43:42 --> File already loaded: /home/koperasi/public_html/application/controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-26 10:43:42 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-26 10:43:42 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/list_anggota.php
DEBUG - 2016-09-26 10:43:42 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-26 10:43:42 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:42 --> Database Driver Class Initialized
DEBUG - 2016-09-26 10:43:42 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-26 10:43:42 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-26 10:43:42 --> Final output sent to browser
DEBUG - 2016-09-26 10:43:42 --> Total execution time: 0.0851
INFO - 2016-09-26 10:43:42 --> Config Class Initialized
INFO - 2016-09-26 10:43:42 --> Hooks Class Initialized
DEBUG - 2016-09-26 10:43:42 --> UTF-8 Support Enabled
INFO - 2016-09-26 10:43:42 --> Utf8 Class Initialized
INFO - 2016-09-26 10:43:42 --> URI Class Initialized
INFO - 2016-09-26 10:43:42 --> Router Class Initialized
INFO - 2016-09-26 10:43:42 --> Output Class Initialized
INFO - 2016-09-26 10:43:42 --> Security Class Initialized
DEBUG - 2016-09-26 10:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 10:43:42 --> Input Class Initialized
INFO - 2016-09-26 10:43:42 --> Language Class Initialized
ERROR - 2016-09-26 10:43:42 --> 404 Page Not Found: /index
INFO - 2016-09-26 10:43:55 --> Config Class Initialized
INFO - 2016-09-26 10:43:55 --> Hooks Class Initialized
DEBUG - 2016-09-26 10:43:55 --> UTF-8 Support Enabled
INFO - 2016-09-26 10:43:55 --> Utf8 Class Initialized
INFO - 2016-09-26 10:43:55 --> URI Class Initialized
INFO - 2016-09-26 10:43:55 --> Router Class Initialized
INFO - 2016-09-26 10:43:55 --> Output Class Initialized
INFO - 2016-09-26 10:43:55 --> Security Class Initialized
DEBUG - 2016-09-26 10:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 10:43:55 --> Input Class Initialized
INFO - 2016-09-26 10:43:55 --> Language Class Initialized
INFO - 2016-09-26 10:43:55 --> Language Class Initialized
INFO - 2016-09-26 10:43:55 --> Config Class Initialized
INFO - 2016-09-26 10:43:55 --> Loader Class Initialized
INFO - 2016-09-26 10:43:55 --> Helper loaded: url_helper
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 10:43:55 --> Controller Class Initialized
DEBUG - 2016-09-26 10:43:55 --> Index MX_Controller Initialized
INFO - 2016-09-26 10:43:55 --> Model Class Initialized
INFO - 2016-09-26 10:43:55 --> Model Class Initialized
ERROR - 2016-09-26 10:43:55 --> Unable to delete cache file for admin/index/data/user
DEBUG - 2016-09-26 10:43:55 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-26 10:43:55 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-26 10:43:55 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-26 10:43:55 --> File already loaded: /home/koperasi/public_html/application/controllers/../modules/user/controllers/Users.php
DEBUG - 2016-09-26 10:43:55 --> Users MX_Controller Initialized
DEBUG - 2016-09-26 10:43:55 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/list_user.php
DEBUG - 2016-09-26 10:43:55 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-26 10:43:55 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:55 --> Database Driver Class Initialized
DEBUG - 2016-09-26 10:43:55 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-26 10:43:55 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-26 10:43:55 --> Final output sent to browser
DEBUG - 2016-09-26 10:43:55 --> Total execution time: 0.0910
INFO - 2016-09-26 10:43:55 --> Config Class Initialized
INFO - 2016-09-26 10:43:55 --> Hooks Class Initialized
DEBUG - 2016-09-26 10:43:55 --> UTF-8 Support Enabled
INFO - 2016-09-26 10:43:55 --> Utf8 Class Initialized
INFO - 2016-09-26 10:43:55 --> URI Class Initialized
INFO - 2016-09-26 10:43:55 --> Router Class Initialized
INFO - 2016-09-26 10:43:55 --> Output Class Initialized
INFO - 2016-09-26 10:43:55 --> Security Class Initialized
DEBUG - 2016-09-26 10:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 10:43:55 --> Input Class Initialized
INFO - 2016-09-26 10:43:55 --> Language Class Initialized
ERROR - 2016-09-26 10:43:55 --> 404 Page Not Found: /index
INFO - 2016-09-26 10:43:57 --> Config Class Initialized
INFO - 2016-09-26 10:43:57 --> Hooks Class Initialized
DEBUG - 2016-09-26 10:43:57 --> UTF-8 Support Enabled
INFO - 2016-09-26 10:43:57 --> Utf8 Class Initialized
INFO - 2016-09-26 10:43:57 --> URI Class Initialized
INFO - 2016-09-26 10:43:57 --> Router Class Initialized
INFO - 2016-09-26 10:43:57 --> Output Class Initialized
INFO - 2016-09-26 10:43:57 --> Security Class Initialized
DEBUG - 2016-09-26 10:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 10:43:57 --> Input Class Initialized
INFO - 2016-09-26 10:43:57 --> Language Class Initialized
ERROR - 2016-09-26 10:43:57 --> 404 Page Not Found: /index
INFO - 2016-09-26 10:43:58 --> Config Class Initialized
INFO - 2016-09-26 10:43:58 --> Hooks Class Initialized
DEBUG - 2016-09-26 10:43:58 --> UTF-8 Support Enabled
INFO - 2016-09-26 10:43:58 --> Utf8 Class Initialized
INFO - 2016-09-26 10:43:58 --> URI Class Initialized
INFO - 2016-09-26 10:43:58 --> Router Class Initialized
INFO - 2016-09-26 10:43:58 --> Output Class Initialized
INFO - 2016-09-26 10:43:58 --> Security Class Initialized
DEBUG - 2016-09-26 10:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 10:43:58 --> Input Class Initialized
INFO - 2016-09-26 10:43:58 --> Language Class Initialized
INFO - 2016-09-26 10:43:58 --> Language Class Initialized
INFO - 2016-09-26 10:43:58 --> Config Class Initialized
INFO - 2016-09-26 10:43:58 --> Loader Class Initialized
INFO - 2016-09-26 10:43:58 --> Helper loaded: url_helper
INFO - 2016-09-26 10:43:59 --> Database Driver Class Initialized
INFO - 2016-09-26 10:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 10:43:59 --> Controller Class Initialized
DEBUG - 2016-09-26 10:43:59 --> Index MX_Controller Initialized
INFO - 2016-09-26 10:43:59 --> Model Class Initialized
INFO - 2016-09-26 10:43:59 --> Model Class Initialized
ERROR - 2016-09-26 10:43:59 --> Unable to delete cache file for admin/index/post_get/user/0ade7c2cf97f75d009975f4d720d1fa6c19f4897
DEBUG - 2016-09-26 10:43:59 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-26 10:43:59 --> Users MX_Controller Initialized
INFO - 2016-09-26 10:43:59 --> Final output sent to browser
DEBUG - 2016-09-26 10:43:59 --> Total execution time: 0.0283
INFO - 2016-09-26 10:44:15 --> Config Class Initialized
INFO - 2016-09-26 10:44:15 --> Hooks Class Initialized
DEBUG - 2016-09-26 10:44:15 --> UTF-8 Support Enabled
INFO - 2016-09-26 10:44:15 --> Utf8 Class Initialized
INFO - 2016-09-26 10:44:15 --> URI Class Initialized
INFO - 2016-09-26 10:44:15 --> Router Class Initialized
INFO - 2016-09-26 10:44:15 --> Output Class Initialized
INFO - 2016-09-26 10:44:15 --> Security Class Initialized
DEBUG - 2016-09-26 10:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 10:44:15 --> Input Class Initialized
INFO - 2016-09-26 10:44:15 --> Language Class Initialized
INFO - 2016-09-26 10:44:15 --> Language Class Initialized
INFO - 2016-09-26 10:44:15 --> Config Class Initialized
INFO - 2016-09-26 10:44:15 --> Loader Class Initialized
INFO - 2016-09-26 10:44:15 --> Helper loaded: url_helper
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 10:44:15 --> Controller Class Initialized
DEBUG - 2016-09-26 10:44:15 --> Index MX_Controller Initialized
INFO - 2016-09-26 10:44:15 --> Model Class Initialized
INFO - 2016-09-26 10:44:15 --> Model Class Initialized
ERROR - 2016-09-26 10:44:15 --> Unable to delete cache file for admin/index/data_peminjam
DEBUG - 2016-09-26 10:44:15 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-26 10:44:15 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-26 10:44:15 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-26 10:44:15 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/list_peminjam.php
DEBUG - 2016-09-26 10:44:15 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-26 10:44:15 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:15 --> Database Driver Class Initialized
DEBUG - 2016-09-26 10:44:15 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-26 10:44:15 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-26 10:44:15 --> Final output sent to browser
DEBUG - 2016-09-26 10:44:15 --> Total execution time: 0.0942
INFO - 2016-09-26 10:44:16 --> Config Class Initialized
INFO - 2016-09-26 10:44:16 --> Hooks Class Initialized
DEBUG - 2016-09-26 10:44:16 --> UTF-8 Support Enabled
INFO - 2016-09-26 10:44:16 --> Utf8 Class Initialized
INFO - 2016-09-26 10:44:16 --> URI Class Initialized
INFO - 2016-09-26 10:44:16 --> Router Class Initialized
INFO - 2016-09-26 10:44:16 --> Output Class Initialized
INFO - 2016-09-26 10:44:16 --> Security Class Initialized
DEBUG - 2016-09-26 10:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 10:44:16 --> Input Class Initialized
INFO - 2016-09-26 10:44:16 --> Language Class Initialized
ERROR - 2016-09-26 10:44:16 --> 404 Page Not Found: /index
INFO - 2016-09-26 10:44:18 --> Config Class Initialized
INFO - 2016-09-26 10:44:18 --> Hooks Class Initialized
DEBUG - 2016-09-26 10:44:18 --> UTF-8 Support Enabled
INFO - 2016-09-26 10:44:18 --> Utf8 Class Initialized
INFO - 2016-09-26 10:44:18 --> URI Class Initialized
INFO - 2016-09-26 10:44:18 --> Router Class Initialized
INFO - 2016-09-26 10:44:18 --> Output Class Initialized
INFO - 2016-09-26 10:44:18 --> Security Class Initialized
DEBUG - 2016-09-26 10:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 10:44:18 --> Input Class Initialized
INFO - 2016-09-26 10:44:18 --> Language Class Initialized
ERROR - 2016-09-26 10:44:18 --> 404 Page Not Found: /index
INFO - 2016-09-26 10:44:21 --> Config Class Initialized
INFO - 2016-09-26 10:44:21 --> Hooks Class Initialized
DEBUG - 2016-09-26 10:44:21 --> UTF-8 Support Enabled
INFO - 2016-09-26 10:44:21 --> Utf8 Class Initialized
INFO - 2016-09-26 10:44:21 --> URI Class Initialized
INFO - 2016-09-26 10:44:21 --> Router Class Initialized
INFO - 2016-09-26 10:44:21 --> Output Class Initialized
INFO - 2016-09-26 10:44:21 --> Security Class Initialized
DEBUG - 2016-09-26 10:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 10:44:21 --> Input Class Initialized
INFO - 2016-09-26 10:44:21 --> Language Class Initialized
INFO - 2016-09-26 10:44:21 --> Language Class Initialized
INFO - 2016-09-26 10:44:21 --> Config Class Initialized
INFO - 2016-09-26 10:44:21 --> Loader Class Initialized
INFO - 2016-09-26 10:44:21 --> Helper loaded: url_helper
INFO - 2016-09-26 10:44:21 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 10:44:21 --> Controller Class Initialized
DEBUG - 2016-09-26 10:44:21 --> Index MX_Controller Initialized
INFO - 2016-09-26 10:44:21 --> Model Class Initialized
INFO - 2016-09-26 10:44:21 --> Model Class Initialized
ERROR - 2016-09-26 10:44:21 --> Unable to delete cache file for admin/index/getDataPeminjam
DEBUG - 2016-09-26 10:44:21 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-26 10:44:21 --> Final output sent to browser
DEBUG - 2016-09-26 10:44:21 --> Total execution time: 0.0261
INFO - 2016-09-26 10:44:23 --> Config Class Initialized
INFO - 2016-09-26 10:44:23 --> Hooks Class Initialized
DEBUG - 2016-09-26 10:44:23 --> UTF-8 Support Enabled
INFO - 2016-09-26 10:44:23 --> Utf8 Class Initialized
INFO - 2016-09-26 10:44:23 --> URI Class Initialized
INFO - 2016-09-26 10:44:23 --> Router Class Initialized
INFO - 2016-09-26 10:44:23 --> Output Class Initialized
INFO - 2016-09-26 10:44:23 --> Security Class Initialized
DEBUG - 2016-09-26 10:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 10:44:23 --> Input Class Initialized
INFO - 2016-09-26 10:44:23 --> Language Class Initialized
INFO - 2016-09-26 10:44:23 --> Language Class Initialized
INFO - 2016-09-26 10:44:23 --> Config Class Initialized
INFO - 2016-09-26 10:44:23 --> Loader Class Initialized
INFO - 2016-09-26 10:44:23 --> Helper loaded: url_helper
INFO - 2016-09-26 10:44:23 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 10:44:23 --> Controller Class Initialized
DEBUG - 2016-09-26 10:44:23 --> Index MX_Controller Initialized
INFO - 2016-09-26 10:44:23 --> Model Class Initialized
INFO - 2016-09-26 10:44:23 --> Model Class Initialized
ERROR - 2016-09-26 10:44:23 --> Unable to delete cache file for admin/index/getDataPeminjam/umum
DEBUG - 2016-09-26 10:44:23 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-26 10:44:23 --> Final output sent to browser
DEBUG - 2016-09-26 10:44:23 --> Total execution time: 0.0285
INFO - 2016-09-26 10:44:24 --> Config Class Initialized
INFO - 2016-09-26 10:44:24 --> Hooks Class Initialized
DEBUG - 2016-09-26 10:44:24 --> UTF-8 Support Enabled
INFO - 2016-09-26 10:44:24 --> Utf8 Class Initialized
INFO - 2016-09-26 10:44:24 --> URI Class Initialized
INFO - 2016-09-26 10:44:24 --> Router Class Initialized
INFO - 2016-09-26 10:44:24 --> Output Class Initialized
INFO - 2016-09-26 10:44:24 --> Security Class Initialized
DEBUG - 2016-09-26 10:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 10:44:24 --> Input Class Initialized
INFO - 2016-09-26 10:44:24 --> Language Class Initialized
INFO - 2016-09-26 10:44:24 --> Language Class Initialized
INFO - 2016-09-26 10:44:24 --> Config Class Initialized
INFO - 2016-09-26 10:44:24 --> Loader Class Initialized
INFO - 2016-09-26 10:44:24 --> Helper loaded: url_helper
INFO - 2016-09-26 10:44:24 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 10:44:24 --> Controller Class Initialized
DEBUG - 2016-09-26 10:44:24 --> Index MX_Controller Initialized
INFO - 2016-09-26 10:44:24 --> Model Class Initialized
INFO - 2016-09-26 10:44:24 --> Model Class Initialized
ERROR - 2016-09-26 10:44:24 --> Unable to delete cache file for admin/index/getDataPeminjam/karyawan
DEBUG - 2016-09-26 10:44:24 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-26 10:44:24 --> Final output sent to browser
DEBUG - 2016-09-26 10:44:24 --> Total execution time: 0.0286
INFO - 2016-09-26 10:44:26 --> Config Class Initialized
INFO - 2016-09-26 10:44:26 --> Hooks Class Initialized
DEBUG - 2016-09-26 10:44:26 --> UTF-8 Support Enabled
INFO - 2016-09-26 10:44:26 --> Utf8 Class Initialized
INFO - 2016-09-26 10:44:26 --> URI Class Initialized
INFO - 2016-09-26 10:44:26 --> Router Class Initialized
INFO - 2016-09-26 10:44:26 --> Output Class Initialized
INFO - 2016-09-26 10:44:26 --> Security Class Initialized
DEBUG - 2016-09-26 10:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 10:44:26 --> Input Class Initialized
INFO - 2016-09-26 10:44:26 --> Language Class Initialized
INFO - 2016-09-26 10:44:26 --> Language Class Initialized
INFO - 2016-09-26 10:44:26 --> Config Class Initialized
INFO - 2016-09-26 10:44:26 --> Loader Class Initialized
INFO - 2016-09-26 10:44:26 --> Helper loaded: url_helper
INFO - 2016-09-26 10:44:26 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 10:44:26 --> Controller Class Initialized
DEBUG - 2016-09-26 10:44:26 --> Index MX_Controller Initialized
INFO - 2016-09-26 10:44:26 --> Model Class Initialized
INFO - 2016-09-26 10:44:26 --> Model Class Initialized
ERROR - 2016-09-26 10:44:26 --> Unable to delete cache file for admin/index/getDataPeminjam
DEBUG - 2016-09-26 10:44:26 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/subcontent/data_peminjam.php
INFO - 2016-09-26 10:44:26 --> Final output sent to browser
DEBUG - 2016-09-26 10:44:26 --> Total execution time: 0.0435
INFO - 2016-09-26 10:44:28 --> Config Class Initialized
INFO - 2016-09-26 10:44:28 --> Hooks Class Initialized
DEBUG - 2016-09-26 10:44:28 --> UTF-8 Support Enabled
INFO - 2016-09-26 10:44:28 --> Utf8 Class Initialized
INFO - 2016-09-26 10:44:28 --> URI Class Initialized
INFO - 2016-09-26 10:44:28 --> Router Class Initialized
INFO - 2016-09-26 10:44:28 --> Output Class Initialized
INFO - 2016-09-26 10:44:28 --> Security Class Initialized
DEBUG - 2016-09-26 10:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 10:44:28 --> Input Class Initialized
INFO - 2016-09-26 10:44:28 --> Language Class Initialized
INFO - 2016-09-26 10:44:28 --> Language Class Initialized
INFO - 2016-09-26 10:44:28 --> Config Class Initialized
INFO - 2016-09-26 10:44:28 --> Loader Class Initialized
INFO - 2016-09-26 10:44:28 --> Helper loaded: url_helper
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 10:44:28 --> Controller Class Initialized
DEBUG - 2016-09-26 10:44:28 --> Index MX_Controller Initialized
INFO - 2016-09-26 10:44:28 --> Model Class Initialized
INFO - 2016-09-26 10:44:28 --> Model Class Initialized
ERROR - 2016-09-26 10:44:28 --> Unable to delete cache file for admin/index/buat_pinjaman
DEBUG - 2016-09-26 10:44:28 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-26 10:44:28 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-26 10:44:28 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-26 10:44:28 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/form_get_anggota.php
DEBUG - 2016-09-26 10:44:28 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-26 10:44:28 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:28 --> Database Driver Class Initialized
DEBUG - 2016-09-26 10:44:28 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-26 10:44:28 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-26 10:44:28 --> Final output sent to browser
DEBUG - 2016-09-26 10:44:28 --> Total execution time: 0.0886
INFO - 2016-09-26 10:44:29 --> Config Class Initialized
INFO - 2016-09-26 10:44:29 --> Hooks Class Initialized
DEBUG - 2016-09-26 10:44:29 --> UTF-8 Support Enabled
INFO - 2016-09-26 10:44:29 --> Utf8 Class Initialized
INFO - 2016-09-26 10:44:29 --> URI Class Initialized
INFO - 2016-09-26 10:44:29 --> Router Class Initialized
INFO - 2016-09-26 10:44:29 --> Output Class Initialized
INFO - 2016-09-26 10:44:29 --> Security Class Initialized
DEBUG - 2016-09-26 10:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 10:44:29 --> Input Class Initialized
INFO - 2016-09-26 10:44:29 --> Language Class Initialized
ERROR - 2016-09-26 10:44:29 --> 404 Page Not Found: /index
INFO - 2016-09-26 10:44:36 --> Config Class Initialized
INFO - 2016-09-26 10:44:36 --> Hooks Class Initialized
DEBUG - 2016-09-26 10:44:36 --> UTF-8 Support Enabled
INFO - 2016-09-26 10:44:36 --> Utf8 Class Initialized
INFO - 2016-09-26 10:44:36 --> URI Class Initialized
INFO - 2016-09-26 10:44:36 --> Router Class Initialized
INFO - 2016-09-26 10:44:36 --> Output Class Initialized
INFO - 2016-09-26 10:44:36 --> Security Class Initialized
DEBUG - 2016-09-26 10:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 10:44:36 --> Input Class Initialized
INFO - 2016-09-26 10:44:36 --> Language Class Initialized
INFO - 2016-09-26 10:44:36 --> Language Class Initialized
INFO - 2016-09-26 10:44:36 --> Config Class Initialized
INFO - 2016-09-26 10:44:36 --> Loader Class Initialized
INFO - 2016-09-26 10:44:36 --> Helper loaded: url_helper
INFO - 2016-09-26 10:44:36 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 10:44:36 --> Controller Class Initialized
DEBUG - 2016-09-26 10:44:36 --> Index MX_Controller Initialized
INFO - 2016-09-26 10:44:36 --> Model Class Initialized
INFO - 2016-09-26 10:44:36 --> Model Class Initialized
ERROR - 2016-09-26 10:44:36 --> Unable to delete cache file for admin/index/getAnggota
DEBUG - 2016-09-26 10:44:36 --> Anggota MX_Controller Initialized
INFO - 2016-09-26 10:44:36 --> Final output sent to browser
DEBUG - 2016-09-26 10:44:36 --> Total execution time: 0.0308
INFO - 2016-09-26 10:44:42 --> Config Class Initialized
INFO - 2016-09-26 10:44:42 --> Hooks Class Initialized
DEBUG - 2016-09-26 10:44:42 --> UTF-8 Support Enabled
INFO - 2016-09-26 10:44:42 --> Utf8 Class Initialized
INFO - 2016-09-26 10:44:42 --> URI Class Initialized
INFO - 2016-09-26 10:44:42 --> Router Class Initialized
INFO - 2016-09-26 10:44:42 --> Output Class Initialized
INFO - 2016-09-26 10:44:42 --> Security Class Initialized
DEBUG - 2016-09-26 10:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 10:44:42 --> Input Class Initialized
INFO - 2016-09-26 10:44:42 --> Language Class Initialized
INFO - 2016-09-26 10:44:42 --> Language Class Initialized
INFO - 2016-09-26 10:44:42 --> Config Class Initialized
INFO - 2016-09-26 10:44:42 --> Loader Class Initialized
INFO - 2016-09-26 10:44:42 --> Helper loaded: url_helper
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 10:44:42 --> Controller Class Initialized
DEBUG - 2016-09-26 10:44:42 --> Index MX_Controller Initialized
INFO - 2016-09-26 10:44:42 --> Model Class Initialized
INFO - 2016-09-26 10:44:42 --> Model Class Initialized
ERROR - 2016-09-26 10:44:42 --> Unable to delete cache file for admin/index/data/anggota
DEBUG - 2016-09-26 10:44:42 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-26 10:44:42 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-26 10:44:42 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-26 10:44:42 --> File already loaded: /home/koperasi/public_html/application/controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-26 10:44:42 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-26 10:44:42 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/list_anggota.php
DEBUG - 2016-09-26 10:44:42 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-26 10:44:42 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
INFO - 2016-09-26 10:44:42 --> Database Driver Class Initialized
DEBUG - 2016-09-26 10:44:42 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-26 10:44:42 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-26 10:44:42 --> Final output sent to browser
DEBUG - 2016-09-26 10:44:42 --> Total execution time: 0.0861
INFO - 2016-09-26 10:44:43 --> Config Class Initialized
INFO - 2016-09-26 10:44:43 --> Hooks Class Initialized
DEBUG - 2016-09-26 10:44:43 --> UTF-8 Support Enabled
INFO - 2016-09-26 10:44:43 --> Utf8 Class Initialized
INFO - 2016-09-26 10:44:43 --> URI Class Initialized
INFO - 2016-09-26 10:44:43 --> Router Class Initialized
INFO - 2016-09-26 10:44:43 --> Output Class Initialized
INFO - 2016-09-26 10:44:43 --> Security Class Initialized
DEBUG - 2016-09-26 10:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 10:44:43 --> Input Class Initialized
INFO - 2016-09-26 10:44:43 --> Language Class Initialized
ERROR - 2016-09-26 10:44:43 --> 404 Page Not Found: /index
INFO - 2016-09-26 11:12:36 --> Config Class Initialized
INFO - 2016-09-26 11:12:36 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:12:36 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:12:36 --> Utf8 Class Initialized
INFO - 2016-09-26 11:12:36 --> URI Class Initialized
INFO - 2016-09-26 11:12:36 --> Router Class Initialized
INFO - 2016-09-26 11:12:36 --> Output Class Initialized
INFO - 2016-09-26 11:12:36 --> Security Class Initialized
DEBUG - 2016-09-26 11:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:12:36 --> Input Class Initialized
INFO - 2016-09-26 11:12:36 --> Language Class Initialized
INFO - 2016-09-26 11:12:36 --> Language Class Initialized
INFO - 2016-09-26 11:12:36 --> Config Class Initialized
INFO - 2016-09-26 11:12:36 --> Loader Class Initialized
INFO - 2016-09-26 11:12:36 --> Helper loaded: url_helper
INFO - 2016-09-26 11:12:36 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:12:36 --> Controller Class Initialized
DEBUG - 2016-09-26 11:12:36 --> Index MX_Controller Initialized
INFO - 2016-09-26 11:12:36 --> Model Class Initialized
INFO - 2016-09-26 11:12:36 --> Model Class Initialized
ERROR - 2016-09-26 11:12:36 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-26 11:12:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-26 11:12:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-26 11:12:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-26 11:12:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-26 11:12:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-26 11:12:36 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-26 11:12:36 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:36 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:36 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:36 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:36 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:36 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:36 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:36 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:36 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:36 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:36 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:36 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:36 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:36 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:36 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:36 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:36 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:36 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:36 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:36 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:36 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:36 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:36 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:36 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:36 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:36 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:36 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:36 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:36 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:36 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:36 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:36 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:36 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:36 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:36 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:36 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:36 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:36 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:36 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:36 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:36 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:36 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:36 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:36 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:36 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:36 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:36 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:36 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:37 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:37 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:37 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:37 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:37 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:37 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:37 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:37 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:37 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:37 --> Database Driver Class Initialized
INFO - 2016-09-26 11:12:37 --> Database Driver Class Initialized
DEBUG - 2016-09-26 11:12:37 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-26 11:12:37 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-26 11:12:37 --> Final output sent to browser
DEBUG - 2016-09-26 11:12:37 --> Total execution time: 0.1074
INFO - 2016-09-26 11:12:37 --> Config Class Initialized
INFO - 2016-09-26 11:12:37 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:12:37 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:12:37 --> Utf8 Class Initialized
INFO - 2016-09-26 11:12:37 --> URI Class Initialized
INFO - 2016-09-26 11:12:37 --> Router Class Initialized
INFO - 2016-09-26 11:12:37 --> Output Class Initialized
INFO - 2016-09-26 11:12:37 --> Security Class Initialized
DEBUG - 2016-09-26 11:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:12:37 --> Input Class Initialized
INFO - 2016-09-26 11:12:37 --> Language Class Initialized
ERROR - 2016-09-26 11:12:37 --> 404 Page Not Found: /index
INFO - 2016-09-26 11:17:57 --> Config Class Initialized
INFO - 2016-09-26 11:17:57 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:17:57 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:17:57 --> Utf8 Class Initialized
INFO - 2016-09-26 11:17:57 --> URI Class Initialized
INFO - 2016-09-26 11:17:57 --> Router Class Initialized
INFO - 2016-09-26 11:17:57 --> Output Class Initialized
INFO - 2016-09-26 11:17:57 --> Security Class Initialized
DEBUG - 2016-09-26 11:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:17:57 --> Input Class Initialized
INFO - 2016-09-26 11:17:57 --> Language Class Initialized
INFO - 2016-09-26 11:17:57 --> Language Class Initialized
INFO - 2016-09-26 11:17:57 --> Config Class Initialized
INFO - 2016-09-26 11:17:57 --> Loader Class Initialized
INFO - 2016-09-26 11:17:57 --> Helper loaded: url_helper
INFO - 2016-09-26 11:17:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:17:58 --> Controller Class Initialized
DEBUG - 2016-09-26 11:17:58 --> Index MX_Controller Initialized
INFO - 2016-09-26 11:17:58 --> Model Class Initialized
INFO - 2016-09-26 11:17:58 --> Model Class Initialized
ERROR - 2016-09-26 11:17:58 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-26 11:17:58 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-26 11:17:58 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-26 11:17:58 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-26 11:17:58 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-26 11:17:58 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-26 11:17:58 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:17:58 --> Database Driver Class Initialized
DEBUG - 2016-09-26 11:17:58 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-26 11:17:58 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-26 11:17:58 --> Final output sent to browser
DEBUG - 2016-09-26 11:17:58 --> Total execution time: 0.0979
INFO - 2016-09-26 11:17:58 --> Config Class Initialized
INFO - 2016-09-26 11:17:58 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:17:58 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:17:58 --> Utf8 Class Initialized
INFO - 2016-09-26 11:17:58 --> URI Class Initialized
INFO - 2016-09-26 11:17:58 --> Router Class Initialized
INFO - 2016-09-26 11:17:58 --> Output Class Initialized
INFO - 2016-09-26 11:17:58 --> Security Class Initialized
DEBUG - 2016-09-26 11:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:17:58 --> Input Class Initialized
INFO - 2016-09-26 11:17:58 --> Language Class Initialized
ERROR - 2016-09-26 11:17:58 --> 404 Page Not Found: /index
INFO - 2016-09-26 11:18:16 --> Config Class Initialized
INFO - 2016-09-26 11:18:16 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:18:16 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:18:16 --> Utf8 Class Initialized
INFO - 2016-09-26 11:18:16 --> URI Class Initialized
INFO - 2016-09-26 11:18:16 --> Router Class Initialized
INFO - 2016-09-26 11:18:16 --> Output Class Initialized
INFO - 2016-09-26 11:18:16 --> Security Class Initialized
DEBUG - 2016-09-26 11:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:18:16 --> Input Class Initialized
INFO - 2016-09-26 11:18:16 --> Language Class Initialized
INFO - 2016-09-26 11:18:16 --> Language Class Initialized
INFO - 2016-09-26 11:18:16 --> Config Class Initialized
INFO - 2016-09-26 11:18:16 --> Loader Class Initialized
INFO - 2016-09-26 11:18:16 --> Helper loaded: url_helper
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:18:16 --> Controller Class Initialized
DEBUG - 2016-09-26 11:18:16 --> Index MX_Controller Initialized
INFO - 2016-09-26 11:18:16 --> Model Class Initialized
INFO - 2016-09-26 11:18:16 --> Model Class Initialized
ERROR - 2016-09-26 11:18:16 --> Unable to delete cache file for admin/index/add/anggota
DEBUG - 2016-09-26 11:18:16 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-26 11:18:16 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-26 11:18:16 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-26 11:18:16 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/form_anggota.php
DEBUG - 2016-09-26 11:18:16 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-26 11:18:16 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:18:16 --> Database Driver Class Initialized
DEBUG - 2016-09-26 11:18:16 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-26 11:18:16 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-26 11:18:16 --> Final output sent to browser
DEBUG - 2016-09-26 11:18:16 --> Total execution time: 0.1210
INFO - 2016-09-26 11:18:16 --> Config Class Initialized
INFO - 2016-09-26 11:18:16 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:18:16 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:18:16 --> Utf8 Class Initialized
INFO - 2016-09-26 11:18:16 --> URI Class Initialized
INFO - 2016-09-26 11:18:16 --> Router Class Initialized
INFO - 2016-09-26 11:18:16 --> Output Class Initialized
INFO - 2016-09-26 11:18:16 --> Security Class Initialized
DEBUG - 2016-09-26 11:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:18:16 --> Input Class Initialized
INFO - 2016-09-26 11:18:16 --> Language Class Initialized
ERROR - 2016-09-26 11:18:16 --> 404 Page Not Found: /index
INFO - 2016-09-26 11:18:18 --> Config Class Initialized
INFO - 2016-09-26 11:18:18 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:18:18 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:18:18 --> Utf8 Class Initialized
INFO - 2016-09-26 11:18:18 --> URI Class Initialized
INFO - 2016-09-26 11:18:18 --> Router Class Initialized
INFO - 2016-09-26 11:18:18 --> Output Class Initialized
INFO - 2016-09-26 11:18:18 --> Security Class Initialized
DEBUG - 2016-09-26 11:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:18:19 --> Input Class Initialized
INFO - 2016-09-26 11:18:19 --> Language Class Initialized
ERROR - 2016-09-26 11:18:19 --> 404 Page Not Found: /index
INFO - 2016-09-26 11:19:40 --> Config Class Initialized
INFO - 2016-09-26 11:19:40 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:19:40 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:19:40 --> Utf8 Class Initialized
INFO - 2016-09-26 11:19:40 --> URI Class Initialized
INFO - 2016-09-26 11:19:40 --> Router Class Initialized
INFO - 2016-09-26 11:19:40 --> Output Class Initialized
INFO - 2016-09-26 11:19:40 --> Security Class Initialized
DEBUG - 2016-09-26 11:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:19:40 --> Input Class Initialized
INFO - 2016-09-26 11:19:40 --> Language Class Initialized
INFO - 2016-09-26 11:19:40 --> Language Class Initialized
INFO - 2016-09-26 11:19:40 --> Config Class Initialized
INFO - 2016-09-26 11:19:40 --> Loader Class Initialized
INFO - 2016-09-26 11:19:40 --> Helper loaded: url_helper
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:19:40 --> Controller Class Initialized
DEBUG - 2016-09-26 11:19:40 --> Index MX_Controller Initialized
INFO - 2016-09-26 11:19:40 --> Model Class Initialized
INFO - 2016-09-26 11:19:40 --> Model Class Initialized
ERROR - 2016-09-26 11:19:40 --> Unable to delete cache file for admin/index/add/anggota
DEBUG - 2016-09-26 11:19:40 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-26 11:19:40 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-26 11:19:40 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-26 11:19:40 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/form_anggota.php
DEBUG - 2016-09-26 11:19:40 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-26 11:19:40 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:40 --> Database Driver Class Initialized
DEBUG - 2016-09-26 11:19:40 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-26 11:19:40 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-26 11:19:40 --> Final output sent to browser
DEBUG - 2016-09-26 11:19:40 --> Total execution time: 0.0910
INFO - 2016-09-26 11:19:40 --> Config Class Initialized
INFO - 2016-09-26 11:19:40 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:19:40 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:19:40 --> Utf8 Class Initialized
INFO - 2016-09-26 11:19:40 --> URI Class Initialized
INFO - 2016-09-26 11:19:40 --> Router Class Initialized
INFO - 2016-09-26 11:19:40 --> Output Class Initialized
INFO - 2016-09-26 11:19:40 --> Security Class Initialized
DEBUG - 2016-09-26 11:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:19:40 --> Input Class Initialized
INFO - 2016-09-26 11:19:40 --> Language Class Initialized
ERROR - 2016-09-26 11:19:40 --> 404 Page Not Found: /index
INFO - 2016-09-26 11:19:41 --> Config Class Initialized
INFO - 2016-09-26 11:19:41 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:19:41 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:19:41 --> Utf8 Class Initialized
INFO - 2016-09-26 11:19:41 --> URI Class Initialized
INFO - 2016-09-26 11:19:41 --> Router Class Initialized
INFO - 2016-09-26 11:19:41 --> Output Class Initialized
INFO - 2016-09-26 11:19:41 --> Security Class Initialized
DEBUG - 2016-09-26 11:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:19:41 --> Input Class Initialized
INFO - 2016-09-26 11:19:41 --> Language Class Initialized
ERROR - 2016-09-26 11:19:41 --> 404 Page Not Found: /index
INFO - 2016-09-26 11:19:58 --> Config Class Initialized
INFO - 2016-09-26 11:19:58 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:19:58 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:19:58 --> Utf8 Class Initialized
INFO - 2016-09-26 11:19:58 --> URI Class Initialized
INFO - 2016-09-26 11:19:58 --> Router Class Initialized
INFO - 2016-09-26 11:19:58 --> Output Class Initialized
INFO - 2016-09-26 11:19:58 --> Security Class Initialized
DEBUG - 2016-09-26 11:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:19:58 --> Input Class Initialized
INFO - 2016-09-26 11:19:58 --> Language Class Initialized
INFO - 2016-09-26 11:19:58 --> Language Class Initialized
INFO - 2016-09-26 11:19:58 --> Config Class Initialized
INFO - 2016-09-26 11:19:58 --> Loader Class Initialized
INFO - 2016-09-26 11:19:58 --> Helper loaded: url_helper
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:19:58 --> Controller Class Initialized
DEBUG - 2016-09-26 11:19:58 --> Index MX_Controller Initialized
INFO - 2016-09-26 11:19:58 --> Model Class Initialized
INFO - 2016-09-26 11:19:58 --> Model Class Initialized
ERROR - 2016-09-26 11:19:58 --> Unable to delete cache file for admin/index/data_biaya
DEBUG - 2016-09-26 11:19:58 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-26 11:19:58 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-26 11:19:58 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-26 11:19:58 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/list_biaya.php
DEBUG - 2016-09-26 11:19:58 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-26 11:19:58 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
INFO - 2016-09-26 11:19:58 --> Database Driver Class Initialized
DEBUG - 2016-09-26 11:19:58 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-26 11:19:58 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-26 11:19:58 --> Final output sent to browser
DEBUG - 2016-09-26 11:19:58 --> Total execution time: 0.1196
INFO - 2016-09-26 11:19:59 --> Config Class Initialized
INFO - 2016-09-26 11:19:59 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:19:59 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:19:59 --> Utf8 Class Initialized
INFO - 2016-09-26 11:19:59 --> URI Class Initialized
INFO - 2016-09-26 11:19:59 --> Router Class Initialized
INFO - 2016-09-26 11:19:59 --> Output Class Initialized
INFO - 2016-09-26 11:19:59 --> Security Class Initialized
DEBUG - 2016-09-26 11:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:19:59 --> Input Class Initialized
INFO - 2016-09-26 11:19:59 --> Language Class Initialized
ERROR - 2016-09-26 11:19:59 --> 404 Page Not Found: /index
INFO - 2016-09-26 11:20:03 --> Config Class Initialized
INFO - 2016-09-26 11:20:03 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:20:03 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:20:03 --> Utf8 Class Initialized
INFO - 2016-09-26 11:20:03 --> URI Class Initialized
INFO - 2016-09-26 11:20:03 --> Router Class Initialized
INFO - 2016-09-26 11:20:03 --> Output Class Initialized
INFO - 2016-09-26 11:20:03 --> Security Class Initialized
DEBUG - 2016-09-26 11:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:20:03 --> Input Class Initialized
INFO - 2016-09-26 11:20:03 --> Language Class Initialized
ERROR - 2016-09-26 11:20:03 --> 404 Page Not Found: /index
INFO - 2016-09-26 11:22:20 --> Config Class Initialized
INFO - 2016-09-26 11:22:20 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:22:20 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:22:20 --> Utf8 Class Initialized
INFO - 2016-09-26 11:22:20 --> URI Class Initialized
INFO - 2016-09-26 11:22:20 --> Router Class Initialized
INFO - 2016-09-26 11:22:20 --> Output Class Initialized
INFO - 2016-09-26 11:22:20 --> Security Class Initialized
DEBUG - 2016-09-26 11:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:22:20 --> Input Class Initialized
INFO - 2016-09-26 11:22:20 --> Language Class Initialized
INFO - 2016-09-26 11:22:20 --> Language Class Initialized
INFO - 2016-09-26 11:22:20 --> Config Class Initialized
INFO - 2016-09-26 11:22:20 --> Loader Class Initialized
INFO - 2016-09-26 11:22:20 --> Helper loaded: url_helper
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:22:20 --> Controller Class Initialized
DEBUG - 2016-09-26 11:22:20 --> Index MX_Controller Initialized
INFO - 2016-09-26 11:22:20 --> Model Class Initialized
INFO - 2016-09-26 11:22:20 --> Model Class Initialized
ERROR - 2016-09-26 11:22:20 --> Unable to delete cache file for admin/index/data_biaya
DEBUG - 2016-09-26 11:22:20 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-26 11:22:20 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-26 11:22:20 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-26 11:22:20 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/list_biaya.php
DEBUG - 2016-09-26 11:22:20 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-26 11:22:20 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:22:20 --> Database Driver Class Initialized
DEBUG - 2016-09-26 11:22:20 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-26 11:22:20 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-26 11:22:20 --> Final output sent to browser
DEBUG - 2016-09-26 11:22:20 --> Total execution time: 0.1100
INFO - 2016-09-26 11:22:20 --> Config Class Initialized
INFO - 2016-09-26 11:22:20 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:22:20 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:22:20 --> Utf8 Class Initialized
INFO - 2016-09-26 11:22:20 --> URI Class Initialized
INFO - 2016-09-26 11:22:20 --> Router Class Initialized
INFO - 2016-09-26 11:22:20 --> Output Class Initialized
INFO - 2016-09-26 11:22:20 --> Security Class Initialized
DEBUG - 2016-09-26 11:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:22:20 --> Input Class Initialized
INFO - 2016-09-26 11:22:20 --> Language Class Initialized
ERROR - 2016-09-26 11:22:20 --> 404 Page Not Found: /index
INFO - 2016-09-26 11:22:21 --> Config Class Initialized
INFO - 2016-09-26 11:22:21 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:22:21 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:22:21 --> Utf8 Class Initialized
INFO - 2016-09-26 11:22:21 --> URI Class Initialized
INFO - 2016-09-26 11:22:21 --> Router Class Initialized
INFO - 2016-09-26 11:22:21 --> Output Class Initialized
INFO - 2016-09-26 11:22:21 --> Security Class Initialized
DEBUG - 2016-09-26 11:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:22:21 --> Input Class Initialized
INFO - 2016-09-26 11:22:21 --> Language Class Initialized
ERROR - 2016-09-26 11:22:21 --> 404 Page Not Found: /index
INFO - 2016-09-26 11:24:52 --> Config Class Initialized
INFO - 2016-09-26 11:24:52 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:24:52 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:24:52 --> Utf8 Class Initialized
INFO - 2016-09-26 11:24:52 --> URI Class Initialized
INFO - 2016-09-26 11:24:52 --> Router Class Initialized
INFO - 2016-09-26 11:24:52 --> Output Class Initialized
INFO - 2016-09-26 11:24:52 --> Security Class Initialized
DEBUG - 2016-09-26 11:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:24:52 --> Input Class Initialized
INFO - 2016-09-26 11:24:52 --> Language Class Initialized
INFO - 2016-09-26 11:24:52 --> Language Class Initialized
INFO - 2016-09-26 11:24:52 --> Config Class Initialized
INFO - 2016-09-26 11:24:52 --> Loader Class Initialized
INFO - 2016-09-26 11:24:52 --> Helper loaded: url_helper
INFO - 2016-09-26 11:24:52 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:24:52 --> Controller Class Initialized
DEBUG - 2016-09-26 11:24:52 --> Index MX_Controller Initialized
INFO - 2016-09-26 11:24:52 --> Model Class Initialized
INFO - 2016-09-26 11:24:52 --> Model Class Initialized
ERROR - 2016-09-26 11:24:52 --> Unable to delete cache file for admin/index/data_biaya
DEBUG - 2016-09-26 11:24:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-26 11:24:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-26 11:24:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-26 11:24:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/list_biaya.php
DEBUG - 2016-09-26 11:24:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-26 11:24:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-26 11:24:52 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:52 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:52 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:52 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:52 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:52 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:52 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:52 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 11:24:53 --> Database Driver Class Initialized
DEBUG - 2016-09-26 11:24:53 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-26 11:24:53 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-26 11:24:53 --> Final output sent to browser
DEBUG - 2016-09-26 11:24:53 --> Total execution time: 0.1722
INFO - 2016-09-26 11:24:53 --> Config Class Initialized
INFO - 2016-09-26 11:24:53 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:24:53 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:24:53 --> Utf8 Class Initialized
INFO - 2016-09-26 11:24:53 --> URI Class Initialized
INFO - 2016-09-26 11:24:53 --> Router Class Initialized
INFO - 2016-09-26 11:24:53 --> Output Class Initialized
INFO - 2016-09-26 11:24:53 --> Security Class Initialized
DEBUG - 2016-09-26 11:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:24:53 --> Input Class Initialized
INFO - 2016-09-26 11:24:53 --> Language Class Initialized
ERROR - 2016-09-26 11:24:53 --> 404 Page Not Found: /index
INFO - 2016-09-26 11:24:54 --> Config Class Initialized
INFO - 2016-09-26 11:24:54 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:24:54 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:24:54 --> Utf8 Class Initialized
INFO - 2016-09-26 11:24:54 --> URI Class Initialized
INFO - 2016-09-26 11:24:54 --> Router Class Initialized
INFO - 2016-09-26 11:24:54 --> Output Class Initialized
INFO - 2016-09-26 11:24:54 --> Security Class Initialized
DEBUG - 2016-09-26 11:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:24:54 --> Input Class Initialized
INFO - 2016-09-26 11:24:54 --> Language Class Initialized
ERROR - 2016-09-26 11:24:54 --> 404 Page Not Found: /index
INFO - 2016-09-26 11:29:09 --> Config Class Initialized
INFO - 2016-09-26 11:29:09 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:29:09 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:29:09 --> Utf8 Class Initialized
INFO - 2016-09-26 11:29:09 --> URI Class Initialized
INFO - 2016-09-26 11:29:09 --> Router Class Initialized
INFO - 2016-09-26 11:29:09 --> Output Class Initialized
INFO - 2016-09-26 11:29:09 --> Security Class Initialized
DEBUG - 2016-09-26 11:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:29:09 --> Input Class Initialized
INFO - 2016-09-26 11:29:09 --> Language Class Initialized
INFO - 2016-09-26 11:29:09 --> Language Class Initialized
INFO - 2016-09-26 11:29:09 --> Config Class Initialized
INFO - 2016-09-26 11:29:09 --> Loader Class Initialized
INFO - 2016-09-26 11:29:09 --> Helper loaded: url_helper
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:29:09 --> Controller Class Initialized
DEBUG - 2016-09-26 11:29:09 --> Index MX_Controller Initialized
INFO - 2016-09-26 11:29:09 --> Model Class Initialized
INFO - 2016-09-26 11:29:09 --> Model Class Initialized
ERROR - 2016-09-26 11:29:09 --> Unable to delete cache file for admin/index/data_biaya
DEBUG - 2016-09-26 11:29:09 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-26 11:29:09 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-26 11:29:09 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-26 11:29:09 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/list_biaya.php
DEBUG - 2016-09-26 11:29:09 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-26 11:29:09 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:29:09 --> Database Driver Class Initialized
DEBUG - 2016-09-26 11:29:09 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-26 11:29:09 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-26 11:29:09 --> Final output sent to browser
DEBUG - 2016-09-26 11:29:09 --> Total execution time: 0.1153
INFO - 2016-09-26 11:29:10 --> Config Class Initialized
INFO - 2016-09-26 11:29:10 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:29:10 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:29:10 --> Utf8 Class Initialized
INFO - 2016-09-26 11:29:10 --> URI Class Initialized
INFO - 2016-09-26 11:29:10 --> Router Class Initialized
INFO - 2016-09-26 11:29:10 --> Output Class Initialized
INFO - 2016-09-26 11:29:10 --> Security Class Initialized
DEBUG - 2016-09-26 11:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:29:10 --> Input Class Initialized
INFO - 2016-09-26 11:29:10 --> Language Class Initialized
ERROR - 2016-09-26 11:29:10 --> 404 Page Not Found: /index
INFO - 2016-09-26 11:30:16 --> Config Class Initialized
INFO - 2016-09-26 11:30:16 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:30:16 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:30:16 --> Utf8 Class Initialized
INFO - 2016-09-26 11:30:16 --> URI Class Initialized
INFO - 2016-09-26 11:30:16 --> Router Class Initialized
INFO - 2016-09-26 11:30:16 --> Output Class Initialized
INFO - 2016-09-26 11:30:16 --> Security Class Initialized
DEBUG - 2016-09-26 11:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:30:16 --> Input Class Initialized
INFO - 2016-09-26 11:30:16 --> Language Class Initialized
INFO - 2016-09-26 11:30:16 --> Language Class Initialized
INFO - 2016-09-26 11:30:16 --> Config Class Initialized
INFO - 2016-09-26 11:30:16 --> Loader Class Initialized
INFO - 2016-09-26 11:30:16 --> Helper loaded: url_helper
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:30:16 --> Controller Class Initialized
DEBUG - 2016-09-26 11:30:16 --> Index MX_Controller Initialized
INFO - 2016-09-26 11:30:16 --> Model Class Initialized
INFO - 2016-09-26 11:30:16 --> Model Class Initialized
ERROR - 2016-09-26 11:30:16 --> Unable to delete cache file for admin/index/data_biaya
DEBUG - 2016-09-26 11:30:16 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-26 11:30:16 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-26 11:30:16 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-26 11:30:16 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/list_biaya.php
DEBUG - 2016-09-26 11:30:16 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-26 11:30:16 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:16 --> Database Driver Class Initialized
DEBUG - 2016-09-26 11:30:16 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-26 11:30:16 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-26 11:30:16 --> Final output sent to browser
DEBUG - 2016-09-26 11:30:16 --> Total execution time: 0.1451
INFO - 2016-09-26 11:30:16 --> Config Class Initialized
INFO - 2016-09-26 11:30:16 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:30:16 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:30:16 --> Utf8 Class Initialized
INFO - 2016-09-26 11:30:16 --> URI Class Initialized
INFO - 2016-09-26 11:30:16 --> Router Class Initialized
INFO - 2016-09-26 11:30:16 --> Output Class Initialized
INFO - 2016-09-26 11:30:16 --> Security Class Initialized
DEBUG - 2016-09-26 11:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:30:16 --> Input Class Initialized
INFO - 2016-09-26 11:30:16 --> Language Class Initialized
ERROR - 2016-09-26 11:30:16 --> 404 Page Not Found: /index
INFO - 2016-09-26 11:30:17 --> Config Class Initialized
INFO - 2016-09-26 11:30:17 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:30:17 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:30:17 --> Utf8 Class Initialized
INFO - 2016-09-26 11:30:17 --> URI Class Initialized
INFO - 2016-09-26 11:30:17 --> Router Class Initialized
INFO - 2016-09-26 11:30:17 --> Output Class Initialized
INFO - 2016-09-26 11:30:17 --> Security Class Initialized
DEBUG - 2016-09-26 11:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:30:17 --> Input Class Initialized
INFO - 2016-09-26 11:30:17 --> Language Class Initialized
ERROR - 2016-09-26 11:30:17 --> 404 Page Not Found: /index
INFO - 2016-09-26 11:30:56 --> Config Class Initialized
INFO - 2016-09-26 11:30:56 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:30:56 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:30:56 --> Utf8 Class Initialized
INFO - 2016-09-26 11:30:56 --> URI Class Initialized
INFO - 2016-09-26 11:30:56 --> Router Class Initialized
INFO - 2016-09-26 11:30:56 --> Output Class Initialized
INFO - 2016-09-26 11:30:56 --> Security Class Initialized
DEBUG - 2016-09-26 11:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:30:56 --> Input Class Initialized
INFO - 2016-09-26 11:30:56 --> Language Class Initialized
INFO - 2016-09-26 11:30:57 --> Language Class Initialized
INFO - 2016-09-26 11:30:57 --> Config Class Initialized
INFO - 2016-09-26 11:30:57 --> Loader Class Initialized
INFO - 2016-09-26 11:30:57 --> Helper loaded: url_helper
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:30:57 --> Controller Class Initialized
DEBUG - 2016-09-26 11:30:57 --> Index MX_Controller Initialized
INFO - 2016-09-26 11:30:57 --> Model Class Initialized
INFO - 2016-09-26 11:30:57 --> Model Class Initialized
ERROR - 2016-09-26 11:30:57 --> Unable to delete cache file for admin/index/data_biaya
DEBUG - 2016-09-26 11:30:57 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-26 11:30:57 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-26 11:30:57 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-26 11:30:57 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/list_biaya.php
DEBUG - 2016-09-26 11:30:57 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-26 11:30:57 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
INFO - 2016-09-26 11:30:57 --> Database Driver Class Initialized
DEBUG - 2016-09-26 11:30:57 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-26 11:30:57 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-26 11:30:57 --> Final output sent to browser
DEBUG - 2016-09-26 11:30:57 --> Total execution time: 0.1254
INFO - 2016-09-26 11:30:57 --> Config Class Initialized
INFO - 2016-09-26 11:30:57 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:30:57 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:30:57 --> Utf8 Class Initialized
INFO - 2016-09-26 11:30:57 --> URI Class Initialized
INFO - 2016-09-26 11:30:57 --> Router Class Initialized
INFO - 2016-09-26 11:30:57 --> Output Class Initialized
INFO - 2016-09-26 11:30:57 --> Security Class Initialized
DEBUG - 2016-09-26 11:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:30:57 --> Input Class Initialized
INFO - 2016-09-26 11:30:57 --> Language Class Initialized
ERROR - 2016-09-26 11:30:57 --> 404 Page Not Found: /index
INFO - 2016-09-26 11:30:58 --> Config Class Initialized
INFO - 2016-09-26 11:30:58 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:30:58 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:30:58 --> Utf8 Class Initialized
INFO - 2016-09-26 11:30:58 --> URI Class Initialized
INFO - 2016-09-26 11:30:58 --> Router Class Initialized
INFO - 2016-09-26 11:30:58 --> Output Class Initialized
INFO - 2016-09-26 11:30:58 --> Security Class Initialized
DEBUG - 2016-09-26 11:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:30:58 --> Input Class Initialized
INFO - 2016-09-26 11:30:58 --> Language Class Initialized
ERROR - 2016-09-26 11:30:58 --> 404 Page Not Found: /index
INFO - 2016-09-26 11:31:31 --> Config Class Initialized
INFO - 2016-09-26 11:31:31 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:31:31 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:31:31 --> Utf8 Class Initialized
INFO - 2016-09-26 11:31:31 --> URI Class Initialized
INFO - 2016-09-26 11:31:31 --> Router Class Initialized
INFO - 2016-09-26 11:31:31 --> Output Class Initialized
INFO - 2016-09-26 11:31:31 --> Security Class Initialized
DEBUG - 2016-09-26 11:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:31:31 --> Input Class Initialized
INFO - 2016-09-26 11:31:31 --> Language Class Initialized
INFO - 2016-09-26 11:31:31 --> Language Class Initialized
INFO - 2016-09-26 11:31:31 --> Config Class Initialized
INFO - 2016-09-26 11:31:31 --> Loader Class Initialized
INFO - 2016-09-26 11:31:31 --> Helper loaded: url_helper
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:31:31 --> Controller Class Initialized
DEBUG - 2016-09-26 11:31:31 --> Index MX_Controller Initialized
INFO - 2016-09-26 11:31:31 --> Model Class Initialized
INFO - 2016-09-26 11:31:31 --> Model Class Initialized
ERROR - 2016-09-26 11:31:31 --> Unable to delete cache file for admin/index/data_biaya
DEBUG - 2016-09-26 11:31:31 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-26 11:31:31 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-26 11:31:31 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-26 11:31:31 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/list_biaya.php
DEBUG - 2016-09-26 11:31:31 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-26 11:31:31 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:31:31 --> Database Driver Class Initialized
DEBUG - 2016-09-26 11:31:31 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-26 11:31:31 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-26 11:31:31 --> Final output sent to browser
DEBUG - 2016-09-26 11:31:31 --> Total execution time: 0.1825
INFO - 2016-09-26 11:31:31 --> Config Class Initialized
INFO - 2016-09-26 11:31:31 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:31:31 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:31:31 --> Utf8 Class Initialized
INFO - 2016-09-26 11:31:31 --> URI Class Initialized
INFO - 2016-09-26 11:31:31 --> Router Class Initialized
INFO - 2016-09-26 11:31:31 --> Output Class Initialized
INFO - 2016-09-26 11:31:31 --> Security Class Initialized
DEBUG - 2016-09-26 11:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:31:31 --> Input Class Initialized
INFO - 2016-09-26 11:31:31 --> Language Class Initialized
ERROR - 2016-09-26 11:31:31 --> 404 Page Not Found: /index
INFO - 2016-09-26 11:31:32 --> Config Class Initialized
INFO - 2016-09-26 11:31:32 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:31:32 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:31:32 --> Utf8 Class Initialized
INFO - 2016-09-26 11:31:32 --> URI Class Initialized
INFO - 2016-09-26 11:31:32 --> Router Class Initialized
INFO - 2016-09-26 11:31:32 --> Output Class Initialized
INFO - 2016-09-26 11:31:32 --> Security Class Initialized
DEBUG - 2016-09-26 11:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:31:32 --> Input Class Initialized
INFO - 2016-09-26 11:31:32 --> Language Class Initialized
ERROR - 2016-09-26 11:31:32 --> 404 Page Not Found: /index
INFO - 2016-09-26 11:32:09 --> Config Class Initialized
INFO - 2016-09-26 11:32:09 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:32:09 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:32:09 --> Utf8 Class Initialized
INFO - 2016-09-26 11:32:09 --> URI Class Initialized
INFO - 2016-09-26 11:32:09 --> Router Class Initialized
INFO - 2016-09-26 11:32:09 --> Output Class Initialized
INFO - 2016-09-26 11:32:09 --> Security Class Initialized
DEBUG - 2016-09-26 11:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:32:09 --> Input Class Initialized
INFO - 2016-09-26 11:32:09 --> Language Class Initialized
INFO - 2016-09-26 11:32:09 --> Language Class Initialized
INFO - 2016-09-26 11:32:09 --> Config Class Initialized
INFO - 2016-09-26 11:32:09 --> Loader Class Initialized
INFO - 2016-09-26 11:32:09 --> Helper loaded: url_helper
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:32:09 --> Controller Class Initialized
DEBUG - 2016-09-26 11:32:09 --> Index MX_Controller Initialized
INFO - 2016-09-26 11:32:09 --> Model Class Initialized
INFO - 2016-09-26 11:32:09 --> Model Class Initialized
ERROR - 2016-09-26 11:32:09 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-26 11:32:09 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-26 11:32:09 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-26 11:32:09 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-26 11:32:09 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-26 11:32:09 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-26 11:32:09 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:09 --> Database Driver Class Initialized
DEBUG - 2016-09-26 11:32:09 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-26 11:32:09 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-26 11:32:09 --> Final output sent to browser
DEBUG - 2016-09-26 11:32:09 --> Total execution time: 0.1517
INFO - 2016-09-26 11:32:10 --> Config Class Initialized
INFO - 2016-09-26 11:32:10 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:32:10 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:32:10 --> Utf8 Class Initialized
INFO - 2016-09-26 11:32:10 --> URI Class Initialized
INFO - 2016-09-26 11:32:10 --> Router Class Initialized
INFO - 2016-09-26 11:32:10 --> Output Class Initialized
INFO - 2016-09-26 11:32:10 --> Security Class Initialized
DEBUG - 2016-09-26 11:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:32:10 --> Input Class Initialized
INFO - 2016-09-26 11:32:10 --> Language Class Initialized
ERROR - 2016-09-26 11:32:10 --> 404 Page Not Found: /index
INFO - 2016-09-26 11:32:31 --> Config Class Initialized
INFO - 2016-09-26 11:32:31 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:32:31 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:32:31 --> Utf8 Class Initialized
INFO - 2016-09-26 11:32:31 --> URI Class Initialized
INFO - 2016-09-26 11:32:31 --> Router Class Initialized
INFO - 2016-09-26 11:32:31 --> Output Class Initialized
INFO - 2016-09-26 11:32:31 --> Security Class Initialized
DEBUG - 2016-09-26 11:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:32:31 --> Input Class Initialized
INFO - 2016-09-26 11:32:31 --> Language Class Initialized
INFO - 2016-09-26 11:32:31 --> Language Class Initialized
INFO - 2016-09-26 11:32:31 --> Config Class Initialized
INFO - 2016-09-26 11:32:31 --> Loader Class Initialized
INFO - 2016-09-26 11:32:31 --> Helper loaded: url_helper
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:32:31 --> Controller Class Initialized
DEBUG - 2016-09-26 11:32:31 --> Index MX_Controller Initialized
INFO - 2016-09-26 11:32:31 --> Model Class Initialized
INFO - 2016-09-26 11:32:31 --> Model Class Initialized
ERROR - 2016-09-26 11:32:31 --> Unable to delete cache file for admin/index/upload_foto
DEBUG - 2016-09-26 11:32:31 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-26 11:32:31 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-26 11:32:31 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-26 11:32:31 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/upload_foto.php
DEBUG - 2016-09-26 11:32:31 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-26 11:32:31 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:32:31 --> Database Driver Class Initialized
DEBUG - 2016-09-26 11:32:31 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-26 11:32:31 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-26 11:32:31 --> Final output sent to browser
DEBUG - 2016-09-26 11:32:31 --> Total execution time: 0.1599
INFO - 2016-09-26 11:32:31 --> Config Class Initialized
INFO - 2016-09-26 11:32:31 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:32:31 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:32:31 --> Utf8 Class Initialized
INFO - 2016-09-26 11:32:31 --> URI Class Initialized
INFO - 2016-09-26 11:32:31 --> Router Class Initialized
INFO - 2016-09-26 11:32:31 --> Output Class Initialized
INFO - 2016-09-26 11:32:31 --> Security Class Initialized
DEBUG - 2016-09-26 11:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:32:31 --> Input Class Initialized
INFO - 2016-09-26 11:32:31 --> Language Class Initialized
ERROR - 2016-09-26 11:32:31 --> 404 Page Not Found: /index
INFO - 2016-09-26 11:32:32 --> Config Class Initialized
INFO - 2016-09-26 11:32:32 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:32:32 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:32:32 --> Utf8 Class Initialized
INFO - 2016-09-26 11:32:32 --> URI Class Initialized
INFO - 2016-09-26 11:32:32 --> Router Class Initialized
INFO - 2016-09-26 11:32:32 --> Output Class Initialized
INFO - 2016-09-26 11:32:32 --> Security Class Initialized
DEBUG - 2016-09-26 11:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:32:32 --> Input Class Initialized
INFO - 2016-09-26 11:32:32 --> Language Class Initialized
ERROR - 2016-09-26 11:32:32 --> 404 Page Not Found: /index
INFO - 2016-09-26 11:33:12 --> Config Class Initialized
INFO - 2016-09-26 11:33:12 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:33:12 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:33:12 --> Utf8 Class Initialized
INFO - 2016-09-26 11:33:12 --> URI Class Initialized
INFO - 2016-09-26 11:33:12 --> Router Class Initialized
INFO - 2016-09-26 11:33:12 --> Output Class Initialized
INFO - 2016-09-26 11:33:12 --> Security Class Initialized
DEBUG - 2016-09-26 11:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:33:12 --> Input Class Initialized
INFO - 2016-09-26 11:33:12 --> Language Class Initialized
INFO - 2016-09-26 11:33:12 --> Language Class Initialized
INFO - 2016-09-26 11:33:12 --> Config Class Initialized
INFO - 2016-09-26 11:33:12 --> Loader Class Initialized
INFO - 2016-09-26 11:33:12 --> Helper loaded: url_helper
INFO - 2016-09-26 11:33:12 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:33:12 --> Controller Class Initialized
DEBUG - 2016-09-26 11:33:12 --> Index MX_Controller Initialized
INFO - 2016-09-26 11:33:12 --> Model Class Initialized
INFO - 2016-09-26 11:33:12 --> Model Class Initialized
ERROR - 2016-09-26 11:33:12 --> Unable to delete cache file for admin/index/do_upload_foto
INFO - 2016-09-26 11:33:12 --> Upload Class Initialized
INFO - 2016-09-26 11:33:16 --> Final output sent to browser
DEBUG - 2016-09-26 11:33:16 --> Total execution time: 3.7633
INFO - 2016-09-26 11:33:25 --> Config Class Initialized
INFO - 2016-09-26 11:33:25 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:33:25 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:33:25 --> Utf8 Class Initialized
INFO - 2016-09-26 11:33:25 --> URI Class Initialized
INFO - 2016-09-26 11:33:25 --> Router Class Initialized
INFO - 2016-09-26 11:33:25 --> Output Class Initialized
INFO - 2016-09-26 11:33:25 --> Security Class Initialized
DEBUG - 2016-09-26 11:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:33:25 --> Input Class Initialized
INFO - 2016-09-26 11:33:25 --> Language Class Initialized
INFO - 2016-09-26 11:33:25 --> Language Class Initialized
INFO - 2016-09-26 11:33:25 --> Config Class Initialized
INFO - 2016-09-26 11:33:25 --> Loader Class Initialized
INFO - 2016-09-26 11:33:25 --> Helper loaded: url_helper
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:33:25 --> Controller Class Initialized
DEBUG - 2016-09-26 11:33:25 --> Index MX_Controller Initialized
INFO - 2016-09-26 11:33:25 --> Model Class Initialized
INFO - 2016-09-26 11:33:25 --> Model Class Initialized
ERROR - 2016-09-26 11:33:25 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-26 11:33:25 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-26 11:33:25 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-26 11:33:25 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-26 11:33:25 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-26 11:33:25 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-26 11:33:25 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:25 --> Database Driver Class Initialized
DEBUG - 2016-09-26 11:33:25 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-26 11:33:25 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-26 11:33:25 --> Final output sent to browser
DEBUG - 2016-09-26 11:33:25 --> Total execution time: 0.1391
INFO - 2016-09-26 11:33:26 --> Config Class Initialized
INFO - 2016-09-26 11:33:26 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:33:26 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:33:26 --> Utf8 Class Initialized
INFO - 2016-09-26 11:33:26 --> URI Class Initialized
INFO - 2016-09-26 11:33:26 --> Router Class Initialized
INFO - 2016-09-26 11:33:26 --> Output Class Initialized
INFO - 2016-09-26 11:33:26 --> Security Class Initialized
DEBUG - 2016-09-26 11:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:33:26 --> Input Class Initialized
INFO - 2016-09-26 11:33:26 --> Language Class Initialized
ERROR - 2016-09-26 11:33:26 --> 404 Page Not Found: /index
INFO - 2016-09-26 11:33:27 --> Config Class Initialized
INFO - 2016-09-26 11:33:27 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:33:27 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:33:27 --> Utf8 Class Initialized
INFO - 2016-09-26 11:33:27 --> URI Class Initialized
INFO - 2016-09-26 11:33:27 --> Router Class Initialized
INFO - 2016-09-26 11:33:27 --> Output Class Initialized
INFO - 2016-09-26 11:33:27 --> Security Class Initialized
DEBUG - 2016-09-26 11:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:33:27 --> Input Class Initialized
INFO - 2016-09-26 11:33:27 --> Language Class Initialized
ERROR - 2016-09-26 11:33:27 --> 404 Page Not Found: /index
INFO - 2016-09-26 11:33:34 --> Config Class Initialized
INFO - 2016-09-26 11:33:34 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:33:34 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:33:34 --> Utf8 Class Initialized
INFO - 2016-09-26 11:33:34 --> URI Class Initialized
INFO - 2016-09-26 11:33:34 --> Router Class Initialized
INFO - 2016-09-26 11:33:34 --> Output Class Initialized
INFO - 2016-09-26 11:33:34 --> Security Class Initialized
DEBUG - 2016-09-26 11:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:33:34 --> Input Class Initialized
INFO - 2016-09-26 11:33:34 --> Language Class Initialized
INFO - 2016-09-26 11:33:34 --> Language Class Initialized
INFO - 2016-09-26 11:33:34 --> Config Class Initialized
INFO - 2016-09-26 11:33:34 --> Loader Class Initialized
INFO - 2016-09-26 11:33:34 --> Helper loaded: url_helper
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:33:34 --> Controller Class Initialized
DEBUG - 2016-09-26 11:33:34 --> Index MX_Controller Initialized
INFO - 2016-09-26 11:33:34 --> Model Class Initialized
INFO - 2016-09-26 11:33:34 --> Model Class Initialized
ERROR - 2016-09-26 11:33:34 --> Unable to delete cache file for admin/index/data/anggota
DEBUG - 2016-09-26 11:33:34 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-26 11:33:34 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-26 11:33:34 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-26 11:33:34 --> File already loaded: /home/koperasi/public_html/application/controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-26 11:33:34 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-26 11:33:34 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/list_anggota.php
DEBUG - 2016-09-26 11:33:34 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-26 11:33:34 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:33:34 --> Database Driver Class Initialized
DEBUG - 2016-09-26 11:33:34 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-26 11:33:34 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-26 11:33:34 --> Final output sent to browser
DEBUG - 2016-09-26 11:33:34 --> Total execution time: 0.1046
INFO - 2016-09-26 11:33:35 --> Config Class Initialized
INFO - 2016-09-26 11:33:35 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:33:35 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:33:35 --> Utf8 Class Initialized
INFO - 2016-09-26 11:33:35 --> URI Class Initialized
INFO - 2016-09-26 11:33:35 --> Router Class Initialized
INFO - 2016-09-26 11:33:35 --> Output Class Initialized
INFO - 2016-09-26 11:33:35 --> Security Class Initialized
DEBUG - 2016-09-26 11:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:33:35 --> Input Class Initialized
INFO - 2016-09-26 11:33:35 --> Language Class Initialized
ERROR - 2016-09-26 11:33:35 --> 404 Page Not Found: /index
INFO - 2016-09-26 11:33:38 --> Config Class Initialized
INFO - 2016-09-26 11:33:38 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:33:38 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:33:38 --> Utf8 Class Initialized
INFO - 2016-09-26 11:33:38 --> URI Class Initialized
INFO - 2016-09-26 11:33:38 --> Router Class Initialized
INFO - 2016-09-26 11:33:38 --> Output Class Initialized
INFO - 2016-09-26 11:33:38 --> Security Class Initialized
DEBUG - 2016-09-26 11:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:33:38 --> Input Class Initialized
INFO - 2016-09-26 11:33:38 --> Language Class Initialized
ERROR - 2016-09-26 11:33:38 --> 404 Page Not Found: /index
INFO - 2016-09-26 11:34:17 --> Config Class Initialized
INFO - 2016-09-26 11:34:17 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:34:17 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:34:17 --> Utf8 Class Initialized
INFO - 2016-09-26 11:34:17 --> URI Class Initialized
INFO - 2016-09-26 11:34:17 --> Router Class Initialized
INFO - 2016-09-26 11:34:17 --> Output Class Initialized
INFO - 2016-09-26 11:34:17 --> Security Class Initialized
DEBUG - 2016-09-26 11:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:34:17 --> Input Class Initialized
INFO - 2016-09-26 11:34:17 --> Language Class Initialized
INFO - 2016-09-26 11:34:17 --> Language Class Initialized
INFO - 2016-09-26 11:34:17 --> Config Class Initialized
INFO - 2016-09-26 11:34:17 --> Loader Class Initialized
INFO - 2016-09-26 11:34:17 --> Helper loaded: url_helper
INFO - 2016-09-26 11:34:17 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:34:17 --> Controller Class Initialized
DEBUG - 2016-09-26 11:34:17 --> Index MX_Controller Initialized
INFO - 2016-09-26 11:34:17 --> Model Class Initialized
INFO - 2016-09-26 11:34:17 --> Model Class Initialized
ERROR - 2016-09-26 11:34:17 --> Unable to delete cache file for admin/index/logout
INFO - 2016-09-26 11:34:17 --> Final output sent to browser
DEBUG - 2016-09-26 11:34:17 --> Total execution time: 0.0261
INFO - 2016-09-26 11:34:18 --> Config Class Initialized
INFO - 2016-09-26 11:34:18 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:34:18 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:34:18 --> Utf8 Class Initialized
INFO - 2016-09-26 11:34:18 --> URI Class Initialized
INFO - 2016-09-26 11:34:18 --> Router Class Initialized
INFO - 2016-09-26 11:34:18 --> Output Class Initialized
INFO - 2016-09-26 11:34:18 --> Security Class Initialized
DEBUG - 2016-09-26 11:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:34:18 --> Input Class Initialized
INFO - 2016-09-26 11:34:18 --> Language Class Initialized
INFO - 2016-09-26 11:34:18 --> Language Class Initialized
INFO - 2016-09-26 11:34:18 --> Config Class Initialized
INFO - 2016-09-26 11:34:18 --> Loader Class Initialized
INFO - 2016-09-26 11:34:18 --> Helper loaded: url_helper
INFO - 2016-09-26 11:34:18 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:34:18 --> Controller Class Initialized
DEBUG - 2016-09-26 11:34:18 --> login MX_Controller Initialized
INFO - 2016-09-26 11:34:18 --> Model Class Initialized
INFO - 2016-09-26 11:34:18 --> Model Class Initialized
DEBUG - 2016-09-26 11:34:18 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-26 11:34:18 --> Final output sent to browser
DEBUG - 2016-09-26 11:34:18 --> Total execution time: 0.0229
INFO - 2016-09-26 11:34:27 --> Config Class Initialized
INFO - 2016-09-26 11:34:27 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:34:27 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:34:27 --> Utf8 Class Initialized
INFO - 2016-09-26 11:34:27 --> URI Class Initialized
INFO - 2016-09-26 11:34:27 --> Router Class Initialized
INFO - 2016-09-26 11:34:27 --> Output Class Initialized
INFO - 2016-09-26 11:34:27 --> Security Class Initialized
DEBUG - 2016-09-26 11:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:34:27 --> Input Class Initialized
INFO - 2016-09-26 11:34:27 --> Language Class Initialized
INFO - 2016-09-26 11:34:27 --> Language Class Initialized
INFO - 2016-09-26 11:34:27 --> Config Class Initialized
INFO - 2016-09-26 11:34:27 --> Loader Class Initialized
INFO - 2016-09-26 11:34:27 --> Helper loaded: url_helper
INFO - 2016-09-26 11:34:27 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:34:27 --> Controller Class Initialized
DEBUG - 2016-09-26 11:34:27 --> login MX_Controller Initialized
INFO - 2016-09-26 11:34:27 --> Model Class Initialized
INFO - 2016-09-26 11:34:27 --> Model Class Initialized
INFO - 2016-09-26 11:34:27 --> Final output sent to browser
DEBUG - 2016-09-26 11:34:27 --> Total execution time: 0.0244
INFO - 2016-09-26 11:34:50 --> Config Class Initialized
INFO - 2016-09-26 11:34:50 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:34:50 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:34:50 --> Utf8 Class Initialized
INFO - 2016-09-26 11:34:50 --> URI Class Initialized
INFO - 2016-09-26 11:34:50 --> Router Class Initialized
INFO - 2016-09-26 11:34:50 --> Output Class Initialized
INFO - 2016-09-26 11:34:50 --> Security Class Initialized
DEBUG - 2016-09-26 11:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:34:50 --> Input Class Initialized
INFO - 2016-09-26 11:34:50 --> Language Class Initialized
INFO - 2016-09-26 11:34:50 --> Language Class Initialized
INFO - 2016-09-26 11:34:50 --> Config Class Initialized
INFO - 2016-09-26 11:34:50 --> Loader Class Initialized
INFO - 2016-09-26 11:34:50 --> Helper loaded: url_helper
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:34:50 --> Controller Class Initialized
DEBUG - 2016-09-26 11:34:50 --> login MX_Controller Initialized
INFO - 2016-09-26 11:34:50 --> Model Class Initialized
INFO - 2016-09-26 11:34:50 --> Model Class Initialized
INFO - 2016-09-26 11:34:50 --> Final output sent to browser
DEBUG - 2016-09-26 11:34:50 --> Total execution time: 0.0250
INFO - 2016-09-26 11:34:50 --> Config Class Initialized
INFO - 2016-09-26 11:34:50 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:34:50 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:34:50 --> Utf8 Class Initialized
INFO - 2016-09-26 11:34:50 --> URI Class Initialized
INFO - 2016-09-26 11:34:50 --> Router Class Initialized
INFO - 2016-09-26 11:34:50 --> Output Class Initialized
INFO - 2016-09-26 11:34:50 --> Security Class Initialized
DEBUG - 2016-09-26 11:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:34:50 --> Input Class Initialized
INFO - 2016-09-26 11:34:50 --> Language Class Initialized
INFO - 2016-09-26 11:34:50 --> Language Class Initialized
INFO - 2016-09-26 11:34:50 --> Config Class Initialized
INFO - 2016-09-26 11:34:50 --> Loader Class Initialized
INFO - 2016-09-26 11:34:50 --> Helper loaded: url_helper
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:34:50 --> Controller Class Initialized
DEBUG - 2016-09-26 11:34:50 --> Index MX_Controller Initialized
INFO - 2016-09-26 11:34:50 --> Model Class Initialized
INFO - 2016-09-26 11:34:50 --> Model Class Initialized
ERROR - 2016-09-26 11:34:50 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-26 11:34:50 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-26 11:34:50 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-26 11:34:50 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-26 11:34:50 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-26 11:34:50 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-26 11:34:50 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
INFO - 2016-09-26 11:34:50 --> Database Driver Class Initialized
DEBUG - 2016-09-26 11:34:50 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-26 11:34:50 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-26 11:34:50 --> Final output sent to browser
DEBUG - 2016-09-26 11:34:50 --> Total execution time: 0.1188
INFO - 2016-09-26 11:34:51 --> Config Class Initialized
INFO - 2016-09-26 11:34:51 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:34:51 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:34:51 --> Utf8 Class Initialized
INFO - 2016-09-26 11:34:51 --> URI Class Initialized
INFO - 2016-09-26 11:34:51 --> Router Class Initialized
INFO - 2016-09-26 11:34:51 --> Output Class Initialized
INFO - 2016-09-26 11:34:51 --> Security Class Initialized
DEBUG - 2016-09-26 11:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:34:51 --> Input Class Initialized
INFO - 2016-09-26 11:34:51 --> Language Class Initialized
ERROR - 2016-09-26 11:34:51 --> 404 Page Not Found: /index
INFO - 2016-09-26 11:34:58 --> Config Class Initialized
INFO - 2016-09-26 11:34:58 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:34:58 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:34:58 --> Utf8 Class Initialized
INFO - 2016-09-26 11:34:58 --> URI Class Initialized
INFO - 2016-09-26 11:34:58 --> Router Class Initialized
INFO - 2016-09-26 11:34:58 --> Output Class Initialized
INFO - 2016-09-26 11:34:58 --> Security Class Initialized
DEBUG - 2016-09-26 11:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:34:58 --> Input Class Initialized
INFO - 2016-09-26 11:34:58 --> Language Class Initialized
ERROR - 2016-09-26 11:34:58 --> 404 Page Not Found: /index
INFO - 2016-09-26 11:35:10 --> Config Class Initialized
INFO - 2016-09-26 11:35:10 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:35:10 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:35:10 --> Utf8 Class Initialized
INFO - 2016-09-26 11:35:10 --> URI Class Initialized
INFO - 2016-09-26 11:35:10 --> Router Class Initialized
INFO - 2016-09-26 11:35:10 --> Output Class Initialized
INFO - 2016-09-26 11:35:10 --> Security Class Initialized
DEBUG - 2016-09-26 11:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:35:10 --> Input Class Initialized
INFO - 2016-09-26 11:35:10 --> Language Class Initialized
INFO - 2016-09-26 11:35:10 --> Language Class Initialized
INFO - 2016-09-26 11:35:10 --> Config Class Initialized
INFO - 2016-09-26 11:35:10 --> Loader Class Initialized
INFO - 2016-09-26 11:35:10 --> Helper loaded: url_helper
INFO - 2016-09-26 11:35:10 --> Database Driver Class Initialized
INFO - 2016-09-26 11:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:35:10 --> Controller Class Initialized
DEBUG - 2016-09-26 11:35:10 --> Index MX_Controller Initialized
INFO - 2016-09-26 11:35:10 --> Model Class Initialized
INFO - 2016-09-26 11:35:10 --> Model Class Initialized
ERROR - 2016-09-26 11:35:10 --> Unable to delete cache file for admin/index/logout
INFO - 2016-09-26 11:35:10 --> Final output sent to browser
DEBUG - 2016-09-26 11:35:10 --> Total execution time: 0.0484
INFO - 2016-09-26 11:35:11 --> Config Class Initialized
INFO - 2016-09-26 11:35:11 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:35:11 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:35:11 --> Utf8 Class Initialized
INFO - 2016-09-26 11:35:11 --> URI Class Initialized
INFO - 2016-09-26 11:35:11 --> Router Class Initialized
INFO - 2016-09-26 11:35:11 --> Output Class Initialized
INFO - 2016-09-26 11:35:11 --> Security Class Initialized
DEBUG - 2016-09-26 11:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:35:11 --> Input Class Initialized
INFO - 2016-09-26 11:35:11 --> Language Class Initialized
INFO - 2016-09-26 11:35:11 --> Language Class Initialized
INFO - 2016-09-26 11:35:11 --> Config Class Initialized
INFO - 2016-09-26 11:35:11 --> Loader Class Initialized
INFO - 2016-09-26 11:35:11 --> Helper loaded: url_helper
INFO - 2016-09-26 11:35:11 --> Database Driver Class Initialized
INFO - 2016-09-26 11:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:35:11 --> Controller Class Initialized
DEBUG - 2016-09-26 11:35:11 --> login MX_Controller Initialized
INFO - 2016-09-26 11:35:11 --> Model Class Initialized
INFO - 2016-09-26 11:35:11 --> Model Class Initialized
DEBUG - 2016-09-26 11:35:11 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-26 11:35:11 --> Final output sent to browser
DEBUG - 2016-09-26 11:35:11 --> Total execution time: 0.0273
INFO - 2016-09-26 11:35:34 --> Config Class Initialized
INFO - 2016-09-26 11:35:34 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:35:34 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:35:34 --> Utf8 Class Initialized
INFO - 2016-09-26 11:35:34 --> URI Class Initialized
INFO - 2016-09-26 11:35:34 --> Router Class Initialized
INFO - 2016-09-26 11:35:34 --> Output Class Initialized
INFO - 2016-09-26 11:35:34 --> Security Class Initialized
DEBUG - 2016-09-26 11:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:35:34 --> Input Class Initialized
INFO - 2016-09-26 11:35:34 --> Language Class Initialized
INFO - 2016-09-26 11:35:34 --> Language Class Initialized
INFO - 2016-09-26 11:35:34 --> Config Class Initialized
INFO - 2016-09-26 11:35:34 --> Loader Class Initialized
INFO - 2016-09-26 11:35:34 --> Helper loaded: url_helper
INFO - 2016-09-26 11:35:34 --> Database Driver Class Initialized
INFO - 2016-09-26 11:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:35:34 --> Controller Class Initialized
DEBUG - 2016-09-26 11:35:34 --> login MX_Controller Initialized
INFO - 2016-09-26 11:35:34 --> Model Class Initialized
INFO - 2016-09-26 11:35:34 --> Model Class Initialized
INFO - 2016-09-26 11:35:34 --> Final output sent to browser
DEBUG - 2016-09-26 11:35:34 --> Total execution time: 0.0351
INFO - 2016-09-26 11:36:05 --> Config Class Initialized
INFO - 2016-09-26 11:36:05 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:36:05 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:36:05 --> Utf8 Class Initialized
INFO - 2016-09-26 11:36:05 --> URI Class Initialized
INFO - 2016-09-26 11:36:05 --> Router Class Initialized
INFO - 2016-09-26 11:36:05 --> Output Class Initialized
INFO - 2016-09-26 11:36:05 --> Security Class Initialized
DEBUG - 2016-09-26 11:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:36:05 --> Input Class Initialized
INFO - 2016-09-26 11:36:05 --> Language Class Initialized
INFO - 2016-09-26 11:36:05 --> Language Class Initialized
INFO - 2016-09-26 11:36:05 --> Config Class Initialized
INFO - 2016-09-26 11:36:05 --> Loader Class Initialized
INFO - 2016-09-26 11:36:05 --> Helper loaded: url_helper
INFO - 2016-09-26 11:36:05 --> Database Driver Class Initialized
INFO - 2016-09-26 11:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:36:05 --> Controller Class Initialized
DEBUG - 2016-09-26 11:36:05 --> login MX_Controller Initialized
INFO - 2016-09-26 11:36:05 --> Model Class Initialized
INFO - 2016-09-26 11:36:05 --> Model Class Initialized
INFO - 2016-09-26 11:36:05 --> Final output sent to browser
DEBUG - 2016-09-26 11:36:05 --> Total execution time: 0.0280
INFO - 2016-09-26 11:36:19 --> Config Class Initialized
INFO - 2016-09-26 11:36:19 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:36:19 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:36:19 --> Utf8 Class Initialized
INFO - 2016-09-26 11:36:19 --> URI Class Initialized
INFO - 2016-09-26 11:36:19 --> Router Class Initialized
INFO - 2016-09-26 11:36:19 --> Output Class Initialized
INFO - 2016-09-26 11:36:19 --> Security Class Initialized
DEBUG - 2016-09-26 11:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:36:19 --> Input Class Initialized
INFO - 2016-09-26 11:36:19 --> Language Class Initialized
INFO - 2016-09-26 11:36:19 --> Language Class Initialized
INFO - 2016-09-26 11:36:19 --> Config Class Initialized
INFO - 2016-09-26 11:36:19 --> Loader Class Initialized
INFO - 2016-09-26 11:36:19 --> Helper loaded: url_helper
INFO - 2016-09-26 11:36:19 --> Database Driver Class Initialized
INFO - 2016-09-26 11:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:36:19 --> Controller Class Initialized
DEBUG - 2016-09-26 11:36:19 --> login MX_Controller Initialized
INFO - 2016-09-26 11:36:19 --> Model Class Initialized
INFO - 2016-09-26 11:36:19 --> Model Class Initialized
INFO - 2016-09-26 11:36:19 --> Final output sent to browser
DEBUG - 2016-09-26 11:36:19 --> Total execution time: 0.0258
INFO - 2016-09-26 11:36:19 --> Config Class Initialized
INFO - 2016-09-26 11:36:19 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:36:19 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:36:19 --> Utf8 Class Initialized
INFO - 2016-09-26 11:36:19 --> URI Class Initialized
INFO - 2016-09-26 11:36:19 --> Router Class Initialized
INFO - 2016-09-26 11:36:19 --> Output Class Initialized
INFO - 2016-09-26 11:36:19 --> Security Class Initialized
DEBUG - 2016-09-26 11:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:36:19 --> Input Class Initialized
INFO - 2016-09-26 11:36:19 --> Language Class Initialized
INFO - 2016-09-26 11:36:19 --> Language Class Initialized
INFO - 2016-09-26 11:36:19 --> Config Class Initialized
INFO - 2016-09-26 11:36:19 --> Loader Class Initialized
INFO - 2016-09-26 11:36:19 --> Helper loaded: url_helper
INFO - 2016-09-26 11:36:19 --> Database Driver Class Initialized
INFO - 2016-09-26 11:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:36:19 --> Controller Class Initialized
DEBUG - 2016-09-26 11:36:19 --> login MX_Controller Initialized
INFO - 2016-09-26 11:36:19 --> Model Class Initialized
INFO - 2016-09-26 11:36:19 --> Model Class Initialized
INFO - 2016-09-26 11:36:19 --> Final output sent to browser
DEBUG - 2016-09-26 11:36:19 --> Total execution time: 0.0244
INFO - 2016-09-26 11:36:19 --> Config Class Initialized
INFO - 2016-09-26 11:36:19 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:36:19 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:36:19 --> Utf8 Class Initialized
INFO - 2016-09-26 11:36:19 --> URI Class Initialized
INFO - 2016-09-26 11:36:19 --> Router Class Initialized
INFO - 2016-09-26 11:36:19 --> Output Class Initialized
INFO - 2016-09-26 11:36:19 --> Security Class Initialized
DEBUG - 2016-09-26 11:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:36:19 --> Input Class Initialized
INFO - 2016-09-26 11:36:19 --> Language Class Initialized
INFO - 2016-09-26 11:36:19 --> Language Class Initialized
INFO - 2016-09-26 11:36:19 --> Config Class Initialized
INFO - 2016-09-26 11:36:19 --> Loader Class Initialized
INFO - 2016-09-26 11:36:19 --> Helper loaded: url_helper
INFO - 2016-09-26 11:36:19 --> Database Driver Class Initialized
INFO - 2016-09-26 11:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:36:19 --> Controller Class Initialized
DEBUG - 2016-09-26 11:36:19 --> login MX_Controller Initialized
INFO - 2016-09-26 11:36:19 --> Model Class Initialized
INFO - 2016-09-26 11:36:19 --> Model Class Initialized
INFO - 2016-09-26 11:36:19 --> Final output sent to browser
DEBUG - 2016-09-26 11:36:19 --> Total execution time: 0.0301
INFO - 2016-09-26 11:36:19 --> Config Class Initialized
INFO - 2016-09-26 11:36:19 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:36:19 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:36:19 --> Utf8 Class Initialized
INFO - 2016-09-26 11:36:19 --> URI Class Initialized
INFO - 2016-09-26 11:36:19 --> Router Class Initialized
INFO - 2016-09-26 11:36:19 --> Output Class Initialized
INFO - 2016-09-26 11:36:19 --> Security Class Initialized
DEBUG - 2016-09-26 11:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:36:19 --> Input Class Initialized
INFO - 2016-09-26 11:36:19 --> Language Class Initialized
INFO - 2016-09-26 11:36:19 --> Language Class Initialized
INFO - 2016-09-26 11:36:19 --> Config Class Initialized
INFO - 2016-09-26 11:36:19 --> Loader Class Initialized
INFO - 2016-09-26 11:36:19 --> Helper loaded: url_helper
INFO - 2016-09-26 11:36:19 --> Database Driver Class Initialized
INFO - 2016-09-26 11:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:36:19 --> Controller Class Initialized
DEBUG - 2016-09-26 11:36:19 --> login MX_Controller Initialized
INFO - 2016-09-26 11:36:19 --> Model Class Initialized
INFO - 2016-09-26 11:36:19 --> Model Class Initialized
INFO - 2016-09-26 11:36:19 --> Final output sent to browser
DEBUG - 2016-09-26 11:36:19 --> Total execution time: 0.0227
INFO - 2016-09-26 11:36:19 --> Config Class Initialized
INFO - 2016-09-26 11:36:19 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:36:19 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:36:19 --> Utf8 Class Initialized
INFO - 2016-09-26 11:36:19 --> URI Class Initialized
INFO - 2016-09-26 11:36:19 --> Router Class Initialized
INFO - 2016-09-26 11:36:19 --> Output Class Initialized
INFO - 2016-09-26 11:36:19 --> Security Class Initialized
DEBUG - 2016-09-26 11:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:36:19 --> Input Class Initialized
INFO - 2016-09-26 11:36:19 --> Language Class Initialized
INFO - 2016-09-26 11:36:19 --> Language Class Initialized
INFO - 2016-09-26 11:36:19 --> Config Class Initialized
INFO - 2016-09-26 11:36:19 --> Loader Class Initialized
INFO - 2016-09-26 11:36:19 --> Helper loaded: url_helper
INFO - 2016-09-26 11:36:19 --> Database Driver Class Initialized
INFO - 2016-09-26 11:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:36:19 --> Controller Class Initialized
DEBUG - 2016-09-26 11:36:19 --> login MX_Controller Initialized
INFO - 2016-09-26 11:36:19 --> Model Class Initialized
INFO - 2016-09-26 11:36:19 --> Model Class Initialized
INFO - 2016-09-26 11:36:19 --> Final output sent to browser
DEBUG - 2016-09-26 11:36:19 --> Total execution time: 0.0239
INFO - 2016-09-26 11:36:19 --> Config Class Initialized
INFO - 2016-09-26 11:36:19 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:36:19 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:36:19 --> Utf8 Class Initialized
INFO - 2016-09-26 11:36:19 --> URI Class Initialized
INFO - 2016-09-26 11:36:19 --> Router Class Initialized
INFO - 2016-09-26 11:36:19 --> Output Class Initialized
INFO - 2016-09-26 11:36:19 --> Security Class Initialized
DEBUG - 2016-09-26 11:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:36:19 --> Input Class Initialized
INFO - 2016-09-26 11:36:19 --> Language Class Initialized
INFO - 2016-09-26 11:36:19 --> Language Class Initialized
INFO - 2016-09-26 11:36:19 --> Config Class Initialized
INFO - 2016-09-26 11:36:19 --> Loader Class Initialized
INFO - 2016-09-26 11:36:19 --> Helper loaded: url_helper
INFO - 2016-09-26 11:36:19 --> Database Driver Class Initialized
INFO - 2016-09-26 11:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:36:19 --> Controller Class Initialized
DEBUG - 2016-09-26 11:36:19 --> login MX_Controller Initialized
INFO - 2016-09-26 11:36:19 --> Model Class Initialized
INFO - 2016-09-26 11:36:19 --> Model Class Initialized
INFO - 2016-09-26 11:36:19 --> Final output sent to browser
DEBUG - 2016-09-26 11:36:19 --> Total execution time: 0.0300
INFO - 2016-09-26 11:36:19 --> Config Class Initialized
INFO - 2016-09-26 11:36:19 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:36:19 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:36:19 --> Utf8 Class Initialized
INFO - 2016-09-26 11:36:19 --> URI Class Initialized
INFO - 2016-09-26 11:36:19 --> Router Class Initialized
INFO - 2016-09-26 11:36:19 --> Output Class Initialized
INFO - 2016-09-26 11:36:19 --> Security Class Initialized
DEBUG - 2016-09-26 11:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:36:19 --> Input Class Initialized
INFO - 2016-09-26 11:36:19 --> Language Class Initialized
INFO - 2016-09-26 11:36:19 --> Language Class Initialized
INFO - 2016-09-26 11:36:19 --> Config Class Initialized
INFO - 2016-09-26 11:36:19 --> Loader Class Initialized
INFO - 2016-09-26 11:36:19 --> Helper loaded: url_helper
INFO - 2016-09-26 11:36:19 --> Database Driver Class Initialized
INFO - 2016-09-26 11:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:36:19 --> Controller Class Initialized
DEBUG - 2016-09-26 11:36:19 --> login MX_Controller Initialized
INFO - 2016-09-26 11:36:19 --> Model Class Initialized
INFO - 2016-09-26 11:36:19 --> Model Class Initialized
INFO - 2016-09-26 11:36:19 --> Final output sent to browser
DEBUG - 2016-09-26 11:36:19 --> Total execution time: 0.0320
INFO - 2016-09-26 11:36:19 --> Config Class Initialized
INFO - 2016-09-26 11:36:19 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:36:19 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:36:19 --> Utf8 Class Initialized
INFO - 2016-09-26 11:36:19 --> URI Class Initialized
INFO - 2016-09-26 11:36:19 --> Router Class Initialized
INFO - 2016-09-26 11:36:19 --> Output Class Initialized
INFO - 2016-09-26 11:36:19 --> Security Class Initialized
DEBUG - 2016-09-26 11:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:36:19 --> Input Class Initialized
INFO - 2016-09-26 11:36:19 --> Language Class Initialized
INFO - 2016-09-26 11:36:19 --> Language Class Initialized
INFO - 2016-09-26 11:36:19 --> Config Class Initialized
INFO - 2016-09-26 11:36:19 --> Loader Class Initialized
INFO - 2016-09-26 11:36:19 --> Helper loaded: url_helper
INFO - 2016-09-26 11:36:19 --> Database Driver Class Initialized
INFO - 2016-09-26 11:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:36:19 --> Controller Class Initialized
DEBUG - 2016-09-26 11:36:19 --> login MX_Controller Initialized
INFO - 2016-09-26 11:36:19 --> Model Class Initialized
INFO - 2016-09-26 11:36:19 --> Model Class Initialized
INFO - 2016-09-26 11:36:19 --> Final output sent to browser
DEBUG - 2016-09-26 11:36:19 --> Total execution time: 0.0290
INFO - 2016-09-26 11:36:20 --> Config Class Initialized
INFO - 2016-09-26 11:36:20 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:36:20 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:36:20 --> Utf8 Class Initialized
INFO - 2016-09-26 11:36:20 --> URI Class Initialized
INFO - 2016-09-26 11:36:20 --> Router Class Initialized
INFO - 2016-09-26 11:36:20 --> Output Class Initialized
INFO - 2016-09-26 11:36:20 --> Security Class Initialized
DEBUG - 2016-09-26 11:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:36:20 --> Input Class Initialized
INFO - 2016-09-26 11:36:20 --> Language Class Initialized
INFO - 2016-09-26 11:36:20 --> Language Class Initialized
INFO - 2016-09-26 11:36:20 --> Config Class Initialized
INFO - 2016-09-26 11:36:20 --> Loader Class Initialized
INFO - 2016-09-26 11:36:20 --> Helper loaded: url_helper
INFO - 2016-09-26 11:36:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:36:20 --> Controller Class Initialized
DEBUG - 2016-09-26 11:36:20 --> login MX_Controller Initialized
INFO - 2016-09-26 11:36:20 --> Model Class Initialized
INFO - 2016-09-26 11:36:20 --> Model Class Initialized
INFO - 2016-09-26 11:36:20 --> Final output sent to browser
DEBUG - 2016-09-26 11:36:20 --> Total execution time: 0.0281
INFO - 2016-09-26 11:36:20 --> Config Class Initialized
INFO - 2016-09-26 11:36:20 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:36:20 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:36:20 --> Utf8 Class Initialized
INFO - 2016-09-26 11:36:20 --> URI Class Initialized
INFO - 2016-09-26 11:36:20 --> Router Class Initialized
INFO - 2016-09-26 11:36:20 --> Output Class Initialized
INFO - 2016-09-26 11:36:20 --> Security Class Initialized
DEBUG - 2016-09-26 11:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:36:20 --> Input Class Initialized
INFO - 2016-09-26 11:36:20 --> Language Class Initialized
INFO - 2016-09-26 11:36:20 --> Language Class Initialized
INFO - 2016-09-26 11:36:20 --> Config Class Initialized
INFO - 2016-09-26 11:36:20 --> Loader Class Initialized
INFO - 2016-09-26 11:36:20 --> Helper loaded: url_helper
INFO - 2016-09-26 11:36:20 --> Database Driver Class Initialized
INFO - 2016-09-26 11:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:36:20 --> Controller Class Initialized
DEBUG - 2016-09-26 11:36:20 --> login MX_Controller Initialized
INFO - 2016-09-26 11:36:20 --> Model Class Initialized
INFO - 2016-09-26 11:36:20 --> Model Class Initialized
INFO - 2016-09-26 11:36:20 --> Final output sent to browser
DEBUG - 2016-09-26 11:36:20 --> Total execution time: 0.0242
INFO - 2016-09-26 11:36:23 --> Config Class Initialized
INFO - 2016-09-26 11:36:23 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:36:23 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:36:23 --> Utf8 Class Initialized
INFO - 2016-09-26 11:36:23 --> URI Class Initialized
INFO - 2016-09-26 11:36:23 --> Router Class Initialized
INFO - 2016-09-26 11:36:23 --> Output Class Initialized
INFO - 2016-09-26 11:36:23 --> Security Class Initialized
DEBUG - 2016-09-26 11:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:36:23 --> Input Class Initialized
INFO - 2016-09-26 11:36:23 --> Language Class Initialized
INFO - 2016-09-26 11:36:23 --> Language Class Initialized
INFO - 2016-09-26 11:36:23 --> Config Class Initialized
INFO - 2016-09-26 11:36:23 --> Loader Class Initialized
INFO - 2016-09-26 11:36:23 --> Helper loaded: url_helper
INFO - 2016-09-26 11:36:23 --> Database Driver Class Initialized
INFO - 2016-09-26 11:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:36:23 --> Controller Class Initialized
DEBUG - 2016-09-26 11:36:23 --> login MX_Controller Initialized
INFO - 2016-09-26 11:36:23 --> Model Class Initialized
INFO - 2016-09-26 11:36:23 --> Model Class Initialized
INFO - 2016-09-26 11:36:23 --> Final output sent to browser
DEBUG - 2016-09-26 11:36:23 --> Total execution time: 0.0251
INFO - 2016-09-26 11:36:23 --> Config Class Initialized
INFO - 2016-09-26 11:36:23 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:36:23 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:36:23 --> Utf8 Class Initialized
INFO - 2016-09-26 11:36:23 --> URI Class Initialized
INFO - 2016-09-26 11:36:23 --> Router Class Initialized
INFO - 2016-09-26 11:36:23 --> Output Class Initialized
INFO - 2016-09-26 11:36:23 --> Security Class Initialized
DEBUG - 2016-09-26 11:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:36:23 --> Input Class Initialized
INFO - 2016-09-26 11:36:23 --> Language Class Initialized
INFO - 2016-09-26 11:36:23 --> Language Class Initialized
INFO - 2016-09-26 11:36:23 --> Config Class Initialized
INFO - 2016-09-26 11:36:23 --> Loader Class Initialized
INFO - 2016-09-26 11:36:23 --> Helper loaded: url_helper
INFO - 2016-09-26 11:36:23 --> Database Driver Class Initialized
INFO - 2016-09-26 11:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:36:23 --> Controller Class Initialized
DEBUG - 2016-09-26 11:36:23 --> login MX_Controller Initialized
INFO - 2016-09-26 11:36:23 --> Model Class Initialized
INFO - 2016-09-26 11:36:23 --> Model Class Initialized
INFO - 2016-09-26 11:36:23 --> Final output sent to browser
DEBUG - 2016-09-26 11:36:23 --> Total execution time: 0.0261
INFO - 2016-09-26 11:36:23 --> Config Class Initialized
INFO - 2016-09-26 11:36:23 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:36:23 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:36:23 --> Utf8 Class Initialized
INFO - 2016-09-26 11:36:23 --> URI Class Initialized
INFO - 2016-09-26 11:36:23 --> Router Class Initialized
INFO - 2016-09-26 11:36:23 --> Output Class Initialized
INFO - 2016-09-26 11:36:23 --> Security Class Initialized
DEBUG - 2016-09-26 11:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:36:23 --> Input Class Initialized
INFO - 2016-09-26 11:36:23 --> Language Class Initialized
INFO - 2016-09-26 11:36:23 --> Language Class Initialized
INFO - 2016-09-26 11:36:23 --> Config Class Initialized
INFO - 2016-09-26 11:36:23 --> Loader Class Initialized
INFO - 2016-09-26 11:36:23 --> Helper loaded: url_helper
INFO - 2016-09-26 11:36:23 --> Database Driver Class Initialized
INFO - 2016-09-26 11:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:36:23 --> Controller Class Initialized
DEBUG - 2016-09-26 11:36:23 --> login MX_Controller Initialized
INFO - 2016-09-26 11:36:23 --> Model Class Initialized
INFO - 2016-09-26 11:36:23 --> Model Class Initialized
INFO - 2016-09-26 11:36:23 --> Final output sent to browser
DEBUG - 2016-09-26 11:36:23 --> Total execution time: 0.0297
INFO - 2016-09-26 11:36:23 --> Config Class Initialized
INFO - 2016-09-26 11:36:23 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:36:23 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:36:23 --> Utf8 Class Initialized
INFO - 2016-09-26 11:36:23 --> URI Class Initialized
INFO - 2016-09-26 11:36:23 --> Router Class Initialized
INFO - 2016-09-26 11:36:23 --> Output Class Initialized
INFO - 2016-09-26 11:36:23 --> Security Class Initialized
DEBUG - 2016-09-26 11:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:36:23 --> Input Class Initialized
INFO - 2016-09-26 11:36:23 --> Language Class Initialized
INFO - 2016-09-26 11:36:23 --> Language Class Initialized
INFO - 2016-09-26 11:36:23 --> Config Class Initialized
INFO - 2016-09-26 11:36:23 --> Loader Class Initialized
INFO - 2016-09-26 11:36:23 --> Helper loaded: url_helper
INFO - 2016-09-26 11:36:23 --> Database Driver Class Initialized
INFO - 2016-09-26 11:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:36:23 --> Controller Class Initialized
DEBUG - 2016-09-26 11:36:23 --> login MX_Controller Initialized
INFO - 2016-09-26 11:36:23 --> Model Class Initialized
INFO - 2016-09-26 11:36:23 --> Model Class Initialized
INFO - 2016-09-26 11:36:23 --> Final output sent to browser
DEBUG - 2016-09-26 11:36:23 --> Total execution time: 0.0241
INFO - 2016-09-26 11:36:24 --> Config Class Initialized
INFO - 2016-09-26 11:36:24 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:36:24 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:36:24 --> Utf8 Class Initialized
INFO - 2016-09-26 11:36:24 --> URI Class Initialized
INFO - 2016-09-26 11:36:24 --> Router Class Initialized
INFO - 2016-09-26 11:36:24 --> Output Class Initialized
INFO - 2016-09-26 11:36:24 --> Security Class Initialized
DEBUG - 2016-09-26 11:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:36:24 --> Input Class Initialized
INFO - 2016-09-26 11:36:24 --> Language Class Initialized
INFO - 2016-09-26 11:36:24 --> Language Class Initialized
INFO - 2016-09-26 11:36:24 --> Config Class Initialized
INFO - 2016-09-26 11:36:24 --> Loader Class Initialized
INFO - 2016-09-26 11:36:24 --> Helper loaded: url_helper
INFO - 2016-09-26 11:36:24 --> Database Driver Class Initialized
INFO - 2016-09-26 11:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:36:24 --> Controller Class Initialized
DEBUG - 2016-09-26 11:36:24 --> login MX_Controller Initialized
INFO - 2016-09-26 11:36:24 --> Model Class Initialized
INFO - 2016-09-26 11:36:24 --> Model Class Initialized
INFO - 2016-09-26 11:36:24 --> Final output sent to browser
DEBUG - 2016-09-26 11:36:24 --> Total execution time: 0.0356
INFO - 2016-09-26 11:36:24 --> Config Class Initialized
INFO - 2016-09-26 11:36:24 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:36:24 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:36:24 --> Utf8 Class Initialized
INFO - 2016-09-26 11:36:24 --> URI Class Initialized
INFO - 2016-09-26 11:36:24 --> Router Class Initialized
INFO - 2016-09-26 11:36:24 --> Output Class Initialized
INFO - 2016-09-26 11:36:24 --> Security Class Initialized
DEBUG - 2016-09-26 11:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:36:24 --> Input Class Initialized
INFO - 2016-09-26 11:36:24 --> Language Class Initialized
INFO - 2016-09-26 11:36:24 --> Language Class Initialized
INFO - 2016-09-26 11:36:24 --> Config Class Initialized
INFO - 2016-09-26 11:36:24 --> Loader Class Initialized
INFO - 2016-09-26 11:36:24 --> Helper loaded: url_helper
INFO - 2016-09-26 11:36:24 --> Database Driver Class Initialized
INFO - 2016-09-26 11:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:36:24 --> Controller Class Initialized
DEBUG - 2016-09-26 11:36:24 --> login MX_Controller Initialized
INFO - 2016-09-26 11:36:24 --> Model Class Initialized
INFO - 2016-09-26 11:36:24 --> Model Class Initialized
INFO - 2016-09-26 11:36:24 --> Final output sent to browser
DEBUG - 2016-09-26 11:36:24 --> Total execution time: 0.0296
INFO - 2016-09-26 11:36:24 --> Config Class Initialized
INFO - 2016-09-26 11:36:24 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:36:24 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:36:24 --> Utf8 Class Initialized
INFO - 2016-09-26 11:36:24 --> URI Class Initialized
INFO - 2016-09-26 11:36:24 --> Router Class Initialized
INFO - 2016-09-26 11:36:24 --> Output Class Initialized
INFO - 2016-09-26 11:36:24 --> Security Class Initialized
DEBUG - 2016-09-26 11:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:36:24 --> Input Class Initialized
INFO - 2016-09-26 11:36:24 --> Language Class Initialized
INFO - 2016-09-26 11:36:24 --> Language Class Initialized
INFO - 2016-09-26 11:36:24 --> Config Class Initialized
INFO - 2016-09-26 11:36:24 --> Loader Class Initialized
INFO - 2016-09-26 11:36:24 --> Helper loaded: url_helper
INFO - 2016-09-26 11:36:24 --> Database Driver Class Initialized
INFO - 2016-09-26 11:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:36:24 --> Controller Class Initialized
DEBUG - 2016-09-26 11:36:24 --> login MX_Controller Initialized
INFO - 2016-09-26 11:36:24 --> Model Class Initialized
INFO - 2016-09-26 11:36:24 --> Model Class Initialized
INFO - 2016-09-26 11:36:24 --> Final output sent to browser
DEBUG - 2016-09-26 11:36:24 --> Total execution time: 0.0251
INFO - 2016-09-26 11:36:24 --> Config Class Initialized
INFO - 2016-09-26 11:36:24 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:36:24 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:36:24 --> Utf8 Class Initialized
INFO - 2016-09-26 11:36:24 --> URI Class Initialized
INFO - 2016-09-26 11:36:24 --> Router Class Initialized
INFO - 2016-09-26 11:36:24 --> Output Class Initialized
INFO - 2016-09-26 11:36:24 --> Security Class Initialized
DEBUG - 2016-09-26 11:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:36:24 --> Input Class Initialized
INFO - 2016-09-26 11:36:24 --> Language Class Initialized
INFO - 2016-09-26 11:36:24 --> Language Class Initialized
INFO - 2016-09-26 11:36:24 --> Config Class Initialized
INFO - 2016-09-26 11:36:24 --> Loader Class Initialized
INFO - 2016-09-26 11:36:24 --> Helper loaded: url_helper
INFO - 2016-09-26 11:36:24 --> Database Driver Class Initialized
INFO - 2016-09-26 11:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:36:24 --> Controller Class Initialized
DEBUG - 2016-09-26 11:36:24 --> login MX_Controller Initialized
INFO - 2016-09-26 11:36:24 --> Model Class Initialized
INFO - 2016-09-26 11:36:24 --> Model Class Initialized
INFO - 2016-09-26 11:36:24 --> Final output sent to browser
DEBUG - 2016-09-26 11:36:24 --> Total execution time: 0.0246
INFO - 2016-09-26 11:36:24 --> Config Class Initialized
INFO - 2016-09-26 11:36:24 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:36:24 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:36:24 --> Utf8 Class Initialized
INFO - 2016-09-26 11:36:24 --> URI Class Initialized
INFO - 2016-09-26 11:36:24 --> Router Class Initialized
INFO - 2016-09-26 11:36:24 --> Output Class Initialized
INFO - 2016-09-26 11:36:24 --> Security Class Initialized
DEBUG - 2016-09-26 11:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:36:24 --> Input Class Initialized
INFO - 2016-09-26 11:36:24 --> Language Class Initialized
INFO - 2016-09-26 11:36:24 --> Language Class Initialized
INFO - 2016-09-26 11:36:24 --> Config Class Initialized
INFO - 2016-09-26 11:36:24 --> Loader Class Initialized
INFO - 2016-09-26 11:36:24 --> Helper loaded: url_helper
INFO - 2016-09-26 11:36:24 --> Database Driver Class Initialized
INFO - 2016-09-26 11:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:36:24 --> Controller Class Initialized
DEBUG - 2016-09-26 11:36:24 --> login MX_Controller Initialized
INFO - 2016-09-26 11:36:24 --> Model Class Initialized
INFO - 2016-09-26 11:36:24 --> Model Class Initialized
INFO - 2016-09-26 11:36:24 --> Final output sent to browser
DEBUG - 2016-09-26 11:36:24 --> Total execution time: 0.0311
INFO - 2016-09-26 11:36:24 --> Config Class Initialized
INFO - 2016-09-26 11:36:24 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:36:24 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:36:24 --> Utf8 Class Initialized
INFO - 2016-09-26 11:36:24 --> URI Class Initialized
INFO - 2016-09-26 11:36:24 --> Router Class Initialized
INFO - 2016-09-26 11:36:24 --> Output Class Initialized
INFO - 2016-09-26 11:36:24 --> Security Class Initialized
DEBUG - 2016-09-26 11:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:36:24 --> Input Class Initialized
INFO - 2016-09-26 11:36:24 --> Language Class Initialized
INFO - 2016-09-26 11:36:24 --> Language Class Initialized
INFO - 2016-09-26 11:36:24 --> Config Class Initialized
INFO - 2016-09-26 11:36:24 --> Loader Class Initialized
INFO - 2016-09-26 11:36:24 --> Helper loaded: url_helper
INFO - 2016-09-26 11:36:24 --> Database Driver Class Initialized
INFO - 2016-09-26 11:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:36:24 --> Controller Class Initialized
DEBUG - 2016-09-26 11:36:24 --> login MX_Controller Initialized
INFO - 2016-09-26 11:36:24 --> Model Class Initialized
INFO - 2016-09-26 11:36:24 --> Model Class Initialized
INFO - 2016-09-26 11:36:24 --> Final output sent to browser
DEBUG - 2016-09-26 11:36:24 --> Total execution time: 0.0233
INFO - 2016-09-26 11:36:24 --> Config Class Initialized
INFO - 2016-09-26 11:36:24 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:36:24 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:36:24 --> Utf8 Class Initialized
INFO - 2016-09-26 11:36:24 --> URI Class Initialized
INFO - 2016-09-26 11:36:24 --> Router Class Initialized
INFO - 2016-09-26 11:36:24 --> Output Class Initialized
INFO - 2016-09-26 11:36:24 --> Security Class Initialized
DEBUG - 2016-09-26 11:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:36:24 --> Input Class Initialized
INFO - 2016-09-26 11:36:24 --> Language Class Initialized
INFO - 2016-09-26 11:36:24 --> Language Class Initialized
INFO - 2016-09-26 11:36:24 --> Config Class Initialized
INFO - 2016-09-26 11:36:24 --> Loader Class Initialized
INFO - 2016-09-26 11:36:24 --> Helper loaded: url_helper
INFO - 2016-09-26 11:36:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:36:25 --> Controller Class Initialized
DEBUG - 2016-09-26 11:36:25 --> login MX_Controller Initialized
INFO - 2016-09-26 11:36:25 --> Model Class Initialized
INFO - 2016-09-26 11:36:25 --> Model Class Initialized
INFO - 2016-09-26 11:36:25 --> Final output sent to browser
DEBUG - 2016-09-26 11:36:25 --> Total execution time: 0.0306
INFO - 2016-09-26 11:36:25 --> Config Class Initialized
INFO - 2016-09-26 11:36:25 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:36:25 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:36:25 --> Utf8 Class Initialized
INFO - 2016-09-26 11:36:25 --> URI Class Initialized
INFO - 2016-09-26 11:36:25 --> Router Class Initialized
INFO - 2016-09-26 11:36:25 --> Output Class Initialized
INFO - 2016-09-26 11:36:25 --> Security Class Initialized
DEBUG - 2016-09-26 11:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:36:25 --> Input Class Initialized
INFO - 2016-09-26 11:36:25 --> Language Class Initialized
INFO - 2016-09-26 11:36:25 --> Language Class Initialized
INFO - 2016-09-26 11:36:25 --> Config Class Initialized
INFO - 2016-09-26 11:36:25 --> Loader Class Initialized
INFO - 2016-09-26 11:36:25 --> Helper loaded: url_helper
INFO - 2016-09-26 11:36:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:36:25 --> Controller Class Initialized
DEBUG - 2016-09-26 11:36:25 --> login MX_Controller Initialized
INFO - 2016-09-26 11:36:25 --> Model Class Initialized
INFO - 2016-09-26 11:36:25 --> Model Class Initialized
INFO - 2016-09-26 11:36:25 --> Final output sent to browser
DEBUG - 2016-09-26 11:36:25 --> Total execution time: 0.0278
INFO - 2016-09-26 11:36:25 --> Config Class Initialized
INFO - 2016-09-26 11:36:25 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:36:25 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:36:25 --> Utf8 Class Initialized
INFO - 2016-09-26 11:36:25 --> URI Class Initialized
INFO - 2016-09-26 11:36:25 --> Router Class Initialized
INFO - 2016-09-26 11:36:25 --> Output Class Initialized
INFO - 2016-09-26 11:36:25 --> Security Class Initialized
DEBUG - 2016-09-26 11:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:36:25 --> Input Class Initialized
INFO - 2016-09-26 11:36:25 --> Language Class Initialized
INFO - 2016-09-26 11:36:25 --> Language Class Initialized
INFO - 2016-09-26 11:36:25 --> Config Class Initialized
INFO - 2016-09-26 11:36:25 --> Loader Class Initialized
INFO - 2016-09-26 11:36:25 --> Helper loaded: url_helper
INFO - 2016-09-26 11:36:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:36:25 --> Controller Class Initialized
DEBUG - 2016-09-26 11:36:25 --> login MX_Controller Initialized
INFO - 2016-09-26 11:36:25 --> Model Class Initialized
INFO - 2016-09-26 11:36:25 --> Model Class Initialized
INFO - 2016-09-26 11:36:25 --> Final output sent to browser
DEBUG - 2016-09-26 11:36:25 --> Total execution time: 0.0351
INFO - 2016-09-26 11:36:25 --> Config Class Initialized
INFO - 2016-09-26 11:36:25 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:36:25 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:36:25 --> Utf8 Class Initialized
INFO - 2016-09-26 11:36:25 --> URI Class Initialized
INFO - 2016-09-26 11:36:25 --> Router Class Initialized
INFO - 2016-09-26 11:36:25 --> Output Class Initialized
INFO - 2016-09-26 11:36:25 --> Security Class Initialized
DEBUG - 2016-09-26 11:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:36:25 --> Input Class Initialized
INFO - 2016-09-26 11:36:25 --> Language Class Initialized
INFO - 2016-09-26 11:36:25 --> Language Class Initialized
INFO - 2016-09-26 11:36:25 --> Config Class Initialized
INFO - 2016-09-26 11:36:25 --> Loader Class Initialized
INFO - 2016-09-26 11:36:25 --> Helper loaded: url_helper
INFO - 2016-09-26 11:36:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:36:25 --> Controller Class Initialized
DEBUG - 2016-09-26 11:36:25 --> login MX_Controller Initialized
INFO - 2016-09-26 11:36:25 --> Model Class Initialized
INFO - 2016-09-26 11:36:25 --> Model Class Initialized
INFO - 2016-09-26 11:36:25 --> Final output sent to browser
DEBUG - 2016-09-26 11:36:25 --> Total execution time: 0.0248
INFO - 2016-09-26 11:36:25 --> Config Class Initialized
INFO - 2016-09-26 11:36:25 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:36:25 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:36:25 --> Utf8 Class Initialized
INFO - 2016-09-26 11:36:25 --> URI Class Initialized
INFO - 2016-09-26 11:36:25 --> Router Class Initialized
INFO - 2016-09-26 11:36:25 --> Output Class Initialized
INFO - 2016-09-26 11:36:25 --> Security Class Initialized
DEBUG - 2016-09-26 11:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:36:25 --> Input Class Initialized
INFO - 2016-09-26 11:36:25 --> Language Class Initialized
INFO - 2016-09-26 11:36:26 --> Language Class Initialized
INFO - 2016-09-26 11:36:26 --> Config Class Initialized
INFO - 2016-09-26 11:36:26 --> Loader Class Initialized
INFO - 2016-09-26 11:36:26 --> Helper loaded: url_helper
INFO - 2016-09-26 11:36:26 --> Database Driver Class Initialized
INFO - 2016-09-26 11:36:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:36:26 --> Controller Class Initialized
DEBUG - 2016-09-26 11:36:26 --> login MX_Controller Initialized
INFO - 2016-09-26 11:36:26 --> Model Class Initialized
INFO - 2016-09-26 11:36:26 --> Model Class Initialized
INFO - 2016-09-26 11:36:26 --> Final output sent to browser
DEBUG - 2016-09-26 11:36:26 --> Total execution time: 0.0308
INFO - 2016-09-26 11:36:26 --> Config Class Initialized
INFO - 2016-09-26 11:36:26 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:36:26 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:36:26 --> Utf8 Class Initialized
INFO - 2016-09-26 11:36:26 --> URI Class Initialized
INFO - 2016-09-26 11:36:26 --> Router Class Initialized
INFO - 2016-09-26 11:36:26 --> Output Class Initialized
INFO - 2016-09-26 11:36:26 --> Security Class Initialized
DEBUG - 2016-09-26 11:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:36:26 --> Input Class Initialized
INFO - 2016-09-26 11:36:26 --> Language Class Initialized
INFO - 2016-09-26 11:36:26 --> Language Class Initialized
INFO - 2016-09-26 11:36:26 --> Config Class Initialized
INFO - 2016-09-26 11:36:26 --> Loader Class Initialized
INFO - 2016-09-26 11:36:26 --> Helper loaded: url_helper
INFO - 2016-09-26 11:36:26 --> Database Driver Class Initialized
INFO - 2016-09-26 11:36:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:36:26 --> Controller Class Initialized
DEBUG - 2016-09-26 11:36:26 --> login MX_Controller Initialized
INFO - 2016-09-26 11:36:26 --> Model Class Initialized
INFO - 2016-09-26 11:36:26 --> Model Class Initialized
INFO - 2016-09-26 11:36:26 --> Final output sent to browser
DEBUG - 2016-09-26 11:36:26 --> Total execution time: 0.0276
INFO - 2016-09-26 11:36:26 --> Config Class Initialized
INFO - 2016-09-26 11:36:26 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:36:26 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:36:26 --> Utf8 Class Initialized
INFO - 2016-09-26 11:36:26 --> URI Class Initialized
INFO - 2016-09-26 11:36:26 --> Router Class Initialized
INFO - 2016-09-26 11:36:26 --> Output Class Initialized
INFO - 2016-09-26 11:36:26 --> Security Class Initialized
DEBUG - 2016-09-26 11:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:36:26 --> Input Class Initialized
INFO - 2016-09-26 11:36:26 --> Language Class Initialized
INFO - 2016-09-26 11:36:26 --> Language Class Initialized
INFO - 2016-09-26 11:36:26 --> Config Class Initialized
INFO - 2016-09-26 11:36:26 --> Loader Class Initialized
INFO - 2016-09-26 11:36:26 --> Helper loaded: url_helper
INFO - 2016-09-26 11:36:26 --> Database Driver Class Initialized
INFO - 2016-09-26 11:36:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:36:26 --> Controller Class Initialized
DEBUG - 2016-09-26 11:36:26 --> login MX_Controller Initialized
INFO - 2016-09-26 11:36:26 --> Model Class Initialized
INFO - 2016-09-26 11:36:26 --> Model Class Initialized
INFO - 2016-09-26 11:36:26 --> Final output sent to browser
DEBUG - 2016-09-26 11:36:26 --> Total execution time: 0.0261
INFO - 2016-09-26 11:36:26 --> Config Class Initialized
INFO - 2016-09-26 11:36:26 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:36:26 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:36:26 --> Utf8 Class Initialized
INFO - 2016-09-26 11:36:26 --> URI Class Initialized
INFO - 2016-09-26 11:36:26 --> Router Class Initialized
INFO - 2016-09-26 11:36:26 --> Output Class Initialized
INFO - 2016-09-26 11:36:26 --> Security Class Initialized
DEBUG - 2016-09-26 11:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:36:26 --> Input Class Initialized
INFO - 2016-09-26 11:36:26 --> Language Class Initialized
INFO - 2016-09-26 11:36:26 --> Language Class Initialized
INFO - 2016-09-26 11:36:26 --> Config Class Initialized
INFO - 2016-09-26 11:36:26 --> Loader Class Initialized
INFO - 2016-09-26 11:36:26 --> Helper loaded: url_helper
INFO - 2016-09-26 11:36:26 --> Database Driver Class Initialized
INFO - 2016-09-26 11:36:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:36:26 --> Controller Class Initialized
DEBUG - 2016-09-26 11:36:26 --> login MX_Controller Initialized
INFO - 2016-09-26 11:36:26 --> Model Class Initialized
INFO - 2016-09-26 11:36:26 --> Model Class Initialized
INFO - 2016-09-26 11:36:26 --> Final output sent to browser
DEBUG - 2016-09-26 11:36:26 --> Total execution time: 0.0273
INFO - 2016-09-26 11:36:26 --> Config Class Initialized
INFO - 2016-09-26 11:36:26 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:36:26 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:36:26 --> Utf8 Class Initialized
INFO - 2016-09-26 11:36:26 --> URI Class Initialized
INFO - 2016-09-26 11:36:26 --> Router Class Initialized
INFO - 2016-09-26 11:36:26 --> Output Class Initialized
INFO - 2016-09-26 11:36:26 --> Security Class Initialized
DEBUG - 2016-09-26 11:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:36:26 --> Input Class Initialized
INFO - 2016-09-26 11:36:26 --> Language Class Initialized
INFO - 2016-09-26 11:36:26 --> Language Class Initialized
INFO - 2016-09-26 11:36:26 --> Config Class Initialized
INFO - 2016-09-26 11:36:26 --> Loader Class Initialized
INFO - 2016-09-26 11:36:26 --> Helper loaded: url_helper
INFO - 2016-09-26 11:36:26 --> Database Driver Class Initialized
INFO - 2016-09-26 11:36:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:36:26 --> Controller Class Initialized
DEBUG - 2016-09-26 11:36:26 --> login MX_Controller Initialized
INFO - 2016-09-26 11:36:26 --> Model Class Initialized
INFO - 2016-09-26 11:36:26 --> Model Class Initialized
INFO - 2016-09-26 11:36:26 --> Final output sent to browser
DEBUG - 2016-09-26 11:36:26 --> Total execution time: 0.0282
INFO - 2016-09-26 11:36:26 --> Config Class Initialized
INFO - 2016-09-26 11:36:26 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:36:26 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:36:26 --> Utf8 Class Initialized
INFO - 2016-09-26 11:36:26 --> URI Class Initialized
INFO - 2016-09-26 11:36:26 --> Router Class Initialized
INFO - 2016-09-26 11:36:26 --> Output Class Initialized
INFO - 2016-09-26 11:36:26 --> Security Class Initialized
DEBUG - 2016-09-26 11:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:36:26 --> Input Class Initialized
INFO - 2016-09-26 11:36:26 --> Language Class Initialized
INFO - 2016-09-26 11:36:26 --> Language Class Initialized
INFO - 2016-09-26 11:36:26 --> Config Class Initialized
INFO - 2016-09-26 11:36:26 --> Loader Class Initialized
INFO - 2016-09-26 11:36:26 --> Helper loaded: url_helper
INFO - 2016-09-26 11:36:26 --> Database Driver Class Initialized
INFO - 2016-09-26 11:36:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:36:26 --> Controller Class Initialized
DEBUG - 2016-09-26 11:36:26 --> login MX_Controller Initialized
INFO - 2016-09-26 11:36:26 --> Model Class Initialized
INFO - 2016-09-26 11:36:26 --> Model Class Initialized
INFO - 2016-09-26 11:36:26 --> Final output sent to browser
DEBUG - 2016-09-26 11:36:26 --> Total execution time: 0.0330
INFO - 2016-09-26 11:36:26 --> Config Class Initialized
INFO - 2016-09-26 11:36:26 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:36:26 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:36:26 --> Utf8 Class Initialized
INFO - 2016-09-26 11:36:26 --> URI Class Initialized
INFO - 2016-09-26 11:36:26 --> Router Class Initialized
INFO - 2016-09-26 11:36:26 --> Output Class Initialized
INFO - 2016-09-26 11:36:26 --> Security Class Initialized
DEBUG - 2016-09-26 11:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:36:26 --> Input Class Initialized
INFO - 2016-09-26 11:36:26 --> Language Class Initialized
INFO - 2016-09-26 11:36:26 --> Language Class Initialized
INFO - 2016-09-26 11:36:26 --> Config Class Initialized
INFO - 2016-09-26 11:36:26 --> Loader Class Initialized
INFO - 2016-09-26 11:36:26 --> Helper loaded: url_helper
INFO - 2016-09-26 11:36:26 --> Database Driver Class Initialized
INFO - 2016-09-26 11:36:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:36:26 --> Controller Class Initialized
DEBUG - 2016-09-26 11:36:26 --> login MX_Controller Initialized
INFO - 2016-09-26 11:36:26 --> Model Class Initialized
INFO - 2016-09-26 11:36:26 --> Model Class Initialized
INFO - 2016-09-26 11:36:26 --> Final output sent to browser
DEBUG - 2016-09-26 11:36:26 --> Total execution time: 0.0293
INFO - 2016-09-26 11:36:26 --> Config Class Initialized
INFO - 2016-09-26 11:36:26 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:36:26 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:36:26 --> Utf8 Class Initialized
INFO - 2016-09-26 11:36:26 --> URI Class Initialized
INFO - 2016-09-26 11:36:26 --> Router Class Initialized
INFO - 2016-09-26 11:36:26 --> Output Class Initialized
INFO - 2016-09-26 11:36:26 --> Security Class Initialized
DEBUG - 2016-09-26 11:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:36:26 --> Input Class Initialized
INFO - 2016-09-26 11:36:26 --> Language Class Initialized
INFO - 2016-09-26 11:36:26 --> Language Class Initialized
INFO - 2016-09-26 11:36:26 --> Config Class Initialized
INFO - 2016-09-26 11:36:26 --> Loader Class Initialized
INFO - 2016-09-26 11:36:26 --> Helper loaded: url_helper
INFO - 2016-09-26 11:36:26 --> Database Driver Class Initialized
INFO - 2016-09-26 11:36:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:36:26 --> Controller Class Initialized
DEBUG - 2016-09-26 11:36:26 --> login MX_Controller Initialized
INFO - 2016-09-26 11:36:26 --> Model Class Initialized
INFO - 2016-09-26 11:36:26 --> Model Class Initialized
INFO - 2016-09-26 11:36:26 --> Final output sent to browser
DEBUG - 2016-09-26 11:36:26 --> Total execution time: 0.0351
INFO - 2016-09-26 11:36:27 --> Config Class Initialized
INFO - 2016-09-26 11:36:27 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:36:27 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:36:27 --> Utf8 Class Initialized
INFO - 2016-09-26 11:36:27 --> URI Class Initialized
INFO - 2016-09-26 11:36:27 --> Router Class Initialized
INFO - 2016-09-26 11:36:27 --> Output Class Initialized
INFO - 2016-09-26 11:36:27 --> Security Class Initialized
DEBUG - 2016-09-26 11:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:36:27 --> Input Class Initialized
INFO - 2016-09-26 11:36:27 --> Language Class Initialized
INFO - 2016-09-26 11:36:27 --> Language Class Initialized
INFO - 2016-09-26 11:36:27 --> Config Class Initialized
INFO - 2016-09-26 11:36:27 --> Loader Class Initialized
INFO - 2016-09-26 11:36:27 --> Helper loaded: url_helper
INFO - 2016-09-26 11:36:27 --> Database Driver Class Initialized
INFO - 2016-09-26 11:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:36:27 --> Controller Class Initialized
DEBUG - 2016-09-26 11:36:27 --> login MX_Controller Initialized
INFO - 2016-09-26 11:36:27 --> Model Class Initialized
INFO - 2016-09-26 11:36:27 --> Model Class Initialized
INFO - 2016-09-26 11:36:27 --> Final output sent to browser
DEBUG - 2016-09-26 11:36:27 --> Total execution time: 0.0239
INFO - 2016-09-26 11:36:27 --> Config Class Initialized
INFO - 2016-09-26 11:36:27 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:36:27 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:36:27 --> Utf8 Class Initialized
INFO - 2016-09-26 11:36:27 --> URI Class Initialized
INFO - 2016-09-26 11:36:27 --> Router Class Initialized
INFO - 2016-09-26 11:36:27 --> Output Class Initialized
INFO - 2016-09-26 11:36:27 --> Security Class Initialized
DEBUG - 2016-09-26 11:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:36:27 --> Input Class Initialized
INFO - 2016-09-26 11:36:27 --> Language Class Initialized
INFO - 2016-09-26 11:36:27 --> Language Class Initialized
INFO - 2016-09-26 11:36:27 --> Config Class Initialized
INFO - 2016-09-26 11:36:27 --> Loader Class Initialized
INFO - 2016-09-26 11:36:27 --> Helper loaded: url_helper
INFO - 2016-09-26 11:36:27 --> Database Driver Class Initialized
INFO - 2016-09-26 11:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:36:27 --> Controller Class Initialized
DEBUG - 2016-09-26 11:36:27 --> login MX_Controller Initialized
INFO - 2016-09-26 11:36:27 --> Model Class Initialized
INFO - 2016-09-26 11:36:27 --> Model Class Initialized
INFO - 2016-09-26 11:36:27 --> Final output sent to browser
DEBUG - 2016-09-26 11:36:27 --> Total execution time: 0.0228
INFO - 2016-09-26 11:36:27 --> Config Class Initialized
INFO - 2016-09-26 11:36:27 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:36:27 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:36:27 --> Utf8 Class Initialized
INFO - 2016-09-26 11:36:27 --> URI Class Initialized
INFO - 2016-09-26 11:36:27 --> Router Class Initialized
INFO - 2016-09-26 11:36:27 --> Output Class Initialized
INFO - 2016-09-26 11:36:27 --> Security Class Initialized
DEBUG - 2016-09-26 11:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:36:27 --> Input Class Initialized
INFO - 2016-09-26 11:36:27 --> Language Class Initialized
INFO - 2016-09-26 11:36:27 --> Language Class Initialized
INFO - 2016-09-26 11:36:27 --> Config Class Initialized
INFO - 2016-09-26 11:36:27 --> Loader Class Initialized
INFO - 2016-09-26 11:36:27 --> Helper loaded: url_helper
INFO - 2016-09-26 11:36:27 --> Database Driver Class Initialized
INFO - 2016-09-26 11:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:36:27 --> Controller Class Initialized
DEBUG - 2016-09-26 11:36:27 --> login MX_Controller Initialized
INFO - 2016-09-26 11:36:27 --> Model Class Initialized
INFO - 2016-09-26 11:36:27 --> Model Class Initialized
INFO - 2016-09-26 11:36:27 --> Final output sent to browser
DEBUG - 2016-09-26 11:36:27 --> Total execution time: 0.0276
INFO - 2016-09-26 11:36:28 --> Config Class Initialized
INFO - 2016-09-26 11:36:28 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:36:28 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:36:28 --> Utf8 Class Initialized
INFO - 2016-09-26 11:36:28 --> URI Class Initialized
INFO - 2016-09-26 11:36:28 --> Router Class Initialized
INFO - 2016-09-26 11:36:28 --> Output Class Initialized
INFO - 2016-09-26 11:36:28 --> Security Class Initialized
DEBUG - 2016-09-26 11:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:36:28 --> Input Class Initialized
INFO - 2016-09-26 11:36:28 --> Language Class Initialized
INFO - 2016-09-26 11:36:28 --> Language Class Initialized
INFO - 2016-09-26 11:36:28 --> Config Class Initialized
INFO - 2016-09-26 11:36:28 --> Loader Class Initialized
INFO - 2016-09-26 11:36:28 --> Helper loaded: url_helper
INFO - 2016-09-26 11:36:28 --> Database Driver Class Initialized
INFO - 2016-09-26 11:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:36:28 --> Controller Class Initialized
DEBUG - 2016-09-26 11:36:28 --> login MX_Controller Initialized
INFO - 2016-09-26 11:36:28 --> Model Class Initialized
INFO - 2016-09-26 11:36:28 --> Model Class Initialized
INFO - 2016-09-26 11:36:28 --> Final output sent to browser
DEBUG - 2016-09-26 11:36:28 --> Total execution time: 0.0279
INFO - 2016-09-26 11:36:28 --> Config Class Initialized
INFO - 2016-09-26 11:36:28 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:36:28 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:36:28 --> Utf8 Class Initialized
INFO - 2016-09-26 11:36:28 --> URI Class Initialized
INFO - 2016-09-26 11:36:28 --> Router Class Initialized
INFO - 2016-09-26 11:36:28 --> Output Class Initialized
INFO - 2016-09-26 11:36:28 --> Security Class Initialized
DEBUG - 2016-09-26 11:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:36:28 --> Input Class Initialized
INFO - 2016-09-26 11:36:28 --> Language Class Initialized
INFO - 2016-09-26 11:36:28 --> Language Class Initialized
INFO - 2016-09-26 11:36:28 --> Config Class Initialized
INFO - 2016-09-26 11:36:28 --> Loader Class Initialized
INFO - 2016-09-26 11:36:28 --> Helper loaded: url_helper
INFO - 2016-09-26 11:36:28 --> Database Driver Class Initialized
INFO - 2016-09-26 11:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:36:28 --> Controller Class Initialized
DEBUG - 2016-09-26 11:36:28 --> login MX_Controller Initialized
INFO - 2016-09-26 11:36:28 --> Model Class Initialized
INFO - 2016-09-26 11:36:28 --> Model Class Initialized
INFO - 2016-09-26 11:36:28 --> Final output sent to browser
DEBUG - 2016-09-26 11:36:28 --> Total execution time: 0.0246
INFO - 2016-09-26 11:36:28 --> Config Class Initialized
INFO - 2016-09-26 11:36:28 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:36:28 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:36:28 --> Utf8 Class Initialized
INFO - 2016-09-26 11:36:28 --> URI Class Initialized
INFO - 2016-09-26 11:36:28 --> Router Class Initialized
INFO - 2016-09-26 11:36:28 --> Output Class Initialized
INFO - 2016-09-26 11:36:28 --> Security Class Initialized
DEBUG - 2016-09-26 11:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:36:28 --> Input Class Initialized
INFO - 2016-09-26 11:36:28 --> Language Class Initialized
INFO - 2016-09-26 11:36:28 --> Language Class Initialized
INFO - 2016-09-26 11:36:28 --> Config Class Initialized
INFO - 2016-09-26 11:36:28 --> Loader Class Initialized
INFO - 2016-09-26 11:36:28 --> Helper loaded: url_helper
INFO - 2016-09-26 11:36:28 --> Database Driver Class Initialized
INFO - 2016-09-26 11:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:36:28 --> Controller Class Initialized
DEBUG - 2016-09-26 11:36:28 --> login MX_Controller Initialized
INFO - 2016-09-26 11:36:28 --> Model Class Initialized
INFO - 2016-09-26 11:36:28 --> Model Class Initialized
INFO - 2016-09-26 11:36:28 --> Final output sent to browser
DEBUG - 2016-09-26 11:36:28 --> Total execution time: 0.0225
INFO - 2016-09-26 11:36:28 --> Config Class Initialized
INFO - 2016-09-26 11:36:28 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:36:28 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:36:28 --> Utf8 Class Initialized
INFO - 2016-09-26 11:36:28 --> URI Class Initialized
INFO - 2016-09-26 11:36:28 --> Router Class Initialized
INFO - 2016-09-26 11:36:28 --> Output Class Initialized
INFO - 2016-09-26 11:36:28 --> Security Class Initialized
DEBUG - 2016-09-26 11:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:36:28 --> Input Class Initialized
INFO - 2016-09-26 11:36:28 --> Language Class Initialized
INFO - 2016-09-26 11:36:28 --> Language Class Initialized
INFO - 2016-09-26 11:36:28 --> Config Class Initialized
INFO - 2016-09-26 11:36:28 --> Loader Class Initialized
INFO - 2016-09-26 11:36:28 --> Helper loaded: url_helper
INFO - 2016-09-26 11:36:28 --> Database Driver Class Initialized
INFO - 2016-09-26 11:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:36:28 --> Controller Class Initialized
DEBUG - 2016-09-26 11:36:28 --> login MX_Controller Initialized
INFO - 2016-09-26 11:36:28 --> Model Class Initialized
INFO - 2016-09-26 11:36:28 --> Model Class Initialized
INFO - 2016-09-26 11:36:28 --> Final output sent to browser
DEBUG - 2016-09-26 11:36:28 --> Total execution time: 0.0241
INFO - 2016-09-26 11:36:28 --> Config Class Initialized
INFO - 2016-09-26 11:36:28 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:36:28 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:36:28 --> Utf8 Class Initialized
INFO - 2016-09-26 11:36:28 --> URI Class Initialized
INFO - 2016-09-26 11:36:28 --> Router Class Initialized
INFO - 2016-09-26 11:36:28 --> Output Class Initialized
INFO - 2016-09-26 11:36:28 --> Security Class Initialized
DEBUG - 2016-09-26 11:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:36:28 --> Input Class Initialized
INFO - 2016-09-26 11:36:28 --> Language Class Initialized
INFO - 2016-09-26 11:36:28 --> Language Class Initialized
INFO - 2016-09-26 11:36:28 --> Config Class Initialized
INFO - 2016-09-26 11:36:28 --> Loader Class Initialized
INFO - 2016-09-26 11:36:28 --> Helper loaded: url_helper
INFO - 2016-09-26 11:36:28 --> Database Driver Class Initialized
INFO - 2016-09-26 11:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:36:28 --> Controller Class Initialized
DEBUG - 2016-09-26 11:36:28 --> login MX_Controller Initialized
INFO - 2016-09-26 11:36:28 --> Model Class Initialized
INFO - 2016-09-26 11:36:28 --> Model Class Initialized
INFO - 2016-09-26 11:36:28 --> Final output sent to browser
DEBUG - 2016-09-26 11:36:28 --> Total execution time: 0.0248
INFO - 2016-09-26 11:36:28 --> Config Class Initialized
INFO - 2016-09-26 11:36:28 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:36:28 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:36:28 --> Utf8 Class Initialized
INFO - 2016-09-26 11:36:28 --> URI Class Initialized
INFO - 2016-09-26 11:36:28 --> Router Class Initialized
INFO - 2016-09-26 11:36:28 --> Output Class Initialized
INFO - 2016-09-26 11:36:28 --> Security Class Initialized
DEBUG - 2016-09-26 11:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:36:28 --> Input Class Initialized
INFO - 2016-09-26 11:36:28 --> Language Class Initialized
INFO - 2016-09-26 11:36:28 --> Language Class Initialized
INFO - 2016-09-26 11:36:28 --> Config Class Initialized
INFO - 2016-09-26 11:36:28 --> Loader Class Initialized
INFO - 2016-09-26 11:36:28 --> Helper loaded: url_helper
INFO - 2016-09-26 11:36:28 --> Database Driver Class Initialized
INFO - 2016-09-26 11:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:36:28 --> Controller Class Initialized
DEBUG - 2016-09-26 11:36:28 --> login MX_Controller Initialized
INFO - 2016-09-26 11:36:28 --> Model Class Initialized
INFO - 2016-09-26 11:36:28 --> Model Class Initialized
INFO - 2016-09-26 11:36:28 --> Final output sent to browser
DEBUG - 2016-09-26 11:36:28 --> Total execution time: 0.0239
INFO - 2016-09-26 11:36:28 --> Config Class Initialized
INFO - 2016-09-26 11:36:28 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:36:28 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:36:28 --> Utf8 Class Initialized
INFO - 2016-09-26 11:36:28 --> URI Class Initialized
INFO - 2016-09-26 11:36:28 --> Router Class Initialized
INFO - 2016-09-26 11:36:28 --> Output Class Initialized
INFO - 2016-09-26 11:36:28 --> Security Class Initialized
DEBUG - 2016-09-26 11:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:36:28 --> Input Class Initialized
INFO - 2016-09-26 11:36:28 --> Language Class Initialized
INFO - 2016-09-26 11:36:28 --> Language Class Initialized
INFO - 2016-09-26 11:36:28 --> Config Class Initialized
INFO - 2016-09-26 11:36:28 --> Loader Class Initialized
INFO - 2016-09-26 11:36:28 --> Helper loaded: url_helper
INFO - 2016-09-26 11:36:28 --> Database Driver Class Initialized
INFO - 2016-09-26 11:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:36:28 --> Controller Class Initialized
DEBUG - 2016-09-26 11:36:28 --> login MX_Controller Initialized
INFO - 2016-09-26 11:36:28 --> Model Class Initialized
INFO - 2016-09-26 11:36:28 --> Model Class Initialized
INFO - 2016-09-26 11:36:28 --> Final output sent to browser
DEBUG - 2016-09-26 11:36:28 --> Total execution time: 0.0234
INFO - 2016-09-26 11:36:28 --> Config Class Initialized
INFO - 2016-09-26 11:36:28 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:36:28 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:36:28 --> Utf8 Class Initialized
INFO - 2016-09-26 11:36:28 --> URI Class Initialized
INFO - 2016-09-26 11:36:28 --> Router Class Initialized
INFO - 2016-09-26 11:36:28 --> Output Class Initialized
INFO - 2016-09-26 11:36:28 --> Security Class Initialized
DEBUG - 2016-09-26 11:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:36:28 --> Input Class Initialized
INFO - 2016-09-26 11:36:28 --> Language Class Initialized
INFO - 2016-09-26 11:36:28 --> Language Class Initialized
INFO - 2016-09-26 11:36:28 --> Config Class Initialized
INFO - 2016-09-26 11:36:28 --> Loader Class Initialized
INFO - 2016-09-26 11:36:28 --> Helper loaded: url_helper
INFO - 2016-09-26 11:36:28 --> Database Driver Class Initialized
INFO - 2016-09-26 11:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:36:28 --> Controller Class Initialized
DEBUG - 2016-09-26 11:36:28 --> login MX_Controller Initialized
INFO - 2016-09-26 11:36:28 --> Model Class Initialized
INFO - 2016-09-26 11:36:28 --> Model Class Initialized
INFO - 2016-09-26 11:36:28 --> Final output sent to browser
DEBUG - 2016-09-26 11:36:28 --> Total execution time: 0.0246
INFO - 2016-09-26 11:36:29 --> Config Class Initialized
INFO - 2016-09-26 11:36:29 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:36:29 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:36:29 --> Utf8 Class Initialized
INFO - 2016-09-26 11:36:29 --> URI Class Initialized
INFO - 2016-09-26 11:36:29 --> Router Class Initialized
INFO - 2016-09-26 11:36:29 --> Output Class Initialized
INFO - 2016-09-26 11:36:29 --> Security Class Initialized
DEBUG - 2016-09-26 11:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:36:29 --> Input Class Initialized
INFO - 2016-09-26 11:36:29 --> Language Class Initialized
INFO - 2016-09-26 11:36:29 --> Language Class Initialized
INFO - 2016-09-26 11:36:29 --> Config Class Initialized
INFO - 2016-09-26 11:36:29 --> Loader Class Initialized
INFO - 2016-09-26 11:36:29 --> Helper loaded: url_helper
INFO - 2016-09-26 11:36:29 --> Database Driver Class Initialized
INFO - 2016-09-26 11:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:36:29 --> Controller Class Initialized
DEBUG - 2016-09-26 11:36:29 --> login MX_Controller Initialized
INFO - 2016-09-26 11:36:29 --> Model Class Initialized
INFO - 2016-09-26 11:36:29 --> Model Class Initialized
INFO - 2016-09-26 11:36:29 --> Final output sent to browser
DEBUG - 2016-09-26 11:36:29 --> Total execution time: 0.0340
INFO - 2016-09-26 11:36:29 --> Config Class Initialized
INFO - 2016-09-26 11:36:29 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:36:29 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:36:29 --> Utf8 Class Initialized
INFO - 2016-09-26 11:36:29 --> URI Class Initialized
INFO - 2016-09-26 11:36:29 --> Router Class Initialized
INFO - 2016-09-26 11:36:29 --> Output Class Initialized
INFO - 2016-09-26 11:36:29 --> Security Class Initialized
DEBUG - 2016-09-26 11:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:36:29 --> Input Class Initialized
INFO - 2016-09-26 11:36:29 --> Language Class Initialized
INFO - 2016-09-26 11:36:29 --> Language Class Initialized
INFO - 2016-09-26 11:36:29 --> Config Class Initialized
INFO - 2016-09-26 11:36:29 --> Loader Class Initialized
INFO - 2016-09-26 11:36:29 --> Helper loaded: url_helper
INFO - 2016-09-26 11:36:29 --> Database Driver Class Initialized
INFO - 2016-09-26 11:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:36:29 --> Controller Class Initialized
DEBUG - 2016-09-26 11:36:29 --> login MX_Controller Initialized
INFO - 2016-09-26 11:36:29 --> Model Class Initialized
INFO - 2016-09-26 11:36:29 --> Model Class Initialized
INFO - 2016-09-26 11:36:29 --> Final output sent to browser
DEBUG - 2016-09-26 11:36:29 --> Total execution time: 0.0294
INFO - 2016-09-26 11:36:59 --> Config Class Initialized
INFO - 2016-09-26 11:36:59 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:36:59 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:36:59 --> Utf8 Class Initialized
INFO - 2016-09-26 11:36:59 --> URI Class Initialized
INFO - 2016-09-26 11:36:59 --> Router Class Initialized
INFO - 2016-09-26 11:36:59 --> Output Class Initialized
INFO - 2016-09-26 11:36:59 --> Security Class Initialized
DEBUG - 2016-09-26 11:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:36:59 --> Input Class Initialized
INFO - 2016-09-26 11:36:59 --> Language Class Initialized
INFO - 2016-09-26 11:36:59 --> Language Class Initialized
INFO - 2016-09-26 11:36:59 --> Config Class Initialized
INFO - 2016-09-26 11:36:59 --> Loader Class Initialized
INFO - 2016-09-26 11:36:59 --> Helper loaded: url_helper
INFO - 2016-09-26 11:36:59 --> Database Driver Class Initialized
INFO - 2016-09-26 11:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:36:59 --> Controller Class Initialized
DEBUG - 2016-09-26 11:36:59 --> login MX_Controller Initialized
INFO - 2016-09-26 11:36:59 --> Model Class Initialized
INFO - 2016-09-26 11:36:59 --> Model Class Initialized
INFO - 2016-09-26 11:36:59 --> Final output sent to browser
DEBUG - 2016-09-26 11:36:59 --> Total execution time: 0.0382
INFO - 2016-09-26 11:36:59 --> Config Class Initialized
INFO - 2016-09-26 11:36:59 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:36:59 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:36:59 --> Utf8 Class Initialized
INFO - 2016-09-26 11:36:59 --> URI Class Initialized
INFO - 2016-09-26 11:36:59 --> Router Class Initialized
INFO - 2016-09-26 11:36:59 --> Output Class Initialized
INFO - 2016-09-26 11:36:59 --> Security Class Initialized
DEBUG - 2016-09-26 11:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:36:59 --> Input Class Initialized
INFO - 2016-09-26 11:36:59 --> Language Class Initialized
INFO - 2016-09-26 11:36:59 --> Language Class Initialized
INFO - 2016-09-26 11:36:59 --> Config Class Initialized
INFO - 2016-09-26 11:36:59 --> Loader Class Initialized
INFO - 2016-09-26 11:36:59 --> Helper loaded: url_helper
INFO - 2016-09-26 11:36:59 --> Database Driver Class Initialized
INFO - 2016-09-26 11:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:36:59 --> Controller Class Initialized
DEBUG - 2016-09-26 11:36:59 --> login MX_Controller Initialized
INFO - 2016-09-26 11:36:59 --> Model Class Initialized
INFO - 2016-09-26 11:36:59 --> Model Class Initialized
INFO - 2016-09-26 11:36:59 --> Final output sent to browser
DEBUG - 2016-09-26 11:36:59 --> Total execution time: 0.0425
INFO - 2016-09-26 11:36:59 --> Config Class Initialized
INFO - 2016-09-26 11:36:59 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:36:59 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:36:59 --> Utf8 Class Initialized
INFO - 2016-09-26 11:36:59 --> URI Class Initialized
INFO - 2016-09-26 11:36:59 --> Router Class Initialized
INFO - 2016-09-26 11:36:59 --> Output Class Initialized
INFO - 2016-09-26 11:37:00 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:00 --> Input Class Initialized
INFO - 2016-09-26 11:37:00 --> Language Class Initialized
INFO - 2016-09-26 11:37:00 --> Language Class Initialized
INFO - 2016-09-26 11:37:00 --> Config Class Initialized
INFO - 2016-09-26 11:37:00 --> Loader Class Initialized
INFO - 2016-09-26 11:37:00 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:00 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:00 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:00 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:00 --> Model Class Initialized
INFO - 2016-09-26 11:37:00 --> Model Class Initialized
INFO - 2016-09-26 11:37:00 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:00 --> Total execution time: 0.0346
INFO - 2016-09-26 11:37:00 --> Config Class Initialized
INFO - 2016-09-26 11:37:00 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:00 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:00 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:00 --> URI Class Initialized
INFO - 2016-09-26 11:37:00 --> Router Class Initialized
INFO - 2016-09-26 11:37:00 --> Output Class Initialized
INFO - 2016-09-26 11:37:00 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:00 --> Input Class Initialized
INFO - 2016-09-26 11:37:00 --> Language Class Initialized
INFO - 2016-09-26 11:37:00 --> Language Class Initialized
INFO - 2016-09-26 11:37:00 --> Config Class Initialized
INFO - 2016-09-26 11:37:00 --> Loader Class Initialized
INFO - 2016-09-26 11:37:00 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:00 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:00 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:00 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:00 --> Model Class Initialized
INFO - 2016-09-26 11:37:00 --> Model Class Initialized
INFO - 2016-09-26 11:37:00 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:00 --> Total execution time: 0.0255
INFO - 2016-09-26 11:37:00 --> Config Class Initialized
INFO - 2016-09-26 11:37:00 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:00 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:00 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:00 --> URI Class Initialized
INFO - 2016-09-26 11:37:00 --> Router Class Initialized
INFO - 2016-09-26 11:37:00 --> Output Class Initialized
INFO - 2016-09-26 11:37:00 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:00 --> Input Class Initialized
INFO - 2016-09-26 11:37:00 --> Language Class Initialized
INFO - 2016-09-26 11:37:00 --> Language Class Initialized
INFO - 2016-09-26 11:37:00 --> Config Class Initialized
INFO - 2016-09-26 11:37:00 --> Loader Class Initialized
INFO - 2016-09-26 11:37:00 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:00 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:00 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:00 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:00 --> Model Class Initialized
INFO - 2016-09-26 11:37:00 --> Model Class Initialized
INFO - 2016-09-26 11:37:00 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:00 --> Total execution time: 0.0358
INFO - 2016-09-26 11:37:00 --> Config Class Initialized
INFO - 2016-09-26 11:37:00 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:00 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:00 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:00 --> URI Class Initialized
INFO - 2016-09-26 11:37:00 --> Router Class Initialized
INFO - 2016-09-26 11:37:00 --> Output Class Initialized
INFO - 2016-09-26 11:37:00 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:00 --> Input Class Initialized
INFO - 2016-09-26 11:37:00 --> Language Class Initialized
INFO - 2016-09-26 11:37:00 --> Language Class Initialized
INFO - 2016-09-26 11:37:00 --> Config Class Initialized
INFO - 2016-09-26 11:37:00 --> Loader Class Initialized
INFO - 2016-09-26 11:37:00 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:00 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:00 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:00 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:00 --> Model Class Initialized
INFO - 2016-09-26 11:37:00 --> Model Class Initialized
INFO - 2016-09-26 11:37:00 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:00 --> Total execution time: 0.0259
INFO - 2016-09-26 11:37:00 --> Config Class Initialized
INFO - 2016-09-26 11:37:00 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:00 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:00 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:00 --> URI Class Initialized
INFO - 2016-09-26 11:37:00 --> Router Class Initialized
INFO - 2016-09-26 11:37:00 --> Output Class Initialized
INFO - 2016-09-26 11:37:00 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:00 --> Input Class Initialized
INFO - 2016-09-26 11:37:00 --> Language Class Initialized
INFO - 2016-09-26 11:37:00 --> Language Class Initialized
INFO - 2016-09-26 11:37:00 --> Config Class Initialized
INFO - 2016-09-26 11:37:00 --> Loader Class Initialized
INFO - 2016-09-26 11:37:00 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:00 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:00 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:00 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:00 --> Model Class Initialized
INFO - 2016-09-26 11:37:00 --> Model Class Initialized
INFO - 2016-09-26 11:37:00 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:00 --> Total execution time: 0.0359
INFO - 2016-09-26 11:37:00 --> Config Class Initialized
INFO - 2016-09-26 11:37:00 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:00 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:00 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:00 --> URI Class Initialized
INFO - 2016-09-26 11:37:00 --> Router Class Initialized
INFO - 2016-09-26 11:37:00 --> Output Class Initialized
INFO - 2016-09-26 11:37:00 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:00 --> Input Class Initialized
INFO - 2016-09-26 11:37:00 --> Language Class Initialized
INFO - 2016-09-26 11:37:00 --> Language Class Initialized
INFO - 2016-09-26 11:37:00 --> Config Class Initialized
INFO - 2016-09-26 11:37:00 --> Loader Class Initialized
INFO - 2016-09-26 11:37:00 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:00 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:00 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:00 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:00 --> Model Class Initialized
INFO - 2016-09-26 11:37:00 --> Model Class Initialized
INFO - 2016-09-26 11:37:00 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:00 --> Total execution time: 0.0266
INFO - 2016-09-26 11:37:01 --> Config Class Initialized
INFO - 2016-09-26 11:37:01 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:01 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:01 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:01 --> URI Class Initialized
INFO - 2016-09-26 11:37:01 --> Router Class Initialized
INFO - 2016-09-26 11:37:01 --> Output Class Initialized
INFO - 2016-09-26 11:37:01 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:01 --> Input Class Initialized
INFO - 2016-09-26 11:37:01 --> Language Class Initialized
INFO - 2016-09-26 11:37:01 --> Language Class Initialized
INFO - 2016-09-26 11:37:01 --> Config Class Initialized
INFO - 2016-09-26 11:37:01 --> Loader Class Initialized
INFO - 2016-09-26 11:37:01 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:01 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:01 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:01 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:01 --> Model Class Initialized
INFO - 2016-09-26 11:37:01 --> Model Class Initialized
INFO - 2016-09-26 11:37:01 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:01 --> Total execution time: 0.0324
INFO - 2016-09-26 11:37:01 --> Config Class Initialized
INFO - 2016-09-26 11:37:01 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:01 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:01 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:01 --> URI Class Initialized
INFO - 2016-09-26 11:37:01 --> Router Class Initialized
INFO - 2016-09-26 11:37:01 --> Output Class Initialized
INFO - 2016-09-26 11:37:01 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:01 --> Input Class Initialized
INFO - 2016-09-26 11:37:01 --> Language Class Initialized
INFO - 2016-09-26 11:37:01 --> Language Class Initialized
INFO - 2016-09-26 11:37:01 --> Config Class Initialized
INFO - 2016-09-26 11:37:01 --> Loader Class Initialized
INFO - 2016-09-26 11:37:01 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:01 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:01 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:01 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:01 --> Model Class Initialized
INFO - 2016-09-26 11:37:01 --> Model Class Initialized
INFO - 2016-09-26 11:37:01 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:01 --> Total execution time: 0.0276
INFO - 2016-09-26 11:37:01 --> Config Class Initialized
INFO - 2016-09-26 11:37:01 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:01 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:01 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:01 --> URI Class Initialized
INFO - 2016-09-26 11:37:01 --> Router Class Initialized
INFO - 2016-09-26 11:37:01 --> Output Class Initialized
INFO - 2016-09-26 11:37:01 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:01 --> Input Class Initialized
INFO - 2016-09-26 11:37:01 --> Language Class Initialized
INFO - 2016-09-26 11:37:01 --> Language Class Initialized
INFO - 2016-09-26 11:37:01 --> Config Class Initialized
INFO - 2016-09-26 11:37:01 --> Loader Class Initialized
INFO - 2016-09-26 11:37:01 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:01 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:01 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:01 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:01 --> Model Class Initialized
INFO - 2016-09-26 11:37:01 --> Model Class Initialized
INFO - 2016-09-26 11:37:01 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:01 --> Total execution time: 0.0249
INFO - 2016-09-26 11:37:01 --> Config Class Initialized
INFO - 2016-09-26 11:37:01 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:01 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:01 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:01 --> URI Class Initialized
INFO - 2016-09-26 11:37:01 --> Router Class Initialized
INFO - 2016-09-26 11:37:01 --> Output Class Initialized
INFO - 2016-09-26 11:37:01 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:01 --> Input Class Initialized
INFO - 2016-09-26 11:37:01 --> Language Class Initialized
INFO - 2016-09-26 11:37:01 --> Language Class Initialized
INFO - 2016-09-26 11:37:01 --> Config Class Initialized
INFO - 2016-09-26 11:37:01 --> Loader Class Initialized
INFO - 2016-09-26 11:37:01 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:01 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:01 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:01 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:01 --> Model Class Initialized
INFO - 2016-09-26 11:37:01 --> Model Class Initialized
INFO - 2016-09-26 11:37:01 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:01 --> Total execution time: 0.0377
INFO - 2016-09-26 11:37:01 --> Config Class Initialized
INFO - 2016-09-26 11:37:01 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:01 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:01 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:01 --> URI Class Initialized
INFO - 2016-09-26 11:37:01 --> Router Class Initialized
INFO - 2016-09-26 11:37:01 --> Output Class Initialized
INFO - 2016-09-26 11:37:01 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:01 --> Input Class Initialized
INFO - 2016-09-26 11:37:01 --> Language Class Initialized
INFO - 2016-09-26 11:37:01 --> Language Class Initialized
INFO - 2016-09-26 11:37:01 --> Config Class Initialized
INFO - 2016-09-26 11:37:01 --> Loader Class Initialized
INFO - 2016-09-26 11:37:01 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:01 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:01 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:01 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:01 --> Model Class Initialized
INFO - 2016-09-26 11:37:01 --> Model Class Initialized
INFO - 2016-09-26 11:37:01 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:01 --> Total execution time: 0.0434
INFO - 2016-09-26 11:37:01 --> Config Class Initialized
INFO - 2016-09-26 11:37:01 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:01 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:01 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:01 --> URI Class Initialized
INFO - 2016-09-26 11:37:01 --> Router Class Initialized
INFO - 2016-09-26 11:37:01 --> Output Class Initialized
INFO - 2016-09-26 11:37:01 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:01 --> Input Class Initialized
INFO - 2016-09-26 11:37:01 --> Language Class Initialized
INFO - 2016-09-26 11:37:01 --> Language Class Initialized
INFO - 2016-09-26 11:37:01 --> Config Class Initialized
INFO - 2016-09-26 11:37:01 --> Loader Class Initialized
INFO - 2016-09-26 11:37:01 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:01 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:01 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:01 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:01 --> Model Class Initialized
INFO - 2016-09-26 11:37:01 --> Model Class Initialized
INFO - 2016-09-26 11:37:01 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:01 --> Total execution time: 0.0581
INFO - 2016-09-26 11:37:02 --> Config Class Initialized
INFO - 2016-09-26 11:37:02 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:02 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:02 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:02 --> URI Class Initialized
INFO - 2016-09-26 11:37:02 --> Router Class Initialized
INFO - 2016-09-26 11:37:02 --> Output Class Initialized
INFO - 2016-09-26 11:37:02 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:02 --> Input Class Initialized
INFO - 2016-09-26 11:37:02 --> Language Class Initialized
INFO - 2016-09-26 11:37:02 --> Language Class Initialized
INFO - 2016-09-26 11:37:02 --> Config Class Initialized
INFO - 2016-09-26 11:37:02 --> Loader Class Initialized
INFO - 2016-09-26 11:37:02 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:02 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:02 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:02 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:02 --> Model Class Initialized
INFO - 2016-09-26 11:37:02 --> Model Class Initialized
INFO - 2016-09-26 11:37:02 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:02 --> Total execution time: 0.0280
INFO - 2016-09-26 11:37:02 --> Config Class Initialized
INFO - 2016-09-26 11:37:02 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:02 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:02 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:02 --> URI Class Initialized
INFO - 2016-09-26 11:37:02 --> Router Class Initialized
INFO - 2016-09-26 11:37:02 --> Output Class Initialized
INFO - 2016-09-26 11:37:02 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:02 --> Input Class Initialized
INFO - 2016-09-26 11:37:02 --> Language Class Initialized
INFO - 2016-09-26 11:37:02 --> Language Class Initialized
INFO - 2016-09-26 11:37:02 --> Config Class Initialized
INFO - 2016-09-26 11:37:02 --> Loader Class Initialized
INFO - 2016-09-26 11:37:02 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:02 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:02 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:02 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:02 --> Model Class Initialized
INFO - 2016-09-26 11:37:02 --> Model Class Initialized
INFO - 2016-09-26 11:37:02 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:02 --> Total execution time: 0.0297
INFO - 2016-09-26 11:37:02 --> Config Class Initialized
INFO - 2016-09-26 11:37:02 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:02 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:02 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:02 --> URI Class Initialized
INFO - 2016-09-26 11:37:02 --> Router Class Initialized
INFO - 2016-09-26 11:37:02 --> Output Class Initialized
INFO - 2016-09-26 11:37:02 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:02 --> Input Class Initialized
INFO - 2016-09-26 11:37:02 --> Language Class Initialized
INFO - 2016-09-26 11:37:02 --> Language Class Initialized
INFO - 2016-09-26 11:37:02 --> Config Class Initialized
INFO - 2016-09-26 11:37:02 --> Loader Class Initialized
INFO - 2016-09-26 11:37:02 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:02 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:02 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:02 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:02 --> Model Class Initialized
INFO - 2016-09-26 11:37:02 --> Model Class Initialized
INFO - 2016-09-26 11:37:02 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:02 --> Total execution time: 0.0459
INFO - 2016-09-26 11:37:03 --> Config Class Initialized
INFO - 2016-09-26 11:37:03 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:03 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:03 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:03 --> URI Class Initialized
INFO - 2016-09-26 11:37:03 --> Router Class Initialized
INFO - 2016-09-26 11:37:03 --> Output Class Initialized
INFO - 2016-09-26 11:37:03 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:03 --> Input Class Initialized
INFO - 2016-09-26 11:37:03 --> Language Class Initialized
INFO - 2016-09-26 11:37:03 --> Language Class Initialized
INFO - 2016-09-26 11:37:03 --> Config Class Initialized
INFO - 2016-09-26 11:37:03 --> Loader Class Initialized
INFO - 2016-09-26 11:37:03 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:03 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:03 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:03 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:03 --> Model Class Initialized
INFO - 2016-09-26 11:37:03 --> Model Class Initialized
INFO - 2016-09-26 11:37:03 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:03 --> Total execution time: 0.0338
INFO - 2016-09-26 11:37:03 --> Config Class Initialized
INFO - 2016-09-26 11:37:03 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:03 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:03 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:03 --> URI Class Initialized
INFO - 2016-09-26 11:37:03 --> Router Class Initialized
INFO - 2016-09-26 11:37:03 --> Output Class Initialized
INFO - 2016-09-26 11:37:03 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:03 --> Input Class Initialized
INFO - 2016-09-26 11:37:03 --> Language Class Initialized
INFO - 2016-09-26 11:37:03 --> Language Class Initialized
INFO - 2016-09-26 11:37:03 --> Config Class Initialized
INFO - 2016-09-26 11:37:03 --> Loader Class Initialized
INFO - 2016-09-26 11:37:03 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:03 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:03 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:03 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:03 --> Model Class Initialized
INFO - 2016-09-26 11:37:03 --> Model Class Initialized
INFO - 2016-09-26 11:37:03 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:03 --> Total execution time: 0.0292
INFO - 2016-09-26 11:37:03 --> Config Class Initialized
INFO - 2016-09-26 11:37:03 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:03 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:03 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:03 --> URI Class Initialized
INFO - 2016-09-26 11:37:03 --> Router Class Initialized
INFO - 2016-09-26 11:37:03 --> Output Class Initialized
INFO - 2016-09-26 11:37:03 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:03 --> Input Class Initialized
INFO - 2016-09-26 11:37:03 --> Language Class Initialized
INFO - 2016-09-26 11:37:03 --> Language Class Initialized
INFO - 2016-09-26 11:37:03 --> Config Class Initialized
INFO - 2016-09-26 11:37:03 --> Loader Class Initialized
INFO - 2016-09-26 11:37:03 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:03 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:03 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:03 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:03 --> Model Class Initialized
INFO - 2016-09-26 11:37:03 --> Model Class Initialized
INFO - 2016-09-26 11:37:03 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:03 --> Total execution time: 0.0258
INFO - 2016-09-26 11:37:03 --> Config Class Initialized
INFO - 2016-09-26 11:37:03 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:03 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:03 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:03 --> URI Class Initialized
INFO - 2016-09-26 11:37:03 --> Router Class Initialized
INFO - 2016-09-26 11:37:03 --> Output Class Initialized
INFO - 2016-09-26 11:37:03 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:03 --> Input Class Initialized
INFO - 2016-09-26 11:37:03 --> Language Class Initialized
INFO - 2016-09-26 11:37:03 --> Language Class Initialized
INFO - 2016-09-26 11:37:03 --> Config Class Initialized
INFO - 2016-09-26 11:37:03 --> Loader Class Initialized
INFO - 2016-09-26 11:37:03 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:03 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:03 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:03 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:03 --> Model Class Initialized
INFO - 2016-09-26 11:37:03 --> Model Class Initialized
INFO - 2016-09-26 11:37:03 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:03 --> Total execution time: 0.0353
INFO - 2016-09-26 11:37:03 --> Config Class Initialized
INFO - 2016-09-26 11:37:03 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:03 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:03 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:03 --> URI Class Initialized
INFO - 2016-09-26 11:37:03 --> Router Class Initialized
INFO - 2016-09-26 11:37:03 --> Output Class Initialized
INFO - 2016-09-26 11:37:03 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:03 --> Input Class Initialized
INFO - 2016-09-26 11:37:03 --> Language Class Initialized
INFO - 2016-09-26 11:37:03 --> Language Class Initialized
INFO - 2016-09-26 11:37:03 --> Config Class Initialized
INFO - 2016-09-26 11:37:03 --> Loader Class Initialized
INFO - 2016-09-26 11:37:03 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:03 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:03 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:03 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:03 --> Model Class Initialized
INFO - 2016-09-26 11:37:03 --> Model Class Initialized
INFO - 2016-09-26 11:37:03 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:03 --> Total execution time: 0.0261
INFO - 2016-09-26 11:37:03 --> Config Class Initialized
INFO - 2016-09-26 11:37:03 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:03 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:03 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:03 --> URI Class Initialized
INFO - 2016-09-26 11:37:03 --> Router Class Initialized
INFO - 2016-09-26 11:37:03 --> Output Class Initialized
INFO - 2016-09-26 11:37:03 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:03 --> Input Class Initialized
INFO - 2016-09-26 11:37:03 --> Language Class Initialized
INFO - 2016-09-26 11:37:03 --> Language Class Initialized
INFO - 2016-09-26 11:37:03 --> Config Class Initialized
INFO - 2016-09-26 11:37:03 --> Loader Class Initialized
INFO - 2016-09-26 11:37:03 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:03 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:03 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:03 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:03 --> Model Class Initialized
INFO - 2016-09-26 11:37:03 --> Model Class Initialized
INFO - 2016-09-26 11:37:03 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:03 --> Total execution time: 0.0250
INFO - 2016-09-26 11:37:03 --> Config Class Initialized
INFO - 2016-09-26 11:37:03 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:03 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:03 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:03 --> URI Class Initialized
INFO - 2016-09-26 11:37:03 --> Router Class Initialized
INFO - 2016-09-26 11:37:03 --> Output Class Initialized
INFO - 2016-09-26 11:37:03 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:03 --> Input Class Initialized
INFO - 2016-09-26 11:37:03 --> Language Class Initialized
INFO - 2016-09-26 11:37:03 --> Language Class Initialized
INFO - 2016-09-26 11:37:03 --> Config Class Initialized
INFO - 2016-09-26 11:37:03 --> Loader Class Initialized
INFO - 2016-09-26 11:37:03 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:03 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:03 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:03 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:03 --> Model Class Initialized
INFO - 2016-09-26 11:37:03 --> Model Class Initialized
INFO - 2016-09-26 11:37:03 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:03 --> Total execution time: 0.0369
INFO - 2016-09-26 11:37:03 --> Config Class Initialized
INFO - 2016-09-26 11:37:03 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:03 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:03 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:03 --> URI Class Initialized
INFO - 2016-09-26 11:37:03 --> Router Class Initialized
INFO - 2016-09-26 11:37:03 --> Output Class Initialized
INFO - 2016-09-26 11:37:03 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:03 --> Input Class Initialized
INFO - 2016-09-26 11:37:03 --> Language Class Initialized
INFO - 2016-09-26 11:37:03 --> Language Class Initialized
INFO - 2016-09-26 11:37:03 --> Config Class Initialized
INFO - 2016-09-26 11:37:03 --> Loader Class Initialized
INFO - 2016-09-26 11:37:03 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:04 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:04 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:04 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:04 --> Model Class Initialized
INFO - 2016-09-26 11:37:04 --> Model Class Initialized
INFO - 2016-09-26 11:37:04 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:04 --> Total execution time: 0.0482
INFO - 2016-09-26 11:37:04 --> Config Class Initialized
INFO - 2016-09-26 11:37:04 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:04 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:04 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:04 --> URI Class Initialized
INFO - 2016-09-26 11:37:04 --> Router Class Initialized
INFO - 2016-09-26 11:37:04 --> Output Class Initialized
INFO - 2016-09-26 11:37:04 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:04 --> Input Class Initialized
INFO - 2016-09-26 11:37:04 --> Language Class Initialized
INFO - 2016-09-26 11:37:04 --> Language Class Initialized
INFO - 2016-09-26 11:37:04 --> Config Class Initialized
INFO - 2016-09-26 11:37:04 --> Loader Class Initialized
INFO - 2016-09-26 11:37:04 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:04 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:04 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:04 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:04 --> Model Class Initialized
INFO - 2016-09-26 11:37:04 --> Model Class Initialized
INFO - 2016-09-26 11:37:04 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:04 --> Total execution time: 0.0241
INFO - 2016-09-26 11:37:04 --> Config Class Initialized
INFO - 2016-09-26 11:37:04 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:04 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:04 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:04 --> URI Class Initialized
INFO - 2016-09-26 11:37:04 --> Router Class Initialized
INFO - 2016-09-26 11:37:04 --> Output Class Initialized
INFO - 2016-09-26 11:37:04 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:04 --> Input Class Initialized
INFO - 2016-09-26 11:37:04 --> Language Class Initialized
INFO - 2016-09-26 11:37:04 --> Language Class Initialized
INFO - 2016-09-26 11:37:04 --> Config Class Initialized
INFO - 2016-09-26 11:37:04 --> Loader Class Initialized
INFO - 2016-09-26 11:37:04 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:04 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:04 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:04 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:04 --> Model Class Initialized
INFO - 2016-09-26 11:37:04 --> Model Class Initialized
INFO - 2016-09-26 11:37:04 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:04 --> Total execution time: 0.0247
INFO - 2016-09-26 11:37:04 --> Config Class Initialized
INFO - 2016-09-26 11:37:04 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:04 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:04 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:04 --> URI Class Initialized
INFO - 2016-09-26 11:37:04 --> Router Class Initialized
INFO - 2016-09-26 11:37:04 --> Output Class Initialized
INFO - 2016-09-26 11:37:04 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:04 --> Input Class Initialized
INFO - 2016-09-26 11:37:04 --> Language Class Initialized
INFO - 2016-09-26 11:37:04 --> Language Class Initialized
INFO - 2016-09-26 11:37:04 --> Config Class Initialized
INFO - 2016-09-26 11:37:04 --> Loader Class Initialized
INFO - 2016-09-26 11:37:04 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:04 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:04 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:04 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:04 --> Model Class Initialized
INFO - 2016-09-26 11:37:04 --> Model Class Initialized
INFO - 2016-09-26 11:37:04 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:04 --> Total execution time: 0.0258
INFO - 2016-09-26 11:37:05 --> Config Class Initialized
INFO - 2016-09-26 11:37:05 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:05 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:05 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:05 --> URI Class Initialized
INFO - 2016-09-26 11:37:05 --> Router Class Initialized
INFO - 2016-09-26 11:37:05 --> Output Class Initialized
INFO - 2016-09-26 11:37:05 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:05 --> Input Class Initialized
INFO - 2016-09-26 11:37:05 --> Language Class Initialized
INFO - 2016-09-26 11:37:05 --> Language Class Initialized
INFO - 2016-09-26 11:37:05 --> Config Class Initialized
INFO - 2016-09-26 11:37:05 --> Loader Class Initialized
INFO - 2016-09-26 11:37:05 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:05 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:05 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:05 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:05 --> Model Class Initialized
INFO - 2016-09-26 11:37:05 --> Model Class Initialized
INFO - 2016-09-26 11:37:05 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:05 --> Total execution time: 0.0416
INFO - 2016-09-26 11:37:05 --> Config Class Initialized
INFO - 2016-09-26 11:37:05 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:05 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:05 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:05 --> URI Class Initialized
INFO - 2016-09-26 11:37:05 --> Router Class Initialized
INFO - 2016-09-26 11:37:05 --> Output Class Initialized
INFO - 2016-09-26 11:37:05 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:05 --> Input Class Initialized
INFO - 2016-09-26 11:37:05 --> Language Class Initialized
INFO - 2016-09-26 11:37:05 --> Language Class Initialized
INFO - 2016-09-26 11:37:05 --> Config Class Initialized
INFO - 2016-09-26 11:37:05 --> Loader Class Initialized
INFO - 2016-09-26 11:37:05 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:05 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:05 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:05 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:05 --> Model Class Initialized
INFO - 2016-09-26 11:37:05 --> Model Class Initialized
INFO - 2016-09-26 11:37:05 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:05 --> Total execution time: 0.0384
INFO - 2016-09-26 11:37:05 --> Config Class Initialized
INFO - 2016-09-26 11:37:05 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:05 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:05 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:05 --> URI Class Initialized
INFO - 2016-09-26 11:37:05 --> Router Class Initialized
INFO - 2016-09-26 11:37:05 --> Output Class Initialized
INFO - 2016-09-26 11:37:05 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:05 --> Input Class Initialized
INFO - 2016-09-26 11:37:05 --> Language Class Initialized
INFO - 2016-09-26 11:37:05 --> Language Class Initialized
INFO - 2016-09-26 11:37:05 --> Config Class Initialized
INFO - 2016-09-26 11:37:05 --> Loader Class Initialized
INFO - 2016-09-26 11:37:05 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:05 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:05 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:05 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:05 --> Model Class Initialized
INFO - 2016-09-26 11:37:05 --> Model Class Initialized
INFO - 2016-09-26 11:37:05 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:05 --> Total execution time: 0.0402
INFO - 2016-09-26 11:37:05 --> Config Class Initialized
INFO - 2016-09-26 11:37:05 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:05 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:05 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:05 --> URI Class Initialized
INFO - 2016-09-26 11:37:05 --> Router Class Initialized
INFO - 2016-09-26 11:37:05 --> Output Class Initialized
INFO - 2016-09-26 11:37:05 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:05 --> Input Class Initialized
INFO - 2016-09-26 11:37:05 --> Language Class Initialized
INFO - 2016-09-26 11:37:05 --> Language Class Initialized
INFO - 2016-09-26 11:37:05 --> Config Class Initialized
INFO - 2016-09-26 11:37:05 --> Loader Class Initialized
INFO - 2016-09-26 11:37:05 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:05 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:05 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:05 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:05 --> Model Class Initialized
INFO - 2016-09-26 11:37:05 --> Model Class Initialized
INFO - 2016-09-26 11:37:05 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:05 --> Total execution time: 0.0420
INFO - 2016-09-26 11:37:05 --> Config Class Initialized
INFO - 2016-09-26 11:37:05 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:05 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:05 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:05 --> URI Class Initialized
INFO - 2016-09-26 11:37:05 --> Router Class Initialized
INFO - 2016-09-26 11:37:05 --> Output Class Initialized
INFO - 2016-09-26 11:37:05 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:05 --> Input Class Initialized
INFO - 2016-09-26 11:37:05 --> Language Class Initialized
INFO - 2016-09-26 11:37:05 --> Language Class Initialized
INFO - 2016-09-26 11:37:05 --> Config Class Initialized
INFO - 2016-09-26 11:37:05 --> Loader Class Initialized
INFO - 2016-09-26 11:37:05 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:05 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:05 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:05 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:05 --> Model Class Initialized
INFO - 2016-09-26 11:37:05 --> Model Class Initialized
INFO - 2016-09-26 11:37:05 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:05 --> Total execution time: 0.0339
INFO - 2016-09-26 11:37:05 --> Config Class Initialized
INFO - 2016-09-26 11:37:05 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:05 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:05 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:05 --> URI Class Initialized
INFO - 2016-09-26 11:37:05 --> Router Class Initialized
INFO - 2016-09-26 11:37:05 --> Output Class Initialized
INFO - 2016-09-26 11:37:05 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:05 --> Input Class Initialized
INFO - 2016-09-26 11:37:05 --> Language Class Initialized
INFO - 2016-09-26 11:37:05 --> Language Class Initialized
INFO - 2016-09-26 11:37:05 --> Config Class Initialized
INFO - 2016-09-26 11:37:05 --> Loader Class Initialized
INFO - 2016-09-26 11:37:05 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:05 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:05 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:05 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:05 --> Model Class Initialized
INFO - 2016-09-26 11:37:05 --> Model Class Initialized
INFO - 2016-09-26 11:37:05 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:05 --> Total execution time: 0.0415
INFO - 2016-09-26 11:37:05 --> Config Class Initialized
INFO - 2016-09-26 11:37:05 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:05 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:05 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:05 --> URI Class Initialized
INFO - 2016-09-26 11:37:05 --> Router Class Initialized
INFO - 2016-09-26 11:37:05 --> Output Class Initialized
INFO - 2016-09-26 11:37:05 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:05 --> Input Class Initialized
INFO - 2016-09-26 11:37:05 --> Language Class Initialized
INFO - 2016-09-26 11:37:05 --> Language Class Initialized
INFO - 2016-09-26 11:37:05 --> Config Class Initialized
INFO - 2016-09-26 11:37:05 --> Loader Class Initialized
INFO - 2016-09-26 11:37:05 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:05 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:05 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:05 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:05 --> Model Class Initialized
INFO - 2016-09-26 11:37:05 --> Model Class Initialized
INFO - 2016-09-26 11:37:05 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:05 --> Total execution time: 0.0319
INFO - 2016-09-26 11:37:06 --> Config Class Initialized
INFO - 2016-09-26 11:37:06 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:06 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:06 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:06 --> URI Class Initialized
INFO - 2016-09-26 11:37:06 --> Router Class Initialized
INFO - 2016-09-26 11:37:06 --> Output Class Initialized
INFO - 2016-09-26 11:37:06 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:06 --> Input Class Initialized
INFO - 2016-09-26 11:37:06 --> Language Class Initialized
INFO - 2016-09-26 11:37:06 --> Language Class Initialized
INFO - 2016-09-26 11:37:06 --> Config Class Initialized
INFO - 2016-09-26 11:37:06 --> Loader Class Initialized
INFO - 2016-09-26 11:37:06 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:06 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:06 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:06 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:06 --> Model Class Initialized
INFO - 2016-09-26 11:37:06 --> Model Class Initialized
INFO - 2016-09-26 11:37:06 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:06 --> Total execution time: 0.0417
INFO - 2016-09-26 11:37:06 --> Config Class Initialized
INFO - 2016-09-26 11:37:06 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:06 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:06 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:06 --> URI Class Initialized
INFO - 2016-09-26 11:37:06 --> Router Class Initialized
INFO - 2016-09-26 11:37:06 --> Output Class Initialized
INFO - 2016-09-26 11:37:06 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:06 --> Input Class Initialized
INFO - 2016-09-26 11:37:06 --> Language Class Initialized
INFO - 2016-09-26 11:37:06 --> Language Class Initialized
INFO - 2016-09-26 11:37:06 --> Config Class Initialized
INFO - 2016-09-26 11:37:06 --> Loader Class Initialized
INFO - 2016-09-26 11:37:06 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:06 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:06 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:06 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:06 --> Model Class Initialized
INFO - 2016-09-26 11:37:06 --> Model Class Initialized
INFO - 2016-09-26 11:37:06 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:06 --> Total execution time: 0.0333
INFO - 2016-09-26 11:37:06 --> Config Class Initialized
INFO - 2016-09-26 11:37:06 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:06 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:06 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:06 --> URI Class Initialized
INFO - 2016-09-26 11:37:06 --> Router Class Initialized
INFO - 2016-09-26 11:37:06 --> Output Class Initialized
INFO - 2016-09-26 11:37:06 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:06 --> Input Class Initialized
INFO - 2016-09-26 11:37:06 --> Language Class Initialized
INFO - 2016-09-26 11:37:06 --> Language Class Initialized
INFO - 2016-09-26 11:37:06 --> Config Class Initialized
INFO - 2016-09-26 11:37:06 --> Loader Class Initialized
INFO - 2016-09-26 11:37:06 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:06 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:06 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:06 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:06 --> Model Class Initialized
INFO - 2016-09-26 11:37:06 --> Model Class Initialized
INFO - 2016-09-26 11:37:06 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:06 --> Total execution time: 0.0262
INFO - 2016-09-26 11:37:06 --> Config Class Initialized
INFO - 2016-09-26 11:37:06 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:06 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:06 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:06 --> URI Class Initialized
INFO - 2016-09-26 11:37:06 --> Router Class Initialized
INFO - 2016-09-26 11:37:06 --> Output Class Initialized
INFO - 2016-09-26 11:37:06 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:06 --> Input Class Initialized
INFO - 2016-09-26 11:37:06 --> Language Class Initialized
INFO - 2016-09-26 11:37:06 --> Language Class Initialized
INFO - 2016-09-26 11:37:06 --> Config Class Initialized
INFO - 2016-09-26 11:37:06 --> Loader Class Initialized
INFO - 2016-09-26 11:37:06 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:06 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:06 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:06 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:06 --> Model Class Initialized
INFO - 2016-09-26 11:37:06 --> Model Class Initialized
INFO - 2016-09-26 11:37:06 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:06 --> Total execution time: 0.0265
INFO - 2016-09-26 11:37:06 --> Config Class Initialized
INFO - 2016-09-26 11:37:06 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:06 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:06 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:06 --> URI Class Initialized
INFO - 2016-09-26 11:37:06 --> Router Class Initialized
INFO - 2016-09-26 11:37:06 --> Output Class Initialized
INFO - 2016-09-26 11:37:06 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:06 --> Input Class Initialized
INFO - 2016-09-26 11:37:06 --> Language Class Initialized
INFO - 2016-09-26 11:37:06 --> Language Class Initialized
INFO - 2016-09-26 11:37:06 --> Config Class Initialized
INFO - 2016-09-26 11:37:06 --> Loader Class Initialized
INFO - 2016-09-26 11:37:06 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:06 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:06 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:06 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:06 --> Model Class Initialized
INFO - 2016-09-26 11:37:06 --> Model Class Initialized
INFO - 2016-09-26 11:37:06 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:06 --> Total execution time: 0.0311
INFO - 2016-09-26 11:37:06 --> Config Class Initialized
INFO - 2016-09-26 11:37:06 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:06 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:06 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:06 --> URI Class Initialized
INFO - 2016-09-26 11:37:06 --> Router Class Initialized
INFO - 2016-09-26 11:37:06 --> Output Class Initialized
INFO - 2016-09-26 11:37:06 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:06 --> Input Class Initialized
INFO - 2016-09-26 11:37:06 --> Language Class Initialized
INFO - 2016-09-26 11:37:06 --> Language Class Initialized
INFO - 2016-09-26 11:37:06 --> Config Class Initialized
INFO - 2016-09-26 11:37:06 --> Loader Class Initialized
INFO - 2016-09-26 11:37:06 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:06 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:06 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:06 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:06 --> Model Class Initialized
INFO - 2016-09-26 11:37:06 --> Model Class Initialized
INFO - 2016-09-26 11:37:07 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:07 --> Total execution time: 0.0313
INFO - 2016-09-26 11:37:23 --> Config Class Initialized
INFO - 2016-09-26 11:37:23 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:23 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:23 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:23 --> URI Class Initialized
INFO - 2016-09-26 11:37:23 --> Router Class Initialized
INFO - 2016-09-26 11:37:23 --> Output Class Initialized
INFO - 2016-09-26 11:37:23 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:23 --> Input Class Initialized
INFO - 2016-09-26 11:37:23 --> Language Class Initialized
INFO - 2016-09-26 11:37:23 --> Language Class Initialized
INFO - 2016-09-26 11:37:23 --> Config Class Initialized
INFO - 2016-09-26 11:37:23 --> Loader Class Initialized
INFO - 2016-09-26 11:37:23 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:23 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:23 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:23 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:23 --> Model Class Initialized
INFO - 2016-09-26 11:37:23 --> Model Class Initialized
INFO - 2016-09-26 11:37:23 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:23 --> Total execution time: 0.0253
INFO - 2016-09-26 11:37:23 --> Config Class Initialized
INFO - 2016-09-26 11:37:23 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:23 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:23 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:23 --> URI Class Initialized
INFO - 2016-09-26 11:37:23 --> Router Class Initialized
INFO - 2016-09-26 11:37:23 --> Output Class Initialized
INFO - 2016-09-26 11:37:23 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:23 --> Input Class Initialized
INFO - 2016-09-26 11:37:23 --> Language Class Initialized
INFO - 2016-09-26 11:37:23 --> Language Class Initialized
INFO - 2016-09-26 11:37:23 --> Config Class Initialized
INFO - 2016-09-26 11:37:23 --> Loader Class Initialized
INFO - 2016-09-26 11:37:23 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:23 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:23 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:23 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:23 --> Model Class Initialized
INFO - 2016-09-26 11:37:23 --> Model Class Initialized
INFO - 2016-09-26 11:37:23 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:23 --> Total execution time: 0.0246
INFO - 2016-09-26 11:37:23 --> Config Class Initialized
INFO - 2016-09-26 11:37:23 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:23 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:23 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:23 --> URI Class Initialized
INFO - 2016-09-26 11:37:23 --> Router Class Initialized
INFO - 2016-09-26 11:37:23 --> Output Class Initialized
INFO - 2016-09-26 11:37:23 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:23 --> Input Class Initialized
INFO - 2016-09-26 11:37:23 --> Language Class Initialized
INFO - 2016-09-26 11:37:23 --> Language Class Initialized
INFO - 2016-09-26 11:37:23 --> Config Class Initialized
INFO - 2016-09-26 11:37:23 --> Loader Class Initialized
INFO - 2016-09-26 11:37:23 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:23 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:23 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:23 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:23 --> Model Class Initialized
INFO - 2016-09-26 11:37:23 --> Model Class Initialized
INFO - 2016-09-26 11:37:23 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:23 --> Total execution time: 0.0306
INFO - 2016-09-26 11:37:23 --> Config Class Initialized
INFO - 2016-09-26 11:37:23 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:23 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:23 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:23 --> URI Class Initialized
INFO - 2016-09-26 11:37:23 --> Router Class Initialized
INFO - 2016-09-26 11:37:23 --> Output Class Initialized
INFO - 2016-09-26 11:37:23 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:23 --> Input Class Initialized
INFO - 2016-09-26 11:37:23 --> Language Class Initialized
INFO - 2016-09-26 11:37:23 --> Language Class Initialized
INFO - 2016-09-26 11:37:23 --> Config Class Initialized
INFO - 2016-09-26 11:37:23 --> Loader Class Initialized
INFO - 2016-09-26 11:37:23 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:23 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:23 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:23 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:23 --> Model Class Initialized
INFO - 2016-09-26 11:37:23 --> Model Class Initialized
INFO - 2016-09-26 11:37:23 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:23 --> Total execution time: 0.0535
INFO - 2016-09-26 11:37:23 --> Config Class Initialized
INFO - 2016-09-26 11:37:23 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:23 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:23 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:23 --> URI Class Initialized
INFO - 2016-09-26 11:37:23 --> Router Class Initialized
INFO - 2016-09-26 11:37:23 --> Output Class Initialized
INFO - 2016-09-26 11:37:23 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:23 --> Input Class Initialized
INFO - 2016-09-26 11:37:23 --> Language Class Initialized
INFO - 2016-09-26 11:37:23 --> Language Class Initialized
INFO - 2016-09-26 11:37:23 --> Config Class Initialized
INFO - 2016-09-26 11:37:23 --> Loader Class Initialized
INFO - 2016-09-26 11:37:23 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:23 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:23 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:23 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:23 --> Model Class Initialized
INFO - 2016-09-26 11:37:23 --> Model Class Initialized
INFO - 2016-09-26 11:37:23 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:23 --> Total execution time: 0.0368
INFO - 2016-09-26 11:37:23 --> Config Class Initialized
INFO - 2016-09-26 11:37:23 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:23 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:23 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:23 --> URI Class Initialized
INFO - 2016-09-26 11:37:23 --> Router Class Initialized
INFO - 2016-09-26 11:37:23 --> Output Class Initialized
INFO - 2016-09-26 11:37:23 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:23 --> Input Class Initialized
INFO - 2016-09-26 11:37:23 --> Language Class Initialized
INFO - 2016-09-26 11:37:23 --> Language Class Initialized
INFO - 2016-09-26 11:37:23 --> Config Class Initialized
INFO - 2016-09-26 11:37:23 --> Loader Class Initialized
INFO - 2016-09-26 11:37:23 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:23 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:23 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:23 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:23 --> Model Class Initialized
INFO - 2016-09-26 11:37:23 --> Model Class Initialized
INFO - 2016-09-26 11:37:23 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:23 --> Total execution time: 0.0743
INFO - 2016-09-26 11:37:23 --> Config Class Initialized
INFO - 2016-09-26 11:37:23 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:23 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:23 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:23 --> URI Class Initialized
INFO - 2016-09-26 11:37:23 --> Router Class Initialized
INFO - 2016-09-26 11:37:23 --> Config Class Initialized
INFO - 2016-09-26 11:37:23 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:23 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:23 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:23 --> URI Class Initialized
INFO - 2016-09-26 11:37:23 --> Router Class Initialized
INFO - 2016-09-26 11:37:23 --> Output Class Initialized
INFO - 2016-09-26 11:37:23 --> Output Class Initialized
INFO - 2016-09-26 11:37:23 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:23 --> Input Class Initialized
INFO - 2016-09-26 11:37:23 --> Language Class Initialized
INFO - 2016-09-26 11:37:23 --> Language Class Initialized
INFO - 2016-09-26 11:37:23 --> Config Class Initialized
INFO - 2016-09-26 11:37:23 --> Loader Class Initialized
INFO - 2016-09-26 11:37:23 --> Config Class Initialized
INFO - 2016-09-26 11:37:23 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:23 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:23 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:23 --> URI Class Initialized
INFO - 2016-09-26 11:37:23 --> Router Class Initialized
INFO - 2016-09-26 11:37:23 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:23 --> Input Class Initialized
INFO - 2016-09-26 11:37:23 --> Language Class Initialized
INFO - 2016-09-26 11:37:23 --> Language Class Initialized
INFO - 2016-09-26 11:37:23 --> Config Class Initialized
INFO - 2016-09-26 11:37:23 --> Loader Class Initialized
INFO - 2016-09-26 11:37:23 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:23 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:23 --> Output Class Initialized
INFO - 2016-09-26 11:37:23 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:23 --> Input Class Initialized
INFO - 2016-09-26 11:37:23 --> Language Class Initialized
INFO - 2016-09-26 11:37:23 --> Language Class Initialized
INFO - 2016-09-26 11:37:23 --> Config Class Initialized
INFO - 2016-09-26 11:37:23 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:23 --> Loader Class Initialized
INFO - 2016-09-26 11:37:23 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:23 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:23 --> Controller Class Initialized
INFO - 2016-09-26 11:37:23 --> Config Class Initialized
INFO - 2016-09-26 11:37:23 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:23 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:23 --> Utf8 Class Initialized
DEBUG - 2016-09-26 11:37:23 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:23 --> Model Class Initialized
INFO - 2016-09-26 11:37:23 --> Model Class Initialized
INFO - 2016-09-26 11:37:23 --> URI Class Initialized
INFO - 2016-09-26 11:37:23 --> Router Class Initialized
INFO - 2016-09-26 11:37:23 --> Output Class Initialized
INFO - 2016-09-26 11:37:23 --> Security Class Initialized
INFO - 2016-09-26 11:37:23 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:23 --> Total execution time: 0.0887
INFO - 2016-09-26 11:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:23 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:23 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:23 --> Model Class Initialized
INFO - 2016-09-26 11:37:23 --> Model Class Initialized
INFO - 2016-09-26 11:37:23 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:23 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:23 --> Total execution time: 0.1019
DEBUG - 2016-09-26 11:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:23 --> Input Class Initialized
INFO - 2016-09-26 11:37:23 --> Language Class Initialized
INFO - 2016-09-26 11:37:23 --> Language Class Initialized
INFO - 2016-09-26 11:37:23 --> Config Class Initialized
INFO - 2016-09-26 11:37:23 --> Loader Class Initialized
INFO - 2016-09-26 11:37:23 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:23 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:23 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:23 --> Model Class Initialized
INFO - 2016-09-26 11:37:23 --> Model Class Initialized
INFO - 2016-09-26 11:37:23 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:23 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:23 --> Total execution time: 0.1085
INFO - 2016-09-26 11:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:23 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:23 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:23 --> Model Class Initialized
INFO - 2016-09-26 11:37:23 --> Model Class Initialized
INFO - 2016-09-26 11:37:23 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:23 --> Total execution time: 0.0532
INFO - 2016-09-26 11:37:24 --> Config Class Initialized
INFO - 2016-09-26 11:37:24 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:24 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:24 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:24 --> URI Class Initialized
INFO - 2016-09-26 11:37:24 --> Router Class Initialized
INFO - 2016-09-26 11:37:24 --> Output Class Initialized
INFO - 2016-09-26 11:37:24 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:24 --> Input Class Initialized
INFO - 2016-09-26 11:37:24 --> Language Class Initialized
INFO - 2016-09-26 11:37:24 --> Language Class Initialized
INFO - 2016-09-26 11:37:24 --> Config Class Initialized
INFO - 2016-09-26 11:37:24 --> Loader Class Initialized
INFO - 2016-09-26 11:37:24 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:24 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:24 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:24 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:24 --> Model Class Initialized
INFO - 2016-09-26 11:37:24 --> Model Class Initialized
INFO - 2016-09-26 11:37:24 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:24 --> Total execution time: 0.0269
INFO - 2016-09-26 11:37:24 --> Config Class Initialized
INFO - 2016-09-26 11:37:24 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:24 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:24 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:24 --> URI Class Initialized
INFO - 2016-09-26 11:37:24 --> Router Class Initialized
INFO - 2016-09-26 11:37:24 --> Output Class Initialized
INFO - 2016-09-26 11:37:24 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:24 --> Input Class Initialized
INFO - 2016-09-26 11:37:24 --> Language Class Initialized
INFO - 2016-09-26 11:37:24 --> Language Class Initialized
INFO - 2016-09-26 11:37:24 --> Config Class Initialized
INFO - 2016-09-26 11:37:24 --> Loader Class Initialized
INFO - 2016-09-26 11:37:24 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:24 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:24 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:24 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:24 --> Model Class Initialized
INFO - 2016-09-26 11:37:24 --> Model Class Initialized
INFO - 2016-09-26 11:37:24 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:24 --> Total execution time: 0.0370
INFO - 2016-09-26 11:37:24 --> Config Class Initialized
INFO - 2016-09-26 11:37:24 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:24 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:24 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:24 --> URI Class Initialized
INFO - 2016-09-26 11:37:24 --> Router Class Initialized
INFO - 2016-09-26 11:37:24 --> Output Class Initialized
INFO - 2016-09-26 11:37:24 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:24 --> Input Class Initialized
INFO - 2016-09-26 11:37:24 --> Language Class Initialized
INFO - 2016-09-26 11:37:24 --> Language Class Initialized
INFO - 2016-09-26 11:37:24 --> Config Class Initialized
INFO - 2016-09-26 11:37:24 --> Loader Class Initialized
INFO - 2016-09-26 11:37:24 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:24 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:24 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:24 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:24 --> Model Class Initialized
INFO - 2016-09-26 11:37:24 --> Model Class Initialized
INFO - 2016-09-26 11:37:24 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:24 --> Total execution time: 0.0227
INFO - 2016-09-26 11:37:24 --> Config Class Initialized
INFO - 2016-09-26 11:37:24 --> Hooks Class Initialized
INFO - 2016-09-26 11:37:24 --> Config Class Initialized
INFO - 2016-09-26 11:37:24 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:24 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:24 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:24 --> URI Class Initialized
INFO - 2016-09-26 11:37:24 --> Router Class Initialized
INFO - 2016-09-26 11:37:24 --> Output Class Initialized
INFO - 2016-09-26 11:37:24 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:24 --> Input Class Initialized
DEBUG - 2016-09-26 11:37:24 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:24 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:24 --> URI Class Initialized
INFO - 2016-09-26 11:37:24 --> Router Class Initialized
INFO - 2016-09-26 11:37:24 --> Output Class Initialized
INFO - 2016-09-26 11:37:24 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:24 --> Input Class Initialized
INFO - 2016-09-26 11:37:24 --> Language Class Initialized
INFO - 2016-09-26 11:37:24 --> Language Class Initialized
INFO - 2016-09-26 11:37:24 --> Config Class Initialized
INFO - 2016-09-26 11:37:24 --> Language Class Initialized
INFO - 2016-09-26 11:37:24 --> Language Class Initialized
INFO - 2016-09-26 11:37:24 --> Config Class Initialized
INFO - 2016-09-26 11:37:24 --> Loader Class Initialized
INFO - 2016-09-26 11:37:24 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:24 --> Loader Class Initialized
INFO - 2016-09-26 11:37:24 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:24 --> Config Class Initialized
INFO - 2016-09-26 11:37:24 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:24 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:24 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:24 --> URI Class Initialized
INFO - 2016-09-26 11:37:24 --> Router Class Initialized
INFO - 2016-09-26 11:37:24 --> Output Class Initialized
INFO - 2016-09-26 11:37:24 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:24 --> Input Class Initialized
INFO - 2016-09-26 11:37:24 --> Language Class Initialized
INFO - 2016-09-26 11:37:24 --> Language Class Initialized
INFO - 2016-09-26 11:37:24 --> Config Class Initialized
INFO - 2016-09-26 11:37:24 --> Loader Class Initialized
INFO - 2016-09-26 11:37:24 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:24 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:24 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:24 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:24 --> Model Class Initialized
INFO - 2016-09-26 11:37:24 --> Model Class Initialized
INFO - 2016-09-26 11:37:24 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:24 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:24 --> Total execution time: 0.0598
INFO - 2016-09-26 11:37:24 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:24 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:24 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:24 --> Model Class Initialized
INFO - 2016-09-26 11:37:24 --> Model Class Initialized
INFO - 2016-09-26 11:37:24 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:24 --> Total execution time: 0.0754
INFO - 2016-09-26 11:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:24 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:24 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:24 --> Model Class Initialized
INFO - 2016-09-26 11:37:24 --> Model Class Initialized
INFO - 2016-09-26 11:37:24 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:24 --> Total execution time: 0.0429
INFO - 2016-09-26 11:37:25 --> Config Class Initialized
INFO - 2016-09-26 11:37:25 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:25 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:25 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:25 --> URI Class Initialized
INFO - 2016-09-26 11:37:25 --> Router Class Initialized
INFO - 2016-09-26 11:37:25 --> Output Class Initialized
INFO - 2016-09-26 11:37:25 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:25 --> Input Class Initialized
INFO - 2016-09-26 11:37:25 --> Language Class Initialized
INFO - 2016-09-26 11:37:25 --> Language Class Initialized
INFO - 2016-09-26 11:37:25 --> Config Class Initialized
INFO - 2016-09-26 11:37:25 --> Loader Class Initialized
INFO - 2016-09-26 11:37:25 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:25 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:25 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:25 --> Model Class Initialized
INFO - 2016-09-26 11:37:25 --> Model Class Initialized
INFO - 2016-09-26 11:37:25 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:25 --> Total execution time: 0.0335
INFO - 2016-09-26 11:37:25 --> Config Class Initialized
INFO - 2016-09-26 11:37:25 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:25 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:25 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:25 --> URI Class Initialized
INFO - 2016-09-26 11:37:25 --> Router Class Initialized
INFO - 2016-09-26 11:37:25 --> Output Class Initialized
INFO - 2016-09-26 11:37:25 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:25 --> Input Class Initialized
INFO - 2016-09-26 11:37:25 --> Language Class Initialized
INFO - 2016-09-26 11:37:25 --> Language Class Initialized
INFO - 2016-09-26 11:37:25 --> Config Class Initialized
INFO - 2016-09-26 11:37:25 --> Loader Class Initialized
INFO - 2016-09-26 11:37:25 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:25 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:25 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:25 --> Model Class Initialized
INFO - 2016-09-26 11:37:25 --> Model Class Initialized
INFO - 2016-09-26 11:37:25 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:25 --> Total execution time: 0.0235
INFO - 2016-09-26 11:37:25 --> Config Class Initialized
INFO - 2016-09-26 11:37:25 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:25 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:25 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:25 --> URI Class Initialized
INFO - 2016-09-26 11:37:25 --> Router Class Initialized
INFO - 2016-09-26 11:37:25 --> Output Class Initialized
INFO - 2016-09-26 11:37:25 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:25 --> Input Class Initialized
INFO - 2016-09-26 11:37:25 --> Language Class Initialized
INFO - 2016-09-26 11:37:25 --> Language Class Initialized
INFO - 2016-09-26 11:37:25 --> Config Class Initialized
INFO - 2016-09-26 11:37:25 --> Loader Class Initialized
INFO - 2016-09-26 11:37:25 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:25 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:25 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:25 --> Model Class Initialized
INFO - 2016-09-26 11:37:25 --> Model Class Initialized
INFO - 2016-09-26 11:37:25 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:25 --> Total execution time: 0.0237
INFO - 2016-09-26 11:37:25 --> Config Class Initialized
INFO - 2016-09-26 11:37:25 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:25 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:25 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:25 --> URI Class Initialized
INFO - 2016-09-26 11:37:25 --> Router Class Initialized
INFO - 2016-09-26 11:37:25 --> Output Class Initialized
INFO - 2016-09-26 11:37:25 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:25 --> Input Class Initialized
INFO - 2016-09-26 11:37:25 --> Language Class Initialized
INFO - 2016-09-26 11:37:25 --> Language Class Initialized
INFO - 2016-09-26 11:37:25 --> Config Class Initialized
INFO - 2016-09-26 11:37:25 --> Loader Class Initialized
INFO - 2016-09-26 11:37:25 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:25 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:25 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:25 --> Model Class Initialized
INFO - 2016-09-26 11:37:25 --> Model Class Initialized
INFO - 2016-09-26 11:37:25 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:25 --> Total execution time: 0.0236
INFO - 2016-09-26 11:37:25 --> Config Class Initialized
INFO - 2016-09-26 11:37:25 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:25 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:25 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:25 --> URI Class Initialized
INFO - 2016-09-26 11:37:25 --> Router Class Initialized
INFO - 2016-09-26 11:37:25 --> Output Class Initialized
INFO - 2016-09-26 11:37:25 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:25 --> Input Class Initialized
INFO - 2016-09-26 11:37:25 --> Language Class Initialized
INFO - 2016-09-26 11:37:25 --> Language Class Initialized
INFO - 2016-09-26 11:37:25 --> Config Class Initialized
INFO - 2016-09-26 11:37:25 --> Loader Class Initialized
INFO - 2016-09-26 11:37:25 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:25 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:25 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:25 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:25 --> Model Class Initialized
INFO - 2016-09-26 11:37:25 --> Model Class Initialized
INFO - 2016-09-26 11:37:25 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:25 --> Total execution time: 0.0259
INFO - 2016-09-26 11:37:26 --> Config Class Initialized
INFO - 2016-09-26 11:37:26 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:26 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:26 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:26 --> URI Class Initialized
INFO - 2016-09-26 11:37:26 --> Router Class Initialized
INFO - 2016-09-26 11:37:26 --> Output Class Initialized
INFO - 2016-09-26 11:37:26 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:26 --> Input Class Initialized
INFO - 2016-09-26 11:37:26 --> Language Class Initialized
INFO - 2016-09-26 11:37:26 --> Language Class Initialized
INFO - 2016-09-26 11:37:26 --> Config Class Initialized
INFO - 2016-09-26 11:37:26 --> Loader Class Initialized
INFO - 2016-09-26 11:37:26 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:26 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:26 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:26 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:26 --> Model Class Initialized
INFO - 2016-09-26 11:37:26 --> Model Class Initialized
INFO - 2016-09-26 11:37:26 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:26 --> Total execution time: 0.0242
INFO - 2016-09-26 11:37:26 --> Config Class Initialized
INFO - 2016-09-26 11:37:26 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:26 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:26 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:26 --> URI Class Initialized
INFO - 2016-09-26 11:37:26 --> Config Class Initialized
INFO - 2016-09-26 11:37:26 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:26 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:26 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:26 --> URI Class Initialized
INFO - 2016-09-26 11:37:26 --> Router Class Initialized
INFO - 2016-09-26 11:37:26 --> Output Class Initialized
INFO - 2016-09-26 11:37:26 --> Security Class Initialized
INFO - 2016-09-26 11:37:26 --> Router Class Initialized
INFO - 2016-09-26 11:37:26 --> Output Class Initialized
INFO - 2016-09-26 11:37:26 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:26 --> Input Class Initialized
INFO - 2016-09-26 11:37:26 --> Language Class Initialized
INFO - 2016-09-26 11:37:26 --> Language Class Initialized
INFO - 2016-09-26 11:37:26 --> Config Class Initialized
INFO - 2016-09-26 11:37:26 --> Loader Class Initialized
INFO - 2016-09-26 11:37:26 --> Helper loaded: url_helper
DEBUG - 2016-09-26 11:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:26 --> Input Class Initialized
INFO - 2016-09-26 11:37:26 --> Language Class Initialized
INFO - 2016-09-26 11:37:26 --> Language Class Initialized
INFO - 2016-09-26 11:37:26 --> Config Class Initialized
INFO - 2016-09-26 11:37:26 --> Loader Class Initialized
INFO - 2016-09-26 11:37:26 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:26 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:26 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:26 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:26 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:26 --> Model Class Initialized
INFO - 2016-09-26 11:37:26 --> Model Class Initialized
INFO - 2016-09-26 11:37:26 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:26 --> Total execution time: 0.0411
INFO - 2016-09-26 11:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:26 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:26 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:26 --> Model Class Initialized
INFO - 2016-09-26 11:37:26 --> Model Class Initialized
INFO - 2016-09-26 11:37:26 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:26 --> Total execution time: 0.0542
INFO - 2016-09-26 11:37:27 --> Config Class Initialized
INFO - 2016-09-26 11:37:27 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:27 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:27 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:27 --> URI Class Initialized
INFO - 2016-09-26 11:37:27 --> Router Class Initialized
INFO - 2016-09-26 11:37:27 --> Output Class Initialized
INFO - 2016-09-26 11:37:27 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:27 --> Input Class Initialized
INFO - 2016-09-26 11:37:27 --> Language Class Initialized
INFO - 2016-09-26 11:37:27 --> Language Class Initialized
INFO - 2016-09-26 11:37:27 --> Config Class Initialized
INFO - 2016-09-26 11:37:27 --> Loader Class Initialized
INFO - 2016-09-26 11:37:27 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:27 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:27 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:27 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:27 --> Model Class Initialized
INFO - 2016-09-26 11:37:27 --> Model Class Initialized
INFO - 2016-09-26 11:37:27 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:27 --> Total execution time: 0.0397
INFO - 2016-09-26 11:37:27 --> Config Class Initialized
INFO - 2016-09-26 11:37:27 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:27 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:27 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:27 --> URI Class Initialized
INFO - 2016-09-26 11:37:27 --> Router Class Initialized
INFO - 2016-09-26 11:37:27 --> Output Class Initialized
INFO - 2016-09-26 11:37:27 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:27 --> Input Class Initialized
INFO - 2016-09-26 11:37:27 --> Language Class Initialized
INFO - 2016-09-26 11:37:27 --> Language Class Initialized
INFO - 2016-09-26 11:37:27 --> Config Class Initialized
INFO - 2016-09-26 11:37:27 --> Loader Class Initialized
INFO - 2016-09-26 11:37:27 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:27 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:27 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:27 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:27 --> Model Class Initialized
INFO - 2016-09-26 11:37:27 --> Model Class Initialized
INFO - 2016-09-26 11:37:27 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:27 --> Total execution time: 0.0287
INFO - 2016-09-26 11:37:27 --> Config Class Initialized
INFO - 2016-09-26 11:37:27 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:27 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:27 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:27 --> URI Class Initialized
INFO - 2016-09-26 11:37:27 --> Router Class Initialized
INFO - 2016-09-26 11:37:27 --> Output Class Initialized
INFO - 2016-09-26 11:37:27 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:27 --> Input Class Initialized
INFO - 2016-09-26 11:37:27 --> Language Class Initialized
INFO - 2016-09-26 11:37:27 --> Language Class Initialized
INFO - 2016-09-26 11:37:27 --> Config Class Initialized
INFO - 2016-09-26 11:37:27 --> Loader Class Initialized
INFO - 2016-09-26 11:37:27 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:27 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:27 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:27 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:27 --> Model Class Initialized
INFO - 2016-09-26 11:37:27 --> Model Class Initialized
INFO - 2016-09-26 11:37:27 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:27 --> Total execution time: 0.0235
INFO - 2016-09-26 11:37:30 --> Config Class Initialized
INFO - 2016-09-26 11:37:30 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:30 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:30 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:30 --> URI Class Initialized
INFO - 2016-09-26 11:37:30 --> Router Class Initialized
INFO - 2016-09-26 11:37:30 --> Output Class Initialized
INFO - 2016-09-26 11:37:30 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:30 --> Input Class Initialized
INFO - 2016-09-26 11:37:30 --> Language Class Initialized
INFO - 2016-09-26 11:37:30 --> Language Class Initialized
INFO - 2016-09-26 11:37:30 --> Config Class Initialized
INFO - 2016-09-26 11:37:30 --> Loader Class Initialized
INFO - 2016-09-26 11:37:30 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:30 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:30 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:30 --> login MX_Controller Initialized
INFO - 2016-09-26 11:37:30 --> Model Class Initialized
INFO - 2016-09-26 11:37:30 --> Model Class Initialized
INFO - 2016-09-26 11:37:30 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:30 --> Total execution time: 0.0227
INFO - 2016-09-26 11:37:30 --> Config Class Initialized
INFO - 2016-09-26 11:37:30 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:30 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:30 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:30 --> URI Class Initialized
INFO - 2016-09-26 11:37:30 --> Router Class Initialized
INFO - 2016-09-26 11:37:30 --> Output Class Initialized
INFO - 2016-09-26 11:37:30 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:30 --> Input Class Initialized
INFO - 2016-09-26 11:37:30 --> Language Class Initialized
INFO - 2016-09-26 11:37:30 --> Language Class Initialized
INFO - 2016-09-26 11:37:30 --> Config Class Initialized
INFO - 2016-09-26 11:37:30 --> Loader Class Initialized
INFO - 2016-09-26 11:37:30 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:30 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:30 --> Controller Class Initialized
DEBUG - 2016-09-26 11:37:30 --> Index MX_Controller Initialized
INFO - 2016-09-26 11:37:30 --> Model Class Initialized
INFO - 2016-09-26 11:37:30 --> Model Class Initialized
ERROR - 2016-09-26 11:37:30 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-26 11:37:30 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-26 11:37:30 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-26 11:37:30 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-26 11:37:30 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-26 11:37:30 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-26 11:37:30 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-26 11:37:30 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:30 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:30 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:30 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:30 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:30 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:30 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:30 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:30 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:30 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:30 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:30 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:30 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:30 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:30 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:30 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:30 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:30 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:30 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:30 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:30 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:31 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:31 --> Database Driver Class Initialized
DEBUG - 2016-09-26 11:37:31 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-26 11:37:31 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-26 11:37:31 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:31 --> Total execution time: 0.0968
INFO - 2016-09-26 11:37:31 --> Config Class Initialized
INFO - 2016-09-26 11:37:31 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:31 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:31 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:31 --> URI Class Initialized
INFO - 2016-09-26 11:37:31 --> Router Class Initialized
INFO - 2016-09-26 11:37:31 --> Output Class Initialized
INFO - 2016-09-26 11:37:31 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:31 --> Input Class Initialized
INFO - 2016-09-26 11:37:31 --> Language Class Initialized
ERROR - 2016-09-26 11:37:31 --> 404 Page Not Found: /index
INFO - 2016-09-26 11:37:32 --> Config Class Initialized
INFO - 2016-09-26 11:37:32 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:32 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:32 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:32 --> URI Class Initialized
INFO - 2016-09-26 11:37:32 --> Router Class Initialized
INFO - 2016-09-26 11:37:32 --> Output Class Initialized
INFO - 2016-09-26 11:37:32 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:32 --> Input Class Initialized
INFO - 2016-09-26 11:37:32 --> Language Class Initialized
ERROR - 2016-09-26 11:37:32 --> 404 Page Not Found: /index
INFO - 2016-09-26 12:22:50 --> Config Class Initialized
INFO - 2016-09-26 12:22:50 --> Hooks Class Initialized
DEBUG - 2016-09-26 12:22:50 --> UTF-8 Support Enabled
INFO - 2016-09-26 12:22:50 --> Utf8 Class Initialized
INFO - 2016-09-26 12:22:50 --> URI Class Initialized
DEBUG - 2016-09-26 12:22:50 --> No URI present. Default controller set.
INFO - 2016-09-26 12:22:50 --> Router Class Initialized
INFO - 2016-09-26 12:22:50 --> Output Class Initialized
INFO - 2016-09-26 12:22:50 --> Security Class Initialized
DEBUG - 2016-09-26 12:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 12:22:50 --> Input Class Initialized
INFO - 2016-09-26 12:22:50 --> Language Class Initialized
INFO - 2016-09-26 12:22:50 --> Language Class Initialized
INFO - 2016-09-26 12:22:50 --> Config Class Initialized
INFO - 2016-09-26 12:22:50 --> Loader Class Initialized
INFO - 2016-09-26 12:22:50 --> Helper loaded: url_helper
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 12:22:50 --> Controller Class Initialized
DEBUG - 2016-09-26 12:22:50 --> Index MX_Controller Initialized
INFO - 2016-09-26 12:22:50 --> Model Class Initialized
INFO - 2016-09-26 12:22:50 --> Model Class Initialized
ERROR - 2016-09-26 12:22:50 --> Unable to delete cache file for 
DEBUG - 2016-09-26 12:22:50 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-26 12:22:50 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-26 12:22:50 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-26 12:22:50 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-26 12:22:50 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-26 12:22:50 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
INFO - 2016-09-26 12:22:50 --> Database Driver Class Initialized
DEBUG - 2016-09-26 12:22:50 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-26 12:22:50 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-26 12:22:50 --> Final output sent to browser
DEBUG - 2016-09-26 12:22:50 --> Total execution time: 0.1051
INFO - 2016-09-26 12:22:50 --> Config Class Initialized
INFO - 2016-09-26 12:22:50 --> Hooks Class Initialized
DEBUG - 2016-09-26 12:22:50 --> UTF-8 Support Enabled
INFO - 2016-09-26 12:22:50 --> Utf8 Class Initialized
INFO - 2016-09-26 12:22:50 --> URI Class Initialized
INFO - 2016-09-26 12:22:50 --> Router Class Initialized
INFO - 2016-09-26 12:22:50 --> Output Class Initialized
INFO - 2016-09-26 12:22:50 --> Security Class Initialized
DEBUG - 2016-09-26 12:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 12:22:50 --> Input Class Initialized
INFO - 2016-09-26 12:22:50 --> Language Class Initialized
ERROR - 2016-09-26 12:22:50 --> 404 Page Not Found: /index
INFO - 2016-09-26 12:22:50 --> Config Class Initialized
INFO - 2016-09-26 12:22:50 --> Hooks Class Initialized
DEBUG - 2016-09-26 12:22:50 --> UTF-8 Support Enabled
INFO - 2016-09-26 12:22:50 --> Utf8 Class Initialized
INFO - 2016-09-26 12:22:50 --> URI Class Initialized
INFO - 2016-09-26 12:22:50 --> Router Class Initialized
INFO - 2016-09-26 12:22:50 --> Output Class Initialized
INFO - 2016-09-26 12:22:50 --> Security Class Initialized
DEBUG - 2016-09-26 12:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 12:22:50 --> Input Class Initialized
INFO - 2016-09-26 12:22:50 --> Language Class Initialized
ERROR - 2016-09-26 12:22:50 --> 404 Page Not Found: /index
INFO - 2016-09-26 12:22:51 --> Config Class Initialized
INFO - 2016-09-26 12:22:51 --> Hooks Class Initialized
DEBUG - 2016-09-26 12:22:51 --> UTF-8 Support Enabled
INFO - 2016-09-26 12:22:51 --> Utf8 Class Initialized
INFO - 2016-09-26 12:22:51 --> URI Class Initialized
INFO - 2016-09-26 12:22:51 --> Router Class Initialized
INFO - 2016-09-26 12:22:51 --> Output Class Initialized
INFO - 2016-09-26 12:22:51 --> Security Class Initialized
DEBUG - 2016-09-26 12:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 12:22:51 --> Input Class Initialized
INFO - 2016-09-26 12:22:51 --> Language Class Initialized
ERROR - 2016-09-26 12:22:51 --> 404 Page Not Found: /index
INFO - 2016-09-26 12:22:51 --> Config Class Initialized
INFO - 2016-09-26 12:22:51 --> Hooks Class Initialized
DEBUG - 2016-09-26 12:22:51 --> UTF-8 Support Enabled
INFO - 2016-09-26 12:22:51 --> Utf8 Class Initialized
INFO - 2016-09-26 12:22:51 --> URI Class Initialized
INFO - 2016-09-26 12:22:51 --> Router Class Initialized
INFO - 2016-09-26 12:22:51 --> Output Class Initialized
INFO - 2016-09-26 12:22:51 --> Security Class Initialized
DEBUG - 2016-09-26 12:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 12:22:51 --> Input Class Initialized
INFO - 2016-09-26 12:22:51 --> Language Class Initialized
ERROR - 2016-09-26 12:22:51 --> 404 Page Not Found: /index
INFO - 2016-09-26 12:22:51 --> Config Class Initialized
INFO - 2016-09-26 12:22:51 --> Hooks Class Initialized
DEBUG - 2016-09-26 12:22:51 --> UTF-8 Support Enabled
INFO - 2016-09-26 12:22:51 --> Utf8 Class Initialized
INFO - 2016-09-26 12:22:51 --> URI Class Initialized
INFO - 2016-09-26 12:22:51 --> Router Class Initialized
INFO - 2016-09-26 12:22:51 --> Output Class Initialized
INFO - 2016-09-26 12:22:51 --> Security Class Initialized
DEBUG - 2016-09-26 12:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 12:22:51 --> Input Class Initialized
INFO - 2016-09-26 12:22:51 --> Language Class Initialized
ERROR - 2016-09-26 12:22:51 --> 404 Page Not Found: /index
INFO - 2016-09-26 12:22:51 --> Config Class Initialized
INFO - 2016-09-26 12:22:51 --> Hooks Class Initialized
DEBUG - 2016-09-26 12:22:51 --> UTF-8 Support Enabled
INFO - 2016-09-26 12:22:51 --> Utf8 Class Initialized
INFO - 2016-09-26 12:22:51 --> URI Class Initialized
INFO - 2016-09-26 12:22:51 --> Router Class Initialized
INFO - 2016-09-26 12:22:51 --> Output Class Initialized
INFO - 2016-09-26 12:22:51 --> Security Class Initialized
DEBUG - 2016-09-26 12:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 12:22:51 --> Input Class Initialized
INFO - 2016-09-26 12:22:51 --> Language Class Initialized
ERROR - 2016-09-26 12:22:51 --> 404 Page Not Found: /index
INFO - 2016-09-26 12:22:52 --> Config Class Initialized
INFO - 2016-09-26 12:22:52 --> Hooks Class Initialized
DEBUG - 2016-09-26 12:22:52 --> UTF-8 Support Enabled
INFO - 2016-09-26 12:22:52 --> Utf8 Class Initialized
INFO - 2016-09-26 12:22:52 --> URI Class Initialized
INFO - 2016-09-26 12:22:52 --> Router Class Initialized
INFO - 2016-09-26 12:22:52 --> Output Class Initialized
INFO - 2016-09-26 12:22:52 --> Security Class Initialized
DEBUG - 2016-09-26 12:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 12:22:52 --> Input Class Initialized
INFO - 2016-09-26 12:22:52 --> Language Class Initialized
ERROR - 2016-09-26 12:22:52 --> 404 Page Not Found: /index
INFO - 2016-09-26 12:22:52 --> Config Class Initialized
INFO - 2016-09-26 12:22:52 --> Hooks Class Initialized
DEBUG - 2016-09-26 12:22:52 --> UTF-8 Support Enabled
INFO - 2016-09-26 12:22:52 --> Utf8 Class Initialized
INFO - 2016-09-26 12:22:52 --> URI Class Initialized
INFO - 2016-09-26 12:22:52 --> Router Class Initialized
INFO - 2016-09-26 12:22:52 --> Output Class Initialized
INFO - 2016-09-26 12:22:52 --> Security Class Initialized
DEBUG - 2016-09-26 12:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 12:22:52 --> Input Class Initialized
INFO - 2016-09-26 12:22:52 --> Language Class Initialized
ERROR - 2016-09-26 12:22:52 --> 404 Page Not Found: /index
INFO - 2016-09-26 12:22:52 --> Config Class Initialized
INFO - 2016-09-26 12:22:52 --> Hooks Class Initialized
DEBUG - 2016-09-26 12:22:52 --> UTF-8 Support Enabled
INFO - 2016-09-26 12:22:52 --> Utf8 Class Initialized
INFO - 2016-09-26 12:22:52 --> URI Class Initialized
INFO - 2016-09-26 12:22:52 --> Router Class Initialized
INFO - 2016-09-26 12:22:52 --> Output Class Initialized
INFO - 2016-09-26 12:22:52 --> Security Class Initialized
DEBUG - 2016-09-26 12:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 12:22:52 --> Input Class Initialized
INFO - 2016-09-26 12:22:52 --> Language Class Initialized
ERROR - 2016-09-26 12:22:52 --> 404 Page Not Found: /index
INFO - 2016-09-26 12:22:53 --> Config Class Initialized
INFO - 2016-09-26 12:22:53 --> Hooks Class Initialized
DEBUG - 2016-09-26 12:22:53 --> UTF-8 Support Enabled
INFO - 2016-09-26 12:22:53 --> Utf8 Class Initialized
INFO - 2016-09-26 12:22:53 --> URI Class Initialized
INFO - 2016-09-26 12:22:53 --> Router Class Initialized
INFO - 2016-09-26 12:22:53 --> Output Class Initialized
INFO - 2016-09-26 12:22:53 --> Security Class Initialized
DEBUG - 2016-09-26 12:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 12:22:53 --> Input Class Initialized
INFO - 2016-09-26 12:22:53 --> Language Class Initialized
ERROR - 2016-09-26 12:22:53 --> 404 Page Not Found: /index
INFO - 2016-09-26 12:22:53 --> Config Class Initialized
INFO - 2016-09-26 12:22:53 --> Hooks Class Initialized
DEBUG - 2016-09-26 12:22:53 --> UTF-8 Support Enabled
INFO - 2016-09-26 12:22:53 --> Utf8 Class Initialized
INFO - 2016-09-26 12:22:53 --> URI Class Initialized
INFO - 2016-09-26 12:22:53 --> Router Class Initialized
INFO - 2016-09-26 12:22:53 --> Output Class Initialized
INFO - 2016-09-26 12:22:53 --> Security Class Initialized
DEBUG - 2016-09-26 12:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 12:22:53 --> Input Class Initialized
INFO - 2016-09-26 12:22:53 --> Language Class Initialized
ERROR - 2016-09-26 12:22:53 --> 404 Page Not Found: /index
INFO - 2016-09-26 12:22:53 --> Config Class Initialized
INFO - 2016-09-26 12:22:53 --> Hooks Class Initialized
DEBUG - 2016-09-26 12:22:53 --> UTF-8 Support Enabled
INFO - 2016-09-26 12:22:53 --> Utf8 Class Initialized
INFO - 2016-09-26 12:22:53 --> URI Class Initialized
INFO - 2016-09-26 12:22:53 --> Router Class Initialized
INFO - 2016-09-26 12:22:53 --> Output Class Initialized
INFO - 2016-09-26 12:22:53 --> Security Class Initialized
DEBUG - 2016-09-26 12:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 12:22:53 --> Input Class Initialized
INFO - 2016-09-26 12:22:53 --> Language Class Initialized
ERROR - 2016-09-26 12:22:53 --> 404 Page Not Found: /index
INFO - 2016-09-26 12:22:54 --> Config Class Initialized
INFO - 2016-09-26 12:22:54 --> Hooks Class Initialized
DEBUG - 2016-09-26 12:22:54 --> UTF-8 Support Enabled
INFO - 2016-09-26 12:22:54 --> Utf8 Class Initialized
INFO - 2016-09-26 12:22:54 --> URI Class Initialized
INFO - 2016-09-26 12:22:54 --> Router Class Initialized
INFO - 2016-09-26 12:22:54 --> Output Class Initialized
INFO - 2016-09-26 12:22:54 --> Security Class Initialized
DEBUG - 2016-09-26 12:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 12:22:54 --> Input Class Initialized
INFO - 2016-09-26 12:22:54 --> Language Class Initialized
ERROR - 2016-09-26 12:22:54 --> 404 Page Not Found: /index
INFO - 2016-09-26 12:22:54 --> Config Class Initialized
INFO - 2016-09-26 12:22:54 --> Hooks Class Initialized
DEBUG - 2016-09-26 12:22:54 --> UTF-8 Support Enabled
INFO - 2016-09-26 12:22:54 --> Utf8 Class Initialized
INFO - 2016-09-26 12:22:54 --> URI Class Initialized
INFO - 2016-09-26 12:22:54 --> Router Class Initialized
INFO - 2016-09-26 12:22:54 --> Output Class Initialized
INFO - 2016-09-26 12:22:54 --> Security Class Initialized
DEBUG - 2016-09-26 12:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 12:22:54 --> Input Class Initialized
INFO - 2016-09-26 12:22:54 --> Language Class Initialized
ERROR - 2016-09-26 12:22:54 --> 404 Page Not Found: /index
INFO - 2016-09-26 13:49:26 --> Config Class Initialized
INFO - 2016-09-26 13:49:26 --> Hooks Class Initialized
DEBUG - 2016-09-26 13:49:26 --> UTF-8 Support Enabled
INFO - 2016-09-26 13:49:26 --> Utf8 Class Initialized
INFO - 2016-09-26 13:49:26 --> URI Class Initialized
DEBUG - 2016-09-26 13:49:26 --> No URI present. Default controller set.
INFO - 2016-09-26 13:49:26 --> Router Class Initialized
INFO - 2016-09-26 13:49:26 --> Output Class Initialized
INFO - 2016-09-26 13:49:26 --> Security Class Initialized
DEBUG - 2016-09-26 13:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 13:49:26 --> Input Class Initialized
INFO - 2016-09-26 13:49:26 --> Language Class Initialized
INFO - 2016-09-26 13:49:26 --> Language Class Initialized
INFO - 2016-09-26 13:49:26 --> Config Class Initialized
INFO - 2016-09-26 13:49:26 --> Loader Class Initialized
INFO - 2016-09-26 13:49:26 --> Helper loaded: url_helper
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 13:49:26 --> Controller Class Initialized
DEBUG - 2016-09-26 13:49:26 --> Index MX_Controller Initialized
INFO - 2016-09-26 13:49:26 --> Model Class Initialized
INFO - 2016-09-26 13:49:26 --> Model Class Initialized
ERROR - 2016-09-26 13:49:26 --> Unable to delete cache file for 
DEBUG - 2016-09-26 13:49:26 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-26 13:49:26 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-26 13:49:26 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-26 13:49:26 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-26 13:49:26 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-26 13:49:26 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:26 --> Database Driver Class Initialized
DEBUG - 2016-09-26 13:49:26 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-26 13:49:26 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-26 13:49:26 --> Final output sent to browser
DEBUG - 2016-09-26 13:49:26 --> Total execution time: 0.1176
INFO - 2016-09-26 13:49:27 --> Config Class Initialized
INFO - 2016-09-26 13:49:27 --> Hooks Class Initialized
DEBUG - 2016-09-26 13:49:27 --> UTF-8 Support Enabled
INFO - 2016-09-26 13:49:27 --> Utf8 Class Initialized
INFO - 2016-09-26 13:49:27 --> URI Class Initialized
DEBUG - 2016-09-26 13:49:27 --> No URI present. Default controller set.
INFO - 2016-09-26 13:49:27 --> Router Class Initialized
INFO - 2016-09-26 13:49:27 --> Output Class Initialized
INFO - 2016-09-26 13:49:27 --> Security Class Initialized
DEBUG - 2016-09-26 13:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 13:49:27 --> Input Class Initialized
INFO - 2016-09-26 13:49:27 --> Language Class Initialized
INFO - 2016-09-26 13:49:27 --> Language Class Initialized
INFO - 2016-09-26 13:49:27 --> Config Class Initialized
INFO - 2016-09-26 13:49:27 --> Loader Class Initialized
INFO - 2016-09-26 13:49:27 --> Helper loaded: url_helper
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 13:49:27 --> Controller Class Initialized
DEBUG - 2016-09-26 13:49:27 --> Index MX_Controller Initialized
INFO - 2016-09-26 13:49:27 --> Model Class Initialized
INFO - 2016-09-26 13:49:27 --> Model Class Initialized
ERROR - 2016-09-26 13:49:27 --> Unable to delete cache file for 
DEBUG - 2016-09-26 13:49:27 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-26 13:49:27 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-26 13:49:27 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-26 13:49:27 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-26 13:49:27 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-26 13:49:27 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
INFO - 2016-09-26 13:49:27 --> Database Driver Class Initialized
DEBUG - 2016-09-26 13:49:27 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-26 13:49:27 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-26 13:49:27 --> Final output sent to browser
DEBUG - 2016-09-26 13:49:27 --> Total execution time: 0.0896
INFO - 2016-09-26 16:01:26 --> Config Class Initialized
INFO - 2016-09-26 16:01:26 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:01:26 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:01:26 --> Utf8 Class Initialized
INFO - 2016-09-26 16:01:26 --> URI Class Initialized
INFO - 2016-09-26 16:01:26 --> Router Class Initialized
INFO - 2016-09-26 16:01:26 --> Output Class Initialized
INFO - 2016-09-26 16:01:26 --> Security Class Initialized
DEBUG - 2016-09-26 16:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:01:26 --> Input Class Initialized
INFO - 2016-09-26 16:01:26 --> Language Class Initialized
INFO - 2016-09-26 16:01:26 --> Language Class Initialized
INFO - 2016-09-26 16:01:26 --> Config Class Initialized
INFO - 2016-09-26 16:01:26 --> Loader Class Initialized
INFO - 2016-09-26 16:01:26 --> Helper loaded: url_helper
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 16:01:26 --> Controller Class Initialized
DEBUG - 2016-09-26 16:01:26 --> Index MX_Controller Initialized
INFO - 2016-09-26 16:01:26 --> Model Class Initialized
INFO - 2016-09-26 16:01:26 --> Model Class Initialized
ERROR - 2016-09-26 16:01:26 --> Unable to delete cache file for admin/index/data_biaya
DEBUG - 2016-09-26 16:01:26 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-26 16:01:26 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-26 16:01:26 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-26 16:01:26 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/list_biaya.php
DEBUG - 2016-09-26 16:01:26 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-26 16:01:26 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
DEBUG - 2016-09-26 16:01:26 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-26 16:01:26 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-26 16:01:26 --> Final output sent to browser
DEBUG - 2016-09-26 16:01:26 --> Total execution time: 0.1220
INFO - 2016-09-26 16:01:26 --> Config Class Initialized
INFO - 2016-09-26 16:01:26 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:01:26 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:01:26 --> Utf8 Class Initialized
INFO - 2016-09-26 16:01:26 --> URI Class Initialized
INFO - 2016-09-26 16:01:26 --> Router Class Initialized
INFO - 2016-09-26 16:01:26 --> Output Class Initialized
INFO - 2016-09-26 16:01:26 --> Security Class Initialized
DEBUG - 2016-09-26 16:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:01:26 --> Input Class Initialized
INFO - 2016-09-26 16:01:26 --> Language Class Initialized
INFO - 2016-09-26 16:01:26 --> Language Class Initialized
INFO - 2016-09-26 16:01:26 --> Config Class Initialized
INFO - 2016-09-26 16:01:26 --> Loader Class Initialized
INFO - 2016-09-26 16:01:26 --> Helper loaded: url_helper
INFO - 2016-09-26 16:01:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 16:01:26 --> Controller Class Initialized
DEBUG - 2016-09-26 16:01:26 --> login MX_Controller Initialized
INFO - 2016-09-26 16:01:26 --> Model Class Initialized
INFO - 2016-09-26 16:01:26 --> Model Class Initialized
DEBUG - 2016-09-26 16:01:26 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-26 16:01:26 --> Final output sent to browser
DEBUG - 2016-09-26 16:01:26 --> Total execution time: 0.0239
INFO - 2016-09-26 16:04:58 --> Config Class Initialized
INFO - 2016-09-26 16:04:58 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:04:58 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:04:58 --> Utf8 Class Initialized
INFO - 2016-09-26 16:04:58 --> URI Class Initialized
DEBUG - 2016-09-26 16:04:58 --> No URI present. Default controller set.
INFO - 2016-09-26 16:04:58 --> Router Class Initialized
INFO - 2016-09-26 16:04:58 --> Output Class Initialized
INFO - 2016-09-26 16:04:58 --> Security Class Initialized
DEBUG - 2016-09-26 16:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:04:58 --> Input Class Initialized
INFO - 2016-09-26 16:04:58 --> Language Class Initialized
INFO - 2016-09-26 16:04:58 --> Language Class Initialized
INFO - 2016-09-26 16:04:58 --> Config Class Initialized
INFO - 2016-09-26 16:04:58 --> Loader Class Initialized
INFO - 2016-09-26 16:04:58 --> Helper loaded: url_helper
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 16:04:58 --> Controller Class Initialized
DEBUG - 2016-09-26 16:04:58 --> Index MX_Controller Initialized
INFO - 2016-09-26 16:04:58 --> Model Class Initialized
INFO - 2016-09-26 16:04:58 --> Model Class Initialized
ERROR - 2016-09-26 16:04:58 --> Unable to delete cache file for 
DEBUG - 2016-09-26 16:04:58 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-26 16:04:58 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-26 16:04:58 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-26 16:04:58 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-26 16:04:58 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-26 16:04:58 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:04:58 --> Database Driver Class Initialized
DEBUG - 2016-09-26 16:04:58 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-26 16:04:58 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-26 16:04:58 --> Final output sent to browser
DEBUG - 2016-09-26 16:04:58 --> Total execution time: 0.1755
INFO - 2016-09-26 16:05:00 --> Config Class Initialized
INFO - 2016-09-26 16:05:00 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:05:00 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:05:00 --> Utf8 Class Initialized
INFO - 2016-09-26 16:05:00 --> URI Class Initialized
INFO - 2016-09-26 16:05:00 --> Router Class Initialized
INFO - 2016-09-26 16:05:00 --> Output Class Initialized
INFO - 2016-09-26 16:05:00 --> Security Class Initialized
DEBUG - 2016-09-26 16:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:05:00 --> Input Class Initialized
INFO - 2016-09-26 16:05:00 --> Language Class Initialized
INFO - 2016-09-26 16:05:00 --> Language Class Initialized
INFO - 2016-09-26 16:05:00 --> Config Class Initialized
INFO - 2016-09-26 16:05:00 --> Loader Class Initialized
INFO - 2016-09-26 16:05:00 --> Helper loaded: url_helper
INFO - 2016-09-26 16:05:00 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 16:05:00 --> Controller Class Initialized
DEBUG - 2016-09-26 16:05:00 --> login MX_Controller Initialized
INFO - 2016-09-26 16:05:00 --> Model Class Initialized
INFO - 2016-09-26 16:05:00 --> Model Class Initialized
DEBUG - 2016-09-26 16:05:00 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-26 16:05:00 --> Final output sent to browser
DEBUG - 2016-09-26 16:05:00 --> Total execution time: 0.0360
INFO - 2016-09-26 16:05:13 --> Config Class Initialized
INFO - 2016-09-26 16:05:13 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:05:13 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:05:13 --> Utf8 Class Initialized
INFO - 2016-09-26 16:05:13 --> URI Class Initialized
INFO - 2016-09-26 16:05:13 --> Router Class Initialized
INFO - 2016-09-26 16:05:13 --> Output Class Initialized
INFO - 2016-09-26 16:05:13 --> Security Class Initialized
DEBUG - 2016-09-26 16:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:05:13 --> Input Class Initialized
INFO - 2016-09-26 16:05:13 --> Language Class Initialized
INFO - 2016-09-26 16:05:13 --> Language Class Initialized
INFO - 2016-09-26 16:05:13 --> Config Class Initialized
INFO - 2016-09-26 16:05:13 --> Loader Class Initialized
INFO - 2016-09-26 16:05:13 --> Helper loaded: url_helper
INFO - 2016-09-26 16:05:13 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 16:05:13 --> Controller Class Initialized
DEBUG - 2016-09-26 16:05:13 --> login MX_Controller Initialized
INFO - 2016-09-26 16:05:13 --> Model Class Initialized
INFO - 2016-09-26 16:05:13 --> Model Class Initialized
INFO - 2016-09-26 16:05:13 --> Final output sent to browser
DEBUG - 2016-09-26 16:05:13 --> Total execution time: 0.0285
INFO - 2016-09-26 16:05:15 --> Config Class Initialized
INFO - 2016-09-26 16:05:15 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:05:15 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:05:15 --> Utf8 Class Initialized
INFO - 2016-09-26 16:05:15 --> URI Class Initialized
INFO - 2016-09-26 16:05:15 --> Router Class Initialized
INFO - 2016-09-26 16:05:16 --> Output Class Initialized
INFO - 2016-09-26 16:05:16 --> Security Class Initialized
DEBUG - 2016-09-26 16:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:05:16 --> Input Class Initialized
INFO - 2016-09-26 16:05:16 --> Language Class Initialized
INFO - 2016-09-26 16:05:16 --> Language Class Initialized
INFO - 2016-09-26 16:05:16 --> Config Class Initialized
INFO - 2016-09-26 16:05:16 --> Loader Class Initialized
INFO - 2016-09-26 16:05:16 --> Helper loaded: url_helper
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 16:05:16 --> Controller Class Initialized
DEBUG - 2016-09-26 16:05:16 --> Index MX_Controller Initialized
INFO - 2016-09-26 16:05:16 --> Model Class Initialized
INFO - 2016-09-26 16:05:16 --> Model Class Initialized
ERROR - 2016-09-26 16:05:16 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-26 16:05:16 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-26 16:05:16 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-26 16:05:16 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-26 16:05:16 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-26 16:05:16 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-26 16:05:16 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:16 --> Database Driver Class Initialized
DEBUG - 2016-09-26 16:05:16 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-26 16:05:16 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-26 16:05:16 --> Final output sent to browser
DEBUG - 2016-09-26 16:05:16 --> Total execution time: 0.1321
INFO - 2016-09-26 16:05:18 --> Config Class Initialized
INFO - 2016-09-26 16:05:18 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:05:18 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:05:18 --> Utf8 Class Initialized
INFO - 2016-09-26 16:05:18 --> URI Class Initialized
INFO - 2016-09-26 16:05:18 --> Router Class Initialized
INFO - 2016-09-26 16:05:18 --> Output Class Initialized
INFO - 2016-09-26 16:05:18 --> Security Class Initialized
DEBUG - 2016-09-26 16:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:05:18 --> Input Class Initialized
INFO - 2016-09-26 16:05:18 --> Language Class Initialized
ERROR - 2016-09-26 16:05:18 --> 404 Page Not Found: /index
INFO - 2016-09-26 16:08:52 --> Config Class Initialized
INFO - 2016-09-26 16:08:52 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:08:52 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:08:52 --> Utf8 Class Initialized
INFO - 2016-09-26 16:08:52 --> URI Class Initialized
INFO - 2016-09-26 16:08:52 --> Router Class Initialized
INFO - 2016-09-26 16:08:52 --> Output Class Initialized
INFO - 2016-09-26 16:08:52 --> Security Class Initialized
DEBUG - 2016-09-26 16:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:08:52 --> Input Class Initialized
INFO - 2016-09-26 16:08:52 --> Language Class Initialized
INFO - 2016-09-26 16:08:52 --> Language Class Initialized
INFO - 2016-09-26 16:08:52 --> Config Class Initialized
INFO - 2016-09-26 16:08:52 --> Loader Class Initialized
INFO - 2016-09-26 16:08:52 --> Helper loaded: url_helper
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 16:08:52 --> Controller Class Initialized
DEBUG - 2016-09-26 16:08:52 --> Index MX_Controller Initialized
INFO - 2016-09-26 16:08:52 --> Model Class Initialized
INFO - 2016-09-26 16:08:52 --> Model Class Initialized
ERROR - 2016-09-26 16:08:52 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-26 16:08:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-26 16:08:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-26 16:08:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-26 16:08:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-26 16:08:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-26 16:08:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:52 --> Database Driver Class Initialized
DEBUG - 2016-09-26 16:08:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-26 16:08:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-26 16:08:52 --> Final output sent to browser
DEBUG - 2016-09-26 16:08:52 --> Total execution time: 0.1073
INFO - 2016-09-26 16:08:53 --> Config Class Initialized
INFO - 2016-09-26 16:08:53 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:08:53 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:08:53 --> Utf8 Class Initialized
INFO - 2016-09-26 16:08:53 --> URI Class Initialized
INFO - 2016-09-26 16:08:53 --> Router Class Initialized
INFO - 2016-09-26 16:08:53 --> Output Class Initialized
INFO - 2016-09-26 16:08:53 --> Security Class Initialized
DEBUG - 2016-09-26 16:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:08:53 --> Input Class Initialized
INFO - 2016-09-26 16:08:53 --> Language Class Initialized
ERROR - 2016-09-26 16:08:53 --> 404 Page Not Found: /index
INFO - 2016-09-26 16:10:52 --> Config Class Initialized
INFO - 2016-09-26 16:10:52 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:10:52 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:10:52 --> Utf8 Class Initialized
INFO - 2016-09-26 16:10:52 --> URI Class Initialized
INFO - 2016-09-26 16:10:52 --> Router Class Initialized
INFO - 2016-09-26 16:10:52 --> Output Class Initialized
INFO - 2016-09-26 16:10:52 --> Security Class Initialized
DEBUG - 2016-09-26 16:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:10:52 --> Input Class Initialized
INFO - 2016-09-26 16:10:52 --> Language Class Initialized
INFO - 2016-09-26 16:10:52 --> Language Class Initialized
INFO - 2016-09-26 16:10:52 --> Config Class Initialized
INFO - 2016-09-26 16:10:52 --> Loader Class Initialized
INFO - 2016-09-26 16:10:52 --> Helper loaded: url_helper
INFO - 2016-09-26 16:10:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 16:10:52 --> Controller Class Initialized
DEBUG - 2016-09-26 16:10:52 --> Index MX_Controller Initialized
INFO - 2016-09-26 16:10:52 --> Model Class Initialized
INFO - 2016-09-26 16:10:52 --> Model Class Initialized
ERROR - 2016-09-26 16:10:52 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-26 16:10:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-26 16:10:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-26 16:10:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-26 16:10:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-26 16:10:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-26 16:10:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
ERROR - 2016-09-26 16:10:52 --> Severity: Parsing Error --> syntax error, unexpected ''admin/index/' (T_ENCAPSED_AND_WHITESPACE) /home/koperasi/public_html/application/views/main_html/script.php 264
INFO - 2016-09-26 16:11:06 --> Config Class Initialized
INFO - 2016-09-26 16:11:06 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:11:06 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:11:06 --> Utf8 Class Initialized
INFO - 2016-09-26 16:11:06 --> URI Class Initialized
INFO - 2016-09-26 16:11:06 --> Router Class Initialized
INFO - 2016-09-26 16:11:06 --> Output Class Initialized
INFO - 2016-09-26 16:11:06 --> Security Class Initialized
DEBUG - 2016-09-26 16:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:11:06 --> Input Class Initialized
INFO - 2016-09-26 16:11:06 --> Language Class Initialized
INFO - 2016-09-26 16:11:06 --> Language Class Initialized
INFO - 2016-09-26 16:11:06 --> Config Class Initialized
INFO - 2016-09-26 16:11:06 --> Loader Class Initialized
INFO - 2016-09-26 16:11:06 --> Helper loaded: url_helper
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 16:11:06 --> Controller Class Initialized
DEBUG - 2016-09-26 16:11:06 --> Index MX_Controller Initialized
INFO - 2016-09-26 16:11:06 --> Model Class Initialized
INFO - 2016-09-26 16:11:06 --> Model Class Initialized
ERROR - 2016-09-26 16:11:06 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-26 16:11:06 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-26 16:11:06 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-26 16:11:06 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-26 16:11:06 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-26 16:11:06 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-26 16:11:06 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:06 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:07 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:07 --> Database Driver Class Initialized
DEBUG - 2016-09-26 16:11:07 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-26 16:11:07 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-26 16:11:07 --> Final output sent to browser
DEBUG - 2016-09-26 16:11:07 --> Total execution time: 0.1702
INFO - 2016-09-26 16:11:07 --> Config Class Initialized
INFO - 2016-09-26 16:11:07 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:11:07 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:11:07 --> Utf8 Class Initialized
INFO - 2016-09-26 16:11:07 --> URI Class Initialized
INFO - 2016-09-26 16:11:07 --> Router Class Initialized
INFO - 2016-09-26 16:11:07 --> Output Class Initialized
INFO - 2016-09-26 16:11:07 --> Security Class Initialized
DEBUG - 2016-09-26 16:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:11:07 --> Input Class Initialized
INFO - 2016-09-26 16:11:07 --> Language Class Initialized
ERROR - 2016-09-26 16:11:07 --> 404 Page Not Found: /index
INFO - 2016-09-26 16:11:25 --> Config Class Initialized
INFO - 2016-09-26 16:11:25 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:11:25 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:11:25 --> Utf8 Class Initialized
INFO - 2016-09-26 16:11:25 --> URI Class Initialized
INFO - 2016-09-26 16:11:25 --> Router Class Initialized
INFO - 2016-09-26 16:11:25 --> Output Class Initialized
INFO - 2016-09-26 16:11:25 --> Security Class Initialized
DEBUG - 2016-09-26 16:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:11:25 --> Input Class Initialized
INFO - 2016-09-26 16:11:25 --> Language Class Initialized
INFO - 2016-09-26 16:11:25 --> Language Class Initialized
INFO - 2016-09-26 16:11:25 --> Config Class Initialized
INFO - 2016-09-26 16:11:25 --> Loader Class Initialized
INFO - 2016-09-26 16:11:25 --> Helper loaded: url_helper
INFO - 2016-09-26 16:11:25 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 16:11:25 --> Controller Class Initialized
DEBUG - 2016-09-26 16:11:25 --> Index MX_Controller Initialized
INFO - 2016-09-26 16:11:25 --> Model Class Initialized
INFO - 2016-09-26 16:11:25 --> Model Class Initialized
ERROR - 2016-09-26 16:11:25 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-26 16:11:25 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-26 16:11:25 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-26 16:11:25 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-26 16:11:25 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-26 16:11:25 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-26 16:11:25 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
DEBUG - 2016-09-26 16:11:25 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-26 16:11:25 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-26 16:11:25 --> Final output sent to browser
DEBUG - 2016-09-26 16:11:25 --> Total execution time: 0.0329
INFO - 2016-09-26 16:11:29 --> Config Class Initialized
INFO - 2016-09-26 16:11:29 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:11:29 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:11:29 --> Utf8 Class Initialized
INFO - 2016-09-26 16:11:29 --> URI Class Initialized
INFO - 2016-09-26 16:11:29 --> Router Class Initialized
INFO - 2016-09-26 16:11:29 --> Output Class Initialized
INFO - 2016-09-26 16:11:29 --> Security Class Initialized
DEBUG - 2016-09-26 16:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:11:29 --> Input Class Initialized
INFO - 2016-09-26 16:11:29 --> Language Class Initialized
INFO - 2016-09-26 16:11:29 --> Language Class Initialized
INFO - 2016-09-26 16:11:29 --> Config Class Initialized
INFO - 2016-09-26 16:11:29 --> Loader Class Initialized
INFO - 2016-09-26 16:11:29 --> Helper loaded: url_helper
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 16:11:29 --> Controller Class Initialized
DEBUG - 2016-09-26 16:11:29 --> Index MX_Controller Initialized
INFO - 2016-09-26 16:11:29 --> Model Class Initialized
INFO - 2016-09-26 16:11:29 --> Model Class Initialized
ERROR - 2016-09-26 16:11:29 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-26 16:11:29 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-26 16:11:29 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-26 16:11:29 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-26 16:11:29 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-26 16:11:29 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-26 16:11:29 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:29 --> Database Driver Class Initialized
DEBUG - 2016-09-26 16:11:29 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-26 16:11:29 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-26 16:11:29 --> Final output sent to browser
DEBUG - 2016-09-26 16:11:29 --> Total execution time: 0.0812
INFO - 2016-09-26 16:11:31 --> Config Class Initialized
INFO - 2016-09-26 16:11:31 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:11:31 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:11:31 --> Utf8 Class Initialized
INFO - 2016-09-26 16:11:31 --> URI Class Initialized
INFO - 2016-09-26 16:11:31 --> Router Class Initialized
INFO - 2016-09-26 16:11:31 --> Output Class Initialized
INFO - 2016-09-26 16:11:31 --> Security Class Initialized
DEBUG - 2016-09-26 16:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:11:31 --> Input Class Initialized
INFO - 2016-09-26 16:11:31 --> Language Class Initialized
ERROR - 2016-09-26 16:11:31 --> 404 Page Not Found: /index
INFO - 2016-09-26 16:11:32 --> Config Class Initialized
INFO - 2016-09-26 16:11:32 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:11:32 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:11:32 --> Utf8 Class Initialized
INFO - 2016-09-26 16:11:32 --> URI Class Initialized
INFO - 2016-09-26 16:11:32 --> Router Class Initialized
INFO - 2016-09-26 16:11:32 --> Output Class Initialized
INFO - 2016-09-26 16:11:32 --> Security Class Initialized
DEBUG - 2016-09-26 16:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:11:32 --> Input Class Initialized
INFO - 2016-09-26 16:11:32 --> Language Class Initialized
ERROR - 2016-09-26 16:11:32 --> 404 Page Not Found: /index
INFO - 2016-09-26 16:12:05 --> Config Class Initialized
INFO - 2016-09-26 16:12:05 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:12:05 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:12:05 --> Utf8 Class Initialized
INFO - 2016-09-26 16:12:05 --> URI Class Initialized
INFO - 2016-09-26 16:12:05 --> Router Class Initialized
INFO - 2016-09-26 16:12:05 --> Output Class Initialized
INFO - 2016-09-26 16:12:05 --> Security Class Initialized
DEBUG - 2016-09-26 16:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:12:05 --> Input Class Initialized
INFO - 2016-09-26 16:12:05 --> Language Class Initialized
INFO - 2016-09-26 16:12:05 --> Language Class Initialized
INFO - 2016-09-26 16:12:05 --> Config Class Initialized
INFO - 2016-09-26 16:12:05 --> Loader Class Initialized
INFO - 2016-09-26 16:12:05 --> Helper loaded: url_helper
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 16:12:05 --> Controller Class Initialized
DEBUG - 2016-09-26 16:12:05 --> Index MX_Controller Initialized
INFO - 2016-09-26 16:12:05 --> Model Class Initialized
INFO - 2016-09-26 16:12:05 --> Model Class Initialized
ERROR - 2016-09-26 16:12:05 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-26 16:12:05 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-26 16:12:05 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-26 16:12:05 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-26 16:12:05 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-26 16:12:05 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-26 16:12:05 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:05 --> Database Driver Class Initialized
DEBUG - 2016-09-26 16:12:05 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-26 16:12:05 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-26 16:12:05 --> Final output sent to browser
DEBUG - 2016-09-26 16:12:05 --> Total execution time: 0.1841
INFO - 2016-09-26 16:12:05 --> Config Class Initialized
INFO - 2016-09-26 16:12:05 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:12:05 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:12:05 --> Utf8 Class Initialized
INFO - 2016-09-26 16:12:05 --> URI Class Initialized
INFO - 2016-09-26 16:12:05 --> Router Class Initialized
INFO - 2016-09-26 16:12:05 --> Output Class Initialized
INFO - 2016-09-26 16:12:05 --> Security Class Initialized
DEBUG - 2016-09-26 16:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:12:05 --> Input Class Initialized
INFO - 2016-09-26 16:12:05 --> Language Class Initialized
ERROR - 2016-09-26 16:12:05 --> 404 Page Not Found: /index
INFO - 2016-09-26 16:12:06 --> Config Class Initialized
INFO - 2016-09-26 16:12:06 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:12:06 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:12:06 --> Utf8 Class Initialized
INFO - 2016-09-26 16:12:06 --> URI Class Initialized
INFO - 2016-09-26 16:12:06 --> Router Class Initialized
INFO - 2016-09-26 16:12:06 --> Output Class Initialized
INFO - 2016-09-26 16:12:06 --> Security Class Initialized
DEBUG - 2016-09-26 16:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:12:06 --> Input Class Initialized
INFO - 2016-09-26 16:12:06 --> Language Class Initialized
ERROR - 2016-09-26 16:12:06 --> 404 Page Not Found: /index
INFO - 2016-09-26 16:12:21 --> Config Class Initialized
INFO - 2016-09-26 16:12:21 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:12:21 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:12:21 --> Utf8 Class Initialized
INFO - 2016-09-26 16:12:21 --> URI Class Initialized
INFO - 2016-09-26 16:12:21 --> Router Class Initialized
INFO - 2016-09-26 16:12:21 --> Output Class Initialized
INFO - 2016-09-26 16:12:21 --> Security Class Initialized
DEBUG - 2016-09-26 16:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:12:21 --> Input Class Initialized
INFO - 2016-09-26 16:12:21 --> Language Class Initialized
INFO - 2016-09-26 16:12:21 --> Language Class Initialized
INFO - 2016-09-26 16:12:21 --> Config Class Initialized
INFO - 2016-09-26 16:12:21 --> Loader Class Initialized
INFO - 2016-09-26 16:12:21 --> Helper loaded: url_helper
INFO - 2016-09-26 16:12:21 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 16:12:21 --> Controller Class Initialized
DEBUG - 2016-09-26 16:12:21 --> Index MX_Controller Initialized
INFO - 2016-09-26 16:12:21 --> Model Class Initialized
INFO - 2016-09-26 16:12:21 --> Model Class Initialized
ERROR - 2016-09-26 16:12:21 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-26 16:12:21 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-26 16:12:21 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-26 16:12:21 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-26 16:12:21 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-26 16:12:21 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-26 16:12:21 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-26 16:12:21 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:21 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:21 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:21 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:21 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:21 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:21 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:21 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:21 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:21 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:21 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:21 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:21 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:21 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:21 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:21 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:22 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:22 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:22 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:22 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:22 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:22 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:22 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:22 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:22 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:22 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:22 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:22 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:22 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:22 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:22 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:22 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:22 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:22 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:22 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:22 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:22 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:22 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:22 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:22 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:22 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:22 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:22 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:22 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:22 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:22 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:22 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:22 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:22 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:22 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:22 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:22 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:22 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:22 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:22 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:22 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:22 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:22 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:22 --> Database Driver Class Initialized
DEBUG - 2016-09-26 16:12:22 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-26 16:12:22 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-26 16:12:22 --> Final output sent to browser
DEBUG - 2016-09-26 16:12:22 --> Total execution time: 0.1236
INFO - 2016-09-26 16:12:22 --> Config Class Initialized
INFO - 2016-09-26 16:12:22 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:12:22 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:12:22 --> Utf8 Class Initialized
INFO - 2016-09-26 16:12:22 --> URI Class Initialized
INFO - 2016-09-26 16:12:22 --> Router Class Initialized
INFO - 2016-09-26 16:12:22 --> Output Class Initialized
INFO - 2016-09-26 16:12:22 --> Security Class Initialized
DEBUG - 2016-09-26 16:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:12:22 --> Input Class Initialized
INFO - 2016-09-26 16:12:22 --> Language Class Initialized
ERROR - 2016-09-26 16:12:22 --> 404 Page Not Found: /index
INFO - 2016-09-26 16:12:23 --> Config Class Initialized
INFO - 2016-09-26 16:12:23 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:12:23 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:12:23 --> Utf8 Class Initialized
INFO - 2016-09-26 16:12:23 --> URI Class Initialized
INFO - 2016-09-26 16:12:23 --> Router Class Initialized
INFO - 2016-09-26 16:12:23 --> Output Class Initialized
INFO - 2016-09-26 16:12:23 --> Security Class Initialized
DEBUG - 2016-09-26 16:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:12:23 --> Input Class Initialized
INFO - 2016-09-26 16:12:23 --> Language Class Initialized
ERROR - 2016-09-26 16:12:23 --> 404 Page Not Found: /index
INFO - 2016-09-26 16:17:34 --> Config Class Initialized
INFO - 2016-09-26 16:17:34 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:17:34 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:17:34 --> Utf8 Class Initialized
INFO - 2016-09-26 16:17:34 --> URI Class Initialized
INFO - 2016-09-26 16:17:34 --> Router Class Initialized
INFO - 2016-09-26 16:17:34 --> Output Class Initialized
INFO - 2016-09-26 16:17:34 --> Security Class Initialized
DEBUG - 2016-09-26 16:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:17:34 --> Input Class Initialized
INFO - 2016-09-26 16:17:34 --> Language Class Initialized
INFO - 2016-09-26 16:17:34 --> Language Class Initialized
INFO - 2016-09-26 16:17:34 --> Config Class Initialized
INFO - 2016-09-26 16:17:34 --> Loader Class Initialized
INFO - 2016-09-26 16:17:34 --> Helper loaded: url_helper
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 16:17:34 --> Controller Class Initialized
DEBUG - 2016-09-26 16:17:34 --> Index MX_Controller Initialized
INFO - 2016-09-26 16:17:34 --> Model Class Initialized
INFO - 2016-09-26 16:17:34 --> Model Class Initialized
ERROR - 2016-09-26 16:17:34 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-26 16:17:34 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-26 16:17:34 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-26 16:17:34 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-26 16:17:34 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-26 16:17:34 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-26 16:17:34 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:17:34 --> Database Driver Class Initialized
DEBUG - 2016-09-26 16:17:34 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-26 16:17:34 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-26 16:17:34 --> Final output sent to browser
DEBUG - 2016-09-26 16:17:34 --> Total execution time: 0.0947
INFO - 2016-09-26 16:17:35 --> Config Class Initialized
INFO - 2016-09-26 16:17:35 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:17:35 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:17:35 --> Utf8 Class Initialized
INFO - 2016-09-26 16:17:35 --> URI Class Initialized
INFO - 2016-09-26 16:17:35 --> Router Class Initialized
INFO - 2016-09-26 16:17:35 --> Output Class Initialized
INFO - 2016-09-26 16:17:35 --> Security Class Initialized
DEBUG - 2016-09-26 16:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:17:35 --> Input Class Initialized
INFO - 2016-09-26 16:17:35 --> Language Class Initialized
ERROR - 2016-09-26 16:17:35 --> 404 Page Not Found: /index
INFO - 2016-09-26 16:18:58 --> Config Class Initialized
INFO - 2016-09-26 16:18:58 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:18:58 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:18:58 --> Utf8 Class Initialized
INFO - 2016-09-26 16:18:58 --> URI Class Initialized
INFO - 2016-09-26 16:18:58 --> Router Class Initialized
INFO - 2016-09-26 16:18:58 --> Output Class Initialized
INFO - 2016-09-26 16:18:58 --> Security Class Initialized
DEBUG - 2016-09-26 16:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:18:58 --> Input Class Initialized
INFO - 2016-09-26 16:18:58 --> Language Class Initialized
INFO - 2016-09-26 16:18:58 --> Language Class Initialized
INFO - 2016-09-26 16:18:58 --> Config Class Initialized
INFO - 2016-09-26 16:18:58 --> Loader Class Initialized
INFO - 2016-09-26 16:18:58 --> Helper loaded: url_helper
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 16:18:58 --> Controller Class Initialized
DEBUG - 2016-09-26 16:18:58 --> Index MX_Controller Initialized
INFO - 2016-09-26 16:18:58 --> Model Class Initialized
INFO - 2016-09-26 16:18:58 --> Model Class Initialized
ERROR - 2016-09-26 16:18:58 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-26 16:18:58 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-26 16:18:58 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-26 16:18:58 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-26 16:18:58 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-26 16:18:58 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-26 16:18:58 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
INFO - 2016-09-26 16:18:58 --> Database Driver Class Initialized
DEBUG - 2016-09-26 16:18:58 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-26 16:18:58 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-26 16:18:58 --> Final output sent to browser
DEBUG - 2016-09-26 16:18:58 --> Total execution time: 0.1119
INFO - 2016-09-26 16:18:58 --> Config Class Initialized
INFO - 2016-09-26 16:18:58 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:18:58 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:18:58 --> Utf8 Class Initialized
INFO - 2016-09-26 16:18:58 --> URI Class Initialized
INFO - 2016-09-26 16:18:58 --> Router Class Initialized
INFO - 2016-09-26 16:18:58 --> Output Class Initialized
INFO - 2016-09-26 16:18:58 --> Security Class Initialized
DEBUG - 2016-09-26 16:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:18:58 --> Input Class Initialized
INFO - 2016-09-26 16:18:58 --> Language Class Initialized
ERROR - 2016-09-26 16:18:58 --> 404 Page Not Found: /index
INFO - 2016-09-26 16:18:59 --> Config Class Initialized
INFO - 2016-09-26 16:18:59 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:18:59 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:18:59 --> Utf8 Class Initialized
INFO - 2016-09-26 16:18:59 --> URI Class Initialized
INFO - 2016-09-26 16:18:59 --> Router Class Initialized
INFO - 2016-09-26 16:18:59 --> Output Class Initialized
INFO - 2016-09-26 16:18:59 --> Security Class Initialized
DEBUG - 2016-09-26 16:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:18:59 --> Input Class Initialized
INFO - 2016-09-26 16:18:59 --> Language Class Initialized
ERROR - 2016-09-26 16:18:59 --> 404 Page Not Found: /index
INFO - 2016-09-26 16:22:16 --> Config Class Initialized
INFO - 2016-09-26 16:22:16 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:22:16 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:22:16 --> Utf8 Class Initialized
INFO - 2016-09-26 16:22:16 --> URI Class Initialized
INFO - 2016-09-26 16:22:16 --> Router Class Initialized
INFO - 2016-09-26 16:22:16 --> Output Class Initialized
INFO - 2016-09-26 16:22:16 --> Security Class Initialized
DEBUG - 2016-09-26 16:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:22:16 --> Input Class Initialized
INFO - 2016-09-26 16:22:16 --> Language Class Initialized
INFO - 2016-09-26 16:22:16 --> Language Class Initialized
INFO - 2016-09-26 16:22:16 --> Config Class Initialized
INFO - 2016-09-26 16:22:16 --> Loader Class Initialized
INFO - 2016-09-26 16:22:16 --> Helper loaded: url_helper
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 16:22:16 --> Controller Class Initialized
DEBUG - 2016-09-26 16:22:16 --> Index MX_Controller Initialized
INFO - 2016-09-26 16:22:16 --> Model Class Initialized
INFO - 2016-09-26 16:22:16 --> Model Class Initialized
ERROR - 2016-09-26 16:22:16 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-26 16:22:16 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-26 16:22:16 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-26 16:22:16 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-26 16:22:16 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-26 16:22:16 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-26 16:22:16 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
INFO - 2016-09-26 16:22:16 --> Database Driver Class Initialized
DEBUG - 2016-09-26 16:22:16 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-26 16:22:16 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-26 16:22:16 --> Final output sent to browser
DEBUG - 2016-09-26 16:22:16 --> Total execution time: 0.1112
INFO - 2016-09-26 16:22:16 --> Config Class Initialized
INFO - 2016-09-26 16:22:16 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:22:16 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:22:16 --> Utf8 Class Initialized
INFO - 2016-09-26 16:22:16 --> URI Class Initialized
INFO - 2016-09-26 16:22:16 --> Router Class Initialized
INFO - 2016-09-26 16:22:16 --> Output Class Initialized
INFO - 2016-09-26 16:22:16 --> Security Class Initialized
DEBUG - 2016-09-26 16:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:22:16 --> Input Class Initialized
INFO - 2016-09-26 16:22:16 --> Language Class Initialized
ERROR - 2016-09-26 16:22:16 --> 404 Page Not Found: /index
INFO - 2016-09-26 16:22:17 --> Config Class Initialized
INFO - 2016-09-26 16:22:17 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:22:17 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:22:17 --> Utf8 Class Initialized
INFO - 2016-09-26 16:22:17 --> URI Class Initialized
INFO - 2016-09-26 16:22:17 --> Router Class Initialized
INFO - 2016-09-26 16:22:17 --> Output Class Initialized
INFO - 2016-09-26 16:22:17 --> Security Class Initialized
DEBUG - 2016-09-26 16:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:22:17 --> Input Class Initialized
INFO - 2016-09-26 16:22:17 --> Language Class Initialized
ERROR - 2016-09-26 16:22:17 --> 404 Page Not Found: /index
INFO - 2016-09-26 16:24:52 --> Config Class Initialized
INFO - 2016-09-26 16:24:52 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:24:52 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:24:52 --> Utf8 Class Initialized
INFO - 2016-09-26 16:24:52 --> URI Class Initialized
INFO - 2016-09-26 16:24:52 --> Router Class Initialized
INFO - 2016-09-26 16:24:52 --> Output Class Initialized
INFO - 2016-09-26 16:24:52 --> Security Class Initialized
DEBUG - 2016-09-26 16:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:24:52 --> Input Class Initialized
INFO - 2016-09-26 16:24:52 --> Language Class Initialized
INFO - 2016-09-26 16:24:52 --> Language Class Initialized
INFO - 2016-09-26 16:24:52 --> Config Class Initialized
INFO - 2016-09-26 16:24:52 --> Loader Class Initialized
INFO - 2016-09-26 16:24:52 --> Helper loaded: url_helper
INFO - 2016-09-26 16:24:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 16:24:52 --> Controller Class Initialized
DEBUG - 2016-09-26 16:24:52 --> Index MX_Controller Initialized
INFO - 2016-09-26 16:24:52 --> Model Class Initialized
INFO - 2016-09-26 16:24:52 --> Model Class Initialized
ERROR - 2016-09-26 16:24:52 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-26 16:24:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-26 16:24:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-26 16:24:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-26 16:24:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-26 16:24:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-26 16:24:52 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-26 16:24:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:52 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:53 --> Database Driver Class Initialized
INFO - 2016-09-26 16:24:53 --> Database Driver Class Initialized
DEBUG - 2016-09-26 16:24:53 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-26 16:24:53 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-26 16:24:53 --> Final output sent to browser
DEBUG - 2016-09-26 16:24:53 --> Total execution time: 0.1479
INFO - 2016-09-26 16:24:53 --> Config Class Initialized
INFO - 2016-09-26 16:24:53 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:24:53 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:24:53 --> Utf8 Class Initialized
INFO - 2016-09-26 16:24:53 --> URI Class Initialized
INFO - 2016-09-26 16:24:53 --> Router Class Initialized
INFO - 2016-09-26 16:24:53 --> Output Class Initialized
INFO - 2016-09-26 16:24:53 --> Security Class Initialized
DEBUG - 2016-09-26 16:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:24:53 --> Input Class Initialized
INFO - 2016-09-26 16:24:53 --> Language Class Initialized
ERROR - 2016-09-26 16:24:53 --> 404 Page Not Found: /index
INFO - 2016-09-26 16:26:57 --> Config Class Initialized
INFO - 2016-09-26 16:26:57 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:26:57 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:26:57 --> Utf8 Class Initialized
INFO - 2016-09-26 16:26:57 --> URI Class Initialized
INFO - 2016-09-26 16:26:57 --> Router Class Initialized
INFO - 2016-09-26 16:26:57 --> Output Class Initialized
INFO - 2016-09-26 16:26:57 --> Security Class Initialized
DEBUG - 2016-09-26 16:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:26:57 --> Input Class Initialized
INFO - 2016-09-26 16:26:57 --> Language Class Initialized
INFO - 2016-09-26 16:26:57 --> Language Class Initialized
INFO - 2016-09-26 16:26:57 --> Config Class Initialized
INFO - 2016-09-26 16:26:57 --> Loader Class Initialized
INFO - 2016-09-26 16:26:57 --> Helper loaded: url_helper
INFO - 2016-09-26 16:26:57 --> Database Driver Class Initialized
INFO - 2016-09-26 16:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 16:26:57 --> Controller Class Initialized
DEBUG - 2016-09-26 16:26:57 --> Index MX_Controller Initialized
INFO - 2016-09-26 16:26:57 --> Model Class Initialized
INFO - 2016-09-26 16:26:57 --> Model Class Initialized
ERROR - 2016-09-26 16:26:57 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-26 16:26:57 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-26 16:26:57 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-26 16:26:57 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-26 16:26:57 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-26 16:26:57 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-26 16:26:57 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
ERROR - 2016-09-26 16:26:57 --> Severity: Parsing Error --> syntax error, unexpected '}' /home/koperasi/public_html/application/views/main_html/script.php 223
INFO - 2016-09-26 16:27:04 --> Config Class Initialized
INFO - 2016-09-26 16:27:04 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:27:04 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:27:04 --> Utf8 Class Initialized
INFO - 2016-09-26 16:27:04 --> URI Class Initialized
INFO - 2016-09-26 16:27:04 --> Router Class Initialized
INFO - 2016-09-26 16:27:04 --> Output Class Initialized
INFO - 2016-09-26 16:27:04 --> Security Class Initialized
DEBUG - 2016-09-26 16:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:27:04 --> Input Class Initialized
INFO - 2016-09-26 16:27:04 --> Language Class Initialized
INFO - 2016-09-26 16:27:04 --> Language Class Initialized
INFO - 2016-09-26 16:27:04 --> Config Class Initialized
INFO - 2016-09-26 16:27:04 --> Loader Class Initialized
INFO - 2016-09-26 16:27:04 --> Helper loaded: url_helper
INFO - 2016-09-26 16:27:04 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 16:27:04 --> Controller Class Initialized
DEBUG - 2016-09-26 16:27:04 --> Index MX_Controller Initialized
INFO - 2016-09-26 16:27:04 --> Model Class Initialized
INFO - 2016-09-26 16:27:04 --> Model Class Initialized
ERROR - 2016-09-26 16:27:04 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-26 16:27:04 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-26 16:27:04 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-26 16:27:04 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-26 16:27:04 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-26 16:27:04 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-26 16:27:04 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
ERROR - 2016-09-26 16:27:04 --> Severity: Parsing Error --> syntax error, unexpected '}' /home/koperasi/public_html/application/views/main_html/script.php 223
INFO - 2016-09-26 16:27:48 --> Config Class Initialized
INFO - 2016-09-26 16:27:48 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:27:48 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:27:48 --> Utf8 Class Initialized
INFO - 2016-09-26 16:27:48 --> URI Class Initialized
INFO - 2016-09-26 16:27:48 --> Router Class Initialized
INFO - 2016-09-26 16:27:48 --> Output Class Initialized
INFO - 2016-09-26 16:27:48 --> Security Class Initialized
DEBUG - 2016-09-26 16:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:27:48 --> Input Class Initialized
INFO - 2016-09-26 16:27:48 --> Language Class Initialized
INFO - 2016-09-26 16:27:48 --> Language Class Initialized
INFO - 2016-09-26 16:27:48 --> Config Class Initialized
INFO - 2016-09-26 16:27:48 --> Loader Class Initialized
INFO - 2016-09-26 16:27:48 --> Helper loaded: url_helper
INFO - 2016-09-26 16:27:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 16:27:48 --> Controller Class Initialized
DEBUG - 2016-09-26 16:27:48 --> Index MX_Controller Initialized
INFO - 2016-09-26 16:27:48 --> Model Class Initialized
INFO - 2016-09-26 16:27:48 --> Model Class Initialized
ERROR - 2016-09-26 16:27:48 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-26 16:27:48 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-26 16:27:48 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-26 16:27:48 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-26 16:27:48 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-26 16:27:48 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-26 16:27:48 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-26 16:27:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:49 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:49 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:49 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:49 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:49 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:49 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:49 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:49 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:49 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:49 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:49 --> Database Driver Class Initialized
INFO - 2016-09-26 16:27:49 --> Database Driver Class Initialized
DEBUG - 2016-09-26 16:27:49 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-26 16:27:49 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-26 16:27:49 --> Final output sent to browser
DEBUG - 2016-09-26 16:27:49 --> Total execution time: 0.0918
INFO - 2016-09-26 16:27:49 --> Config Class Initialized
INFO - 2016-09-26 16:27:49 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:27:49 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:27:49 --> Utf8 Class Initialized
INFO - 2016-09-26 16:27:49 --> URI Class Initialized
INFO - 2016-09-26 16:27:49 --> Router Class Initialized
INFO - 2016-09-26 16:27:49 --> Output Class Initialized
INFO - 2016-09-26 16:27:49 --> Security Class Initialized
DEBUG - 2016-09-26 16:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:27:49 --> Input Class Initialized
INFO - 2016-09-26 16:27:49 --> Language Class Initialized
ERROR - 2016-09-26 16:27:49 --> 404 Page Not Found: /index
INFO - 2016-09-26 16:27:50 --> Config Class Initialized
INFO - 2016-09-26 16:27:50 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:27:50 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:27:50 --> Utf8 Class Initialized
INFO - 2016-09-26 16:27:50 --> URI Class Initialized
INFO - 2016-09-26 16:27:50 --> Router Class Initialized
INFO - 2016-09-26 16:27:50 --> Output Class Initialized
INFO - 2016-09-26 16:27:50 --> Security Class Initialized
DEBUG - 2016-09-26 16:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:27:50 --> Input Class Initialized
INFO - 2016-09-26 16:27:50 --> Language Class Initialized
ERROR - 2016-09-26 16:27:50 --> 404 Page Not Found: /index
INFO - 2016-09-26 16:28:19 --> Config Class Initialized
INFO - 2016-09-26 16:28:19 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:28:19 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:28:19 --> Utf8 Class Initialized
INFO - 2016-09-26 16:28:19 --> URI Class Initialized
INFO - 2016-09-26 16:28:19 --> Router Class Initialized
INFO - 2016-09-26 16:28:19 --> Output Class Initialized
INFO - 2016-09-26 16:28:19 --> Security Class Initialized
DEBUG - 2016-09-26 16:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:28:19 --> Input Class Initialized
INFO - 2016-09-26 16:28:19 --> Language Class Initialized
INFO - 2016-09-26 16:28:19 --> Language Class Initialized
INFO - 2016-09-26 16:28:19 --> Config Class Initialized
INFO - 2016-09-26 16:28:19 --> Loader Class Initialized
INFO - 2016-09-26 16:28:19 --> Helper loaded: url_helper
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 16:28:19 --> Controller Class Initialized
DEBUG - 2016-09-26 16:28:19 --> Index MX_Controller Initialized
INFO - 2016-09-26 16:28:19 --> Model Class Initialized
INFO - 2016-09-26 16:28:19 --> Model Class Initialized
ERROR - 2016-09-26 16:28:19 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-26 16:28:19 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-26 16:28:19 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-26 16:28:19 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-26 16:28:19 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-26 16:28:19 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-26 16:28:19 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
INFO - 2016-09-26 16:28:19 --> Database Driver Class Initialized
DEBUG - 2016-09-26 16:28:19 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-26 16:28:19 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-26 16:28:19 --> Final output sent to browser
DEBUG - 2016-09-26 16:28:19 --> Total execution time: 0.0946
INFO - 2016-09-26 16:28:20 --> Config Class Initialized
INFO - 2016-09-26 16:28:20 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:28:20 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:28:20 --> Utf8 Class Initialized
INFO - 2016-09-26 16:28:20 --> URI Class Initialized
INFO - 2016-09-26 16:28:20 --> Router Class Initialized
INFO - 2016-09-26 16:28:20 --> Output Class Initialized
INFO - 2016-09-26 16:28:20 --> Security Class Initialized
DEBUG - 2016-09-26 16:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:28:20 --> Input Class Initialized
INFO - 2016-09-26 16:28:20 --> Language Class Initialized
ERROR - 2016-09-26 16:28:20 --> 404 Page Not Found: /index
INFO - 2016-09-26 16:29:26 --> Config Class Initialized
INFO - 2016-09-26 16:29:26 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:29:26 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:29:26 --> Utf8 Class Initialized
INFO - 2016-09-26 16:29:26 --> URI Class Initialized
INFO - 2016-09-26 16:29:26 --> Router Class Initialized
INFO - 2016-09-26 16:29:26 --> Output Class Initialized
INFO - 2016-09-26 16:29:26 --> Security Class Initialized
DEBUG - 2016-09-26 16:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:29:26 --> Input Class Initialized
INFO - 2016-09-26 16:29:26 --> Language Class Initialized
INFO - 2016-09-26 16:29:26 --> Language Class Initialized
INFO - 2016-09-26 16:29:26 --> Config Class Initialized
INFO - 2016-09-26 16:29:26 --> Loader Class Initialized
INFO - 2016-09-26 16:29:26 --> Helper loaded: url_helper
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 16:29:26 --> Controller Class Initialized
DEBUG - 2016-09-26 16:29:26 --> Index MX_Controller Initialized
INFO - 2016-09-26 16:29:26 --> Model Class Initialized
INFO - 2016-09-26 16:29:26 --> Model Class Initialized
ERROR - 2016-09-26 16:29:26 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-26 16:29:26 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-26 16:29:26 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-26 16:29:26 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-26 16:29:26 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-26 16:29:26 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-26 16:29:26 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
INFO - 2016-09-26 16:29:26 --> Database Driver Class Initialized
DEBUG - 2016-09-26 16:29:26 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-26 16:29:26 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-26 16:29:26 --> Final output sent to browser
DEBUG - 2016-09-26 16:29:26 --> Total execution time: 0.1144
INFO - 2016-09-26 16:29:27 --> Config Class Initialized
INFO - 2016-09-26 16:29:27 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:29:27 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:29:27 --> Utf8 Class Initialized
INFO - 2016-09-26 16:29:27 --> URI Class Initialized
INFO - 2016-09-26 16:29:27 --> Router Class Initialized
INFO - 2016-09-26 16:29:27 --> Output Class Initialized
INFO - 2016-09-26 16:29:27 --> Security Class Initialized
DEBUG - 2016-09-26 16:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:29:27 --> Input Class Initialized
INFO - 2016-09-26 16:29:27 --> Language Class Initialized
ERROR - 2016-09-26 16:29:27 --> 404 Page Not Found: /index
INFO - 2016-09-26 16:35:48 --> Config Class Initialized
INFO - 2016-09-26 16:35:48 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:35:48 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:35:48 --> Utf8 Class Initialized
INFO - 2016-09-26 16:35:48 --> URI Class Initialized
INFO - 2016-09-26 16:35:48 --> Router Class Initialized
INFO - 2016-09-26 16:35:48 --> Output Class Initialized
INFO - 2016-09-26 16:35:48 --> Security Class Initialized
DEBUG - 2016-09-26 16:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:35:48 --> Input Class Initialized
INFO - 2016-09-26 16:35:48 --> Language Class Initialized
INFO - 2016-09-26 16:35:48 --> Language Class Initialized
INFO - 2016-09-26 16:35:48 --> Config Class Initialized
INFO - 2016-09-26 16:35:48 --> Loader Class Initialized
INFO - 2016-09-26 16:35:48 --> Helper loaded: url_helper
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 16:35:48 --> Controller Class Initialized
DEBUG - 2016-09-26 16:35:48 --> Index MX_Controller Initialized
INFO - 2016-09-26 16:35:48 --> Model Class Initialized
INFO - 2016-09-26 16:35:48 --> Model Class Initialized
ERROR - 2016-09-26 16:35:48 --> Unable to delete cache file for admin/index
DEBUG - 2016-09-26 16:35:48 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-26 16:35:48 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-26 16:35:48 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-26 16:35:48 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-26 16:35:48 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-26 16:35:48 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:48 --> Database Driver Class Initialized
DEBUG - 2016-09-26 16:35:48 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-26 16:35:48 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-26 16:35:48 --> Final output sent to browser
DEBUG - 2016-09-26 16:35:48 --> Total execution time: 0.1070
INFO - 2016-09-26 16:35:49 --> Config Class Initialized
INFO - 2016-09-26 16:35:49 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:35:49 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:35:49 --> Utf8 Class Initialized
INFO - 2016-09-26 16:35:49 --> URI Class Initialized
INFO - 2016-09-26 16:35:49 --> Router Class Initialized
INFO - 2016-09-26 16:35:49 --> Output Class Initialized
INFO - 2016-09-26 16:35:49 --> Security Class Initialized
DEBUG - 2016-09-26 16:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:35:49 --> Input Class Initialized
INFO - 2016-09-26 16:35:49 --> Language Class Initialized
INFO - 2016-09-26 16:35:49 --> Language Class Initialized
INFO - 2016-09-26 16:35:49 --> Config Class Initialized
INFO - 2016-09-26 16:35:49 --> Loader Class Initialized
INFO - 2016-09-26 16:35:49 --> Helper loaded: url_helper
INFO - 2016-09-26 16:35:49 --> Database Driver Class Initialized
INFO - 2016-09-26 16:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 16:35:49 --> Controller Class Initialized
DEBUG - 2016-09-26 16:35:49 --> login MX_Controller Initialized
INFO - 2016-09-26 16:35:49 --> Model Class Initialized
INFO - 2016-09-26 16:35:49 --> Model Class Initialized
DEBUG - 2016-09-26 16:35:49 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-26 16:35:49 --> Final output sent to browser
DEBUG - 2016-09-26 16:35:49 --> Total execution time: 0.0242
INFO - 2016-09-26 21:10:20 --> Config Class Initialized
INFO - 2016-09-26 21:10:20 --> Hooks Class Initialized
DEBUG - 2016-09-26 21:10:20 --> UTF-8 Support Enabled
INFO - 2016-09-26 21:10:20 --> Utf8 Class Initialized
INFO - 2016-09-26 21:10:20 --> URI Class Initialized
INFO - 2016-09-26 21:10:20 --> Router Class Initialized
INFO - 2016-09-26 21:10:20 --> Output Class Initialized
INFO - 2016-09-26 21:10:20 --> Security Class Initialized
DEBUG - 2016-09-26 21:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 21:10:20 --> Input Class Initialized
INFO - 2016-09-26 21:10:20 --> Language Class Initialized
ERROR - 2016-09-26 21:10:20 --> 404 Page Not Found: /index
INFO - 2016-09-26 21:10:21 --> Config Class Initialized
INFO - 2016-09-26 21:10:21 --> Hooks Class Initialized
DEBUG - 2016-09-26 21:10:21 --> UTF-8 Support Enabled
INFO - 2016-09-26 21:10:21 --> Utf8 Class Initialized
INFO - 2016-09-26 21:10:21 --> URI Class Initialized
DEBUG - 2016-09-26 21:10:21 --> No URI present. Default controller set.
INFO - 2016-09-26 21:10:21 --> Router Class Initialized
INFO - 2016-09-26 21:10:21 --> Output Class Initialized
INFO - 2016-09-26 21:10:21 --> Security Class Initialized
DEBUG - 2016-09-26 21:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 21:10:21 --> Input Class Initialized
INFO - 2016-09-26 21:10:21 --> Language Class Initialized
INFO - 2016-09-26 21:10:21 --> Language Class Initialized
INFO - 2016-09-26 21:10:21 --> Config Class Initialized
INFO - 2016-09-26 21:10:21 --> Loader Class Initialized
INFO - 2016-09-26 21:10:21 --> Helper loaded: url_helper
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 21:10:21 --> Controller Class Initialized
DEBUG - 2016-09-26 21:10:21 --> Index MX_Controller Initialized
INFO - 2016-09-26 21:10:21 --> Model Class Initialized
INFO - 2016-09-26 21:10:21 --> Model Class Initialized
ERROR - 2016-09-26 21:10:21 --> Unable to delete cache file for 
DEBUG - 2016-09-26 21:10:21 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-26 21:10:21 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-26 21:10:21 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-26 21:10:21 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-26 21:10:21 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-26 21:10:21 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:21 --> Database Driver Class Initialized
DEBUG - 2016-09-26 21:10:21 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-26 21:10:21 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-26 21:10:21 --> Final output sent to browser
DEBUG - 2016-09-26 21:10:21 --> Total execution time: 0.1581
INFO - 2016-09-26 21:10:31 --> Config Class Initialized
INFO - 2016-09-26 21:10:31 --> Hooks Class Initialized
DEBUG - 2016-09-26 21:10:31 --> UTF-8 Support Enabled
INFO - 2016-09-26 21:10:31 --> Utf8 Class Initialized
INFO - 2016-09-26 21:10:31 --> URI Class Initialized
INFO - 2016-09-26 21:10:31 --> Router Class Initialized
INFO - 2016-09-26 21:10:31 --> Output Class Initialized
INFO - 2016-09-26 21:10:31 --> Security Class Initialized
DEBUG - 2016-09-26 21:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 21:10:31 --> Input Class Initialized
INFO - 2016-09-26 21:10:31 --> Language Class Initialized
INFO - 2016-09-26 21:10:31 --> Language Class Initialized
INFO - 2016-09-26 21:10:31 --> Config Class Initialized
INFO - 2016-09-26 21:10:31 --> Loader Class Initialized
INFO - 2016-09-26 21:10:31 --> Helper loaded: url_helper
INFO - 2016-09-26 21:10:31 --> Database Driver Class Initialized
INFO - 2016-09-26 21:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 21:10:31 --> Controller Class Initialized
DEBUG - 2016-09-26 21:10:31 --> login MX_Controller Initialized
INFO - 2016-09-26 21:10:31 --> Model Class Initialized
INFO - 2016-09-26 21:10:31 --> Model Class Initialized
DEBUG - 2016-09-26 21:10:31 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-26 21:10:31 --> Final output sent to browser
DEBUG - 2016-09-26 21:10:31 --> Total execution time: 0.0251
INFO - 2016-09-26 23:14:48 --> Config Class Initialized
INFO - 2016-09-26 23:14:48 --> Hooks Class Initialized
DEBUG - 2016-09-26 23:14:48 --> UTF-8 Support Enabled
INFO - 2016-09-26 23:14:48 --> Utf8 Class Initialized
INFO - 2016-09-26 23:14:48 --> URI Class Initialized
DEBUG - 2016-09-26 23:14:48 --> No URI present. Default controller set.
INFO - 2016-09-26 23:14:48 --> Router Class Initialized
INFO - 2016-09-26 23:14:48 --> Output Class Initialized
INFO - 2016-09-26 23:14:48 --> Security Class Initialized
DEBUG - 2016-09-26 23:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 23:14:48 --> Input Class Initialized
INFO - 2016-09-26 23:14:48 --> Language Class Initialized
INFO - 2016-09-26 23:14:48 --> Language Class Initialized
INFO - 2016-09-26 23:14:48 --> Config Class Initialized
INFO - 2016-09-26 23:14:48 --> Loader Class Initialized
INFO - 2016-09-26 23:14:48 --> Helper loaded: url_helper
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 23:14:48 --> Controller Class Initialized
DEBUG - 2016-09-26 23:14:48 --> Index MX_Controller Initialized
INFO - 2016-09-26 23:14:48 --> Model Class Initialized
INFO - 2016-09-26 23:14:48 --> Model Class Initialized
ERROR - 2016-09-26 23:14:48 --> Unable to delete cache file for 
DEBUG - 2016-09-26 23:14:48 --> File loaded: /home/koperasi/public_html/application/views/main_html/head.php
DEBUG - 2016-09-26 23:14:48 --> File loaded: /home/koperasi/public_html/application/views/main_html/left_menu.php
DEBUG - 2016-09-26 23:14:48 --> File loaded: /home/koperasi/public_html/application/views/main_html/top_menu.php
DEBUG - 2016-09-26 23:14:48 --> File loaded: /home/koperasi/public_html/application/views/main_html/content/dashboard.php
DEBUG - 2016-09-26 23:14:48 --> File loaded: /home/koperasi/public_html/application/views/main_html/page_content.php
DEBUG - 2016-09-26 23:14:48 --> File loaded: /home/koperasi/public_html/application/views/main_html/foot.php
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:48 --> Database Driver Class Initialized
DEBUG - 2016-09-26 23:14:48 --> File loaded: /home/koperasi/public_html/application/views/main_html/script.php
DEBUG - 2016-09-26 23:14:48 --> File loaded: /home/koperasi/public_html/application/views/main_html/content.php
INFO - 2016-09-26 23:14:48 --> Final output sent to browser
DEBUG - 2016-09-26 23:14:48 --> Total execution time: 0.1326
INFO - 2016-09-26 23:14:49 --> Config Class Initialized
INFO - 2016-09-26 23:14:49 --> Hooks Class Initialized
DEBUG - 2016-09-26 23:14:49 --> UTF-8 Support Enabled
INFO - 2016-09-26 23:14:49 --> Utf8 Class Initialized
INFO - 2016-09-26 23:14:49 --> URI Class Initialized
INFO - 2016-09-26 23:14:49 --> Router Class Initialized
INFO - 2016-09-26 23:14:49 --> Output Class Initialized
INFO - 2016-09-26 23:14:49 --> Security Class Initialized
DEBUG - 2016-09-26 23:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 23:14:49 --> Input Class Initialized
INFO - 2016-09-26 23:14:49 --> Language Class Initialized
INFO - 2016-09-26 23:14:49 --> Language Class Initialized
INFO - 2016-09-26 23:14:49 --> Config Class Initialized
INFO - 2016-09-26 23:14:49 --> Loader Class Initialized
INFO - 2016-09-26 23:14:49 --> Helper loaded: url_helper
INFO - 2016-09-26 23:14:49 --> Database Driver Class Initialized
INFO - 2016-09-26 23:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 23:14:49 --> Controller Class Initialized
DEBUG - 2016-09-26 23:14:49 --> login MX_Controller Initialized
INFO - 2016-09-26 23:14:49 --> Model Class Initialized
INFO - 2016-09-26 23:14:49 --> Model Class Initialized
DEBUG - 2016-09-26 23:14:49 --> File loaded: /home/koperasi/public_html/application/views/main_html/login.php
INFO - 2016-09-26 23:14:49 --> Final output sent to browser
DEBUG - 2016-09-26 23:14:49 --> Total execution time: 0.0521
