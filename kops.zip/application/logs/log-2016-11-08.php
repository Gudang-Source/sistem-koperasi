<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-11-08 18:07:20 --> Config Class Initialized
INFO - 2016-11-08 18:07:20 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:07:20 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:07:20 --> Utf8 Class Initialized
INFO - 2016-11-08 18:07:20 --> URI Class Initialized
INFO - 2016-11-08 18:07:20 --> Router Class Initialized
INFO - 2016-11-08 18:07:20 --> Output Class Initialized
INFO - 2016-11-08 18:07:20 --> Security Class Initialized
DEBUG - 2016-11-08 18:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:07:20 --> Input Class Initialized
INFO - 2016-11-08 18:07:20 --> Language Class Initialized
INFO - 2016-11-08 18:07:20 --> Language Class Initialized
INFO - 2016-11-08 18:07:20 --> Config Class Initialized
INFO - 2016-11-08 18:07:20 --> Loader Class Initialized
INFO - 2016-11-08 18:07:20 --> Helper loaded: url_helper
INFO - 2016-11-08 18:07:20 --> Database Driver Class Initialized
INFO - 2016-11-08 18:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:07:20 --> Controller Class Initialized
DEBUG - 2016-11-08 18:07:20 --> Index MX_Controller Initialized
INFO - 2016-11-08 18:07:20 --> Model Class Initialized
INFO - 2016-11-08 18:07:20 --> Model Class Initialized
ERROR - 2016-11-08 18:07:20 --> Unable to delete cache file for admin/index/getDetailAngsuran
INFO - 2016-11-08 18:07:20 --> Database Driver Class Initialized
INFO - 2016-11-08 18:07:20 --> Final output sent to browser
DEBUG - 2016-11-08 18:07:20 --> Total execution time: 0.4942
INFO - 2016-11-08 18:07:20 --> Config Class Initialized
INFO - 2016-11-08 18:07:20 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:07:20 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:07:20 --> Utf8 Class Initialized
INFO - 2016-11-08 18:07:20 --> URI Class Initialized
INFO - 2016-11-08 18:07:20 --> Router Class Initialized
INFO - 2016-11-08 18:07:21 --> Output Class Initialized
INFO - 2016-11-08 18:07:21 --> Security Class Initialized
DEBUG - 2016-11-08 18:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:07:21 --> Input Class Initialized
INFO - 2016-11-08 18:07:21 --> Language Class Initialized
INFO - 2016-11-08 18:07:21 --> Language Class Initialized
INFO - 2016-11-08 18:07:21 --> Config Class Initialized
INFO - 2016-11-08 18:07:21 --> Loader Class Initialized
INFO - 2016-11-08 18:07:21 --> Helper loaded: url_helper
INFO - 2016-11-08 18:07:21 --> Database Driver Class Initialized
INFO - 2016-11-08 18:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:07:21 --> Controller Class Initialized
DEBUG - 2016-11-08 18:07:21 --> login MX_Controller Initialized
INFO - 2016-11-08 18:07:21 --> Model Class Initialized
INFO - 2016-11-08 18:07:21 --> Model Class Initialized
DEBUG - 2016-11-08 18:07:21 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/login.php
INFO - 2016-11-08 18:07:21 --> Final output sent to browser
DEBUG - 2016-11-08 18:07:21 --> Total execution time: 0.4201
INFO - 2016-11-08 18:08:18 --> Config Class Initialized
INFO - 2016-11-08 18:08:18 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:08:18 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:08:18 --> Utf8 Class Initialized
INFO - 2016-11-08 18:08:18 --> URI Class Initialized
INFO - 2016-11-08 18:08:18 --> Router Class Initialized
INFO - 2016-11-08 18:08:18 --> Output Class Initialized
INFO - 2016-11-08 18:08:18 --> Security Class Initialized
DEBUG - 2016-11-08 18:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:08:18 --> Input Class Initialized
INFO - 2016-11-08 18:08:18 --> Language Class Initialized
INFO - 2016-11-08 18:08:19 --> Language Class Initialized
INFO - 2016-11-08 18:08:19 --> Config Class Initialized
INFO - 2016-11-08 18:08:19 --> Loader Class Initialized
INFO - 2016-11-08 18:08:19 --> Helper loaded: url_helper
INFO - 2016-11-08 18:08:19 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:08:19 --> Controller Class Initialized
DEBUG - 2016-11-08 18:08:19 --> Index MX_Controller Initialized
INFO - 2016-11-08 18:08:19 --> Model Class Initialized
INFO - 2016-11-08 18:08:19 --> Model Class Initialized
ERROR - 2016-11-08 18:08:19 --> Unable to delete cache file for admin/index/test_date
INFO - 2016-11-08 18:08:19 --> Final output sent to browser
DEBUG - 2016-11-08 18:08:19 --> Total execution time: 0.7145
INFO - 2016-11-08 18:08:19 --> Config Class Initialized
INFO - 2016-11-08 18:08:19 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:08:19 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:08:19 --> Utf8 Class Initialized
INFO - 2016-11-08 18:08:19 --> URI Class Initialized
INFO - 2016-11-08 18:08:19 --> Router Class Initialized
INFO - 2016-11-08 18:08:19 --> Output Class Initialized
INFO - 2016-11-08 18:08:19 --> Security Class Initialized
DEBUG - 2016-11-08 18:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:08:19 --> Input Class Initialized
INFO - 2016-11-08 18:08:19 --> Language Class Initialized
INFO - 2016-11-08 18:08:19 --> Language Class Initialized
INFO - 2016-11-08 18:08:19 --> Config Class Initialized
INFO - 2016-11-08 18:08:19 --> Loader Class Initialized
INFO - 2016-11-08 18:08:19 --> Helper loaded: url_helper
INFO - 2016-11-08 18:08:19 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:08:20 --> Controller Class Initialized
DEBUG - 2016-11-08 18:08:20 --> login MX_Controller Initialized
INFO - 2016-11-08 18:08:20 --> Model Class Initialized
INFO - 2016-11-08 18:08:20 --> Model Class Initialized
DEBUG - 2016-11-08 18:08:20 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/login.php
INFO - 2016-11-08 18:08:20 --> Final output sent to browser
DEBUG - 2016-11-08 18:08:20 --> Total execution time: 0.7203
INFO - 2016-11-08 18:08:27 --> Config Class Initialized
INFO - 2016-11-08 18:08:27 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:08:27 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:08:27 --> Utf8 Class Initialized
INFO - 2016-11-08 18:08:27 --> URI Class Initialized
INFO - 2016-11-08 18:08:27 --> Router Class Initialized
INFO - 2016-11-08 18:08:27 --> Output Class Initialized
INFO - 2016-11-08 18:08:27 --> Security Class Initialized
DEBUG - 2016-11-08 18:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:08:27 --> Input Class Initialized
INFO - 2016-11-08 18:08:27 --> Language Class Initialized
INFO - 2016-11-08 18:08:27 --> Language Class Initialized
INFO - 2016-11-08 18:08:27 --> Config Class Initialized
INFO - 2016-11-08 18:08:27 --> Loader Class Initialized
INFO - 2016-11-08 18:08:27 --> Helper loaded: url_helper
INFO - 2016-11-08 18:08:27 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:08:27 --> Controller Class Initialized
DEBUG - 2016-11-08 18:08:27 --> login MX_Controller Initialized
INFO - 2016-11-08 18:08:27 --> Model Class Initialized
INFO - 2016-11-08 18:08:27 --> Model Class Initialized
INFO - 2016-11-08 18:08:27 --> Final output sent to browser
DEBUG - 2016-11-08 18:08:27 --> Total execution time: 0.5350
INFO - 2016-11-08 18:08:27 --> Config Class Initialized
INFO - 2016-11-08 18:08:28 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:08:28 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:08:28 --> Utf8 Class Initialized
INFO - 2016-11-08 18:08:28 --> URI Class Initialized
INFO - 2016-11-08 18:08:28 --> Router Class Initialized
INFO - 2016-11-08 18:08:28 --> Output Class Initialized
INFO - 2016-11-08 18:08:28 --> Security Class Initialized
DEBUG - 2016-11-08 18:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:08:28 --> Input Class Initialized
INFO - 2016-11-08 18:08:28 --> Language Class Initialized
INFO - 2016-11-08 18:08:28 --> Language Class Initialized
INFO - 2016-11-08 18:08:28 --> Config Class Initialized
INFO - 2016-11-08 18:08:28 --> Loader Class Initialized
INFO - 2016-11-08 18:08:28 --> Helper loaded: url_helper
INFO - 2016-11-08 18:08:28 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:08:28 --> Controller Class Initialized
DEBUG - 2016-11-08 18:08:28 --> Index MX_Controller Initialized
INFO - 2016-11-08 18:08:28 --> Model Class Initialized
INFO - 2016-11-08 18:08:28 --> Model Class Initialized
ERROR - 2016-11-08 18:08:28 --> Unable to delete cache file for admin/index
DEBUG - 2016-11-08 18:08:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/head.php
DEBUG - 2016-11-08 18:08:28 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/left_menu.php
DEBUG - 2016-11-08 18:08:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/top_menu.php
DEBUG - 2016-11-08 18:08:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content/dashboard.php
DEBUG - 2016-11-08 18:08:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/page_content.php
DEBUG - 2016-11-08 18:08:29 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/foot.php
INFO - 2016-11-08 18:08:29 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:29 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:29 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:29 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:29 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:29 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:29 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:29 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:29 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:29 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:29 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:29 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:30 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:30 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:30 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:30 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:30 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:30 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:30 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:30 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:30 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:30 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:30 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:30 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:30 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:30 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:30 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:30 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:30 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:31 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:31 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:31 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:31 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:31 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:31 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:31 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:31 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:31 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:31 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:31 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:31 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:31 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:31 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:31 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:31 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:31 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:31 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:31 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:31 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:31 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:31 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:31 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:31 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:31 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:31 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:31 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:31 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:31 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:32 --> Database Driver Class Initialized
DEBUG - 2016-11-08 18:08:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/script.php
DEBUG - 2016-11-08 18:08:32 --> File loaded: E:\SERVER\htdocs\kops\application\views\main_html/content.php
INFO - 2016-11-08 18:08:32 --> Final output sent to browser
DEBUG - 2016-11-08 18:08:32 --> Total execution time: 4.0865
INFO - 2016-11-08 18:08:40 --> Config Class Initialized
INFO - 2016-11-08 18:08:40 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:08:40 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:08:40 --> Utf8 Class Initialized
INFO - 2016-11-08 18:08:40 --> URI Class Initialized
INFO - 2016-11-08 18:08:40 --> Router Class Initialized
INFO - 2016-11-08 18:08:40 --> Output Class Initialized
INFO - 2016-11-08 18:08:40 --> Security Class Initialized
DEBUG - 2016-11-08 18:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:08:40 --> Input Class Initialized
INFO - 2016-11-08 18:08:40 --> Language Class Initialized
ERROR - 2016-11-08 18:08:41 --> 404 Page Not Found: ../modules/admin/controllers//index
INFO - 2016-11-08 18:08:46 --> Config Class Initialized
INFO - 2016-11-08 18:08:46 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:08:46 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:08:47 --> Utf8 Class Initialized
INFO - 2016-11-08 18:08:47 --> URI Class Initialized
INFO - 2016-11-08 18:08:47 --> Router Class Initialized
INFO - 2016-11-08 18:08:47 --> Output Class Initialized
INFO - 2016-11-08 18:08:47 --> Security Class Initialized
DEBUG - 2016-11-08 18:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:08:47 --> Input Class Initialized
INFO - 2016-11-08 18:08:47 --> Language Class Initialized
INFO - 2016-11-08 18:08:47 --> Language Class Initialized
INFO - 2016-11-08 18:08:47 --> Config Class Initialized
INFO - 2016-11-08 18:08:47 --> Loader Class Initialized
INFO - 2016-11-08 18:08:47 --> Helper loaded: url_helper
INFO - 2016-11-08 18:08:47 --> Database Driver Class Initialized
INFO - 2016-11-08 18:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:08:47 --> Controller Class Initialized
DEBUG - 2016-11-08 18:08:47 --> Index MX_Controller Initialized
INFO - 2016-11-08 18:08:47 --> Model Class Initialized
INFO - 2016-11-08 18:08:47 --> Model Class Initialized
ERROR - 2016-11-08 18:08:47 --> Unable to delete cache file for admin/index/test_date
INFO - 2016-11-08 18:08:47 --> Final output sent to browser
DEBUG - 2016-11-08 18:08:47 --> Total execution time: 0.6287
INFO - 2016-11-08 18:09:26 --> Config Class Initialized
INFO - 2016-11-08 18:09:26 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:09:26 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:09:26 --> Utf8 Class Initialized
INFO - 2016-11-08 18:09:26 --> URI Class Initialized
INFO - 2016-11-08 18:09:26 --> Router Class Initialized
INFO - 2016-11-08 18:09:26 --> Output Class Initialized
INFO - 2016-11-08 18:09:26 --> Security Class Initialized
DEBUG - 2016-11-08 18:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:09:26 --> Input Class Initialized
INFO - 2016-11-08 18:09:26 --> Language Class Initialized
INFO - 2016-11-08 18:09:26 --> Language Class Initialized
INFO - 2016-11-08 18:09:26 --> Config Class Initialized
INFO - 2016-11-08 18:09:26 --> Loader Class Initialized
INFO - 2016-11-08 18:09:27 --> Helper loaded: url_helper
INFO - 2016-11-08 18:09:27 --> Database Driver Class Initialized
INFO - 2016-11-08 18:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:09:27 --> Controller Class Initialized
DEBUG - 2016-11-08 18:09:27 --> Index MX_Controller Initialized
INFO - 2016-11-08 18:09:27 --> Model Class Initialized
INFO - 2016-11-08 18:09:27 --> Model Class Initialized
ERROR - 2016-11-08 18:09:27 --> Unable to delete cache file for admin/index/test_date
INFO - 2016-11-08 18:09:27 --> Final output sent to browser
DEBUG - 2016-11-08 18:09:27 --> Total execution time: 0.6660
INFO - 2016-11-08 18:09:42 --> Config Class Initialized
INFO - 2016-11-08 18:09:42 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:09:43 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:09:43 --> Utf8 Class Initialized
INFO - 2016-11-08 18:09:43 --> URI Class Initialized
INFO - 2016-11-08 18:09:43 --> Router Class Initialized
INFO - 2016-11-08 18:09:43 --> Output Class Initialized
INFO - 2016-11-08 18:09:43 --> Security Class Initialized
DEBUG - 2016-11-08 18:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:09:43 --> Input Class Initialized
INFO - 2016-11-08 18:09:43 --> Language Class Initialized
INFO - 2016-11-08 18:09:43 --> Language Class Initialized
INFO - 2016-11-08 18:09:43 --> Config Class Initialized
INFO - 2016-11-08 18:09:43 --> Loader Class Initialized
INFO - 2016-11-08 18:09:43 --> Helper loaded: url_helper
INFO - 2016-11-08 18:09:43 --> Database Driver Class Initialized
INFO - 2016-11-08 18:09:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:09:43 --> Controller Class Initialized
DEBUG - 2016-11-08 18:09:43 --> Index MX_Controller Initialized
INFO - 2016-11-08 18:09:43 --> Model Class Initialized
INFO - 2016-11-08 18:09:43 --> Model Class Initialized
ERROR - 2016-11-08 18:09:43 --> Unable to delete cache file for admin/index/test_date
INFO - 2016-11-08 18:09:43 --> Final output sent to browser
DEBUG - 2016-11-08 18:09:43 --> Total execution time: 0.6160
INFO - 2016-11-08 18:09:51 --> Config Class Initialized
INFO - 2016-11-08 18:09:51 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:09:51 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:09:51 --> Utf8 Class Initialized
INFO - 2016-11-08 18:09:51 --> URI Class Initialized
INFO - 2016-11-08 18:09:52 --> Router Class Initialized
INFO - 2016-11-08 18:09:52 --> Output Class Initialized
INFO - 2016-11-08 18:09:52 --> Security Class Initialized
DEBUG - 2016-11-08 18:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:09:52 --> Input Class Initialized
INFO - 2016-11-08 18:09:52 --> Language Class Initialized
INFO - 2016-11-08 18:09:52 --> Language Class Initialized
INFO - 2016-11-08 18:09:52 --> Config Class Initialized
INFO - 2016-11-08 18:09:52 --> Loader Class Initialized
INFO - 2016-11-08 18:09:52 --> Helper loaded: url_helper
INFO - 2016-11-08 18:09:52 --> Database Driver Class Initialized
INFO - 2016-11-08 18:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:09:52 --> Controller Class Initialized
DEBUG - 2016-11-08 18:09:52 --> Index MX_Controller Initialized
INFO - 2016-11-08 18:09:52 --> Model Class Initialized
INFO - 2016-11-08 18:09:52 --> Model Class Initialized
ERROR - 2016-11-08 18:09:52 --> Unable to delete cache file for admin/index/test_date
INFO - 2016-11-08 18:09:52 --> Final output sent to browser
DEBUG - 2016-11-08 18:09:52 --> Total execution time: 0.7945
