<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-09-07 07:01:22 --> Config Class Initialized
INFO - 2016-09-07 07:01:22 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:01:22 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:01:22 --> Utf8 Class Initialized
INFO - 2016-09-07 07:01:22 --> URI Class Initialized
INFO - 2016-09-07 07:01:23 --> Router Class Initialized
INFO - 2016-09-07 07:01:23 --> Output Class Initialized
INFO - 2016-09-07 07:01:23 --> Security Class Initialized
DEBUG - 2016-09-07 07:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:01:23 --> Input Class Initialized
INFO - 2016-09-07 07:01:23 --> Language Class Initialized
ERROR - 2016-09-07 07:01:23 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:01:28 --> Config Class Initialized
INFO - 2016-09-07 07:01:28 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:01:28 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:01:28 --> Utf8 Class Initialized
INFO - 2016-09-07 07:01:28 --> URI Class Initialized
INFO - 2016-09-07 07:01:28 --> Router Class Initialized
INFO - 2016-09-07 07:01:29 --> Output Class Initialized
INFO - 2016-09-07 07:01:29 --> Security Class Initialized
DEBUG - 2016-09-07 07:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:01:29 --> Input Class Initialized
INFO - 2016-09-07 07:01:29 --> Language Class Initialized
INFO - 2016-09-07 07:01:29 --> Language Class Initialized
INFO - 2016-09-07 07:01:29 --> Config Class Initialized
INFO - 2016-09-07 07:01:29 --> Loader Class Initialized
INFO - 2016-09-07 07:01:29 --> Database Driver Class Initialized
INFO - 2016-09-07 07:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-07 07:01:29 --> Model Class Initialized
INFO - 2016-09-07 07:02:21 --> Config Class Initialized
INFO - 2016-09-07 07:02:21 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:02:21 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:02:21 --> Utf8 Class Initialized
INFO - 2016-09-07 07:02:21 --> URI Class Initialized
INFO - 2016-09-07 07:02:21 --> Router Class Initialized
INFO - 2016-09-07 07:02:21 --> Output Class Initialized
INFO - 2016-09-07 07:02:21 --> Security Class Initialized
DEBUG - 2016-09-07 07:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:02:21 --> Input Class Initialized
INFO - 2016-09-07 07:02:21 --> Language Class Initialized
INFO - 2016-09-07 07:02:21 --> Language Class Initialized
INFO - 2016-09-07 07:02:21 --> Config Class Initialized
INFO - 2016-09-07 07:02:21 --> Loader Class Initialized
INFO - 2016-09-07 07:02:21 --> Database Driver Class Initialized
INFO - 2016-09-07 07:02:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-07 07:02:21 --> Model Class Initialized
INFO - 2016-09-07 07:02:57 --> Config Class Initialized
INFO - 2016-09-07 07:02:57 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:02:57 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:02:57 --> Utf8 Class Initialized
INFO - 2016-09-07 07:02:57 --> URI Class Initialized
INFO - 2016-09-07 07:02:57 --> Router Class Initialized
INFO - 2016-09-07 07:02:57 --> Output Class Initialized
INFO - 2016-09-07 07:02:57 --> Security Class Initialized
DEBUG - 2016-09-07 07:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:02:57 --> Input Class Initialized
INFO - 2016-09-07 07:02:57 --> Language Class Initialized
INFO - 2016-09-07 07:02:57 --> Language Class Initialized
INFO - 2016-09-07 07:02:57 --> Config Class Initialized
INFO - 2016-09-07 07:02:57 --> Loader Class Initialized
INFO - 2016-09-07 07:02:57 --> Database Driver Class Initialized
INFO - 2016-09-07 07:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-07 07:02:57 --> Model Class Initialized
INFO - 2016-09-07 07:03:15 --> Config Class Initialized
INFO - 2016-09-07 07:03:15 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:03:15 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:03:15 --> Utf8 Class Initialized
INFO - 2016-09-07 07:03:15 --> URI Class Initialized
INFO - 2016-09-07 07:03:15 --> Router Class Initialized
INFO - 2016-09-07 07:03:15 --> Output Class Initialized
INFO - 2016-09-07 07:03:15 --> Security Class Initialized
DEBUG - 2016-09-07 07:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:03:15 --> Input Class Initialized
INFO - 2016-09-07 07:03:15 --> Language Class Initialized
INFO - 2016-09-07 07:03:15 --> Language Class Initialized
INFO - 2016-09-07 07:03:15 --> Config Class Initialized
INFO - 2016-09-07 07:03:15 --> Loader Class Initialized
INFO - 2016-09-07 07:03:15 --> Database Driver Class Initialized
INFO - 2016-09-07 07:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-07 07:03:15 --> Model Class Initialized
INFO - 2016-09-07 07:03:25 --> Config Class Initialized
INFO - 2016-09-07 07:03:25 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:03:25 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:03:25 --> Utf8 Class Initialized
INFO - 2016-09-07 07:03:25 --> URI Class Initialized
INFO - 2016-09-07 07:03:25 --> Router Class Initialized
INFO - 2016-09-07 07:03:25 --> Output Class Initialized
INFO - 2016-09-07 07:03:25 --> Security Class Initialized
DEBUG - 2016-09-07 07:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:03:25 --> Input Class Initialized
INFO - 2016-09-07 07:03:25 --> Language Class Initialized
INFO - 2016-09-07 07:03:25 --> Language Class Initialized
INFO - 2016-09-07 07:03:25 --> Config Class Initialized
INFO - 2016-09-07 07:03:25 --> Loader Class Initialized
INFO - 2016-09-07 07:03:25 --> Database Driver Class Initialized
INFO - 2016-09-07 07:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-07 07:03:25 --> Model Class Initialized
INFO - 2016-09-07 07:03:25 --> Model Class Initialized
INFO - 2016-09-07 07:03:25 --> Controller Class Initialized
ERROR - 2016-09-07 07:03:25 --> Severity: Error --> Call to undefined function base_url() E:\SERVER\htdocs\koperasiweda\application\views\main_html\head.php 11
INFO - 2016-09-07 07:04:36 --> Config Class Initialized
INFO - 2016-09-07 07:04:36 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:04:36 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:04:36 --> Utf8 Class Initialized
INFO - 2016-09-07 07:04:36 --> URI Class Initialized
INFO - 2016-09-07 07:04:36 --> Router Class Initialized
INFO - 2016-09-07 07:04:36 --> Output Class Initialized
INFO - 2016-09-07 07:04:36 --> Security Class Initialized
DEBUG - 2016-09-07 07:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:04:36 --> Input Class Initialized
INFO - 2016-09-07 07:04:36 --> Language Class Initialized
INFO - 2016-09-07 07:04:36 --> Language Class Initialized
INFO - 2016-09-07 07:04:36 --> Config Class Initialized
INFO - 2016-09-07 07:04:36 --> Loader Class Initialized
INFO - 2016-09-07 07:04:36 --> Database Driver Class Initialized
INFO - 2016-09-07 07:04:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-07 07:04:36 --> Model Class Initialized
INFO - 2016-09-07 07:04:36 --> Model Class Initialized
INFO - 2016-09-07 07:04:36 --> Controller Class Initialized
ERROR - 2016-09-07 07:04:36 --> Severity: Error --> Call to undefined function base_url() E:\SERVER\htdocs\koperasiweda\application\views\main_html\head.php 11
INFO - 2016-09-07 07:05:16 --> Config Class Initialized
INFO - 2016-09-07 07:05:16 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:05:16 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:16 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:16 --> URI Class Initialized
INFO - 2016-09-07 07:05:16 --> Router Class Initialized
INFO - 2016-09-07 07:05:16 --> Output Class Initialized
INFO - 2016-09-07 07:05:16 --> Security Class Initialized
DEBUG - 2016-09-07 07:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:16 --> Input Class Initialized
INFO - 2016-09-07 07:05:16 --> Language Class Initialized
INFO - 2016-09-07 07:05:16 --> Language Class Initialized
INFO - 2016-09-07 07:05:16 --> Config Class Initialized
INFO - 2016-09-07 07:05:16 --> Loader Class Initialized
INFO - 2016-09-07 07:05:16 --> Helper loaded: url_helper
INFO - 2016-09-07 07:05:16 --> Database Driver Class Initialized
INFO - 2016-09-07 07:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-07 07:05:16 --> Model Class Initialized
INFO - 2016-09-07 07:05:16 --> Model Class Initialized
INFO - 2016-09-07 07:05:16 --> Controller Class Initialized
DEBUG - 2016-09-07 07:05:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 07:05:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 07:05:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 07:05:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/dashboard.php
DEBUG - 2016-09-07 07:05:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 07:05:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 07:05:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 07:05:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 07:05:16 --> Final output sent to browser
DEBUG - 2016-09-07 07:05:17 --> Total execution time: 0.5516
INFO - 2016-09-07 07:05:17 --> Config Class Initialized
INFO - 2016-09-07 07:05:17 --> Config Class Initialized
INFO - 2016-09-07 07:05:17 --> Config Class Initialized
INFO - 2016-09-07 07:05:17 --> Config Class Initialized
INFO - 2016-09-07 07:05:17 --> Hooks Class Initialized
INFO - 2016-09-07 07:05:17 --> Config Class Initialized
INFO - 2016-09-07 07:05:17 --> Hooks Class Initialized
INFO - 2016-09-07 07:05:17 --> Hooks Class Initialized
INFO - 2016-09-07 07:05:17 --> Hooks Class Initialized
INFO - 2016-09-07 07:05:17 --> Hooks Class Initialized
INFO - 2016-09-07 07:05:17 --> Config Class Initialized
DEBUG - 2016-09-07 07:05:17 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:17 --> Utf8 Class Initialized
DEBUG - 2016-09-07 07:05:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 07:05:17 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:17 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:05:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 07:05:17 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:17 --> URI Class Initialized
INFO - 2016-09-07 07:05:17 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:17 --> Router Class Initialized
INFO - 2016-09-07 07:05:17 --> URI Class Initialized
INFO - 2016-09-07 07:05:17 --> Output Class Initialized
INFO - 2016-09-07 07:05:17 --> Router Class Initialized
INFO - 2016-09-07 07:05:17 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:17 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:17 --> Utf8 Class Initialized
DEBUG - 2016-09-07 07:05:17 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:17 --> Security Class Initialized
INFO - 2016-09-07 07:05:17 --> Output Class Initialized
INFO - 2016-09-07 07:05:17 --> Security Class Initialized
DEBUG - 2016-09-07 07:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:17 --> URI Class Initialized
INFO - 2016-09-07 07:05:17 --> URI Class Initialized
INFO - 2016-09-07 07:05:17 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:17 --> URI Class Initialized
DEBUG - 2016-09-07 07:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:17 --> URI Class Initialized
INFO - 2016-09-07 07:05:17 --> Router Class Initialized
INFO - 2016-09-07 07:05:17 --> Router Class Initialized
INFO - 2016-09-07 07:05:17 --> Router Class Initialized
INFO - 2016-09-07 07:05:17 --> Input Class Initialized
INFO - 2016-09-07 07:05:17 --> Language Class Initialized
INFO - 2016-09-07 07:05:17 --> Input Class Initialized
ERROR - 2016-09-07 07:05:17 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:17 --> Language Class Initialized
ERROR - 2016-09-07 07:05:17 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:17 --> Router Class Initialized
INFO - 2016-09-07 07:05:17 --> Output Class Initialized
INFO - 2016-09-07 07:05:17 --> Security Class Initialized
DEBUG - 2016-09-07 07:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:17 --> Input Class Initialized
INFO - 2016-09-07 07:05:18 --> Language Class Initialized
ERROR - 2016-09-07 07:05:18 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:18 --> Output Class Initialized
INFO - 2016-09-07 07:05:18 --> Output Class Initialized
INFO - 2016-09-07 07:05:18 --> Output Class Initialized
INFO - 2016-09-07 07:05:18 --> Security Class Initialized
INFO - 2016-09-07 07:05:18 --> Config Class Initialized
INFO - 2016-09-07 07:05:18 --> Config Class Initialized
INFO - 2016-09-07 07:05:18 --> Config Class Initialized
INFO - 2016-09-07 07:05:18 --> Security Class Initialized
INFO - 2016-09-07 07:05:18 --> Security Class Initialized
INFO - 2016-09-07 07:05:18 --> Hooks Class Initialized
INFO - 2016-09-07 07:05:18 --> Hooks Class Initialized
INFO - 2016-09-07 07:05:18 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:05:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-07 07:05:18 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 07:05:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-07 07:05:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-07 07:05:18 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:18 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:18 --> URI Class Initialized
INFO - 2016-09-07 07:05:18 --> Router Class Initialized
INFO - 2016-09-07 07:05:18 --> Output Class Initialized
INFO - 2016-09-07 07:05:18 --> Security Class Initialized
INFO - 2016-09-07 07:05:18 --> Input Class Initialized
DEBUG - 2016-09-07 07:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:18 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:18 --> Input Class Initialized
DEBUG - 2016-09-07 07:05:18 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:18 --> Input Class Initialized
INFO - 2016-09-07 07:05:18 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:18 --> URI Class Initialized
INFO - 2016-09-07 07:05:18 --> Language Class Initialized
INFO - 2016-09-07 07:05:18 --> Language Class Initialized
INFO - 2016-09-07 07:05:18 --> Language Class Initialized
INFO - 2016-09-07 07:05:18 --> Input Class Initialized
INFO - 2016-09-07 07:05:18 --> URI Class Initialized
INFO - 2016-09-07 07:05:18 --> Router Class Initialized
INFO - 2016-09-07 07:05:18 --> Output Class Initialized
INFO - 2016-09-07 07:05:18 --> Security Class Initialized
DEBUG - 2016-09-07 07:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:18 --> Input Class Initialized
INFO - 2016-09-07 07:05:18 --> Language Class Initialized
ERROR - 2016-09-07 07:05:18 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:18 --> Language Class Initialized
ERROR - 2016-09-07 07:05:18 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:18 --> Router Class Initialized
ERROR - 2016-09-07 07:05:18 --> 404 Page Not Found: /index
ERROR - 2016-09-07 07:05:18 --> 404 Page Not Found: /index
ERROR - 2016-09-07 07:05:18 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:18 --> Config Class Initialized
INFO - 2016-09-07 07:05:18 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:05:18 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:18 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:18 --> URI Class Initialized
INFO - 2016-09-07 07:05:18 --> Config Class Initialized
INFO - 2016-09-07 07:05:18 --> Router Class Initialized
INFO - 2016-09-07 07:05:19 --> Hooks Class Initialized
INFO - 2016-09-07 07:05:19 --> Output Class Initialized
INFO - 2016-09-07 07:05:19 --> Output Class Initialized
INFO - 2016-09-07 07:05:19 --> Config Class Initialized
INFO - 2016-09-07 07:05:19 --> Config Class Initialized
INFO - 2016-09-07 07:05:19 --> Config Class Initialized
INFO - 2016-09-07 07:05:19 --> Hooks Class Initialized
INFO - 2016-09-07 07:05:19 --> Hooks Class Initialized
INFO - 2016-09-07 07:05:19 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:05:19 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:19 --> Security Class Initialized
INFO - 2016-09-07 07:05:19 --> Security Class Initialized
INFO - 2016-09-07 07:05:19 --> Utf8 Class Initialized
DEBUG - 2016-09-07 07:05:19 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 07:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-07 07:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:19 --> URI Class Initialized
DEBUG - 2016-09-07 07:05:19 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:19 --> Input Class Initialized
INFO - 2016-09-07 07:05:19 --> Input Class Initialized
DEBUG - 2016-09-07 07:05:19 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:19 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:19 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:19 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:19 --> Language Class Initialized
INFO - 2016-09-07 07:05:19 --> URI Class Initialized
INFO - 2016-09-07 07:05:19 --> URI Class Initialized
INFO - 2016-09-07 07:05:19 --> Language Class Initialized
INFO - 2016-09-07 07:05:19 --> Router Class Initialized
INFO - 2016-09-07 07:05:19 --> URI Class Initialized
INFO - 2016-09-07 07:05:19 --> Output Class Initialized
ERROR - 2016-09-07 07:05:19 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:19 --> Router Class Initialized
INFO - 2016-09-07 07:05:19 --> Security Class Initialized
INFO - 2016-09-07 07:05:19 --> Output Class Initialized
ERROR - 2016-09-07 07:05:19 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:19 --> Router Class Initialized
INFO - 2016-09-07 07:05:19 --> Config Class Initialized
INFO - 2016-09-07 07:05:19 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:19 --> Input Class Initialized
DEBUG - 2016-09-07 07:05:19 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:19 --> Security Class Initialized
INFO - 2016-09-07 07:05:19 --> Router Class Initialized
INFO - 2016-09-07 07:05:19 --> Output Class Initialized
INFO - 2016-09-07 07:05:19 --> Language Class Initialized
INFO - 2016-09-07 07:05:19 --> Config Class Initialized
INFO - 2016-09-07 07:05:19 --> Security Class Initialized
INFO - 2016-09-07 07:05:19 --> Output Class Initialized
DEBUG - 2016-09-07 07:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:19 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:19 --> Hooks Class Initialized
ERROR - 2016-09-07 07:05:19 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:19 --> Input Class Initialized
INFO - 2016-09-07 07:05:19 --> URI Class Initialized
INFO - 2016-09-07 07:05:19 --> Security Class Initialized
DEBUG - 2016-09-07 07:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-07 07:05:19 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:19 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:19 --> URI Class Initialized
INFO - 2016-09-07 07:05:19 --> Router Class Initialized
INFO - 2016-09-07 07:05:19 --> Output Class Initialized
INFO - 2016-09-07 07:05:19 --> Security Class Initialized
DEBUG - 2016-09-07 07:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:19 --> Input Class Initialized
INFO - 2016-09-07 07:05:19 --> Language Class Initialized
ERROR - 2016-09-07 07:05:19 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:19 --> Config Class Initialized
INFO - 2016-09-07 07:05:19 --> Hooks Class Initialized
INFO - 2016-09-07 07:05:19 --> Language Class Initialized
INFO - 2016-09-07 07:05:19 --> Router Class Initialized
INFO - 2016-09-07 07:05:19 --> Input Class Initialized
DEBUG - 2016-09-07 07:05:19 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 07:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:19 --> Config Class Initialized
INFO - 2016-09-07 07:05:19 --> Output Class Initialized
ERROR - 2016-09-07 07:05:19 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:19 --> Input Class Initialized
INFO - 2016-09-07 07:05:19 --> Hooks Class Initialized
INFO - 2016-09-07 07:05:19 --> Language Class Initialized
INFO - 2016-09-07 07:05:19 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:19 --> Language Class Initialized
INFO - 2016-09-07 07:05:19 --> Security Class Initialized
ERROR - 2016-09-07 07:05:19 --> 404 Page Not Found: /index
DEBUG - 2016-09-07 07:05:19 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:19 --> URI Class Initialized
INFO - 2016-09-07 07:05:19 --> Config Class Initialized
INFO - 2016-09-07 07:05:19 --> Hooks Class Initialized
ERROR - 2016-09-07 07:05:19 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:19 --> Utf8 Class Initialized
DEBUG - 2016-09-07 07:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:20 --> Config Class Initialized
DEBUG - 2016-09-07 07:05:20 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:20 --> Hooks Class Initialized
INFO - 2016-09-07 07:05:20 --> Router Class Initialized
INFO - 2016-09-07 07:05:20 --> Input Class Initialized
INFO - 2016-09-07 07:05:20 --> URI Class Initialized
INFO - 2016-09-07 07:05:20 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:20 --> Config Class Initialized
INFO - 2016-09-07 07:05:20 --> Hooks Class Initialized
INFO - 2016-09-07 07:05:20 --> Output Class Initialized
INFO - 2016-09-07 07:05:20 --> URI Class Initialized
INFO - 2016-09-07 07:05:20 --> Language Class Initialized
DEBUG - 2016-09-07 07:05:20 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:20 --> Security Class Initialized
DEBUG - 2016-09-07 07:05:20 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:20 --> Router Class Initialized
ERROR - 2016-09-07 07:05:20 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:20 --> Router Class Initialized
INFO - 2016-09-07 07:05:20 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:20 --> Utf8 Class Initialized
DEBUG - 2016-09-07 07:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:20 --> Output Class Initialized
INFO - 2016-09-07 07:05:20 --> Config Class Initialized
INFO - 2016-09-07 07:05:20 --> Output Class Initialized
INFO - 2016-09-07 07:05:20 --> URI Class Initialized
INFO - 2016-09-07 07:05:20 --> Hooks Class Initialized
INFO - 2016-09-07 07:05:20 --> URI Class Initialized
INFO - 2016-09-07 07:05:20 --> Security Class Initialized
INFO - 2016-09-07 07:05:20 --> Router Class Initialized
INFO - 2016-09-07 07:05:20 --> Input Class Initialized
INFO - 2016-09-07 07:05:20 --> Security Class Initialized
DEBUG - 2016-09-07 07:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-07 07:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:20 --> Router Class Initialized
INFO - 2016-09-07 07:05:20 --> Language Class Initialized
INFO - 2016-09-07 07:05:20 --> Output Class Initialized
DEBUG - 2016-09-07 07:05:20 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:20 --> Input Class Initialized
INFO - 2016-09-07 07:05:20 --> Security Class Initialized
INFO - 2016-09-07 07:05:20 --> Output Class Initialized
INFO - 2016-09-07 07:05:20 --> Input Class Initialized
INFO - 2016-09-07 07:05:20 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:20 --> Language Class Initialized
ERROR - 2016-09-07 07:05:20 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:20 --> Security Class Initialized
DEBUG - 2016-09-07 07:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:20 --> Language Class Initialized
ERROR - 2016-09-07 07:05:20 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:20 --> URI Class Initialized
DEBUG - 2016-09-07 07:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:20 --> Config Class Initialized
INFO - 2016-09-07 07:05:20 --> Router Class Initialized
ERROR - 2016-09-07 07:05:20 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:20 --> Input Class Initialized
INFO - 2016-09-07 07:05:20 --> Input Class Initialized
INFO - 2016-09-07 07:05:20 --> Language Class Initialized
INFO - 2016-09-07 07:05:20 --> Hooks Class Initialized
INFO - 2016-09-07 07:05:20 --> Output Class Initialized
INFO - 2016-09-07 07:05:20 --> Config Class Initialized
INFO - 2016-09-07 07:05:20 --> Config Class Initialized
ERROR - 2016-09-07 07:05:20 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:20 --> Language Class Initialized
DEBUG - 2016-09-07 07:05:20 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:20 --> Security Class Initialized
INFO - 2016-09-07 07:05:20 --> Utf8 Class Initialized
DEBUG - 2016-09-07 07:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:20 --> Hooks Class Initialized
ERROR - 2016-09-07 07:05:20 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:20 --> Hooks Class Initialized
INFO - 2016-09-07 07:05:20 --> URI Class Initialized
INFO - 2016-09-07 07:05:20 --> Config Class Initialized
INFO - 2016-09-07 07:05:20 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:05:20 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 07:05:20 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:20 --> Input Class Initialized
INFO - 2016-09-07 07:05:20 --> Router Class Initialized
INFO - 2016-09-07 07:05:20 --> Config Class Initialized
INFO - 2016-09-07 07:05:20 --> Hooks Class Initialized
INFO - 2016-09-07 07:05:20 --> Output Class Initialized
INFO - 2016-09-07 07:05:20 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:20 --> Utf8 Class Initialized
DEBUG - 2016-09-07 07:05:20 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:20 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:20 --> Language Class Initialized
INFO - 2016-09-07 07:05:20 --> URI Class Initialized
DEBUG - 2016-09-07 07:05:20 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:20 --> URI Class Initialized
INFO - 2016-09-07 07:05:20 --> Security Class Initialized
ERROR - 2016-09-07 07:05:20 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:20 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:20 --> Router Class Initialized
DEBUG - 2016-09-07 07:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:20 --> Router Class Initialized
INFO - 2016-09-07 07:05:20 --> URI Class Initialized
INFO - 2016-09-07 07:05:20 --> Output Class Initialized
INFO - 2016-09-07 07:05:20 --> Router Class Initialized
INFO - 2016-09-07 07:05:20 --> Output Class Initialized
INFO - 2016-09-07 07:05:20 --> Input Class Initialized
INFO - 2016-09-07 07:05:20 --> URI Class Initialized
INFO - 2016-09-07 07:05:20 --> Config Class Initialized
INFO - 2016-09-07 07:05:20 --> Security Class Initialized
INFO - 2016-09-07 07:05:20 --> Router Class Initialized
INFO - 2016-09-07 07:05:20 --> Hooks Class Initialized
INFO - 2016-09-07 07:05:20 --> Security Class Initialized
INFO - 2016-09-07 07:05:20 --> Language Class Initialized
INFO - 2016-09-07 07:05:20 --> Output Class Initialized
DEBUG - 2016-09-07 07:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:20 --> Output Class Initialized
DEBUG - 2016-09-07 07:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:20 --> Security Class Initialized
ERROR - 2016-09-07 07:05:20 --> 404 Page Not Found: /index
DEBUG - 2016-09-07 07:05:20 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:20 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:20 --> Security Class Initialized
INFO - 2016-09-07 07:05:20 --> Input Class Initialized
INFO - 2016-09-07 07:05:20 --> Input Class Initialized
DEBUG - 2016-09-07 07:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:20 --> URI Class Initialized
INFO - 2016-09-07 07:05:20 --> Config Class Initialized
INFO - 2016-09-07 07:05:20 --> Language Class Initialized
DEBUG - 2016-09-07 07:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:20 --> Router Class Initialized
ERROR - 2016-09-07 07:05:20 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:20 --> Hooks Class Initialized
INFO - 2016-09-07 07:05:20 --> Language Class Initialized
INFO - 2016-09-07 07:05:20 --> Input Class Initialized
INFO - 2016-09-07 07:05:20 --> Input Class Initialized
INFO - 2016-09-07 07:05:20 --> Language Class Initialized
INFO - 2016-09-07 07:05:20 --> Output Class Initialized
DEBUG - 2016-09-07 07:05:20 --> UTF-8 Support Enabled
ERROR - 2016-09-07 07:05:20 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:20 --> Language Class Initialized
ERROR - 2016-09-07 07:05:20 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:20 --> Config Class Initialized
INFO - 2016-09-07 07:05:20 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:20 --> Security Class Initialized
INFO - 2016-09-07 07:05:21 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:05:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-09-07 07:05:21 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:21 --> Config Class Initialized
INFO - 2016-09-07 07:05:21 --> URI Class Initialized
INFO - 2016-09-07 07:05:21 --> Hooks Class Initialized
INFO - 2016-09-07 07:05:21 --> Config Class Initialized
DEBUG - 2016-09-07 07:05:21 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:21 --> Input Class Initialized
INFO - 2016-09-07 07:05:21 --> Router Class Initialized
INFO - 2016-09-07 07:05:21 --> Language Class Initialized
DEBUG - 2016-09-07 07:05:21 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:21 --> Output Class Initialized
INFO - 2016-09-07 07:05:21 --> Config Class Initialized
INFO - 2016-09-07 07:05:21 --> Hooks Class Initialized
INFO - 2016-09-07 07:05:21 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:21 --> Hooks Class Initialized
ERROR - 2016-09-07 07:05:21 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:21 --> URI Class Initialized
INFO - 2016-09-07 07:05:21 --> Utf8 Class Initialized
DEBUG - 2016-09-07 07:05:21 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:21 --> Security Class Initialized
DEBUG - 2016-09-07 07:05:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 07:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:21 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:21 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:21 --> URI Class Initialized
INFO - 2016-09-07 07:05:21 --> Config Class Initialized
INFO - 2016-09-07 07:05:21 --> Router Class Initialized
INFO - 2016-09-07 07:05:21 --> Input Class Initialized
INFO - 2016-09-07 07:05:21 --> Output Class Initialized
INFO - 2016-09-07 07:05:21 --> Hooks Class Initialized
INFO - 2016-09-07 07:05:21 --> Router Class Initialized
INFO - 2016-09-07 07:05:21 --> URI Class Initialized
INFO - 2016-09-07 07:05:21 --> URI Class Initialized
INFO - 2016-09-07 07:05:21 --> Language Class Initialized
INFO - 2016-09-07 07:05:21 --> Router Class Initialized
INFO - 2016-09-07 07:05:21 --> Router Class Initialized
DEBUG - 2016-09-07 07:05:21 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:21 --> Security Class Initialized
INFO - 2016-09-07 07:05:21 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:21 --> Output Class Initialized
INFO - 2016-09-07 07:05:21 --> Security Class Initialized
ERROR - 2016-09-07 07:05:21 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:21 --> Output Class Initialized
INFO - 2016-09-07 07:05:21 --> Output Class Initialized
INFO - 2016-09-07 07:05:21 --> URI Class Initialized
DEBUG - 2016-09-07 07:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:21 --> Security Class Initialized
DEBUG - 2016-09-07 07:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:21 --> Security Class Initialized
INFO - 2016-09-07 07:05:21 --> Config Class Initialized
DEBUG - 2016-09-07 07:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:21 --> Hooks Class Initialized
INFO - 2016-09-07 07:05:21 --> Router Class Initialized
DEBUG - 2016-09-07 07:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:21 --> Input Class Initialized
INFO - 2016-09-07 07:05:21 --> Input Class Initialized
INFO - 2016-09-07 07:05:21 --> Input Class Initialized
INFO - 2016-09-07 07:05:21 --> Input Class Initialized
INFO - 2016-09-07 07:05:21 --> Language Class Initialized
INFO - 2016-09-07 07:05:21 --> Language Class Initialized
INFO - 2016-09-07 07:05:21 --> Language Class Initialized
INFO - 2016-09-07 07:05:21 --> Language Class Initialized
DEBUG - 2016-09-07 07:05:21 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:21 --> Output Class Initialized
INFO - 2016-09-07 07:05:21 --> Utf8 Class Initialized
ERROR - 2016-09-07 07:05:21 --> 404 Page Not Found: /index
ERROR - 2016-09-07 07:05:21 --> 404 Page Not Found: /index
ERROR - 2016-09-07 07:05:21 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:21 --> Security Class Initialized
ERROR - 2016-09-07 07:05:21 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:21 --> Config Class Initialized
INFO - 2016-09-07 07:05:21 --> Hooks Class Initialized
INFO - 2016-09-07 07:05:21 --> URI Class Initialized
DEBUG - 2016-09-07 07:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:21 --> Input Class Initialized
DEBUG - 2016-09-07 07:05:21 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:21 --> Config Class Initialized
INFO - 2016-09-07 07:05:21 --> Config Class Initialized
INFO - 2016-09-07 07:05:21 --> Router Class Initialized
INFO - 2016-09-07 07:05:21 --> Hooks Class Initialized
INFO - 2016-09-07 07:05:21 --> Hooks Class Initialized
INFO - 2016-09-07 07:05:21 --> Language Class Initialized
DEBUG - 2016-09-07 07:05:21 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:21 --> Config Class Initialized
INFO - 2016-09-07 07:05:21 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:21 --> Output Class Initialized
INFO - 2016-09-07 07:05:21 --> URI Class Initialized
DEBUG - 2016-09-07 07:05:21 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:21 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:21 --> Router Class Initialized
INFO - 2016-09-07 07:05:21 --> URI Class Initialized
INFO - 2016-09-07 07:05:21 --> Security Class Initialized
INFO - 2016-09-07 07:05:21 --> Hooks Class Initialized
INFO - 2016-09-07 07:05:21 --> Utf8 Class Initialized
ERROR - 2016-09-07 07:05:21 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:21 --> Output Class Initialized
INFO - 2016-09-07 07:05:21 --> Router Class Initialized
INFO - 2016-09-07 07:05:21 --> Security Class Initialized
INFO - 2016-09-07 07:05:21 --> URI Class Initialized
DEBUG - 2016-09-07 07:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:21 --> Input Class Initialized
INFO - 2016-09-07 07:05:21 --> Config Class Initialized
INFO - 2016-09-07 07:05:21 --> Output Class Initialized
DEBUG - 2016-09-07 07:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:21 --> Router Class Initialized
DEBUG - 2016-09-07 07:05:21 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:21 --> Language Class Initialized
INFO - 2016-09-07 07:05:21 --> Hooks Class Initialized
ERROR - 2016-09-07 07:05:21 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:21 --> Input Class Initialized
INFO - 2016-09-07 07:05:21 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:21 --> Output Class Initialized
INFO - 2016-09-07 07:05:21 --> URI Class Initialized
INFO - 2016-09-07 07:05:21 --> Language Class Initialized
INFO - 2016-09-07 07:05:21 --> Security Class Initialized
DEBUG - 2016-09-07 07:05:21 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:21 --> Security Class Initialized
INFO - 2016-09-07 07:05:21 --> Config Class Initialized
INFO - 2016-09-07 07:05:21 --> Hooks Class Initialized
INFO - 2016-09-07 07:05:21 --> Router Class Initialized
INFO - 2016-09-07 07:05:21 --> Output Class Initialized
DEBUG - 2016-09-07 07:05:21 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:21 --> Utf8 Class Initialized
DEBUG - 2016-09-07 07:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-07 07:05:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-09-07 07:05:21 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:21 --> Input Class Initialized
INFO - 2016-09-07 07:05:21 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:21 --> Language Class Initialized
INFO - 2016-09-07 07:05:21 --> URI Class Initialized
ERROR - 2016-09-07 07:05:21 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:21 --> Router Class Initialized
INFO - 2016-09-07 07:05:21 --> Output Class Initialized
INFO - 2016-09-07 07:05:22 --> Config Class Initialized
INFO - 2016-09-07 07:05:22 --> Hooks Class Initialized
INFO - 2016-09-07 07:05:22 --> Security Class Initialized
INFO - 2016-09-07 07:05:22 --> Input Class Initialized
INFO - 2016-09-07 07:05:22 --> Security Class Initialized
INFO - 2016-09-07 07:05:22 --> Language Class Initialized
DEBUG - 2016-09-07 07:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:22 --> URI Class Initialized
DEBUG - 2016-09-07 07:05:22 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:22 --> Config Class Initialized
DEBUG - 2016-09-07 07:05:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-09-07 07:05:22 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:22 --> Router Class Initialized
INFO - 2016-09-07 07:05:22 --> Input Class Initialized
INFO - 2016-09-07 07:05:22 --> Hooks Class Initialized
INFO - 2016-09-07 07:05:22 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:22 --> Input Class Initialized
INFO - 2016-09-07 07:05:22 --> Config Class Initialized
INFO - 2016-09-07 07:05:22 --> Language Class Initialized
INFO - 2016-09-07 07:05:22 --> Hooks Class Initialized
INFO - 2016-09-07 07:05:22 --> Output Class Initialized
INFO - 2016-09-07 07:05:22 --> URI Class Initialized
INFO - 2016-09-07 07:05:22 --> Language Class Initialized
DEBUG - 2016-09-07 07:05:22 --> UTF-8 Support Enabled
ERROR - 2016-09-07 07:05:22 --> 404 Page Not Found: /index
ERROR - 2016-09-07 07:05:22 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:22 --> Security Class Initialized
DEBUG - 2016-09-07 07:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:22 --> Utf8 Class Initialized
DEBUG - 2016-09-07 07:05:22 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:22 --> Config Class Initialized
INFO - 2016-09-07 07:05:22 --> Router Class Initialized
INFO - 2016-09-07 07:05:22 --> Config Class Initialized
INFO - 2016-09-07 07:05:22 --> Input Class Initialized
INFO - 2016-09-07 07:05:22 --> Language Class Initialized
INFO - 2016-09-07 07:05:22 --> URI Class Initialized
INFO - 2016-09-07 07:05:22 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:22 --> Output Class Initialized
INFO - 2016-09-07 07:05:22 --> Hooks Class Initialized
INFO - 2016-09-07 07:05:22 --> Hooks Class Initialized
INFO - 2016-09-07 07:05:22 --> Security Class Initialized
DEBUG - 2016-09-07 07:05:22 --> UTF-8 Support Enabled
ERROR - 2016-09-07 07:05:22 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:22 --> URI Class Initialized
INFO - 2016-09-07 07:05:22 --> Router Class Initialized
DEBUG - 2016-09-07 07:05:22 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:22 --> Output Class Initialized
INFO - 2016-09-07 07:05:22 --> Router Class Initialized
DEBUG - 2016-09-07 07:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:22 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:22 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:22 --> Config Class Initialized
INFO - 2016-09-07 07:05:22 --> Hooks Class Initialized
INFO - 2016-09-07 07:05:22 --> Security Class Initialized
DEBUG - 2016-09-07 07:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-07 07:05:22 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:22 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:22 --> Input Class Initialized
INFO - 2016-09-07 07:05:22 --> Language Class Initialized
INFO - 2016-09-07 07:05:22 --> URI Class Initialized
INFO - 2016-09-07 07:05:22 --> Input Class Initialized
INFO - 2016-09-07 07:05:22 --> URI Class Initialized
INFO - 2016-09-07 07:05:22 --> Output Class Initialized
INFO - 2016-09-07 07:05:22 --> URI Class Initialized
INFO - 2016-09-07 07:05:22 --> Router Class Initialized
ERROR - 2016-09-07 07:05:22 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:22 --> Router Class Initialized
INFO - 2016-09-07 07:05:22 --> Router Class Initialized
INFO - 2016-09-07 07:05:22 --> Language Class Initialized
INFO - 2016-09-07 07:05:22 --> Security Class Initialized
INFO - 2016-09-07 07:05:22 --> Output Class Initialized
DEBUG - 2016-09-07 07:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:22 --> Output Class Initialized
INFO - 2016-09-07 07:05:22 --> Output Class Initialized
ERROR - 2016-09-07 07:05:22 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:22 --> Security Class Initialized
INFO - 2016-09-07 07:05:22 --> Security Class Initialized
INFO - 2016-09-07 07:05:22 --> Security Class Initialized
INFO - 2016-09-07 07:05:22 --> Config Class Initialized
INFO - 2016-09-07 07:05:22 --> Input Class Initialized
INFO - 2016-09-07 07:05:22 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:22 --> Input Class Initialized
DEBUG - 2016-09-07 07:05:22 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 07:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-07 07:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:22 --> Language Class Initialized
INFO - 2016-09-07 07:05:22 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:22 --> Language Class Initialized
INFO - 2016-09-07 07:05:22 --> URI Class Initialized
ERROR - 2016-09-07 07:05:22 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:22 --> Input Class Initialized
INFO - 2016-09-07 07:05:22 --> Input Class Initialized
ERROR - 2016-09-07 07:05:22 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:22 --> Router Class Initialized
INFO - 2016-09-07 07:05:22 --> Language Class Initialized
INFO - 2016-09-07 07:05:22 --> Output Class Initialized
INFO - 2016-09-07 07:05:22 --> Language Class Initialized
ERROR - 2016-09-07 07:05:22 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:22 --> Config Class Initialized
ERROR - 2016-09-07 07:05:22 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:22 --> Security Class Initialized
INFO - 2016-09-07 07:05:22 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-07 07:05:23 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:23 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:23 --> Input Class Initialized
INFO - 2016-09-07 07:05:23 --> Language Class Initialized
INFO - 2016-09-07 07:05:23 --> URI Class Initialized
ERROR - 2016-09-07 07:05:23 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:23 --> Router Class Initialized
INFO - 2016-09-07 07:05:23 --> Output Class Initialized
INFO - 2016-09-07 07:05:23 --> Security Class Initialized
DEBUG - 2016-09-07 07:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:23 --> Input Class Initialized
INFO - 2016-09-07 07:05:23 --> Language Class Initialized
ERROR - 2016-09-07 07:05:23 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:23 --> Config Class Initialized
INFO - 2016-09-07 07:05:23 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:05:23 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:23 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:23 --> URI Class Initialized
INFO - 2016-09-07 07:05:23 --> Router Class Initialized
INFO - 2016-09-07 07:05:23 --> Output Class Initialized
INFO - 2016-09-07 07:05:23 --> Security Class Initialized
DEBUG - 2016-09-07 07:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:23 --> Input Class Initialized
INFO - 2016-09-07 07:05:23 --> Language Class Initialized
ERROR - 2016-09-07 07:05:23 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:23 --> Config Class Initialized
INFO - 2016-09-07 07:05:23 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:05:23 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:23 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:23 --> URI Class Initialized
INFO - 2016-09-07 07:05:23 --> Router Class Initialized
INFO - 2016-09-07 07:05:23 --> Output Class Initialized
INFO - 2016-09-07 07:05:23 --> Security Class Initialized
DEBUG - 2016-09-07 07:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:23 --> Input Class Initialized
INFO - 2016-09-07 07:05:23 --> Language Class Initialized
ERROR - 2016-09-07 07:05:23 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:24 --> Config Class Initialized
INFO - 2016-09-07 07:05:24 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:05:24 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:24 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:24 --> URI Class Initialized
INFO - 2016-09-07 07:05:24 --> Router Class Initialized
INFO - 2016-09-07 07:05:24 --> Output Class Initialized
INFO - 2016-09-07 07:05:24 --> Security Class Initialized
DEBUG - 2016-09-07 07:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:24 --> Input Class Initialized
INFO - 2016-09-07 07:05:24 --> Language Class Initialized
ERROR - 2016-09-07 07:05:24 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:24 --> Config Class Initialized
INFO - 2016-09-07 07:05:24 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:05:24 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:24 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:24 --> URI Class Initialized
INFO - 2016-09-07 07:05:24 --> Router Class Initialized
INFO - 2016-09-07 07:05:24 --> Output Class Initialized
INFO - 2016-09-07 07:05:24 --> Security Class Initialized
DEBUG - 2016-09-07 07:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:24 --> Input Class Initialized
INFO - 2016-09-07 07:05:24 --> Language Class Initialized
ERROR - 2016-09-07 07:05:24 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:24 --> Config Class Initialized
INFO - 2016-09-07 07:05:24 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:05:24 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:24 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:24 --> URI Class Initialized
INFO - 2016-09-07 07:05:24 --> Router Class Initialized
INFO - 2016-09-07 07:05:24 --> Output Class Initialized
INFO - 2016-09-07 07:05:24 --> Security Class Initialized
DEBUG - 2016-09-07 07:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:24 --> Input Class Initialized
INFO - 2016-09-07 07:05:24 --> Language Class Initialized
ERROR - 2016-09-07 07:05:24 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:24 --> Config Class Initialized
INFO - 2016-09-07 07:05:24 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:05:25 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:25 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:25 --> URI Class Initialized
INFO - 2016-09-07 07:05:25 --> Router Class Initialized
INFO - 2016-09-07 07:05:25 --> Output Class Initialized
INFO - 2016-09-07 07:05:25 --> Security Class Initialized
DEBUG - 2016-09-07 07:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:25 --> Input Class Initialized
INFO - 2016-09-07 07:05:25 --> Language Class Initialized
ERROR - 2016-09-07 07:05:25 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:25 --> Config Class Initialized
INFO - 2016-09-07 07:05:25 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:05:25 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:25 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:25 --> URI Class Initialized
INFO - 2016-09-07 07:05:25 --> Router Class Initialized
INFO - 2016-09-07 07:05:25 --> Output Class Initialized
INFO - 2016-09-07 07:05:25 --> Security Class Initialized
DEBUG - 2016-09-07 07:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:25 --> Input Class Initialized
INFO - 2016-09-07 07:05:25 --> Language Class Initialized
ERROR - 2016-09-07 07:05:25 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:25 --> Config Class Initialized
INFO - 2016-09-07 07:05:25 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:05:25 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:25 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:25 --> URI Class Initialized
INFO - 2016-09-07 07:05:25 --> Router Class Initialized
INFO - 2016-09-07 07:05:25 --> Output Class Initialized
INFO - 2016-09-07 07:05:25 --> Security Class Initialized
DEBUG - 2016-09-07 07:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:25 --> Input Class Initialized
INFO - 2016-09-07 07:05:25 --> Language Class Initialized
ERROR - 2016-09-07 07:05:25 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:25 --> Config Class Initialized
INFO - 2016-09-07 07:05:25 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:05:25 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:25 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:25 --> URI Class Initialized
INFO - 2016-09-07 07:05:26 --> Router Class Initialized
INFO - 2016-09-07 07:05:26 --> Output Class Initialized
INFO - 2016-09-07 07:05:26 --> Security Class Initialized
DEBUG - 2016-09-07 07:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:26 --> Input Class Initialized
INFO - 2016-09-07 07:05:26 --> Language Class Initialized
ERROR - 2016-09-07 07:05:26 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:26 --> Config Class Initialized
INFO - 2016-09-07 07:05:26 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:05:26 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:26 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:26 --> URI Class Initialized
INFO - 2016-09-07 07:05:26 --> Router Class Initialized
INFO - 2016-09-07 07:05:26 --> Output Class Initialized
INFO - 2016-09-07 07:05:26 --> Security Class Initialized
DEBUG - 2016-09-07 07:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:26 --> Input Class Initialized
INFO - 2016-09-07 07:05:26 --> Language Class Initialized
ERROR - 2016-09-07 07:05:26 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:26 --> Config Class Initialized
INFO - 2016-09-07 07:05:26 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:05:26 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:26 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:26 --> URI Class Initialized
INFO - 2016-09-07 07:05:26 --> Router Class Initialized
INFO - 2016-09-07 07:05:26 --> Output Class Initialized
INFO - 2016-09-07 07:05:26 --> Security Class Initialized
DEBUG - 2016-09-07 07:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:26 --> Input Class Initialized
INFO - 2016-09-07 07:05:26 --> Language Class Initialized
ERROR - 2016-09-07 07:05:26 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:26 --> Config Class Initialized
INFO - 2016-09-07 07:05:26 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:05:26 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:26 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:26 --> URI Class Initialized
INFO - 2016-09-07 07:05:27 --> Router Class Initialized
INFO - 2016-09-07 07:05:27 --> Output Class Initialized
INFO - 2016-09-07 07:05:27 --> Security Class Initialized
DEBUG - 2016-09-07 07:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:27 --> Input Class Initialized
INFO - 2016-09-07 07:05:27 --> Language Class Initialized
ERROR - 2016-09-07 07:05:27 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:27 --> Config Class Initialized
INFO - 2016-09-07 07:05:27 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:05:27 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:27 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:27 --> URI Class Initialized
INFO - 2016-09-07 07:05:27 --> Router Class Initialized
INFO - 2016-09-07 07:05:27 --> Output Class Initialized
INFO - 2016-09-07 07:05:27 --> Security Class Initialized
DEBUG - 2016-09-07 07:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:27 --> Input Class Initialized
INFO - 2016-09-07 07:05:27 --> Language Class Initialized
ERROR - 2016-09-07 07:05:27 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:27 --> Config Class Initialized
INFO - 2016-09-07 07:05:27 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:05:27 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:27 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:27 --> URI Class Initialized
INFO - 2016-09-07 07:05:27 --> Router Class Initialized
INFO - 2016-09-07 07:05:27 --> Output Class Initialized
INFO - 2016-09-07 07:05:27 --> Security Class Initialized
DEBUG - 2016-09-07 07:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:27 --> Input Class Initialized
INFO - 2016-09-07 07:05:27 --> Language Class Initialized
ERROR - 2016-09-07 07:05:27 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:27 --> Config Class Initialized
INFO - 2016-09-07 07:05:27 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:05:28 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:28 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:28 --> URI Class Initialized
INFO - 2016-09-07 07:05:28 --> Router Class Initialized
INFO - 2016-09-07 07:05:28 --> Output Class Initialized
INFO - 2016-09-07 07:05:28 --> Security Class Initialized
DEBUG - 2016-09-07 07:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:28 --> Input Class Initialized
INFO - 2016-09-07 07:05:28 --> Language Class Initialized
ERROR - 2016-09-07 07:05:28 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:28 --> Config Class Initialized
INFO - 2016-09-07 07:05:28 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:05:28 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:28 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:28 --> URI Class Initialized
INFO - 2016-09-07 07:05:28 --> Router Class Initialized
INFO - 2016-09-07 07:05:28 --> Output Class Initialized
INFO - 2016-09-07 07:05:28 --> Security Class Initialized
DEBUG - 2016-09-07 07:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:28 --> Input Class Initialized
INFO - 2016-09-07 07:05:28 --> Language Class Initialized
ERROR - 2016-09-07 07:05:28 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:28 --> Config Class Initialized
INFO - 2016-09-07 07:05:28 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:05:28 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:28 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:28 --> URI Class Initialized
INFO - 2016-09-07 07:05:28 --> Router Class Initialized
INFO - 2016-09-07 07:05:28 --> Output Class Initialized
INFO - 2016-09-07 07:05:28 --> Security Class Initialized
DEBUG - 2016-09-07 07:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:28 --> Input Class Initialized
INFO - 2016-09-07 07:05:28 --> Language Class Initialized
ERROR - 2016-09-07 07:05:28 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:28 --> Config Class Initialized
INFO - 2016-09-07 07:05:29 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:05:29 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:29 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:29 --> URI Class Initialized
INFO - 2016-09-07 07:05:29 --> Router Class Initialized
INFO - 2016-09-07 07:05:29 --> Output Class Initialized
INFO - 2016-09-07 07:05:29 --> Security Class Initialized
DEBUG - 2016-09-07 07:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:29 --> Input Class Initialized
INFO - 2016-09-07 07:05:29 --> Language Class Initialized
ERROR - 2016-09-07 07:05:29 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:29 --> Config Class Initialized
INFO - 2016-09-07 07:05:29 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:05:29 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:29 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:29 --> URI Class Initialized
INFO - 2016-09-07 07:05:29 --> Router Class Initialized
INFO - 2016-09-07 07:05:29 --> Output Class Initialized
INFO - 2016-09-07 07:05:29 --> Security Class Initialized
DEBUG - 2016-09-07 07:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:29 --> Input Class Initialized
INFO - 2016-09-07 07:05:29 --> Language Class Initialized
ERROR - 2016-09-07 07:05:29 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:29 --> Config Class Initialized
INFO - 2016-09-07 07:05:29 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:05:29 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:29 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:29 --> URI Class Initialized
INFO - 2016-09-07 07:05:29 --> Router Class Initialized
INFO - 2016-09-07 07:05:29 --> Output Class Initialized
INFO - 2016-09-07 07:05:29 --> Security Class Initialized
DEBUG - 2016-09-07 07:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:29 --> Input Class Initialized
INFO - 2016-09-07 07:05:29 --> Language Class Initialized
ERROR - 2016-09-07 07:05:29 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:29 --> Config Class Initialized
INFO - 2016-09-07 07:05:29 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:05:30 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:30 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:30 --> URI Class Initialized
INFO - 2016-09-07 07:05:30 --> Router Class Initialized
INFO - 2016-09-07 07:05:30 --> Output Class Initialized
INFO - 2016-09-07 07:05:30 --> Security Class Initialized
DEBUG - 2016-09-07 07:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:30 --> Input Class Initialized
INFO - 2016-09-07 07:05:30 --> Language Class Initialized
ERROR - 2016-09-07 07:05:30 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:30 --> Config Class Initialized
INFO - 2016-09-07 07:05:30 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:05:30 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:30 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:30 --> URI Class Initialized
INFO - 2016-09-07 07:05:30 --> Router Class Initialized
INFO - 2016-09-07 07:05:30 --> Output Class Initialized
INFO - 2016-09-07 07:05:30 --> Security Class Initialized
DEBUG - 2016-09-07 07:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:30 --> Input Class Initialized
INFO - 2016-09-07 07:05:30 --> Language Class Initialized
ERROR - 2016-09-07 07:05:30 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:30 --> Config Class Initialized
INFO - 2016-09-07 07:05:30 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:05:30 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:30 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:30 --> URI Class Initialized
INFO - 2016-09-07 07:05:30 --> Router Class Initialized
INFO - 2016-09-07 07:05:30 --> Output Class Initialized
INFO - 2016-09-07 07:05:30 --> Security Class Initialized
DEBUG - 2016-09-07 07:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:30 --> Input Class Initialized
INFO - 2016-09-07 07:05:30 --> Language Class Initialized
ERROR - 2016-09-07 07:05:30 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:30 --> Config Class Initialized
INFO - 2016-09-07 07:05:30 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:05:30 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:31 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:31 --> URI Class Initialized
INFO - 2016-09-07 07:05:31 --> Router Class Initialized
INFO - 2016-09-07 07:05:31 --> Output Class Initialized
INFO - 2016-09-07 07:05:31 --> Security Class Initialized
DEBUG - 2016-09-07 07:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:31 --> Input Class Initialized
INFO - 2016-09-07 07:05:31 --> Language Class Initialized
ERROR - 2016-09-07 07:05:31 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:31 --> Config Class Initialized
INFO - 2016-09-07 07:05:31 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:05:31 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:31 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:31 --> URI Class Initialized
INFO - 2016-09-07 07:05:31 --> Router Class Initialized
INFO - 2016-09-07 07:05:31 --> Output Class Initialized
INFO - 2016-09-07 07:05:31 --> Security Class Initialized
DEBUG - 2016-09-07 07:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:31 --> Input Class Initialized
INFO - 2016-09-07 07:05:31 --> Language Class Initialized
ERROR - 2016-09-07 07:05:31 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:31 --> Config Class Initialized
INFO - 2016-09-07 07:05:31 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:05:31 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:31 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:31 --> URI Class Initialized
INFO - 2016-09-07 07:05:31 --> Router Class Initialized
INFO - 2016-09-07 07:05:31 --> Output Class Initialized
INFO - 2016-09-07 07:05:31 --> Security Class Initialized
DEBUG - 2016-09-07 07:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:31 --> Input Class Initialized
INFO - 2016-09-07 07:05:31 --> Language Class Initialized
ERROR - 2016-09-07 07:05:31 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:31 --> Config Class Initialized
INFO - 2016-09-07 07:05:31 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:05:31 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:32 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:32 --> URI Class Initialized
INFO - 2016-09-07 07:05:32 --> Router Class Initialized
INFO - 2016-09-07 07:05:32 --> Output Class Initialized
INFO - 2016-09-07 07:05:32 --> Security Class Initialized
DEBUG - 2016-09-07 07:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:32 --> Input Class Initialized
INFO - 2016-09-07 07:05:32 --> Language Class Initialized
ERROR - 2016-09-07 07:05:32 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:32 --> Config Class Initialized
INFO - 2016-09-07 07:05:32 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:05:32 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:32 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:32 --> URI Class Initialized
INFO - 2016-09-07 07:05:32 --> Router Class Initialized
INFO - 2016-09-07 07:05:32 --> Output Class Initialized
INFO - 2016-09-07 07:05:32 --> Security Class Initialized
DEBUG - 2016-09-07 07:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:32 --> Input Class Initialized
INFO - 2016-09-07 07:05:32 --> Language Class Initialized
ERROR - 2016-09-07 07:05:32 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:32 --> Config Class Initialized
INFO - 2016-09-07 07:05:32 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:05:32 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:32 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:32 --> URI Class Initialized
INFO - 2016-09-07 07:05:32 --> Router Class Initialized
INFO - 2016-09-07 07:05:32 --> Output Class Initialized
INFO - 2016-09-07 07:05:32 --> Security Class Initialized
DEBUG - 2016-09-07 07:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:32 --> Input Class Initialized
INFO - 2016-09-07 07:05:32 --> Language Class Initialized
ERROR - 2016-09-07 07:05:32 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:32 --> Config Class Initialized
INFO - 2016-09-07 07:05:33 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:05:33 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:33 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:33 --> URI Class Initialized
INFO - 2016-09-07 07:05:33 --> Router Class Initialized
INFO - 2016-09-07 07:05:33 --> Output Class Initialized
INFO - 2016-09-07 07:05:33 --> Security Class Initialized
DEBUG - 2016-09-07 07:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:33 --> Input Class Initialized
INFO - 2016-09-07 07:05:33 --> Language Class Initialized
ERROR - 2016-09-07 07:05:33 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:33 --> Config Class Initialized
INFO - 2016-09-07 07:05:33 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:05:33 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:33 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:33 --> URI Class Initialized
INFO - 2016-09-07 07:05:33 --> Router Class Initialized
INFO - 2016-09-07 07:05:33 --> Output Class Initialized
INFO - 2016-09-07 07:05:33 --> Security Class Initialized
DEBUG - 2016-09-07 07:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:33 --> Input Class Initialized
INFO - 2016-09-07 07:05:33 --> Language Class Initialized
ERROR - 2016-09-07 07:05:33 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:33 --> Config Class Initialized
INFO - 2016-09-07 07:05:33 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:05:33 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:33 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:33 --> URI Class Initialized
INFO - 2016-09-07 07:05:33 --> Router Class Initialized
INFO - 2016-09-07 07:05:33 --> Output Class Initialized
INFO - 2016-09-07 07:05:33 --> Security Class Initialized
DEBUG - 2016-09-07 07:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:33 --> Input Class Initialized
INFO - 2016-09-07 07:05:33 --> Language Class Initialized
ERROR - 2016-09-07 07:05:33 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:34 --> Config Class Initialized
INFO - 2016-09-07 07:05:34 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:05:34 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:34 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:34 --> URI Class Initialized
INFO - 2016-09-07 07:05:34 --> Router Class Initialized
INFO - 2016-09-07 07:05:34 --> Output Class Initialized
INFO - 2016-09-07 07:05:34 --> Security Class Initialized
DEBUG - 2016-09-07 07:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:34 --> Input Class Initialized
INFO - 2016-09-07 07:05:34 --> Language Class Initialized
ERROR - 2016-09-07 07:05:34 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:34 --> Config Class Initialized
INFO - 2016-09-07 07:05:34 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:05:34 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:34 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:34 --> URI Class Initialized
INFO - 2016-09-07 07:05:34 --> Router Class Initialized
INFO - 2016-09-07 07:05:34 --> Output Class Initialized
INFO - 2016-09-07 07:05:34 --> Security Class Initialized
DEBUG - 2016-09-07 07:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:34 --> Input Class Initialized
INFO - 2016-09-07 07:05:34 --> Language Class Initialized
ERROR - 2016-09-07 07:05:34 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:34 --> Config Class Initialized
INFO - 2016-09-07 07:05:34 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:05:35 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:35 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:35 --> URI Class Initialized
INFO - 2016-09-07 07:05:35 --> Router Class Initialized
INFO - 2016-09-07 07:05:35 --> Output Class Initialized
INFO - 2016-09-07 07:05:35 --> Security Class Initialized
DEBUG - 2016-09-07 07:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:35 --> Input Class Initialized
INFO - 2016-09-07 07:05:35 --> Language Class Initialized
ERROR - 2016-09-07 07:05:35 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:05:35 --> Config Class Initialized
INFO - 2016-09-07 07:05:35 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:05:35 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:05:35 --> Utf8 Class Initialized
INFO - 2016-09-07 07:05:35 --> URI Class Initialized
INFO - 2016-09-07 07:05:35 --> Router Class Initialized
INFO - 2016-09-07 07:05:35 --> Output Class Initialized
INFO - 2016-09-07 07:05:35 --> Security Class Initialized
DEBUG - 2016-09-07 07:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:05:35 --> Input Class Initialized
INFO - 2016-09-07 07:05:35 --> Language Class Initialized
ERROR - 2016-09-07 07:05:35 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:15 --> Config Class Initialized
INFO - 2016-09-07 07:06:15 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:06:15 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:15 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:15 --> URI Class Initialized
INFO - 2016-09-07 07:06:15 --> Router Class Initialized
INFO - 2016-09-07 07:06:15 --> Output Class Initialized
INFO - 2016-09-07 07:06:15 --> Security Class Initialized
DEBUG - 2016-09-07 07:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:15 --> Input Class Initialized
INFO - 2016-09-07 07:06:15 --> Language Class Initialized
INFO - 2016-09-07 07:06:15 --> Language Class Initialized
INFO - 2016-09-07 07:06:15 --> Config Class Initialized
INFO - 2016-09-07 07:06:15 --> Loader Class Initialized
INFO - 2016-09-07 07:06:15 --> Helper loaded: url_helper
INFO - 2016-09-07 07:06:15 --> Database Driver Class Initialized
INFO - 2016-09-07 07:06:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-07 07:06:15 --> Model Class Initialized
INFO - 2016-09-07 07:06:15 --> Model Class Initialized
INFO - 2016-09-07 07:06:15 --> Controller Class Initialized
DEBUG - 2016-09-07 07:06:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 07:06:15 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 07:06:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 07:06:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/dashboard.php
DEBUG - 2016-09-07 07:06:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 07:06:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 07:06:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 07:06:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 07:06:16 --> Final output sent to browser
DEBUG - 2016-09-07 07:06:16 --> Total execution time: 0.6404
INFO - 2016-09-07 07:06:16 --> Config Class Initialized
INFO - 2016-09-07 07:06:16 --> Config Class Initialized
INFO - 2016-09-07 07:06:16 --> Config Class Initialized
INFO - 2016-09-07 07:06:16 --> Hooks Class Initialized
INFO - 2016-09-07 07:06:16 --> Config Class Initialized
INFO - 2016-09-07 07:06:16 --> Hooks Class Initialized
INFO - 2016-09-07 07:06:16 --> Config Class Initialized
INFO - 2016-09-07 07:06:16 --> Hooks Class Initialized
INFO - 2016-09-07 07:06:16 --> Config Class Initialized
INFO - 2016-09-07 07:06:16 --> Hooks Class Initialized
INFO - 2016-09-07 07:06:16 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:06:16 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 07:06:16 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 07:06:16 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:16 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:06:16 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:16 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:16 --> URI Class Initialized
INFO - 2016-09-07 07:06:16 --> Router Class Initialized
INFO - 2016-09-07 07:06:16 --> Output Class Initialized
INFO - 2016-09-07 07:06:16 --> Security Class Initialized
DEBUG - 2016-09-07 07:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:16 --> Input Class Initialized
INFO - 2016-09-07 07:06:16 --> Language Class Initialized
DEBUG - 2016-09-07 07:06:16 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:16 --> Utf8 Class Initialized
DEBUG - 2016-09-07 07:06:16 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:16 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:16 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:16 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:16 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:16 --> URI Class Initialized
ERROR - 2016-09-07 07:06:16 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:16 --> URI Class Initialized
INFO - 2016-09-07 07:06:16 --> URI Class Initialized
INFO - 2016-09-07 07:06:16 --> URI Class Initialized
INFO - 2016-09-07 07:06:16 --> Router Class Initialized
INFO - 2016-09-07 07:06:17 --> Router Class Initialized
INFO - 2016-09-07 07:06:17 --> Router Class Initialized
INFO - 2016-09-07 07:06:17 --> URI Class Initialized
INFO - 2016-09-07 07:06:17 --> Config Class Initialized
INFO - 2016-09-07 07:06:17 --> Router Class Initialized
INFO - 2016-09-07 07:06:17 --> Router Class Initialized
INFO - 2016-09-07 07:06:17 --> Output Class Initialized
INFO - 2016-09-07 07:06:17 --> Output Class Initialized
INFO - 2016-09-07 07:06:17 --> Output Class Initialized
INFO - 2016-09-07 07:06:17 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:06:17 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:17 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:17 --> URI Class Initialized
INFO - 2016-09-07 07:06:17 --> Router Class Initialized
INFO - 2016-09-07 07:06:17 --> Security Class Initialized
INFO - 2016-09-07 07:06:17 --> Security Class Initialized
INFO - 2016-09-07 07:06:17 --> Output Class Initialized
INFO - 2016-09-07 07:06:17 --> Output Class Initialized
INFO - 2016-09-07 07:06:17 --> Output Class Initialized
INFO - 2016-09-07 07:06:17 --> Security Class Initialized
INFO - 2016-09-07 07:06:17 --> Security Class Initialized
DEBUG - 2016-09-07 07:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-07 07:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:17 --> Input Class Initialized
INFO - 2016-09-07 07:06:17 --> Language Class Initialized
ERROR - 2016-09-07 07:06:17 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:17 --> Input Class Initialized
INFO - 2016-09-07 07:06:17 --> Language Class Initialized
ERROR - 2016-09-07 07:06:17 --> 404 Page Not Found: /index
DEBUG - 2016-09-07 07:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:17 --> Input Class Initialized
INFO - 2016-09-07 07:06:17 --> Security Class Initialized
INFO - 2016-09-07 07:06:17 --> Config Class Initialized
INFO - 2016-09-07 07:06:17 --> Config Class Initialized
INFO - 2016-09-07 07:06:17 --> Language Class Initialized
INFO - 2016-09-07 07:06:17 --> Security Class Initialized
DEBUG - 2016-09-07 07:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:17 --> Hooks Class Initialized
INFO - 2016-09-07 07:06:17 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-07 07:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:17 --> Input Class Initialized
ERROR - 2016-09-07 07:06:17 --> 404 Page Not Found: /index
DEBUG - 2016-09-07 07:06:17 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:17 --> Utf8 Class Initialized
DEBUG - 2016-09-07 07:06:17 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:17 --> URI Class Initialized
INFO - 2016-09-07 07:06:17 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:17 --> URI Class Initialized
INFO - 2016-09-07 07:06:18 --> Router Class Initialized
INFO - 2016-09-07 07:06:18 --> Input Class Initialized
INFO - 2016-09-07 07:06:18 --> Output Class Initialized
INFO - 2016-09-07 07:06:18 --> Language Class Initialized
ERROR - 2016-09-07 07:06:18 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:18 --> Router Class Initialized
INFO - 2016-09-07 07:06:18 --> Output Class Initialized
INFO - 2016-09-07 07:06:18 --> Security Class Initialized
INFO - 2016-09-07 07:06:18 --> Language Class Initialized
INFO - 2016-09-07 07:06:18 --> Input Class Initialized
INFO - 2016-09-07 07:06:18 --> Security Class Initialized
DEBUG - 2016-09-07 07:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:18 --> Input Class Initialized
INFO - 2016-09-07 07:06:18 --> Config Class Initialized
INFO - 2016-09-07 07:06:18 --> Config Class Initialized
INFO - 2016-09-07 07:06:18 --> Hooks Class Initialized
INFO - 2016-09-07 07:06:18 --> Language Class Initialized
ERROR - 2016-09-07 07:06:18 --> 404 Page Not Found: /index
DEBUG - 2016-09-07 07:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:18 --> Language Class Initialized
INFO - 2016-09-07 07:06:18 --> Hooks Class Initialized
ERROR - 2016-09-07 07:06:18 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:18 --> Input Class Initialized
INFO - 2016-09-07 07:06:18 --> Config Class Initialized
ERROR - 2016-09-07 07:06:18 --> 404 Page Not Found: /index
DEBUG - 2016-09-07 07:06:18 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 07:06:18 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:18 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:18 --> Config Class Initialized
INFO - 2016-09-07 07:06:18 --> Hooks Class Initialized
INFO - 2016-09-07 07:06:18 --> Language Class Initialized
INFO - 2016-09-07 07:06:18 --> Hooks Class Initialized
INFO - 2016-09-07 07:06:18 --> Config Class Initialized
INFO - 2016-09-07 07:06:18 --> URI Class Initialized
ERROR - 2016-09-07 07:06:18 --> 404 Page Not Found: /index
DEBUG - 2016-09-07 07:06:18 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:18 --> Utf8 Class Initialized
DEBUG - 2016-09-07 07:06:18 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:18 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:18 --> URI Class Initialized
INFO - 2016-09-07 07:06:18 --> Hooks Class Initialized
INFO - 2016-09-07 07:06:18 --> URI Class Initialized
INFO - 2016-09-07 07:06:18 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:18 --> Router Class Initialized
INFO - 2016-09-07 07:06:18 --> Router Class Initialized
INFO - 2016-09-07 07:06:18 --> Config Class Initialized
INFO - 2016-09-07 07:06:19 --> Output Class Initialized
INFO - 2016-09-07 07:06:19 --> Router Class Initialized
DEBUG - 2016-09-07 07:06:19 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:19 --> URI Class Initialized
INFO - 2016-09-07 07:06:19 --> Output Class Initialized
INFO - 2016-09-07 07:06:19 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:06:19 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:19 --> Output Class Initialized
INFO - 2016-09-07 07:06:19 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:19 --> Security Class Initialized
INFO - 2016-09-07 07:06:19 --> Router Class Initialized
INFO - 2016-09-07 07:06:19 --> Security Class Initialized
INFO - 2016-09-07 07:06:19 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:19 --> URI Class Initialized
INFO - 2016-09-07 07:06:19 --> Security Class Initialized
DEBUG - 2016-09-07 07:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-07 07:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:19 --> Output Class Initialized
INFO - 2016-09-07 07:06:19 --> URI Class Initialized
INFO - 2016-09-07 07:06:19 --> Router Class Initialized
INFO - 2016-09-07 07:06:19 --> Input Class Initialized
INFO - 2016-09-07 07:06:19 --> Input Class Initialized
INFO - 2016-09-07 07:06:19 --> Security Class Initialized
DEBUG - 2016-09-07 07:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:19 --> Output Class Initialized
INFO - 2016-09-07 07:06:19 --> Router Class Initialized
INFO - 2016-09-07 07:06:19 --> Input Class Initialized
INFO - 2016-09-07 07:06:19 --> Language Class Initialized
INFO - 2016-09-07 07:06:19 --> Output Class Initialized
INFO - 2016-09-07 07:06:19 --> Language Class Initialized
DEBUG - 2016-09-07 07:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:19 --> Security Class Initialized
INFO - 2016-09-07 07:06:19 --> Language Class Initialized
ERROR - 2016-09-07 07:06:19 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:19 --> Config Class Initialized
INFO - 2016-09-07 07:06:19 --> Hooks Class Initialized
ERROR - 2016-09-07 07:06:19 --> 404 Page Not Found: /index
DEBUG - 2016-09-07 07:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-07 07:06:19 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:19 --> Input Class Initialized
ERROR - 2016-09-07 07:06:19 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:19 --> Security Class Initialized
INFO - 2016-09-07 07:06:19 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:19 --> Input Class Initialized
INFO - 2016-09-07 07:06:19 --> Language Class Initialized
DEBUG - 2016-09-07 07:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:19 --> Config Class Initialized
INFO - 2016-09-07 07:06:19 --> Config Class Initialized
INFO - 2016-09-07 07:06:19 --> Hooks Class Initialized
INFO - 2016-09-07 07:06:19 --> URI Class Initialized
INFO - 2016-09-07 07:06:19 --> Hooks Class Initialized
INFO - 2016-09-07 07:06:19 --> Input Class Initialized
DEBUG - 2016-09-07 07:06:19 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:19 --> Language Class Initialized
ERROR - 2016-09-07 07:06:19 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:19 --> Utf8 Class Initialized
ERROR - 2016-09-07 07:06:19 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:19 --> Router Class Initialized
INFO - 2016-09-07 07:06:19 --> Language Class Initialized
DEBUG - 2016-09-07 07:06:19 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:19 --> Config Class Initialized
INFO - 2016-09-07 07:06:19 --> URI Class Initialized
INFO - 2016-09-07 07:06:19 --> Config Class Initialized
INFO - 2016-09-07 07:06:19 --> Hooks Class Initialized
INFO - 2016-09-07 07:06:19 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:19 --> Output Class Initialized
ERROR - 2016-09-07 07:06:19 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:19 --> Hooks Class Initialized
INFO - 2016-09-07 07:06:19 --> Router Class Initialized
INFO - 2016-09-07 07:06:19 --> URI Class Initialized
DEBUG - 2016-09-07 07:06:19 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:19 --> Security Class Initialized
DEBUG - 2016-09-07 07:06:19 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:19 --> Config Class Initialized
INFO - 2016-09-07 07:06:19 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:19 --> Output Class Initialized
INFO - 2016-09-07 07:06:19 --> Router Class Initialized
DEBUG - 2016-09-07 07:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:19 --> Output Class Initialized
INFO - 2016-09-07 07:06:19 --> Security Class Initialized
INFO - 2016-09-07 07:06:19 --> URI Class Initialized
INFO - 2016-09-07 07:06:19 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:19 --> Hooks Class Initialized
INFO - 2016-09-07 07:06:19 --> Input Class Initialized
INFO - 2016-09-07 07:06:19 --> Security Class Initialized
DEBUG - 2016-09-07 07:06:19 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 07:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:19 --> URI Class Initialized
INFO - 2016-09-07 07:06:19 --> Language Class Initialized
INFO - 2016-09-07 07:06:19 --> Router Class Initialized
INFO - 2016-09-07 07:06:19 --> Input Class Initialized
INFO - 2016-09-07 07:06:19 --> Output Class Initialized
INFO - 2016-09-07 07:06:19 --> Utf8 Class Initialized
ERROR - 2016-09-07 07:06:19 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:19 --> Router Class Initialized
DEBUG - 2016-09-07 07:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:19 --> Security Class Initialized
INFO - 2016-09-07 07:06:19 --> Output Class Initialized
INFO - 2016-09-07 07:06:19 --> Language Class Initialized
INFO - 2016-09-07 07:06:19 --> URI Class Initialized
INFO - 2016-09-07 07:06:19 --> Config Class Initialized
INFO - 2016-09-07 07:06:19 --> Input Class Initialized
INFO - 2016-09-07 07:06:19 --> Hooks Class Initialized
INFO - 2016-09-07 07:06:19 --> Security Class Initialized
INFO - 2016-09-07 07:06:19 --> Language Class Initialized
DEBUG - 2016-09-07 07:06:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-09-07 07:06:19 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:19 --> Router Class Initialized
INFO - 2016-09-07 07:06:19 --> Input Class Initialized
ERROR - 2016-09-07 07:06:19 --> 404 Page Not Found: /index
DEBUG - 2016-09-07 07:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:19 --> Output Class Initialized
DEBUG - 2016-09-07 07:06:19 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:19 --> Config Class Initialized
INFO - 2016-09-07 07:06:19 --> Language Class Initialized
INFO - 2016-09-07 07:06:19 --> Config Class Initialized
INFO - 2016-09-07 07:06:19 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:19 --> Input Class Initialized
INFO - 2016-09-07 07:06:19 --> Security Class Initialized
INFO - 2016-09-07 07:06:19 --> Hooks Class Initialized
INFO - 2016-09-07 07:06:19 --> Hooks Class Initialized
ERROR - 2016-09-07 07:06:19 --> 404 Page Not Found: /index
DEBUG - 2016-09-07 07:06:19 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:20 --> Config Class Initialized
INFO - 2016-09-07 07:06:20 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:20 --> Hooks Class Initialized
INFO - 2016-09-07 07:06:20 --> Language Class Initialized
INFO - 2016-09-07 07:06:20 --> URI Class Initialized
DEBUG - 2016-09-07 07:06:20 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 07:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:20 --> URI Class Initialized
ERROR - 2016-09-07 07:06:20 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:20 --> Input Class Initialized
DEBUG - 2016-09-07 07:06:20 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:20 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:20 --> Router Class Initialized
INFO - 2016-09-07 07:06:20 --> Router Class Initialized
INFO - 2016-09-07 07:06:20 --> Output Class Initialized
INFO - 2016-09-07 07:06:20 --> Output Class Initialized
INFO - 2016-09-07 07:06:20 --> Language Class Initialized
INFO - 2016-09-07 07:06:20 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:20 --> Config Class Initialized
INFO - 2016-09-07 07:06:20 --> URI Class Initialized
ERROR - 2016-09-07 07:06:20 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:20 --> Security Class Initialized
INFO - 2016-09-07 07:06:20 --> Hooks Class Initialized
INFO - 2016-09-07 07:06:20 --> Security Class Initialized
INFO - 2016-09-07 07:06:20 --> URI Class Initialized
INFO - 2016-09-07 07:06:20 --> Router Class Initialized
DEBUG - 2016-09-07 07:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-07 07:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:20 --> Router Class Initialized
DEBUG - 2016-09-07 07:06:20 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:20 --> Config Class Initialized
INFO - 2016-09-07 07:06:20 --> Output Class Initialized
INFO - 2016-09-07 07:06:20 --> Hooks Class Initialized
INFO - 2016-09-07 07:06:20 --> Input Class Initialized
INFO - 2016-09-07 07:06:20 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:20 --> Input Class Initialized
INFO - 2016-09-07 07:06:20 --> Security Class Initialized
INFO - 2016-09-07 07:06:20 --> Output Class Initialized
INFO - 2016-09-07 07:06:20 --> Language Class Initialized
INFO - 2016-09-07 07:06:20 --> Security Class Initialized
INFO - 2016-09-07 07:06:20 --> URI Class Initialized
INFO - 2016-09-07 07:06:20 --> Language Class Initialized
DEBUG - 2016-09-07 07:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-07 07:06:20 --> UTF-8 Support Enabled
ERROR - 2016-09-07 07:06:20 --> 404 Page Not Found: /index
DEBUG - 2016-09-07 07:06:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-09-07 07:06:20 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:20 --> Router Class Initialized
INFO - 2016-09-07 07:06:20 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:20 --> Input Class Initialized
INFO - 2016-09-07 07:06:20 --> URI Class Initialized
INFO - 2016-09-07 07:06:20 --> Input Class Initialized
INFO - 2016-09-07 07:06:20 --> Config Class Initialized
INFO - 2016-09-07 07:06:20 --> Config Class Initialized
INFO - 2016-09-07 07:06:20 --> Language Class Initialized
INFO - 2016-09-07 07:06:20 --> Output Class Initialized
ERROR - 2016-09-07 07:06:20 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:20 --> Security Class Initialized
INFO - 2016-09-07 07:06:20 --> Router Class Initialized
INFO - 2016-09-07 07:06:20 --> Hooks Class Initialized
INFO - 2016-09-07 07:06:20 --> Hooks Class Initialized
INFO - 2016-09-07 07:06:20 --> Language Class Initialized
DEBUG - 2016-09-07 07:06:20 --> UTF-8 Support Enabled
ERROR - 2016-09-07 07:06:20 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:20 --> Config Class Initialized
INFO - 2016-09-07 07:06:20 --> Utf8 Class Initialized
DEBUG - 2016-09-07 07:06:20 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:20 --> URI Class Initialized
DEBUG - 2016-09-07 07:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:20 --> Hooks Class Initialized
INFO - 2016-09-07 07:06:20 --> Output Class Initialized
INFO - 2016-09-07 07:06:20 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:20 --> Config Class Initialized
INFO - 2016-09-07 07:06:20 --> Security Class Initialized
INFO - 2016-09-07 07:06:20 --> Router Class Initialized
INFO - 2016-09-07 07:06:20 --> Input Class Initialized
DEBUG - 2016-09-07 07:06:20 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:20 --> URI Class Initialized
INFO - 2016-09-07 07:06:20 --> Output Class Initialized
INFO - 2016-09-07 07:06:20 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:20 --> Language Class Initialized
INFO - 2016-09-07 07:06:20 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-07 07:06:20 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:20 --> Input Class Initialized
ERROR - 2016-09-07 07:06:20 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:20 --> Router Class Initialized
INFO - 2016-09-07 07:06:20 --> Security Class Initialized
INFO - 2016-09-07 07:06:20 --> URI Class Initialized
INFO - 2016-09-07 07:06:20 --> Language Class Initialized
INFO - 2016-09-07 07:06:20 --> Output Class Initialized
INFO - 2016-09-07 07:06:20 --> Config Class Initialized
INFO - 2016-09-07 07:06:20 --> Utf8 Class Initialized
DEBUG - 2016-09-07 07:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:20 --> Router Class Initialized
INFO - 2016-09-07 07:06:20 --> Output Class Initialized
ERROR - 2016-09-07 07:06:20 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:20 --> URI Class Initialized
INFO - 2016-09-07 07:06:20 --> Input Class Initialized
INFO - 2016-09-07 07:06:20 --> Security Class Initialized
INFO - 2016-09-07 07:06:20 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:20 --> Security Class Initialized
INFO - 2016-09-07 07:06:20 --> Router Class Initialized
DEBUG - 2016-09-07 07:06:20 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:20 --> Language Class Initialized
INFO - 2016-09-07 07:06:20 --> Config Class Initialized
INFO - 2016-09-07 07:06:20 --> Input Class Initialized
INFO - 2016-09-07 07:06:20 --> Language Class Initialized
ERROR - 2016-09-07 07:06:20 --> 404 Page Not Found: /index
DEBUG - 2016-09-07 07:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:21 --> Input Class Initialized
INFO - 2016-09-07 07:06:21 --> Config Class Initialized
INFO - 2016-09-07 07:06:21 --> Language Class Initialized
ERROR - 2016-09-07 07:06:21 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:21 --> Output Class Initialized
ERROR - 2016-09-07 07:06:21 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:21 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:21 --> Hooks Class Initialized
INFO - 2016-09-07 07:06:21 --> Hooks Class Initialized
INFO - 2016-09-07 07:06:21 --> Security Class Initialized
INFO - 2016-09-07 07:06:21 --> URI Class Initialized
INFO - 2016-09-07 07:06:21 --> Config Class Initialized
DEBUG - 2016-09-07 07:06:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 07:06:21 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:21 --> Config Class Initialized
INFO - 2016-09-07 07:06:21 --> Utf8 Class Initialized
DEBUG - 2016-09-07 07:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:21 --> Hooks Class Initialized
INFO - 2016-09-07 07:06:21 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:21 --> Hooks Class Initialized
INFO - 2016-09-07 07:06:21 --> Input Class Initialized
INFO - 2016-09-07 07:06:21 --> URI Class Initialized
INFO - 2016-09-07 07:06:21 --> Router Class Initialized
DEBUG - 2016-09-07 07:06:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 07:06:21 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:21 --> URI Class Initialized
INFO - 2016-09-07 07:06:21 --> Output Class Initialized
INFO - 2016-09-07 07:06:21 --> Router Class Initialized
INFO - 2016-09-07 07:06:21 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:21 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:21 --> Security Class Initialized
INFO - 2016-09-07 07:06:21 --> Language Class Initialized
INFO - 2016-09-07 07:06:21 --> Router Class Initialized
ERROR - 2016-09-07 07:06:21 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:21 --> URI Class Initialized
DEBUG - 2016-09-07 07:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:21 --> Output Class Initialized
INFO - 2016-09-07 07:06:21 --> URI Class Initialized
INFO - 2016-09-07 07:06:21 --> Output Class Initialized
INFO - 2016-09-07 07:06:21 --> Router Class Initialized
INFO - 2016-09-07 07:06:21 --> Security Class Initialized
INFO - 2016-09-07 07:06:21 --> Config Class Initialized
INFO - 2016-09-07 07:06:21 --> Security Class Initialized
INFO - 2016-09-07 07:06:21 --> Input Class Initialized
INFO - 2016-09-07 07:06:21 --> Router Class Initialized
INFO - 2016-09-07 07:06:21 --> Output Class Initialized
DEBUG - 2016-09-07 07:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:21 --> Language Class Initialized
INFO - 2016-09-07 07:06:21 --> Hooks Class Initialized
INFO - 2016-09-07 07:06:21 --> Output Class Initialized
DEBUG - 2016-09-07 07:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:21 --> Input Class Initialized
INFO - 2016-09-07 07:06:21 --> Input Class Initialized
INFO - 2016-09-07 07:06:21 --> Security Class Initialized
INFO - 2016-09-07 07:06:21 --> Security Class Initialized
DEBUG - 2016-09-07 07:06:21 --> UTF-8 Support Enabled
ERROR - 2016-09-07 07:06:21 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:21 --> Language Class Initialized
INFO - 2016-09-07 07:06:21 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:21 --> Language Class Initialized
DEBUG - 2016-09-07 07:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-07 07:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:21 --> URI Class Initialized
ERROR - 2016-09-07 07:06:21 --> 404 Page Not Found: /index
ERROR - 2016-09-07 07:06:21 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:21 --> Input Class Initialized
INFO - 2016-09-07 07:06:21 --> Input Class Initialized
INFO - 2016-09-07 07:06:21 --> Config Class Initialized
INFO - 2016-09-07 07:06:21 --> Config Class Initialized
INFO - 2016-09-07 07:06:21 --> Router Class Initialized
INFO - 2016-09-07 07:06:21 --> Language Class Initialized
INFO - 2016-09-07 07:06:21 --> Language Class Initialized
INFO - 2016-09-07 07:06:21 --> Hooks Class Initialized
INFO - 2016-09-07 07:06:21 --> Config Class Initialized
INFO - 2016-09-07 07:06:21 --> Hooks Class Initialized
ERROR - 2016-09-07 07:06:21 --> 404 Page Not Found: /index
DEBUG - 2016-09-07 07:06:21 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:21 --> Output Class Initialized
DEBUG - 2016-09-07 07:06:21 --> UTF-8 Support Enabled
ERROR - 2016-09-07 07:06:21 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:21 --> Hooks Class Initialized
INFO - 2016-09-07 07:06:21 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:21 --> Config Class Initialized
INFO - 2016-09-07 07:06:21 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:21 --> Security Class Initialized
INFO - 2016-09-07 07:06:21 --> Config Class Initialized
DEBUG - 2016-09-07 07:06:21 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:21 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:21 --> URI Class Initialized
INFO - 2016-09-07 07:06:21 --> URI Class Initialized
INFO - 2016-09-07 07:06:21 --> Hooks Class Initialized
INFO - 2016-09-07 07:06:21 --> URI Class Initialized
DEBUG - 2016-09-07 07:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:21 --> Hooks Class Initialized
INFO - 2016-09-07 07:06:21 --> Input Class Initialized
INFO - 2016-09-07 07:06:21 --> Router Class Initialized
INFO - 2016-09-07 07:06:21 --> Router Class Initialized
DEBUG - 2016-09-07 07:06:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 07:06:21 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:21 --> Router Class Initialized
INFO - 2016-09-07 07:06:21 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:21 --> Output Class Initialized
INFO - 2016-09-07 07:06:21 --> Language Class Initialized
INFO - 2016-09-07 07:06:21 --> Output Class Initialized
INFO - 2016-09-07 07:06:21 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:21 --> Output Class Initialized
INFO - 2016-09-07 07:06:21 --> Security Class Initialized
INFO - 2016-09-07 07:06:21 --> URI Class Initialized
INFO - 2016-09-07 07:06:21 --> Security Class Initialized
ERROR - 2016-09-07 07:06:21 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:21 --> Security Class Initialized
INFO - 2016-09-07 07:06:21 --> URI Class Initialized
DEBUG - 2016-09-07 07:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-07 07:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:21 --> Router Class Initialized
DEBUG - 2016-09-07 07:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:21 --> Router Class Initialized
INFO - 2016-09-07 07:06:21 --> Config Class Initialized
INFO - 2016-09-07 07:06:21 --> Input Class Initialized
INFO - 2016-09-07 07:06:21 --> Hooks Class Initialized
INFO - 2016-09-07 07:06:21 --> Language Class Initialized
INFO - 2016-09-07 07:06:21 --> Output Class Initialized
INFO - 2016-09-07 07:06:21 --> Input Class Initialized
INFO - 2016-09-07 07:06:21 --> Input Class Initialized
INFO - 2016-09-07 07:06:21 --> Output Class Initialized
ERROR - 2016-09-07 07:06:21 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:21 --> Security Class Initialized
INFO - 2016-09-07 07:06:21 --> Language Class Initialized
INFO - 2016-09-07 07:06:21 --> Language Class Initialized
INFO - 2016-09-07 07:06:21 --> Security Class Initialized
DEBUG - 2016-09-07 07:06:22 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:22 --> Utf8 Class Initialized
DEBUG - 2016-09-07 07:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-07 07:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:22 --> Config Class Initialized
ERROR - 2016-09-07 07:06:22 --> 404 Page Not Found: /index
ERROR - 2016-09-07 07:06:22 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:22 --> Input Class Initialized
INFO - 2016-09-07 07:06:22 --> Hooks Class Initialized
INFO - 2016-09-07 07:06:22 --> Input Class Initialized
INFO - 2016-09-07 07:06:22 --> URI Class Initialized
INFO - 2016-09-07 07:06:22 --> Config Class Initialized
INFO - 2016-09-07 07:06:22 --> Language Class Initialized
INFO - 2016-09-07 07:06:22 --> Config Class Initialized
INFO - 2016-09-07 07:06:22 --> Hooks Class Initialized
INFO - 2016-09-07 07:06:22 --> Router Class Initialized
INFO - 2016-09-07 07:06:22 --> Language Class Initialized
DEBUG - 2016-09-07 07:06:22 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:22 --> Utf8 Class Initialized
ERROR - 2016-09-07 07:06:22 --> 404 Page Not Found: /index
ERROR - 2016-09-07 07:06:22 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:22 --> URI Class Initialized
INFO - 2016-09-07 07:06:22 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:06:22 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:22 --> Output Class Initialized
INFO - 2016-09-07 07:06:22 --> Config Class Initialized
INFO - 2016-09-07 07:06:22 --> Hooks Class Initialized
INFO - 2016-09-07 07:06:22 --> Config Class Initialized
INFO - 2016-09-07 07:06:22 --> Router Class Initialized
DEBUG - 2016-09-07 07:06:22 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:22 --> Utf8 Class Initialized
DEBUG - 2016-09-07 07:06:22 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:22 --> Hooks Class Initialized
INFO - 2016-09-07 07:06:22 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:22 --> Security Class Initialized
INFO - 2016-09-07 07:06:22 --> URI Class Initialized
INFO - 2016-09-07 07:06:22 --> Output Class Initialized
DEBUG - 2016-09-07 07:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:22 --> URI Class Initialized
INFO - 2016-09-07 07:06:22 --> Utf8 Class Initialized
DEBUG - 2016-09-07 07:06:22 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:22 --> Input Class Initialized
INFO - 2016-09-07 07:06:22 --> Security Class Initialized
INFO - 2016-09-07 07:06:22 --> Router Class Initialized
INFO - 2016-09-07 07:06:22 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:22 --> URI Class Initialized
INFO - 2016-09-07 07:06:22 --> Router Class Initialized
INFO - 2016-09-07 07:06:22 --> URI Class Initialized
DEBUG - 2016-09-07 07:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:22 --> Language Class Initialized
INFO - 2016-09-07 07:06:22 --> Router Class Initialized
INFO - 2016-09-07 07:06:22 --> Output Class Initialized
INFO - 2016-09-07 07:06:22 --> Output Class Initialized
INFO - 2016-09-07 07:06:22 --> Input Class Initialized
INFO - 2016-09-07 07:06:22 --> Security Class Initialized
ERROR - 2016-09-07 07:06:22 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:22 --> Output Class Initialized
INFO - 2016-09-07 07:06:22 --> Security Class Initialized
INFO - 2016-09-07 07:06:22 --> Router Class Initialized
DEBUG - 2016-09-07 07:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:22 --> Output Class Initialized
DEBUG - 2016-09-07 07:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:22 --> Language Class Initialized
INFO - 2016-09-07 07:06:22 --> Security Class Initialized
INFO - 2016-09-07 07:06:22 --> Input Class Initialized
ERROR - 2016-09-07 07:06:22 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:22 --> Language Class Initialized
INFO - 2016-09-07 07:06:22 --> Security Class Initialized
INFO - 2016-09-07 07:06:22 --> Input Class Initialized
DEBUG - 2016-09-07 07:06:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-09-07 07:06:22 --> 404 Page Not Found: /index
DEBUG - 2016-09-07 07:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:22 --> Language Class Initialized
INFO - 2016-09-07 07:06:22 --> Input Class Initialized
INFO - 2016-09-07 07:06:22 --> Input Class Initialized
INFO - 2016-09-07 07:06:22 --> Language Class Initialized
ERROR - 2016-09-07 07:06:22 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:22 --> Language Class Initialized
ERROR - 2016-09-07 07:06:22 --> 404 Page Not Found: /index
ERROR - 2016-09-07 07:06:22 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:22 --> Config Class Initialized
INFO - 2016-09-07 07:06:22 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:06:22 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:22 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:22 --> URI Class Initialized
INFO - 2016-09-07 07:06:23 --> Router Class Initialized
INFO - 2016-09-07 07:06:23 --> Output Class Initialized
INFO - 2016-09-07 07:06:23 --> Security Class Initialized
DEBUG - 2016-09-07 07:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:23 --> Input Class Initialized
INFO - 2016-09-07 07:06:23 --> Language Class Initialized
ERROR - 2016-09-07 07:06:23 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:23 --> Config Class Initialized
INFO - 2016-09-07 07:06:23 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:06:23 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:23 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:23 --> URI Class Initialized
INFO - 2016-09-07 07:06:23 --> Router Class Initialized
INFO - 2016-09-07 07:06:23 --> Output Class Initialized
INFO - 2016-09-07 07:06:23 --> Security Class Initialized
DEBUG - 2016-09-07 07:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:23 --> Input Class Initialized
INFO - 2016-09-07 07:06:23 --> Language Class Initialized
ERROR - 2016-09-07 07:06:23 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:23 --> Config Class Initialized
INFO - 2016-09-07 07:06:23 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:06:23 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:23 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:23 --> URI Class Initialized
INFO - 2016-09-07 07:06:23 --> Router Class Initialized
INFO - 2016-09-07 07:06:23 --> Output Class Initialized
INFO - 2016-09-07 07:06:23 --> Security Class Initialized
DEBUG - 2016-09-07 07:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:23 --> Input Class Initialized
INFO - 2016-09-07 07:06:23 --> Language Class Initialized
ERROR - 2016-09-07 07:06:23 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:24 --> Config Class Initialized
INFO - 2016-09-07 07:06:24 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:06:24 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:24 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:24 --> URI Class Initialized
INFO - 2016-09-07 07:06:24 --> Router Class Initialized
INFO - 2016-09-07 07:06:24 --> Output Class Initialized
INFO - 2016-09-07 07:06:24 --> Security Class Initialized
DEBUG - 2016-09-07 07:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:24 --> Input Class Initialized
INFO - 2016-09-07 07:06:24 --> Language Class Initialized
ERROR - 2016-09-07 07:06:24 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:24 --> Config Class Initialized
INFO - 2016-09-07 07:06:24 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:06:24 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:24 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:24 --> URI Class Initialized
INFO - 2016-09-07 07:06:24 --> Router Class Initialized
INFO - 2016-09-07 07:06:24 --> Output Class Initialized
INFO - 2016-09-07 07:06:24 --> Security Class Initialized
DEBUG - 2016-09-07 07:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:24 --> Input Class Initialized
INFO - 2016-09-07 07:06:24 --> Language Class Initialized
ERROR - 2016-09-07 07:06:24 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:25 --> Config Class Initialized
INFO - 2016-09-07 07:06:25 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:06:25 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:25 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:25 --> URI Class Initialized
INFO - 2016-09-07 07:06:25 --> Router Class Initialized
INFO - 2016-09-07 07:06:25 --> Output Class Initialized
INFO - 2016-09-07 07:06:25 --> Security Class Initialized
DEBUG - 2016-09-07 07:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:25 --> Input Class Initialized
INFO - 2016-09-07 07:06:25 --> Language Class Initialized
ERROR - 2016-09-07 07:06:25 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:25 --> Config Class Initialized
INFO - 2016-09-07 07:06:25 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:06:25 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:25 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:25 --> URI Class Initialized
INFO - 2016-09-07 07:06:25 --> Router Class Initialized
INFO - 2016-09-07 07:06:25 --> Output Class Initialized
INFO - 2016-09-07 07:06:26 --> Security Class Initialized
DEBUG - 2016-09-07 07:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:26 --> Input Class Initialized
INFO - 2016-09-07 07:06:26 --> Language Class Initialized
ERROR - 2016-09-07 07:06:26 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:26 --> Config Class Initialized
INFO - 2016-09-07 07:06:26 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:06:26 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:26 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:26 --> URI Class Initialized
INFO - 2016-09-07 07:06:26 --> Router Class Initialized
INFO - 2016-09-07 07:06:26 --> Output Class Initialized
INFO - 2016-09-07 07:06:26 --> Security Class Initialized
DEBUG - 2016-09-07 07:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:26 --> Input Class Initialized
INFO - 2016-09-07 07:06:26 --> Language Class Initialized
ERROR - 2016-09-07 07:06:26 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:26 --> Config Class Initialized
INFO - 2016-09-07 07:06:26 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:06:26 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:26 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:26 --> URI Class Initialized
INFO - 2016-09-07 07:06:26 --> Router Class Initialized
INFO - 2016-09-07 07:06:26 --> Output Class Initialized
INFO - 2016-09-07 07:06:26 --> Security Class Initialized
DEBUG - 2016-09-07 07:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:26 --> Input Class Initialized
INFO - 2016-09-07 07:06:26 --> Language Class Initialized
ERROR - 2016-09-07 07:06:26 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:26 --> Config Class Initialized
INFO - 2016-09-07 07:06:26 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:06:26 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:27 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:27 --> URI Class Initialized
INFO - 2016-09-07 07:06:27 --> Router Class Initialized
INFO - 2016-09-07 07:06:27 --> Output Class Initialized
INFO - 2016-09-07 07:06:27 --> Security Class Initialized
DEBUG - 2016-09-07 07:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:27 --> Input Class Initialized
INFO - 2016-09-07 07:06:27 --> Language Class Initialized
ERROR - 2016-09-07 07:06:27 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:27 --> Config Class Initialized
INFO - 2016-09-07 07:06:27 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:06:27 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:27 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:27 --> URI Class Initialized
INFO - 2016-09-07 07:06:27 --> Router Class Initialized
INFO - 2016-09-07 07:06:27 --> Output Class Initialized
INFO - 2016-09-07 07:06:27 --> Security Class Initialized
DEBUG - 2016-09-07 07:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:27 --> Input Class Initialized
INFO - 2016-09-07 07:06:27 --> Language Class Initialized
ERROR - 2016-09-07 07:06:27 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:27 --> Config Class Initialized
INFO - 2016-09-07 07:06:27 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:06:27 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:27 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:27 --> URI Class Initialized
INFO - 2016-09-07 07:06:27 --> Router Class Initialized
INFO - 2016-09-07 07:06:27 --> Output Class Initialized
INFO - 2016-09-07 07:06:27 --> Security Class Initialized
DEBUG - 2016-09-07 07:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:27 --> Input Class Initialized
INFO - 2016-09-07 07:06:27 --> Language Class Initialized
ERROR - 2016-09-07 07:06:27 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:28 --> Config Class Initialized
INFO - 2016-09-07 07:06:28 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:06:28 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:28 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:28 --> URI Class Initialized
INFO - 2016-09-07 07:06:28 --> Router Class Initialized
INFO - 2016-09-07 07:06:28 --> Output Class Initialized
INFO - 2016-09-07 07:06:28 --> Security Class Initialized
DEBUG - 2016-09-07 07:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:28 --> Input Class Initialized
INFO - 2016-09-07 07:06:28 --> Language Class Initialized
ERROR - 2016-09-07 07:06:28 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:28 --> Config Class Initialized
INFO - 2016-09-07 07:06:28 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:06:28 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:28 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:28 --> URI Class Initialized
INFO - 2016-09-07 07:06:28 --> Router Class Initialized
INFO - 2016-09-07 07:06:28 --> Output Class Initialized
INFO - 2016-09-07 07:06:28 --> Security Class Initialized
DEBUG - 2016-09-07 07:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:28 --> Input Class Initialized
INFO - 2016-09-07 07:06:28 --> Language Class Initialized
ERROR - 2016-09-07 07:06:28 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:28 --> Config Class Initialized
INFO - 2016-09-07 07:06:28 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:06:28 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:29 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:29 --> URI Class Initialized
INFO - 2016-09-07 07:06:29 --> Router Class Initialized
INFO - 2016-09-07 07:06:29 --> Output Class Initialized
INFO - 2016-09-07 07:06:29 --> Security Class Initialized
DEBUG - 2016-09-07 07:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:29 --> Input Class Initialized
INFO - 2016-09-07 07:06:29 --> Language Class Initialized
ERROR - 2016-09-07 07:06:29 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:29 --> Config Class Initialized
INFO - 2016-09-07 07:06:29 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:06:29 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:29 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:29 --> URI Class Initialized
INFO - 2016-09-07 07:06:29 --> Router Class Initialized
INFO - 2016-09-07 07:06:29 --> Output Class Initialized
INFO - 2016-09-07 07:06:29 --> Security Class Initialized
DEBUG - 2016-09-07 07:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:29 --> Input Class Initialized
INFO - 2016-09-07 07:06:29 --> Language Class Initialized
ERROR - 2016-09-07 07:06:29 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:29 --> Config Class Initialized
INFO - 2016-09-07 07:06:29 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:06:29 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:29 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:29 --> URI Class Initialized
INFO - 2016-09-07 07:06:29 --> Router Class Initialized
INFO - 2016-09-07 07:06:29 --> Output Class Initialized
INFO - 2016-09-07 07:06:29 --> Security Class Initialized
DEBUG - 2016-09-07 07:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:29 --> Input Class Initialized
INFO - 2016-09-07 07:06:29 --> Language Class Initialized
ERROR - 2016-09-07 07:06:29 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:30 --> Config Class Initialized
INFO - 2016-09-07 07:06:30 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:06:30 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:30 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:30 --> URI Class Initialized
INFO - 2016-09-07 07:06:30 --> Router Class Initialized
INFO - 2016-09-07 07:06:30 --> Output Class Initialized
INFO - 2016-09-07 07:06:30 --> Security Class Initialized
DEBUG - 2016-09-07 07:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:30 --> Input Class Initialized
INFO - 2016-09-07 07:06:30 --> Language Class Initialized
ERROR - 2016-09-07 07:06:30 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:30 --> Config Class Initialized
INFO - 2016-09-07 07:06:30 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:06:30 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:30 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:30 --> URI Class Initialized
INFO - 2016-09-07 07:06:30 --> Router Class Initialized
INFO - 2016-09-07 07:06:30 --> Output Class Initialized
INFO - 2016-09-07 07:06:30 --> Security Class Initialized
DEBUG - 2016-09-07 07:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:30 --> Input Class Initialized
INFO - 2016-09-07 07:06:30 --> Language Class Initialized
ERROR - 2016-09-07 07:06:30 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:30 --> Config Class Initialized
INFO - 2016-09-07 07:06:30 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:06:30 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:30 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:30 --> URI Class Initialized
INFO - 2016-09-07 07:06:30 --> Router Class Initialized
INFO - 2016-09-07 07:06:30 --> Output Class Initialized
INFO - 2016-09-07 07:06:30 --> Security Class Initialized
DEBUG - 2016-09-07 07:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:31 --> Input Class Initialized
INFO - 2016-09-07 07:06:31 --> Language Class Initialized
ERROR - 2016-09-07 07:06:31 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:31 --> Config Class Initialized
INFO - 2016-09-07 07:06:31 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:06:31 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:31 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:31 --> URI Class Initialized
INFO - 2016-09-07 07:06:31 --> Router Class Initialized
INFO - 2016-09-07 07:06:31 --> Output Class Initialized
INFO - 2016-09-07 07:06:31 --> Security Class Initialized
DEBUG - 2016-09-07 07:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:31 --> Input Class Initialized
INFO - 2016-09-07 07:06:31 --> Language Class Initialized
ERROR - 2016-09-07 07:06:31 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:31 --> Config Class Initialized
INFO - 2016-09-07 07:06:31 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:06:31 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:31 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:31 --> URI Class Initialized
INFO - 2016-09-07 07:06:31 --> Router Class Initialized
INFO - 2016-09-07 07:06:31 --> Output Class Initialized
INFO - 2016-09-07 07:06:31 --> Security Class Initialized
DEBUG - 2016-09-07 07:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:31 --> Input Class Initialized
INFO - 2016-09-07 07:06:31 --> Language Class Initialized
ERROR - 2016-09-07 07:06:31 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:32 --> Config Class Initialized
INFO - 2016-09-07 07:06:32 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:06:32 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:32 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:32 --> URI Class Initialized
INFO - 2016-09-07 07:06:32 --> Router Class Initialized
INFO - 2016-09-07 07:06:32 --> Output Class Initialized
INFO - 2016-09-07 07:06:32 --> Security Class Initialized
DEBUG - 2016-09-07 07:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:32 --> Input Class Initialized
INFO - 2016-09-07 07:06:32 --> Language Class Initialized
ERROR - 2016-09-07 07:06:32 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:32 --> Config Class Initialized
INFO - 2016-09-07 07:06:32 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:06:32 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:32 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:32 --> URI Class Initialized
INFO - 2016-09-07 07:06:32 --> Router Class Initialized
INFO - 2016-09-07 07:06:32 --> Output Class Initialized
INFO - 2016-09-07 07:06:32 --> Security Class Initialized
DEBUG - 2016-09-07 07:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:32 --> Input Class Initialized
INFO - 2016-09-07 07:06:32 --> Language Class Initialized
ERROR - 2016-09-07 07:06:32 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:32 --> Config Class Initialized
INFO - 2016-09-07 07:06:32 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:06:32 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:32 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:32 --> URI Class Initialized
INFO - 2016-09-07 07:06:33 --> Router Class Initialized
INFO - 2016-09-07 07:06:33 --> Output Class Initialized
INFO - 2016-09-07 07:06:33 --> Security Class Initialized
DEBUG - 2016-09-07 07:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:33 --> Input Class Initialized
INFO - 2016-09-07 07:06:33 --> Language Class Initialized
ERROR - 2016-09-07 07:06:33 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:33 --> Config Class Initialized
INFO - 2016-09-07 07:06:33 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:06:33 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:33 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:33 --> URI Class Initialized
INFO - 2016-09-07 07:06:33 --> Router Class Initialized
INFO - 2016-09-07 07:06:33 --> Output Class Initialized
INFO - 2016-09-07 07:06:33 --> Security Class Initialized
DEBUG - 2016-09-07 07:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:33 --> Input Class Initialized
INFO - 2016-09-07 07:06:33 --> Language Class Initialized
ERROR - 2016-09-07 07:06:33 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:33 --> Config Class Initialized
INFO - 2016-09-07 07:06:33 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:06:33 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:33 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:33 --> URI Class Initialized
INFO - 2016-09-07 07:06:33 --> Router Class Initialized
INFO - 2016-09-07 07:06:33 --> Output Class Initialized
INFO - 2016-09-07 07:06:34 --> Security Class Initialized
DEBUG - 2016-09-07 07:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:34 --> Input Class Initialized
INFO - 2016-09-07 07:06:34 --> Language Class Initialized
ERROR - 2016-09-07 07:06:34 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:34 --> Config Class Initialized
INFO - 2016-09-07 07:06:34 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:06:34 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:34 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:34 --> URI Class Initialized
INFO - 2016-09-07 07:06:34 --> Router Class Initialized
INFO - 2016-09-07 07:06:34 --> Output Class Initialized
INFO - 2016-09-07 07:06:34 --> Security Class Initialized
DEBUG - 2016-09-07 07:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:34 --> Input Class Initialized
INFO - 2016-09-07 07:06:34 --> Language Class Initialized
ERROR - 2016-09-07 07:06:34 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:34 --> Config Class Initialized
INFO - 2016-09-07 07:06:34 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:06:34 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:34 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:34 --> URI Class Initialized
INFO - 2016-09-07 07:06:34 --> Router Class Initialized
INFO - 2016-09-07 07:06:34 --> Output Class Initialized
INFO - 2016-09-07 07:06:34 --> Security Class Initialized
DEBUG - 2016-09-07 07:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:34 --> Input Class Initialized
INFO - 2016-09-07 07:06:35 --> Language Class Initialized
ERROR - 2016-09-07 07:06:35 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:35 --> Config Class Initialized
INFO - 2016-09-07 07:06:35 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:06:35 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:35 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:35 --> URI Class Initialized
INFO - 2016-09-07 07:06:35 --> Router Class Initialized
INFO - 2016-09-07 07:06:35 --> Output Class Initialized
INFO - 2016-09-07 07:06:35 --> Security Class Initialized
DEBUG - 2016-09-07 07:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:35 --> Input Class Initialized
INFO - 2016-09-07 07:06:35 --> Language Class Initialized
ERROR - 2016-09-07 07:06:35 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:35 --> Config Class Initialized
INFO - 2016-09-07 07:06:35 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:06:35 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:35 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:35 --> URI Class Initialized
INFO - 2016-09-07 07:06:35 --> Router Class Initialized
INFO - 2016-09-07 07:06:35 --> Output Class Initialized
INFO - 2016-09-07 07:06:35 --> Security Class Initialized
DEBUG - 2016-09-07 07:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:35 --> Input Class Initialized
INFO - 2016-09-07 07:06:35 --> Language Class Initialized
ERROR - 2016-09-07 07:06:35 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:35 --> Config Class Initialized
INFO - 2016-09-07 07:06:36 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:06:36 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:36 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:36 --> URI Class Initialized
INFO - 2016-09-07 07:06:36 --> Router Class Initialized
INFO - 2016-09-07 07:06:36 --> Output Class Initialized
INFO - 2016-09-07 07:06:36 --> Security Class Initialized
DEBUG - 2016-09-07 07:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:36 --> Input Class Initialized
INFO - 2016-09-07 07:06:36 --> Language Class Initialized
ERROR - 2016-09-07 07:06:36 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:36 --> Config Class Initialized
INFO - 2016-09-07 07:06:36 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:06:36 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:36 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:36 --> URI Class Initialized
INFO - 2016-09-07 07:06:36 --> Router Class Initialized
INFO - 2016-09-07 07:06:36 --> Output Class Initialized
INFO - 2016-09-07 07:06:36 --> Security Class Initialized
DEBUG - 2016-09-07 07:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:36 --> Input Class Initialized
INFO - 2016-09-07 07:06:36 --> Language Class Initialized
ERROR - 2016-09-07 07:06:36 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:36 --> Config Class Initialized
INFO - 2016-09-07 07:06:36 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:06:36 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:36 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:36 --> URI Class Initialized
INFO - 2016-09-07 07:06:36 --> Router Class Initialized
INFO - 2016-09-07 07:06:36 --> Output Class Initialized
INFO - 2016-09-07 07:06:36 --> Security Class Initialized
DEBUG - 2016-09-07 07:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:37 --> Input Class Initialized
INFO - 2016-09-07 07:06:37 --> Language Class Initialized
ERROR - 2016-09-07 07:06:37 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:06:37 --> Config Class Initialized
INFO - 2016-09-07 07:06:37 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:06:37 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:06:37 --> Utf8 Class Initialized
INFO - 2016-09-07 07:06:37 --> URI Class Initialized
INFO - 2016-09-07 07:06:37 --> Router Class Initialized
INFO - 2016-09-07 07:06:37 --> Output Class Initialized
INFO - 2016-09-07 07:06:37 --> Security Class Initialized
DEBUG - 2016-09-07 07:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:06:37 --> Input Class Initialized
INFO - 2016-09-07 07:06:37 --> Language Class Initialized
ERROR - 2016-09-07 07:06:37 --> 404 Page Not Found: /index
INFO - 2016-09-07 07:09:20 --> Config Class Initialized
INFO - 2016-09-07 07:09:20 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:09:20 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:09:20 --> Utf8 Class Initialized
INFO - 2016-09-07 07:09:20 --> URI Class Initialized
INFO - 2016-09-07 07:09:20 --> Router Class Initialized
INFO - 2016-09-07 07:09:20 --> Output Class Initialized
INFO - 2016-09-07 07:09:20 --> Security Class Initialized
DEBUG - 2016-09-07 07:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:09:20 --> Input Class Initialized
INFO - 2016-09-07 07:09:20 --> Language Class Initialized
INFO - 2016-09-07 07:09:20 --> Language Class Initialized
INFO - 2016-09-07 07:09:20 --> Config Class Initialized
INFO - 2016-09-07 07:09:20 --> Loader Class Initialized
INFO - 2016-09-07 07:09:20 --> Helper loaded: url_helper
INFO - 2016-09-07 07:09:20 --> Database Driver Class Initialized
INFO - 2016-09-07 07:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-07 07:09:20 --> Model Class Initialized
INFO - 2016-09-07 07:09:20 --> Model Class Initialized
INFO - 2016-09-07 07:09:20 --> Controller Class Initialized
DEBUG - 2016-09-07 07:09:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 07:09:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 07:09:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 07:09:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/dashboard.php
DEBUG - 2016-09-07 07:09:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 07:09:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 07:09:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 07:09:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 07:09:20 --> Final output sent to browser
DEBUG - 2016-09-07 07:09:20 --> Total execution time: 0.7318
INFO - 2016-09-07 07:09:50 --> Config Class Initialized
INFO - 2016-09-07 07:09:50 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:09:50 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:09:50 --> Utf8 Class Initialized
INFO - 2016-09-07 07:09:50 --> URI Class Initialized
INFO - 2016-09-07 07:09:50 --> Router Class Initialized
INFO - 2016-09-07 07:09:51 --> Output Class Initialized
INFO - 2016-09-07 07:09:51 --> Security Class Initialized
DEBUG - 2016-09-07 07:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:09:51 --> Input Class Initialized
INFO - 2016-09-07 07:09:51 --> Language Class Initialized
INFO - 2016-09-07 07:09:51 --> Language Class Initialized
INFO - 2016-09-07 07:09:51 --> Config Class Initialized
INFO - 2016-09-07 07:09:51 --> Loader Class Initialized
INFO - 2016-09-07 07:09:51 --> Helper loaded: url_helper
INFO - 2016-09-07 07:09:51 --> Database Driver Class Initialized
INFO - 2016-09-07 07:09:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-07 07:09:51 --> Model Class Initialized
INFO - 2016-09-07 07:09:51 --> Model Class Initialized
INFO - 2016-09-07 07:09:51 --> Controller Class Initialized
DEBUG - 2016-09-07 07:09:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 07:09:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 07:09:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
ERROR - 2016-09-07 07:09:51 --> Severity: Notice --> Undefined variable: table E:\SERVER\htdocs\koperasiweda\application\views\main_html\content\list_anggota.php 24
ERROR - 2016-09-07 07:09:51 --> Severity: Error --> Call to a member function result_array() on null E:\SERVER\htdocs\koperasiweda\application\views\main_html\content\list_anggota.php 24
INFO - 2016-09-07 07:12:11 --> Config Class Initialized
INFO - 2016-09-07 07:12:11 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:12:11 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:12:11 --> Utf8 Class Initialized
INFO - 2016-09-07 07:12:11 --> URI Class Initialized
INFO - 2016-09-07 07:12:11 --> Router Class Initialized
INFO - 2016-09-07 07:12:11 --> Output Class Initialized
INFO - 2016-09-07 07:12:11 --> Security Class Initialized
DEBUG - 2016-09-07 07:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:12:11 --> Input Class Initialized
INFO - 2016-09-07 07:12:11 --> Language Class Initialized
INFO - 2016-09-07 07:12:11 --> Language Class Initialized
INFO - 2016-09-07 07:12:11 --> Config Class Initialized
INFO - 2016-09-07 07:12:11 --> Loader Class Initialized
INFO - 2016-09-07 07:12:11 --> Helper loaded: url_helper
INFO - 2016-09-07 07:12:11 --> Database Driver Class Initialized
INFO - 2016-09-07 07:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-07 07:12:11 --> Model Class Initialized
INFO - 2016-09-07 07:12:11 --> Model Class Initialized
INFO - 2016-09-07 07:12:11 --> Controller Class Initialized
DEBUG - 2016-09-07 07:12:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 07:12:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 07:12:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 07:12:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/Anggota/controllers/Anggota.php
INFO - 2016-09-07 07:12:55 --> Config Class Initialized
INFO - 2016-09-07 07:12:55 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:12:55 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:12:55 --> Utf8 Class Initialized
INFO - 2016-09-07 07:12:55 --> URI Class Initialized
INFO - 2016-09-07 07:12:55 --> Router Class Initialized
INFO - 2016-09-07 07:12:55 --> Output Class Initialized
INFO - 2016-09-07 07:12:55 --> Security Class Initialized
DEBUG - 2016-09-07 07:12:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:12:55 --> Input Class Initialized
INFO - 2016-09-07 07:12:55 --> Language Class Initialized
INFO - 2016-09-07 07:12:55 --> Language Class Initialized
INFO - 2016-09-07 07:12:55 --> Config Class Initialized
INFO - 2016-09-07 07:12:55 --> Loader Class Initialized
INFO - 2016-09-07 07:12:55 --> Helper loaded: url_helper
INFO - 2016-09-07 07:12:55 --> Database Driver Class Initialized
INFO - 2016-09-07 07:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-07 07:12:56 --> Model Class Initialized
INFO - 2016-09-07 07:12:56 --> Model Class Initialized
INFO - 2016-09-07 07:12:56 --> Controller Class Initialized
DEBUG - 2016-09-07 07:12:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 07:12:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 07:12:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 07:12:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/Anggota/controllers/Anggota.php
INFO - 2016-09-07 07:14:12 --> Config Class Initialized
INFO - 2016-09-07 07:14:12 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:14:12 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:14:12 --> Utf8 Class Initialized
INFO - 2016-09-07 07:14:12 --> URI Class Initialized
INFO - 2016-09-07 07:14:12 --> Router Class Initialized
INFO - 2016-09-07 07:14:12 --> Output Class Initialized
INFO - 2016-09-07 07:14:12 --> Security Class Initialized
DEBUG - 2016-09-07 07:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:14:12 --> Input Class Initialized
INFO - 2016-09-07 07:14:12 --> Language Class Initialized
INFO - 2016-09-07 07:14:12 --> Language Class Initialized
INFO - 2016-09-07 07:14:12 --> Config Class Initialized
INFO - 2016-09-07 07:14:12 --> Loader Class Initialized
INFO - 2016-09-07 07:14:12 --> Helper loaded: url_helper
INFO - 2016-09-07 07:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-07 07:14:12 --> Database Driver Class Initialized
INFO - 2016-09-07 07:14:12 --> Model Class Initialized
INFO - 2016-09-07 07:14:12 --> Model Class Initialized
INFO - 2016-09-07 07:14:12 --> Controller Class Initialized
DEBUG - 2016-09-07 07:14:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 07:14:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 07:14:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 07:14:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/Anggota/controllers/Anggota.php
INFO - 2016-09-07 07:14:24 --> Config Class Initialized
INFO - 2016-09-07 07:14:24 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:14:24 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:14:24 --> Utf8 Class Initialized
INFO - 2016-09-07 07:14:24 --> URI Class Initialized
INFO - 2016-09-07 07:14:24 --> Router Class Initialized
INFO - 2016-09-07 07:14:24 --> Output Class Initialized
INFO - 2016-09-07 07:14:24 --> Security Class Initialized
DEBUG - 2016-09-07 07:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:14:24 --> Input Class Initialized
INFO - 2016-09-07 07:14:24 --> Language Class Initialized
INFO - 2016-09-07 07:14:24 --> Language Class Initialized
INFO - 2016-09-07 07:14:24 --> Config Class Initialized
INFO - 2016-09-07 07:14:24 --> Loader Class Initialized
INFO - 2016-09-07 07:14:24 --> Helper loaded: url_helper
INFO - 2016-09-07 07:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-07 07:14:25 --> Database Driver Class Initialized
INFO - 2016-09-07 07:14:25 --> Model Class Initialized
INFO - 2016-09-07 07:14:25 --> Model Class Initialized
INFO - 2016-09-07 07:14:25 --> Controller Class Initialized
DEBUG - 2016-09-07 07:14:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 07:14:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 07:14:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 07:14:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/Anggota/controllers/Anggota.php
INFO - 2016-09-07 07:14:39 --> Config Class Initialized
INFO - 2016-09-07 07:14:39 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:14:39 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:14:39 --> Utf8 Class Initialized
INFO - 2016-09-07 07:14:39 --> URI Class Initialized
INFO - 2016-09-07 07:14:39 --> Router Class Initialized
INFO - 2016-09-07 07:14:39 --> Output Class Initialized
INFO - 2016-09-07 07:14:39 --> Security Class Initialized
DEBUG - 2016-09-07 07:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:14:39 --> Input Class Initialized
INFO - 2016-09-07 07:14:39 --> Language Class Initialized
INFO - 2016-09-07 07:14:39 --> Language Class Initialized
INFO - 2016-09-07 07:14:39 --> Config Class Initialized
INFO - 2016-09-07 07:14:39 --> Loader Class Initialized
INFO - 2016-09-07 07:14:39 --> Helper loaded: url_helper
INFO - 2016-09-07 07:14:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-07 07:14:39 --> Database Driver Class Initialized
INFO - 2016-09-07 07:14:39 --> Model Class Initialized
INFO - 2016-09-07 07:14:39 --> Model Class Initialized
INFO - 2016-09-07 07:14:39 --> Controller Class Initialized
DEBUG - 2016-09-07 07:14:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 07:14:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 07:14:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 07:14:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/Anggota/controllers/Anggota.php
INFO - 2016-09-07 07:15:50 --> Config Class Initialized
INFO - 2016-09-07 07:15:50 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:15:50 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:15:50 --> Utf8 Class Initialized
INFO - 2016-09-07 07:15:50 --> URI Class Initialized
INFO - 2016-09-07 07:15:50 --> Router Class Initialized
INFO - 2016-09-07 07:15:50 --> Output Class Initialized
INFO - 2016-09-07 07:15:50 --> Security Class Initialized
DEBUG - 2016-09-07 07:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:15:50 --> Input Class Initialized
INFO - 2016-09-07 07:15:50 --> Language Class Initialized
INFO - 2016-09-07 07:15:50 --> Language Class Initialized
INFO - 2016-09-07 07:15:50 --> Config Class Initialized
INFO - 2016-09-07 07:15:50 --> Loader Class Initialized
INFO - 2016-09-07 07:15:50 --> Helper loaded: url_helper
INFO - 2016-09-07 07:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-07 07:15:50 --> Database Driver Class Initialized
INFO - 2016-09-07 07:15:50 --> Model Class Initialized
INFO - 2016-09-07 07:15:50 --> Model Class Initialized
INFO - 2016-09-07 07:15:50 --> Controller Class Initialized
DEBUG - 2016-09-07 07:15:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 07:15:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 07:15:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 07:15:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/Anggota/controllers/Anggota.php
INFO - 2016-09-07 07:16:02 --> Config Class Initialized
INFO - 2016-09-07 07:16:02 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:16:02 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:16:02 --> Utf8 Class Initialized
INFO - 2016-09-07 07:16:02 --> URI Class Initialized
INFO - 2016-09-07 07:16:02 --> Router Class Initialized
INFO - 2016-09-07 07:16:03 --> Output Class Initialized
INFO - 2016-09-07 07:16:03 --> Security Class Initialized
DEBUG - 2016-09-07 07:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:16:03 --> Input Class Initialized
INFO - 2016-09-07 07:16:03 --> Language Class Initialized
INFO - 2016-09-07 07:16:03 --> Language Class Initialized
INFO - 2016-09-07 07:16:03 --> Config Class Initialized
INFO - 2016-09-07 07:16:03 --> Loader Class Initialized
INFO - 2016-09-07 07:16:03 --> Helper loaded: url_helper
INFO - 2016-09-07 07:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-07 07:16:03 --> Database Driver Class Initialized
INFO - 2016-09-07 07:16:03 --> Model Class Initialized
INFO - 2016-09-07 07:16:03 --> Model Class Initialized
INFO - 2016-09-07 07:16:03 --> Controller Class Initialized
DEBUG - 2016-09-07 07:16:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 07:16:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 07:16:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 07:16:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/Anggota/controllers/Anggota.php
INFO - 2016-09-07 07:16:19 --> Config Class Initialized
INFO - 2016-09-07 07:16:19 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:16:19 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:16:19 --> Utf8 Class Initialized
INFO - 2016-09-07 07:16:19 --> URI Class Initialized
INFO - 2016-09-07 07:16:19 --> Router Class Initialized
INFO - 2016-09-07 07:16:19 --> Output Class Initialized
INFO - 2016-09-07 07:16:19 --> Security Class Initialized
DEBUG - 2016-09-07 07:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:16:19 --> Input Class Initialized
INFO - 2016-09-07 07:16:19 --> Language Class Initialized
INFO - 2016-09-07 07:16:19 --> Language Class Initialized
INFO - 2016-09-07 07:16:19 --> Config Class Initialized
INFO - 2016-09-07 07:16:19 --> Loader Class Initialized
INFO - 2016-09-07 07:16:19 --> Helper loaded: url_helper
INFO - 2016-09-07 07:16:19 --> Database Driver Class Initialized
INFO - 2016-09-07 07:16:19 --> Model Class Initialized
INFO - 2016-09-07 07:16:19 --> Model Class Initialized
INFO - 2016-09-07 07:16:19 --> Controller Class Initialized
DEBUG - 2016-09-07 07:16:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 07:16:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 07:16:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 07:16:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/Anggota/controllers/Anggota.php
INFO - 2016-09-07 07:16:19 --> Controller Class Initialized
ERROR - 2016-09-07 07:16:19 --> Severity: Error --> Call to undefined method CI_Model::get() E:\SERVER\htdocs\koperasiweda\application\modules\Anggota\controllers\Anggota.php 6
INFO - 2016-09-07 07:17:19 --> Config Class Initialized
INFO - 2016-09-07 07:17:19 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:17:19 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:17:19 --> Utf8 Class Initialized
INFO - 2016-09-07 07:17:19 --> URI Class Initialized
INFO - 2016-09-07 07:17:19 --> Router Class Initialized
INFO - 2016-09-07 07:17:19 --> Output Class Initialized
INFO - 2016-09-07 07:17:19 --> Security Class Initialized
DEBUG - 2016-09-07 07:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:17:19 --> Input Class Initialized
INFO - 2016-09-07 07:17:19 --> Language Class Initialized
INFO - 2016-09-07 07:17:19 --> Language Class Initialized
INFO - 2016-09-07 07:17:19 --> Config Class Initialized
INFO - 2016-09-07 07:17:19 --> Loader Class Initialized
INFO - 2016-09-07 07:17:19 --> Helper loaded: url_helper
INFO - 2016-09-07 07:17:19 --> Database Driver Class Initialized
INFO - 2016-09-07 07:17:19 --> Model Class Initialized
INFO - 2016-09-07 07:17:19 --> Model Class Initialized
INFO - 2016-09-07 07:17:19 --> Controller Class Initialized
DEBUG - 2016-09-07 07:17:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 07:17:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 07:17:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 07:17:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/Anggota/controllers/Anggota.php
INFO - 2016-09-07 07:17:19 --> Controller Class Initialized
ERROR - 2016-09-07 07:17:19 --> Severity: Error --> Call to undefined method CI_Model::get() E:\SERVER\htdocs\koperasiweda\application\modules\Anggota\controllers\Anggota.php 6
INFO - 2016-09-07 07:18:06 --> Config Class Initialized
INFO - 2016-09-07 07:18:06 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:18:06 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:18:06 --> Utf8 Class Initialized
INFO - 2016-09-07 07:18:06 --> URI Class Initialized
INFO - 2016-09-07 07:18:06 --> Router Class Initialized
INFO - 2016-09-07 07:18:06 --> Output Class Initialized
INFO - 2016-09-07 07:18:06 --> Security Class Initialized
DEBUG - 2016-09-07 07:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:18:07 --> Input Class Initialized
INFO - 2016-09-07 07:18:07 --> Language Class Initialized
INFO - 2016-09-07 07:18:07 --> Language Class Initialized
INFO - 2016-09-07 07:18:07 --> Config Class Initialized
INFO - 2016-09-07 07:18:07 --> Loader Class Initialized
INFO - 2016-09-07 07:18:07 --> Helper loaded: url_helper
INFO - 2016-09-07 07:18:07 --> Database Driver Class Initialized
INFO - 2016-09-07 07:18:07 --> Model Class Initialized
INFO - 2016-09-07 07:18:07 --> Model Class Initialized
INFO - 2016-09-07 07:18:07 --> Controller Class Initialized
DEBUG - 2016-09-07 07:18:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 07:18:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 07:18:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 07:18:07 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/Anggota/controllers/Anggota.php
INFO - 2016-09-07 07:18:07 --> Controller Class Initialized
INFO - 2016-09-07 07:18:07 --> Model Class Initialized
ERROR - 2016-09-07 07:18:07 --> Severity: Error --> Call to undefined method CI_Model::get() E:\SERVER\htdocs\koperasiweda\application\modules\Anggota\controllers\Anggota.php 10
INFO - 2016-09-07 07:18:35 --> Config Class Initialized
INFO - 2016-09-07 07:18:35 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:18:35 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:18:35 --> Utf8 Class Initialized
INFO - 2016-09-07 07:18:35 --> URI Class Initialized
INFO - 2016-09-07 07:18:35 --> Router Class Initialized
INFO - 2016-09-07 07:18:35 --> Output Class Initialized
INFO - 2016-09-07 07:18:35 --> Security Class Initialized
DEBUG - 2016-09-07 07:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:18:35 --> Input Class Initialized
INFO - 2016-09-07 07:18:35 --> Language Class Initialized
INFO - 2016-09-07 07:18:35 --> Language Class Initialized
INFO - 2016-09-07 07:18:35 --> Config Class Initialized
INFO - 2016-09-07 07:18:35 --> Loader Class Initialized
INFO - 2016-09-07 07:18:35 --> Helper loaded: url_helper
INFO - 2016-09-07 07:18:35 --> Database Driver Class Initialized
INFO - 2016-09-07 07:18:35 --> Model Class Initialized
INFO - 2016-09-07 07:18:35 --> Model Class Initialized
INFO - 2016-09-07 07:18:35 --> Controller Class Initialized
DEBUG - 2016-09-07 07:18:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 07:18:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 07:18:35 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 07:18:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/Anggota/controllers/Anggota.php
INFO - 2016-09-07 07:18:36 --> Controller Class Initialized
INFO - 2016-09-07 07:18:36 --> Model Class Initialized
ERROR - 2016-09-07 07:18:36 --> Severity: Runtime Notice --> Accessing static property Anggota::$tabel as non static E:\SERVER\htdocs\koperasiweda\application\modules\Anggota\controllers\Anggota.php 10
ERROR - 2016-09-07 07:18:36 --> Severity: Notice --> Undefined property: Anggota::$tabel E:\SERVER\htdocs\koperasiweda\application\modules\Anggota\controllers\Anggota.php 10
ERROR - 2016-09-07 07:18:36 --> Severity: Notice --> Undefined property: Anggota::$db E:\SERVER\htdocs\koperasiweda\system\core\Model.php 77
ERROR - 2016-09-07 07:18:36 --> Severity: Error --> Call to a member function get() on null E:\SERVER\htdocs\koperasiweda\application\models\GLobalModel.php 8
INFO - 2016-09-07 07:19:02 --> Config Class Initialized
INFO - 2016-09-07 07:19:02 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:19:02 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:19:02 --> Utf8 Class Initialized
INFO - 2016-09-07 07:19:02 --> URI Class Initialized
INFO - 2016-09-07 07:19:02 --> Router Class Initialized
INFO - 2016-09-07 07:19:02 --> Output Class Initialized
INFO - 2016-09-07 07:19:02 --> Security Class Initialized
DEBUG - 2016-09-07 07:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:19:03 --> Input Class Initialized
INFO - 2016-09-07 07:19:03 --> Language Class Initialized
INFO - 2016-09-07 07:19:03 --> Language Class Initialized
INFO - 2016-09-07 07:19:03 --> Config Class Initialized
INFO - 2016-09-07 07:19:03 --> Loader Class Initialized
INFO - 2016-09-07 07:19:03 --> Helper loaded: url_helper
INFO - 2016-09-07 07:19:03 --> Database Driver Class Initialized
INFO - 2016-09-07 07:19:03 --> Model Class Initialized
INFO - 2016-09-07 07:19:03 --> Model Class Initialized
INFO - 2016-09-07 07:19:03 --> Controller Class Initialized
DEBUG - 2016-09-07 07:19:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 07:19:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 07:19:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 07:19:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/Anggota/controllers/Anggota.php
INFO - 2016-09-07 07:19:03 --> Controller Class Initialized
INFO - 2016-09-07 07:19:03 --> Model Class Initialized
ERROR - 2016-09-07 07:19:03 --> Severity: Notice --> Undefined property: Anggota::$db E:\SERVER\htdocs\koperasiweda\system\core\Model.php 77
ERROR - 2016-09-07 07:19:03 --> Severity: Error --> Call to a member function get() on null E:\SERVER\htdocs\koperasiweda\application\models\GLobalModel.php 8
INFO - 2016-09-07 07:20:19 --> Config Class Initialized
INFO - 2016-09-07 07:20:19 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:20:19 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:20:19 --> Utf8 Class Initialized
INFO - 2016-09-07 07:20:19 --> URI Class Initialized
INFO - 2016-09-07 07:20:19 --> Router Class Initialized
INFO - 2016-09-07 07:20:20 --> Output Class Initialized
INFO - 2016-09-07 07:20:20 --> Security Class Initialized
DEBUG - 2016-09-07 07:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:20:20 --> Input Class Initialized
INFO - 2016-09-07 07:20:20 --> Language Class Initialized
INFO - 2016-09-07 07:20:20 --> Language Class Initialized
INFO - 2016-09-07 07:20:20 --> Config Class Initialized
INFO - 2016-09-07 07:20:20 --> Loader Class Initialized
INFO - 2016-09-07 07:20:20 --> Helper loaded: url_helper
INFO - 2016-09-07 07:20:20 --> Database Driver Class Initialized
INFO - 2016-09-07 07:20:20 --> Model Class Initialized
INFO - 2016-09-07 07:20:26 --> Config Class Initialized
INFO - 2016-09-07 07:20:26 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:20:26 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:20:26 --> Utf8 Class Initialized
INFO - 2016-09-07 07:20:27 --> URI Class Initialized
INFO - 2016-09-07 07:20:27 --> Router Class Initialized
INFO - 2016-09-07 07:20:27 --> Output Class Initialized
INFO - 2016-09-07 07:20:27 --> Security Class Initialized
DEBUG - 2016-09-07 07:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:20:27 --> Input Class Initialized
INFO - 2016-09-07 07:20:27 --> Language Class Initialized
INFO - 2016-09-07 07:20:27 --> Language Class Initialized
INFO - 2016-09-07 07:20:27 --> Config Class Initialized
INFO - 2016-09-07 07:20:27 --> Loader Class Initialized
INFO - 2016-09-07 07:20:27 --> Helper loaded: url_helper
INFO - 2016-09-07 07:20:27 --> Database Driver Class Initialized
INFO - 2016-09-07 07:20:27 --> Controller Class Initialized
DEBUG - 2016-09-07 07:20:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 07:20:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 07:20:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 07:20:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/Anggota/controllers/Anggota.php
INFO - 2016-09-07 07:20:27 --> Controller Class Initialized
INFO - 2016-09-07 07:20:27 --> Model Class Initialized
INFO - 2016-09-07 07:20:27 --> Model Class Initialized
ERROR - 2016-09-07 07:20:27 --> Severity: Notice --> Undefined property: Anggota::$db E:\SERVER\htdocs\koperasiweda\system\core\Model.php 77
ERROR - 2016-09-07 07:20:27 --> Severity: Error --> Call to a member function get() on null E:\SERVER\htdocs\koperasiweda\application\models\GLobalModel.php 8
INFO - 2016-09-07 07:21:58 --> Config Class Initialized
INFO - 2016-09-07 07:21:58 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:21:58 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:21:58 --> Utf8 Class Initialized
INFO - 2016-09-07 07:21:58 --> URI Class Initialized
INFO - 2016-09-07 07:21:58 --> Router Class Initialized
INFO - 2016-09-07 07:21:59 --> Output Class Initialized
INFO - 2016-09-07 07:21:59 --> Security Class Initialized
DEBUG - 2016-09-07 07:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:21:59 --> Input Class Initialized
INFO - 2016-09-07 07:21:59 --> Language Class Initialized
INFO - 2016-09-07 07:21:59 --> Language Class Initialized
INFO - 2016-09-07 07:21:59 --> Config Class Initialized
INFO - 2016-09-07 07:21:59 --> Loader Class Initialized
INFO - 2016-09-07 07:21:59 --> Helper loaded: url_helper
INFO - 2016-09-07 07:21:59 --> Database Driver Class Initialized
INFO - 2016-09-07 07:21:59 --> Controller Class Initialized
DEBUG - 2016-09-07 07:21:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 07:21:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 07:21:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 07:21:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/Anggota/controllers/Anggota.php
INFO - 2016-09-07 07:21:59 --> Controller Class Initialized
INFO - 2016-09-07 07:21:59 --> Model Class Initialized
INFO - 2016-09-07 07:21:59 --> Model Class Initialized
ERROR - 2016-09-07 07:21:59 --> Severity: Notice --> Undefined property: Anggota::$db E:\SERVER\htdocs\koperasiweda\system\core\Model.php 77
ERROR - 2016-09-07 07:21:59 --> Severity: Error --> Call to a member function get() on null E:\SERVER\htdocs\koperasiweda\application\models\GLobalModel.php 12
INFO - 2016-09-07 07:22:59 --> Config Class Initialized
INFO - 2016-09-07 07:22:59 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:22:59 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:22:59 --> Utf8 Class Initialized
INFO - 2016-09-07 07:22:59 --> URI Class Initialized
INFO - 2016-09-07 07:22:59 --> Router Class Initialized
INFO - 2016-09-07 07:22:59 --> Output Class Initialized
INFO - 2016-09-07 07:22:59 --> Security Class Initialized
DEBUG - 2016-09-07 07:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:22:59 --> Input Class Initialized
INFO - 2016-09-07 07:22:59 --> Language Class Initialized
INFO - 2016-09-07 07:22:59 --> Language Class Initialized
INFO - 2016-09-07 07:22:59 --> Config Class Initialized
INFO - 2016-09-07 07:22:59 --> Loader Class Initialized
INFO - 2016-09-07 07:22:59 --> Helper loaded: url_helper
INFO - 2016-09-07 07:22:59 --> Database Driver Class Initialized
INFO - 2016-09-07 07:22:59 --> Controller Class Initialized
DEBUG - 2016-09-07 07:22:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 07:22:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 07:22:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 07:23:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
INFO - 2016-09-07 07:23:00 --> Controller Class Initialized
INFO - 2016-09-07 07:23:00 --> Model Class Initialized
INFO - 2016-09-07 07:23:00 --> Model Class Initialized
ERROR - 2016-09-07 07:23:00 --> Severity: Notice --> Undefined property: Anggota::$db E:\SERVER\htdocs\koperasiweda\system\core\Model.php 77
ERROR - 2016-09-07 07:23:00 --> Severity: Error --> Call to a member function get() on null E:\SERVER\htdocs\koperasiweda\application\models\GLobalModel.php 12
INFO - 2016-09-07 07:23:33 --> Config Class Initialized
INFO - 2016-09-07 07:23:33 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:23:33 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:23:33 --> Utf8 Class Initialized
INFO - 2016-09-07 07:23:33 --> URI Class Initialized
INFO - 2016-09-07 07:23:33 --> Router Class Initialized
INFO - 2016-09-07 07:23:33 --> Output Class Initialized
INFO - 2016-09-07 07:23:33 --> Security Class Initialized
DEBUG - 2016-09-07 07:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:23:33 --> Input Class Initialized
INFO - 2016-09-07 07:23:33 --> Language Class Initialized
INFO - 2016-09-07 07:23:33 --> Language Class Initialized
INFO - 2016-09-07 07:23:33 --> Config Class Initialized
INFO - 2016-09-07 07:23:33 --> Loader Class Initialized
INFO - 2016-09-07 07:23:33 --> Helper loaded: url_helper
INFO - 2016-09-07 07:23:33 --> Database Driver Class Initialized
INFO - 2016-09-07 07:23:33 --> Controller Class Initialized
DEBUG - 2016-09-07 07:23:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 07:23:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 07:23:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 07:23:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
INFO - 2016-09-07 07:23:33 --> Controller Class Initialized
INFO - 2016-09-07 07:23:33 --> Model Class Initialized
INFO - 2016-09-07 07:23:33 --> Model Class Initialized
ERROR - 2016-09-07 07:23:33 --> Severity: Notice --> Undefined variable: tabel E:\SERVER\htdocs\koperasiweda\application\modules\Anggota\controllers\Anggota.php 10
ERROR - 2016-09-07 07:23:33 --> Severity: Notice --> Undefined property: Anggota::$db E:\SERVER\htdocs\koperasiweda\system\core\Model.php 77
ERROR - 2016-09-07 07:23:33 --> Severity: Error --> Call to a member function get() on null E:\SERVER\htdocs\koperasiweda\application\models\GLobalModel.php 12
INFO - 2016-09-07 07:23:51 --> Config Class Initialized
INFO - 2016-09-07 07:23:51 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:23:51 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:23:51 --> Utf8 Class Initialized
INFO - 2016-09-07 07:23:51 --> URI Class Initialized
INFO - 2016-09-07 07:23:51 --> Router Class Initialized
INFO - 2016-09-07 07:23:52 --> Output Class Initialized
INFO - 2016-09-07 07:23:52 --> Security Class Initialized
DEBUG - 2016-09-07 07:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:23:52 --> Input Class Initialized
INFO - 2016-09-07 07:23:52 --> Language Class Initialized
INFO - 2016-09-07 07:23:52 --> Language Class Initialized
INFO - 2016-09-07 07:23:52 --> Config Class Initialized
INFO - 2016-09-07 07:23:52 --> Loader Class Initialized
INFO - 2016-09-07 07:23:52 --> Helper loaded: url_helper
INFO - 2016-09-07 07:23:52 --> Database Driver Class Initialized
INFO - 2016-09-07 07:23:52 --> Controller Class Initialized
DEBUG - 2016-09-07 07:23:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 07:23:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 07:23:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 07:23:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
INFO - 2016-09-07 07:23:52 --> Controller Class Initialized
INFO - 2016-09-07 07:23:52 --> Model Class Initialized
INFO - 2016-09-07 07:23:52 --> Model Class Initialized
ERROR - 2016-09-07 07:23:52 --> Severity: Notice --> Undefined property: Anggota::$db E:\SERVER\htdocs\koperasiweda\system\core\Model.php 77
ERROR - 2016-09-07 07:23:52 --> Severity: Error --> Call to a member function get() on null E:\SERVER\htdocs\koperasiweda\application\models\GLobalModel.php 12
INFO - 2016-09-07 07:30:29 --> Config Class Initialized
INFO - 2016-09-07 07:30:29 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:30:30 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:30:30 --> Utf8 Class Initialized
INFO - 2016-09-07 07:30:30 --> URI Class Initialized
INFO - 2016-09-07 07:30:30 --> Router Class Initialized
INFO - 2016-09-07 07:30:30 --> Output Class Initialized
INFO - 2016-09-07 07:30:30 --> Security Class Initialized
DEBUG - 2016-09-07 07:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:30:30 --> Input Class Initialized
INFO - 2016-09-07 07:30:30 --> Language Class Initialized
INFO - 2016-09-07 07:30:30 --> Language Class Initialized
INFO - 2016-09-07 07:30:30 --> Config Class Initialized
INFO - 2016-09-07 07:30:30 --> Loader Class Initialized
INFO - 2016-09-07 07:30:30 --> Helper loaded: url_helper
INFO - 2016-09-07 07:30:30 --> Database Driver Class Initialized
INFO - 2016-09-07 07:30:30 --> Controller Class Initialized
DEBUG - 2016-09-07 07:30:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 07:30:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 07:30:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 07:30:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
INFO - 2016-09-07 07:30:30 --> Controller Class Initialized
INFO - 2016-09-07 07:30:30 --> Model Class Initialized
INFO - 2016-09-07 07:30:30 --> Model Class Initialized
ERROR - 2016-09-07 07:30:30 --> Severity: Notice --> Undefined property: Anggota::$db E:\SERVER\htdocs\koperasiweda\system\core\Model.php 77
ERROR - 2016-09-07 07:30:30 --> Severity: Error --> Call to a member function get() on null E:\SERVER\htdocs\koperasiweda\application\models\GLobalModel.php 12
INFO - 2016-09-07 07:35:35 --> Config Class Initialized
INFO - 2016-09-07 07:35:36 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:35:36 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:35:36 --> Utf8 Class Initialized
INFO - 2016-09-07 07:35:36 --> URI Class Initialized
INFO - 2016-09-07 07:35:36 --> Router Class Initialized
INFO - 2016-09-07 07:35:36 --> Output Class Initialized
INFO - 2016-09-07 07:35:36 --> Security Class Initialized
DEBUG - 2016-09-07 07:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:35:36 --> Input Class Initialized
INFO - 2016-09-07 07:35:36 --> Language Class Initialized
INFO - 2016-09-07 07:35:36 --> Language Class Initialized
INFO - 2016-09-07 07:35:36 --> Config Class Initialized
INFO - 2016-09-07 07:35:36 --> Loader Class Initialized
INFO - 2016-09-07 07:35:36 --> Helper loaded: url_helper
INFO - 2016-09-07 07:35:36 --> Database Driver Class Initialized
INFO - 2016-09-07 07:35:36 --> Controller Class Initialized
DEBUG - 2016-09-07 07:35:36 --> Index MX_Controller Initialized
DEBUG - 2016-09-07 07:35:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 07:35:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 07:35:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 07:35:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-07 07:35:36 --> Anggota MX_Controller Initialized
INFO - 2016-09-07 07:35:36 --> Model Class Initialized
INFO - 2016-09-07 07:35:36 --> Model Class Initialized
ERROR - 2016-09-07 07:35:36 --> Severity: Notice --> Undefined property: CI::$table_prefix E:\SERVER\htdocs\koperasiweda\system\core\Model.php 77
DEBUG - 2016-09-07 07:35:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-07 07:35:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 07:35:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 07:35:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 07:35:36 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 07:35:36 --> Final output sent to browser
DEBUG - 2016-09-07 07:35:36 --> Total execution time: 0.9279
INFO - 2016-09-07 07:36:50 --> Config Class Initialized
INFO - 2016-09-07 07:36:50 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:36:50 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:36:50 --> Utf8 Class Initialized
INFO - 2016-09-07 07:36:50 --> URI Class Initialized
INFO - 2016-09-07 07:36:50 --> Router Class Initialized
INFO - 2016-09-07 07:36:50 --> Output Class Initialized
INFO - 2016-09-07 07:36:50 --> Security Class Initialized
DEBUG - 2016-09-07 07:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:36:50 --> Input Class Initialized
INFO - 2016-09-07 07:36:50 --> Language Class Initialized
INFO - 2016-09-07 07:36:50 --> Language Class Initialized
INFO - 2016-09-07 07:36:50 --> Config Class Initialized
INFO - 2016-09-07 07:36:51 --> Loader Class Initialized
INFO - 2016-09-07 07:36:51 --> Helper loaded: url_helper
INFO - 2016-09-07 07:36:51 --> Database Driver Class Initialized
INFO - 2016-09-07 07:36:51 --> Controller Class Initialized
DEBUG - 2016-09-07 07:36:51 --> Index MX_Controller Initialized
INFO - 2016-09-07 07:36:51 --> Model Class Initialized
INFO - 2016-09-07 07:36:51 --> Model Class Initialized
DEBUG - 2016-09-07 07:36:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 07:36:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 07:36:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 07:36:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-07 07:36:51 --> Anggota MX_Controller Initialized
ERROR - 2016-09-07 07:36:51 --> Severity: Notice --> Undefined property: CI::$table_prefix E:\SERVER\htdocs\koperasiweda\system\core\Model.php 77
DEBUG - 2016-09-07 07:36:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-07 07:36:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 07:36:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 07:36:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 07:36:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 07:36:51 --> Final output sent to browser
DEBUG - 2016-09-07 07:36:51 --> Total execution time: 0.8393
INFO - 2016-09-07 07:53:37 --> Config Class Initialized
INFO - 2016-09-07 07:53:37 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:53:37 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:53:37 --> Utf8 Class Initialized
INFO - 2016-09-07 07:53:37 --> URI Class Initialized
INFO - 2016-09-07 07:53:37 --> Router Class Initialized
INFO - 2016-09-07 07:53:37 --> Output Class Initialized
INFO - 2016-09-07 07:53:37 --> Security Class Initialized
DEBUG - 2016-09-07 07:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:53:37 --> Input Class Initialized
INFO - 2016-09-07 07:53:37 --> Language Class Initialized
INFO - 2016-09-07 07:53:37 --> Language Class Initialized
INFO - 2016-09-07 07:53:37 --> Config Class Initialized
INFO - 2016-09-07 07:53:37 --> Loader Class Initialized
INFO - 2016-09-07 07:53:37 --> Helper loaded: url_helper
INFO - 2016-09-07 07:53:37 --> Database Driver Class Initialized
INFO - 2016-09-07 07:53:37 --> Controller Class Initialized
DEBUG - 2016-09-07 07:53:37 --> Index MX_Controller Initialized
INFO - 2016-09-07 07:53:37 --> Model Class Initialized
INFO - 2016-09-07 07:53:37 --> Model Class Initialized
DEBUG - 2016-09-07 07:53:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 07:53:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 07:53:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 07:53:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 07:53:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 07:53:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 07:53:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 07:53:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 07:53:38 --> Final output sent to browser
DEBUG - 2016-09-07 07:53:38 --> Total execution time: 0.8323
INFO - 2016-09-07 07:55:43 --> Config Class Initialized
INFO - 2016-09-07 07:55:43 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:55:43 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:55:43 --> Utf8 Class Initialized
INFO - 2016-09-07 07:55:43 --> URI Class Initialized
INFO - 2016-09-07 07:55:43 --> Router Class Initialized
INFO - 2016-09-07 07:55:43 --> Output Class Initialized
INFO - 2016-09-07 07:55:43 --> Security Class Initialized
DEBUG - 2016-09-07 07:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:55:43 --> Input Class Initialized
INFO - 2016-09-07 07:55:43 --> Language Class Initialized
INFO - 2016-09-07 07:55:43 --> Language Class Initialized
INFO - 2016-09-07 07:55:43 --> Config Class Initialized
INFO - 2016-09-07 07:55:43 --> Loader Class Initialized
INFO - 2016-09-07 07:55:43 --> Helper loaded: url_helper
INFO - 2016-09-07 07:55:44 --> Database Driver Class Initialized
INFO - 2016-09-07 07:55:44 --> Controller Class Initialized
DEBUG - 2016-09-07 07:55:44 --> Index MX_Controller Initialized
INFO - 2016-09-07 07:55:44 --> Model Class Initialized
INFO - 2016-09-07 07:55:44 --> Model Class Initialized
DEBUG - 2016-09-07 07:55:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 07:55:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 07:55:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 07:55:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 07:55:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 07:55:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 07:55:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 07:55:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 07:55:44 --> Final output sent to browser
DEBUG - 2016-09-07 07:55:44 --> Total execution time: 0.7286
INFO - 2016-09-07 07:56:31 --> Config Class Initialized
INFO - 2016-09-07 07:56:31 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:56:31 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:56:31 --> Utf8 Class Initialized
INFO - 2016-09-07 07:56:31 --> URI Class Initialized
INFO - 2016-09-07 07:56:31 --> Router Class Initialized
INFO - 2016-09-07 07:56:31 --> Output Class Initialized
INFO - 2016-09-07 07:56:31 --> Security Class Initialized
DEBUG - 2016-09-07 07:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:56:31 --> Input Class Initialized
INFO - 2016-09-07 07:56:31 --> Language Class Initialized
INFO - 2016-09-07 07:56:31 --> Language Class Initialized
INFO - 2016-09-07 07:56:31 --> Config Class Initialized
INFO - 2016-09-07 07:56:31 --> Loader Class Initialized
INFO - 2016-09-07 07:56:31 --> Helper loaded: url_helper
INFO - 2016-09-07 07:56:31 --> Database Driver Class Initialized
INFO - 2016-09-07 07:56:31 --> Controller Class Initialized
DEBUG - 2016-09-07 07:56:31 --> Index MX_Controller Initialized
INFO - 2016-09-07 07:56:32 --> Model Class Initialized
INFO - 2016-09-07 07:56:32 --> Model Class Initialized
DEBUG - 2016-09-07 07:56:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 07:56:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 07:56:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 07:56:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 07:56:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 07:56:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 07:56:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 07:56:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 07:56:32 --> Final output sent to browser
DEBUG - 2016-09-07 07:56:32 --> Total execution time: 0.7481
INFO - 2016-09-07 07:56:42 --> Config Class Initialized
INFO - 2016-09-07 07:56:42 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:56:42 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:56:42 --> Utf8 Class Initialized
INFO - 2016-09-07 07:56:42 --> URI Class Initialized
INFO - 2016-09-07 07:56:42 --> Router Class Initialized
INFO - 2016-09-07 07:56:42 --> Output Class Initialized
INFO - 2016-09-07 07:56:42 --> Security Class Initialized
DEBUG - 2016-09-07 07:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:56:42 --> Input Class Initialized
INFO - 2016-09-07 07:56:42 --> Language Class Initialized
INFO - 2016-09-07 07:56:42 --> Language Class Initialized
INFO - 2016-09-07 07:56:42 --> Config Class Initialized
INFO - 2016-09-07 07:56:42 --> Loader Class Initialized
INFO - 2016-09-07 07:56:42 --> Helper loaded: url_helper
INFO - 2016-09-07 07:56:42 --> Database Driver Class Initialized
INFO - 2016-09-07 07:56:42 --> Controller Class Initialized
DEBUG - 2016-09-07 07:56:42 --> Index MX_Controller Initialized
INFO - 2016-09-07 07:56:42 --> Model Class Initialized
INFO - 2016-09-07 07:56:42 --> Model Class Initialized
DEBUG - 2016-09-07 07:56:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 07:56:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 07:56:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 07:56:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 07:56:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 07:56:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 07:56:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 07:56:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 07:56:42 --> Final output sent to browser
DEBUG - 2016-09-07 07:56:42 --> Total execution time: 0.7575
INFO - 2016-09-07 07:58:30 --> Config Class Initialized
INFO - 2016-09-07 07:58:30 --> Hooks Class Initialized
DEBUG - 2016-09-07 07:58:30 --> UTF-8 Support Enabled
INFO - 2016-09-07 07:58:30 --> Utf8 Class Initialized
INFO - 2016-09-07 07:58:30 --> URI Class Initialized
INFO - 2016-09-07 07:58:30 --> Router Class Initialized
INFO - 2016-09-07 07:58:30 --> Output Class Initialized
INFO - 2016-09-07 07:58:30 --> Security Class Initialized
DEBUG - 2016-09-07 07:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 07:58:30 --> Input Class Initialized
INFO - 2016-09-07 07:58:30 --> Language Class Initialized
INFO - 2016-09-07 07:58:30 --> Language Class Initialized
INFO - 2016-09-07 07:58:30 --> Config Class Initialized
INFO - 2016-09-07 07:58:30 --> Loader Class Initialized
INFO - 2016-09-07 07:58:30 --> Helper loaded: url_helper
INFO - 2016-09-07 07:58:30 --> Database Driver Class Initialized
INFO - 2016-09-07 07:58:30 --> Controller Class Initialized
DEBUG - 2016-09-07 07:58:30 --> Index MX_Controller Initialized
INFO - 2016-09-07 07:58:30 --> Model Class Initialized
INFO - 2016-09-07 07:58:30 --> Model Class Initialized
DEBUG - 2016-09-07 07:58:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 07:58:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 07:58:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 07:58:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 07:58:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 07:58:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 07:58:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 07:58:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 07:58:30 --> Final output sent to browser
DEBUG - 2016-09-07 07:58:31 --> Total execution time: 0.7282
INFO - 2016-09-07 08:00:18 --> Config Class Initialized
INFO - 2016-09-07 08:00:18 --> Hooks Class Initialized
DEBUG - 2016-09-07 08:00:18 --> UTF-8 Support Enabled
INFO - 2016-09-07 08:00:19 --> Utf8 Class Initialized
INFO - 2016-09-07 08:00:19 --> URI Class Initialized
INFO - 2016-09-07 08:00:19 --> Router Class Initialized
INFO - 2016-09-07 08:00:19 --> Output Class Initialized
INFO - 2016-09-07 08:00:19 --> Security Class Initialized
DEBUG - 2016-09-07 08:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 08:00:19 --> Input Class Initialized
INFO - 2016-09-07 08:00:19 --> Language Class Initialized
INFO - 2016-09-07 08:00:19 --> Language Class Initialized
INFO - 2016-09-07 08:00:19 --> Config Class Initialized
INFO - 2016-09-07 08:00:19 --> Loader Class Initialized
INFO - 2016-09-07 08:00:19 --> Helper loaded: url_helper
INFO - 2016-09-07 08:00:19 --> Database Driver Class Initialized
INFO - 2016-09-07 08:00:19 --> Controller Class Initialized
DEBUG - 2016-09-07 08:00:19 --> Index MX_Controller Initialized
INFO - 2016-09-07 08:00:19 --> Model Class Initialized
INFO - 2016-09-07 08:00:19 --> Model Class Initialized
DEBUG - 2016-09-07 08:00:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 08:00:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 08:00:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 08:00:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 08:00:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 08:00:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 08:00:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 08:00:19 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 08:00:19 --> Final output sent to browser
DEBUG - 2016-09-07 08:00:19 --> Total execution time: 0.7725
INFO - 2016-09-07 08:03:50 --> Config Class Initialized
INFO - 2016-09-07 08:03:50 --> Hooks Class Initialized
DEBUG - 2016-09-07 08:03:50 --> UTF-8 Support Enabled
INFO - 2016-09-07 08:03:50 --> Utf8 Class Initialized
INFO - 2016-09-07 08:03:50 --> URI Class Initialized
INFO - 2016-09-07 08:03:50 --> Router Class Initialized
INFO - 2016-09-07 08:03:50 --> Output Class Initialized
INFO - 2016-09-07 08:03:50 --> Security Class Initialized
DEBUG - 2016-09-07 08:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 08:03:50 --> Input Class Initialized
INFO - 2016-09-07 08:03:50 --> Language Class Initialized
INFO - 2016-09-07 08:03:50 --> Language Class Initialized
INFO - 2016-09-07 08:03:50 --> Config Class Initialized
INFO - 2016-09-07 08:03:50 --> Loader Class Initialized
INFO - 2016-09-07 08:03:50 --> Helper loaded: url_helper
INFO - 2016-09-07 08:03:50 --> Database Driver Class Initialized
INFO - 2016-09-07 08:03:50 --> Controller Class Initialized
DEBUG - 2016-09-07 08:03:50 --> Index MX_Controller Initialized
INFO - 2016-09-07 08:03:50 --> Model Class Initialized
INFO - 2016-09-07 08:03:50 --> Model Class Initialized
DEBUG - 2016-09-07 08:03:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 08:03:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 08:03:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 08:03:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 08:03:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 08:03:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 08:03:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 08:03:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 08:03:50 --> Final output sent to browser
DEBUG - 2016-09-07 08:03:50 --> Total execution time: 0.7381
INFO - 2016-09-07 08:07:12 --> Config Class Initialized
INFO - 2016-09-07 08:07:12 --> Hooks Class Initialized
DEBUG - 2016-09-07 08:07:12 --> UTF-8 Support Enabled
INFO - 2016-09-07 08:07:12 --> Utf8 Class Initialized
INFO - 2016-09-07 08:07:12 --> URI Class Initialized
INFO - 2016-09-07 08:07:12 --> Router Class Initialized
INFO - 2016-09-07 08:07:12 --> Output Class Initialized
INFO - 2016-09-07 08:07:12 --> Security Class Initialized
DEBUG - 2016-09-07 08:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 08:07:12 --> Input Class Initialized
INFO - 2016-09-07 08:07:12 --> Language Class Initialized
INFO - 2016-09-07 08:07:12 --> Language Class Initialized
INFO - 2016-09-07 08:07:12 --> Config Class Initialized
INFO - 2016-09-07 08:07:12 --> Loader Class Initialized
INFO - 2016-09-07 08:07:12 --> Helper loaded: url_helper
INFO - 2016-09-07 08:07:12 --> Database Driver Class Initialized
INFO - 2016-09-07 08:07:12 --> Controller Class Initialized
DEBUG - 2016-09-07 08:07:12 --> Index MX_Controller Initialized
INFO - 2016-09-07 08:07:12 --> Model Class Initialized
INFO - 2016-09-07 08:07:12 --> Model Class Initialized
DEBUG - 2016-09-07 08:07:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 08:07:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 08:07:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 08:07:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 08:07:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 08:07:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 08:07:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 08:07:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 08:07:13 --> Final output sent to browser
DEBUG - 2016-09-07 08:07:13 --> Total execution time: 0.7561
INFO - 2016-09-07 08:09:58 --> Config Class Initialized
INFO - 2016-09-07 08:09:58 --> Hooks Class Initialized
DEBUG - 2016-09-07 08:09:58 --> UTF-8 Support Enabled
INFO - 2016-09-07 08:09:58 --> Utf8 Class Initialized
INFO - 2016-09-07 08:09:58 --> URI Class Initialized
INFO - 2016-09-07 08:09:58 --> Router Class Initialized
INFO - 2016-09-07 08:09:58 --> Output Class Initialized
INFO - 2016-09-07 08:09:58 --> Security Class Initialized
DEBUG - 2016-09-07 08:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 08:09:58 --> Input Class Initialized
INFO - 2016-09-07 08:09:58 --> Language Class Initialized
INFO - 2016-09-07 08:09:58 --> Language Class Initialized
INFO - 2016-09-07 08:09:58 --> Config Class Initialized
INFO - 2016-09-07 08:09:58 --> Loader Class Initialized
INFO - 2016-09-07 08:09:58 --> Helper loaded: url_helper
INFO - 2016-09-07 08:09:58 --> Database Driver Class Initialized
INFO - 2016-09-07 08:09:58 --> Controller Class Initialized
DEBUG - 2016-09-07 08:09:58 --> Index MX_Controller Initialized
INFO - 2016-09-07 08:09:58 --> Model Class Initialized
INFO - 2016-09-07 08:09:58 --> Model Class Initialized
DEBUG - 2016-09-07 08:09:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 08:09:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 08:09:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 08:09:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 08:09:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 08:09:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 08:09:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 08:09:59 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 08:09:59 --> Final output sent to browser
DEBUG - 2016-09-07 08:09:59 --> Total execution time: 0.7109
INFO - 2016-09-07 08:10:46 --> Config Class Initialized
INFO - 2016-09-07 08:10:47 --> Hooks Class Initialized
DEBUG - 2016-09-07 08:10:47 --> UTF-8 Support Enabled
INFO - 2016-09-07 08:10:47 --> Utf8 Class Initialized
INFO - 2016-09-07 08:10:47 --> URI Class Initialized
INFO - 2016-09-07 08:10:47 --> Router Class Initialized
INFO - 2016-09-07 08:10:47 --> Output Class Initialized
INFO - 2016-09-07 08:10:47 --> Security Class Initialized
DEBUG - 2016-09-07 08:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 08:10:47 --> Input Class Initialized
INFO - 2016-09-07 08:10:47 --> Language Class Initialized
INFO - 2016-09-07 08:10:47 --> Language Class Initialized
INFO - 2016-09-07 08:10:47 --> Config Class Initialized
INFO - 2016-09-07 08:10:47 --> Loader Class Initialized
INFO - 2016-09-07 08:10:47 --> Helper loaded: url_helper
INFO - 2016-09-07 08:10:47 --> Database Driver Class Initialized
INFO - 2016-09-07 08:10:47 --> Controller Class Initialized
DEBUG - 2016-09-07 08:10:47 --> Index MX_Controller Initialized
INFO - 2016-09-07 08:10:47 --> Model Class Initialized
INFO - 2016-09-07 08:10:47 --> Model Class Initialized
DEBUG - 2016-09-07 08:10:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 08:10:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 08:10:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 08:10:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 08:10:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 08:10:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 08:10:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 08:10:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 08:10:47 --> Final output sent to browser
DEBUG - 2016-09-07 08:10:47 --> Total execution time: 0.8219
INFO - 2016-09-07 08:12:50 --> Config Class Initialized
INFO - 2016-09-07 08:12:50 --> Hooks Class Initialized
DEBUG - 2016-09-07 08:12:50 --> UTF-8 Support Enabled
INFO - 2016-09-07 08:12:50 --> Utf8 Class Initialized
INFO - 2016-09-07 08:12:50 --> URI Class Initialized
INFO - 2016-09-07 08:12:50 --> Router Class Initialized
INFO - 2016-09-07 08:12:50 --> Output Class Initialized
INFO - 2016-09-07 08:12:50 --> Security Class Initialized
DEBUG - 2016-09-07 08:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 08:12:50 --> Input Class Initialized
INFO - 2016-09-07 08:12:50 --> Language Class Initialized
INFO - 2016-09-07 08:12:50 --> Language Class Initialized
INFO - 2016-09-07 08:12:50 --> Config Class Initialized
INFO - 2016-09-07 08:12:50 --> Loader Class Initialized
INFO - 2016-09-07 08:12:50 --> Helper loaded: url_helper
INFO - 2016-09-07 08:12:50 --> Database Driver Class Initialized
INFO - 2016-09-07 08:12:50 --> Controller Class Initialized
DEBUG - 2016-09-07 08:12:50 --> Index MX_Controller Initialized
INFO - 2016-09-07 08:12:50 --> Model Class Initialized
INFO - 2016-09-07 08:12:50 --> Model Class Initialized
DEBUG - 2016-09-07 08:12:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 08:12:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 08:12:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 08:12:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 08:12:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 08:12:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 08:12:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 08:12:50 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 08:12:50 --> Final output sent to browser
DEBUG - 2016-09-07 08:12:51 --> Total execution time: 0.8199
INFO - 2016-09-07 08:13:26 --> Config Class Initialized
INFO - 2016-09-07 08:13:26 --> Hooks Class Initialized
DEBUG - 2016-09-07 08:13:26 --> UTF-8 Support Enabled
INFO - 2016-09-07 08:13:26 --> Utf8 Class Initialized
INFO - 2016-09-07 08:13:26 --> URI Class Initialized
INFO - 2016-09-07 08:13:26 --> Router Class Initialized
INFO - 2016-09-07 08:13:26 --> Output Class Initialized
INFO - 2016-09-07 08:13:26 --> Security Class Initialized
DEBUG - 2016-09-07 08:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 08:13:26 --> Input Class Initialized
INFO - 2016-09-07 08:13:26 --> Language Class Initialized
INFO - 2016-09-07 08:13:26 --> Language Class Initialized
INFO - 2016-09-07 08:13:26 --> Config Class Initialized
INFO - 2016-09-07 08:13:26 --> Loader Class Initialized
INFO - 2016-09-07 08:13:26 --> Helper loaded: url_helper
INFO - 2016-09-07 08:13:26 --> Database Driver Class Initialized
INFO - 2016-09-07 08:13:27 --> Controller Class Initialized
DEBUG - 2016-09-07 08:13:27 --> Index MX_Controller Initialized
INFO - 2016-09-07 08:13:27 --> Model Class Initialized
INFO - 2016-09-07 08:13:27 --> Model Class Initialized
DEBUG - 2016-09-07 08:13:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 08:13:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 08:13:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 08:13:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 08:13:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 08:13:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 08:13:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 08:13:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 08:13:27 --> Final output sent to browser
DEBUG - 2016-09-07 08:13:27 --> Total execution time: 0.7170
INFO - 2016-09-07 08:15:53 --> Config Class Initialized
INFO - 2016-09-07 08:15:53 --> Hooks Class Initialized
DEBUG - 2016-09-07 08:15:53 --> UTF-8 Support Enabled
INFO - 2016-09-07 08:15:53 --> Utf8 Class Initialized
INFO - 2016-09-07 08:15:53 --> URI Class Initialized
INFO - 2016-09-07 08:15:53 --> Router Class Initialized
INFO - 2016-09-07 08:15:53 --> Output Class Initialized
INFO - 2016-09-07 08:15:53 --> Security Class Initialized
DEBUG - 2016-09-07 08:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 08:15:53 --> Input Class Initialized
INFO - 2016-09-07 08:15:53 --> Language Class Initialized
INFO - 2016-09-07 08:15:53 --> Language Class Initialized
INFO - 2016-09-07 08:15:53 --> Config Class Initialized
INFO - 2016-09-07 08:15:53 --> Loader Class Initialized
INFO - 2016-09-07 08:15:53 --> Helper loaded: url_helper
INFO - 2016-09-07 08:15:53 --> Database Driver Class Initialized
INFO - 2016-09-07 08:15:53 --> Controller Class Initialized
DEBUG - 2016-09-07 08:15:53 --> Index MX_Controller Initialized
INFO - 2016-09-07 08:15:53 --> Model Class Initialized
INFO - 2016-09-07 08:15:53 --> Model Class Initialized
DEBUG - 2016-09-07 08:15:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 08:15:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 08:15:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 08:15:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 08:15:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 08:15:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 08:15:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 08:15:53 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 08:15:53 --> Final output sent to browser
DEBUG - 2016-09-07 08:15:53 --> Total execution time: 0.7322
INFO - 2016-09-07 08:28:44 --> Config Class Initialized
INFO - 2016-09-07 08:28:45 --> Hooks Class Initialized
DEBUG - 2016-09-07 08:28:45 --> UTF-8 Support Enabled
INFO - 2016-09-07 08:28:45 --> Utf8 Class Initialized
INFO - 2016-09-07 08:28:45 --> URI Class Initialized
INFO - 2016-09-07 08:28:45 --> Router Class Initialized
INFO - 2016-09-07 08:28:45 --> Output Class Initialized
INFO - 2016-09-07 08:28:45 --> Security Class Initialized
DEBUG - 2016-09-07 08:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 08:28:45 --> Input Class Initialized
INFO - 2016-09-07 08:28:45 --> Language Class Initialized
INFO - 2016-09-07 08:28:45 --> Language Class Initialized
INFO - 2016-09-07 08:28:45 --> Config Class Initialized
INFO - 2016-09-07 08:28:45 --> Loader Class Initialized
INFO - 2016-09-07 08:28:45 --> Helper loaded: url_helper
INFO - 2016-09-07 08:28:45 --> Database Driver Class Initialized
INFO - 2016-09-07 08:28:45 --> Controller Class Initialized
DEBUG - 2016-09-07 08:28:45 --> Index MX_Controller Initialized
INFO - 2016-09-07 08:28:45 --> Model Class Initialized
INFO - 2016-09-07 08:28:45 --> Model Class Initialized
DEBUG - 2016-09-07 08:28:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 08:28:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 08:28:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 08:28:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 08:28:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 08:28:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 08:28:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 08:28:45 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 08:28:45 --> Final output sent to browser
DEBUG - 2016-09-07 08:28:45 --> Total execution time: 0.8841
INFO - 2016-09-07 08:30:12 --> Config Class Initialized
INFO - 2016-09-07 08:30:12 --> Hooks Class Initialized
DEBUG - 2016-09-07 08:30:12 --> UTF-8 Support Enabled
INFO - 2016-09-07 08:30:12 --> Utf8 Class Initialized
INFO - 2016-09-07 08:30:12 --> URI Class Initialized
INFO - 2016-09-07 08:30:12 --> Router Class Initialized
INFO - 2016-09-07 08:30:12 --> Output Class Initialized
INFO - 2016-09-07 08:30:12 --> Security Class Initialized
DEBUG - 2016-09-07 08:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 08:30:12 --> Input Class Initialized
INFO - 2016-09-07 08:30:12 --> Language Class Initialized
INFO - 2016-09-07 08:30:12 --> Language Class Initialized
INFO - 2016-09-07 08:30:12 --> Config Class Initialized
INFO - 2016-09-07 08:30:12 --> Loader Class Initialized
INFO - 2016-09-07 08:30:12 --> Helper loaded: url_helper
INFO - 2016-09-07 08:30:12 --> Database Driver Class Initialized
INFO - 2016-09-07 08:30:12 --> Controller Class Initialized
DEBUG - 2016-09-07 08:30:12 --> Index MX_Controller Initialized
INFO - 2016-09-07 08:30:12 --> Model Class Initialized
INFO - 2016-09-07 08:30:12 --> Model Class Initialized
DEBUG - 2016-09-07 08:30:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 08:30:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 08:30:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 08:30:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 08:30:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 08:30:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 08:30:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 08:30:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 08:30:12 --> Final output sent to browser
DEBUG - 2016-09-07 08:30:12 --> Total execution time: 0.7631
INFO - 2016-09-07 08:30:29 --> Config Class Initialized
INFO - 2016-09-07 08:30:29 --> Hooks Class Initialized
DEBUG - 2016-09-07 08:30:29 --> UTF-8 Support Enabled
INFO - 2016-09-07 08:30:29 --> Utf8 Class Initialized
INFO - 2016-09-07 08:30:29 --> URI Class Initialized
INFO - 2016-09-07 08:30:29 --> Router Class Initialized
INFO - 2016-09-07 08:30:29 --> Output Class Initialized
INFO - 2016-09-07 08:30:29 --> Security Class Initialized
DEBUG - 2016-09-07 08:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 08:30:29 --> Input Class Initialized
INFO - 2016-09-07 08:30:29 --> Language Class Initialized
INFO - 2016-09-07 08:30:29 --> Language Class Initialized
INFO - 2016-09-07 08:30:30 --> Config Class Initialized
INFO - 2016-09-07 08:30:30 --> Loader Class Initialized
INFO - 2016-09-07 08:30:30 --> Helper loaded: url_helper
INFO - 2016-09-07 08:30:30 --> Database Driver Class Initialized
INFO - 2016-09-07 08:30:30 --> Controller Class Initialized
DEBUG - 2016-09-07 08:30:30 --> Index MX_Controller Initialized
INFO - 2016-09-07 08:30:30 --> Model Class Initialized
INFO - 2016-09-07 08:30:30 --> Model Class Initialized
DEBUG - 2016-09-07 08:30:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 08:30:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 08:30:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 08:30:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 08:30:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 08:30:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 08:30:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 08:30:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 08:30:30 --> Final output sent to browser
DEBUG - 2016-09-07 08:30:30 --> Total execution time: 0.7702
INFO - 2016-09-07 08:30:40 --> Config Class Initialized
INFO - 2016-09-07 08:30:40 --> Hooks Class Initialized
DEBUG - 2016-09-07 08:30:40 --> UTF-8 Support Enabled
INFO - 2016-09-07 08:30:40 --> Utf8 Class Initialized
INFO - 2016-09-07 08:30:40 --> URI Class Initialized
INFO - 2016-09-07 08:30:40 --> Router Class Initialized
INFO - 2016-09-07 08:30:40 --> Output Class Initialized
INFO - 2016-09-07 08:30:40 --> Security Class Initialized
DEBUG - 2016-09-07 08:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 08:30:40 --> Input Class Initialized
INFO - 2016-09-07 08:30:40 --> Language Class Initialized
INFO - 2016-09-07 08:30:40 --> Language Class Initialized
INFO - 2016-09-07 08:30:40 --> Config Class Initialized
INFO - 2016-09-07 08:30:40 --> Loader Class Initialized
INFO - 2016-09-07 08:30:40 --> Helper loaded: url_helper
INFO - 2016-09-07 08:30:40 --> Database Driver Class Initialized
INFO - 2016-09-07 08:30:40 --> Controller Class Initialized
DEBUG - 2016-09-07 08:30:40 --> Index MX_Controller Initialized
INFO - 2016-09-07 08:30:40 --> Model Class Initialized
INFO - 2016-09-07 08:30:40 --> Model Class Initialized
DEBUG - 2016-09-07 08:30:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 08:30:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 08:30:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 08:30:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 08:30:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 08:30:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 08:30:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 08:30:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 08:30:41 --> Final output sent to browser
DEBUG - 2016-09-07 08:30:41 --> Total execution time: 0.7741
INFO - 2016-09-07 08:31:16 --> Config Class Initialized
INFO - 2016-09-07 08:31:16 --> Hooks Class Initialized
DEBUG - 2016-09-07 08:31:16 --> UTF-8 Support Enabled
INFO - 2016-09-07 08:31:16 --> Utf8 Class Initialized
INFO - 2016-09-07 08:31:16 --> URI Class Initialized
INFO - 2016-09-07 08:31:16 --> Router Class Initialized
INFO - 2016-09-07 08:31:16 --> Output Class Initialized
INFO - 2016-09-07 08:31:16 --> Security Class Initialized
DEBUG - 2016-09-07 08:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 08:31:16 --> Input Class Initialized
INFO - 2016-09-07 08:31:16 --> Language Class Initialized
INFO - 2016-09-07 08:31:16 --> Language Class Initialized
INFO - 2016-09-07 08:31:16 --> Config Class Initialized
INFO - 2016-09-07 08:31:16 --> Loader Class Initialized
INFO - 2016-09-07 08:31:16 --> Helper loaded: url_helper
INFO - 2016-09-07 08:31:16 --> Database Driver Class Initialized
INFO - 2016-09-07 08:31:16 --> Controller Class Initialized
DEBUG - 2016-09-07 08:31:16 --> Index MX_Controller Initialized
INFO - 2016-09-07 08:31:16 --> Model Class Initialized
INFO - 2016-09-07 08:31:16 --> Model Class Initialized
DEBUG - 2016-09-07 08:31:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 08:31:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 08:31:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 08:31:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 08:31:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 08:31:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 08:31:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 08:31:17 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 08:31:17 --> Final output sent to browser
DEBUG - 2016-09-07 08:31:17 --> Total execution time: 0.7713
INFO - 2016-09-07 08:31:26 --> Config Class Initialized
INFO - 2016-09-07 08:31:26 --> Hooks Class Initialized
DEBUG - 2016-09-07 08:31:27 --> UTF-8 Support Enabled
INFO - 2016-09-07 08:31:27 --> Utf8 Class Initialized
INFO - 2016-09-07 08:31:27 --> URI Class Initialized
INFO - 2016-09-07 08:31:27 --> Router Class Initialized
INFO - 2016-09-07 08:31:27 --> Output Class Initialized
INFO - 2016-09-07 08:31:27 --> Security Class Initialized
DEBUG - 2016-09-07 08:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 08:31:27 --> Input Class Initialized
INFO - 2016-09-07 08:31:27 --> Language Class Initialized
INFO - 2016-09-07 08:31:27 --> Language Class Initialized
INFO - 2016-09-07 08:31:27 --> Config Class Initialized
INFO - 2016-09-07 08:31:27 --> Loader Class Initialized
INFO - 2016-09-07 08:31:27 --> Helper loaded: url_helper
INFO - 2016-09-07 08:31:27 --> Database Driver Class Initialized
INFO - 2016-09-07 08:31:27 --> Controller Class Initialized
DEBUG - 2016-09-07 08:31:27 --> Index MX_Controller Initialized
INFO - 2016-09-07 08:31:27 --> Model Class Initialized
INFO - 2016-09-07 08:31:27 --> Model Class Initialized
DEBUG - 2016-09-07 08:31:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 08:31:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 08:31:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 08:31:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 08:31:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 08:31:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 08:31:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 08:31:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 08:31:27 --> Final output sent to browser
DEBUG - 2016-09-07 08:31:27 --> Total execution time: 0.8037
INFO - 2016-09-07 08:32:26 --> Config Class Initialized
INFO - 2016-09-07 08:32:26 --> Hooks Class Initialized
DEBUG - 2016-09-07 08:32:26 --> UTF-8 Support Enabled
INFO - 2016-09-07 08:32:26 --> Utf8 Class Initialized
INFO - 2016-09-07 08:32:26 --> URI Class Initialized
INFO - 2016-09-07 08:32:26 --> Router Class Initialized
INFO - 2016-09-07 08:32:26 --> Output Class Initialized
INFO - 2016-09-07 08:32:26 --> Security Class Initialized
DEBUG - 2016-09-07 08:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 08:32:26 --> Input Class Initialized
INFO - 2016-09-07 08:32:26 --> Language Class Initialized
INFO - 2016-09-07 08:32:26 --> Language Class Initialized
INFO - 2016-09-07 08:32:26 --> Config Class Initialized
INFO - 2016-09-07 08:32:26 --> Loader Class Initialized
INFO - 2016-09-07 08:32:26 --> Helper loaded: url_helper
INFO - 2016-09-07 08:32:26 --> Database Driver Class Initialized
INFO - 2016-09-07 08:32:26 --> Controller Class Initialized
DEBUG - 2016-09-07 08:32:26 --> Index MX_Controller Initialized
INFO - 2016-09-07 08:32:26 --> Model Class Initialized
INFO - 2016-09-07 08:32:26 --> Model Class Initialized
DEBUG - 2016-09-07 08:32:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 08:32:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 08:32:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 08:32:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 08:32:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 08:32:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 08:32:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 08:32:27 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 08:32:27 --> Final output sent to browser
DEBUG - 2016-09-07 08:32:27 --> Total execution time: 0.8613
INFO - 2016-09-07 08:32:44 --> Config Class Initialized
INFO - 2016-09-07 08:32:44 --> Hooks Class Initialized
DEBUG - 2016-09-07 08:32:44 --> UTF-8 Support Enabled
INFO - 2016-09-07 08:32:44 --> Utf8 Class Initialized
INFO - 2016-09-07 08:32:44 --> URI Class Initialized
INFO - 2016-09-07 08:32:44 --> Router Class Initialized
INFO - 2016-09-07 08:32:44 --> Output Class Initialized
INFO - 2016-09-07 08:32:44 --> Security Class Initialized
DEBUG - 2016-09-07 08:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 08:32:44 --> Input Class Initialized
INFO - 2016-09-07 08:32:44 --> Language Class Initialized
INFO - 2016-09-07 08:32:44 --> Language Class Initialized
INFO - 2016-09-07 08:32:44 --> Config Class Initialized
INFO - 2016-09-07 08:32:44 --> Loader Class Initialized
INFO - 2016-09-07 08:32:44 --> Helper loaded: url_helper
INFO - 2016-09-07 08:32:44 --> Database Driver Class Initialized
INFO - 2016-09-07 08:32:44 --> Controller Class Initialized
DEBUG - 2016-09-07 08:32:44 --> Anggota MX_Controller Initialized
INFO - 2016-09-07 08:32:44 --> Model Class Initialized
INFO - 2016-09-07 08:32:44 --> Model Class Initialized
ERROR - 2016-09-07 08:32:44 --> Severity: Notice --> Undefined index: nama_anggota E:\SERVER\htdocs\koperasiweda\application\modules\Anggota\controllers\Anggota.php 18
ERROR - 2016-09-07 08:32:44 --> Severity: Notice --> Undefined index: nama_anggota E:\SERVER\htdocs\koperasiweda\application\modules\Anggota\controllers\Anggota.php 19
ERROR - 2016-09-07 08:32:44 --> Severity: Notice --> Undefined index: tanggal_lahir E:\SERVER\htdocs\koperasiweda\application\modules\Anggota\controllers\Anggota.php 20
ERROR - 2016-09-07 08:32:44 --> Severity: Notice --> Undefined index: tanggal_masuk E:\SERVER\htdocs\koperasiweda\application\modules\Anggota\controllers\Anggota.php 21
ERROR - 2016-09-07 08:32:44 --> Severity: Notice --> Undefined index: tanggal_daftar E:\SERVER\htdocs\koperasiweda\application\modules\Anggota\controllers\Anggota.php 22
ERROR - 2016-09-07 08:32:44 --> Severity: Notice --> Undefined index: no_identitas E:\SERVER\htdocs\koperasiweda\application\modules\Anggota\controllers\Anggota.php 23
ERROR - 2016-09-07 08:32:44 --> Severity: Notice --> Undefined index: no_karyawan E:\SERVER\htdocs\koperasiweda\application\modules\Anggota\controllers\Anggota.php 24
ERROR - 2016-09-07 08:32:44 --> Severity: Notice --> Undefined index: kd_user E:\SERVER\htdocs\koperasiweda\application\modules\Anggota\controllers\Anggota.php 25
ERROR - 2016-09-07 08:32:44 --> Severity: Notice --> Undefined property: CI::$table_prefix E:\SERVER\htdocs\koperasiweda\system\core\Model.php 77
ERROR - 2016-09-07 08:32:44 --> Query error: Unknown column 'nama' in 'field list' - Invalid query: INSERT INTO `tm_anggota` (`nama`, `alamat`, `tanggal_lahir`, `tanggal_masuk`, `tanggal_daftar`, `no_identitas`, `no_karyawan`, `kd_user`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
INFO - 2016-09-07 08:32:44 --> Language file loaded: language/english/db_lang.php
ERROR - 2016-09-07 08:32:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\SERVER\htdocs\koperasiweda\system\core\Exceptions.php:272) E:\SERVER\htdocs\koperasiweda\system\core\Common.php 569
INFO - 2016-09-07 08:34:37 --> Config Class Initialized
INFO - 2016-09-07 08:34:37 --> Hooks Class Initialized
DEBUG - 2016-09-07 08:34:37 --> UTF-8 Support Enabled
INFO - 2016-09-07 08:34:37 --> Utf8 Class Initialized
INFO - 2016-09-07 08:34:37 --> URI Class Initialized
INFO - 2016-09-07 08:34:37 --> Router Class Initialized
INFO - 2016-09-07 08:34:37 --> Output Class Initialized
INFO - 2016-09-07 08:34:37 --> Security Class Initialized
DEBUG - 2016-09-07 08:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 08:34:37 --> Input Class Initialized
INFO - 2016-09-07 08:34:37 --> Language Class Initialized
INFO - 2016-09-07 08:34:37 --> Language Class Initialized
INFO - 2016-09-07 08:34:37 --> Config Class Initialized
INFO - 2016-09-07 08:34:37 --> Loader Class Initialized
INFO - 2016-09-07 08:34:37 --> Helper loaded: url_helper
INFO - 2016-09-07 08:34:37 --> Database Driver Class Initialized
INFO - 2016-09-07 08:34:37 --> Controller Class Initialized
DEBUG - 2016-09-07 08:34:37 --> Index MX_Controller Initialized
INFO - 2016-09-07 08:34:37 --> Model Class Initialized
INFO - 2016-09-07 08:34:37 --> Model Class Initialized
DEBUG - 2016-09-07 08:34:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 08:34:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 08:34:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 08:34:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 08:34:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 08:34:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 08:34:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 08:34:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 08:34:38 --> Final output sent to browser
DEBUG - 2016-09-07 08:34:38 --> Total execution time: 0.7857
INFO - 2016-09-07 08:34:51 --> Config Class Initialized
INFO - 2016-09-07 08:34:51 --> Hooks Class Initialized
DEBUG - 2016-09-07 08:34:51 --> UTF-8 Support Enabled
INFO - 2016-09-07 08:34:51 --> Utf8 Class Initialized
INFO - 2016-09-07 08:34:51 --> URI Class Initialized
INFO - 2016-09-07 08:34:51 --> Router Class Initialized
INFO - 2016-09-07 08:34:51 --> Output Class Initialized
INFO - 2016-09-07 08:34:51 --> Security Class Initialized
DEBUG - 2016-09-07 08:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 08:34:51 --> Input Class Initialized
INFO - 2016-09-07 08:34:51 --> Language Class Initialized
INFO - 2016-09-07 08:34:51 --> Language Class Initialized
INFO - 2016-09-07 08:34:51 --> Config Class Initialized
INFO - 2016-09-07 08:34:51 --> Loader Class Initialized
INFO - 2016-09-07 08:34:51 --> Helper loaded: url_helper
INFO - 2016-09-07 08:34:51 --> Database Driver Class Initialized
INFO - 2016-09-07 08:34:51 --> Controller Class Initialized
DEBUG - 2016-09-07 08:34:51 --> Anggota MX_Controller Initialized
INFO - 2016-09-07 08:34:51 --> Model Class Initialized
INFO - 2016-09-07 08:34:51 --> Model Class Initialized
ERROR - 2016-09-07 08:34:51 --> Severity: Notice --> Undefined index: alamat E:\SERVER\htdocs\koperasiweda\application\modules\Anggota\controllers\Anggota.php 19
ERROR - 2016-09-07 08:34:51 --> Severity: Notice --> Undefined property: CI::$table_prefix E:\SERVER\htdocs\koperasiweda\system\core\Model.php 77
ERROR - 2016-09-07 08:34:51 --> Query error: Unknown column 'nama' in 'field list' - Invalid query: INSERT INTO `tm_anggota` (`nama`, `alamat`, `tanggal_lahir`, `tanggal_masuk`, `tanggal_daftar`, `no_identitas`, `no_karyawan`, `kd_user`) VALUES ('Muhammad Handharbeni', NULL, '20/02/1993', '01/01/2001', '2016-09-07', '3573032002930011', '0', 0)
INFO - 2016-09-07 08:34:51 --> Language file loaded: language/english/db_lang.php
INFO - 2016-09-07 08:35:57 --> Config Class Initialized
INFO - 2016-09-07 08:35:57 --> Hooks Class Initialized
DEBUG - 2016-09-07 08:35:57 --> UTF-8 Support Enabled
INFO - 2016-09-07 08:35:57 --> Utf8 Class Initialized
INFO - 2016-09-07 08:35:57 --> URI Class Initialized
INFO - 2016-09-07 08:35:57 --> Router Class Initialized
INFO - 2016-09-07 08:35:58 --> Output Class Initialized
INFO - 2016-09-07 08:35:58 --> Security Class Initialized
DEBUG - 2016-09-07 08:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 08:35:58 --> Input Class Initialized
INFO - 2016-09-07 08:35:58 --> Language Class Initialized
INFO - 2016-09-07 08:35:58 --> Language Class Initialized
INFO - 2016-09-07 08:35:58 --> Config Class Initialized
INFO - 2016-09-07 08:35:58 --> Loader Class Initialized
INFO - 2016-09-07 08:35:58 --> Helper loaded: url_helper
INFO - 2016-09-07 08:35:58 --> Database Driver Class Initialized
INFO - 2016-09-07 08:35:58 --> Controller Class Initialized
DEBUG - 2016-09-07 08:35:58 --> Index MX_Controller Initialized
INFO - 2016-09-07 08:35:58 --> Model Class Initialized
INFO - 2016-09-07 08:35:58 --> Model Class Initialized
DEBUG - 2016-09-07 08:35:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 08:35:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 08:35:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 08:35:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 08:35:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 08:35:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 08:35:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 08:35:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 08:35:58 --> Final output sent to browser
DEBUG - 2016-09-07 08:35:58 --> Total execution time: 0.8214
INFO - 2016-09-07 08:36:11 --> Config Class Initialized
INFO - 2016-09-07 08:36:11 --> Hooks Class Initialized
DEBUG - 2016-09-07 08:36:11 --> UTF-8 Support Enabled
INFO - 2016-09-07 08:36:11 --> Utf8 Class Initialized
INFO - 2016-09-07 08:36:11 --> URI Class Initialized
INFO - 2016-09-07 08:36:11 --> Router Class Initialized
INFO - 2016-09-07 08:36:11 --> Output Class Initialized
INFO - 2016-09-07 08:36:11 --> Security Class Initialized
DEBUG - 2016-09-07 08:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 08:36:11 --> Input Class Initialized
INFO - 2016-09-07 08:36:11 --> Language Class Initialized
INFO - 2016-09-07 08:36:11 --> Language Class Initialized
INFO - 2016-09-07 08:36:11 --> Config Class Initialized
INFO - 2016-09-07 08:36:11 --> Loader Class Initialized
INFO - 2016-09-07 08:36:11 --> Helper loaded: url_helper
INFO - 2016-09-07 08:36:11 --> Database Driver Class Initialized
INFO - 2016-09-07 08:36:11 --> Controller Class Initialized
DEBUG - 2016-09-07 08:36:11 --> Anggota MX_Controller Initialized
INFO - 2016-09-07 08:36:11 --> Model Class Initialized
INFO - 2016-09-07 08:36:11 --> Model Class Initialized
ERROR - 2016-09-07 08:36:11 --> Severity: Notice --> Undefined index: alamat E:\SERVER\htdocs\koperasiweda\application\modules\Anggota\controllers\Anggota.php 19
ERROR - 2016-09-07 08:36:11 --> Severity: Notice --> Undefined property: CI::$table_prefix E:\SERVER\htdocs\koperasiweda\system\core\Model.php 77
ERROR - 2016-09-07 08:36:11 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`koperasi`.`tm_anggota`, CONSTRAINT `FK_tm_anggota_tm_user` FOREIGN KEY (`kd_user`) REFERENCES `tm_user` (`kd_user`)) - Invalid query: INSERT INTO `tm_anggota` (`nama_anggota`, `alamat_anggota`, `tanggal_lahir`, `tanggal_masuk`, `tanggal_daftar`, `no_identitas`, `no_karyawan`, `kd_user`) VALUES ('Muhammad Handharbeni', NULL, '20/02/1993', '01/01/2001', '2016-09-07', '3573032002930011', '0', 0)
INFO - 2016-09-07 08:36:12 --> Language file loaded: language/english/db_lang.php
INFO - 2016-09-07 08:36:51 --> Config Class Initialized
INFO - 2016-09-07 08:36:51 --> Hooks Class Initialized
DEBUG - 2016-09-07 08:36:51 --> UTF-8 Support Enabled
INFO - 2016-09-07 08:36:51 --> Utf8 Class Initialized
INFO - 2016-09-07 08:36:51 --> URI Class Initialized
INFO - 2016-09-07 08:36:51 --> Router Class Initialized
INFO - 2016-09-07 08:36:51 --> Output Class Initialized
INFO - 2016-09-07 08:36:51 --> Security Class Initialized
DEBUG - 2016-09-07 08:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 08:36:51 --> Input Class Initialized
INFO - 2016-09-07 08:36:51 --> Language Class Initialized
INFO - 2016-09-07 08:36:51 --> Language Class Initialized
INFO - 2016-09-07 08:36:51 --> Config Class Initialized
INFO - 2016-09-07 08:36:51 --> Loader Class Initialized
INFO - 2016-09-07 08:36:51 --> Helper loaded: url_helper
INFO - 2016-09-07 08:36:51 --> Database Driver Class Initialized
INFO - 2016-09-07 08:36:51 --> Controller Class Initialized
DEBUG - 2016-09-07 08:36:51 --> Index MX_Controller Initialized
INFO - 2016-09-07 08:36:51 --> Model Class Initialized
INFO - 2016-09-07 08:36:51 --> Model Class Initialized
DEBUG - 2016-09-07 08:36:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 08:36:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 08:36:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 08:36:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 08:36:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 08:36:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 08:36:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 08:36:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 08:36:51 --> Final output sent to browser
DEBUG - 2016-09-07 08:36:51 --> Total execution time: 0.7569
INFO - 2016-09-07 08:37:14 --> Config Class Initialized
INFO - 2016-09-07 08:37:14 --> Hooks Class Initialized
DEBUG - 2016-09-07 08:37:14 --> UTF-8 Support Enabled
INFO - 2016-09-07 08:37:14 --> Utf8 Class Initialized
INFO - 2016-09-07 08:37:14 --> URI Class Initialized
INFO - 2016-09-07 08:37:14 --> Router Class Initialized
INFO - 2016-09-07 08:37:14 --> Output Class Initialized
INFO - 2016-09-07 08:37:14 --> Security Class Initialized
DEBUG - 2016-09-07 08:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 08:37:14 --> Input Class Initialized
INFO - 2016-09-07 08:37:14 --> Language Class Initialized
INFO - 2016-09-07 08:37:14 --> Language Class Initialized
INFO - 2016-09-07 08:37:14 --> Config Class Initialized
INFO - 2016-09-07 08:37:14 --> Loader Class Initialized
INFO - 2016-09-07 08:37:14 --> Helper loaded: url_helper
INFO - 2016-09-07 08:37:14 --> Database Driver Class Initialized
INFO - 2016-09-07 08:37:15 --> Controller Class Initialized
DEBUG - 2016-09-07 08:37:15 --> Anggota MX_Controller Initialized
INFO - 2016-09-07 08:37:15 --> Model Class Initialized
INFO - 2016-09-07 08:37:15 --> Model Class Initialized
ERROR - 2016-09-07 08:37:15 --> Severity: Notice --> Undefined property: CI::$table_prefix E:\SERVER\htdocs\koperasiweda\system\core\Model.php 77
ERROR - 2016-09-07 08:37:15 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`koperasi`.`tm_anggota`, CONSTRAINT `FK_tm_anggota_tm_user` FOREIGN KEY (`kd_user`) REFERENCES `tm_user` (`kd_user`)) - Invalid query: INSERT INTO `tm_anggota` (`nama_anggota`, `alamat_anggota`, `tanggal_lahir`, `tanggal_masuk`, `tanggal_daftar`, `no_identitas`, `no_karyawan`, `kd_user`) VALUES ('Muhammad Handharbeni', 'Puri Cempaka Putih AS 20', '20/02/1993', '01/01/2001', '2016-09-07', '3573032002930011', '0', 0)
INFO - 2016-09-07 08:37:15 --> Language file loaded: language/english/db_lang.php
INFO - 2016-09-07 08:38:39 --> Config Class Initialized
INFO - 2016-09-07 08:38:39 --> Hooks Class Initialized
DEBUG - 2016-09-07 08:38:39 --> UTF-8 Support Enabled
INFO - 2016-09-07 08:38:39 --> Utf8 Class Initialized
INFO - 2016-09-07 08:38:39 --> URI Class Initialized
INFO - 2016-09-07 08:38:39 --> Router Class Initialized
INFO - 2016-09-07 08:38:39 --> Output Class Initialized
INFO - 2016-09-07 08:38:39 --> Security Class Initialized
DEBUG - 2016-09-07 08:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 08:38:39 --> Input Class Initialized
INFO - 2016-09-07 08:38:39 --> Language Class Initialized
INFO - 2016-09-07 08:38:39 --> Language Class Initialized
INFO - 2016-09-07 08:38:39 --> Config Class Initialized
INFO - 2016-09-07 08:38:39 --> Loader Class Initialized
INFO - 2016-09-07 08:38:39 --> Helper loaded: url_helper
INFO - 2016-09-07 08:38:39 --> Database Driver Class Initialized
INFO - 2016-09-07 08:38:39 --> Controller Class Initialized
DEBUG - 2016-09-07 08:38:39 --> Index MX_Controller Initialized
INFO - 2016-09-07 08:38:39 --> Model Class Initialized
INFO - 2016-09-07 08:38:39 --> Model Class Initialized
DEBUG - 2016-09-07 08:38:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 08:38:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 08:38:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 08:38:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 08:38:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 08:38:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 08:38:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 08:38:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 08:38:39 --> Final output sent to browser
DEBUG - 2016-09-07 08:38:39 --> Total execution time: 0.7729
INFO - 2016-09-07 08:39:38 --> Config Class Initialized
INFO - 2016-09-07 08:39:38 --> Hooks Class Initialized
DEBUG - 2016-09-07 08:39:38 --> UTF-8 Support Enabled
INFO - 2016-09-07 08:39:38 --> Utf8 Class Initialized
INFO - 2016-09-07 08:39:38 --> URI Class Initialized
INFO - 2016-09-07 08:39:38 --> Router Class Initialized
INFO - 2016-09-07 08:39:38 --> Output Class Initialized
INFO - 2016-09-07 08:39:38 --> Security Class Initialized
DEBUG - 2016-09-07 08:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 08:39:38 --> Input Class Initialized
INFO - 2016-09-07 08:39:38 --> Language Class Initialized
INFO - 2016-09-07 08:39:38 --> Language Class Initialized
INFO - 2016-09-07 08:39:38 --> Config Class Initialized
INFO - 2016-09-07 08:39:38 --> Loader Class Initialized
INFO - 2016-09-07 08:39:38 --> Helper loaded: url_helper
INFO - 2016-09-07 08:39:38 --> Database Driver Class Initialized
INFO - 2016-09-07 08:39:38 --> Controller Class Initialized
DEBUG - 2016-09-07 08:39:38 --> Anggota MX_Controller Initialized
INFO - 2016-09-07 08:39:38 --> Model Class Initialized
INFO - 2016-09-07 08:39:38 --> Model Class Initialized
ERROR - 2016-09-07 08:39:38 --> Severity: Notice --> Undefined property: CI::$table_prefix E:\SERVER\htdocs\koperasiweda\system\core\Model.php 77
INFO - 2016-09-07 08:39:39 --> Final output sent to browser
DEBUG - 2016-09-07 08:39:39 --> Total execution time: 0.7154
INFO - 2016-09-07 08:42:23 --> Config Class Initialized
INFO - 2016-09-07 08:42:23 --> Hooks Class Initialized
DEBUG - 2016-09-07 08:42:23 --> UTF-8 Support Enabled
INFO - 2016-09-07 08:42:23 --> Utf8 Class Initialized
INFO - 2016-09-07 08:42:23 --> URI Class Initialized
INFO - 2016-09-07 08:42:23 --> Router Class Initialized
INFO - 2016-09-07 08:42:23 --> Output Class Initialized
INFO - 2016-09-07 08:42:23 --> Security Class Initialized
DEBUG - 2016-09-07 08:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 08:42:23 --> Input Class Initialized
INFO - 2016-09-07 08:42:23 --> Language Class Initialized
INFO - 2016-09-07 08:42:23 --> Language Class Initialized
INFO - 2016-09-07 08:42:23 --> Config Class Initialized
INFO - 2016-09-07 08:42:23 --> Loader Class Initialized
INFO - 2016-09-07 08:42:23 --> Helper loaded: url_helper
INFO - 2016-09-07 08:42:23 --> Database Driver Class Initialized
INFO - 2016-09-07 08:42:23 --> Controller Class Initialized
DEBUG - 2016-09-07 08:42:23 --> Index MX_Controller Initialized
INFO - 2016-09-07 08:42:23 --> Model Class Initialized
INFO - 2016-09-07 08:42:23 --> Model Class Initialized
ERROR - 2016-09-07 08:42:23 --> Severity: Warning --> require(./anggota/Anggota.php): failed to open stream: No such file or directory E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 7
ERROR - 2016-09-07 08:42:23 --> Severity: Compile Error --> require(): Failed opening required './anggota/Anggota.php' (include_path='E:\SERVER\php\PEAR') E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 7
INFO - 2016-09-07 08:42:30 --> Config Class Initialized
INFO - 2016-09-07 08:42:30 --> Hooks Class Initialized
DEBUG - 2016-09-07 08:42:30 --> UTF-8 Support Enabled
INFO - 2016-09-07 08:42:30 --> Utf8 Class Initialized
INFO - 2016-09-07 08:42:30 --> URI Class Initialized
INFO - 2016-09-07 08:42:30 --> Router Class Initialized
INFO - 2016-09-07 08:42:30 --> Output Class Initialized
INFO - 2016-09-07 08:42:30 --> Security Class Initialized
DEBUG - 2016-09-07 08:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 08:42:30 --> Input Class Initialized
INFO - 2016-09-07 08:42:30 --> Language Class Initialized
INFO - 2016-09-07 08:42:30 --> Language Class Initialized
INFO - 2016-09-07 08:42:30 --> Config Class Initialized
INFO - 2016-09-07 08:42:31 --> Loader Class Initialized
INFO - 2016-09-07 08:42:31 --> Helper loaded: url_helper
INFO - 2016-09-07 08:42:31 --> Database Driver Class Initialized
INFO - 2016-09-07 08:42:31 --> Controller Class Initialized
DEBUG - 2016-09-07 08:42:31 --> Index MX_Controller Initialized
INFO - 2016-09-07 08:42:31 --> Model Class Initialized
INFO - 2016-09-07 08:42:31 --> Model Class Initialized
ERROR - 2016-09-07 08:42:31 --> Severity: Warning --> require(../anggota/Anggota.php): failed to open stream: No such file or directory E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 7
ERROR - 2016-09-07 08:42:31 --> Severity: Compile Error --> require(): Failed opening required '../anggota/Anggota.php' (include_path='E:\SERVER\php\PEAR') E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 7
INFO - 2016-09-07 08:42:36 --> Config Class Initialized
INFO - 2016-09-07 08:42:37 --> Hooks Class Initialized
DEBUG - 2016-09-07 08:42:37 --> UTF-8 Support Enabled
INFO - 2016-09-07 08:42:37 --> Utf8 Class Initialized
INFO - 2016-09-07 08:42:37 --> URI Class Initialized
INFO - 2016-09-07 08:42:37 --> Router Class Initialized
INFO - 2016-09-07 08:42:37 --> Output Class Initialized
INFO - 2016-09-07 08:42:37 --> Security Class Initialized
DEBUG - 2016-09-07 08:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 08:42:37 --> Input Class Initialized
INFO - 2016-09-07 08:42:37 --> Language Class Initialized
INFO - 2016-09-07 08:42:37 --> Language Class Initialized
INFO - 2016-09-07 08:42:37 --> Config Class Initialized
INFO - 2016-09-07 08:42:37 --> Loader Class Initialized
INFO - 2016-09-07 08:42:37 --> Helper loaded: url_helper
INFO - 2016-09-07 08:42:37 --> Database Driver Class Initialized
INFO - 2016-09-07 08:42:37 --> Controller Class Initialized
DEBUG - 2016-09-07 08:42:37 --> Index MX_Controller Initialized
INFO - 2016-09-07 08:42:37 --> Model Class Initialized
INFO - 2016-09-07 08:42:37 --> Model Class Initialized
ERROR - 2016-09-07 08:42:37 --> Severity: Warning --> require(anggota/Anggota.php): failed to open stream: No such file or directory E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 7
ERROR - 2016-09-07 08:42:37 --> Severity: Compile Error --> require(): Failed opening required 'anggota/Anggota.php' (include_path='E:\SERVER\php\PEAR') E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 7
INFO - 2016-09-07 08:43:05 --> Config Class Initialized
INFO - 2016-09-07 08:43:05 --> Hooks Class Initialized
DEBUG - 2016-09-07 08:43:05 --> UTF-8 Support Enabled
INFO - 2016-09-07 08:43:05 --> Utf8 Class Initialized
INFO - 2016-09-07 08:43:05 --> URI Class Initialized
INFO - 2016-09-07 08:43:05 --> Router Class Initialized
INFO - 2016-09-07 08:43:05 --> Output Class Initialized
INFO - 2016-09-07 08:43:05 --> Security Class Initialized
DEBUG - 2016-09-07 08:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 08:43:05 --> Input Class Initialized
INFO - 2016-09-07 08:43:05 --> Language Class Initialized
INFO - 2016-09-07 08:43:05 --> Language Class Initialized
INFO - 2016-09-07 08:43:05 --> Config Class Initialized
INFO - 2016-09-07 08:43:05 --> Loader Class Initialized
INFO - 2016-09-07 08:43:05 --> Helper loaded: url_helper
INFO - 2016-09-07 08:43:05 --> Database Driver Class Initialized
INFO - 2016-09-07 08:43:05 --> Controller Class Initialized
DEBUG - 2016-09-07 08:43:05 --> Index MX_Controller Initialized
INFO - 2016-09-07 08:43:05 --> Model Class Initialized
INFO - 2016-09-07 08:43:05 --> Model Class Initialized
ERROR - 2016-09-07 08:43:05 --> Severity: Warning --> require(anggota/controllers/Anggota.php): failed to open stream: No such file or directory E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 7
ERROR - 2016-09-07 08:43:05 --> Severity: Compile Error --> require(): Failed opening required 'anggota/controllers/Anggota.php' (include_path='E:\SERVER\php\PEAR') E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 7
INFO - 2016-09-07 08:43:09 --> Config Class Initialized
INFO - 2016-09-07 08:43:09 --> Hooks Class Initialized
DEBUG - 2016-09-07 08:43:09 --> UTF-8 Support Enabled
INFO - 2016-09-07 08:43:09 --> Utf8 Class Initialized
INFO - 2016-09-07 08:43:09 --> URI Class Initialized
INFO - 2016-09-07 08:43:09 --> Router Class Initialized
INFO - 2016-09-07 08:43:09 --> Output Class Initialized
INFO - 2016-09-07 08:43:09 --> Security Class Initialized
DEBUG - 2016-09-07 08:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 08:43:09 --> Input Class Initialized
INFO - 2016-09-07 08:43:09 --> Language Class Initialized
INFO - 2016-09-07 08:43:09 --> Language Class Initialized
INFO - 2016-09-07 08:43:09 --> Config Class Initialized
INFO - 2016-09-07 08:43:09 --> Loader Class Initialized
INFO - 2016-09-07 08:43:09 --> Helper loaded: url_helper
INFO - 2016-09-07 08:43:09 --> Database Driver Class Initialized
INFO - 2016-09-07 08:43:09 --> Controller Class Initialized
DEBUG - 2016-09-07 08:43:09 --> Index MX_Controller Initialized
INFO - 2016-09-07 08:43:09 --> Model Class Initialized
INFO - 2016-09-07 08:43:10 --> Model Class Initialized
ERROR - 2016-09-07 08:43:10 --> Severity: Warning --> require(../anggota/controllers/Anggota.php): failed to open stream: No such file or directory E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 7
ERROR - 2016-09-07 08:43:10 --> Severity: Compile Error --> require(): Failed opening required '../anggota/controllers/Anggota.php' (include_path='E:\SERVER\php\PEAR') E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 7
INFO - 2016-09-07 08:43:38 --> Config Class Initialized
INFO - 2016-09-07 08:43:38 --> Hooks Class Initialized
DEBUG - 2016-09-07 08:43:38 --> UTF-8 Support Enabled
INFO - 2016-09-07 08:43:38 --> Utf8 Class Initialized
INFO - 2016-09-07 08:43:38 --> URI Class Initialized
INFO - 2016-09-07 08:43:38 --> Router Class Initialized
INFO - 2016-09-07 08:43:38 --> Output Class Initialized
INFO - 2016-09-07 08:43:38 --> Security Class Initialized
DEBUG - 2016-09-07 08:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 08:43:38 --> Input Class Initialized
INFO - 2016-09-07 08:43:38 --> Language Class Initialized
INFO - 2016-09-07 08:43:38 --> Language Class Initialized
INFO - 2016-09-07 08:43:38 --> Config Class Initialized
INFO - 2016-09-07 08:43:38 --> Loader Class Initialized
INFO - 2016-09-07 08:43:38 --> Helper loaded: url_helper
INFO - 2016-09-07 08:43:38 --> Database Driver Class Initialized
INFO - 2016-09-07 08:43:38 --> Controller Class Initialized
DEBUG - 2016-09-07 08:43:38 --> Index MX_Controller Initialized
INFO - 2016-09-07 08:43:38 --> Model Class Initialized
INFO - 2016-09-07 08:43:38 --> Model Class Initialized
ERROR - 2016-09-07 08:43:38 --> Severity: Warning --> require(E:/SERVER/htdocs/koperasiweda/system/../anggota/controllers/Anggota.php): failed to open stream: No such file or directory E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 7
ERROR - 2016-09-07 08:43:38 --> Severity: Compile Error --> require(): Failed opening required 'E:/SERVER/htdocs/koperasiweda/system/../anggota/controllers/Anggota.php' (include_path='E:\SERVER\php\PEAR') E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 7
INFO - 2016-09-07 08:43:49 --> Config Class Initialized
INFO - 2016-09-07 08:43:49 --> Hooks Class Initialized
DEBUG - 2016-09-07 08:43:49 --> UTF-8 Support Enabled
INFO - 2016-09-07 08:43:49 --> Utf8 Class Initialized
INFO - 2016-09-07 08:43:49 --> URI Class Initialized
INFO - 2016-09-07 08:43:49 --> Router Class Initialized
INFO - 2016-09-07 08:43:49 --> Output Class Initialized
INFO - 2016-09-07 08:43:49 --> Security Class Initialized
DEBUG - 2016-09-07 08:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 08:43:49 --> Input Class Initialized
INFO - 2016-09-07 08:43:49 --> Language Class Initialized
INFO - 2016-09-07 08:43:49 --> Language Class Initialized
INFO - 2016-09-07 08:43:49 --> Config Class Initialized
INFO - 2016-09-07 08:43:49 --> Loader Class Initialized
INFO - 2016-09-07 08:43:49 --> Helper loaded: url_helper
INFO - 2016-09-07 08:43:49 --> Database Driver Class Initialized
INFO - 2016-09-07 08:43:49 --> Controller Class Initialized
DEBUG - 2016-09-07 08:43:49 --> Index MX_Controller Initialized
INFO - 2016-09-07 08:43:49 --> Model Class Initialized
INFO - 2016-09-07 08:43:49 --> Model Class Initialized
ERROR - 2016-09-07 08:43:49 --> Severity: Warning --> require(E:\SERVER\htdocs\koperasiweda\application\../anggota/controllers/Anggota.php): failed to open stream: No such file or directory E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 7
ERROR - 2016-09-07 08:43:49 --> Severity: Compile Error --> require(): Failed opening required 'E:\SERVER\htdocs\koperasiweda\application\../anggota/controllers/Anggota.php' (include_path='E:\SERVER\php\PEAR') E:\SERVER\htdocs\koperasiweda\application\modules\Admin\controllers\Index.php 7
INFO - 2016-09-07 08:44:10 --> Config Class Initialized
INFO - 2016-09-07 08:44:10 --> Hooks Class Initialized
DEBUG - 2016-09-07 08:44:10 --> UTF-8 Support Enabled
INFO - 2016-09-07 08:44:10 --> Utf8 Class Initialized
INFO - 2016-09-07 08:44:10 --> URI Class Initialized
INFO - 2016-09-07 08:44:10 --> Router Class Initialized
INFO - 2016-09-07 08:44:10 --> Output Class Initialized
INFO - 2016-09-07 08:44:10 --> Security Class Initialized
DEBUG - 2016-09-07 08:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 08:44:11 --> Input Class Initialized
INFO - 2016-09-07 08:44:11 --> Language Class Initialized
INFO - 2016-09-07 08:44:11 --> Language Class Initialized
INFO - 2016-09-07 08:44:11 --> Config Class Initialized
INFO - 2016-09-07 08:44:11 --> Loader Class Initialized
INFO - 2016-09-07 08:44:11 --> Helper loaded: url_helper
INFO - 2016-09-07 08:44:11 --> Database Driver Class Initialized
INFO - 2016-09-07 08:44:11 --> Controller Class Initialized
DEBUG - 2016-09-07 08:44:11 --> Index MX_Controller Initialized
INFO - 2016-09-07 08:44:11 --> Model Class Initialized
INFO - 2016-09-07 08:44:11 --> Model Class Initialized
DEBUG - 2016-09-07 08:44:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 08:44:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 08:44:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 08:44:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 08:44:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 08:44:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 08:44:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 08:44:11 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 08:44:11 --> Final output sent to browser
DEBUG - 2016-09-07 08:44:11 --> Total execution time: 0.7609
INFO - 2016-09-07 08:44:24 --> Config Class Initialized
INFO - 2016-09-07 08:44:24 --> Hooks Class Initialized
DEBUG - 2016-09-07 08:44:24 --> UTF-8 Support Enabled
INFO - 2016-09-07 08:44:24 --> Utf8 Class Initialized
INFO - 2016-09-07 08:44:24 --> URI Class Initialized
INFO - 2016-09-07 08:44:24 --> Router Class Initialized
INFO - 2016-09-07 08:44:24 --> Output Class Initialized
INFO - 2016-09-07 08:44:24 --> Security Class Initialized
DEBUG - 2016-09-07 08:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 08:44:24 --> Input Class Initialized
INFO - 2016-09-07 08:44:24 --> Language Class Initialized
INFO - 2016-09-07 08:44:24 --> Language Class Initialized
INFO - 2016-09-07 08:44:24 --> Config Class Initialized
INFO - 2016-09-07 08:44:24 --> Loader Class Initialized
INFO - 2016-09-07 08:44:24 --> Helper loaded: url_helper
INFO - 2016-09-07 08:44:24 --> Database Driver Class Initialized
INFO - 2016-09-07 08:44:25 --> Controller Class Initialized
DEBUG - 2016-09-07 08:44:25 --> Index MX_Controller Initialized
INFO - 2016-09-07 08:44:25 --> Model Class Initialized
INFO - 2016-09-07 08:44:25 --> Model Class Initialized
DEBUG - 2016-09-07 08:44:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 08:44:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 08:44:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 08:44:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 08:44:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 08:44:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 08:44:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 08:44:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 08:44:25 --> Final output sent to browser
DEBUG - 2016-09-07 08:44:25 --> Total execution time: 0.7569
INFO - 2016-09-07 08:45:12 --> Config Class Initialized
INFO - 2016-09-07 08:45:12 --> Hooks Class Initialized
DEBUG - 2016-09-07 08:45:12 --> UTF-8 Support Enabled
INFO - 2016-09-07 08:45:12 --> Utf8 Class Initialized
INFO - 2016-09-07 08:45:12 --> URI Class Initialized
INFO - 2016-09-07 08:45:12 --> Router Class Initialized
INFO - 2016-09-07 08:45:12 --> Output Class Initialized
INFO - 2016-09-07 08:45:12 --> Security Class Initialized
DEBUG - 2016-09-07 08:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 08:45:12 --> Input Class Initialized
INFO - 2016-09-07 08:45:12 --> Language Class Initialized
INFO - 2016-09-07 08:45:12 --> Language Class Initialized
INFO - 2016-09-07 08:45:12 --> Config Class Initialized
INFO - 2016-09-07 08:45:12 --> Loader Class Initialized
INFO - 2016-09-07 08:45:12 --> Helper loaded: url_helper
INFO - 2016-09-07 08:45:12 --> Database Driver Class Initialized
INFO - 2016-09-07 08:45:12 --> Controller Class Initialized
DEBUG - 2016-09-07 08:45:12 --> Index MX_Controller Initialized
INFO - 2016-09-07 08:45:12 --> Model Class Initialized
INFO - 2016-09-07 08:45:12 --> Model Class Initialized
ERROR - 2016-09-07 08:45:12 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) E:\SERVER\htdocs\koperasiweda\application\modules\Anggota\controllers\Anggota.php 13
INFO - 2016-09-07 08:45:46 --> Config Class Initialized
INFO - 2016-09-07 08:45:46 --> Hooks Class Initialized
DEBUG - 2016-09-07 08:45:46 --> UTF-8 Support Enabled
INFO - 2016-09-07 08:45:47 --> Utf8 Class Initialized
INFO - 2016-09-07 08:45:47 --> URI Class Initialized
INFO - 2016-09-07 08:45:47 --> Router Class Initialized
INFO - 2016-09-07 08:45:47 --> Output Class Initialized
INFO - 2016-09-07 08:45:47 --> Security Class Initialized
DEBUG - 2016-09-07 08:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 08:45:47 --> Input Class Initialized
INFO - 2016-09-07 08:45:47 --> Language Class Initialized
INFO - 2016-09-07 08:45:47 --> Language Class Initialized
INFO - 2016-09-07 08:45:47 --> Config Class Initialized
INFO - 2016-09-07 08:45:47 --> Loader Class Initialized
INFO - 2016-09-07 08:45:47 --> Helper loaded: url_helper
INFO - 2016-09-07 08:45:47 --> Database Driver Class Initialized
INFO - 2016-09-07 08:45:47 --> Controller Class Initialized
DEBUG - 2016-09-07 08:45:47 --> Index MX_Controller Initialized
INFO - 2016-09-07 08:45:47 --> Model Class Initialized
INFO - 2016-09-07 08:45:47 --> Model Class Initialized
DEBUG - 2016-09-07 08:45:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 08:45:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 08:45:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 08:45:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 08:45:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 08:45:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 08:45:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 08:45:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 08:45:47 --> Final output sent to browser
DEBUG - 2016-09-07 08:45:47 --> Total execution time: 0.7536
INFO - 2016-09-07 08:46:15 --> Config Class Initialized
INFO - 2016-09-07 08:46:16 --> Hooks Class Initialized
DEBUG - 2016-09-07 08:46:16 --> UTF-8 Support Enabled
INFO - 2016-09-07 08:46:16 --> Utf8 Class Initialized
INFO - 2016-09-07 08:46:16 --> URI Class Initialized
INFO - 2016-09-07 08:46:16 --> Router Class Initialized
INFO - 2016-09-07 08:46:16 --> Output Class Initialized
INFO - 2016-09-07 08:46:16 --> Security Class Initialized
DEBUG - 2016-09-07 08:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 08:46:16 --> Input Class Initialized
INFO - 2016-09-07 08:46:16 --> Language Class Initialized
INFO - 2016-09-07 08:46:16 --> Language Class Initialized
INFO - 2016-09-07 08:46:16 --> Config Class Initialized
INFO - 2016-09-07 08:46:16 --> Loader Class Initialized
INFO - 2016-09-07 08:46:16 --> Helper loaded: url_helper
INFO - 2016-09-07 08:46:16 --> Database Driver Class Initialized
INFO - 2016-09-07 08:46:16 --> Controller Class Initialized
DEBUG - 2016-09-07 08:46:16 --> Index MX_Controller Initialized
INFO - 2016-09-07 08:46:16 --> Model Class Initialized
INFO - 2016-09-07 08:46:16 --> Model Class Initialized
DEBUG - 2016-09-07 08:46:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 08:46:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 08:46:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 08:46:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 08:46:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 08:46:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 08:46:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 08:46:16 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 08:46:16 --> Final output sent to browser
DEBUG - 2016-09-07 08:46:16 --> Total execution time: 0.7954
INFO - 2016-09-07 08:46:27 --> Config Class Initialized
INFO - 2016-09-07 08:46:27 --> Hooks Class Initialized
DEBUG - 2016-09-07 08:46:27 --> UTF-8 Support Enabled
INFO - 2016-09-07 08:46:27 --> Utf8 Class Initialized
INFO - 2016-09-07 08:46:27 --> URI Class Initialized
INFO - 2016-09-07 08:46:27 --> Router Class Initialized
INFO - 2016-09-07 08:46:27 --> Output Class Initialized
INFO - 2016-09-07 08:46:27 --> Security Class Initialized
DEBUG - 2016-09-07 08:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 08:46:27 --> Input Class Initialized
INFO - 2016-09-07 08:46:27 --> Language Class Initialized
INFO - 2016-09-07 08:46:27 --> Language Class Initialized
INFO - 2016-09-07 08:46:27 --> Config Class Initialized
INFO - 2016-09-07 08:46:27 --> Loader Class Initialized
INFO - 2016-09-07 08:46:28 --> Helper loaded: url_helper
INFO - 2016-09-07 08:46:28 --> Database Driver Class Initialized
INFO - 2016-09-07 08:46:28 --> Controller Class Initialized
DEBUG - 2016-09-07 08:46:28 --> Index MX_Controller Initialized
INFO - 2016-09-07 08:46:28 --> Model Class Initialized
INFO - 2016-09-07 08:46:28 --> Model Class Initialized
DEBUG - 2016-09-07 08:46:28 --> Anggota MX_Controller Initialized
ERROR - 2016-09-07 08:46:28 --> Severity: Notice --> Undefined property: CI::$table_prefix E:\SERVER\htdocs\koperasiweda\system\core\Model.php 77
INFO - 2016-09-07 08:46:28 --> Final output sent to browser
DEBUG - 2016-09-07 08:46:28 --> Total execution time: 0.8503
INFO - 2016-09-07 08:46:57 --> Config Class Initialized
INFO - 2016-09-07 08:46:57 --> Hooks Class Initialized
DEBUG - 2016-09-07 08:46:57 --> UTF-8 Support Enabled
INFO - 2016-09-07 08:46:57 --> Utf8 Class Initialized
INFO - 2016-09-07 08:46:57 --> URI Class Initialized
INFO - 2016-09-07 08:46:57 --> Router Class Initialized
INFO - 2016-09-07 08:46:57 --> Output Class Initialized
INFO - 2016-09-07 08:46:57 --> Security Class Initialized
DEBUG - 2016-09-07 08:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 08:46:57 --> Input Class Initialized
INFO - 2016-09-07 08:46:57 --> Language Class Initialized
INFO - 2016-09-07 08:46:57 --> Language Class Initialized
INFO - 2016-09-07 08:46:57 --> Config Class Initialized
INFO - 2016-09-07 08:46:57 --> Loader Class Initialized
INFO - 2016-09-07 08:46:57 --> Helper loaded: url_helper
INFO - 2016-09-07 08:46:57 --> Database Driver Class Initialized
INFO - 2016-09-07 08:46:57 --> Controller Class Initialized
DEBUG - 2016-09-07 08:46:57 --> Index MX_Controller Initialized
INFO - 2016-09-07 08:46:57 --> Model Class Initialized
INFO - 2016-09-07 08:46:57 --> Model Class Initialized
DEBUG - 2016-09-07 08:46:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 08:46:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 08:46:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 08:46:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 08:46:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 08:46:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 08:46:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 08:46:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 08:46:58 --> Final output sent to browser
DEBUG - 2016-09-07 08:46:58 --> Total execution time: 0.8068
INFO - 2016-09-07 08:47:07 --> Config Class Initialized
INFO - 2016-09-07 08:47:07 --> Hooks Class Initialized
DEBUG - 2016-09-07 08:47:07 --> UTF-8 Support Enabled
INFO - 2016-09-07 08:47:07 --> Utf8 Class Initialized
INFO - 2016-09-07 08:47:07 --> URI Class Initialized
INFO - 2016-09-07 08:47:07 --> Router Class Initialized
INFO - 2016-09-07 08:47:07 --> Output Class Initialized
INFO - 2016-09-07 08:47:07 --> Security Class Initialized
DEBUG - 2016-09-07 08:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 08:47:07 --> Input Class Initialized
INFO - 2016-09-07 08:47:07 --> Language Class Initialized
INFO - 2016-09-07 08:47:07 --> Language Class Initialized
INFO - 2016-09-07 08:47:07 --> Config Class Initialized
INFO - 2016-09-07 08:47:07 --> Loader Class Initialized
INFO - 2016-09-07 08:47:07 --> Helper loaded: url_helper
INFO - 2016-09-07 08:47:07 --> Database Driver Class Initialized
INFO - 2016-09-07 08:47:07 --> Controller Class Initialized
DEBUG - 2016-09-07 08:47:07 --> Index MX_Controller Initialized
INFO - 2016-09-07 08:47:07 --> Model Class Initialized
INFO - 2016-09-07 08:47:07 --> Model Class Initialized
DEBUG - 2016-09-07 08:47:07 --> Anggota MX_Controller Initialized
INFO - 2016-09-07 08:47:08 --> Final output sent to browser
DEBUG - 2016-09-07 08:47:08 --> Total execution time: 0.7770
INFO - 2016-09-07 08:47:19 --> Config Class Initialized
INFO - 2016-09-07 08:47:19 --> Hooks Class Initialized
DEBUG - 2016-09-07 08:47:20 --> UTF-8 Support Enabled
INFO - 2016-09-07 08:47:20 --> Utf8 Class Initialized
INFO - 2016-09-07 08:47:20 --> URI Class Initialized
INFO - 2016-09-07 08:47:20 --> Router Class Initialized
INFO - 2016-09-07 08:47:20 --> Output Class Initialized
INFO - 2016-09-07 08:47:20 --> Security Class Initialized
DEBUG - 2016-09-07 08:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 08:47:20 --> Input Class Initialized
INFO - 2016-09-07 08:47:20 --> Language Class Initialized
INFO - 2016-09-07 08:47:20 --> Language Class Initialized
INFO - 2016-09-07 08:47:20 --> Config Class Initialized
INFO - 2016-09-07 08:47:20 --> Loader Class Initialized
INFO - 2016-09-07 08:47:20 --> Helper loaded: url_helper
INFO - 2016-09-07 08:47:20 --> Database Driver Class Initialized
INFO - 2016-09-07 08:47:20 --> Controller Class Initialized
DEBUG - 2016-09-07 08:47:20 --> Index MX_Controller Initialized
INFO - 2016-09-07 08:47:20 --> Model Class Initialized
INFO - 2016-09-07 08:47:20 --> Model Class Initialized
DEBUG - 2016-09-07 08:47:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 08:47:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 08:47:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 08:47:20 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-07 08:47:20 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-07 08:47:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-07 08:47:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 08:47:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 08:47:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 08:47:20 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 08:47:20 --> Final output sent to browser
DEBUG - 2016-09-07 08:47:20 --> Total execution time: 0.8888
INFO - 2016-09-07 08:49:51 --> Config Class Initialized
INFO - 2016-09-07 08:49:51 --> Hooks Class Initialized
DEBUG - 2016-09-07 08:49:51 --> UTF-8 Support Enabled
INFO - 2016-09-07 08:49:51 --> Utf8 Class Initialized
INFO - 2016-09-07 08:49:51 --> URI Class Initialized
INFO - 2016-09-07 08:49:51 --> Router Class Initialized
INFO - 2016-09-07 08:49:51 --> Output Class Initialized
INFO - 2016-09-07 08:49:51 --> Security Class Initialized
DEBUG - 2016-09-07 08:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 08:49:51 --> Input Class Initialized
INFO - 2016-09-07 08:49:51 --> Language Class Initialized
INFO - 2016-09-07 08:49:51 --> Language Class Initialized
INFO - 2016-09-07 08:49:51 --> Config Class Initialized
INFO - 2016-09-07 08:49:51 --> Loader Class Initialized
INFO - 2016-09-07 08:49:51 --> Helper loaded: url_helper
INFO - 2016-09-07 08:49:51 --> Database Driver Class Initialized
INFO - 2016-09-07 08:49:51 --> Controller Class Initialized
DEBUG - 2016-09-07 08:49:51 --> Index MX_Controller Initialized
INFO - 2016-09-07 08:49:51 --> Model Class Initialized
INFO - 2016-09-07 08:49:51 --> Model Class Initialized
DEBUG - 2016-09-07 08:49:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 08:49:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 08:49:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 08:49:52 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-07 08:49:52 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-07 08:49:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-07 08:49:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 08:49:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 08:49:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 08:49:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 08:49:52 --> Final output sent to browser
DEBUG - 2016-09-07 08:49:52 --> Total execution time: 0.8390
INFO - 2016-09-07 08:50:01 --> Config Class Initialized
INFO - 2016-09-07 08:50:01 --> Hooks Class Initialized
DEBUG - 2016-09-07 08:50:01 --> UTF-8 Support Enabled
INFO - 2016-09-07 08:50:01 --> Utf8 Class Initialized
INFO - 2016-09-07 08:50:01 --> URI Class Initialized
INFO - 2016-09-07 08:50:01 --> Router Class Initialized
INFO - 2016-09-07 08:50:01 --> Output Class Initialized
INFO - 2016-09-07 08:50:01 --> Security Class Initialized
DEBUG - 2016-09-07 08:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 08:50:01 --> Input Class Initialized
INFO - 2016-09-07 08:50:01 --> Language Class Initialized
INFO - 2016-09-07 08:50:01 --> Language Class Initialized
INFO - 2016-09-07 08:50:01 --> Config Class Initialized
INFO - 2016-09-07 08:50:01 --> Loader Class Initialized
INFO - 2016-09-07 08:50:01 --> Helper loaded: url_helper
INFO - 2016-09-07 08:50:01 --> Database Driver Class Initialized
INFO - 2016-09-07 08:50:01 --> Controller Class Initialized
DEBUG - 2016-09-07 08:50:01 --> Index MX_Controller Initialized
INFO - 2016-09-07 08:50:01 --> Model Class Initialized
INFO - 2016-09-07 08:50:01 --> Model Class Initialized
DEBUG - 2016-09-07 08:50:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 08:50:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 08:50:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 08:50:01 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-07 08:50:02 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-07 08:50:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-07 08:50:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 08:50:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 08:50:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 08:50:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 08:50:02 --> Final output sent to browser
DEBUG - 2016-09-07 08:50:02 --> Total execution time: 0.8564
INFO - 2016-09-07 08:50:09 --> Config Class Initialized
INFO - 2016-09-07 08:50:09 --> Hooks Class Initialized
DEBUG - 2016-09-07 08:50:09 --> UTF-8 Support Enabled
INFO - 2016-09-07 08:50:09 --> Utf8 Class Initialized
INFO - 2016-09-07 08:50:09 --> URI Class Initialized
INFO - 2016-09-07 08:50:09 --> Router Class Initialized
INFO - 2016-09-07 08:50:09 --> Output Class Initialized
INFO - 2016-09-07 08:50:09 --> Security Class Initialized
DEBUG - 2016-09-07 08:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 08:50:09 --> Input Class Initialized
INFO - 2016-09-07 08:50:09 --> Language Class Initialized
INFO - 2016-09-07 08:50:09 --> Language Class Initialized
INFO - 2016-09-07 08:50:09 --> Config Class Initialized
INFO - 2016-09-07 08:50:09 --> Loader Class Initialized
INFO - 2016-09-07 08:50:09 --> Helper loaded: url_helper
INFO - 2016-09-07 08:50:09 --> Database Driver Class Initialized
INFO - 2016-09-07 08:50:09 --> Controller Class Initialized
DEBUG - 2016-09-07 08:50:09 --> Index MX_Controller Initialized
INFO - 2016-09-07 08:50:09 --> Model Class Initialized
INFO - 2016-09-07 08:50:09 --> Model Class Initialized
DEBUG - 2016-09-07 08:50:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 08:50:09 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 08:50:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 08:50:10 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-07 08:50:10 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-07 08:50:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-07 08:50:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 08:50:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 08:50:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 08:50:10 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 08:50:10 --> Final output sent to browser
DEBUG - 2016-09-07 08:50:10 --> Total execution time: 0.9384
INFO - 2016-09-07 08:50:59 --> Config Class Initialized
INFO - 2016-09-07 08:50:59 --> Hooks Class Initialized
DEBUG - 2016-09-07 08:50:59 --> UTF-8 Support Enabled
INFO - 2016-09-07 08:50:59 --> Utf8 Class Initialized
INFO - 2016-09-07 08:50:59 --> URI Class Initialized
INFO - 2016-09-07 08:50:59 --> Router Class Initialized
INFO - 2016-09-07 08:50:59 --> Output Class Initialized
INFO - 2016-09-07 08:50:59 --> Security Class Initialized
DEBUG - 2016-09-07 08:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 08:51:00 --> Input Class Initialized
INFO - 2016-09-07 08:51:00 --> Language Class Initialized
INFO - 2016-09-07 08:51:00 --> Language Class Initialized
INFO - 2016-09-07 08:51:00 --> Config Class Initialized
INFO - 2016-09-07 08:51:00 --> Loader Class Initialized
INFO - 2016-09-07 08:51:00 --> Helper loaded: url_helper
INFO - 2016-09-07 08:51:00 --> Database Driver Class Initialized
INFO - 2016-09-07 08:51:00 --> Controller Class Initialized
DEBUG - 2016-09-07 08:51:00 --> Index MX_Controller Initialized
INFO - 2016-09-07 08:51:00 --> Model Class Initialized
INFO - 2016-09-07 08:51:00 --> Model Class Initialized
DEBUG - 2016-09-07 08:51:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 08:51:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 08:51:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 08:51:00 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-07 08:51:00 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-07 08:51:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-07 08:51:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 08:51:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 08:51:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 08:51:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 08:51:00 --> Final output sent to browser
DEBUG - 2016-09-07 08:51:00 --> Total execution time: 0.8315
INFO - 2016-09-07 08:54:32 --> Config Class Initialized
INFO - 2016-09-07 08:54:32 --> Hooks Class Initialized
DEBUG - 2016-09-07 08:54:32 --> UTF-8 Support Enabled
INFO - 2016-09-07 08:54:32 --> Utf8 Class Initialized
INFO - 2016-09-07 08:54:32 --> URI Class Initialized
INFO - 2016-09-07 08:54:32 --> Router Class Initialized
INFO - 2016-09-07 08:54:32 --> Output Class Initialized
INFO - 2016-09-07 08:54:32 --> Security Class Initialized
DEBUG - 2016-09-07 08:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 08:54:32 --> Input Class Initialized
INFO - 2016-09-07 08:54:32 --> Language Class Initialized
INFO - 2016-09-07 08:54:32 --> Language Class Initialized
INFO - 2016-09-07 08:54:32 --> Config Class Initialized
INFO - 2016-09-07 08:54:32 --> Loader Class Initialized
INFO - 2016-09-07 08:54:32 --> Helper loaded: url_helper
INFO - 2016-09-07 08:54:32 --> Database Driver Class Initialized
INFO - 2016-09-07 08:54:32 --> Controller Class Initialized
DEBUG - 2016-09-07 08:54:32 --> Index MX_Controller Initialized
INFO - 2016-09-07 08:54:32 --> Model Class Initialized
INFO - 2016-09-07 08:54:32 --> Model Class Initialized
DEBUG - 2016-09-07 08:54:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 08:54:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 08:54:32 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 08:54:33 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-07 08:54:33 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-07 08:54:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-07 08:54:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 08:54:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 08:54:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 08:54:33 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 08:54:33 --> Final output sent to browser
DEBUG - 2016-09-07 08:54:33 --> Total execution time: 0.8420
INFO - 2016-09-07 08:54:45 --> Config Class Initialized
INFO - 2016-09-07 08:54:45 --> Hooks Class Initialized
DEBUG - 2016-09-07 08:54:45 --> UTF-8 Support Enabled
INFO - 2016-09-07 08:54:45 --> Utf8 Class Initialized
INFO - 2016-09-07 08:54:45 --> URI Class Initialized
INFO - 2016-09-07 08:54:45 --> Router Class Initialized
INFO - 2016-09-07 08:54:45 --> Output Class Initialized
INFO - 2016-09-07 08:54:45 --> Security Class Initialized
DEBUG - 2016-09-07 08:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 08:54:45 --> Input Class Initialized
INFO - 2016-09-07 08:54:45 --> Language Class Initialized
INFO - 2016-09-07 08:54:45 --> Language Class Initialized
INFO - 2016-09-07 08:54:45 --> Config Class Initialized
INFO - 2016-09-07 08:54:45 --> Loader Class Initialized
INFO - 2016-09-07 08:54:45 --> Helper loaded: url_helper
INFO - 2016-09-07 08:54:45 --> Database Driver Class Initialized
INFO - 2016-09-07 08:54:45 --> Controller Class Initialized
DEBUG - 2016-09-07 08:54:46 --> Index MX_Controller Initialized
INFO - 2016-09-07 08:54:46 --> Model Class Initialized
INFO - 2016-09-07 08:54:46 --> Model Class Initialized
DEBUG - 2016-09-07 08:54:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 08:54:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 08:54:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 08:54:46 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-07 08:54:46 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-07 08:54:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-07 08:54:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 08:54:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 08:54:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 08:54:46 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 08:54:46 --> Final output sent to browser
DEBUG - 2016-09-07 08:54:46 --> Total execution time: 0.8819
INFO - 2016-09-07 08:55:39 --> Config Class Initialized
INFO - 2016-09-07 08:55:39 --> Hooks Class Initialized
DEBUG - 2016-09-07 08:55:39 --> UTF-8 Support Enabled
INFO - 2016-09-07 08:55:39 --> Utf8 Class Initialized
INFO - 2016-09-07 08:55:39 --> URI Class Initialized
INFO - 2016-09-07 08:55:40 --> Router Class Initialized
INFO - 2016-09-07 08:55:40 --> Output Class Initialized
INFO - 2016-09-07 08:55:40 --> Security Class Initialized
DEBUG - 2016-09-07 08:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 08:55:40 --> Input Class Initialized
INFO - 2016-09-07 08:55:40 --> Language Class Initialized
INFO - 2016-09-07 08:55:40 --> Language Class Initialized
INFO - 2016-09-07 08:55:40 --> Config Class Initialized
INFO - 2016-09-07 08:55:40 --> Loader Class Initialized
INFO - 2016-09-07 08:55:40 --> Helper loaded: url_helper
INFO - 2016-09-07 08:55:40 --> Database Driver Class Initialized
INFO - 2016-09-07 08:55:40 --> Controller Class Initialized
DEBUG - 2016-09-07 08:55:40 --> Index MX_Controller Initialized
INFO - 2016-09-07 08:55:40 --> Model Class Initialized
INFO - 2016-09-07 08:55:40 --> Model Class Initialized
DEBUG - 2016-09-07 08:55:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 08:55:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 08:55:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 08:55:40 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-07 08:55:40 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-07 08:55:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-07 08:55:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 08:55:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 08:55:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 08:55:40 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 08:55:40 --> Final output sent to browser
DEBUG - 2016-09-07 08:55:40 --> Total execution time: 0.8733
INFO - 2016-09-07 08:55:50 --> Config Class Initialized
INFO - 2016-09-07 08:55:50 --> Hooks Class Initialized
DEBUG - 2016-09-07 08:55:50 --> UTF-8 Support Enabled
INFO - 2016-09-07 08:55:50 --> Utf8 Class Initialized
INFO - 2016-09-07 08:55:50 --> URI Class Initialized
INFO - 2016-09-07 08:55:50 --> Router Class Initialized
INFO - 2016-09-07 08:55:50 --> Output Class Initialized
INFO - 2016-09-07 08:55:50 --> Security Class Initialized
DEBUG - 2016-09-07 08:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 08:55:50 --> Input Class Initialized
INFO - 2016-09-07 08:55:50 --> Language Class Initialized
INFO - 2016-09-07 08:55:51 --> Language Class Initialized
INFO - 2016-09-07 08:55:51 --> Config Class Initialized
INFO - 2016-09-07 08:55:51 --> Loader Class Initialized
INFO - 2016-09-07 08:55:51 --> Helper loaded: url_helper
INFO - 2016-09-07 08:55:51 --> Database Driver Class Initialized
INFO - 2016-09-07 08:55:51 --> Controller Class Initialized
DEBUG - 2016-09-07 08:55:51 --> Index MX_Controller Initialized
INFO - 2016-09-07 08:55:51 --> Model Class Initialized
INFO - 2016-09-07 08:55:51 --> Model Class Initialized
DEBUG - 2016-09-07 08:55:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 08:55:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 08:55:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 08:55:51 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-07 08:55:51 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-07 08:55:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-07 08:55:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 08:55:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 08:55:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 08:55:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 08:55:51 --> Final output sent to browser
DEBUG - 2016-09-07 08:55:51 --> Total execution time: 0.8728
INFO - 2016-09-07 08:56:04 --> Config Class Initialized
INFO - 2016-09-07 08:56:04 --> Hooks Class Initialized
DEBUG - 2016-09-07 08:56:04 --> UTF-8 Support Enabled
INFO - 2016-09-07 08:56:04 --> Utf8 Class Initialized
INFO - 2016-09-07 08:56:04 --> URI Class Initialized
INFO - 2016-09-07 08:56:04 --> Router Class Initialized
INFO - 2016-09-07 08:56:04 --> Output Class Initialized
INFO - 2016-09-07 08:56:04 --> Security Class Initialized
DEBUG - 2016-09-07 08:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 08:56:04 --> Input Class Initialized
INFO - 2016-09-07 08:56:04 --> Language Class Initialized
INFO - 2016-09-07 08:56:04 --> Language Class Initialized
INFO - 2016-09-07 08:56:04 --> Config Class Initialized
INFO - 2016-09-07 08:56:04 --> Loader Class Initialized
INFO - 2016-09-07 08:56:04 --> Helper loaded: url_helper
INFO - 2016-09-07 08:56:04 --> Database Driver Class Initialized
INFO - 2016-09-07 08:56:04 --> Controller Class Initialized
DEBUG - 2016-09-07 08:56:04 --> Index MX_Controller Initialized
INFO - 2016-09-07 08:56:04 --> Model Class Initialized
INFO - 2016-09-07 08:56:04 --> Model Class Initialized
DEBUG - 2016-09-07 08:56:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 08:56:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 08:56:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 08:56:04 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-07 08:56:04 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-07 08:56:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-07 08:56:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 08:56:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 08:56:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 08:56:05 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 08:56:05 --> Final output sent to browser
DEBUG - 2016-09-07 08:56:05 --> Total execution time: 0.8849
INFO - 2016-09-07 13:52:55 --> Config Class Initialized
INFO - 2016-09-07 13:52:55 --> Hooks Class Initialized
DEBUG - 2016-09-07 13:52:55 --> UTF-8 Support Enabled
INFO - 2016-09-07 13:52:55 --> Utf8 Class Initialized
INFO - 2016-09-07 13:52:55 --> URI Class Initialized
INFO - 2016-09-07 13:52:56 --> Router Class Initialized
INFO - 2016-09-07 13:52:56 --> Output Class Initialized
INFO - 2016-09-07 13:52:56 --> Security Class Initialized
DEBUG - 2016-09-07 13:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 13:52:56 --> Input Class Initialized
INFO - 2016-09-07 13:52:56 --> Language Class Initialized
INFO - 2016-09-07 13:52:57 --> Language Class Initialized
INFO - 2016-09-07 13:52:57 --> Config Class Initialized
INFO - 2016-09-07 13:52:57 --> Loader Class Initialized
INFO - 2016-09-07 13:52:57 --> Helper loaded: url_helper
INFO - 2016-09-07 13:52:58 --> Database Driver Class Initialized
INFO - 2016-09-07 13:52:58 --> Controller Class Initialized
DEBUG - 2016-09-07 13:52:58 --> Index MX_Controller Initialized
INFO - 2016-09-07 13:52:58 --> Model Class Initialized
INFO - 2016-09-07 13:52:58 --> Model Class Initialized
DEBUG - 2016-09-07 13:52:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 13:52:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 13:52:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 13:52:58 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-07 13:52:58 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-07 13:52:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-07 13:52:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 13:52:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 13:52:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 13:52:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 13:52:58 --> Final output sent to browser
DEBUG - 2016-09-07 13:52:58 --> Total execution time: 3.9746
INFO - 2016-09-07 13:53:42 --> Config Class Initialized
INFO - 2016-09-07 13:53:42 --> Hooks Class Initialized
DEBUG - 2016-09-07 13:53:42 --> UTF-8 Support Enabled
INFO - 2016-09-07 13:53:42 --> Utf8 Class Initialized
INFO - 2016-09-07 13:53:42 --> URI Class Initialized
INFO - 2016-09-07 13:53:42 --> Router Class Initialized
INFO - 2016-09-07 13:53:42 --> Output Class Initialized
INFO - 2016-09-07 13:53:42 --> Security Class Initialized
DEBUG - 2016-09-07 13:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 13:53:42 --> Input Class Initialized
INFO - 2016-09-07 13:53:42 --> Language Class Initialized
INFO - 2016-09-07 13:53:42 --> Language Class Initialized
INFO - 2016-09-07 13:53:42 --> Config Class Initialized
INFO - 2016-09-07 13:53:42 --> Loader Class Initialized
INFO - 2016-09-07 13:53:42 --> Helper loaded: url_helper
INFO - 2016-09-07 13:53:42 --> Database Driver Class Initialized
INFO - 2016-09-07 13:53:42 --> Controller Class Initialized
DEBUG - 2016-09-07 13:53:42 --> Index MX_Controller Initialized
INFO - 2016-09-07 13:53:42 --> Model Class Initialized
INFO - 2016-09-07 13:53:42 --> Model Class Initialized
DEBUG - 2016-09-07 13:53:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 13:53:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 13:53:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 13:53:42 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-07 13:53:42 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-07 13:53:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-07 13:53:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 13:53:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 13:53:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 13:53:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 13:53:43 --> Final output sent to browser
DEBUG - 2016-09-07 13:53:43 --> Total execution time: 0.9806
INFO - 2016-09-07 13:53:46 --> Config Class Initialized
INFO - 2016-09-07 13:53:46 --> Hooks Class Initialized
DEBUG - 2016-09-07 13:53:46 --> UTF-8 Support Enabled
INFO - 2016-09-07 13:53:46 --> Utf8 Class Initialized
INFO - 2016-09-07 13:53:46 --> URI Class Initialized
INFO - 2016-09-07 13:53:46 --> Router Class Initialized
INFO - 2016-09-07 13:53:46 --> Output Class Initialized
INFO - 2016-09-07 13:53:46 --> Security Class Initialized
DEBUG - 2016-09-07 13:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 13:53:46 --> Input Class Initialized
INFO - 2016-09-07 13:53:46 --> Language Class Initialized
INFO - 2016-09-07 13:53:46 --> Language Class Initialized
INFO - 2016-09-07 13:53:46 --> Config Class Initialized
INFO - 2016-09-07 13:53:47 --> Loader Class Initialized
INFO - 2016-09-07 13:53:47 --> Helper loaded: url_helper
INFO - 2016-09-07 13:53:47 --> Database Driver Class Initialized
INFO - 2016-09-07 13:53:47 --> Controller Class Initialized
DEBUG - 2016-09-07 13:53:47 --> Index MX_Controller Initialized
INFO - 2016-09-07 13:53:47 --> Model Class Initialized
INFO - 2016-09-07 13:53:47 --> Model Class Initialized
DEBUG - 2016-09-07 13:53:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 13:53:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 13:53:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 13:53:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 13:53:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 13:53:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 13:53:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 13:53:47 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 13:53:47 --> Final output sent to browser
DEBUG - 2016-09-07 13:53:47 --> Total execution time: 0.9316
INFO - 2016-09-07 13:53:51 --> Config Class Initialized
INFO - 2016-09-07 13:53:52 --> Hooks Class Initialized
DEBUG - 2016-09-07 13:53:52 --> UTF-8 Support Enabled
INFO - 2016-09-07 13:53:52 --> Utf8 Class Initialized
INFO - 2016-09-07 13:53:52 --> URI Class Initialized
INFO - 2016-09-07 13:53:52 --> Router Class Initialized
INFO - 2016-09-07 13:53:52 --> Output Class Initialized
INFO - 2016-09-07 13:53:52 --> Security Class Initialized
DEBUG - 2016-09-07 13:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 13:53:52 --> Input Class Initialized
INFO - 2016-09-07 13:53:52 --> Language Class Initialized
INFO - 2016-09-07 13:53:52 --> Language Class Initialized
INFO - 2016-09-07 13:53:52 --> Config Class Initialized
INFO - 2016-09-07 13:53:52 --> Loader Class Initialized
INFO - 2016-09-07 13:53:52 --> Helper loaded: url_helper
INFO - 2016-09-07 13:53:52 --> Database Driver Class Initialized
INFO - 2016-09-07 13:53:52 --> Controller Class Initialized
DEBUG - 2016-09-07 13:53:52 --> Index MX_Controller Initialized
INFO - 2016-09-07 13:53:52 --> Model Class Initialized
INFO - 2016-09-07 13:53:52 --> Model Class Initialized
DEBUG - 2016-09-07 13:53:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 13:53:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 13:53:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 13:53:52 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-07 13:53:52 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-07 13:53:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-07 13:53:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 13:53:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 13:53:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 13:53:52 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 13:53:52 --> Final output sent to browser
DEBUG - 2016-09-07 13:53:53 --> Total execution time: 1.0087
INFO - 2016-09-07 13:54:01 --> Config Class Initialized
INFO - 2016-09-07 13:54:01 --> Hooks Class Initialized
DEBUG - 2016-09-07 13:54:01 --> UTF-8 Support Enabled
INFO - 2016-09-07 13:54:01 --> Utf8 Class Initialized
INFO - 2016-09-07 13:54:01 --> URI Class Initialized
INFO - 2016-09-07 13:54:01 --> Router Class Initialized
INFO - 2016-09-07 13:54:01 --> Output Class Initialized
INFO - 2016-09-07 13:54:01 --> Security Class Initialized
DEBUG - 2016-09-07 13:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 13:54:01 --> Input Class Initialized
INFO - 2016-09-07 13:54:01 --> Language Class Initialized
INFO - 2016-09-07 13:54:01 --> Language Class Initialized
INFO - 2016-09-07 13:54:01 --> Config Class Initialized
INFO - 2016-09-07 13:54:01 --> Loader Class Initialized
INFO - 2016-09-07 13:54:01 --> Helper loaded: url_helper
INFO - 2016-09-07 13:54:01 --> Database Driver Class Initialized
INFO - 2016-09-07 13:54:02 --> Controller Class Initialized
DEBUG - 2016-09-07 13:54:02 --> Index MX_Controller Initialized
INFO - 2016-09-07 13:54:02 --> Model Class Initialized
INFO - 2016-09-07 13:54:02 --> Model Class Initialized
DEBUG - 2016-09-07 13:54:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 13:54:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 13:54:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 13:54:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 13:54:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 13:54:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 13:54:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 13:54:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 13:54:02 --> Final output sent to browser
DEBUG - 2016-09-07 13:54:02 --> Total execution time: 0.8396
INFO - 2016-09-07 13:54:08 --> Config Class Initialized
INFO - 2016-09-07 13:54:08 --> Hooks Class Initialized
DEBUG - 2016-09-07 13:54:08 --> UTF-8 Support Enabled
INFO - 2016-09-07 13:54:08 --> Utf8 Class Initialized
INFO - 2016-09-07 13:54:08 --> URI Class Initialized
INFO - 2016-09-07 13:54:08 --> Router Class Initialized
INFO - 2016-09-07 13:54:08 --> Output Class Initialized
INFO - 2016-09-07 13:54:08 --> Security Class Initialized
DEBUG - 2016-09-07 13:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 13:54:08 --> Input Class Initialized
INFO - 2016-09-07 13:54:08 --> Language Class Initialized
INFO - 2016-09-07 13:54:08 --> Language Class Initialized
INFO - 2016-09-07 13:54:08 --> Config Class Initialized
INFO - 2016-09-07 13:54:08 --> Loader Class Initialized
INFO - 2016-09-07 13:54:08 --> Helper loaded: url_helper
INFO - 2016-09-07 13:54:08 --> Database Driver Class Initialized
INFO - 2016-09-07 13:54:08 --> Controller Class Initialized
DEBUG - 2016-09-07 13:54:08 --> Index MX_Controller Initialized
INFO - 2016-09-07 13:54:08 --> Model Class Initialized
INFO - 2016-09-07 13:54:08 --> Model Class Initialized
DEBUG - 2016-09-07 13:54:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 13:54:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 13:54:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 13:54:08 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-07 13:54:08 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-07 13:54:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-07 13:54:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 13:54:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 13:54:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 13:54:08 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 13:54:08 --> Final output sent to browser
DEBUG - 2016-09-07 13:54:09 --> Total execution time: 0.9394
INFO - 2016-09-07 14:00:02 --> Config Class Initialized
INFO - 2016-09-07 14:00:02 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:00:02 --> UTF-8 Support Enabled
INFO - 2016-09-07 14:00:02 --> Utf8 Class Initialized
INFO - 2016-09-07 14:00:02 --> URI Class Initialized
INFO - 2016-09-07 14:00:02 --> Router Class Initialized
INFO - 2016-09-07 14:00:02 --> Output Class Initialized
INFO - 2016-09-07 14:00:02 --> Security Class Initialized
DEBUG - 2016-09-07 14:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 14:00:02 --> Input Class Initialized
INFO - 2016-09-07 14:00:02 --> Language Class Initialized
INFO - 2016-09-07 14:00:02 --> Language Class Initialized
INFO - 2016-09-07 14:00:02 --> Config Class Initialized
INFO - 2016-09-07 14:00:02 --> Loader Class Initialized
INFO - 2016-09-07 14:00:02 --> Helper loaded: url_helper
INFO - 2016-09-07 14:00:02 --> Database Driver Class Initialized
INFO - 2016-09-07 14:00:03 --> Controller Class Initialized
DEBUG - 2016-09-07 14:00:03 --> Index MX_Controller Initialized
INFO - 2016-09-07 14:00:03 --> Model Class Initialized
INFO - 2016-09-07 14:00:03 --> Model Class Initialized
DEBUG - 2016-09-07 14:00:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 14:00:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 14:00:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 14:00:03 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-07 14:00:03 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-07 14:00:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-07 14:00:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 14:00:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 14:00:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 14:00:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 14:00:03 --> Final output sent to browser
DEBUG - 2016-09-07 14:00:03 --> Total execution time: 1.0790
INFO - 2016-09-07 14:00:54 --> Config Class Initialized
INFO - 2016-09-07 14:00:54 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:00:54 --> UTF-8 Support Enabled
INFO - 2016-09-07 14:00:54 --> Utf8 Class Initialized
INFO - 2016-09-07 14:00:54 --> URI Class Initialized
INFO - 2016-09-07 14:00:54 --> Router Class Initialized
INFO - 2016-09-07 14:00:54 --> Output Class Initialized
INFO - 2016-09-07 14:00:55 --> Security Class Initialized
DEBUG - 2016-09-07 14:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 14:00:55 --> Input Class Initialized
INFO - 2016-09-07 14:00:55 --> Language Class Initialized
INFO - 2016-09-07 14:00:55 --> Language Class Initialized
INFO - 2016-09-07 14:00:55 --> Config Class Initialized
INFO - 2016-09-07 14:00:55 --> Loader Class Initialized
INFO - 2016-09-07 14:00:55 --> Helper loaded: url_helper
INFO - 2016-09-07 14:00:55 --> Database Driver Class Initialized
INFO - 2016-09-07 14:00:55 --> Controller Class Initialized
DEBUG - 2016-09-07 14:00:55 --> Index MX_Controller Initialized
INFO - 2016-09-07 14:00:55 --> Model Class Initialized
INFO - 2016-09-07 14:00:55 --> Model Class Initialized
DEBUG - 2016-09-07 14:00:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 14:00:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 14:00:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 14:00:55 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-07 14:00:55 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-07 14:00:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-07 14:00:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 14:00:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 14:00:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 14:00:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 14:00:55 --> Final output sent to browser
DEBUG - 2016-09-07 14:00:55 --> Total execution time: 0.9544
INFO - 2016-09-07 14:02:00 --> Config Class Initialized
INFO - 2016-09-07 14:02:00 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:02:00 --> UTF-8 Support Enabled
INFO - 2016-09-07 14:02:00 --> Utf8 Class Initialized
INFO - 2016-09-07 14:02:00 --> URI Class Initialized
INFO - 2016-09-07 14:02:00 --> Router Class Initialized
INFO - 2016-09-07 14:02:00 --> Output Class Initialized
INFO - 2016-09-07 14:02:00 --> Security Class Initialized
DEBUG - 2016-09-07 14:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 14:02:01 --> Input Class Initialized
INFO - 2016-09-07 14:02:01 --> Language Class Initialized
INFO - 2016-09-07 14:02:01 --> Language Class Initialized
INFO - 2016-09-07 14:02:01 --> Config Class Initialized
INFO - 2016-09-07 14:02:01 --> Loader Class Initialized
INFO - 2016-09-07 14:02:01 --> Helper loaded: url_helper
INFO - 2016-09-07 14:02:01 --> Database Driver Class Initialized
INFO - 2016-09-07 14:02:01 --> Controller Class Initialized
DEBUG - 2016-09-07 14:02:01 --> Index MX_Controller Initialized
INFO - 2016-09-07 14:02:01 --> Model Class Initialized
INFO - 2016-09-07 14:02:01 --> Model Class Initialized
DEBUG - 2016-09-07 14:02:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 14:02:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 14:02:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 14:02:01 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-07 14:02:01 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-07 14:02:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-07 14:02:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 14:02:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 14:02:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 14:02:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 14:02:01 --> Final output sent to browser
DEBUG - 2016-09-07 14:02:01 --> Total execution time: 0.9073
INFO - 2016-09-07 14:04:41 --> Config Class Initialized
INFO - 2016-09-07 14:04:41 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:04:41 --> UTF-8 Support Enabled
INFO - 2016-09-07 14:04:41 --> Utf8 Class Initialized
INFO - 2016-09-07 14:04:41 --> URI Class Initialized
INFO - 2016-09-07 14:04:41 --> Router Class Initialized
INFO - 2016-09-07 14:04:41 --> Output Class Initialized
INFO - 2016-09-07 14:04:41 --> Security Class Initialized
DEBUG - 2016-09-07 14:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 14:04:42 --> Input Class Initialized
INFO - 2016-09-07 14:04:42 --> Language Class Initialized
INFO - 2016-09-07 14:04:42 --> Language Class Initialized
INFO - 2016-09-07 14:04:42 --> Config Class Initialized
INFO - 2016-09-07 14:04:42 --> Loader Class Initialized
INFO - 2016-09-07 14:04:42 --> Helper loaded: url_helper
INFO - 2016-09-07 14:04:42 --> Database Driver Class Initialized
INFO - 2016-09-07 14:04:42 --> Controller Class Initialized
DEBUG - 2016-09-07 14:04:42 --> Index MX_Controller Initialized
INFO - 2016-09-07 14:04:42 --> Model Class Initialized
INFO - 2016-09-07 14:04:42 --> Model Class Initialized
DEBUG - 2016-09-07 14:04:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 14:04:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 14:04:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 14:04:42 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-07 14:04:42 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-07 14:04:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 14:04:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-07 14:04:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 14:04:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 14:04:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 14:04:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 14:04:42 --> Final output sent to browser
DEBUG - 2016-09-07 14:04:42 --> Total execution time: 0.9518
INFO - 2016-09-07 14:04:56 --> Config Class Initialized
INFO - 2016-09-07 14:04:56 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:04:56 --> UTF-8 Support Enabled
INFO - 2016-09-07 14:04:56 --> Utf8 Class Initialized
INFO - 2016-09-07 14:04:56 --> URI Class Initialized
INFO - 2016-09-07 14:04:56 --> Router Class Initialized
INFO - 2016-09-07 14:04:56 --> Output Class Initialized
INFO - 2016-09-07 14:04:56 --> Security Class Initialized
DEBUG - 2016-09-07 14:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 14:04:56 --> Input Class Initialized
INFO - 2016-09-07 14:04:56 --> Language Class Initialized
INFO - 2016-09-07 14:04:56 --> Language Class Initialized
INFO - 2016-09-07 14:04:56 --> Config Class Initialized
INFO - 2016-09-07 14:04:56 --> Loader Class Initialized
INFO - 2016-09-07 14:04:56 --> Helper loaded: url_helper
INFO - 2016-09-07 14:04:56 --> Database Driver Class Initialized
INFO - 2016-09-07 14:04:56 --> Controller Class Initialized
DEBUG - 2016-09-07 14:04:56 --> Index MX_Controller Initialized
INFO - 2016-09-07 14:04:56 --> Model Class Initialized
INFO - 2016-09-07 14:04:56 --> Model Class Initialized
DEBUG - 2016-09-07 14:04:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 14:04:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 14:04:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 14:04:56 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-07 14:04:56 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-07 14:04:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 14:04:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-07 14:04:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 14:04:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 14:04:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 14:04:57 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 14:04:57 --> Final output sent to browser
DEBUG - 2016-09-07 14:04:57 --> Total execution time: 1.0000
INFO - 2016-09-07 14:05:21 --> Config Class Initialized
INFO - 2016-09-07 14:05:21 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:05:21 --> UTF-8 Support Enabled
INFO - 2016-09-07 14:05:21 --> Utf8 Class Initialized
INFO - 2016-09-07 14:05:21 --> URI Class Initialized
INFO - 2016-09-07 14:05:21 --> Router Class Initialized
INFO - 2016-09-07 14:05:21 --> Output Class Initialized
INFO - 2016-09-07 14:05:21 --> Security Class Initialized
DEBUG - 2016-09-07 14:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 14:05:21 --> Input Class Initialized
INFO - 2016-09-07 14:05:21 --> Language Class Initialized
INFO - 2016-09-07 14:05:21 --> Language Class Initialized
INFO - 2016-09-07 14:05:21 --> Config Class Initialized
INFO - 2016-09-07 14:05:22 --> Loader Class Initialized
INFO - 2016-09-07 14:05:22 --> Helper loaded: url_helper
INFO - 2016-09-07 14:05:22 --> Database Driver Class Initialized
INFO - 2016-09-07 14:05:22 --> Controller Class Initialized
DEBUG - 2016-09-07 14:05:22 --> Index MX_Controller Initialized
INFO - 2016-09-07 14:05:22 --> Model Class Initialized
INFO - 2016-09-07 14:05:22 --> Model Class Initialized
DEBUG - 2016-09-07 14:05:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 14:05:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 14:05:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 14:05:22 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-07 14:05:22 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-07 14:05:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 14:05:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-07 14:05:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 14:05:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 14:05:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 14:05:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 14:05:22 --> Final output sent to browser
DEBUG - 2016-09-07 14:05:22 --> Total execution time: 1.0282
INFO - 2016-09-07 14:05:53 --> Config Class Initialized
INFO - 2016-09-07 14:05:53 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:05:53 --> UTF-8 Support Enabled
INFO - 2016-09-07 14:05:53 --> Utf8 Class Initialized
INFO - 2016-09-07 14:05:53 --> URI Class Initialized
INFO - 2016-09-07 14:05:53 --> Router Class Initialized
INFO - 2016-09-07 14:05:53 --> Output Class Initialized
INFO - 2016-09-07 14:05:53 --> Security Class Initialized
DEBUG - 2016-09-07 14:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 14:05:53 --> Input Class Initialized
INFO - 2016-09-07 14:05:53 --> Language Class Initialized
INFO - 2016-09-07 14:05:53 --> Language Class Initialized
INFO - 2016-09-07 14:05:53 --> Config Class Initialized
INFO - 2016-09-07 14:05:53 --> Loader Class Initialized
INFO - 2016-09-07 14:05:53 --> Helper loaded: url_helper
INFO - 2016-09-07 14:05:53 --> Database Driver Class Initialized
INFO - 2016-09-07 14:05:53 --> Controller Class Initialized
DEBUG - 2016-09-07 14:05:54 --> Index MX_Controller Initialized
INFO - 2016-09-07 14:05:54 --> Model Class Initialized
INFO - 2016-09-07 14:05:54 --> Model Class Initialized
DEBUG - 2016-09-07 14:05:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 14:05:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 14:05:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 14:05:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 14:05:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 14:05:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 14:05:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 14:05:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 14:05:54 --> Final output sent to browser
DEBUG - 2016-09-07 14:05:54 --> Total execution time: 0.8655
INFO - 2016-09-07 14:06:25 --> Config Class Initialized
INFO - 2016-09-07 14:06:25 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:06:25 --> UTF-8 Support Enabled
INFO - 2016-09-07 14:06:25 --> Utf8 Class Initialized
INFO - 2016-09-07 14:06:25 --> URI Class Initialized
INFO - 2016-09-07 14:06:25 --> Router Class Initialized
INFO - 2016-09-07 14:06:25 --> Output Class Initialized
INFO - 2016-09-07 14:06:25 --> Security Class Initialized
DEBUG - 2016-09-07 14:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 14:06:25 --> Input Class Initialized
INFO - 2016-09-07 14:06:25 --> Language Class Initialized
INFO - 2016-09-07 14:06:25 --> Language Class Initialized
INFO - 2016-09-07 14:06:25 --> Config Class Initialized
INFO - 2016-09-07 14:06:25 --> Loader Class Initialized
INFO - 2016-09-07 14:06:25 --> Helper loaded: url_helper
INFO - 2016-09-07 14:06:25 --> Database Driver Class Initialized
INFO - 2016-09-07 14:06:26 --> Controller Class Initialized
DEBUG - 2016-09-07 14:06:26 --> Index MX_Controller Initialized
INFO - 2016-09-07 14:06:26 --> Model Class Initialized
INFO - 2016-09-07 14:06:26 --> Model Class Initialized
DEBUG - 2016-09-07 14:06:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 14:06:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 14:06:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 14:06:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 14:06:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 14:06:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 14:06:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 14:06:26 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 14:06:26 --> Final output sent to browser
DEBUG - 2016-09-07 14:06:26 --> Total execution time: 0.9367
INFO - 2016-09-07 14:06:30 --> Config Class Initialized
INFO - 2016-09-07 14:06:30 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:06:30 --> UTF-8 Support Enabled
INFO - 2016-09-07 14:06:30 --> Utf8 Class Initialized
INFO - 2016-09-07 14:06:30 --> URI Class Initialized
INFO - 2016-09-07 14:06:30 --> Router Class Initialized
INFO - 2016-09-07 14:06:30 --> Output Class Initialized
INFO - 2016-09-07 14:06:30 --> Security Class Initialized
DEBUG - 2016-09-07 14:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 14:06:30 --> Input Class Initialized
INFO - 2016-09-07 14:06:30 --> Language Class Initialized
INFO - 2016-09-07 14:06:30 --> Language Class Initialized
INFO - 2016-09-07 14:06:30 --> Config Class Initialized
INFO - 2016-09-07 14:06:30 --> Loader Class Initialized
INFO - 2016-09-07 14:06:30 --> Helper loaded: url_helper
INFO - 2016-09-07 14:06:30 --> Database Driver Class Initialized
INFO - 2016-09-07 14:06:30 --> Controller Class Initialized
DEBUG - 2016-09-07 14:06:30 --> Index MX_Controller Initialized
INFO - 2016-09-07 14:06:30 --> Model Class Initialized
INFO - 2016-09-07 14:06:30 --> Model Class Initialized
DEBUG - 2016-09-07 14:06:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 14:06:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 14:06:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 14:06:30 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-07 14:06:30 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-07 14:06:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 14:06:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-07 14:06:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 14:06:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 14:06:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 14:06:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 14:06:31 --> Final output sent to browser
DEBUG - 2016-09-07 14:06:31 --> Total execution time: 0.9910
INFO - 2016-09-07 14:06:54 --> Config Class Initialized
INFO - 2016-09-07 14:06:54 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:06:54 --> UTF-8 Support Enabled
INFO - 2016-09-07 14:06:54 --> Utf8 Class Initialized
INFO - 2016-09-07 14:06:54 --> URI Class Initialized
INFO - 2016-09-07 14:06:54 --> Router Class Initialized
INFO - 2016-09-07 14:06:54 --> Output Class Initialized
INFO - 2016-09-07 14:06:54 --> Security Class Initialized
DEBUG - 2016-09-07 14:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 14:06:54 --> Input Class Initialized
INFO - 2016-09-07 14:06:54 --> Language Class Initialized
INFO - 2016-09-07 14:06:54 --> Language Class Initialized
INFO - 2016-09-07 14:06:54 --> Config Class Initialized
INFO - 2016-09-07 14:06:54 --> Loader Class Initialized
INFO - 2016-09-07 14:06:54 --> Helper loaded: url_helper
INFO - 2016-09-07 14:06:54 --> Database Driver Class Initialized
INFO - 2016-09-07 14:06:54 --> Controller Class Initialized
DEBUG - 2016-09-07 14:06:54 --> Index MX_Controller Initialized
INFO - 2016-09-07 14:06:54 --> Model Class Initialized
INFO - 2016-09-07 14:06:54 --> Model Class Initialized
DEBUG - 2016-09-07 14:06:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 14:06:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 14:06:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 14:06:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 14:06:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 14:06:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 14:06:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 14:06:54 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 14:06:54 --> Final output sent to browser
DEBUG - 2016-09-07 14:06:55 --> Total execution time: 0.8438
INFO - 2016-09-07 14:06:57 --> Config Class Initialized
INFO - 2016-09-07 14:06:57 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:06:57 --> UTF-8 Support Enabled
INFO - 2016-09-07 14:06:57 --> Utf8 Class Initialized
INFO - 2016-09-07 14:06:57 --> URI Class Initialized
INFO - 2016-09-07 14:06:57 --> Router Class Initialized
INFO - 2016-09-07 14:06:57 --> Output Class Initialized
INFO - 2016-09-07 14:06:58 --> Security Class Initialized
DEBUG - 2016-09-07 14:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 14:06:58 --> Input Class Initialized
INFO - 2016-09-07 14:06:58 --> Language Class Initialized
INFO - 2016-09-07 14:06:58 --> Language Class Initialized
INFO - 2016-09-07 14:06:58 --> Config Class Initialized
INFO - 2016-09-07 14:06:58 --> Loader Class Initialized
INFO - 2016-09-07 14:06:58 --> Helper loaded: url_helper
INFO - 2016-09-07 14:06:58 --> Database Driver Class Initialized
INFO - 2016-09-07 14:06:58 --> Controller Class Initialized
DEBUG - 2016-09-07 14:06:58 --> Index MX_Controller Initialized
INFO - 2016-09-07 14:06:58 --> Model Class Initialized
INFO - 2016-09-07 14:06:58 --> Model Class Initialized
DEBUG - 2016-09-07 14:06:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 14:06:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 14:06:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 14:06:58 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-07 14:06:58 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-07 14:06:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 14:06:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-07 14:06:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 14:06:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 14:06:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 14:06:58 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 14:06:58 --> Final output sent to browser
DEBUG - 2016-09-07 14:06:58 --> Total execution time: 1.0166
INFO - 2016-09-07 14:09:21 --> Config Class Initialized
INFO - 2016-09-07 14:09:21 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:09:22 --> UTF-8 Support Enabled
INFO - 2016-09-07 14:09:22 --> Utf8 Class Initialized
INFO - 2016-09-07 14:09:22 --> URI Class Initialized
INFO - 2016-09-07 14:09:22 --> Router Class Initialized
INFO - 2016-09-07 14:09:22 --> Output Class Initialized
INFO - 2016-09-07 14:09:22 --> Security Class Initialized
DEBUG - 2016-09-07 14:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 14:09:22 --> Input Class Initialized
INFO - 2016-09-07 14:09:22 --> Language Class Initialized
INFO - 2016-09-07 14:09:22 --> Language Class Initialized
INFO - 2016-09-07 14:09:22 --> Config Class Initialized
INFO - 2016-09-07 14:09:22 --> Loader Class Initialized
INFO - 2016-09-07 14:09:22 --> Helper loaded: url_helper
INFO - 2016-09-07 14:09:22 --> Database Driver Class Initialized
INFO - 2016-09-07 14:09:22 --> Controller Class Initialized
DEBUG - 2016-09-07 14:09:22 --> Index MX_Controller Initialized
INFO - 2016-09-07 14:09:22 --> Model Class Initialized
INFO - 2016-09-07 14:09:22 --> Model Class Initialized
DEBUG - 2016-09-07 14:09:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 14:09:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 14:09:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 14:09:22 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-07 14:09:22 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-07 14:09:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 14:09:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-07 14:09:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 14:09:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 14:09:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 14:09:22 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 14:09:22 --> Final output sent to browser
DEBUG - 2016-09-07 14:09:22 --> Total execution time: 0.9679
INFO - 2016-09-07 14:12:24 --> Config Class Initialized
INFO - 2016-09-07 14:12:24 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:12:24 --> UTF-8 Support Enabled
INFO - 2016-09-07 14:12:24 --> Utf8 Class Initialized
INFO - 2016-09-07 14:12:24 --> URI Class Initialized
INFO - 2016-09-07 14:12:24 --> Router Class Initialized
INFO - 2016-09-07 14:12:24 --> Output Class Initialized
INFO - 2016-09-07 14:12:24 --> Security Class Initialized
DEBUG - 2016-09-07 14:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 14:12:24 --> Input Class Initialized
INFO - 2016-09-07 14:12:24 --> Language Class Initialized
INFO - 2016-09-07 14:12:24 --> Language Class Initialized
INFO - 2016-09-07 14:12:24 --> Config Class Initialized
INFO - 2016-09-07 14:12:24 --> Loader Class Initialized
INFO - 2016-09-07 14:12:24 --> Helper loaded: url_helper
INFO - 2016-09-07 14:12:24 --> Database Driver Class Initialized
INFO - 2016-09-07 14:12:24 --> Controller Class Initialized
DEBUG - 2016-09-07 14:12:24 --> Index MX_Controller Initialized
INFO - 2016-09-07 14:12:24 --> Model Class Initialized
INFO - 2016-09-07 14:12:24 --> Model Class Initialized
DEBUG - 2016-09-07 14:12:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 14:12:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 14:12:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 14:12:24 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-07 14:12:24 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-07 14:12:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 14:12:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-07 14:12:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 14:12:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 14:12:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 14:12:24 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 14:12:24 --> Final output sent to browser
DEBUG - 2016-09-07 14:12:25 --> Total execution time: 0.9626
INFO - 2016-09-07 14:12:56 --> Config Class Initialized
INFO - 2016-09-07 14:12:56 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:12:56 --> UTF-8 Support Enabled
INFO - 2016-09-07 14:12:56 --> Utf8 Class Initialized
INFO - 2016-09-07 14:12:56 --> URI Class Initialized
INFO - 2016-09-07 14:12:56 --> Router Class Initialized
INFO - 2016-09-07 14:12:56 --> Output Class Initialized
INFO - 2016-09-07 14:12:56 --> Security Class Initialized
DEBUG - 2016-09-07 14:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 14:12:56 --> Input Class Initialized
INFO - 2016-09-07 14:12:56 --> Language Class Initialized
INFO - 2016-09-07 14:12:56 --> Language Class Initialized
INFO - 2016-09-07 14:12:56 --> Config Class Initialized
INFO - 2016-09-07 14:12:56 --> Loader Class Initialized
INFO - 2016-09-07 14:12:56 --> Helper loaded: url_helper
INFO - 2016-09-07 14:12:56 --> Database Driver Class Initialized
INFO - 2016-09-07 14:12:56 --> Controller Class Initialized
DEBUG - 2016-09-07 14:12:56 --> Index MX_Controller Initialized
INFO - 2016-09-07 14:12:56 --> Model Class Initialized
INFO - 2016-09-07 14:12:56 --> Model Class Initialized
DEBUG - 2016-09-07 14:12:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 14:12:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 14:12:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 14:12:56 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-07 14:12:56 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-07 14:12:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 14:12:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-07 14:12:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 14:12:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 14:12:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 14:12:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 14:12:56 --> Final output sent to browser
DEBUG - 2016-09-07 14:12:57 --> Total execution time: 0.9427
INFO - 2016-09-07 14:14:22 --> Config Class Initialized
INFO - 2016-09-07 14:14:22 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:14:22 --> UTF-8 Support Enabled
INFO - 2016-09-07 14:14:22 --> Utf8 Class Initialized
INFO - 2016-09-07 14:14:22 --> URI Class Initialized
INFO - 2016-09-07 14:14:22 --> Router Class Initialized
INFO - 2016-09-07 14:14:22 --> Output Class Initialized
INFO - 2016-09-07 14:14:22 --> Security Class Initialized
DEBUG - 2016-09-07 14:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 14:14:22 --> Input Class Initialized
INFO - 2016-09-07 14:14:22 --> Language Class Initialized
INFO - 2016-09-07 14:14:22 --> Language Class Initialized
INFO - 2016-09-07 14:14:22 --> Config Class Initialized
INFO - 2016-09-07 14:14:23 --> Loader Class Initialized
INFO - 2016-09-07 14:14:23 --> Helper loaded: url_helper
INFO - 2016-09-07 14:14:23 --> Database Driver Class Initialized
INFO - 2016-09-07 14:14:23 --> Controller Class Initialized
DEBUG - 2016-09-07 14:14:23 --> Index MX_Controller Initialized
INFO - 2016-09-07 14:14:23 --> Model Class Initialized
INFO - 2016-09-07 14:14:23 --> Model Class Initialized
DEBUG - 2016-09-07 14:14:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 14:14:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 14:14:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 14:14:23 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-07 14:14:23 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-07 14:14:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 14:14:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-07 14:14:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 14:14:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 14:14:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 14:14:23 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 14:14:23 --> Final output sent to browser
DEBUG - 2016-09-07 14:14:23 --> Total execution time: 0.9608
INFO - 2016-09-07 14:19:55 --> Config Class Initialized
INFO - 2016-09-07 14:19:55 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:19:55 --> UTF-8 Support Enabled
INFO - 2016-09-07 14:19:55 --> Utf8 Class Initialized
INFO - 2016-09-07 14:19:55 --> URI Class Initialized
INFO - 2016-09-07 14:19:55 --> Router Class Initialized
INFO - 2016-09-07 14:19:55 --> Output Class Initialized
INFO - 2016-09-07 14:19:55 --> Security Class Initialized
DEBUG - 2016-09-07 14:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 14:19:55 --> Input Class Initialized
INFO - 2016-09-07 14:19:55 --> Language Class Initialized
INFO - 2016-09-07 14:19:55 --> Language Class Initialized
INFO - 2016-09-07 14:19:55 --> Config Class Initialized
INFO - 2016-09-07 14:19:55 --> Loader Class Initialized
INFO - 2016-09-07 14:19:55 --> Helper loaded: url_helper
INFO - 2016-09-07 14:19:55 --> Database Driver Class Initialized
INFO - 2016-09-07 14:19:55 --> Controller Class Initialized
DEBUG - 2016-09-07 14:19:55 --> Index MX_Controller Initialized
INFO - 2016-09-07 14:19:55 --> Model Class Initialized
INFO - 2016-09-07 14:19:55 --> Model Class Initialized
DEBUG - 2016-09-07 14:19:55 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 14:19:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 14:19:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 14:19:56 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-07 14:19:56 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-07 14:19:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 14:19:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-07 14:19:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 14:19:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 14:19:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 14:19:56 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 14:19:56 --> Final output sent to browser
DEBUG - 2016-09-07 14:19:56 --> Total execution time: 0.9794
INFO - 2016-09-07 14:20:38 --> Config Class Initialized
INFO - 2016-09-07 14:20:38 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:20:38 --> UTF-8 Support Enabled
INFO - 2016-09-07 14:20:38 --> Utf8 Class Initialized
INFO - 2016-09-07 14:20:38 --> URI Class Initialized
INFO - 2016-09-07 14:20:38 --> Router Class Initialized
INFO - 2016-09-07 14:20:38 --> Output Class Initialized
INFO - 2016-09-07 14:20:38 --> Security Class Initialized
DEBUG - 2016-09-07 14:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 14:20:38 --> Input Class Initialized
INFO - 2016-09-07 14:20:38 --> Language Class Initialized
INFO - 2016-09-07 14:20:38 --> Language Class Initialized
INFO - 2016-09-07 14:20:38 --> Config Class Initialized
INFO - 2016-09-07 14:20:38 --> Loader Class Initialized
INFO - 2016-09-07 14:20:38 --> Helper loaded: url_helper
INFO - 2016-09-07 14:20:38 --> Database Driver Class Initialized
INFO - 2016-09-07 14:20:38 --> Controller Class Initialized
DEBUG - 2016-09-07 14:20:38 --> Index MX_Controller Initialized
INFO - 2016-09-07 14:20:38 --> Model Class Initialized
INFO - 2016-09-07 14:20:38 --> Model Class Initialized
DEBUG - 2016-09-07 14:20:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 14:20:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 14:20:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 14:20:38 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-07 14:20:38 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-07 14:20:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 14:20:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-07 14:20:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 14:20:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 14:20:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 14:20:39 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 14:20:39 --> Final output sent to browser
DEBUG - 2016-09-07 14:20:39 --> Total execution time: 0.9902
INFO - 2016-09-07 14:20:43 --> Config Class Initialized
INFO - 2016-09-07 14:20:43 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:20:43 --> UTF-8 Support Enabled
INFO - 2016-09-07 14:20:43 --> Utf8 Class Initialized
INFO - 2016-09-07 14:20:43 --> URI Class Initialized
INFO - 2016-09-07 14:20:43 --> Router Class Initialized
INFO - 2016-09-07 14:20:43 --> Output Class Initialized
INFO - 2016-09-07 14:20:43 --> Security Class Initialized
DEBUG - 2016-09-07 14:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 14:20:43 --> Input Class Initialized
INFO - 2016-09-07 14:20:43 --> Language Class Initialized
INFO - 2016-09-07 14:20:43 --> Language Class Initialized
INFO - 2016-09-07 14:20:43 --> Config Class Initialized
INFO - 2016-09-07 14:20:43 --> Loader Class Initialized
INFO - 2016-09-07 14:20:43 --> Helper loaded: url_helper
INFO - 2016-09-07 14:20:43 --> Database Driver Class Initialized
INFO - 2016-09-07 14:20:43 --> Controller Class Initialized
DEBUG - 2016-09-07 14:20:43 --> Index MX_Controller Initialized
INFO - 2016-09-07 14:20:43 --> Model Class Initialized
INFO - 2016-09-07 14:20:43 --> Model Class Initialized
DEBUG - 2016-09-07 14:20:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 14:20:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 14:20:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 14:20:43 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-07 14:20:43 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-07 14:20:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 14:20:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-07 14:20:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 14:20:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 14:20:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 14:20:44 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 14:20:44 --> Final output sent to browser
DEBUG - 2016-09-07 14:20:44 --> Total execution time: 0.9784
INFO - 2016-09-07 14:23:00 --> Config Class Initialized
INFO - 2016-09-07 14:23:00 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:23:00 --> UTF-8 Support Enabled
INFO - 2016-09-07 14:23:00 --> Utf8 Class Initialized
INFO - 2016-09-07 14:23:00 --> URI Class Initialized
INFO - 2016-09-07 14:23:00 --> Router Class Initialized
INFO - 2016-09-07 14:23:00 --> Output Class Initialized
INFO - 2016-09-07 14:23:00 --> Security Class Initialized
DEBUG - 2016-09-07 14:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 14:23:00 --> Input Class Initialized
INFO - 2016-09-07 14:23:00 --> Language Class Initialized
INFO - 2016-09-07 14:23:00 --> Language Class Initialized
INFO - 2016-09-07 14:23:00 --> Config Class Initialized
INFO - 2016-09-07 14:23:00 --> Loader Class Initialized
INFO - 2016-09-07 14:23:00 --> Helper loaded: url_helper
INFO - 2016-09-07 14:23:00 --> Database Driver Class Initialized
INFO - 2016-09-07 14:23:00 --> Controller Class Initialized
DEBUG - 2016-09-07 14:23:00 --> Index MX_Controller Initialized
INFO - 2016-09-07 14:23:00 --> Model Class Initialized
INFO - 2016-09-07 14:23:00 --> Model Class Initialized
DEBUG - 2016-09-07 14:23:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 14:23:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 14:23:00 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 14:23:01 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-07 14:23:01 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-07 14:23:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 14:23:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-07 14:23:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 14:23:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 14:23:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 14:23:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 14:23:01 --> Final output sent to browser
DEBUG - 2016-09-07 14:23:01 --> Total execution time: 0.9396
INFO - 2016-09-07 14:24:01 --> Config Class Initialized
INFO - 2016-09-07 14:24:01 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:24:01 --> UTF-8 Support Enabled
INFO - 2016-09-07 14:24:01 --> Utf8 Class Initialized
INFO - 2016-09-07 14:24:01 --> URI Class Initialized
INFO - 2016-09-07 14:24:01 --> Router Class Initialized
INFO - 2016-09-07 14:24:02 --> Output Class Initialized
INFO - 2016-09-07 14:24:02 --> Security Class Initialized
DEBUG - 2016-09-07 14:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 14:24:02 --> Input Class Initialized
INFO - 2016-09-07 14:24:02 --> Language Class Initialized
INFO - 2016-09-07 14:24:02 --> Language Class Initialized
INFO - 2016-09-07 14:24:02 --> Config Class Initialized
INFO - 2016-09-07 14:24:02 --> Loader Class Initialized
INFO - 2016-09-07 14:24:02 --> Helper loaded: url_helper
INFO - 2016-09-07 14:24:02 --> Database Driver Class Initialized
INFO - 2016-09-07 14:24:02 --> Controller Class Initialized
DEBUG - 2016-09-07 14:24:02 --> Index MX_Controller Initialized
INFO - 2016-09-07 14:24:02 --> Model Class Initialized
INFO - 2016-09-07 14:24:02 --> Model Class Initialized
DEBUG - 2016-09-07 14:24:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 14:24:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 14:24:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 14:24:02 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-07 14:24:02 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-07 14:24:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 14:24:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-07 14:24:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 14:24:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 14:24:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 14:24:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 14:24:02 --> Final output sent to browser
DEBUG - 2016-09-07 14:24:02 --> Total execution time: 0.9788
INFO - 2016-09-07 14:25:50 --> Config Class Initialized
INFO - 2016-09-07 14:25:51 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:25:51 --> UTF-8 Support Enabled
INFO - 2016-09-07 14:25:51 --> Utf8 Class Initialized
INFO - 2016-09-07 14:25:51 --> URI Class Initialized
INFO - 2016-09-07 14:25:51 --> Router Class Initialized
INFO - 2016-09-07 14:25:51 --> Output Class Initialized
INFO - 2016-09-07 14:25:51 --> Security Class Initialized
DEBUG - 2016-09-07 14:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 14:25:51 --> Input Class Initialized
INFO - 2016-09-07 14:25:51 --> Language Class Initialized
INFO - 2016-09-07 14:25:51 --> Language Class Initialized
INFO - 2016-09-07 14:25:51 --> Config Class Initialized
INFO - 2016-09-07 14:25:51 --> Loader Class Initialized
INFO - 2016-09-07 14:25:51 --> Helper loaded: url_helper
INFO - 2016-09-07 14:25:51 --> Database Driver Class Initialized
INFO - 2016-09-07 14:25:51 --> Controller Class Initialized
DEBUG - 2016-09-07 14:25:51 --> Index MX_Controller Initialized
INFO - 2016-09-07 14:25:51 --> Model Class Initialized
INFO - 2016-09-07 14:25:51 --> Model Class Initialized
DEBUG - 2016-09-07 14:25:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 14:25:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 14:25:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 14:25:51 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-07 14:25:51 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-07 14:25:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 14:25:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-07 14:25:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 14:25:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 14:25:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 14:25:51 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 14:25:51 --> Final output sent to browser
DEBUG - 2016-09-07 14:25:52 --> Total execution time: 0.9775
INFO - 2016-09-07 14:26:42 --> Config Class Initialized
INFO - 2016-09-07 14:26:42 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:26:42 --> UTF-8 Support Enabled
INFO - 2016-09-07 14:26:42 --> Utf8 Class Initialized
INFO - 2016-09-07 14:26:42 --> URI Class Initialized
INFO - 2016-09-07 14:26:42 --> Router Class Initialized
INFO - 2016-09-07 14:26:42 --> Output Class Initialized
INFO - 2016-09-07 14:26:42 --> Security Class Initialized
DEBUG - 2016-09-07 14:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 14:26:42 --> Input Class Initialized
INFO - 2016-09-07 14:26:42 --> Language Class Initialized
INFO - 2016-09-07 14:26:42 --> Language Class Initialized
INFO - 2016-09-07 14:26:42 --> Config Class Initialized
INFO - 2016-09-07 14:26:43 --> Loader Class Initialized
INFO - 2016-09-07 14:26:43 --> Helper loaded: url_helper
INFO - 2016-09-07 14:26:43 --> Database Driver Class Initialized
INFO - 2016-09-07 14:26:43 --> Controller Class Initialized
DEBUG - 2016-09-07 14:26:43 --> Index MX_Controller Initialized
INFO - 2016-09-07 14:26:43 --> Model Class Initialized
INFO - 2016-09-07 14:26:43 --> Model Class Initialized
DEBUG - 2016-09-07 14:26:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 14:26:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 14:26:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 14:26:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 14:26:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 14:26:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 14:26:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 14:26:43 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 14:26:43 --> Final output sent to browser
DEBUG - 2016-09-07 14:26:43 --> Total execution time: 0.9326
INFO - 2016-09-07 14:26:56 --> Config Class Initialized
INFO - 2016-09-07 14:26:56 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:26:56 --> UTF-8 Support Enabled
INFO - 2016-09-07 14:26:56 --> Utf8 Class Initialized
INFO - 2016-09-07 14:26:56 --> URI Class Initialized
INFO - 2016-09-07 14:26:56 --> Router Class Initialized
INFO - 2016-09-07 14:26:56 --> Output Class Initialized
INFO - 2016-09-07 14:26:56 --> Security Class Initialized
DEBUG - 2016-09-07 14:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 14:26:56 --> Input Class Initialized
INFO - 2016-09-07 14:26:56 --> Language Class Initialized
INFO - 2016-09-07 14:26:56 --> Language Class Initialized
INFO - 2016-09-07 14:26:56 --> Config Class Initialized
INFO - 2016-09-07 14:26:56 --> Loader Class Initialized
INFO - 2016-09-07 14:26:56 --> Helper loaded: url_helper
INFO - 2016-09-07 14:26:56 --> Database Driver Class Initialized
INFO - 2016-09-07 14:26:56 --> Controller Class Initialized
DEBUG - 2016-09-07 14:26:56 --> Index MX_Controller Initialized
INFO - 2016-09-07 14:26:56 --> Model Class Initialized
INFO - 2016-09-07 14:26:56 --> Model Class Initialized
DEBUG - 2016-09-07 14:26:56 --> Anggota MX_Controller Initialized
INFO - 2016-09-07 14:26:56 --> Final output sent to browser
DEBUG - 2016-09-07 14:26:56 --> Total execution time: 0.7850
INFO - 2016-09-07 14:26:58 --> Config Class Initialized
INFO - 2016-09-07 14:26:58 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:26:58 --> UTF-8 Support Enabled
INFO - 2016-09-07 14:26:58 --> Utf8 Class Initialized
INFO - 2016-09-07 14:26:58 --> URI Class Initialized
INFO - 2016-09-07 14:26:59 --> Router Class Initialized
INFO - 2016-09-07 14:26:59 --> Output Class Initialized
INFO - 2016-09-07 14:26:59 --> Security Class Initialized
DEBUG - 2016-09-07 14:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 14:26:59 --> Input Class Initialized
INFO - 2016-09-07 14:26:59 --> Language Class Initialized
INFO - 2016-09-07 14:26:59 --> Language Class Initialized
INFO - 2016-09-07 14:26:59 --> Config Class Initialized
INFO - 2016-09-07 14:26:59 --> Loader Class Initialized
INFO - 2016-09-07 14:26:59 --> Helper loaded: url_helper
INFO - 2016-09-07 14:26:59 --> Database Driver Class Initialized
INFO - 2016-09-07 14:26:59 --> Controller Class Initialized
DEBUG - 2016-09-07 14:26:59 --> Index MX_Controller Initialized
INFO - 2016-09-07 14:26:59 --> Model Class Initialized
INFO - 2016-09-07 14:26:59 --> Model Class Initialized
DEBUG - 2016-09-07 14:26:59 --> Anggota MX_Controller Initialized
INFO - 2016-09-07 14:26:59 --> Final output sent to browser
DEBUG - 2016-09-07 14:26:59 --> Total execution time: 0.7979
INFO - 2016-09-07 14:27:00 --> Config Class Initialized
INFO - 2016-09-07 14:27:00 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:27:00 --> UTF-8 Support Enabled
INFO - 2016-09-07 14:27:00 --> Utf8 Class Initialized
INFO - 2016-09-07 14:27:00 --> URI Class Initialized
INFO - 2016-09-07 14:27:00 --> Router Class Initialized
INFO - 2016-09-07 14:27:00 --> Output Class Initialized
INFO - 2016-09-07 14:27:01 --> Security Class Initialized
DEBUG - 2016-09-07 14:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 14:27:01 --> Input Class Initialized
INFO - 2016-09-07 14:27:01 --> Language Class Initialized
INFO - 2016-09-07 14:27:01 --> Language Class Initialized
INFO - 2016-09-07 14:27:01 --> Config Class Initialized
INFO - 2016-09-07 14:27:01 --> Loader Class Initialized
INFO - 2016-09-07 14:27:01 --> Helper loaded: url_helper
INFO - 2016-09-07 14:27:01 --> Database Driver Class Initialized
INFO - 2016-09-07 14:27:01 --> Controller Class Initialized
DEBUG - 2016-09-07 14:27:01 --> Index MX_Controller Initialized
INFO - 2016-09-07 14:27:01 --> Model Class Initialized
INFO - 2016-09-07 14:27:01 --> Model Class Initialized
DEBUG - 2016-09-07 14:27:01 --> Anggota MX_Controller Initialized
INFO - 2016-09-07 14:27:01 --> Final output sent to browser
DEBUG - 2016-09-07 14:27:01 --> Total execution time: 0.8621
INFO - 2016-09-07 14:27:03 --> Config Class Initialized
INFO - 2016-09-07 14:27:03 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:27:03 --> UTF-8 Support Enabled
INFO - 2016-09-07 14:27:03 --> Utf8 Class Initialized
INFO - 2016-09-07 14:27:03 --> URI Class Initialized
INFO - 2016-09-07 14:27:03 --> Router Class Initialized
INFO - 2016-09-07 14:27:03 --> Output Class Initialized
INFO - 2016-09-07 14:27:03 --> Security Class Initialized
DEBUG - 2016-09-07 14:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 14:27:03 --> Input Class Initialized
INFO - 2016-09-07 14:27:03 --> Language Class Initialized
INFO - 2016-09-07 14:27:03 --> Language Class Initialized
INFO - 2016-09-07 14:27:03 --> Config Class Initialized
INFO - 2016-09-07 14:27:03 --> Loader Class Initialized
INFO - 2016-09-07 14:27:03 --> Helper loaded: url_helper
INFO - 2016-09-07 14:27:03 --> Database Driver Class Initialized
INFO - 2016-09-07 14:27:03 --> Controller Class Initialized
DEBUG - 2016-09-07 14:27:03 --> Index MX_Controller Initialized
INFO - 2016-09-07 14:27:03 --> Model Class Initialized
INFO - 2016-09-07 14:27:03 --> Model Class Initialized
DEBUG - 2016-09-07 14:27:03 --> Anggota MX_Controller Initialized
INFO - 2016-09-07 14:27:04 --> Final output sent to browser
DEBUG - 2016-09-07 14:27:04 --> Total execution time: 0.8692
INFO - 2016-09-07 14:27:05 --> Config Class Initialized
INFO - 2016-09-07 14:27:05 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:27:05 --> UTF-8 Support Enabled
INFO - 2016-09-07 14:27:05 --> Utf8 Class Initialized
INFO - 2016-09-07 14:27:05 --> URI Class Initialized
INFO - 2016-09-07 14:27:05 --> Router Class Initialized
INFO - 2016-09-07 14:27:05 --> Output Class Initialized
INFO - 2016-09-07 14:27:05 --> Security Class Initialized
DEBUG - 2016-09-07 14:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 14:27:05 --> Input Class Initialized
INFO - 2016-09-07 14:27:05 --> Language Class Initialized
INFO - 2016-09-07 14:27:05 --> Language Class Initialized
INFO - 2016-09-07 14:27:05 --> Config Class Initialized
INFO - 2016-09-07 14:27:05 --> Loader Class Initialized
INFO - 2016-09-07 14:27:05 --> Helper loaded: url_helper
INFO - 2016-09-07 14:27:05 --> Database Driver Class Initialized
INFO - 2016-09-07 14:27:05 --> Controller Class Initialized
DEBUG - 2016-09-07 14:27:05 --> Index MX_Controller Initialized
INFO - 2016-09-07 14:27:05 --> Model Class Initialized
INFO - 2016-09-07 14:27:05 --> Model Class Initialized
DEBUG - 2016-09-07 14:27:05 --> Anggota MX_Controller Initialized
INFO - 2016-09-07 14:27:06 --> Final output sent to browser
DEBUG - 2016-09-07 14:27:06 --> Total execution time: 0.8706
INFO - 2016-09-07 14:27:06 --> Config Class Initialized
INFO - 2016-09-07 14:27:07 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:27:07 --> UTF-8 Support Enabled
INFO - 2016-09-07 14:27:07 --> Utf8 Class Initialized
INFO - 2016-09-07 14:27:07 --> URI Class Initialized
INFO - 2016-09-07 14:27:07 --> Router Class Initialized
INFO - 2016-09-07 14:27:07 --> Output Class Initialized
INFO - 2016-09-07 14:27:07 --> Security Class Initialized
DEBUG - 2016-09-07 14:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 14:27:07 --> Input Class Initialized
INFO - 2016-09-07 14:27:07 --> Language Class Initialized
INFO - 2016-09-07 14:27:07 --> Language Class Initialized
INFO - 2016-09-07 14:27:07 --> Config Class Initialized
INFO - 2016-09-07 14:27:07 --> Loader Class Initialized
INFO - 2016-09-07 14:27:07 --> Helper loaded: url_helper
INFO - 2016-09-07 14:27:07 --> Database Driver Class Initialized
INFO - 2016-09-07 14:27:07 --> Controller Class Initialized
DEBUG - 2016-09-07 14:27:07 --> Index MX_Controller Initialized
INFO - 2016-09-07 14:27:07 --> Model Class Initialized
INFO - 2016-09-07 14:27:07 --> Model Class Initialized
DEBUG - 2016-09-07 14:27:07 --> Anggota MX_Controller Initialized
INFO - 2016-09-07 14:27:07 --> Final output sent to browser
DEBUG - 2016-09-07 14:27:07 --> Total execution time: 0.8118
INFO - 2016-09-07 14:27:08 --> Config Class Initialized
INFO - 2016-09-07 14:27:08 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:27:08 --> UTF-8 Support Enabled
INFO - 2016-09-07 14:27:08 --> Utf8 Class Initialized
INFO - 2016-09-07 14:27:08 --> URI Class Initialized
INFO - 2016-09-07 14:27:08 --> Router Class Initialized
INFO - 2016-09-07 14:27:08 --> Output Class Initialized
INFO - 2016-09-07 14:27:08 --> Security Class Initialized
DEBUG - 2016-09-07 14:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 14:27:08 --> Input Class Initialized
INFO - 2016-09-07 14:27:09 --> Language Class Initialized
INFO - 2016-09-07 14:27:09 --> Language Class Initialized
INFO - 2016-09-07 14:27:09 --> Config Class Initialized
INFO - 2016-09-07 14:27:09 --> Loader Class Initialized
INFO - 2016-09-07 14:27:09 --> Helper loaded: url_helper
INFO - 2016-09-07 14:27:09 --> Database Driver Class Initialized
INFO - 2016-09-07 14:27:09 --> Controller Class Initialized
DEBUG - 2016-09-07 14:27:09 --> Index MX_Controller Initialized
INFO - 2016-09-07 14:27:09 --> Model Class Initialized
INFO - 2016-09-07 14:27:09 --> Model Class Initialized
DEBUG - 2016-09-07 14:27:09 --> Anggota MX_Controller Initialized
INFO - 2016-09-07 14:27:09 --> Final output sent to browser
DEBUG - 2016-09-07 14:27:09 --> Total execution time: 0.7927
INFO - 2016-09-07 14:27:10 --> Config Class Initialized
INFO - 2016-09-07 14:27:10 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:27:10 --> UTF-8 Support Enabled
INFO - 2016-09-07 14:27:10 --> Utf8 Class Initialized
INFO - 2016-09-07 14:27:10 --> URI Class Initialized
INFO - 2016-09-07 14:27:10 --> Router Class Initialized
INFO - 2016-09-07 14:27:10 --> Output Class Initialized
INFO - 2016-09-07 14:27:10 --> Security Class Initialized
DEBUG - 2016-09-07 14:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 14:27:10 --> Input Class Initialized
INFO - 2016-09-07 14:27:10 --> Language Class Initialized
INFO - 2016-09-07 14:27:10 --> Language Class Initialized
INFO - 2016-09-07 14:27:10 --> Config Class Initialized
INFO - 2016-09-07 14:27:10 --> Loader Class Initialized
INFO - 2016-09-07 14:27:10 --> Helper loaded: url_helper
INFO - 2016-09-07 14:27:10 --> Database Driver Class Initialized
INFO - 2016-09-07 14:27:10 --> Controller Class Initialized
DEBUG - 2016-09-07 14:27:10 --> Index MX_Controller Initialized
INFO - 2016-09-07 14:27:10 --> Model Class Initialized
INFO - 2016-09-07 14:27:10 --> Model Class Initialized
DEBUG - 2016-09-07 14:27:10 --> Anggota MX_Controller Initialized
INFO - 2016-09-07 14:27:11 --> Final output sent to browser
DEBUG - 2016-09-07 14:27:11 --> Total execution time: 0.8595
INFO - 2016-09-07 14:27:11 --> Config Class Initialized
INFO - 2016-09-07 14:27:11 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:27:11 --> UTF-8 Support Enabled
INFO - 2016-09-07 14:27:12 --> Utf8 Class Initialized
INFO - 2016-09-07 14:27:12 --> URI Class Initialized
INFO - 2016-09-07 14:27:12 --> Router Class Initialized
INFO - 2016-09-07 14:27:12 --> Output Class Initialized
INFO - 2016-09-07 14:27:12 --> Security Class Initialized
DEBUG - 2016-09-07 14:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 14:27:12 --> Input Class Initialized
INFO - 2016-09-07 14:27:12 --> Language Class Initialized
INFO - 2016-09-07 14:27:12 --> Language Class Initialized
INFO - 2016-09-07 14:27:12 --> Config Class Initialized
INFO - 2016-09-07 14:27:12 --> Loader Class Initialized
INFO - 2016-09-07 14:27:12 --> Helper loaded: url_helper
INFO - 2016-09-07 14:27:12 --> Database Driver Class Initialized
INFO - 2016-09-07 14:27:12 --> Controller Class Initialized
DEBUG - 2016-09-07 14:27:12 --> Index MX_Controller Initialized
INFO - 2016-09-07 14:27:12 --> Model Class Initialized
INFO - 2016-09-07 14:27:12 --> Model Class Initialized
DEBUG - 2016-09-07 14:27:12 --> Anggota MX_Controller Initialized
INFO - 2016-09-07 14:27:12 --> Final output sent to browser
DEBUG - 2016-09-07 14:27:12 --> Total execution time: 0.8638
INFO - 2016-09-07 14:27:13 --> Config Class Initialized
INFO - 2016-09-07 14:27:13 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:27:13 --> UTF-8 Support Enabled
INFO - 2016-09-07 14:27:13 --> Utf8 Class Initialized
INFO - 2016-09-07 14:27:13 --> URI Class Initialized
INFO - 2016-09-07 14:27:13 --> Router Class Initialized
INFO - 2016-09-07 14:27:13 --> Output Class Initialized
INFO - 2016-09-07 14:27:13 --> Security Class Initialized
DEBUG - 2016-09-07 14:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 14:27:13 --> Input Class Initialized
INFO - 2016-09-07 14:27:13 --> Language Class Initialized
INFO - 2016-09-07 14:27:13 --> Language Class Initialized
INFO - 2016-09-07 14:27:13 --> Config Class Initialized
INFO - 2016-09-07 14:27:14 --> Loader Class Initialized
INFO - 2016-09-07 14:27:14 --> Helper loaded: url_helper
INFO - 2016-09-07 14:27:14 --> Database Driver Class Initialized
INFO - 2016-09-07 14:27:14 --> Controller Class Initialized
DEBUG - 2016-09-07 14:27:14 --> Index MX_Controller Initialized
INFO - 2016-09-07 14:27:14 --> Model Class Initialized
INFO - 2016-09-07 14:27:14 --> Model Class Initialized
DEBUG - 2016-09-07 14:27:14 --> Anggota MX_Controller Initialized
INFO - 2016-09-07 14:27:14 --> Final output sent to browser
DEBUG - 2016-09-07 14:27:14 --> Total execution time: 0.8404
INFO - 2016-09-07 14:27:15 --> Config Class Initialized
INFO - 2016-09-07 14:27:15 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:27:15 --> UTF-8 Support Enabled
INFO - 2016-09-07 14:27:15 --> Utf8 Class Initialized
INFO - 2016-09-07 14:27:15 --> URI Class Initialized
INFO - 2016-09-07 14:27:15 --> Router Class Initialized
INFO - 2016-09-07 14:27:15 --> Output Class Initialized
INFO - 2016-09-07 14:27:15 --> Security Class Initialized
DEBUG - 2016-09-07 14:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 14:27:15 --> Input Class Initialized
INFO - 2016-09-07 14:27:15 --> Language Class Initialized
INFO - 2016-09-07 14:27:15 --> Language Class Initialized
INFO - 2016-09-07 14:27:15 --> Config Class Initialized
INFO - 2016-09-07 14:27:15 --> Loader Class Initialized
INFO - 2016-09-07 14:27:15 --> Helper loaded: url_helper
INFO - 2016-09-07 14:27:15 --> Database Driver Class Initialized
INFO - 2016-09-07 14:27:15 --> Controller Class Initialized
DEBUG - 2016-09-07 14:27:15 --> Index MX_Controller Initialized
INFO - 2016-09-07 14:27:15 --> Model Class Initialized
INFO - 2016-09-07 14:27:16 --> Model Class Initialized
DEBUG - 2016-09-07 14:27:16 --> Anggota MX_Controller Initialized
INFO - 2016-09-07 14:27:16 --> Final output sent to browser
DEBUG - 2016-09-07 14:27:16 --> Total execution time: 0.7984
INFO - 2016-09-07 14:27:16 --> Config Class Initialized
INFO - 2016-09-07 14:27:17 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:27:17 --> UTF-8 Support Enabled
INFO - 2016-09-07 14:27:17 --> Utf8 Class Initialized
INFO - 2016-09-07 14:27:17 --> URI Class Initialized
INFO - 2016-09-07 14:27:17 --> Router Class Initialized
INFO - 2016-09-07 14:27:17 --> Output Class Initialized
INFO - 2016-09-07 14:27:17 --> Security Class Initialized
DEBUG - 2016-09-07 14:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 14:27:17 --> Input Class Initialized
INFO - 2016-09-07 14:27:17 --> Language Class Initialized
INFO - 2016-09-07 14:27:17 --> Language Class Initialized
INFO - 2016-09-07 14:27:17 --> Config Class Initialized
INFO - 2016-09-07 14:27:17 --> Loader Class Initialized
INFO - 2016-09-07 14:27:17 --> Helper loaded: url_helper
INFO - 2016-09-07 14:27:17 --> Database Driver Class Initialized
INFO - 2016-09-07 14:27:17 --> Controller Class Initialized
DEBUG - 2016-09-07 14:27:17 --> Index MX_Controller Initialized
INFO - 2016-09-07 14:27:17 --> Model Class Initialized
INFO - 2016-09-07 14:27:17 --> Model Class Initialized
DEBUG - 2016-09-07 14:27:17 --> Anggota MX_Controller Initialized
INFO - 2016-09-07 14:27:17 --> Final output sent to browser
DEBUG - 2016-09-07 14:27:17 --> Total execution time: 0.7744
INFO - 2016-09-07 14:27:18 --> Config Class Initialized
INFO - 2016-09-07 14:27:18 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:27:18 --> UTF-8 Support Enabled
INFO - 2016-09-07 14:27:18 --> Utf8 Class Initialized
INFO - 2016-09-07 14:27:18 --> URI Class Initialized
INFO - 2016-09-07 14:27:18 --> Router Class Initialized
INFO - 2016-09-07 14:27:18 --> Output Class Initialized
INFO - 2016-09-07 14:27:18 --> Security Class Initialized
DEBUG - 2016-09-07 14:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 14:27:18 --> Input Class Initialized
INFO - 2016-09-07 14:27:18 --> Language Class Initialized
INFO - 2016-09-07 14:27:18 --> Language Class Initialized
INFO - 2016-09-07 14:27:19 --> Config Class Initialized
INFO - 2016-09-07 14:27:19 --> Loader Class Initialized
INFO - 2016-09-07 14:27:19 --> Helper loaded: url_helper
INFO - 2016-09-07 14:27:19 --> Database Driver Class Initialized
INFO - 2016-09-07 14:27:19 --> Controller Class Initialized
DEBUG - 2016-09-07 14:27:19 --> Index MX_Controller Initialized
INFO - 2016-09-07 14:27:19 --> Model Class Initialized
INFO - 2016-09-07 14:27:19 --> Model Class Initialized
DEBUG - 2016-09-07 14:27:19 --> Anggota MX_Controller Initialized
INFO - 2016-09-07 14:27:19 --> Final output sent to browser
DEBUG - 2016-09-07 14:27:19 --> Total execution time: 0.7832
INFO - 2016-09-07 14:27:20 --> Config Class Initialized
INFO - 2016-09-07 14:27:20 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:27:20 --> UTF-8 Support Enabled
INFO - 2016-09-07 14:27:20 --> Utf8 Class Initialized
INFO - 2016-09-07 14:27:20 --> URI Class Initialized
INFO - 2016-09-07 14:27:20 --> Router Class Initialized
INFO - 2016-09-07 14:27:20 --> Output Class Initialized
INFO - 2016-09-07 14:27:20 --> Security Class Initialized
DEBUG - 2016-09-07 14:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 14:27:20 --> Input Class Initialized
INFO - 2016-09-07 14:27:20 --> Language Class Initialized
INFO - 2016-09-07 14:27:20 --> Language Class Initialized
INFO - 2016-09-07 14:27:20 --> Config Class Initialized
INFO - 2016-09-07 14:27:20 --> Loader Class Initialized
INFO - 2016-09-07 14:27:20 --> Helper loaded: url_helper
INFO - 2016-09-07 14:27:20 --> Database Driver Class Initialized
INFO - 2016-09-07 14:27:20 --> Controller Class Initialized
DEBUG - 2016-09-07 14:27:20 --> Index MX_Controller Initialized
INFO - 2016-09-07 14:27:20 --> Model Class Initialized
INFO - 2016-09-07 14:27:20 --> Model Class Initialized
DEBUG - 2016-09-07 14:27:20 --> Anggota MX_Controller Initialized
INFO - 2016-09-07 14:27:20 --> Final output sent to browser
DEBUG - 2016-09-07 14:27:20 --> Total execution time: 0.7863
INFO - 2016-09-07 14:27:21 --> Config Class Initialized
INFO - 2016-09-07 14:27:21 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:27:21 --> UTF-8 Support Enabled
INFO - 2016-09-07 14:27:21 --> Utf8 Class Initialized
INFO - 2016-09-07 14:27:22 --> URI Class Initialized
INFO - 2016-09-07 14:27:22 --> Router Class Initialized
INFO - 2016-09-07 14:27:22 --> Output Class Initialized
INFO - 2016-09-07 14:27:22 --> Security Class Initialized
DEBUG - 2016-09-07 14:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 14:27:22 --> Input Class Initialized
INFO - 2016-09-07 14:27:22 --> Language Class Initialized
INFO - 2016-09-07 14:27:22 --> Language Class Initialized
INFO - 2016-09-07 14:27:22 --> Config Class Initialized
INFO - 2016-09-07 14:27:22 --> Loader Class Initialized
INFO - 2016-09-07 14:27:22 --> Helper loaded: url_helper
INFO - 2016-09-07 14:27:22 --> Database Driver Class Initialized
INFO - 2016-09-07 14:27:22 --> Controller Class Initialized
DEBUG - 2016-09-07 14:27:22 --> Index MX_Controller Initialized
INFO - 2016-09-07 14:27:22 --> Model Class Initialized
INFO - 2016-09-07 14:27:22 --> Model Class Initialized
DEBUG - 2016-09-07 14:27:22 --> Anggota MX_Controller Initialized
INFO - 2016-09-07 14:27:22 --> Final output sent to browser
DEBUG - 2016-09-07 14:27:22 --> Total execution time: 0.8001
INFO - 2016-09-07 14:27:23 --> Config Class Initialized
INFO - 2016-09-07 14:27:23 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:27:23 --> UTF-8 Support Enabled
INFO - 2016-09-07 14:27:23 --> Utf8 Class Initialized
INFO - 2016-09-07 14:27:23 --> URI Class Initialized
INFO - 2016-09-07 14:27:23 --> Router Class Initialized
INFO - 2016-09-07 14:27:23 --> Output Class Initialized
INFO - 2016-09-07 14:27:23 --> Security Class Initialized
DEBUG - 2016-09-07 14:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 14:27:23 --> Input Class Initialized
INFO - 2016-09-07 14:27:24 --> Language Class Initialized
INFO - 2016-09-07 14:27:24 --> Language Class Initialized
INFO - 2016-09-07 14:27:24 --> Config Class Initialized
INFO - 2016-09-07 14:27:24 --> Loader Class Initialized
INFO - 2016-09-07 14:27:24 --> Helper loaded: url_helper
INFO - 2016-09-07 14:27:24 --> Database Driver Class Initialized
INFO - 2016-09-07 14:27:24 --> Controller Class Initialized
DEBUG - 2016-09-07 14:27:24 --> Index MX_Controller Initialized
INFO - 2016-09-07 14:27:24 --> Model Class Initialized
INFO - 2016-09-07 14:27:24 --> Model Class Initialized
DEBUG - 2016-09-07 14:27:24 --> Anggota MX_Controller Initialized
INFO - 2016-09-07 14:27:24 --> Final output sent to browser
DEBUG - 2016-09-07 14:27:24 --> Total execution time: 0.8028
INFO - 2016-09-07 14:27:26 --> Config Class Initialized
INFO - 2016-09-07 14:27:26 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:27:26 --> UTF-8 Support Enabled
INFO - 2016-09-07 14:27:26 --> Utf8 Class Initialized
INFO - 2016-09-07 14:27:26 --> URI Class Initialized
INFO - 2016-09-07 14:27:26 --> Router Class Initialized
INFO - 2016-09-07 14:27:26 --> Output Class Initialized
INFO - 2016-09-07 14:27:26 --> Security Class Initialized
DEBUG - 2016-09-07 14:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 14:27:26 --> Input Class Initialized
INFO - 2016-09-07 14:27:26 --> Language Class Initialized
INFO - 2016-09-07 14:27:26 --> Language Class Initialized
INFO - 2016-09-07 14:27:26 --> Config Class Initialized
INFO - 2016-09-07 14:27:26 --> Loader Class Initialized
INFO - 2016-09-07 14:27:26 --> Helper loaded: url_helper
INFO - 2016-09-07 14:27:26 --> Database Driver Class Initialized
INFO - 2016-09-07 14:27:26 --> Controller Class Initialized
DEBUG - 2016-09-07 14:27:26 --> Index MX_Controller Initialized
INFO - 2016-09-07 14:27:26 --> Model Class Initialized
INFO - 2016-09-07 14:27:26 --> Model Class Initialized
DEBUG - 2016-09-07 14:27:26 --> Anggota MX_Controller Initialized
INFO - 2016-09-07 14:27:26 --> Final output sent to browser
DEBUG - 2016-09-07 14:27:26 --> Total execution time: 0.8161
INFO - 2016-09-07 14:27:28 --> Config Class Initialized
INFO - 2016-09-07 14:27:28 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:27:28 --> UTF-8 Support Enabled
INFO - 2016-09-07 14:27:28 --> Utf8 Class Initialized
INFO - 2016-09-07 14:27:28 --> URI Class Initialized
INFO - 2016-09-07 14:27:28 --> Router Class Initialized
INFO - 2016-09-07 14:27:28 --> Output Class Initialized
INFO - 2016-09-07 14:27:28 --> Security Class Initialized
DEBUG - 2016-09-07 14:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 14:27:28 --> Input Class Initialized
INFO - 2016-09-07 14:27:28 --> Language Class Initialized
INFO - 2016-09-07 14:27:28 --> Language Class Initialized
INFO - 2016-09-07 14:27:28 --> Config Class Initialized
INFO - 2016-09-07 14:27:28 --> Loader Class Initialized
INFO - 2016-09-07 14:27:28 --> Helper loaded: url_helper
INFO - 2016-09-07 14:27:28 --> Database Driver Class Initialized
INFO - 2016-09-07 14:27:28 --> Controller Class Initialized
DEBUG - 2016-09-07 14:27:28 --> Index MX_Controller Initialized
INFO - 2016-09-07 14:27:28 --> Model Class Initialized
INFO - 2016-09-07 14:27:28 --> Model Class Initialized
DEBUG - 2016-09-07 14:27:28 --> Anggota MX_Controller Initialized
INFO - 2016-09-07 14:27:29 --> Final output sent to browser
DEBUG - 2016-09-07 14:27:29 --> Total execution time: 0.8127
INFO - 2016-09-07 14:27:30 --> Config Class Initialized
INFO - 2016-09-07 14:27:30 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:27:30 --> UTF-8 Support Enabled
INFO - 2016-09-07 14:27:30 --> Utf8 Class Initialized
INFO - 2016-09-07 14:27:30 --> URI Class Initialized
INFO - 2016-09-07 14:27:30 --> Router Class Initialized
INFO - 2016-09-07 14:27:30 --> Output Class Initialized
INFO - 2016-09-07 14:27:30 --> Security Class Initialized
DEBUG - 2016-09-07 14:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 14:27:30 --> Input Class Initialized
INFO - 2016-09-07 14:27:30 --> Language Class Initialized
INFO - 2016-09-07 14:27:30 --> Language Class Initialized
INFO - 2016-09-07 14:27:30 --> Config Class Initialized
INFO - 2016-09-07 14:27:30 --> Loader Class Initialized
INFO - 2016-09-07 14:27:30 --> Helper loaded: url_helper
INFO - 2016-09-07 14:27:30 --> Database Driver Class Initialized
INFO - 2016-09-07 14:27:30 --> Controller Class Initialized
DEBUG - 2016-09-07 14:27:30 --> Index MX_Controller Initialized
INFO - 2016-09-07 14:27:30 --> Model Class Initialized
INFO - 2016-09-07 14:27:30 --> Model Class Initialized
DEBUG - 2016-09-07 14:27:30 --> Anggota MX_Controller Initialized
INFO - 2016-09-07 14:27:30 --> Final output sent to browser
DEBUG - 2016-09-07 14:27:31 --> Total execution time: 0.8508
INFO - 2016-09-07 14:27:32 --> Config Class Initialized
INFO - 2016-09-07 14:27:32 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:27:32 --> UTF-8 Support Enabled
INFO - 2016-09-07 14:27:32 --> Utf8 Class Initialized
INFO - 2016-09-07 14:27:32 --> URI Class Initialized
INFO - 2016-09-07 14:27:32 --> Router Class Initialized
INFO - 2016-09-07 14:27:32 --> Output Class Initialized
INFO - 2016-09-07 14:27:32 --> Security Class Initialized
DEBUG - 2016-09-07 14:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 14:27:32 --> Input Class Initialized
INFO - 2016-09-07 14:27:32 --> Language Class Initialized
INFO - 2016-09-07 14:27:32 --> Language Class Initialized
INFO - 2016-09-07 14:27:32 --> Config Class Initialized
INFO - 2016-09-07 14:27:32 --> Loader Class Initialized
INFO - 2016-09-07 14:27:32 --> Helper loaded: url_helper
INFO - 2016-09-07 14:27:32 --> Database Driver Class Initialized
INFO - 2016-09-07 14:27:32 --> Controller Class Initialized
DEBUG - 2016-09-07 14:27:32 --> Index MX_Controller Initialized
INFO - 2016-09-07 14:27:32 --> Model Class Initialized
INFO - 2016-09-07 14:27:32 --> Model Class Initialized
DEBUG - 2016-09-07 14:27:32 --> Anggota MX_Controller Initialized
INFO - 2016-09-07 14:27:33 --> Final output sent to browser
DEBUG - 2016-09-07 14:27:33 --> Total execution time: 1.0053
INFO - 2016-09-07 14:27:37 --> Config Class Initialized
INFO - 2016-09-07 14:27:37 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:27:37 --> UTF-8 Support Enabled
INFO - 2016-09-07 14:27:37 --> Utf8 Class Initialized
INFO - 2016-09-07 14:27:37 --> URI Class Initialized
INFO - 2016-09-07 14:27:37 --> Router Class Initialized
INFO - 2016-09-07 14:27:37 --> Output Class Initialized
INFO - 2016-09-07 14:27:37 --> Security Class Initialized
DEBUG - 2016-09-07 14:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 14:27:37 --> Input Class Initialized
INFO - 2016-09-07 14:27:37 --> Language Class Initialized
INFO - 2016-09-07 14:27:37 --> Language Class Initialized
INFO - 2016-09-07 14:27:37 --> Config Class Initialized
INFO - 2016-09-07 14:27:37 --> Loader Class Initialized
INFO - 2016-09-07 14:27:37 --> Helper loaded: url_helper
INFO - 2016-09-07 14:27:37 --> Database Driver Class Initialized
INFO - 2016-09-07 14:27:37 --> Controller Class Initialized
DEBUG - 2016-09-07 14:27:37 --> Index MX_Controller Initialized
INFO - 2016-09-07 14:27:37 --> Model Class Initialized
INFO - 2016-09-07 14:27:37 --> Model Class Initialized
DEBUG - 2016-09-07 14:27:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 14:27:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 14:27:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 14:27:37 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-07 14:27:37 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-07 14:27:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 14:27:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-07 14:27:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 14:27:37 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 14:27:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 14:27:38 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 14:27:38 --> Final output sent to browser
DEBUG - 2016-09-07 14:27:38 --> Total execution time: 1.0473
INFO - 2016-09-07 14:52:30 --> Config Class Initialized
INFO - 2016-09-07 14:52:30 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:52:30 --> UTF-8 Support Enabled
INFO - 2016-09-07 14:52:30 --> Utf8 Class Initialized
INFO - 2016-09-07 14:52:30 --> URI Class Initialized
INFO - 2016-09-07 14:52:30 --> Router Class Initialized
INFO - 2016-09-07 14:52:30 --> Output Class Initialized
INFO - 2016-09-07 14:52:30 --> Security Class Initialized
DEBUG - 2016-09-07 14:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 14:52:30 --> Input Class Initialized
INFO - 2016-09-07 14:52:30 --> Language Class Initialized
INFO - 2016-09-07 14:52:30 --> Language Class Initialized
INFO - 2016-09-07 14:52:30 --> Config Class Initialized
INFO - 2016-09-07 14:52:30 --> Loader Class Initialized
INFO - 2016-09-07 14:52:30 --> Helper loaded: url_helper
INFO - 2016-09-07 14:52:30 --> Database Driver Class Initialized
INFO - 2016-09-07 14:52:30 --> Controller Class Initialized
DEBUG - 2016-09-07 14:52:30 --> Index MX_Controller Initialized
INFO - 2016-09-07 14:52:30 --> Model Class Initialized
INFO - 2016-09-07 14:52:30 --> Model Class Initialized
DEBUG - 2016-09-07 14:52:30 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 14:52:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 14:52:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 14:52:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 14:52:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 14:52:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 14:52:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 14:52:31 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 14:52:31 --> Final output sent to browser
DEBUG - 2016-09-07 14:52:31 --> Total execution time: 0.8790
INFO - 2016-09-07 14:54:01 --> Config Class Initialized
INFO - 2016-09-07 14:54:01 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:54:01 --> UTF-8 Support Enabled
INFO - 2016-09-07 14:54:01 --> Utf8 Class Initialized
INFO - 2016-09-07 14:54:01 --> URI Class Initialized
INFO - 2016-09-07 14:54:01 --> Router Class Initialized
INFO - 2016-09-07 14:54:01 --> Output Class Initialized
INFO - 2016-09-07 14:54:01 --> Security Class Initialized
DEBUG - 2016-09-07 14:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 14:54:01 --> Input Class Initialized
INFO - 2016-09-07 14:54:01 --> Language Class Initialized
INFO - 2016-09-07 14:54:01 --> Language Class Initialized
INFO - 2016-09-07 14:54:01 --> Config Class Initialized
INFO - 2016-09-07 14:54:01 --> Loader Class Initialized
INFO - 2016-09-07 14:54:01 --> Helper loaded: url_helper
INFO - 2016-09-07 14:54:01 --> Database Driver Class Initialized
INFO - 2016-09-07 14:54:01 --> Controller Class Initialized
DEBUG - 2016-09-07 14:54:01 --> Index MX_Controller Initialized
INFO - 2016-09-07 14:54:01 --> Model Class Initialized
INFO - 2016-09-07 14:54:01 --> Model Class Initialized
DEBUG - 2016-09-07 14:54:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 14:54:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 14:54:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 14:54:01 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-07 14:54:01 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-07 14:54:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 14:54:01 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-07 14:54:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 14:54:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 14:54:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 14:54:02 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 14:54:02 --> Final output sent to browser
DEBUG - 2016-09-07 14:54:02 --> Total execution time: 1.0209
INFO - 2016-09-07 14:54:12 --> Config Class Initialized
INFO - 2016-09-07 14:54:12 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:54:12 --> UTF-8 Support Enabled
INFO - 2016-09-07 14:54:12 --> Utf8 Class Initialized
INFO - 2016-09-07 14:54:12 --> URI Class Initialized
INFO - 2016-09-07 14:54:12 --> Router Class Initialized
INFO - 2016-09-07 14:54:12 --> Output Class Initialized
INFO - 2016-09-07 14:54:12 --> Security Class Initialized
DEBUG - 2016-09-07 14:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 14:54:12 --> Input Class Initialized
INFO - 2016-09-07 14:54:12 --> Language Class Initialized
INFO - 2016-09-07 14:54:12 --> Language Class Initialized
INFO - 2016-09-07 14:54:12 --> Config Class Initialized
INFO - 2016-09-07 14:54:12 --> Loader Class Initialized
INFO - 2016-09-07 14:54:12 --> Helper loaded: url_helper
INFO - 2016-09-07 14:54:12 --> Database Driver Class Initialized
INFO - 2016-09-07 14:54:12 --> Controller Class Initialized
DEBUG - 2016-09-07 14:54:12 --> Index MX_Controller Initialized
INFO - 2016-09-07 14:54:12 --> Model Class Initialized
INFO - 2016-09-07 14:54:12 --> Model Class Initialized
DEBUG - 2016-09-07 14:54:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 14:54:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 14:54:12 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 14:54:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 14:54:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 14:54:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 14:54:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 14:54:13 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 14:54:13 --> Final output sent to browser
DEBUG - 2016-09-07 14:54:13 --> Total execution time: 0.9799
INFO - 2016-09-07 14:54:17 --> Config Class Initialized
INFO - 2016-09-07 14:54:17 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:54:17 --> UTF-8 Support Enabled
INFO - 2016-09-07 14:54:18 --> Utf8 Class Initialized
INFO - 2016-09-07 14:54:18 --> URI Class Initialized
INFO - 2016-09-07 14:54:18 --> Router Class Initialized
INFO - 2016-09-07 14:54:18 --> Output Class Initialized
INFO - 2016-09-07 14:54:18 --> Security Class Initialized
DEBUG - 2016-09-07 14:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 14:54:18 --> Input Class Initialized
INFO - 2016-09-07 14:54:18 --> Language Class Initialized
INFO - 2016-09-07 14:54:18 --> Language Class Initialized
INFO - 2016-09-07 14:54:18 --> Config Class Initialized
INFO - 2016-09-07 14:54:18 --> Loader Class Initialized
INFO - 2016-09-07 14:54:18 --> Helper loaded: url_helper
INFO - 2016-09-07 14:54:18 --> Database Driver Class Initialized
INFO - 2016-09-07 14:54:18 --> Controller Class Initialized
DEBUG - 2016-09-07 14:54:18 --> Index MX_Controller Initialized
INFO - 2016-09-07 14:54:18 --> Model Class Initialized
INFO - 2016-09-07 14:54:18 --> Model Class Initialized
DEBUG - 2016-09-07 14:54:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 14:54:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 14:54:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 14:54:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 14:54:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 14:54:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 14:54:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 14:54:18 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 14:54:18 --> Final output sent to browser
DEBUG - 2016-09-07 14:54:18 --> Total execution time: 0.8827
INFO - 2016-09-07 14:54:24 --> Config Class Initialized
INFO - 2016-09-07 14:54:24 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:54:25 --> UTF-8 Support Enabled
INFO - 2016-09-07 14:54:25 --> Utf8 Class Initialized
INFO - 2016-09-07 14:54:25 --> URI Class Initialized
INFO - 2016-09-07 14:54:25 --> Router Class Initialized
INFO - 2016-09-07 14:54:25 --> Output Class Initialized
INFO - 2016-09-07 14:54:25 --> Security Class Initialized
DEBUG - 2016-09-07 14:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 14:54:25 --> Input Class Initialized
INFO - 2016-09-07 14:54:25 --> Language Class Initialized
INFO - 2016-09-07 14:54:25 --> Language Class Initialized
INFO - 2016-09-07 14:54:25 --> Config Class Initialized
INFO - 2016-09-07 14:54:25 --> Loader Class Initialized
INFO - 2016-09-07 14:54:25 --> Helper loaded: url_helper
INFO - 2016-09-07 14:54:25 --> Database Driver Class Initialized
INFO - 2016-09-07 14:54:25 --> Controller Class Initialized
DEBUG - 2016-09-07 14:54:25 --> Index MX_Controller Initialized
INFO - 2016-09-07 14:54:25 --> Model Class Initialized
INFO - 2016-09-07 14:54:25 --> Model Class Initialized
DEBUG - 2016-09-07 14:54:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 14:54:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 14:54:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 14:54:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 14:54:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 14:54:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 14:54:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 14:54:25 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 14:54:25 --> Final output sent to browser
DEBUG - 2016-09-07 14:54:25 --> Total execution time: 0.9822
INFO - 2016-09-07 14:54:41 --> Config Class Initialized
INFO - 2016-09-07 14:54:41 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:54:41 --> UTF-8 Support Enabled
INFO - 2016-09-07 14:54:41 --> Utf8 Class Initialized
INFO - 2016-09-07 14:54:41 --> URI Class Initialized
INFO - 2016-09-07 14:54:41 --> Router Class Initialized
INFO - 2016-09-07 14:54:41 --> Output Class Initialized
INFO - 2016-09-07 14:54:41 --> Security Class Initialized
DEBUG - 2016-09-07 14:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 14:54:41 --> Input Class Initialized
INFO - 2016-09-07 14:54:41 --> Language Class Initialized
INFO - 2016-09-07 14:54:41 --> Language Class Initialized
INFO - 2016-09-07 14:54:41 --> Config Class Initialized
INFO - 2016-09-07 14:54:41 --> Loader Class Initialized
INFO - 2016-09-07 14:54:41 --> Helper loaded: url_helper
INFO - 2016-09-07 14:54:41 --> Database Driver Class Initialized
INFO - 2016-09-07 14:54:41 --> Controller Class Initialized
DEBUG - 2016-09-07 14:54:41 --> Index MX_Controller Initialized
INFO - 2016-09-07 14:54:41 --> Model Class Initialized
INFO - 2016-09-07 14:54:41 --> Model Class Initialized
DEBUG - 2016-09-07 14:54:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 14:54:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 14:54:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 14:54:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 14:54:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 14:54:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 14:54:41 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 14:54:42 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 14:54:42 --> Final output sent to browser
DEBUG - 2016-09-07 14:54:42 --> Total execution time: 0.8912
INFO - 2016-09-07 17:11:03 --> Config Class Initialized
INFO - 2016-09-07 17:11:03 --> Hooks Class Initialized
DEBUG - 2016-09-07 17:11:03 --> UTF-8 Support Enabled
INFO - 2016-09-07 17:11:03 --> Utf8 Class Initialized
INFO - 2016-09-07 17:11:03 --> URI Class Initialized
INFO - 2016-09-07 17:11:03 --> Router Class Initialized
INFO - 2016-09-07 17:11:03 --> Output Class Initialized
INFO - 2016-09-07 17:11:03 --> Security Class Initialized
DEBUG - 2016-09-07 17:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 17:11:03 --> Input Class Initialized
INFO - 2016-09-07 17:11:03 --> Language Class Initialized
INFO - 2016-09-07 17:11:03 --> Language Class Initialized
INFO - 2016-09-07 17:11:03 --> Config Class Initialized
INFO - 2016-09-07 17:11:03 --> Loader Class Initialized
INFO - 2016-09-07 17:11:03 --> Helper loaded: url_helper
INFO - 2016-09-07 17:11:03 --> Database Driver Class Initialized
INFO - 2016-09-07 17:11:03 --> Controller Class Initialized
DEBUG - 2016-09-07 17:11:03 --> Index MX_Controller Initialized
INFO - 2016-09-07 17:11:03 --> Model Class Initialized
INFO - 2016-09-07 17:11:03 --> Model Class Initialized
DEBUG - 2016-09-07 17:11:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 17:11:03 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 17:11:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 17:11:04 --> File already loaded: E:\SERVER\htdocs\koperasiweda\application\controllers/../modules/anggota/controllers/Anggota.php
DEBUG - 2016-09-07 17:11:04 --> Anggota MX_Controller Initialized
DEBUG - 2016-09-07 17:11:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/form_anggota.php
DEBUG - 2016-09-07 17:11:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/list_anggota.php
DEBUG - 2016-09-07 17:11:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 17:11:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 17:11:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 17:11:04 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 17:11:04 --> Final output sent to browser
DEBUG - 2016-09-07 17:11:04 --> Total execution time: 0.9753
INFO - 2016-09-07 17:24:28 --> Config Class Initialized
INFO - 2016-09-07 17:24:28 --> Hooks Class Initialized
DEBUG - 2016-09-07 17:24:28 --> UTF-8 Support Enabled
INFO - 2016-09-07 17:24:28 --> Utf8 Class Initialized
INFO - 2016-09-07 17:24:28 --> URI Class Initialized
INFO - 2016-09-07 17:24:28 --> Router Class Initialized
INFO - 2016-09-07 17:24:28 --> Output Class Initialized
INFO - 2016-09-07 17:24:28 --> Security Class Initialized
DEBUG - 2016-09-07 17:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-07 17:24:28 --> Input Class Initialized
INFO - 2016-09-07 17:24:28 --> Language Class Initialized
INFO - 2016-09-07 17:24:28 --> Language Class Initialized
INFO - 2016-09-07 17:24:28 --> Config Class Initialized
INFO - 2016-09-07 17:24:28 --> Loader Class Initialized
INFO - 2016-09-07 17:24:28 --> Helper loaded: url_helper
INFO - 2016-09-07 17:24:28 --> Database Driver Class Initialized
INFO - 2016-09-07 17:24:28 --> Controller Class Initialized
DEBUG - 2016-09-07 17:24:28 --> Index MX_Controller Initialized
INFO - 2016-09-07 17:24:28 --> Model Class Initialized
INFO - 2016-09-07 17:24:28 --> Model Class Initialized
DEBUG - 2016-09-07 17:24:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/head.php
DEBUG - 2016-09-07 17:24:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/left_menu.php
DEBUG - 2016-09-07 17:24:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/top_menu.php
DEBUG - 2016-09-07 17:24:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content/dashboard.php
DEBUG - 2016-09-07 17:24:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/page_content.php
DEBUG - 2016-09-07 17:24:28 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/foot.php
DEBUG - 2016-09-07 17:24:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/script.php
DEBUG - 2016-09-07 17:24:29 --> File loaded: E:\SERVER\htdocs\koperasiweda\application\views\main_html/content.php
INFO - 2016-09-07 17:24:29 --> Final output sent to browser
DEBUG - 2016-09-07 17:24:29 --> Total execution time: 0.9568
