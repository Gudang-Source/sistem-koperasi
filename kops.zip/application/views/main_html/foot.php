        <footer>
          <div class="pull-right">
            Muhammad Handharbeni & Andrias Sofian Adinata
          </div>
          <div class="clearfix"></div>
        </footer>