<div class="posting">
   <fieldset width='80%'>
      <legend>
         <h5><strong>SURAT PERJANJIAN<br></strong></h5>
      </legend>
      <div id="border">
         <p align="center">
            <img src="http://1.bp.blogspot.com/-seEGVAJ0wNs/VCth3DKB88I/AAAAAAAAATQ/l4COGF9M250/s1600/logo.png" alt="image"><br>
            <b>KOP SURAT LKM/KOPERASI</b>
         </p>
         <hr>
         <hr>
         <br>
         <p align="center"><b>SURAT PERJANJIAN</b><br>No : ....... /LKM. ........ / ................. /.......... / 20......</p>
         Yang bertanda tangan dibawah ini:
         <table style="width:50%;" border="0">
            <tbody>
               <tr>
                  <td style="width:30%;">Nama</td>
                  <td>: <?=$detailUser->row()->nama?></td>                  
               </tr>
               <tr>
                  <td>Tempat, tanggal lahir<br></td>
                  <td>: <?=$detailUser->row()->tanggal_lahir?></td>
               </tr>
<!--                <tr>
                  <td valign="top">Pekerjaan</td>
                  <td valign="top">: Manager LKM .................................................<br></td>
               </tr>
 -->               <tr>
                  <td valign="top">Alamat<br></td>
                  <td valign="top">: <?=$detailUser->row()->alamat?></td>
               </tr>
            </tbody>
         </table>
         <p align="justify">Bertindak untuk dan atas nama KOPERASI WETA yang selanjutnya disebut <b>PIHAK PERTAMA</b>.</p>
         <table style="width:100%;" border="0">
            <tbody>
               <tr>
                  <td style="width:30%;">Nama</td>
                  <td>: <?=$detailPinjaman->row()->nama_anggota?></td>
               </tr>
               <tr>
                  <td>Tempat, tanggal lahir<br></td>
                  <td>: <?=$detailPinjaman->row()->tanggal_lahir?></td>
               </tr>
               <tr>
                  <td valign="top">Alamat<br></td>
                  <td>: <?=$detailPinjaman->row()->alamat_anggota?></td>
               </tr>
            </tbody>
         </table>
         <p align="justify">selanjutnya disebut <b>PIHAK KEDUA</b>.</p>
         <br>
         <p align="justify">Pada hari ini <?=date('D')?> tanggal <?=date('d')?> bulan <?=date('M')?> tahun <?=date('Y')?> , kedua belah pihak sepakat untuk mengadakan perjanjian utang pihutang/pinjaman dengan kesepakatan sebagai berikut :</p>
         <br>
         <div align="center"><b>PASAL  1<br>JUMLAH KREDIT DAN BUNGA
            </b>
         </div>
         <p align="justify"><b>Pihak  Pertama</b>  memberikan  kredit / pinjaman  uang  kepada  <b>Pihak  Kedua</b>  sebesar
            Rp. <?=$detailPinjaman->row()->jumlah_pinjaman?> <i>(<?=modules::run('admin/index/Terbilang',$detailPinjaman->row()->jumlah_pinjaman)?>)&nbsp;</i> dan disepakati dengan bunga sebesar <?=$detailPinjaman->row()->bunga?>% yang dibayarkan setiap bulan.
         </p>
         <div align="center"><b>PASAL 2<br>ADMINISTRASI, PROVISI DAN TABUNGAN KOPERASI</b></div>
         <p align="justify"><b>Pihak Kedua</b> bersedia melunasi uang administrasi sebesar 2% dan Provisi kredit sebesar 1% pada saat sebelum transaksi kredit dilaksanakan.</p>
         <div align="center"><b>PASAL 3<br>ANGSURAN KREDIT</b></div>
         <p align="justify"></p>
         <ol>
            <li><b>Pihak Kedua</b> akan mengangsur atas kredit/pinjaman uang tersebut selama <?=$detailPinjaman->row()->jangka_waktu?> (<?=$detailPinjaman->row()->jangka_waktu?>) kali  angsuran bulanan sebesar  Rp. <?=$detailPinjaman->row()->pokok_angsuran?>
               <i>(<?=modules::run('admin/index/Terbilang',$detailPinjaman->row()->pokok_angsuran)?>) </i> per <?=$detailPinjaman->row()->pokok_angsuran+$detailPinjaman->row()->bunga_angsuran?> (Pokok + bunga), terhitung  mulai  bulan <?=date('m')+1?> s/d  bulan <?php $dateNow = date('m')+1=='12'?0:date('m'); ?><?=($dateNow)+$detailPinjaman->row()->jangka_waktu?> setiap tanggal jatuh tempo.
            </li>
            <li><b>Pihak Kedua </b>bersedia membayar sendiri angsuran kredit/pinjaman uang tersebut di kantor yang telah ditetapkan oleh <b>Pihak Pertama</b>.</li>
         </ol>
         <p></p>
         <div align="center"><b>PASAL 4<br>JAMINAN KREDIT</b></div>
         <p align="justify"><b>Pihak Kedua</b> memberikan jaminan atas kredit/pinjaman uang dari Pihak Pertama dengan barang miliknya sendiri atau berupa jaminan usaha berupa : <?=$detailJaminan->row()->jaminan?> </p>
         <div align="center"><b>PASAL 5<br>S A N K S I</b></div>
         <p align="justify"></p>
         <ol>
            <li>
               <div align="justify">Keterlambatan pembayaran angsuran dengan sengaja maupun tidak sengaja <b>Pihak Kedua</b> bersedia membayar denda yang telah ditetapkan oleh <b>Pihak Pertama</b> yaitu sebesar 1% perbulan kali saldo terhitung pada minggu termaksud/jatuh tempo.</div>
            </li>
            <li>
               <div align="justify">Keterlambatan pembayaran angsuran dengan sengaja maupun tidak sengaja oleh <b>Pihak Kedua</b> yang lamanya  hingga mencapai batas waktu 3 (tiga) kali setelah jatuh tempo, maka <b>Pihak Kedua</b> bersedia menyerahkan barang yang dijaminkan kepada <b>Pihak Pertama</b> dengan tanpa mempersulit proses dan atau langsung diadakan proses jual beli antara kedua belah pihak atas barang jaminan tersebut.</div>
            </li>
         </ol>
         <p></p>
         <div align="center"><b>PASAL 6<br>RESIKO KREDIT DAN ASURANSI</b></div>
         <p align="justify"></p>
         <ol>
            <li><b>Pihak Pertama</b> menyetujui permohonan dari <b>Pihak Kedua</b> bahwa proses kredit ini tanpa adanya jaminan dari pihak asuransi manapun.</li>
            <li>Maka dalam hal resiko pada <b>Pihak Kedua</b> selama masa kredit belum berakhir, <b>Pihak Kedua</b> melimpahkan pertanggung jawaban kredit ini kepada ahli warisnya.</li>
         </ol>
         <p></p>
         <div align="center"><b>PASAL 7<br>LAIN-LAIN DAN PENUTUP</b></div>
         <p align="justify">Hal lain-lain yang belum tertuang dalam perjanjian ini kedua belah pihak sepakat untuk diselesaikan dengan cara musyawarah dan mufakat. Dan untuk itu pula kedua belah pihak sepakat menetapkan Kantor Pengadilan Negeri ................................ sebagai tempat penyelesaian akhir hukum yang timbul karenanya.</p>
         <table style="width:100%;" border="0">
            <tbody>
               <tr>
                  <td><br></td>
                  <td><br></td>
               </tr>
               <tr>
                  <td>
                     <div class="text-center"><strong><br>Pihak Pertama,</strong></div>
                  </td>
                  <td align="center">.............., ...................................2014<br><strong>Pihak Kedua,</strong></td>
               </tr>
               <tr>
                  <td><br></td>
                  <td><img src="http://2.bp.blogspot.com/-B09YbhxoZFs/VC3ybSFCYBI/AAAAAAAAATg/eZNrkOfShJw/s1600/materai.jpg" align="left" hspace="12"></td>
               </tr>
               <tr>
                  <td>
                     <div class="text-center">( <strong><u>.................................................</u></strong> )</div>
                  </td>
                  <td>
                     <div class="text-center">( <strong><u>.................................................</u></strong> )</div>
                  </td>
               </tr>
            </tbody>
         </table>
      </div>
   </fieldset>
</div>
