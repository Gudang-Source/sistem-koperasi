              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Upload Foto Profil</h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">                    
                    <form action="<?=base_url('admin/index/do_upload_foto')?>" class="dropzone"></form>
                    <br />
                    <br />
                    <br />
                    <br />
                  </div>
                </div>
              </div>