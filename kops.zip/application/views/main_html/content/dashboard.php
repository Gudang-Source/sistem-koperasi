<div class="col-md-12 col-sm-12 col-xs-12">
  <div class="dashboard_graph">

      <div class="row x_title">
        <div class="col-md-6">
          <h3>Grafik Pinjaman dan Tabungan</h3>
        </div>
      </div>
    <div class="col-md-12 col-sm-12 col-xs-12">
      <div id="placeholder33" style="height: 260px; display: none" class="demo-placeholder"></div>
      <div style="width: 100%;">
        <div id="canvas_dahs" class="demo-placeholder" style="width: 100%; height:270px;"></div>
      </div>
    </div>


    <div class="clearfix"></div>
  </div>
  <div class="dashboard_graph">

      <div class="row x_title">
        <div class="col-md-6">
          <h3>Grafik Debit, Kredit dan Saldo</h3>
        </div>
      </div>
    <div class="col-md-12 col-sm-12 col-xs-12">
      <div id="placeholder33" style="height: 260px; display: none" class="demo-placeholder"></div>
      <div style="width: 100%;">
        <div id="canvas_dk" class="demo-placeholder" style="width: 100%; height:270px;"></div>
      </div>
    </div>


    <div class="clearfix"></div>
  </div>
</div>            