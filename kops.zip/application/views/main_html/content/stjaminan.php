<table width="100%" border="0">
	<thead>
		<tr align="center">
			<td colspan="3">BERITA ACARA SERAH TERIMA BARANG</td>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td colspan="3">Pada hari ini <?=date('D')?> Tanggal <?=date('d')?> Bulan <?=date('M')?> Tahun <?=date('Y')?>. Kami yang bertanda tangan dibawah ini :</td>
		</tr>
		<tr>
			<td>Nama</td>
			<td>:</td>
			<td><?=$detailUser->row()->nama?></td>
		</tr>
		<tr>
			<td>Jabatan</td>
			<td>:</td>
			<td>........................................</td>
		</tr>
		<tr>
			<td>Alamat</td>
			<td>:</td>
			<td><?=$detailUser->row()->alamat?></td>
		</tr>
		<tr>
			<td colspan="3">Selanjutnya disebut PIHAK PERTAMA</td>
		</tr>
		<tr>
			<td>Nama</td>
			<td>:</td>
			<td><?=$detailPinjaman->row()->nama_anggota?></td>
		</tr>
		<tr>
			<td>Jabatan</td>
			<td>:</td>
			<td>........................................</td>
		</tr>
		<tr>
			<td>Alamat</td>
			<td>:</td>
			<td><?=$detailPinjaman->row()->alamat_anggota?></td>
		</tr>
		<tr>
			<td colspan="3">Selanjutnya disebut PIHAK KEDUA</td>
		</tr>
		<tr>
			<td colspan="3">PIHAK PERTAMA menyerahkan barang kepada PIHAK KEDUA, dan PIHAK KEDUA menyatakan telah menerima barang dari PIHAK PERTAMA berupa daftar terlampir :</td>
		</tr>		
		<tr>
			<td>Jenis Jaminan</td>
			<td>:</td>
			<td><?=$detailJaminan->row()->jaminan?></td>
		</tr>
		<tr>
			<td>Nomor Surat</td>
			<td>:</td>
			<td><?=$detailJaminan->row()->no_surat?></td>
		</tr>		
		<tr>
			<td colspan="3">
				Demikianlah berita acara serah terima barang ini di perbuat oleh kedua belah pihak, adapun barang-barang tersebut dalam keadaan baik dan cukup, sejak penandatanganan berita acara ini, maka barang tersebut, menjadi tanggung jawab PIHAK KEDUA, memlihara / merawat dengan baik serta dipergunakan untuk keperluan (tempat dimana barang itu dibutuhkan).	
			</td>
		</tr>
		<tr align="center">
			<td>Yang menerima</td>
			<td>&nbsp;</td>
			<td>Yang menyerahkan</td>
		</tr>
		<tr align="center">
			<td>PIHAK PERTAMA</td>
			<td>&nbsp;</td>
			<td>PIHAK KEDUA</td>
		</tr>
		<tr align="center">
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
		</tr>
		<tr align="center">
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
		</tr>
		<tr align="center">
			<td>(...................................................)</td>
			<td>&nbsp;</td>
			<td>(...................................................)</td>
		</tr>
	</tbody>
</table>