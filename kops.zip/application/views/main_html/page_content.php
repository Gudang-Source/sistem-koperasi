        <!-- page content -->
        <div class="right_col" role="main" >
          <div class="row">
            <?php $this->load->view($view); ?>
          </div>                  
        </div>
        <!-- /page content -->